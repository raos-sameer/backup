const copyNpmrc = `for p in packages/*; do cp .npmrc $p; done`;
const manageVersion = `standard-version --message "chore(release): publish v%s ***NO_CI***"`;
const manageVersionDry = `${manageVersion} --dry-run`;

const checkRegistry = `REGISTRY=$(npm config get ui_ci_npm_registry); if [ "$REGISTRY" = "undefined" ]; then echo '*** Artifactory URL not configured ***' ; exit 1; fi`;

module.exports = {
  scripts: {
    default: 'lerna run start --parallel',
    local: 'lerna run start:local --parallel',
    test: {
      default: 'cross-env CI=true BABEL_ENV=test jest --coverage --env=jsdom',
      watch: 'cross-env BABEL_ENV=test jest -u --watch --env=jsdom',
      debug:
        'node --inspect-brk ./node_modules/jest/bin/jest.js --env=jsdom --runInBand --no-cache --watch',
      coverage: 'jest -u --coverage --env=jsdom',
    },
    prepare: 'lerna run build --scope=@wdpui-sirius/securedlendingservicing',
    release: {
      default: `npm start release.prepare && npm start release.publish`,
      prepare: `${
        process.env.BUILD_NUMBER
          ? `${copyNpmrc} && ${checkRegistry}`
          : `${manageVersionDry}`
      }`,
      publish: `${
        process.env.BUILD_NUMBER
          ? `lerna publish --registry $(npm config get ui_ci_npm_registry) --loglevel verbose`
          : `echo *** Dry run! Nothing to publish ***`
      } `,
    },
  },
};
