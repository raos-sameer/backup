module.exports = 'BINARY_MOCK';
