module.exports = function(api) {
  // Cache the configuration & plugins
  // This is so that the plugins & helpers
  // do not recompile each time
  api.cache(true);

  // Presets are synced with WDP UI framework
  // configurations to keep a consistent pattern
  // for development
  const presets = [
    [
      '@babel/preset-env',
      {
        modules: false,
        loose: true,
        targets: {
          browsers: ['last 2 versions', 'ie 10'],
        },
      },
    ],
    '@babel/preset-react',
  ];

  // Default plugins for babel transpilation
  const plugins = [
    'lodash',
    '@babel/plugin-proposal-class-properties',
    '@babel/plugin-syntax-dynamic-import',
  ];

  // Plugins to optimise the production bundle
  if (process.env['ENV'] === 'production') {
    plugins.push('@babel/plugin-external-helpers');
    plugins.push('transform-react-remove-prop-types');
  }

  // Babel environment presets
  const env = {
    test: {
      presets: [
        [
          '@babel/preset-env',
          {
            modules: 'commonjs',
            debug: false,
          },
        ],
        '@babel/preset-react',
        'jest',
      ],
      plugins: [...plugins, 'dynamic-import-node'],
    },
  };

  return {
    presets,
    plugins,
    env,
  };
};
