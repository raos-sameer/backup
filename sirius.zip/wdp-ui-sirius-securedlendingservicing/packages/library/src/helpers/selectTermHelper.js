import { formatDiscount } from './amountFormatter';

export const checkIfItemsExists = itemList => {
  return itemList && itemList.length > 0;
};

export const showAdvantagePackageDiscountText = (
  advantagePackage,
  isExpiryDateLessThanYear,
  discountedSilos,
) => {
  return (
    advantagePackage &&
    !isExpiryDateLessThanYear &&
    checkIfItemsExists(discountedSilos)
  );
};

export const showNoPackageDiscountText = (
  advantagePackage,
  isExpiryDateLessThanYear,
  discountedSilos,
) => {
  return (
    !advantagePackage &&
    !isExpiryDateLessThanYear &&
    checkIfItemsExists(discountedSilos)
  );
};

export const showNoPackagePanel = (
  advantagePackage,
  isExpiryDateLessThanYear,
) => {
  return !advantagePackage && !isExpiryDateLessThanYear;
};

export const isPrincipalCustomer = isPrincipalInterestCustomer => {
  return isPrincipalInterestCustomer;
};

export const showNextButton = (
  repaymentType,
  isExpiryDateLessThanYear,
  selectedYearTerm,
) => {
  return repaymentType && !isExpiryDateLessThanYear && !!selectedYearTerm;
};
export const getInterestTileLabelText = (yearTerm, interestRate) => {
  return `${yearTerm} year fixed rate of ${interestRate}% p.a.`;
};

export const getInterestTileDiscountText = discountRate => {
  return discountRate
    ? `Includes ${formatDiscount(discountRate)}% p.a. discount`
    : '';
};

export const getRepaymentHintText = isPrincipalInterestCustomer => {
  return isPrincipalInterestCustomer
    ? ` principal and interest repayments`
    : ` interest only repayments`;
};
