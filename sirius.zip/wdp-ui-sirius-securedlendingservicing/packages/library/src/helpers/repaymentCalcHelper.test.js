import {
  getInterestOnlyRepaymentAmount,
  getVariableCompCurrentBalanceIO,
  getVariableCompCurrentBalancePIF,
  getInterestRateForLoan,
  getPMT,
  getFixedCompCurrentBalance,
} from './repaymentCalcHelper';
import { REDRAW_LOAN_OPTION, FIXED_LOAN_OPTION } from './constants';

describe('repaymentcalc.helper', () => {
  it('should return repayment amount for interest only for package customer', () => {
    expect(getInterestOnlyRepaymentAmount(300000, 500, 8, 3.4, true)).toBe(850);
  });
  it('should return repayment amount for interest only if its not package customer ', () => {
    expect(getInterestOnlyRepaymentAmount(300000, 500, 8, 3.4, false)).toBe(
      859.42,
    );
  });

  it('should return zero if available balance and other null values ', () => {
    expect(
      getInterestOnlyRepaymentAmount(
        null,
        null,
        null,
        null,
        null,
        false,
        REDRAW_LOAN_OPTION,
      ),
    ).toBe(0);
  });

  it('should return amount if its not redraw customer and no package customer ', () => {
    expect(getInterestOnlyRepaymentAmount(300000, 500, 8, 3.4, false)).toBe(
      859.42,
    );
  });

  it('should return amount if its not redraw customer and package customer ', () => {
    expect(getInterestOnlyRepaymentAmount(300000, 500, 8, 3.4, true)).toBe(850);
  });

  it('should return amount if its not redraw customer and package customer ', () => {
    expect(getInterestOnlyRepaymentAmount(300000, 500, 8, 3.4, true)).toBe(850);
  });

  it('should return variable amount from fixed amount entered by User ', () => {
    expect(getVariableCompCurrentBalanceIO(700000, 15000)).toBe(685000);
  });

  it('should return zero variable amount from fixed amount entered by User ', () => {
    expect(getVariableCompCurrentBalanceIO(0, 0)).toBe(0);
  });

  it('should return zero variable amount from fixed amount entered by User ', () => {
    expect(getVariableCompCurrentBalanceIO(15000, 0)).toBe(15000);
  });
  it('should return variable amount from fixed amount entered by User ', () => {
    expect(getVariableCompCurrentBalancePIF(700000, 1000, 15000)).toBe(686000);
  });

  it('should return zero variable amount from fixed amount entered by User ', () => {
    expect(getVariableCompCurrentBalancePIF(0, 0, 0)).toBe(0);
  });

  it('should return zero variable amount from fixed amount entered by User ', () => {
    expect(getVariableCompCurrentBalancePIF(15000, 1000, 0)).toBe(16000);
  });
  it('should return interest rate value ', () => {
    expect(getInterestRateForLoan(3.5)).toBeCloseTo(0.0029);
  });

  it('should return PMT value if no package', () => {
    expect(getPMT(4.95, 23, 48019.39, 0, false, 300, 8)).toBeCloseTo(
      2214.4041789911303,
    );
  });

  it('should return PMT value if  package', () => {
    expect(getPMT(4.95, 23, 48019.39, 0, true, 300, 8)).toBeCloseTo(
      2192.7053046117694,
    );
  });

  it('should return current balance if no avail balance for fixed component ', () => {
    expect(getFixedCompCurrentBalance(FIXED_LOAN_OPTION, '', 500000)).toBe(
      500000,
    );
  });
  it('should return current balance if no avail balance for fixed component ', () => {
    expect(
      getFixedCompCurrentBalance(REDRAW_LOAN_OPTION, '10000', 500000),
    ).toBe(510000);
  });
});
