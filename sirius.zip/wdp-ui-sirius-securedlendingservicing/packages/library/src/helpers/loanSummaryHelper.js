import {
  VARIABLE_COMPONENT,
  FIXED_COMPONENT,
  NEWLOAN_COMPONENT,
} from './constants';

export const isVariableComponent = componentType => {
  return componentType === VARIABLE_COMPONENT;
};

export const isFixedComponent = componentType => {
  return componentType === FIXED_COMPONENT;
};
export const isNewLoanComponent = componentType => {
  return componentType === NEWLOAN_COMPONENT;
};

export const getMonthlyRepaymentText = componentType => {
  if (isFixedComponent(componentType) || isNewLoanComponent(componentType))
    return 'Indicative monthly repayments';
  return 'Contracted monthly repayments';
};

export const getLoanTypeText = componentType => {
  if (isFixedComponent(componentType) || isNewLoanComponent(componentType))
    return 'Loan balance';
  return 'Current balance';
};
