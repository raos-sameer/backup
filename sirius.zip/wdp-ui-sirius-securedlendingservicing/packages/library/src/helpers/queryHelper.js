/**
 *Parse query string from location.search and return an Object of key and values
 *
 * @param {string} queryString
 * @returns Object of key and value
 */
export const queryStringParse = queryString => {
  const parsed = {};
  if (queryString !== '') {
    queryString
      .substring(queryString.indexOf('?') + 1)
      .split('&')
      .forEach(value => {
        const params = value.split('=');
        const [query, queryValue] = params;
        parsed[query] = queryValue;
      });
  }
  return parsed;
};
