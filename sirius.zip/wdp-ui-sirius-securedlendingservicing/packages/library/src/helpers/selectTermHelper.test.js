import {
  showNoPackagePanel,
  checkIfItemsExists,
  showAdvantagePackageDiscountText,
  showNoPackageDiscountText,
  isPrincipalCustomer,
  getRepaymentHintText,
  showNextButton,
  getInterestTileLabelText,
  getInterestTileDiscountText,
} from './selectTermHelper';

describe('selectTerm.helper', () => {
  it('should return true to show No Package Panel if expiry date is less than year and no package customer', () => {
    expect(showNoPackagePanel(false, false)).toBe(true);
  });
  it('should return false to hide No Package Panel if expiry date is less than year and package customer', () => {
    expect(showNoPackagePanel(true, false)).toBe(false);
  });

  it('should return true if array list item has values', () => {
    const list = [{ Test: '1' }];
    expect(checkIfItemsExists(list)).toBe(true);
  });

  it('should return false if array list item does not has values', () => {
    const list = [];
    expect(checkIfItemsExists(list)).toBe(false);
  });

  it('should return true if package customer and also has discounted silos', () => {
    const list = [{ Test: '1' }];
    expect(showAdvantagePackageDiscountText(true, false, list)).toBe(true);
  });

  it('should return true if not package customer and also has discounted silos', () => {
    const list = [{ Test: '2' }];
    expect(showNoPackageDiscountText(false, false, list)).toBe(true);
  });

  it('should return true if its principal interest customer', () => {
    expect(isPrincipalCustomer(true)).toBe(true);
  });

  it('should show Next Button and return true if repayment option is selected and isExpiryDate is less than year', () => {
    expect(showNextButton('Test repayment', false, true)).toBe(true);
  });
  it('should not show Next Button and return false if repayment option is not selected', () => {
    expect(showNextButton('Test repayment', false, undefined)).toBe(false);
  });
  it('should get the interest tile label text for year term and interest rate passed', () => {
    expect(getInterestTileLabelText('4', '1.23')).toEqual(
      `4 year fixed rate of 1.23% p.a.`,
    );
  });

  it('should get the discount text for discount rate passed', () => {
    expect(getInterestTileDiscountText('1.23')).toEqual(
      `Includes 1.23% p.a. discount`,
    );
    expect(getInterestTileDiscountText('')).toEqual(``);
  });

  it('should get the repayment option current loan hint text for principal and interest customer', () => {
    expect(getRepaymentHintText(true)).toEqual(
      ` principal and interest repayments`,
    );
  });

  it('should get the repayment option current loan hint text for interest only customer', () => {
    expect(getRepaymentHintText(false)).toEqual(` interest only repayments`);
  });
});
