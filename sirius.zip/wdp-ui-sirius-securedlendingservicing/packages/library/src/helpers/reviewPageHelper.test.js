import {
  getReviewHeaderTitleText,
  getDisplayAccountNumber,
  getDisplayBSBNumber,
} from './reviewPageHelper';

describe('reviewPage.helper', () => {
  it('should return You`re fixing your loan if component type is not Split', () => {
    expect(getReviewHeaderTitleText('Text')).toEqual(`You're fixing your loan`);
  });
  it('should test getDisplayAccountNumber', () => {
    expect(getDisplayAccountNumber('')).toEqual('');
  });

  it('should test getDisplayAccountNumber', () => {
    expect(getDisplayAccountNumber('405124599880')).toEqual('599880');
  });

  it('should test getDisplayBSBNumber', () => {
    expect(getDisplayBSBNumber('')).toEqual('');
  });
  it('should test getDisplayBSBNumber', () => {
    expect(getDisplayBSBNumber('405124599880')).toEqual('405-124');
  });
});
