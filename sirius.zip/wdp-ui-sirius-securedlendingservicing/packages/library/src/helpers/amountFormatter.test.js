import {
  roundValue,
  formatAmount,
  decimalFormat,
  currencySymbol,
  formatCurrency,
  formatBalance,
  formatDiscount,
  formatToTwoDecimalPlaces,
} from './amountFormatter';

describe('amountFormatter.helper', () => {
  describe('roundValue', () => {
    it('should round the value upto the decimal values provided as parameter', () => {
      expect(roundValue(1.002, 2)).toEqual(1);
      expect(roundValue('1.002', 2)).toEqual(1);
      expect(roundValue(1.002, 3)).toEqual(1.002);
      expect(roundValue(5.12542, 2)).toEqual(5.13);
      expect(roundValue(5.1234, 2)).toEqual(5.12);
      expect(roundValue('5.1235', 3)).toEqual(5.124);
    });
  });
  describe('currencyFormat', () => {
    it('should return the symbol of currency', () => {
      expect(currencySymbol('')).toEqual('$');
      expect(currencySymbol('AUD')).toEqual('$');
    });

    it('should return a formatted amount of money', () => {
      const amount = 1500000;
      expect(formatCurrency(amount)).toEqual('$1,500,000');
    });

    it('should return 0 if amount is undefined', () => {
      expect(formatCurrency(undefined)).toEqual('$0');
    });

    it('should return 0 if amount is null in bad data', () => {
      expect(formatCurrency(null)).toEqual('$0');
      expect(formatCurrency()).toEqual('$0');
    });
  });

  describe('formatAmount', () => {
    it('should return 1,234.53 for 1234.526', () => {
      expect(formatAmount(1234.526)).toEqual('$1,234.53');
    });
    it('should return 150.26 for 150.255', () => {
      expect(formatAmount(150.255)).toBe('$150.26');
    });
    it('should return 15.57 for 15.5659', () => {
      expect(formatAmount(15.5659)).toBe('$15.57');
    });
    it('should return 1.00 for 1', () => {
      expect(formatAmount(1)).toBe('$1.00');
    });
    it('should return 150.00 for 150', () => {
      expect(formatAmount(150)).toBe('$150.00');
    });
    it('should return 0.28 for 0.284', () => {
      expect(formatAmount(0.284)).toBe('$0.28');
    });
    it('should return 56,464.00 for 56464', () => {
      expect(formatAmount(56464)).toBe('$56,464.00');
    });
    it('should return 123,145,678.00 for 123145678', () => {
      expect(formatAmount(123145678)).toBe('$123,145,678.00');
    });
    it('should return formatted 0.00 for 0', () => {
      expect(formatAmount(0)).toBe('$0.00');
    });
  });

  describe('decimalFormat', () => {
    it('should return 0 for 0.0', () => {
      expect(decimalFormat(0.0)).toEqual('0');
    });
    it('should return 1 for 1', () => {
      expect(decimalFormat(1)).toBe('1');
    });
    it('should return 10 for 10.0', () => {
      expect(decimalFormat(10.0)).toBe('10');
    });
    it('should return 12 for 12.00', () => {
      expect(decimalFormat('12.00')).toBe('12');
    });
    it('should return 1.5 for 1.50', () => {
      expect(decimalFormat('1.50')).toBe('1.5');
    });
    it('should return 1.51 for 1.51', () => {
      expect(decimalFormat(1.51)).toBe('1.51');
    });
    it('should return 1000 for 1000', () => {
      expect(decimalFormat(1000)).toBe('1000');
    });
    it('should return 10000 for 10000', () => {
      expect(decimalFormat(10000)).toBe('10000');
    });
  });

  describe('formatBalance', () => {
    it('should return 0 for 0.0', () => {
      expect(formatBalance(100000.0)).toEqual(100000);
      expect(formatBalance(null)).toEqual('$0.00');
    });
  });
  describe('formatToTwoDecimalPlaces', () => {
    it('should return two decimal places', () => {
      expect(formatToTwoDecimalPlaces()).toBe('0.00');
      expect(formatToTwoDecimalPlaces('')).toBe('0.00');
      expect(formatToTwoDecimalPlaces('10.293')).toBe('10.29');
      expect(formatToTwoDecimalPlaces(10.293)).toBe('10.29');
      expect(formatToTwoDecimalPlaces(10.297)).toBe('10.30');
      expect(formatToTwoDecimalPlaces('10.297')).toBe('10.30');
    });
  });
  describe('formatDiscount', () => {
    it('should return positive for 0.0', () => {
      expect(formatDiscount()).toBe(0);
      expect(formatDiscount('')).toBe(0);
      expect(formatDiscount('-2.00')).toBe(2);
      expect(formatDiscount('-2.00')).toBe(2);
      expect(formatDiscount('2.00')).toBe(2);
      expect(formatDiscount(2.0)).toBe(2);
      expect(formatDiscount(-2.0)).toBe(2);
      expect(formatDiscount(2.222)).toBe(2.222);
      expect(formatDiscount(-2.222)).toBe(2.222);
      expect(formatDiscount('-2.222')).toBe(2.222);
      expect(formatDiscount('2.222')).toBe(2.222);
      expect(formatDiscount(0.29)).toBe(0.29);
      expect(formatDiscount(-0.29)).toBe(0.29);
      expect(formatDiscount('-0.29')).toBe(0.29);
      expect(formatDiscount('-0.30')).toBe(0.3);
    });
  });
});
