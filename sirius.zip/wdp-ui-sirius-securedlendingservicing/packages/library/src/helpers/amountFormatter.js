import { isEqual, toNumber } from 'lodash';

const moneyFormatter = /(\d)(?=(\d{3})+(,|$))/g;

export const roundValue = (value, decimals) =>
  Number(`${Math.round(`${value}e${decimals}`)}e-${decimals}`);

export const decimalFormat = qty => {
  if (!qty) {
    return '0';
  }
  const parsedQty = qty.toString().replace(/,/g, '');
  return parseFloat(parsedQty).toString();
};
export const currencySymbol = currencyCode => {
  switch (currencyCode) {
    case 'AUD':
      return '$';
    default:
      return '$';
  }
};

export const formatCurrency = quantum => {
  const amount = quantum || 0;
  const amountStr = amount.toFixed().replace(moneyFormatter, '$1,');
  const sign = currencySymbol();
  return `${sign}${amountStr}`;
};

export const formatAmount = amount => {
  if (!amount) {
    return '$0.00';
  }
  const parsedAmt = amount.toString().replace(/,/g, '');
  const floatvalue = parseFloat(Math.round(parsedAmt * 100) / 100).toFixed(2);
  const amountFormatted = floatvalue.replace(/\B(?=(\d{3})+(?!\d))/g, ',');
  const sign = currencySymbol();
  return `${sign}${amountFormatted}`;
};
export const formatBalance = amount => {
  if (!amount) {
    return '$0.00';
  }
  const parsedAmt = amount.toString().replace(/,/g, '');
  const formattedamt = Math.round(parsedAmt);
  return formattedamt;
};

export const formatDiscount = (discountRate = 0) => {
  const isNegative = isEqual(Math.sign(toNumber(discountRate)), -1);
  return isNegative
    ? Math.abs(toNumber(discountRate))
    : parseFloat(toNumber(discountRate));
};

export const formatToTwoDecimalPlaces = (amount = 0) => {
  return toNumber(amount)
    .toFixed(2)
    .toString();
};
