import { EventTypes } from '@wdpui/common-analytics';

export const FORMNAME = 'variable-to-fix';
export const PAGETYPE = {
  SELFSERVICE: 'selfservice',
};

export const PAGEACTION = {
  START: 'start',
  WELCOME: 'welcome',
  COMPLETE: 'complete',
};

export const PAGENAME = {
  LANDING: 'get started',
  SELECTERM: 'interest rate options',
  SELECTLOANOPTION: 'choose fixed rate',
  REVIEW: 'review',
  CONFIRMATION: 'confirmation',
  REDRAWPOPUP: 'popup:redraw available funds',
  REVIEWPOPUP: 'popup:current loan details',
  UNEXPECTEDERROR: 'error:system unexpected error',
  CASEEXISTS: 'already requested',
};

export const getPackageString = isPackageCustomer => {
  return isPackageCustomer ? '_package:adv' : '_package:no';
};

export const getConfirmationSelfServiceDetails = (
  isPackageCustomer,
  isFlexiProduct,
) => {
  return `${FORMNAME}${getPackageString(isPackageCustomer)}${
    isFlexiProduct ? '|flexi' : ''
  }`;
};

export const LANDING_PAGE = 'LANDING_PAGE';
export const QUOTES_PAGE = 'QUOTES_PAGE';
export const LOANOPTIONS_PAGE = 'LOANOPTIONS_PAGE';
export const REVIEW_PAGE = 'REVIEW_PAGE';
export const SUBMIT_PAGE = 'SUBMIT_PAGE';
export const ERROR_PAGE = 'ERROR_PAGE';
export const REVIEW_MODAL = 'REVIEW_MODAL';
export const REDRAW_MODAL = 'REDRAW_MODAL';

const analyticsParams = {
  [LANDING_PAGE]: {
    pageName: PAGENAME.LANDING,
    pageAction: PAGEACTION.WELCOME,
  },
  [QUOTES_PAGE]: {
    pageName: PAGENAME.SELECTERM,
    pageAction: PAGEACTION.START,
  },
  [LOANOPTIONS_PAGE]: {
    pageName: PAGENAME.SELECTLOANOPTION,
  },
  [REVIEW_PAGE]: {
    pageName: PAGENAME.REVIEW,
  },
  [SUBMIT_PAGE]: {
    pageName: PAGENAME.CONFIRMATION,
    pageAction: PAGEACTION.COMPLETE,
  },
  [REVIEW_MODAL]: {
    pageName: PAGENAME.REVIEWPOPUP,
    trackOnce: 'false',
  },
  [REDRAW_MODAL]: {
    pageName: PAGENAME.REDRAWPOPUP,
    trackOnce: 'false',
  },
};

export const getAnalyticsTags = (analyticsId, props) => {
  const analyticsTags = {
    event: EventTypes.PAGE,
    params: {
      ...analyticsParams[analyticsId],
      newFormName: FORMNAME,
      siteSubSection: 'sirius',
      siteSubSubSection: 'securedlendingservicing',
      pageType: PAGETYPE.SELFSERVICE,
    },
  };

  if (analyticsId === 'ERROR') {
    const { errorCode } = props;
    if (errorCode === 'caseexists') {
      analyticsTags.params.pageName = PAGENAME.CASEEXISTS;
    } else {
      analyticsTags.params.pageAction = PAGEACTION.COMPLETE;
      analyticsTags.params.pageName = PAGENAME.UNEXPECTEDERROR;
    }
  }

  if (analyticsId === 'SUBMIT_PAGE') {
    const { advantagePackage, isFlexiCustomer } = props;
    analyticsTags.params.selfserviceDetails = getConfirmationSelfServiceDetails(
      advantagePackage,
      isFlexiCustomer,
    );
  }

  return analyticsTags;
};
