import moment from 'moment-timezone';
import { isString } from 'lodash';

export const TIMEZONE_AUSTRALIA_SYDNEY = 'Australia/Sydney';

export const formatDateString = (dateString, format, isUTCTime) => {
  if (!dateString) {
    return null;
  }
  const dateStringValue = isUTCTime
    ? moment.tz(dateString, TIMEZONE_AUSTRALIA_SYDNEY).format()
    : dateString;
  return moment(dateStringValue.split('-').join(), 'YYYYMMDD').format(format);
};

export const parseDateTime = dateTime => {
  if (isString(dateTime)) {
    return dateTime.replace('Z', '').replace('T', ' ');
  }
  return moment();
};

export const formatDateTime = (dateTime, format) => {
  if (!dateTime) {
    return null;
  }
  const parsedDateTime = parseDateTime(dateTime);
  return moment(parsedDateTime).format(format);
};

export const formattedDate = dateTime => {
  return formatDateString(dateTime, 'DD MMM YYYY');
};
