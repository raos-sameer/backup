import {
  isSplitLoan,
  isFixedOptionCheckBoxChecked,
  showNewLoanDetails,
  isRedrawLoan,
  isClearLoan,
  getRepaymentType,
  getAdvantagePackageDesc,
  getSwitchingFeeText,
  getMonthlyMaintainenceFee,
  getNegatedAmountText,
  showHeaderTextForConfirmationPage,
  getHintTextForSplitFixedAmount,
  validateAmount,
  isAvailableFunds,
  getLoanVariationType,
  showSplitLoanTextForPackageCustomer,
  getFixedOptionLoanHeader,
} from './loanOptionsHelper';

import {
  SPLIT_LOAN_OPTION,
  FIXED_LOAN_OPTION,
  REDRAW_LOAN_OPTION,
  CLEAR_LOAN_OPTION,
  INTEREST_ONLY,
  PRINCIPAL_INTEREST,
} from './constants';

describe('loanoptions.helper', () => {
  it('should return true if loan type is split loan', () => {
    expect(isSplitLoan(SPLIT_LOAN_OPTION)).toBe(true);
  });
  it('should return true if loan type is redraw loan', () => {
    expect(isRedrawLoan(REDRAW_LOAN_OPTION)).toBe(true);
  });
  it('should return true if loan type is clear loan', () => {
    expect(isClearLoan(CLEAR_LOAN_OPTION)).toBe(true);
  });
  it('should return true if loan type is redraw loan', () => {
    expect(isFixedOptionCheckBoxChecked(REDRAW_LOAN_OPTION)).toBe(true);
  });
  it('should return true if loan type is clear loan', () => {
    expect(isFixedOptionCheckBoxChecked(CLEAR_LOAN_OPTION)).toBe(true);
  });
  it('should return true if loan type is fixed loan and no available balance passed', () => {
    expect(showNewLoanDetails(FIXED_LOAN_OPTION, '')).toBe(true);
  });
  it('should return true if loan type is clear loan and no available balance passed', () => {
    expect(showNewLoanDetails(CLEAR_LOAN_OPTION, '')).toBe(true);
  });
  it('should return true if loan type is split loan and no available balance and split amount passed', () => {
    expect(showNewLoanDetails(SPLIT_LOAN_OPTION, '11')).toBe(true);
  });
  it('should return true if all conditions are pased for fixed option checkbox', () => {
    expect(isFixedOptionCheckBoxChecked(FIXED_LOAN_OPTION)).toBe(true);
  });

  it('should return Interest Only as Text if repayment Indicator is I', () => {
    expect(getRepaymentType('IO')).toEqual(INTEREST_ONLY);
  });

  it('should return Interest Only as Text if repayment Indicator is PI', () => {
    expect(getRepaymentType('PIF')).toEqual(PRINCIPAL_INTEREST);
  });

  it('should return Yes Text if advantage package is true', () => {
    expect(getAdvantagePackageDesc(true)).toEqual('Yes');
  });
  it('should return No Text if advantage package is true', () => {
    expect(getAdvantagePackageDesc(false)).toEqual('No');
  });
  it('should return switching fee text if passed', () => {
    expect(getSwitchingFeeText(800)).toMatch(`A switching fee of $800.00`);
  });
  it('should return maintainence fee text if passed', () => {
    expect(getMonthlyMaintainenceFee(8)).toEqual(
      `An $8.00 monthly loan maintenance fee will apply`,
    );
  });

  it('should return formatted loan balance with negative sign', () => {
    expect(getNegatedAmountText(8, true)).toEqual(`-$8.00`);
  });
  it('should return formatted loan balance with no sign', () => {
    expect(getNegatedAmountText(8, false)).toEqual(`$8.00`);
  });

  it('should return formatted loan balance with no negative sign if balance is zero', () => {
    expect(getNegatedAmountText(0)).toEqual(`$0.00`);
  });

  it('should return header text for confirmation page', () => {
    expect(showHeaderTextForConfirmationPage('FixedLoanOption', '1')).toEqual(
      `You've requested to fix your loan for 1 year`,
    );
  });

  it('should return header text for confirmation page for 2 years', () => {
    expect(showHeaderTextForConfirmationPage('FixedLoanOption', '2')).toEqual(
      `You've requested to fix your loan for 2 years`,
    );
  });

  it('should return header text for confirmation page for split case', () => {
    expect(showHeaderTextForConfirmationPage('SplitLoanOption', '1'))
      .toMatch(`You've requested to split your loan and fix a portion
    for 1  year`);
  });

  it('should return header text for confirmation page for split case for 2', () => {
    expect(showHeaderTextForConfirmationPage('SplitLoanOption', '2'))
      .toMatch(`You've requested to split your loan and fix a portion
    for 2  years`);
  });

  it('should return hint text split fixed amount', () => {
    expect(getHintTextForSplitFixedAmount(700000)).toMatch(
      `$15,000 min $690,000.00 max`,
    );
  });

  it('should return true if empty values passed', () => {
    expect(validateAmount('', '')).toEqual(true);
  });
  it('should return true if amount empty passed', () => {
    expect(validateAmount('', '1111')).toEqual(true);
  });
  it('should return false if empty values passed', () => {
    expect(validateAmount('', 1111)).toEqual(true);
  });
  it('should return false if amount entered less than 15k', () => {
    expect(validateAmount(14999, 1111)).toEqual(false);
  });
  it('should return false if amount entered greater than 15k and less than max amount allotted', () => {
    expect(validateAmount(15999, 49599)).toEqual(true);
  });
  it('should return false if amount entered less than 15k but amount less than current balance', () => {
    expect(validateAmount(14000, 14509)).toEqual(false);
  });

  it('should return 0 if available balance is blank', () => {
    expect(isAvailableFunds('')).toEqual(false);
  });

  it('should return 0 if available balance is blank', () => {
    expect(isAvailableFunds('0')).toEqual(false);
  });
  it('should return 0 if available balance is blank', () => {
    expect(isAvailableFunds('999')).toEqual(false);
  });

  it('should return 0 if available balance is blank', () => {
    expect(isAvailableFunds(0)).toEqual(false);
  });

  it('should return 0 if available balance is blank', () => {
    expect(isAvailableFunds('2000')).toEqual(true);
  });

  it('should return 0 if available balance is blank', () => {
    expect(isAvailableFunds(2000)).toEqual(true);
  });
  it('should return FixLimit for fixed loan variation for submit api', () => {
    expect(getLoanVariationType(FIXED_LOAN_OPTION)).toEqual('FixLimit');
  });
  it('should return Split for split loan variation for submit api', () => {
    expect(getLoanVariationType(SPLIT_LOAN_OPTION)).toEqual('Split');
  });
  it('should return FixBalance for clear loan variation for submit api', () => {
    expect(getLoanVariationType(CLEAR_LOAN_OPTION)).toEqual('FixBalance');
  });

  it('should return if split loan bullet text for landing page can be shown', () => {
    expect(showSplitLoanTextForPackageCustomer(SPLIT_LOAN_OPTION)).toEqual(
      'true',
    );
  });
  it('should return if split loan bullet text for landing page can be shown for redraw scenario', () => {
    expect(showSplitLoanTextForPackageCustomer(REDRAW_LOAN_OPTION)).toEqual(
      'false',
    );
  });
  it('should return false if its not packaged custome', () => {
    expect(showSplitLoanTextForPackageCustomer(SPLIT_LOAN_OPTION)).toEqual(
      'true',
    );
  });

  it('should return header text for fixed options screen', () => {
    expect(getFixedOptionLoanHeader(1.299, 1)).toEqual(
      `You've chosen a 1 year fixed rate of 1.30 % p.a.`,
    );
  });
});
