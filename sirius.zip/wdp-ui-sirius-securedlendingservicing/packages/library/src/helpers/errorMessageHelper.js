import { get } from 'lodash';
import { queryStringParse } from './queryHelper';
import { QUERY_PARAMS, ERRORCODE, ERRORHEADING } from './constants';

export const getErrorCode = () => {
  const queryParams = queryStringParse(window.location.search);
  const errorCode = get(queryParams, QUERY_PARAMS.ERRORCODE, 'fatalerror');
  return errorCode;
};
export const getErrorHeading = () => {
  const errorCode = getErrorCode();
  if (errorCode === ERRORCODE.CASEEXISTS) {
    return ERRORHEADING.CASEEXISTSHEADING;
  }
  if (errorCode === ERRORCODE.ELIGIBILITYFAIL) {
    return ERRORHEADING.ELIGIBILITYFAILHEADING;
  }
  return ERRORHEADING.FATALERRORHEADING;
};
