import { SPLIT_LOAN_OPTION } from './constants';

export const getReviewHeaderTitleText = pageType => {
  if (pageType === SPLIT_LOAN_OPTION) return `You're splitting your loan`;

  return `You're fixing your loan`;
};
export const getDisplayAccountNumber = arrangementId => {
  if (arrangementId) {
    return arrangementId.substr(6, 12);
  }
  return '';
};

export const getDisplayBSBNumber = arrangementId => {
  if (arrangementId) {
    const accountNumber = arrangementId.substr(0, 6);
    return accountNumber.match(/.{1,3}/g).join('-');
  }
  return '';
};
