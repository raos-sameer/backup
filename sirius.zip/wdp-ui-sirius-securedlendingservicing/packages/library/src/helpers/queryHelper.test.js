import { get } from 'lodash';
import { queryStringParse } from './queryHelper';
import { QUERY_PARAMS } from './constants';

describe('queryHelper.helper', () => {
  it('should return query string for context ref id passed', () => {
    const obj = queryStringParse('test?contextRefId=123');
    const refId = get(obj, QUERY_PARAMS.REFID, '');

    expect(refId).toStrictEqual('123');
  });
  it('should return query string for context ref id passed if its 2nd one', () => {
    const obj = queryStringParse('test?testing=11&contextRefId=123');
    const refId = get(obj, QUERY_PARAMS.REFID, '');
    expect(refId).toStrictEqual('123');
  });
  it('should return empty query string if no url passed', () => {
    const obj = queryStringParse('');
    const refId = get(obj, QUERY_PARAMS.REFID, '');
    expect(refId).toStrictEqual('');
  });

  it('should return empty string if context ref id is not passed', () => {
    const obj = queryStringParse('test?testing=11');
    const refId = get(obj, QUERY_PARAMS.REFID, '');
    expect(refId).toStrictEqual('');
  });
});
