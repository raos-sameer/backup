import { subtract, toNumber } from 'lodash';
import {
  formatAmount,
  formatBalance,
  formatToTwoDecimalPlaces,
} from './amountFormatter';

import {
  SPLIT_LOAN_OPTION,
  FIXED_LOAN_OPTION,
  REDRAW_LOAN_OPTION,
  CLEAR_LOAN_OPTION,
  INTEREST_ONLY,
  PRINCIPAL_INTEREST,
  MINIMUM_SPLIT_AMOUNT,
  MAXIMUM_CURRENTBALANCE_DIFFERENCE,
} from './constants';

export const isAvailableFunds = availableFunds => {
  if (toNumber(availableFunds) > 1000) return true;
  return false;
};

export const showNewLoanDetails = (loanOption, splitAmount, availableFunds) => {
  if (
    (loanOption === FIXED_LOAN_OPTION && !isAvailableFunds(availableFunds)) ||
    (loanOption === SPLIT_LOAN_OPTION && splitAmount) ||
    loanOption === REDRAW_LOAN_OPTION ||
    loanOption === CLEAR_LOAN_OPTION
  )
    return true;
  return false;
};
export const isSplitLoan = loanOption => {
  return loanOption === SPLIT_LOAN_OPTION;
};

export const isRedrawLoan = loanOption => {
  return loanOption === REDRAW_LOAN_OPTION;
};

export const isClearLoan = loanOption => {
  return loanOption === CLEAR_LOAN_OPTION;
};

export const isFixedOptionCheckBoxChecked = loanOption => {
  return (
    loanOption === FIXED_LOAN_OPTION ||
    loanOption === CLEAR_LOAN_OPTION ||
    loanOption === REDRAW_LOAN_OPTION
  );
};

export const getRepaymentType = repaymentIndicator => {
  return repaymentIndicator === 'IO' ? INTEREST_ONLY : PRINCIPAL_INTEREST;
};
export const getAdvantagePackageDesc = isAdvantagePackage => {
  return isAdvantagePackage ? 'Yes' : 'No';
};
export const showSplitLoanTextForPackageCustomer = loanType => {
  return isSplitLoan(loanType) ? 'true' : 'false';
};

export const showHeaderTextForConfirmationPage = (loanType, loanTerm) => {
  let headerText = `You've requested to fix your loan for ${loanTerm}${
    loanTerm === '1' ? ` year` : ` years`
  }`;

  if (isSplitLoan(loanType)) {
    headerText = `You've requested to split your loan and fix a portion
    for ${loanTerm} ${loanTerm === '1' ? ` year` : ` years`}`;
  }

  return headerText;
};

export const getSwitchingFeeText = switchFee => {
  return `A switching fee of ${formatAmount(
    switchFee,
  )} will be charged to the loan
  account at the start of fixed rate term`;
};

export const getMonthlyMaintainenceFee = maintainenceFee => {
  return `An ${formatAmount(
    maintainenceFee,
  )} monthly loan maintenance fee will apply`;
};

export const getNegatedAmountText = (amountVal, isNegated) => {
  const appendMinus = isNegated ? '-' : '';

  if (amountVal && amountVal !== '' && amountVal !== '0')
    return `${appendMinus}${formatAmount(amountVal)}`;
  return `$0.00`;
};
export const getHintTextForSplitFixedAmount = currentBalance => {
  const maxFixedAmt = subtract(
    toNumber(currentBalance),
    toNumber(MAXIMUM_CURRENTBALANCE_DIFFERENCE),
  );
  return `$15,000 min ${formatAmount(maxFixedAmt)} max`;
};

export const validateAmount = (inputAmountData, currentBalance) => {
  if (inputAmountData && currentBalance) {
    const amount = toNumber(inputAmountData);
    const maxFixedAmt = subtract(
      toNumber(currentBalance),
      toNumber(MAXIMUM_CURRENTBALANCE_DIFFERENCE),
    );
    return (
      amount > toNumber(MINIMUM_SPLIT_AMOUNT) &&
      amount < formatBalance(maxFixedAmt)
    );
  }
  return true;
};

export const getLoanVariationType = loanOptionSelected => {
  if (
    loanOptionSelected === FIXED_LOAN_OPTION ||
    loanOptionSelected === REDRAW_LOAN_OPTION
  )
    return 'FixLimit';
  if (loanOptionSelected === SPLIT_LOAN_OPTION) return 'Split';
  if (loanOptionSelected === CLEAR_LOAN_OPTION) return 'FixBalance';
  return '';
};

export const getFixedOptionLoanHeader = (interestRate, yearTerm) => {
  const formattedInterestRate = formatToTwoDecimalPlaces(interestRate);
  const headerText = `You've chosen a ${yearTerm} year fixed rate of ${formattedInterestRate} % p.a.`;

  return headerText;
};
