import {
  showSpecialBulletForFlexiOrPackage,
  showSpecialBulletOnlyForFlexi,
} from './landingPageHelper';

describe('landingPage.helper', () => {
  it('should return string  true if its flexi deposit or if its not advantage package', () => {
    expect(showSpecialBulletForFlexiOrPackage(false, true)).toEqual(`true`);
  });

  it('should return string  true if its not flexi deposit or if its advantage package', () => {
    expect(showSpecialBulletForFlexiOrPackage(true, false)).toEqual(`false`);
  });

  it('should return string  true if its not flexi deposit or if its not advantage package', () => {
    expect(showSpecialBulletForFlexiOrPackage(false, false)).toEqual(`true`);
  });

  it('should return string  true if its flexi deposit', () => {
    expect(showSpecialBulletOnlyForFlexi(true)).toEqual(`true`);
  });
  it('should return string  false if its not flexi deposit', () => {
    expect(showSpecialBulletOnlyForFlexi(false)).toEqual(`false`);
  });
});
