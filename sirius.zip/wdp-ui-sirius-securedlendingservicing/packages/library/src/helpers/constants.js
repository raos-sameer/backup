export const SPLIT_LOAN_OPTION = 'SplitLoanOption';
export const FIXED_LOAN_OPTION = 'FixedLoanOption';
export const REDRAW_LOAN_OPTION = 'RedrawFundsOption';
export const CLEAR_LOAN_OPTION = 'AccessFundsOption';
export const INTEREST_ONLY = 'Interest Only';
export const PRINCIPAL_INTEREST = 'Principal and Interest';

export const VARIABLE_COMPONENT = 'Variable';
export const FIXED_COMPONENT = 'Fixed';
export const NEWLOAN_COMPONENT = 'NewLoan';
export const QUERY_PARAMS = {
  TID: 'tid',
  PID: 'pid',
  FID: 'fid',
  REFID: 'contextRefId',
  ERRORCODE: 'code',
};
export const ERRORCODE = {
  CASEEXISTS: 'caseexists',
  ELIGIBILITYFAIL: 'eligibilityfail',
};
export const ERRORHEADING = {
  CASEEXISTSHEADING: 'A request to fix this loan has already been submitted',
  ELIGIBILITYFAILHEADING: "You can't switch to a fixed rate online",
  FATALERRORHEADING: 'We encountered an error',
};

export const UNLIMITED_REPAYMENT_TEXT = '(unlimited)';

export const LIMITED_REPAYMENT_TEXT = '(up to $30,000.00)';
export const MINIMUM_SPLIT_AMOUNT = 15000;
export const MAXIMUM_CURRENTBALANCE_DIFFERENCE = 10000;
