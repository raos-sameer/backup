/* eslint-disable no-param-reassign */
import { sum, multiply, divide, round, subtract, toNumber } from 'lodash';
import { REDRAW_LOAN_OPTION, FIXED_LOAN_OPTION } from './constants';

export const getInterestRateForLoan = interestRate => {
  return divide(divide(interestRate, 12), 100);
};

export const getSummation = (amount1, amount2) => {
  return sum([toNumber(amount1), toNumber(amount2)]);
};
export const getInterestOnlyRepaymentAmount = (
  currentBalance,
  switchingFee,
  monthlyAccountFee,
  netInterestRate,
  isPackageCustomer,
) => {
  const percentRate = getInterestRateForLoan(netInterestRate);
  const calculatedLoanBalance = sum([
    toNumber(currentBalance),
    !isPackageCustomer ? toNumber(switchingFee) : 0,
  ]);

  const calculatedNetInterest = round(
    multiply(percentRate, calculatedLoanBalance),
    2,
  );

  return sum([
    calculatedNetInterest,
    !isPackageCustomer ? toNumber(monthlyAccountFee) : 0,
  ]);
};

export const getFixedCompCurrentBalance = (
  loanOptionSelected,
  availableBalance,
  currentBalance,
) => {
  return sum([
    toNumber(currentBalance),
    loanOptionSelected === REDRAW_LOAN_OPTION ||
    loanOptionSelected === FIXED_LOAN_OPTION
      ? toNumber(availableBalance)
      : 0,
  ]);
};

export const getVariableCompCurrentBalanceIO = (
  currentBalance,
  fixedAmountEntered,
) => {
  return subtract(toNumber(currentBalance), toNumber(fixedAmountEntered));
};

export const getVariableCompCurrentBalancePIF = (
  currentBalance,
  availableBalance,
  fixedAmountEntered,
) => {
  const loanLimit = sum([toNumber(currentBalance), toNumber(availableBalance)]);
  return subtract(toNumber(loanLimit), toNumber(fixedAmountEntered));
};

/*
interestRate/rate: interest rate for the loan
monthlyPayments/nper: total number of payments for the loan
presentValue/pv: present value/principal
residualValue/fv: future value, or a cash balance you want after the last payment is made
PMT Function
*/
export const getPMT = (
  interestRate = 0,
  remainingTermMonths = 0,
  presentValue = 0,
  residualValue = 0,
  isPackageCustomer = false,
  switchingFee = 0,
  monthlyAccountFee = 0,
) => {
  const loanLimit = sum([
    toNumber(presentValue),
    !isPackageCustomer ? toNumber(switchingFee) : 0,
  ]);

  const monthlyRate = getInterestRateForLoan(interestRate);

  const presentValueInterestFactor =
    sum([toNumber(monthlyRate), 1]) ** remainingTermMonths;
  const pmtcomp = multiply(
    loanLimit,
    sum([presentValueInterestFactor, residualValue]),
  );
  const calcPresentValueInterestFactor =
    monthlyRate / (presentValueInterestFactor - 1);

  const pmt = sum([
    multiply(calcPresentValueInterestFactor, pmtcomp),
    !isPackageCustomer ? toNumber(monthlyAccountFee) : 0,
  ]);
  return pmt;
};
