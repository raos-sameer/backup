import { scrollWindow } from './windowFunctionsHelper';

describe('windowFunctionsHelper', () => {
  global.window = Object.create(window);

  const spyScrollTo = jest.fn();

  beforeEach(() => {
    Object.defineProperty(global.window, 'scroll', { value: spyScrollTo });

    Object.defineProperty(global.window, 'scrollTo', { value: spyScrollTo });
    spyScrollTo.mockClear();
  });

  it('should scroll window to mentioned position', () => {
    scrollWindow('120', '130', () => {
      expect(window.scrollTo).toBeCalledWith({
        behavior: 'smooth',
        left: '130',
        top: '120',
      });
    });
  });
});
