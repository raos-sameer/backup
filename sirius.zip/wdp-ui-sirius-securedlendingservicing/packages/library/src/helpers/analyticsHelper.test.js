import {
  getConfirmationSelfServiceDetails,
  getPackageString,
  getAnalyticsTags,
  FORMNAME,
  PAGETYPE,
  LANDING_PAGE,
} from './analyticsHelper';

describe('analytics.helper', () => {
  it('should return self service data if its package and flexi product', () => {
    expect(getConfirmationSelfServiceDetails(true, true)).toEqual(
      `variable-to-fix_package:adv|flexi`,
    );
  });

  it('should return self service data if its package and not flexi product', () => {
    expect(getConfirmationSelfServiceDetails(true, false)).toEqual(
      `variable-to-fix_package:adv`,
    );
  });
  it('should return self service data if its not package and flexi product', () => {
    expect(getConfirmationSelfServiceDetails(false, true)).toEqual(
      `variable-to-fix_package:no|flexi`,
    );
  });
  it('should return self service data if its not package and not flexi product', () => {
    expect(getConfirmationSelfServiceDetails(false, false)).toEqual(
      `variable-to-fix_package:no`,
    );
  });

  it('should return self service data if its package', () => {
    expect(getPackageString(true)).toEqual(`_package:adv`);
  });
  it('should return self service data if its not package', () => {
    expect(getPackageString(false)).toEqual(`_package:no`);
  });
});

describe('getAnalyticsTags', () => {
  it('should return tags', () => {
    expect(getAnalyticsTags(LANDING_PAGE)).toEqual({
      event: 'page',
      params: {
        pageName: 'get started',
        newFormName: FORMNAME,
        siteSubSection: 'sirius',
        siteSubSubSection: 'securedlendingservicing',
        pageType: PAGETYPE.SELFSERVICE,
        pageAction: 'welcome',
      },
    });
  });
});
