import {
  isFixedComponent,
  isVariableComponent,
  isNewLoanComponent,
  getLoanTypeText,
  getMonthlyRepaymentText,
} from './loanSummaryHelper';

import {
  VARIABLE_COMPONENT,
  FIXED_COMPONENT,
  NEWLOAN_COMPONENT,
} from './constants';

describe('loanSummary.helper', () => {
  it('should return true if component type is Variable', () => {
    expect(isVariableComponent(VARIABLE_COMPONENT)).toBe(true);
  });

  it('should return false if component type is not Variable', () => {
    expect(isVariableComponent(FIXED_COMPONENT)).toBe(false);
  });

  it('should return true if component type is Fixed', () => {
    expect(isFixedComponent(FIXED_COMPONENT)).toBe(true);
  });

  it('should return false if component type is not Fixed', () => {
    expect(isFixedComponent(VARIABLE_COMPONENT)).toBe(false);
  });

  it('should return true if component type is New Loan', () => {
    expect(isNewLoanComponent(NEWLOAN_COMPONENT)).toBe(true);
  });

  it('should return loan type text as Loan balance if loan type is Fixed', () => {
    expect(getLoanTypeText(FIXED_COMPONENT)).toEqual('Loan balance');
  });

  it('should return loan type text as Loan balance if loan type is NewLoan', () => {
    expect(getLoanTypeText(NEWLOAN_COMPONENT)).toEqual('Loan balance');
  });

  it('should return loan type text as Current balance if loan type is not Fixed/NewLoan', () => {
    expect(getLoanTypeText('Test')).toEqual('Current balance');
  });

  it('should return indicative repayment text as Indicative Monthly repayments if loan type is Fixed', () => {
    expect(getMonthlyRepaymentText(FIXED_COMPONENT)).toEqual(
      'Indicative monthly repayments',
    );
  });

  it('should return indicative repayment text as Indicative Monthly repayments if loan type is NewLoan', () => {
    expect(getMonthlyRepaymentText(NEWLOAN_COMPONENT)).toEqual(
      'Indicative monthly repayments',
    );
  });
  it('should return indicative repayment text as Contracted Monthly repayments if loan type is not NewLoan/Fixed', () => {
    expect(getMonthlyRepaymentText('Test')).toEqual(
      'Contracted monthly repayments',
    );
  });
});
