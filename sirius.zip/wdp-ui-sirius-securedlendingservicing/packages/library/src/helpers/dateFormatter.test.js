import { formatDateString, formatDateTime } from './dateFormatter';

describe('formatDateString', () => {
  it('should return date in passd format', () => {
    expect(formatDateString('2011-12-31', 'DD-MMMM-YYYY')).toEqual(
      '31-December-2011',
    );
    expect(formatDateString('2011-03-31', 'DD MMMM YYYY')).toEqual(
      '31 March 2011',
    );
    expect(formatDateString('2019-02-06T13:00:00Z', 'DD/MM/YYYY')).toEqual(
      '06/02/2019',
    );
    expect(formatDateString('2019-02-06T11:00:00Z', 'DD/MM/YYYY')).toEqual(
      '06/02/2019',
    );
    expect(
      formatDateString('2019-02-06T11:00:00Z', 'DD/MM/YYYY', true),
    ).toEqual('06/02/2019');
    expect(
      formatDateString('2019-02-06T13:00:00Z', 'DD/MM/YYYY', true),
    ).toEqual('07/02/2019');
    expect(
      formatDateString('2019-02-06T13:00:00Z', 'DD/MM/YYYY', false),
    ).toEqual('06/02/2019');
  });
});
describe('formatDateTime', () => {
  expect(formatDateTime('', '')).toEqual(null);
  expect(formatDateTime('2017-12-29T14:25:10.487Z', 'DD-MMMM-YYYY')).toEqual(
    '29-December-2017',
  );
  expect(formatDateTime('2017-01-01T08:25:10.487Z', 'DD MMMM YYYY')).toEqual(
    '01 January 2017',
  );
  expect(formatDateTime('2017-12-31T14:25:10.487Z', 'DD MMMM YYYY')).toEqual(
    '31 December 2017',
  );
  expect(formatDateTime('2016-02-29T14:25:10.487Z', 'DD-MM-YYYY')).toEqual(
    '29-02-2016',
  );
  expect(formatDateTime('2016-02-29T08:25:10.487Z', 'DD-MM-YYYY')).toEqual(
    '29-02-2016',
  );
});
