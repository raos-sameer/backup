export const scrollWindow = (top = 0, left = 0) => {
  setTimeout(() => {
    window.scroll({
      top,
      left,
      behavior: 'smooth',
    });
  }, 100);
};
