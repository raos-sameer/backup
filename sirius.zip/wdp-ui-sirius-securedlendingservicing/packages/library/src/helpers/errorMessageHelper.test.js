import { getErrorCode, getErrorHeading } from './errorMessageHelper';
import { ERRORHEADING } from './constants';

describe('errorMessageHelper', () => {
  global.window = Object.create(window);
  const url = 'test?code=caseexists';
  Object.defineProperty(window, 'location', {
    value: {
      href: url,
      search: url,
    },
  });

  it('should return error code passed', () => {
    expect(getErrorCode()).toStrictEqual('caseexists');
  });
  it('should return error heading for case exists', () => {
    expect(getErrorHeading()).toStrictEqual(ERRORHEADING.CASEEXISTSHEADING);
  });

  it('should return error heading for eligibilityfail', () => {
    window.location.search = 'test?code=eligibilityfail';
    expect(getErrorHeading()).toStrictEqual(
      ERRORHEADING.ELIGIBILITYFAILHEADING,
    );
  });
  it('should return fatal error heading for no code', () => {
    window.location.search = '';
    expect(getErrorHeading()).toStrictEqual(ERRORHEADING.FATALERRORHEADING);
  });
});
