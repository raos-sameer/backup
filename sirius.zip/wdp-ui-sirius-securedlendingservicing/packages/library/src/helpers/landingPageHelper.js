export const showSpecialBulletForFlexiOrPackage = (
  advantagePackage,
  isFlexiProduct,
) => {
  return !advantagePackage || isFlexiProduct ? 'true' : 'false';
};

export const showSpecialBulletOnlyForFlexi = isFlexiProduct => {
  return isFlexiProduct ? 'true' : 'false';
};
