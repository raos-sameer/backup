export { getSectionFromPath } from './commonUtil';
