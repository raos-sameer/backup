import { getSectionFromPath } from './commonUtil';

const URL = 'https://www.dev1.ui.westpac.com.au/sirius/securedlendingservicing';

describe('getSectionFromPath', () => {
  it('should return empty string if passed empty path', () => {
    expect(getSectionFromPath('', 1)).toStrictEqual('');
  });
  it('should return section path if url passed with position 1', () => {
    expect(getSectionFromPath(URL, 2)).toStrictEqual(
      'www.dev1.ui.westpac.com.au',
    );
  });
  it('should return section path if url passed with position 2', () => {
    expect(getSectionFromPath(URL, 3)).toStrictEqual('sirius');
  });
  it('should return section path if url passed with position 3', () => {
    expect(getSectionFromPath(URL, 4)).toStrictEqual('securedlendingservicing');
  });
});
