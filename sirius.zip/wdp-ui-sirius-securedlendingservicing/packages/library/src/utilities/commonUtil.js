export const getSectionFromPath = (url, position) =>
  url ? url.split('/')[position] : '';
