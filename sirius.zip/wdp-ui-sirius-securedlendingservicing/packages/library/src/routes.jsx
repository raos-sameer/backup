import React from 'react';
import { Switch, Route } from 'react-router-dom';
import { withMicroAppConfig } from '@wdpui/common-with-app-config';
import { getBasepath } from '@wdpui/common-utilities';
import { MasterLayout } from './layouts/Master';
import {
  SelectInterestRateContainer,
  ErrorContainer,
  LandingPageContainer,
  ReviewPageContainer,
  ConfirmationPageContainer,
  FixedOptionLoanContainer,
} from './containers';

// trigger
const Routes = props => (
  <MasterLayout {...props}>
    <Switch>
      <Route
        path="/securedlendingservicing"
        name="Digital Home Loan Switching"
        exact
        component={LandingPageContainer}
      />

      <Route
        path="/securedlendingservicing/selectterm"
        name="Digital Home Loan Switching"
        exact
        component={SelectInterestRateContainer}
      />
      <Route
        path="/securedlendingservicing/selectloanoption"
        name="Digital Home Loan Switching"
        exact
        component={FixedOptionLoanContainer}
      />
      <Route
        path="/securedlendingservicing/receipt"
        name="Digital Home Loan Switching"
        exact
        component={ConfirmationPageContainer}
      />
      <Route
        path="/securedlendingservicing/error"
        name="Digital Home Loan Switching Error"
        exact
        component={ErrorContainer}
      />
      <Route
        path="/securedlendingservicing/error?code=caseexists"
        name="Digital Home Loan Switching Error"
        exact
        component={ErrorContainer}
      />
      <Route
        path="/securedlendingservicing/error?code=eligibilityfail"
        name="Digital Home Loan Switching Error"
        exact
        component={ErrorContainer}
      />

      <Route
        path="/securedlendingservicing/review"
        name="Digital Home Loan Switching"
        exact
        component={ReviewPageContainer}
      />
    </Switch>
  </MasterLayout>
);

const env = process.env.NODE_ENV;
const homepage = process.env.REACT_APP_HOMEPAGE;

const basepath = getBasepath(env, homepage);
const microApp = 'securedlendingservicing';

export const ComposedRoutes = withMicroAppConfig({
  basepath,
  microApp,
})(Routes);

/**
 * The routes exported are stitched together
 * in the RouteRegistry of the master SPA
 * along-with the other micro apps
 */
export const pages = [
  {
    id: 'pages.sirius.securedlendingservicing',
    path: '/securedlendingservicing',
    name: 'Digital Home Loan Switching',
    component: ComposedRoutes,
    ui: {
      layout: {
        inherit: false,
        hero: false,
        footer: true,
      },
    },
    routes: [
      {
        id: 'pages.sirius.securedlendingservicing',
        path: '/securedlendingservicing',
        name: 'Digital Home Loan Switching',
        exact: true,
        queryParams: {
          contextRefId: {
            pattern: /^[\w:-]+$/,
          },
          code: {
            pattern: /^[\w:-]+$/,
          },
        },
        ui: {
          layout: {
            inherit: true,
            hero: false,
            footer: false,
          },
        },
      },
    ],
  },
];

export default pages;
