import React from 'react';
import { Header } from '@wdpui/gel-header';
import { Button } from '@wdpui/gel-button';
import PropTypes from 'prop-types';

const PageHeader = ({ brandId, signout, leftArrowAction, headerTitle }) => (
  <div>
    <Header
      title={headerTitle}
      fixed
      leftArrow
      leftArrowAction={leftArrowAction}
    >
      <Button
        styling="faint"
        soft
        label={brandId === 'WBC' ? 'Sign out' : 'Logout'}
        responsive={{ xs: 'small', sm: 'medium' }}
        onClick={signout}
      />
    </Header>
  </div>
);

PageHeader.propTypes = {
  brandId: PropTypes.string.isRequired,
  signout: PropTypes.func.isRequired,
  leftArrowAction: PropTypes.func.isRequired,
  headerTitle: PropTypes.string,
};

PageHeader.defaultProps = {
  headerTitle: '',
};

export default PageHeader;
