import React from 'react';
import styled from 'styled-components';
import { IconPadlock, IconHeadset } from '@wdpui/react-gel';
import { Row } from '@wdpui/gel-grid';

export const StyledAnchorNoUnderline = styled.a`
  text-decoration: none !important;
`;
export const StyledPageFooter = styled.div`
  background: white;
  padding-top: 15px;
  padding-left: 24px;
  padding-bottom: 15px;
  padding-right: 24px;
`;

export const Display = styled.span`
  @media only screen and (max-width: 480px) {
    display: none;
  }
`;

export const RightFloat = styled(Row)`
  float: right;
`;
export const Span = styled.span`
  color: ${({ theme }) => theme.color.primary};
`;

export const StyledSpan = styled.span`
  color: ${({ theme }) => theme.color.neutral};
`;

export const PageFooter = () => (
  <StyledPageFooter>
    <IconPadlock size="medium" />
    <RightFloat>
      <Display>Call&nbsp;</Display>
      <strong>
        {' '}
        <StyledAnchorNoUnderline href="tel:131 900">
          <StyledSpan>131 900</StyledSpan>
        </StyledAnchorNoUnderline>
      </strong>{' '}
      <Display>&nbsp;for help </Display>
      &nbsp;&nbsp;
      <Span>
        <IconHeadset size="medium" />
      </Span>
    </RightFloat>
  </StyledPageFooter>
);
