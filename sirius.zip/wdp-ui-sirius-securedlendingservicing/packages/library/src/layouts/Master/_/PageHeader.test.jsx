import React from 'react';
import { shallow } from 'enzyme';
import renderer from 'react-test-renderer';
import { withTheme } from '../../../../../../utils/jest/TestUtils';
import PageHeader from './PageHeader';

describe('PageHeader Child Layout', () => {
  let store;
  const spy = jest.spyOn(global.console, 'error');

  const leftArrowAction = jest.fn();
  const signout = jest.fn();

  afterEach(() => {
    if (store && store.clearActions) {
      store.clearActions();
    }
    if (spy && spy.mockReset && spy.mockRestore) {
      spy.mockReset();
      spy.mockRestore();
    }
    leftArrowAction.mockReset();
    leftArrowAction.mockRestore();
    signout.mockRestore();
    signout.mockReset();
  });

  it('should render without error when required props are passed', () => {
    const component = withTheme(
      <PageHeader
        leftArrowAction={leftArrowAction}
        signout={signout}
        brandId="STG"
        headerTitle="Test Title"
      />,
    );
    shallow(component).dive();
    expect(spy).not.toHaveBeenCalled();
  });

  it('should match generated snapshot for WBC brandId', () => {
    const component = withTheme(
      <PageHeader
        leftArrowAction={leftArrowAction}
        signout={signout}
        brandId="WBC"
        headerTitle="Test Title"
      />,
    );
    const tree = renderer.create(component).toJSON();
    expect(tree).toMatchSnapshot();
  });

  it('should match generated snapshot for STG brandId', () => {
    const component = withTheme(
      <PageHeader
        leftArrowAction={leftArrowAction}
        signout={signout}
        brandId="STG"
        headerTitle="Test Title"
      />,
    );
    const tree = renderer.create(component).toJSON();
    expect(tree).toMatchSnapshot();
  });
});
