import React from 'react';
import { shallow } from 'enzyme';
import renderer from 'react-test-renderer';
import { withTheme } from '../../../../../../utils/jest/TestUtils';
import { Page } from './Page';

describe('Page Child Layout', () => {
  const spy = jest.spyOn(global.console, 'error');

  afterEach(() => {
    if (spy && spy.mockReset && spy.mockRestore) {
      spy.mockReset();
      spy.mockRestore();
    }
  });

  it('should render without error when required props are passed', () => {
    const component = withTheme(<Page />);
    shallow(component).dive();
    expect(spy).not.toHaveBeenCalled();
  });

  it('should match generated snapshot', () => {
    const component = withTheme(<Page />);
    const tree = renderer.create(component).toJSON();
    expect(tree).toMatchSnapshot();
  });
});
