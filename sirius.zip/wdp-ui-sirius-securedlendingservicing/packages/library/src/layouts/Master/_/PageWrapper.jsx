import styled from 'styled-components';
import { Grid } from '@wdpui/gel-grid';

export const PageWrapper = styled(Grid)`
  flex-direction: column;
  margin-left: auto;
  margin-right: auto;
`;
