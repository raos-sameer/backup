import React from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { getBrandId } from '@wdpui/common-with-app-config';
import { signoutActions } from '@wdpui/common-with-sso';
import {
  getHeaderBackNavSelector,
  getDashboardUrl,
  getFooterInfoSecurityUrl,
} from '../../redux/selectors';
import { PageWrapper } from './_/PageWrapper';
import { Page } from './_/Page';
import PageHeader from './_/PageHeader';
import { PageFooter } from './_/PageFooter';
import {
  StyledGridContainer,
  StyledGrid,
  StyledColumn,
} from '../../components/common/styles';

class MasterLayout extends React.Component {
  static propTypes = {
    children: PropTypes.node.isRequired,
    brandId: PropTypes.string.isRequired,
    headerBackNavigate: PropTypes.string.isRequired,
    channelDashboardUrl: PropTypes.string.isRequired,
    footerInfoSecurityUrl: PropTypes.string.isRequired,
    signout: PropTypes.func.isRequired,
    history: PropTypes.shape({
      replace: PropTypes.func.isRequired,
      goBack: PropTypes.func.isRequired,
    }).isRequired,
  };

  signout = () => {
    const { signout } = this.props;
    signout();
  };

  headerLeftArrowAction = () => {
    const { headerBackNavigate, channelDashboardUrl, history } = this.props;
    switch (headerBackNavigate) {
      case 'CHANNEL': {
        window.location.replace(channelDashboardUrl);
        break;
      }
      case 'PREVIOUS': {
        history.goBack();
        break;
      }
      default:
        break;
    }
    return null;
  };

  render() {
    const { children, footerInfoSecurityUrl, brandId } = this.props;

    return (
      <PageWrapper>
        <Page>
          <PageHeader
            brandId={brandId}
            signout={this.signout}
            leftArrowAction={this.headerLeftArrowAction}
          />
          <StyledGridContainer px={[12, 12]}>
            <StyledGrid>
              <StyledColumn width={[1, 10 / 12, 10 / 12, 8 / 12]} m="auto">
                {children}
              </StyledColumn>
            </StyledGrid>
          </StyledGridContainer>
        </Page>
        <PageFooter footerInfoSecurityUrl={footerInfoSecurityUrl} />
      </PageWrapper>
    );
  }
}

const mapStateToProps = state => ({
  headerBackNavigate: getHeaderBackNavSelector(state),
  footerInfoSecurityUrl: getFooterInfoSecurityUrl(state),
  channelDashboardUrl: getDashboardUrl(state),
  brandId: getBrandId(state),
});

const mapDispatchToProps = {
  signout: signoutActions.sso.signout.request,
};

export default connect(mapStateToProps, mapDispatchToProps)(MasterLayout);
