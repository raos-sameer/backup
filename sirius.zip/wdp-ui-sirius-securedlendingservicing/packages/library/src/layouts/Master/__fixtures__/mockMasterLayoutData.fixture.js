export const mockStoreData = {
  valid: [
    {
      ui: {
        securedLendingServicing: {
          app: {
            headerBackNavigate: 'PREVIOUS',
            showHidePopUp: false,
            selectedYearTerm: '2',
            selectedInterestRateForTerm: '3.96',
            alertBoxMessage: 'Test',
            selectedRepaymentType: '1',
          },
        },
      },
      config: { brandId: 'WBC' },
    },
    {
      ui: {
        securedLendingServicing: {
          app: {
            headerBackNavigate: 'CHANNEL',
            showHidePopUp: false,
            selectedYearTerm: '2',
            selectedInterestRateForTerm: '3.96',
            alertBoxMessage: 'Test',
            selectedRepaymentType: '1',
          },
        },
      },
      config: { brandId: 'WBC' },
    },
  ],
  invalid: [
    {
      ui: {
        securedLendingServicing: {
          app: {
            headerBackNavigate: 'OTHER',
            showHidePopUp: false,
            selectedYearTerm: '2',
            selectedInterestRateForTerm: '3.96',
            alertBoxMessage: 'Test',
            selectedRepaymentType: '1',
          },
        },
      },
      config: { brandId: 'WBC' },
    },
  ],
};
