import React from 'react';
import { shallow } from 'enzyme';
import configureMockStore from 'redux-mock-store';
import renderer from 'react-test-renderer';
import { withTheme } from '../../../../../utils/jest/TestUtils';
import { mockStoreData } from './__fixtures__/mockMasterLayoutData.fixture';
import MasterLayout from './MasterLayout';

const mockStore = configureMockStore();

describe('MasterLayout', () => {
  let store;
  const spy = jest.spyOn(global.console, 'error');
  const history = {
    push: jest.fn(),
    goBack: jest.fn(),
    replace: jest.fn(),
  };

  afterEach(() => {
    if (store && store.clearActions) {
      store.clearActions();
    }
    if (spy && spy.mockReset && spy.mockRestore) {
      spy.mockReset();
      spy.mockRestore();
    }
    if (history && history.push && history.goBack) {
      history.push.mockReset();
      history.push.mockRestore();
      history.goBack.mockReset();
      history.goBack.mockRestore();
    }
  });

  it('should render without error when required props are passed', () => {
    store = mockStore(mockStoreData.valid[0]);
    const component = withTheme(
      <MasterLayout history={history}>
        <div />
      </MasterLayout>,
    );
    shallow(component, { context: { store } }).dive();
    expect(spy).not.toHaveBeenCalled();
  });

  it('should match generated snapshot', () => {
    store = mockStore(mockStoreData.valid[0]);
    const component = withTheme(
      <MasterLayout history={history} store={store}>
        <div />
      </MasterLayout>,
    );
    const tree = renderer.create(component).toJSON();
    expect(tree).toMatchSnapshot();
  });

  it('should navigate back to previous page', () => {
    store = mockStore(mockStoreData.valid[0]);
    const wrapper = shallow(
      withTheme(
        <MasterLayout history={history} store={store}>
          <div />
        </MasterLayout>,
      ),
    );
    wrapper
      .dive()
      .dive()
      .dive()
      .dive()
      .instance()
      .headerLeftArrowAction();
    expect(history.goBack).toHaveBeenCalledTimes(1);
  });

  it('should navigate back to channel', () => {
    store = mockStore(mockStoreData.valid[1]);
    const wrapper = shallow(
      withTheme(
        <MasterLayout history={history} store={store}>
          <div />
        </MasterLayout>,
      ),
    );
    wrapper
      .dive()
      .dive()
      .dive()
      .dive()
      .instance()
      .headerLeftArrowAction();
    expect(history.goBack).not.toHaveBeenCalled();
  });

  it('should do nothing on back', () => {
    store = mockStore(mockStoreData.invalid[0]);
    const wrapper = shallow(
      withTheme(
        <MasterLayout history={history} store={store}>
          <div />
        </MasterLayout>,
      ),
    );
    wrapper
      .dive()
      .dive()
      .dive()
      .dive()
      .instance()
      .headerLeftArrowAction();
    expect(history.goBack).not.toHaveBeenCalled();
  });
});
