export const mockStoreData = {
  valid: [
    {
      ui: {
        securedLendingServicing: {
          app: {
            headerBackNavigate: 'PREVIOUS',
            showHidePopUp: false,
            repaymentType: '',
            selectedYearTerm: '',
            selectedInterestRateForTerm: '',
            alertBoxMessage: '',
          },
        },
      },
      config: { brandId: 'WBC' },
    },
  ],
  invalid: [
    {
      securedLendingServicing: {
        app: {
          headerBackNavigate: 'OTHER',
        },
      },
      config: { brandId: 'WBC' },
    },
  ],
};
