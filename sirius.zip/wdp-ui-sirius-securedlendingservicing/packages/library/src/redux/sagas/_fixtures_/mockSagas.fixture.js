export const mockStoreData = {
  valid: [
    {
      entities: {
        siriusCoreV1: {
          contexts: {
            byId: {
              'j-hwNz3u': {
                fields: [
                  {
                    fieldName: 'accountNumber',
                    value: '034017161770',
                  },
                  {
                    fieldName: 'CPC',
                    value: '9ba83148d96c4d1bac176afcff65b078',
                  },
                  {
                    fieldName: 'PackageType',
                    value: 'P',
                  },
                  {
                    fieldName: 'PackageName',
                    value: 'Premier Advantage Package',
                  },
                ],
                packageType: 'P',
                packageName: 'Premier Advantage',
                id: 'j-hwNz3u',
              },
            },
            allIds: ['j-hwNz3u'],
            isFetching: false,
            isError: false,
          },
        },
        siriusSecuredlendingservicingV1: {
          quotes: {
            byId: {
              '6aZvBOo5': {
                isDiscountApplicable: false,
                switchedProductName: 'Fixed Rate Investment Property Loan 1',
                isDiscretionaryDiscount: false,
                discountRate: '0.20',
                interestRate: '1.22',
                yearTerm: '1',
                LVRAdjustment: '1.3',
                id: '6aZvBOo5',
              },
              'ybppcQX-D': {
                isDiscountApplicable: false,
                isDiscretionaryDiscount: false,
                switchedProductName: 'Fixed Rate Investment Property Loan 1',
                discountRate: '0.17',
                interestRate: '4.2',
                yearTerm: '2',
                LVRAdjustment: '1.3',

                id: 'ybppcQX-D',
              },
              HUFDVOAv7: {
                isDiscountApplicable: false,
                isDiscretionaryDiscount: false,
                switchedProductName: 'Fixed Rate Investment Property Loan 1',
                discountRate: '0.40',
                interestRate: '3.95',
                yearTerm: '3',
                LVRAdjustment: '1.3',

                id: 'HUFDVOAv7',
              },
              '5oWf2qazV': {
                isDiscountApplicable: false,
                isDiscretionaryDiscount: false,
                switchedProductName: 'Fixed Rate Investment Property Loan 1',
                discountRate: '0.90',
                interestRate: '5.22',
                yearTerm: '4',
                LVRAdjustment: '1.3',

                id: '5oWf2qazV',
              },
              evhaaurcr: {
                isDiscountApplicable: true,
                isDiscretionaryDiscount: true,
                discountRate: '0.20',
                interestRate: '3.22',
                yearTerm: '5',
                LVRAdjustment: '1.3',

                id: 'evhaaurcr',
              },
            },
            allIds: [
              '6aZvBOo5',
              'ybppcQX-D',
              'HUFDVOAv7',
              '5oWf2qazV',
              'evhaaurcr',
            ],
            isFetching: false,
            isError: false,
          },

          eligibilities: {
            byId: {
              'j-hwNz3u': {
                status: 'Eligible',
                id: 'j-hwNz3u1',
              },
            },
            allIds: ['j-hwNz3u1'],
            isFetching: false,
            isError: false,
          },
          arrangements: {
            byId: {
              ZiWtQhuAo: {
                currentBalance: { amount: '300000', position: 'DR' },
                availableBalance: { amount: '300000', position: 'CR' },
                variableInterestRate: '4.20',
                loanMaturityDate: '23 Jan 2052',
                repaymentType: 'IO',
                interestOnlyMaturityDate: '01 Dec 2018',
                monthlyRepayment: '1400',
                redrawIndicatorSet: false,
                loanLimit: '1223',
                id: 'ZiWtQhuAo',
              },
            },
            allIds: ['ZiWtQhuAo'],
            isFetching: false,
            isError: false,
          },
        },
      },
    },
    {
      entities: {
        siriusCoreV1: {
          contexts: {
            byId: {
              'j-hwNz3u': {
                fields: [
                  {
                    fieldName: 'accountNumber',
                    value: '034017161770',
                  },
                  {
                    fieldName: 'CPC',
                    value: '9ba83148d96c4d1bac176afcff65b078',
                  },
                  {
                    fieldName: 'PackageType',
                    value: 'P',
                  },
                  {
                    fieldName: 'PackageName',
                    value: 'Premier Advantage Package',
                  },
                ],
                packageType: 'P',
                packageName: 'Premier Advantage',
                id: 'j-hwNz3u',
              },
              redrawAccounts: {
                byId: {},
                allIds: [],
                isFetching: false,
                isError: false,
              },
            },
            allIds: ['j-hwNz3u'],
            isFetching: false,
            isError: false,
          },
        },
        siriusSecuredlendingservicingV1: {
          quotes: {
            byId: {
              '6aZvBOo5': {
                isDiscountApplicable: false,
                isDiscretionaryDiscount: false,
                discountRate: '0.20',
                interestRate: '1.22',
                yearTerm: '1',
                LVRAdjustment: '1.3',
                id: '6aZvBOo5',
              },
              'ybppcQX-D': {
                isDiscountApplicable: false,
                isDiscretionaryDiscount: false,
                discountRate: '0.17',
                interestRate: '4.2',
                yearTerm: '2',
                LVRAdjustment: '1.3',

                id: 'ybppcQX-D',
              },
              HUFDVOAv7: {
                isDiscountApplicable: false,
                isDiscretionaryDiscount: false,
                discountRate: '0.40',
                interestRate: '3.95',
                yearTerm: '3',
                LVRAdjustment: '1.3',

                id: 'HUFDVOAv7',
              },
              '5oWf2qazV': {
                isDiscountApplicable: false,
                isDiscretionaryDiscount: false,
                discountRate: '0.90',
                interestRate: '5.22',
                yearTerm: '4',
                LVRAdjustment: '1.3',

                id: '5oWf2qazV',
              },
              evhaaurcr: {
                isDiscountApplicable: true,
                isDiscretionaryDiscount: true,
                discountRate: '0.20',
                interestRate: '3.22',
                yearTerm: '5',
                LVRAdjustment: '1.3',

                id: 'evhaaurcr',
              },
            },
            allIds: [
              '6aZvBOo5',
              'ybppcQX-D',
              'HUFDVOAv7',
              '5oWf2qazV',
              'evhaaurcr',
            ],
            isFetching: false,
            isError: false,
          },

          eligibilities: {
            byId: {
              'j-hwNz3u1': {
                status: 'Eligible',
                id: 'j-hwNz3u1',
              },
            },
            allIds: ['j-hwNz3u1'],
            isFetching: false,
            isError: false,
          },
          arrangements: {
            byId: {
              ZiWtQhuAo1: {
                currentBalance: '300000',
                availableBalance: '300000',
                variableInterestRate: '4.20',
                loanMaturityDate: '23 Jan 2052',
                repaymentType: 'IO',
                interestOnlyMaturityDate: '01 Dec 2018',
                monthlyRepayment: '1400',
                redrawIndicatorSet: false,
                loanLimit: '1223',
                id: 'ZiWtQhuAo1',
              },
            },
            allIds: ['ZiWtQhuAo1'],
            isFetching: false,
            isError: false,
          },
        },
      },
    },
  ],
  invalid: [],
};
