import SagaTester from 'redux-saga-tester';
import { combineReducers } from 'redux';
import { commonReducers } from '@wdpui/common-app-wrapper';
import configureMockStore from 'redux-mock-store';
import { arrangementsQuotesActions } from '@wdpui/redux-exp-sirius-securedlendingservicing-v1/actions';
import { reducer as securedLendingEntityReducer } from '@wdpui/redux-exp-sirius-securedlendingservicing-v1';
import { reducers as coreReducer } from '@wdpui/redux-exp-sirius-core-v1';

import rootReducer from '../modules';

import { mockStoreData } from './_fixtures_/mockSagas.fixture';

import fetchMortgageQuotes from './mortgageQuotesSaga';

const mockStore = configureMockStore();
const store = mockStore(mockStoreData.valid[0]);

const reducers = combineReducers({
  ...commonReducers,
  entities: combineReducers(securedLendingEntityReducer, coreReducer),
  ...rootReducer,
});

describe('mortgageQuotesSaga', () => {
  beforeEach(() => {
    // Runs before each test in the suite
    store.clearActions();
  });

  it('should trigger action for get mortgage quotes', async () => {
    const state = mockStoreData.valid[0];
    let sagaTester = new SagaTester({
      initialState: {
        ...state,
      },
      reducers,
    });
    sagaTester.start(fetchMortgageQuotes);

    const responseAction =
      arrangementsQuotesActions.api.arrangementsQuotes.get.receive;
    sagaTester.dispatch(responseAction());
    expect(sagaTester.getLatestCalledAction().type).toEqual(
      'api/arrangementsQuotes/get/RECEIVE',
    );

    // where eligibility repaymentType is not available
    const stateWithoutEligibilityStatus = {
      ui: {
        securedLendingServicing: {
          app: {
            headerBackNavigate: 'CHANNEL',
            showHidePopUp: false,
            selectedYearTerm: '3',
            selectedInterestRateForTerm: '3.96',
            alertBoxMessage:
              'The terms offered are within your interest only period. Switching to Principal and interest repayments may offer longer terms',
            selectedRepaymentType: 'IO',
            submitAction: 'SUCCESS',
          },
        },
      },
      entities: {
        siriusSecuredlendingservicingV1: {
          ...mockStoreData.valid[1].entities.siriusSecuredlendingservicingV1,
          eligibilities: {
            byId: {
              'j-hwNz3u': {
                status: 'NotEligible',
                isFlexiLoan: true,
                failureReason: {
                  reason: 'CaseExists',
                  details: 'User case already exists',
                },
                id: 'j-hwNz3u',
              },
            },
            allIds: ['j-hwNz3u'],
            isFetching: false,
            isError: false,
          },
          arrangements: {
            ...mockStoreData.valid[1].entities.siriusSecuredlendingservicingV1
              .arrangements,
            byId: {
              ZiWtQhuAo1: {
                currentBalance: { amount: '300000', position: 'DR' },
                availableBalance: { amount: '300000', position: 'CR' },
                variableInterestRate: '4.20',
                loanMaturityDate: '23 Jan 2052',
                repaymentType: 'IO',
                interestOnlyMaturityDate: '01 Dec 2018',
                monthlyRepayment: '1400',
                redrawIndicatorSet: false,
                remainingTermIO: '15',
                remainingTermPIF: '15',
                productName: 'flexi',
                loanLimit: '1223',
                id: 'ZiWtQhuAo',
              },
            },
          },
        },
      },
    };

    sagaTester = new SagaTester({
      initialState: {
        ...stateWithoutEligibilityStatus,
      },
      reducers,
    });
    sagaTester.start(fetchMortgageQuotes);

    sagaTester.dispatch(responseAction());
  });
});
