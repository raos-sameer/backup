import { put, select, takeLatest } from 'redux-saga/effects';
import { arrangementsQuotesActions } from '@wdpui/redux-exp-sirius-securedlendingservicing-v1/actions';

import { isEmpty, size, first } from 'lodash';
import { actions as appActions } from '../modules/app.module';

import {
  getCurrentLoanDetails,
  getContextData,
  getCustomersEligibility,
  getRepaymentType,
  isRemainingLoanTermLessThanYear,
} from '../selectors';

export function* handleQuotesErrorResponse({ payload }) {
  const {
    error: { data, status },
  } = payload;

  if (status === 500) {
    const {
      result: { errors },
    } = data;

    if (size(errors) > 0 && first(errors).code === 10001) {
      yield put(appActions.app.interestrate.setQuotesError('PRICING'));
    } else {
      yield put(appActions.app.interestrate.setQuotesError('GENERIC'));
    }
  }
}

export default function* fetchMortgageQuotes() {
  const eligibilityData = yield select(getCustomersEligibility);
  const contextDetails = yield select(getContextData);
  const termLessThanYear = yield select(isRemainingLoanTermLessThanYear);

  const { status } = eligibilityData;
  const selectedRepaymentType = yield select(getRepaymentType);
  const {
    repaymentType,
    interestOnlyMaturityDate,
    loanMaturityDate,
    loanLimit,
  } = yield select(getCurrentLoanDetails);
  const { arrangementId, canonicalProductCode, packageType } = contextDetails;
  const metaRequestObject = {
    refreshMethod: 'NONE',
    replaceEntities: ['quotes'],
  };
  const repaymentIndicator = selectedRepaymentType || repaymentType;

  if (
    status === 'Eligible' &&
    canonicalProductCode &&
    repaymentIndicator &&
    !termLessThanYear
  ) {
    yield put(
      arrangementsQuotesActions.api.arrangementsQuotes.get.request({
        repaymentType: repaymentIndicator,
        isPackageEnabled: !isEmpty(packageType),
        maturityDate:
          repaymentIndicator === 'IO'
            ? interestOnlyMaturityDate
            : loanMaturityDate,
        canonicalProductCode,
        limitAmount: loanLimit,
        pathParams: { arrangementId },
        meta: metaRequestObject,
        ...(packageType && { packageType }),
      }),
    );

    yield takeLatest(
      [arrangementsQuotesActions.api.arrangementsQuotes.get.error],
      handleQuotesErrorResponse,
    );
  }
}
