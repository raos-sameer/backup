import { put, select, takeLatest } from 'redux-saga/effects';

import { arrangementsByIdActions } from '@wdpui/redux-exp-sirius-securedlendingservicing-v1/actions';
import {
  getSubmitDetails,
  getSubmitRequestBody,
  getContextData,
} from '../selectors';
import { actions as appActions } from '../modules/app.module';

export function* handleSubmitDetailsError() {
  yield put(appActions.app.interestrate.setSubmitSuccess('ERROR'));
}

export function* handleSubmitDetailsReponse() {
  const submitDetails = yield select(getSubmitDetails);
  const { caseId, caseReferenceNumber } = submitDetails;
  if (caseId && caseReferenceNumber) {
    yield put(appActions.app.interestrate.setSubmitSuccess('SUCCESS'));
  } else {
    yield put(appActions.app.interestrate.setSubmitSuccess('ERROR'));
  }
}
export default function* submitArrangementDetails() {
  const contextDetails = yield select(getContextData);
  const { arrangementId } = contextDetails;
  const metaRequestObject = { refreshMethod: 'NONE' };

  const bodyParams = yield select(getSubmitRequestBody);

  yield put(
    arrangementsByIdActions.api.arrangementsById.post.request({
      params: bodyParams,
      pathParams: { arrangementId },
      meta: metaRequestObject,
    }),
  );
  yield takeLatest(
    [arrangementsByIdActions.api.arrangementsById.post.receive],
    handleSubmitDetailsReponse,
  );

  yield takeLatest(
    [arrangementsByIdActions.api.arrangementsById.post.error],
    handleSubmitDetailsReponse,
  );
}
