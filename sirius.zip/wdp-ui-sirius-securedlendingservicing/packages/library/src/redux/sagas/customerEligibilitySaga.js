import { put, select } from 'redux-saga/effects';
import { eligibilitiesActions } from '@wdpui/redux-exp-sirius-securedlendingservicing-v1/actions';
import { getContextData, getCustomersEligibility } from '../selectors';

export default function* fetchCustomerEligibility() {
  const contextDetails = yield select(getContextData);
  const { arrangementId, canonicalProductCode } = contextDetails;
  const { status } = yield select(getCustomersEligibility);

  const metaRequestObject = { refreshMethod: 'NONE' };
  if (canonicalProductCode && !status) {
    yield put(
      eligibilitiesActions.api.eligibilities.get.request({
        canonicalProductCode,
        arrangementId,
        meta: metaRequestObject,
      }),
    );
  }
}
