import { put, select } from 'redux-saga/effects';
import { arrangementsByIdActions } from '@wdpui/redux-exp-sirius-securedlendingservicing-v1/actions';
import { getContextData, getCustomersEligibility } from '../selectors';

export default function* fetchCurrentLoanDetails() {
  const eligibilityData = yield select(getCustomersEligibility);
  const { status } = eligibilityData;
  if (status === 'Eligible') {
    const contextDetails = yield select(getContextData);
    const { arrangementId, canonicalProductCode } = contextDetails;
    const metaRequestObject = { refreshMethod: 'NONE' };
    yield put(
      arrangementsByIdActions.api.arrangementsById.get.request({
        canonicalProductCode,
        pathParams: { arrangementId },
        meta: metaRequestObject,
      }),
    );
  }
}
