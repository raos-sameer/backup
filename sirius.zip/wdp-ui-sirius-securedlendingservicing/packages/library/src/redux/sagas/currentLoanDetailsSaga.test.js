import SagaTester from 'redux-saga-tester';
import { combineReducers } from 'redux';
import { commonReducers } from '@wdpui/common-app-wrapper';
import configureMockStore from 'redux-mock-store';
import { arrangementsByIdActions } from '@wdpui/redux-exp-sirius-securedlendingservicing-v1/actions';
import { reducer as securedLendingEntityReducer } from '@wdpui/redux-exp-sirius-securedlendingservicing-v1';
import { mockStoreData } from './_fixtures_/mockSagas.fixture';
import rootReducer from '../modules';
import fetchCurrentLoanDetails from './currentLoanDetailsSaga';

const mockStore = configureMockStore();
const store = mockStore(mockStoreData.valid[0]);

const reducers = combineReducers({
  ...commonReducers,
  entities: combineReducers(securedLendingEntityReducer),
  ...rootReducer,
});

describe('currentLoanDetailsSaga', () => {
  beforeEach(() => {
    // Runs before each test in the suite
    store.clearActions();
  });
  it('should dispatch action fetchCurrentLoanDetails', async () => {
    const state = mockStoreData.valid[1];
    let sagaTester = new SagaTester({
      initialState: {
        ...state,
      },
      reducers,
    });
    sagaTester.start(fetchCurrentLoanDetails);

    const responseAction =
      arrangementsByIdActions.api.arrangementsById.get.receive;
    sagaTester.dispatch(responseAction());

    expect(sagaTester.getLatestCalledAction().type).toEqual(
      'api/arrangementsById/get/RECEIVE',
    );
    // where eligibility data status is not available
    const stateWithoutEligibilityStatus = {
      entities: {
        siriusSecuredlendingservicingV1: {
          ...mockStoreData.valid[1].entities.siriusSecuredlendingservicingV1,
          eligibilities: {
            ...mockStoreData.valid[1].entities.siriusSecuredlendingservicingV1
              .eligibilities,
            byId: {
              'j-hwNz3u1': {
                status: '',
                id: 'j-hwNz3u1',
              },
            },
          },
        },
      },
    };
    sagaTester = new SagaTester({
      initialState: {
        ...stateWithoutEligibilityStatus,
      },
      reducers,
    });
    sagaTester.start(fetchCurrentLoanDetails);
  });
});
