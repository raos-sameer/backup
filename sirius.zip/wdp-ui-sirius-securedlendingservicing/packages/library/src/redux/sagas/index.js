import { put, select, all, takeLatest } from 'redux-saga/effects';
import { contextsByIdActions } from '@wdpui/redux-exp-sirius-core-v1/actions';
import { arrangementsByIdActions } from '@wdpui/redux-exp-sirius-securedlendingservicing-v1/actions';
import { formActions } from '../actions/formActions';
import fetchCustomerEligibility from './customerEligibilitySaga';
import fetchCurrentLoanDetails from './currentLoanDetailsSaga';
import { getContextData } from '../selectors';
import { actions as appActions } from '../modules/app.module';

import fetchRedrawAccounts from './redrawAccountsSaga';

import fetchMortgageQuotes from './mortgageQuotesSaga';
import submitArrangementDetails from './submitArrangementDetailsSaga';

export function* handleContextExpiry() {
  const { arrangementId } = yield select(getContextData);
  if (!arrangementId) {
    yield put(appActions.app.interestrate.setContextExpired(true));
  }
}
export function* securedLendingSagas() {
  yield all([
    yield takeLatest(
      formActions.getCustomerEligibility,
      fetchCustomerEligibility,
    ),
    yield takeLatest(formActions.getRedrawAccounts, fetchRedrawAccounts),
    yield takeLatest(formActions.submitDetails, submitArrangementDetails),
    yield takeLatest(formActions.getMortgageQuotes, fetchMortgageQuotes),
    yield takeLatest(
      formActions.getCurrentLoanDetails,
      fetchCurrentLoanDetails,
    ),

    yield takeLatest(
      arrangementsByIdActions.api.arrangementsById.get.receive,
      fetchMortgageQuotes,
    ),
    yield takeLatest(
      contextsByIdActions.api.contextsById.get.receive,
      handleContextExpiry,
    ),
  ]);
}
