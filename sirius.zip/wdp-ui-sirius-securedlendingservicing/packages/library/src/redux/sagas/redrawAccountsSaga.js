import { put, select, takeLatest } from 'redux-saga/effects';
import { redrawAccountsByIdActions } from '@wdpui/redux-exp-sirius-securedlendingservicing-v1/actions';
import { getArrangementId, getRedrawAccounts } from '../selectors';
import { actions as appActions } from '../modules/app.module';

export function* handleRedrawResponse() {
  const redrawAccounts = yield select(getRedrawAccounts);

  if (redrawAccounts && redrawAccounts.length === 0) {
    yield put(appActions.app.interestrate.setRedrawError('NOACCOUNTS'));
  }
}

export default function* fetchRedrawAccounts() {
  const metaRequestObject = { refreshMethod: 'NONE' };
  const arrangementId = yield select(getArrangementId);

  yield put(
    redrawAccountsByIdActions.api.redrawAccountsById.get.request({
      pathParams: { arrangementId },
      meta: metaRequestObject,
    }),
  );
  yield takeLatest(
    [redrawAccountsByIdActions.api.redrawAccountsById.get.receive],
    handleRedrawResponse,
  );
}
