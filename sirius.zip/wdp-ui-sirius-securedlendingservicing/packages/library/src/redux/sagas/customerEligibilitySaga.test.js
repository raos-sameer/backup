import configureMockStore from 'redux-mock-store';
import SagaTester from 'redux-saga-tester';
import { combineReducers } from 'redux';
import { eligibilitiesActions } from '@wdpui/redux-exp-sirius-securedlendingservicing-v1/actions';

import { commonReducers } from '@wdpui/common-app-wrapper';
import { reducer as securedLendingEntityReducer } from '@wdpui/redux-exp-sirius-securedlendingservicing-v1';
import { mockStoreData } from './_fixtures_/mockSagas.fixture';
import rootReducer from '../modules';

import fetchCustomerEligibility from './customerEligibilitySaga';

const mockStore = configureMockStore();
const store = mockStore(mockStoreData.valid[0]);

const reducers = combineReducers({
  ...commonReducers,
  entities: combineReducers(securedLendingEntityReducer),
  ...rootReducer,
});

describe('customerEligibilitySaga', () => {
  beforeEach(() => {
    // Runs before each test in the suite
    store.clearActions();
  });
  it('should dispatch action fetchCustomerEligibility', () => {
    const state = mockStoreData.valid[0];
    let sagaTester = new SagaTester({
      initialState: {
        ...state,
      },
      reducers,
    });
    sagaTester.start(fetchCustomerEligibility);

    const responseAction = eligibilitiesActions.api.eligibilities.get.receive;
    sagaTester.dispatch(responseAction());
    expect(sagaTester.getLatestCalledAction().type).toEqual(
      'api/eligibilities/get/RECEIVE',
    );
    // where eligibility data status and canonicalProductCode is not available
    const stateWithoutEligibilityStatus = {
      entities: {
        siriusSecuredlendingservicingV1: {
          ...mockStoreData.valid[1].entities.siriusSecuredlendingservicingV1,
          eligibilities: {
            ...mockStoreData.valid[1].entities.siriusSecuredlendingservicingV1
              .eligibilities,
            byId: {
              'j-hwNz3u1': {
                status: null,
                id: 'j-hwNz3u1',
              },
            },
          },
          contexts: {
            ...mockStoreData.valid[1].entities.siriusCoreV1.contexts,
            byId: {
              ...mockStoreData.valid[1].entities.siriusCoreV1.contexts.byId,
              'j-hwNz3u': {
                arrangementId: '034017161770',
                canonicalProductCode: null,
                packageType: 'P',
                packageName: 'Premier Advantage',
                id: 'j-hwNz3u',
              },
            },
          },
        },
      },
    };
    sagaTester = new SagaTester({
      initialState: {
        ...stateWithoutEligibilityStatus,
      },
      reducers,
    });
    sagaTester.start(fetchCustomerEligibility);
  });
});
