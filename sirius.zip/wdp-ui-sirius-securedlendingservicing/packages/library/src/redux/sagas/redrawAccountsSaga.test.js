import configureMockStore from 'redux-mock-store';
import { runSaga } from 'redux-saga';
import SagaTester from 'redux-saga-tester';
import { combineReducers } from 'redux';
import { redrawAccountsByIdActions } from '@wdpui/redux-exp-sirius-securedlendingservicing-v1/actions';

import { commonReducers } from '@wdpui/common-app-wrapper';
import { reducer as securedLendingEntityReducer } from '@wdpui/redux-exp-sirius-securedlendingservicing-v1';
import fetchRedrawAccounts from './redrawAccountsSaga';
import rootReducer from '../modules';
import { mockStoreData } from './_fixtures_/mockSagas.fixture';

const mockStore = configureMockStore();
const store = mockStore(mockStoreData.valid[0]);

const reducers = combineReducers({
  ...commonReducers,
  entities: combineReducers(securedLendingEntityReducer),
  ...rootReducer,
});

export async function recordSaga(saga, initialAction, state) {
  const responseAction =
    redrawAccountsByIdActions.api.redrawAccountsById.get.request;
  const dispatched = [responseAction()];

  await runSaga(
    {
      dispatch: action => dispatched.push(action),
      getState: () => ({
        ...state,
      }),
    },
    saga,
    initialAction,
  ).done;

  return dispatched;
}

describe('redrawAccountsSaga', () => {
  beforeEach(() => {
    // Runs before each test in the suite
    store.clearActions();
  });

  it('should trigger action for get redraw accounts', async () => {
    const state = mockStoreData.valid[0];
    const sagaTester = new SagaTester({
      initialState: {
        ...state,
      },
      reducers,
    });
    sagaTester.start(fetchRedrawAccounts);

    const responseAction =
      redrawAccountsByIdActions.api.redrawAccountsById.get.receive;
    sagaTester.dispatch(responseAction());
    expect(sagaTester.getLatestCalledAction().type).toEqual(
      'app/interestrate/SET_REDRAW_ERROR',
    );
  });
});
