import configureMockStore from 'redux-mock-store';
import { runSaga } from 'redux-saga';
import SagaTester from 'redux-saga-tester';
import { combineReducers } from 'redux';
import { arrangementsByIdActions } from '@wdpui/redux-exp-sirius-securedlendingservicing-v1/actions';

import { commonReducers } from '@wdpui/common-app-wrapper';
import { reducer as securedLendingEntityReducer } from '@wdpui/redux-exp-sirius-securedlendingservicing-v1';
import rootReducer from '../modules';
import { mockStoreData } from './_fixtures_/mockSagas.fixture';
import submitArrangementDetails from './submitArrangementDetailsSaga';

const mockStore = configureMockStore();
const store = mockStore(mockStoreData.valid[0]);

const reducers = combineReducers({
  ...commonReducers,
  entities: combineReducers(securedLendingEntityReducer),
  ...rootReducer,
});

export async function recordSaga(saga, initialAction, state) {
  const responseAction =
    arrangementsByIdActions.api.arrangementsById.post.request;
  const dispatched = [responseAction()];

  await runSaga(
    {
      dispatch: action => dispatched.push(action),
      getState: () => ({
        ...state,
      }),
    },
    saga,
    initialAction,
  ).done;

  return dispatched;
}

describe('submitArrangementDetailsSaga', () => {
  beforeEach(() => {
    // Runs before each test in the suite
    store.clearActions();
  });

  it('should trigger action for get redraw accounts', async () => {
    const state = mockStoreData.valid[0];
    const sagaTester = new SagaTester({
      initialState: {
        ...state,
      },
      reducers,
    });
    sagaTester.start(submitArrangementDetails);

    const responseAction =
      arrangementsByIdActions.api.arrangementsById.post.receive;
    sagaTester.dispatch(responseAction());
    expect(sagaTester.getLatestCalledAction().type).toEqual(
      'api/arrangementsById/post/RECEIVE',
    );
  });
});
