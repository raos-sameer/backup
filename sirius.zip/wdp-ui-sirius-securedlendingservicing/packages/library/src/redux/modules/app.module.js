import { createActions, handleActions } from 'redux-actions';

export const actions = createActions({
  app: {
    header: {
      NAVIGATE_BACK: action => action,
    },
    modal: {
      SET_SHOW_HIDE_POPUP: action => action,
      SET_REDRAW_SHOW_HIDE_POPUP: action => action,
      SET_REDRAW_MODAL_TITLE: action => action,
      SET_REDRAW_MODAL_BUTTON_TEXT: action => action,
    },
    interestrate: {
      SET_REPAYMENT_TYPE: action => action,
      SET_INTEREST_RATE_TERM: action => action,
      SET_YEAR_TERM: action => action,
      SET_ALERT_MESSAGE: action => action,
      SET_FIXED_OPTION_RATE: action => action,
      SET_INPUT_VALUE_DATA: action => action,
      SET_REDRAW_FUNDS_ACCOUNTS: action => action,
      SET_FIELD_SELECT_VALUE: action => action,
      SET_REDRAW_ALERT_MESSAGE: action => action,
      SET_SPLIT_FIXED_AMOUNT: action => action,
      SET_SPLIT_VARIABLE_AMOUNT: action => action,
      SET_FIXED_LOAN_BALANCE: action => action,
      SET_VARIABLE_LOAN_BALANCE: action => action,
      SET_AMOUNT_VALIDATION_MESSAGE: action => action,
      SET_SUBMIT_SUCCESS: action => action,
      SET_CONTEXT_EXPIRED: action => action,
      SET_QUOTES_ERROR: action => action,
      SET_REDRAW_ERROR: action => action,
    },
  },
});

export const securedLendingServicingReducer = handleActions(
  {
    [actions.app.header.navigateBack]: (state, action) => ({
      ...state,
      headerBackNavigate: action.payload,
    }),
    [actions.app.modal.setShowHidePopup]: (state, action) => ({
      ...state,
      showHidePopUp: action.payload,
    }),
    [actions.app.interestrate.setRepaymentType]: (state, action) => ({
      ...state,
      selectedRepaymentType: action.payload,
    }),
    [actions.app.interestrate.setYearTerm]: (state, action) => ({
      ...state,
      selectedYearTerm: action.payload,
    }),
    [actions.app.interestrate.setInterestRateTerm]: (state, action) => ({
      ...state,
      selectedInterestRateForTerm: action.payload,
    }),
    [actions.app.interestrate.setFixedOptionRate]: (state, action) => ({
      ...state,
      selectedLoanOption: action.payload,
    }),
    [actions.app.interestrate.setInputValueData]: (state, action) => ({
      ...state,
      inputAmountData: action.payload,
    }),
    [actions.app.interestrate.setAlertMessage]: (state, action) => ({
      ...state,
      alertBoxMessage: action.payload,
    }),
    [actions.app.modal.setRedrawShowHidePopup]: (state, action) => ({
      ...state,
      redrawShowHidePopup: action.payload,
    }),
    [actions.app.modal.setRedrawModalTitle]: (state, action) => ({
      ...state,
      redrawModalTitle: action.payload,
    }),
    [actions.app.modal.setRedrawModalButtonText]: (state, action) => ({
      ...state,
      redrawModalButtonText: action.payload,
    }),
    [actions.app.interestrate.setRedrawFundsAccounts]: (state, action) => ({
      ...state,
      redrawFundAccountsList: action.payload,
    }),
    [actions.app.interestrate.setFieldSelectValue]: (state, action) => ({
      ...state,
      selectedAccount: action.payload,
    }),
    [actions.app.interestrate.setRedrawAlertMessage]: (state, action) => ({
      ...state,
      redrawAlertBoxMessage: action.payload,
    }),
    [actions.app.interestrate.setSplitFixedAmount]: (state, action) => ({
      ...state,
      splitFixedAmount: action.payload,
    }),
    [actions.app.interestrate.setSplitVariableAmount]: (state, action) => ({
      ...state,
      splitVariableAmount: action.payload,
    }),
    [actions.app.interestrate.setFixedLoanBalance]: (state, action) => ({
      ...state,
      fixedLoanBalance: action.payload,
    }),
    [actions.app.interestrate.setVariableLoanBalance]: (state, action) => ({
      ...state,
      variableLoanBalance: action.payload,
    }),
    [actions.app.interestrate.setAmountValidationMessage]: (state, action) => ({
      ...state,
      amountValidationMessage: action.payload,
    }),
    [actions.app.interestrate.setSubmitSuccess]: (state, action) => ({
      ...state,
      submitAction: action.payload,
    }),
    [actions.app.interestrate.setContextExpired]: (state, action) => ({
      ...state,
      isContextExpired: action.payload,
    }),
    [actions.app.interestrate.setQuotesError]: (state, action) => ({
      ...state,
      quotesError: action.payload,
    }),
    [actions.app.interestrate.setRedrawError]: (state, action) => ({
      ...state,
      redrawResponse: action.payload,
    }),
  },
  {
    headerBackNavigate: '',
    showHidePopUp: false,
    selectedInterestRateForTerm: '',
    selectedYearTerm: '',
    alertBoxMessage: '',
    setFixedOptionRate: '',
    setInputValueData: '',
    selectedRepaymentType: '',
    setRedrawShowHidePopup: '',
    redrawShowHidePopup: false,
    setRedrawModalTitle: '',
    redrawModalTitle: '',
    setRedrawModalButtonText: '',
    redrawModalButtonText: '',
    setRedrawFundsAccounts: '',
    redrawFundAccountsList: [],
    setFieldSelectValue: '',
    selectedAccount: '',
    redrawAlertBoxMessage: '',
    splitFixedAmount: '',
    splitVariableAmount: '',
    fixedLoanBalance: '',
    variableLoanBalance: '',
    amountValidationMessage: '',
    submitAction: '',
    isContextExpired: false,
    quotesError: '',
    redrawResponse: '',
  },
);
