import { actions, securedLendingServicingReducer } from './app.module';

describe('app.module -> header', () => {
  it('should set the correct header navigation action', () => {
    expect(
      securedLendingServicingReducer(
        {},
        actions.app.header.navigateBack('PREVIOUS'),
      ),
    ).toEqual({
      headerBackNavigate: 'PREVIOUS',
    });
  });
});

describe('app.module -> interest rate', () => {
  it('should set the correct value for setRepaymentType for interest rate selector', () => {
    expect(
      securedLendingServicingReducer(
        {},
        actions.app.interestrate.setRepaymentType('IO'),
      ),
    ).toEqual({
      selectedRepaymentType: 'IO',
    });
  });

  it('should set the correct value for setYearTerm for interest rate selector', () => {
    expect(
      securedLendingServicingReducer(
        {},
        actions.app.interestrate.setYearTerm('2'),
      ),
    ).toEqual({
      selectedYearTerm: '2',
    });
  });

  it('should set the correct value for setInterestRateTerm for interest rate selector', () => {
    expect(
      securedLendingServicingReducer(
        {},
        actions.app.interestrate.setInterestRateTerm('2'),
      ),
    ).toEqual({
      selectedInterestRateForTerm: '2',
    });
  });

  it('should set the correct value for setAlertMessage for interest rate selector', () => {
    expect(
      securedLendingServicingReducer(
        {},
        actions.app.interestrate.setAlertMessage('Test Alert Message'),
      ),
    ).toEqual({
      alertBoxMessage: 'Test Alert Message',
    });
  });
  it('should set the correct value for setRedrawAlertMessage for interest rate selector', () => {
    expect(
      securedLendingServicingReducer(
        {},
        actions.app.interestrate.setRedrawAlertMessage('Test Alert Message'),
      ),
    ).toEqual({
      redrawAlertBoxMessage: 'Test Alert Message',
    });
  });
});

describe('app.module -> modal', () => {
  it('should set the correct value for setShowHidePopup for modal popup', () => {
    expect(
      securedLendingServicingReducer(
        {},
        actions.app.modal.setShowHidePopup(true),
      ),
    ).toEqual({
      showHidePopUp: true,
    });
  });
});

describe('app.module -> redraw modal', () => {
  it('should set the correct value for setRedrawShowHidePopup for modal popup', () => {
    expect(
      securedLendingServicingReducer(
        {},
        actions.app.modal.setRedrawShowHidePopup(true),
      ),
    ).toEqual({
      redrawShowHidePopup: true,
    });
  });
  it('should set the correct value for setRedrawModalButtonText for modal popup', () => {
    expect(
      securedLendingServicingReducer(
        {},
        actions.app.modal.setRedrawModalButtonText('Test button text'),
      ),
    ).toEqual({
      redrawModalButtonText: 'Test button text',
    });
  });
  it('should set the correct value for setRedrawModalTitle for modal popup', () => {
    expect(
      securedLendingServicingReducer(
        {},
        actions.app.modal.setRedrawModalTitle('Test title'),
      ),
    ).toEqual({
      redrawModalTitle: 'Test title',
    });
  });
});

describe('app.module -> redraw modal container', () => {
  it('should set the correct value for setRedrawFundsAccounts for modal popup', () => {
    expect(
      securedLendingServicingReducer(
        {},
        actions.app.interestrate.setRedrawFundsAccounts([
          { label: 'Test1', value: '1' },
        ]),
      ),
    ).toEqual({
      redrawFundAccountsList: [{ label: 'Test1', value: '1' }],
    });
  });
  it('should set the correct value for setFieldSelectValue for dropdown', () => {
    expect(
      securedLendingServicingReducer(
        {},
        actions.app.interestrate.setFieldSelectValue('Complete Freedom'),
      ),
    ).toEqual({
      selectedAccount: 'Complete Freedom',
    });
  });
});
describe('app.module -> Fixed options select container', () => {
  it('should set the correct value for setInputValueData for amount entered', () => {
    expect(
      securedLendingServicingReducer(
        {},
        actions.app.interestrate.setInputValueData('1.11'),
      ),
    ).toEqual({
      inputAmountData: '1.11',
    });
  });
  it('should set the correct value for setFixedOptionRate for radio option selected', () => {
    expect(
      securedLendingServicingReducer(
        {},
        actions.app.interestrate.setFixedOptionRate('Redraw'),
      ),
    ).toEqual({
      selectedLoanOption: 'Redraw',
    });
  });
  it('should set the correct value for setSplitVariableAmount for amount entered', () => {
    expect(
      securedLendingServicingReducer(
        {},
        actions.app.interestrate.setSplitVariableAmount('1111'),
      ),
    ).toEqual({
      splitVariableAmount: '1111',
    });
  });
  it('should set the correct value for setSplitFixedAmount for amount entered', () => {
    expect(
      securedLendingServicingReducer(
        {},
        actions.app.interestrate.setSplitFixedAmount('1222'),
      ),
    ).toEqual({
      splitFixedAmount: '1222',
    });
  });

  it('should set the correct value for setVariableLoanBalance for amount entered', () => {
    expect(
      securedLendingServicingReducer(
        {},
        actions.app.interestrate.setVariableLoanBalance('1111'),
      ),
    ).toEqual({
      variableLoanBalance: '1111',
    });
  });
  it('should set the correct value for setFixedLoanBalance for amount entered', () => {
    expect(
      securedLendingServicingReducer(
        {},
        actions.app.interestrate.setFixedLoanBalance('1222'),
      ),
    ).toEqual({
      fixedLoanBalance: '1222',
    });
  });
  it('should set the success of submit button', () => {
    expect(
      securedLendingServicingReducer(
        {},
        actions.app.interestrate.setSubmitSuccess('Test Message'),
      ),
    ).toEqual({
      submitAction: 'Test Message',
    });
  });
  it('should set the validation message if amount not entered on click of calculate button', () => {
    expect(
      securedLendingServicingReducer(
        {},
        actions.app.interestrate.setAmountValidationMessage('Test Message'),
      ),
    ).toEqual({
      amountValidationMessage: 'Test Message',
    });
  });
  it('should set the value for setContextExpired', () => {
    expect(
      securedLendingServicingReducer(
        {},
        actions.app.interestrate.setContextExpired(true),
      ),
    ).toEqual({
      isContextExpired: true,
    });
  });

  it('should set the error response of quotes api', () => {
    expect(
      securedLendingServicingReducer(
        {},
        actions.app.interestrate.setQuotesError('Test Message'),
      ),
    ).toEqual({
      quotesError: 'Test Message',
    });
  });
  it('should set the error response of quotes api', () => {
    expect(
      securedLendingServicingReducer(
        {},
        actions.app.interestrate.setRedrawError('Test Message'),
      ),
    ).toEqual({
      redrawResponse: 'Test Message',
    });
  });
});
