import { combineReducers } from 'redux';
import { securedLendingServicingReducer } from './app.module';

const rootReducer = {
  securedLendingServicing: combineReducers({
    app: securedLendingServicingReducer,
  }),
};

export * from './app.module';
export default rootReducer;
