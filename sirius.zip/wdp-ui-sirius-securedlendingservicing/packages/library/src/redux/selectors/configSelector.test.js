import {
  getConfig,
  getSecuredLendingConfig,
  getBrandId,
  getDashboardUrl,
  getFooterInfoSecurityUrl,
  getMessageInboxUrl,
  getDirectDebitUrlPrincipalInterest,
  getDirectDebitUrlInterestOnly,
  getConditionsOfUseUrl,
  getBreakCostUrl,
  getSwitchingFee,
  getAdditionalPaymentAmount,
  getMonthlyMaintainenceFee,
  getDiscountRate,
  getPackageFee,
} from './configSelector';

const defaultState = {
  config: {
    brandId: 'WBC',
    securedlendingservicing: {
      switchingFee: '500',
      additionalPaymentAmount: '30,000',
      monthlyMaintainenceFee: '8',
      packageFee: '395',
      discount: '0.20',
      footerInfoSecurityUrl: {
        STG:
          'https://webapps.stgeorge.com.au/apply-now/acc_help.asp#security?view=oaf',
        BOM:
          'https://webapps.bankofmelbourne.com.au/apply-now/acc_help.asp#security?view=oaf',
        BSA:
          'https://webapps.banksa.com.au/apply-now/acc_help.asp#security?view=oaf',
        WBC:
          'https://webapps.stgeorge.com.au/apply-now/acc_help.asp#security?view=oaf',
      },
      dashboardUrl: {
        STG:
          'https://vp1ibank.stgeorge.com.au/services/wdpToCompass?actionType=dashboard',
        BOM:
          'https://vp1ibank.bankofmelbourne.com.au/services/wdpToCompass?actionType=dashboard',
        BSA:
          'https://vp1ibank.banksa.com.au/services/wdpToCompass?actionType=dashboard',
        WBC:
          'https://vp1ibank.stgeorge.com.au/services/wdpToCompass?actionType=dashboard',
      },
      conditionsOfUseUrl: {
        STG:
          'https://www.stgeorge.com.au/content/dam/public/wbc/documents/pdf/pb/PAP_ConditionsofUse.pdf',
        BOM:
          'https://www.bankofmelbourne.com.au/content/dam/public/wbc/documents/pdf/pb/PAP_ConditionsofUse.pdf',
        BSA:
          'https://www.banksa.com.au/content/dam/public/wbc/documents/pdf/pb/PAP_ConditionsofUse.pdf',
        WBC:
          'https://www.westpac.com.au/content/dam/public/wbc/documents/pdf/pb/PAP_ConditionsofUse.pdf',
      },
      messageInboxUrl: {
        STG:
          'https://www.stgeorge.com.au/content/dam/public/wbc/documents/pdf/pb/PAP_ConditionsofUse.pdf',
        BOM:
          'https://www.bankofmelbourne.com.au/content/dam/public/wbc/documents/pdf/pb/PAP_ConditionsofUse.pdf',
        BSA:
          'https://www.banksa.com.au/content/dam/public/wbc/documents/pdf/pb/PAP_ConditionsofUse.pdf',
        WBC:
          'https://www.westpac.com.au/content/dam/public/wbc/documents/pdf/pb/PAP_ConditionsofUse.pdf',
      },
      directDebitUrlInterestOnly: {
        STG:
          'https://www.stgeorge.com.au/content/dam/public/wbc/documents/pdf/pb/Direct_Debit_Request_Interest_Only_Loan_Repayment.pdf',
        BOM:
          'https://www.bankofmelbourne.com.au/content/dam/public/wbc/documents/pdf/pb/Direct_Debit_Request_Interest_Only_Loan_Repayment.pdf',
        BSA:
          'https://www.banksa.com.au/content/dam/public/wbc/documents/pdf/pb/Direct_Debit_Request_Interest_Only_Loan_Repayment.pdf',
        WBC:
          'https://www.westpac.com.au/content/dam/public/wbc/documents/pdf/pb/Direct_Debit_Request_Interest_Only_Loan_Repayment.pdf',
      },
      directDebitUrlPrincipalInterest: {
        STG:
          'https://www.stgeorge.com.au/content/dam/public/wbc/documents/pdf/pb/Direct_Debit_Request_Loan_Repayment.pdf',
        BOM:
          'https://www.bankofmelbourne.com.au/content/dam/public/wbc/documents/pdf/pb/Direct_Debit_Request_Loan_Repayment.pdf',
        BSA:
          'https://www.banksa.com.au/content/dam/public/wbc/documents/pdf/pb/Direct_Debit_Request_Loan_Repayment.pdf',
        WBC:
          'https://www.westpac.com.au/content/dam/public/wbc/documents/pdf/pb/Direct_Debit_Request_Loan_Repayment.pdf',
      },
      breakCostUrl: {
        STG:
          'https://www.stgeorge.com.au/content/dam/public/wbc/documents/pdf/pb/WBC-things-you-should-know-about-break-costs.pdf?appAction=PDF',
        BOM:
          'https://www.bankofmelbourne.com.au/content/dam/public/wbc/documents/pdf/pb/WBC-things-you-should-know-about-break-costs.pdf?appAction=PDF',
        BSA:
          'https://www.banksa.com.au/content/dam/public/wbc/documents/pdf/pb/WBC-things-you-should-know-about-break-costs.pdf?appAction=PDF',
        WBC:
          'https://www.westpac.com.au/content/dam/public/wbc/documents/pdf/pb/WBC-things-you-should-know-about-break-costs.pdf?appAction=PDF',
      },
    },
  },
};
describe('getConfig', () => {
  it('Get empty if a proper config state is not passed', () => {
    const configuredState = { config: {} };
    expect(getConfig(configuredState)).toEqual({});
  });

  it('Get the config being passed if sent a proper state', () => {
    expect(getConfig(defaultState)).toEqual(defaultState.config);
  });
});
describe('getSecuredLendingConfig', () => {
  it('Get empty if a proper config state is not passed', () => {
    const configuredState = { config: { securedlendingservicing: {} } };
    expect(getSecuredLendingConfig(configuredState)).toEqual({});
  });

  it('Get the config being passed if sent a proper state', () => {
    expect(getSecuredLendingConfig(defaultState)).toEqual(
      defaultState.config.securedlendingservicing,
    );
  });
});
describe('getBrandId', () => {
  it('Get null if a proper config state is not passed', () => {
    const configuredState = { config: {} };
    expect(getBrandId(configuredState)).toBeNull();
  });

  it('Get the brandId if sent a proper state', () => {
    expect(getBrandId(defaultState)).toEqual(defaultState.config.brandId);
  });
});
describe('getDashboardUrl', () => {
  it('Get empty string if a proper config state is not passed', () => {
    const configuredState = { config: {} };
    expect(getDashboardUrl(configuredState)).toBe('');
  });

  it('Get WBC Dashboard url if a proper config state is passed', () => {
    expect(getDashboardUrl(defaultState)).toEqual(
      `${defaultState.config.securedlendingservicing.dashboardUrl.WBC}`,
    );
  });
});
describe('getFooterInfoSecurityUrl', () => {
  it('Get empty string if a proper config state is not passed', () => {
    const configuredState = { config: {} };
    expect(getFooterInfoSecurityUrl(configuredState)).toBe('');
  });

  it('Get WBC Footer Info Security Url if a proper config state is passed', () => {
    expect(getFooterInfoSecurityUrl(defaultState)).toEqual(
      `${defaultState.config.securedlendingservicing.footerInfoSecurityUrl.WBC}`,
    );
  });
});
describe('getConditionsOfUseUrl', () => {
  it('Get empty string if a proper config state is not passed', () => {
    const configuredState = { config: {} };
    expect(getConditionsOfUseUrl(configuredState)).toBe('');
  });

  it('Get WBC conditionsOfUse url if a proper config state is passed', () => {
    expect(getConditionsOfUseUrl(defaultState)).toEqual(
      `${defaultState.config.securedlendingservicing.conditionsOfUseUrl.WBC}`,
    );
  });
});
describe('getMessageInboxUrl', () => {
  it('Get empty string if a proper config state is not passed', () => {
    const configuredState = { config: {} };
    expect(getMessageInboxUrl(configuredState)).toBe('');
  });

  it('Get WBC MessageInbox url if a proper config state is passed', () => {
    expect(getMessageInboxUrl(defaultState)).toEqual(
      `${defaultState.config.securedlendingservicing.messageInboxUrl.WBC}`,
    );
  });
});
describe('getDirectDebitUrlInterestOnly', () => {
  it('Get empty string directDebitUrlInterestOnly if a proper config state is not passed', () => {
    const configuredState = { config: {} };
    expect(getDirectDebitUrlInterestOnly(configuredState)).toBe('');
  });

  it('Get WBC directDebitUrlInterestOnly url for interest only if a proper config state is passed', () => {
    expect(getDirectDebitUrlInterestOnly(defaultState)).toEqual(
      `${defaultState.config.securedlendingservicing.directDebitUrlInterestOnly.WBC}`,
    );
  });
});
describe('getDirectDebitUrlPrincipalInterest', () => {
  it('Get empty string getDirectDebitUrlPrincipalInterest if a proper config state is not passed', () => {
    const configuredState = { config: {} };
    expect(getDirectDebitUrlPrincipalInterest(configuredState)).toBe('');
  });

  it('Get WBC directDebitUrlPrincipalInterest url for principal interest only if a proper config state is passed', () => {
    expect(getDirectDebitUrlPrincipalInterest(defaultState)).toEqual(
      `${defaultState.config.securedlendingservicing.directDebitUrlPrincipalInterest.WBC}`,
    );
  });
});

describe('getBreakCostUrl', () => {
  it('Get empty string if a proper config state is not passed', () => {
    const configuredState = { config: {} };
    expect(getBreakCostUrl(configuredState)).toBe('');
  });

  it('Get WBC breakCost url if a proper config state is passed', () => {
    expect(getBreakCostUrl(defaultState)).toEqual(
      `${defaultState.config.securedlendingservicing.breakCostUrl.WBC}`,
    );
  });
});
describe('getSwitchingFee', () => {
  it('Get empty string if a proper config state is not passed', () => {
    const configuredState = { config: {} };
    expect(getSwitchingFee(configuredState)).toBe('');
  });

  it('Get switchingFee if a proper config state is passed', () => {
    expect(getSwitchingFee(defaultState)).toEqual(
      `${defaultState.config.securedlendingservicing.switchingFee}`,
    );
  });
});

describe('getAdditionalPaymentAmount', () => {
  it('Get empty string if a proper config state is not passed', () => {
    const configuredState = { config: {} };
    expect(getAdditionalPaymentAmount(configuredState)).toBe('');
  });

  it('Get additionalPaymentAmount if a proper config state is passed', () => {
    expect(getAdditionalPaymentAmount(defaultState)).toEqual(
      `${defaultState.config.securedlendingservicing.additionalPaymentAmount}`,
    );
  });
});

describe('getMonthlyMaintainenceFee', () => {
  it('Get empty string if a proper config state is not passed', () => {
    const configuredState = { config: {} };
    expect(getMonthlyMaintainenceFee(configuredState)).toBe('');
  });

  it('Get monthlyMaintainenceFee if a proper config state is passed', () => {
    expect(getMonthlyMaintainenceFee(defaultState)).toEqual(
      `${defaultState.config.securedlendingservicing.monthlyMaintainenceFee}`,
    );
  });
});

describe('getPackageFee', () => {
  it('Get empty string if a proper config state is not passed', () => {
    const configuredState = { config: {} };
    expect(getPackageFee(configuredState)).toBe('');
  });

  it('Get packageFee if a proper config state is passed', () => {
    expect(getPackageFee(defaultState)).toEqual(
      `${defaultState.config.securedlendingservicing.packageFee}`,
    );
  });
});

describe('getDiscountRate', () => {
  it('Get empty string if a proper config state is not passed', () => {
    const configuredState = { config: {} };
    expect(getDiscountRate(configuredState)).toBe('');
  });

  it('Get discount if a proper config state is passed', () => {
    expect(getDiscountRate(defaultState)).toEqual(
      `${defaultState.config.securedlendingservicing.discount}`,
    );
  });
});
