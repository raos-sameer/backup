import { createSelector } from 'reselect';
import { get, first, filter } from 'lodash';

export const getUiSelector = state => get(state, 'ui', null);

export const getSecuredLendingServicingSelector = createSelector(
  [getUiSelector],
  ui => get(ui, 'securedLendingServicing', null),
);

export const getAppSelector = createSelector(
  [getSecuredLendingServicingSelector],
  securedlendingservicing => get(securedlendingservicing, 'app', null),
);

export const getHeaderBackNavSelector = createSelector([getAppSelector], app =>
  get(app, 'headerBackNavigate', null),
);

export const getShowHidePopUp = createSelector([getAppSelector], app =>
  get(app, 'showHidePopUp', null),
);

export const getRepaymentType = createSelector([getAppSelector], app =>
  get(app, 'selectedRepaymentType', null),
);
export const getSelectedYearTerm = createSelector([getAppSelector], app =>
  get(app, 'selectedYearTerm', null),
);
export const getSelectedInterestRateForTerm = createSelector(
  [getAppSelector],
  app => get(app, 'selectedInterestRateForTerm', null),
);
export const getAlertBoxMessage = createSelector([getAppSelector], app =>
  get(app, 'alertBoxMessage', null),
);
export const getSelectedLoanOption = createSelector([getAppSelector], app =>
  get(app, 'selectedLoanOption', null),
);
export const getInputValueData = createSelector([getAppSelector], app =>
  get(app, 'inputAmountData', null),
);
export const getRedrawShowHidePopup = createSelector([getAppSelector], app =>
  get(app, 'redrawShowHidePopup', null),
);

export const getRedrawModalTitle = createSelector([getAppSelector], app =>
  get(app, 'redrawModalTitle', null),
);

export const getRedrawModalButtonText = createSelector([getAppSelector], app =>
  get(app, 'redrawModalButtonText', null),
);

export const getRedrawFundsAccounts = createSelector([getAppSelector], app =>
  get(app, 'redrawFundAccountsList', null),
);

export const getSelectedAccount = createSelector([getAppSelector], app =>
  get(app, 'selectedAccount', null),
);
export const getRedrawAlertBoxMessage = createSelector([getAppSelector], app =>
  get(app, 'redrawAlertBoxMessage', null),
);
export const getFixedRepaymentAmount = createSelector([getAppSelector], app =>
  get(app, 'splitFixedAmount', null),
);
export const getVariableRepaymentAmount = createSelector(
  [getAppSelector],
  app => get(app, 'splitVariableAmount', null),
);
export const getSelectedRedrawAccountLabel = createSelector(
  [getRedrawFundsAccounts, getSelectedAccount],

  (accounts, redrawAccountId) => {
    return get(first(filter(accounts, { id: redrawAccountId })), 'label', '');
  },
);

export const getFixedLoanBalance = createSelector([getAppSelector], app =>
  get(app, 'fixedLoanBalance', null),
);
export const getVariableLoanBalance = createSelector([getAppSelector], app =>
  get(app, 'variableLoanBalance', null),
);
export const getAmountValidationMessage = createSelector(
  [getAppSelector],
  app => get(app, 'amountValidationMessage', null),
);
export const getSubmitSuccess = createSelector([getAppSelector], app =>
  get(app, 'submitAction', null),
);
export const getContextsExpired = createSelector([getAppSelector], app =>
  get(app, 'isContextExpired', null),
);
export const getQuotesReponseError = createSelector([getAppSelector], app =>
  get(app, 'quotesError', null),
);
export const getRedrawError = createSelector([getAppSelector], app =>
  get(app, 'redrawResponse', null),
);
