import {
  getCurrentLoanDetails,
  getRedrawAccounts,
  isCurrentLoanDetailsLoaded,
  isMortgageQuotesLoaded,
  isRedrawAccountsLoaded,
  getFlexiIndicator,
  getDiscountedSilos,
  getDirectDebitUrl,
  getPackageIndicator,
  getContractedRepaymentDate,
  getEligibilityReasonDesc,
  getCurrentRepaymentType,
  getCanonicalCode,
  getProductName,
  getAvailableBalance,
  getSelectedMortgageQuoteDetails,
  getSelectedRedrawAccount,
  getSubmitRequestBody,
  isContextFieldsLoaded,
  getSelectedYearTermMonths,
  isContextsToBeFetched,
  isRemainingLoanTermLessThanYear,
  getSwitchedProductName,
  getSelectedDiscountRate,
} from './reviewDetailsSelector';

describe('current loan details slice selector', () => {
  it('should return default app params if state is null', () => {
    const state = null;
    expect(getCurrentLoanDetails(state)).not.toBeUndefined();
  });

  it('should not return null if current loan details slice is present', () => {
    const state = {
      entities: {
        siriusSecuredlendingservicingV1: {
          arrangements: {
            byId: {},
            allIds: [],
            isFetching: false,
            isError: false,
          },
        },
      },
    };
    expect(getCurrentLoanDetails(state)).not.toBeNull();
  });
  it('should not return arrangement id and canonical code if get context is loaded', () => {
    const state = {
      entities: {
        siriusSecuredlendingservicingV1: {
          arrangements: {
            byId: {},
            allIds: [],
            isFetching: false,
            isError: false,
          },
        },
      },
    };
    expect(getCurrentLoanDetails(state)).not.toBeNull();
  });
});
describe('Test for remaining loan term', () => {
  it('should return true if remaining loan term is 11 for IO', () => {
    const state = {
      ui: {
        securedLendingServicing: {
          app: {
            selectedRepaymentType: 'IO',
          },
        },
      },
      entities: {
        siriusSecuredlendingservicingV1: {
          arrangements: {
            byId: {
              ZiWtQhuAo: {
                currentBalance: { amount: '300000', position: 'DR' },
                availableBalance: { amount: '300000', position: 'CR' },
                variableInterestRate: '4.20',
                loanMaturityDate: '23 Jan 2052',
                repaymentType: 'IO',
                interestOnlyMaturityDate: '01 Dec 2018',
                monthlyRepayment: '1400',
                redrawIndicatorSet: false,
                remainingTermIO: '11',
                remainingTermPIF: '140',
                id: '1',
              },
            },
            allIds: ['1'],
            isFetching: true,
            isError: false,
          },
        },
      },
    };
    expect(isCurrentLoanDetailsLoaded(state)).toEqual(false);
    expect(isRemainingLoanTermLessThanYear(state)).toEqual(true);
  });

  it('should return true if remaining loan term is 11 for PIF', () => {
    const state = {
      ui: {
        securedLendingServicing: {
          app: {
            selectedRepaymentType: 'PIF',
          },
        },
      },
      entities: {
        siriusSecuredlendingservicingV1: {
          arrangements: {
            byId: {
              ZiWtQhuAo: {
                currentBalance: { amount: '300000', position: 'DR' },
                availableBalance: { amount: '300000', position: 'CR' },
                variableInterestRate: '4.20',
                loanMaturityDate: '23 Jan 2052',
                repaymentType: 'PIF',
                interestOnlyMaturityDate: '01 Dec 2018',
                monthlyRepayment: '1400',
                redrawIndicatorSet: false,
                remainingTermIO: '140',
                remainingTermPIF: '11',
                id: '1',
              },
            },
            allIds: ['1'],
            isFetching: true,
            isError: false,
          },
        },
      },
    };
    expect(isRemainingLoanTermLessThanYear(state)).toEqual(true);
  });
  it('should return false if remaining loan term is 11 for PIF', () => {
    const state = {
      ui: {
        securedLendingServicing: {
          app: {
            selectedRepaymentType: 'PIF',
          },
        },
      },
      entities: {
        siriusSecuredlendingservicingV1: {
          arrangements: {
            byId: {
              ZiWtQhuAo: {
                currentBalance: { amount: '300000', position: 'DR' },
                availableBalance: { amount: '300000', position: 'CR' },
                variableInterestRate: '4.20',
                loanMaturityDate: '23 Jan 2052',
                repaymentType: 'PIF',
                interestOnlyMaturityDate: '01 Dec 2018',
                monthlyRepayment: '1400',
                redrawIndicatorSet: false,
                remainingTermIO: '140',
                remainingTermPIF: '140',
                id: '1',
              },
            },
            allIds: ['1'],
            isFetching: true,
            isError: false,
          },
        },
      },
    };
    expect(isRemainingLoanTermLessThanYear(state)).toEqual(true);
  });
  it('should return false if ajax call is in progress', () => {
    const state = {
      entities: {
        siriusSecuredlendingservicingV1: {
          arrangements: {
            byId: {
              ZiWtQhuAo: {
                loanLimit: '1223',
                id: '1',
              },
            },
            allIds: ['1'],
            isFetching: true,
            isError: false,
          },
        },
      },
    };
    expect(isCurrentLoanDetailsLoaded(state)).toEqual(false);
  });
  it('should return false if ajax call is not in progress and there is error in response', () => {
    const state = {
      entities: {
        siriusSecuredlendingservicingV1: {
          arrangements: {
            byId: {
              ZiWtQhuAo: {
                loanLimit: '1223',
                id: '1',
              },
            },
            allIds: ['1'],
            isFetching: false,
            isError: true,
          },
        },
      },
    };
    expect(isCurrentLoanDetailsLoaded(state)).toEqual(false);
  });
});
describe('Test for isMortgageQuotesLoaded', () => {
  it('should return false if ajax call is in progress', () => {
    const state = {
      entities: {
        siriusSecuredlendingservicingV1: {
          quotes: {
            byId: {
              '6aZvBOo5': {
                isDiscountApplicable: false,
                switchedProductName: 'Fixed Rate Investment Property Loan 1',
                isDiscretionaryDiscount: false,
                discountRate: '0.20',
                interestRate: '1.22',
                yearTerm: '1',
                id: '6aZvBOo5',
              },
              'ybppcQX-D': {
                isDiscountApplicable: false,
                isDiscretionaryDiscount: false,
                switchedProductName: 'Fixed Rate Investment Property Loan 1',
                discountRate: '0.17',
                interestRate: '4.2',
                yearTerm: '2',
                id: 'ybppcQX-D',
              },
              HUFDVOAv7: {
                isDiscountApplicable: false,
                isDiscretionaryDiscount: false,
                discountRate: '0.40',
                switchedProductName: 'Fixed Rate Investment Property Loan 1',
                interestRate: '3.95',
                yearTerm: '3',
                id: 'HUFDVOAv7',
              },
              '5oWf2qazV': {
                isDiscountApplicable: false,
                isDiscretionaryDiscount: false,
                switchedProductName: 'Fixed Rate Investment Property Loan 1',
                discountRate: '0.90',
                interestRate: '5.22',
                yearTerm: '4',
                id: '5oWf2qazV',
              },
              evhaaurcr: {
                isDiscountApplicable: true,
                isDiscretionaryDiscount: true,
                discountRate: '0.20',
                interestRate: '3.22',
                yearTerm: '5',
                switchedProductName: 'Fixed Rate Investment Property Loan 1',

                id: 'evhaaurcr',
              },
            },
            allIds: [
              '6aZvBOo5',
              'ybppcQX-D',
              'HUFDVOAv7',
              '5oWf2qazV',
              'evhaaurcr',
            ],
            isFetching: true,
            isError: false,
          },
        },
      },
      ui: {
        securedLendingServicing: {
          app: {
            selectedYearTerm: '2',
          },
        },
      },
    };
    expect(isMortgageQuotesLoaded(state)).toEqual(false);
    expect(getSelectedMortgageQuoteDetails(state).discountRate).toEqual('0.17');
    expect(getSwitchedProductName(state)).toEqual(
      'Fixed Rate Investment Property Loan 1',
    );
    expect(getSelectedYearTermMonths(state)).toEqual(24);
  });

  it('should return false if ajax call is not in progress and there is error in response', () => {
    const state = {
      entities: {
        siriusSecuredlendingservicingV1: {
          quotes: {
            byId: {
              ZiWtQhuAo: {
                loanLimit: '1223',
                id: '1',
              },
            },
            allIds: ['1'],
            isFetching: false,
            isError: true,
          },
        },
      },
    };
    expect(isMortgageQuotesLoaded(state)).toEqual(false);
  });
});
describe('Test for isRedrawAccountsLoaded', () => {
  it('should return selected redraw account product name', () => {
    const state = {
      entities: {
        siriusSecuredlendingservicingV1: {
          redrawAccounts: {
            byId: {
              '605124499880': {
                productLongName: 'WestPac Choice 1',
                id: '605124499880',
              },
              '405124599880': {
                productLongName: 'WestPac Choice 2',
                id: '405124599880',
              },
              '205124699882': {
                productLongName: 'WestPac Choice 3',

                id: '205124699882',
              },
              '505124549889': {
                productLongName: 'WestPac Choice 4',

                id: '505124549889',
              },
            },
            allIds: [
              '605124499880',
              '405124599880',
              '205124699882',
              '505124549889',
            ],
            isFetching: false,
            isError: false,
          },
        },
      },
      ui: {
        securedLendingServicing: {
          app: {
            selectedAccount: '505124549889',
          },
        },
      },
    };
    expect(getSelectedRedrawAccount(state).productLongName).toEqual(
      'WestPac Choice 4',
    );
  });
  it('should return false if ajax call is in progress', () => {
    const state = {
      entities: {
        siriusSecuredlendingservicingV1: {
          redrawAccounts: {
            byId: {
              ZiWtQhuAo: {
                loanLimit: '1223',
                id: '1',
              },
            },
            allIds: ['1'],
            isFetching: true,
            isError: false,
          },
        },
      },
    };
    expect(isRedrawAccountsLoaded(state)).toEqual(false);
  });
  it('should return false if ajax call is not in progress and there is error in response', () => {
    const state = {
      entities: {
        siriusSecuredlendingservicingV1: {
          byId: {},
          allIds: [],
          isFetching: false,
          isError: true,
        },
      },
    };
    expect(isRedrawAccountsLoaded(state)).toEqual(false);
  });
});
describe('redraw accounts slice selector', () => {
  it('should return default app params if state is null', () => {
    const state = null;
    expect(getRedrawAccounts(state)).not.toBeUndefined();
  });

  it('should not return null if redraw accounts slice is present', () => {
    const state = {
      entities: {
        siriusSecuredlendingservicingV1: {
          redrawAccounts: {
            byId: {},
            allIds: [],
            isFetching: false,
            isError: false,
          },
        },
      },
    };
    expect(getRedrawAccounts(state)).not.toBeNull();
  });
  it('should return flexi as true if product name is Flexi', () => {
    const state = {
      entities: {
        siriusSecuredlendingservicingV1: {
          eligibilities: {
            byId: {
              'j-hwNz3u': {
                status: 'Eligible',
                isFlexiLoan: true,
                statusReason: {
                  code: 'CaseExists',
                  details: 'User case already exists',
                },
                id: 'j-hwNz3u',
              },
            },
            allIds: ['j-hwNz3u'],
            isFetching: false,
            isError: false,
          },
        },
      },
    };
    expect(getFlexiIndicator(state)).toEqual(true);
  });
  it('should return flexi as false if product name is not Flexi', () => {
    const state = {
      entities: {
        siriusSecuredlendingservicingV1: {
          eligibilities: {
            byId: {
              'j-hwNz3u': {
                status: 'Eligible',
                isFlexiLoan: false,
                statusReason: {
                  code: 'CaseExists',
                  details: 'User case already exists',
                },
                id: 'j-hwNz3u',
              },
            },
            allIds: ['j-hwNz3u'],
            isFetching: false,
            isError: false,
          },
        },
      },
    };
    expect(getFlexiIndicator(state)).toEqual(false);
  });
  it('should return discounted list', () => {
    const state = {
      entities: {
        siriusSecuredlendingservicingV1: {
          quotes: {
            byId: {
              '6aZvBOo5': {
                isDiscountApplicable: false,
                isDiscretionaryDiscount: false,
                discountRate: '0.20',
                interestRate: '1.22',
                yearTerm: '1',
                id: '6aZvBOo5',
              },
              'ybppcQX-D': {
                isDiscountApplicable: false,
                isDiscretionaryDiscount: false,
                discountRate: '0.17',
                interestRate: '4.2',
                yearTerm: '2',
                id: 'ybppcQX-D',
              },
              HUFDVOAv7: {
                isDiscountApplicable: false,
                isDiscretionaryDiscount: false,
                discountRate: '0.40',
                interestRate: '3.95',
                yearTerm: '3',
                id: 'HUFDVOAv7',
              },
              '5oWf2qazV': {
                isDiscountApplicable: false,
                isDiscretionaryDiscount: false,
                discountRate: '0.90',
                interestRate: '5.22',
                yearTerm: '4',
                id: '5oWf2qazV',
              },
              evhaaurcr: {
                isDiscountApplicable: true,
                isDiscretionaryDiscount: true,
                discountRate: '0.20',
                interestRate: '3.22',
                yearTerm: '5',
                id: 'evhaaurcr',
              },
            },
            allIds: [
              '6aZvBOo5',
              'ybppcQX-D',
              'HUFDVOAv7',
              '5oWf2qazV',
              'evhaaurcr',
            ],
            isFetching: false,
            isError: false,
          },
        },
      },
    };
    expect(getDiscountedSilos(state).length).toEqual(1);
  });

  it('should return getDirectDebitUrl', () => {
    const state = {
      ui: {
        securedLendingServicing: {
          app: {
            selectedRepaymentType: 'IO',
          },
        },
      },
      config: {
        brandId: 'WBC',
        securedlendingservicing: {
          directDebitUrlInterestOnly: {
            STG:
              'https://www.stgeorge.com.au/content/dam/public/wbc/documents/pdf/pb/Direct_Debit_Request_Interest_Only_Loan_Repayment.pdf',
            BOM:
              'https://www.bankofmelbourne.com.au/content/dam/public/wbc/documents/pdf/pb/Direct_Debit_Request_Interest_Only_Loan_Repayment.pdf',
            BSA:
              'https://www.banksa.com.au/content/dam/public/wbc/documents/pdf/pb/Direct_Debit_Request_Interest_Only_Loan_Repayment.pdf',
            WBC:
              'https://www.westpac.com.au/content/dam/public/wbc/documents/pdf/pb/Direct_Debit_Request_Interest_Only_Loan_Repayment.pdf',
          },
          directDebitUrlPrincipalInterest: {
            STG:
              'https://www.stgeorge.com.au/content/dam/public/wbc/documents/pdf/pb/Direct_Debit_Request_Loan_Repayment.pdf',
            BOM:
              'https://www.bankofmelbourne.com.au/content/dam/public/wbc/documents/pdf/pb/Direct_Debit_Request_Loan_Repayment.pdf',
            BSA:
              'https://www.banksa.com.au/content/dam/public/wbc/documents/pdf/pb/Direct_Debit_Request_Loan_Repayment.pdf',
            WBC:
              'https://www.westpac.com.au/content/dam/public/wbc/documents/pdf/pb/Direct_Debit_Request_Loan_Repayment.pdf',
          },
        },
      },
    };
    expect(getDirectDebitUrl(state)).toEqual(
      'https://www.westpac.com.au/content/dam/public/wbc/documents/pdf/pb/Direct_Debit_Request_Interest_Only_Loan_Repayment.pdf',
    );
  });

  it('should not return false if package type not returned from context handover api', () => {
    const state = {
      entities: {
        siriusCoreV1: {
          contexts: {
            byId: {
              'j-hwNz3u': {
                fields: [
                  {
                    fieldName: 'accountNumber',
                    value: '034017161770',
                  },
                  {
                    fieldName: 'CPC',
                    value: '9ba83148d96c4d1bac176afcff65b078',
                  },
                  {
                    fieldName: 'PackageType',
                    value: 'P',
                  },
                  {
                    fieldName: 'PackageName',
                    value: 'Premier Advantage Package',
                  },
                ],

                id: 'j-hwNz3u',
              },
            },
            allIds: ['j-hwNz3u'],
            isFetching: false,
            isError: false,
          },
        },
      },
    };
    expect(isContextFieldsLoaded(state)).toBe(true);
    expect(isContextsToBeFetched(state)).toBe(false);
    expect(getPackageIndicator(state)).toBe(true);
    expect(getCanonicalCode(state)).toBe('9ba83148d96c4d1bac176afcff65b078');
  });
  it('should not return true if package type returned from context handover api', () => {
    const state = {
      entities: {
        siriusCoreV1: {
          contexts: {
            byId: {
              'j-hwNz3u': {
                fields: [
                  {
                    fieldName: 'accountNumber',
                    value: '034017161770',
                  },
                  {
                    fieldName: 'CPC',
                    value: '9ba83148d96c4d1bac176afcff65b078',
                  },
                  {
                    fieldName: 'PackageType',
                    value: 'P',
                  },
                  {
                    fieldName: 'PackageName',
                    value: 'Premier Advantage Package',
                  },
                ],
                id: 'j-hwNz3u',
              },
            },
            allIds: ['j-hwNz3u'],
            isFetching: false,
            isError: false,
          },
        },
      },
    };
    expect(getPackageIndicator(state)).toBe(true);
  });

  it('should return contracted date if returned from current loan details', () => {
    const state = {
      entities: {
        siriusSecuredlendingservicingV1: {
          arrangements: {
            byId: {
              ZiWtQhuAo: {
                currentBalance: { amount: '300000', position: 'DR' },
                availableBalance: { amount: '300000', position: 'CR' },
                variableInterestRate: '4.20',
                loanMaturityDate: '23 Jan 2052',
                repaymentType: 'IO',
                interestOnlyMaturityDate: '01 Dec 2018',
                monthlyRepayment: '1400',
                redrawIndicatorSet: false,
                remainingTermIO: '186',
                remainingTermPIF: '140',
                productName: 'Rocket Repay Home Loan',
                loanLimit: '1223',
                nextPaymentDueDate: '23 Jan 2032',
                id: 'ZiWtQhuAo',
              },
            },
            allIds: ['ZiWtQhuAo'],
            isFetching: false,
            isError: false,
          },
        },
      },
    };
    expect(getContractedRepaymentDate(state)).toBe('23 Jan 2032');
    expect(getCurrentRepaymentType(state)).toBe('IO');
    expect(getProductName(state)).toEqual('Rocket Repay Home Loan');
    expect(getAvailableBalance(state)).toEqual('300000');
  });

  it('should return eligibility reason details for last case date', () => {
    const state = {
      entities: {
        siriusSecuredlendingservicingV1: {
          eligibilities: {
            byId: {
              'j-hwNz3u': {
                status: 'NotEligible',
                isFlexiLoan: true,
                statusReason: {
                  code: 'CaseExists',
                  details: '23 Jan 2012',
                },
                id: 'j-hwNz3u',
              },
            },
            allIds: ['j-hwNz3u'],
            isFetching: false,
            isError: false,
          },
        },
      },
    };
    expect(getEligibilityReasonDesc(state)).toBe('23 Jan 2012');
  });

  it('should return submit request body', () => {
    const state = {
      entities: {
        siriusCoreV1: {
          contexts: {
            byId: {
              'j-hwNz3u': {
                fields: [
                  {
                    fieldName: 'AccountNumber',
                    value: '034017161770',
                  },
                  {
                    fieldName: 'CPC',
                    value: '9ba83148d96c4d1bac176afcff65b078',
                  },
                  {
                    fieldName: 'PackageType',
                    value: 'P',
                  },
                  {
                    fieldName: 'PackageName',
                    value: 'Premier Advantage Package',
                  },
                ],

                id: 'j-hwNz3u',
              },
            },
            allIds: ['j-hwNz3u'],
            isFetching: false,
            isError: false,
          },
        },
        siriusSecuredlendingservicingV1: {
          arrangements: {
            byId: {
              ZiWtQhuAo: {
                currentBalance: { amount: '300000', position: 'DR' },
                availableBalance: { amount: '300000', position: 'CR' },
                variableInterestRate: '4.20',
                loanMaturityDate: '23 Jan 2052',
                repaymentType: 'IO',

                interestOnlyMaturityDate: '2030-12-16',
                monthlyRepayment: '2500.12',
                redrawIndicatorSet: true,
                loanLimit: '800000.32',
                productName: 'Rocket Repay Test',
                remainingTermIO: '135',
                remainingTermPIF: '140',
                nextPaymentDueDate: '2020-08-15',
                id: 'ZiWtQhuAo',
              },
            },
            allIds: ['ZiWtQhuAo'],
            isFetching: true,
            isError: false,
          },

          quotes: {
            byId: {
              '6aZvBOo5': {
                isDiscountApplicable: false,
                isDiscretionaryDiscount: false,
                discountRate: '0.20',
                interestRate: '1.22',
                yearTerm: '1',
                LVRAdjustment: '1.3',
                discounts: {
                  packageDiscount: '1.0',
                  extraDiscount: '0.0',
                  totalDiscount: '3.0',
                  switchedProductName: 'SwitchedProdName2',
                },
                id: '6aZvBOo5',
              },
              'ybppcQX-D': {
                isDiscountApplicable: false,
                isDiscretionaryDiscount: false,
                discountRate: '0.17',
                interestRate: '4.2',
                yearTerm: '2',
                LVRAdjustment: '1.3',
                discounts: {
                  packageDiscount: '1.0',
                  extraDiscount: '0.0',
                  totalDiscount: '3.0',
                  switchedProductName: 'SwitchedProdName2',
                },
                id: 'ybppcQX-D',
              },
              HUFDVOAv7: {
                isDiscountApplicable: false,
                isDiscretionaryDiscount: false,
                discountRate: '0.40',
                interestRate: '3.95',
                yearTerm: '3',
                LVRAdjustment: '1.3',
                discounts: {
                  packageDiscount: '1.0',
                  extraDiscount: '0.0',
                  totalDiscount: '3.0',
                  switchedProductName: 'SwitchedProdName2',
                },
                id: 'HUFDVOAv7',
              },
              '5oWf2qazV': {
                isDiscountApplicable: false,
                isDiscretionaryDiscount: false,
                discountRate: '0.90',
                interestRate: '5.22',
                yearTerm: '4',
                LVRAdjustment: '1.3',
                discounts: {
                  packageDiscount: '1.0',
                  extraDiscount: '0.0',
                  totalDiscount: '3.0',
                  switchedProductName: 'SwitchedProdName2',
                },
                id: '5oWf2qazV',
              },
              evhaaurcr: {
                isDiscountApplicable: true,
                isDiscretionaryDiscount: true,
                discountRate: '0.20',
                interestRate: '3.22',
                yearTerm: '5',
                LVRAdjustment: '1.3',
                discounts: {
                  packageDiscount: '1.0',
                  extraDiscount: '0.0',
                  totalDiscount: '3.0',
                  switchedProductName: 'SwitchedProdName2',
                },
                id: 'evhaaurcr',
              },
            },
            allIds: [
              '6aZvBOo5',
              'ybppcQX-D',
              'HUFDVOAv7',
              '5oWf2qazV',
              'evhaaurcr',
            ],
            isFetching: true,
            isError: false,
          },
          redrawAccounts: {
            byId: {
              '605124499880': {
                productLongName: 'WestPac Choice 1',
                id: '605124499880',
              },
              '405124599880': {
                productLongName: 'WestPac Choice 2',
                id: '405124599880',
              },
              '205124699882': {
                productLongName: 'WestPac Choice 3',

                id: '205124699882',
              },
              '505124549889': {
                productLongName: 'WestPac Choice 4',

                id: '505124549889',
              },
            },
            allIds: [
              '605124499880',
              '405124599880',
              '205124699882',
              '505124549889',
            ],
            isFetching: false,
            isError: false,
          },
        },
      },
      ui: {
        securedLendingServicing: {
          app: {
            headerBackNavigate: 'CHANNEL',
            showHidePopUp: false,
            selectedInterestRateForTerm: '3.95',
            selectedYearTerm: '1',
            alertBoxMessage:
              'The terms offered are within your interest only period. Switching to Principal and interest repayments may offer longer terms',
            setFixedOptionRate: '',
            setInputValueData: '',
            selectedRepaymentType: 'IO',
            setRedrawShowHidePopup: '',
            redrawShowHidePopup: true,
            setRedrawModalTitle: '',
            redrawModalTitle: 'Redraw available funds',
            setRedrawModalButtonText: '',
            redrawModalButtonText: 'Next',
            setRedrawFundsAccounts: '',
            selectedAccount: '505124549889',
            setFieldSelectValue: '',
            redrawAlertBoxMessage:
              'This transfer will only take place once you’ve submitted your request and it’s processed',
            splitFixedAmount: 2337.08,
            splitVariableAmount: '11111',
            fixedLoanBalance: 710000,
            variableLoanBalance: '1233',
            amountValidationMessage: '',
            submitAction: 'SUCCESS',
            selectedLoanOption: 'RedrawFundsOption',
          },
        },
      },
    };
    const expectedResponse = {
      loanVariationSubType: 'FixLimit',
      quoteNumber: '6aZvBOo5',
      currentLoanDetails: {
        productName: undefined,
        repaymentType: 'IO',
        loanBalance: { amount: '300000.00', position: 'DR' },
        availableFunds: { amount: '300000.00', position: 'CR' },
        loanMaturityDate: '23 Jan 2052',
        nextContractedRepaymentDate: undefined,
        interestOnlyExpiryDate: '01 Dec 2018',
      },
      switchedLoanDetails: {
        fixedRateLoan: {
          productName: undefined,
          repaymentType: 'IO',
          interestOnlyExpiryDate: '01 Dec 2018',
          loanLimit: undefined,
          loanBalance: [Object],
          availableFunds: [Object],
          fixedLoanTerm: 'P1Y',
          interestRate: '1.22',
          LVRAdjustment: '1.3',
          discounts: [Object],
          packageType: 'P',
          contractedMonthlyRepayment: '2337.08',
        },
      },
      arrangementId: '034017161770',
      canonicalProductCode: '9ba83148d96c4d1bac176afcff65b078',
      redrawArrangement: {
        arrangementId: '505124549889',
        productLongName: 'WestPac Choice 4',
      },
    };

    expect(getSubmitRequestBody(state).arrangementId).toEqual(
      expectedResponse.arrangementId,
    );
    expect(
      getSubmitRequestBody(state).currentLoanDetails.loanBalance.amount,
    ).toEqual(expectedResponse.currentLoanDetails.loanBalance.amount);
  });

  it('should  return true if context fields returns no value', () => {
    const state = {
      entities: {
        siriusCoreV1: {
          contexts: {
            byId: {
              'j-tttttt': {
                fields: [],

                id: 'j-tttttt',
              },
            },
            allIds: ['j-tttttt'],
            isFetching: false,
            isError: false,
          },
        },
      },
    };
    expect(isContextFieldsLoaded(state)).toBe(true);
  });

  it('should not return false if context service is not called', () => {
    const state = {
      entities: {
        siriusSecuredlendingservicingV1: {},
      },
    };
    expect(isContextFieldsLoaded(state)).toBe(false);
  });

  it('should not return false if context returns no value', () => {
    const state = {
      entities: {
        siriusCoreV1: {
          contexts: {
            byId: {},
            allIds: [],
            isFetching: false,
            isError: false,
          },
        },
      },
    };
    expect(isContextFieldsLoaded(state)).toBe(false);
    expect(isContextsToBeFetched(state)).toBe(true);
  });
  it('should return proper discount value for the selected year term', () => {
    const state = {
      entities: {
        siriusSecuredlendingservicingV1: {
          quotes: {
            byId: {
              'ybppcQX-D': {
                isDiscountApplicable: true,
                isDiscretionaryDiscount: false,
                discountRate: '0.17',
                interestRate: '4.2',
                yearTerm: '2',
                id: 'ybppcQX-D',
              },
            },
            allIds: ['ybppcQX-D'],
            isFetching: true,
            isError: false,
          },
        },
      },
      ui: {
        securedLendingServicing: {
          app: {
            selectedYearTerm: '2',
          },
        },
      },
    };
    expect(getSelectedDiscountRate(state)).toEqual('0.17');
  });
  it('should return empty value if year term is not selected', () => {
    const state = {
      entities: {
        siriusSecuredlendingservicingV1: {
          quotes: {
            byId: {
              'ybppcQX-D': {
                isDiscountApplicable: true,
                isDiscretionaryDiscount: false,
                discountRate: '0.17',
                interestRate: '4.2',
                yearTerm: '2',
                id: 'ybppcQX-D',
              },
            },
            allIds: ['ybppcQX-D'],
            isFetching: true,
            isError: false,
          },
        },
      },
      ui: {
        securedLendingServicing: {
          app: {
            selectedYearTerm: '3',
          },
        },
      },
    };
    expect(getSelectedDiscountRate(state)).toEqual('');
  });
});
