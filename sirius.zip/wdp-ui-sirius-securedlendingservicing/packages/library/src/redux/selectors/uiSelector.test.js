import {
  getSecuredLendingServicingSelector,
  getUiSelector,
  getAppSelector,
  getSelectedRedrawAccountLabel,
  getAmountValidationMessage,
  getSubmitSuccess,
  getContextsExpired,
  getQuotesReponseError,
  getRedrawError,
} from './uiSelector';

describe('securedlendingservicing ui slice selector', () => {
  it('should return null if state is null', () => {
    const state = null;
    expect(getUiSelector(state)).toBeNull();
  });

  it('should return null if securedlendingservicing slice is missing', () => {
    const state = {};
    expect(getSecuredLendingServicingSelector(state)).toBeNull();
  });

  it('should return null if ui slice is missing', () => {
    const state = {};
    expect(getUiSelector(state)).toBeNull();
  });

  it('should not return null if ui slice is present', () => {
    const state = {
      ui: {
        securedlendingservicing: {},
      },
    };
    expect(getUiSelector(state)).not.toBeNull();
  });
});

describe('app slice selector', () => {
  it('should return null if state is null', () => {
    const state = null;
    expect(getAppSelector(state)).toBeNull();
  });

  it('should return null if app slice is missing', () => {
    const state = {
      ui: {
        securedlendingservicing: {},
      },
    };
    expect(getAppSelector(state)).toBeNull();
  });
  it('should return  value for redraw fund label', () => {
    const state = {
      ui: {
        securedLendingServicing: {
          app: {
            redrawFundAccountsList: [
              {
                label: 'Select an account',
                id: 0,
                value: '0',
              },
              {
                label: 'WestPac Choice 1 123-415 11223344',
                id: '6aZvBOo5',
                value: '6aZvBOo5',
              },
              {
                label: 'WestPac Choice 2 123-415 11223345',
                id: 'ybppcQX-D',
                value: 'ybppcQX-D',
              },
              {
                label: 'WestPac Choice 3 123-415 11223346',
                id: 'HUFDVOAv7',
                value: 'HUFDVOAv7',
              },
              {
                label: 'WestPac Choice 4 123-415 11223344',
                id: '5oWf2qazV',
                value: '5oWf2qazV',
              },
              {
                label: 'WestPac Choice 5 123-415 11223344',
                id: 'evhaaurcr',
                value: 'evhaaurcr',
              },
            ],
            setFieldSelectValue: '',
            selectedAccount: '5oWf2qazV',
            selectedLoanOption: 'RedrawFundsOption',
          },
        },
      },
    };
    expect(getSelectedRedrawAccountLabel(state)).toEqual(
      'WestPac Choice 4 123-415 11223344',
    );
  });

  it('should return  value for validation message', () => {
    const state = {
      ui: {
        securedLendingServicing: {
          app: { amountValidationMessage: 'Please enter amount' },
        },
      },
    };
    expect(getAmountValidationMessage(state)).toEqual('Please enter amount');
  });
  it('should return  value for submit success action', () => {
    const state = {
      ui: {
        securedLendingServicing: {
          app: { submitAction: 'Please enter amount' },
        },
      },
    };
    expect(getSubmitSuccess(state)).toEqual('Please enter amount');
  });
  it('should return  value for contexts expired', () => {
    const state = {
      ui: {
        securedLendingServicing: {
          app: { isContextExpired: true },
        },
      },
    };
    expect(getContextsExpired(state)).toEqual(true);
  });

  it('should return  value for quotes response action', () => {
    const state = {
      ui: {
        securedLendingServicing: {
          app: { quotesError: 'PRICING' },
        },
      },
    };
    expect(getQuotesReponseError(state)).toEqual('PRICING');
  });

  it('should return  value for redraw response action', () => {
    const state = {
      ui: {
        securedLendingServicing: {
          app: { redrawResponse: 'Test' },
        },
      },
    };
    expect(getRedrawError(state)).toEqual('Test');
  });
});
