import { createSelector } from 'reselect';
import { get } from 'lodash';

export const getConfig = state => get(state, 'config', null);

export const getSecuredLendingConfig = createSelector([getConfig], config =>
  get(config, 'securedlendingservicing', null),
);

export const getBrandId = createSelector([getConfig], config =>
  get(config, 'brandId', null),
);

export const getDashboardUrl = createSelector(
  [getSecuredLendingConfig, getBrandId],
  (config, brandId) => {
    const dashboardUrl = get(config, 'dashboardUrl', {});
    const brandBasedDashboardURL = get(dashboardUrl, brandId, '');
    return brandBasedDashboardURL;
  },
);
export const getFooterInfoSecurityUrl = createSelector(
  [getSecuredLendingConfig, getBrandId],
  (config, brandId) => {
    const footerInfoSecurityUrl = get(config, 'footerInfoSecurityUrl', {});
    const brandBasedFooterURL = get(footerInfoSecurityUrl, brandId, '');
    return brandBasedFooterURL;
  },
);

export const getConditionsOfUseUrl = createSelector(
  [getSecuredLendingConfig, getBrandId],
  (config, brandId) => {
    const urlConditionsUse = get(config, 'conditionsOfUseUrl', {});
    const brandConditionsUseUrl = get(urlConditionsUse, brandId, '');
    return brandConditionsUseUrl;
  },
);

export const getMessageInboxUrl = createSelector(
  [getSecuredLendingConfig, getBrandId],
  (config, brandId) => {
    const messageInboxUrl = get(config, 'messageInboxUrl', {});
    const brandMessageInboxUrl = get(messageInboxUrl, brandId, '');
    return brandMessageInboxUrl;
  },
);

export const getDirectDebitUrlInterestOnly = createSelector(
  [getSecuredLendingConfig, getBrandId],
  (config, brandId) => {
    const urlDebitInterestUrl = get(config, 'directDebitUrlInterestOnly', {});
    const urlBrandDebitInterestUrl = get(urlDebitInterestUrl, brandId, '');
    return urlBrandDebitInterestUrl;
  },
);

export const getDirectDebitUrlPrincipalInterest = createSelector(
  [getSecuredLendingConfig, getBrandId],
  (config, brandId) => {
    const urlDebitPrincipalUrl = get(
      config,
      'directDebitUrlPrincipalInterest',
      {},
    );
    const urlBrandDebitPrincipalUrl = get(urlDebitPrincipalUrl, brandId, '');
    return urlBrandDebitPrincipalUrl;
  },
);

export const getBreakCostUrl = createSelector(
  [getSecuredLendingConfig, getBrandId],
  (config, brandId) => {
    const urlBreakCost = get(config, 'breakCostUrl', {});
    const breakCostBrandUrl = get(urlBreakCost, brandId, '');
    return breakCostBrandUrl;
  },
);

export const getSwitchingFee = createSelector(
  [getSecuredLendingConfig],
  config => {
    const switchingFee = get(config, 'switchingFee', '');
    return switchingFee;
  },
);

export const getAdditionalPaymentAmount = createSelector(
  [getSecuredLendingConfig],
  config => {
    const additionalPaymentAmount = get(config, 'additionalPaymentAmount', '');
    return additionalPaymentAmount;
  },
);

export const getMonthlyMaintainenceFee = createSelector(
  [getSecuredLendingConfig],
  config => {
    const monthlyMaintainenceFee = get(config, 'monthlyMaintainenceFee', '');
    return monthlyMaintainenceFee;
  },
);

export const getDiscountRate = createSelector(
  [getSecuredLendingConfig],
  config => {
    const discountRate = get(config, 'discount', '');
    return discountRate;
  },
);

export const getPackageFee = createSelector(
  [getSecuredLendingConfig],
  config => {
    const packageFee = get(config, 'packageFee', '');
    return packageFee;
  },
);
