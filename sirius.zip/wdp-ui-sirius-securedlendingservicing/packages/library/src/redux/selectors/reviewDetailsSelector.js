import { createSelector } from 'reselect';
import {
  getAllContexts,
  isContextsError as getContextsError,
  isContextsFetching as getContextsFetching,
} from '@wdpui/redux-exp-sirius-core-v1/selectors';

import {
  isArrangementsFetching as getArrangementsFetching,
  getAllArrangements,
  isQuotesFetching as getMortgageQuotesFetching,
  isQuotesError as getMortgageQuotesError,
  getAllQuotes,
  getAllRedrawAccounts,
  isRedrawAccountsFetching as getRedrawAccountsFetching,
  getAllEligibilities,
} from '@wdpui/redux-exp-sirius-securedlendingservicing-v1/selectors';

import {
  get,
  last,
  sortBy,
  filter,
  toNumber,
  isEmpty,
  first,
  multiply,
} from 'lodash';
import {
  getRepaymentType,
  getSelectedYearTerm,
  getSelectedAccount,
  getVariableRepaymentAmount,
  getVariableLoanBalance,
  getFixedRepaymentAmount,
  getFixedLoanBalance,
  getSelectedLoanOption,
} from './uiSelector';
import {
  getDirectDebitUrlInterestOnly,
  getDirectDebitUrlPrincipalInterest,
} from './configSelector';
import { getLoanVariationType } from '../../helpers/loanOptionsHelper';
import {
  SPLIT_LOAN_OPTION,
  FIXED_LOAN_OPTION,
  REDRAW_LOAN_OPTION,
} from '../../helpers/constants';

export const getCurrentLoanDetails = createSelector(
  [getAllArrangements],
  currentLoanDetails => {
    return (
      first(currentLoanDetails) || {
        currentBalance: { amount: '', position: '' },
        availableBalance: { amount: '', position: '' },
        variableInterestRate: '',
        loanMaturityDate: '',
        repaymentType: '',
        interestOnlyMaturityDate: '',
        monthlyRepayment: '',
        redrawIndicatorSet: true,
        loanLimit: '',
        productName: '',
        remainingTermPIF: '',
        remainingTermIO: '',
        nextPaymentDueDate: '',
      }
    );
  },
);

export const getAvailableBalance = createSelector(
  [getCurrentLoanDetails],
  currentLoanDetails => {
    return currentLoanDetails.availableBalance.amount;
  },
);

export const isCurrentLoanDetailsLoaded = createSelector(
  [getArrangementsFetching, getAllArrangements],
  (isCurrentLoanDetailsFetching, isCurrentLoanDetailsError) =>
    (!isCurrentLoanDetailsFetching && !isCurrentLoanDetailsError) || false,
);

export const isMortgageQuotesLoaded = createSelector(
  [getMortgageQuotesFetching, getMortgageQuotesError],
  (isMortgageQuotesFetching, isMortgageQuotesError) =>
    (!isMortgageQuotesFetching && !isMortgageQuotesError) || false,
);

export const getRedrawAccounts = createSelector(
  [getAllRedrawAccounts],
  (accounts = []) => sortBy(accounts, ['accountName']),
);

export const getMortgageQuotes = createSelector([getAllQuotes], allSilos => {
  return filter(allSilos, 'yearTerm');
});

export const getDiscountedSilos = createSelector([getAllQuotes], allSilos => {
  return filter(allSilos, 'isDiscountApplicable');
});
export const isRedrawAccountsLoaded = createSelector(
  [getRedrawAccountsFetching, getAllRedrawAccounts],
  (isRedrawAccountsFetching, isRedrawAccountsError) =>
    (!isRedrawAccountsFetching && !isRedrawAccountsError) || false,
);

export const getDirectDebitUrl = createSelector(
  [
    getRepaymentType,
    getDirectDebitUrlInterestOnly,
    getDirectDebitUrlPrincipalInterest,
  ],
  (repaymentType, interestOnlyUrl, principalInterestUrl) => {
    const debitUrl =
      repaymentType === 'IO' ? interestOnlyUrl : principalInterestUrl;
    return debitUrl;
  },
);

export const getContextData = createSelector([getAllContexts], contexts => {
  const fields = get(last(contexts), 'fields', []);

  const modifiedContextsData = fields
    ? {
        arrangementId: get(
          first(filter(fields, { fieldName: 'AccountNumber' })),
          'value',
          '',
        ),
        canonicalProductCode: get(
          first(filter(fields, { fieldName: 'CPC' })),
          'value',
          '',
        ),
        packageType: get(
          first(filter(fields, { fieldName: 'PackageType' })),
          'value',
          '',
        ),
        packageName: get(
          first(filter(fields, { fieldName: 'PackageName' })),
          'value',
          '',
        ),
      }
    : {
        arrangementId: '',
        packageName: '',
        packageType: '',
        canonicalProductCode: '',
      };
  return modifiedContextsData;
});

export const getPackageIndicator = createSelector(
  [getContextData],
  contextData => {
    return !isEmpty(contextData.packageType);
  },
);

export const getCurrentRepaymentType = createSelector(
  [getCurrentLoanDetails],
  loanDetails => get(loanDetails, 'repaymentType', ''),
);

export const getArrangementId = createSelector([getContextData], contextData =>
  get(contextData, 'arrangementId', ''),
);
export const getCanonicalCode = createSelector([getContextData], contextData =>
  get(contextData, 'canonicalProductCode', ''),
);
export const getCustomersEligibility = createSelector(
  [getAllEligibilities],
  eligibilities => {
    return (
      last(eligibilities) || [
        {
          status: '',
          isFlexiLoan: false,
          statusReason: { code: '', details: '' },
        },
      ]
    );
  },
);
export const getFlexiIndicator = createSelector(
  [getCustomersEligibility],
  eligibilityData => {
    return eligibilityData.isFlexiLoan;
  },
);

export const isRemainingLoanTermLessThanYear = createSelector(
  [getCurrentLoanDetails, getRepaymentType],
  (loanDetails, repaymentType) => {
    const remainingTermIO = get(loanDetails, 'remainingTermIO', '');
    const remainingTermPIF = get(loanDetails, 'remainingTermPIF', '');
    const remainingTerm =
      repaymentType === 'PIF' ? remainingTermPIF : remainingTermIO;
    return toNumber(remainingTerm) < 12;
  },
);

export const isEligibilityError = createSelector(
  [getCustomersEligibility],
  customersEligibility => {
    return !!(
      customersEligibility &&
      customersEligibility.statusReason &&
      customersEligibility.status === 'NotEligible' &&
      !isEmpty(customersEligibility.statusReason.code) &&
      customersEligibility.statusReason.code !== 'CaseExists'
    );
  },
);

export const isEligibilityCaseExistsError = createSelector(
  [getCustomersEligibility],
  customersEligibility => {
    return !!(
      customersEligibility &&
      customersEligibility.status === 'NotEligible' &&
      customersEligibility.statusReason &&
      customersEligibility.statusReason.code === 'CaseExists'
    );
  },
);

export const getEligibilityReasonDesc = createSelector(
  [getCustomersEligibility],
  customersEligibility => {
    const statusReason = get(customersEligibility, 'statusReason', '');
    return statusReason.details;
  },
);

export const getContractedRepaymentDate = createSelector(
  [getCurrentLoanDetails],
  loanDetails => {
    const dueDate = get(loanDetails, 'nextPaymentDueDate', null);
    return dueDate;
  },
);
export const getProductName = createSelector(
  [getCurrentLoanDetails],
  currentLoanDetails => get(currentLoanDetails, 'productName', ''),
);
export const getSubmitDetails = createSelector(
  [getAllArrangements],
  submitDetails => {
    return (
      last(submitDetails) || [
        {
          caseId: '',
          caseReferenceNumber: '',
        },
      ]
    );
  },
);

export const getSelectedMortgageQuoteDetails = createSelector(
  [getMortgageQuotes, getSelectedYearTerm],
  (quotes, selectedTerm) => {
    const selectedQuote = first(filter(quotes, { yearTerm: selectedTerm }));

    return selectedQuote;
  },
);
export const getSwitchedProductName = createSelector(
  [getSelectedMortgageQuoteDetails],
  quote => get(quote, 'switchedProductName', ''),
);

export const getSelectedYearTermMonths = createSelector(
  [getSelectedYearTerm],
  selectedTerm => {
    return multiply(selectedTerm, 12);
  },
);

export const isContextFieldsLoaded = createSelector(
  [getAllContexts],
  contexts => {
    if (contexts && contexts.length > 0) {
      const fields = get(last(contexts), 'fields', null);
      if (fields) return true;
    }
    return false;
  },
);

export const isContextsToBeFetched = createSelector(
  [isContextFieldsLoaded, getContextsError, getContextsFetching],
  (isContextLoaded, isContextsError, isContextFetching) => {
    return !isContextLoaded && !isContextsError && !isContextFetching;
  },
);

export const getSelectedRedrawAccount = createSelector(
  [getRedrawAccounts, getSelectedAccount],

  (accounts, redrawAccountId) => {
    const selectedAcct = first(filter(accounts, { id: redrawAccountId }));
    return selectedAcct;
  },
);
export const getSubmitRequestBody = createSelector(
  [
    getSelectedYearTerm,
    getVariableRepaymentAmount,
    getVariableLoanBalance,
    getFixedRepaymentAmount,
    getFixedLoanBalance,
    getSelectedLoanOption,
    getContextData,
    getCurrentLoanDetails,
    getRepaymentType,
    getSelectedMortgageQuoteDetails,
    getSelectedRedrawAccount,
  ],
  (
    selectedYearTerm,
    variableRateLoanRepayment,
    variableRateBalance,
    fixedLoanRepayment,
    fixedLoanBalance,
    selectedLoanType,
    contextDetails,
    currentLoanDetails,
    selectedRepaymentType,
    selectedQuoteDetails,
    selectedRedrawAccount,
  ) => {
    const loanVariationSubType = getLoanVariationType(selectedLoanType);
    const { arrangementId, canonicalProductCode, packageType } = contextDetails;

    const {
      LVRAdjustment,
      discountRate,
      discounts,
      id: quoteNumber,
      interestRate,
      switchedProductName,
    } = selectedQuoteDetails;
    const {
      productName,
      repaymentType,
      currentBalance: { amount: currBalance, position: currPosition },
      availableBalance: { amount: availCurrBalance, position: availPosition },
      nextPaymentDueDate,
      loanMaturityDate,
      interestOnlyMaturityDate,
      loanLimit,
    } = currentLoanDetails;
    let availBalance = '0';
    // In case of available balance is less than 1000 or 0
    // avail balance stays and doesnt reset
    if (selectedLoanType === FIXED_LOAN_OPTION) {
      availBalance = availCurrBalance;
    }
    const bodyParams = {
      loanVariationSubType,
      quoteNumber,
      currentLoanDetails: {
        productName,
        repaymentType,
        loanBalance: {
          amount: Number.parseFloat(currBalance).toFixed(2),
          position: currPosition,
        },
        availableFunds: {
          amount: Number.parseFloat(availCurrBalance).toFixed(2),
          position: availPosition,
        },
        loanMaturityDate,
        nextContractedRepaymentDate: nextPaymentDueDate,
        interestOnlyExpiryDate: interestOnlyMaturityDate,
      },
      switchedLoanDetails: {
        fixedRateLoan: {
          productName: switchedProductName,
          repaymentType: selectedRepaymentType,
          interestOnlyExpiryDate: interestOnlyMaturityDate,
          loanLimit,
          loanBalance: {
            amount: Number.parseFloat(fixedLoanBalance).toFixed(2),
            position: 'DR',
          },
          availableFunds: {
            amount: Number.parseFloat(availBalance).toFixed(2),
            position: 'DR',
          },
          fixedLoanTerm: `P${selectedYearTerm}Y`,
          interestRate,
          LVRAdjustment,
          totalAdjustment: discountRate,
          discounts,
          contractedMonthlyRepayment: Number.parseFloat(
            fixedLoanRepayment,
          ).toFixed(2),
        },
      },

      arrangementId,
      canonicalProductCode,
    };
    if (packageType) {
      bodyParams.switchedLoanDetails.fixedRateLoan.packageType = packageType;
    }
    if (selectedLoanType === SPLIT_LOAN_OPTION) {
      bodyParams.switchedLoanDetails.variableRateLoan = {
        loanBalance: {
          amount: Number.parseFloat(variableRateBalance).toFixed(2),
          position: 'DR',
        },
        contractedMonthlyRepayment: Number.parseFloat(
          variableRateLoanRepayment,
        ).toFixed(2),
      };
    }
    if (selectedLoanType === REDRAW_LOAN_OPTION) {
      const { productLongName, id } = selectedRedrawAccount;
      bodyParams.redrawArrangement = {
        arrangementId: id,
        productLongName,
      };
    }
    return bodyParams;
  },
);

export const getSelectedDiscountRate = createSelector(
  [getSelectedMortgageQuoteDetails],
  selectedQuote => {
    const selectedDiscountRate =
      selectedQuote && selectedQuote.isDiscountApplicable
        ? selectedQuote.discountRate
        : '';
    return selectedDiscountRate;
  },
);
export const getQuotesFetchingError = createSelector(
  [getAllQuotes],
  quotesResponse => {
    const errors = get(quotesResponse, 'errors', null);
    return errors;
  },
);
