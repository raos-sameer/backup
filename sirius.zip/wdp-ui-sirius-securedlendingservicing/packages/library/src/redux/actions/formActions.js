import { createActions } from 'redux-actions';

export const formActions = createActions({
  getContexts: props => ({
    props,
  }),
  getCustomerEligibility: props => ({
    props,
  }),
  getCurrentLoanDetails: props => ({
    props,
  }),
  getMortgageQuotes: props => ({
    props,
  }),
  getRedrawAccounts: props => ({
    props,
  }),
  submitDetails: props => ({
    props,
  }),
});
