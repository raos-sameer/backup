import configureStore from 'redux-mock-store';
import { formActions } from './formActions';

const mockStore = configureStore();
const store = mockStore();

describe('formActions', () => {
  beforeEach(() => {
    // Runs before each test in the suite
    store.clearActions();
  });

  it('Dispatches the correct action and payload for getContexts', () => {
    const expectedActions = [
      {
        payload: {
          props: {
            ctxhandover: [
              { canonicalProductCode: '12333', arrangementId: '1112333' },
            ],
          },
        },
        type: 'getContexts',
      },
    ];

    store.dispatch(
      formActions.getContexts({
        ctxhandover: [
          { canonicalProductCode: '12333', arrangementId: '1112333' },
        ],
      }),
    );
    expect(store.getActions()).toEqual(expectedActions);
  });
});
