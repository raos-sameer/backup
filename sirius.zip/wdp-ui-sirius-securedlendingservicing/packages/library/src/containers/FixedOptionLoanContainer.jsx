import React from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { compose } from 'recompose';
import { withTracking } from '@wdpui/common-analytics';
import { isEmpty } from 'lodash';
import {
  isRedrawAccountsError as getRedrawAccountsError,
  isRedrawAccountsFetching as getRedrawAccountsFetching,
} from '@wdpui/redux-exp-sirius-securedlendingservicing-v1/selectors';

import { formActions } from '../redux/actions/formActions';

import { actions as appActions } from '../redux/modules/app.module';
import { FixedOptionLoanPage } from '../components';
import { scrollWindow } from '../helpers/windowFunctionsHelper';

import {
  getCurrentLoanDetails,
  getSelectedLoanOption,
  getSelectedYearTerm,
  getSelectedInterestRateForTerm,
  getInputValueData,
  getShowHidePopUp,
  getRedrawShowHidePopup,
  getRedrawModalTitle,
  getRedrawModalButtonText,
  getRedrawAlertBoxMessage,
  getRedrawAccounts,
  getSelectedAccount,
  getDashboardUrl,
  getRedrawFundsAccounts,
  getFixedRepaymentAmount,
  getVariableRepaymentAmount,
  getFixedLoanBalance,
  getVariableLoanBalance,
  getRepaymentType,
  getPackageIndicator,
  getSwitchingFee,
  getMonthlyMaintainenceFee,
  getAmountValidationMessage,
  getProductName,
  getSwitchedProductName,
  getRedrawError,
} from '../redux/selectors';
import { getAnalyticsTags } from '../helpers/analyticsHelper';
import {
  getFixedCompCurrentBalance,
  getInterestOnlyRepaymentAmount,
  getVariableCompCurrentBalanceIO,
  getVariableCompCurrentBalancePIF,
  getPMT,
  getSummation,
} from '../helpers/repaymentCalcHelper';
import { validateAmount, isAvailableFunds } from '../helpers/loanOptionsHelper';
import {
  getDisplayAccountNumber,
  getDisplayBSBNumber,
} from '../helpers/reviewPageHelper';

import {
  REDRAW_LOAN_OPTION,
  CLEAR_LOAN_OPTION,
  FIXED_LOAN_OPTION,
} from '../helpers/constants';

class FixedOptionLoanContainer extends React.Component {
  static propTypes = {
    channelDashboardUrl: PropTypes.string.isRequired,
    redrawResponse: PropTypes.string.isRequired,
    setFixedOptionRate: PropTypes.func.isRequired,
    setInputValueData: PropTypes.func.isRequired,
    setSplitVariableAmount: PropTypes.func.isRequired,
    setSplitFixedAmount: PropTypes.func.isRequired,
    setShowHidePopup: PropTypes.func.isRequired,
    showHidePopUp: PropTypes.bool,
    selectedLoanOption: PropTypes.string,
    yearTermSelected: PropTypes.string,
    interestRateOptionSelected: PropTypes.string,
    inputAmountData: PropTypes.number,
    history: PropTypes.shape({
      push: PropTypes.func.isRequired,
    }).isRequired,
    currentLoanDetails: PropTypes.shape({
      currentBalance: PropTypes.string.isRequired,
      availableBalance: PropTypes.string.isRequired,
      variableInterestRate: PropTypes.string.isRequired,
      loanMaturityDate: PropTypes.string.isRequired,
      repaymentType: PropTypes.string.isRequired,
      interestOnlyMaturityDate: PropTypes.string.isRequired,
      monthlyRepayment: PropTypes.string.isRequired,
      redrawIndicatorSet: PropTypes.bool.isRequired,
      remainingTermIO: PropTypes.bool.isRequired,
      remainingTermPIF: PropTypes.bool.isRequired,
    }).isRequired,
    switchedProductName: PropTypes.string.isRequired,
    redrawShowHidePopup: PropTypes.bool,
    setRedrawShowHidePopup: PropTypes.func,

    redrawModalTitle: PropTypes.string,
    setRedrawModalTitle: PropTypes.func.isRequired,

    redrawModalButtonText: PropTypes.string,
    setRedrawModalButtonText: PropTypes.func.isRequired,

    redrawAlertBoxMessage: PropTypes.string,
    setRedrawAlertMessage: PropTypes.func.isRequired,

    redrawFundAccountsList: PropTypes.arrayOf(PropTypes.shape({})),
    redrawFundAccounts: PropTypes.arrayOf(PropTypes.shape({})),
    setRedrawFundsAccounts: PropTypes.func.isRequired,

    setFieldSelectValue: PropTypes.func.isRequired,
    selectedAccount: PropTypes.string,
    updateHeaderBackNavigation: PropTypes.func.isRequired,
    fetchRedrawAccounts: PropTypes.func,
    isRedrawAccountsFetching: PropTypes.bool.isRequired,
    isRedrawAccountsError: PropTypes.bool.isRequired,
    splitVariableAmount: PropTypes.string.isRequired,
    splitFixedAmount: PropTypes.number.isRequired,
    setVariableLoanBalance: PropTypes.func.isRequired,
    setFixedLoanBalance: PropTypes.func.isRequired,
    variableLoanBalance: PropTypes.string.isRequired,
    fixedLoanBalance: PropTypes.number.isRequired,
    selectedRepaymentType: PropTypes.string.isRequired,
    isPackageCustomer: PropTypes.bool.isRequired,
    switchFee: PropTypes.string.isRequired,
    monthlyMaintainence: PropTypes.string.isRequired,
    setAmountValidationMessage: PropTypes.func.isRequired,
    amountValidationMessage: PropTypes.func.isRequired,
    productName: PropTypes.string.isRequired,
  };

  static defaultProps = {
    fetchRedrawAccounts: () => {},
    showHidePopUp: false,
    selectedLoanOption: '',
    yearTermSelected: '',
    interestRateOptionSelected: '',
    inputAmountData: ' ',
    redrawShowHidePopup: false,
    redrawModalTitle: '',
    redrawModalButtonText: '',
    redrawAlertBoxMessage: '',
    selectedAccount: '',
    redrawFundAccountsList: [],
    setRedrawShowHidePopup: false,
    redrawFundAccounts: [],
  };

  componentDidMount() {
    const { updateHeaderBackNavigation } = this.props;
    scrollWindow();
    updateHeaderBackNavigation('PREVIOUS');
  }

  componentDidUpdate() {
    const {
      redrawFundAccounts,
      setRedrawModalTitle,
      selectedLoanOption,
      setRedrawModalButtonText,
      currentLoanDetails: { redrawIndicatorSet },
    } = this.props;
    let TitleMsg = '';
    let RedrawModalText = '';
    if (!redrawIndicatorSet) {
      TitleMsg = 'We need to know more to continue with your request';
      RedrawModalText = 'Call us';
    } else if (
      selectedLoanOption === REDRAW_LOAN_OPTION &&
      redrawFundAccounts.length > 0 &&
      redrawIndicatorSet
    ) {
      TitleMsg = 'Redraw available funds';
      RedrawModalText = 'Next';
    } else if (
      selectedLoanOption === REDRAW_LOAN_OPTION &&
      redrawFundAccounts.length === 0 &&
      redrawIndicatorSet
    ) {
      TitleMsg = 'Redraw available funds';
      RedrawModalText = 'Exit form';
    }
    if (
      selectedLoanOption === REDRAW_LOAN_OPTION ||
      selectedLoanOption === FIXED_LOAN_OPTION
    ) {
      setRedrawModalTitle(TitleMsg);
      setRedrawModalButtonText(RedrawModalText);
    }
    if (selectedLoanOption === REDRAW_LOAN_OPTION) {
      this.showAlertMessage();
      this.loadRedrawAccounts();
    }
  }

  loadRedrawAccounts = () => {
    const {
      redrawFundAccounts,
      isRedrawAccountsError,
      isRedrawAccountsFetching,
      fetchRedrawAccounts,
      redrawResponse,
      currentLoanDetails: { redrawIndicatorSet },
    } = this.props;

    if (
      isEmpty(redrawFundAccounts) &&
      !isRedrawAccountsError &&
      !isRedrawAccountsFetching &&
      redrawIndicatorSet &&
      !redrawResponse
    ) {
      fetchRedrawAccounts();
    }
  };

  showAlertMessage = () => {
    const { setRedrawAlertMessage, redrawAlertBoxMessage } = this.props;
    if (isEmpty(redrawAlertBoxMessage)) {
      const redrawTransferMsg =
        'This transfer will only take place once you’ve submitted your request and it’s processed';
      setRedrawAlertMessage(redrawTransferMsg);
    }
  };

  backToChannel = () => {
    const { channelDashboardUrl } = this.props;
    window.location.replace(channelDashboardUrl);
  };

  onFixedRateRadioChange = event => {
    const loanOptionSelected = event.target.value;
    const {
      setFixedOptionRate,
      setSplitFixedAmount,
      setFixedLoanBalance,
      interestRateOptionSelected,
      currentLoanDetails: {
        currentBalance: { amount: currBalance },
        availableBalance: { amount: availBalance },
        remainingTermPIF,
      },
      isPackageCustomer,
      selectedRepaymentType,
      switchFee,
      monthlyMaintainence,
    } = this.props;

    if (
      loanOptionSelected === REDRAW_LOAN_OPTION ||
      loanOptionSelected === FIXED_LOAN_OPTION ||
      loanOptionSelected === CLEAR_LOAN_OPTION
    ) {
      const fixedLoanBalance = getFixedCompCurrentBalance(
        loanOptionSelected,
        availBalance,
        currBalance,
        '',
      );

      let fixedAmt = 0;
      if (selectedRepaymentType === 'IO') {
        fixedAmt = getInterestOnlyRepaymentAmount(
          fixedLoanBalance,
          switchFee,
          monthlyMaintainence,
          interestRateOptionSelected,
          isPackageCustomer,
        );
      } else if (selectedRepaymentType === 'PIF') {
        fixedAmt = getPMT(
          interestRateOptionSelected,
          remainingTermPIF,
          fixedLoanBalance,
          0,
          isPackageCustomer,
          switchFee,
          monthlyMaintainence,
        );
      }
      setSplitFixedAmount(fixedAmt);
      setFixedLoanBalance(fixedLoanBalance);
    } else {
      setSplitFixedAmount('');
      setFixedLoanBalance('');
    }

    setFixedOptionRate(loanOptionSelected);
  };

  navigateNext = () => {
    const {
      history,
      selectedLoanOption,
      setRedrawFundsAccounts,
      redrawFundAccounts,
      redrawShowHidePopup,
      selectedAccount,
      setFieldSelectValue,
      currentLoanDetails: { redrawIndicatorSet, availableBalance },
    } = this.props;

    if (
      selectedLoanOption === FIXED_LOAN_OPTION &&
      !redrawIndicatorSet &&
      !redrawShowHidePopup
    ) {
      this.showRedrawFundsPopup();
    } else if (
      selectedLoanOption === REDRAW_LOAN_OPTION &&
      !redrawShowHidePopup
    ) {
      const selectOptionOj = { label: 'Select an account', id: 0, value: '0' };
      if (!redrawShowHidePopup && redrawFundAccounts.length === 0) {
        this.showRedrawFundsPopup();
      } else if (redrawFundAccounts && redrawFundAccounts.length > 0) {
        const accountsList = redrawFundAccounts.map(obj => {
          const rObj = {};
          const BSB = getDisplayBSBNumber(obj.id);
          const accountNumber = getDisplayAccountNumber(obj.id);
          rObj.label = `${obj.productLongName} ${BSB} ${accountNumber}`;
          rObj.id = obj.id;
          rObj.value = `${obj.id}`;
          return rObj;
        });
        if (redrawFundAccounts.length > 1) {
          accountsList.unshift(selectOptionOj);
        } else {
          setFieldSelectValue(accountsList[0].value);
        }
        setRedrawFundsAccounts(accountsList);
        this.showRedrawFundsPopup();
      }
    } else if (redrawShowHidePopup && redrawFundAccounts.length > 0) {
      if (isEmpty(selectedAccount) || selectedAccount === '0') {
        setFieldSelectValue('0');
      } else {
        history.push('/securedlendingservicing/review');
      }
    } else if (
      selectedLoanOption !== FIXED_LOAN_OPTION ||
      !isAvailableFunds(availableBalance)
    ) {
      history.push('/securedlendingservicing/review');
    }
  };

  showReviewDetailsPopup = () => {
    const { setShowHidePopup } = this.props;
    setShowHidePopup(true);
  };

  hideReviewDetailsPopup = () => {
    const { setShowHidePopup } = this.props;
    setShowHidePopup(false);
  };

  onSplitAmountEnter = event => {
    const {
      setInputValueData,
      inputAmountData,
      setAmountValidationMessage,
      setSplitFixedAmount,
      setSplitVariableAmount,
    } = this.props;
    setSplitFixedAmount(''); // Resetting back
    setSplitVariableAmount('');
    if (inputAmountData) {
      setAmountValidationMessage('');
    }
    setInputValueData(event.target.value);
  };

  onClickCalculateRepayments = () => {
    const {
      setSplitVariableAmount,
      setVariableLoanBalance,
      setSplitFixedAmount,
      setFixedLoanBalance,
      inputAmountData,
      interestRateOptionSelected,
      currentLoanDetails: {
        currentBalance: { amount: currBalance },
        availableBalance: { amount: availBalance },
        variableInterestRate,
        remainingTermPIF,
        repaymentType,
      },
      isPackageCustomer,
      selectedRepaymentType,
      switchFee,
      monthlyMaintainence,
      setAmountValidationMessage,
    } = this.props;
    if (!inputAmountData) {
      setAmountValidationMessage('Please enter an amount.');
    } else {
      setAmountValidationMessage('');

      let fixedRepayment = 0;
      let variableRepayment = 0;
      let variableCompCurrentBalance = 0;
      if (repaymentType === 'IO') {
        variableCompCurrentBalance = getVariableCompCurrentBalanceIO(
          currBalance,
          inputAmountData,
        );

        variableRepayment = getInterestOnlyRepaymentAmount(
          variableCompCurrentBalance,
          0,
          monthlyMaintainence,
          variableInterestRate,
          isPackageCustomer,
        );
      } else if (repaymentType === 'PIF') {
        variableCompCurrentBalance = getVariableCompCurrentBalancePIF(
          currBalance,
          availBalance,
          inputAmountData,
        );

        variableRepayment = getPMT(
          variableInterestRate,
          remainingTermPIF,
          variableCompCurrentBalance,
          0,
          isPackageCustomer,
          0,
          monthlyMaintainence,
        );
      }
      if (selectedRepaymentType === 'IO') {
        fixedRepayment = getInterestOnlyRepaymentAmount(
          inputAmountData,
          switchFee,
          monthlyMaintainence,
          interestRateOptionSelected,
          isPackageCustomer,
        );
      } else if (selectedRepaymentType === 'PIF') {
        fixedRepayment = getPMT(
          interestRateOptionSelected,
          remainingTermPIF,
          inputAmountData,
          0,
          isPackageCustomer,
          switchFee,
          monthlyMaintainence,
        );
      }
      if (validateAmount(inputAmountData, currBalance)) {
        setSplitFixedAmount(fixedRepayment);
        setSplitVariableAmount(variableRepayment);
        setFixedLoanBalance(inputAmountData);
        setVariableLoanBalance(variableCompCurrentBalance);
      }
    }
  };

  showRedrawFundsPopup = () => {
    const { setRedrawShowHidePopup } = this.props;
    scrollWindow();
    setRedrawShowHidePopup(true);
  };

  hideRedrawFundsPopup = () => {
    const { setRedrawShowHidePopup } = this.props;
    setRedrawShowHidePopup(false);
  };

  selectAccountToTransfer = event => {
    const { setFieldSelectValue } = this.props;
    setFieldSelectValue(event.value);
  };

  render() {
    const {
      selectedLoanOption,
      showHidePopUp,
      inputAmountData,
      yearTermSelected,
      interestRateOptionSelected,
      redrawShowHidePopup,
      redrawModalTitle,
      redrawModalButtonText,
      redrawAlertBoxMessage,
      redrawFundAccountsList,
      selectedAccount,
      currentLoanDetails: {
        currentBalance: { amount: currBalance },
        availableBalance: { amount: availBalance },
        variableInterestRate,
        loanMaturityDate,
        interestOnlyMaturityDate,
        monthlyRepayment,
        repaymentType,
        redrawIndicatorSet,
      },
      switchedProductName,
      splitVariableAmount,
      splitFixedAmount,
      fixedLoanBalance,
      variableLoanBalance,
      isPackageCustomer,
      amountValidationMessage,
      productName,
      monthlyMaintainence,
    } = this.props;
    const totalIndicativeRepayment = getSummation(
      splitVariableAmount,
      splitFixedAmount,
    );
    return (
      <div>
        <FixedOptionLoanPage
          onFixedRateRadioChange={this.onFixedRateRadioChange}
          isPackageCustomer={isPackageCustomer}
          onSplitAmountEnter={this.onSplitAmountEnter}
          onClickCalculateRepayments={this.onClickCalculateRepayments}
          showReviewDetailsPopup={this.showReviewDetailsPopup}
          inputAmountData={inputAmountData}
          navigateNext={this.navigateNext}
          backToChannel={this.backToChannel}
          showHidePopUp={showHidePopUp}
          selectedLoanOption={selectedLoanOption}
          currentBalance={currBalance}
          hideReviewDetailsPopup={this.hideReviewDetailsPopup}
          variableInterestRate={variableInterestRate}
          loanMaturityDate={loanMaturityDate}
          interestOnlyMaturityDate={interestOnlyMaturityDate}
          monthlyRepayment={monthlyRepayment}
          interestRate={interestRateOptionSelected}
          availableFunds={redrawIndicatorSet ? availBalance : 0}
          yearTerm={yearTermSelected}
          redrawShowHidePopup={redrawShowHidePopup}
          showRedrawFundsPopup={this.showRedrawFundsPopup}
          hideRedrawFundsPopup={this.hideRedrawFundsPopup}
          redrawModalTitle={redrawModalTitle}
          redrawModalButtonText={redrawModalButtonText}
          redrawAlertBoxMessage={redrawAlertBoxMessage}
          redrawFundAccountsList={redrawFundAccountsList}
          selectAccountToTransfer={this.selectAccountToTransfer}
          selectedAccount={selectedAccount}
          splitVariableAmount={splitVariableAmount}
          splitFixedAmount={splitFixedAmount}
          repaymentType={repaymentType}
          calculatedVariableLoanBalance={variableLoanBalance}
          calculatedFixedLoanBalance={fixedLoanBalance}
          amountValidationMessage={amountValidationMessage}
          productName={productName}
          switchedProductName={switchedProductName}
          redrawIndicator={redrawIndicatorSet}
          totalIndicativeRepayment={totalIndicativeRepayment}
          monthlyMaintainence={monthlyMaintainence}
        />
      </div>
    );
  }
}

const mapStateToProps = state => ({
  channelDashboardUrl: getDashboardUrl(state),
  currentLoanDetails: getCurrentLoanDetails(state),
  selectedLoanOption: getSelectedLoanOption(state),
  yearTermSelected: getSelectedYearTerm(state),
  interestRateOptionSelected: getSelectedInterestRateForTerm(state),
  inputAmountData: getInputValueData(state),
  showHidePopUp: getShowHidePopUp(state),
  redrawShowHidePopup: getRedrawShowHidePopup(state),
  redrawModalTitle: getRedrawModalTitle(state),
  redrawModalButtonText: getRedrawModalButtonText(state),
  redrawAlertBoxMessage: getRedrawAlertBoxMessage(state),
  redrawFundAccounts: getRedrawAccounts(state),
  selectedAccount: getSelectedAccount(state),
  isRedrawAccountsFetching: getRedrawAccountsFetching(state),
  isRedrawAccountsError: getRedrawAccountsError(state),
  redrawFundAccountsList: getRedrawFundsAccounts(state),
  splitFixedAmount: getFixedRepaymentAmount(state),
  splitVariableAmount: getVariableRepaymentAmount(state),
  fixedLoanBalance: getFixedLoanBalance(state),
  variableLoanBalance: getVariableLoanBalance(state),
  selectedRepaymentType: getRepaymentType(state),
  isPackageCustomer: getPackageIndicator(state),
  switchFee: getSwitchingFee(state),
  monthlyMaintainence: getMonthlyMaintainenceFee(state),
  amountValidationMessage: getAmountValidationMessage(state),
  productName: getProductName(state),
  switchedProductName: getSwitchedProductName(state),
  redrawResponse: getRedrawError(state),
});

const mapDispatchToProps = {
  setShowHidePopup: appActions.app.modal.setShowHidePopup,
  setRedrawShowHidePopup: appActions.app.modal.setRedrawShowHidePopup,
  setRedrawModalTitle: appActions.app.modal.setRedrawModalTitle,
  setFixedOptionRate: appActions.app.interestrate.setFixedOptionRate,
  setInputValueData: appActions.app.interestrate.setInputValueData,
  setRedrawModalButtonText: appActions.app.modal.setRedrawModalButtonText,
  setRedrawAlertMessage: appActions.app.interestrate.setRedrawAlertMessage,
  setFieldSelectValue: appActions.app.interestrate.setFieldSelectValue,
  updateHeaderBackNavigation: appActions.app.header.navigateBack,
  fetchRedrawAccounts: formActions.getRedrawAccounts,
  setRedrawFundsAccounts: appActions.app.interestrate.setRedrawFundsAccounts,
  setSplitFixedAmount: appActions.app.interestrate.setSplitFixedAmount,
  setSplitVariableAmount: appActions.app.interestrate.setSplitVariableAmount,

  setFixedLoanBalance: appActions.app.interestrate.setFixedLoanBalance,
  setVariableLoanBalance: appActions.app.interestrate.setVariableLoanBalance,
  setAmountValidationMessage:
    appActions.app.interestrate.setAmountValidationMessage,
};

const enhance = compose(
  connect(mapStateToProps, mapDispatchToProps),
  withTracking((state, props) => getAnalyticsTags('LOANOPTIONS_PAGE', props)),
);
export default enhance(FixedOptionLoanContainer);
