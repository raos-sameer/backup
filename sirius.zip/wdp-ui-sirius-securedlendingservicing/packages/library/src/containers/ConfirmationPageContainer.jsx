import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { compose } from 'recompose';
import { withTracking } from '@wdpui/common-analytics';
import {
  getDashboardUrl,
  getPackageIndicator,
  getSelectedYearTerm,
  getRepaymentType,
  getMessageInboxUrl,
  getFlexiIndicator,
  getSelectedRedrawAccountLabel,
  getSelectedLoanOption,
  getDirectDebitUrl,
  getContractedRepaymentDate,
  getSwitchingFee,
} from '../redux/selectors';
import { actions as appActions } from '../redux/modules';
import { ConfirmationPage } from '../components';
import { scrollWindow } from '../helpers/windowFunctionsHelper';

import { getAnalyticsTags } from '../helpers/analyticsHelper';

class ConfirmationPageContainer extends Component {
  static propTypes = {
    channelDashboardUrl: PropTypes.string.isRequired,
    updateHeaderBackNavigation: PropTypes.func.isRequired,
    history: PropTypes.shape({
      push: PropTypes.func.isRequired,
      replace: PropTypes.func.isRequired,
    }).isRequired,
    directDebitUrl: PropTypes.string.isRequired,
    messageInboxUrl: PropTypes.string.isRequired,
    loanType: PropTypes.string.isRequired,
    contractedRepaymentDate: PropTypes.string.isRequired,
    selectedAccountLabel: PropTypes.string,
    switchFee: PropTypes.string.isRequired,
    advantagePackage: PropTypes.bool.isRequired,
    loanTerm: PropTypes.string.isRequired,
  };

  static defaultProps = {
    selectedAccountLabel: '',
  };

  componentDidMount() {
    const { updateHeaderBackNavigation } = this.props;
    scrollWindow();
    updateHeaderBackNavigation('CHANNEL');
  }

  backToChannel = () => {
    const { channelDashboardUrl } = this.props;
    window.location.replace(channelDashboardUrl);
  };

  render() {
    const {
      loanType,
      loanTerm,
      contractedRepaymentDate,
      messageInboxUrl,
      selectedAccountLabel,
      switchFee,
      advantagePackage,
      directDebitUrl,
    } = this.props;

    return (
      <ConfirmationPage
        onDoneClick={this.backToChannel}
        loanType={loanType}
        loanTerm={loanTerm}
        contractedRepaymentDate={contractedRepaymentDate}
        directDebitUrl={directDebitUrl}
        messageInboxUrl={messageInboxUrl}
        selectedAccountLabel={selectedAccountLabel}
        switchFee={switchFee}
        advantagePackage={advantagePackage}
      />
    );
  }
}

const mapStateToProps = state => ({
  channelDashboardUrl: getDashboardUrl(state),
  messageInboxUrl: getMessageInboxUrl(state),
  advantagePackage: getPackageIndicator(state),
  isFlexiCustomer: getFlexiIndicator(state),
  repaymentType: getRepaymentType(state),
  directDebitUrl: getDirectDebitUrl(state),
  loanTerm: getSelectedYearTerm(state),
  loanType: getSelectedLoanOption(state),
  selectedAccountLabel: getSelectedRedrawAccountLabel(state),
  contractedRepaymentDate: getContractedRepaymentDate(state),
  switchFee: getSwitchingFee(state),
});

const mapDispatchToProps = {
  updateHeaderBackNavigation: appActions.app.header.navigateBack,
};

const enhance = compose(
  connect(mapStateToProps, mapDispatchToProps),
  withTracking((state, props) => getAnalyticsTags('SUBMIT_PAGE', props)),
);

export default enhance(ConfirmationPageContainer);
