import React from 'react';
import { shallow } from 'enzyme';
import { sortBy, pick } from 'lodash';
import { Redirect, BrowserRouter as Router } from 'react-router-dom';

import configureMockStore from 'redux-mock-store';
import { withTheme } from '../../../../utils/jest/TestUtils';
import { mockStoreData } from './__fixtures__/mockSelectInterestRateContainer.fixture';
import EnhancedSelectInterestRateContainer from './SelectInterestRateContainer';

const mockStore = configureMockStore();

global.matchMedia = matches => () => ({
  matches,
  addListener: () => {},
  removeListener: () => {},
});
describe('SelectInterestRateContainer', () => {
  let store;
  const spy = jest.spyOn(global.console, 'error');
  const history = {
    push: jest.fn(),
    replace: jest.fn(),
  };
  const mockFn = jest.fn();
  window.location.replace = jest.fn();
  afterEach(() => {
    if (store && store.clearActions) {
      store.clearActions();
    }
    if (spy && spy.mockReset && spy.mockRestore) {
      spy.mockReset();
      spy.mockRestore();
    }
    if (history && history.push) {
      history.push.mockReset();
      history.push.mockRestore();
      history.replace.mockReset();
      history.replace.mockRestore();
    }
  });

  it('should render without error when required props are passed', () => {
    store = mockStore(mockStoreData.valid[0]);
    const component = withTheme(
      <EnhancedSelectInterestRateContainer
        history={history}
        match={{ path: '' }}
      />,
    );
    shallow(component, { context: { store } }).dive();
    expect(spy).not.toHaveBeenCalled();
  });

  it('should call backToChannel', () => {
    store = mockStore(mockStoreData.valid[0]);
    const component = withTheme(
      <EnhancedSelectInterestRateContainer
        history={history}
        match={{ path: '' }}
      />,
    );
    const shl = shallow(component, { context: { store } })
      .dive()
      .dive()
      .dive()
      .dive()
      .dive()
      .dive();
    const instance = shl.instance();
    instance.backToChannel();
    expect(window.location.replace).toHaveBeenCalled();
  });

  it('should call navigateNext', () => {
    store = mockStore(mockStoreData.valid[0]);
    const component = withTheme(
      <EnhancedSelectInterestRateContainer
        history={history}
        match={{ path: '' }}
      />,
    );
    const shl = shallow(component, { context: { store } })
      .dive()
      .dive()
      .dive()
      .dive()
      .dive()
      .dive();
    const instance = shl.instance();
    instance.navigateNext();
    expect(history.push).toHaveBeenCalled();
  });

  it('should call showReviewDetailsPopup', () => {
    store = mockStore(mockStoreData.valid[0]);

    const component = withTheme(
      <EnhancedSelectInterestRateContainer
        history={history}
        match={{ path: '' }}
      />,
    );
    const shl = shallow(component, { context: { store } })
      .dive()
      .dive()
      .dive()
      .dive()
      .dive()
      .dive();
    const instance = shl.instance();
    instance.showReviewDetailsPopup();

    const actionShowHide = store.getActions().filter(a => {
      return a.type === 'app/modal/SET_SHOW_HIDE_POPUP';
    });
    expect(actionShowHide[0].payload).toEqual(true);
  });

  it('should call hideReviewDetailsPopup', () => {
    store = mockStore(mockStoreData.valid[0]);
    const component = withTheme(
      <EnhancedSelectInterestRateContainer
        history={history}
        match={{ path: '' }}
      />,
    );
    const shl = shallow(component, { context: { store } })
      .dive()
      .dive()
      .dive()
      .dive()
      .dive()
      .dive();
    const instance = shl.instance();
    instance.hideReviewDetailsPopup();
    const actionShowHide = store.getActions().filter(a => {
      return a.type === 'app/modal/SET_SHOW_HIDE_POPUP';
    });
    expect(actionShowHide[0].payload).toEqual(false);
  });

  it('should call handleInterestRateSiloChange', () => {
    store = mockStore(mockStoreData.valid[0]);
    const component = withTheme(
      <EnhancedSelectInterestRateContainer
        history={history}
        match={{ path: '' }}
      />,
    );
    const shl = shallow(component, { context: { store } })
      .dive()
      .dive()
      .dive()
      .dive()
      .dive()
      .dive();
    const instance = shl.instance();

    instance.handleInterestRateSiloChange('1', '3.95');
    const actionSetYear = store.getActions().filter(a => {
      return a.type === 'app/interestrate/SET_YEAR_TERM';
    });
    const actionSetInterestRate = store.getActions().filter(a => {
      return a.type === 'app/interestrate/SET_INTEREST_RATE_TERM';
    });
    expect(actionSetInterestRate[0].payload).toEqual('3.95');
    expect(actionSetYear[0].payload).toEqual('1');
  });

  it('should call handleAlertMessageSet For Principal Interest Only', () => {
    store = mockStore(mockStoreData.valid[10]);

    const component = withTheme(
      <EnhancedSelectInterestRateContainer
        history={history}
        match={{ path: '' }}
      />,
    );
    const shl = shallow(component, { context: { store } })
      .dive()
      .dive()
      .dive()
      .dive()
      .dive()
      .dive();
    const instance = shl.instance();
    instance.handleAlertMessageSet('PIF');
    const actionObjPI = store.getActions().filter(a => {
      return a.type === 'app/interestrate/SET_ALERT_MESSAGE';
    });
    const principalMsg =
      'Your interest only period will end on switching to principal and interest repayments';
    expect(actionObjPI[0].payload.trim()).toEqual(principalMsg.trim());
  });

  it('should call handleAlertMessageSet For Interest Only', () => {
    store = mockStore(mockStoreData.valid[10]);

    const props = {
      isExpiryDateLessThanYear: false,
      setAlertMessage: { mockFn },
    };
    const component = withTheme(
      <EnhancedSelectInterestRateContainer
        history={history}
        match={{ path: '' }}
        {...props}
      />,
    );
    const shl = shallow(component, { context: { store } })
      .dive()
      .dive()
      .dive()
      .dive()
      .dive()
      .dive();
    const instance = shl.instance();
    instance.handleAlertMessageSet('IO');
    const actionFiltered = store.getActions().filter(a => {
      return a.type === 'app/interestrate/SET_ALERT_MESSAGE';
    });
    const interestOnlyMsg =
      'The terms offered are within your interest only period. Switching to Principal and interest repayments may offer longer terms';
    expect(actionFiltered[0].payload.trim()).toEqual(interestOnlyMsg.trim());
  });

  it('should call handleAlertMessageSet if expiry date less than year and repayment type is Interest only', () => {
    store = mockStore(mockStoreData.valid[9]);

    const props = {
      isExpiryDateLessThanYear: true,
      setAlertMessage: { mockFn },
    };

    const component = withTheme(
      <EnhancedSelectInterestRateContainer
        history={history}
        match={{ path: '' }}
        {...props}
      />,
    );
    const shl = shallow(component, { context: { store } })
      .dive()
      .dive()
      .dive()
      .dive()
      .dive()
      .dive();
    const instance = shl.instance();
    instance.handleAlertMessageSet('IO');

    const actionObjPI = store.getActions().filter(a => {
      return a.type === 'app/interestrate/SET_ALERT_MESSAGE';
    });
    const principalMsg =
      'Your interest only period expires in less than a year. You"ll have to switch to principal and interest repayments to fix your loan.';

    expect(actionObjPI[0].payload.trim().replace("'", '')).toEqual(
      principalMsg.trim().replace('"', ''),
    );
  });

  it('should call handleAlertMessageSet if expiry date less than year and repayment type is principal interest', () => {
    store = mockStore(mockStoreData.valid[8]);
    const props = {
      isExpiryDateLessThanYear: false,
      setAlertMessage: { mockFn },
    };
    const component = withTheme(
      <EnhancedSelectInterestRateContainer
        history={history}
        match={{ path: '' }}
        {...props}
      />,
    );
    const shl = shallow(component, { context: { store } })
      .dive()
      .dive()
      .dive()
      .dive()
      .dive()
      .dive();
    const instance = shl.instance();
    instance.handleAlertMessageSet('PIF');

    const actionFiltered = store.getActions().filter(a => {
      return a.type === 'app/interestrate/SET_ALERT_MESSAGE';
    });
    const interestOnlyMsg =
      'Your interest only period will end on switching to principal and interest repayments';
    expect(actionFiltered[0].payload.trim()).toEqual(interestOnlyMsg.trim());
  });

  it('should call setRepaymentType', () => {
    store = mockStore(mockStoreData.valid[0]);
    const component = withTheme(
      <EnhancedSelectInterestRateContainer
        history={history}
        match={{ path: '' }}
      />,
    );
    const shl = shallow(component, { context: { store } })
      .dive()
      .dive()
      .dive()
      .dive()
      .dive()
      .dive();

    const instance = shl.instance();
    const ev = {
      preventDefault() {},
      target: { value: 'IO' },
    };
    instance.setRepaymentType(ev);
    const actionFiltered = store.getActions().filter(a => {
      return a.type === 'app/interestrate/SET_REPAYMENT_TYPE';
    });
    expect(actionFiltered[0].payload.trim()).toEqual('IO');
  });

  it('should call componentDidUpdate and set Alert Message if alertMessage is empty and also set repayment type', () => {
    store = mockStore(mockStoreData.valid[6]);
    const component = withTheme(
      <EnhancedSelectInterestRateContainer
        history={history}
        match={{ path: '' }}
      />,
    );
    const shl = shallow(component, { context: { store } })
      .dive()
      .dive()
      .dive()
      .dive()
      .dive()
      .dive();
    const instance = shl.instance();

    instance.componentDidUpdate();
    const expectedActions = sortBy(
      [
        {
          type: 'common/analytics/LOAD',
        },
        {
          type: 'app/header/NAVIGATE_BACK',
        },
        {
          type: 'app/interestrate/SET_ALERT_MESSAGE',
        },
        {
          type: 'app/interestrate/SET_REPAYMENT_TYPE',
        },
      ],
      ['type'],
    );
    let actions = store.getActions().map(a => pick(a, 'type'));
    actions = sortBy(actions, ['type']);
    expect(actions).toEqual(expectedActions);
  });

  it('should display Redirect when arrangements api error is true', () => {
    store = mockStore(mockStoreData.valid[12]);
    const component = withTheme(
      <Router>
        <EnhancedSelectInterestRateContainer
          history={history}
          store={store}
          match={{ path: '' }}
        />
      </Router>,
    );
    const wrapper = shallow(component, { context: { store } })
      .dive()
      .dive()
      .dive()
      .dive()
      .dive()
      .dive()
      .dive()

      .dive();
    expect(wrapper.find(Redirect)).toHaveLength(1);
  });
  it('should display loader when arrangements api is being called', () => {
    store = mockStore(mockStoreData.valid[15]);
    const component = withTheme(
      <EnhancedSelectInterestRateContainer
        history={history}
        store={store}
        match={{ path: '' }}
      />,
    );
    const wrapper = shallow(component, { context: { store } })
      .dive()
      .dive()
      .dive()
      .dive()
      .dive()
      .dive()
      .dive()
      .dive();
    expect(wrapper.find('Loader')).toHaveLength(1);
  });

  it('should display Redirect when mortgage quotes api fail for pricing error', () => {
    store = mockStore(mockStoreData.valid[16]);
    const component = withTheme(
      <Router>
        <EnhancedSelectInterestRateContainer
          history={history}
          store={store}
          match={{ path: '' }}
        />
      </Router>,
    );
    const wrapper = shallow(component, { context: { store } })
      .dive()
      .dive()
      .dive()
      .dive()
      .dive()
      .dive()
      .dive()
      .dive();
    expect(wrapper.find(Redirect)).toHaveLength(1);
  });
});
