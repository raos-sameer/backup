import React from 'react';
import { shallow } from 'enzyme';
import configureMockStore from 'redux-mock-store';
import { sortBy, pick } from 'lodash';
import { Redirect, BrowserRouter as Router } from 'react-router-dom';
import { withTheme } from '../../../../utils/jest/TestUtils';
import { mockStoreData } from './__fixtures__/mockSelectInterestRateContainer.fixture';
import EnhancedLandingPageContainer from './LandingPageContainer';
import { Loader } from '../components/common';

const mockStore = configureMockStore();

global.matchMedia = matches => () => ({
  matches,
  addListener: () => {},
  removeListener: () => {},
});
describe('LandingPageContainer', () => {
  let store;
  const url = 'test?contextRefId=1234';

  Object.defineProperty(window, 'location', {
    value: {
      href: url,
      search: url,
    },
  });

  const spy = jest.spyOn(global.console, 'error');
  const history = {
    push: jest.fn(),
    replace: jest.fn(),
  };
  window.location.replace = jest.fn();

  afterEach(() => {
    if (store && store.clearActions) {
      store.clearActions();
    }
    if (spy && spy.mockReset && spy.mockRestore) {
      spy.mockReset();
      spy.mockRestore();
    }
    if (history && history.push) {
      history.push.mockReset();
      history.push.mockRestore();
      history.replace.mockReset();
      history.replace.mockRestore();
    }
  });

  it('should render without error when required props are passed', () => {
    store = mockStore(mockStoreData.valid[0]);
    const component = withTheme(
      <EnhancedLandingPageContainer history={history} match={{ path: '' }} />,
    );
    shallow(component, { context: { store } }).dive();
    expect(spy).not.toHaveBeenCalled();
  });

  it('should call backToChannel', () => {
    store = mockStore(mockStoreData.valid[0]);

    const component = withTheme(
      <EnhancedLandingPageContainer history={history} match={{ path: '' }} />,
    );
    const shl = shallow(component, { context: { store } })
      .dive()
      .dive()
      .dive()
      .dive()
      .dive()
      .dive()
      .dive()
      .dive()
      .dive()
      .dive();
    const instance = shl.instance();
    instance.backToChannel();
    expect(window.location.replace).toHaveBeenCalled();
  });

  it('should call fetchMortgageQuotes', () => {
    store = mockStore(mockStoreData.valid[4]);
    const component = withTheme(
      <EnhancedLandingPageContainer history={history} match={{ path: '' }} />,
    );
    const shl = shallow(component, { context: { store } })
      .dive()
      .dive()
      .dive()
      .dive()
      .dive()
      .dive()
      .dive()
      .dive()
      .dive()
      .dive();
    const instance = shl.instance();
    instance.navigateNext();
    expect(window.location.replace).toHaveBeenCalled();
  });

  it('should call navigateNext', () => {
    store = mockStore(mockStoreData.valid[0]);
    const component = withTheme(
      <EnhancedLandingPageContainer history={history} match={{ path: '' }} />,
    );
    const shl = shallow(component, { context: { store } })
      .dive()
      .dive()
      .dive()
      .dive()
      .dive()
      .dive()
      .dive()
      .dive()
      .dive()
      .dive();
    const instance = shl.instance();
    instance.navigateNext();
    expect(history.push).toHaveBeenCalled();
  });

  it('should display loader when currentloandetails api is being called', () => {
    store = mockStore(mockStoreData.valid[1]);
    const component = withTheme(
      <EnhancedLandingPageContainer
        history={history}
        store={store}
        match={{ path: '' }}
      />,
    );
    const wrapper = shallow(component, { context: { store } })
      .dive()
      .dive()
      .dive()
      .dive()
      .dive()
      .dive()
      .dive()
      .dive()
      .dive()
      .dive();

    expect(wrapper.find(Loader)).toHaveLength(1);
  });

  it('should display Redirect when contexts api error is true', () => {
    store = mockStore(mockStoreData.valid[2]);
    const component = withTheme(
      <Router>
        <EnhancedLandingPageContainer
          history={history}
          store={store}
          match={{ path: '' }}
        />
      </Router>,
    );
    const wrapper = shallow(component, { context: { store } })
      .dive()
      .dive()
      .dive()
      .dive()
      .dive()
      .dive()
      .dive()
      .dive()
      .dive()
      .dive()
      .dive()
      .dive();
    expect(wrapper.find(Redirect)).toHaveLength(1);
  });

  it('should display Redirect to caseexists  when loanCaseExists is true', () => {
    store = mockStore(mockStoreData.valid[11]);
    const component = withTheme(
      <Router>
        <EnhancedLandingPageContainer
          history={history}
          store={store}
          match={{ path: '' }}
        />
      </Router>,
    );
    const wrapper = shallow(component, { context: { store } })
      .dive()
      .dive()
      .dive()
      .dive()
      .dive()
      .dive()
      .dive()
      .dive()
      .dive()
      .dive()
      .dive()
      .dive();
    expect(wrapper.find(Redirect)).toHaveLength(1);
  });

  it('should call componentDidUpdate', () => {
    store = mockStore(mockStoreData.valid[0]);
    const component = withTheme(
      <EnhancedLandingPageContainer history={history} match={{ path: '' }} />,
    );
    const shl = shallow(component, { context: { store } })
      .dive()
      .dive()
      .dive()
      .dive()
      .dive()
      .dive()
      .dive()
      .dive()
      .dive()
      .dive();
    const instance = shl.instance();
    instance.componentDidUpdate();
    const expectedActions = sortBy(
      [
        {
          type: 'api/contextsById/get/REQUEST',
        },
        {
          type: 'getCustomerEligibility',
        },
        {
          type: 'common/analytics/LOAD',
        },
        {
          type: 'app/header/NAVIGATE_BACK',
        },
      ],
      ['type'],
    );
    let actions = store.getActions().map(a => pick(a, 'type'));

    actions = sortBy(actions, ['type']);

    expect(actions).toEqual(expectedActions);
  });
});
