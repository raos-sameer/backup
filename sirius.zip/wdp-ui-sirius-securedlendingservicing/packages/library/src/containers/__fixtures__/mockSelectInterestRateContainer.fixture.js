export const mockStoreData = {
  valid: [
    {
      config: {
        brandId: 'WBC',
      },
      ui: {
        securedLendingServicing: {
          app: {
            headerBackNavigate: 'CHANNEL',
            showHidePopUp: false,
            selectedYearTerm: '3',
            discountRate: '0.4',
            selectedInterestRateForTerm: '3.96',
            alertBoxMessage:
              'The terms offered are within your interest only period. Switching to Principal and interest repayments may offer longer terms',
            selectedRepaymentType: 'IO',
            submitAction: 'SUCCESS',
          },
        },
      },
      entities: {
        siriusCoreV1: {
          contexts: {
            byId: {
              'j-hwNz3u': {
                fields: [
                  {
                    fieldName: 'accountNumber',
                    value: '034017161770',
                  },
                  {
                    fieldName: 'CPC',
                    value: '9ba83148d96c4d1bac176afcff65b078',
                  },
                  {
                    fieldName: 'PackageType',
                    value: 'P',
                  },
                  {
                    fieldName: 'PackageName',
                    value: 'Premier Advantage Package',
                  },
                ],
                id: 'j-hwNz3u',
              },
            },
            allIds: ['j-hwNz3u'],
            isFetching: false,
            isError: false,
          },
        },
        siriusSecuredlendingservicingV1: {
          arrangements: {
            byId: {
              ZiWtQhuAo: {
                currentBalance: { amount: '300000', position: 'DR' },
                availableBalance: { amount: '300000', position: 'CR' },
                discounts: ['0.48'],
                variableInterestRate: '4.20',
                loanMaturityDate: '23 Jan 2052',
                repaymentType: 'IO',
                interestOnlyMaturityDate: '01 Dec 2018',
                monthlyRepayment: '1400',
                redrawIndicatorSet: false,
                remainingTermPIF: '186',
                remainingTermIO: '110',
                productName: 'flexi',
                loanLimit: '1223',
                id: 'ZiWtQhuAo',
              },
            },
            allIds: ['ZiWtQhuAo'],
            isFetching: false,
            isError: false,
          },

          eligibilities: {
            byId: {},
            allIds: [],
            isFetching: false,
            isError: false,
          },
        },
      },
    },
    {
      config: {
        brandId: 'WBC',
      },
      ui: {
        securedLendingServicing: {
          app: {
            headerBackNavigate: 'CHANNEL',
            headerTitle: 'Test',
            submitAction: 'SUCCESS',
          },
        },
      },
      entities: {
        siriusCoreV1: {
          contexts: {
            byId: {},
            allIds: [],
            isFetching: true,
            isError: false,
          },
        },
        siriusSecuredlendingservicingV1: {
          eligibilities: {
            byId: {
              'j-hwNz3u': {
                status: 'Eligible',
                isFlexiLoan: true,
                failureReason: {
                  reason: 'CaseExists',
                  details: 'User case already exists',
                },
                id: 'j-hwNz3u',
              },
            },
            allIds: ['j-hwNz3u'],
            isFetching: false,
            isError: false,
          },
          arrangements: {
            byId: {
              ZiWtQhuAo: {
                currentBalance: { amount: '300000', position: 'DR' },
                availableBalance: { amount: '300000', position: 'CR' },
                discounts: ['0.48'],
                variableInterestRate: '4.20',
                loanMaturityDate: '23 Jan 2052',
                repaymentType: 'IO',
                interestOnlyMaturityDate: '01 Dec 2018',
                monthlyRepayment: '1400',
                redrawIndicatorSet: false,
                remainingTermPIF: '186',
                remainingTermIO: '110',
                productName: 'flexi',
                loanLimit: '1223',
                id: 'ZiWtQhuAo',
              },
            },
            allIds: ['ZiWtQhuAo'],
            isFetching: false,
            isError: false,
          },
        },
      },
    },
    {
      config: {
        brandId: 'WBC',
      },
      ui: {
        securedLendingServicing: {
          app: {
            headerBackNavigate: 'CHANNEL',
            headerTitle: 'Test',
            isContextExpired: true,
          },
        },
      },
      entities: {
        siriusCoreV1: {
          contexts: {
            byId: {},
            allIds: [],
            isFetching: false,
            isError: true,
          },
        },
        siriusSecuredlendingservicingV1: {
          eligibilities: {
            byId: {},
            allIds: [],
            isFetching: false,
            isError: true,
          },
          arrangements: {
            byId: {
              ZiWtQhuAo: {
                currentBalance: { amount: '300000', position: 'DR' },
                availableBalance: { amount: '300000', position: 'CR' },
                discounts: ['0.48'],
                variableInterestRate: '4.20',
                loanMaturityDate: '23 Jan 2052',
                repaymentType: 'IO',
                interestOnlyMaturityDate: '01 Dec 2018',
                monthlyRepayment: '1400',
                redrawIndicatorSet: false,
                remainingTermPIF: '186',
                remainingTermIO: '110',
                productName: 'flexi',
                loanLimit: '1223',
                id: 'ZiWtQhuAo',
              },
            },
            allIds: ['ZiWtQhuAo'],
            isFetching: false,
            isError: false,
          },
          quotes: {
            byId: {},
            allIds: [],
            isFetching: false,
            isError: false,
          },
        },
      },
    },
    {
      config: {
        brandId: 'WBC',
      },
      ui: {
        securedLendingServicing: {
          app: {
            headerBackNavigate: 'CHANNEL',
            headerTitle: 'Test',
          },
        },
      },
      entities: {
        siriusCoreV1: {
          contexts: {
            byId: {
              'j-hwNz3u': {
                fields: [
                  {
                    fieldName: 'accountNumber',
                    value: '034017161770',
                  },
                  {
                    fieldName: 'CPC',
                    value: '9ba83148d96c4d1bac176afcff65b078',
                  },
                  {
                    fieldName: 'PackageType',
                    value: 'P',
                  },
                  {
                    fieldName: 'PackageName',
                    value: 'Premier Advantage Package',
                  },
                ],
                id: 'j-hwNz3u',
              },
            },
            allIds: ['j-hwNz3u'],
            isFetching: false,
            isError: false,
          },
        },
        siriusSecuredlendingservicingV1: {
          eligibilities: {
            byId: {
              'j-hwNz3u': {
                status: 'Eligible',
                isFlexiLoan: true,
                failureReason: {
                  reason: 'CaseExists',
                  details: 'User case already exists',
                },
                id: 'j-hwNz3u',
              },
            },
            allIds: ['j-hwNz3u'],
            isFetching: false,
            isError: false,
          },
          quotes: {
            byId: {},
            allIds: [],
            isFetching: false,
            isError: false,
          },
        },
      },
    },
    {
      config: {
        brandId: 'WBC',
      },
      ui: {
        securedLendingServicing: {
          app: {
            headerBackNavigate: 'CHANNEL',
            headerTitle: 'Test',
          },
        },
      },
      entities: {
        siriusCoreV1: {
          contexts: {
            byId: {
              'j-hwNz3u': {
                fields: [
                  {
                    fieldName: 'accountNumber',
                    value: '034017161770',
                  },
                  {
                    fieldName: 'CPC',
                    value: '9ba83148d96c4d1bac176afcff65b078',
                  },
                  {
                    fieldName: 'PackageType',
                    value: 'P',
                  },
                  {
                    fieldName: 'PackageName',
                    value: 'Premier Advantage Package',
                  },
                ],
                id: 'j-hwNz3u',
              },
            },
            allIds: ['j-hwNz3u'],
            isFetching: false,
            isError: false,
          },
        },
        siriusSecuredlendingservicingV1: {
          arrangements: {
            byId: {
              ZiWtQhuAo: {
                currentBalance: { amount: '300000', position: 'DR' },
                availableBalance: { amount: '300000', position: 'CR' },
                discounts: ['0.48'],
                variableInterestRate: '4.20',
                loanMaturityDate: '23 Jan 2052',
                repaymentType: 'IO',
                interestOnlyMaturityDate: '01 Dec 2018',
                monthlyRepayment: '1400',
                redrawIndicatorSet: false,
                loanLimit: '1223',
                remainingTermPIF: '186',
                remainingTermIO: '110',
                productName: 'flexi',
                id: 'ZiWtQhuAo',
              },
            },
            allIds: ['ZiWtQhuAo'],
            isFetching: false,
            isError: false,
          },

          eligibilities: {
            byId: {
              'j-hwNz3u': {
                status: 'Eligible',
                isFlexiLoan: true,
                failureReason: {
                  reason: 'CaseExists',
                  details: 'User case already exists',
                },
                id: 'j-hwNz3u',
              },
            },
            allIds: ['j-hwNz3u'],
            isFetching: false,
            isError: false,
          },
          quotes: {
            byId: {},
            allIds: [],
            isFetching: true,
            isError: false,
          },
        },
      },
    },
    {
      config: {
        brandId: 'WBC',
      },
      ui: {
        securedLendingServicing: {
          app: {
            headerBackNavigate: 'CHANNEL',
            headerTitle: 'Test',
          },
        },
      },
      entities: {
        siriusCoreV1: {
          contexts: {
            byId: {
              'j-hwNz3u': {
                fields: [
                  {
                    fieldName: 'accountNumber',
                    value: '034017161770',
                  },
                  {
                    fieldName: 'CPC',
                    value: '9ba83148d96c4d1bac176afcff65b078',
                  },
                  {
                    fieldName: 'PackageType',
                    value: 'P',
                  },
                  {
                    fieldName: 'PackageName',
                    value: 'Premier Advantage Package',
                  },
                ],
                id: 'j-hwNz3u',
              },
            },
            allIds: ['j-hwNz3u'],
            isFetching: false,
            isError: false,
          },
        },
        siriusSecuredlendingservicingV1: {
          eligibilities: {
            byId: {
              'j-hwNz3u': {
                status: 'Eligible',
                isFlexiLoan: true,
                failureReason: {
                  reason: 'CaseExists',
                  details: 'User case already exists',
                },
                id: 'j-hwNz3u',
              },
            },
            allIds: ['j-hwNz3u'],
            isFetching: false,
            isError: false,
          },
          arrangements: {
            byId: {},
            allIds: [],
            isFetching: false,
            isError: false,
          },
          quotes: {
            byId: {},
            allIds: [],
            isFetching: false,
            isError: true,
          },
        },
      },
    },
    {
      config: {
        brandId: 'WBC',
      },
      ui: {
        securedLendingServicing: {
          app: {
            headerBackNavigate: 'CHANNEL',
            showHidePopUp: false,
            selectedYearTerm: '',
            discountRate: '',
            selectedInterestRateForTerm: '',
            alertBoxMessage: '',
            selectedRepaymentType: '',
          },
        },
      },
      entities: {
        siriusCoreV1: {
          contexts: {
            byId: {
              'j-hwNz3u': {
                fields: [
                  {
                    fieldName: 'accountNumber',
                    value: '034017161770',
                  },
                  {
                    fieldName: 'CPC',
                    value: '9ba83148d96c4d1bac176afcff65b078',
                  },
                  {
                    fieldName: 'PackageType',
                    value: 'P',
                  },
                  {
                    fieldName: 'PackageName',
                    value: 'Premier Advantage Package',
                  },
                ],
                id: 'j-hwNz3u',
              },
            },
            allIds: ['j-hwNz3u'],
            isFetching: false,
            isError: false,
          },
        },
        siriusSecuredlendingservicingV1: {
          eligibilities: {
            byId: {
              'j-hwNz3u': {
                status: 'Eligible',
                isFlexiLoan: true,
                failureReason: {
                  reason: 'CaseExists',
                  details: 'User case already exists',
                },
                id: 'j-hwNz3u',
              },
            },
            allIds: ['j-hwNz3u'],
            isFetching: false,
            isError: false,
          },
          arrangements: {
            byId: {
              ZiWtQhuAo: {
                currentBalance: { amount: '300000', position: 'DR' },
                availableBalance: { amount: '300000', position: 'CR' },
                discounts: ['0.48'],
                variableInterestRate: '4.20',
                loanMaturityDate: '23 Jan 2052',
                repaymentType: 'IO',
                interestOnlyMaturityDate: '01 Dec 2018',
                monthlyRepayment: '1400',
                redrawIndicatorSet: false,
                loanLimit: '1223',
                remainingTermPIF: '186',
                remainingTermIO: '110',
                productName: 'flexi',
                id: 'ZiWtQhuAo',
              },
            },
            allIds: ['ZiWtQhuAo'],
            isFetching: false,
            isError: false,
          },
        },
      },
    },

    {
      config: {
        brandId: 'WBC',
      },
      ui: {
        securedLendingServicing: {
          app: {
            headerBackNavigate: 'CHANNEL',
            showHidePopUp: false,
            selectedYearTerm: '3',
            discountRate: '0.4',
            selectedInterestRateForTerm: '3.96',
            alertBoxMessage: '',
            selectedRepaymentType: 'IO',
          },
        },
      },
      entities: {
        siriusCoreV1: {
          contexts: {
            byId: {
              'j-hwNz3u': {
                fields: [
                  {
                    fieldName: 'accountNumber',
                    value: '034017161770',
                  },
                  {
                    fieldName: 'CPC',
                    value: '9ba83148d96c4d1bac176afcff65b078',
                  },
                  {
                    fieldName: 'PackageType',
                    value: 'P',
                  },
                  {
                    fieldName: 'PackageName',
                    value: 'Premier Advantage Package',
                  },
                ],
                id: 'j-hwNz3u',
              },
            },
            allIds: ['j-hwNz3u'],
            isFetching: false,
            isError: false,
          },
        },
        siriusSecuredlendingservicingV1: {
          eligibilities: {
            byId: {
              'j-hwNz3u': {
                status: 'Eligible',
                isFlexiLoan: true,
                failureReason: {
                  reason: 'CaseExists',
                  details: 'User case already exists',
                },
                id: 'j-hwNz3u',
              },
            },
            allIds: ['j-hwNz3u'],
            isFetching: false,
            isError: false,
          },
          arrangements: {
            byId: {
              ZiWtQhuAo: {
                currentBalance: { amount: '300000', position: 'DR' },
                availableBalance: { amount: '300000', position: 'CR' },
                discounts: ['0.48'],
                variableInterestRate: '4.20',
                loanMaturityDate: '23 Jan 2052',
                repaymentType: 'IO',
                interestOnlyMaturityDate: '01 Dec 2018',
                monthlyRepayment: '1400',
                redrawIndicatorSet: false,
                remainingTermPIF: '186',
                remainingTermIO: '110',
                productName: 'flexi',
                loanLimit: '1223',
                id: 'ZiWtQhuAo',
              },
            },
            allIds: ['ZiWtQhuAo'],
            isFetching: false,
            isError: false,
          },
          quotes: {
            byId: {
              '6aZvBOo5': {
                isDiscountApplicable: false,
                isDiscretionaryDiscount: false,
                discountRate: '0.20',
                interestRate: '1.22',
                yearTerm: '1',
                switchedProductName: 'Fixed Rate Investment Property Loan 1',

                id: '6aZvBOo5',
              },
              'ybppcQX-D': {
                isDiscountApplicable: false,
                isDiscretionaryDiscount: false,
                discountRate: '0.17',
                interestRate: '4.2',
                yearTerm: '2',
                switchedProductName: 'Fixed Rate Investment Property Loan 2',

                id: 'ybppcQX-D',
              },
              HUFDVOAv7: {
                isDiscountApplicable: false,
                isDiscretionaryDiscount: false,
                discountRate: '0.40',
                interestRate: '3.95',
                yearTerm: '3',
                switchedProductName: 'Fixed Rate Investment Property Loan 3',

                id: 'HUFDVOAv7',
              },
              '5oWf2qazV': {
                isDiscountApplicable: false,
                isDiscretionaryDiscount: false,
                discountRate: '0.90',
                interestRate: '5.22',
                yearTerm: '4',
                switchedProductName: 'Fixed Rate Investment Property Loan 4',

                id: '5oWf2qazV',
              },
              evhaaurcr: {
                isDiscountApplicable: true,
                isDiscretionaryDiscount: true,
                discountRate: '0.20',
                interestRate: '3.22',
                yearTerm: '5',
                switchedProductName: 'Fixed Rate Investment Property Loan 5',

                id: 'evhaaurcr',
              },
            },
            allIds: [
              '6aZvBOo5',
              'ybppcQX-D',
              'HUFDVOAv7',
              '5oWf2qazV',
              'evhaaurcr',
            ],
            isFetching: false,
            isError: false,
          },
        },
      },
    },
    {
      config: {
        brandId: 'WBC',
      },
      ui: {
        securedLendingServicing: {
          app: {
            headerBackNavigate: 'CHANNEL',
            showHidePopUp: false,
            selectedYearTerm: '3',
            discountRate: '0.4',
            selectedInterestRateForTerm: '3.96',
            alertBoxMessage:
              'The terms offered are within your interest only period. Switching to Principal and interest repayments may offer longer terms',
            selectedRepaymentType: 'IO',
          },
        },
      },
      entities: {
        siriusCoreV1: {
          contexts: {
            byId: {
              'j-hwNz3u': {
                fields: [
                  {
                    fieldName: 'accountNumber',
                    value: '034017161770',
                  },
                  {
                    fieldName: 'CPC',
                    value: '9ba83148d96c4d1bac176afcff65b078',
                  },
                  {
                    fieldName: 'PackageType',
                    value: 'P',
                  },
                  {
                    fieldName: 'PackageName',
                    value: 'Premier Advantage Package',
                  },
                ],
                id: 'j-hwNz3u',
              },
            },
            allIds: ['j-hwNz3u'],
            isFetching: false,
            isError: false,
          },
        },
        siriusSecuredlendingservicingV1: {
          eligibilities: {
            byId: {
              'j-hwNz3u': {
                status: 'Eligible',
                isFlexiLoan: true,
                failureReason: {
                  reason: 'CaseExists',
                  details: 'User case already exists',
                },
                id: 'j-hwNz3u',
              },
            },
            allIds: ['j-hwNz3u'],
            isFetching: false,
            isError: false,
          },
          arrangements: {
            byId: {
              ZiWtQhuAo: {
                currentBalance: { amount: '300000', position: 'DR' },
                availableBalance: { amount: '300000', position: 'CR' },
                discounts: ['0.48'],
                variableInterestRate: '4.20',
                loanMaturityDate: '23 Jan 2052',
                repaymentType: 'IO',
                interestOnlyMaturityDate: '01 Dec 2018',
                monthlyRepayment: '1400',
                redrawIndicatorSet: false,
                remainingTermPIF: '186',
                remainingTermIO: '110',
                productName: 'flexi',
                loanLimit: '1223',
                id: 'ZiWtQhuAo',
              },
            },
            allIds: ['ZiWtQhuAo'],
            isFetching: false,
            isError: false,
          },
          quotes: {
            byId: {},
            allIds: [],
            isFetching: false,
            isError: true,
          },
        },
      },
    },
    {
      config: {
        brandId: 'WBC',
      },
      ui: {
        securedLendingServicing: {
          app: {
            headerBackNavigate: 'CHANNEL',
            showHidePopUp: false,
            selectedYearTerm: '3',
            discountRate: '0.4',
            selectedInterestRateForTerm: '3.96',
            alertBoxMessage:
              'The terms offered are within your interest only period. Switching to Principal and interest repayments may offer longer terms',
            selectedRepaymentType: 'IO',
          },
        },
      },
      entities: {
        siriusCoreV1: {
          contexts: {
            byId: {
              'j-hwNz3u': {
                fields: [
                  {
                    fieldName: 'accountNumber',
                    value: '034017161770',
                  },
                  {
                    fieldName: 'CPC',
                    value: '9ba83148d96c4d1bac176afcff65b078',
                  },
                  {
                    fieldName: 'PackageType',
                    value: 'P',
                  },
                  {
                    fieldName: 'PackageName',
                    value: 'Premier Advantage Package',
                  },
                ],
                id: 'j-hwNz3u',
              },
            },
            allIds: ['j-hwNz3u'],
            isFetching: false,
            isError: false,
          },
        },
        siriusSecuredlendingservicingV1: {
          eligibilities: {
            byId: {
              'j-hwNz3u': {
                status: 'Eligible',
                isFlexiLoan: true,
                failureReason: {
                  reason: 'CaseExists',
                  details: 'User case already exists',
                },
                id: 'j-hwNz3u',
              },
            },
            allIds: ['j-hwNz3u'],
            isFetching: false,
            isError: false,
          },
          arrangements: {
            byId: {
              ZiWtQhuAo: {
                currentBalance: { amount: '300000', position: 'DR' },
                availableBalance: { amount: '300000', position: 'CR' },
                discounts: ['0.48'],
                variableInterestRate: '4.20',
                loanMaturityDate: '23 Jan 2052',
                repaymentType: 'IO',
                interestOnlyMaturityDate: '01 Dec 2018',
                monthlyRepayment: '1400',
                redrawIndicatorSet: false,
                remainingTermPIF: '186',
                remainingTermIO: '11',
                productName: 'flexi',
                loanLimit: '1223',
                id: 'ZiWtQhuAo',
              },
            },
            allIds: ['ZiWtQhuAo'],
            isFetching: false,
            isError: false,
          },
          quotes: {
            byId: {
              '6aZvBOo5': {
                isDiscountApplicable: false,
                isDiscretionaryDiscount: false,
                discountRate: '0.20',
                interestRate: '1.22',
                yearTerm: '1',
                switchedProductName: 'Fixed Rate Investment Property Loan 1',

                id: '6aZvBOo5',
              },
              'ybppcQX-D': {
                isDiscountApplicable: false,
                isDiscretionaryDiscount: false,
                discountRate: '0.17',
                interestRate: '4.2',
                yearTerm: '2',
                switchedProductName: 'Fixed Rate Investment Property Loan 2',

                id: 'ybppcQX-D',
              },
              HUFDVOAv7: {
                isDiscountApplicable: false,
                isDiscretionaryDiscount: false,
                discountRate: '0.40',
                interestRate: '3.95',
                yearTerm: '3',
                switchedProductName: 'Fixed Rate Investment Property Loan 3',

                id: 'HUFDVOAv7',
              },
              '5oWf2qazV': {
                isDiscountApplicable: false,
                isDiscretionaryDiscount: false,
                discountRate: '0.90',
                interestRate: '5.22',
                yearTerm: '4',
                switchedProductName: 'Fixed Rate Investment Property Loan 4',

                id: '5oWf2qazV',
              },
              evhaaurcr: {
                isDiscountApplicable: true,
                isDiscretionaryDiscount: true,
                discountRate: '0.20',
                interestRate: '3.22',
                yearTerm: '5',
                switchedProductName: 'Fixed Rate Investment Property Loan 5',

                id: 'evhaaurcr',
              },
            },
            allIds: [
              '6aZvBOo5',
              'ybppcQX-D',
              'HUFDVOAv7',
              '5oWf2qazV',
              'evhaaurcr',
            ],
            isFetching: false,
            isError: false,
          },
        },
      },
    },
    {
      config: {
        brandId: 'WBC',
      },
      ui: {
        securedLendingServicing: {
          app: {
            headerBackNavigate: 'CHANNEL',
            showHidePopUp: false,
            selectedYearTerm: '3',
            discountRate: '0.4',
            selectedInterestRateForTerm: '3.96',
            alertBoxMessage:
              'The terms offered are within your interest only period. Switching to Principal and interest repayments may offer longer terms',
            selectedRepaymentType: 'IO',
          },
        },
      },
      entities: {
        siriusCoreV1: {
          contexts: {
            byId: {
              'j-hwNz3u': {
                fields: [
                  {
                    fieldName: 'accountNumber',
                    value: '034017161770',
                  },
                  {
                    fieldName: 'CPC',
                    value: '9ba83148d96c4d1bac176afcff65b078',
                  },
                  {
                    fieldName: 'PackageType',
                    value: 'P',
                  },
                  {
                    fieldName: 'PackageName',
                    value: 'Premier Advantage Package',
                  },
                ],
                id: 'j-hwNz3u',
              },
            },
            allIds: ['j-hwNz3u'],
            isFetching: false,
            isError: false,
          },
        },
        siriusSecuredlendingservicingV1: {
          eligibilities: {
            byId: {
              'j-hwNz3u': {
                status: 'Eligible',
                isFlexiLoan: true,
                failureReason: {
                  reason: 'CaseExists',
                  details: 'User case already exists',
                },
                id: 'j-hwNz3u',
              },
            },
            allIds: ['j-hwNz3u'],
            isFetching: false,
            isError: false,
          },
          arrangements: {
            byId: {
              ZiWtQhuAo: {
                currentBalance: { amount: '300000', position: 'DR' },
                availableBalance: { amount: '300000', position: 'CR' },
                discounts: ['0.48'],
                variableInterestRate: '4.20',
                loanMaturityDate: '23 Jan 2052',
                repaymentType: 'IO',
                interestOnlyMaturityDate: '01 Dec 2018',
                monthlyRepayment: '1400',
                redrawIndicatorSet: false,
                remainingTermPIF: '186',
                remainingTermIO: '110',
                productName: 'flexi',
                loanLimit: '1223',
                id: 'ZiWtQhuAo',
              },
            },
            allIds: ['ZiWtQhuAo'],
            isFetching: false,
            isError: false,
          },
          quotes: {
            byId: {
              '6aZvBOo5': {
                isDiscountApplicable: false,
                isDiscretionaryDiscount: false,
                discountRate: '0.20',
                interestRate: '1.22',
                yearTerm: '1',
                switchedProductName: 'Fixed Rate Investment Property Loan 1',

                id: '6aZvBOo5',
              },
              'ybppcQX-D': {
                isDiscountApplicable: false,
                isDiscretionaryDiscount: false,
                discountRate: '0.17',
                interestRate: '4.2',
                yearTerm: '2',
                switchedProductName: 'Fixed Rate Investment Property Loan 2',

                id: 'ybppcQX-D',
              },
              HUFDVOAv7: {
                isDiscountApplicable: false,
                isDiscretionaryDiscount: false,
                discountRate: '0.40',
                interestRate: '3.95',
                yearTerm: '3',
                switchedProductName: 'Fixed Rate Investment Property Loan 3',

                id: 'HUFDVOAv7',
              },
              '5oWf2qazV': {
                isDiscountApplicable: false,
                isDiscretionaryDiscount: false,
                discountRate: '0.90',
                interestRate: '5.22',
                yearTerm: '4',
                switchedProductName: 'Fixed Rate Investment Property Loan 4',

                id: '5oWf2qazV',
              },
              evhaaurcr: {
                isDiscountApplicable: true,
                isDiscretionaryDiscount: true,
                discountRate: '0.20',
                interestRate: '3.22',
                yearTerm: '5',
                switchedProductName: 'Fixed Rate Investment Property Loan 5',

                id: 'evhaaurcr',
              },
            },
            allIds: [
              '6aZvBOo5',
              'ybppcQX-D',
              'HUFDVOAv7',
              '5oWf2qazV',
              'evhaaurcr',
            ],
            isFetching: false,
            isError: false,
          },
        },
      },
    },
    {
      config: {
        brandId: 'WBC',
      },
      ui: {
        securedLendingServicing: {
          app: {
            headerBackNavigate: 'CHANNEL',
            showHidePopUp: false,
            selectedYearTerm: '3',
            discountRate: '0.4',
            selectedInterestRateForTerm: '3.96',
            alertBoxMessage:
              'The terms offered are within your interest only period. Switching to Principal and interest repayments may offer longer terms',
            selectedRepaymentType: 'IO',
          },
        },
      },
      entities: {
        siriusCoreV1: {
          contexts: {
            byId: {
              'j-hwNz3u': {
                fields: [
                  {
                    fieldName: 'accountNumber',
                    value: '034017161770',
                  },
                  {
                    fieldName: 'CPC',
                    value: '9ba83148d96c4d1bac176afcff65b078',
                  },
                  {
                    fieldName: 'PackageType',
                    value: 'P',
                  },
                  {
                    fieldName: 'PackageName',
                    value: 'Premier Advantage Package',
                  },
                ],
                id: 'j-hwNz3u',
              },
            },
            allIds: ['j-hwNz3u'],
            isFetching: false,
            isError: false,
          },
        },
        siriusSecuredlendingservicingV1: {
          eligibilities: {
            byId: {
              'j-hwNz3u': {
                status: 'NotEligible',
                isFlexiLoan: true,
                statusReason: {
                  code: 'CaseExists',
                  details: 'User case already exists',
                },
                id: 'j-hwNz3u',
              },
            },
            allIds: ['j-hwNz3u'],
            isFetching: false,
            isError: false,
          },
          arrangements: {
            byId: {
              ZiWtQhuAo: {
                currentBalance: { amount: '300000', position: 'DR' },
                availableBalance: { amount: '300000', position: 'CR' },
                discounts: ['0.48'],
                variableInterestRate: '4.20',
                loanMaturityDate: '23 Jan 2052',
                repaymentType: 'IO',
                interestOnlyMaturityDate: '01 Dec 2018',
                monthlyRepayment: '1400',
                redrawIndicatorSet: false,
                remainingTermPIF: '186',
                remainingTermIO: '110',
                productName: 'flexi',
                loanLimit: '1223',
                id: 'ZiWtQhuAo',
              },
            },
            allIds: ['ZiWtQhuAo'],
            isFetching: false,
            isError: false,
          },
          quotes: {
            byId: {
              '6aZvBOo5': {
                isDiscountApplicable: false,
                isDiscretionaryDiscount: false,
                discountRate: '0.20',
                interestRate: '1.22',
                yearTerm: '1',
                switchedProductName: 'Fixed Rate Investment Property Loan 1',

                id: '6aZvBOo5',
              },
              'ybppcQX-D': {
                isDiscountApplicable: false,
                isDiscretionaryDiscount: false,
                discountRate: '0.17',
                interestRate: '4.2',
                yearTerm: '2',
                switchedProductName: 'Fixed Rate Investment Property Loan 2',

                id: 'ybppcQX-D',
              },
              HUFDVOAv7: {
                isDiscountApplicable: false,
                isDiscretionaryDiscount: false,
                discountRate: '0.40',
                interestRate: '3.95',
                yearTerm: '3',
                switchedProductName: 'Fixed Rate Investment Property Loan 3',

                id: 'HUFDVOAv7',
              },
              '5oWf2qazV': {
                isDiscountApplicable: false,
                isDiscretionaryDiscount: false,
                discountRate: '0.90',
                interestRate: '5.22',
                yearTerm: '4',
                switchedProductName: 'Fixed Rate Investment Property Loan 4',

                id: '5oWf2qazV',
              },
              evhaaurcr: {
                isDiscountApplicable: true,
                isDiscretionaryDiscount: true,
                discountRate: '0.20',
                interestRate: '3.22',
                yearTerm: '5',
                switchedProductName: 'Fixed Rate Investment Property Loan 5',

                id: 'evhaaurcr',
              },
            },
            allIds: [
              '6aZvBOo5',
              'ybppcQX-D',
              'HUFDVOAv7',
              '5oWf2qazV',
              'evhaaurcr',
            ],
            isFetching: false,
            isError: false,
          },
        },
      },
    },
    {
      config: {
        brandId: 'WBC',
      },
      ui: {
        securedLendingServicing: {
          app: {
            submitAction: 'ERROR',
          },
        },
      },
      entities: {
        siriusSecuredlendingservicingV1: {
          arrangements: {
            byId: {},
            allIds: [],
            isFetching: false,
            isError: true,
          },
        },
      },
    },
    {
      config: {
        brandId: 'WBC',
      },
      ui: {
        securedLendingServicing: {
          app: {
            headerBackNavigate: 'CHANNEL',
            showHidePopUp: false,
            selectedInterestRateForTerm: '3.95',
            selectedYearTerm: '3',
            discountRate: '0.4',
            alertBoxMessage:
              'The terms offered are within your interest only period. Switching to Principal and interest repayments may offer longer terms',
            setFixedOptionRate: '',
            setInputValueData: '',
            selectedRepaymentType: 'IO',
            setRedrawShowHidePopup: '',
            redrawShowHidePopup: true,
            setRedrawModalTitle: '',
            redrawModalTitle: 'Redraw available funds',
            setRedrawModalButtonText: '',
            redrawModalButtonText: 'Next',
            setRedrawFundsAccounts: '',
            redrawFundAccountsList: [
              {
                label: 'Select an account',
                id: 0,
                value: '0',
              },
              {
                label: 'Westpac Saver4 505-124 549 889',
                id: 'QJD-E9uVx_',
                value: 'QJD-E9uVx_',
              },
              {
                label: 'Westpac Student Reward Saver 405-124 599 880',
                id: 'OvFBjvonSq',
                value: 'OvFBjvonSq',
              },
              {
                label: 'Westpac Student Reward Saver1 605-124 499 880',
                id: 'IpOWe6t6g',
                value: 'IpOWe6t6g',
              },
              {
                label: 'Westpac Student Reward Saver3 205-124 699 882',
                id: '_cnFGiK-w4',
                value: '_cnFGiK-w4',
              },
            ],
            setFieldSelectValue: '',
            selectedAccount: '_cnFGiK-w4',
            redrawAlertBoxMessage:
              'This transfer will only take place once you’ve submitted your request and it’s processed',
            splitFixedAmount: 2337.08,
            splitVariableAmount: '',
            fixedLoanBalance: 710000,
            variableLoanBalance: '',
            amountValidationMessage: '',
            submitAction: '',
            selectedLoanOption: 'RedrawFundsOption',
          },
        },
      },
      entities: {
        siriusCoreV1: {
          contexts: {
            byId: {
              '2r3h1GSjE': {
                fields: [
                  {
                    fieldName: 'accountNumber',
                    value: '034017161770',
                  },
                  {
                    fieldName: 'CPC',
                    value: '9ba83148d96c4d1bac176afcff65b078',
                  },
                  {
                    fieldName: 'PackageType',
                    value: 'P',
                  },
                  {
                    fieldName: 'PackageName',
                    value: 'Premier Advantage Package',
                  },
                ],
                packageType: 'F',
                packageName: 'Family Advantage Package',
                id: '2r3h1GSjE',
              },
            },
            allIds: ['2r3h1GSjE'],
            isFetching: false,
            isError: false,
          },
        },
        siriusSecuredlendingservicingV1: {
          eligibilities: {
            byId: {
              SVTxPKiWT: {
                status: 'Eligible',
                isFlexiLoan: false,
                statusReason: {
                  code: '',
                  details: '23 Jan 2032',
                },
                id: 'SVTxPKiWT',
              },
            },
            allIds: ['SVTxPKiWT'],
            isFetching: false,
            isError: false,
          },
          arrangements: {
            byId: {
              WJ_k5k_91s: {
                currentBalance: { amount: '700000', position: 'DR' },
                availableBalance: { amount: '10000', position: 'CR' },
                discounts: ['0.48'],
                variableInterestRate: '3.22',
                loanMaturityDate: '2031-07-25T00:00:00.000Z',
                repaymentType: 'IO',
                interestOnlyMaturityDate: '2030-12-16',
                monthlyRepayment: '2500.12',
                redrawIndicatorSet: true,
                loanLimit: '800000.32',
                productName: 'Rocket Repay Test',
                remainingTermPIF: '135',
                remainingTermIO: '135',
                nextPaymentDueDate: '2020-08-15',
                id: 'WJ_k5k_91s',
              },
            },
            allIds: ['WJ_k5k_91s'],
            isFetching: false,
            isError: false,
          },
          quotes: {
            byId: {
              '1E0ZxzbNA9': {
                quoteNumber: 'Q1111',
                isDiscountApplicable: true,
                isDiscretionaryDiscount: true,
                discountRate: '0.20',
                interestRate: '1.22',
                yearTerm: '1',
                LVRAdjustment: '1.3',
                switchedProductName: 'Fixed Rate Investment Property Loan 1',
                discounts: {
                  packageDiscount: '1.0',
                  extraDiscount: '0.0',
                  totalDiscount: '3.0',
                  switchedProductName: 'SwitchedProdName1',
                },
                id: '1E0ZxzbNA9',
              },
              '5iUxY1nTOm': {
                quoteNumber: 'Q1112',
                isDiscountApplicable: true,
                isDiscretionaryDiscount: true,
                discountRate: '0.30',
                interestRate: '4.2',
                yearTerm: '2',
                LVRAdjustment: '1.3',
                switchedProductName: 'Fixed Rate Investment Property Loan 1',
                discounts: {
                  packageDiscount: '1.0',
                  extraDiscount: '0.0',
                  totalDiscount: '3.0',
                  switchedProductName: 'SwitchedProdName2',
                },
                id: '5iUxY1nTOm',
              },
              B5CB25oVuw: {
                quoteNumber: 'Q1113',
                isDiscountApplicable: false,
                isDiscretionaryDiscount: false,
                discountRate: '0.40',
                interestRate: '3.95',
                yearTerm: '3',
                LVRAdjustment: '1.3',
                switchedProductName: 'Fixed Rate Investment Property Loan 1',
                discounts: {
                  packageDiscount: '1.0',
                  extraDiscount: '0.0',
                  totalDiscount: '3.0',
                  switchedProductName: 'SwitchedProdName2',
                },
                id: 'B5CB25oVuw',
              },
              J3KPguQxBS: {
                quoteNumber: 'Q1114',
                isDiscountApplicable: false,
                isDiscretionaryDiscount: false,
                discountRate: '0.90',
                interestRate: '5.22',
                yearTerm: '4',
                LVRAdjustment: '1.3',
                switchedProductName: 'Fixed Rate Investment Property Loan 1',
                discounts: {
                  packageDiscount: '1.0',
                  extraDiscount: '0.0',
                  totalDiscount: '3.0',
                  switchedProductName: 'SwitchedProdName3',
                },
                id: 'J3KPguQxBS',
              },
              LRakL4Msht: {
                quoteNumber: 'Q1115',
                isDiscountApplicable: true,
                isDiscretionaryDiscount: true,
                discountRate: '0.20',
                interestRate: '3.22',
                yearTerm: '5',
                LVRAdjustment: '1.3',
                switchedProductName: 'Fixed Rate Investment Property Loan 1',
                discounts: {
                  packageDiscount: '1.0',
                  extraDiscount: '0.0',
                  totalDiscount: '3.0',
                  switchedProductName: 'SwitchedProdName4',
                },
                id: 'LRakL4Msht',
              },
            },
            allIds: [
              '1E0ZxzbNA9',
              '5iUxY1nTOm',
              'B5CB25oVuw',
              'J3KPguQxBS',
              'LRakL4Msht',
            ],
            isFetching: false,
            isError: false,
          },
          redrawAccounts: {
            byId: {
              IpOWe6t6g: {
                accountName: 'Westpac Student Reward Saver1',
                accountId: {
                  accountNumber: '499 880',
                  BSB: '605-124',
                },
                id: 'IpOWe6t6g',
              },
              OvFBjvonSq: {
                accountName: 'Westpac Student Reward Saver',
                accountId: {
                  accountNumber: '599 880',
                  BSB: '405-124',
                },
                id: 'OvFBjvonSq',
              },
              '_cnFGiK-w4': {
                accountName: 'Westpac Student Reward Saver3',
                accountId: {
                  accountNumber: '699 882',
                  BSB: '205-124',
                },
                id: '_cnFGiK-w4',
              },
              'QJD-E9uVx_': {
                accountName: 'Westpac Saver4',
                accountId: {
                  accountNumber: '549 889',
                  BSB: '505-124',
                },
                id: 'QJD-E9uVx_',
              },
            },
            allIds: ['IpOWe6t6g', 'OvFBjvonSq', '_cnFGiK-w4', 'QJD-E9uVx_'],
            isFetching: false,
            isError: false,
          },
        },
      },
    },
    {
      config: {
        brandId: 'WBC',
      },
      ui: {
        securedLendingServicing: {
          app: {
            headerBackNavigate: 'CHANNEL',
            showHidePopUp: false,
            selectedYearTerm: '',
            discountRate: '',
            selectedInterestRateForTerm: '',
            alertBoxMessage: '',
            selectedRepaymentType: '',
          },
        },
      },
      entities: {
        siriusCoreV1: {
          contexts: {
            byId: {
              'j-hwNz3u': {
                fields: [
                  {
                    fieldName: 'accountNumber',
                    value: '034017161770',
                  },
                  {
                    fieldName: 'CPC',
                    value: '9ba83148d96c4d1bac176afcff65b078',
                  },
                  {
                    fieldName: 'PackageType',
                    value: 'P',
                  },
                  {
                    fieldName: 'PackageName',
                    value: 'Premier Advantage Package',
                  },
                ],
                id: 'j-hwNz3u',
              },
            },
            allIds: ['j-hwNz3u'],
            isFetching: false,
            isError: false,
          },
        },
        siriusSecuredlendingservicingV1: {
          eligibilities: {
            byId: {
              'j-hwNz3u': {
                status: 'Eligible',
                isFlexiLoan: true,
                failureReason: {
                  reason: 'CaseExists',
                  details: 'User case already exists',
                },
                id: 'j-hwNz3u',
              },
            },
            allIds: ['j-hwNz3u'],
            isFetching: false,
            isError: false,
          },
          arrangements: {
            byId: {
              ZiWtQhuAo: {
                currentBalance: { amount: '300000', position: 'DR' },
                availableBalance: { amount: '300000', position: 'CR' },
                discounts: ['0.48'],
                variableInterestRate: '4.20',
                loanMaturityDate: '23 Jan 2052',
                repaymentType: 'IO',
                interestOnlyMaturityDate: '01 Dec 2018',
                monthlyRepayment: '1400',
                redrawIndicatorSet: false,
                loanLimit: '1223',
                remainingTermPIF: '123',
                remainingTermIO: '123',
                productName: 'flexi',
                id: 'ZiWtQhuAo',
              },
            },
            allIds: ['ZiWtQhuAo'],
            isFetching: false,
            isError: false,
          },
        },
      },
    },
    {
      config: {
        brandId: 'WBC',
      },
      ui: {
        securedLendingServicing: {
          app: {
            headerBackNavigate: 'CHANNEL',
            showHidePopUp: false,
            selectedYearTerm: '3',
            discountRate: '0.4',
            selectedInterestRateForTerm: '3.96',
            alertBoxMessage:
              'The terms offered are within your interest only period. Switching to Principal and interest repayments may offer longer terms',
            selectedRepaymentType: 'IO',
            submitAction: 'SUCCESS',
          },
        },
      },
      entities: {
        siriusCoreV1: {
          contexts: {
            byId: {
              'j-hwNz3u': {
                fields: [
                  {
                    fieldName: 'accountNumber',
                    value: '034017161770',
                  },
                  {
                    fieldName: 'CPC',
                    value: '9ba83148d96c4d1bac176afcff65b078',
                  },
                  {
                    fieldName: 'PackageType',
                    value: 'P',
                  },
                  {
                    fieldName: 'PackageName',
                    value: 'Premier Advantage Package',
                  },
                ],
                id: 'j-hwNz3u',
              },
            },
            allIds: ['j-hwNz3u'],
            isFetching: false,
            isError: false,
          },
        },
        siriusSecuredlendingservicingV1: {
          arrangements: {
            byId: {},
            allIds: [],
            isFetching: true,
            isError: false,
          },

          eligibilities: {
            byId: {},
            allIds: [],
            isFetching: false,
            isError: false,
          },
        },
      },
    },
    {
      config: {
        brandId: 'WBC',
      },
      ui: {
        securedLendingServicing: {
          app: {
            headerBackNavigate: 'CHANNEL',
            showHidePopUp: false,
            selectedYearTerm: '3',
            discountRate: '0.4',
            selectedInterestRateForTerm: '3.96',
            alertBoxMessage:
              'The terms offered are within your interest only period. Switching to Principal and interest repayments may offer longer terms',
            selectedRepaymentType: 'IO',
            quotesError: 'PRICING',
          },
        },
      },
      entities: {
        siriusCoreV1: {
          contexts: {
            byId: {
              'j-hwNz3u': {
                fields: [
                  {
                    fieldName: 'accountNumber',
                    value: '034017161770',
                  },
                  {
                    fieldName: 'CPC',
                    value: '9ba83148d96c4d1bac176afcff65b078',
                  },
                  {
                    fieldName: 'PackageType',
                    value: 'P',
                  },
                  {
                    fieldName: 'PackageName',
                    value: 'Premier Advantage Package',
                  },
                ],
                id: 'j-hwNz3u',
              },
            },
            allIds: ['j-hwNz3u'],
            isFetching: false,
            isError: false,
          },
        },
        siriusSecuredlendingservicingV1: {
          eligibilities: {
            byId: {
              'j-hwNz3u': {
                status: 'NotEligible',
                isFlexiLoan: true,
                statusReason: {
                  code: 'CaseExists',
                  details: 'User case already exists',
                },
                id: 'j-hwNz3u',
              },
            },
            allIds: ['j-hwNz3u'],
            isFetching: false,
            isError: false,
          },
          arrangements: {
            byId: {
              ZiWtQhuAo: {
                currentBalance: { amount: '300000', position: 'DR' },
                availableBalance: { amount: '300000', position: 'CR' },
                discounts: ['0.48'],
                variableInterestRate: '4.20',
                loanMaturityDate: '23 Jan 2052',
                repaymentType: 'IO',
                interestOnlyMaturityDate: '01 Dec 2018',
                monthlyRepayment: '1400',
                redrawIndicatorSet: false,
                remainingTermPIF: '186',
                remainingTermIO: '110',
                productName: 'flexi',
                loanLimit: '1223',
                id: 'ZiWtQhuAo',
              },
            },
            allIds: ['ZiWtQhuAo'],
            isFetching: false,
            isError: false,
          },
          quotes: {
            byId: {},
            allIds: [],
            isFetching: false,
            isError: false,
          },
        },
      },
    },
  ],
  invalid: [],
};
