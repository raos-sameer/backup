export const mockStoreData = {
  valid: [
    {
      config: {
        brandId: 'WBC',
      },
      ui: {
        securedLendingServicing: {
          app: {
            headerBackNavigate: 'CHANNEL',
          },
        },
      },
    },
    {
      config: {
        brandId: 'STG',
      },
      ui: {
        securedLendingServicing: {
          app: {
            headerBackNavigate: 'OTHER',
          },
        },
      },
    },
  ],
};
