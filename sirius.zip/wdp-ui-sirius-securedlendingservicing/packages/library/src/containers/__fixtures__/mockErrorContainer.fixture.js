export const mockStoreData = {
  valid: [
    {
      config: {
        brandId: 'STG',
      },
      securedlendingservicing: {
        ui: {
          app: {
            headerBackNavigate: 'CHANNEL',
            headerTitle: 'Test',
          },
        },
      },
    },
  ],
  invalid: [],
};
