export const mockStoreData = {
  valid: [
    {
      config: {
        brandId: 'WBC',
        securedlendingservicing: {
          switchingFee: '500',
          additionalPaymentAmount: '30,000',
          monthlyMaintainenceFee: '8',
          directDebitUrlInterestOnly: {
            STG:
              'https://www.stgeorge.com.au/content/dam/public/wbc/documents/pdf/pb/Direct_Debit_Request_Interest_Only_Loan_Repayment.pdf',
            BOM:
              'https://www.bankofmelbourne.com.au/content/dam/public/wbc/documents/pdf/pb/Direct_Debit_Request_Interest_Only_Loan_Repayment.pdf',
            BSA:
              'https://www.banksa.com.au/content/dam/public/wbc/documents/pdf/pb/Direct_Debit_Request_Interest_Only_Loan_Repayment.pdf',
            WBC:
              'https://www.westpac.com.au/content/dam/public/wbc/documents/pdf/pb/Direct_Debit_Request_Interest_Only_Loan_Repayment.pdf',
          },
          directDebitUrlPrincipalInterest: {
            STG:
              'https://www.stgeorge.com.au/content/dam/public/wbc/documents/pdf/pb/Direct_Debit_Request_Loan_Repayment.pdf',
            BOM:
              'https://www.bankofmelbourne.com.au/content/dam/public/wbc/documents/pdf/pb/Direct_Debit_Request_Loan_Repayment.pdf',
            BSA:
              'https://www.banksa.com.au/content/dam/public/wbc/documents/pdf/pb/Direct_Debit_Request_Loan_Repayment.pdf',
            WBC:
              'https://www.westpac.com.au/content/dam/public/wbc/documents/pdf/pb/Direct_Debit_Request_Loan_Repayment.pdf',
          },
        },
      },
      ui: {
        securedLendingServicing: {
          app: {
            headerBackNavigate: 'CHANNEL',
            showHidePopUp: false,
            selectedYearTerm: '3',
            selectedInterestRateForTerm: '3.96',
            alertBoxMessage:
              'The terms offered are within your interest only period. Switching to Principal and interest repayments may offer longer terms',
            redrawAlertBoxMessage:
              'The terms offered are within your interest only period. Switching to Principal and interest repayments may offer longer terms',
            selectedRepaymentType: 'IO',
            selectedLoanOption: 'SplitLoanOption',
            inputAmountData: '29000',
          },
        },
      },
      entities: {
        siriusCoreV1: {
          contexts: {
            byId: {
              'j-hwNz3u': {
                fields: [
                  {
                    fieldName: 'accountNumber',
                    value: '034017161770',
                  },
                  {
                    fieldName: 'CPC',
                    value: '9ba83148d96c4d1bac176afcff65b078',
                  },
                  {
                    fieldName: 'PackageType',
                    value: 'P',
                  },
                  {
                    fieldName: 'PackageName',
                    value: 'Premier Advantage Package',
                  },
                ],
                id: 'j-hwNz3u',
              },
            },
            allIds: ['j-hwNz3u'],
            isFetching: false,
            isError: false,
          },
        },
        siriusSecuredlendingservicingV1: {
          eligibilities: {
            byId: {
              'j-hwNz3u': {
                status: 'Eligible',
                isFlexiLoan: true,
                failureReason: {
                  reason: 'CaseExists',
                  details: 'User case already exists',
                },
                id: 'j-hwNz3u',
              },
            },
            allIds: ['j-hwNz3u'],
            isFetching: false,
            isError: false,
          },
          arrangements: {
            byId: {
              ZiWtQhuAo: {
                currentBalance: { amount: '320000', position: 'DR' },
                availableBalance: { amount: '300000', position: 'CR' },

                variableInterestRate: '4.20',
                loanMaturityDate: '23 Jan 2052',
                repaymentType: 'IO',
                interestOnlyMaturityDate: '01 Dec 2018',
                monthlyRepayment: '1400',
                redrawIndicatorSet: false,
                remainingTermPIF: '186',
                remainingTermIO: '0',
                nextPaymentDueDate: '23 Jan 2032',
                productName: 'flexi',
                loanLimit: '1223',
                id: 'ZiWtQhuAo',
              },
            },
            allIds: ['ZiWtQhuAo'],
            isFetching: false,
            isError: false,
          },
        },
      },
    },
    {
      config: {
        brandId: 'WBC',
        securedlendingservicing: {
          switchingFee: '500',
          additionalPaymentAmount: '30,000',
          monthlyMaintainenceFee: '8',
          directDebitUrlInterestOnly: {
            STG:
              'https://www.stgeorge.com.au/content/dam/public/wbc/documents/pdf/pb/Direct_Debit_Request_Interest_Only_Loan_Repayment.pdf',
            BOM:
              'https://www.bankofmelbourne.com.au/content/dam/public/wbc/documents/pdf/pb/Direct_Debit_Request_Interest_Only_Loan_Repayment.pdf',
            BSA:
              'https://www.banksa.com.au/content/dam/public/wbc/documents/pdf/pb/Direct_Debit_Request_Interest_Only_Loan_Repayment.pdf',
            WBC:
              'https://www.westpac.com.au/content/dam/public/wbc/documents/pdf/pb/Direct_Debit_Request_Interest_Only_Loan_Repayment.pdf',
          },
          directDebitUrlPrincipalInterest: {
            STG:
              'https://www.stgeorge.com.au/content/dam/public/wbc/documents/pdf/pb/Direct_Debit_Request_Loan_Repayment.pdf',
            BOM:
              'https://www.bankofmelbourne.com.au/content/dam/public/wbc/documents/pdf/pb/Direct_Debit_Request_Loan_Repayment.pdf',
            BSA:
              'https://www.banksa.com.au/content/dam/public/wbc/documents/pdf/pb/Direct_Debit_Request_Loan_Repayment.pdf',
            WBC:
              'https://www.westpac.com.au/content/dam/public/wbc/documents/pdf/pb/Direct_Debit_Request_Loan_Repayment.pdf',
          },
        },
      },
      ui: {
        securedLendingServicing: {
          app: {
            headerBackNavigate: 'CHANNEL',
            showHidePopUp: false,
            selectedYearTerm: '3',
            inputAmountData: '16000',
            selectedInterestRateForTerm: '3.96',
            alertBoxMessage:
              'The terms offered are within your interest only period. Switching to Principal and interest repayments may offer longer terms',
            selectedRepaymentType: 'PIF',
          },
        },
      },
      entities: {
        siriusCoreV1: {
          contexts: {
            byId: {
              'j-hwNz3u': {
                fields: [
                  {
                    fieldName: 'accountNumber',
                    value: '034017161770',
                  },
                  {
                    fieldName: 'CPC',
                    value: '9ba83148d96c4d1bac176afcff65b078',
                  },
                  {
                    fieldName: 'PackageType',
                    value: 'P',
                  },
                  {
                    fieldName: 'PackageName',
                    value: 'Premier Advantage Package',
                  },
                ],
                id: 'j-hwNz3u',
              },
            },
            allIds: ['j-hwNz3u'],
            isFetching: false,
            isError: false,
          },
        },
        siriusSecuredlendingservicingV1: {
          arrangements: {
            byId: {
              ZiWtQhuAo: {
                currentBalance: { amount: '300000', position: 'DR' },
                availableBalance: { amount: '', position: 'CR' },
                variableInterestRate: '4.20',
                loanMaturityDate: '23 Jan 2052',
                repaymentType: 'PIF',
                interestOnlyMaturityDate: '01 Dec 2018',
                monthlyRepayment: '1400',
                redrawIndicatorSet: true,
                remainingTermPIF: '186',
                remainingTermIO: '110',
                nextPaymentDueDate: '23 Jan 2032',
                productName: 'flexi',
                loanLimit: '1223',
                id: 'ZiWtQhuAo',
              },
            },
            allIds: ['ZiWtQhuAo'],
            isFetching: false,
            isError: false,
          },
        },
      },
    },
    {
      user: {
        user: null,
        isLoadingUser: false,
      },
      config: {
        isLoading: false,
        appName: 'securedlendingservicing',
        appId: 'au.com.westpac.ui.www1-sirius',
        appVersion: '1.0.0',
        brandId: 'WBC',
        xChannelType: 'Internal',
        apiBaseUrl: 'http://localhost:8080',
        api: {
          basePath: {
            'exp-sirius-securedlendingservicing-v1':
              '/exp/sirius/securedlendingservicing/v1/',
          },
        },
        analytics: {
          seedFiles: {
            BOM: '/static/scripts/analytics/1.0.6/WBC/analytics_wdp.js',
            BSA: '/static/scripts/analytics/1.0.6/WBC/analytics_wdp.js',
            STG: '/static/scripts/analytics/1.0.6/WBC/analytics_wdp.js',
            WBC: '/static/scripts/analytics/1.0.6/WBC/analytics_wdp.js',
          },
          channel: 'digital',
          journeyType: 'auth',
          trackOnce: 'true',
          siteEnv: 'test',
          siteName: 'banking',
          siteSection: 'sirius',
        },
        securedlendingservicing: {
          switchingFee: '500',
          additionalPaymentAmount: '30,000',
          monthlyMaintainenceFee: '8',
          dashboardUrl: {
            STG:
              'https://vp1ibank.stgeorge.com.au/services/wdpToCompass?actionType=dashboard',
            BOM:
              'https://vp1ibank.bankofmelbourne.com.au/services/wdpToCompass?actionType=dashboard',
            BSA:
              'https://vp1ibank.banksa.com.au/services/wdpToCompass?actionType=dashboard',
            WBC:
              'https://vp1ibank.stgeorge.com.au/services/wdpToCompass?actionType=dashboard',
          },
          footerInfoSecurityUrl: {
            STG:
              'https://webapps.stgeorge.com.au/apply-now/acc_help.asp#security?view=oaf',
            BOM:
              'https://webapps.bankofmelbourne.com.au/apply-now/acc_help.asp#security?view=oaf',
            BSA:
              'https://webapps.banksa.com.au/apply-now/acc_help.asp#security?view=oaf',
            WBC:
              'https://webapps.stgeorge.com.au/apply-now/acc_help.asp#security?view=oaf',
          },
          conditionsOfUseUrl: {
            STG:
              'https://www.stgeorge.com.au/content/dam/public/wbc/documents/pdf/pb/PAP_ConditionsofUse.pdf',
            BOM:
              'https://www.bankofmelbourne.com.au/content/dam/public/wbc/documents/pdf/pb/PAP_ConditionsofUse.pdf',
            BSA:
              'https://www.banksa.com.au/content/dam/public/wbc/documents/pdf/pb/PAP_ConditionsofUse.pdf',
            WBC:
              'https://www.westpac.com.au/content/dam/public/wbc/documents/pdf/pb/PAP_ConditionsofUse.pdf',
          },
          messageInboxUrl: {
            STG:
              'https://www.stgeorge.com.au/content/dam/public/wbc/documents/pdf/pb/PAP_ConditionsofUse.pdf',
            BOM:
              'https://www.bankofmelbourne.com.au/content/dam/public/wbc/documents/pdf/pb/PAP_ConditionsofUse.pdf',
            BSA:
              'https://www.banksa.com.au/content/dam/public/wbc/documents/pdf/pb/PAP_ConditionsofUse.pdf',
            WBC:
              'https://www.westpac.com.au/content/dam/public/wbc/documents/pdf/pb/PAP_ConditionsofUse.pdf',
          },
          directDebitUrlInterestOnly: {
            STG:
              'https://www.stgeorge.com.au/content/dam/public/wbc/documents/pdf/pb/Direct_Debit_Request_Interest_Only_Loan_Repayment.pdf',
            BOM:
              'https://www.bankofmelbourne.com.au/content/dam/public/wbc/documents/pdf/pb/Direct_Debit_Request_Interest_Only_Loan_Repayment.pdf',
            BSA:
              'https://www.banksa.com.au/content/dam/public/wbc/documents/pdf/pb/Direct_Debit_Request_Interest_Only_Loan_Repayment.pdf',
            WBC:
              'https://www.westpac.com.au/content/dam/public/wbc/documents/pdf/pb/Direct_Debit_Request_Interest_Only_Loan_Repayment.pdf',
          },
          directDebitUrlPrincipalInterest: {
            STG:
              'https://www.stgeorge.com.au/content/dam/public/wbc/documents/pdf/pb/Direct_Debit_Request_Loan_Repayment.pdf',
            BOM:
              'https://www.bankofmelbourne.com.au/content/dam/public/wbc/documents/pdf/pb/Direct_Debit_Request_Loan_Repayment.pdf',
            BSA:
              'https://www.banksa.com.au/content/dam/public/wbc/documents/pdf/pb/Direct_Debit_Request_Loan_Repayment.pdf',
            WBC:
              'https://www.westpac.com.au/content/dam/public/wbc/documents/pdf/pb/Direct_Debit_Request_Loan_Repayment.pdf',
          },
          breakCostUrl: {
            STG:
              'https://www.stgeorge.com.au/content/dam/public/wbc/documents/pdf/pb/WBC-things-you-should-know-about-break-costs.pdf?appAction=PDF',
            BOM:
              'https://www.bankofmelbourne.com.au/dam/public/wbc/documents/pdf/pb/WBC-things-you-should-know-about-break-costs.pdf?appAction=PDF',
            BSA:
              'https://www.banksa.com.au/dam/public/wbc/documents/pdf/pb/WBC-things-you-should-know-about-break-costs.pdf?appAction=PDF',
            WBC:
              'https://www.westpac.com.au/content/dam/public/wbc/documents/pdf/pb/WBC-things-you-should-know-about-break-costs.pdf?appAction=PDF',
          },
          brandNames: {
            STG: {
              name: 'St. George',
              ariaLabel: 'Saint George',
            },
            BOM: {
              name: 'Bank Of Melbourne',
              ariaLabel: 'Bank Of Melbourne',
            },
            BSA: {
              name: 'BankSA',
              ariaLabel: 'Bank S A',
            },
            WBC: {
              name: 'Westpac',
              ariaLabel: 'Westpac',
            },
          },
        },
        appCorrelationId: 'YRC28nOk',
        isMicroAppLoading: false,
        isMicroAppError: false,
      },
      analytics: {
        analyticsEnabled: false,
      },
      entities: {
        siriusCoreV1: {
          contexts: {
            byId: {
              'j-hwNz3u': {
                fields: [
                  {
                    fieldName: 'accountNumber',
                    value: '034017161770',
                  },
                  {
                    fieldName: 'CPC',
                    value: '9ba83148d96c4d1bac176afcff65b078',
                  },
                  {
                    fieldName: 'PackageType',
                    value: 'P',
                  },
                  {
                    fieldName: 'PackageName',
                    value: 'Premier Advantage Package',
                  },
                ],
                id: 'j-hwNz3u',
              },
            },
            allIds: ['j-hwNz3u'],
            isFetching: false,
            isError: false,
          },
        },
        siriusSecuredlendingservicingV1: {
          eligibilities: {
            byId: {
              'j-hwNz3u': {
                status: 'Eligible',
                isFlexiLoan: true,
                failureReason: {
                  reason: 'CaseExists',
                  details: 'User case already exists',
                },
                id: 'j-hwNz3u',
              },
            },
            allIds: ['j-hwNz3u'],
            isFetching: false,
            isError: false,
          },
          arrangements: {
            byId: {
              ZiWtQhuAo: {
                currentBalance: { amount: '300000', position: 'DR' },
                availableBalance: { amount: '300000', position: 'CR' },
                variableInterestRate: '4.20',
                loanMaturityDate: '23 Jan 2052',
                repaymentType: 'IO',
                interestOnlyMaturityDate: '01 Dec 2018',
                monthlyRepayment: '1400',
                redrawIndicatorSet: true,
                loanLimit: '1223',
                remainingTermPIF: '186',
                remainingTermIO: '110',
                nextPaymentDueDate: '23 Jan 2032',
                productName: 'flexi',
                id: 'ZiWtQhuAo',
              },
            },
            allIds: ['ZiWtQhuAo'],
            isFetching: false,
            isError: false,
          },
          quotes: {
            byId: {
              '6aZvBOo5': {
                isDiscountApplicable: false,
                isDiscretionaryDiscount: false,
                discountRate: '0.20',
                interestRate: '1.22',
                yearTerm: '1',
                switchedProductName: 'Fixed Rate Investment Property Loan 1',
                id: '6aZvBOo5',
              },
              'ybppcQX-D': {
                isDiscountApplicable: false,
                isDiscretionaryDiscount: false,
                discountRate: '0.17',
                interestRate: '4.2',
                switchedProductName: 'Fixed Rate Investment Property Loan 2',
                yearTerm: '2',
                id: 'ybppcQX-D',
              },
              HUFDVOAv7: {
                isDiscountApplicable: false,
                isDiscretionaryDiscount: false,
                discountRate: '0.40',
                interestRate: '3.95',
                yearTerm: '3',
                switchedProductName: 'Fixed Rate Investment Property Loan 3',
                id: 'HUFDVOAv7',
              },
              '5oWf2qazV': {
                isDiscountApplicable: false,
                isDiscretionaryDiscount: false,
                discountRate: '0.90',
                interestRate: '5.22',
                yearTerm: '4',
                switchedProductName: 'Fixed Rate Investment Property Loan 4',
                id: '5oWf2qazV',
              },
              evhaaurcr: {
                isDiscountApplicable: true,
                isDiscretionaryDiscount: true,
                discountRate: '0.20',
                interestRate: '3.22',
                yearTerm: '5',
                switchedProductName: 'Fixed Rate Investment Property Loan 5',
                id: 'evhaaurcr',
              },
            },
            allIds: [
              '6aZvBOo5',
              'ybppcQX-D',
              'HUFDVOAv7',
              '5oWf2qazV',
              'evhaaurcr',
            ],
            isFetching: false,
            isError: false,
          },
          redrawAccounts: {
            byId: {
              '605124499880': {
                productLongName: 'WestPac Choice 1',
                id: '605124499880',
              },
              '405124599880': {
                productLongName: 'WestPac Choice 2',
                id: '405124599880',
              },
              '205124699882': {
                productLongName: 'WestPac Choice 3',

                id: '205124699882',
              },
              '505124549889': {
                productLongName: 'WestPac Choice 4',

                id: '505124549889',
              },
            },
            allIds: [
              '605124499880',
              '405124599880',
              '205124699882',
              '505124549889',
            ],
            isFetching: false,
            isError: false,
          },
        },
      },
      ui: {
        securedLendingServicing: {
          app: {
            headerBackNavigate: 'PREVIOUS',
            showHidePopUp: false,
            selectedInterestRateForTerm: '4.2',
            selectedYearTerm: '2',
            alertBoxMessage:
              'The terms offered are within your interest only period. Switching to Principal and interest repayments may offer longer terms',
            setFixedOptionRate: '',
            setInputValueData: '',
            selectedRepaymentType: 'IO',
            setRedrawShowHidePopup: '',
            redrawShowHidePopup: false,
            setRedrawModalTitle: '',
            redrawModalTitle: 'Redraw available funds',
            setRedrawModalButtonText: '',
            redrawModalButtonText: 'Next',
            setRedrawFundsAccounts: '',
            redrawFundAccountsList: [
              {
                label: 'Select an account',
                id: 0,
                value: '0',
              },
              {
                label: 'WestPac Choice 1 123-415 11223344',
                id: '6aZvBOo5',
                value: '6aZvBOo5',
              },
              {
                label: 'WestPac Choice 2 123-415 11223345',
                id: 'ybppcQX-D',
                value: 'ybppcQX-D',
              },
              {
                label: 'WestPac Choice 3 123-415 11223346',
                id: 'HUFDVOAv7',
                value: 'HUFDVOAv7',
              },
              {
                label: 'WestPac Choice 4 123-415 11223344',
                id: '5oWf2qazV',
                value: '5oWf2qazV',
              },
              {
                label: 'WestPac Choice 5 123-415 11223344',
                id: 'evhaaurcr',
                value: 'evhaaurcr',
              },
            ],
            setFieldSelectValue: '',
            selectedAccount: '',
            selectedLoanOption: 'RedrawFundsOption',
          },
        },
      },
    },
    {
      user: {
        user: null,
        isLoadingUser: false,
      },
      config: {
        isLoading: false,
        appName: 'securedlendingservicing',
        appId: 'au.com.westpac.ui.www1-sirius',
        appVersion: '1.0.0',
        brandId: 'WBC',
        xChannelType: 'Internal',
        apiBaseUrl: 'http://localhost:8080',
        api: {
          basePath: {
            'exp-sirius-securedlendingservicing-v1':
              '/exp/sirius/securedlendingservicing/v1/',
          },
        },
        analytics: {
          seedFiles: {
            BOM: '/static/scripts/analytics/1.0.6/WBC/analytics_wdp.js',
            BSA: '/static/scripts/analytics/1.0.6/WBC/analytics_wdp.js',
            STG: '/static/scripts/analytics/1.0.6/WBC/analytics_wdp.js',
            WBC: '/static/scripts/analytics/1.0.6/WBC/analytics_wdp.js',
          },
          channel: 'digital',
          journeyType: 'auth',
          trackOnce: 'true',
          siteEnv: 'test',
          siteName: 'banking',
          siteSection: 'sirius',
        },
        securedlendingservicing: {
          switchingFee: '500',
          additionalPaymentAmount: '30,000',
          monthlyMaintainenceFee: '8',
          dashboardUrl: {
            STG:
              'https://vp1ibank.stgeorge.com.au/services/wdpToCompass?actionType=dashboard',
            BOM:
              'https://vp1ibank.bankofmelbourne.com.au/services/wdpToCompass?actionType=dashboard',
            BSA:
              'https://vp1ibank.banksa.com.au/services/wdpToCompass?actionType=dashboard',
            WBC:
              'https://vp1ibank.stgeorge.com.au/services/wdpToCompass?actionType=dashboard',
          },
          footerInfoSecurityUrl: {
            STG:
              'https://webapps.stgeorge.com.au/apply-now/acc_help.asp#security?view=oaf',
            BOM:
              'https://webapps.bankofmelbourne.com.au/apply-now/acc_help.asp#security?view=oaf',
            BSA:
              'https://webapps.banksa.com.au/apply-now/acc_help.asp#security?view=oaf',
            WBC:
              'https://webapps.stgeorge.com.au/apply-now/acc_help.asp#security?view=oaf',
          },
          conditionsOfUseUrl: {
            STG:
              'https://www.stgeorge.com.au/content/dam/public/wbc/documents/pdf/pb/PAP_ConditionsofUse.pdf',
            BOM:
              'https://www.bankofmelbourne.com.au/content/dam/public/wbc/documents/pdf/pb/PAP_ConditionsofUse.pdf',
            BSA:
              'https://www.banksa.com.au/content/dam/public/wbc/documents/pdf/pb/PAP_ConditionsofUse.pdf',
            WBC:
              'https://www.westpac.com.au/content/dam/public/wbc/documents/pdf/pb/PAP_ConditionsofUse.pdf',
          },
          messageInboxUrl: {
            STG:
              'https://www.stgeorge.com.au/content/dam/public/wbc/documents/pdf/pb/PAP_ConditionsofUse.pdf',
            BOM:
              'https://www.bankofmelbourne.com.au/content/dam/public/wbc/documents/pdf/pb/PAP_ConditionsofUse.pdf',
            BSA:
              'https://www.banksa.com.au/content/dam/public/wbc/documents/pdf/pb/PAP_ConditionsofUse.pdf',
            WBC:
              'https://www.westpac.com.au/content/dam/public/wbc/documents/pdf/pb/PAP_ConditionsofUse.pdf',
          },
          directDebitUrlInterestOnly: {
            STG:
              'https://www.stgeorge.com.au/content/dam/public/wbc/documents/pdf/pb/Direct_Debit_Request_Interest_Only_Loan_Repayment.pdf',
            BOM:
              'https://www.bankofmelbourne.com.au/content/dam/public/wbc/documents/pdf/pb/Direct_Debit_Request_Interest_Only_Loan_Repayment.pdf',
            BSA:
              'https://www.banksa.com.au/content/dam/public/wbc/documents/pdf/pb/Direct_Debit_Request_Interest_Only_Loan_Repayment.pdf',
            WBC:
              'https://www.westpac.com.au/content/dam/public/wbc/documents/pdf/pb/Direct_Debit_Request_Interest_Only_Loan_Repayment.pdf',
          },
          directDebitUrlPrincipalInterest: {
            STG:
              'https://www.stgeorge.com.au/content/dam/public/wbc/documents/pdf/pb/Direct_Debit_Request_Loan_Repayment.pdf',
            BOM:
              'https://www.bankofmelbourne.com.au/content/dam/public/wbc/documents/pdf/pb/Direct_Debit_Request_Loan_Repayment.pdf',
            BSA:
              'https://www.banksa.com.au/content/dam/public/wbc/documents/pdf/pb/Direct_Debit_Request_Loan_Repayment.pdf',
            WBC:
              'https://www.westpac.com.au/content/dam/public/wbc/documents/pdf/pb/Direct_Debit_Request_Loan_Repayment.pdf',
          },
          breakCostUrl: {
            STG:
              'https://www.stgeorge.com.au/content/dam/public/wbc/documents/pdf/pb/WBC-things-you-should-know-about-break-costs.pdf?appAction=PDF',
            BOM:
              'https://www.bankofmelbourne.com.au/dam/public/wbc/documents/pdf/pb/WBC-things-you-should-know-about-break-costs.pdf?appAction=PDF',
            BSA:
              'https://www.banksa.com.au/dam/public/wbc/documents/pdf/pb/WBC-things-you-should-know-about-break-costs.pdf?appAction=PDF',
            WBC:
              'https://www.westpac.com.au/content/dam/public/wbc/documents/pdf/pb/WBC-things-you-should-know-about-break-costs.pdf?appAction=PDF',
          },
          brandNames: {
            STG: {
              name: 'St. George',
              ariaLabel: 'Saint George',
            },
            BOM: {
              name: 'Bank Of Melbourne',
              ariaLabel: 'Bank Of Melbourne',
            },
            BSA: {
              name: 'BankSA',
              ariaLabel: 'Bank S A',
            },
            WBC: {
              name: 'Westpac',
              ariaLabel: 'Westpac',
            },
          },
        },
        appCorrelationId: 'YRC28nOk',
        isMicroAppLoading: false,

        isMicroAppError: false,
      },
      analytics: {
        analyticsEnabled: false,
      },
      entities: {
        siriusCoreV1: {
          contexts: {
            byId: {
              'j-hwNz3u': {
                fields: [
                  {
                    fieldName: 'accountNumber',
                    value: '034017161770',
                  },
                  {
                    fieldName: 'CPC',
                    value: '9ba83148d96c4d1bac176afcff65b078',
                  },
                  {
                    fieldName: 'PackageType',
                    value: 'P',
                  },
                  {
                    fieldName: 'PackageName',
                    value: 'Premier Advantage Package',
                  },
                ],
                id: 'j-hwNz3u',
              },
            },
            allIds: ['j-hwNz3u'],
            isFetching: false,
            isError: false,
          },
        },
        siriusSecuredlendingservicingV1: {
          eligibilities: {
            byId: {
              'j-hwNz3u': {
                status: 'Eligible',
                isFlexiLoan: true,
                failureReason: {
                  reason: 'CaseExists',
                  details: 'User case already exists',
                },
                id: 'j-hwNz3u',
              },
            },
            allIds: ['j-hwNz3u'],
            isFetching: false,
            isError: false,
          },
          arrangements: {
            byId: {
              ZiWtQhuAo: {
                currentBalance: { amount: '300000', position: 'DR' },
                availableBalance: { amount: '300000', position: 'CR' },
                variableInterestRate: '4.20',
                loanMaturityDate: '23 Jan 2052',
                repaymentType: 'IO',
                interestOnlyMaturityDate: '01 Dec 2018',
                monthlyRepayment: '1400',
                redrawIndicatorSet: true,
                loanLimit: '1223',
                remainingTermPIF: '186',
                remainingTermIO: '110',
                nextPaymentDueDate: '23 Jan 2032',
                productName: 'flexi',
                id: 'ZiWtQhuAo',
              },
            },
            allIds: ['ZiWtQhuAo'],
            isFetching: false,
            isError: false,
          },
          redrawAccounts: {
            byId: {
              '605124499880': {
                productLongName: 'WestPac Choice 1',
                id: '605124499880',
              },
              '405124599880': {
                productLongName: 'WestPac Choice 2',
                id: '405124599880',
              },
              '205124699882': {
                productLongName: 'WestPac Choice 3',

                id: '205124699882',
              },
              '505124549889': {
                productLongName: 'WestPac Choice 4',

                id: '505124549889',
              },
            },
            allIds: [
              '605124499880',
              '405124599880',
              '205124699882',
              '505124549889',
            ],
            isFetching: false,
            isError: false,
          },
        },
      },
      ui: {
        securedLendingServicing: {
          app: {
            headerBackNavigate: 'PREVIOUS',
            showHidePopUp: false,
            selectedInterestRateForTerm: '4.2',
            selectedYearTerm: '2',
            alertBoxMessage: '',
            setFixedOptionRate: '',
            setInputValueData: '',
            selectedRepaymentType: 'IO',
            setRedrawShowHidePopup: '',
            redrawShowHidePopup: true,
            setRedrawModalTitle: '',
            redrawModalTitle: 'Redraw available funds',
            setRedrawModalButtonText: '',
            redrawModalButtonText: 'Next',
            setRedrawFundsAccounts: '',
            redrawFundAccountsList: [
              {
                label: 'Select an account',
                id: 0,
                value: '0',
              },
              {
                label: 'WestPac Choice 1 123-415 11223344',
                id: '6aZvBOo5',
                value: '6aZvBOo5',
              },
              {
                label: 'WestPac Choice 2 123-415 11223345',
                id: 'ybppcQX-D',
                value: 'ybppcQX-D',
              },
              {
                label: 'WestPac Choice 3 123-415 11223346',
                id: 'HUFDVOAv7',
                value: 'HUFDVOAv7',
              },
              {
                label: 'WestPac Choice 4 123-415 11223344',
                id: '5oWf2qazV',
                value: '5oWf2qazV',
              },
              {
                label: 'WestPac Choice 5 123-415 11223344',
                id: 'evhaaurcr',
                value: 'evhaaurcr',
              },
            ],
            setFieldSelectValue: '',
            selectedAccount: '',
            selectedLoanOption: 'RedrawFundsOption',
          },
        },
      },
    },
    {
      user: {
        user: null,
        isLoadingUser: false,
      },
      config: {
        isLoading: false,
        appName: 'securedlendingservicing',
        appId: 'au.com.westpac.ui.www1-sirius',
        appVersion: '1.0.0',
        brandId: 'WBC',
        xChannelType: 'Internal',
        apiBaseUrl: 'http://localhost:8080',
        api: {
          basePath: {
            'exp-sirius-securedlendingservicing-v1':
              '/exp/sirius/securedlendingservicing/v1/',
          },
        },
        analytics: {
          seedFiles: {
            BOM: '/static/scripts/analytics/1.0.6/WBC/analytics_wdp.js',
            BSA: '/static/scripts/analytics/1.0.6/WBC/analytics_wdp.js',
            STG: '/static/scripts/analytics/1.0.6/WBC/analytics_wdp.js',
            WBC: '/static/scripts/analytics/1.0.6/WBC/analytics_wdp.js',
          },
          channel: 'digital',
          journeyType: 'auth',
          trackOnce: 'true',
          siteEnv: 'test',
          siteName: 'banking',
          siteSection: 'sirius',
        },
        securedlendingservicing: {
          switchingFee: '500',
          additionalPaymentAmount: '30,000',
          monthlyMaintainenceFee: '8',
          dashboardUrl: {
            STG:
              'https://vp1ibank.stgeorge.com.au/services/wdpToCompass?actionType=dashboard',
            BOM:
              'https://vp1ibank.bankofmelbourne.com.au/services/wdpToCompass?actionType=dashboard',
            BSA:
              'https://vp1ibank.banksa.com.au/services/wdpToCompass?actionType=dashboard',
            WBC:
              'https://vp1ibank.stgeorge.com.au/services/wdpToCompass?actionType=dashboard',
          },
          footerInfoSecurityUrl: {
            STG:
              'https://webapps.stgeorge.com.au/apply-now/acc_help.asp#security?view=oaf',
            BOM:
              'https://webapps.bankofmelbourne.com.au/apply-now/acc_help.asp#security?view=oaf',
            BSA:
              'https://webapps.banksa.com.au/apply-now/acc_help.asp#security?view=oaf',
            WBC:
              'https://webapps.stgeorge.com.au/apply-now/acc_help.asp#security?view=oaf',
          },
          conditionsOfUseUrl: {
            STG:
              'https://www.stgeorge.com.au/content/dam/public/wbc/documents/pdf/pb/PAP_ConditionsofUse.pdf',
            BOM:
              'https://www.bankofmelbourne.com.au/content/dam/public/wbc/documents/pdf/pb/PAP_ConditionsofUse.pdf',
            BSA:
              'https://www.banksa.com.au/content/dam/public/wbc/documents/pdf/pb/PAP_ConditionsofUse.pdf',
            WBC:
              'https://www.westpac.com.au/content/dam/public/wbc/documents/pdf/pb/PAP_ConditionsofUse.pdf',
          },
          messageInboxUrl: {
            STG:
              'https://www.stgeorge.com.au/content/dam/public/wbc/documents/pdf/pb/PAP_ConditionsofUse.pdf',
            BOM:
              'https://www.bankofmelbourne.com.au/content/dam/public/wbc/documents/pdf/pb/PAP_ConditionsofUse.pdf',
            BSA:
              'https://www.banksa.com.au/content/dam/public/wbc/documents/pdf/pb/PAP_ConditionsofUse.pdf',
            WBC:
              'https://www.westpac.com.au/content/dam/public/wbc/documents/pdf/pb/PAP_ConditionsofUse.pdf',
          },
          directDebitUrlInterestOnly: {
            STG:
              'https://www.stgeorge.com.au/content/dam/public/wbc/documents/pdf/pb/Direct_Debit_Request_Interest_Only_Loan_Repayment.pdf',
            BOM:
              'https://www.bankofmelbourne.com.au/content/dam/public/wbc/documents/pdf/pb/Direct_Debit_Request_Interest_Only_Loan_Repayment.pdf',
            BSA:
              'https://www.banksa.com.au/content/dam/public/wbc/documents/pdf/pb/Direct_Debit_Request_Interest_Only_Loan_Repayment.pdf',
            WBC:
              'https://www.westpac.com.au/content/dam/public/wbc/documents/pdf/pb/Direct_Debit_Request_Interest_Only_Loan_Repayment.pdf',
          },
          directDebitUrlPrincipalInterest: {
            STG:
              'https://www.stgeorge.com.au/content/dam/public/wbc/documents/pdf/pb/Direct_Debit_Request_Loan_Repayment.pdf',
            BOM:
              'https://www.bankofmelbourne.com.au/content/dam/public/wbc/documents/pdf/pb/Direct_Debit_Request_Loan_Repayment.pdf',
            BSA:
              'https://www.banksa.com.au/content/dam/public/wbc/documents/pdf/pb/Direct_Debit_Request_Loan_Repayment.pdf',
            WBC:
              'https://www.westpac.com.au/content/dam/public/wbc/documents/pdf/pb/Direct_Debit_Request_Loan_Repayment.pdf',
          },
          breakCostUrl: {
            STG:
              'https://www.stgeorge.com.au/content/dam/public/wbc/documents/pdf/pb/WBC-things-you-should-know-about-break-costs.pdf?appAction=PDF',
            BOM:
              'https://www.bankofmelbourne.com.au/dam/public/wbc/documents/pdf/pb/WBC-things-you-should-know-about-break-costs.pdf?appAction=PDF',
            BSA:
              'https://www.banksa.com.au/dam/public/wbc/documents/pdf/pb/WBC-things-you-should-know-about-break-costs.pdf?appAction=PDF',
            WBC:
              'https://www.westpac.com.au/content/dam/public/wbc/documents/pdf/pb/WBC-things-you-should-know-about-break-costs.pdf?appAction=PDF',
          },
          brandNames: {
            STG: {
              name: 'St. George',
              ariaLabel: 'Saint George',
            },
            BOM: {
              name: 'Bank Of Melbourne',
              ariaLabel: 'Bank Of Melbourne',
            },
            BSA: {
              name: 'BankSA',
              ariaLabel: 'Bank S A',
            },
            WBC: {
              name: 'Westpac',
              ariaLabel: 'Westpac',
            },
          },
        },
        appCorrelationId: 'YRC28nOk',
        isMicroAppLoading: false,

        isMicroAppError: false,
      },
      analytics: {
        analyticsEnabled: false,
      },
      entities: {
        siriusSecuredlendingservicingV1: {
          redrawAccounts: {
            byId: {},
            allIds: [],
            isFetching: false,
            isError: false,
          },
        },
      },
      ui: {
        securedLendingServicing: {
          app: {
            headerBackNavigate: 'PREVIOUS',
            showHidePopUp: false,
            selectedInterestRateForTerm: '4.2',
            selectedYearTerm: '2',
            alertBoxMessage:
              'The terms offered are within your interest only period. Switching to Principal and interest repayments may offer longer terms',
            setFixedOptionRate: '',
            setInputValueData: '',
            selectedRepaymentType: 'IO',
            setRedrawShowHidePopup: '',
            redrawShowHidePopup: true,
            setRedrawModalTitle: '',
            redrawModalTitle: 'Redraw available funds',
            setRedrawModalButtonText: '',
            redrawModalButtonText: 'Next',
            setRedrawFundsAccounts: '',
            redrawFundAccountsList: [],
            setFieldSelectValue: '',
            selectedAccount: '',
            selectedLoanOption: 'RedrawFundsOption',
          },
        },
      },
    },
    {
      config: {
        brandId: 'WBC',
      },
      ui: {
        securedLendingServicing: {
          app: {
            headerBackNavigate: 'CHANNEL',
            headerTitle: 'Test',
            selectedLoanOption: 'RedrawFundsOption',
            selectedAccount: '0',
          },
        },
      },
      entities: {
        siriusCoreV1: {
          contexts: {
            byId: {
              'j-hwNz3u': {
                fields: [
                  {
                    fieldName: 'accountNumber',
                    value: '034017161770',
                  },
                  {
                    fieldName: 'CPC',
                    value: '9ba83148d96c4d1bac176afcff65b078',
                  },
                  {
                    fieldName: 'PackageType',
                    value: 'P',
                  },
                  {
                    fieldName: 'PackageName',
                    value: 'Premier Advantage Package',
                  },
                ],
                id: 'j-hwNz3u',
              },
            },
            allIds: ['j-hwNz3u'],
            isFetching: false,
            isError: false,
          },
        },
        siriusSecuredlendingservicingV1: {
          eligibilities: {
            byId: {
              'j-hwNz3u': {
                status: 'Eligible',
                isFlexiLoan: true,
                failureReason: {
                  reason: 'CaseExists',
                  details: 'User case already exists',
                },
                id: 'j-hwNz3u',
              },
            },
            allIds: ['j-hwNz3u'],
            isFetching: false,
            isError: false,
          },
          arrangements: {
            byId: {
              ZiWtQhuAo: {
                currentBalance: { amount: '300000', position: 'DR' },
                availableBalance: { amount: '300000', position: 'CR' },

                variableInterestRate: '4.20',
                loanMaturityDate: '23 Jan 2052',
                repaymentType: 'IO',
                interestOnlyMaturityDate: '01 Dec 2018',
                monthlyRepayment: '1400',
                redrawIndicatorSet: true,
                loanLimit: '1223',
                remainingTermPIF: '186',
                remainingTermIO: '110',
                nextPaymentDueDate: '23 Jan 2032',
                productName: 'flexi',
                id: 'ZiWtQhuAo',
              },
            },
            allIds: ['ZiWtQhuAo'],
            isFetching: false,
            isError: false,
          },
          quotes: {
            byId: {},
            allIds: [],
            isFetching: false,
            isError: false,
          },
          redrawAccounts: {
            byId: {},
            allIds: [],
            isFetching: false,
            isError: false,
          },
        },
      },
    },
    {
      config: {
        brandId: 'WBC',
      },
      ui: {
        securedLendingServicing: {
          app: {
            headerBackNavigate: 'CHANNEL',
            headerTitle: 'Test',
            selectedLoanOption: 'RedrawFundsOption',
            redrawShowHidePopup: true,
            redrawFundAccountsList: [
              {
                label: 'Select an account',
                id: 0,
                value: '0',
              },
              {
                label: 'WestPac Choice 1 123-415 11223344',
                id: '6aZvBOo5',
                value: '6aZvBOo5',
              },
              {
                label: 'WestPac Choice 2 123-415 11223345',
                id: 'ybppcQX-D',
                value: 'ybppcQX-D',
              },
              {
                label: 'WestPac Choice 3 123-415 11223346',
                id: 'HUFDVOAv7',
                value: 'HUFDVOAv7',
              },
              {
                label: 'WestPac Choice 4 123-415 11223344',
                id: '5oWf2qazV',
                value: '5oWf2qazV',
              },
              {
                label: 'WestPac Choice 5 123-415 11223344',
                id: 'evhaaurcr',
                value: 'evhaaurcr',
              },
            ],
          },
        },
      },
      entities: {
        siriusCoreV1: {
          contexts: {
            byId: {
              'j-hwNz3u': {
                fields: [
                  {
                    fieldName: 'accountNumber',
                    value: '034017161770',
                  },
                  {
                    fieldName: 'CPC',
                    value: '9ba83148d96c4d1bac176afcff65b078',
                  },
                  {
                    fieldName: 'PackageType',
                    value: 'P',
                  },
                  {
                    fieldName: 'PackageName',
                    value: 'Premier Advantage Package',
                  },
                ],
                id: 'j-hwNz3u',
              },
            },
            allIds: ['j-hwNz3u'],
            isFetching: false,
            isError: false,
          },
        },
        siriusSecuredlendingservicingV1: {
          eligibilities: {
            byId: {
              'j-hwNz3u': {
                status: 'Eligible',
                isFlexiLoan: true,
                failureReason: {
                  reason: 'CaseExists',
                  details: 'User case already exists',
                },
                id: 'j-hwNz3u',
              },
            },
            allIds: ['j-hwNz3u'],
            isFetching: false,
            isError: false,
          },
          arrangements: {
            byId: {
              ZiWtQhuAo: {
                currentBalance: { amount: '300000', position: 'DR' },
                availableBalance: { amount: '300000', position: 'CR' },

                variableInterestRate: '2.20',
                loanMaturityDate: '23 Jan 2052',
                repaymentType: 'IO',
                interestOnlyMaturityDate: '01 Dec 2018',
                monthlyRepayment: '1400',
                redrawIndicatorSet: true,
                loanLimit: '1223',
                remainingTermPIF: '186',
                remainingTermIO: '110',
                nextPaymentDueDate: '23 Jan 2032',
                productName: 'flexi',
                id: 'ZiWtQhuAo',
              },
            },
            allIds: ['ZiWtQhuAo'],
            isFetching: false,
            isError: false,
          },
          quotes: {
            byId: {},
            allIds: [],
            isFetching: false,
            isError: false,
          },
          redrawAccounts: {
            byId: {
              '6aZvBOo5': {
                productLongName: 'WestPac Choice 1',
                accountId: {
                  accountNumber: '11223344',
                  BSB: '123-415',
                },
                id: '6aZvBOo5',
              },
              'ybppcQX-D': {
                productLongName: 'WestPac Choice 2',
                accountId: {
                  accountNumber: '11223345',
                  BSB: '123-415',
                },
                id: 'ybppcQX-D',
              },
              HUFDVOAv7: {
                productLongName: 'WestPac Choice 3',
                accountId: {
                  accountNumber: '11223346',
                  BSB: '123-415',
                },
                id: 'HUFDVOAv7',
              },
              '5oWf2qazV': {
                productLongName: 'WestPac Choice 4',
                accountId: {
                  accountNumber: '11223344',
                  BSB: '123-415',
                },
                id: '5oWf2qazV',
              },
              evhaaurcr: {
                productLongName: 'WestPac Choice 5',
                accountId: {
                  accountNumber: '11223344',
                  BSB: '123-415',
                },
                id: 'evhaaurcr',
              },
            },
            allIds: [
              '6aZvBOo5',
              'ybppcQX-D',
              'HUFDVOAv7',
              '5oWf2qazV',
              'evhaaurcr',
            ],
            isFetching: false,
            isError: false,
          },
        },
      },
    },
    {
      config: {
        brandId: 'WBC',
      },
      ui: {
        securedLendingServicing: {
          app: {
            headerBackNavigate: 'CHANNEL',
            headerTitle: 'Test',
            selectedLoanOption: 'RedrawFundsOption',
            redrawShowHidePopup: true,
            redrawFundAccountsList: [],
          },
        },
      },
      entities: {
        siriusCoreV1: {
          contexts: {
            byId: {
              'j-hwNz3u': {
                fields: [
                  {
                    fieldName: 'accountNumber',
                    value: '034017161770',
                  },
                  {
                    fieldName: 'CPC',
                    value: '9ba83148d96c4d1bac176afcff65b078',
                  },
                  {
                    fieldName: 'PackageType',
                    value: 'P',
                  },
                  {
                    fieldName: 'PackageName',
                    value: 'Premier Advantage Package',
                  },
                ],
                id: 'j-hwNz3u',
              },
            },
            allIds: ['j-hwNz3u'],
            isFetching: false,
            isError: false,
          },
        },
        siriusSecuredlendingservicingV1: {
          eligibilities: {
            byId: {
              'j-hwNz3u': {
                status: 'Eligible',
                isFlexiLoan: true,
                failureReason: {
                  reason: 'CaseExists',
                  details: 'User case already exists',
                },
                id: 'j-hwNz3u',
              },
            },
            allIds: ['j-hwNz3u'],
            isFetching: false,
            isError: false,
          },
          arrangements: {
            byId: {
              ZiWtQhuAo: {
                currentBalance: { amount: '300000', position: 'DR' },
                availableBalance: { amount: '300000', position: 'CR' },
                variableInterestRate: '1.20',
                loanMaturityDate: '23 Jan 2052',
                repaymentType: 'IO',
                interestOnlyMaturityDate: '01 Dec 2018',
                monthlyRepayment: '1400',
                redrawIndicatorSet: false,
                loanLimit: '1223',
                remainingTermPIF: '186',
                remainingTermIO: '110',
                nextPaymentDueDate: '23 Jan 2032',
                productName: 'flexi',
                id: 'ZiWtQhuAo',
              },
            },
            allIds: ['ZiWtQhuAo'],
            isFetching: false,
            isError: false,
          },
          quotes: {
            byId: {},
            allIds: [],
            isFetching: false,
            isError: false,
          },
          redrawAccounts: {
            byId: {},
            allIds: [],
            isFetching: false,
            isError: false,
          },
        },
      },
    },
    {
      config: {
        brandId: 'WBC',
      },
      ui: {
        securedLendingServicing: {
          app: {
            headerBackNavigate: 'CHANNEL',
            headerTitle: 'Test',
            selectedLoanOption: 'RedrawFundsOption',
            redrawShowHidePopup: false,
            redrawFundAccountsList: [],
          },
        },
      },
      entities: {
        siriusCoreV1: {
          contexts: {
            byId: {
              'j-hwNz3u': {
                fields: [
                  {
                    fieldName: 'accountNumber',
                    value: '034017161770',
                  },
                  {
                    fieldName: 'CPC',
                    value: '9ba83148d96c4d1bac176afcff65b078',
                  },
                  {
                    fieldName: 'PackageType',
                    value: 'P',
                  },
                  {
                    fieldName: 'PackageName',
                    value: 'Premier Advantage Package',
                  },
                ],
                id: 'j-hwNz3u',
              },
            },
            allIds: ['j-hwNz3u'],
            isFetching: false,
            isError: false,
          },
        },
        siriusSecuredlendingservicingV1: {
          eligibilities: {
            byId: {
              'j-hwNz3u': {
                status: 'Eligible',
                isFlexiLoan: true,
                failureReason: {
                  reason: 'CaseExists',
                  details: 'User case already exists',
                },
                id: 'j-hwNz3u',
              },
            },
            allIds: ['j-hwNz3u'],
            isFetching: false,
            isError: false,
          },
          arrangements: {
            byId: {
              ZiWtQhuAo: {
                currentBalance: { amount: '300000', position: 'DR' },
                availableBalance: { amount: '300000', position: 'CR' },
                variableInterestRate: '4.20',
                loanMaturityDate: '23 Jan 2052',
                repaymentType: 'IO',
                interestOnlyMaturityDate: '01 Dec 2018',
                monthlyRepayment: '1400',
                redrawIndicatorSet: true,
                remainingTermPIF: '186',
                remainingTermIO: '110',
                nextPaymentDueDate: '23 Jan 2032',
                productName: 'flexi',
                loanLimit: '1223',
                id: 'ZiWtQhuAo',
              },
            },
            allIds: ['ZiWtQhuAo'],
            isFetching: false,
            isError: false,
          },
          quotes: {
            byId: {},
            allIds: [],
            isFetching: false,
            isError: false,
          },
          redrawAccounts: {
            byId: {
              '605124499880': {
                productLongName: 'WestPac Choice 1',
                id: '605124499880',
              },
              '405124599880': {
                productLongName: 'WestPac Choice 2',
                id: '405124599880',
              },
              '205124699882': {
                productLongName: 'WestPac Choice 3',

                id: '205124699882',
              },
              '505124549889': {
                productLongName: 'WestPac Choice 4',

                id: '505124549889',
              },
            },
            allIds: [
              '605124499880',
              '405124599880',
              '205124699882',
              '505124549889',
            ],
            isFetching: false,
            isError: false,
          },
        },
      },
    },
  ],
  invalid: [],
};
