import React, { Component } from 'react';
import { connect } from 'react-redux';
import { compose } from 'recompose';
import PropTypes from 'prop-types';
import { withTracking } from '@wdpui/common-analytics';
import { Error } from '../components';
import { actions as appActions } from '../redux/modules/app.module';
import { getDashboardUrl, getEligibilityReasonDesc } from '../redux/selectors';
import { scrollWindow } from '../helpers/windowFunctionsHelper';
import { getAnalyticsTags } from '../helpers/analyticsHelper';

import { getErrorHeading, getErrorCode } from '../helpers/errorMessageHelper';

class ErrorContainer extends Component {
  static propTypes = {
    channelDashboardUrl: PropTypes.string.isRequired,
    updateHeaderBackNavigation: PropTypes.func.isRequired,
    caseSubmittedDate: PropTypes.string.isRequired,
    heading: PropTypes.string.isRequired,
    errorCode: PropTypes.string.isRequired,
  };

  componentDidMount() {
    const { updateHeaderBackNavigation } = this.props;
    scrollWindow();

    updateHeaderBackNavigation('CHANNEL');
  }

  backToChannel = () => {
    const { channelDashboardUrl } = this.props;
    window.location.replace(channelDashboardUrl);
  };

  render() {
    const { caseSubmittedDate, heading, errorCode } = this.props;
    let btnLabel = 'Back to dashboard';

    if (errorCode === 'caseexists' || errorCode === 'eligibilityfail') {
      btnLabel = 'Done';
    }
    return (
      <Error
        onDoneClick={this.backToChannel}
        heading={heading}
        errorCode={errorCode}
        caseSubmittedDate={caseSubmittedDate}
        btnLabel={btnLabel}
      />
    );
  }
}
const mapStateToProps = state => ({
  channelDashboardUrl: getDashboardUrl(state),
  caseSubmittedDate: getEligibilityReasonDesc(state),
  heading: getErrorHeading(),
  errorCode: getErrorCode(),
});
const mapDispatchToProps = {
  updateHeaderBackNavigation: appActions.app.header.navigateBack,
};

const enhance = compose(
  connect(mapStateToProps, mapDispatchToProps),
  withTracking((state, props) => getAnalyticsTags('ERROR', props)),
);

export default enhance(ErrorContainer);
