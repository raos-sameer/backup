import React from 'react';
import { shallow, mount } from 'enzyme';
import { sortBy, pick } from 'lodash';
import configureMockStore from 'redux-mock-store';
import { BrowserRouter as Router } from 'react-router-dom';
import { withTheme } from '../../../../utils/jest/TestUtils';
import { mockStoreData } from './__fixtures__/mockErrorContainer.fixture';
import ErrorContainer from './ErrorContainer';

const mockStore = configureMockStore();
global.matchMedia = matches => () => ({
  matches,
  addListener: () => {},
  removeListener: () => {},
});
describe('ErrorContainer', () => {
  let store;
  const spy = jest.spyOn(global.console, 'error');

  afterEach(() => {
    if (store && store.clearActions) {
      store.clearActions();
    }
    if (spy && spy.mockReset && spy.mockRestore) {
      spy.mockReset();
      spy.mockRestore();
    }
  });

  it('should render without error when required props are passed', () => {
    store = mockStore(mockStoreData.valid[0]);
    const component = withTheme(<ErrorContainer />);
    shallow(component, { context: { store } }).dive();
    expect(spy).not.toHaveBeenCalled();
  });

  it('should trigger action to update header title', () => {
    store = mockStore(mockStoreData.valid[0]);
    const component = withTheme(
      <ErrorContainer store={store} match={{ path: '' }} />,
    );
    mount(component);
    const expectedActions = sortBy(
      [
        { type: 'app/header/NAVIGATE_BACK' },
        {
          type: 'common/analytics/LOAD',
        },
      ],
      ['type'],
    );
    let actions = store.getActions().map(a => pick(a, 'type'));
    actions = sortBy(actions, ['type']);
    expect(actions).toEqual(expectedActions);
  });
  it('should call backToChannel when clicked on cancel button', () => {
    store = mockStore(mockStoreData.valid[0]);
    const props = {};
    const component = withTheme(
      <Router>
        <ErrorContainer store={store} match={{ path: '' }} {...props} />
      </Router>,
    );
    const wrapper = mount(component);
    const cmp = wrapper.find('ErrorContainer');
    const instance = cmp.instance();
    instance.backToChannel();
    const backNav = store.getActions().filter(a => {
      return a.type === 'app/header/NAVIGATE_BACK';
    });
    expect(backNav[0].payload).toEqual('CHANNEL');
  });
  it('should change button label for caseExists scenario', () => {
    store = mockStore(mockStoreData.valid[0]);
    global.window = Object.create(window);
    const url = 'test?code=caseexists';
    Object.defineProperty(window, 'location', {
      value: {
        href: url,
        search: url,
      },
    });
    const component = withTheme(
      <ErrorContainer store={store} match={{ path: '' }} />,
    );
    mount(component);
    const expectedActions = sortBy(
      [
        { type: 'app/header/NAVIGATE_BACK' },
        {
          type: 'common/analytics/LOAD',
        },
      ],
      ['type'],
    );
    let actions = store.getActions().map(a => pick(a, 'type'));
    actions = sortBy(actions, ['type']);
    expect(actions).toEqual(expectedActions);
  });
});
