import React from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { compose } from 'recompose';
import { withTracking } from '@wdpui/common-analytics';
import { isEmpty } from 'lodash';
import { Redirect } from 'react-router-dom';

import {
  isQuotesError as getMortgageQuotesError,
  isQuotesFetching as getMortgageQuotesFetching,
  isArrangementsError as getCurrentLoanDetailsError,
  isArrangementsFetching as getCurrentLoanDetailsFetching,
} from '@wdpui/redux-exp-sirius-securedlendingservicing-v1/selectors';
import { formActions } from '../redux/actions/formActions';
import { scrollWindow } from '../helpers/windowFunctionsHelper';
import { Loader } from '../components/common';

import {
  getQuotesReponseError,
  getCurrentLoanDetails,
  getMortgageQuotes,
  getDiscountedSilos,
  isMortgageQuotesLoaded as getMortgageQuotesLoaded,
  getShowHidePopUp,
  getDashboardUrl,
  getRepaymentType,
  getSelectedYearTerm,
  getAlertBoxMessage,
  getConditionsOfUseUrl,
  getSelectedInterestRateForTerm,
  isRemainingLoanTermLessThanYear,
  getPackageIndicator,
  getSwitchingFee,
  getMonthlyMaintainenceFee,
  getPackageFee,
  getDiscountRate,
  getAdditionalPaymentAmount,
  getProductName,
} from '../redux/selectors';
import { InterestRatePackageSelect } from '../components';

import { actions as appActions } from '../redux/modules/app.module';
import { getAnalyticsTags } from '../helpers/analyticsHelper';

export class SelectInterestRateContainer extends React.Component {
  static propTypes = {
    isMortgageQuotesFetching: PropTypes.bool.isRequired,
    isMortgageQuotesError: PropTypes.bool.isRequired,
    isArrangementsFetching: PropTypes.bool.isRequired,
    isArrangementsError: PropTypes.bool.isRequired,
    showHidePopUp: PropTypes.bool,
    fetchMortgageQuotes: PropTypes.func,
    isExpiryDateLessThanYear: PropTypes.bool.isRequired,
    selectedYearTerm: PropTypes.string,
    selectedInterestRateForTerm: PropTypes.string,
    selectedRepaymentType: PropTypes.string,
    setShowHidePopup: PropTypes.func.isRequired,
    setRepaymentType: PropTypes.func.isRequired,
    setYearTerm: PropTypes.func.isRequired,
    setInterestRateTerm: PropTypes.func.isRequired,
    history: PropTypes.shape({
      push: PropTypes.func.isRequired,
    }).isRequired,
    currentLoanDetails: PropTypes.shape({
      currentBalance: PropTypes.string.isRequired,
      availableBalance: PropTypes.string.isRequired,
      variableInterestRate: PropTypes.string.isRequired,
      loanMaturityDate: PropTypes.string.isRequired,
      repaymentType: PropTypes.string.isRequired,
      interestOnlyMaturityDate: PropTypes.string.isRequired,
      monthlyRepayment: PropTypes.string.isRequired,
      redrawIndicatorSet: PropTypes.bool.isRequired,
    }).isRequired,
    mortgageQuotes: PropTypes.arrayOf(PropTypes.shape({})),
    discountedSilos: PropTypes.arrayOf(PropTypes.shape({})),
    setAlertMessage: PropTypes.func.isRequired,
    alertBoxMessage: PropTypes.string,
    conditionsOfUseUrl: PropTypes.string,
    updateHeaderBackNavigation: PropTypes.func.isRequired,
    isPackageCustomer: PropTypes.bool.isRequired,
    switchFee: PropTypes.string.isRequired,
    monthlyMaintainence: PropTypes.string.isRequired,
    packageFee: PropTypes.string.isRequired,
    discountRate: PropTypes.string.isRequired,
    additionalPaymentAmount: PropTypes.string.isRequired,
    productName: PropTypes.string.isRequired,
    channelDashboardUrl: PropTypes.string.isRequired,
    quotesErrorCode: PropTypes.string.isRequired,
  };

  static defaultProps = {
    showHidePopUp: false,
    selectedYearTerm: '',
    selectedInterestRateForTerm: '',
    selectedRepaymentType: '',
    alertBoxMessage: '',
    discountedSilos: [],
    conditionsOfUseUrl: '',
    mortgageQuotes: [],
    fetchMortgageQuotes: () => {},
  };

  componentDidMount() {
    const { updateHeaderBackNavigation } = this.props;
    scrollWindow();

    updateHeaderBackNavigation('PREVIOUS');
  }

  componentDidUpdate() {
    const {
      currentLoanDetails: { repaymentType },
      setRepaymentType,
      alertBoxMessage,
      selectedRepaymentType,
    } = this.props;

    const repaymentIndicator = selectedRepaymentType || repaymentType;

    if (isEmpty(alertBoxMessage)) {
      this.handleAlertMessageSet(repaymentIndicator, selectedRepaymentType);
      setRepaymentType(repaymentIndicator);
    }
  }

  navigateNext = () => {
    const { history } = this.props;
    history.push('/securedlendingservicing/selectloanoption');
  };

  showReviewDetailsPopup = () => {
    const { setShowHidePopup } = this.props;
    setShowHidePopup(true);
  };

  hideReviewDetailsPopup = () => {
    const { setShowHidePopup } = this.props;
    setShowHidePopup(false);
  };

  handleInterestRateSiloChange = (term, intrate) => {
    const { setYearTerm, setInterestRateTerm } = this.props;
    setYearTerm(term);
    setInterestRateTerm(intrate);
  };

  setRepaymentType = event => {
    const repaymentType = event.target.value;
    const { setRepaymentType, fetchMortgageQuotes } = this.props;

    setRepaymentType(repaymentType);
    this.handleAlertMessageSet(repaymentType);
    fetchMortgageQuotes();
  };

  backToChannel = () => {
    const { channelDashboardUrl } = this.props;
    window.location.replace(channelDashboardUrl);
  };

  handleAlertMessageSet(repaymentType) {
    const {
      isExpiryDateLessThanYear,
      setAlertMessage,
      currentLoanDetails: { repaymentType: currentRepaymentType },
    } = this.props;

    let message = '';
    if (isExpiryDateLessThanYear && repaymentType === 'IO') {
      message = `Your interest only period expires in less than a year. You'll have to switch to principal and interest repayments to fix your loan.`;
    } else if (!isExpiryDateLessThanYear && repaymentType === 'IO') {
      message = `The terms offered are within your interest only period. Switching to Principal and interest repayments may offer longer terms`;
    } else if (
      !isExpiryDateLessThanYear &&
      repaymentType === 'PIF' &&
      currentRepaymentType === 'IO'
    ) {
      message = `Your interest only period will end on switching to principal and interest repayments`;
    }
    setAlertMessage(message);
  }

  render() {
    const {
      isMortgageQuotesFetching,
      isMortgageQuotesError,
      isArrangementsError,
      isArrangementsFetching,
      showHidePopUp,
      mortgageQuotes,
      discountedSilos,
      selectedYearTerm,
      selectedInterestRateForTerm,
      alertBoxMessage,
      selectedRepaymentType,
      currentLoanDetails: {
        currentBalance: { amount: currBalance },
        availableBalance: { amount: availBalance },
        variableInterestRate,
        loanMaturityDate,
        interestOnlyMaturityDate,
        monthlyRepayment,
        repaymentType,
        redrawIndicatorSet,
      },
      isExpiryDateLessThanYear,
      conditionsOfUseUrl,
      isPackageCustomer,
      switchFee,
      monthlyMaintainence,
      additionalPaymentAmount,
      productName,
      packageFee,
      discountRate,
      quotesErrorCode,
    } = this.props;

    if (quotesErrorCode === 'PRICING') {
      return (
        <Redirect to="/securedlendingservicing/error?code=eligibilityfail" />
      );
    }
    if (isArrangementsError) {
      return <Redirect to="/securedlendingservicing/error" />;
    }
    if (isArrangementsFetching) {
      return <Loader />;
    }

    return (
      <InterestRatePackageSelect
        mortgageQuotes={mortgageQuotes}
        isMortgageQuotesFetching={isMortgageQuotesFetching}
        isMortgageQuotesError={isMortgageQuotesError}
        variableInterestRate={variableInterestRate}
        showReviewDetailsPopup={this.showReviewDetailsPopup}
        hideReviewDetailsPopup={this.hideReviewDetailsPopup}
        repaymentType={repaymentType}
        selectedRepaymentType={selectedRepaymentType}
        setRepaymentType={this.setRepaymentType}
        selectedYearTerm={selectedYearTerm}
        selectedInterestRateForTerm={selectedInterestRateForTerm}
        handleInterestRateSiloChange={this.handleInterestRateSiloChange}
        backToChannel={this.backToChannel}
        navigateNext={this.navigateNext}
        currentBalance={currBalance}
        availableBalance={availBalance}
        varInterestRate={variableInterestRate}
        loanMaturityDate={loanMaturityDate}
        interestOnlyMatDate={interestOnlyMaturityDate}
        monthlyRepayment={monthlyRepayment}
        advantagePackage={isPackageCustomer}
        showHidePopUp={showHidePopUp}
        isExpiryDateLessThanYear={isExpiryDateLessThanYear}
        alertBoxMessage={alertBoxMessage}
        discountedSilos={discountedSilos}
        conditionsOfUseUrl={conditionsOfUseUrl}
        isPrincipalInterestCustomer={repaymentType === 'PIF'}
        switchFee={switchFee}
        monthlyMaintainence={monthlyMaintainence}
        additionalPaymentAmount={additionalPaymentAmount}
        productName={productName}
        redrawIndicatorSet={redrawIndicatorSet}
        packageFee={packageFee}
        discountRate={discountRate}
      />
    );
  }
}

const mapStateToProps = state => ({
  quotesErrorCode: getQuotesReponseError(state),
  channelDashboardUrl: getDashboardUrl(state),
  currentLoanDetails: getCurrentLoanDetails(state),
  isMortgageQuotesFetching: getMortgageQuotesFetching(state),
  isMortgageQuotesError: getMortgageQuotesError(state),
  isMortgageQuotesLoaded: getMortgageQuotesLoaded(state),
  mortgageQuotes: getMortgageQuotes(state),
  discountedSilos: getDiscountedSilos(state),
  showHidePopUp: getShowHidePopUp(state),
  alertBoxMessage: getAlertBoxMessage(state),
  selectedRepaymentType: getRepaymentType(state),
  selectedYearTerm: getSelectedYearTerm(state),
  selectedInterestRateForTerm: getSelectedInterestRateForTerm(state),
  conditionsOfUseUrl: getConditionsOfUseUrl(state),
  isExpiryDateLessThanYear: isRemainingLoanTermLessThanYear(state),
  isPackageCustomer: getPackageIndicator(state),
  switchFee: getSwitchingFee(state),
  monthlyMaintainence: getMonthlyMaintainenceFee(state),
  additionalPaymentAmount: getAdditionalPaymentAmount(state),
  productName: getProductName(state),
  packageFee: getPackageFee(state),
  discountRate: getDiscountRate(state),
  isArrangementsFetching: getCurrentLoanDetailsFetching(state),
  isArrangementsError: getCurrentLoanDetailsError(state),
});

const mapDispatchToProps = {
  updateHeaderBackNavigation: appActions.app.header.navigateBack,
  setShowHidePopup: appActions.app.modal.setShowHidePopup,
  setRepaymentType: appActions.app.interestrate.setRepaymentType,
  setInterestRateTerm: appActions.app.interestrate.setInterestRateTerm,
  setYearTerm: appActions.app.interestrate.setYearTerm,
  setAlertMessage: appActions.app.interestrate.setAlertMessage,
  fetchMortgageQuotes: formActions.getMortgageQuotes,
};

const enhance = compose(
  connect(mapStateToProps, mapDispatchToProps),
  withTracking((state, props) => getAnalyticsTags('QUOTES_PAGE', props)),
);

export default enhance(SelectInterestRateContainer);
