/* eslint-disable no-console */
import React from 'react';
import { shallow } from 'enzyme';
import { Redirect } from 'react-router-dom';

import configureMockStore from 'redux-mock-store';
import { withTheme } from '../../../../utils/jest/TestUtils';
import { mockStoreData } from './__fixtures__/mockSelectInterestRateContainer.fixture';
import EnhancedReviewPageContainer from './ReviewPageContainer';

const mockStore = configureMockStore();

global.matchMedia = matches => () => ({
  matches,
  addListener: () => {},
  removeListener: () => {},
});
describe('ReviewPageContainer', () => {
  let store;
  const spy = jest.spyOn(global.console, 'error');
  const history = {
    push: jest.fn(),
    replace: jest.fn(),
  };
  window.location.replace = jest.fn();

  afterEach(() => {
    if (store && store.clearActions) {
      store.clearActions();
    }
    if (spy && spy.mockReset && spy.mockRestore) {
      spy.mockReset();
      spy.mockRestore();
    }
    if (history && history.push) {
      history.push.mockReset();
      history.push.mockRestore();
      history.replace.mockReset();
      history.replace.mockRestore();
    }
  });

  it('should render without error when required props are passed', () => {
    store = mockStore(mockStoreData.valid[0]);
    const component = withTheme(
      <EnhancedReviewPageContainer history={history} match={{ path: '' }} />,
    );
    shallow(component, { context: { store } }).dive();
    expect(spy).not.toHaveBeenCalled();
  });

  it('should call backToChannel', () => {
    store = mockStore(mockStoreData.valid[0]);
    const component = withTheme(
      <EnhancedReviewPageContainer history={history} match={{ path: '' }} />,
    );
    const shl = shallow(component, { context: { store } })
      .dive()
      .dive()
      .dive()
      .dive()
      .dive()
      .dive();
    const instance = shl.instance();
    instance.backToChannel();
    expect(window.location.replace).toHaveBeenCalled();
  });

  it('should call navigateNext', () => {
    store = mockStore(mockStoreData.valid[0]);
    const component = withTheme(
      <EnhancedReviewPageContainer history={history} match={{ path: '' }} />,
    );
    const shl = shallow(component, { context: { store } })
      .dive()
      .dive()
      .dive()
      .dive()
      .dive()
      .dive();
    const instance = shl.instance();
    instance.navigateNext();
    const submitDetails = store.getActions().filter(a => {
      return a.type === 'submitDetails';
    });
    expect(submitDetails.length).toBe(1);
  });

  it('should redirect to success receipt page if action is success', () => {
    store = mockStore(mockStoreData.valid[0]);
    const component = withTheme(
      <EnhancedReviewPageContainer
        history={history}
        store={store}
        match={{ path: '' }}
      />,
    );
    const wrapper = shallow(component, { context: { store } })
      .dive()
      .dive()
      .dive()
      .dive()
      .dive()
      .dive();
    expect(wrapper.find(Redirect).prop('to')).toBe(
      '/securedlendingservicing/receipt',
    );
    expect(wrapper.find(Redirect)).toHaveLength(1);
  });

  it('should redirect to error page if action is error', () => {
    store = mockStore(mockStoreData.valid[12]);
    const component = withTheme(
      <EnhancedReviewPageContainer
        history={history}
        store={store}
        match={{ path: '' }}
      />,
    );
    const wrapper = shallow(component, { context: { store } })
      .dive()
      .dive()
      .dive()
      .dive()
      .dive()
      .dive();
    expect(wrapper.find(Redirect).prop('to')).toBe(
      '/securedlendingservicing/error',
    );
    expect(wrapper.find(Redirect)).toHaveLength(1);
  });
  it('should load review page component if submit action is blank', () => {
    store = mockStore(mockStoreData.valid[13]);
    const component = withTheme(
      <EnhancedReviewPageContainer
        history={history}
        store={store}
        match={{ path: '' }}
      />,
    );
    const wrapper = shallow(component, { context: { store } })
      .dive()
      .dive()
      .dive()
      .dive()
      .dive()
      .dive();
    expect(wrapper.find('ReviewPageComponent')).toHaveLength(1);
  });

  it('should display loader when submit api is being called', () => {
    store = mockStore(mockStoreData.valid[15]);
    const component = withTheme(
      <EnhancedReviewPageContainer
        history={history}
        store={store}
        match={{ path: '' }}
      />,
    );
    const wrapper = shallow(component, { context: { store } })
      .dive()
      .dive()
      .dive()
      .dive()
      .dive()
      .dive()
      .dive()
      .dive();
    expect(wrapper.find('Loader')).toHaveLength(1);
  });
});
