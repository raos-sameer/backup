/* eslint-disable no-console */
import React from 'react';
import { shallow, mount } from 'enzyme';
import { sortBy, pick } from 'lodash';
import configureMockStore from 'redux-mock-store';
import { BrowserRouter as Router } from 'react-router-dom';
import { withTheme } from '../../../../utils/jest/TestUtils';
import FixedOptionLoanContainer from './FixedOptionLoanContainer';
import { mockStoreData } from './__fixtures__/mockConfirmReviewDetailsLayout.fixture';

const mockStore = configureMockStore();

global.matchMedia = matches => () => ({
  matches,
  addListener: () => {},
  removeListener: () => {},
});

describe('FixedOptionLoanContainer', () => {
  let store;
  const spy = jest.spyOn(global.console, 'error');
  const history = {
    push: jest.fn(),
  };
  const mockFn = jest.fn();

  afterEach(() => {
    if (store && store.clearActions) {
      store.clearActions();
    }
    if (spy && spy.mockReset && spy.mockRestore) {
      spy.mockReset();
      spy.mockRestore();
    }
    if (history && history.push) {
      history.push.mockReset();
      history.push.mockRestore();
    }
  });

  const props = {
    currentLoanDetails: {
      currentBalance: { amount: '900000', position: 'DR' },
      availableBalance: { amount: '300000', position: 'CR' },
      variableInterestRate: '4.20',
      monthlyRepayment: '1400',
      redrawTransferMsg: 'Test message',
      remainingTermPIF: '186',
      remainingTermIO: '0',
      productName: 'flexi',
    },
    alertBoxMessage: 'Test',
    switchedProductName: 'Test',
  };
  store = mockStore(props);

  it('should call showReviewDetailsPopup when clicked on toggled or show review button link clicked', () => {
    store = mockStore(mockStoreData.valid[0]);

    const component = withTheme(
      <Router>
        <FixedOptionLoanContainer
          history={history}
          store={store}
          match={{ path: '' }}
          {...props}
        />
      </Router>,
    );
    const wrapper = mount(component);
    const cmp = wrapper.find('FixedOptionLoanContainer');
    const instance = cmp.instance();
    instance.showReviewDetailsPopup();
    const actionShowHide = store.getActions().filter(a => {
      return a.type === 'app/modal/SET_SHOW_HIDE_POPUP';
    });
    expect(actionShowHide[0].payload).toEqual(true);
  });

  it('should call hideReviewDetailsPopup when clicked on toggled or show review button link clicked', () => {
    store = mockStore(mockStoreData.valid[0]);

    const component = withTheme(
      <Router>
        <FixedOptionLoanContainer
          history={history}
          store={store}
          match={{ path: '' }}
          {...props}
        />
      </Router>,
    );
    const wrapper = mount(component);
    const cmp = wrapper.find('FixedOptionLoanContainer');
    const instance = cmp.instance();
    instance.hideReviewDetailsPopup();
    const actionShowHide = store.getActions().filter(a => {
      return a.type === 'app/modal/SET_SHOW_HIDE_POPUP';
    });
    expect(actionShowHide[0].payload).toEqual(false);
  });

  it('should call showRedrawFundsPopup when clicked on toggled or show review button link clicked', () => {
    store = mockStore(mockStoreData.valid[0]);
    const component = withTheme(
      <Router>
        <FixedOptionLoanContainer
          history={history}
          store={store}
          match={{ path: '' }}
          {...props}
        />
      </Router>,
    );
    const wrapper = mount(component);
    const cmp = wrapper.find('FixedOptionLoanContainer');
    const instance = cmp.instance();
    instance.showRedrawFundsPopup();
    const actionShowHide = store.getActions().filter(a => {
      return a.type === 'app/modal/SET_REDRAW_SHOW_HIDE_POPUP';
    });
    expect(actionShowHide[0].payload).toEqual(true);
  });
  it('should call hideRedrawFundsPopup when clicked on toggled or hide review button link clicked', () => {
    store = mockStore(mockStoreData.valid[0]);
    const component = withTheme(
      <Router>
        <FixedOptionLoanContainer
          history={history}
          store={store}
          match={{ path: '' }}
          {...props}
        />
      </Router>,
    );
    const wrapper = mount(component);
    const cmp = wrapper.find('FixedOptionLoanContainer');
    const instance = cmp.instance();
    instance.hideRedrawFundsPopup();
    const actionShowHide = store.getActions().filter(a => {
      return a.type === 'app/modal/SET_REDRAW_SHOW_HIDE_POPUP';
    });
    expect(actionShowHide[0].payload).toEqual(false);
  });
  it('should render without error when required props are passed', () => {
    store = mockStore(mockStoreData.valid[0]);
    const component = withTheme(
      <FixedOptionLoanContainer
        backToChannel={mockFn}
        navigateNext={mockFn}
        history={history}
        store={store}
        match={{ path: '' }}
      />,
    );
    shallow(component, { context: { store } }).dive();
    expect(spy).not.toHaveBeenCalled();
  });

  it('should call navigateNext when clicked on next button', () => {
    props.selectedLoanOption = '';
    props.redrawShowHidePopup = false;
    props.redrawFundAccounts = [];

    store = mockStore(mockStoreData.valid[0]);
    const component = withTheme(
      <Router>
        <FixedOptionLoanContainer
          history={history}
          store={store}
          match={{ path: '' }}
          {...props}
        />
      </Router>,
    );
    const wrapper = mount(component);
    const cmp = wrapper.find('FixedOptionLoanContainer');
    const instance = cmp.instance();
    instance.navigateNext();
    expect(history.push).toHaveBeenCalled();
  });

  it('should call conditional navigateNext to show popup when clicked on next button', () => {
    store = mockStore(mockStoreData.valid[2]);
    const component = withTheme(
      <Router>
        <FixedOptionLoanContainer
          history={history}
          store={store}
          showRedrawFundsPopup={mockFn}
          match={{ path: '' }}
          {...props}
        />
      </Router>,
    );
    const wrapper = mount(component);
    const cmp = wrapper.find('FixedOptionLoanContainer');
    const instance = cmp.instance();
    instance.navigateNext();

    const actionShowPopUp = store.getActions().filter(a => {
      return a.type === 'app/modal/SET_REDRAW_SHOW_HIDE_POPUP';
    });
    expect(actionShowPopUp[0].payload).toEqual(true);
  });
  it('should call conditional navigateNext to hide popup and navigate to review screen', () => {
    store = mockStore(mockStoreData.valid[3]);
    const component = withTheme(
      <Router>
        <FixedOptionLoanContainer
          history={history}
          store={store}
          showRedrawFundsPopup={mockFn}
          match={{ path: '' }}
          {...props}
        />
      </Router>,
    );

    const wrapper = shallow(component, { context: { store } })
      .dive()
      .dive()
      .dive()
      .dive()
      .dive()
      .dive()
      .dive()
      .dive();
    const instance = wrapper.instance();
    instance.navigateNext();
    const backNav = store.getActions().filter(a => {
      return a.type === 'app/header/NAVIGATE_BACK';
    });
    expect(backNav[0].payload).toEqual('PREVIOUS');
  });
  it('should call show popup if accounts length is 0', () => {
    mockStoreData.valid[4].ui.securedLendingServicing.app.redrawShowHidePopup = false;
    store = mockStore(mockStoreData.valid[4]);

    const component = withTheme(
      <Router>
        <FixedOptionLoanContainer
          history={history}
          store={store}
          showRedrawFundsPopup={mockFn}
          match={{ path: '' }}
          {...props}
        />
      </Router>,
    );
    const wrapper = shallow(component, { context: { store } })
      .dive()
      .dive()
      .dive()
      .dive()
      .dive()
      .dive()
      .dive()
      .dive();
    const instance = wrapper.instance();

    instance.navigateNext();

    const actionShowPopUp = store.getActions().filter(a => {
      return a.type === 'app/modal/SET_REDRAW_SHOW_HIDE_POPUP';
    });
    expect(actionShowPopUp[0].payload).toEqual(true);
  });
  it('should call backToChannel when clicked on cancel button', () => {
    store = mockStore(mockStoreData.valid[2]);
    const component = withTheme(
      <Router>
        <FixedOptionLoanContainer
          history={history}
          store={store}
          match={{ path: '' }}
          {...props}
        />
      </Router>,
    );
    const wrapper = mount(component);
    const cmp = wrapper.find('FixedOptionLoanContainer');
    const instance = cmp.instance();
    instance.backToChannel();
    const backNav = store.getActions().filter(a => {
      return a.type === 'app/header/NAVIGATE_BACK';
    });
    expect(backNav[0].payload).toEqual('PREVIOUS');
  });

  it('should call onFixedRateRadioChange', () => {
    store = mockStore(mockStoreData.valid[0]);
    const event = { target: { value: 'test' } };
    const component = withTheme(
      <Router>
        <FixedOptionLoanContainer
          history={history}
          store={store}
          onFixedRateRadioChange={mockFn}
          match={{ path: '' }}
          {...props}
        />
      </Router>,
    );
    const wrapper = mount(component);
    const cmp = wrapper.find('FixedOptionLoanContainer');
    const instance = cmp.instance();
    instance.onFixedRateRadioChange(event);
    const optiontoSelect = store.getActions().filter(a => {
      return a.type === 'app/interestrate/SET_FIXED_OPTION_RATE';
    });
    expect(optiontoSelect[0].payload).toEqual('test');
  });

  it('should call onSplitAmountEnter ', () => {
    store = mockStore(mockStoreData.valid[0]);
    const event = { target: { value: '1.11' } };
    const component = withTheme(
      <Router>
        <FixedOptionLoanContainer
          history={history}
          store={store}
          onSplitAmountEnter={mockFn}
          match={{ path: '' }}
          {...props}
        />
      </Router>,
    );
    const wrapper = mount(component);
    const cmp = wrapper.find('FixedOptionLoanContainer');
    const instance = cmp.instance();
    instance.onSplitAmountEnter(event);
    const amountEntered = store.getActions().filter(a => {
      return a.type === 'app/interestrate/SET_INPUT_VALUE_DATA';
    });
    expect(amountEntered[0].payload).toEqual('1.11');
  });

  it('should call showAlertMessage ', () => {
    store = mockStore(mockStoreData.valid[3]);
    const component = withTheme(
      <Router>
        <FixedOptionLoanContainer
          history={history}
          store={store}
          showAlertMessage={mockFn}
          match={{ path: '' }}
          {...props}
        />
      </Router>,
    );
    const wrapper = shallow(component, { context: { store } })
      .dive()
      .dive()
      .dive()
      .dive()
      .dive()
      .dive()
      .dive()
      .dive();
    const instance = wrapper.instance();

    instance.showAlertMessage();
    const alertMsgAction = store.getActions().filter(a => {
      return a.type === 'app/interestrate/SET_REDRAW_ALERT_MESSAGE';
    });
    expect(alertMsgAction[0].payload).toEqual(
      'This transfer will only take place once you’ve submitted your request and it’s processed',
    );
  });
  it('should not call showAlertMessage if message has value', () => {
    store = mockStore(mockStoreData.valid[0]);
    const event = { target: { value: '' } };
    const component = withTheme(
      <Router>
        <FixedOptionLoanContainer
          history={history}
          store={store}
          showAlertMessage={mockFn}
          match={{ path: '' }}
        />
      </Router>,
    );
    const wrapper = mount(component);
    const cmp = wrapper.find('FixedOptionLoanContainer');
    const instance = cmp.instance();
    instance.showAlertMessage(event);
    const alerMsgAction = store.getActions().filter(a => {
      return a.type === 'app/interestrate/SET_REDRAW_ALERT_MESSAGE';
    });
    expect(alerMsgAction.length).toEqual(0);
  });

  it('should update title and button text on componentdidupdate', () => {
    store = mockStore(mockStoreData.valid[3]);
    const event = { target: { value: '' } };
    const component = withTheme(
      <Router>
        <FixedOptionLoanContainer
          history={history}
          store={store}
          showAlertMessage={mockFn}
          match={{ path: '' }}
        />
      </Router>,
    );
    const wrapper = shallow(component, { context: { store } })
      .dive()
      .dive()
      .dive()
      .dive()
      .dive()
      .dive()
      .dive()
      .dive();
    const instance = wrapper.instance();
    instance.componentDidUpdate(event);
    const alertMsgAction = store.getActions().filter(a => {
      return a.type === 'app/interestrate/SET_REDRAW_ALERT_MESSAGE';
    });
    const modalTitleAction = store.getActions().filter(a => {
      return a.type === 'app/modal/SET_REDRAW_MODAL_TITLE';
    });
    const modalButtonAction = store.getActions().filter(a => {
      return a.type === 'app/modal/SET_REDRAW_MODAL_BUTTON_TEXT';
    });
    expect(alertMsgAction[0].payload).toEqual(
      'This transfer will only take place once you’ve submitted your request and it’s processed',
    );
    expect(modalTitleAction[0].payload).toEqual('Redraw available funds');
    expect(modalButtonAction[0].payload).toEqual('Next');
  });

  it('should call selectAccountToTransfer ', () => {
    store = mockStore(mockStoreData.valid[2]);
    const component = withTheme(
      <Router>
        <FixedOptionLoanContainer
          history={history}
          store={store}
          selectAccountToTransfer={mockFn}
          match={{ path: '' }}
          {...props}
        />
      </Router>,
    );
    const wrapper = mount(component);
    const cmp = wrapper.find('FixedOptionLoanContainer');
    const instance = cmp.instance();
    const event = { target: { value: '1111' } };

    instance.selectAccountToTransfer(event);
  });

  it('should call onClickCalculateRepayments when clicked on toggled or show review button link clicked', () => {
    props.selectedLoanOption = 'SplitLoanOption';
    props.inputAmountData = 32000;

    store = mockStore(mockStoreData.valid[0]);
    const component = withTheme(
      <Router>
        <FixedOptionLoanContainer
          history={history}
          store={store}
          match={{ path: '' }}
          {...props}
        />
      </Router>,
    );
    const wrapper = mount(component);
    const cmp = wrapper.find('FixedOptionLoanContainer');
    const instance = cmp.instance();
    instance.onClickCalculateRepayments();
    const setFixedAmount = store.getActions().filter(a => {
      return a.type === 'app/interestrate/SET_SPLIT_FIXED_AMOUNT';
    });
    const setSplitAmount = store.getActions().filter(a => {
      return a.type === 'app/interestrate/SET_SPLIT_VARIABLE_AMOUNT';
    });
    expect(setFixedAmount[0].payload).toEqual(95.7);
    expect(setSplitAmount[0].payload).toEqual(1018.5);
  });
  it('should call componentDidUpdate', () => {
    store = mockStore(mockStoreData.valid[5]);
    const component = withTheme(
      <Router>
        <FixedOptionLoanContainer
          history={history}
          store={store}
          match={{ path: '' }}
          {...props}
        />
      </Router>,
    );
    const wrapper = mount(component);
    const cmp = wrapper.find('FixedOptionLoanContainer');
    const instance = cmp.instance();
    instance.componentDidUpdate();
    const expectedActions = sortBy(
      [
        {
          type: 'getRedrawAccounts',
        },
        { type: 'app/header/NAVIGATE_BACK' },
        {
          type: 'app/interestrate/SET_REDRAW_ALERT_MESSAGE',
        },
        {
          type: 'app/modal/SET_REDRAW_MODAL_BUTTON_TEXT',
        },
        {
          type: 'app/modal/SET_REDRAW_MODAL_TITLE',
        },
        { type: 'common/analytics/LOAD' },
      ],
      ['type'],
    );
    let actions = store.getActions().map(a => pick(a, 'type'));

    actions = sortBy(actions, ['type']);

    expect(actions).toEqual(expectedActions);
  });

  it('should call onFixedRateRadioChange to set fixed amount for repayments for AccessFundsOption and Redraw', () => {
    store = mockStore(mockStoreData.valid[0]);
    const event = { target: { value: 'RedrawFundsOption' } };
    const component = withTheme(
      <Router>
        <FixedOptionLoanContainer
          history={history}
          store={store}
          onFixedRateRadioChange={mockFn}
          match={{ path: '' }}
          {...props}
        />
      </Router>,
    );
    const wrapper = mount(component);
    const cmp = wrapper.find('FixedOptionLoanContainer');
    const instance = cmp.instance();
    instance.onFixedRateRadioChange(event);
    const optiontoSelect = store.getActions().filter(a => {
      return a.type === 'app/interestrate/SET_SPLIT_FIXED_AMOUNT';
    });
    expect(optiontoSelect[0].payload).toEqual(2046);
  });

  it('should reset fixed amount if loan option is not redraw or clear as we need to calculate incase of split on call of onFixedRateRadioChange ', () => {
    store = mockStore(mockStoreData.valid[0]);
    const event = { target: { value: 'Test' } };
    const component = withTheme(
      <Router>
        <FixedOptionLoanContainer
          history={history}
          store={store}
          onFixedRateRadioChange={mockFn}
          match={{ path: '' }}
          {...props}
        />
      </Router>,
    );
    const wrapper = mount(component);
    const cmp = wrapper.find('FixedOptionLoanContainer');
    const instance = cmp.instance();
    instance.onFixedRateRadioChange(event);
    const optiontoSelect = store.getActions().filter(a => {
      return a.type === 'app/interestrate/SET_SPLIT_FIXED_AMOUNT';
    });
    expect(optiontoSelect[0].payload).toEqual('');
  });

  it('should show redraw popup and reset dropdown index as 0 on call of navigateNext when clicked on next button', () => {
    store = mockStore(mockStoreData.valid[6]);
    const component = withTheme(
      <Router>
        <FixedOptionLoanContainer
          history={history}
          store={store}
          match={{ path: '' }}
          {...props}
        />
      </Router>,
    );
    const wrapper = shallow(component, { context: { store } })
      .dive()
      .dive()
      .dive()
      .dive()
      .dive()
      .dive()
      .dive()
      .dive();
    const instance = wrapper.instance();
    instance.navigateNext();
    const optiontoSelect = store.getActions().filter(a => {
      return a.type === 'app/interestrate/SET_FIELD_SELECT_VALUE';
    });
    expect(optiontoSelect[0].payload).toEqual('0');
  });

  it('should set the title of redraw popup Exit form if no accounts are loaded', () => {
    store = mockStore(mockStoreData.valid[5]);
    const component = withTheme(
      <Router>
        <FixedOptionLoanContainer
          history={history}
          store={store}
          match={{ path: '' }}
          {...props}
        />
      </Router>,
    );
    const wrapper = mount(component);
    const cmp = wrapper.find('FixedOptionLoanContainer');
    const instance = cmp.instance();
    instance.componentDidUpdate();
    const optiontoSelect = store.getActions().filter(a => {
      return a.type === 'app/modal/SET_REDRAW_MODAL_BUTTON_TEXT';
    });
    expect(optiontoSelect[0].payload).toEqual('Exit form');

    const optionTitle = store.getActions().filter(a => {
      return a.type === 'app/modal/SET_REDRAW_MODAL_TITLE';
    });
    expect(optionTitle[0].payload).toEqual('Redraw available funds');
  });

  it('should navigate to review page if option is redraw and account is selected from dropdown', () => {
    mockStoreData.valid[6].ui.securedLendingServicing.app.selectedAccount = '1';
    store = mockStore(mockStoreData.valid[6]);
    const component = withTheme(
      <Router>
        <FixedOptionLoanContainer
          history={history}
          store={store}
          match={{ path: '' }}
          {...props}
        />
      </Router>,
    );
    const wrapper = shallow(component, { context: { store } })
      .dive()
      .dive()
      .dive()
      .dive()
      .dive()
      .dive()
      .dive()
      .dive();
    const instance = wrapper.instance();
    instance.navigateNext();
    expect(history.push).toHaveBeenCalled();
  });
  it('should show different header for redraw popup as We need to know more to continue with your request if redraw Indicator is false', () => {
    store = mockStore(mockStoreData.valid[7]);
    const component = withTheme(
      <Router>
        <FixedOptionLoanContainer
          history={history}
          store={store}
          match={{ path: '' }}
          {...props}
        />
      </Router>,
    );

    const wrapper = shallow(component, { context: { store } })
      .dive()
      .dive()
      .dive()
      .dive()
      .dive()
      .dive()
      .dive()
      .dive();
    const instance = wrapper.instance();
    instance.componentDidUpdate();
    const optiontoSelect = store.getActions().filter(a => {
      return a.type === 'app/modal/SET_REDRAW_MODAL_BUTTON_TEXT';
    });
    expect(optiontoSelect[0].payload).toEqual('Call us');

    const optionTitle = store.getActions().filter(a => {
      return a.type === 'app/modal/SET_REDRAW_MODAL_TITLE';
    });
    expect(optionTitle[0].payload).toEqual(
      'We need to know more to continue with your request',
    );
  });

  it('should set custom redraw funds account list with key value if api returns the redraw accounts', () => {
    store = mockStore(mockStoreData.valid[8]);
    const component = withTheme(
      <Router>
        <FixedOptionLoanContainer
          history={history}
          store={store}
          match={{ path: '' }}
          {...props}
        />
      </Router>,
    );
    const wrapper = mount(component);
    const cmp = wrapper.find('FixedOptionLoanContainer');
    const instance = cmp.instance();
    instance.navigateNext();
    const accounts = store.getActions().filter(a => {
      return a.type === 'app/interestrate/SET_REDRAW_FUNDS_ACCOUNTS';
    });
    expect(accounts[0].payload.length).toEqual(5);
  });
});
