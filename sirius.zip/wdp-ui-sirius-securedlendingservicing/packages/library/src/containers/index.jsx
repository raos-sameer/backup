import React from 'react';
import Loadable from 'react-loadable';

export const ErrorContainer = Loadable({
  loader: () => import('./ErrorContainer'),
  loading: () => <div />,
});

export const LandingPageContainer = Loadable({
  loader: () => import('./LandingPageContainer'),
  loading: () => <div />,
});

export const ConfirmationPageContainer = Loadable({
  loader: () => import('./ConfirmationPageContainer'),
  loading: () => <div />,
});

export const SelectInterestRateContainer = Loadable({
  loader: () => import('./SelectInterestRateContainer'),
  loading: () => <div />,
});

export const ReviewPageContainer = Loadable({
  loader: () => import('./ReviewPageContainer'),
  loading: () => <div />,
});

export const FixedOptionLoanContainer = Loadable({
  loader: () => import('./FixedOptionLoanContainer'),
  loading: () => <div />,
});
