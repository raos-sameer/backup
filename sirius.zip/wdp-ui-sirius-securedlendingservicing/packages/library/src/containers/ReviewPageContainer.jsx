/* eslint-disable no-console */
import PropTypes from 'prop-types';
import React from 'react';
import { connect } from 'react-redux';
import { compose } from 'recompose';
import { Redirect } from 'react-router-dom';
import { withTracking } from '@wdpui/common-analytics';
import { isArrangementsFetching as submitRequestLoading } from '@wdpui/redux-exp-sirius-securedlendingservicing-v1/selectors';

import { Loader } from '../components/common';

import { ReviewPageComponent } from '../components/ReviewPage/ReviewPageComponent';
import { formActions } from '../redux/actions/formActions';
import {
  getDashboardUrl,
  getBreakCostUrl,
  getCurrentLoanDetails,
  getSelectedLoanOption,
  getSelectedInterestRateForTerm,
  getSelectedYearTerm,
  getRepaymentType,
  getSelectedRedrawAccountLabel,
  getFixedRepaymentAmount,
  getVariableRepaymentAmount,
  getFixedLoanBalance,
  getVariableLoanBalance,
  getPackageIndicator,
  getSwitchingFee,
  getMonthlyMaintainenceFee,
  getProductName,
  getSubmitDetails,
  getSubmitSuccess,
  getSwitchedProductName,
  getSelectedDiscountRate,
} from '../redux/selectors';
import { actions as appActions } from '../redux/modules/app.module';
import { getAnalyticsTags } from '../helpers/analyticsHelper';
import { scrollWindow } from '../helpers/windowFunctionsHelper';
import { getInterestTileDiscountText } from '../helpers/selectTermHelper';

export class ReviewPageContainer extends React.Component {
  static propTypes = {
    channelDashboardUrl: PropTypes.string.isRequired,
    history: PropTypes.shape({
      push: PropTypes.func.isRequired,
    }).isRequired,
    updateHeaderBackNavigation: PropTypes.func.isRequired,
    breakCostUrl: PropTypes.string.isRequired,
    currentLoanDetails: PropTypes.shape({
      currentBalance: PropTypes.string.isRequired,
      availableBalance: PropTypes.string.isRequired,
      repaymentType: PropTypes.string.isRequired,
      monthlyRepayment: PropTypes.string.isRequired,
      variableInterestRate: PropTypes.string.isRequired,
      discounts: PropTypes.string.isRequired,
      redrawIndicatorSet: PropTypes.bool.isRequired,
    }).isRequired,
    switchedProductName: PropTypes.string.isRequired,
    yearTermSelected: PropTypes.string,
    selectedLoanOption: PropTypes.string,
    interestRateOptionSelected: PropTypes.string,
    selectedRepaymentType: PropTypes.string.isRequired,
    selectedAccountLabel: PropTypes.string,
    splitVariableAmount: PropTypes.string.isRequired,
    splitFixedAmount: PropTypes.string.isRequired,
    variableLoanBalance: PropTypes.string.isRequired,
    fixedLoanBalance: PropTypes.string.isRequired,
    isPackageCustomer: PropTypes.bool.isRequired,
    switchFee: PropTypes.string.isRequired,
    monthlyMaintainence: PropTypes.string.isRequired,
    productName: PropTypes.string.isRequired,
    postSubmitDetails: PropTypes.func.isRequired,
    submitDetails: PropTypes.shape({
      caseId: PropTypes.string.isRequired,
      caseReferenceNumber: PropTypes.string.isRequired,
    }).isRequired,
    submitAction: PropTypes.string.isRequired,
    selectedDiscountRate: PropTypes.string.isRequired,
    isSubmitRequestLoading: PropTypes.bool,
  };

  static defaultProps = {
    interestRateOptionSelected: '',
    selectedLoanOption: '',
    yearTermSelected: '',
    selectedAccountLabel: '',
    isSubmitRequestLoading: false,
  };

  componentDidMount() {
    const { updateHeaderBackNavigation } = this.props;
    scrollWindow();
    updateHeaderBackNavigation('PREVIOUS');
  }

  backToChannel = () => {
    const { channelDashboardUrl } = this.props;
    window.location.replace(channelDashboardUrl);
  };

  navigateNext = () => {
    const { history, postSubmitDetails } = this.props;
    postSubmitDetails(history);
  };

  render() {
    const {
      yearTermSelected,
      selectedLoanOption,
      interestRateOptionSelected,
      breakCostUrl,
      currentLoanDetails: {
        currentBalance: { amount: currBalance },
        availableBalance: { amount: availBalance },
        monthlyRepayment,
        repaymentType,
        variableInterestRate,
        redrawIndicatorSet,
      },
      switchedProductName,
      selectedRepaymentType,
      selectedAccountLabel,
      splitVariableAmount,
      splitFixedAmount,
      fixedLoanBalance,
      variableLoanBalance,
      isPackageCustomer,
      switchFee,
      monthlyMaintainence,
      productName,
      submitAction,
      selectedDiscountRate,
      isSubmitRequestLoading,
    } = this.props;

    if (isSubmitRequestLoading) {
      return <Loader />;
    }

    if (submitAction === 'SUCCESS') {
      return <Redirect to="/securedlendingservicing/receipt" />;
    }
    if (submitAction === 'ERROR') {
      return <Redirect to="/securedlendingservicing/error" />;
    }
    const selectedDiscountText = getInterestTileDiscountText(
      selectedDiscountRate,
    );

    return (
      <ReviewPageComponent
        selectedAccountLabel={selectedAccountLabel}
        switchFee={switchFee}
        monthlyMaintainence={monthlyMaintainence}
        selectedLoanOption={selectedLoanOption}
        backToChannel={this.backToChannel}
        navigateNext={this.navigateNext}
        loanBalance={currBalance}
        availableFunds={redrawIndicatorSet ? availBalance : 0}
        advantagePackage={isPackageCustomer}
        interestRate={interestRateOptionSelected}
        repaymentType={repaymentType}
        selectedRepaymentType={selectedRepaymentType}
        loanTerm={yearTermSelected}
        monthlyRepayments={monthlyRepayment}
        breakCostUrl={breakCostUrl}
        splitVariableAmount={splitVariableAmount}
        splitFixedAmount={splitFixedAmount}
        calculatedVariableLoanBalance={variableLoanBalance}
        calculatedFixedLoanBalance={fixedLoanBalance}
        variableInterestRate={variableInterestRate}
        productName={productName}
        switchedProductName={switchedProductName}
        selectedDiscountText={selectedDiscountText}
      />
    );
  }
}

const mapStateToProps = state => ({
  isPackageCustomer: getPackageIndicator(state),
  breakCostUrl: getBreakCostUrl(state),
  currentLoanDetails: getCurrentLoanDetails(state),
  selectedLoanOption: getSelectedLoanOption(state),
  yearTermSelected: getSelectedYearTerm(state),
  selectedRepaymentType: getRepaymentType(state),
  interestRateOptionSelected: getSelectedInterestRateForTerm(state),
  selectedAccountLabel: getSelectedRedrawAccountLabel(state),
  splitFixedAmount: getFixedRepaymentAmount(state),
  splitVariableAmount: getVariableRepaymentAmount(state),
  fixedLoanBalance: getFixedLoanBalance(state),
  variableLoanBalance: getVariableLoanBalance(state),
  switchFee: getSwitchingFee(state),
  monthlyMaintainence: getMonthlyMaintainenceFee(state),
  productName: getProductName(state),
  channelDashboardUrl: getDashboardUrl(state),
  submitDetails: getSubmitDetails(state),
  submitAction: getSubmitSuccess(state),
  switchedProductName: getSwitchedProductName(state),
  selectedDiscountRate: getSelectedDiscountRate(state),
  isSubmitRequestLoading: submitRequestLoading(state),
});

const mapDispatchToProps = {
  updateHeaderBackNavigation: appActions.app.header.navigateBack,
  postSubmitDetails: formActions.submitDetails,
};
const enhance = compose(
  connect(mapStateToProps, mapDispatchToProps),
  withTracking((state, props) => getAnalyticsTags('REVIEW_PAGE', props)),
);
export default enhance(ReviewPageContainer);
