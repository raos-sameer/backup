/* eslint-disable no-console */
import React from 'react';
import configureMockStore from 'redux-mock-store';
import { shallow, mount } from 'enzyme';
import { BrowserRouter as Router } from 'react-router-dom';
import EnhancedConfirmationPageContainer from './ConfirmationPageContainer';
import { withTheme } from '../../../../utils/jest/TestUtils';
import { mockStoreData } from './__fixtures__/mockConfirmReviewDetailsLayout.fixture';

const mockStore = configureMockStore();

global.matchMedia = matches => () => ({
  matches,
  addListener: () => {},
  removeListener: () => {},
});

const props = {
  loanTerm: '1',
  contractedRepaymentDate: '23 Jan 2032',
  directDebitUrlInterestOnly:
    'https://www.westpac.com.au/content/dam/public/wbc/documents/pdf/pb/Direct_Debit_Request_Interest_Only_Loan_Repayment.pdf',
  directDebitUrlPrincipalInterest:
    'https://www.westpac.com.au/content/dam/public/wbc/documents/pdf/pb/Direct_Debit_Request_Loan_Repayment.pdf',
  messageInboxUrl: 'https://www.westpac.com.au',
  bsbNumber: '112-879',
  accountNumber: '1124556',
  accountName: 'Westpac choice',
  switchFee: '558',
};
describe('ConfirmationPageContainer', () => {
  let store;
  const spy = jest.spyOn(global.console, 'error');
  const history = {
    push: jest.fn(),
    replace: jest.fn(),
  };

  window.location.replace = jest.fn();

  afterEach(() => {
    if (store && store.clearActions) {
      store.clearActions();
    }
    if (spy && spy.mockReset && spy.mockRestore) {
      spy.mockReset();
      spy.mockRestore();
    }
    if (history && history.push) {
      history.push.mockReset();
      history.replace.mockReset();
      history.push.mockRestore();
      history.replace.mockRestore();
    }
  });

  it('should render without error when required props are passed', () => {
    store = mockStore(mockStoreData.valid[0]);
    const otherprops = {
      advantagePackage: true,
      loanType: 'REDRAW',
      availableBalance: '100,000',
      repaymentType: 'IO',
    };
    const component = withTheme(
      <EnhancedConfirmationPageContainer
        history={history}
        match={{ path: '' }}
        {...props}
        {...otherprops}
      />,
    );
    shallow(component, { context: { store } }).dive();
    expect(spy).not.toHaveBeenCalled();
  });
  it('should call backToChannel', () => {
    store = mockStore(mockStoreData.valid[0]);
    const component = withTheme(
      <Router>
        <EnhancedConfirmationPageContainer
          history={history}
          store={store}
          match={{ path: '' }}
        />
      </Router>,
    );
    const wrapper = mount(component);
    const cmp = wrapper.find('ConfirmationPageContainer');
    const instance = cmp.instance();
    instance.backToChannel();
    expect(window.location.replace).toHaveBeenCalled();
  });

  it('should render different options when loan type is REDRAW', () => {
    store = mockStore(mockStoreData.valid[0]);
    const redrawprops = {
      advantagePackage: true,
      loanType: 'REDRAW',
      availableBalance: '100,000',
      repaymentType: 'IO',
    };
    const component = withTheme(
      <EnhancedConfirmationPageContainer {...props} {...redrawprops} />,
    );
    const wrapper = shallow(component, { context: { store } });
    expect(wrapper).toMatchSnapshot();
  });
  it('should render different options when loan type is SPLIT', () => {
    store = mockStore(mockStoreData.valid[0]);
    const redrawprops = {
      advantagePackage: true,
      loanType: 'SPLIT',
      availableBalance: '100,000',
      repaymentType: 'IO',
    };
    const component = withTheme(
      <EnhancedConfirmationPageContainer {...props} {...redrawprops} />,
    );
    const wrapper = shallow(component, { context: { store } });
    expect(wrapper).toMatchSnapshot();
  });
  it('should render different options when loan type is CLEAR', () => {
    store = mockStore(mockStoreData.valid[0]);
    const redrawprops = {
      advantagePackage: true,
      loanType: 'CLEAR',
      availableBalance: '100,000',
      repaymentType: 'IO',
    };
    const component = withTheme(
      <EnhancedConfirmationPageContainer {...props} {...redrawprops} />,
    );
    const wrapper = shallow(component, { context: { store } });
    expect(wrapper).toMatchSnapshot();
  });

  it('should render different options when no available balance', () => {
    store = mockStore(mockStoreData.valid[0]);
    const redrawprops = {
      advantagePackage: true,
      loanType: '',
      availableBalance: '',
      repaymentType: 'IO',
    };
    const component = withTheme(
      <EnhancedConfirmationPageContainer {...props} {...redrawprops} />,
    );
    const wrapper = shallow(component, { context: { store } });
    expect(wrapper).toMatchSnapshot();
  });
  it('should render different options when its not package customer', () => {
    store = mockStore(mockStoreData.valid[0]);
    const redrawprops = {
      advantagePackage: false,
      loanType: '',
      availableBalance: '',
      repaymentType: 'IO',
    };
    const component = withTheme(
      <EnhancedConfirmationPageContainer {...props} {...redrawprops} />,
    );
    const wrapper = shallow(component, { context: { store } });
    expect(wrapper).toMatchSnapshot();
  });
});
