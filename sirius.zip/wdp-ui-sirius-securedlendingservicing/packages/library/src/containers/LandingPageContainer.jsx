import React from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { compose, branch, mapProps } from 'recompose';
import { Redirect } from 'react-router-dom';
import { withTracking } from '@wdpui/common-analytics';
import { withContextsById } from '@wdpui/redux-exp-sirius-core-v1';

import { isEmpty, get } from 'lodash';
import {
  isContextsError as getContextsError,
  isContextsFetching as getContextsFetching,
} from '@wdpui/redux-exp-sirius-core-v1/selectors';

import {
  isEligibilitiesFetching as getCustomersEligibilityFetching,
  isEligibilitiesError as getCustomersEligibilityError,
  isArrangementsError as getCurrentLoanDetailsError,
  isArrangementsFetching as getCurrentLoanDetailsFetching,
} from '@wdpui/redux-exp-sirius-securedlendingservicing-v1/selectors';
import { QUERY_PARAMS } from '../helpers/constants';

import { queryStringParse } from '../helpers/queryHelper';
import { scrollWindow } from '../helpers/windowFunctionsHelper';

import {
  getDashboardUrl,
  getBreakCostUrl,
  getCurrentLoanDetails,
  getPackageIndicator,
  getCustomersEligibility,
  isEligibilityCaseExistsError,
  isEligibilityError,
  getFlexiIndicator,
  getSwitchingFee,
  getMonthlyMaintainenceFee,
  getAdditionalPaymentAmount,
  getContextsExpired,
} from '../redux/selectors';

import { LandingPage } from '../components';
import { actions as appActions } from '../redux/modules/app.module';
import { formActions } from '../redux/actions/formActions';
import { Loader } from '../components/common';
import { getAnalyticsTags } from '../helpers/analyticsHelper';

export class LandingPageContainer extends React.Component {
  static propTypes = {
    isContextsFetching: PropTypes.bool,
    isContextsError: PropTypes.bool,
    isCustomersEligibilityFetching: PropTypes.bool,
    isCustomersEligibilityError: PropTypes.bool,
    isCurrentLoanDetailsFetching: PropTypes.bool,
    isCurrentLoanDetailsError: PropTypes.bool,
    fetchCurrentLoanDetails: PropTypes.func,
    history: PropTypes.shape({
      push: PropTypes.func.isRequired,
    }).isRequired,
    breakCostUrl: PropTypes.string.isRequired,
    updateHeaderBackNavigation: PropTypes.func.isRequired,
    isFlexiProduct: PropTypes.bool.isRequired,
    isPackageCustomer: PropTypes.bool.isRequired,
    fetchEligibility: PropTypes.func,
    currentLoanDetails: PropTypes.arrayOf(PropTypes.shape({})).isRequired,
    loanCaseExists: PropTypes.bool.isRequired,
    isEligibilityNonCaseExistsError: PropTypes.bool.isRequired,
    switchFee: PropTypes.string.isRequired,
    monthlyMaintainence: PropTypes.string.isRequired,
    additionalPaymentAmount: PropTypes.string.isRequired,
    channelDashboardUrl: PropTypes.string.isRequired,
    isContextsExpired: PropTypes.bool,
  };

  static defaultProps = {
    fetchCurrentLoanDetails: () => {},
    fetchEligibility: () => {},
    isCustomersEligibilityFetching: false,
    isContextsFetching: false,
    isContextsError: false,
    isCustomersEligibilityError: false,
    isCurrentLoanDetailsError: false,
    isContextsExpired: false,
    isCurrentLoanDetailsFetching: false,
  };

  componentDidMount() {
    const { updateHeaderBackNavigation } = this.props;
    scrollWindow();
    updateHeaderBackNavigation('CHANNEL');
  }

  componentDidUpdate() {
    const {
      isContextsFetching,
      isCustomersEligibilityFetching,
      isCustomersEligibilityError,
      fetchEligibility,
    } = this.props;

    if (
      !isContextsFetching &&
      !isCustomersEligibilityFetching &&
      !isCustomersEligibilityError
    ) {
      fetchEligibility();
    }
  }

  navigateNext = () => {
    const {
      history,
      fetchCurrentLoanDetails,
      currentLoanDetails: { repaymentType },
    } = this.props;

    if (isEmpty(repaymentType)) {
      fetchCurrentLoanDetails();
    }
    history.push('/securedlendingservicing/selectterm');
  };

  backToChannel = () => {
    const { channelDashboardUrl } = this.props;
    window.location.replace(channelDashboardUrl);
  };

  render() {
    const {
      isContextsFetching,
      isContextsError,
      isCustomersEligibilityFetching,
      isCustomersEligibilityError,
      isContextsExpired,
      isPackageCustomer,
      isFlexiProduct,
      breakCostUrl,
      loanCaseExists,
      isEligibilityNonCaseExistsError,
      isCurrentLoanDetailsError,
      isCurrentLoanDetailsFetching,
      switchFee,
      monthlyMaintainence,
      additionalPaymentAmount,
    } = this.props;
    if (loanCaseExists) {
      return <Redirect to="/securedlendingservicing/error?code=caseexists" />;
    }
    if (isEligibilityNonCaseExistsError) {
      return (
        <Redirect to="/securedlendingservicing/error?code=eligibilityfail" />
      );
    }
    if (
      isContextsError ||
      isCustomersEligibilityError ||
      isCurrentLoanDetailsError ||
      isContextsExpired
    ) {
      return <Redirect to="/securedlendingservicing/error" />;
    }

    if (
      isContextsFetching ||
      isCustomersEligibilityFetching ||
      isCurrentLoanDetailsFetching
    ) {
      return <Loader />;
    }

    return (
      <LandingPage
        backToChannel={this.backToChannel}
        navigateNext={this.navigateNext}
        breakCostUrl={breakCostUrl}
        advantagePackage={isPackageCustomer}
        isFlexiProduct={isFlexiProduct}
        switchFee={switchFee}
        monthlyMaintainence={monthlyMaintainence}
        additionalPaymentAmount={additionalPaymentAmount}
      />
    );
  }
}

const mapStateToProps = state => ({
  isContextsError: getContextsError(state),
  isContextsFetching: getContextsFetching(state),
  isCustomersEligibilityFetching: getCustomersEligibilityFetching(state),
  isCustomersEligibilityError: getCustomersEligibilityError(state),
  isPackageCustomer: getPackageIndicator(state),
  breakCostUrl: getBreakCostUrl(state),
  currentLoanDetails: getCurrentLoanDetails(state),
  eligibilityData: getCustomersEligibility(state),
  loanCaseExists: isEligibilityCaseExistsError(state),
  isEligibilityNonCaseExistsError: isEligibilityError(state),
  isFlexiProduct: getFlexiIndicator(state),
  isCurrentLoanDetailsError: getCurrentLoanDetailsError(state),
  isCurrentLoanDetailsFetching: getCurrentLoanDetailsFetching(state),
  switchFee: getSwitchingFee(state),
  monthlyMaintainence: getMonthlyMaintainenceFee(state),
  additionalPaymentAmount: getAdditionalPaymentAmount(state),
  channelDashboardUrl: getDashboardUrl(state),
  isContextsExpired: getContextsExpired(state),
});

const mapDispatchToProps = {
  updateHeaderBackNavigation: appActions.app.header.navigateBack,
  fetchEligibility: formActions.getCustomerEligibility,
  fetchCurrentLoanDetails: formActions.getCurrentLoanDetails,
};

const enhance = compose(
  connect(mapStateToProps, mapDispatchToProps),

  mapProps(({ ...rest }) => {
    const queryParams = queryStringParse(window.location.search);
    const contextRefId = get(queryParams, QUERY_PARAMS.REFID, '');
    return {
      contextRefId,
      ...rest,
    };
  }),
  branch(
    ({ contextRefId }) => contextRefId,
    withContextsById((_, { contextRefId }) => {
      return {
        pathParams: {
          id: contextRefId,
        },
      };
    }),
  ),
  withTracking((state, props) => getAnalyticsTags('LANDING_PAGE', props)),
);

export default enhance(LandingPageContainer);
