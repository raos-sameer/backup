import React from 'react';
import { Text } from '@wdpui/gel-typography';
import { Row, Column } from '@wdpui/gel-grid';
import styled from 'styled-components';

import { Radio } from '@wdpui/gel-radio';
import { Button } from '@wdpui/gel-button';

import { Input } from '@wdpui/gel-input';
import { FieldInputGroup } from '@wdpui/gel-field-inputgroup';

import { InputGroupAddon } from '@wdpui/gel-inputgroup';
import PropTypes from 'prop-types';
import { AlertBox } from '@wdpui/gel-alertbox';
import {
  ActionButtons,
  StyledRadioWithHintText,
  FocusedPageTitle,
} from '../common';
import ConnectedReviewModalPopUp from '../ReviewModalPopUp';
import ConnectedRedrawFundsPopup from './RedrawFundsPopup';
import { NewLoanSummary } from './NewLoanSummary';
import { ThingsYouKnow } from './ThingsYouKnow';
import {
  isSplitLoan,
  isFixedOptionCheckBoxChecked,
  showNewLoanDetails,
  isRedrawLoan,
  isClearLoan,
  getNegatedAmountText,
  getHintTextForSplitFixedAmount,
  validateAmount,
  isAvailableFunds,
  getFixedOptionLoanHeader,
} from '../../helpers/loanOptionsHelper';
import {
  formatAmount,
  formatToTwoDecimalPlaces,
} from '../../helpers/amountFormatter';

import {
  PanelWhiteWithBorder,
  HeadingColouredText,
  MutedText,
  StyledGridPnl,
  StyledRowPnl,
  StyledColumnPnl,
  PaddedBox,
  LinkButton,
  HR,
  StyledIconAdd,
} from '../common/styles';

export const StyledNewColumn = styled(Column)`
  margin-left: -6px;
  @media (max-width: 768px) {
    margin-left: 0px;
  }
`;

export const StyledMutedText = styled(MutedText)`
  margin-top: 18px;
  margin-bottom: 6px;
`;

export const StyledHR = styled(HR)`
  margin-top: 24px;
  margin-bottom: 36px;
  @media (max-width: 480px) {
    margin-bottom: 30px;
  }
`;

export const StyledColumn = styled(Column)`
  margin-bottom: 12px;
  @media (max-width: 480px) {
    margin-bottom: 6px;
  }
`;
export const NewStyledMutedText = styled(MutedText)`
  margin-top: -24px;
  @media only screen and (max-width: 768px) {
    margin-top: -18px;
  }
`;

export const RowInput = styled(Row)`
  width: 194px;
  margin-left: 0px;
  flex-direction: column;
`;

export const IndicativeRateText = styled(MutedText)`
  margin-bottom: -4px;
`;

export const StyledAmountRow = styled(Row)`
  margin-top: -24px;
  margin-left: 24px;
`;

export const StyledAlertBox = styled(AlertBox)`
  margin-bottom: 0px;
`;

export const FixedOptionLoanPage = ({
  onFixedRateRadioChange,
  selectedLoanOption,
  onSplitAmountEnter,
  inputAmountData,
  isPackageCustomer,
  currentBalance,
  variableInterestRate,
  loanMaturityDate,
  repaymentType,
  showReviewDetailsPopup,
  hideReviewDetailsPopup,
  navigateNext,
  backToChannel,
  showHidePopUp,
  interestRate,
  monthlyRepayment,
  availableFunds,
  yearTerm,
  redrawShowHidePopup,
  hideRedrawFundsPopup,
  redrawModalTitle,
  redrawModalButtonText,
  redrawAlertBoxMessage,
  redrawFundAccountsList,
  selectAccountToTransfer,
  selectedAccount,
  onClickCalculateRepayments,
  splitVariableAmount,
  splitFixedAmount,
  interestOnlyMaturityDate,
  calculatedVariableLoanBalance,
  calculatedFixedLoanBalance,
  amountValidationMessage,
  redrawIndicator,
  productName,
  switchedProductName,
  totalIndicativeRepayment,
  monthlyMaintainence,
}) => (
  <StyledGridPnl id="gridPnlFixedOption">
    {showHidePopUp && (
      <ConnectedReviewModalPopUp
        showPopUp={showHidePopUp}
        modalTitle="Current loan details"
        currentBalance={currentBalance}
        availableBalance={availableFunds}
        varInterestRate={formatToTwoDecimalPlaces(variableInterestRate)}
        loanMaturityDate={loanMaturityDate}
        repaymentType={repaymentType}
        interestOnlyMatDate={interestOnlyMaturityDate}
        monthlyRepayment={monthlyRepayment}
        advantagePackage={isPackageCustomer}
        closeButtonText="Close"
        closeButtonClick={hideReviewDetailsPopup}
        panelTitle={productName}
        redrawIndicatorSet={redrawIndicator}
      />
    )}
    {redrawShowHidePopup && (
      <ConnectedRedrawFundsPopup
        redrawShowHidePopup={redrawShowHidePopup}
        redrawModalTitle={redrawModalTitle}
        hideRedrawFundsPopup={hideRedrawFundsPopup}
        redrawModalButtonText={redrawModalButtonText}
        redrawAlertBoxMessage={redrawAlertBoxMessage}
        redrawFundAccountsList={redrawFundAccountsList}
        onFieldSelectChange={selectAccountToTransfer}
        selectedAccount={selectedAccount}
        navigateNext={navigateNext}
        redrawIndicator={redrawIndicator}
      />
    )}
    <StyledRowPnl>
      <FocusedPageTitle
        title={getFixedOptionLoanHeader(interestRate, yearTerm)}
      />
    </StyledRowPnl>
    <PanelWhiteWithBorder
      direction="column"
      aria-hidden={redrawShowHidePopup || showHidePopUp ? 'true' : 'false'}
    >
      {amountValidationMessage && (
        <StyledAlertBox
          styling="warning"
          hasIcon
          mt={24}
          role="alert"
          aria-live="assertive"
        >
          {amountValidationMessage}
        </StyledAlertBox>
      )}
      <Column px={2} pb={4}>
        <HeadingColouredText weight="medium" size={2}>
          How much would you like to fix?
        </HeadingColouredText>
        {currentBalance && (
          <MutedText size={1}>
            Your current balance is
            <b> {getNegatedAmountText(currentBalance, true)}</b>
          </MutedText>
        )}
        <Row id="loanoptions" direction="column">
          <Column>
            <Radio
              id="rdFixedLoan"
              name="rdFixedLoan"
              block
              onChange={onFixedRateRadioChange}
              label="Fix entire loan"
              value="FixedLoanOption"
              checked={isFixedOptionCheckBoxChecked(selectedLoanOption)}
            />
            <Radio
              id="rdSplitLoan"
              name="rdSplitLoan"
              value="SplitLoanOption"
              label="Split loan and fix a portion"
              onChange={onFixedRateRadioChange}
              checked={isSplitLoan(selectedLoanOption)}
            />
          </Column>
        </Row>
        {isFixedOptionCheckBoxChecked(selectedLoanOption) &&
          isAvailableFunds(availableFunds) && (
            <Text size={2} weight="medium">
              You currently have {formatAmount(availableFunds)} in available
              funds. What would like to do with them?
            </Text>
          )}
        {isFixedOptionCheckBoxChecked(selectedLoanOption) &&
          isAvailableFunds(availableFunds) && (
            <>
              <StyledRadioWithHintText
                radioId="rdRedrawLoan"
                radioValue="RedrawFundsOption"
                radioLabel="Redraw funds"
                isChecked={isRedrawLoan(selectedLoanOption)}
                onChangeFn={onFixedRateRadioChange}
                hintText=" Your loan balance will increase when these funds are transferred  out"
              />
              <StyledRadioWithHintText
                radioId="rdClearLoan"
                radioValue="AccessFundsOption"
                radioLabel="Clear access to funds"
                isChecked={isClearLoan(selectedLoanOption)}
                onChangeFn={onFixedRateRadioChange}
                hintText="  You'll keep your current loan balance and won't be
          able to redraw these funds in the future"
              />
            </>
          )}
        {isSplitLoan(selectedLoanOption) && (
          <>
            <StyledAmountRow id="amountrow" direction="column">
              <StyledNewColumn width={[1]}>
                <StyledMutedText>Enter an amount to fix</StyledMutedText>
                <RowInput>
                  <FieldInputGroup
                    style={{ marginBottom: '0px' }}
                    name="fldSplitFixedAmount"
                    id="fldSplitFixedAmount"
                    errorMessage={`${
                      !validateAmount(inputAmountData, currentBalance)
                        ? 'Enter a valid amount'
                        : ''
                    }`}
                    inputGroupProps={`${
                      !validateAmount(inputAmountData, currentBalance)
                        ? {
                            alertType: 'danger',
                          }
                        : ''
                    }`}
                  >
                    <InputGroupAddon label="$" />
                    <Input
                      type="number"
                      value={inputAmountData}
                      onChange={onSplitAmountEnter}
                    />
                  </FieldInputGroup>
                </RowInput>

                <NewStyledMutedText>
                  {getHintTextForSplitFixedAmount(currentBalance)}
                </NewStyledMutedText>
              </StyledNewColumn>
            </StyledAmountRow>
            <StyledHR />
            {!showNewLoanDetails(
              selectedLoanOption,
              splitFixedAmount,
              availableFunds,
            ) && (
              <Row>
                <StyledColumn width={[1, 255]} mx={12} px={0}>
                  <Button
                    block
                    soft
                    size="large"
                    styling="hero"
                    label="Calculate repayments"
                    onClick={onClickCalculateRepayments}
                  />
                </StyledColumn>
              </Row>
            )}
          </>
        )}

        {showNewLoanDetails(
          selectedLoanOption,
          splitFixedAmount,
          availableFunds,
        ) && (
          <>
            {!isSplitLoan(selectedLoanOption) && <StyledHR />}
            <HeadingColouredText size={2} weight="medium">
              New loan details
            </HeadingColouredText>
            <IndicativeRateText>
              Your current contracted monthly repayments are&nbsp;
              <b>{formatAmount(monthlyRepayment)}</b>
            </IndicativeRateText>
            <LinkButton
              p={0}
              styling="link"
              onClick={showReviewDetailsPopup}
              label=" See all current loan details"
            />
            <Column>
              <NewLoanSummary
                title={switchedProductName}
                loanType={selectedLoanOption}
                compType="Fixed"
                loanBalance={calculatedFixedLoanBalance}
                interestRate={formatToTwoDecimalPlaces(interestRate)}
                loanTerm={yearTerm}
                monthlyRepayments={splitFixedAmount}
                unlimitedRepayment={false}
                isPackageCustomer={isPackageCustomer}
                monthlyMaintainence={monthlyMaintainence}
              />
              {isSplitLoan(selectedLoanOption) && (
                <>
                  <StyledIconAdd />
                  <NewLoanSummary
                    title={productName}
                    loanType={selectedLoanOption}
                    compType="Variable"
                    loanBalance={calculatedVariableLoanBalance}
                    interestRate={formatToTwoDecimalPlaces(
                      variableInterestRate,
                    )}
                    loanTerm={yearTerm}
                    monthlyRepayments={splitVariableAmount}
                    unlimitedRepayment
                    isPackageCustomer={isPackageCustomer}
                    monthlyMaintainence={monthlyMaintainence}
                  />
                  <b>
                    Total indicative fixed + variable monthly repayments{' '}
                    {formatAmount(totalIndicativeRepayment)}
                  </b>
                </>
              )}
            </Column>
          </>
        )}
      </Column>
    </PanelWhiteWithBorder>
    <PaddedBox
      direction="column"
      aria-hidden={redrawShowHidePopup || showHidePopUp ? 'true' : 'false'}
    >
      <StyledColumnPnl>
        <ActionButtons
          leftButtonLabel="Cancel"
          leftButtonClick={backToChannel}
          rightButtonLabel="Next"
          rightButtonClick={navigateNext}
          leftButtonShow
          isRightButtonShow={showNewLoanDetails(
            selectedLoanOption,
            splitFixedAmount,
            availableFunds,
          )}
        />
      </StyledColumnPnl>
    </PaddedBox>
    <ThingsYouKnow
      aria-hidden={redrawShowHidePopup || showHidePopUp ? 'true' : 'false'}
    />
  </StyledGridPnl>
);

FixedOptionLoanPage.propTypes = {
  isPackageCustomer: PropTypes.bool.isRequired,
  onFixedRateRadioChange: PropTypes.func.isRequired,
  selectedLoanOption: PropTypes.string.isRequired,
  onSplitAmountEnter: PropTypes.func.isRequired,
  inputAmountData: PropTypes.number.isRequired,
  currentBalance: PropTypes.string.isRequired,
  monthlyRepayment: PropTypes.string.isRequired,
  showReviewDetailsPopup: PropTypes.func.isRequired,
  hideReviewDetailsPopup: PropTypes.func.isRequired,
  navigateNext: PropTypes.func.isRequired,
  backToChannel: PropTypes.func.isRequired,
  showHidePopUp: PropTypes.bool.isRequired,
  interestRate: PropTypes.string.isRequired,
  availableFunds: PropTypes.string.isRequired,
  yearTerm: PropTypes.string.isRequired,
  redrawShowHidePopup: PropTypes.bool.isRequired,
  hideRedrawFundsPopup: PropTypes.func.isRequired,
  redrawModalTitle: PropTypes.string.isRequired,
  redrawModalButtonText: PropTypes.string.isRequired,
  redrawAlertBoxMessage: PropTypes.string.isRequired,
  redrawFundAccountsList: PropTypes.arrayOf(PropTypes.shape({})).isRequired,
  selectAccountToTransfer: PropTypes.func.isRequired,
  selectedAccount: PropTypes.string.isRequired,
  onClickCalculateRepayments: PropTypes.func.isRequired,
  splitVariableAmount: PropTypes.string.isRequired,
  splitFixedAmount: PropTypes.string.isRequired,
  variableInterestRate: PropTypes.string.isRequired,
  loanMaturityDate: PropTypes.string.isRequired,
  repaymentType: PropTypes.string.isRequired,
  interestOnlyMaturityDate: PropTypes.string.isRequired,
  calculatedVariableLoanBalance: PropTypes.string.isRequired,
  calculatedFixedLoanBalance: PropTypes.string.isRequired,
  amountValidationMessage: PropTypes.string.isRequired,
  redrawIndicator: PropTypes.string.isRequired,
  productName: PropTypes.string.isRequired,
  switchedProductName: PropTypes.string.isRequired,
  totalIndicativeRepayment: PropTypes.string.isRequired,
  monthlyMaintainence: PropTypes.string.isRequired,
};
export default FixedOptionLoanPage;
