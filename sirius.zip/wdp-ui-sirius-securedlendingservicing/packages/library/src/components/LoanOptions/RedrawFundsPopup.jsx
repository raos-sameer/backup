import React, { Fragment } from 'react';
import PropTypes from 'prop-types';
import { FieldSelect } from '@wdpui/gel-field-select';
import { Text } from '@wdpui/gel-typography';
import { withAccessibleFocusStyle } from '@wdpui/react-gel';
import {
  ModalHeader,
  ModalBody,
  ModalFooter,
  ModalHeaderTitle,
  ModalHeaderClose,
} from '@wdpui/gel-modal';
import { AlertBox } from '@wdpui/gel-alertbox';
import { withTracking } from '@wdpui/common-analytics';
import styled from 'styled-components';

import { compose } from 'recompose';
import {
  StyledModalContainer,
  StyledModalFooter,
  StyledRow,
  StyledColumn,
  WordBreakText,
  ModalButton,
} from '../common/styles';

import { getAnalyticsTags } from '../../helpers/analyticsHelper';

export const StyledDivSpacing = styled.div`
  margin-top: 0px;
`;
export const StyledAlertBox = styled(AlertBox)`
  margin-bottom: 0px;
`;
export const DarkHeaderText = styled(Text)`
  color: ${({ theme }) => theme.color.neutral};
  font-size: 16px;
  font-weight: 500;
  font-stretch: normal;
  font-style: normal;
  line-height: 1.38;
  margin-top: 0px;
  margin-bottom: 0px;
  padding-bottom: 0px;
`;
export const StyledAmountText = styled(Text)`
  color: ${({ theme }) => theme.color.muted};
  margin-top: 6px;
  margin-bottom: 6px;
`;
export const StyleNoteText = styled(StyledAmountText)`
  margin-top: 12px;
  margin-bottom: 0px;
`;
export const StyleOneAccountText = styled(StyledAmountText)`
  margin-top: 18px;
  margin-bottom: 20px;
`;
export const StyledModalButton = styled(ModalButton)`
  width: 120px;
  margin: 5px;
`;
export const StyledFooter = styled(StyledModalFooter)`
  padding-bottom: 0px;
  @media (min-width: 768px) {
    text-align: right;
    padding-right: 24px;
  }
`;

export const ModalFooterContainer = styled(ModalFooter)`
  padding-top: 10px;
  padding-bottom: 10px;
  padding-right: 0px;
  padding-left: 0px;
`;

export const ModalBodyContent = styled(ModalBody)`
  padding-top: 18px;
`;
const AccessibleDiv = withAccessibleFocusStyle(Fragment);

export class RedrawFundsPopup extends React.Component {
  constructor(props) {
    super(props);
    this.accessiblePopUpRef = React.createRef();
  }

  componentDidMount() {
    const { redrawShowHidePopup } = this.props;
    if (redrawShowHidePopup && this.accessiblePopUpRef.current) {
      this.accessiblePopUpRef.current.focus();
    }
  }

  render() {
    const {
      redrawShowHidePopup,
      hideRedrawFundsPopup,
      redrawModalTitle,
      redrawModalButtonText,
      redrawAlertBoxMessage,
      redrawFundAccountsList,
      onFieldSelectChange,
      selectedAccount,
      navigateNext,
      redrawIndicator,
    } = this.props;

    return (
      <AccessibleDiv>
        <StyledModalContainer
          isOpen={redrawShowHidePopup}
          aria-modal="true"
          size="medium"
        >
          <ModalHeader>
            <ModalHeaderTitle tabIndex="0" ref={this.accessiblePopUpRef}>
              {redrawModalTitle}
            </ModalHeaderTitle>
            <ModalHeaderClose
              srLabel="Close and return to previous page"
              onClick={() => hideRedrawFundsPopup()}
            />
          </ModalHeader>
          <ModalBodyContent>
            {redrawIndicator &&
              redrawFundAccountsList &&
              redrawFundAccountsList.length === 0 && (
                <div>
                  <StyledRow direction="column">
                    <StyledColumn>
                      <WordBreakText>
                        You have no eligible Westpac accounts to transfer to.
                      </WordBreakText>
                      <StyleNoteText>
                        To continue with this option, you’ll have to&nbsp;
                        <b>
                          exit this form and transfer your funds out using
                          another method.
                        </b>
                      </StyleNoteText>
                      <StyleNoteText>
                        <b>Please note:</b> When you return, you’ll have to
                        start this form again and the offered rates may change.
                      </StyleNoteText>
                    </StyledColumn>
                  </StyledRow>
                </div>
              )}
            {redrawIndicator &&
              redrawFundAccountsList &&
              redrawFundAccountsList.length === 1 && (
                <div>
                  <StyledRow>
                    <StyledColumn>
                      <DarkHeaderText size={3}>
                        Transfer available funds to
                      </DarkHeaderText>
                    </StyledColumn>
                  </StyledRow>

                  <StyledRow>
                    <StyledColumn>
                      <StyleOneAccountText>
                        {redrawFundAccountsList[0].label}
                      </StyleOneAccountText>
                    </StyledColumn>
                  </StyledRow>

                  <StyledRow>
                    <StyledColumn width={[1]}>
                      {redrawAlertBoxMessage && (
                        <StyledDivSpacing>
                          <StyledAlertBox
                            styling="info"
                            hasIcon
                            mt={24}
                            role="alert"
                            aria-live="assertive"
                          >
                            {redrawAlertBoxMessage}
                          </StyledAlertBox>
                        </StyledDivSpacing>
                      )}
                    </StyledColumn>
                  </StyledRow>
                </div>
              )}
            {redrawIndicator &&
              redrawFundAccountsList &&
              redrawFundAccountsList.length > 1 && (
                <div>
                  <StyledRow>
                    <StyledColumn>
                      <FieldSelect
                        id="title"
                        label="Transfer available funds to"
                        errorMessage={`${
                          selectedAccount === '0' ? 'Select an account' : ''
                        }`}
                        onChange={event =>
                          onFieldSelectChange({ value: event.target.value })
                        }
                        selectProps={{
                          size: 'large',
                        }}
                        value={selectedAccount}
                        options={redrawFundAccountsList}
                      />
                    </StyledColumn>
                  </StyledRow>
                  <StyledRow>
                    <StyledColumn width={[1]}>
                      {redrawAlertBoxMessage && (
                        <StyledDivSpacing>
                          <StyledAlertBox styling="info" hasIcon mt={24}>
                            {redrawAlertBoxMessage}
                          </StyledAlertBox>
                        </StyledDivSpacing>
                      )}
                    </StyledColumn>
                  </StyledRow>
                </div>
              )}
            {!redrawIndicator && (
              <div>
                <StyledRow direction="column">
                  <StyledColumn>
                    <WordBreakText>
                      Please <a href="tel:13 33 30">call us </a>or visit a
                      branch to continue with this request.
                    </WordBreakText>
                    <StyleNoteText>
                      Please note: You will have to restart this process with
                      one of our home finance managers and the offered rates may
                      change
                    </StyleNoteText>
                  </StyledColumn>
                </StyledRow>
              </div>
            )}
          </ModalBodyContent>
          <ModalFooterContainer>
            <StyledFooter>
              <StyledModalButton
                type="button"
                onClick={hideRedrawFundsPopup}
                label="Back"
                styling="faint"
              />

              {redrawIndicator && (
                <StyledModalButton
                  type="button"
                  label={redrawModalButtonText}
                  styling="primary"
                  onClick={
                    redrawFundAccountsList &&
                    redrawFundAccountsList.length === 0
                      ? hideRedrawFundsPopup
                      : navigateNext
                  }
                />
              )}
              {!redrawIndicator && (
                <StyledModalButton
                  type="button"
                  label={redrawModalButtonText}
                  styling="primary"
                  href="tel:13 33 30"
                />
              )}
            </StyledFooter>
          </ModalFooterContainer>
        </StyledModalContainer>
      </AccessibleDiv>
    );
  }
}

RedrawFundsPopup.propTypes = {
  redrawShowHidePopup: PropTypes.bool,
  redrawModalTitle: PropTypes.string,
  redrawModalButtonText: PropTypes.string,
  redrawAlertBoxMessage: PropTypes.string,
  redrawFundAccountsList: PropTypes.arrayOf(
    PropTypes.shape({ label: '', id: '', value: '' }),
  ),
  onFieldSelectChange: PropTypes.func.isRequired,
  selectedAccount: PropTypes.string,
  hideRedrawFundsPopup: PropTypes.func.isRequired,
  navigateNext: PropTypes.func.isRequired,
  redrawIndicator: PropTypes.string.isRequired,
};

RedrawFundsPopup.defaultProps = {
  redrawShowHidePopup: false,
  redrawModalTitle: '',
  redrawModalButtonText: '',
  redrawAlertBoxMessage: '',
  redrawFundAccountsList: [],
  selectedAccount: '',
};

const enhance = compose(
  withTracking((state, props) => getAnalyticsTags('REDRAW_MODAL', props)),
);

export default enhance(RedrawFundsPopup);
