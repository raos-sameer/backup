import React from 'react';
import PropTypes from 'prop-types';
import { Panel } from '@wdpui/gel-panel';
import { Table, Tbody, Tr, Td } from '@wdpui/react-gel';
import { Row } from '@wdpui/gel-grid';
import { List } from '@wdpui/gel-list';

import {
  TickIcon,
  ListItemShowHide,
  MutedText,
  NeutralText,
  CloseIcon,
} from '../common/styles';

import {
  isVariableComponent,
  isFixedComponent,
} from '../../helpers/loanSummaryHelper';
import { formatAmount } from '../../helpers/amountFormatter';
import {
  getNegatedAmountText,
  isSplitLoan,
} from '../../helpers/loanOptionsHelper';
import {
  LIMITED_REPAYMENT_TEXT,
  UNLIMITED_REPAYMENT_TEXT,
} from '../../helpers/constants';

export const NewLoanSummary = ({
  title,
  compType,
  loanTerm,
  loanBalance,
  interestRate,
  monthlyRepayments,
  unlimitedRepayment,
  isPackageCustomer,
  loanType,
  monthlyMaintainence,
}) => (
  <Row direction="column">
    <Panel title={title}>
      <Table responsive>
        <Tbody>
          <Tr>
            <Td>
              <NeutralText>
                Loan balance<sup>*</sup>&nbsp;
                <b>{getNegatedAmountText(loanBalance, true)}</b>
              </NeutralText>
              {isVariableComponent(compType) && (
                <NeutralText>
                  Variable rate of <b> {interestRate}% p.a.</b>
                </NeutralText>
              )}
              {isFixedComponent(compType) && (
                <NeutralText>
                  <b>{loanTerm}</b> year fixed at <b>{interestRate}% p.a.</b>
                </NeutralText>
              )}

              <NeutralText>
                Indicative monthly repayments<sup>*</sup>{' '}
                <b>{formatAmount(monthlyRepayments)}</b>
                {isSplitLoan(loanType) && !isPackageCustomer && (
                  <div>
                    (Includes {formatAmount(monthlyMaintainence)} monthly loan
                    maintenance fee)
                  </div>
                )}
              </NeutralText>
            </Td>
          </Tr>

          <Tr>
            <Td>
              <List>
                <ListItemShowHide icon={TickIcon}>
                  <MutedText size={1}>
                    Additional repayments&nbsp;
                    {unlimitedRepayment ? UNLIMITED_REPAYMENT_TEXT : ''}
                    <b>{!unlimitedRepayment ? LIMITED_REPAYMENT_TEXT : ''}</b>
                  </MutedText>
                </ListItemShowHide>

                <ListItemShowHide
                  renderItem={isFixedComponent(compType) ? 'true' : 'true'}
                  icon={isFixedComponent(compType) ? CloseIcon : TickIcon}
                >
                  Offset benefits
                </ListItemShowHide>

                <ListItemShowHide
                  renderItem={isPackageCustomer ? 'true' : 'false'}
                  icon={TickIcon}
                >
                  Premier Advantage Package
                </ListItemShowHide>
              </List>
            </Td>
          </Tr>
        </Tbody>
      </Table>
    </Panel>
  </Row>
);
NewLoanSummary.propTypes = {
  title: PropTypes.string.isRequired,
  compType: PropTypes.string.isRequired,
  loanBalance: PropTypes.string.isRequired,
  interestRate: PropTypes.string.isRequired,
  loanTerm: PropTypes.string.isRequired,
  monthlyRepayments: PropTypes.string.isRequired,
  unlimitedRepayment: PropTypes.bool.isRequired,
  isPackageCustomer: PropTypes.bool.isRequired,
  loanType: PropTypes.string.isRequired,
  monthlyMaintainence: PropTypes.string.isRequired,
};
export default NewLoanSummary;
