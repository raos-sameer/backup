import { shallow, mount } from 'enzyme';
import React from 'react';
import { Input } from '@wdpui/gel-input';

import { FixedOptionLoanPage, StyledAlertBox } from './FixedOptionLoanPage';
import { NewLoanSummary } from './NewLoanSummary';
import { ThingsYouKnow } from './ThingsYouKnow';
import ConnectedReviewModalPopUp from '../ReviewModalPopUp';
import ConnectedRedrawFundsPopup from './RedrawFundsPopup';
import { FocusedPageTitle } from '../common';
import {
  PanelWhiteWithBorder,
  MutedText,
  StyledGridPnl,
  StyledRowPnl,
  StyledColumnPnl,
  PaddedBox,
  StyledIconAdd,
} from '../common/styles';
import { withTheme } from '../../../../../utils/jest/TestUtils';

const props = {
  currentBalance: '1111,000',
};

const mockFn = jest.fn();
global.matchMedia = matches => () => ({
  matches,
  addListener: () => {},
  removeListener: () => {},
});

describe('FixedOptionLoanPage', () => {
  it('renders the FixedOptionLoanPage structure', () => {
    const component = <FixedOptionLoanPage {...props} />;
    const wrapper = shallow(component);
    expect(wrapper.find(FocusedPageTitle).exists()).toBe(true);
    expect(wrapper.find(PanelWhiteWithBorder).exists()).toBe(true);
    expect(wrapper.find(MutedText).exists()).toBe(true);
    expect(wrapper.find(StyledGridPnl).exists()).toBe(true);
    expect(wrapper.find(StyledColumnPnl).exists()).toBe(true);
    expect(wrapper.find(StyledRowPnl).exists()).toBe(true);
    expect(wrapper.find(PaddedBox).exists()).toBe(true);
    expect(wrapper.find(ThingsYouKnow).exists()).toBe(true);
    expect(wrapper).toMatchSnapshot();
  });

  it('should check for MutedText right color value rendered', () => {
    const wrapper = mount(withTheme(<MutedText color="#575f65" />));
    expect(wrapper.getDOMNode('Text').attributes.color.value).toEqual(
      '#575f65',
    );
  });

  it('should fire on change for split amount enter', () => {
    const component = (
      <FixedOptionLoanPage
        onSplitAmountEnter={mockFn}
        inputAmountData={11}
        currentBalance="1111"
        selectedLoanOption="SplitLoanOption"
        availableFunds="1111"
      />
    );
    const wrapper = shallow(component);
    const evt = {
      preventDefault: () => {},
      target: {
        name: 'options',
      },
    };
    wrapper.find(Input).simulate('change', evt);
  });

  it('should match snapshot if valid props are passed for loan type Split and for component variable', () => {
    const loansummaryprops = {
      title: 'Rocket Repay Home Loan',
      loanType: 'SplitLoanOption',
      compType: 'Variable',
      loanBalance: '111888',
      availableFunds: '555555',
      interestRate: '1.29',
      loanTerm: '3',
      monthlyRepayments: '1111',
      unlimitedRepayment: true,
      isPackageCustomer: true,
    };
    const wrapper = mount(
      withTheme(<NewLoanSummary props={loansummaryprops} />),
    );
    expect(wrapper).toMatchSnapshot();
  });

  it('should match snapshot if valid props are passed for loan type Split and for component fixed', () => {
    const loansummaryprops = {
      title: 'Fixed Option Home Loan',
      loanType: 'SplitLoanOption',
      compType: 'Fixed',
      loanBalance: '111888',
      availableFunds: '555555',
      interestRate: '1.29',
      loanTerm: '3',
      monthlyRepayments: '1111',
      unlimitedRepayment: false,
      isPackageCustomer: true,
    };
    const wrapper = mount(
      withTheme(<NewLoanSummary props={loansummaryprops} />),
    );
    expect(wrapper).toMatchSnapshot();
  });

  it('should match snapshot if valid props are passed for loan type RedrawFundsOption and for component fixed', () => {
    const loansummaryprops = {
      title: 'Fixed Option Home Loan',
      loanType: 'RedrawFundsOption',
      compType: 'Fixed',
      loanBalance: '111888',
      availableFunds: '555555',
      interestRate: '1.29',
      loanTerm: '3',
      monthlyRepayments: '1111',
      unlimitedRepayment: false,
      isPackageCustomer: true,
    };
    const wrapper = mount(
      withTheme(<NewLoanSummary props={loansummaryprops} />),
    );
    expect(wrapper).toMatchSnapshot();
  });

  it('should match snapshot if valid props are passed for loan type AccessFundsOption and for component fixed', () => {
    const loansummaryprops = {
      title: 'Fixed Option Home Loan',
      loanType: 'AccessFundsOption',
      compType: 'Fixed',
      loanBalance: '111888',
      availableFunds: '555555',
      interestRate: '1.29',
      loanTerm: '3',
      monthlyRepayments: '1111',
      unlimitedRepayment: false,
      isPackageCustomer: true,
    };
    const wrapper = mount(
      withTheme(<NewLoanSummary props={loansummaryprops} />),
    );
    expect(wrapper).toMatchSnapshot();
  });

  it('should match snapshot if  user is not package customer', () => {
    const loansummaryprops = {
      title: 'Fixed Option Home Loan',
      loanType: 'AccessFundsOption',
      compType: 'Fixed',
      loanBalance: '111888',
      availableFunds: '555555',
      interestRate: '1.29',
      loanTerm: '3',
      monthlyRepayments: '1111',
      unlimitedRepayment: false,
      isPackageCustomer: false,
    };
    const wrapper = mount(
      withTheme(<NewLoanSummary props={loansummaryprops} />),
    );
    expect(wrapper).toMatchSnapshot();
  });

  it('should render icon add for showing split loan summary', () => {
    const loansummaryprops = {
      title: 'Fixed Option Home Loan',
      loanType: 'SplitLoanOption',
      compType: 'Variable',
      loanBalance: '111888',
      availableFunds: '555555',
      interestRate: '1.29',
      loanTerm: '3',
      monthlyRepayments: '1111',
      unlimitedRepayment: true,
      isPackageCustomer: false,
      inputAmountData: 111,
      splitVariableAmount: '1200',
      splitFixedAmount: '1111',
      selectedLoanOption: 'SplitLoanOption',
    };

    const component = withTheme(<FixedOptionLoanPage {...loansummaryprops} />);
    const wrapper = shallow(component)
      .dive()
      .dive()
      .dive()
      .dive()
      .dive()
      .dive()
      .dive()
      .dive()
      .dive();

    expect(wrapper.find(StyledIconAdd).exists()).toBe(true);
    expect(wrapper).toMatchSnapshot();
  });

  it('should call showReviewDetailsPopup when clicked on toggled or show review button link clicked', () => {
    const component = (
      <FixedOptionLoanPage
        showHidePopUp
        hideReviewDetailsPopup={mockFn}
        isPackageCustomer
        currentBalance="700000"
        availableBalance="10000"
        varInterestRate="3.9"
        loanMaturityDate="23 Aug 2042"
        repaymentType="IO"
        interestOnlyMatDate="23 Aug 2043"
        monthlyRepayment="3211"
        productName="Test title"
      />
    );
    const wrapper = shallow(component);
    expect(wrapper.find(ConnectedReviewModalPopUp).exists()).toBe(true);
    expect(wrapper).toMatchSnapshot();
  });

  it('should call showRedrawPopup when user selects redraw option and list has redraw accounts', () => {
    const redrawFundAccountsList = [{ label: 'Test1', value: '1' }];

    const component = (
      <FixedOptionLoanPage
        redrawShowHidePopup
        redrawModalTitle="Test Redraw popup"
        hideRedrawFundsPopup={mockFn}
        redrawModalButtonText="button text"
        redrawAlertBoxMessage="Test alert message"
        redrawFundAccountsList={redrawFundAccountsList}
        onFieldSelectChange={jest.fn()}
        selectedAccount="1"
        navigateNext={jest.fn()}
        redrawIndicator
      />
    );
    const wrapper = shallow(component);
    expect(wrapper.find(ConnectedRedrawFundsPopup).exists()).toBe(true);
    expect(wrapper).toMatchSnapshot();
  });

  it('should show amount validation message if validation failed if user selects to split', () => {
    const component = (
      <FixedOptionLoanPage amountValidationMessage="Amount validation failed" />
    );
    const wrapper = shallow(component);
    expect(wrapper.find(StyledAlertBox).exists()).toBe(true);
  });
});
