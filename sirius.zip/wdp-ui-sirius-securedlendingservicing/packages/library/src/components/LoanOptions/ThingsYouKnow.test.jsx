import React from 'react';
import { shallow } from 'enzyme';
import { Column, Row } from '@wdpui/gel-grid';
import { List } from '@wdpui/gel-list';
import { Accordion, AccordionItem } from '@wdpui/gel-accordion';
import { ListItemShowHide, StyledSup } from '../common/styles';
import { ThingsYouKnow } from './ThingsYouKnow';

describe('ThingsYouKnow', () => {
  it('renders the ThingsYouKnow structure', () => {
    const component = <ThingsYouKnow />;
    const wrapper = shallow(component);
    expect(wrapper.find(Row).exists()).toBe(true);
    expect(wrapper.find(Column).exists()).toBe(true);
    expect(wrapper.find(List).exists()).toBe(true);
    expect(wrapper.find(Accordion).exists()).toBe(true);
    expect(wrapper.find(AccordionItem).exists()).toBe(true);

    expect(wrapper.find(StyledSup).exists()).toBe(true);
    expect(wrapper.find(ListItemShowHide).exists()).toBe(true);

    expect(wrapper).toMatchSnapshot();
  });
});
