import { mount, shallow } from 'enzyme';
import React from 'react';
import { Panel } from '@wdpui/gel-panel';
import { Row } from '@wdpui/gel-grid';
import { List } from '@wdpui/gel-list';
import { ListItemShowHide, MutedText, NeutralText } from '../common/styles';
import { withTheme } from '../../../../../utils/jest/TestUtils';
import { NewLoanSummary } from './NewLoanSummary';

const props = {
  title: 'Test title',
  loanTerm: '2',
  loanBalance: '111',
  interestRate: '1.5',
  monthlyRepayments: '111',
};
describe('NewLoanSummary', () => {
  global.matchMedia = matches => () => ({
    matches,
    addListener: () => {},
    removeListener: () => {},
  });

  it('renders the NewLoanSummary structure', () => {
    const component = <NewLoanSummary {...props} />;
    const wrapper = shallow(component);

    expect(wrapper.find(Panel).exists()).toBe(true);

    expect(wrapper.find(Row).exists()).toBe(true);
    expect(wrapper.find(List).exists()).toBe(true);
    expect(wrapper.find(NeutralText).exists()).toBe(true);

    expect(wrapper.find(MutedText).exists()).toBe(true);

    expect(wrapper.find(ListItemShowHide).exists()).toBe(true);

    expect(wrapper).toMatchSnapshot();
  });

  it('should show variable interest rate if component is Variable', () => {
    const loansummaryprops = {
      title: 'Fixed Option Home Loan',
      loanType: 'SplitLoanOption',
      compType: 'Variable',
      loanBalance: '111888',
      availableFunds: '555555',
      interestRate: '1.29',
      loanTerm: '3',
      monthlyRepayments: '1111',
      unlimitedRepayment: true,
      isPackageCustomer: false,
    };

    const component = withTheme(<NewLoanSummary {...loansummaryprops} />);
    const wrapper = mount(component);
    expect(wrapper.find(NeutralText).exists()).toBe(true);
    expect(wrapper).toMatchSnapshot();
  });

  it('should show advantage package bullet if its package customer', () => {
    const loansummaryprops = {
      title: 'Fixed Option Home Loan',
      loanType: 'SplitLoanOption',
      compType: 'Fixed',
      loanBalance: '111888',
      availableFunds: '555555',
      interestRate: '1.29',
      loanTerm: '3',
      monthlyRepayments: '1111',
      unlimitedRepayment: false,
      isPackageCustomer: true,
    };

    const component = withTheme(<NewLoanSummary {...loansummaryprops} />);
    const wrapper = mount(component);

    expect(
      wrapper
        .find('li')
        .last()
        .text(),
    ).toEqual('Premier Advantage Package');
  });
});
