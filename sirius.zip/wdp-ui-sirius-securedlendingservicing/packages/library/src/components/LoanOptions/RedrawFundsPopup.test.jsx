import React from 'react';
import { shallow, mount } from 'enzyme';
import { FieldSelect } from '@wdpui/gel-field-select';
import { ModalHeaderClose } from '@wdpui/gel-modal';
import {
  RedrawFundsPopup,
  ModalBodyContent,
  ModalFooterContainer,
  StyledDivSpacing,
  StyledModalButton,
  DarkHeaderText,
} from './RedrawFundsPopup';
import { withTheme } from '../../../../../utils/jest/TestUtils';

import { StyledColumn, WordBreakText } from '../common/styles';

describe('RedrawFundsPopup', () => {
  it('renders the RedrawFundsPopup structure', () => {
    const component = <RedrawFundsPopup />;
    const wrapper = shallow(component);

    expect(wrapper.find(ModalBodyContent).exists()).toBe(true);
    expect(wrapper.find(ModalFooterContainer).exists()).toBe(true);
  });

  it('renders the RedrawFundsPopup structure', () => {
    const mockFn = jest.fn();
    const props = {
      hideRedrawFundsPopup: mockFn,
    };
    const component = <RedrawFundsPopup {...props} />;
    const wrapper = shallow(component);
    wrapper
      .find(ModalHeaderClose)
      .at(0)
      .simulate('click', { hideRedrawFundsPopup() {} });

    expect(mockFn.mock.calls.length).toBe(1);
  });

  it('renders the RedrawFundsPopup structure', () => {
    const mockFn = jest.fn();
    const a = [
      {
        accountName: '456346342',
        bsbNumber: '123-456',
        ProductName: 'Westpac choice',
        id: 1,
      },
      {
        accountName: '265454346',
        bsbNumber: '123-433',
        ProductName: 'Westpac choice',
        id: 2,
      },
    ];
    const component = (
      <RedrawFundsPopup
        redrawModalTitle="some title"
        redrawShowHidePopup="false"
        hideRedrawFundsPopup=""
        onFieldSelectChange={mockFn}
        redrawFundAccountsList={a}
        alertBoxMessage={false}
        redrawIndicator
      />
    );
    const wrapper = shallow(component);

    wrapper.find(FieldSelect).simulate('change', { target: { value: 70 } });
    expect(mockFn.mock.calls.length).toBe(1);
  });

  it('renders the RedrawFundsPopup structure', () => {
    const a = [];
    const component = (
      <RedrawFundsPopup
        redrawModalTitle="some title"
        redrawShowHidePopup="false"
        hideRedrawFundsPopup=""
        onFieldSelectChange={jest.fn}
        redrawFundAccountsList={a}
        alertBoxMessage={false}
        redrawIndicator
      />
    );
    const wrapper = shallow(component);

    expect(
      wrapper
        .find(StyledColumn)
        .at(0)
        .text(),
    ).toMatch(/You have no eligible Westpac/);
    expect(wrapper.find(ModalBodyContent).exists()).toBe(true);
    expect(wrapper.find(StyledDivSpacing).exists()).toBe(false);
    expect(wrapper.find(ModalFooterContainer).exists()).toBe(true);
  });

  it('renders the RedrawFundsPopup structure', () => {
    const a = [
      {
        accountName: '456346342',
        bsbNumber: '123-456',
        ProductName: 'Westpac choice',
        id: 1,
      },
    ];
    const component = (
      <RedrawFundsPopup
        redrawModalTitle="some title"
        redrawShowHidePopup="false"
        hideRedrawFundsPopup=""
        onFieldSelectChange={jest.fn}
        redrawFundAccountsList={a}
        alertBoxMessage="false"
        redrawIndicator
      />
    );
    const wrapper = shallow(component);

    expect(
      wrapper
        .find(DarkHeaderText)
        .at(0)
        .text(),
    ).toMatch(/Transfer available funds to/);
    expect(wrapper.find(ModalBodyContent).exists()).toBe(true);
    expect(wrapper.find(ModalFooterContainer).exists()).toBe(true);
  });

  it('renders the RedrawFundsPopup structure', () => {
    const a = [
      {
        accountName: '456346342',
        bsbNumber: '123-456',
        ProductName: 'Westpac choice',
        id: 1,
      },
      {
        accountName: '265454346',
        bsbNumber: '123-433',
        ProductName: 'Westpac choice',
        id: 2,
      },
    ];
    const component = (
      <RedrawFundsPopup
        redrawModalTitle="some title"
        redrawShowHidePopup="false"
        hideRedrawFundsPopup=""
        onFieldSelectChange={jest.fn}
        redrawFundAccountsList={a}
        alertBoxMessage="false"
        redrawIndicator
      />
    );
    const wrapper = shallow(component);

    expect(wrapper.find(FieldSelect).exists()).toBe(true);
    expect(wrapper.find(ModalFooterContainer).exists()).toBe(true);
  });

  it('renders the RedrawFundsPopup structure when redraw indicator not set', () => {
    const a = [];
    const component = (
      <RedrawFundsPopup
        redrawModalTitle="some title"
        redrawShowHidePopup={false}
        hideRedrawFundsPopup=""
        onFieldSelectChange={jest.fn}
        redrawFundAccountsList={a}
        alertBoxMessage={false}
        redrawIndicator={false}
      />
    );
    const wrapper = shallow(component);

    expect(
      wrapper
        .find(WordBreakText)
        .at(0)
        .text(),
    ).toMatch(/or visit a branch to continue/);
    expect(wrapper.find(ModalFooterContainer).exists()).toBe(true);
  });

  it('renders the RedrawFundsPopup structure', () => {
    const mockFn = jest.fn();
    const props = {
      navigateNext: mockFn,
    };
    const accounts = [
      {
        accountName: '456346342',
        bsbNumber: '123-456',
        ProductName: 'Westpac choice',
        id: 1,
      },
      {
        accountName: '265454346',
        bsbNumber: '123-433',
        ProductName: 'Westpac choice',
        id: 2,
      },
    ];
    props.redrawFundAccountsList = accounts;
    props.redrawIndicator = true;
    const component = <RedrawFundsPopup {...props} />;
    const wrapper = shallow(component);
    wrapper
      .find(StyledModalButton)
      .at(1)
      .simulate('click', { navigateNext() {} });
    expect(mockFn.mock.calls.length).toBe(1);
  });

  it('should check for DarkHeaderText right color value rendered', () => {
    const wrapper = mount(withTheme(<DarkHeaderText color="#621a4b" />));
    expect(wrapper.getDOMNode('Text').attributes.color.value).toEqual(
      '#621a4b',
    );
  });
  it('should check for StyledAmountText right color value rendered', () => {
    const wrapper = mount(withTheme(<DarkHeaderText color="#621a4b" />));
    expect(wrapper.getDOMNode('Text').attributes.color.value).toEqual(
      '#621a4b',
    );
  });
});
