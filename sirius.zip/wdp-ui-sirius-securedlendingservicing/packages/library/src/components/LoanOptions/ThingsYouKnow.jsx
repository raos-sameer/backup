import React from 'react';
import { Column, Row } from '@wdpui/gel-grid';
import { List } from '@wdpui/gel-list';
import { Accordion, AccordionItem } from '@wdpui/gel-accordion';
import { ListItemShowHide, StyledSup } from '../common/styles';

export const ThingsYouKnow = () => (
  <Row direction="column" mb={34}>
    <Column>
      <Accordion>
        <AccordionItem label="Things you should know">
          <StyledSup>*</StyledSup>The new loan balance and monthly repayments
          quoted have been calculated today based on you current loan details.
          <List large role="list" styling="neutral">
            <ListItemShowHide role="listitem">
              If your current loan details change before your request is
              processed, your new loan details will update accordingly.
            </ListItemShowHide>
            <ListItemShowHide role="listitem">
              We&apos;ll send you a letter to confirm your new repayments once
              your request is approved and processed.
            </ListItemShowHide>
          </List>
        </AccordionItem>
      </Accordion>
    </Column>
  </Row>
);
export default ThingsYouKnow;
