import React from 'react';
import styled from 'styled-components';
import { withAccessibleFocusStyle } from '@wdpui/react-gel';

import PropTypes from 'prop-types';
import {
  ModalHeader,
  ModalBody,
  ModalFooter,
  ModalHeaderTitle,
} from '@wdpui/gel-modal';
import { Table, Tbody, Tr, Td } from '@wdpui/gel-table';
import { withTracking } from '@wdpui/common-analytics';
import { Panel } from '@wdpui/gel-panel';
import { compose } from 'recompose';
import {
  StyledModalContainer,
  StyledModalFooter,
  ModalButton,
  StyledDiv,
} from './common/styles';
import { formatAmount } from '../helpers/amountFormatter';
import {
  getRepaymentType,
  getAdvantagePackageDesc,
  getNegatedAmountText,
} from '../helpers/loanOptionsHelper';
import { formattedDate } from '../helpers/dateFormatter';
import { getAnalyticsTags } from '../helpers/analyticsHelper';

const AccessibleDiv = withAccessibleFocusStyle(StyledDiv);

export const StyledTd = styled(Td)`
  margin-left-12px;
  vertical-align: top;
`;
export class ReviewModalPopUp extends React.Component {
  constructor(props) {
    super(props);
    this.accessiblePopUpRef = React.createRef();
  }

  componentDidMount() {
    const { showPopUp } = this.props;
    if (showPopUp && this.accessiblePopUpRef.current) {
      this.accessiblePopUpRef.current.focus();
    }
  }

  render() {
    const {
      modalTitle,
      availableBalance,
      currentBalance,
      varInterestRate,
      loanMaturityDate,
      repaymentType,
      interestOnlyMatDate,
      monthlyRepayment,
      advantagePackage,
      closeButtonText,
      closeButtonClick,
      showPopUp,
      panelTitle,
      redrawIndicatorSet,
    } = this.props;

    return (
      <AccessibleDiv>
        <StyledModalContainer
          size="medium"
          aria-modal="true"
          isOpen={showPopUp}
          onClose={closeButtonClick}
        >
          <ModalHeader hasCloseButton>
            <ModalHeaderTitle
              size={3}
              weight="medium"
              tabIndex="0"
              ref={this.accessiblePopUpRef}
            >
              {modalTitle}
            </ModalHeaderTitle>
          </ModalHeader>
          <ModalBody>
            <Panel title={panelTitle} responsive>
              <Table>
                <Tbody>
                  <Tr>
                    <StyledTd>Current balance</StyledTd>
                    <StyledTd>
                      <b>{getNegatedAmountText(currentBalance, true)} </b>
                    </StyledTd>
                  </Tr>
                  {redrawIndicatorSet ? (
                    <Tr>
                      <StyledTd>Available funds</StyledTd>

                      <StyledTd>
                        <b>{formatAmount(availableBalance)}</b>
                      </StyledTd>
                    </Tr>
                  ) : (
                    <Tr />
                  )}
                  {loanMaturityDate ? (
                    <Tr>
                      <StyledTd>Loan maturity date</StyledTd>

                      <StyledTd>
                        <b>{formattedDate(loanMaturityDate)} </b>
                      </StyledTd>
                    </Tr>
                  ) : (
                    <Tr />
                  )}
                  {varInterestRate ? (
                    <Tr>
                      <StyledTd>Variable interest rate</StyledTd>

                      <StyledTd>
                        <b>{varInterestRate}% p.a. </b>
                      </StyledTd>
                    </Tr>
                  ) : (
                    <Tr />
                  )}
                  <Tr>
                    <StyledTd>Repayment type</StyledTd>

                    <StyledTd>
                      <b>{getRepaymentType(repaymentType)}</b>
                    </StyledTd>
                  </Tr>
                  {interestOnlyMatDate ? (
                    <Tr>
                      <StyledTd>Interest only maturity</StyledTd>

                      <StyledTd>
                        <b>{formattedDate(interestOnlyMatDate)}</b>
                      </StyledTd>
                    </Tr>
                  ) : (
                    <Tr />
                  )}
                  <Tr>
                    <StyledTd> Contracted monthly repayments</StyledTd>

                    <StyledTd>
                      {' '}
                      <b>{formatAmount(monthlyRepayment)}</b>
                    </StyledTd>
                  </Tr>

                  <Tr>
                    <StyledTd> Premier Advantage package</StyledTd>

                    <StyledTd>
                      <b>{getAdvantagePackageDesc(advantagePackage)} </b>
                    </StyledTd>
                  </Tr>
                </Tbody>
              </Table>
            </Panel>
          </ModalBody>
          <ModalFooter>
            <StyledModalFooter>
              <ModalButton
                type="button"
                label={closeButtonText}
                onClick={closeButtonClick}
                styling="faint"
              />
            </StyledModalFooter>
          </ModalFooter>
        </StyledModalContainer>
      </AccessibleDiv>
    );
  }
}
ReviewModalPopUp.propTypes = {
  modalTitle: PropTypes.string.isRequired,
  availableBalance: PropTypes.string.isRequired,
  currentBalance: PropTypes.string.isRequired,
  varInterestRate: PropTypes.string.isRequired,
  loanMaturityDate: PropTypes.string.isRequired,
  repaymentType: PropTypes.string.isRequired,
  interestOnlyMatDate: PropTypes.string.isRequired,
  monthlyRepayment: PropTypes.string.isRequired,
  advantagePackage: PropTypes.bool.isRequired,
  closeButtonText: PropTypes.string.isRequired,
  closeButtonClick: PropTypes.func.isRequired,
  showPopUp: PropTypes.bool.isRequired,
  panelTitle: PropTypes.string.isRequired,
  redrawIndicatorSet: PropTypes.bool.isRequired,
};

const enhance = compose(
  withTracking((state, props) => getAnalyticsTags('REVIEW_MODAL', props)),
);

export default enhance(ReviewModalPopUp);
