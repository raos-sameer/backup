import { shallow } from 'enzyme';
import React from 'react';
import {
  StyledGridPnl,
  HeadingColouredText,
  PanelWhiteWithBorder,
} from '../common/styles';
import { ReviewPageComponent } from './ReviewPageComponent';
import { DisplayLoanDetails } from './DisplayLoanDetails';
import { FocusedPageTitle } from '../common';

describe('ReviewPageComponent', () => {
  it('renders the ReviewPageComponent structure', () => {
    const component = (
      <ReviewPageComponent
        productName="Test product"
        selectedLoanOption="SplitLoanOption"
      />
    );
    const wrapper = shallow(component);
    expect(wrapper.find(StyledGridPnl).exists()).toBe(true);
    expect(wrapper.find(FocusedPageTitle).exists());
    expect(wrapper.find(PanelWhiteWithBorder).exists());
    expect(wrapper.find(HeadingColouredText).exists());
    expect(wrapper.find('Styled(IconAdd)')).toHaveLength(1);
  });

  it('renders have table contents according to Fixed Type of Loan', () => {
    const component = (
      <ReviewPageComponent
        productName="Test product"
        selectedLoanOption="SplitLoanOption"
      />
    );

    const wrapper = shallow(component);
    expect(wrapper.find(DisplayLoanDetails).exists()).toBe(true);
    expect(wrapper.find('Styled(IconAdd)')).toHaveLength(1);
  });

  it('renders have table contents according to Fixed Type of Loan', () => {
    const component = (
      <ReviewPageComponent
        productName="Test product"
        selectedLoanOption="ClearAvailableFunds"
      />
    );

    const wrapper = shallow(component);
    expect(wrapper.find(DisplayLoanDetails).exists()).toBe(true);
    expect(wrapper.find('Styled(IconAdd)')).toHaveLength(0);
  });
});
