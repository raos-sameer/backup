import React from 'react';
import PropTypes from 'prop-types';
import styled from 'styled-components';
import { ListItem, List } from '@wdpui/react-gel';

import {
  isRedrawLoan,
  isClearLoan,
  getSwitchingFeeText,
  getMonthlyMaintainenceFee,
} from '../../helpers/loanOptionsHelper';

export const StyledDivDisclaimerText = styled.div`
  color: ${({ theme }) => theme.color.muted};
  margin-top: -3px;
`;
export const StyledDisclaimerItem = styled(ListItem)`
  margin-bottom: 12px;
  font-size: 14px;
`;
export const StyledHR = styled.hr`
  color: ${({ theme }) => theme.color.border};
  background-color: ${({ theme }) => theme.color.border};
  width: 100%;
  border: 0;
  height: 1px;
  margin-bottom: 30px;
  @media (max-width: 768px) {
    margin-top: 34px;
  }
  @media (min-width: 769px) {
    margin-bottom: 36px;
    margin-top: 36px;
  }
`;

export const StyledDivDisclaimerTnCHeader = styled.div`
  font-weight: 500;
  color: #2d373e;
  margin-bottom: 12px;
`;
export const StyledDivDisclaimerTnC = styled.div`
  color: #636a71;
`;
export const ReviewPageDisclaimerSection = ({
  selectedLoanOption,
  breakCostUrl,
  advantagePackage,
  selectedAccountLabel,
  switchFee,
  monthlyMaintainence,
}) => (
  <div>
    {isRedrawLoan(selectedLoanOption) && (
      <StyledDivDisclaimerText>
        Your available funds will be transferred to&nbsp;
        <b>{selectedAccountLabel}</b> once we process your request.
      </StyledDivDisclaimerText>
    )}
    {isClearLoan(selectedLoanOption) && (
      <StyledDivDisclaimerText>
        We&apos;ll clear your available funds when we process your request.
      </StyledDivDisclaimerText>
    )}
    <StyledDivDisclaimerText>
      *Your new loan balance and monthly repayments are indicative only. If
      there are changes to your current loan amount before we process your
      request, these details will update accordingly.
    </StyledDivDisclaimerText>
    <StyledHR />
    <StyledDivDisclaimerTnCHeader>
      By submitting this request, I understand and accept that
    </StyledDivDisclaimerTnCHeader>
    <StyledDivDisclaimerTnC>
      <List bullet="circle" styling="neutral">
        <StyledDisclaimerItem>
          My rate will be fixed for the specified term regardless of whether
          interest rates rise or fall
        </StyledDisclaimerItem>

        <StyledDisclaimerItem>
          I may be required to pay&nbsp;
          <a href={breakCostUrl} target="_blank" rel="noreferrer noopener">
            break costs
          </a>
          &nbsp;to the Bank if during the fixed rate period I repay ahead of
          time all or part of the loan, make additional payments above the
          prepayment threshold of $30,000.00 or switch to another product,
          interest rate or repayment type
        </StyledDisclaimerItem>
        <StyledDisclaimerItem>
          {!advantagePackage ? getSwitchingFeeText(switchFee) : ''}
        </StyledDisclaimerItem>
        <StyledDisclaimerItem>
          {!advantagePackage
            ? getMonthlyMaintainenceFee(monthlyMaintainence)
            : ''}
        </StyledDisclaimerItem>
        <StyledDisclaimerItem>
          Any other borrowers will receive confirmation of this request
        </StyledDisclaimerItem>
      </List>
    </StyledDivDisclaimerTnC>
  </div>
);
ReviewPageDisclaimerSection.propTypes = {
  selectedLoanOption: PropTypes.string.isRequired,
  breakCostUrl: PropTypes.string.isRequired,
  advantagePackage: PropTypes.bool.isRequired,
  selectedAccountLabel: PropTypes.string,
  switchFee: PropTypes.string,
  monthlyMaintainence: PropTypes.string,
};
ReviewPageDisclaimerSection.defaultProps = {
  selectedAccountLabel: '',
  switchFee: '500',
  monthlyMaintainence: '8',
};
export default ReviewPageDisclaimerSection;
