import React from 'react';
import PropTypes from 'prop-types';
import { IconAdd } from '@wdpui/react-gel';
import styled from 'styled-components';
import { Column, Row } from '@wdpui/gel-grid';
import { DisplayLoanDetails } from './DisplayLoanDetails';
import { ReviewPageDisclaimerSection } from './ReviewPageDisclaimerSection';
import { ActionButtons, FocusedPageTitle } from '../common';

import {
  HeadingColouredText,
  PanelWhiteWithBorder,
  StyledGridPnl,
  HR,
  StyledRowPnl,
} from '../common/styles';
import { getReviewHeaderTitleText } from '../../helpers/reviewPageHelper';

import { isSplitLoan } from '../../helpers/loanOptionsHelper';

export const StyledDiv = styled(HeadingColouredText)`
  margin-bottom: 12px;
`;

export const StyledIconAdd = styled(IconAdd)`
  margin-bottom: 12px;
  margin-top: -9px;
  align-self: center;
`;

export const StyledHR = styled(HR)`
  margin-bottom: 36px;
  margin-top: 15px;
  @media only screen and (max-width: 480px) {
    margin-bottom: 30px;
    margin-top: 9px;
  }
`;

export const ReviewPageComponent = ({
  selectedLoanOption,
  loanBalance,
  availableFunds,
  interestRate,
  advantagePackage,
  repaymentType,
  selectedRepaymentType,
  loanTerm,
  monthlyRepayments,
  breakCostUrl,
  backToChannel,
  navigateNext,
  selectedAccountLabel,
  switchFee,
  monthlyMaintainence,
  splitVariableAmount,
  splitFixedAmount,
  calculatedVariableLoanBalance,
  calculatedFixedLoanBalance,
  variableInterestRate,
  productName,
  switchedProductName,
  selectedDiscountText,
}) => (
  <StyledGridPnl id="gridPnlReview">
    <StyledRowPnl>
      <FocusedPageTitle title={getReviewHeaderTitleText(selectedLoanOption)} />
    </StyledRowPnl>
    <PanelWhiteWithBorder direction="column" id="whiteborderpnl">
      <Column px={2} pb={4} id="colwhite">
        <StyledDiv>
          <HeadingColouredText weight="medium" size={2}>
            Current loan details
          </HeadingColouredText>
        </StyledDiv>

        <DisplayLoanDetails
          title={productName}
          type="Variable"
          loanBalance={loanBalance}
          availableFunds={availableFunds}
          interestRate={variableInterestRate}
          repaymentType={repaymentType}
          loanTerm={loanTerm}
          monthlyRepayments={monthlyRepayments}
          unlimitedRepayment
          advantagePackage={advantagePackage}
          switchFee={switchFee}
          monthlyMaintainence={monthlyMaintainence}
        />

        <StyledHR />
        <StyledDiv>
          <HeadingColouredText weight="medium" size={2}>
            New loan details
          </HeadingColouredText>
        </StyledDiv>
        {isSplitLoan(selectedLoanOption) ? (
          <DisplayLoanDetails
            title={productName}
            type="NewLoan"
            loanBalance={calculatedVariableLoanBalance}
            availableFunds={availableFunds}
            interestRate={variableInterestRate}
            repaymentType={repaymentType}
            loanTerm={loanTerm}
            monthlyRepayments={splitVariableAmount}
            unlimitedRepayment
            advantagePackage={advantagePackage}
            switchFee={switchFee}
            monthlyMaintainence={monthlyMaintainence}
          />
        ) : (
          ''
        )}

        {isSplitLoan(selectedLoanOption) ? <StyledIconAdd /> : ''}
        <DisplayLoanDetails
          title={switchedProductName}
          type="Fixed"
          loanBalance={calculatedFixedLoanBalance}
          availableFunds={availableFunds}
          interestRate={interestRate}
          repaymentType={selectedRepaymentType}
          loanTerm={loanTerm}
          monthlyRepayments={splitFixedAmount}
          unlimitedRepayment={false}
          advantagePackage={advantagePackage}
          switchFee={switchFee}
          monthlyMaintainence={monthlyMaintainence}
          selectedDiscountText={selectedDiscountText}
        />

        <ReviewPageDisclaimerSection
          switchFee={switchFee}
          monthlyMaintainence={monthlyMaintainence}
          selectedLoanOption={selectedLoanOption}
          breakCostUrl={breakCostUrl}
          advantagePackage={advantagePackage}
          selectedAccountLabel={selectedAccountLabel}
        />
      </Column>
    </PanelWhiteWithBorder>
    <Row direction="column" px={2}>
      <Column px={[0, 0, 12, 12]}>
        <ActionButtons
          leftButtonLabel="Cancel"
          leftButtonClick={backToChannel}
          rightButtonLabel="Submit"
          rightButtonClick={navigateNext}
        />
      </Column>
    </Row>
  </StyledGridPnl>
);

ReviewPageComponent.propTypes = {
  selectedLoanOption: PropTypes.string.isRequired,
  loanBalance: PropTypes.string.isRequired,
  availableFunds: PropTypes.string.isRequired,
  interestRate: PropTypes.string.isRequired,
  repaymentType: PropTypes.string.isRequired,
  selectedRepaymentType: PropTypes.string.isRequired,
  loanTerm: PropTypes.string.isRequired,
  monthlyRepayments: PropTypes.string.isRequired,
  breakCostUrl: PropTypes.string.isRequired,
  navigateNext: PropTypes.func.isRequired,
  backToChannel: PropTypes.func.isRequired,
  advantagePackage: PropTypes.bool.isRequired,
  selectedAccountLabel: PropTypes.string,
  switchFee: PropTypes.string,
  monthlyMaintainence: PropTypes.string,
  splitVariableAmount: PropTypes.string.isRequired,
  splitFixedAmount: PropTypes.string.isRequired,
  calculatedVariableLoanBalance: PropTypes.string,
  calculatedFixedLoanBalance: PropTypes.string.isRequired,
  variableInterestRate: PropTypes.string.isRequired,
  productName: PropTypes.string.isRequired,
  switchedProductName: PropTypes.string.isRequired,
  selectedDiscountText: PropTypes.string.isRequired,
};
ReviewPageComponent.defaultProps = {
  calculatedVariableLoanBalance: '',
  selectedAccountLabel: '',
  switchFee: '',
  monthlyMaintainence: '',
};
export default ReviewPageComponent;
