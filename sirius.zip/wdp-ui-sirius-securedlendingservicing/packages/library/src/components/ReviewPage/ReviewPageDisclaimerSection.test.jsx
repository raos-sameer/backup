import { shallow, mount } from 'enzyme';
import React from 'react';
import {
  ReviewPageDisclaimerSection,
  StyledDivDisclaimerText,
  StyledDisclaimerItem,
} from './ReviewPageDisclaimerSection';
import { withTheme } from '../../../../../utils/jest/TestUtils';

const props = {
  loanBalance: '1141',
  availableFunds: '1123',
  switchFee: '500',
  monthlyMaintainence: '8',
  interestRate: '1.23',
  repaymentType: 'IO',
};
describe('ReviewPageDisclaimerSection', () => {
  it('renders the ReviewPageDisclaimerSection structure', () => {
    props.selectedLoanOption = 'RedrawAvailableFunds';
    const component = <ReviewPageDisclaimerSection {...props} />;
    const wrapper = shallow(component);
    expect(wrapper.find('div').exists()).toBe(true);
  });

  it('renders have table contents according to Fixed Type of Loan', () => {
    props.advantagePackage = false;

    const component = <ReviewPageDisclaimerSection {...props} />;

    const wrapper = shallow(component);
    expect(
      wrapper
        .find(StyledDisclaimerItem)
        .at(2)
        .text(),
    ).toMatch(`A switching fee of $500.00`);
    expect(
      wrapper
        .find(StyledDisclaimerItem)
        .at(3)
        .text(),
    ).toMatch(/monthly loan maintenance fee will apply/);
  });
  it('renders have table contents according to Fixed Type of Loan', () => {
    props.selectedLoanOption = 'AccessFundsOption';

    const component = <ReviewPageDisclaimerSection {...props} />;

    const wrapper = shallow(component);
    expect(
      wrapper
        .find(StyledDivDisclaimerText)
        .at(0)
        .text(),
    ).toMatch(/clear your available funds when we process your request/);
  });
  it('renders disclaimer text for redraw', () => {
    props.selectedLoanOption = 'RedrawFundsOption';

    const component = <ReviewPageDisclaimerSection {...props} />;
    const wrapper = shallow(component);
    expect(
      wrapper
        .find(StyledDivDisclaimerText)
        .at(0)
        .text(),
    ).toMatch(/Your available funds will be transferred to/);
  });
  it('should check for header right color value rendered', () => {
    const wrapper = mount(withTheme(<div color="#621a4b" />));
    expect(wrapper.getDOMNode('div').attributes.color.value).toEqual('#621a4b');
  });
});
