import { shallow } from 'enzyme';
import React from 'react';
import { Table } from '@wdpui/react-gel';
import { TickIcon } from '../common/styles';
import {
  DisplayLoanDetails,
  StyledReviewPagePanel,
  CloseIcon,
  StyledTd,
  StyledTable,
} from './DisplayLoanDetails';

describe('DisplayLoanDetails', () => {
  it('renders the DisplayLoanDetails structure', () => {
    const component = (
      <DisplayLoanDetails
        advantagePackage={false}
        title="SomeTitle"
        type="Fixed"
        repaymentType="PIF"
      />
    );
    const wrapper = shallow(component);
    expect(wrapper.find(StyledReviewPagePanel).exists()).toBe(true);
    expect(wrapper.find(Table).exists()).toBe(true);
    expect(wrapper.find(TickIcon).exists()).toBe(true);
    expect(wrapper.find(CloseIcon).exists()).toBe(true);
    expect(wrapper).toMatchSnapshot();
  });

  it('renders have table contents if type is Fixed and no package customer and repayment Type is PI', () => {
    const component = (
      <DisplayLoanDetails
        availableFunds="111"
        advantagePackage={false}
        title="SomeTitle"
        type="Fixed"
        repaymentType="PIF"
        monthlyMaintainence="8"
      />
    );

    const wrapper = shallow(component);

    expect(wrapper.find(StyledReviewPagePanel).exists()).toBe(true);
    expect(wrapper.find(StyledTable).exists()).toBe(true);
    expect(
      wrapper
        .find(StyledTd)
        .first()
        .text(),
    ).toEqual('Loan balance*');
    expect(
      wrapper
        .find(StyledTd)
        .at(4)
        .text(),
    ).toEqual('Fixed interest rate');
    expect(
      wrapper
        .find(StyledTd)
        .at(6)
        .text(),
    ).toEqual('Fixed term');
    expect(
      wrapper
        .find(StyledTd)
        .at(10)
        .text(),
    ).toEqual('Indicative monthly repayments*');

    expect(
      wrapper
        .find(StyledTd)
        .at(11)
        .text(),
    ).toMatch(/8.00 monthly loan maintenance fee/);
    expect(wrapper.find(TickIcon).exists()).toBe(true);
    expect(wrapper.find(CloseIcon).exists()).toBe(true);
  });
  it('renders have table contents if loan type is Split and component is variable', () => {
    const component = (
      <DisplayLoanDetails
        availableFunds="111"
        selectedLoanOption="Split"
        title="SomeTitle"
        type="Variable"
        repaymentType="PIF"
        monthlyMaintainence="8"
        monthlyRepayments="1200"
      />
    );

    const wrapper = shallow(component);
    expect(wrapper.find(StyledReviewPagePanel).exists()).toBe(true);
    expect(
      wrapper
        .find(StyledTd)
        .at(0)
        .text(),
    ).toEqual('Current balance');
    expect(
      wrapper
        .find(StyledTd)
        .at(4)
        .text(),
    ).toEqual('Variable interest rate');
    expect(
      wrapper
        .find(StyledTd)
        .at(8)
        .text(),
    ).toEqual('Contracted monthly repayments');
    expect(wrapper.find(TickIcon).exists()).toBe(true);
    expect(wrapper.find(CloseIcon).exists()).toBe(false);
  });

  it('renders have table contents if its not package customer and type is New Loan and repayment type is PI', () => {
    const component = (
      <DisplayLoanDetails
        availableFunds="111"
        advantagePackage={false}
        title="SomeTitle"
        type="NewLoan"
        repaymentType="PIF"
        monthlyMaintainence="8"
      />
    );

    const wrapper = shallow(component);
    expect(wrapper.find(StyledReviewPagePanel).exists()).toBe(true);
    expect(
      wrapper
        .find(StyledTd)
        .first()
        .text(),
    ).toEqual('Loan balance*');
    expect(
      wrapper
        .find(StyledTd)
        .at(8)
        .text(),
    ).toEqual('Indicative monthly repayments*');

    expect(wrapper.find(TickIcon).exists()).toBe(true);
  });
  it('renders have table contents if nno available funds and for type NewLoan and repayment type PI', () => {
    const component = (
      <DisplayLoanDetails
        availableFunds=""
        title="SomeTitle"
        type="NewLoan"
        repaymentType="PIF"
      />
    );

    const wrapper = shallow(component);
    expect(wrapper.find(StyledReviewPagePanel).exists()).toBe(true);
    expect(
      wrapper
        .find(StyledTd)
        .first()
        .text(),
    ).toEqual('Loan balance*');

    expect(
      wrapper
        .find(StyledTd)
        .at(2)
        .text(),
    ).toMatch(/interest rate/);

    expect(wrapper.find(TickIcon).exists()).toBe(true);
  });
});
