import React from 'react';
import PropTypes from 'prop-types';
import { Table, Tbody, Tr, Td } from '@wdpui/gel-table';
import { IconClose } from '@wdpui/gel-symbols';
import { Panel } from '@wdpui/gel-panel';
import styled from 'styled-components';
import { TickIcon } from '../common/styles';
import {
  getRepaymentType,
  getNegatedAmountText,
} from '../../helpers/loanOptionsHelper';

import {
  getLoanTypeText,
  getMonthlyRepaymentText,
  isNewLoanComponent,
  isFixedComponent,
} from '../../helpers/loanSummaryHelper';
import {
  formatAmount,
  formatToTwoDecimalPlaces,
} from '../../helpers/amountFormatter';
import {
  LIMITED_REPAYMENT_TEXT,
  UNLIMITED_REPAYMENT_TEXT,
} from '../../helpers/constants';

export const StyledTable = styled(Table)`
  margin-bottom: 0px;
  padding-bottom: 0px;
`;
export const CloseIcon = styled(IconClose)`
  margin-bottom: 6px;
  color: #621a4b;
`;
export const StyledTd = styled(Td)`
  margin-left-12px;
  vertical-align: top;
`;

export const StyledPanel = styled(Panel)`
  align: left;
`;
export const StyledReviewPagePanel = styled(Panel)`
  align: left;
`;

export const DisplayLoanDetails = ({
  title,
  type,
  loanBalance,
  availableFunds,
  interestRate,
  repaymentType,
  loanTerm,
  monthlyRepayments,
  advantagePackage,
  unlimitedRepayment,
  monthlyMaintainence,
  selectedDiscountText,
}) => (
  <StyledReviewPagePanel title={title}>
    <Table>
      <Tbody>
        <Tr>
          <StyledTd>
            {getLoanTypeText(type)}
            {isFixedComponent(type) || isNewLoanComponent(type) ? '*' : ''}
          </StyledTd>
          <StyledTd>
            <b>{getNegatedAmountText(loanBalance, true)}</b>
          </StyledTd>
        </Tr>
        {availableFunds ? (
          <Tr>
            <StyledTd>
              Available funds{isFixedComponent(type) ? '*' : ''}
            </StyledTd>
            <StyledTd>
              <b>
                {isFixedComponent(type)
                  ? '$0.00'
                  : getNegatedAmountText(availableFunds, false)}
              </b>
            </StyledTd>
          </Tr>
        ) : (
          <Tr />
        )}
        <Tr>
          <StyledTd>
            {isNewLoanComponent(type) ? 'Variable' : type} interest rate
          </StyledTd>

          <StyledTd>
            <b>{formatToTwoDecimalPlaces(interestRate)}% p.a.</b>
            <br />
            {selectedDiscountText}
          </StyledTd>
        </Tr>
        {isFixedComponent(type) ? (
          <Tr>
            <StyledTd>Fixed term</StyledTd>
            <StyledTd>
              <b>{loanTerm} year</b>
            </StyledTd>
          </Tr>
        ) : (
          <Tr />
        )}
        <Tr>
          <StyledTd>Repayment type</StyledTd>
          <StyledTd>
            <b>{getRepaymentType(repaymentType)}</b>
          </StyledTd>
        </Tr>
        <Tr>
          <StyledTd>
            {getMonthlyRepaymentText(type)}
            {isFixedComponent(type) || isNewLoanComponent(type) ? '*' : ''}
          </StyledTd>
          <StyledTd>
            <b>{getNegatedAmountText(monthlyRepayments, false)}</b>
            {!advantagePackage ? (
              <div>
                (Includes {formatAmount(monthlyMaintainence)} monthly loan
                maintenance fee)
              </div>
            ) : (
              ''
            )}
          </StyledTd>
        </Tr>
        <Tr>
          <StyledTd>Loan features</StyledTd>
          <StyledTd>
            <StyledTable>
              <Tr>
                <StyledTd>
                  <TickIcon size="small" />
                </StyledTd>
                <StyledTd>
                  Additional repayments&nbsp;
                  {unlimitedRepayment ? UNLIMITED_REPAYMENT_TEXT : ''}
                  <b>{!unlimitedRepayment ? LIMITED_REPAYMENT_TEXT : ''}</b>
                </StyledTd>
              </Tr>
              <Tr>
                <StyledTd>
                  {!isFixedComponent(type) ? (
                    <TickIcon size="small" />
                  ) : (
                    <CloseIcon size="small" />
                  )}
                </StyledTd>
                <StyledTd>Offset benefits</StyledTd>
              </Tr>

              {advantagePackage ? (
                <Tr>
                  <StyledTd>
                    <TickIcon size="small" />
                  </StyledTd>
                  <StyledTd>Premier Advantage Package</StyledTd>
                </Tr>
              ) : (
                <Tr />
              )}
            </StyledTable>
          </StyledTd>
        </Tr>
      </Tbody>
    </Table>
  </StyledReviewPagePanel>
);
DisplayLoanDetails.propTypes = {
  title: PropTypes.string.isRequired,
  type: PropTypes.string.isRequired,
  loanBalance: PropTypes.string.isRequired,
  availableFunds: PropTypes.string.isRequired,
  interestRate: PropTypes.string.isRequired,
  repaymentType: PropTypes.string.isRequired,
  loanTerm: PropTypes.string.isRequired,
  monthlyRepayments: PropTypes.string.isRequired,
  unlimitedRepayment: PropTypes.bool.isRequired,
  advantagePackage: PropTypes.bool.isRequired,
  monthlyMaintainence: PropTypes.string.isRequired,
  selectedDiscountText: PropTypes.string.isRequired,
};
export default DisplayLoanDetails;
