import React from 'react';
import { Text } from '@wdpui/gel-typography';

import { Column } from '@wdpui/gel-grid';
import { Button } from '@wdpui/gel-button';
import PropTypes from 'prop-types';
import styled from 'styled-components';
import { FocusedPageTitle } from './common';
import {
  PanelWhiteWithBorder,
  StyledRowPnl,
  ActionButtonRow,
  StyledGridPnl,
  RightStyledColumn,
} from './common/styles';
import { formattedDate } from '../helpers/dateFormatter';

export const StyledPanelWhiteWithBorder = styled(PanelWhiteWithBorder)`
  @media (max-width: 480px) {
    padding-left: 15px;
    padding-right: 15px;
    padding-top: 30px;
    padding-bottom: 36px;
  }
`;

const Error = ({
  heading,
  onDoneClick,
  btnLabel,
  errorCode,
  caseSubmittedDate,
}) => (
  <StyledGridPnl id="gridPnlYearTerm">
    <StyledRowPnl>
      <FocusedPageTitle title={heading} />
    </StyledRowPnl>
    <StyledPanelWhiteWithBorder direction="column" pb={36}>
      <Column>
        {errorCode === 'fatalerror' && (
          <Text size={3}>
            We were unable to complete your request. Please try again later.
          </Text>
        )}
        {errorCode === 'caseexists' && (
          <Text size={3}>
            A request was submitted {formattedDate(caseSubmittedDate)} (Sydney
            Time). A receipt will be sent to your message inbox where you can
            check the details of your request
          </Text>
        )}
        {errorCode === 'eligibilityfail' && (
          <Text size={3}>
            Call us on <a href="tel:131 900">131 900</a> or visit a branch to
            switch to a fixed rate home loan.
          </Text>
        )}
      </Column>
    </StyledPanelWhiteWithBorder>

    <ActionButtonRow id="teja" mt={30} mx={0}>
      <RightStyledColumn width={[1, 4 / 12, 4 / 12, 3 / 12]} mb={0}>
        <Button size="large" label={btnLabel} onClick={onDoneClick} />
      </RightStyledColumn>
    </ActionButtonRow>
  </StyledGridPnl>
);

Error.propTypes = {
  onDoneClick: PropTypes.func.isRequired,
  btnLabel: PropTypes.string.isRequired,
  heading: PropTypes.string.isRequired,
  errorCode: PropTypes.string.isRequired,
  caseSubmittedDate: PropTypes.string,
};

Error.defaultProps = {
  caseSubmittedDate: '',
};

export default Error;
