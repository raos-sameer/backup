import React from 'react';
import { Column, Row } from '@wdpui/gel-grid';
import PropTypes from 'prop-types';
import styled from 'styled-components';
import { ActionButtons, FocusedPageTitle } from '../common';
import {
  TickIcon,
  HeadingColouredText,
  PanelWhiteWithBorder,
  MutedText,
  NewListItemShowHide,
  StyledGridPnl,
  StyledRowPnl,
  BorderBottom,
} from '../common/styles';
import { LandingNoPackagePanel } from './LandingNoPackagePanel';
import { ImportantThings } from './ImportantThings';

export const StyledMutedText = styled(MutedText)`
  margin-top: 18px;
`;

export const NewStyledMutedText = styled(MutedText)`
  margin-top: 0px;
  margin-bottom: 0px;
`;

export const LandingPage = ({
  navigateNext,
  backToChannel,
  advantagePackage,
  isFlexiProduct,
  breakCostUrl,
  switchFee,
  monthlyMaintainence,
  additionalPaymentAmount,
}) => (
  <StyledGridPnl id="gridPnlLanding">
    <StyledRowPnl>
      <FocusedPageTitle title="Switch to a fixed rate loan" />
    </StyledRowPnl>
    <PanelWhiteWithBorder direction="column" id="whiteborderpnl">
      <Column px={2} pb={4} id="colwhite">
        <HeadingColouredText weight="medium" size={2}>
          A fixed rate allows you to...
        </HeadingColouredText>

        <NewListItemShowHide>
          <Column>
            <TickIcon />
          </Column>
          <Column px={-1}>
            <NewStyledMutedText size={1}>
              {' '}
              Lock in a rate for 1-5 years
            </NewStyledMutedText>
          </Column>
        </NewListItemShowHide>

        <NewListItemShowHide>
          <Column>
            <TickIcon />
          </Column>
          <Column px={-1}>
            <NewStyledMutedText size={1}>
              {' '}
              Enjoy the certainty of knowing what your repayments will be{' '}
            </NewStyledMutedText>
          </Column>
        </NewListItemShowHide>

        <StyledMutedText>
          You can choose to fix your entire loan or just a portion of it
        </StyledMutedText>
        <BorderBottom />
        <ImportantThings
          breakCostUrl={breakCostUrl}
          isFlexiProduct={isFlexiProduct}
          advantagePackage={advantagePackage}
          switchFee={switchFee}
          monthlyMaintainence={monthlyMaintainence}
          additionalPaymentAmount={additionalPaymentAmount}
        />
        <LandingNoPackagePanel />
      </Column>
    </PanelWhiteWithBorder>
    <Row direction="column" px={2}>
      <Column px={[0, 0, 12, 12]}>
        <ActionButtons
          leftButtonLabel="Cancel"
          leftButtonClick={backToChannel}
          rightButtonLabel="Let's get started"
          rightButtonClick={navigateNext}
        />
      </Column>
    </Row>
  </StyledGridPnl>
);

LandingPage.propTypes = {
  advantagePackage: PropTypes.bool.isRequired,
  navigateNext: PropTypes.func.isRequired,
  backToChannel: PropTypes.func.isRequired,
  isFlexiProduct: PropTypes.bool.isRequired,
  breakCostUrl: PropTypes.string.isRequired,
  switchFee: PropTypes.string.isRequired,
  monthlyMaintainence: PropTypes.string.isRequired,
  additionalPaymentAmount: PropTypes.string.isRequired,
};
export default LandingPage;
