import React from 'react';
import { shallow } from 'enzyme';
import { List } from '@wdpui/gel-list';
import { ImportantThings } from './ImportantThings';
import {
  HeadingColouredText,
  MutedText,
  ListItemShowHide,
} from '../common/styles';
import { withTheme } from '../../../../../utils/jest/TestUtils';

describe('ImportantThings', () => {
  it('renders the Landing Page ImportantThings structure', () => {
    const component = <ImportantThings />;
    const wrapper = shallow(component);
    expect(wrapper.find(HeadingColouredText).exists()).toBe(true);
    expect(wrapper.find(MutedText).exists()).toBe(true);
    expect(wrapper.find(List).exists()).toBe(true);

    expect(wrapper.find(ListItemShowHide).exists()).toBe(true);
    expect(wrapper).toMatchSnapshot();
  });

  it('should load different list item if its a flexi product', () => {
    const props = {
      advantagePackage: false,
      isFlexiProduct: true,
      breakCostUrl:
        'https://www.westpac.com.au/content/dam/public/wbc/documents/pdf/pb/WBC-things-you-should-know-about-break-costs.pdf?appAction=PDF',
    };
    const component = withTheme(<ImportantThings {...props} />);

    const wrapper = shallow(component)
      .dive()
      .dive()
      .dive();
    expect(wrapper.find('#fixedrtptspnl').find('Styled(ListItem)').length).toBe(
      6,
    );
  });
});
