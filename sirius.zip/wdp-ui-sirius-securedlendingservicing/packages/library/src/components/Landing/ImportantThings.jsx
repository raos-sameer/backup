import React from 'react';
import styled from 'styled-components';
import { Button } from '@wdpui/gel-button';
import { List } from '@wdpui/gel-list';
import PropTypes from 'prop-types';
import { formatAmount } from '../../helpers/amountFormatter';

import {
  HeadingColouredText,
  MutedText,
  ListItemShowHide,
} from '../common/styles';

import {
  showSpecialBulletForFlexiOrPackage,
  showSpecialBulletOnlyForFlexi,
} from '../../helpers/landingPageHelper';

export const CallUsButton = styled(Button)`
  margin-bottom: 18px;
`;

export const ImportantThings = ({
  breakCostUrl,
  isFlexiProduct,
  advantagePackage,
  switchFee,
  monthlyMaintainence,
  additionalPaymentAmount,
}) => (
  <>
    <HeadingColouredText weight="medium" size={2} textAlign="left">
      Important things to consider about fixed rate loans
    </HeadingColouredText>
    <List bullet="circle" styling="neutral" id="fixedrtptspnl" role="list">
      <ListItemShowHide role="listitem">
        <MutedText size={1}> Offset benefits don&apos;t apply</MutedText>
      </ListItemShowHide>

      <ListItemShowHide role="listitem">
        <MutedText size={1}>
          You can only make additional payments up to &nbsp;
          {formatAmount(additionalPaymentAmount)} on top of your total
          contracted repayments without incurring&nbsp;
          <a href={breakCostUrl} target="_blank" rel="noreferrer noopener">
            break costs
          </a>
        </MutedText>
      </ListItemShowHide>

      <ListItemShowHide role="listitem">
        <MutedText size={1}>
          If you change products or refinance before the fixed contract is up
          you may be charged&nbsp;
          <a href={breakCostUrl} target="_blank" rel="noreferrer noopener">
            break costs
          </a>
        </MutedText>
      </ListItemShowHide>

      <ListItemShowHide
        role="listitem"
        renderItem={showSpecialBulletForFlexiOrPackage(
          advantagePackage,
          isFlexiProduct,
        )}
      >
        <MutedText size={1}>
          There&apos;ll will be a {formatAmount(switchFee)} fee charged to your
          loan account on switching to a fixed rate
        </MutedText>
      </ListItemShowHide>
      <ListItemShowHide
        role="listitem"
        renderItem={showSpecialBulletOnlyForFlexi(isFlexiProduct)}
      >
        <MutedText size={1}>
          Your loan will automatically change to the applicable Rocket Loan
          product at the end of the fixed rate period.
        </MutedText>
      </ListItemShowHide>
      <ListItemShowHide
        role="listitem"
        renderItem={showSpecialBulletOnlyForFlexi(isFlexiProduct)}
      >
        <MutedText size={1}>
          An {formatAmount(monthlyMaintainence)} monthly loan maintenance fee
          applies to fixed rate loans and variable Rocket Loans
        </MutedText>
      </ListItemShowHide>
    </List>
  </>
);
ImportantThings.propTypes = {
  isFlexiProduct: PropTypes.bool.isRequired,
  breakCostUrl: PropTypes.string.isRequired,
  advantagePackage: PropTypes.bool.isRequired,
  switchFee: PropTypes.string.isRequired,
  monthlyMaintainence: PropTypes.string.isRequired,
  additionalPaymentAmount: PropTypes.string.isRequired,
};
export default ImportantThings;
