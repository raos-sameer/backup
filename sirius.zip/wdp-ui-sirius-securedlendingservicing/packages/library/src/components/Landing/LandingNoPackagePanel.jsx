import React from 'react';
import styled from 'styled-components';
import { Button } from '@wdpui/gel-button';
import { Text } from '@wdpui/gel-typography';
import { List } from '@wdpui/gel-list';
import { Row } from '@wdpui/gel-grid';

import {
  HeadingColouredText,
  MutedText,
  LightBackGroundContainer,
  ListItemShowHide,
} from '../common/styles';

import { MediaMatch } from '../common';

export const CallUsButton = styled(Button)`
  margin-bottom: 18px;
  font-weight: bold;
`;

export const LandingNoPackagePanel = () => (
  <LightBackGroundContainer direction="column">
    <HeadingColouredText weight="medium" size={2}>
      Fixing your loan may not be right for you if you&apos;re expecting to
    </HeadingColouredText>
    <List bullet="circle" styling="neutral" role="list">
      <ListItemShowHide role="listitem">
        <MutedText size={1}>Sell your property</MutedText>
      </ListItemShowHide>
      <ListItemShowHide role="listitem">
        <MutedText size={1}>Refinance or change products</MutedText>
      </ListItemShowHide>
      <ListItemShowHide role="listitem">
        <MutedText size={1}>
          Make any large additional payments on your loan
        </MutedText>
      </ListItemShowHide>
    </List>

    <MutedText size={1}>
      We want to help you make the right decision,
      <b> so if this is the case...</b>
    </MutedText>
    <MediaMatch query={{ lg: true, md: true, sm: true, xs: false }}>
      <Text>
        Call us on <a href="tel:131900">131 900</a>
      </Text>
    </MediaMatch>
    <MediaMatch query={{ lg: false, md: false, sm: false, xs: true }}>
      <>
        <Row mt={12}>
          <CallUsButton
            href="tel:13 33 30"
            block
            soft
            size="large"
            styling="hero"
            label="Call us"
          />
        </Row>
      </>
    </MediaMatch>
  </LightBackGroundContainer>
);

export default LandingNoPackagePanel;
