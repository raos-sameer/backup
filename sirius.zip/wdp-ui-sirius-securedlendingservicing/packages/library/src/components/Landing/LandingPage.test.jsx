import { shallow, mount } from 'enzyme';
import React from 'react';

import { LandingPage } from './LandingPage';
import { ActionButtons, FocusedPageTitle } from '../common';

import {
  TickIcon,
  HeadingColouredText,
  PanelWhiteWithBorder,
  MutedText,
  NewListItemShowHide,
  StyledGridPnl,
  StyledRowPnl,
} from '../common/styles';
import {
  withThemeManager,
  withTheme,
} from '../../../../../utils/jest/TestUtils';

const mockFn = jest.fn();

describe('LandingPage', () => {
  it('renders the LandingPage structure', () => {
    const component = <LandingPage />;
    const wrapper = shallow(component);
    expect(wrapper.find(TickIcon).exists());
    expect(wrapper.find(FocusedPageTitle).exists());
    expect(wrapper.find(PanelWhiteWithBorder).exists());
    expect(wrapper.find(HeadingColouredText).exists());
    expect(wrapper.find(MutedText).exists());
    expect(wrapper.find(NewListItemShowHide).exists()).toBe(true);
    expect(wrapper.find(StyledGridPnl).exists());
    expect(wrapper.find(StyledRowPnl).exists());

    expect(wrapper.find(ActionButtons).exists());

    expect(wrapper).toMatchSnapshot();
  });

  it('should check for MutedText right color value rendered', () => {
    const wrapper = mount(withTheme(<MutedText color="#575f65" />));
    expect(wrapper.getDOMNode('Text').attributes.color.value).toEqual(
      '#575f65',
    );
  });

  it('should hide the component if render item is set to false for list item component', () => {
    const wrapper = mount(
      withThemeManager(
        <NewListItemShowHide
          styling="neutral"
          bullet="circle"
          renderItem="false"
        >
          Test2
        </NewListItemShowHide>,
      ),
    );
    expect(wrapper).toMatchSnapshot();
  });

  it('should find List Item to render true length', () => {
    const props = {
      advantagePackage: false,
      isFlexiProduct: true,
      navigateNext: { mockFn },
      backToChannel: { mockFn },
      breakCostUrl:
        'https://www.westpac.com.au/content/dam/public/wbc/documents/pdf/pb/WBC-things-you-should-know-about-break-costs.pdf?appAction=PDF',
    };
    const component = withTheme(<LandingPage {...props} />);

    const wrapper = shallow(component)
      .dive()
      .dive()
      .dive()
      .dive()
      .dive()
      .dive()
      .dive()
      .dive();
    expect(wrapper.find('Styled(ListItem)').length).toBe(0);
  });
});
