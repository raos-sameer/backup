import React from 'react';
import { shallow } from 'enzyme';
import { List } from '@wdpui/gel-list';
import { LandingNoPackagePanel, CallUsButton } from './LandingNoPackagePanel';
import { MediaMatch } from '../common';
import {
  HeadingColouredText,
  MutedText,
  LightBackGroundContainer,
  ListItemShowHide,
} from '../common/styles';
import { withTheme } from '../../../../../utils/jest/TestUtils';

const mockFn = jest.fn();

describe('LandingNoPackagePanel', () => {
  it('renders the LandingNoPackagePanel structure', () => {
    const component = <LandingNoPackagePanel />;
    const wrapper = shallow(component);
    expect(wrapper.find(HeadingColouredText).exists()).toBe(true);
    expect(wrapper.find(LightBackGroundContainer).exists()).toBe(true);
    expect(wrapper.find(MutedText).exists()).toBe(true);
    expect(wrapper.find(List).exists()).toBe(true);

    expect(wrapper.find(ListItemShowHide).exists()).toBe(true);
    expect(wrapper).toMatchSnapshot();
  });

  it('renders the call us button and media text depending on query', () => {
    const discprops = {
      isExpiryDateLessThanYear: false,
      isPrincipalInterestCustomer: false,
      advantagePackage: false,
      repaymentType: 'IO',
      showReviewDetailsPopup: { mockFn },
      hideReviewDetailsPopup: { mockFn },
    };

    const component = withTheme(<LandingNoPackagePanel {...discprops} />);
    const wrapper = shallow(component)
      .dive()
      .dive()
      .dive()
      .dive()
      .dive()
      .dive()
      .dive();
    expect(wrapper.find(MediaMatch).exists()).toBe(true);

    expect(wrapper.find(CallUsButton).exists()).toBe(true);
    expect(wrapper.find(MutedText).exists()).toBe(true);
    expect(wrapper).toMatchSnapshot();
  });
});
