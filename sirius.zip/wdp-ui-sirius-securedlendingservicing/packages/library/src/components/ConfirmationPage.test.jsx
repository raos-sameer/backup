import React from 'react';
import configureMockStore from 'redux-mock-store';

import renderer from 'react-test-renderer';
import { shallow } from 'enzyme';
import { BrowserRouter as Router } from 'react-router-dom';
import { withTheme } from '../../../../utils/jest/TestUtils';
import ConfirmationPage from './ConfirmationPage';
import { mockStoreData } from '../__fixtures__/mockRouteStore.fixture';

describe('ConfirmationPage', () => {
  const mockFn = jest.fn();

  it('should render for loan type CLEAR without error when all required props are passed', () => {
    const component = withTheme(
      <Router>
        <ConfirmationPage
          onDoneClick={mockFn}
          loanType="CLEAR"
          loanTerm="1"
          directDebitUrl="https://www.westpac.com.au/content/dam/public/wbc/documents/pdf/pb/Direct_Debit_Request_Interest_Only_Loan_Repayment.pdf"
          messageInboxUrl="https://www.westpac.com.au/content/dam/public/wbc/documents/pdf/pb/PAP_ConditionsofUse.pdf"
          advantagePackage
          availableBalance="30000"
        />
      </Router>,
    );
    const tree = renderer.create(component).toJSON();
    expect(tree).toMatchSnapshot();
  });

  it('should render for loan type SPLIT without error when all required props are passed', () => {
    const component = withTheme(
      <Router>
        <ConfirmationPage
          onDoneClick={mockFn}
          loanType="SPLIT"
          loanTerm="1"
          contractedRepaymentDate="23 Jan 2044"
          directDebitUrl="https://www.westpac.com.au/content/dam/public/wbc/documents/pdf/pb/Direct_Debit_Request_Interest_Only_Loan_Repayment.pdf"
          messageInboxUrl="https://www.westpac.com.au/content/dam/public/wbc/documents/pdf/pb/PAP_ConditionsofUse.pdf"
          advantagePackage
          availableBalance="30000"
        />
      </Router>,
    );
    const tree = renderer.create(component).toJSON();
    expect(tree).toMatchSnapshot();
  });

  it('should render for loan type REDRAW without error when all required props are passed', () => {
    const component = withTheme(
      <Router>
        <ConfirmationPage
          onDoneClick={mockFn}
          loanType="REDRAW"
          loanTerm="1"
          directDebitUrl="https://www.westpac.com.au/content/dam/public/wbc/documents/pdf/pb/Direct_Debit_Request_Interest_Only_Loan_Repayment.pdf"
          messageInboxUrl="https://www.westpac.com.au/content/dam/public/wbc/documents/pdf/pb/PAP_ConditionsofUse.pdf"
          advantagePackage
          availableBalance="30000"
          bsbNumber="112-879"
          accountNumber="1111244"
          accountName="Test account"
        />
      </Router>,
    );

    const tree = renderer.create(component).toJSON();
    expect(tree).toMatchSnapshot();
  });

  it('should render for non package customer when all required props are passed', () => {
    const component = withTheme(
      <Router>
        <ConfirmationPage
          onDoneClick={mockFn}
          loanType=""
          loanTerm="1"
          directDebitUrl="https://www.westpac.com.au/content/dam/public/wbc/documents/pdf/pb/Direct_Debit_Request_Interest_Only_Loan_Repayment.pdf"
          messageInboxUrl="https://www.westpac.com.au/content/dam/public/wbc/documents/pdf/pb/PAP_ConditionsofUse.pdf"
          advantagePackage={false}
          availableBalance="30000"
        />
      </Router>,
    );
    const tree = renderer.create(component).toJSON();
    expect(tree).toMatchSnapshot();
  });

  it('should render for heading text as year if loan term is one year', () => {
    const component = withTheme(
      <Router>
        <ConfirmationPage
          onDoneClick={mockFn}
          loanType=""
          loanTerm="1"
          directDebitUrl="https://www.westpac.com.au/content/dam/public/wbc/documents/pdf/pb/Direct_Debit_Request_Interest_Only_Loan_Repayment.pdf"
          messageInboxUrl="https://www.westpac.com.au/content/dam/public/wbc/documents/pdf/pb/PAP_ConditionsofUse.pdf"
          advantagePackage={false}
          availableBalance="30000"
        />
      </Router>,
    );
    const tree = renderer.create(component).toJSON();
    expect(tree).toMatchSnapshot();
  });

  it('should render for heading text as years if loan term is more than a  year', () => {
    const component = withTheme(
      <Router>
        <ConfirmationPage
          onDoneClick={mockFn}
          loanType=""
          loanTerm="2"
          directDebitUrl="https://www.westpac.com.au/content/dam/public/wbc/documents/pdf/pb/Direct_Debit_Request_Interest_Only_Loan_Repayment.pdf"
          messageInboxUrl="https://www.westpac.com.au/content/dam/public/wbc/documents/pdf/pb/PAP_ConditionsofUse.pdf"
          advantagePackage={false}
          availableBalance="30000"
        />
      </Router>,
    );
    const tree = renderer.create(component).toJSON();
    expect(tree).toMatchSnapshot();
  });

  it('should render for if funds are not available/available balance null when all required props are passed', () => {
    const component = withTheme(
      <Router>
        <ConfirmationPage
          onDoneClick={mockFn}
          loanType=""
          loanTerm="1"
          directDebitUrl="https://www.westpac.com.au/content/dam/public/wbc/documents/pdf/pb/Direct_Debit_Request_Interest_Only_Loan_Repayment.pdf"
          messageInboxUrl="https://www.westpac.com.au/content/dam/public/wbc/documents/pdf/pb/PAP_ConditionsofUse.pdf"
          advantagePackage
          availableBalance=""
        />
      </Router>,
    );
    const tree = renderer.create(component).toJSON();
    expect(tree).toMatchSnapshot();
  });

  it('should render for heading text as years if loan term is more than a  year', () => {
    const component = withTheme(
      <Router>
        <ConfirmationPage
          onDoneClick={mockFn}
          loanType=""
          loanTerm="2"
          directDebitUrl="https://www.westpac.com.au/content/dam/public/wbc/documents/pdf/pb/Direct_Debit_Request_Interest_Only_Loan_Repayment.pdf"
          messageInboxUrl="https://www.westpac.com.au/content/dam/public/wbc/documents/pdf/pb/PAP_ConditionsofUse.pdf"
          advantagePackage={false}
          availableBalance="30000"
        />
      </Router>,
    );
    const tree = renderer.create(component).toJSON();
    expect(tree).toMatchSnapshot();
  });
  it('should render for styled bullet item for loan type RedrawFundsOption', () => {
    const component = withTheme(
      <Router>
        <ConfirmationPage
          onDoneClick={mockFn}
          loanTerm="1"
          directDebitUrl="https://www.westpac.com.au/content/dam/public/wbc/documents/pdf/pb/Direct_Debit_Request_Interest_Only_Loan_Repayment.pdf"
          messageInboxUrl="https://www.westpac.com.au/content/dam/public/wbc/documents/pdf/pb/PAP_ConditionsofUse.pdf"
          advantagePackage={false}
          availableBalance=""
          loanType="RedrawFundsOption"
        />
      </Router>,
    );
    const mockStore = configureMockStore();

    const store = mockStore(mockStoreData.valid[2]);

    const wrapper = shallow(component, { context: { store } })
      .dive()
      .dive()
      .dive()
      .dive()
      .dive();

    const redrawText = wrapper
      .find('Styled(Styled(ListItem))')
      .find({ renderItem: 'true' })
      .at(4)
      .children()
      .map(child => child.childAt(0).text());

    expect(redrawText[0]).toMatch(/transfer your available funds to/);

    const tree = renderer.create(component).toJSON();
    expect(tree).toMatchSnapshot();
  });

  it('should render for styled bullet item if loan type is not split  and funds not available', () => {
    const component = withTheme(
      <Router>
        <ConfirmationPage
          onDoneClick={mockFn}
          loanTerm="1"
          directDebitUrl="https://www.westpac.com.au/content/dam/public/wbc/documents/pdf/pb/Direct_Debit_Request_Interest_Only_Loan_Repayment.pdf"
          messageInboxUrl="https://www.westpac.com.au/content/dam/public/wbc/documents/pdf/pb/PAP_ConditionsofUse.pdf"
          advantagePackage={false}
          availableBalance=""
          loanType="RedrawLoan"
        />
      </Router>,
    );
    const mockStore = configureMockStore();

    const store = mockStore(mockStoreData.valid[2]);

    const wrapper = shallow(component, { context: { store } })
      .dive()
      .dive()
      .dive()
      .dive()
      .dive();

    expect(
      wrapper
        .find('Styled(Styled(ListItem))')
        .find({ renderItem: 'true' })
        .at(4)
        .text(),
    ).toMatch(
      /have an existing direct debit arrangement you can set one up using/,
    );
    const tree = renderer.create(component).toJSON();
    expect(tree).toMatchSnapshot();
  });
  it('should render for styled bullet item if loan type is Clear', () => {
    const component = withTheme(
      <Router>
        <ConfirmationPage
          onDoneClick={mockFn}
          loanTerm="1"
          directDebitUrl="https://www.westpac.com.au/content/dam/public/wbc/documents/pdf/pb/Direct_Debit_Request_Interest_Only_Loan_Repayment.pdf"
          messageInboxUrl="https://www.westpac.com.au/content/dam/public/wbc/documents/pdf/pb/PAP_ConditionsofUse.pdf"
          advantagePackage={false}
          availableBalance=""
          loanType="AccessFundsOption"
        />
      </Router>,
    );
    const mockStore = configureMockStore();

    const store = mockStore(mockStoreData.valid[2]);

    const wrapper = shallow(component, { context: { store } })
      .dive()
      .dive()
      .dive()
      .dive()
      .dive();

    expect(
      wrapper
        .find('Styled(Styled(ListItem))')
        .find({ renderItem: 'true' })
        .at(1)
        .text(),
    ).toMatch(/4 business days/);
    expect(
      wrapper
        .find('Styled(Styled(ListItem))')
        .find({ renderItem: 'true' })
        .at(3)
        .text(),
    ).toMatch(/A switching fee of/);

    const tree = renderer.create(component).toJSON();
    expect(tree).toMatchSnapshot();
  });

  it('should render for styled bullet item if loan type is not split and not package and funds not available', () => {
    const component = withTheme(
      <Router>
        <ConfirmationPage
          onDoneClick={mockFn}
          loanTerm="1"
          directDebitUrl="https://www.westpac.com.au/content/dam/public/wbc/documents/pdf/pb/Direct_Debit_Request_Interest_Only_Loan_Repayment.pdf"
          messageInboxUrl="https://www.westpac.com.au/content/dam/public/wbc/documents/pdf/pb/PAP_ConditionsofUse.pdf"
          advantagePackage={false}
          availableBalance=""
          loanType="RedrawLoan"
        />
      </Router>,
    );
    const mockStore = configureMockStore();

    const store = mockStore(mockStoreData.valid[2]);

    const wrapper = shallow(component, { context: { store } })
      .dive()
      .dive()
      .dive()
      .dive()
      .dive();

    expect(
      wrapper
        .find('Styled(Styled(ListItem))')
        .find({ renderItem: 'true' })
        .at(1)
        .text(),
    ).toMatch(/request will be processed/);
    const tree = renderer.create(component).toJSON();
    expect(tree).toMatchSnapshot();
  });
});
