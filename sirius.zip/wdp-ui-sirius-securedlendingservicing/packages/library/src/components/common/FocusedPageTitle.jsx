/* eslint-disable no-console */
import React, { Component } from 'react';
import PropTypes from 'prop-types';
import styled from 'styled-components';

import { withAccessibleFocusStyle } from '@wdpui/react-gel';
import { PageTitleText } from './styles';

export const StyledDiv = styled.div`
  outline: none;
`;

const AccessibleDiv = withAccessibleFocusStyle(StyledDiv);

class FocusedPageTitle extends Component {
  constructor(props) {
    super(props);

    this.accessibleRefTitle = React.createRef();
  }

  componentDidMount() {
    if (this.accessibleRefTitle.current) {
      this.accessibleRefTitle.current.focus();
    }
  }

  render() {
    const { title } = this.props;

    return (
      <AccessibleDiv ref={this.accessibleRefTitle} tabIndex="-1">
        <PageTitleText is="h3">{title}</PageTitleText>
      </AccessibleDiv>
    );
  }
}
FocusedPageTitle.propTypes = {
  title: PropTypes.string.isRequired,
};
export default FocusedPageTitle;
