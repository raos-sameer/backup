import React from 'react';
import PropTypes from 'prop-types';
import Media from 'react-media';
import entries from 'lodash/entries';
import { breakpointSizes } from '@wdpui/react-gel';

class MediaMatch extends React.Component {
  static propTypes = {
    /**
     * GEL Breakpoint with boolean flag.
     * If flag is set for a specific breakpoint, the child component will be displayed for that breakpoint.
     * Flag can be set true for multiple breakpoints.
     */
    query: PropTypes.shape({
      xs: PropTypes.bool,
      sm: PropTypes.bool,
      md: PropTypes.bool,
      lg: PropTypes.bool,
    }),
    /**
     *  Child nodes which needs to be rendered for specific breakpoints.
     */
    children: PropTypes.oneOfType([PropTypes.node, PropTypes.func]).isRequired,
  };

  static defaultProps = {
    query: { xs: false, sm: false, md: false, lg: false },
  };

  // eslint-disable-next-line react/sort-comp
  breakpoints = entries(breakpointSizes).reduce(
    (acc, [key, value]) => ({
      ...acc,
      [key]: parseInt(value, 10),
    }),
    {},
  );

  queryValues = {
    xs: { maxWidth: this.breakpoints.sm - 1 },
    sm: { minWidth: this.breakpoints.sm, maxWidth: this.breakpoints.md - 1 },
    md: { minWidth: this.breakpoints.md, maxWidth: this.breakpoints.lg - 1 },
    lg: { minWidth: this.breakpoints.lg },
  };

  getMediaValues = query => {
    const { queryValues } = this;

    const queries = entries(queryValues).reduce((acc, [key, value]) => {
      if (query[key]) {
        return [...acc, value];
      }

      return acc;
    }, []);

    return queries;
  };

  render() {
    const { children, query } = this.props;
    const mediaValues = this.getMediaValues(query);
    if (!children) {
      return null;
    }

    if (React.isValidElement(children)) {
      return <Media query={mediaValues}>{children}</Media>;
    }

    return <Media query={mediaValues}>{matches => children(matches)}</Media>;
  }
}

export default MediaMatch;
