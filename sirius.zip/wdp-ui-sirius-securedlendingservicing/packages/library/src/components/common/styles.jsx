/* eslint-disable no-console */
import styled from 'styled-components';
import { Grid, Row, GridContainer, Column } from '@wdpui/gel-grid';
import { Text } from '@wdpui/gel-typography';
import { IconTick } from '@wdpui/react-gel';
import { Button } from '@wdpui/gel-button';
import { Modal } from '@wdpui/gel-modal';
import { ListItem } from '@wdpui/gel-list';
import { IconClose, IconAdd } from '@wdpui/gel-symbols';
import { CircledIcon } from '@wdpui/gel-x-circledicon';

export const StyledGridContainer = styled(GridContainer)`
  height: 100%;
  width: 100%;
  max-width: 100%;
  padding-top: 66px;
  ${({ theme }) => theme.breakpointMax.xs`padding-top: 54px;`};
  ${({ theme }) =>
    theme.breakpoint.md`min-height: calc(100vh - 92px); height: auto;`};
`;

export const StyledGrid = styled(Grid)`
  width: 100%;
`;

export const StyledColumn = styled(Column)`
  padding-left: 0px;
  padding-right: 0px;
`;

export const StyledRow = styled(Row)`
  margin-left: 0px;
  margin-right: 0px;
  align-self: center;
`;

export const ContainerRow = styled(Row)`
  border-bottom: 1px ${({ theme }) => theme.color.border} solid;
  border-top: 1px ${({ theme }) => theme.color.primary} solid;
  align-items: center;
  background-color: #fff;
`;

export const HeaderText = styled(Text)`
  margin-top: 0px;
  margin-bottom: 0px;
  color: ${({ theme }) => theme.color.heading};
`;

export const WordBreakText = styled(Text)`
  margin: 0px;
  word-wrap: break-word;
  word-break: break-all;
`;
export const HR = styled.hr`
  color: ${({ theme }) => theme.color.border};
  background-color: ${({ theme }) => theme.color.border};
  width: 100%;
  border: 0;
  height: 1px;
`;
export const ActionButtonRow = styled(Row)`
  flex-direction: column-reverse;
  ${({ theme }) => theme.breakpoint.xs`flex-direction: row`};
`;

export const StyledModalContainer = styled(Modal)`
  top: 90px;
  ${({ theme }) =>
    (theme.breakpoint.sm ||
      theme.breakpoint.lg ||
      theme.breakpoint.md)` width: auto;
    margin-left: 0px;
    left: 25%;
    right: 25%;`};
`;
export const StyledPanelContainer = styled.div`
  width: 100%;
  padding-right: 15px;
  padding-left: 15px;
  margin-right: auto;
  margin-left: auto;
`;
export const StyledPanelRow = styled.div`
  display: flex;
  flex-wrap: wrap;
  margin-left: -15px;
  padding-bottom: 12px;
`;
export const StyledPanelCol = styled.div`
  flex-basis: 0;
  flex-grow: 1;
  max-width: 100%;
`;

export const StyledModalFooter = styled.div`
  text-align: center;
  padding-bottom: 24px;
`;
export const TickIcon = styled(IconTick)`
  color: ${({ theme }) => theme.color.success};
`;

export const ModalButton = styled(Button)`
  color: ${({ theme }) => theme.color.text};
  width: 100%;
`;
export const SoftButton = styled(Button)`
  border: 1px ${({ theme }) => theme.color.border} solid;
`;
export const StyledCircledIcon = styled(CircledIcon)`
  width: 66px;
  height: 66px;
  border: 1px ${({ theme }) => theme.color.border} solid;
  svg {
    fill: ${({ theme }) => theme.color.success};
  }
`;

export const CenterStyledColumn = styled(StyledColumn)`
  text-align: center;
  align-items: center;
`;

export const HeadingColouredText = styled(Text)`
  margin-top: 0px;
  margin-bottom: 6px;
  font-weight: 400;
  color: ${({ theme }) => theme.color.heading};
`;

export const PageTitleText = styled(HeadingColouredText)`
  margin-top: 0px;

  ${({ theme }) =>
    theme && theme.breakpointMax.xs`font-size:24px; margin-bottom: 24px;`};

  ${({ theme }) =>
    theme && theme.breakpoint.xs`font-size:30px; margin-bottom: 33px;`};
`;
export const MutedText = styled(Text)`
  color: ${({ theme }) => theme.color.muted};
`;
export const NeutralText = styled(Text)`
  color: ${({ theme }) => theme.color.neutral};
`;
export const PanelWhiteWithBorder = styled(Row)`
  border-bottom: 1px ${({ theme }) => theme.color.border} solid;
  border-top: 1px ${({ theme }) => theme.color.primary} solid;
  background-color: #fff;
  margin-left: 0px;
  margin-right: 0px;

  @media (min-width: 480px) and (max-width: 768px) {
    padding-left: 36px;
    padding-right: 36px;
    padding-top: 30px;
  }
  ${({ theme }) =>
    theme &&
    theme.breakpointMax
      .xs`padding-left:0px;padding-right:0px;padding-top:30px;`};

  ${({ theme }) =>
    theme &&
    theme.breakpoint
      .sm`padding-left:85px;padding-right:85px;padding-top:42px;`};
`;

export const LightBackGroundContainer = styled(Row)`
  border-top: 2px ${({ theme }) => theme.color.primary} solid;
  background-color: ${({ theme }) => theme.color.light};
  margin-left: 0px;
  margin-right: 0px;
  margin-bottom: 18px;
  margin-top: 18px;
  padding-right: 24px;
  padding-bottom: 24px;
  padding-left: 24px;
  padding-top: 24px;
`;
export const NewListItemShowHide = styled(Row)`
  ${props =>
    props.renderItem &&
    props.renderItem === 'false' &&
    `
    display:none;
  `};
  margin-top: 12px;
`;

export const ListItemShowHide = styled(ListItem)`
  ${props =>
    props.renderItem &&
    props.renderItem === 'false' &&
    `
    display:none;
  `};
`;

export const StyledGridPnl = styled(Grid)`
  width: 100%;

  ${({ theme }) => theme && theme.breakpointMax.sm`padding-top:30px;`};

  ${({ theme }) => theme && theme.breakpoint.sm`padding-top:62px;`};
`;

export const StyledRowPnl = styled(Row)`
  margin-left: 0px;
  margin-right: 0px;
  ${({ theme }) => theme.breakpointMax.xs`padding-top:0px;`};

  ${({ theme }) =>
    (theme.breakpoint.sm ||
      theme.breakpoint.lg ||
      theme.breakpoint.md)`padding-top: 0px;`};
`;
export const StyledColumnPnl = styled(Column)`
  ${({ theme }) =>
    theme.breakpoint &&
    theme.breakpointMax.xs`padding-left:0px;padding-right:0px;`};

  ${({ theme }) =>
    (theme.breakpoint.sm ||
      theme.breakpoint.lg ||
      theme.breakpoint.md)`padding-left:12px;padding-right:12px;`};
`;
export const StyledAnchorNoUnderline = styled.a`
  text-decoration: none !important;
`;

export const PaddedBox = styled(Row)`
  padding-left: 12px;
  padding-right: 12px;
`;

export const StyledSup = styled.sup`
  color: #636a71;
`;

export const CloseIcon = styled(IconClose)`
  color: ${({ theme }) => theme.color.hero};
`;
export const LinkButton = styled(Button)`
  text-align: left;
  border: none;
  margin-bottom: 24px;
  padding-left: 0px;
  font-size: 14px;
  text-decoration: underline;
`;

export const StyledIconAdd = styled(IconAdd)`
  margin-bottom: 12px;
  margin-top: -9px;
  align-self: center;
`;

export const RightStyledColumn = styled(StyledColumn)`
  margin-left: auto;
`;

export const StyledBulletItem = styled(ListItemShowHide)`
  margin-top: 12px;
  margin-bottom: 12px;
  padding-left: 24px;
  @media (min-width: 768px) and (max-width: 1200px) {
    margin-bottom: 18px;
  }
`;

export const StyledIconTick = styled(IconTick)`
  svg {
    fill: #ffff;
  }
`;
export const BorderBottom = styled(Row)`
  border-bottom: 1px ${({ theme }) => theme.color.border} solid;
  margin-top: 24px;
  margin-bottom: 30px;
  @media (max-width: 480px) {
    margin-top: 18px;
  }
`;
export const StyledDiv = styled.div`
  outline: none;
`;
