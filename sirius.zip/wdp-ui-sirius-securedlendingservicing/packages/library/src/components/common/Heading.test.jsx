import React from 'react';
import renderer from 'react-test-renderer';
import { shallow } from 'enzyme';
import Heading from './Heading';
import { withTheme } from '../../../../../utils/jest/TestUtils';

describe('Heading', () => {
  it('should throw error if no props are passed', () => {
    const spy = jest.spyOn(global.console, 'error');
    shallow(<Heading />);
    expect(spy).toHaveBeenCalledTimes(1);
    spy.mockClear();
  });

  it('should render if props are passed', () => {
    const spy = jest.spyOn(global.console, 'error');
    const component = withTheme(
      <Heading>
        <div className="test" />
      </Heading>,
    );
    const tree = renderer.create(component).toJSON();
    expect(tree).toMatchSnapshot();
    expect(spy).not.toHaveBeenCalled();
    const wrapper = shallow(component).dive();
    expect(wrapper.find('.test')).toHaveLength(1);
  });
});
