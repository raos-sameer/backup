import React from 'react';
import renderer from 'react-test-renderer';
import { shallow } from 'enzyme';
import FocusedPageTitle from './FocusedPageTitle';
import { withTheme } from '../../../../../utils/jest/TestUtils';

describe('FocusedPageTitle', () => {
  it('renders correctly when only required props are passed', () => {
    const component = withTheme(<FocusedPageTitle title="Test title" />);
    const tree = renderer.create(component).toJSON();
    expect(tree).toMatchSnapshot();
  });

  it('should call componentDidMount', () => {
    const component = withTheme(<FocusedPageTitle title="Test title" />);
    const shl = shallow(component);
    const wrapper = shl
      .dive()
      .dive()
      .dive();
    wrapper.accessibleRef = null;
    wrapper.instance().componentDidMount();
    expect(wrapper.find('ForwardRef').exists()).toBe(true);
  });
});
