import React from 'react';
import styled from 'styled-components';
import { Flex, Box } from '@rebass/grid';
import { ScreenReaderOnly } from '@wdpui/gel-screenreader';

import { Loader } from '@wdpui/gel-loader';

const Wrapper = styled(Flex)`
  height: 100vh;
  flex-direction: column;
  justify-content: center;
  align-items: center;
`;

const Loading = () => (
  <Wrapper>
    <Box aria-busy="true" aria-atomic="true" aria-live="polite">
      <Loader size="xlarge" />
      <ScreenReaderOnly
        role="alert"
        aria-busy="true"
        aria-atomic="true"
        aria-live="polite"
        className="a11y-context"
      >
        Please wait.Page is loading
      </ScreenReaderOnly>
    </Box>
  </Wrapper>
);

export default Loading;
