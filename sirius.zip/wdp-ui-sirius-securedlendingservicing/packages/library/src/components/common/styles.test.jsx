import React from 'react';
import renderer from 'react-test-renderer';
import { Themes } from '@wdpui/react-gel';
import { List } from '@wdpui/gel-list';
import { mount } from 'enzyme';
import * as Styles from './styles';
import { withTheme } from '../../../../../utils/jest/TestUtils';

describe('styles', () => {
  it('should render StyledGridContainer', () => {
    const component = withTheme(<Styles.StyledGridContainer />);
    const tree = renderer.create(component).toJSON();
    expect(tree).toMatchSnapshot();
  });

  it('should render StyledModalContainer', () => {
    const component = withTheme(<Styles.StyledModalContainer />);
    const tree = renderer.create(component).toJSON();
    expect(tree).toMatchSnapshot();
  });

  it('should render StyledPanelContainer', () => {
    const component = withTheme(<Styles.StyledPanelContainer />);
    const tree = renderer.create(component).toJSON();
    expect(tree).toMatchSnapshot();
  });
  it('should render StyledPanelRow', () => {
    const component = withTheme(<Styles.StyledPanelRow />);
    const tree = renderer.create(component).toJSON();
    expect(tree).toMatchSnapshot();
  });
  it('should render StyledPanelCol', () => {
    const component = withTheme(<Styles.StyledPanelCol />);
    const tree = renderer.create(component).toJSON();
    expect(tree).toMatchSnapshot();
  });

  it('should render StyledModalFooter', () => {
    const component = withTheme(<Styles.StyledModalFooter />);
    const tree = renderer.create(component).toJSON();
    expect(tree).toMatchSnapshot();
  });

  it('should render TickIcon', () => {
    const component = withTheme(<Styles.TickIcon />);
    const tree = renderer.create(component).toJSON();
    expect(tree).toMatchSnapshot();
  });

  it('should render StyledGrid', () => {
    const component = withTheme(<Styles.StyledGrid />);
    const tree = renderer.create(component).toJSON();
    expect(tree).toMatchSnapshot();
  });

  it('should render StyledColumn', () => {
    const component = withTheme(<Styles.StyledColumn />);
    const tree = renderer.create(component).toJSON();
    expect(tree).toMatchSnapshot();
  });

  it('should render StyledRow', () => {
    const component = withTheme(<Styles.StyledRow />);
    const tree = renderer.create(component).toJSON();
    expect(tree).toMatchSnapshot();
  });

  it('should render ContainerRow', () => {
    const component = withTheme(<Styles.ContainerRow />, Themes.ThemeSTG);
    const tree = renderer.create(component).toJSON();
    expect(tree).toMatchSnapshot();
  });

  it('should render ContainerRow with WBC Theme', () => {
    const component = withTheme(<Styles.ContainerRow />, Themes.ThemeWBC);
    const tree = renderer.create(component).toJSON();
    expect(tree).toMatchSnapshot();
  });

  it('should render WordBreakText', () => {
    const component = withTheme(<Styles.WordBreakText />);
    const tree = renderer.create(component).toJSON();
    expect(tree).toMatchSnapshot();
  });

  it('should render HeaderText', () => {
    const component = withTheme(<Styles.HeaderText />);
    const tree = renderer.create(component).toJSON();
    expect(tree).toMatchSnapshot();
  });

  it('should render WordBreakText', () => {
    const component = withTheme(<Styles.WordBreakText />);
    const tree = renderer.create(component).toJSON();
    expect(tree).toMatchSnapshot();
  });

  it('should render HR', () => {
    const component = withTheme(<Styles.HR />);
    const tree = renderer.create(component).toJSON();
    expect(tree).toMatchSnapshot();
  });

  it('should render MutedText', () => {
    const component = withTheme(<Styles.MutedText />);
    const tree = renderer.create(component).toJSON();
    expect(tree).toMatchSnapshot();
  });

  it('should render NeutralText', () => {
    const component = withTheme(<Styles.NeutralText />);
    const tree = renderer.create(component).toJSON();
    expect(tree).toMatchSnapshot();
  });

  it('should render PanelWhiteWithBorder', () => {
    const component = withTheme(<Styles.PanelWhiteWithBorder />);
    const tree = renderer.create(component).toJSON();
    expect(tree).toMatchSnapshot();
  });

  it('should render LightBackGroundContainer', () => {
    const component = withTheme(<Styles.LightBackGroundContainer />);
    const tree = renderer.create(component).toJSON();
    expect(tree).toMatchSnapshot();
  });

  it('should render StyledGridPnl', () => {
    const component = withTheme(
      <Styles.StyledGridPnl
        theme={{
          breakpoint: {
            sm: f => f,
          },
          breakpointMax: {
            sm: f => f,
          },
        }}
      />,
    );
    const tree = renderer.create(component).toJSON();
    expect(tree).toMatchSnapshot();
  });

  it('should render StyledRowPnl', () => {
    const component = withTheme(
      <Styles.StyledRowPnl
        theme={{
          breakpoint: {
            sm: f => f,
            md: f => f,
            lg: f => f,
          },
          breakpointMax: {
            xs: f => f,
          },
        }}
      />,
    );
    const tree = renderer.create(component).toJSON();
    expect(tree).toMatchSnapshot();
  });

  it('should render StyledColumnPnl', () => {
    const component = (
      <Styles.StyledColumnPnl
        theme={{
          breakpoint: {
            sm: f => f,
            md: f => f,
            lg: f => f,
          },
          breakpointMax: {
            xs: f => f,
          },
        }}
      />
    );
    const tree = renderer.create(component).toJSON();
    expect(tree).toMatchSnapshot();
  });

  it('should check for StyledColumnPnl padding value rendered', () => {
    const wrapper = mount(
      withTheme(
        <Styles.StyledColumnPnl
          pl={0}
          pr={0}
          theme={{
            breakpoint: {
              sm: f => f,
              md: f => f,
              lg: f => f,
            },
            breakpointMax: {
              xs: f => f,
            },
          }}
        />,
      ),
    );
    expect(
      getComputedStyle(wrapper.find('Column').getDOMNode()).getPropertyValue(
        'padding-left',
      ),
    ).toBe('0px');
    expect(
      getComputedStyle(wrapper.find('Column').getDOMNode()).getPropertyValue(
        'padding-right',
      ),
    ).toBe('0px');
  });

  it('should render StyledAnchorNoUnderline', () => {
    const component = withTheme(<Styles.StyledAnchorNoUnderline />);
    const tree = renderer.create(component).toJSON();
    expect(tree).toMatchSnapshot();
  });

  it('should render PaddedBox', () => {
    const component = withTheme(<Styles.PaddedBox />);
    const tree = renderer.create(component).toJSON();
    expect(tree).toMatchSnapshot();
  });

  it('should render CloseIcon', () => {
    const component = withTheme(<Styles.CloseIcon />);
    const tree = renderer.create(component).toJSON();
    expect(tree).toMatchSnapshot();
  });

  it('should render ListItemShowHide', () => {
    const component = withTheme(
      <List>
        <Styles.ListItemShowHide renderItem />
      </List>,
    );
    const tree = renderer.create(component).toJSON();
    expect(tree).toMatchSnapshot();
  });

  it('should render ActionButtonRow', () => {
    const component = withTheme(
      <Styles.ActionButtonRow
        theme={{
          breakpoint: {
            xs: f => f,
          },
        }}
      />,
    );
    const tree = renderer.create(component).toJSON();
    expect(tree).toMatchSnapshot();
  });
  it('should render ContainerRow', () => {
    const component = withTheme(<Styles.ContainerRow />);
    const tree = renderer.create(component).toJSON();
    expect(tree).toMatchSnapshot();
  });
  it('should render ModalButton', () => {
    const component = withTheme(<Styles.ModalButton />);
    const tree = renderer.create(component).toJSON();
    expect(tree).toMatchSnapshot();
  });

  it('should render SoftButton', () => {
    const component = withTheme(<Styles.SoftButton />);
    const tree = renderer.create(component).toJSON();
    expect(tree).toMatchSnapshot();
  });

  it('should render CenterStyledColumn', () => {
    const component = withTheme(<Styles.CenterStyledColumn />);
    const tree = renderer.create(component).toJSON();
    expect(tree).toMatchSnapshot();
  });

  it('should check for PageTitleText right color value rendered', () => {
    const wrapper = mount(withTheme(<Styles.PageTitleText color="#621a4b" />));
    expect(wrapper.getDOMNode('Text').attributes.color.value).toEqual(
      '#621a4b',
    );
  });

  it('should check for HeadingColouredText right color value rendered', () => {
    const wrapper = mount(
      withTheme(<Styles.HeadingColouredText color="#621a4b" />),
    );

    expect(wrapper.getDOMNode('Text').attributes.color.value).toEqual(
      '#621a4b',
    );
  });

  it('should render LinkButton', () => {
    const component = withTheme(<Styles.LinkButton />);
    const tree = renderer.create(component).toJSON();
    expect(tree).toMatchSnapshot();
  });

  it('should render StyledIconAdd', () => {
    const component = withTheme(<Styles.StyledIconAdd />);
    const tree = renderer.create(component).toJSON();
    expect(tree).toMatchSnapshot();
  });

  it('should check for CloseIcon right color value rendered', () => {
    const wrapper = mount(withTheme(<Styles.CloseIcon color="#621a4b" />));
    expect(wrapper.getDOMNode('Icon').attributes.color.value).toEqual(
      '#621a4b',
    );
  });
});
