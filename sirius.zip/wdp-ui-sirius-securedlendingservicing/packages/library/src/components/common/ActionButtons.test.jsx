import React from 'react';
import renderer from 'react-test-renderer';
import { shallow } from 'enzyme';
import ActionButtons from './ActionButtons';
import { withTheme } from '../../../../../utils/jest/TestUtils';

describe('ActionButtons', () => {
  it('should throw prop-type errors when data is missing', () => {
    const spy = jest.spyOn(global.console, 'error');
    shallow(<ActionButtons />);
    expect(spy).toHaveBeenCalledTimes(0);
  });

  it('renders correctly when only required props are passed', () => {
    const component = withTheme(
      <ActionButtons leftButtonLabel="Previous" rightButtonLabel="Next" />,
    );
    const tree = renderer.create(component).toJSON();
    expect(tree).toMatchSnapshot();
  });

  it('should fire the click event for buttons button', () => {
    const mockFn = jest.fn();
    const component = withTheme(
      <ActionButtons
        leftButtonLabel="Previous"
        rightButtonLabel="Next"
        leftButtonClick={mockFn}
        rightButtonClick={mockFn}
      />,
    );
    const shl = shallow(component);
    const wrapper = shl
      .dive()
      .dive()
      .dive();
    wrapper.find("[label='Previous']").simulate('click');
    wrapper.find("[label='Next']").simulate('click');
    expect(mockFn).toHaveBeenCalledTimes(2);
  });

  it('should should show only right button ', () => {
    const mockFn = jest.fn();
    const component = withTheme(
      <ActionButtons
        isLeftButtonShow={false}
        isRightButtonShow
        rightButtonLabel="Next"
        leftButtonLabel="Previous"
        rightButtonClick={mockFn}
      />,
    );
    const wrapper = shallow(component)
      .dive()
      .dive()
      .dive();
    expect(wrapper.find("[label='Next']")).toHaveLength(1);
    expect(wrapper.find("[label='Previous']")).toHaveLength(0);
  });
  it('should fire the click event for right  button if we pass info for right button ', () => {
    const mockFn = jest.fn();
    const component = withTheme(
      <ActionButtons
        isLeftButtonShow={false}
        isRightButtonShow
        rightButtonLabel="Next"
        rightButtonClick={mockFn}
      />,
    );
    const wrapper = shallow(component)
      .dive()
      .dive()
      .dive();
    wrapper.find("[label='Next']").simulate('click');
    expect(mockFn).toHaveBeenCalledTimes(1);
  });
  it('should  show only Left button ', () => {
    const mockFn = jest.fn();
    const component = withTheme(
      <ActionButtons
        isLeftButtonShow
        isRightButtonShow={false}
        rightButtonLabel="Next"
        leftButtonLabel="Previous"
        rightButtonClick={mockFn}
      />,
    );
    const wrapper = shallow(component)
      .dive()
      .dive()
      .dive();
    expect(wrapper.find("[label='Previous']")).toHaveLength(1);
    expect(wrapper.find("[label='Next']")).toHaveLength(0);
  });
  it('should fire the click event for right  button if we pass info for left button ', () => {
    const mockFn = jest.fn();
    const component = withTheme(
      <ActionButtons
        isLeftButtonShow
        isRightButtonShow={false}
        leftButtonLabel="Previous"
        leftButtonClick={mockFn}
      />,
    );
    const wrapper = shallow(component)
      .dive()
      .dive()
      .dive();
    wrapper.find("[label='Previous']").simulate('click');
    expect(mockFn).toHaveBeenCalledTimes(1);
  });
});
