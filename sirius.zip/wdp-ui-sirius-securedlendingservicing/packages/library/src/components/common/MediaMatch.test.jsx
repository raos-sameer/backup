import React from 'react';
import { mount } from 'enzyme';

import MediaMatch from './MediaMatch';

const mockWindowMatch = matches => () => ({
  matches,
  addListener: () => {},
  removeListener: () => {},
});

describe('Media Match Component', () => {
  let wrapper;
  beforeEach(() => {
    window.matchMedia = mockWindowMatch(true);
    wrapper = mount(
      <MediaMatch query={{ md: true, lg: true }}>
        <div>testcomponent</div>
      </MediaMatch>,
    );
  });

  it('match media has passed correct props', () => {
    expect(wrapper.props().query).toEqual({ md: true, lg: true });
  });

  it('match media renders test component', () => {
    expect(wrapper.containsMatchingElement(<div>testcomponent</div>)).toBe(
      true,
    );
  });

  it('match media test getMediaValues', () => {
    expect(wrapper.instance().getMediaValues({ md: true, lg: true })).toEqual([
      { minWidth: 992, maxWidth: 1199 },
      { minWidth: 1200 },
    ]);
  });

  describe('with a query that does not match', () => {
    let funcWrapper;
    beforeEach(() => {
      window.matchMedia = mockWindowMatch(false);
      funcWrapper = mount(
        <MediaMatch query={{ md: true }}>
          {matches => (matches ? <p>matches</p> : <p>not matches.</p>)}
        </MediaMatch>,
      );
    });

    it('match media test function wrapper', () => {
      expect(funcWrapper.children().props().query).toEqual([
        { minWidth: 992, maxWidth: 1199 },
      ]);
    });
    it('match media does not match', () => {
      expect(funcWrapper.containsMatchingElement(<p>not matches.</p>)).toBe(
        true,
      );
    });
  });
});
