import React from 'react';
import renderer from 'react-test-renderer';
import Loader from './Loader';
import { withTheme } from '../../../../../utils/jest/TestUtils';

describe('styles', () => {
  const spy = jest.spyOn(global.console, 'error');

  it('should render StyledGridContainer', () => {
    const component = withTheme(<Loader />);
    const tree = renderer.create(component).toJSON();
    expect(tree).toMatchSnapshot();
    expect(spy).not.toHaveBeenCalled();
  });
});
