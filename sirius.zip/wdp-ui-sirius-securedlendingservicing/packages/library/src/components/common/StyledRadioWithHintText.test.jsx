import React from 'react';
import { shallow } from 'enzyme';
import { Row, Column } from '@wdpui/gel-grid';

import { Radio } from '@wdpui/gel-radio';
import { MutedText } from './styles';

import StyledRadioWithHintText from './StyledRadioWithHintText';

describe('StyledRadioWithHintText', () => {
  it('renders the StyledRadioWithHintText structure', () => {
    const component = (
      <StyledRadioWithHintText
        onChangeFn={jest.fn()}
        isChecked
        radioValue="1"
        radioLabel="Test label"
        radioId="testid"
        hintText="test hint to show"
      />
    );
    const wrapper = shallow(component);
    expect(wrapper.find(Radio).exists()).toBe(true);
    expect(wrapper.find(MutedText).exists()).toBe(true);
    expect(wrapper.find(Row).exists()).toBe(true);
    expect(wrapper.find(Column).exists()).toBe(true);
  });
});
