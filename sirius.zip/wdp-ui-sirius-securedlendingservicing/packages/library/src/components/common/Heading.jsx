import React from 'react';
import PropTypes from 'prop-types';

import { StyledColumn, HeadingColouredText } from './styles';

const Heading = ({ children }) => (
  <StyledColumn width={[10 / 12, 9 / 12]} mx="auto" my={[3]}>
    <HeadingColouredText size={3} weight="medium" textAlign="center">
      {children}
    </HeadingColouredText>
  </StyledColumn>
);

Heading.propTypes = {
  children: PropTypes.node.isRequired,
};

export default Heading;
