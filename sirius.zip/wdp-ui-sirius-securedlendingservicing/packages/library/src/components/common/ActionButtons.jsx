import React from 'react';
import PropTypes from 'prop-types';
import { Button } from '@wdpui/gel-button';
import {
  StyledColumn,
  ActionButtonRow,
  SoftButton,
  RightStyledColumn,
} from './styles';

const ActionButtons = props => {
  const {
    leftButtonLabel,
    leftButtonClick,
    rightButtonLabel,
    rightButtonClick,
    isRightButtonShow,
    isLeftButtonShow,
  } = props;
  return (
    <ActionButtonRow my={5}>
      {isLeftButtonShow && (
        <StyledColumn width={[1, 5 / 12, 3 / 12]}>
          <SoftButton
            block
            soft
            size="large"
            styling="hero"
            label={leftButtonLabel}
            onClick={leftButtonClick}
          />
        </StyledColumn>
      )}
      {isRightButtonShow && (
        <RightStyledColumn width={[1, 5 / 12, 3 / 12]} mb={[2, 0]}>
          <Button
            block
            size="large"
            styling="primary"
            label={rightButtonLabel}
            onClick={rightButtonClick}
          />
        </RightStyledColumn>
      )}
    </ActionButtonRow>
  );
};

ActionButtons.defaultProps = {
  rightButtonClick: null,
  leftButtonClick: null,
  isLeftButtonShow: true,
  isRightButtonShow: true,
  rightButtonLabel: 'Done',
  leftButtonLabel: 'Cancel',
};

ActionButtons.propTypes = {
  leftButtonLabel: PropTypes.string,
  leftButtonClick: PropTypes.func,
  rightButtonLabel: PropTypes.string,
  rightButtonClick: PropTypes.func,
  isLeftButtonShow: PropTypes.bool,
  isRightButtonShow: PropTypes.bool,
};

export default ActionButtons;
