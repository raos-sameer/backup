import React from 'react';
import PropTypes from 'prop-types';
import { Row, Column } from '@wdpui/gel-grid';
import { Radio } from '@wdpui/gel-radio';
import { MutedText } from './styles';

const StyledRadioWithHintText = props => {
  const {
    onChangeFn,
    isChecked,
    radioValue,
    radioLabel,
    radioId,
    hintText,
  } = props;
  return (
    <Row direction="column">
      <Column mb={[-24]}>
        <Radio
          block
          id={radioId}
          name={radioId}
          value={radioValue}
          label={radioLabel}
          checked={isChecked}
          onChange={onChangeFn}
        />
      </Column>
      <Column id="mutedcol" ml={24} pl={[12, 12, 18, 18]}>
        <MutedText>{hintText}</MutedText>
      </Column>
    </Row>
  );
};

StyledRadioWithHintText.propTypes = {
  onChangeFn: PropTypes.func.isRequired,
  isChecked: PropTypes.bool.isRequired,
  radioValue: PropTypes.string.isRequired,
  radioLabel: PropTypes.string.isRequired,
  radioId: PropTypes.string.isRequired,
  hintText: PropTypes.string,
};
StyledRadioWithHintText.defaultProps = {
  hintText: '',
};
export default StyledRadioWithHintText;
