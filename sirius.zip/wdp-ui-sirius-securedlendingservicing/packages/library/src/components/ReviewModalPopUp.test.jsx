import React from 'react';

import { shallow } from 'enzyme';

import { Panel } from '@wdpui/gel-panel';
import { ModalBody } from '@wdpui/gel-modal';
import { StyledModalContainer, StyledModalFooter } from './common/styles';

import { ReviewModalPopUp } from './ReviewModalPopUp';

describe('ReviewModalPopUp', () => {
  it('renders the ReviewModalPopUp structure', () => {
    const component = <ReviewModalPopUp />;
    const wrapper = shallow(component);
    expect(wrapper.find(StyledModalContainer).exists()).toBe(true);
    expect(wrapper.find(ModalBody).exists()).toBe(true);
    expect(wrapper.find(StyledModalFooter).exists()).toBe(true);
    expect(wrapper.find(Panel).exists()).toBe(true);

    expect(wrapper).toMatchSnapshot();
  });
});
