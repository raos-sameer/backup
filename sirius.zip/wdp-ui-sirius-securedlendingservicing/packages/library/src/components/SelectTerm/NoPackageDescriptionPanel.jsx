import React from 'react';
import styled from 'styled-components';
import { Button } from '@wdpui/gel-button';
import { List } from '@wdpui/gel-list';
import PropTypes from 'prop-types';
import { formatAmount } from '../../helpers/amountFormatter';

import {
  HeadingColouredText,
  MutedText,
  LightBackGroundContainer,
  ListItemShowHide,
} from '../common/styles';

import { MediaMatch } from '../common';

export const CallUsButton = styled(Button)`
  margin-bottom: 18px;
  font-weight: bold;
`;

export const NoPackageDescriptionPanel = ({
  switchFee,
  monthlyMaintainence,
  packageFee,
  discountRate,
}) => (
  <LightBackGroundContainer direction="column">
    <HeadingColouredText weight="medium" size={2}>
      Receive a {discountRate}% p.a. discount with a Premier Advantage Package*
    </HeadingColouredText>

    <MutedText size={1}>
      For an annual package fee of ${packageFee} you can package your home loan
      and a Westpac Choice account to benefit from
    </MutedText>
    <List bullet="circle" styling="neutral">
      <ListItemShowHide>
        <MutedText size={1}>
          Waived {formatAmount(switchFee)} switching fee
        </MutedText>
      </ListItemShowHide>
      <ListItemShowHide>
        <MutedText size={1}>
          Waived {formatAmount(monthlyMaintainence)} monthly loan maintenance
          fee
        </MutedText>
      </ListItemShowHide>
      <ListItemShowHide>
        <MutedText size={1}>
          {discountRate}% p.a. discount on fixed rates
        </MutedText>
      </ListItemShowHide>
      <ListItemShowHide>
        <MutedText size={1}>
          1.29% p.a. discount on variable rate Rocket loans
        </MutedText>
      </ListItemShowHide>
      <ListItemShowHide>
        <MutedText size={1}>Other benefits on a range of products</MutedText>
      </ListItemShowHide>
    </List>

    <MediaMatch query={{ lg: true, md: true, sm: true, xs: false }}>
      <MutedText size={1}>
        Call us on <a href="tel:131900">131 900</a> and our home finance
        managers can help you get a package.
      </MutedText>
    </MediaMatch>
    <MediaMatch query={{ lg: false, md: false, sm: false, xs: true }}>
      <>
        <MutedText size={1}>
          Call us and our home finance managers can help you get a package.
        </MutedText>
        <CallUsButton
          href="tel:13 33 30"
          block
          soft
          size="large"
          styling="hero"
          label="Call us"
        />
      </>
    </MediaMatch>
  </LightBackGroundContainer>
);
NoPackageDescriptionPanel.propTypes = {
  switchFee: PropTypes.string.isRequired,
  monthlyMaintainence: PropTypes.string.isRequired,
  packageFee: PropTypes.string.isRequired,
  discountRate: PropTypes.string.isRequired,
};

export default NoPackageDescriptionPanel;
