import React from 'react';
import PropTypes from 'prop-types';
import { Column, Row } from '@wdpui/gel-grid';
import { List } from '@wdpui/gel-list';
import { Accordion, AccordionItem } from '@wdpui/gel-accordion';
import { StyledSup, StyledBulletItem } from '../common/styles';

export const ThingsYouKnow = ({
  advantagePackage,
  conditionsOfUseUrl,
  packageFee,
}) => (
  <Row direction="column" mb={34}>
    <Column>
      <Accordion>
        <AccordionItem label="Things you should know">
          <List role="list" styling="neutral">
            <StyledBulletItem
              role="listitem"
              renderItem={!advantagePackage ? 'true' : 'false'}
            >
              <StyledSup>*</StyledSup>
              <a
                href={conditionsOfUseUrl}
                target="_blank"
                rel="noopener noreferrer"
              >
                Conditions of Use
              </a>
              &nbsp;and a ${packageFee} annual package fee applies. You must
              either hold or be approved for a Westpac Choice account in order
              to qualify and continue to receive the benefits of the Premier
              Advantage Package. Before deciding to acquire a Westpac Choice
              account, read the terms and conditions, and consider whether the
              product is right for you.
            </StyledBulletItem>

            <StyledBulletItem role="listitem">
              Rates quoted are based on today`s rates and on your repayment type
              and loan purpose. Your new fixed interest rate is the rate that
              applies on the day you submit your request
            </StyledBulletItem>
            <StyledBulletItem role="listitem">
              At the end of the fixed rate period, your loan will automatically
              change to the applicable Rocket Loan product and the interest rate
              will convert to the applicable variable loan Interest rate, unless
              a new fixed term is selected
            </StyledBulletItem>
            <StyledBulletItem role="listitem">
              An Interest only loan means that your repayments only go towards
              repaying interest (and any applicable fees) rather than repaying
              any principal from your loans. This means that during the period
              for which you make &apos;Interest only&apos; repayments, the
              balance of your loan will stay the same
            </StyledBulletItem>
          </List>
        </AccordionItem>
      </Accordion>
    </Column>
  </Row>
);
ThingsYouKnow.propTypes = {
  advantagePackage: PropTypes.bool.isRequired,
  conditionsOfUseUrl: PropTypes.string.isRequired,
  packageFee: PropTypes.string.isRequired,
};
export default ThingsYouKnow;
