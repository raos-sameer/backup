/* eslint-disable no-console */
import { shallow } from 'enzyme';
import React from 'react';
import { ButtonGroup } from '@wdpui/gel-buttongroup';
import { AlertBox } from '@wdpui/gel-alertbox';

import renderer from 'react-test-renderer';
import { withTheme } from '../../../../../utils/jest/TestUtils';
import { ActionButtons, Loader, FocusedPageTitle } from '../common';
import {
  InterestRatePackageSelect,
  InterestRateTilePanel,
  InterestRateTileOption,
  NormalLeftPadded,
} from './InterestRatePackageSelect';
import ConnectedReviewModalPopUp from '../ReviewModalPopUp';
import { NoPackageDescriptionPanel } from './NoPackageDescriptionPanel';

import {
  HeadingColouredText,
  PanelWhiteWithBorder,
  MutedText,
  StyledGridPnl,
  StyledRowPnl,
  StyledColumnPnl,
  LinkButton,
} from '../common/styles';

const mockFn = jest.fn();
global.matchMedia = matches => () => ({
  matches,
  addListener: () => {},
  removeListener: () => {},
});
const props = {
  availableBalance: '650000',
  currentBalance: '450000',
  variableInterestRate: '3.20',
  loanMaturityDate: '23 Jan 2032',
  interestOnlyMatDate: '23 Feb 2043',
  monthlyRepayment: '2490',
  advantagePackage: true,
  isPrincipalInterestCustomer: false,
  isExpiryDateLessThanYear: false,
  alertBoxMessage: 'Test message',
  isCurrentLoanDetailsFetching: false,
  closeButtonClick: jest.fn(),
  showReviewDetailsPopup: jest.fn(),
  hideReviewDetailsPopup: jest.fn(),
  showHidePopUp: false,
  selectedYearTerm: '',
  selectedInterestRateForTerm: '',
  setRepaymentType: jest.fn(),
  handleInterestRateSiloChange: jest.fn(),
  conditionsOfUseUrl: 'http://www.westpac.com.au',
  navigateNext: jest.fn(),
  backToChannel: jest.fn(),
  repaymentType: 'IO',
  mortgageQuotes: [
    {
      yearTerm: '1',
      discountRate: '0.20',
      interestRate: '4.5',
      isDiscountApplicable: false,
      isDiscretionaryDiscount: true,
      switchedProductName: 'Fixed Rate Investment Property Loan 1',
      id: 1,
    },
    {
      yearTerm: '2',
      interestRate: '4.2',
      discountRate: '0.30',
      discountApplicable: true,
      isDiscretionaryDiscount: true,
      switchedProductName: 'Fixed Rate Investment Property Loan 1',
      id: 2,
    },
    {
      yearTerm: '3',
      interestRate: '4.2',
      discountRate: '0.30',
      discountApplicable: true,
      isDiscretionaryDiscount: false,
      switchedProductName: 'Fixed Rate Investment Property Loan 1',
      id: 3,
    },
  ],
  discountedSilos: [
    {
      yearTerm: '1',
      discountRate: '0.20',
      interestRate: '4.5',
      isDiscountApplicable: false,
      isDiscretionaryDiscount: true,
      switchedProductName: 'Fixed Rate Investment Property Loan 1',
      id: 1,
    },
  ],
};
describe('InterestRatePackageSelect', () => {
  global.matchMedia = matches => () => ({
    matches,
    addListener: () => {},
    removeListener: () => {},
  });

  it('renders the InterestRatePackageSelect structure', () => {
    const component = <InterestRatePackageSelect {...props} />;
    const wrapper = shallow(component);
    expect(wrapper.find(LinkButton).exists()).toBe(true);
    expect(wrapper.find(ButtonGroup).exists()).toBe(true);
    expect(wrapper.find(FocusedPageTitle).exists());
    expect(wrapper.find(PanelWhiteWithBorder).exists());
    expect(wrapper.find(HeadingColouredText).exists());
    expect(wrapper.find(MutedText).exists());
    expect(wrapper.find(StyledGridPnl).exists());
    expect(wrapper.find(StyledRowPnl).exists());
    expect(wrapper.find(StyledColumnPnl).exists());

    expect(wrapper.find(ActionButtons).exists());
    expect(wrapper).toMatchSnapshot();
  });

  it('should render InterestRatePackageSelect component without error', () => {
    const component = withTheme(<InterestRatePackageSelect {...props} />);
    const tree = renderer.create(component).toJSON();
    expect(tree).toMatchSnapshot();
  });

  it('should call showReviewDetailsPopup when clicked on toggled or show review button link clicked', () => {
    const component = (
      <InterestRatePackageSelect
        showReviewDetailsPopup={mockFn}
        showHidePopUp
      />
    );
    const wrapper = shallow(component);
    expect(wrapper.find(ConnectedReviewModalPopUp).exists()).toBe(true);
    expect(wrapper).toMatchSnapshot();
  });
  it('should call onchange event for setting repayment type', () => {
    const component = (
      <InterestRatePackageSelect
        setRepaymentType={mockFn}
        repaymentType="IO"
        isPrincipalInterestCustomer={false}
      />
    );
    const wrapper = shallow(component);
    expect(wrapper.find(ButtonGroup).exists()).toBe(true);
    expect(wrapper).toMatchSnapshot();
  });
  it('should call onchange event for setting interest rate silo', () => {
    const otherprops = {
      handleInterestRateSiloChange: jest.fn(),
      selectedYearTerm: '2',
      selectedInterestRateForTerm: '3.95',
      selectedRepaymentType: 'IO',
      repaymentType: 'IO',
      mortgageQuotes: [
        {
          yearTerm: '1',
          discountRate: '0.20',
          interestRate: '4.5',
          isDiscountApplicable: false,
          isDiscretionaryDiscount: true,
          switchedProductName: 'Fixed Rate Investment Property Loan 1',
          id: 1,
        },
        {
          yearTerm: '2',
          interestRate: '4.2',
          discountRate: '0.30',
          discountApplicable: true,
          isDiscretionaryDiscount: true,
          switchedProductName: 'Fixed Rate Investment Property Loan 1',
          id: 2,
        },
        {
          yearTerm: '3',
          interestRate: '4.2',
          discountRate: '0.30',
          discountApplicable: true,
          isDiscretionaryDiscount: false,
          switchedProductName: 'Fixed Rate Investment Property Loan 1',
          id: 3,
        },
      ],
    };

    const component = <InterestRatePackageSelect {...otherprops} />;
    const wrapper = shallow(component);
    expect(wrapper.find(InterestRateTilePanel).exists()).toBe(true);
    expect(wrapper).toMatchSnapshot();
  });

  it('renders the option button to select repayment type if current repayment type is not principal and interest', () => {
    const discprops = {
      isExpiryDateLessThanYear: false,
      isPrincipalInterestCustomer: false,
      repaymentType: 'IO',
    };
    const component = withTheme(<InterestRatePackageSelect {...discprops} />);
    const wrapper = shallow(component)
      .dive()
      .dive()
      .dive()
      .dive();
    expect(wrapper.find(ButtonGroup).exists()).toBe(true);
    expect(wrapper).toMatchSnapshot();
  });

  it('renders the interest rate tile to select if expiry date is less than year and interest rates are loaded', () => {
    const discprops = {
      isExpiryDateLessThanYear: false,
      isPrincipalInterestCustomer: false,
      advantagePackage: true,
      selectedRepaymentType: 'IO',
      repaymentType: 'IO',
      mortgageQuotes: [
        {
          yearTerm: '1',
          discountRate: '0.20',
          interestRate: '4.5',
          isDiscountApplicable: false,
          isDiscretionaryDiscount: true,
          id: 1,
        },
        {
          yearTerm: '2',
          interestRate: '4.2',
          discountRate: '0.30',
          discountApplicable: true,
          isDiscretionaryDiscount: true,
          id: 2,
        },
        {
          yearTerm: '3',
          interestRate: '4.2',
          discountRate: '0.30',
          discountApplicable: true,
          isDiscretionaryDiscount: false,
          id: 3,
        },
      ],
    };
    const component = withTheme(<InterestRatePackageSelect {...discprops} />);
    const wrapper = shallow(component)
      .dive()
      .dive()
      .dive()
      .dive();
    expect(wrapper.find(InterestRateTilePanel).exists()).toBe(true);
    expect(wrapper.find(InterestRateTileOption).exists()).toBe(true);
    expect(wrapper).toMatchSnapshot();
  });

  it('should fire on change for repayment type selection option', () => {
    const component = (
      <InterestRatePackageSelect
        setRepaymentType={mockFn}
        repaymentType="IO"
        isPrincipalInterestCustomer={false}
      />
    );
    const wrapper = shallow(component);
    const evt = {
      preventDefault: () => {},
      target: {
        name: 'options',
      },
    };
    wrapper.find(ButtonGroup).simulate('change', evt);
  });

  it('should fire on change for interest rate tile selection option', () => {
    const mockOnChange = jest.fn(() => null);

    const mockprops = {
      selectedYearTerm: '1',
      selectedInterestRateForTerm: '3.97',
      repaymentType: 'IO',
      selectedRepaymentType: 'IO',
      handleInterestRateSiloChange: mockOnChange,
      mortgageQuotes: [
        {
          yearTerm: '1',
          discountRate: '0.20',
          interestRate: '4.5',
          isDiscountApplicable: true,
          isDiscretionaryDiscount: true,
          switchedProductName: 'Fixed Rate Investment Property Loan 1',

          id: 1,
        },
        {
          yearTerm: '2',
          interestRate: '4.2',
          discountRate: '0.30',
          discountApplicable: true,
          isDiscretionaryDiscount: true,
          switchedProductName: 'Fixed Rate Investment Property Loan 1',

          id: 2,
        },
        {
          yearTerm: '3',
          interestRate: '4.2',
          discountRate: '0.30',
          discountApplicable: true,
          isDiscretionaryDiscount: false,
          switchedProductName: 'Fixed Rate Investment Property Loan 1',

          id: 3,
        },
      ],
    };
    const component = withTheme(<InterestRatePackageSelect {...mockprops} />);

    const wrapper = shallow(component)
      .dive()
      .dive()
      .dive()
      .dive()
      .dive()
      .dive()
      .dive();

    const evt = {
      preventDefault: () => {},
      target: {
        name: 'options',
      },
    };
    wrapper.find("[name='1radioTile']").simulate('change', evt);
  });

  it('renders the Discount Text Component if discretionary is selected', () => {
    const discprops = {
      isExpiryDateLessThanYear: false,
      isPrincipalInterestCustomer: false,
      advantagePackage: false,
    };
    const component = withTheme(<InterestRatePackageSelect {...discprops} />);
    const wrapper = shallow(component)
      .dive()
      .dive()
      .dive()
      .dive()
      .dive()
      .dive()
      .dive();
    expect(wrapper.find(NoPackageDescriptionPanel).exists()).toBe(true);
    expect(wrapper).toMatchSnapshot();
  });

  it('renders the Loader Component if show loader is true', () => {
    const discprops = {
      isExpiryDateLessThanYear: false,
      isPrincipalInterestCustomer: false,
      advantagePackage: false,
      isMortgageQuotesFetching: true,
    };
    const component = withTheme(<InterestRatePackageSelect {...discprops} />);
    const wrapper = shallow(component)
      .dive()
      .dive()
      .dive()
      .dive()
      .dive()
      .dive()
      .dive();
    expect(wrapper.find(Loader).exists()).toBe(true);
    expect(wrapper).toMatchSnapshot();
  });

  it('renders the NormalLeftPadded for discount text', () => {
    const discprops = {
      isExpiryDateLessThanYear: false,
      repaymentType: 'IO',
      selectedRepaymentType: 'IO',
      isPrincipalInterestCustomer: false,
      advantagePackage: false,
      mortgageQuotes: [
        {
          yearTerm: '1',
          discountRate: '0.20',
          interestRate: '4.5',
          isDiscountApplicable: false,
          isDiscretionaryDiscount: true,
          switchedProductName: 'Fixed Rate Investment Property Loan 1',
          id: 1,
        },
        {
          yearTerm: '2',
          interestRate: '4.2',
          discountRate: '0.32',
          isDiscountApplicable: true,
          isDiscretionaryDiscount: false,
          switchedProductName: 'Fixed Rate Investment Property Loan 1',

          id: 2,
        },
      ],
    };
    const component = withTheme(<InterestRatePackageSelect {...discprops} />);
    const wrapper = shallow(component)
      .dive()
      .dive()
      .dive()
      .dive()
      .dive()
      .dive()
      .dive();

    expect(wrapper.find(NormalLeftPadded).exists()).toBe(true);
    expect(
      wrapper
        .find(NormalLeftPadded)
        .at(1)
        .text(),
    ).toMatch(/Includes 0.32% p.a. discount/);

    expect(wrapper).toMatchSnapshot();
  });

  it('renders the No package if its not package customer and if expiry date not less than year and discounted silos exists', () => {
    const discprops = {
      isExpiryDateLessThanYear: false,
      repaymentType: 'IO',
      isPrincipalInterestCustomer: false,
      advantagePackage: false,
      discountedSilos: [
        {
          yearTerm: '1',
          discountRate: '0.20',
          interestRate: '4.5',
          isDiscountApplicable: false,
          isDiscretionaryDiscount: true,
          id: 1,
        },
        {
          yearTerm: '2',
          interestRate: '4.2',
          discountRate: '0.30',
          isDiscountApplicable: true,
          isDiscretionaryDiscount: false,
          id: 2,
        },
      ],
    };
    const component = withTheme(<InterestRatePackageSelect {...discprops} />);
    const wrapper = shallow(component)
      .dive()
      .dive()
      .dive()
      .dive()
      .dive()
      .dive()
      .dive();
    expect(wrapper.find(MutedText).exists()).toBe(true);
    expect(
      wrapper
        .find(MutedText)
        .at(0)
        .text(),
    ).toMatch(/Each rate includes any discounts available to you/);

    expect(wrapper).toMatchSnapshot();
  });

  it('renders the alert message if mortgage quotes api fail', () => {
    const discprops = {
      isMortgageQuotesError: true,
    };
    const component = withTheme(<InterestRatePackageSelect {...discprops} />);
    const wrapper = shallow(component)
      .dive()
      .dive()
      .dive()
      .dive()
      .dive()
      .dive()
      .dive();
    expect(wrapper.find(AlertBox).exists()).toBe(true);
    expect(wrapper).toMatchSnapshot();
  });
});
