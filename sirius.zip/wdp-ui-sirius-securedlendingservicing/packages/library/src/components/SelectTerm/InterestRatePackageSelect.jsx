import React from 'react';
import { Text } from '@wdpui/gel-typography';
import { Column, Grid } from '@wdpui/gel-grid';
import { Button } from '@wdpui/gel-button';
import { ButtonGroup } from '@wdpui/gel-buttongroup';
import { AlertBox } from '@wdpui/gel-alertbox';
import styled from 'styled-components';
import { Radio } from '@wdpui/gel-radio';
import { ScreenReaderOnly } from '@wdpui/gel-screenreader';
import PropTypes from 'prop-types';
import { ActionButtons, Loader, FocusedPageTitle } from '../common';
import ConnectedReviewModalPopUp from '../ReviewModalPopUp';

import { ThingsYouKnow } from './ThingsYouKnow';
import { NoPackageDescriptionPanel } from './NoPackageDescriptionPanel';

import {
  PanelWhiteWithBorder,
  HeadingColouredText,
  MutedText,
  StyledGridPnl,
  StyledRowPnl,
  StyledColumnPnl,
  PaddedBox,
  LinkButton,
} from '../common/styles';
import {
  showNoPackagePanel,
  showAdvantagePackageDiscountText,
  showNoPackageDiscountText,
  isPrincipalCustomer,
  getRepaymentHintText,
  showNextButton,
  getInterestTileLabelText,
  getInterestTileDiscountText,
} from '../../helpers/selectTermHelper';

import { formatToTwoDecimalPlaces } from '../../helpers/amountFormatter';

export const NormalLeftPadded = styled(Text)`
  padding-left: 30px;
  margin-top: -12px;
  display: flex;
`;

export const StyledDivSpacing = styled.div`
  margin-top: 24px;
`;
export const StyledRedText = styled(Text)`
  color: ${({ theme }) => theme.color.primary};
  padding-left: 30px;
  margin-top: -12px;
  display: flex;
`;

export const CurrentInterestRateText = styled(MutedText)`
  margin-bottom: -4px;
`;

export const InterestRateTilePanel = styled(Grid)`
  border-radius: 4px;
  border: 1px ${({ theme }) => theme.color.border} solid;
  justify-content: center;
  flex-direction: column;
  align-items: flex-start;
  padding-left: 12px;
  padding-right: 12px;
  padding-top: 15px;
  margin-bottom: 18px;
  width: 100%;
  max-width: 100%;
`;

export const InterestRateTileOption = styled(Radio)`
  margin-bottom: -12px !important;
`;

export const InterestRatePackageSelect = ({
  mortgageQuotes,
  discountedSilos,
  showReviewDetailsPopup,
  hideReviewDetailsPopup,
  setRepaymentType,
  selectedYearTerm,
  handleInterestRateSiloChange,
  backToChannel,
  navigateNext,
  showHidePopUp,
  availableBalance,
  currentBalance,
  variableInterestRate,
  loanMaturityDate,
  repaymentType,
  selectedRepaymentType,
  interestOnlyMatDate,
  monthlyRepayment,
  advantagePackage,
  isExpiryDateLessThanYear,
  alertBoxMessage,
  conditionsOfUseUrl,
  isPrincipalInterestCustomer,
  isMortgageQuotesFetching,
  isMortgageQuotesError,
  switchFee,
  monthlyMaintainence,
  productName,
  redrawIndicatorSet,
  discountRate,
  packageFee,
}) => (
  <StyledGridPnl id="gridPnlYearTerm" aria-labelledby="screen-title">
    <StyledRowPnl>
      <FocusedPageTitle title="Fixed rate options for you" />
    </StyledRowPnl>
    <PanelWhiteWithBorder
      direction="column"
      id="whiteborderpnls"
      aria-hidden={showHidePopUp ? 'true' : 'false'}
    >
      <Column px={2} pb={4} id="colwhite">
        <HeadingColouredText weight="medium" size={2}>
          Compare rates and terms
        </HeadingColouredText>
        <ScreenReaderOnly>
          Your current variable rate is {variableInterestRate} percent per annum
          with {getRepaymentHintText(isPrincipalInterestCustomer)}
        </ScreenReaderOnly>
        <CurrentInterestRateText size={1} weight="regular" aria-hidden="true">
          Your current variable rate is&nbsp;
          <b>{formatToTwoDecimalPlaces(variableInterestRate)}% p.a. </b>
          with
          <b>{getRepaymentHintText(isPrincipalInterestCustomer)}</b>
        </CurrentInterestRateText>
        <LinkButton
          p={0}
          styling="link"
          role="link"
          onClick={showReviewDetailsPopup}
          aria-label="Click on the link to see current loan details"
          label=" See all current loan details"
        />
        {!isPrincipalCustomer(isPrincipalInterestCustomer) && (
          <ButtonGroup
            id="btn-repaymentoptions"
            block
            value={selectedRepaymentType}
            onChange={setRepaymentType}
            size="large"
            styling="hero"
          >
            <Button
              styling="hero"
              role="button"
              aria-label="Interest Only"
              label="Interest Only"
              value="IO"
            />
            <Button
              styling="hero"
              role="button"
              aria-label="Principal and interest"
              label="Principal and interest"
              value="PIF"
            />
          </ButtonGroup>
        )}

        {isMortgageQuotesFetching && <Loader />}

        {alertBoxMessage && (
          <StyledDivSpacing>
            <AlertBox styling="info" hasIcon mt={24} aria-live="assertive">
              {alertBoxMessage}
            </AlertBox>
          </StyledDivSpacing>
        )}
        {isMortgageQuotesError && (
          <AlertBox
            styling="danger"
            alertIcon
            mt={24}
            role="alert"
            aria-live="assertive"
          >
            We’re currently unable to load your rates. Please try again later.
          </AlertBox>
        )}

        {selectedRepaymentType &&
          !isExpiryDateLessThanYear &&
          mortgageQuotes &&
          mortgageQuotes.map(silo => (
            <InterestRateTilePanel key={silo.yearTerm} responsive>
              <InterestRateTileOption
                id={`${silo.yearTerm}radioTile`}
                name={`${silo.yearTerm}radioTile`}
                block
                checked={selectedYearTerm === silo.yearTerm}
                onChange={() =>
                  handleInterestRateSiloChange(silo.yearTerm, silo.interestRate)
                }
                label={getInterestTileLabelText(
                  silo.yearTerm,
                  silo.interestRate,
                )}
                value={silo.yearTerm}
              />
              <NormalLeftPadded>
                {silo.isDiscountApplicable && !silo.isDiscretionaryDiscount
                  ? getInterestTileDiscountText(silo.discountRate)
                  : ``}
              </NormalLeftPadded>
              <StyledRedText>
                {silo.isDiscountApplicable && silo.isDiscretionaryDiscount
                  ? getInterestTileDiscountText(silo.discountRate)
                  : ``}
              </StyledRedText>
            </InterestRateTilePanel>
          ))}
        {showAdvantagePackageDiscountText(
          advantagePackage,
          isExpiryDateLessThanYear,
          discountedSilos,
        ) && (
          <MutedText size={1}>
            Each rate includes your
            <b> Premier Advantage Package discount </b>
            and any
            <b> additional discounts</b>
          </MutedText>
        )}
        {showNoPackageDiscountText(
          advantagePackage,
          isExpiryDateLessThanYear,
          discountedSilos,
        ) && (
          <MutedText size={1}>
            Each rate includes any discounts available to you
          </MutedText>
        )}

        {showNoPackagePanel(advantagePackage, isExpiryDateLessThanYear) && (
          <NoPackageDescriptionPanel
            monthlyMaintainence={monthlyMaintainence}
            switchFee={switchFee}
            packageFee={packageFee}
            discountRate={discountRate}
          />
        )}
      </Column>
    </PanelWhiteWithBorder>
    {showHidePopUp && (
      <ConnectedReviewModalPopUp
        showPopUp={showHidePopUp}
        modalTitle="Current loan details"
        currentBalance={currentBalance}
        availableBalance={availableBalance}
        varInterestRate={formatToTwoDecimalPlaces(variableInterestRate)}
        loanMaturityDate={loanMaturityDate}
        repaymentType={repaymentType}
        interestOnlyMatDate={interestOnlyMatDate}
        monthlyRepayment={monthlyRepayment}
        advantagePackage={advantagePackage}
        closeButtonText="Close"
        closeButtonClick={hideReviewDetailsPopup}
        panelTitle={productName}
        redrawIndicatorSet={redrawIndicatorSet}
      />
    )}
    <PaddedBox
      direction="column"
      aria-hidden={showHidePopUp ? 'true' : 'false'}
    >
      <StyledColumnPnl>
        <ActionButtons
          leftButtonLabel="Cancel"
          leftButtonClick={backToChannel}
          rightButtonLabel="Next"
          rightButtonClick={navigateNext}
          leftButtonShow
          isRightButtonShow={
            !!showNextButton(
              selectedRepaymentType,
              isExpiryDateLessThanYear,
              selectedYearTerm,
            )
          }
        />
      </StyledColumnPnl>
    </PaddedBox>
    <ThingsYouKnow
      aria-hidden={showHidePopUp ? 'true' : 'false'}
      advantagePackage={advantagePackage}
      conditionsOfUseUrl={conditionsOfUseUrl}
      packageFee={packageFee}
    />
  </StyledGridPnl>
);

InterestRatePackageSelect.propTypes = {
  mortgageQuotes: PropTypes.arrayOf(PropTypes.shape({})),
  discountedSilos: PropTypes.arrayOf(PropTypes.shape({})),
  showReviewDetailsPopup: PropTypes.func.isRequired,
  hideReviewDetailsPopup: PropTypes.func.isRequired,
  setRepaymentType: PropTypes.func.isRequired,
  handleInterestRateSiloChange: PropTypes.func.isRequired,
  selectedYearTerm: PropTypes.string.isRequired,
  navigateNext: PropTypes.func.isRequired,
  backToChannel: PropTypes.func.isRequired,
  showHidePopUp: PropTypes.bool.isRequired,
  availableBalance: PropTypes.string.isRequired,
  currentBalance: PropTypes.string.isRequired,
  variableInterestRate: PropTypes.string.isRequired,
  loanMaturityDate: PropTypes.string.isRequired,
  repaymentType: PropTypes.string.isRequired,
  selectedRepaymentType: PropTypes.string.isRequired,
  interestOnlyMatDate: PropTypes.string.isRequired,
  monthlyRepayment: PropTypes.string.isRequired,
  advantagePackage: PropTypes.bool.isRequired,
  isExpiryDateLessThanYear: PropTypes.bool.isRequired,
  isMortgageQuotesFetching: PropTypes.bool.isRequired,
  isMortgageQuotesError: PropTypes.bool.isRequired,
  alertBoxMessage: PropTypes.string.isRequired,
  conditionsOfUseUrl: PropTypes.string.isRequired,
  isPrincipalInterestCustomer: PropTypes.bool.isRequired,
  switchFee: PropTypes.string.isRequired,
  monthlyMaintainence: PropTypes.string.isRequired,
  productName: PropTypes.string.isRequired,
  redrawIndicatorSet: PropTypes.bool.isRequired,
  discountRate: PropTypes.string.isRequired,
  packageFee: PropTypes.string.isRequired,
};
InterestRatePackageSelect.defaultProps = {
  discountedSilos: [],
  mortgageQuotes: [],
};
export default InterestRatePackageSelect;
