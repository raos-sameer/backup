import React from 'react';
import { Text } from '@wdpui/gel-typography';
import { List } from '@wdpui/gel-list';
import { Button } from '@wdpui/gel-button';
import { Column } from '@wdpui/gel-grid';
import PropTypes from 'prop-types';

import { ScreenReaderOnly } from '@wdpui/gel-screenreader';

import styled from 'styled-components';
import { FocusedPageTitle } from './common';

import {
  PanelWhiteWithBorder,
  StyledGridPnl,
  StyledRowPnl,
  StyledCircledIcon,
  ActionButtonRow,
  CenterStyledColumn,
  RightStyledColumn,
  StyledBulletItem,
  StyledIconTick,
  HeadingColouredText,
} from './common/styles';
import {
  isSplitLoan,
  showSplitLoanTextForPackageCustomer,
  showHeaderTextForConfirmationPage,
  isClearLoan,
  isRedrawLoan,
  getSwitchingFeeText,
} from '../helpers/loanOptionsHelper';
import { formatDateTime } from '../helpers/dateFormatter';

const CenterHeaderText = styled(HeadingColouredText)`
  text-align: center;
  margin-top: 18px;
  margin-bottom: 18px;
  font-weight: bold;

  @media (min-width: 768px) and (max-width: 1200px) {
    width: 424px;
  }
`;

const ConfirmationPage = ({
  onDoneClick,
  loanType,
  loanTerm,
  contractedRepaymentDate,
  directDebitUrl,

  selectedAccountLabel,
  switchFee,
  advantagePackage,
}) => {
  return (
    <StyledGridPnl id="gridPnlReview">
      <StyledRowPnl>
        <ScreenReaderOnly role="alert" aria-live="assertive">
          Request submitted successfully
        </ScreenReaderOnly>
        <FocusedPageTitle title=" Request submitted" />
      </StyledRowPnl>
      <PanelWhiteWithBorder direction="column" id="whiteborderpnl">
        <Column px={2} pb={4} id="colwhite">
          <CenterStyledColumn width={[1]}>
            <StyledCircledIcon
              styling="hero"
              color="#008000"
              aria-hidden="true"
            >
              <StyledIconTick size="large" color="#fff" />
            </StyledCircledIcon>
          </CenterStyledColumn>
          <CenterHeaderText size={3}>
            {showHeaderTextForConfirmationPage(loanType, loanTerm)}
          </CenterHeaderText>
          <List role="list" styling="neutral">
            <StyledBulletItem role="listitem" renderItem="true">
              Confirmation will be sent to your message inbox.
            </StyledBulletItem>
            <StyledBulletItem
              role="listitem"
              renderItem={!isSplitLoan(loanType) ? 'true' : 'false'}
            >
              Your request will be processed within the next&nbsp;
              <b>4 business days.</b>
            </StyledBulletItem>

            <StyledBulletItem
              role="listitem"
              renderItem={showSplitLoanTextForPackageCustomer(loanType)}
            >
              <Text>
                We&apos;ll process these changes on your next contracted
                date&nbsp;
                <b>{formatDateTime(contractedRepaymentDate, 'DD-MM-YYYY')}.</b>
              </Text>
              <Text>
                If this in the next 3 business days, we&apos;ll process your
                request the following month
              </Text>
            </StyledBulletItem>
            <StyledBulletItem renderItem="true" role="listitem">
              If there are changes to your loan amount before we process your
              request, this will be reflected in your new loan details
            </StyledBulletItem>
            <StyledBulletItem renderItem={!advantagePackage ? 'true' : 'false'}>
              {getSwitchingFeeText(switchFee)}
            </StyledBulletItem>
            <StyledBulletItem
              role="listitem"
              renderItem={showSplitLoanTextForPackageCustomer(loanType)}
            >
              You can set up a direct debit on your new fixed rate loan using
              the&nbsp;
              <a
                href={directDebitUrl}
                target="_blank"
                rel="noreferrer noopener"
              >
                Direct Debit Request form
              </a>
              .&nbsp;Please submit the form only once your request is processed.
            </StyledBulletItem>
            <StyledBulletItem
              role="listitem"
              renderItem={isClearLoan(loanType) ? 'true' : 'false'}
            >
              We&apos;ll clear your available funds when we process your
              request.
            </StyledBulletItem>
            <StyledBulletItem
              role="listitem"
              renderItem={isRedrawLoan(loanType) ? 'true' : 'false'}
            >
              <Text>
                We&apos;ll transfer your available funds to&nbsp;
                <b>{selectedAccountLabel}</b>
                &nbsp;when we process your request.
              </Text>
              <Text>
                The amount transferred will be your available funds amount when
                we process your request.
              </Text>
            </StyledBulletItem>
            <StyledBulletItem
              role="listitem"
              renderItem={!isSplitLoan(loanType) ? 'true' : 'false'}
            >
              If you don&apos;t have an existing direct debit arrangement you
              can set one up using the&nbsp;
              <a
                href={directDebitUrl}
                target="_blank"
                rel="noreferrer noopener"
              >
                Direct Debit Request form
              </a>
              .&nbsp;Please submit the form only once your request is processed.
            </StyledBulletItem>
            <StyledBulletItem role="listitem" renderItem="true">
              Once your request is processed we&apos;ll send a letter to all
              borrowers to confirm the new loan details.
            </StyledBulletItem>
          </List>
        </Column>
      </PanelWhiteWithBorder>
      <ActionButtonRow my={3} direction="column" px={2}>
        <RightStyledColumn
          width={[1, 4 / 12, 4 / 12, 2 / 12]}
          mb={[2, 0]}
          px={[0, 0, 12, 12]}
        >
          <>
            <Button
              block
              size="large"
              styling="primary"
              label="Done"
              onClick={onDoneClick}
            />
          </>
        </RightStyledColumn>
      </ActionButtonRow>
    </StyledGridPnl>
  );
};

ConfirmationPage.propTypes = {
  onDoneClick: PropTypes.func.isRequired,
  loanType: PropTypes.string.isRequired,
  contractedRepaymentDate: PropTypes.string,
  directDebitUrl: PropTypes.string.isRequired,

  selectedAccountLabel: PropTypes.string,
  switchFee: PropTypes.string,
  advantagePackage: PropTypes.bool.isRequired,
  loanTerm: PropTypes.string.isRequired,
};

ConfirmationPage.defaultProps = {
  contractedRepaymentDate: '',
  selectedAccountLabel: '',
  switchFee: '',
};

export default ConfirmationPage;
