import React from 'react';
import renderer from 'react-test-renderer';
import { shallow } from 'enzyme';
import { withTheme } from '../../../../utils/jest/TestUtils';
import Error from './Error';

describe('Error', () => {
  const mockCallBack = jest.fn();

  it('should render without error', () => {
    const component = withTheme(
      <Error
        onDoneClick={mockCallBack}
        heading="Digital switching"
        btnLabel="Return to dashboard"
      >
        Test
      </Error>,
    );
    const tree = renderer.create(component).toJSON();
    expect(tree).toMatchSnapshot();
  });
  it('should render different content when error code passed is caseexists', () => {
    const component = withTheme(
      <Error
        onDoneClick={mockCallBack}
        heading="Digital switching"
        btnLabel="Return to dashboard"
        errorCode="caseexists"
      />,
    );
    const tree = renderer.create(component).toJSON();
    expect(tree).toMatchSnapshot();
  });
  it('should render different content when error code passed is eligibilityfail', () => {
    const component = withTheme(
      <Error
        onDoneClick={mockCallBack}
        heading="Digital switching"
        btnLabel="Return to dashboard"
        errorCode="eligibilityfail"
      />,
    );
    const tree = renderer.create(component).toJSON();
    expect(tree).toMatchSnapshot();
  });
  it('should call passed method when clicking of button', () => {
    const component = withTheme(
      <Error
        onDoneClick={mockCallBack}
        heading="Digital Switching"
        btnLabel="Return to dashboard"
      >
        Test
      </Error>,
    );
    const wrapper = shallow(component)
      .dive()
      .dive()
      .dive();
    wrapper
      .find("[label='Return to dashboard']")
      .first()
      .simulate('click');
    expect(mockCallBack).toHaveBeenCalledTimes(1);
  });
});
