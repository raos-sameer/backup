import React from 'react';
import configureMockStore from 'redux-mock-store';
import renderer from 'react-test-renderer';
import { Provider } from 'react-redux';
import { BrowserRouter as Router } from 'react-router-dom';
import { mockStoreData } from './__fixtures__/mockRouteStore.fixture';
import { withTheme } from '../../../utils/jest/TestUtils';
import history from '../../../utils/jest/history';
import { ComposedRoutes } from './routes';

const mockStore = configureMockStore();

describe('Routes', () => {
  let store;
  const spy = jest.spyOn(global.console, 'error');

  afterEach(() => {
    if (spy && spy.mockReset && spy.mockRestore) {
      spy.mockReset();
      spy.mockRestore();
    }
  });

  it('should render without error when required props are passed', () => {
    store = mockStore(mockStoreData.valid[0]);
    const component = withTheme(
      <Provider store={store}>
        <Router>
          <ComposedRoutes history={history} />
        </Router>
      </Provider>,
    );
    const tree = renderer.create(component).toJSON();
    expect(tree).toMatchSnapshot();
  });
});
