/* eslint-disable no-console */
const chalk = require('chalk');
const fse = require('fs-extra');
const ora = require('ora');
const path = require('path');

const MICRO_APP = 'securedlendingservicing';

// #region Library dependency module path derivations

// Assumption is that this path is always .../node_modules/@wdpui-{scope}/micro-app
const currentWorkingDirectory = process.cwd();

// Library environment folder to bootstrap into the App
const libEnvDir = path.join(currentWorkingDirectory, './env');

// Based on the above assumption, this would be the project's root
const projectRoot = path.join(currentWorkingDirectory, '..', '..');

// App's root environment folder where the library environment config needs to be bootstrapped
const appEnvDir = path.join(projectRoot, './env');

// #endregion

const cp = async (source, destination) => {
  try {
    await fse.copy(source, destination, { overwrite: true });
  } catch (error) {
    const message = `${chalk.red(
      `Error occurred while copying ${source} -> ${destination}`,
    )}\n${error.message}`;
    throw new Error(message);
  }
};

const cpConfig = async (target, source) => {
  try {
    const promisedEnvironments = fse.readdir(source);
    ora.promise(
      promisedEnvironments,
      chalk.yellowBright(`Parsing environments for available configurations`),
    );
    const subDirs = await promisedEnvironments;

    await Promise.all(
      subDirs.map(async dir => {
        try {
          const targetEnvironment = path.join(target, dir, MICRO_APP);
          const promisedTargetEnvironment = fse.ensureDir(targetEnvironment);
          ora.promise(
            promisedTargetEnvironment,
            chalk.yellowBright(
              `Ensuring the target ${dir.toUpperCase()} environment exists: ${targetEnvironment}\n`,
            ),
          );
          await promisedTargetEnvironment;

          const sourceEnvironment = path.join(source, dir);
          const promisedCopy = cp(sourceEnvironment, targetEnvironment);
          ora.promise(
            promisedCopy,
            chalk.yellowBright(
              `Copying ${sourceEnvironment} -> ${targetEnvironment}`,
            ),
          );
          await promisedCopy;
        } catch (error) {
          const message = `${chalk.red(
            `Error occurred while setting up the target environment`,
          )}\n${error.message}`;
          throw new Error(message);
        }
      }),
    );

    console.log(``);
  } catch (error) {
    const message = `${chalk.red(
      `Error occurred while bootstrapping Micro-app configurations`,
    )}\n${error.message}`;
    throw new Error(message);
  }
};

if (process.env.npm_lifecycle_event === 'postinstall') {
  (async () => {
    const promise = cpConfig(appEnvDir, libEnvDir);
    ora.promise(
      promise,
      chalk.yellowBright(
        `Micro-app configurations bootstrapped to the Master SPA!`,
      ),
    );
    await promise;

    console.log(``);
  })();
}
