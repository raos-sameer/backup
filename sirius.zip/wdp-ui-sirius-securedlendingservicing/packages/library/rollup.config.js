import path from 'path';

import babel from 'rollup-plugin-babel';
import commonjs from 'rollup-plugin-commonjs';
import postcss from 'rollup-plugin-postcss';
import resolve from 'rollup-plugin-node-resolve';
import url from 'rollup-plugin-url';
import svgr from '@svgr/rollup';

import pkg from './package.json';

const externals = Object.keys(pkg.peerDependencies);

export default {
  input: 'src/index.js',
  output: [
    {
      dir: path.parse(pkg.main).dir,
      format: 'cjs',
      sourcemap: true,
      chunkFileNames: '[name].js',
    },
    {
      dir: path.parse(pkg.module).dir,
      format: 'esm',
      sourcemap: true,
      chunkFileNames: '[name].js',
    },
  ],
  plugins: [
    postcss({
      modules: true,
    }),
    url({ exclude: ['**/*.svg'] }),
    svgr(),
    babel({
      exclude: 'node_modules/**',
      babelrc: false,
      configFile: path.join(__dirname, '../../babel.config.js'),
    }),
    resolve({
      extensions: ['.js', '.jsx', '.json'],
      modulesOnly: true,
    }),
    commonjs(),
  ],
  external: [...externals],
};
