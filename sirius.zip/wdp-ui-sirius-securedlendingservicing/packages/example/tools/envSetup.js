/* eslint-disable no-console */
const fse = require('fs-extra');
const chalk = require('chalk');
const path = require('path');
const ora = require('ora');

// #region Library dependency module path derivations

// Assumption is that this path is always .../packages/example
const currentWorkingDirectory = process.cwd();

// Based on the above assumption, this would be the project's root
const projectRoot = path.join(currentWorkingDirectory, '..', '..');

// Library environment folder to bootstrap into the App
const rootEnvDir = path.join(projectRoot, './env');

// App's root environment folder where the library environment config needs to be bootstrapped
const publicEnvDir = path.join(currentWorkingDirectory, 'public', 'env');

// #endregion

const cp = async (source, destination) => {
  try {
    await fse.copy(source, destination, { overwrite: true });
  } catch (error) {
    console.error(`${chalk.red(`\n\nError occurred while copying ${source} -> ${destination}`)}\n\n${error}\n\n`);
  }
};

const cpConfig = async (target, source) => {
  try {
    const promisedRemove = fse.remove(target);
    ora.promise(promisedRemove, chalk.yellowBright(`Performing house-keeping`));
    await promisedRemove;

    const promisedDir = fse.mkdirp(target);
    ora.promise(promisedDir, chalk.yellowBright(`Creating a pristine environment`));
    await promisedDir;

    const promisedEnvironments = fse.readdir(source);
    ora.promise(promisedEnvironments, chalk.yellowBright(`Parsing environments for available configurations\n`));
    const subDirs = await promisedEnvironments;

    // copy flexiform schemas
    const schemasSrc = path.join(projectRoot, './schemas');
    const schemasTarget = path.join(currentWorkingDirectory, 'public', 'forms');
    const cpSchemas = fse.copy(schemasSrc, schemasTarget);
    ora.promise(cpSchemas, chalk.yellowBright(`Copying form schemas: ${schemasSrc} => ${schemasTarget}`));
    await cpSchemas;

    await Promise.all(
      subDirs
        .filter(dir => dir === 'local' || dir === 'default')
        .map(async dir => {
          try {
            const sourceEnvironment = path.join(source, dir);
            const promisedFiles = fse.readdir(sourceEnvironment);
            ora.promise(
              promisedFiles,
              chalk.yellowBright(`Reading available configurations for ${dir.toUpperCase()} environment`),
            );
            const files = await promisedFiles;

            await Promise.all(
              files.map(async file => {
                const filePath = path.join(sourceEnvironment, file);
                const promisedStat = fse.stat(filePath);
                ora.promise(
                  promisedStat,
                  chalk.yellowBright(`Detecting if the configuration belongs to the Master SPA or a micro-app`),
                );
                const stat = await promisedStat;

                const isDirectory = stat.isDirectory();

                if (isDirectory) {
                  const targetDir = path.join(target, file);
                  await fse.ensureDir(targetDir);

                  const microAppFiles = await fse.readdir(filePath);
                  await Promise.all(
                    microAppFiles.map(async microAppFile => {
                      const microAppFilePath = path.join(filePath, microAppFile);
                      const relativeTarget = path.relative(projectRoot, targetDir);
                      const promisedCopy = cp(microAppFilePath, path.join(targetDir, microAppFile));
                      ora.promise(
                        promisedCopy,
                        chalk.yellowBright(`Copying micro-app configurations to ${relativeTarget}`),
                      );
                      await promisedCopy;
                    }),
                  );
                } else {
                  const relativeTarget = path.relative(projectRoot, target);
                  const promisedCopy = cp(filePath, path.join(target, file));
                  ora.promise(
                    promisedCopy,
                    chalk.yellowBright(`Copying Master SPA configurations to ${relativeTarget}`),
                  );
                  await promisedCopy;
                }
              }),
            );
          } catch (error) {
            const message = `${chalk.red(`Error occurred while setting up the target environment`)}\n${error.message}`;
            throw new Error(message);
          }
        }),
    );
    console.log(``);
  } catch (error) {
    const message = `${chalk.red(`Error occurred while bootstrapping Micro-app configurations`)}\n${error.message}`;
    throw new Error(message);
  }
};

(async () => {
  const promise = cpConfig(publicEnvDir, rootEnvDir);
  ora.promise(promise, chalk.yellowBright(`Local environment setup complete!`));
  await promise;

  console.log(``);
})();
