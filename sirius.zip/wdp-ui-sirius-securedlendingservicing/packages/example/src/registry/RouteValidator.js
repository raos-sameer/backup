import { difference, omit, merge } from 'lodash';
import { matchPath } from 'react-router';

/**
 *Parse query string from location.search and return an Object of key and values
 *
 * @param {string} queryString
 * @returns Object of key and value
 */
const queryStringParse = queryString => {
  const parsed = {};
  if (queryString !== '') {
    queryString
      .substring(queryString.indexOf('?') + 1)
      .split('&')
      .forEach(value => {
        const params = value.split('=');
        const [query, queryValue] = params;
        parsed[query] = queryValue;
      });
  }
  return parsed;
};

/**
 *Get the route configuration based on the path
 *
 * @param {string} [pathname='/']
 */
export const getMatchedRouteConfig = (pathname = '/', routes = []) =>
  routes.reduce((result, element) => {
    const matchedResult = result || {};
    if (element.routes && element.routes.length > 0) {
      const matchedChildRoute = getMatchedRouteConfig(pathname, element.routes);
      if (matchedChildRoute) {
        return matchedChildRoute;
      }
    } else {
      const matchedPath = matchPath(pathname, element);
      if (matchedPath) {
        return merge(matchedResult, matchedPath, element);
      }
    }
    return result;
  }, null);

const constructQueryParams = queryParams =>
  Object.keys(queryParams).reduce((query, item, index, array) => {
    const field = `${item}=${queryParams[item]}`;
    const isLast = index === array.length - 1;
    return `${query}${field}${isLast ? '' : '&'}`;
  }, '');

/**
 *Validate query params with the rules. The following set of validations are performed:
 * - Checks if any additional params are passed in query.
 * - Checks if any mandatory params are missing in query.
 * - Checks if the regex pattern defined in config is matching
 *
 * @param {Object.<{key: string, value: string}>} queryParams
 * @param {Object.<{key: string, value: Object}>} [rules={}]
 * @returns
 */
const validateQueryParams = (queryParams, rules = {}) => {
  const incomingParams = Object.keys(queryParams);
  const configuredParams = Object.keys(rules);
  const mandatoryParams = Object.keys(rules).filter(rule => rules[rule].required);

  if (difference(mandatoryParams, incomingParams).length > 0) {
    return { isValid: false };
  }

  const differentialParams = difference(incomingParams, configuredParams);
  if (differentialParams.length > 0) {
    return {
      isValid: false,
      queryParams: constructQueryParams(omit(queryParams, differentialParams)),
    };
  }

  let isValid = true;
  configuredParams.forEach(item => {
    const config = rules[item];
    const incomingValue = queryParams[item];
    if (incomingValue && !RegExp(config.pattern).test(incomingValue)) {
      isValid = false;
    }
  });
  return { isValid };
};

/**
 *Validate path params with the rules. The following set of validations are performed:
 * - Checks if any additional params are passed in path.
 * - Checks if any mandatory params are missing in path.
 * - Checks if the regex pattern defined in config is matching
 *
 * @param {Object.<{key: string, value: string}>} pathParams
 * @param {Object.<{key: string, value: Object}>} [rules={}]
 * @returns
 */
const validatePathParams = (pathParams = {}, rules = {}) => {
  const incomingParams = Object.keys(pathParams);
  const configuredParams = Object.keys(rules);
  const mandatoryParams = Object.keys(rules).filter(rule => rules[rule].required);
  if (difference(incomingParams, configuredParams).length > 0) {
    return { isValid: false };
  }

  if (difference(mandatoryParams, incomingParams).length > 0) {
    return { isValid: false };
  }

  let isValid = true;
  configuredParams.forEach(item => {
    const config = rules[item];
    const incomingValue = pathParams[item];

    if (incomingValue && !RegExp(config.pattern).test(incomingValue)) {
      isValid = false;
    }
  });
  return { isValid };
};

/**
 *Validator function to check the location based on route configuration.
 * Following rules are validated:
 * - Query Param
 * - Path Param
 *
 * @param {Object.<{pathname: string, search: string, state: Object}>} location
 * @returns result
 */
export const routeValidator = (location, matchedRoute) => {
  if (!matchedRoute) {
    return { isValid: true };
  }
  if (matchedRoute.skipValidation) {
    return { isValid: true };
  }
  if (!matchedRoute.isBookmarable) {
    // check if user exists in SSO.
    // If not, redirect to "/"
  }

  if (matchedRoute) {
    const pathParams = validatePathParams(matchedRoute.params, matchedRoute.pathParams);
    const queryParams = validateQueryParams(queryStringParse(location.search), matchedRoute.queryParams);
    return {
      isValid: pathParams.isValid && queryParams.isValid,
      queryParams: queryParams.queryParams,
    };
  }
  return true;
};
