import React, { Component } from 'react';
import { Router, Switch } from 'react-router-dom';

import { Helmet } from 'react-helmet';

import { getBasepath } from '@wdpui/common-utilities';

import { routesPropTypes } from './prop-types';
import { EnhancedRoute } from './EnhancedRoute';
import { getMatchedRouteConfig, routeValidator } from './RouteValidator';
import { history } from '../utilities';

export class AppRouter extends Component {
  static propTypes = {
    routes: routesPropTypes,
  };

  static defaultProps = {
    routes: [],
  };

  state = {
    pageTitle: '',
  };

  componentDidMount = () => {
    history.listen(this.locationChangeListener);
    //  Fire the action on page load as the listener will be not called.
    this.locationChangeListener(history.location);
  };

  /**
   *Location change listener to validate the path and query params
   *
   * @memberof AppRouter
   */
  locationChangeListener = location => {
    const { routes } = this.props;
    const matchedRoute = getMatchedRouteConfig(location.pathname || '/', routes);
    if (!matchedRoute) {
      return;
    }
    if (matchedRoute && matchedRoute.redirect) {
      return;
    }
    const { isValid, queryParams } = routeValidator(location, matchedRoute);
    if (!isValid) {
      if (typeof queryParams === 'string') {
        if (queryParams.length > 0) {
          history.replace(`${location.pathname}?${queryParams}`);
        } else {
          history.replace(`${location.pathname}`);
        }
        return;
      }
      history.replace('/error');
    }
    const { name } = matchedRoute || {};
    if (name)
      this.setState({
        pageTitle: name,
      });
  };

  render() {
    const { routes } = this.props;
    const { pageTitle } = this.state;
    return (
      <>
        <Router history={history} basename={getBasepath(process.env.NODE_ENV, process.env.REACT_APP_HOMEPAGE)}>
          <Switch>{routes && routes.map(route => <EnhancedRoute key={route.id} {...route} />)}</Switch>
        </Router>
        {pageTitle && (
          <Helmet>
            <title>{pageTitle}</title>
          </Helmet>
        )}
      </>
    );
  }
}
