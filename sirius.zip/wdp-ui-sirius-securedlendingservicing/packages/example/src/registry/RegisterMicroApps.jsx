import React, { Component } from 'react';
import PropTypes from 'prop-types';

import { routesPropTypes } from './prop-types';

export class RegisterMicroApps extends Component {
  static propTypes = {
    children: PropTypes.element.isRequired,
    routes: routesPropTypes.isRequired,
  };

  renderChildren() {
    const { children, routes } = this.props;
    const child = React.Children.only(children);

    if (child) {
      return React.cloneElement(child, { ...child.props, routes });
    }

    return null;
  }

  render() {
    const { children } = this.props;

    return <>{children && this.renderChildren(children)}</>;
  }
}
