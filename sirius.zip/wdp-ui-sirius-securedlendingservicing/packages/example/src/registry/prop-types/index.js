import PropTypes from 'prop-types';

export const componentPropTypes = PropTypes.oneOfType([PropTypes.element, PropTypes.func]);

export const layoutPropTypes = PropTypes.shape({
  inherit: PropTypes.bool,
  hero: PropTypes.bool,
  header: PropTypes.bool,
  footer: PropTypes.bool,
});

export const uiPropTypes = PropTypes.shape({
  layout: layoutPropTypes,
});

export const routesPropTypes = PropTypes.arrayOf(
  PropTypes.shape({
    path: PropTypes.string,
    name: PropTypes.string,
    component: componentPropTypes,
    isExact: PropTypes.bool,
    ui: uiPropTypes,
  }),
);
