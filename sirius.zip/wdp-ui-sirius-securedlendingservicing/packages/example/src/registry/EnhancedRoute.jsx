import React from 'react';
import PropTypes from 'prop-types';

import { Route } from 'react-router-dom';
import { Helmet } from 'react-helmet';

import { componentPropTypes, uiPropTypes } from './prop-types';

import { MasterLayout } from '../layouts/Master';

/**
 * Construct the component based on child routes.
 * If child routes are present, render them within the component.
 * If no child routes present, render the component.
 *
 * @param {*} Component
 * @param {*} routeProps
 * @param {*} routes
 */
export const renderWithChildRoutes = (Component, routeProps, routes) => (
  <>
    {Component && <Component routes={routes} {...routeProps} />}
    {!Component &&
      routes &&
      routes.map(
        ({ component: ChildComponent, id, path: childPath, exact: isChildExact, routes: childRoutes, ...rest }) => (
          <Route
            key={id}
            exact={isChildExact}
            path={childPath}
            {...rest}
            render={props => renderWithChildRoutes(ChildComponent, props, childRoutes)}
          />
        ),
      )}
  </>
);

/**
 * TODO:
 * Figure out how to nest MasterLayout for child Routes
 * One option is to hoist this to a common library &
 * let individual Routes in Micro Apps use render functions
 * Another one would be to hoist this Component along-with
 * the MasterLayout & let Micro Apps export EnhancedRoute
 *
 * Design the UI schema to accept from the Micro Apps
 */
export const EnhancedRoute = ({
  component: Component,
  name,
  ui: {
    layout: { inherit, header, hero, footer },
  },
  routes,
  redirect,
  ...rest
}) => (
  <>
    {inherit && (
      <MasterLayout withHeader={header} withHero={hero} withFooter={footer}>
        <Route {...rest} render={props => renderWithChildRoutes(Component, { ...props, ...rest }, routes)} />
      </MasterLayout>
    )}
    {!inherit && <Route {...rest} render={props => renderWithChildRoutes(Component, { ...props, ...rest }, routes)} />}
    <Helmet>
      <title>{name}</title>
    </Helmet>
  </>
);

EnhancedRoute.propTypes = {
  component: componentPropTypes,
  exact: PropTypes.bool,
  ui: uiPropTypes,
  name: PropTypes.string,
  routes: PropTypes.arrayOf(PropTypes.shape({})),
  scope: PropTypes.string,
  redirect: PropTypes.bool,
};

EnhancedRoute.defaultProps = {
  component: null,
  exact: false,
  ui: {},
  name: '',
  routes: null,
  scope: undefined,
  redirect: false,
};
