import { combineReducers } from 'redux';
import { commonReducers } from '@wdpui/common-app-wrapper';
import { reducer as analytics } from '@wdpui/common-analytics';
import {
  reducers as securedLendingServicingReducer,
  securedLendingServicingEntityReducer,
} from '@wdpui-sirius/securedlendingservicing';
import { reducer as coreEntityReducer } from '@wdpui/redux-exp-sirius-core-v1';
// Import your application reducers here and register them in
// the combineReducers map below
// @see http://redux.js.org/docs/recipes/reducers/UsingCombineReducers.html

const rootReducer = combineReducers({
  ...commonReducers,
  analytics,
  entities: combineReducers({ ...coreEntityReducer, ...securedLendingServicingEntityReducer }),
  ui: combineReducers({ ...securedLendingServicingReducer }),
});

export default rootReducer;
