import { createStore, applyMiddleware } from 'redux';
import createSagaMiddleware from 'redux-saga';

import { composeWithDevTools } from 'redux-devtools-extension';

import { createLoggerMiddleware } from '@wdpui/common-logger';
import { apiClientMiddleware } from '@wdpui/common-api-client';

// import the rootReducer which we initialise our store with.
import rootReducer from './rootReducer';

// import our rootSaga which we run with our saga middleware
import rootSaga from './sagas';

const sagaMiddleware = createSagaMiddleware();
const loggerMiddleware = createLoggerMiddleware();

// The default state for our redux store.
const defaultState = {};

// Add any middleware here for it to be applied to the store.
// Note that the order of the middleware is important here.
const middlewares = [sagaMiddleware, apiClientMiddleware, loggerMiddleware];

const store = createStore(rootReducer, defaultState, composeWithDevTools(applyMiddleware(...middlewares)));

sagaMiddleware.run(rootSaga);

export default store;
