import 'react-app-polyfill/ie9';
import React from 'react';
import ReactDOM from 'react-dom';
import { Provider } from 'react-redux';

import { configureLogger, ConsoleTransport } from '@wdpui/common-logger';
import './index.css';

// import './index.css';
import EnhancedApp from './App';
import store from './redux/store';

configureLogger({
  appId: '@wdpui-sirius',
  transport: ConsoleTransport,
});

ReactDOM.render(
  <Provider store={store}>
    <EnhancedApp />
  </Provider>,
  document.getElementById('root'),
);
