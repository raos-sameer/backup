import React from 'react';
import PropTypes from 'prop-types';
import { Column } from '@wdpui/react-gel';

import { PageWrapper, Page, PageHeader, PageFooter } from './_';

import { StyledGridContainer, StyledGrid } from '../../components/common/styles';

import { HeroContainer } from '../../containers/HeroContainer';

const MasterLayout = ({ children, withHeader, withHero, withFooter }) => (
  <PageWrapper>
    <Page>
      {withHeader && <PageHeader />}
      {withHero && <HeroContainer />}
      <StyledGridContainer>
        <StyledGrid>
          <Column>{children}</Column>
        </StyledGrid>
      </StyledGridContainer>
      {withFooter && <PageFooter />}
    </Page>
  </PageWrapper>
);

MasterLayout.propTypes = {
  children: PropTypes.element.isRequired,
  withHeader: PropTypes.bool,
  withHero: PropTypes.bool,
  withFooter: PropTypes.bool,
};

MasterLayout.defaultProps = {
  withHeader: true,
  withHero: false,
  withFooter: true,
};

export default MasterLayout;
