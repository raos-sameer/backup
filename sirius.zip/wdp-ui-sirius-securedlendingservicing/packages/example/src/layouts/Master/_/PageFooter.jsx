import React from 'react';
import { Footer } from '@wdpui/gel-footer';

const year = new Date().getFullYear();

const PageFooter = () => (
  <Footer divider link="https://www.westpac.com.au/">
    <p>
      Our site and your transactions are secure. You can read our{' '}
      <a href="https://www.westpac.com.au">security information</a>.
      <br />© {year} Westpac Banking Corporation ABN 33 007 457 141 AFSL and Australian credit licence 233714
    </p>
  </Footer>
);

export default PageFooter;
