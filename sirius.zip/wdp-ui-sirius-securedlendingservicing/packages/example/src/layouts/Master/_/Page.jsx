import styled from 'styled-components';
import { Flex } from '@rebass/grid';

const Page = styled(Flex)`
  min-height: 100vh;
  flex: 1 0 auto;
  flex-direction: column;
`;

export default Page;
