import React from 'react';
import { Header, Button } from '@wdpui/react-gel';

const PageHeader = () => (
  <Header logoCenterXs>
    <Button
      styling="faint"
      soft
      size="medium"
      label="Sign out"
      // eslint-disable-next-line no-alert
      onClick={() => alert('Sign Out Clicked')}
    />
  </Header>
);

export default PageHeader;
