import React from 'react';
import { Link } from 'react-router-dom';

import styled from 'styled-components';
import { Grid, Column } from '@wdpui/gel-grid';
import { Text } from '@wdpui/gel-typography';
import { List, ListItem } from '@wdpui/gel-list';
import { ContainerRow } from '../components/common/styles';

const Heading = styled(Text)`
  margin: 0;
`;

const Default = () => (
  <Grid>
    <Column pt={24} pb={12} flex="1 0 auto">
      <Heading is="h1" size={6} weight="light">
        Master SPA home
      </Heading>
    </Column>
    <Column pt={12} pb={24} flex="1 0 auto">
      <ContainerRow>
        <Column>
          <List bullet="link">
            <ListItem>
              <Link to="/securedlendingservicing?contextRefId=1234">Micro app home page</Link>
            </ListItem>
          </List>
        </Column>
      </ContainerRow>
    </Column>
  </Grid>
);

export default Default;
