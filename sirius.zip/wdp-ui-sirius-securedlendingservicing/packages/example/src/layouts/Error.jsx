import React from 'react';
import PropTypes from 'prop-types';

const Error = ({ error }) => (
  <div>
    <h1>{error || 'Oops... something went wrong'}</h1>
  </div>
);

Error.propTypes = {
  error: PropTypes.string,
};
Error.defaultProps = {
  error: undefined,
};

export default Error;
