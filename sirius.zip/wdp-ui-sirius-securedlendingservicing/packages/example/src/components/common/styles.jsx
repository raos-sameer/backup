import styled from 'styled-components';
import { GridContainer, Row, Grid } from '@wdpui/gel-grid';

export const StyledGridContainer = styled(GridContainer)`
  background-color: ${props => props.theme.color.background};
  padding: 0;
  width: 100%;
  max-width: 100%;
`;

export const StyledGrid = styled(Grid)`
  width: 100%;
`;

export const StyledRow = styled(Row)`
  margin-left: 0px;
  margin-right: 0px;
`;

export const ContainerRow = styled(Row)`
  border-bottom: 1px ${({ theme }) => theme.color.border} solid;
  align-items: center;
  background-color: #fff;
`;
