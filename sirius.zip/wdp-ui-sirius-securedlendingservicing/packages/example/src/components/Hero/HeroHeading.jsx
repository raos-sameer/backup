import React from 'react';
import PropTypes from 'prop-types';
import styled from 'styled-components';

import { Text } from '@wdpui/gel-typography';

/* The white color is non-GEL standard, hardcoding white here */
const StyledHeading = styled(Text)`
  color: #fff;
  margin: 0;
  position: relative;
  z-index: 1;
  padding: 24px 6px;
  ${({ theme }) =>
    theme.breakpointMax.sm`
  font-size: ${theme.typography.scale(5)};
  padding: 12px 0;
  `};
`;

const HeroHeading = ({ heading }) => (
  <StyledHeading is="h1" size={6}>
    {heading}
    <br />
    <strong>What&apos;s on today?</strong>
  </StyledHeading>
);

HeroHeading.propTypes = {
  heading: PropTypes.node.isRequired,
};

export default HeroHeading;
