export { default as Hero } from './Hero';
