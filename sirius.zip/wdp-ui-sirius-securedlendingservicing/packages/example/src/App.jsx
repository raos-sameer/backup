import React from 'react';
import { compose } from 'recompose';
import { AppWrapper } from '@wdpui/common-app-wrapper';
import { withLocation } from '@wdpui/common-location';
import { pages as securedlendingRoutes } from '@wdpui-sirius/securedlendingservicing';
import store from './redux/store';
import { pages as masterRoutes } from './routes';

import { RegisterMicroApps, RegisterRoutes, Router } from './registry';
import { history } from './utilities';

export const App = () => (
  <RegisterMicroApps routes={[...securedlendingRoutes, ...masterRoutes]}>
    <RegisterRoutes>
      <Router />
    </RegisterRoutes>
  </RegisterMicroApps>
);

// NOTE: Disabling SSO for demo purposes only
const options = {
  env: process.env.NODE_ENV,
  homepage: process.env.REACT_APP_HOMEPAGE,
  history,
  sso: {
    enable: true,
  },
  analytics: {
    enable: true,
    vendors: ['omniture'],
  },
};

const withWDP = compose(
  AppWrapper(options),
  withLocation(() => ({
    history,

    routeValidation: {
      enable: false,
    },
    virtualSwimlanes: {
      enable: true,
      dispatch: store.dispatch,
    },
  })),
);

export default withWDP(App);
