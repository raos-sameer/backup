import { filter, find, map } from 'lodash';

export const filterPagesById = (applicationRoutes, pages) =>
  filter(applicationRoutes, applicationRoute => find(pages, page => page.id === applicationRoute.id));

/**
 * Merges routes config from /pages api and the routes configured in the individual microapps
 *
 * @param {Array<Object>} applicationRoutes
 * @param {Array<Object>} pages
 * @returns
 */
export const mergeRoutes = (applicationRoutes, pages) => {
  const roleBasedRoutes = filterPagesById(applicationRoutes, pages);
  return map(roleBasedRoutes, applicationRoute => {
    const route = find(pages, page => page.id === applicationRoute.id);
    if (applicationRoute.routes) {
      route.routes = mergeRoutes(applicationRoute.routes, pages);
    }
    return {
      ...applicationRoute,
      ...route,
    };
  });
};
