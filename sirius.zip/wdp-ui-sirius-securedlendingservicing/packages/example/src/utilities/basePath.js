import { getBasepath } from '@wdpui/common-utilities';

export const fromBasepath = (path, basePath = getBasepath(process.env.NODE_ENV, process.env.REACT_APP_HOMEPAGE)) =>
  `/${basePath}/${path}`.replace(/\/+/g, '/');
