import { createBrowserHistory } from 'history';
import { getBasepath } from '@wdpui/common-utilities';

export const history = createBrowserHistory({
  basename: getBasepath(process.env.NODE_ENV, process.env.REACT_APP_HOMEPAGE),
});
