import { Default, Error } from './layouts';

const error404 = `Oops... It seems you have visited a page that doesn't exist`;
export const ErrorPage = {
  id: 'pages.sirius.error',
  name: 'sirius Error',
  path: '/error',
  component: Error,
  ui: {
    layout: {
      inherit: true,
      hero: false,
      footer: true,
    },
  },
};

export const NotFoundPage = {
  id: 'pages.sirius.404',
  name: 'Page Not Found',
  path: '/not-found',
  component: Error,
  error: error404,
  ui: {
    layout: {
      inherit: true,
      hero: false,
      footer: true,
    },
  },
};

export const pages = [
  {
    id: 'pages.sirius.home',
    component: Default,
    exact: true,
    ui: {
      layout: {
        inherit: true,
        hero: true,
        footer: true,
      },
    },
  },
];

export default pages;
