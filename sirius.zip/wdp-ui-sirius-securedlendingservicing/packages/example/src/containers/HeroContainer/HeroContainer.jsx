import React, { PureComponent } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';

import { getLoggedUserGivenName } from '@wdpui/common-with-sso';

import { Hero } from '../../components/Hero';

class HeroContainer extends PureComponent {
  static propTypes = {
    userGivenName: PropTypes.string,
  };

  static defaultProps = {
    userGivenName: '',
  };

  render() {
    const { userGivenName = '' } = this.props;
    const givenName = userGivenName ? `, ${userGivenName}` : '';
    const heading = `Hi${givenName}.`;
    const heroAltText = 'Welcome to your new banker platform';

    return <Hero heading={heading} altText={heroAltText} />;
  }
}

const mapStateToProps = state => ({
  userGivenName: getLoggedUserGivenName(state),
});

export default connect(mapStateToProps)(HeroContainer);
