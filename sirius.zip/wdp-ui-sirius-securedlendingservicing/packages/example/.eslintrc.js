module.exports = {
    extends: ['@wdpui'],
    parser: 'babel-eslint',
    root: true,
  };