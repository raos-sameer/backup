# Change Log

All notable changes to this project will be documented in this file.
See [Conventional Commits](https://conventionalcommits.org) for commit guidelines.

## [1.34.14](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/compare/v1.34.13...v1.34.14) (2020-05-29)

**Note:** Version bump only for package @wdpui-sirius/securedlendingservicing-example





## [1.34.13](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/compare/v1.34.12...v1.34.13) (2020-05-25)

**Note:** Version bump only for package @wdpui-sirius/securedlendingservicing-example





## [1.34.12](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/compare/v1.34.11...v1.34.12) (2020-05-25)

**Note:** Version bump only for package @wdpui-sirius/securedlendingservicing-example





## [1.34.11](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/compare/v1.34.10...v1.34.11) (2020-05-22)

**Note:** Version bump only for package @wdpui-sirius/securedlendingservicing-example





## [1.34.10](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/compare/v1.34.9...v1.34.10) (2020-05-22)

**Note:** Version bump only for package @wdpui-sirius/securedlendingservicing-example





## [1.34.9](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/compare/v1.34.8...v1.34.9) (2020-05-22)


### Bug Fixes

* code fixes for submit api and redraw popup ([8101c2f](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/8101c2f7b7b64921634039d68f6e168d41670c3c))





## [1.34.8](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/compare/v1.34.7...v1.34.8) (2020-05-22)

**Note:** Version bump only for package @wdpui-sirius/securedlendingservicing-example





## [1.34.7](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/compare/v1.34.6...v1.34.7) (2020-05-21)

**Note:** Version bump only for package @wdpui-sirius/securedlendingservicing-example





## [1.34.6](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/compare/v1.34.5...v1.34.6) (2020-05-21)

**Note:** Version bump only for package @wdpui-sirius/securedlendingservicing-example





## [1.34.5](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/compare/v1.34.4...v1.34.5) (2020-05-20)

**Note:** Version bump only for package @wdpui-sirius/securedlendingservicing-example





## [1.34.4](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/compare/v1.34.3...v1.34.4) (2020-05-20)

**Note:** Version bump only for package @wdpui-sirius/securedlendingservicing-example





## [1.34.3](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/compare/v1.34.2...v1.34.3) (2020-05-20)

**Note:** Version bump only for package @wdpui-sirius/securedlendingservicing-example





## [1.34.2](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/compare/v1.34.1...v1.34.2) (2020-05-20)

**Note:** Version bump only for package @wdpui-sirius/securedlendingservicing-example





## [1.34.1](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/compare/v1.34.0...v1.34.1) (2020-05-20)

**Note:** Version bump only for package @wdpui-sirius/securedlendingservicing-example





# [1.34.0](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/compare/v1.33.5...v1.34.0) (2020-05-19)

**Note:** Version bump only for package @wdpui-sirius/securedlendingservicing-example





## [1.33.5](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/compare/v1.33.4...v1.33.5) (2020-05-19)

**Note:** Version bump only for package @wdpui-sirius/securedlendingservicing-example





## [1.33.4](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/compare/v1.33.3...v1.33.4) (2020-05-19)

**Note:** Version bump only for package @wdpui-sirius/securedlendingservicing-example





## [1.33.3](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/compare/v1.33.2...v1.33.3) (2020-05-18)

**Note:** Version bump only for package @wdpui-sirius/securedlendingservicing-example





## [1.33.2](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/compare/v1.33.1...v1.33.2) (2020-05-18)

**Note:** Version bump only for package @wdpui-sirius/securedlendingservicing-example





## [1.33.1](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/compare/v1.33.0...v1.33.1) (2020-05-17)

**Note:** Version bump only for package @wdpui-sirius/securedlendingservicing-example





# [1.33.0](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/compare/v1.32.3...v1.33.0) (2020-05-15)

**Note:** Version bump only for package @wdpui-sirius/securedlendingservicing-example





## [1.32.3](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/compare/v1.32.2...v1.32.3) (2020-05-14)

**Note:** Version bump only for package @wdpui-sirius/securedlendingservicing-example





## [1.32.2](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/compare/v1.32.1...v1.32.2) (2020-05-14)

**Note:** Version bump only for package @wdpui-sirius/securedlendingservicing-example





## [1.32.1](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/compare/v1.32.0...v1.32.1) (2020-05-14)

**Note:** Version bump only for package @wdpui-sirius/securedlendingservicing-example





# [1.32.0](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/compare/v1.31.0...v1.32.0) (2020-05-14)

**Note:** Version bump only for package @wdpui-sirius/securedlendingservicing-example





# [1.31.0](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/compare/v1.30.5...v1.31.0) (2020-05-14)

**Note:** Version bump only for package @wdpui-sirius/securedlendingservicing-example





## [1.30.5](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/compare/v1.30.4...v1.30.5) (2020-05-13)

**Note:** Version bump only for package @wdpui-sirius/securedlendingservicing-example





## [1.30.4](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/compare/v1.30.3...v1.30.4) (2020-05-13)

**Note:** Version bump only for package @wdpui-sirius/securedlendingservicing-example





## [1.30.3](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/compare/v1.30.2...v1.30.3) (2020-05-12)

**Note:** Version bump only for package @wdpui-sirius/securedlendingservicing-example





## [1.30.2](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/compare/v1.30.1...v1.30.2) (2020-05-12)


### Bug Fixes

* to show proper discount text ([68934e8](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/68934e8f1c626b1a360c7787aac5bb2076a453a8))





## [1.30.1](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/compare/v1.30.0...v1.30.1) (2020-05-12)

**Note:** Version bump only for package @wdpui-sirius/securedlendingservicing-example





# [1.30.0](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/compare/v1.29.0...v1.30.0) (2020-05-08)

**Note:** Version bump only for package @wdpui-sirius/securedlendingservicing-example





# [1.29.0](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/compare/v1.28.3...v1.29.0) (2020-05-07)


### Features

* moving back code from master spa to micro spa for contexts ([68bcadf](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/68bcadf70f9c8ed337e612d862b9c268c396ba80))





## [1.28.3](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/compare/v1.28.2...v1.28.3) (2020-05-07)

**Note:** Version bump only for package @wdpui-sirius/securedlendingservicing-example





## [1.28.2](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/compare/v1.28.1...v1.28.2) (2020-05-06)


### Bug Fixes

* moved context handover fetching to master spa ([acdd32d](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/acdd32d7bd1574ffb0a61aaf290a41d21d38a92c))





## [1.28.1](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/compare/v1.28.0...v1.28.1) (2020-05-06)

**Note:** Version bump only for package @wdpui-sirius/securedlendingservicing-example





# [1.28.0](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/compare/v1.27.1...v1.28.0) (2020-05-06)

**Note:** Version bump only for package @wdpui-sirius/securedlendingservicing-example





## [1.27.1](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/compare/v1.27.0...v1.27.1) (2020-05-05)

**Note:** Version bump only for package @wdpui-sirius/securedlendingservicing-example





# [1.27.0](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/compare/v1.26.0...v1.27.0) (2020-05-05)

**Note:** Version bump only for package @wdpui-sirius/securedlendingservicing-example





# [1.26.0](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/compare/v1.25.0...v1.26.0) (2020-05-04)

**Note:** Version bump only for package @wdpui-sirius/securedlendingservicing-example





# [1.25.0](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/compare/v1.24.3...v1.25.0) (2020-05-04)

**Note:** Version bump only for package @wdpui-sirius/securedlendingservicing-example





## [1.24.3](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/compare/v1.24.2...v1.24.3) (2020-05-01)


### Bug Fixes

* remaining term reading from exp api ([0970012](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/0970012648d4667fe4e918033bffd35d3a17974d))





## [1.24.2](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/compare/v1.24.1...v1.24.2) (2020-04-30)

**Note:** Version bump only for package @wdpui-sirius/securedlendingservicing-example





## [1.24.1](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/compare/v1.24.0...v1.24.1) (2020-04-30)

**Note:** Version bump only for package @wdpui-sirius/securedlendingservicing-example





# [1.24.0](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/compare/v1.23.1...v1.24.0) (2020-04-29)


### Features

* changed context handover api to refer sirius core api ([32d1600](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/32d1600081c23424cc52310eea7b9204ae5bbaaa))





## [1.23.1](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/compare/v1.23.0...v1.23.1) (2020-04-28)

**Note:** Version bump only for package @wdpui-sirius/securedlendingservicing-example





# [1.23.0](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/compare/v1.22.2...v1.23.0) (2020-04-27)


### Features

* adding validation message if quotes failed error ([f4ed094](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/f4ed0945012a4dfe8bdadbc51916ed8ac902ce5e))





## [1.22.2](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/compare/v1.22.1...v1.22.2) (2020-04-27)

**Note:** Version bump only for package @wdpui-sirius/securedlendingservicing-example





## [1.22.1](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/compare/v1.22.0...v1.22.1) (2020-04-23)


### Bug Fixes

* eligibility changes to be in sync with exp and cap api ([c2df276](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/c2df2764d3e27f9eb353a0322ffe885ce69a46b5))





# [1.22.0](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/compare/v1.21.0...v1.22.0) (2020-04-17)


### Features

* reading context latest form exp api ([8012ff5](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/8012ff5f2164ab99692fe9d2d7d519631bb1a630))
* refactor sagas request body and moved to selector ([400aff9](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/400aff9edc38e0227130f4ae694e09fcd31f67da))
* swagger ui changes integration ([453a934](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/453a934799e38ed68cb8af16a7e43cad75592edd))





# [1.21.0](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/compare/v1.20.0...v1.21.0) (2020-04-07)

**Note:** Version bump only for package @wdpui-sirius/securedlendingservicing-example





# [1.20.0](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/compare/v1.19.0...v1.20.0) (2020-04-07)

**Note:** Version bump only for package @wdpui-sirius/securedlendingservicing-example





# [1.19.0](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/compare/v1.18.0...v1.19.0) (2020-04-07)


### Features

* reading product name from current loan details ([f59ee07](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/f59ee0755486f3950cec764ea221f56ef990b258))





# [1.18.0](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/compare/v1.17.1...v1.18.0) (2020-04-03)

**Note:** Version bump only for package @wdpui-sirius/securedlendingservicing-example





## [1.17.1](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/compare/v1.17.0...v1.17.1) (2020-04-03)

**Note:** Version bump only for package @wdpui-sirius/securedlendingservicing-example





# [1.17.0](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/compare/v1.16.1...v1.17.0) (2020-04-02)


### Bug Fixes

* defect fix for popup ([4b9efa8](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/4b9efa867aabd322493922183ac8b0ce5191b4b0))


### Features

* reading from config fee details ([ad3e0c8](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/ad3e0c8e9af695a8a11514d3d2a82f064aa19424))





## [1.16.1](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/compare/v1.16.0...v1.16.1) (2020-03-31)

**Note:** Version bump only for package @wdpui-sirius/securedlendingservicing-example





# [1.16.0](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/compare/v1.15.0...v1.16.0) (2020-03-25)

**Note:** Version bump only for package @wdpui-sirius/securedlendingservicing-example





# [1.15.0](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/compare/v1.14.0...v1.15.0) (2020-03-25)

**Note:** Version bump only for package @wdpui-sirius/securedlendingservicing-example





# [1.14.0](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/compare/v1.13.1...v1.14.0) (2020-03-25)


### Features

* reading contracted date from api ([bd150a5](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/bd150a5f10374d0a69dc49073d31e255b38f1f46))





## [1.13.1](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/compare/v1.13.0...v1.13.1) (2020-03-24)

**Note:** Version bump only for package @wdpui-sirius/securedlendingservicing-example





# [1.13.0](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/compare/v1.12.0...v1.13.0) (2020-03-24)


### Features

* error scenarios for eligibility ([8531e96](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/8531e96c5a947cdc45d2db58619516d5a6a47e66))





# [1.12.0](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/compare/v1.11.4...v1.12.0) (2020-03-24)

**Note:** Version bump only for package @wdpui-sirius/securedlendingservicing-example





## [1.11.4](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/compare/v1.11.3...v1.11.4) (2020-03-22)

**Note:** Version bump only for package @wdpui-sirius/securedlendingservicing-example





## [1.11.3](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/compare/v1.11.2...v1.11.3) (2020-03-19)

**Note:** Version bump only for package @wdpui-sirius/securedlendingservicing-example





## [1.11.2](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/compare/v1.11.1...v1.11.2) (2020-03-19)

**Note:** Version bump only for package @wdpui-sirius/securedlendingservicing-example





## [1.11.1](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/compare/v1.11.0...v1.11.1) (2020-03-17)


### Bug Fixes

* swagger changes to read new entities ([4beb4dc](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/4beb4dcc3dfd313a3f8a9e6d8fdaea45ae4740c6))





# [1.11.0](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/compare/v1.10.0...v1.11.0) (2020-03-17)


### Features

* reading package indicator from context api ([1c1776f](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/1c1776fa5b073b23d3f3a8f44bd52d01b3b2e446))





# [1.10.0](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/compare/v1.9.1...v1.10.0) (2020-03-16)


### Bug Fixes

* code fix for removing unused ([4dd0bda](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/4dd0bda5b08948d76fa62adf4f08259924cbe423))
* fixed formatting and added loan calculation for interest only ([b34fecc](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/b34fecceac66ae9acf15f8482db8076c8109801a))
* hint text for split amount ([5cbf440](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/5cbf440c5e8f69820aaa5a6c813bbf9d8356b458))


### Features

* added new sagas ([eeef7df](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/eeef7df15a273ad16132754f1e21cb668318da58))
* handling eligibility data ([f491fc7](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/f491fc796de026e0f1361ba742f5448b07328a60))





## [1.9.1](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/compare/v1.9.0...v1.9.1) (2020-02-28)

**Note:** Version bump only for package @wdpui-sirius/securedlendingservicing-example





# [1.9.0](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/compare/v1.8.1...v1.9.0) (2020-02-27)


### Features

* added test case and refactored ([20110ab](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/20110ab44ba78049d1f522debad0b4cb2aa76b68))





## [1.8.1](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/compare/v1.8.0...v1.8.1) (2020-02-19)

**Note:** Version bump only for package @wdpui-sirius/securedlendingservicing-example





# [1.8.0](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/compare/v1.7.1...v1.8.0) (2020-02-18)


### Features

* fixed loan options screen merge from sagar reshma ([335eb65](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/335eb65965ade44b912b747e470d5a8d5353436c))





## [1.7.1](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/compare/v1.7.0...v1.7.1) (2020-02-12)

**Note:** Version bump only for package @wdpui-sirius/securedlendingservicing-example





# [1.7.0](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/compare/v1.6.1...v1.7.0) (2020-02-10)

**Note:** Version bump only for package @wdpui-sirius/securedlendingservicing-example





## [1.6.1](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/compare/v1.6.0...v1.6.1) (2020-02-05)

**Note:** Version bump only for package @wdpui-sirius/securedlendingservicing-example





# [1.6.0](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/compare/v1.5.0...v1.6.0) (2020-02-03)


### Bug Fixes

* changes as per cx ([4821e16](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/4821e16d5e861327c4c3c2621c5e26d6e683548a))
* fixing bullet list item with styled rendering ([e88facd](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/e88facd82154f66ffce3047f3a3c3ed850434c60))


### Features

* added new component for interest rate selection ([e287e01](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/e287e014e18732399fe9974cf779e4209d328ad8))
* changed button style ([5682781](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/56827817150e21f24157301a66be42739a9b7520))
* changed list item rendering for landing page ([1073c5b](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/1073c5b19cca9b6ab38a73dc462641a4a50df304))
* changed list item rendering for landing page ([eca6557](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/eca6557c6308c5e4525a9bd94f3b131b085f181c))
* components added for interest rate ([8f22fc8](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/8f22fc8d22ce586403183fabe60936ac442cc6a0))
* fixes for styling for different scenarios ([6bb0143](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/6bb0143b75807222d848d8c30a5f46c59e42c7ad))
* updated styles ([1aa9563](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/1aa95638384d0cbc4e68c2fa1c65f701e1d83e3a))





# [1.5.0](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/compare/v1.4.0...v1.5.0) (2020-01-09)


### Bug Fixes

* changed as per review comments ([8d4c8d2](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/8d4c8d25910040fbcc7f41ba7f4b3ca2b6c7701b))
* changes in exp api to remove appparam and response change ([90999fe](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/90999fee97e9220f50785136b3767208e32a3d38))
* moved code to containers and also removed appparams ([4ed2721](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/4ed2721d5b9667c14557f366956a6c759d6b1ebd))
* ui change for popup ([ef3103b](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/ef3103bc326c347109c406159070940030f62065))





# [1.4.0](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/compare/v1.3.0...v1.4.0) (2020-01-08)

**Note:** Version bump only for package @wdpui-sirius/securedlendingservicing-example





# [1.3.0](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/compare/v1.2.1...v1.3.0) (2020-01-07)

**Note:** Version bump only for package @wdpui-sirius/securedlendingservicing-example





## [1.2.1](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/compare/v1.2.0...v1.2.1) (2020-01-07)

**Note:** Version bump only for package @wdpui-sirius/securedlendingservicing-example





# [1.2.0](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/compare/v1.1.1...v1.2.0) (2020-01-07)


### Bug Fixes

* move reducer ui slice to the master app ([7ec27c9](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/7ec27c9d881f6440a9405829b7df6c7e78dc1ebd))





## [1.1.1](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/compare/v1.1.0...v1.1.1) (2020-01-06)

**Note:** Version bump only for package @wdpui-sirius/securedlendingservicing-example





# 1.1.0 (2020-01-06)


### Features

* **analytics:** enable analytics and ui changes ([11e61a7](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/11e61a7d98f6f292937c395ddabe7a0ea1555889))
* **change:** route changes and config changes ([712becb](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/712becb0cdd42eeaeabe00783bdafb7ddf0052f8))
* **modal popup:** new component introduced ([ba74a34](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/ba74a344ddbc0ae76ffdbdc69389c5549b21b110))
