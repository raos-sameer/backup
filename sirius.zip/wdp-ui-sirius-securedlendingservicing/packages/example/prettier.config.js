module.exports = {
  jsxBracketSameLine: false,
  printWidth: 120,
  semi: true,
  singleQuote: true,
  trailingComma: 'all',
};