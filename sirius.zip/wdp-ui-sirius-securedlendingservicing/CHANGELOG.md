# Change Log

All notable changes to this project will be documented in this file.
See [Conventional Commits](https://conventionalcommits.org) for commit guidelines.

## [1.34.14](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/compare/v1.34.13...v1.34.14) (2020-05-29)


### Bug Fixes

* calculation defect for PIF loan calc ([f08c31f](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/f08c31f328e5bc43f021cf8ece3c2e73cadb2ee7))





## [1.34.13](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/compare/v1.34.12...v1.34.13) (2020-05-25)


### Bug Fixes

* redraw popup issue for explorer fixed ([3f526c8](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/3f526c8d72ce87e70fc1e5f3dddcb7fcc6fda527))





## [1.34.12](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/compare/v1.34.11...v1.34.12) (2020-05-25)


### Bug Fixes

* internet explorer issues ([5377cf6](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/5377cf64fa248896fa0c4f43817ad864284081f3))





## [1.34.11](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/compare/v1.34.10...v1.34.11) (2020-05-22)


### Bug Fixes

* footer for inernet explorer ([6eea2da](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/6eea2da962179cb94a9e8a4504376cbaca998f62))
* landing page tick issue ([796bb0f](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/796bb0fc7b88ba1c0d2d216c93793072b717cde2))





## [1.34.10](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/compare/v1.34.9...v1.34.10) (2020-05-22)


### Bug Fixes

* available balance ([a70ec49](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/a70ec499b096a4ddcd65fdb48c705490f7e5f419))





## [1.34.9](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/compare/v1.34.8...v1.34.9) (2020-05-22)


### Bug Fixes

* code fixes for submit api and redraw popup ([8101c2f](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/8101c2f7b7b64921634039d68f6e168d41670c3c))





## [1.34.8](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/compare/v1.34.7...v1.34.8) (2020-05-22)


### Bug Fixes

* defect fix ([acf9141](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/acf9141762d046cc0d90e97c854d6526fe9a6ce0))





## [1.34.7](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/compare/v1.34.6...v1.34.7) (2020-05-21)


### Bug Fixes

* accessibility focus for modal and tagging ([9c2671c](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/9c2671cb76f8773e9984d030647802da0e2faca2))





## [1.34.6](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/compare/v1.34.5...v1.34.6) (2020-05-21)


### Bug Fixes

* refactoring analytics code ([0b6d043](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/0b6d043ba1ae410d6cd4b606e7c6422f738f0e7c))





## [1.34.5](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/compare/v1.34.4...v1.34.5) (2020-05-20)


### Bug Fixes

*  new cx changes ([b5296a7](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/b5296a7d30a19655e058279f9c309e82df4ab5bd))
* new cx changes ([5a7724f](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/5a7724fc9ff073e6af65e48141de114d15e462d7))





## [1.34.4](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/compare/v1.34.3...v1.34.4) (2020-05-20)


### Bug Fixes

* defect fixes ([43bfb7f](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/43bfb7f72c0be45405def4deda9a8d60e53a0094))





## [1.34.3](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/compare/v1.34.2...v1.34.3) (2020-05-20)


### Bug Fixes

* error code change ([33d4a1a](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/33d4a1aac24def4a2e429a0298a1da6d3dc8156b))





## [1.34.2](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/compare/v1.34.1...v1.34.2) (2020-05-20)


### Bug Fixes

* check discount applicable then show discount text ([1ad7a39](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/1ad7a399a0923010094bd70a5c4827a5137a672b))





## [1.34.1](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/compare/v1.34.0...v1.34.1) (2020-05-20)


### Bug Fixes

* cx changes fr all pages ([3450dff](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/3450dffca5ba75067c59e3db0aa1816e1bbac748))
* test fixes ([2e338bd](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/2e338bdbf5156f36e59164a46db85146c37d24ab))





# [1.34.0](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/compare/v1.33.5...v1.34.0) (2020-05-19)


### Features

* accessibility focus issue for header ([308694d](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/308694d15beb7414c87ba4a10855ec76e3875c88))





## [1.33.5](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/compare/v1.33.4...v1.33.5) (2020-05-19)


### Bug Fixes

* conflict resolved ([b88235d](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/b88235d4d3eb77d2d250139cdd62bea8c6717c78))
* cx changes ([2a08d57](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/2a08d5770005631680a2e9a9f01edbd5d14b26f1))
* minor fixes ([0123a09](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/0123a09b6be390473f3d1e969f9a5ba6230f8fff))
* minor fixes ([228726a](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/228726a3415d7ad74bffea0e8c0c88bb386c5e35))
* test file conflict ([d8cf796](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/d8cf79638a76231ef7cabd8ad59bdf13aec06993))
* test file conflict resolved ([4d9a170](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/4d9a170cd971c42e5c3d0ed1f55e340d164f2026))





## [1.33.4](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/compare/v1.33.3...v1.33.4) (2020-05-19)


### Bug Fixes

* accessibility fixes and repayment type check ([f99419b](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/f99419bab974fe5cd531557b36249436fb69106c))
* minor fix for PIF scenario ([462c7ff](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/462c7ff90259b7e103af238e07313a9ba7a9547d))





## [1.33.3](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/compare/v1.33.2...v1.33.3) (2020-05-18)


### Bug Fixes

* moved amount constant to helper ([671da17](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/671da17b04c6db53f0d041929c0f4a275ba4ad43))
* validation added for max amount ([2f75d46](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/2f75d467c752257124adfff26c4093d8a634ecb5))





## [1.33.2](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/compare/v1.33.1...v1.33.2) (2020-05-18)

**Note:** Version bump only for package @wdpui-sirius/securedlendingservicing-mono-repo





## [1.33.1](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/compare/v1.33.0...v1.33.1) (2020-05-17)


### Bug Fixes

* calculate repayment button ([a948c15](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/a948c15a940e6f044c7bc9e73e73a735dfa26f5a))
* error page css for mobile view ([3e58b17](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/3e58b17fe87cc4d08823b3cc804aaf13e72295f7))
* some minor changes in files ([4b79dd2](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/4b79dd2f5f0c99fe54bd08bb5ac1a8f133ad0500))





# [1.33.0](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/compare/v1.32.3...v1.33.0) (2020-05-15)


### Features

* handle redraw 204 blank response ([a37d910](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/a37d9103d672d9ea8bda6afc8998aeb64f75332f))





## [1.32.3](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/compare/v1.32.2...v1.32.3) (2020-05-14)


### Bug Fixes

* hyperlink and offset benefits cosmetic defects ([de40a2b](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/de40a2b9dd40ec2d01d8412bde31c74d5a945de3))





## [1.32.2](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/compare/v1.32.1...v1.32.2) (2020-05-14)


### Bug Fixes

* change to remove disc info in review page for curr & var loans ([4f2aa34](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/4f2aa34555d2490eb1523f876d7583bd2a989a47))





## [1.32.1](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/compare/v1.32.0...v1.32.1) (2020-05-14)

**Note:** Version bump only for package @wdpui-sirius/securedlendingservicing-mono-repo





# [1.32.0](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/compare/v1.31.0...v1.32.0) (2020-05-14)


### Features

* sagas to read result with errors ([fa22dad](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/fa22dad864b69f5c964ae6e1cb85dc00cf210f8e))





# [1.31.0](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/compare/v1.30.5...v1.31.0) (2020-05-14)


### Bug Fixes

* confirmation page fix ([4ef03ab](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/4ef03ab33b7d82830ef13d1cd346d501e642534e))
* confirmation page fixes ([0d0ddd3](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/0d0ddd38e00c3ef716740e36785b557bcadc064a))


### Features

* adding loader for submit and timeout for scroll ([5d8766f](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/5d8766fea30127db8c7e0ec3e94b4713620e1301))





## [1.30.5](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/compare/v1.30.4...v1.30.5) (2020-05-13)

**Note:** Version bump only for package @wdpui-sirius/securedlendingservicing-mono-repo





## [1.30.4](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/compare/v1.30.3...v1.30.4) (2020-05-13)

**Note:** Version bump only for package @wdpui-sirius/securedlendingservicing-mono-repo





## [1.30.3](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/compare/v1.30.2...v1.30.3) (2020-05-12)


### Bug Fixes

* al lconflicts resolved ([083db18](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/083db180a912f740169edd4a52e48407bc001f97))
* changes after conflicts ([c8c9f44](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/c8c9f4465fcf0dae5246b61d33c37f7c24a290dc))
* changes as per comment ([caea06e](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/caea06ebb6ecfae29cf625d702b2618589ec77a5))
* conflict resolved ([92124b6](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/92124b6d86815c8df906e64d4075100ae1e9a399))
* conflicts resolved ([7e0503a](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/7e0503a1642f072b9c9fa458fd47730de4deab5b))
* conflicts resolved ([25f3ced](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/25f3cedabef5d90550ab9d23c6238ffe6518a113))
* cosmetic issue ([731c3b5](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/731c3b5e6b60cf1a9bf2820e410b0bcc9e175abc))
* cosmetic issues ([39af7c8](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/39af7c8c474222c1f895f09e0c6909fd75656589))
* cx changes conflict resolved ([3b0e565](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/3b0e565b66dd574b8307d7ea903639c480307434))
* did suggesdted changes accrdingly ([621d19b](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/621d19bae8acbfb88e2c72134bfd47bcdc6bfae6))
* floating footer problem solved ([3ea6b85](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/3ea6b8548d7b34c8252b207b70e68832419f4649))
* made footer as per zeplin ([5479f82](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/5479f827da9cf3be1283713c79a9ba91e6db9294))
* theme applied to colour ([c056e51](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/c056e516f9bca0d7a87094f8647cd42bdaee7f74))
* trial ([6140bfa](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/6140bfa29340967d6fb4011f7c515c16eea34e69))
* trial ([6448c02](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/6448c024fd51fc0d928ad14cd21e39eebbe75cd9))





## [1.30.2](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/compare/v1.30.1...v1.30.2) (2020-05-12)


### Bug Fixes

* 9869 reverting changes ([30ba9da](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/30ba9da0dee5d1f5bbf6307e5663532196c44277))
* fixes to verify error scenario ([927730f](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/927730f1ae67f222f9c4c5a7f7faaf87d0f008d3))
* minor fixes ([b4da3d8](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/b4da3d8a20b61079e9b73640ee05cd211c82522f))
* revert changes ([5d6fbe4](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/5d6fbe43bc9db71c7e1fbc670efe3562711de6f4))
* review comment fixes ([78e7120](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/78e712039e414cc359d5631334c0e0022f57566a))
* sbgexp-9869 fix to show error page ([56a9ad2](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/56a9ad280f1ef71696df984c000780a4c3ed200f))
* sbgexp-9870change to make variable loan correct for splits ([60683ab](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/60683ab91796317df7e0eeabcc3cadec59ef72ed))
* sbgexp-9934 text fixes ([be828bc](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/be828bcbbc6999ce1a72cf3034e132027a646523))
* sbgexp-9951 fix to redirect to proper page ([b3b2e2b](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/b3b2e2bc47cf4893bd0af45026250428e524b2f1))
* sbgexp-9951 remove uncessary params ([8b3c4f2](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/8b3c4f246da04f008d9ce7f72c80895557290fdb))
* to show proper discount text ([68934e8](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/68934e8f1c626b1a360c7787aac5bb2076a453a8))





## [1.30.1](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/compare/v1.30.0...v1.30.1) (2020-05-12)


### Bug Fixes

* audit fixes and small defect fixes ([b065367](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/b065367ea2c423a1fab8b3287d0d5c994a2f9c05))
* defect fixes ([39fcbdd](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/39fcbddb7f303ed203d7e074f82ca9f336a4b3b9))
* package fix and calculation for loan balance ([e496d8b](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/e496d8bb390781a346fd45f9dd4e7fc923f79b34))
* review comments to handle scrolling ([0e4d642](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/0e4d6420a7da749366e4971c3fe8e03c3b4c37de))





# [1.30.0](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/compare/v1.29.0...v1.30.0) (2020-05-08)


### Bug Fixes

* audit fix ([cc2f4a4](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/cc2f4a42251ec13196b3986409e86de00ace700b))
* text defect fix ([bd27d35](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/bd27d356b6b268fb4340c1d548793427aa8e1859))


### Features

* round upto 2 decimal places ([80d6963](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/80d6963de3158ddba861d2ea89c0dbd355b86625))





# [1.29.0](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/compare/v1.28.3...v1.29.0) (2020-05-07)


### Features

* moving back code from master spa to micro spa for contexts ([68bcadf](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/68bcadf70f9c8ed337e612d862b9c268c396ba80))
* reading discount rate and package rate from config ([ee629fb](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/ee629fbd3e563f7670a803d46946a76aa079303a))





## [1.28.3](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/compare/v1.28.2...v1.28.3) (2020-05-07)


### Bug Fixes

* css changes ([d9dfe3e](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/d9dfe3ef1b341f66e233693c38c779938abef65e))
* defect fix to show proper values in review page ([27c6315](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/27c6315d150c0d639a04ea2833994a28ac71facb))
* sbgexp-9935 text changes ([3e5aebb](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/3e5aebb8b8cc8c17b11e92cc7cc6c83a5c5e8c93))
* to show proper sign n review page ([0b71766](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/0b717668ba91ea84b4042a32bca756e1cb7f4163))





## [1.28.2](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/compare/v1.28.1...v1.28.2) (2020-05-06)


### Bug Fixes

* moved context handover fetching to master spa ([acdd32d](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/acdd32d7bd1574ffb0a61aaf290a41d21d38a92c))





## [1.28.1](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/compare/v1.28.0...v1.28.1) (2020-05-06)

**Note:** Version bump only for package @wdpui-sirius/securedlendingservicing-mono-repo





# [1.28.0](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/compare/v1.27.1...v1.28.0) (2020-05-06)


### Features

* submit body to check if no package exists ([75cc0da](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/75cc0da67ceb6d0173ab19b0a2066bfff6e800cd))





## [1.27.1](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/compare/v1.27.0...v1.27.1) (2020-05-05)


### Bug Fixes

* defect fixes ([ae305f4](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/ae305f4a3a744f944220b598511481f24f900b98))





# [1.27.0](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/compare/v1.26.0...v1.27.0) (2020-05-05)


### Features

* accessibility defects fix ([eec5225](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/eec5225503be17b146ed38c9fd5511ad55f2e454))
* calculation issues fix ([ad256e1](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/ad256e13bf27561dd851065e9f4046e9f7731b65))





# [1.26.0](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/compare/v1.25.0...v1.26.0) (2020-05-04)


### Features

* added phone number in href ([41eadac](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/41eadac4ebfcf6ae2b0b89d69e9f299a948f1f9b))
* use package indicator for PMT calculation ([41f477d](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/41f477d72811f94fc7063ff829cbac2c82b88b5b))





# [1.25.0](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/compare/v1.24.3...v1.25.0) (2020-05-04)


### Bug Fixes

* mortgage quotes api issue to replace node ([c072b03](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/c072b03900943d40aeabb197abf0c6f7646e0aa5))


### Features

* reading repayment type from selected one ([1007287](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/1007287b122bb2bdadd168f4812c7167eb721ec6))





## [1.24.3](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/compare/v1.24.2...v1.24.3) (2020-05-01)


### Bug Fixes

* remaining term reading from exp api ([0970012](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/0970012648d4667fe4e918033bffd35d3a17974d))





## [1.24.2](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/compare/v1.24.1...v1.24.2) (2020-04-30)


### Bug Fixes

* fixes for next btn on Redraw popUp not working for only 1 account ([072f005](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/072f0056f7467217b975ae9a12c0552beb68e304))
* sgbexp-9858 Date format fixes ([4d87831](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/4d87831f109b9068161e3f48472c491a42cee55f))





## [1.24.1](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/compare/v1.24.0...v1.24.1) (2020-04-30)

**Note:** Version bump only for package @wdpui-sirius/securedlendingservicing-mono-repo





# [1.24.0](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/compare/v1.23.1...v1.24.0) (2020-04-29)


### Bug Fixes

* context ref id expired scenario handling ([8aef4ab](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/8aef4abb05946b05376c61be241e4d3ef50a9826))
* moved selectors ([220e51f](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/220e51f46dc444fe5f6fe92be11959c5082788b3))
* refactor as per review comment ([cca1fa8](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/cca1fa8f338934df3cd081ab2768ac24379bcf49))


### Features

* changed context handover api to refer sirius core api ([d1512b3](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/d1512b386b22f1d033fe14494ba47f3fbf957b87))
* changed context handover api to refer sirius core api ([32d1600](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/32d1600081c23424cc52310eea7b9204ae5bbaaa))





## [1.23.1](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/compare/v1.23.0...v1.23.1) (2020-04-28)


### Bug Fixes

* fixed Error page txt ([03566b6](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/03566b658ccef5db3a8896e992ecee9394a4be63))
* show-hide button conditionally ([eac24ec](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/eac24ecbd2f074796893b747aa0fe247730e0ab3))





# [1.23.0](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/compare/v1.22.2...v1.23.0) (2020-04-27)


### Features

* adding validation message if quotes failed error ([f4ed094](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/f4ed0945012a4dfe8bdadbc51916ed8ac902ce5e))





## [1.22.2](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/compare/v1.22.1...v1.22.2) (2020-04-27)


### Bug Fixes

* eligibility changes to be in sync with exp and cap api ([bdae5fe](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/bdae5fe5319e609500ed13f2402d40a5f4d83f3a))





## [1.22.1](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/compare/v1.22.0...v1.22.1) (2020-04-23)


### Bug Fixes

* eligibility changes to be in sync with exp and cap api ([c2df276](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/c2df2764d3e27f9eb353a0322ffe885ce69a46b5))





# [1.22.0](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/compare/v1.21.0...v1.22.0) (2020-04-17)


### Features

* changed to read selected year term ([7e2e13e](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/7e2e13eedad70d8f584d26cc51c15b894415ea22))
* reading context latest form exp api ([8012ff5](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/8012ff5f2164ab99692fe9d2d7d519631bb1a630))
* reading selected redraw account and sending to exp api ([ddafb37](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/ddafb37b64ee002dd61551eb549ab21c5bc6dfc1))
* refactor sagas request body and moved to selector ([400aff9](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/400aff9edc38e0227130f4ae694e09fcd31f67da))
* sagas check avail balance logic ([d70fe9d](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/d70fe9da7536897d41a80b79cc3114919cab757d))
* swagger ui changes integration ([453a934](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/453a934799e38ed68cb8af16a7e43cad75592edd))





# [1.21.0](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/compare/v1.20.0...v1.21.0) (2020-04-07)


### Features

* fixes defects ([5becd9c](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/5becd9c77d10ea117943822e45c1283f68f7c665))





# [1.20.0](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/compare/v1.19.0...v1.20.0) (2020-04-07)


### Features

* fixes defects ([61c46a5](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/61c46a58dcd3bd888c9cd4b3c8e037d399ebca06))





# [1.19.0](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/compare/v1.18.0...v1.19.0) (2020-04-07)


### Features

*  back navigation ([23a63d1](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/23a63d18dc27e81187c07100e3653dc1d846aa0e))
* fixes for validations and updated test ([895bc41](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/895bc412a32152294c9b15b09a46ea7782b0a597))
* reading product name from current loan details ([f59ee07](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/f59ee0755486f3950cec764ea221f56ef990b258))





# [1.18.0](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/compare/v1.17.1...v1.18.0) (2020-04-03)


### Features

* call fetch quotes only if its within valid date ([037ad3a](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/037ad3a422606659544b32a5985c22e6411feb78))





## [1.17.1](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/compare/v1.17.0...v1.17.1) (2020-04-03)

**Note:** Version bump only for package @wdpui-sirius/securedlendingservicing-mono-repo





# [1.17.0](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/compare/v1.16.1...v1.17.0) (2020-04-02)


### Bug Fixes

* defect fix for popup ([4b9efa8](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/4b9efa867aabd322493922183ac8b0ce5191b4b0))


### Features

* reading from config fee details ([ad3e0c8](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/ad3e0c8e9af695a8a11514d3d2a82f064aa19424))





## [1.16.1](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/compare/v1.16.0...v1.16.1) (2020-03-31)


### Bug Fixes

* fixed loan page input field width change ([2a21610](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/2a2161090a7509dd1984e78519bc4c3bed9e3562))
* package updation and flexi text conditionally ([9065371](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/90653713224e5eb8d2d221adfcd434325386d280))





# [1.16.0](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/compare/v1.15.0...v1.16.0) (2020-03-25)


### Features

* tagging with sub section and sub sub section ([df19894](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/df198940494134cfc63624602b16e368b973efb1))





# [1.15.0](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/compare/v1.14.0...v1.15.0) (2020-03-25)


### Bug Fixes

* replace entities for mortgagequotes ([3a293ce](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/3a293ce98f68c1aa32ea15bc3d42caeca9a12d9a))


### Features

* remove console ([42161d7](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/42161d74a52fd3f7925fb965a03c4f969e1c8091))





# [1.14.0](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/compare/v1.13.1...v1.14.0) (2020-03-25)


### Features

* reading contracted date from api ([bd150a5](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/bd150a5f10374d0a69dc49073d31e255b38f1f46))
* remove console ([9d3346b](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/9d3346beba63dbaa8d8a1f0677e447277e762447))





## [1.13.1](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/compare/v1.13.0...v1.13.1) (2020-03-24)


### Bug Fixes

* conditionally passing package type for 400 error ([8ef7cb9](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/8ef7cb9633ab9d58decd45781162e0ee3a76bcda))





# [1.13.0](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/compare/v1.12.0...v1.13.0) (2020-03-24)


### Features

* error scenarios for eligibility ([8531e96](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/8531e96c5a947cdc45d2db58619516d5a6a47e66))





# [1.12.0](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/compare/v1.11.4...v1.12.0) (2020-03-24)


### Features

* 429 multiple request error ([313736f](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/313736f396e2c7ad3be0267b1805147559837109))





## [1.11.4](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/compare/v1.11.3...v1.11.4) (2020-03-22)


### Bug Fixes

* params sending to exp api ([d100bd4](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/d100bd45fbf285baf53ce6e89fb648e797259f28))
* ui defects fixes ([43c366e](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/43c366e7e96c1f88f6a69e27d5dcc7f66ed0d2a7))





## [1.11.3](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/compare/v1.11.2...v1.11.3) (2020-03-19)

**Note:** Version bump only for package @wdpui-sirius/securedlendingservicing-mono-repo





## [1.11.2](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/compare/v1.11.1...v1.11.2) (2020-03-19)

**Note:** Version bump only for package @wdpui-sirius/securedlendingservicing-mono-repo





## [1.11.1](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/compare/v1.11.0...v1.11.1) (2020-03-17)


### Bug Fixes

* data fix for mortagge quotes ([92438c8](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/92438c86cc8b1c3f1b6cff4c97e6339248115e78))
* swagger changes to read new entities ([4beb4dc](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/4beb4dcc3dfd313a3f8a9e6d8fdaea45ae4740c6))
* updated loader component ([7fc7e1d](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/7fc7e1de452159abd05da18d05fc2843ad9cd94b))





# [1.11.0](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/compare/v1.10.0...v1.11.0) (2020-03-17)


### Features

* reading package indicator from context api ([1c1776f](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/1c1776fa5b073b23d3f3a8f44bd52d01b3b2e446))





# [1.10.0](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/compare/v1.9.1...v1.10.0) (2020-03-16)


### Bug Fixes

* code fix for removing unused ([4dd0bda](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/4dd0bda5b08948d76fa62adf4f08259924cbe423))
* current loan details sagas ([6f7462c](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/6f7462cfe8f5b6dedb02531566dc38cd4e35924a))
* fixed formatting and added loan calculation for interest only ([b34fecc](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/b34fecceac66ae9acf15f8482db8076c8109801a))
* fixed option loan page next button condtion updated ([4da468f](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/4da468fdbd91448a4f41d8b6f2e76a8ab5938973))
* hint text for split amount ([5cbf440](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/5cbf440c5e8f69820aaa5a6c813bbf9d8356b458))
* mortgageQuotes service change & loader ([6f25418](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/6f254185da41505b9a4e47b71a0c7c4b21662fb0))
* show next button visiblity fixes on Interest Page ([8e9bb0c](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/8e9bb0c8c16767fda5b8ee545c9753909cc14d92))
* updated fixed option loan container test cases ([15f1fd2](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/15f1fd2b82a1a674038ee112cdbda59f0ac44aba))
* updated test cases ([77eb081](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/77eb081bc1a66b1a52b091004bf92bb7cf7d18e7))
* updated testcases for sagas ([c7f7a5a](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/c7f7a5ae70a34fe02721b5ee6312fdf019c9cde8))


### Features

* added new sagas ([eeef7df](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/eeef7df15a273ad16132754f1e21cb668318da58))
* changed to add loan balance in case of component change ([b63d73a](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/b63d73a69e2e4a292ce1c7488638114f28498fec))
* handling eligibility data ([f491fc7](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/f491fc796de026e0f1361ba742f5448b07328a60))





## [1.9.1](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/compare/v1.9.0...v1.9.1) (2020-02-28)


### Bug Fixes

* showing split fixed and variable component from selectors ([ac9b835](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/ac9b8357285ab3eb5c8b8b9095eebcb59aef763b))





# [1.9.0](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/compare/v1.8.1...v1.9.0) (2020-02-27)


### Bug Fixes

* as per review comments to use boolean filter ([b8cc149](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/b8cc1494443f0b909cb6c129a6693b9cd58b2caa))
* check for empty before calling service ([6a10164](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/6a10164a845f8791c7b4915975536bd9f32868fd))
* fixed lodash functions as per review comments ([7817453](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/78174536f8f30824493876a55102ab8450a7cb00))
* modal popup ([4676afd](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/4676afda79fd9d0b8802dad3ae5e3aa5c887fa3e))


### Features

* added test case and refactored ([20110ab](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/20110ab44ba78049d1f522debad0b4cb2aa76b68))





## [1.8.1](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/compare/v1.8.0...v1.8.1) (2020-02-19)


### Bug Fixes

* set exception messsage when redraw indictaor is set ([c82ca28](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/c82ca28e417eac5afa8632afac0ac6423a69a3d6))





# [1.8.0](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/compare/v1.7.1...v1.8.0) (2020-02-18)


### Bug Fixes

* added reshma component ([fe12e8c](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/fe12e8c8a596535cb7ced861543e04a47dc9a9e4))
* adding reshma code on navigate next ([f2b81d1](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/f2b81d12ab66bd0f8b58bf9d194cc48a355310b4))
* changed as per comments ([527bfff](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/527bfffce3aef09b66028e1e5eb83c2be9734651))
* changed as per comments ([b2105df](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/b2105dfff10ab1d4b65240f74ea15df8531c7fd7))
* fixedOption page coverage updated ([a37f249](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/a37f24925b39cd344a1d2f31e15ac9cc77b567c0))
* getting values from mock instead of default props ([e9546ff](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/e9546ff594c2a3050ac04f38388f5f587f250be5))
* moved redraw popup to folder ([13b4c25](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/13b4c25a862ed7903496624041e5b93ff98c7aba))
* refactor components ([00f6c9d](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/00f6c9d185e117691be8b2ff55fc86f1c07472e3))
* refactored styles and component for using common styles ([c20c0b1](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/c20c0b1073b0b29a54d50a0c96c326baa163c3b3))


### Features

* fixed loan options screen merge from sagar reshma ([335eb65](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/335eb65965ade44b912b747e470d5a8d5353436c))





## [1.7.1](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/compare/v1.7.0...v1.7.1) (2020-02-12)

**Note:** Version bump only for package @wdpui-sirius/securedlendingservicing-mono-repo





# [1.7.0](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/compare/v1.6.1...v1.7.0) (2020-02-10)


### Bug Fixes

* reverted code from sagar branch ([4f2f835](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/4f2f8357916c6bbb26677d1d4eda2ab25015fd47))


### Features

* merge changes for secured lending from sameer ([dd1ba54](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/dd1ba545003217c4e80273a0d639026d48e019aa))
* new component introduced for Review details by Sameer ([1a00560](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/1a005602ad9ca804fa07a94338f27ff42be2e458))
* sbgexp-8211 ([dc111d3](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/dc111d32879d2b983c0caca5b3c8c4e9de733a4c))
* sbgexp-8211 ([5a78cbd](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/5a78cbda54c44d2f2ec3a6ff0d398c58d8be9654))
* sbgexp-8211 ([6be8728](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/6be8728b032f68aab658a147661215c5bf004d70))
* sbgexp-8211 ([fd53898](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/fd5389887fbeefc966f6a6dfac7ab490e3922b81))
* sbgexp-8211 ([0986ed2](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/0986ed2a08b8eb0bc4a73c22f1e76a3745b34f93))
* sbgexp-8211 ([bb569ea](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/bb569eab74ba13b11cc33c564f0db0b5e667e0d2))
* sbgexp-8211 ([0d19375](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/0d19375360f37e3c0f67ee55f0242d8f22c4ea69))
* sbgexp-8211 ([7de598f](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/7de598f199c26f593bfea8620de23cb572712b1e))
* sbgexp-8211 ([41245fe](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/41245fe6994a5e847122f410cd36450d29e65cc1))
* sbgexp-8211 ([78b92dc](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/78b92dcf1312dbb987909fe1748e17a6004c610e))
* sbgexp-8211 ([21b2e9f](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/21b2e9f684a9766f27768a0edeb50e6f3b5ec133))
* sbgexp-8211 ([1998408](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/1998408568b2b20e890aa21b949ccfc2c87e93d8))
* sbgexp-8211 ([75c6107](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/75c6107ecf95296f86bf6e863fd8b1331a8134dd))
* sbgexp-8211 committing snapshots ([45b47ee](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/45b47ee54f0126fd664569a93a2a8fb7308dcc19))
* sgbexp-8211 ([4d82d5c](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/4d82d5c6f1bf63254943e36d26c3fb129bef6122))





## [1.6.1](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/compare/v1.6.0...v1.6.1) (2020-02-05)

**Note:** Version bump only for package @wdpui-sirius/securedlendingservicing-mono-repo





# [1.6.0](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/compare/v1.5.0...v1.6.0) (2020-02-03)


### Bug Fixes

* changed landing page pdf url ([dac661f](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/dac661f2519112e0f8bff6786e1dab17ec669f6f))
* changes as per cx ([4821e16](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/4821e16d5e861327c4c3c2621c5e26d6e683548a))
* component changes ([9307f97](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/9307f9764e1b2da6e5142bde0f118862a6c0ae99))
* feedback comments ([82b80fa](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/82b80faf728ea0e2773c24ee309b8d6d4f4cc521))
* fixing bullet list item with styled rendering ([e88facd](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/e88facd82154f66ffce3047f3a3c3ed850434c60))
* landing page text changes & popup text changes ([71ddb21](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/71ddb21befb0002d0c813d813813c9775884b04c))
* landing page ui change & popup text changes ([444981e](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/444981efb230bc8036290cddad90a7c66562825d))
* media query for showing hiding call us button ([aea2553](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/aea2553459d79b7b564325aecb30138161e9ea8a))
* rate component ([95eafe1](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/95eafe1cf09288eb7fc068b5c03b94bf0b3fdf6d))
* style for component moved which is not common ([56b8347](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/56b8347710db55d4c0c7cbbe8e5bfc7df35da7ec))


### Features

* added new component for interest rate selection ([e287e01](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/e287e014e18732399fe9974cf779e4209d328ad8))
* changed button style ([5682781](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/56827817150e21f24157301a66be42739a9b7520))
* changed list item rendering for landing page ([1073c5b](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/1073c5b19cca9b6ab38a73dc462641a4a50df304))
* changed list item rendering for landing page ([eca6557](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/eca6557c6308c5e4525a9bd94f3b131b085f181c))
* components added for interest rate ([8f22fc8](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/8f22fc8d22ce586403183fabe60936ac442cc6a0))
* fixes for styling for different scenarios ([6bb0143](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/6bb0143b75807222d848d8c30a5f46c59e42c7ad))
* updated styles ([1aa9563](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/1aa95638384d0cbc4e68c2fa1c65f701e1d83e3a))





# [1.5.0](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/compare/v1.4.0...v1.5.0) (2020-01-09)


### Bug Fixes

* changed as per review comments ([8d4c8d2](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/8d4c8d25910040fbcc7f41ba7f4b3ca2b6c7701b))
* changes in exp api to remove appparam and response change ([90999fe](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/90999fee97e9220f50785136b3767208e32a3d38))
* moved code to containers and also removed appparams ([4ed2721](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/4ed2721d5b9667c14557f366956a6c759d6b1ebd))
* ui change for popup ([ef3103b](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/ef3103bc326c347109c406159070940030f62065))


### Features

* changed landing page changes and added new component ([74ea97a](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/74ea97a31bea7c99b8b58e7bc60641b2e6ab3b74))





# [1.4.0](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/compare/v1.3.0...v1.4.0) (2020-01-08)


### Features

* changed landing page content ([d02350f](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/d02350f44c0e4a6ad1d5455a12dcd701b47eac6a))





# [1.3.0](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/compare/v1.2.1...v1.3.0) (2020-01-07)


### Features

* new ui for landing ([3040591](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/30405918fe4598f0c8b5c5a40079c553e187a18b))
* remove home unused component ([d419209](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/d419209ba14fcb66e75bbaab89dc4866e7bdd9cd))
* updated test snapshot and modified ui ([debffba](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/debffbab354d0750cb9b5596fee6eb40c37f24c7))





## [1.2.1](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/compare/v1.2.0...v1.2.1) (2020-01-07)

**Note:** Version bump only for package @wdpui-sirius/securedlendingservicing-mono-repo





# [1.2.0](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/compare/v1.1.1...v1.2.0) (2020-01-07)


### Bug Fixes

* move reducer ui slice to the master app ([7ec27c9](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/7ec27c9d881f6440a9405829b7df6c7e78dc1ebd))


### Features

* added ui selector ([6dbdc3d](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/6dbdc3d2011e1eb16aec3a0e3c9bc2e81161307a))





## [1.1.1](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/compare/v1.1.0...v1.1.1) (2020-01-06)

**Note:** Version bump only for package @wdpui-sirius/securedlendingservicing-mono-repo





# 1.1.0 (2020-01-06)


### Bug Fixes

* test ([fabc086](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/fabc086809b845487f05d763a466104d1074f37a))


### Features

* **analytics:** enable analytics and ui changes ([11e61a7](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/11e61a7d98f6f292937c395ddabe7a0ea1555889))
* **change:** route changes and config changes ([712becb](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/712becb0cdd42eeaeabe00783bdafb7ddf0052f8))
* **modal popup:** new component introduced ([ba74a34](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/ba74a344ddbc0ae76ffdbdc69389c5549b21b110))
* **modal popup:** renamed component ([b992646](http://bitbucket.srv.westpac.com.au/ui-www/wdp-ui-sirius-securedlendingservicing/commits/b99264641a0a6cbf854fd2f5c3bf8aa720014c71))
