// jest.config.js
module.exports = {
  verbose: true,
  coverageDirectory: 'coverage/',
  setupFilesAfterEnv: ['<rootDir>/test-support/setupTests.js'],
  snapshotSerializers: ['enzyme-to-json/serializer'],
  collectCoverageFrom: [
    'packages/library/src/**/*.js?(x)',
    '!**/__snapshots__/*',
    '!**/__fixtures__/*',
    '!/node_modules/',
    '!**/index.js',
    '!**/index.jsx',
    '!/test-support/',
  ],
  coverageThreshold: {
    global: {
      branches: 80,
      functions: 80,
      lines: 80,
      statements: 80,
    },
  },
  coveragePathIgnorePatterns: [
    '/node_modules/',
    '/packages/example/node_modules/',
    '/packages/library/node_modules/',
    '/umr/node_modules/',
    '/test-support/',
  ],
  coverageReporters: ['json', 'lcov', 'text', 'html'],
  moduleNameMapper: {
    '.*\\.(css|less|styl|scss|sass)$': '<rootDir>/test-support/mocks/css.js',
    '.*\\.(jpg|jpeg|png|gif|eot|otf|webp|svg|ttf|woff|woff2|mp4|webm|wav|mp3|m4a|aac|oga)$':
      '<rootDir>/test-support/mocks/binary.js',
  },
  testMatch: [
    '**/__tests__/**/*(test|spec).[jt]s?(x)',
    '**/?(*.)+(spec|test).[jt]s?(x)',
    '!**/__tests__/**/*.e2e.js',
    '!**/?(*.)+(spec|test).e2e.js',
  ],
};
