package au.com.stgeorge.mbank.model.common;

import org.apache.commons.lang.builder.ReflectionToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

/**
 * Payee receipts response
 * 
 * @author C38854
 *
 */
@JsonInclude(Include.NON_NULL)
public class BTTileStatusResp implements IMBResp {

	private static final long serialVersionUID = -4963733439114624716L;

	private RespHeader header;

	private BTSuperSearchResp btSuperSearchResp;

	
	public RespHeader getHeader() {
		return header;
	}


	public void setHeader(RespHeader header) {
		this.header = header;
	}


	public BTSuperSearchResp getBtSuperSearchResp() {
		return btSuperSearchResp;
	}


	public void setBtSuperSearchResp(BTSuperSearchResp btSuperSearchResp) {
		this.btSuperSearchResp = btSuperSearchResp;
	}


	@Override
	public String toString() {
		return ReflectionToStringBuilder.toString(this, ToStringStyle.MULTI_LINE_STYLE);
	}

}
