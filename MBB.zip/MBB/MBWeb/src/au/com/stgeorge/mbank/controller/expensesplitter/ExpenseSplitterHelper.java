package au.com.stgeorge.mbank.controller.expensesplitter;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Date;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import au.com.stgeorge.framework.common.logging.Logger;
import au.com.stgeorge.framework.common.util.StringMethods;
import au.com.stgeorge.ibank.businessobject.BusinessException;
import au.com.stgeorge.ibank.expensesplitter.businessobject.valueobject.ExpenseSplitterDashboardVO;
import au.com.stgeorge.ibank.expensesplitter.businessobject.valueobject.ExpenseSplitterUpdateVO;
import au.com.stgeorge.ibank.expensesplitter.businessobject.valueobject.ExpenseSplitterVO;
import au.com.stgeorge.ibank.expensesplitter.dao.valueobject.Expense;
import au.com.stgeorge.ibank.expensesplitter.dao.valueobject.ExpenseContact;
import au.com.stgeorge.ibank.expensesplitter.dao.valueobject.ExpenseGroup;
import au.com.stgeorge.ibank.expensesplitter.dao.valueobject.ExpenseSearch;
import au.com.stgeorge.ibank.expensesplitter.dao.valueobject.ExpenseSplitterContact;
import au.com.stgeorge.ibank.util.DateUtils;
import au.com.stgeorge.ibank.util.StringUtil;
import au.com.stgeorge.ibank.valueobject.Account;
import au.com.stgeorge.ibank.valueobject.OutstandingAuthorisations;
import au.com.stgeorge.ibank.valueobject.TransactionHistory;
import au.com.stgeorge.ibank.valueobject.TransactionInfo;
import au.com.stgeorge.ibank.valueobject.transfer.IBankCommonData;
import au.com.stgeorge.mbank.model.accountinfo.CardAuthResp;
import au.com.stgeorge.mbank.model.accountinfo.TranDetailResp;
import au.com.stgeorge.mbank.model.accountinfo.TranHistoryResp;
import au.com.stgeorge.mbank.model.common.ErrorInfo;
import au.com.stgeorge.mbank.model.common.RespHeader;
import au.com.stgeorge.mbank.model.request.expensesplitter.ContactAmountDetailReq;
import au.com.stgeorge.mbank.model.request.expensesplitter.ContactReq;
import au.com.stgeorge.mbank.model.request.expensesplitter.ExpenseGroupReq;
import au.com.stgeorge.mbank.model.request.expensesplitter.ExpenseGrpAmountPaidReq;
import au.com.stgeorge.mbank.model.request.expensesplitter.ExpenseReq;
import au.com.stgeorge.mbank.model.request.expensesplitter.ExpenseSplitterReq;
import au.com.stgeorge.mbank.model.response.SuccessResp;
import au.com.stgeorge.mbank.model.response.expensesplitter.ContactGroupDetailResp;
import au.com.stgeorge.mbank.model.response.expensesplitter.ContactListResp;
import au.com.stgeorge.mbank.model.response.expensesplitter.ContactResp;
import au.com.stgeorge.mbank.model.response.expensesplitter.ExpenseContactListResp;
import au.com.stgeorge.mbank.model.response.expensesplitter.ExpenseGrpListResp;
import au.com.stgeorge.mbank.model.response.expensesplitter.ExpenseResp;
import au.com.stgeorge.mbank.model.response.expensesplitter.ExpenseSplitterDashboardResp;
import au.com.stgeorge.mbank.model.response.expensesplitter.ExpenseSplitterResp;
import au.com.stgeorge.mbank.model.response.expensesplitter.ExpenseSplitterTransHistResp;
import au.com.stgeorge.mbank.util.MBAppHelper;
import au.com.stgeorge.mbank.util.MBAppUtils;



@Service
public class ExpenseSplitterHelper {
	
	@Autowired
	private MBAppHelper mbAppHelper;

	private String DATE_FORMAT="yyyy-MM-dd";
	
	private static final String SPLIT_OPTION_EQUAL ="1";
	
	private static final String SPLIT_OPTION_UNEQUAL ="2";
	
	protected ExpenseSplitterVO populateExpenseSplitterVO(ExpenseSplitterReq request,IBankCommonData commonData) throws BusinessException{
		Logger.info("Starting to populate expense splitter vo", this.getClass());
		ExpenseSplitterVO vo = new ExpenseSplitterVO();
		vo.setExpenseGrpName(request.getExpenseGrpName().trim());
		if(StringMethods.isValidString(request.getExpGrpID())){
			vo.setExpGrpId(Long.parseLong(request.getExpGrpID()));	
		}
		
		if(request.getExpenseList() != null && !request.getExpenseList().isEmpty()){
			List<Expense> expenses = new ArrayList<Expense>();
			for(ExpenseReq expReq: request.getExpenseList()){
				Expense exp = new Expense();
				exp.setExpenseName(expReq.getExpenseName() != null ? StringMethods.removeLeadingZero(expReq.getExpenseName()).trim() : null);
				exp.setTotalAmt(expReq.getExpenseAmt() != null ? new BigDecimal(expReq.getExpenseAmt()) : null);
//				exp.setExpenseDate(expReq.getExpenseDate() != null ? DateUtils.StringtoDate(expReq.getExpenseDate(), DATE_FORMAT) : null);
				exp.setExpenseDate(new Date());
				exp.setCreatedBy(commonData.getUser().getGCISNumber());
				exp.setGCISNum(commonData.getUser().getGCISNumber());
				exp.setExpID(expReq.getExpID());
				expenses.add(exp);
			}
			vo.setExpenses(expenses);
		}
		if(request.getContactList() != null && ! request.getContactList().isEmpty()){
			List<ExpenseSplitterContact> contacts = new ArrayList<ExpenseSplitterContact>();
			for(ContactReq contactReq:request.getContactList()){
				ExpenseSplitterContact expContact = new ExpenseSplitterContact();
				expContact.setContactName(contactReq.getContactName() != null ? StringMethods.removeLeadingZero(contactReq.getContactName()).trim() : null);
				if(StringMethods.isValidString(contactReq.getContactID()))
					expContact.setContactID(Long.parseLong(contactReq.getContactID()));
				expContact.setContactNum(contactReq.getContactMobileNum());
				expContact.setMeContact(contactReq.isMeContact());
				if(SPLIT_OPTION_EQUAL.equalsIgnoreCase(request.getSplitOption())){
					expContact.setContactAmt(contactReq.getTotalAmt() != null ? new BigDecimal(contactReq.getTotalAmt()) : new BigDecimal(contactReq.getContactAmt()));
				}
				else if(SPLIT_OPTION_UNEQUAL.equalsIgnoreCase(request.getSplitOption())){
					expContact.setContactAmt(contactReq.getTotalAmt() != null ? new BigDecimal(contactReq.getTotalAmt()) : new BigDecimal(contactReq.getUnequalContactAmt()));
				}
				expContact.setGCISNum(commonData.getUser().getGCISNumber());
				expContact.setCreatedBy(commonData.getUser().getGCISNumber());
				expContact.setAmountPaid(contactReq.getAmtPaid() != null ? new BigDecimal(contactReq.getAmtPaid()) : null);
				expContact.setAmountDue(contactReq.getAmtDue() != null ? new BigDecimal(contactReq.getAmtDue()) : null);
				expContact.setSettled(contactReq.isSettled()?1:0);
				contacts.add(expContact);
			}
			vo.setContacts(contacts);
		}
		
		return vo;
	}
	
	protected ExpenseSplitterResp populateExpenseSplitterResponse(RespHeader header, ExpenseSplitterVO expenseSplitterVO)throws BusinessException {
		ExpenseSplitterResp response = new ExpenseSplitterResp(header);
		if(expenseSplitterVO != null){
			if(expenseSplitterVO.getContacts() != null && expenseSplitterVO.getContacts().size() > 0){			
				response.setExpGrpID(expenseSplitterVO.getExpGrpId());
				List<ContactListResp> contactList = new ArrayList<ContactListResp>();				
				for(ExpenseSplitterContact voContact : expenseSplitterVO.getContacts()){
					if(!voContact.isMeContact()){
						ContactListResp contactListResp = new ContactListResp();
						contactListResp.setContactName(voContact.getContactName());
						contactListResp.setContactID(voContact.getContactID());
						if(voContact.getAmountPaid() != null){
							contactListResp.setContactAmt(voContact.getContactAmt().subtract(voContact.getAmountPaid())); // update scenario
						}else{
							contactListResp.setContactAmt(voContact.getContactAmt()); // Create scenario
						}
						contactListResp.setContactMobileNum(voContact.getContactNum());
						contactListResp.setSettled(voContact.getSettled() == 1 ? true : false);
						contactListResp.setMeContact(voContact.isMeContact());
						if(expenseSplitterVO.getExpContacts() != null && expenseSplitterVO.getExpContacts().size() > 0){
							List<ExpenseContactListResp> expenseContactList = new ArrayList<ExpenseContactListResp>();						
							for(ExpenseContact voExpContact : expenseSplitterVO.getExpContacts()){
								if(voContact.getContactID().equals(voExpContact.getContactID())){
									ExpenseContactListResp expenseContactListResp = new ExpenseContactListResp();
									if(expenseSplitterVO.getExpenses() != null){
										for(Expense voExpense : expenseSplitterVO.getExpenses()){
											if(voExpContact.getExpID().longValue() == voExpense.getExpID().longValue()){
												expenseContactListResp.setExpenseName(voExpense.getExpenseName().trim());	
												if(voExpContact.getAmtPaid() != null){
													expenseContactListResp.setExpenseContactAmt(voExpContact.getTotalAmt().subtract(voExpContact.getAmtPaid()));
												}else{
													expenseContactListResp.setExpenseContactAmt(voExpContact.getTotalAmt());//create scenario
												}
											}
										}
									}
									expenseContactList.add(expenseContactListResp);
								}
							}
							contactListResp.setExpenseContactList(expenseContactList);
						}
						contactList.add(contactListResp);
					}
				}
				response.setContactList(contactList);
			}			
		}
		return 	response;
	}
	
	protected ExpenseSplitterDashboardResp populateExpenseSplitterDashboardResponse(RespHeader header, ExpenseSplitterDashboardVO expenseSplitterDashboardVO)throws BusinessException {
		ExpenseSplitterDashboardResp response = new ExpenseSplitterDashboardResp(header);
		if(expenseSplitterDashboardVO != null){
			response.setContactsCount(expenseSplitterDashboardVO.getTotalContacts());
			response.setTotalAmtDue(expenseSplitterDashboardVO.getTotalAmtDue());
			if(expenseSplitterDashboardVO.getContactSearchList() != null && expenseSplitterDashboardVO.getContactSearchList().size() > 0){			
				List<ContactListResp> contactList = new ArrayList<ContactListResp>();				
				for(ExpenseSplitterContact voContact : expenseSplitterDashboardVO.getContactSearchList()){
					ContactListResp contactListResp = new ContactListResp();
					contactListResp.setContactName(voContact.getContactName());
					contactListResp.setContactMobileNum(voContact.getContactNum());
					contactListResp.setContactID(voContact.getContactID());
					contactListResp.setAmtPaid(voContact.getAmountPaid());
					contactListResp.setTotalAmt(voContact.getContactAmt());
					contactListResp.setAmtDue(voContact.getAmountDue());
					contactListResp.setSettled(voContact.getSettled() == 1 ? true : false);
					contactList.add(contactListResp);
				}
				response.setContactList(contactList);
			}
			if(expenseSplitterDashboardVO.getExpenseSearchList() != null && expenseSplitterDashboardVO.getExpenseSearchList().size() > 0){
				List<ExpenseGrpListResp> expenseGrpList = new ArrayList<ExpenseGrpListResp>();				
				for(ExpenseSearch expenseSearch : expenseSplitterDashboardVO.getExpenseSearchList()){
					ExpenseGrpListResp expenseGrpListResp = new ExpenseGrpListResp();
					expenseGrpListResp.setExpenseGrpName(expenseSearch.getExpenseGrpName().trim());
//					expenseGrpListResp.setContactCount(expenseSearch.getNumContactsInGrp());
//					expenseGrpListResp.setAmtPaid(expenseSearch.getAmtGrpPaid());
//					expenseGrpListResp.setTotalAmt(expenseSearch.getTotalGrpAmt());
					expenseGrpListResp.setAmtDue(expenseSearch.getGrpAmtDue());
					expenseGrpListResp.setExpGrpID(expenseSearch.getExpGrpID());
					expenseGrpListResp.setSettled(expenseSearch.getSettled() == 1 ? true : false);
					expenseGrpList.add(expenseGrpListResp);
				}
				response.setExpenseGrpList(expenseGrpList);
			}
		}
		return 	response;
	}
	
	protected void populateTranHistoryResp(ExpenseSplitterTransHistResp resp, TransactionHistory tranHistory){
		if(tranHistory != null){
			TranHistoryResp transHistResp = new TranHistoryResp();
			transHistResp.setTranList(getTranHistoryResp(tranHistory));
			
			if(("Y").equalsIgnoreCase(tranHistory.getMoreToCome()))
				transHistResp.setHasMoreTran(true);					
			
			resp.setTranHistory(transHistResp);
		}
	}
	
	private List<TranDetailResp> getTranHistoryResp(TransactionHistory tranHistory){
		
		List<TranDetailResp> debitTranHistoryList = null; 
		TranDetailResp transactionDetail;
		
		if(tranHistory != null && tranHistory.getTransactions()!=null && tranHistory.getTransactions().size() > 0 ){
			
			debitTranHistoryList = new ArrayList<TranDetailResp>();
			ArrayList list=(ArrayList)tranHistory.getTransactions();
			Iterator it = list.iterator();
			while(it.hasNext()){
				//Iterating through all transactions
				transactionDetail = new TranDetailResp();
				TransactionInfo eachTransactionInfo=(TransactionInfo)it.next();
				String amtValue = "";
				BigDecimal amount = eachTransactionInfo.getAmount();
				if (amount !=null){
					if (amount.signum() == -1) {
						Logger.debug("It is Debit Transaction.",this.getClass());
						transactionDetail.setDebit(true);
						BigDecimal negatedAmt = amount.negate();
						amtValue=negatedAmt.toString();
						//Setting amount
						transactionDetail.setAmt(amtValue);
						//Setting date
						transactionDetail.setDate(eachTransactionInfo.getDate());
						//Setting Description
						if(StringMethods.isValidString(eachTransactionInfo.getDescription1()))					
							transactionDetail.setDesc(eachTransactionInfo.getDescription1().trim());				
			
						if(StringMethods.isValidString(eachTransactionInfo.getDescription2()))
							transactionDetail.setDesc2(eachTransactionInfo.getDescription2().trim());	
						
						//Adding debit transaction to the response list
						debitTranHistoryList.add(transactionDetail);
					}
					else{
						//Credit transaction
						Logger.debug("It is Credit Transaction.Not Populating",this.getClass());
					}
				}	
			
			}
		}
		
		return debitTranHistoryList;
	}
	

	protected ContactResp populateCheckContactResp(boolean contactExists, String origin, ContactResp resp){
		resp.setContactExists(contactExists);
		if(contactExists){
			ErrorInfo errorInfo = new ErrorInfo();
			errorInfo.setCode(String.valueOf(BusinessException.EXP_SPLITTER_CONTACT_ALREADY_EXISTS));
			errorInfo.setMessage(MBAppUtils.getMessage(origin, BusinessException.EXP_SPLITTER_CONTACT_ALREADY_EXISTS));
			List<ErrorInfo> errorList = new ArrayList<ErrorInfo>();
			errorList.add(errorInfo);
			resp.setErrorList(errorList);
		}
		return resp;
	}
		
	protected ExpenseSplitterContact createExpenseSplitterContactObject(ContactReq contactReq, IBankCommonData commonData){
		Logger.info("Starting to populate expense splitter contact object", this.getClass());
		ExpenseSplitterContact contact =  new ExpenseSplitterContact();
		contact.setContactName(contactReq.getContactName().trim());
		contact.setContactNum(contactReq.getContactMobileNum());
		contact.setGCISNum(commonData.getUser().getGCISNumber());
		contact.setContactIndex(contactReq.getContactIndex());
		if(StringMethods.isValidString(contactReq.getContactID()))
			contact.setContactID(Long.parseLong(contactReq.getContactID()));
		return contact;
	}
	
	/**
	 * Populating Pending Authorizations + Transaction History response
	 * 
	 **/
	protected void populateEntireHistoryResp(ExpenseSplitterTransHistResp resp ,Account selectedAccount, Collection cardAuthorizations,StringBuffer[] cardAuthtotAmt, TransactionHistory tranHistory) {
		
		if ( (Account.CREDIT_CARD.equalsIgnoreCase(selectedAccount.getAccountId().getEhubProductCode())
				|| Account.SAVING_ACCOUNT.equalsIgnoreCase(selectedAccount.getAccountId().getEhubProductCode())
				|| Account.CHEQUE_ACCOUNT.equalsIgnoreCase(selectedAccount.getAccountId().getEhubProductCode())
				)
				&& !selectedAccount.getAccountId().isSenseSavingAccount() 
				&& !MBAppHelper.isHISAAccount(selectedAccount.getAccountId().getSubProductCode())){
						
			CardAuthResp cardAuth = new CardAuthResp();			
			
			if(null!= cardAuthorizations){			
				BigDecimal totalAmount = new BigDecimal(0);
				cardAuth.setAuthList(getCardAuthResp(cardAuthorizations));			
				if(Account.CREDIT_CARD.equalsIgnoreCase(selectedAccount.getAccountId().getEhubProductCode()))
					totalAmount = new BigDecimal(Double.parseDouble(cardAuthtotAmt[0].toString()));
				else				
					totalAmount = getCardAuthTotalAmount(cardAuthorizations);																	
				cardAuth.setTotAmt(StringUtil.formatBigDecimal(totalAmount));
			}
			resp.setCardAuth(cardAuth);			
		}
		
		populateTranHistoryResp(resp, tranHistory);

	}
	
	private List<TranDetailResp> getCardAuthResp(Collection authorisations){
		List<TranDetailResp> authlist = null;
		
		TranDetailResp cardAuth;
		if(authorisations != null && authorisations.size() > 0 ){
			
			authlist = new ArrayList<TranDetailResp>();						
			Iterator it = authorisations.iterator();			
			while(it.hasNext()){				
				OutstandingAuthorisations auth = (OutstandingAuthorisations)it.next();
				cardAuth = new TranDetailResp();
				
				String amtValue = "";
				BigDecimal amount=auth.getAmount();//for DDA account cardAuth transactions
				//auth.getCrAmt() & auth.getDrAmt() used for CreditCard transactions
				
				if (amount !=null){
					cardAuth.setDebit(true);
					if (amount.signum() == -1) {
						Logger.debug("This is Debit Transaction pending for Authorization for DDA",this.getClass());					
						BigDecimal negatedAmt = amount.negate();
						amtValue=negatedAmt.toString();						
					}
					else{
						amtValue=amount.toString();
					}
					//Setting amount
					cardAuth.setAmt(amtValue);
					
					//Setting description
					if (StringMethods.isValidString(auth.getDescription())){						
						String desc = auth.getDescription();
						//Splitting over multiple spaces
						String[] tempDesc = auth.getDescription().trim().split("\\s+");
						
						if(null!= tempDesc && tempDesc.length > 0 && tempDesc.length != 1){
							//This condition to check if array has more than 1 values ; then check for first thing to be numeric
							desc = StringMethods.isNumber(tempDesc[0]) ? tempDesc[1] : tempDesc[0];	
							
						}else if(null!= tempDesc && tempDesc.length > 0 && tempDesc.length == 1){
							//This condition to check if array has only 1 then just assign as it is.
							desc = tempDesc[0];
						}
						//If both above conditions fail ; assign whatever coming in auth response
						cardAuth.setDesc(desc);	
					}
						
					
					//Setting request Time
					if(auth.getRequestTime() == null)
						cardAuth.setDate(auth.getRequestDate());
					else{
						Date datetime = mbAppHelper.getDateTime(auth.getRequestDate(),auth.getRequestTime());
						cardAuth.setDate(datetime);
					}
								
					authlist.add(cardAuth);	
					
				}else if(auth.getDrAmt()!=null && auth.getDrAmt().compareTo(new BigDecimal(0)) != 0){
					
					Logger.debug("This is Debit Transaction pending for Authorization for CRA",this.getClass());
					cardAuth.setDebit(true);
					amtValue=auth.getDrAmt().toString();
					
					//Setting amount
					cardAuth.setAmt(amtValue);
					
					//Setting description
					if (StringMethods.isValidString(auth.getDescription())){
						Logger.debug("Removing all splitting description logic for CRA.. sending everything coming from service.", this.getClass());
						cardAuth.setDesc(auth.getDescription().trim());
					}
						
					
					//Setting request Time
					if(auth.getRequestTime() == null)
						cardAuth.setDate(auth.getRequestDate());
					else{
						Date datetime = mbAppHelper.getDateTime(auth.getRequestDate(),auth.getRequestTime());
						cardAuth.setDate(datetime);
					}
								
					authlist.add(cardAuth);	
					
				}else if(auth.getCrAmt() != null && auth.getCrAmt().compareTo(new BigDecimal(0)) != 0){
					Logger.debug("This is Credit Transaction pending for Authorization for CRA.Not populating",this.getClass());					
				}
				
							
			}			
			Collections.reverse(authlist);
		}		
		return authlist;
	}
	
	private BigDecimal getCardAuthTotalAmount(Collection authorisations){
		BigDecimal total = new BigDecimal(0);
		if (authorisations == null)
			return total;
		Iterator it = authorisations.iterator();
		while(it.hasNext()){
			OutstandingAuthorisations auth = (OutstandingAuthorisations)it.next();
			if(auth.getAmount()!=null)
				total = total.add(auth.getAmount());
		}
		return total;
	}	
	
	
	protected ExpenseSplitterResp populateExpenseGroupDetailResponse(RespHeader header, ExpenseSplitterVO expSplitterVO)throws BusinessException {
		ExpenseSplitterResp response = new ExpenseSplitterResp(header);
		List<ExpenseResp> expenseRespList = new ArrayList<ExpenseResp>();
		List<ContactListResp> contactRespList = new ArrayList<ContactListResp>();
		response.setTotalAmt(expSplitterVO.getTotalAmt().toString());
		response.setExpGrpID(expSplitterVO.getExpGrpId());
		String splitOption = "1"; //Initialize with equal split, as groups with no contacts are considered as equal split
		Set<BigDecimal> contactAmtSet = new HashSet<BigDecimal>();
		
		if(expSplitterVO.getExpenses() != null && !expSplitterVO.getExpenses().isEmpty()){
			for(Expense exp: expSplitterVO.getExpenses()){
				ExpenseResp expResp = new ExpenseResp();
				expResp.setExpenseAmt(exp.getTotalAmt().toString());
				expResp.setExpenseDate(exp.getExpenseDate().toString());
				expResp.setExpenseName(exp.getExpenseName().trim());
				expResp.setExpID(exp.getExpID());
				expenseRespList.add(expResp);
			}
			response.setExpenseList(expenseRespList);
		}
		if(expSplitterVO.getContacts() != null && !expSplitterVO.getContacts().isEmpty()){
			BigDecimal meContactAmt = new BigDecimal(0);
			for(ExpenseSplitterContact voContact : expSplitterVO.getContacts()){
				ContactListResp contactListResp = new ContactListResp();
				contactListResp.setContactName(voContact.getContactName());
				contactListResp.setContactID(voContact.getContactID());
				contactListResp.setAmtPaid(voContact.getAmountPaid());
				contactListResp.setTotalAmt(voContact.getContactAmt());
				contactListResp.setAmtDue(voContact.getAmountDue());
				contactListResp.setContactMobileNum(voContact.getContactNum());
				contactListResp.setMeContact(voContact.isMeContact());
				contactRespList.add(contactListResp);
				if(!voContact.isMeContact()){ // for an equal split, all contact amounts will be equal except for Me.
					contactAmtSet.add(voContact.getContactAmt());
				}else{
					meContactAmt = voContact.getContactAmt();
				}
			}
			response.setContactList(contactRespList);
			meContactAmt = meContactAmt.subtract(contactAmtSet.iterator().next());
			if(contactAmtSet.size() > 1 ||  meContactAmt.doubleValue() > 1.00 || meContactAmt.doubleValue() < -1.00 ){ // different amounts found for contacts. it is an unequal split. Or if Me is off by more than a dollar it is an unequal split
				splitOption = "2";
			}
			
		}
		response.setSplitOption(splitOption);
		return 	response;
	}
	
	
	protected ContactGroupDetailResp populateContactDetailResponse(RespHeader header, List<ExpenseSearch> expSearchList)throws BusinessException {
		ContactGroupDetailResp response = new ContactGroupDetailResp(header);
		List<ExpenseGrpListResp> expenseGrpRespList = new ArrayList<ExpenseGrpListResp>();
		ContactListResp contactListResp = new ContactListResp();
		if(expSearchList != null ){
			for(ExpenseSearch expSearch : expSearchList){
				ExpenseGrpListResp resp = new ExpenseGrpListResp();
				resp.setAmtDue(expSearch.getTotalGrpAmt().subtract(expSearch.getAmtGrpPaid()));
				resp.setAmtPaid(expSearch.getAmtGrpPaid());
//				resp.setTotalAmt(expSearch.getTotalGrpAmt());
//				resp.setContactCount(expSearch.getNumContactsInGrp());
				resp.setExpGrpID(expSearch.getExpGrpID());
				resp.setSettled(expSearch.getSettled() == 1 ? true : false);
				resp.setExpenseGrpName(expSearch.getExpenseGrpName().trim());
				//setting expensecontactList associated with that group
				List<ExpenseContactListResp> expenseContactList = new ArrayList<ExpenseContactListResp>();	
				for(Expense exp : expSearch.getExpenses()){
					ExpenseContactListResp expenseContactListResp = new ExpenseContactListResp();
					expenseContactListResp.setExpenseName(exp.getExpenseName().trim()); 
					expenseContactListResp.setExpenseContactAmt(exp.getTotalAmt());
					expenseContactList.add(expenseContactListResp);
				}									
				resp.setExpenseContactList(expenseContactList);
								
				expenseGrpRespList.add(resp);
			}
			ExpenseSearch expContactDetail =  expSearchList.get(0);
			if(expContactDetail != null){
				contactListResp.setContactName(expContactDetail.getContactName());
				contactListResp.setContactID(expContactDetail.getContactID());
				contactListResp.setContactMobileNum(expContactDetail.getContactNum());				
			}
			response.setContact(contactListResp);
			response.setExpenseGrpList(expenseGrpRespList);
		}
	
		return 	response;
	}
	
	
	protected SuccessResp populateSuccessResp(RespHeader headerResp){
		SuccessResp serviceResponse = new SuccessResp();
		serviceResponse.setHeader(headerResp);
		serviceResponse.setIsSuccess(true);
		return serviceResponse;
	}
	
	protected ExpenseSplitterUpdateVO populateExpenseSplitterUpdateVO(ContactAmountDetailReq request,IBankCommonData commonData){
		ExpenseSplitterUpdateVO  updateVO = new ExpenseSplitterUpdateVO();
		List<ExpenseSearch> expenseSearchList = new ArrayList<ExpenseSearch>();
		Logger.debug("creating the expensesplitter vo object in helper", this.getClass());
		if(request != null && request.getContactID() != null){
			
			updateVO.setContactID(new Long(request.getContactID()));
			for(ExpenseGroupReq req: request.getExpenseGrpList()){
				if(req.isSettled()){
					continue; // We do not want to modify anything on settled groups
				}
				ExpenseSearch expSearch = new ExpenseSearch();
				expSearch.setAmtGrpPaid(new BigDecimal(req.getAmtPaid()));
				expSearch.setExpenseGrpName(req.getExpenseGrpName().trim());
				expSearch.setExpGrpID(new Long(req.getExpGrpID()));
				expSearch.setGrpAmtDue(req.getAmtDue() != null ? new BigDecimal(req.getAmtDue()): new BigDecimal(0));
				expSearch.setTotalGrpAmt(req.getTotalAmt() != null ? new BigDecimal(req.getTotalAmt()) : new BigDecimal(0) );
				expSearch.setAmountPaidNow(req.getAmtPaidNow() !=null ?new BigDecimal(req.getAmtPaidNow()) : new BigDecimal(0));
				expenseSearchList.add(expSearch);
			}
			updateVO.setExpenseSearchList(expenseSearchList);
		}
		return updateVO;
	}
	
	protected ExpenseSplitterUpdateVO populateExpenseSplitterUpdateVOForExpenseGroup(ExpenseGrpAmountPaidReq request,IBankCommonData commonData){
		ExpenseSplitterUpdateVO  updateVO = new ExpenseSplitterUpdateVO();
		List<ExpenseSearch> expenseSearchList = new ArrayList<ExpenseSearch>();
		List<Expense> expenseList = new ArrayList<Expense>();
		Logger.debug("creating the expensesplitter vo object in helper", this.getClass());
		int countOfSettledContacts = 0;
		if(request != null && request.getExpGrpID() != null){
			
			updateVO.setExpGrpID(new Long(request.getExpGrpID()));
			updateVO.setTotalAmt(new BigDecimal(request.getTotalAmt()));
			for(ContactReq req: request.getContactList()){
				ExpenseSearch expSearch = new ExpenseSearch();
				expSearch.setAmtGrpPaid(new BigDecimal(req.getAmtPaid()));
				expSearch.setGrpAmtDue(req.getAmtDue() != null ? new BigDecimal(req.getAmtDue()): new BigDecimal(0));
				expSearch.setTotalGrpAmt(req.getTotalAmt() != null ? new BigDecimal(req.getTotalAmt()) : new BigDecimal(0) );
				expSearch.setAmountPaidNow(req.getAmtPaidNow() !=null ?new BigDecimal(req.getAmtPaidNow()) : new BigDecimal(0));
				expSearch.setContactID(new Long(req.getContactID()));
				expSearch.setContactName(req.getContactName());
				if(req.getAmtDue() != null && req.getAmtPaidNow() != null){
					if(new BigDecimal(req.getAmtDue()).compareTo(new BigDecimal(req.getAmtPaidNow())) == 0){ // The contact has been settled
						expSearch.setSettled(1);
						countOfSettledContacts++;
					}
				}
				
				expenseSearchList.add(expSearch);
			}
			for(ExpenseReq expReq: request.getExpenseList()){
				Expense expense = new Expense();
				expense.setExpID(expReq.getExpID());
				expense.setTotalAmt(new BigDecimal(expReq.getExpenseAmt()));
				expenseList.add(expense);
			}
			if(request.getContactList().size() == countOfSettledContacts){
				updateVO.setSettled(true);
			}
			updateVO.setExpenseSearchList(expenseSearchList);
			updateVO.setExpenseList(expenseList);
		}
		return updateVO;
	}
	
	protected ExpenseGroup populateExpenseGroupObject(ExpenseGroupReq req, IBankCommonData commonData){
		ExpenseGroup expGrp = new ExpenseGroup();
		expGrp.setExpGrpID(new Long(req.getExpGrpID()));
		expGrp.setModifiedBy(commonData.getUser().getGCISNumber());
		expGrp.setExpGrpName(req.getExpenseGrpName().trim());
		expGrp.setGCISNum(commonData.getUser().getGCISNumber());
		return expGrp;
	}
}
