package au.com.stgeorge.mbank.model.mortgageinfo;

import java.io.Serializable;
import java.util.List;

import javax.validation.Valid;
import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.Length;
import org.hibernate.validator.constraints.Range;

import au.com.stgeorge.ibank.businessobject.BusinessException;


import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_NULL)
public class DocTypeDetailInfo implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = -3511955740636187428L;
	private List<String> toolTips;	
	private String docTypeName;		
	private List<DocDetailInfo> docDetails;
	private String docAppMapId;
	private Boolean joint;
	
	public List<String> getToolTips() {
		return toolTips;
	}

	public void setToolTips(List<String> toolTips) {
		this.toolTips = toolTips;
	}

	public String getDocTypeName() {
		return docTypeName;
	}

	public void setDocTypeName(String docTypeName) {
		this.docTypeName = docTypeName;
	}

	public List<DocDetailInfo> getDocDetails() {
		return docDetails;
	}

	public void setDocDetails(List<DocDetailInfo> docDetails) {
		this.docDetails = docDetails;
	}

	public String getDocAppMapId() {
		return docAppMapId;
	}

	public void setDocAppMapId(String docAppMapId) {
		this.docAppMapId = docAppMapId;
	}

	public Boolean getJoint() {
		return joint;
	}

	public void setJoint(Boolean joint) {
		this.joint = joint;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
}
