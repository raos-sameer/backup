package au.com.stgeorge.mbank.controller.services;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang.builder.ReflectionToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;

import au.com.stgeorge.framework.common.logging.Logger;
import au.com.stgeorge.ibank.businessobject.BusinessException;
import au.com.stgeorge.ibank.businessobject.ResourceException;
import au.com.stgeorge.ibank.businessobject.TaxFileNumberService;
import au.com.stgeorge.ibank.common.cache.IBankParams;
import au.com.stgeorge.ibank.valueobject.Customer;
import au.com.stgeorge.ibank.valueobject.transfer.IBankCommonData;
import au.com.stgeorge.mbank.controller.IMBController;
import au.com.stgeorge.mbank.model.common.IMBReq;
import au.com.stgeorge.mbank.model.common.IMBResp;
import au.com.stgeorge.mbank.model.common.KeyValueResp;
import au.com.stgeorge.mbank.model.common.ReqHeader;
import au.com.stgeorge.mbank.model.common.RespHeader;
import au.com.stgeorge.mbank.model.request.services.ProvideTFNReq;
import au.com.stgeorge.mbank.model.request.services.TFNReq;
import au.com.stgeorge.mbank.model.response.ErrorResp;
import au.com.stgeorge.mbank.model.response.StatusResp;
import au.com.stgeorge.mbank.model.response.services.TFNCheckResp;
import au.com.stgeorge.mbank.session.MobileSession;
import au.com.stgeorge.mbank.session.MobileSessionImpl;
import au.com.stgeorge.mbank.util.MBAppHelper;
import au.com.stgeorge.mbank.util.MBAppUtils;
import au.com.stgeorge.mbank.util.MBAppValidator;
import au.com.stgeorge.mbank.util.ServiceConstants;
import au.com.stgeorge.perflogger.PerformanceLogger;

/**
 * Provide TFN service
 * 
 * @author C38854
 * 
 */
@Controller
@RequestMapping("/tfn")
public class TFNController implements IMBController {

	private static final String ACTION_SUCCESSFUL = "ACTION SUCCESSFUL";

	@Autowired
	private TFNHelper helper;

	
	@Autowired
	private MBAppValidator mbAppValidator;
	
	@Autowired
	private MBAppHelper mbAppHelper;

	//19E3 code
	@Autowired
	private TFNHelper tfnHelper;
	
	/**
	 * Check if TFN provided
	 * 
	 * @param httpRequest
	 * @param request
	 * @return
	 */
	@RequestMapping(method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE, value = "check")
	@ResponseBody
	public IMBResp check(HttpServletRequest httpRequest, @RequestBody final TFNReq request) {
		Logger.debug("TFNController - check(). Request: " + request, this.getClass());
		String logName = startPerformanceLog(httpRequest);
		MobileSession mobileSession = new MobileSessionImpl();
		TFNCheckResp tfnCheck=null;
		try {
			mobileSession.getSessionContext(httpRequest);
			validateRequestHeader(request.getHeader(), httpRequest);
			ErrorResp errorResponse = validate(request, httpRequest);
			if (errorResponse.hasErrors())
				return errorResponse;

			
			IBankCommonData ibankCommonData = new MBAppHelper().populateIBankCommonData(mobileSession, httpRequest);
			Customer customer = mobileSession.getCustomer();
			//19e3 code
			if(!IBankParams.isSwitchOn(ibankCommonData.getOrigin(), IBankParams.TFN_SWITCH)){
			    
                String description = TaxFileNumberService.getTFNDescription(customer);
			    boolean thfHeld = false;
			    boolean thfExcemption = false;
			    if (description.equalsIgnoreCase(TaxFileNumberService.TAX_FILE_NUMBER_HELD))
				    thfHeld = true;
			    else if (description.equalsIgnoreCase(TaxFileNumberService.FOREIGN_EXEMPTION))
				    thfExcemption = true;
			    return helper.populateTFNCheckResponse(populateResponseHeader(ServiceConstants.TFN_CHECK_SERVICE, mobileSession), thfExcemption, thfHeld);
			}
			else{

				//19E3 TFN code
				Logger.debug("TFNController - Entered TFN Switch on scenario:: ", this.getClass());
				Boolean showTfn = tfnHelper.showTfn(ibankCommonData,mobileSession);
				
				if(null != showTfn) {	
					
					mobileSession.setShowTfn(showTfn);
					
					if(showTfn){
						Logger.debug("TFNController - check method - populating tfn widget properties:START", this.getClass());
						//populate the response
						 tfnCheck = new TFNCheckResp(populateResponseHeader(ServiceConstants.TFN_CHECK_SERVICE, mobileSession));
						 tfnCheck.setExemptionList(tfnHelper.getTFNExemptOptList());
						 List<KeyValueResp>optionsList = tfnHelper.getTFNOptionList();
						 
						 //Change for 19E3
						 // for savings habit and incentive saver, do populate all three options
						 if(null == request.getStandAlone())
							 optionsList.remove(1);
						 
						 tfnCheck.setTfnOptionList(optionsList);
						 //Business customer
						 if(null!= customer && ("B".equalsIgnoreCase(customer.getCustTypeInd()) 
									|| customer.isCHSCustomer() || customer.isCHSGHSCustomer())){
							Logger.debug("TFNController - check method - Business customer", this.getClass());
							tfnCheck.setBusinessCustomer(true);
						 }
						 Logger.debug("TFNController - check method - populating tfn widget properties:END", this.getClass());
					}
					else{
						tfnCheck = new TFNCheckResp(populateResponseHeader(ServiceConstants.TFN_CHECK_SERVICE, mobileSession));
					    //set showTfn irrespective true or false to avoid null pointer in openTermDepositAccount method.
					    tfnCheck.setTfnHeld(true);
					    
					    //If TFN already provided, set StatUpdTfn to true, so that while opening account, HASTFN is set as Y;
					    mobileSession.setStatUpdTfn(true);
					}
				} else{
					Logger.debug("TFNController - TFN switch is OFF.. no widget", this.getClass());
					tfnCheck = new TFNCheckResp(populateResponseHeader(ServiceConstants.TFN_CHECK_SERVICE, mobileSession));
					mobileSession.setShowTfn(showTfn);
				}
				
				return tfnCheck;
			}
		} catch (BusinessException e) {
			Logger.info("BusinessException in TFNController - check() - [key: " + e.getKey() + "] : GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), e, ServiceConstants.TFN_CHECK_SERVICE, httpRequest);
		} catch (ResourceException e) {
			Logger.error("ResourceException in TFNController - check() - [key: " + e.getKey() + "] : GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.SYSTEM_UNAVILABLE, ServiceConstants.TFN_CHECK_SERVICE, httpRequest);
		} catch (Exception e) {
			Logger.error("Exception TFNController - check(): GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), ResourceException.MOBILE_NON_FINANCIAL_FATAL_ERR,
					ServiceConstants.TFN_CHECK_SERVICE, httpRequest);
		} finally {
			endPerformanceLog(logName);
		}
	}

	/**
	 * Provide TFN
	 * 
	 * @param httpRequest
	 * @param request
	 * @return
	 */
	@RequestMapping(method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE, value = "provide")
	@ResponseBody
	public IMBResp provide(HttpServletRequest httpRequest, @RequestBody final ProvideTFNReq request) {
		Logger.debug("TFNController - provide(). Request: " + request, this.getClass());
		String logName = startPerformanceLog(httpRequest);
		MobileSession mobileSession = new MobileSessionImpl();

		try {
			mobileSession.getSessionContext(httpRequest);
			validateRequestHeader(request.getHeader(), httpRequest);
			ErrorResp errorResponse = validate(request, httpRequest);
			if (errorResponse.hasErrors())
				return errorResponse;
			
			
			IBankCommonData commonData = new MBAppHelper().populateIBankCommonData(mobileSession, httpRequest);
			
			if(!IBankParams.isSwitchOn(commonData.getOrigin(), IBankParams.TFN_SWITCH)){
				Logger.debug("TFNController :: provide() method TFNSwitch OFF scenario :: ", this.getClass());
				try {
					if (!helper.isValidTFN(request.getTaxFileNumber()) || !Boolean.TRUE.equals(request.getApplyToAllAccts())) {
						return MBAppUtils.createErrorResp(mobileSession.getOrigin(), null,
								"The Tax File Number you have entered is invalid. Please re-enter.", ServiceConstants.TFN_PROVIDE_SERVICE, httpRequest);
					}
				} catch (Exception e) {
					return MBAppUtils.createErrorResp(mobileSession.getOrigin(), null,
							"The Tax File Number you have entered is invalid. Please re-enter.", ServiceConstants.TFN_PROVIDE_SERVICE, httpRequest);
				}
				Customer customer = mobileSession.getCustomer();
				
				// check if TFN already there
				String description = TaxFileNumberService.getTFNDescription(customer);
				if (!description.equalsIgnoreCase(TaxFileNumberService.TAX_FILE_NUMBER_HELD)
						&& !description.equalsIgnoreCase(TaxFileNumberService.FOREIGN_EXEMPTION)) {
					String tfnUpdRespStr = TaxFileNumberService.submitTaxFileNumber(customer, request.getTaxFileNumber(), commonData);
					if (tfnUpdRespStr.equalsIgnoreCase(ACTION_SUCCESSFUL))
						return helper.populateStatusResponse(populateResponseHeader(ServiceConstants.TFN_PROVIDE_SERVICE, mobileSession), 1);
					return helper.populateStatusResponse(populateResponseHeader(ServiceConstants.TFN_PROVIDE_SERVICE,mobileSession), 0);
				} else {
					return MBAppUtils.createErrorResp(mobileSession.getOrigin(), null,
							"You have already Provided your Tax File Number or you have been exempted.", ServiceConstants.TFN_PROVIDE_SERVICE, httpRequest);
				}
				
			}
		     else{
				//19E3 Changes
				//if switch is On and !tfnheld - then get values from req and do validation
				Logger.debug("TFNController :: provide () TFN Switch ON scenario ::",this.getClass());
		    	Boolean statUpdTfn=false;
				Boolean showTfn = mobileSession.getShowTfn();
				if(showTfn!=null && showTfn){
					//trigger validations
					 Logger.debug("TFNController - openTermDepositAccount - validations", this.getClass());
					 if(request.getSelectedOption()!=null && !request.getSelectedOption().equals("1")){
					    tfnHelper.validateTFN(request.getSelectedOption(),request.getTaxFileNumber(),request.getSelectedExemption());
					    statUpdTfn = tfnHelper.updateTFN(commonData,request.getSelectedOption(),request.getTaxFileNumber(),request.getSelectedExemption());
					    Logger.debug("TFNController - TFN update :"+statUpdTfn, this.getClass());
				         if(statUpdTfn) {
				        	 mobileSession.setStatUpdTfn(true);
				        	 return helper.populateStatusResponse(populateResponseHeader(ServiceConstants.TFN_PROVIDE_SERVICE, mobileSession), 1);
				         }
				         
				         mobileSession.setStatUpdTfn(false);
				         return helper.populateStatusResponse(populateResponseHeader(ServiceConstants.TFN_PROVIDE_SERVICE,mobileSession), 0);
				        
					 }
					 else{
						 StatusResp response = new StatusResp(populateResponseHeader(ServiceConstants.TFN_PROVIDE_SERVICE, mobileSession));
					     return response;
					 }
	             }
				//need to check this  
				return helper.populateStatusResponse(populateResponseHeader(ServiceConstants.TFN_PROVIDE_SERVICE,mobileSession), 0);
			}
		} catch (BusinessException e) {
			Logger.info("BusinessException in TFNController - provide() - [key: " + e.getKey() + "] : GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), e, ServiceConstants.TFN_PROVIDE_SERVICE, httpRequest);
		} catch (ResourceException e) {
			Logger.error("ResourceException in TFNController - provide() - [key: " + e.getKey() + "] : GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.SYSTEM_UNAVILABLE, ServiceConstants.TFN_PROVIDE_SERVICE, httpRequest);
		} catch (Exception e) {
			Logger.error("Exception TFNController - provide(): GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), ResourceException.MOBILE_NON_FINANCIAL_FATAL_ERR,
					ServiceConstants.TFN_PROVIDE_SERVICE, httpRequest);
		} finally {
			endPerformanceLog(logName);
		}
	}

	public ErrorResp validate(IMBReq serviceRequest, HttpServletRequest request) {
		Logger.info("Service request object - " + ReflectionToStringBuilder.toString(serviceRequest), this.getClass());
		return mbAppValidator.validate(serviceRequest, request);
	}

	public void validateRequestHeader(ReqHeader headerReq, HttpServletRequest request) throws BusinessException {
		Logger.debug("Request header validation: " + ReflectionToStringBuilder.toString(headerReq, ToStringStyle.MULTI_LINE_STYLE), this.getClass());
		 mbAppValidator.validateRequestHeader(headerReq, request);
	}
	
	public RespHeader populateResponseHeader(String serviceName, MobileSession mobSession) {
		return mbAppHelper.populateResponseHeader(serviceName, mobSession);
	}


	/**
	 * Response for invalid body request
	 * 
	 * @return
	 */
	@ExceptionHandler( { org.springframework.http.converter.HttpMessageNotReadableException.class })
	@ResponseStatus(org.springframework.http.HttpStatus.OK)
	@ResponseBody
	public IMBResp resolveException() {
		return MBAppUtils.createInvalidMessageBodyResponse(ServiceConstants.TFN_PROVIDE_SERVICE);
	}

	@Autowired
	private PerformanceLogger perfLogger;
	
	private String startPerformanceLog(HttpServletRequest httpRequest){
		perfLogger.startAllLogs();
		String logName = MBAppUtils.getLogName(httpRequest);
		perfLogger.startLog(logName);
		return logName;
	}
	
	private void endPerformanceLog(String logName){
		perfLogger.endLog(logName);
		perfLogger.endAllLogs();
	}
}
