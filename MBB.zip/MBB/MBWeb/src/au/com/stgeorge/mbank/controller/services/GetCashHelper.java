package au.com.stgeorge.mbank.controller.services;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Service;

import au.com.stgeorge.framework.common.logging.Logger;
import au.com.stgeorge.framework.common.util.DateMethods;
import au.com.stgeorge.ibank.businessobject.BusinessException;
import au.com.stgeorge.ibank.businessobject.GetCashService;
import au.com.stgeorge.ibank.businessobject.ResourceException;
import au.com.stgeorge.ibank.common.cache.IBankParams;
import au.com.stgeorge.ibank.dao.DAOConstants;
import au.com.stgeorge.ibank.dao.IPreferenceDAO;
import au.com.stgeorge.ibank.dao.ViperDAOFactory;
import au.com.stgeorge.ibank.service.valueobject.CustDevice;
import au.com.stgeorge.ibank.service.valueobject.CustServiceRegistration;
import au.com.stgeorge.ibank.valueobject.Account;
import au.com.stgeorge.ibank.valueobject.AccountFlags;
import au.com.stgeorge.ibank.valueobject.DebitCardAccount;
import au.com.stgeorge.ibank.valueobject.GetCashArrangementDetail;
import au.com.stgeorge.ibank.valueobject.GetCashVO;
import au.com.stgeorge.ibank.valueobject.Preference;
import au.com.stgeorge.ibank.valueobject.UserAgentVO;
import au.com.stgeorge.ibank.valueobject.database.CodesVO;
import au.com.stgeorge.ibank.valueobject.database.PreferenceVO;
import au.com.stgeorge.mbank.model.common.IMBResp;
import au.com.stgeorge.mbank.model.response.services.GetCashAccountDetailResp;
import au.com.stgeorge.mbank.model.response.services.GetCashCodeResp;
import au.com.stgeorge.mbank.model.response.services.GetCashEligiblityResp;
import au.com.stgeorge.mbank.model.response.services.GetCashRegistrationResp;
import au.com.stgeorge.mbank.session.MobileSession;
import au.com.stgeorge.mbank.util.MBAppHelper;
import au.com.stgeorge.mobilebank.businessobject.CardService;
import au.com.stgeorge.security.util.StringMethods;

/**
 * @author C50216
 *
 */
@Service
public class GetCashHelper {
	
	@Autowired
	private MBAppHelper mbAppHelper;
	
	@Autowired
	private CardService mobileCardService;
	
	@Autowired 
	private GetCashService getCashService;		
		
	protected IMBResp populateRegistrationResp(MobileSession mbSession,GetCashArrangementDetail arrangementDet,String messageCode){
		
		GetCashRegistrationResp resp = new GetCashRegistrationResp();		
		
		resp.setMessageCode(messageCode);
		resp.setToken(mbSession.getGetCashToken());
		if(arrangementDet != null )				
			resp.setArrangementDetail(populateArrangementDetail(arrangementDet, mbSession));
		
		return resp;
	}

	protected IMBResp populateEligiblityResp(MobileSession mbSession, boolean isRegistered, String messageCode, GetCashArrangementDetail arrangementDet){
				
		GetCashEligiblityResp elgiResp = new GetCashEligiblityResp();
		List<Account> custAcct = mbSession.getCustomer().getAccounts();
		List<DebitCardAccount> dbCrdAcctList = mbSession.getGetCashAccountDetail();
		List<GetCashAccountDetailResp> eligibleProdList = new ArrayList<GetCashAccountDetailResp>();
		elgiResp.setIsRegistered(isRegistered);
		
		if(messageCode != null)
			elgiResp.setMessageCode(messageCode);
		
		CodesVO codeItem=IBankParams.getCodesData(IBankParams.BRAND_ORIGIN, IBankParams.PARAMETER,IBankParams.GET_CASH_ELIGIBLE_PRODUCTS);
		
		if(codeItem != null){
					
			for(Account acct : custAcct){
				if(codeItem.getMessage().indexOf(";"+acct.getAccountId().getSubProductCode()+";") >= 0){
					GetCashAccountDetailResp acctDet = new GetCashAccountDetailResp(); 				
					acctDet.setAccountIndex(mbAppHelper.getAccountIndexByAccountId(custAcct, acct.getAccountId()));
					
					if(dbCrdAcctList != null){
						
						for(DebitCardAccount dbtCardAcct : dbCrdAcctList){
							if(acct.getAccountId().equals(dbtCardAcct.getAccountId())){
								acctDet.setIsCardLinked(true);
								break;
							}												
						}																									
					}
					eligibleProdList.add(acctDet);				
				}					
			}									
		}
		
		//This change is for poplating the default account for CardLessCash
		if(eligibleProdList!=null && eligibleProdList.size() > 1){
			
			Logger.debug("eligible Prod List Size ::"+ eligibleProdList.size(), this.getClass());
			
			eligibleProdList = getEligibleProductList(eligibleProdList,mbSession);
		}
		
		if(eligibleProdList != null && eligibleProdList.size() > 0)
			elgiResp.setAccountList(eligibleProdList);
		if( arrangementDet != null)						
			elgiResp.setArrangementDetail(populateArrangementDetail(arrangementDet, mbSession));
		
		return elgiResp;		
	}
	
	private List<GetCashAccountDetailResp> getEligibleProductList(List<GetCashAccountDetailResp> eligibleProdList,MobileSession mbSession){
		
		Logger.debug("Inside method getEligibleProductList", this.getClass());
		
		Preference preference = mbSession.getCustomer().getPreference();
		
		for (GetCashAccountDetailResp acctDet: eligibleProdList){
			
			Account acct = mbAppHelper.getAccountFromCustomer(mbSession.getCustomer(), acctDet.getAccountIndex());

			Logger.debug("acct.getAccountId().getAccountNumber() ::"+acct.getAccountId().getAccountNumber(), this.getClass());
			Logger.debug("preference.getDefaultGetCashAccount() ::"+preference.getDefaultGetCashAccount(), this.getClass());
			Logger.debug("preference.getDefaultPayeeAccount() ::"+preference.getDefaultPayeeAccount(), this.getClass());
			Logger.debug("preference.getDefaultBPayAccount() ::"+preference.getDefaultBPayAccount(), this.getClass());
			
			if(!StringMethods.isEmptyString(preference.getDefaultGetCashAccount())){
				if(acct.getAccountId().getAccountNumber().equalsIgnoreCase(preference.getDefaultGetCashAccount())){
					acctDet.setDefaultAcct(true);
					break;
				}
			}
			else if(!StringMethods.isEmptyString(preference.getDefaultPayeeAccount())){
				if(acct.getAccountId().getAccountNumber().equalsIgnoreCase(preference.getDefaultPayeeAccount())){
					acctDet.setDefaultAcct(true);
					break;
				}
			}
			else if(!StringMethods.isEmptyString(preference.getDefaultBPayAccount())){
				if(acct.getAccountId().getAccountNumber().equalsIgnoreCase(preference.getDefaultBPayAccount())){
					acctDet.setDefaultAcct(true);
					break;
				}
			}
		}
		return eligibleProdList;
	}
	
	protected GetCashVO populateRetrieveArrangementRequestVO(){
		
		GetCashVO requestVO = new GetCashVO();
		Calendar cal = Calendar.getInstance();
		Date date = new Date();
		cal.setTime (date);
	  	cal.add (Calendar.DATE, - 1);
		requestVO.setFromDate(cal.getTime());
		requestVO.setToDate(date);
		
		return requestVO;
	}
	
	protected GetCashArrangementDetail populateCreateArrangementRequestVO(DebitCardAccount account, String amount){
		GetCashArrangementDetail arrangementReq = new GetCashArrangementDetail();
		
		arrangementReq.setAmount(new BigDecimal(amount));
		arrangementReq.setAccountNumber(account.getAccountId().getAccountNumber());
		arrangementReq.setBsbNumber(account.getAccountId().getBsb());
		arrangementReq.setCardNumber(account.getCardNumber());
		
		
		
//		if (DebitCardAccount.SAVINGS_PCCS.equalsIgnoreCase(account.getCardAcctType())){
//			arrangementReq.setAccountAccessMethod(GetCashService.ACCOUNT_ACCESS_METHOD_SVG);
//		}else if (DebitCardAccount.CHEQUE_PCCS.equalsIgnoreCase(account.getCardAcctType())){
//			arrangementReq.setAccountAccessMethod(GetCashService.ACCOUNT_ACCESS_METHOD_CHQ);
//		}

		//WATCH OUT !!!!!!!! ESB-FAH-ATM inverting SAVING and CHEQUE
		if (DebitCardAccount.SAVINGS_PCCS.equalsIgnoreCase(account.getCardAcctType())){
			arrangementReq.setAccountAccessMethod(GetCashService.ACCOUNT_ACCESS_METHOD_CHQ);
		}else if (DebitCardAccount.CHEQUE_PCCS.equalsIgnoreCase(account.getCardAcctType())){
			arrangementReq.setAccountAccessMethod(GetCashService.ACCOUNT_ACCESS_METHOD_SVG);
		}
				
		Logger.debug("PCCS card acct type: " + account.getCardAcctType() + " **** ESB acct access method: " + arrangementReq.getAccountAccessMethod(), this.getClass());
		return arrangementReq;
		
		
	}
	
	private Integer getAccountIndexFromCardNumber(List<DebitCardAccount> dbCrdAcctList, String cardNumber){
		
		Integer accountIndex = null;
		
		for(DebitCardAccount dbCrdAcct : dbCrdAcctList){
			if(dbCrdAcct.getCardNumber().equals(cardNumber)){
				accountIndex = dbCrdAcct.getIndex();
				break;
			}
		}		
		return accountIndex;
	}
	
	protected GetCashCodeResp populateArrangementDetail(GetCashArrangementDetail detail,MobileSession mbSession){
								
		GetCashCodeResp vo = null;
		
		//GetCashArrangementDetail detail = getCashService.getActiveCashCode(getCashVO); 
		if(detail != null && detail.getFaultMessage() == null){
			vo = new GetCashCodeResp();
			vo.setAmt(detail.getAmount().toString());
			vo.setCode(detail.getPassword());
			vo.setExpiryTimeStamp(detail.getExpiryTimeStamp());			
			vo.setSystemDate(DateMethods.getTimestamp());									
			vo.setAccountIndex(getAccountIndexFromCardNumber(mbSession.getGetCashAccountDetail(),detail.getCardNumber()));
			
			mbSession.setGetCashArrangementDetail(detail);//setting active arrangement in session
		}						
		
		return vo;
	}
	
	protected IMBResp populateCreateCodeResp(GetCashArrangementDetail detail){
		
		GetCashCodeResp resp = new GetCashCodeResp();			
		String faultMessage = detail.getFaultMessage();
		if(faultMessage != null){			
			resp.setMessageCode(faultMessage);
		}
		
		resp.setCode(detail.getPassword());
		resp.setExpiryTimeStamp(detail.getExpiryTimeStamp());				
		resp.setSystemDate(DateMethods.getTimestamp());		
		
		return resp;
		
	}	
	
	protected UserAgentVO populateUserAgentVO(au.com.stgeorge.mbank.useragent.UserAgentVO mbank_userAgentVO){
		
		UserAgentVO vo = new UserAgentVO();
		
		if(mbank_userAgentVO != null){
			
			vo.setBrowserDetails(mbank_userAgentVO.getBrowserDetails());
			vo.setDeviceOSDetails(mbank_userAgentVO.getDeviceOSDetails());
			vo.setDeviceType(mbank_userAgentVO.getDeviceType());
		}else
		{
			vo.setBrowserDetails("");
			vo.setDeviceOSDetails("");
			vo.setDeviceType("");
		}
		
		return vo;
		
	}
	
	protected CustDevice populateCustDevice(String deviceId, String gcisNumber, UserAgentVO userAgentVO){
		
		CustDevice custDevice = new CustDevice();
		
		custDevice.setDeviceID(deviceId);
		custDevice.setDeviceType(userAgentVO.getDeviceType());
		custDevice.setBrowserDetails(userAgentVO.getBrowserDetails());
		custDevice.setOsDetails(userAgentVO.getDeviceOSDetails());
		custDevice.setGcisNumber(gcisNumber);
		custDevice.setCreatedBy(gcisNumber);		
		
		return custDevice;
	}
	
	protected String validateAccountEligiblity(MobileSession mbSession, boolean isRegistered){
		
	String messageCode = null;	
	List<Account> eligibleProdList = new ArrayList<Account>();
	List<DebitCardAccount> accountsWithDebitCard = null;
	List<Integer> acctIndexList = new ArrayList<Integer>();
	//boolean withdrawableAcct = false;
	List<Account> acctList = mbSession.getCustomer().getAccounts();
	CodesVO codeItem=IBankParams.getCodesData(IBankParams.BRAND_ORIGIN, IBankParams.PARAMETER,IBankParams.GET_CASH_ELIGIBLE_PRODUCTS);
	
	if(codeItem != null){
				
		for(Account acct : acctList){
			if(codeItem.getMessage().indexOf(";"+acct.getAccountId().getSubProductCode()+";") >= 0){								
				eligibleProdList.add(acct);							
			}				
		}
		
		if(eligibleProdList.size() > 0){
						
			try{ 
				accountsWithDebitCard = mobileCardService.getAcctsLinkwithDebitCards(eligibleProdList ,mbSession.getUser().getGCISNumber());
				
				if(accountsWithDebitCard != null && accountsWithDebitCard.size() > 0){
					for(Account account : accountsWithDebitCard){
						if(account.getAllowFlags().contains(AccountFlags.ALLOW_WITHDRAWAL))							
							acctIndexList.add(mbAppHelper.getAccountIndexByAccountId(acctList, account.getAccountId()));							
						 	break;
					}					
					mbSession.setGetCashAccountDetail(accountsWithDebitCard);					
					if(! (acctIndexList.size() > 0) ){
						if(isRegistered)
							messageCode = GetCashService.NO_LONGER_ELIGIBLE_ACCOUNT_CODE;
						else
							messageCode = GetCashService.RESTRICTION_ON_ACCOUNT_CODE;						
					}
					
				}else
					if(isRegistered)
						messageCode = GetCashService.NO_LONGER_ELIGIBLE_ACCOUNT_CODE;
					else
						messageCode = GetCashService.NO_CARD_LINKED_CODE;
								
			}catch(Exception e){
				Logger.error("Error :  " + e.getMessage() , this.getClass());
				messageCode = GetCashService.SERVICE_UNAVAILABLE_CODE;			  
				}						
		}else{
			messageCode = GetCashService.NO_TRANSACTION_ACCOUNT_CODE;
		}
	}
	else
		messageCode = GetCashService.NO_TRANSACTION_ACCOUNT_CODE;
	
	return messageCode;
	
	 }
	
	protected String validateCustomerEligiblity(CustServiceRegistration custReg, String deviceId, String gcisNumber, boolean tokenValidated, String token) throws BusinessException, ResourceException{
		
		String messageCode = null;
		
		if (custReg == null) {
						
			if(!tokenValidated && token != null){
				//Scenario3:  When customer is registered, unbound (by security)(De-register by Admin) and then signs in again.
				messageCode = GetCashService.REGISTERED_WITHOUT_TOKEN_CODE;
			}else if(tokenValidated){
				// custRegistration where deviceId = ? and gcisNumber != session.gcisNumber
				// if there are records Erroe msg E013 BREAK				
				List<CustServiceRegistration> list = getCashService.isDeviceRegistered(deviceId, gcisNumber);
				
				if(list != null && list.size() > 0)
					messageCode =  GetCashService.ALREADY_REGISTERED_DEVICE_CODE; 
			}
			
		}else if (custReg !=null && !tokenValidated){
			//Scenario1: App has non valid token, and registration is valid (FATAL Error when saving token on APP)
			//Scenario2: There is no token stored on App, but customer is registered
			//E014 			
			messageCode = GetCashService.REGISTERED_WITHOUT_TOKEN_CODE;
			
		}else{
			//throw system unavailable and log scenario not handled, please check
			Logger.info("this GetCash Registration/Token validation scenario not covered. Please check the scenario & add the logic : " , this.getClass());
			throw new BusinessException(BusinessException.GENERIC_ERROR);
		}
		
		return messageCode;
	}

	public DebitCardAccount getAccountByAccountIndex(List<DebitCardAccount> accounts, int index) {
		DebitCardAccount debitCardAccount = null;
		if (accounts != null && accounts.size() > 0) {
			for(DebitCardAccount acct : accounts){
				if(acct.getIndex() == index){
					debitCardAccount = acct;
					break;
				}
			}
		}
		return debitCardAccount;
	}	
	
	protected IMBResp populateCancelCodeResp(GetCashArrangementDetail detail){
		GetCashCodeResp resp = new GetCashCodeResp();			
		return resp;
	}	
}
