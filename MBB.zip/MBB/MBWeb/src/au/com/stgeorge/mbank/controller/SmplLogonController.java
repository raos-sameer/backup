package au.com.stgeorge.mbank.controller;

/* The Controller which is used for NAtive app logon */

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.AbstractController;

import au.com.stgeorge.framework.common.logging.Logger;
import au.com.stgeorge.framework.common.model.User;
import au.com.stgeorge.ibank.businessobject.BusinessException;
import au.com.stgeorge.ibank.businessobject.ResourceException;
import au.com.stgeorge.ibank.businessobject.StatisticsService;
import au.com.stgeorge.ibank.businessobject.SystemInformation;
import au.com.stgeorge.ibank.common.cache.IBankParams;
import au.com.stgeorge.ibank.service.businessobject.QuickZoneService;
import au.com.stgeorge.ibank.util.CommonBusinessUtil;
import au.com.stgeorge.ibank.util.ServiceHelper;
import au.com.stgeorge.ibank.util.StringUtil;
import au.com.stgeorge.ibank.valueobject.Customer;
import au.com.stgeorge.ibank.valueobject.Statistic;
import au.com.stgeorge.ibank.valueobject.UserAgentVO;
import au.com.stgeorge.ibank.valueobject.database.CodesVO;
import au.com.stgeorge.ibank.valueobject.database.OriginsVO;
import au.com.stgeorge.ibank.valueobject.transfer.IBankCommonData;
import au.com.stgeorge.mbank.controller.customer.LogonHelper;
import au.com.stgeorge.mbank.session.GenericSessionFactory;
import au.com.stgeorge.mbank.session.IGenericSession;
import au.com.stgeorge.mbank.session.MobileSessionImpl;
import au.com.stgeorge.mbank.util.MBAppConstants;
import au.com.stgeorge.mbank.util.MBAppHelper;
import au.com.stgeorge.mobilebank.businessobject.MobileBankService;
import au.com.stgeorge.perflogger.PerformanceLogger;
import au.com.stgeorge.security.util.StringMethods;

public class SmplLogonController  extends AbstractController {

	private static final String REQ_DASHBOARD = "DASHBOARD";   // Used by Native App logon My accounts
	private static String REQ_REACTIVATE = "REACTIVATEAUTH";
	private static final String REQ_TIMEOUT = "TIMEOUT";

	private static String SESSION_ID = "SessionID";
	private static String CONNECT_SESSION_ID = "ConnectSessionID";
	private static final String SMPL_DEVICE_ID ="DeviceID";
	public static final String ORIGIN = "origin";
	public static final String GET_CASH_TOKEN = "cardlesstoken";
	public static final String ACTION_TYPE_OFFER = "Offer";
	public static final String GET_CASH_FLAG = "sgcInd";
	public static final String APP_VER_COOKIE = "AppVersion";
	public static final double ANDROID_BACKBTN_APPVERSION =  7.0;
	public static final String DEVICE_ANDROID = "ANDROID";//to support older app
	public static final String DEVICE_ANDROID_MOBBANK = "AND-MOBBANK";//added in 16E1
	private static String END_POINT = "/app";

	
    private final Map<String, String> actionTypeToGDWMapping;
    
    private static final String BLOCK_CHARS = "^[0-9A-Za-z',. &/\\-_]*$";
    
    public SmplLogonController() {
    	actionTypeToGDWMapping = new HashMap<String, String>();
    	actionTypeToGDWMapping.put("atmEFTPOS", "atmEFTPOS");
    	actionTypeToGDWMapping.put("activateCard", "activateCard");
    	actionTypeToGDWMapping.put("lostStolen", "lostStolen");
    	actionTypeToGDWMapping.put("stopStmt", "stopStmt");
    	actionTypeToGDWMapping.put("provideTaxFile", "provideTaxFile");
    	actionTypeToGDWMapping.put("disputeCard", "disputeCard");
    	actionTypeToGDWMapping.put("finYrInterest", "finYrInterest");
    	actionTypeToGDWMapping.put("smsEmailAlert", "smsEmailAlert");
    	actionTypeToGDWMapping.put("transferCreditBal", "transferCreditBal");
    	actionTypeToGDWMapping.put("updateContact", "updateContact");
    	actionTypeToGDWMapping.put("changeSecuNum", "changeSecuNum");
    	actionTypeToGDWMapping.put("changePwd", "changePwd");
    	actionTypeToGDWMapping.put("travelOverseas", "travelOverseas");
    	actionTypeToGDWMapping.put("openAccount", "openAccount");
    	actionTypeToGDWMapping.put("serviceMenu", "serviceMenu");
    	actionTypeToGDWMapping.put("default", "dashboard");
    	actionTypeToGDWMapping.put("completeFreedom", "activateCompleteFreedom");
    	actionTypeToGDWMapping.put("expressFreedom", "activateExpressFreedom");
    	actionTypeToGDWMapping.put("incentiveSaver", "activateIncentive");
    	actionTypeToGDWMapping.put("maxiSaver", "activateMaxiSaver");
    	actionTypeToGDWMapping.put("sense", "activateSense");
    	actionTypeToGDWMapping.put("applyBT", "applyBT");
    	actionTypeToGDWMapping.put("btSuperSearch", "btSuperSearch");
    	actionTypeToGDWMapping.put("applyGCC", "applyGCC");
    	actionTypeToGDWMapping.put("payCCBill", "payCCBill");
    	actionTypeToGDWMapping.put("switchPaperStmt", "switchPaperStmt");
    	actionTypeToGDWMapping.put("changeCardPIN", "changeCardPIN");
    	actionTypeToGDWMapping.put("expenseSplitter", "expenseSplitter");
    	actionTypeToGDWMapping.put("GetCash", "GetCash");//To add get Cash deep link
    	actionTypeToGDWMapping.put("Offer", "Offer");//Added for Additional Insertion Points Feature
    	actionTypeToGDWMapping.put("transferAndPay", "transferAndPay"); //Added for Transfer and pay deeplink
    	actionTypeToGDWMapping.put("closedAcctStmt", "closedAcctStmt"); //Added for closed acct deeplink
    	// added for Native App Redesign 17E4
    	actionTypeToGDWMapping.put("termDeposit", "termDeposit");
    	actionTypeToGDWMapping.put("msgCentre", "msgCentre");
    	actionTypeToGDWMapping.put("residencyInfo", "residencyInfo"); //Added for CRS Deep link
    	actionTypeToGDWMapping.put("manageTd", "manageTd"); // Term Deposit management
    }

		
		
	@Override
	protected ModelAndView handleRequestInternal(HttpServletRequest request,
			HttpServletResponse response) throws Exception {

		ModelAndView model = new ModelAndView(MainController.MAIN_VIEW);
		
		String sessionId = request.getParameter(SESSION_ID);
		String connectSessionId = request.getParameter(CONNECT_SESSION_ID);

		if ( ! StringMethods.isEmptyString(sessionId) || !StringMethods.isEmptyString(connectSessionId))
		{
			model=processRequest(request, response);
			if(model==null)
			{
				return redirectUserForLogin(request, response);
				
			}
		} else {
			response.sendRedirect(request.getContextPath()+"/?appAction=login");
			return null;
		}
		return model;
	}
	
	
	private ModelAndView redirectUserForLogin(HttpServletRequest request,HttpServletResponse response) throws IOException {
		String connectSessionId = request.getParameter(CONNECT_SESSION_ID);
		boolean userRedirectedFromConnectApp = !StringMethods.isEmptyString(connectSessionId);
		if(userRedirectedFromConnectApp) {
			String origin = LogonHelper.resolveOrigin(request);
            OriginsVO originVO = IBankParams.getOrigin(origin);
            request.setAttribute("origin",origin );
			request.setAttribute(MainController.ORIGIN_NAME, originVO.getName());
			request.setAttribute( MainController.REQ_ACTION_STR, REQ_TIMEOUT);
			request.setAttribute(MainController.WEB_CONTEXT, logonHelper.getMBWebResourceContext());
			request.setAttribute(MainController.SYS_VERSION, systemInformation.getMB3PackageVersion());
			int loadCordova = logonHelper.loadCordova(request);
			request.setAttribute(MainController.REQ_LOAD_CORDOVA, String.valueOf(loadCordova));
			String numKeyType =  logonHelper.getNumKeyBoardType(request);
			String numKeyTypePattern =  logonHelper.getNumKeyBoardPattern(request);
			request.setAttribute(MainController.NUM_KEYBOARD_TYPE, numKeyType);
			request.setAttribute(MainController.NUM_KEYBOARD_PATTERN_TYPE, numKeyTypePattern);
			return new ModelAndView(MainController.MAIN_VIEW);
		}
		else {
		    response.sendRedirect(request.getContextPath()+"/?appAction=login");
		    return null;
		}
		
	}


	public ModelAndView processRequest(HttpServletRequest request,HttpServletResponse response){
		String logName = END_POINT;
		String origin = null;
		String numKeyType = null;
		String numKeyTypePattern = null;
		String HOME_LOAN_APP_TRACKER ="homeLoanAppTracker";
		String F_ID = "fid";
		String C_ID = "cid";
		//20E3 - CSH  prepareonline 
		String CSH_PREPARE_ONLINE ="prepareOnline";
		String CSH_APPLY_ONLINE ="cshApplyOnline";
		String PURPOSE = "purpose";
		String OPPORTUNITY_ID = "oid";
		String LENDER_ID = "lid";
		String HMAC = "a";
		String STAGE = "stage";
		String JOINT = "jnt";
		String SID = "sid";
		String CTX = "ctx";
		boolean  reactivateOnline = false;
		
		ModelAndView model = new ModelAndView(MainController.MAIN_VIEW);
		IGenericSession genericSession = null;
		
		PerformanceLogger performanceLogger = new PerformanceLogger(true);
		performanceLogger.startAllLogs();
		performanceLogger.startLog(logName);
		
		try{
			Logger.debug("Inside Post Request. Device ID : " + request.getParameter(SMPL_DEVICE_ID) + " Sess Id : " + request.getParameter(SESSION_ID) + " lenderid "+ request.getParameter("lenderid"),this.getClass());
			Logger.debug("Inside smplLogonController method: " + request.getMethod() + " -- Request. Device ID : " + request.getParameter(SMPL_DEVICE_ID) + " Sess Id : " + request.getParameter(SESSION_ID) ,this.getClass());
			request.setAttribute(MainController.WEB_CONTEXT, logonHelper.getMBWebResourceContext());
			origin = LogonHelper.resolveOrigin(request);
			
			if(request.getParameter(SMPL_DEVICE_ID)==null || (request.getParameter(SESSION_ID)==null && request.getParameter(CONNECT_SESSION_ID)==null ) ){
				Logger.error("SessionID and DeviceID is not set in request.", this.getClass());
				throw new ResourceException(ResourceException.SYSTEM_ERROR,"SessionID and DeviceID is not set in request.");
			}
						
			String sessionId = request.getParameter(SESSION_ID);
			String getCashToken = request.getParameter(GET_CASH_TOKEN);
			String getCashFlag = request.getParameter(GET_CASH_FLAG);
			Logger.debug("getCAshToken from App : " + getCashToken + " : getCashFlag is from App is : " + getCashFlag, this.getClass());
			
			
			String sessDeviceId = null; 
			boolean loginViaConnect = false;
			if (request.getParameter(SESSION_ID)!=null){
				genericSession = GenericSessionFactory.getInstance(sessionId);
				
				Logger.debug("SmplLogonController - getting session :"+genericSession , this.getClass());
				
				if ( genericSession.getAttribute(SMPL_DEVICE_ID) != null )
				{
					sessDeviceId = (String) genericSession.getAttribute(SMPL_DEVICE_ID);
				}				
			}else{
				performanceLogger.startLog("Connect");
				//CONNECT!!!!!!!!!!!!!!!!
				String connectSessionID = request.getParameter(CONNECT_SESSION_ID);
				//read WSServiceSession and Validate Session
				Map<String, Object> connectSessionObj = logonHelper.getConnectSession(connectSessionID);
				
				//get USER from Session
				User user = logonHelper.getUserFromSession(connectSessionObj);
				Logger.debug("retrieve from connect session gcis: " + user.getGCISNumber() + " ++++ CAN: " + user.getUserId(), this.getClass());
				
				//get UserAgent from Session
				UserAgentVO userAgentVO = logonHelper.getUserAgentFromSession(connectSessionObj);
				Logger.debug("retrieve from connect session UserAgent: " + sessDeviceId, this.getClass());
				
				//deviceID from Session
				sessDeviceId = logonHelper.getDeviceIDFromSession(connectSessionObj);
				Logger.debug("retrieve from connect session DeviceID: " + sessDeviceId, this.getClass());
				
				//create MB Session
				genericSession = logonHelper.createMBSession(request, user, origin, sessDeviceId,logonHelper);
				
				//kill connect session
				logonHelper.deleteConnectSession(connectSessionID);
				
				loginViaConnect = true;
				performanceLogger.endLog("Connect");
				//TODO STATISTIC GDW
			}
			
				if(!isValidString(getCashToken)){
					Logger.info("Invalid Character in getCashToken " + getCashToken,  this.getClass());
					throw new BusinessException(BusinessException.INVALID_CHAR_SET, "Invalid Character");
				}
			
				if(!isValidString(getCashFlag)){
					Logger.info("Invalid Character in getCashFlag " + getCashFlag,  this.getClass());
					throw new BusinessException(BusinessException.INVALID_CHAR_SET, "Invalid Character");
				}
				else{
					request.setAttribute( MainController.GET_CASH_INDICATOR , getCashFlag+"");
					Logger.debug("getcashind: " + getCashFlag,  this.getClass());
				}
			
			Logger.debug("Inside without action, SessionID :" + genericSession.getId() + ", User Object : " + genericSession.getUser() + ",DeviceID : " + genericSession.getAttribute(SMPL_DEVICE_ID) ,this.getClass());
			genericSession.setAttribute(ORIGIN, origin);
			genericSession.setAttribute(GET_CASH_TOKEN, getCashToken);
			genericSession.setAttribute(GET_CASH_FLAG, getCashFlag);
			
			//20E3 UI Switch clean up starts
			/*String androidBackButtonSwitch="OFF";
			if(logonHelper.isAndroidBackBtnSupported(request) && IBankParams.isSwitchOn(IBankParams.ANDROID_BACKBUTTON_SWITCH)){
				androidBackButtonSwitch="ON";
			}
			request.setAttribute(MainController.ANDROID_BACK_BTN, androidBackButtonSwitch);*/
			//20E3 UI Switch clean up ends
			
			String smplRequestDeviceID = request.getParameter(SMPL_DEVICE_ID)==null?"":request.getParameter(SMPL_DEVICE_ID);
			if(!smplRequestDeviceID.equalsIgnoreCase(sessDeviceId)){
				Logger.error("Device ID do not match , Session Device ID :" + sessDeviceId + ", Request Device ID : " + request.getParameter(SMPL_DEVICE_ID) ,this.getClass());
				return null;
			}   
			request.setAttribute("origin",origin );
		
			request.setAttribute( MainController.REQ_ACTION_STR ,REQ_DASHBOARD );
			
			User user = genericSession.getUser();
			Logger.debug("ReactivateOnline: " + reactivateOnline+" CAN : "+user.getUserId()+" Logon Type "+user.getAttribute( IBankParams.LOGON_TYPE), this.getClass());
			if ( user != null && user.getAttribute(IBankParams.LOGON_TYPE) != null &&  IBankParams.LogonTypeEnum.OTP == user.getAttribute( IBankParams.LOGON_TYPE)  )
			{
				//Check for deep link actionType and throw error
				String actionType = request.getParameter(MainController.REQ_ACTION_TYPE);
				Logger.info("processRequest(): actionType:"+actionType+",....CAN: "+user.getUserId(), this.getClass());
/*				if(!StringUtils.isEmpty(actionType)) {
					Logger.warn("processRequest(): Deeplink request identified with actionType:"+actionType+",....CAN: "+user.getUserId(), this.getClass());
					throw new BusinessException(BusinessException.INVALID_USERID_PASSWORD);
				}  */
				
				reactivateOnline = true;
				Logger.info("Reactivate:  reactivateOnline " + reactivateOnline+" CAN : "+user.getUserId(), this.getClass());
				request.setAttribute( MainController.REQ_ACTION_STR ,REQ_REACTIVATE  );
			}
			
			String lenderid = request.getParameter("lenderid");
			if (! StringMethods.isEmptyString(lenderid))
			{
				if ( ! StringUtil.isValidAlphaNumeric(lenderid) )
				{
					Logger.error("Invalid Lender Id : " +lenderid , this.getClass());
					throw new ResourceException(ResourceException.SYSTEM_ERROR,  "Invalid Lender Id : " +lenderid  );
				}
				else
				{
					request.setAttribute( MobileSessionImpl.MORTGAGE_LENDER_ID , lenderid );
					genericSession.setAttribute( MobileSessionImpl.MORTGAGE_LENDER_ID , lenderid );
					
					Logger.info("Setting Lender Id in Session " + lenderid , this.getClass());
				}
			}
			
			//request.setAttribute( MainController.ANDROID_BACK_BTN , "ON");
			/*OnboardingVO onBoardingVo = genericSession.getOnboardingVO();
			
			if(onBoardingVo!=null){
				
				logger.debug("Onboarding ticket from session :"+onBoardingVo.getTicket());
				
				if(onBoardingVo.getTicket() != null && "SPIKEAPP".equalsIgnoreCase(onBoardingVo.getTicket()))
					request.setAttribute(MainController.REQ_ACTION_STR, "SPIKEAPP");	
				else if(onBoardingVo.getTicket() != null && "SPIKETC".equalsIgnoreCase(onBoardingVo.getTicket()))
					request.setAttribute(MainController.REQ_ACTION_STR, "SPIKETC");
				
			}*/
			
			logger.debug("Request attribute action = "+request.getAttribute(MainController.REQ_ACTION_STR));
			
			String actionType = request.getParameter(MainController.REQ_ACTION_TYPE);
			String actionSource = request.getParameter(MainController.REQ_ACTION_SOURCE);
			String actionId = request.getParameter(MainController.REQ_ACTION_ID);
			
			logger.debug("Request attribute action type = "+actionType);
			logger.debug("Request attribute action id = "+actionId);
			logger.debug("Request attribute actionSource = "+actionSource);
			
			if(!isValidString(actionType)){
				Logger.info("Invalid Character in Action Type " + actionType,  this.getClass());
				throw new BusinessException(BusinessException.INVALID_CHAR_SET, "Invalid Character");
			}
			
			if(!isValidString(actionId)){
				Logger.info("Invalid Character in Action ID " + actionId,  this.getClass());
				throw new BusinessException(BusinessException.INVALID_CHAR_SET, "Invalid Character");
			}
			
			if ( ! StringMethods.isEmptyString(actionType) && MainController.APPLY_GCC.equalsIgnoreCase(actionType) ){
				request.setAttribute( MainController.REQ_ACTION_TYPE ,MainController.APPLY_GCC );
			}else if ( ! StringMethods.isEmptyString(actionType) && MainController.APPLY_BT.equalsIgnoreCase(actionType) ){
				request.setAttribute( MainController.REQ_ACTION_TYPE, MainController.APPLY_BT );
			}else if ( ! StringMethods.isEmptyString(actionType) && MainController.BT_SUPER_SEARCH.equalsIgnoreCase(actionType) ){
				request.setAttribute( MainController.REQ_ACTION_TYPE, MainController.BT_SUPER_SEARCH );
			}else if ( ! StringMethods.isEmptyString(actionType) && MainController.SERVICE_MENU.equalsIgnoreCase(actionType) ){
				request.setAttribute( MainController.REQ_ACTION_TYPE ,MainController.SERVICE_MENU );
			}else if(!StringMethods.isEmptyString(actionType) 
					&& MainController.ONBOARDING_STATUS.equalsIgnoreCase(actionType) 
						&& !IBankParams.isOnboardingSwitchON()){
					request.removeAttribute(MainController.REQ_ACTION_TYPE);
			}else if(!StringMethods.isEmptyString(actionType) && HOME_LOAN_APP_TRACKER.equalsIgnoreCase(actionType) ) {
				if(IBankParams.isSwitchOn(IBankParams.getBaseOriginCode(origin), IBankParams.CSH_DISPLAY_TILE_SWITCH)) {
					request.setAttribute( MainController.REQ_ACTION_TYPE ,actionType);
					if(null != request.getParameter(F_ID) && !StringUtil.isRogueInputData(request.getParameter(F_ID))) {					
						request.setAttribute(F_ID, (String)request.getParameter(F_ID));					
					}					
					if(null != request.getParameter(C_ID) && !StringUtil.isRogueInputData(request.getParameter(C_ID))) {					
						request.setAttribute(C_ID, (String)request.getParameter(C_ID));					
					}		
				}
			}
			else if(!StringMethods.isEmptyString(actionType) && CSH_PREPARE_ONLINE.equalsIgnoreCase(actionType) ) {		
				request.setAttribute( MainController.REQ_ACTION_TYPE ,actionType);		
		
				if(null != request.getParameter(PURPOSE) && !StringUtil.isRogueInputData(request.getParameter(PURPOSE))) {					
					request.setAttribute(PURPOSE, (String)request.getParameter(PURPOSE));					
				}
				if(null != request.getParameter(OPPORTUNITY_ID) && !StringUtil.isRogueInputData(request.getParameter(OPPORTUNITY_ID))) {					
					request.setAttribute(OPPORTUNITY_ID, (String)request.getParameter(OPPORTUNITY_ID));					
				}				
				if(null != request.getParameter(LENDER_ID) && !StringUtil.isRogueInputData(request.getParameter(LENDER_ID))) {					
					request.setAttribute(LENDER_ID, (String)request.getParameter(LENDER_ID));					
				}
				if(null != request.getParameter(HMAC) && !StringUtil.isRogueInputData(request.getParameter(HMAC))) {					
					request.setAttribute(HMAC, (String)request.getParameter(HMAC));					
				}
				
				if(null != request.getParameter(STAGE) && !StringUtil.isRogueInputData(request.getParameter(STAGE))) {					
					request.setAttribute(STAGE, (String)request.getParameter(STAGE));					
				}
				if(null != request.getParameter(JOINT) && !StringUtil.isRogueInputData(request.getParameter(JOINT))) {					
					request.setAttribute(JOINT, (String)request.getParameter(JOINT));					
				}
				if(null != request.getParameter(SID) && !StringUtil.isRogueInputData(request.getParameter(SID))) {					
					request.setAttribute(SID, (String)request.getParameter(SID));					
				}
				if(null != request.getParameter(CTX) && !StringUtil.isRogueInputData(request.getParameter(CTX))) {					
					request.setAttribute(CTX, (String)request.getParameter(CTX));					
				}			

			} else if (!StringMethods.isEmptyString(actionType) && CSH_APPLY_ONLINE.equalsIgnoreCase(actionType)) {
				request.setAttribute(MainController.REQ_ACTION_TYPE, actionType);

				if (null != request.getParameter(PURPOSE) && !StringUtil.isRogueInputData(request.getParameter(PURPOSE))) {
					request.setAttribute(PURPOSE, (String) request.getParameter(PURPOSE));
				}
				if (null != request.getParameter(STAGE) && !StringUtil.isRogueInputData(request.getParameter(STAGE))) {
					request.setAttribute(STAGE, (String) request.getParameter(STAGE));
				}
				if (null != request.getParameter(JOINT) && !StringUtil.isRogueInputData(request.getParameter(JOINT))) {
					request.setAttribute(JOINT, (String) request.getParameter(JOINT));
				}
			}
			else{
				request.setAttribute( MainController.REQ_ACTION_TYPE ,actionType);
			}
			
			if ( ! StringMethods.isEmptyString(actionId) )
				request.setAttribute( MainController.REQ_ACTION_ID ,actionId);
			
			if(actionType != null || loginViaConnect == true) {
				String gcisNumber = genericSession.getUser()==null?"":genericSession.getUser().getGCISNumber();
				addStatisticLog(actionType, genericSession.getId(),loginViaConnect, origin, gcisNumber, MBAppHelper.resolveIPAddress(request, origin),actionSource);
			}
			
			request.setAttribute(MainController.PRELOAD_VALUE, 2);  // Complete

			//String userAgent = request.getHeader("User-Agent").toLowerCase();			
			response.setHeader("Set-Cookie", MBAppConstants.SMPL_SESS_CONSTANT + "=" + genericSession.getId()   + "; HttpOnly ; Secure; path=/" );
			
			int loadCordova = logonHelper.loadCordova(request);
			request.setAttribute(MainController.REQ_LOAD_CORDOVA, String.valueOf(loadCordova));
			
			numKeyType =  logonHelper.getNumKeyBoardType(request);
			numKeyTypePattern =  logonHelper.getNumKeyBoardPattern(request);
			request.setAttribute(MainController.NUM_KEYBOARD_TYPE, numKeyType);
			request.setAttribute(MainController.NUM_KEYBOARD_PATTERN_TYPE, numKeyTypePattern);
			
			OriginsVO originVO = IBankParams.getOrigin(origin);
			
			request.setAttribute(MainController.ORIGIN_NAME, originVO.getName());

			request.setAttribute(MainController.SYS_VERSION, systemInformation.getMB3PackageVersion());
			Cookie appVersionCookie = CommonBusinessUtil.getCookie(request, IBankParams.APP_VER_COOKIE);

			String lpMessagingSwitch = "OFF";
			CodesVO codesVO = IBankParams.getCodesData(IBankParams.getBaseOriginCode(origin),	IBankParams.CONFIGURATION_PROPERTIES, IBankParams.LP_MESSAGING_SWITCH);
			if ( (codesVO == null) || codesVO != null  && "ON".equalsIgnoreCase(codesVO.getMessage())){
				lpMessagingSwitch = "ON";
			}
			request.setAttribute(MainController.LP_MESSAGING_SWITCH, lpMessagingSwitch);
			
			Boolean isLpOldAppVersion = !CommonBusinessUtil.cookieContainsValue(appVersionCookie, MainController.CHAT);
			if(isLpOldAppVersion) {
				request.setAttribute(MainController.LP_NATIVE_OLD_APP_SWITCH, IBankParams.ON);
			}else {
				request.setAttribute(MainController.LP_NATIVE_OLD_APP_SWITCH, IBankParams.OFF);
			}
			

			if ( reactivateOnline )
			{
				Logger.info("Reactivate Flow Setting Help Desk Num  " + reactivateOnline+" CAN : "+user.getUserId() + " HelpDesk "+ originVO.getPhone(), this.getClass());
				request.setAttribute(MainController.HELP_DESK_NO, originVO.getPhone());
			}
			
			genericSession.updateSession();
			performanceLogger.setPrefix("GCIS:" + genericSession.getUser().getGCISNumber() + ";SESSIONID:" + genericSession.getId() + ";BRAND:" + origin +";");
		
			
		}catch(ResourceException re){

			Logger.error("ResourceException Request Details. URL : "+ request.getRequestURL() + " IP :" + request.getRemoteAddr() +
					" True IP >> " + request.getHeader(IBankParams.trueClientIP()), re  , this.getClass());
			model = null;
		
		}
		catch (Exception e)
		{
			Logger.error("Request Details. URL : "+ request.getRequestURL() + " IP :" + request.getRemoteAddr() +
					" True IP >> " + request.getHeader(IBankParams.trueClientIP()), e, this.getClass());
			model = null;
		}
		finally
		{
			if ( performanceLogger!=null )
			{
	            performanceLogger.endLog(logName);
	            performanceLogger.endAllLogs();  
			}
			
		}

		return model;
	}

	private boolean isValidString(String actionType){
		
		if(StringMethods.isEmptyString(actionType)){
			return true;
		}

		String pattern = BLOCK_CHARS;
		Pattern r = Pattern.compile(pattern);

		Matcher m = r.matcher(actionType);
		if (m.find()) {
			return true;
		} 
		return false;
	}
	
	

	public Cookie getCookie(HttpServletRequest request, String cookieName) throws ResourceException
	{

		Cookie[] cookies = request.getCookies();
		Cookie cookie = null;
		if (cookies != null)
		{
			for (int i = 0; i < cookies.length; i++)
			{
		//		Logger.info("Cookie Name" + cookies[i].getName() + " found in the request. Value : " + cookie.getValue() , this.getClass());
				if (cookies[i].getName().equals(cookieName))
				{
						cookie = cookies[i]; 
						Logger.info("Cookie " + cookieName + " found in the request. Value : " + cookie.getValue() , this.getClass());
					  break;
				}
			}
		}
		return cookie;
	}

	@Autowired
	private LogonHelper logonHelper;

	
	@Autowired
	private SystemInformation systemInformation;

	private void addStatisticLog(String statAction, String sessionID,boolean loginViaConnect, String origin, String gcisNumber, String ipAddress,String actionSource){
		String gdwData =  getGDWMappedInfo(statAction);
		
		if(actionSource != null && actionSource.length() > 0){
			gdwData = gdwData+":"+actionSource;
		}
		
		String gdwActionType = loginViaConnect?MainController.GDW_ACTION_CONNECT:MainController.GDW_ACTION_MB;
		
		Statistic statistic = new Statistic();
		statistic.setAction(gdwActionType);
		statistic.setGcisNumber(gcisNumber);
		statistic.setOriginBank(origin);
		statistic.setIpAddress(ipAddress);
		statistic.setSessionId(sessionID);
		statistic.setDescription(gdwData);
		try {
			StatisticsService.logStatistic(statistic);	
		} catch (Exception e) {
			Logger.error("Failed to create a statistic entry for addStatistics",e, SmplLogonController.class);
		}
	}
	
	private String getGDWMappedInfo(String actionType) {
		String actionTypeKey = "default";
		if(actionType != null && actionType.trim().length() > 0) {
			actionTypeKey = actionType;
		}
		return actionTypeToGDWMapping.get(actionTypeKey);
	}
	
	
	private Customer getCustomer(IBankCommonData commonData , String statistic) throws BusinessException,ResourceException{
		//	IBankCommonData commonData = populateIBankCommonData(sessionId,user , origin, ipAddress);
		MobileBankService mobileBankService = (MobileBankService) ServiceHelper.getBean(MBAppConstants.SPRING_MOBILE_SERVICE_BEAN);
		Customer customer = mobileBankService.getCustomer(commonData, statistic);
		return customer;
	}
	
//	private IBankCommonData populateIBankCommonData(String sessionId, User user, String origin, String ipAddress ,String userAgent)
//	{
//		IBankCommonData commonData = new IBankCommonData();
//		commonData.setUser(user);
//		commonData.setOrigin(origin);
//		commonData.setIpAddress(ipAddress);
//		commonData.setSessionId(sessionId);
//		commonData.setUserAgent(userAgent);
//		return commonData;
//	}
	
	
}