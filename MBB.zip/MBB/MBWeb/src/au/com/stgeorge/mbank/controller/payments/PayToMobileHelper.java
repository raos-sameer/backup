package au.com.stgeorge.mbank.controller.payments;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import au.com.stgeorge.framework.common.logging.Logger;
import au.com.stgeorge.ibank.businessobject.BusinessException;
import au.com.stgeorge.ibank.businessobject.impl.P2PPaymentServiceImpl;
import au.com.stgeorge.ibank.common.cache.IBankParams;
import au.com.stgeorge.ibank.util.StringUtil;
import au.com.stgeorge.ibank.valueobject.Account;
import au.com.stgeorge.ibank.valueobject.AccountId;
import au.com.stgeorge.ibank.valueobject.Customer;
import au.com.stgeorge.ibank.valueobject.P2PPayment;
import au.com.stgeorge.ibank.valueobject.PaymentDuplicateVO;
import au.com.stgeorge.ibank.valueobject.database.CodesVO;
import au.com.stgeorge.ibank.valueobject.transfer.IBankCommonData;
import au.com.stgeorge.mbank.model.common.AccountKeyInfoResp;
import au.com.stgeorge.mbank.model.common.RespHeader;
import au.com.stgeorge.mbank.model.payments.PayToMobileDetailResp;
import au.com.stgeorge.mbank.model.request.payments.PayToMobileReq;
import au.com.stgeorge.mbank.model.response.payments.DuplicatePaymentResp;
import au.com.stgeorge.mbank.model.response.payments.PayToMobileResp;
import au.com.stgeorge.mbank.model.response.payments.TransferReceiptResp;
import au.com.stgeorge.mbank.model.response.payments.TransferResp;
import au.com.stgeorge.mbank.util.MBAppHelper;
import au.com.stgeorge.mbank.util.MBAppUtils;

@Service
public class PayToMobileHelper {
	
	private static String AUS_ISD_CODE = "\\+61";

	@Autowired
	private MBAppHelper mbAppHelper;
	
	protected void validateTransferReq(PayToMobileReq request) throws BusinessException {
		if (request.getScheduleDetail() != null) new TransferHelper().validateTransferSchedule(request.getScheduleDetail());
		CodesVO myVO = IBankParams.getCodesData(IBankParams.DEFAULT_ORIGIN, P2PPaymentServiceImpl.P2P_CATEGORY, "AmtThreshold");
		int amtThreshold = Integer.parseInt(myVO.getMessage());
		if (Double.parseDouble(request.getAmt()) > amtThreshold) {
			throw new BusinessException(BusinessException.P2P_AMT_THRESHOLD_ERROR);
		}
	}

	protected P2PPayment populatePayment(Customer customer, IBankCommonData commonData, PayToMobileReq request) {
		Account fromAcct = customer.getAccounts().get(request.getFromAccountIndex());
		P2PPayment payment = new P2PPayment();
		String temp = (request.getAmt() == null) ? "" : request.getAmt();
		payment.setFromAcct(fromAcct);
		payment.setAmount(new BigDecimal(temp.replaceAll("\\$", "").replaceAll(",", "")));
		payment.setRecipientAcctName(request.getReceiverName());
		payment.setDescription(request.getDesc());
		if (payment.getDescription()==null){
			payment.setDescription("");
		}
		payment.setPayerName(request.getPayerName());
		
		if(request.getMobileNumber() != null){
			String mobileNumber = request.getMobileNumber().replaceAll(" ", "");//Temp, until GUI fixes it
			mobileNumber = mobileNumber.replaceFirst(AUS_ISD_CODE, "0");
			payment.setRecipientMobNum(mobileNumber);
		} 
		
		if (request.getFromNativeContacts() != null)
			payment.setRecipientMobNumNative(request.getFromNativeContacts());
		
		if(request.getSendPayerEmail() != null){
			payment.setSendPayerEmail(request.getSendPayerEmail());
		}
		
		payment.setRecipientEmail(request.getRecipientEmail());
		
		if (request.getDupCount() != null){
			payment.setDuplicatePaymentCount(request.getDupCount());
		}
		return payment;
	}

	protected TransferResp populateTransferResponse(RespHeader header, P2PPayment payment, String requestId) {
		TransferResp transferResponse = new TransferResp(header);
		transferResponse.setReceipt(new TransferReceiptResp());
		transferResponse.getReceipt().setAmt(payment.getAmount().toString());

		Account fromAcct = payment.getFromAcct();
		
		if(fromAcct.getAvailableBalance() != null)
			transferResponse.getReceipt().setFromAccountAvailBalance(fromAcct.getAvailableBalance().toString());
		if(fromAcct.getBalanceDisplay() != null)
			transferResponse.getReceipt().setFromAccountBalance(fromAcct.getBalanceDisplay().toString());
		
		String formattedRequestId = StringUtil.formatReceiptNumber(requestId);
		if( !payment.isStraightThrough() ) {
			formattedRequestId = "P " + formattedRequestId;
		}
		
		transferResponse.getReceipt().setReceiptNumDisp(formattedRequestId);
		transferResponse.setIsStraightThrough(payment.isStraightThrough());
		transferResponse.getReceipt().setTranDateTime(new Date());
		
		Calendar p2mExpDate = Calendar.getInstance();
		p2mExpDate.setTime(new Date());
		p2mExpDate.add(Calendar.DAY_OF_MONTH, 3);
		transferResponse.setP2mTokenExpDateTime(p2mExpDate.getTime());

		Logger.info("Response populated: " + transferResponse, this.getClass());
		return transferResponse;
	}

	protected PayToMobileResp populatePaymentListResp(List<P2PPayment> payToMobReqs,Customer customer) {
		
		PayToMobileResp resp = new PayToMobileResp();
		PayToMobileDetailResp detail = null;		 
		List<PayToMobileDetailResp> list = null;
		
		if(payToMobReqs != null){
			
			list = new ArrayList<PayToMobileDetailResp>();
			Iterator<P2PPayment> it = payToMobReqs.iterator();
			List<Account> accts = customer.getAccounts();
			
			while(it.hasNext()){
				
				detail = new PayToMobileDetailResp();
				P2PPayment payment = it.next();
				if ( payment.getPaymentStatus() != null &&  P2PPaymentServiceImpl.STRAIGHT_THROUGH == payment.getPaymentStatus().intValue() )
				{
					Logger.debug("Staright through Payment " + payment.getId()  , this.getClass());
					continue;
				}
				AccountId acctId = new AccountId();
				acctId.setAccountNumber(payment.getAcctNum());
				acctId.setApplicationId(payment.getApplID());
				
				Account fromAccount = MBAppHelper.getAccountbyAccountId(acctId,accts);
				if(fromAccount != null){					
					AccountKeyInfoResp keyInfo = mbAppHelper.getAcctKeyInfoResp(fromAccount);
										
					detail.setFromAccountName(fromAccount.getAlias());
					detail.setFromAccountNumDisp(keyInfo.getAccountNumDisp());
					detail.setFromBsbDisp(keyInfo.getBsbDisp());
				}else{				
					detail.setFromAccountNumDisp(StringUtil.formatDDAAccountNumber(payment.getAcctNum()));
					detail.setFromAccountName(StringUtil.formatDDAAccountNumber(payment.getAcctNum()));
				}
				
				detail.setId(payment.getId());
				detail.setIdDisp(MBAppUtils.formatPayMobRequest(payment.getId().toString()));
				detail.setMobileNum(payment.getRecipientMobNum());
				detail.setToAccountName(payment.getRecipientAcctName());
				detail.setStatusCode(Integer.parseInt(payment.getPaymentStatus().toString()));
				detail.setStatusDisp(payment.getPaymentStatusDesp());
				detail.setRequestDate(payment.getCreatedOn());
				detail.setAmt(payment.getAmount().toString());
				detail.setDesc(payment.getDescription());
				detail.setExpiryDate(payment.getTokenExpiryDate());
				detail.setPayerName(payment.getPayerName());
				
				if(payment.getPaymentStatus() == P2PPaymentServiceImpl.UNSUCCESSFUL)
					detail.setErrorDesc(payment.getErrorMsg());
				
				if(payment.getPaymentStatus() == P2PPaymentServiceImpl.COMPLETED){
					detail.setToBsbDisp(payment.getRecipientBSBNum());
					detail.setToAccountNumDisp(payment.getRecipientAcctNum());
					detail.setCompletionDate(payment.getPaymentDate());
					detail.setReceiptNumDisp(MBAppUtils.formatReceiptNumber(payment.getReceiptNumber()));
				}
					
				list.add(detail);
			}
			resp.setPayToMobileRequests(list);
		}
		
		return resp;
	}
	
	protected PayToMobileResp populatePaymentCancelResp() {
		
		PayToMobileResp resp = new PayToMobileResp();
		
		CodesVO myVO=IBankParams.getCodesData(IBankParams.DEFAULT_ORIGIN, P2PPaymentServiceImpl.P2P_CATEGORY, ""+P2PPaymentServiceImpl.CANCELLED);
      	if(myVO!=null){
      		resp.setStatusCode(P2PPaymentServiceImpl.CANCELLED);
      		resp.setStatusDisp(myVO.getMessage());
      	}
				
		return resp;		
	}	
	
	/**
	 * Populate service response - duplicate
	 * 
	 * @param header
	 * @param duplicates
	 * @return
	 */
	protected TransferResp populateTransferResponse(RespHeader header, List<PaymentDuplicateVO> duplicates, List<Account> accountList) {
		TransferResp payeeTransferResponse = new TransferResp(header);
		payeeTransferResponse.setDupList(new ArrayList<DuplicatePaymentResp>());
		for (PaymentDuplicateVO duplicateVO : duplicates) {
			DuplicatePaymentResp duplResp = new DuplicatePaymentResp();
			duplResp.setDesc(duplicateVO.getReferenceNumber());
			//if BPAY - desc is null
//			if (this instanceof BPayHelper) duplResp.setDesc(null); - reverted
			duplResp.setFromAccountNumDisp(duplicateVO.getAccountNumberFrom());
			for (Account fromAccount : accountList) {
				if (fromAccount != null && fromAccount.getAccountId() != null) {
					if (fromAccount.getAccountId().getAccountNumber().equals(duplicateVO.getAccountNumberFrom())) {
						duplResp.setFromAccountName(fromAccount.getAlias());
						duplResp.setFromAccountNumDisp(new MBAppHelper().getFormattedAcctNumber(fromAccount
							    .getAccountId().getAccountNumber(), fromAccount.getAccountId()
							    .getApplicationId(), fromAccount.getAccountId().getBsb()));
					}
				}
			}
			duplResp.setTranDateTime(duplicateVO.getPDate());
			duplResp.setSeqNum(duplicateVO.getId());
			payeeTransferResponse.getDupList().add(duplResp);
		}
		return payeeTransferResponse;
	}
}
