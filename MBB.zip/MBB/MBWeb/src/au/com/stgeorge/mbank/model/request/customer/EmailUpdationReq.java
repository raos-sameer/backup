package au.com.stgeorge.mbank.model.request.customer;

import java.io.Serializable;

import au.com.stgeorge.mbank.model.common.IMBReq;
import au.com.stgeorge.mbank.model.common.ReqHeader;

public class EmailUpdationReq implements IMBReq, Serializable{
	
	private static final long serialVersionUID = -256469501889499302L;
	
	private ReqHeader header;
	
	public ReqHeader getHeader() {
		return header;
	}
	public void setHeader(ReqHeader header)	{
		this.header = header;
	}
	
}
