package au.com.stgeorge.mbank.model.common;

import java.util.ArrayList;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_NULL)
public class ContactInfoResp
{
	private ArrayList <PhoneInfoResp>  phones;
	private ArrayList <AddressResp>  addresses;
  private String emailAddress;
  
	public ArrayList<PhoneInfoResp> getPhones()
	{
		return phones;
	}
	public void setPhones(ArrayList<PhoneInfoResp> phones)
	{
		this.phones = phones;
	}
	public ArrayList<AddressResp> getAddresses()
	{
		return addresses;
	}
	public void setAddresses(ArrayList<AddressResp> addresses)
	{
		this.addresses = addresses;
	}
	public String getEmailAddress()
	{
		return emailAddress;
	}
	public void setEmailAddress(String emailAddress)
	{
		this.emailAddress = emailAddress;
	}
	
	
}
