package au.com.stgeorge.mbank.controller.services;

import java.util.Calendar;
import java.util.UUID;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;

import au.com.stgeorge.digitalsec.logger.DigitalSecLogger;
import au.com.stgeorge.digitalsec.logger.DigitalSecLogggerVO;
import au.com.stgeorge.framework.common.logging.Logger;
import au.com.stgeorge.framework.common.util.StringMethods;
import au.com.stgeorge.ibank.businessobject.BusinessException;
import au.com.stgeorge.ibank.businessobject.HeartBeat;
import au.com.stgeorge.ibank.businessobject.IBankSecureService;
import au.com.stgeorge.ibank.businessobject.ResourceException;
import au.com.stgeorge.ibank.common.cache.IBankParams;
import au.com.stgeorge.ibank.service.businessobject.CreditCardClosureService;
import au.com.stgeorge.ibank.service.valueobject.CCClosureReqVO;
import au.com.stgeorge.ibank.valueobject.Account;
import au.com.stgeorge.ibank.valueobject.CreditCardAccount;
import au.com.stgeorge.ibank.valueobject.Customer;
import au.com.stgeorge.ibank.valueobject.NonFinTransactionDetails;
import au.com.stgeorge.ibank.valueobject.transfer.IBankCommonData;
import au.com.stgeorge.ibank.valueobject.wdp.CCClosurePreparationData;
import au.com.stgeorge.ibank.valueobject.wdp.PayoutQuoteData;
import au.com.stgeorge.mbank.controller.IMBController;
import au.com.stgeorge.mbank.controller.SecureCodeHelper;
import au.com.stgeorge.mbank.controller.customer.LogonHelper;
import au.com.stgeorge.mbank.model.common.IMBReq;
import au.com.stgeorge.mbank.model.common.IMBResp;
import au.com.stgeorge.mbank.model.common.ReqHeader;
import au.com.stgeorge.mbank.model.common.RespHeader;
import au.com.stgeorge.mbank.model.request.SecureCodeReq;
import au.com.stgeorge.mbank.model.request.services.CCClosureEligibilityReq;
import au.com.stgeorge.mbank.model.request.services.CCClosurePayoutReq;
import au.com.stgeorge.mbank.model.request.services.CCClosureReq;
import au.com.stgeorge.mbank.model.response.ErrorResp;
import au.com.stgeorge.mbank.model.response.SuccessResp;
import au.com.stgeorge.mbank.session.MobileSession;
import au.com.stgeorge.mbank.util.FraudLogger;
import au.com.stgeorge.mbank.util.MBAppHelper;
import au.com.stgeorge.mbank.util.MBAppUtils;
import au.com.stgeorge.mbank.util.MBAppValidator;
import au.com.stgeorge.mbank.util.ServiceConstants;
import au.com.stgeorge.perflogger.PerformanceLogger;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

@Controller
@RequestMapping("/ccclosure")
public class CCClosureController implements IMBController{
	
	@Autowired
	private MBAppHelper mbAppHelper;
	
	@Autowired
	private CCClosureHelper ccClosureHelper;
	
	@Autowired
	private MBAppValidator mbAppValidator;
				
	@Autowired
	private PerformanceLogger perfLogger;
	
	@Autowired
	private CreditCardClosureService creditCardClosureService;
	
	@Autowired
	private SecureCodeHelper secureCodeHelper;
	
	@Autowired
    private DigitalSecLogger digitalSecurityLogger;
	
	@Autowired
	private LogonHelper logonHelper;
	
	@RequestMapping(value= "eligiblecards" , method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public IMBResp getEligibleCards(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, @RequestBody final CCClosureEligibilityReq req){
		
		ObjectMapper objectMapper = new ObjectMapper();							
		perfLogger.startAllLogs();
		String logName = MBAppUtils.getLogName(httpServletRequest);
		perfLogger.startLog(logName);
		
		new FraudLogger();
		MobileSession mbSession = null;
		String accountId = null;

		try{	
			
			mbSession = mbAppHelper.getMobileSession(httpServletRequest);
			mbSession.removeCCClosureAppCorrID();
			mbSession.removeCCClosureEligibleCards();
			
			Logger.info("CC closure getEligibleCards List JSON Request :" + objectMapper.writeValueAsString(req), this.getClass());
			validateRequestHeader(req.getHeader(), httpServletRequest);
			ErrorResp errorResp = validate(req, httpServletRequest);
			if (errorResp != null && errorResp.getErrors() != null && errorResp.getErrors().size() > 0)	{				
				return errorResp;
			}
															
			IBankCommonData commonData=mbAppHelper.populateIBankCommonData(mbSession,httpServletRequest);
			
			if(!HeartBeat.isApplicationAvailable(HeartBeat.VISION_PLUS))
					throw new BusinessException(BusinessException.SYSTEM_UNAVILABLE);
			
			if(!StringMethods.isEmptyString(req.getAccountIndex())){
				Account selectedAccount = mbSession.getCustomer().getAccounts().get(Integer.parseInt(req.getAccountIndex()));
				accountId = selectedAccount.getAccountId().getAccountNumber();
			}
			
			UUID appCorrelationID = UUID.randomUUID();
			mbSession.setCCClosureAppCorrID(appCorrelationID);
			CCClosurePreparationData ccClosurePrepData = creditCardClosureService.retrieveEligibleCardsForClosure(commonData, appCorrelationID,accountId);
			
			IMBResp serviceResponse = ccClosureHelper.populateCCClosureEligibleCardsResp(ccClosurePrepData,IBankParams.getBaseOriginCode(commonData.getOrigin()));			 					
			RespHeader headerResp = populateResponseHeader(ServiceConstants.CC_CLOSURE_ELIGIBLE_CARDLIST_SERVICE, mbSession);
			serviceResponse.setHeader(headerResp);			
			
			mbSession.setCCClosureEligibleCards(ccClosurePrepData.getAccounts());
			Logger.info("CC closure getEligibleCards List JSON Response :" + objectMapper.writeValueAsString(serviceResponse), this.getClass());
			
			return serviceResponse;		
		}catch (BusinessException e) {			
			Logger.info("BusinessException Inside getEligibleCards() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());			
			BusinessException exp = new BusinessException(e.getKey());
			IMBResp resp1  = MBAppUtils.createErrorResp(IBankParams.getBaseOriginCode(mbSession.getOrigin()), exp, ServiceConstants.CC_CLOSURE_ELIGIBLE_CARDLIST_SERVICE, httpServletRequest);
			return resp1;
		}catch (ResourceException e) {
			Logger.error("ResourceException Inside getEligibleCards() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			ResourceException exp = new ResourceException(e.getKey());
			IMBResp resp1  = MBAppUtils.createErrorResp(IBankParams.getBaseOriginCode(mbSession.getOrigin()), exp, ServiceConstants.CC_CLOSURE_ELIGIBLE_CARDLIST_SERVICE, httpServletRequest);
			return resp1;
		}catch (Exception e) {
			Logger.error("Exception Inside getEligibleCards() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			BusinessException exp = new BusinessException(BusinessException.GENERIC_ERROR);
			IMBResp resp1  = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, ServiceConstants.CC_CLOSURE_ELIGIBLE_CARDLIST_SERVICE, httpServletRequest);
			return resp1;
		} finally {
			perfLogger.endLog(logName);
			perfLogger.endAllLogs();
		}
	}
	
	@RequestMapping(value= "payoutQuote" , method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public IMBResp getPayoutQuote(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, @RequestBody final CCClosurePayoutReq req){
		
		ObjectMapper objectMapper = new ObjectMapper();							
		perfLogger.startAllLogs();
		String logName = MBAppUtils.getLogName(httpServletRequest);
		perfLogger.startLog(logName);
		
		new FraudLogger();
		MobileSession mbSession = null;
		String accountId = null;

		try{	
			
			mbSession = mbAppHelper.getMobileSession(httpServletRequest);
			mbSession.removeCCClosureReason();
			mbSession.removeCCClosurePayoutDate();
			mbSession.removeCCClosurePayoutAmount();
			
			Logger.info("CC closure getPayoutQuote List JSON Request :" + objectMapper.writeValueAsString(req), this.getClass());
			validateRequestHeader(req.getHeader(), httpServletRequest);
			ErrorResp errorResp = validate(req, httpServletRequest);
			if (errorResp != null && errorResp.getErrors() != null && errorResp.getErrors().size() > 0)	{				
				return errorResp;
			}
			
			ErrorResp errorResponse = ccClosureHelper.validatePayoutReq(req, mbSession);
			if (errorResponse != null && errorResponse.getErrors() != null && errorResponse.getErrors().size() > 0)	{				
				return errorResponse;
			}
															
			IBankCommonData commonData=mbAppHelper.populateIBankCommonData(mbSession,httpServletRequest);
			
			if(!HeartBeat.isApplicationAvailable(HeartBeat.VISION_PLUS))
					throw new BusinessException(BusinessException.SYSTEM_UNAVILABLE);
			
			Account selectedAccount = mbSession.getCustomer().getAccounts().get(Integer.parseInt(req.getAccountIndex()));
			accountId = selectedAccount.getAccountId().getAccountNumber();
			
			UUID appCorreleationID = mbSession.getCCClosureAppCorrID();
			if(appCorreleationID==null){
				appCorreleationID = UUID.randomUUID();
			}
			
			PayoutQuoteData payoutData = creditCardClosureService.calculatePayoutQuote(commonData, appCorreleationID, accountId, mbSession.getCCClosureEligibleCards(), Calendar.getInstance(), 0);
			
			IMBResp serviceResponse = ccClosureHelper.populatePayoutDataResp(payoutData);			 					
			RespHeader headerResp = populateResponseHeader(ServiceConstants.CC_CLOSURE_PAYOUT_QUOTE, mbSession);
			serviceResponse.setHeader(headerResp);			
			
			if(!"008".equalsIgnoreCase(req.getReasonCode())){
				mbSession.setCCClosureReason(req.getReasonCode());
			}else{
				mbSession.setCCClosureReason(req.getReasonCode()+":"+req.getOtherDescription());
			}
			mbSession.setCCClosurePayoutDate(payoutData.getPayoutDate());
			mbSession.setCCClosurePayoutAmount(payoutData.getPayoutAmount());// keeping in session without sign

			Logger.info("CC closure getPayoutQuote List JSON Response :" + objectMapper.writeValueAsString(serviceResponse), this.getClass());
			
			return serviceResponse;		
		}catch (BusinessException e) {			
			Logger.info("BusinessException Inside getPayoutQuote() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			BusinessException exp = new BusinessException(e.getKey());
			
			if(e.getKey() == BusinessException.CC_CLOSURE_POSITIVE_PAYOUT_MORE_THAN_MAXAMOUNT){
				return MBAppUtils.createErrorResp(IBankParams.getBaseOriginCode(mbSession.getOrigin()), e.getKey(), 
						MBAppUtils.getMessage(IBankParams.getBaseOriginCode(mbSession.getOrigin()), e.getKey(), new String[] {IBankParams.getCCClosureMaxAmount()}), ServiceConstants.CC_CLOSURE_PAYOUT_QUOTE, httpServletRequest);
			}
			
			IMBResp resp1  = MBAppUtils.createErrorResp(IBankParams.getBaseOriginCode(mbSession.getOrigin()), exp, ServiceConstants.CC_CLOSURE_PAYOUT_QUOTE, httpServletRequest);
			return resp1;
		}catch (ResourceException e) {
			Logger.error("ResourceException Inside getPayoutQuote() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			ResourceException exp = new ResourceException(e.getKey());
			IMBResp resp1  = MBAppUtils.createErrorResp(IBankParams.getBaseOriginCode(mbSession.getOrigin()), exp, ServiceConstants.CC_CLOSURE_PAYOUT_QUOTE, httpServletRequest);
			return resp1;
		}catch (Exception e) {
			Logger.error("Exception Inside getPayoutQuote() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			BusinessException exp = new BusinessException(BusinessException.GENERIC_ERROR);
			IMBResp resp1  = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, ServiceConstants.CC_CLOSURE_PAYOUT_QUOTE, httpServletRequest);
			return resp1;
		} finally {
			perfLogger.endLog(logName);
			perfLogger.endAllLogs();
		}
	}
	
	@RequestMapping(value= "validateCCClosureReq" , method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public IMBResp validateCCClosureReq(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, @RequestBody final CCClosureReq req){
		
		ObjectMapper objectMapper = new ObjectMapper();							
		perfLogger.startAllLogs();
		String logName = MBAppUtils.getLogName(httpServletRequest);
		perfLogger.startLog(logName);
		
		new FraudLogger();
		MobileSession mbSession = null;

		try{	
			
			mbSession = mbAppHelper.getMobileSession(httpServletRequest);
			mbSession.removeCCClosureReqVO();
			Logger.info("validateCCClosureReq JSON Request :" + objectMapper.writeValueAsString(req), this.getClass());
			validateRequestHeader(req.getHeader(), httpServletRequest);
			ErrorResp errorResp = validate(req, httpServletRequest);
			if (errorResp != null && errorResp.getErrors() != null && errorResp.getErrors().size() > 0)	{				
				return errorResp;
			}
															
			IBankCommonData commonData=mbAppHelper.populateIBankCommonData(mbSession,httpServletRequest);
			
			if(hasSecureCodeConstraints(commonData.getCustomer()) || !CCClosureHelper.isPhoneNumberAvailable(commonData.getCustomer().getContactDetail())){
				throw new BusinessException(BusinessException.CC_CLOSURE_2FA_EXEMPT_NO_NUMBER);
			}
			
			CCClosureReqVO ccClosureReqVO = ccClosureHelper.populateClosureReqVO(req);
			mbSession.setCCClosureReqVO(ccClosureReqVO);
			SuccessResp serviceResponse = new SuccessResp();
			serviceResponse.setIsSuccess(true);
			RespHeader headerResp = populateResponseHeader(ServiceConstants.CC_CLOSURE_VALIDATE_CLOSURE_REQ, mbSession);
			serviceResponse.setHeader(headerResp);
			
			Logger.info("validateCCClosureReq JSON Response :" + objectMapper.writeValueAsString(serviceResponse), this.getClass());
			
			return serviceResponse;		
		}catch (BusinessException e) {			
			Logger.info("BusinessException Inside validateCCClosureReq() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());			
			BusinessException exp = new BusinessException(e.getKey());
			IMBResp resp1  = MBAppUtils.createErrorResp(IBankParams.getBaseOriginCode(mbSession.getOrigin()), exp, ServiceConstants.CC_CLOSURE_VALIDATE_CLOSURE_REQ, httpServletRequest);
			return resp1;
		}catch (ResourceException e) {
			Logger.error("ResourceException Inside validateCCClosureReq() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			ResourceException exp = new ResourceException(e.getKey());
			IMBResp resp1  = MBAppUtils.createErrorResp(IBankParams.getBaseOriginCode(mbSession.getOrigin()), exp, ServiceConstants.CC_CLOSURE_VALIDATE_CLOSURE_REQ, httpServletRequest);
			return resp1;
		}catch (Exception e) {
			Logger.error("Exception Inside validateCCClosureReq() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			BusinessException exp = new BusinessException(BusinessException.GENERIC_ERROR);
			IMBResp resp1  = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, ServiceConstants.CC_CLOSURE_VALIDATE_CLOSURE_REQ, httpServletRequest);
			return resp1;
		} finally {
			perfLogger.endLog(logName);
			perfLogger.endAllLogs();
		}
	}
		
	@RequestMapping(method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE, value = "reqSecureCode")
	@ResponseBody
	public IMBResp reqSecureCode(HttpServletRequest httpRequest, @RequestBody final SecureCodeReq request) {
		Logger.debug("CCClosureController - reqSecureCode(). Request: " + request, this.getClass());

		MobileSession mobileSession = null;
		IBankCommonData commonData = null;
		try {
			mobileSession = mbAppHelper.getMobileSession(httpRequest);	
			
			commonData = new MBAppHelper().populateIBankCommonData(mobileSession, httpRequest);
			
			validateRequestHeader(request.getHeader(), httpRequest);
			ErrorResp errorResponse = validate(request, httpRequest);
			if (errorResponse.hasErrors())
				return errorResponse;
			
			if (ServiceConstants.CCCLOSURE_TRAN_CODE != request.getTranType()){
				return MBAppUtils.createInvalid2FATransactionTypeResponse(ServiceConstants.CC_CLOSURE_SECURE_CODE);
			}
			
			return secureCodeHelper.reqSecureCode(commonData, mobileSession, null, new NonFinTransactionDetails() {}, request, ServiceConstants.CC_CLOSURE_SECURE_CODE, httpRequest);
			
		} catch (ResourceException e) {
			Logger.error("ResourceException in CCClosureController - reqSecureCode() - [key: " + e.getKey() + "], GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());
			mobileSession.removeSecureCodeDetails();
			return MBAppUtils.createErrorResp(IBankParams.getBaseOriginCode(mobileSession.getOrigin()), BusinessException.SYSTEM_UNAVILABLE, ServiceConstants.CC_CLOSURE_SECURE_CODE, httpRequest);
		}
		catch (Exception e) {
			Logger.error("Exception CCClosureController - reqSecureCode(): GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "]", e, this.getClass());
			mobileSession.removeSecureCodeDetails();
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.GENERIC_ERROR, ServiceConstants.CC_CLOSURE_SECURE_CODE, httpRequest);
		} finally {
			
		}

	}	

	@RequestMapping(value="verifySecCodeCloseCard", method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public IMBResp verifySecCodeCloseCard(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse,
			@RequestBody final SecureCodeReq req)
	{
		Logger.debug("In verifySecCodeCloseCard ( CCClosureController )  for Customer " +  "  " + httpServletRequest.getContentType() + " "
				+ httpServletRequest.getRemoteAddr() + "  " + httpServletResponse.getCharacterEncoding() + httpServletResponse.getLocale() +
				" True IP >> " + httpServletRequest.getHeader(IBankParams.trueClientIP()), this.getClass());

		PerformanceLogger performanceLogger = new PerformanceLogger();
		performanceLogger.startAllLogs();
		String logName = MBAppUtils.getLogName(httpServletRequest);
		performanceLogger.startLog(logName);
		ObjectMapper mapper = new ObjectMapper();
		MobileSession mbSession = null;
		String devicePrintForLogger = null;
		DigitalSecLogggerVO digitalSecLoggerVO =new DigitalSecLogggerVO();
		digitalSecLoggerVO.setTranName(DigitalSecLogger.CCCLOSURE_POSITIVE_BALANCE);
		
		try
		{
			mbSession = mbAppHelper.getMobileSession(httpServletRequest);
			CCClosureReqVO closureReqVO = mbSession.getCCClosureReqVO();
			CreditCardAccount ccAccount = (CreditCardAccount) mbSession.getCustomer().getAccounts().get(Integer.parseInt(closureReqVO.getAccountIndex()));
			
			boolean isMobileApp = ((logonHelper.loadCordova(httpServletRequest)) == -1) ? false:true;
			
			if(isMobileApp){
				Logger.debug("Value of isMobileApp ::" + isMobileApp, this.getClass());
				String sdkDevicePrint = mbSession.getSafiLogonInfo()!= null ? mbSession.getSafiLogonInfo().getDevicePrint():null;
				Logger.debug("sdkDevicePrint from session is ::" + sdkDevicePrint, this.getClass());
				try{
					JsonNode jsonNode = mapper.readValue(sdkDevicePrint, JsonNode.class);
					devicePrintForLogger = jsonNode!= null? jsonNode.toString() : "";
					Logger.debug("devicePrintForLogger ::" + devicePrintForLogger, this.getClass());
				}catch (Exception e) {
					Logger.debug("Exception while formatting devicePrint for Forensic log", this.getClass());
				}
			}
			
			validateRequestHeader( req.getHeader(), httpServletRequest );

			ErrorResp errorResp = validate(req, httpServletRequest);
			if (errorResp != null && errorResp.getErrors() != null && errorResp.getErrors().size() > 0){
				return errorResp;
			}
			
			IBankCommonData ibankCommonData=mbAppHelper.populateIBankCommonData(mbSession,httpServletRequest);
			digitalSecLoggerVO.setCommonLogData(mbAppHelper.getCommonLogData(ibankCommonData));
			digitalSecLoggerVO.setValues(toDigitalSecurityLog(closureReqVO, ccAccount, mbSession.getCCClosurePayoutAmount(), devicePrintForLogger));
			digitalSecLoggerVO.setUserAgent(ibankCommonData.getUserAgent());
			
			ErrorResp errorResponse = secureCodeHelper.verifySecureCode(ibankCommonData, mbSession, new NonFinTransactionDetails(){}, req, ServiceConstants.CC_CLOSURE_VERIFY_SECURE_CODE, httpServletRequest);
			if (errorResponse.hasErrors()){
				digitalSecLoggerVO.setStatus(DigitalSecLogger.FAILURE_2FA);
				digitalSecurityLogger.log(digitalSecLoggerVO);
				return errorResponse;
			}
			
			mbSession.setSecureCodeVerifiedTranName(ServiceConstants.CC_CLOSURE_VERIFY_SECURE_CODE);
			
			creditCardClosureService.closeCreditCard(ibankCommonData, mbSession.getCCClosureAppCorrID(), ccAccount.getAccountId().getAccountNumber(),closureReqVO.getAccountNum(), closureReqVO.getBsb(), closureReqVO.getDonationIndicator(), mbSession.getCCClosureReason(),mbSession.getCCClosurePayoutDate(),ccAccount.getCreditCardAdditionalInfo().getLogo());
			
			digitalSecLoggerVO.setStatus(DigitalSecLogger.SUCCESS);
			digitalSecurityLogger.log(digitalSecLoggerVO);
			
			IMBResp serviceResponse = ccClosureHelper.populateClosureResp(ibankCommonData, true, null);
		
			Logger.info("verifySecCodeCloseCard JSON Response :" + mapper.writeValueAsString(serviceResponse), this.getClass());
			RespHeader headerResp = populateResponseHeader(ServiceConstants.CC_CLOSURE_VERIFY_SECURE_CODE, mbSession);
			serviceResponse.setHeader(headerResp);
			
			mbSession.removeCCClosureAppCorrID();
			mbSession.removeCCClosurePayoutAmount();
			mbSession.removeCCClosurePayoutDate();
			mbSession.removeCCClosureEligibleCards();
			mbSession.removeCCClosureReason();
			mbSession.removeCCClosureReqVO();
			
			return serviceResponse;
		} catch (BusinessException e) {
			Logger.error("Exception Inside verifySecCodeCloseCard() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			IMBResp resp1 = MBAppUtils.createErrorResp(IBankParams.getBaseOriginCode(mbSession.getOrigin()), e, ServiceConstants.CC_CLOSURE_VERIFY_SECURE_CODE, httpServletRequest);
			return resp1;
		} catch (Exception e)
		{
			Logger.error("Exception Inside verifySecCodeCloseCard() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			BusinessException exp = new BusinessException(BusinessException.SMPL_SYS_ERROR);
			IMBResp resp1 = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, ServiceConstants.CC_CLOSURE_VERIFY_SECURE_CODE, httpServletRequest);
			return resp1;
		} finally
		{
			performanceLogger.endLog(logName);
			performanceLogger.endAllLogs();
		}
	}
	
	@RequestMapping(value= "closeCard" , method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public IMBResp closeCard(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, @RequestBody final CCClosureReq req){
		
		ObjectMapper objectMapper = new ObjectMapper();							
		perfLogger.startAllLogs();
		String logName = MBAppUtils.getLogName(httpServletRequest);
		perfLogger.startLog(logName);
		
		new FraudLogger();
		MobileSession mbSession = null;

		try{	
			
			mbSession = mbAppHelper.getMobileSession(httpServletRequest);
			
			Logger.info("closeCard JSON Request :" + objectMapper.writeValueAsString(req), this.getClass());
			validateRequestHeader(req.getHeader(), httpServletRequest);
			ErrorResp errorResp = validate(req, httpServletRequest);
			if (errorResp != null && errorResp.getErrors() != null && errorResp.getErrors().size() > 0)	{				
				return errorResp;
			}
															
			IBankCommonData commonData=mbAppHelper.populateIBankCommonData(mbSession,httpServletRequest);
			
			CreditCardAccount ccAccount = (CreditCardAccount) mbSession.getCustomer().getAccounts().get(Integer.parseInt(req.getAccountIndex()));
			
			creditCardClosureService.closeCreditCard(commonData, mbSession.getCCClosureAppCorrID(), ccAccount.getAccountId().getAccountNumber(), null, null, req.getDonationIndicator(),mbSession.getCCClosureReason(), mbSession.getCCClosurePayoutDate(), ccAccount.getCreditCardAdditionalInfo().getLogo());
			
			String billerCode = creditCardClosureService.brandBillerCode(IBankParams.getBaseOriginCode(commonData.getOrigin()));
			
			boolean isTransactionAccountPresent = creditCardClosureService.isTransactionAccountPresent(commonData.getCustomer().getAccounts());
			
			IMBResp serviceResponse = ccClosureHelper.populateClosureResp(commonData, isTransactionAccountPresent, billerCode);

			RespHeader headerResp = populateResponseHeader(ServiceConstants.CC_CLOSURE_VALIDATE_CLOSURE_REQ, mbSession);
			serviceResponse.setHeader(headerResp);
			
			mbSession.removeCCClosureAppCorrID();
			mbSession.removeCCClosurePayoutAmount();
			mbSession.removeCCClosurePayoutDate();
			mbSession.removeCCClosureEligibleCards();
			mbSession.removeCCClosureReason();
			mbSession.removeCCClosureReqVO();
			
			Logger.info("closeCard JSON Response :" + objectMapper.writeValueAsString(serviceResponse), this.getClass());
			
			return serviceResponse;		
		}catch (BusinessException e) {			
			Logger.info("BusinessException Inside closeCard() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());			
			BusinessException exp = new BusinessException(e.getKey());
			IMBResp resp1  = MBAppUtils.createErrorResp(IBankParams.getBaseOriginCode(mbSession.getOrigin()), exp, ServiceConstants.CC_CLOSURE_VALIDATE_CLOSURE_REQ, httpServletRequest);
			return resp1;
		}catch (ResourceException e) {
			Logger.error("ResourceException Inside closeCard() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			ResourceException exp = new ResourceException(e.getKey());
			IMBResp resp1  = MBAppUtils.createErrorResp(IBankParams.getBaseOriginCode(mbSession.getOrigin()), exp, ServiceConstants.CC_CLOSURE_VALIDATE_CLOSURE_REQ, httpServletRequest);
			return resp1;
		}catch (Exception e) {
			Logger.error("Exception Inside closeCard() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			BusinessException exp = new BusinessException(BusinessException.GENERIC_ERROR);
			IMBResp resp1  = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, ServiceConstants.CC_CLOSURE_VALIDATE_CLOSURE_REQ, httpServletRequest);
			return resp1;
		} finally {
			perfLogger.endLog(logName);
			perfLogger.endAllLogs();
		}
	}
	
	/**
	 * Response for invalid body request 
	 * 
	 * @return
	 */
	@ExceptionHandler({org.springframework.http.converter.HttpMessageNotReadableException.class})
	@ResponseStatus(org.springframework.http.HttpStatus.OK)
	@ResponseBody
	public IMBResp resolveException() {		
		return MBAppUtils.createInvalidMessageBodyResponse(ServiceConstants.CC_BALANCE_TRANSFER_SERVICE);
	}
	
	public ErrorResp validate(IMBReq serviceRequest, HttpServletRequest request) {
		return new MBAppValidator().validate(serviceRequest, request);
	}
	
	public void validateRequestHeader(ReqHeader header, HttpServletRequest request) throws ResourceException
	{	
		mbAppValidator.validateRequestHeader(header,  request);	
	}
	
	public RespHeader populateResponseHeader(String ServiceName, MobileSession mobSession )
	{		
		return mbAppHelper.populateResponseHeader(ServiceName, mobSession);
	}
	
	private boolean hasSecureCodeConstraints(Customer customer) {
		boolean resp = false;
		try{
			if(IBankParams.isGlobalByPass()){
				resp = true;
			}else if (IBankSecureService.isCustomerExempt(customer.getIBankSecureDetails())){
				resp = true;
			}
		}catch (Exception e){
			resp = false;
			Logger.error("Error CCClosure hasSecureCodeConstraints: " + customer.getGcis(), this.getClass());			
		}
		return resp;
	}
	
	private String toDigitalSecurityLog(CCClosureReqVO closureReqVO, CreditCardAccount ccAccount, String payoutAmount, String devicePrint){
		
		StringBuffer sb = new StringBuffer();
		try{
			if(null!=closureReqVO && null!=ccAccount){	
				sb.append(DigitalSecLogger.FROM_ACCT_NUM).append(DigitalSecLogger.DELIMITER_COLON).append(ccAccount.getAccountId().getAccountNumber()).append(DigitalSecLogger.DELIMITER_COMMA)
				.append(DigitalSecLogger.TO_ACCT_BSB).append(DigitalSecLogger.DELIMITER_COLON).append(closureReqVO.getBsb()).append(DigitalSecLogger.DELIMITER_COMMA)
				.append(DigitalSecLogger.TO_ACCT_NUM).append(DigitalSecLogger.DELIMITER_COLON).append(closureReqVO.getAccountNum()).append(DigitalSecLogger.DELIMITER_COMMA)
				.append(DigitalSecLogger.AMOUNT).append(DigitalSecLogger.DELIMITER_COLON).append(payoutAmount);
				
				if(!StringMethods.isEmptyString(devicePrint)){
					sb.append(DigitalSecLogger.DELIMITER_COMMA).append(DigitalSecLogger.SDK_DEVICE_PRINT).append(DigitalSecLogger.DELIMITER_COLON).append(devicePrint);
				}
			}
	    }                          
	    catch (Exception e){
	          Logger.error("Exception while creating data for Fraud Logging for CCClosure::", e, this.getClass());
	    }         
		return sb.toString();
		
	}
}
