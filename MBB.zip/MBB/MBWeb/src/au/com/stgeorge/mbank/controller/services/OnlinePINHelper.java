package au.com.stgeorge.mbank.controller.services;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.stereotype.Service;

import au.com.stgeorge.framework.common.logging.Logger;
import au.com.stgeorge.framework.common.util.StringMethods;
import au.com.stgeorge.ibank.businessobject.BusinessException;
import au.com.stgeorge.ibank.common.cache.IBankParams;
import au.com.stgeorge.ibank.servicestation.businessobject.valueobject.ServiceStationVO;
import au.com.stgeorge.ibank.servicestation.util.ServicetationConstants;
import au.com.stgeorge.ibank.util.StringUtil;
import au.com.stgeorge.ibank.valueobject.Account;
import au.com.stgeorge.ibank.valueobject.CardActivation;
import au.com.stgeorge.ibank.valueobject.CreditCardAccount;
import au.com.stgeorge.ibank.valueobject.DebitCardAccount;
import au.com.stgeorge.ibank.valueobject.GCCAccount;
import au.com.stgeorge.ibank.valueobject.OnlinePINVO;
import au.com.stgeorge.ibank.valueobject.database.CodesVO;
import au.com.stgeorge.ibank.valueobject.globalWallet.GlobalWalletDetails;
import au.com.stgeorge.ibank.valueobject.globalWallet.GlobalWalletSetPIN;
import au.com.stgeorge.mbank.model.common.RespHeader;
import au.com.stgeorge.mbank.model.request.services.OnlinePINGlobalWalletReq;
import au.com.stgeorge.mbank.model.request.services.OnlinePINReq;
import au.com.stgeorge.mbank.model.response.services.CardResp;
import au.com.stgeorge.mbank.model.response.services.GlobalWalletChangePINResponse;
import au.com.stgeorge.mbank.model.response.services.OnlinePINResp;
import au.com.stgeorge.mbank.model.response.servicestation.ServiceStationResp;
import au.com.stgeorge.mbank.session.MobileSession;
import au.com.stgeorge.mbank.util.MBAppHelper;


@Service
public class OnlinePINHelper {

	protected OnlinePINResp populateCardListResponse(RespHeader header, List<Account> cards) throws BusinessException {
		
		OnlinePINResp response = new OnlinePINResp(header);
		List<CardResp> cardsResp = new ArrayList<CardResp>();

		int index = 0;
		for (Account card : cards) {
			CardResp cardResp = new CardResp();
			cardResp.setIndex(String.valueOf(index));
			if (card instanceof DebitCardAccount) {
				DebitCardAccount debitCard = (DebitCardAccount) card;
				
				if(IBankParams.isSwitchOn(IBankParams.CARD_NUM_MASK_SWITCH)) {
					cardResp.setAccountNumDisp(StringUtil.formatCardNumber(debitCard.getCardNumber()));
					}
				else {
					cardResp.setAccountNumDisp(new MBAppHelper().getFormattedAcctNumber(debitCard.getCardNumber(), debitCard.getAccountId()
							.getApplicationId(), debitCard.getAccountId().getBsb()));
					
				}
				
		     if(!"1".equalsIgnoreCase(debitCard.getIssueNumber())){
		       cardResp.setAccountNumDisp( cardResp.getAccountNumDisp() + "(" + debitCard.getIssueNumber() + ")");
		      }

				cardResp.setAccountName(debitCard.getCardName());
				cardResp.setDebitCard(true);
				cardResp.setIssueNumber(debitCard.getIssueNumber());
				
			} else {
				cardResp.setAccountNumDisp(new MBAppHelper().getFormattedAcctNumber(card.getAccountId().getAccountNumber(), card.getAccountId()
						.getApplicationId(), card.getAccountId().getBsb()));
				cardResp.setDebitCard(false);
				cardResp.setIssueNumber("");
				cardResp.setAccountName(card.getAlias());
			}
				cardsResp.add(cardResp);
			index++;
		}

		response.setCards(cardsResp);
		Logger.info("Response: " + response, this.getClass());
		return response;
	}
	
	protected OnlinePINResp populateEncryptionDetails(RespHeader header,OnlinePINVO vo) throws BusinessException {
		OnlinePINResp response = new OnlinePINResp(header);
		response.setRandomNum(vo.getRandomNum());
		response.setModulus(vo.getModulus());
		response.setExponent(vo.getExponent());
		response.setHashAlgo(vo.getHashAlgo());
		return response;
	}
	
	protected OnlinePINResp populateChangePINResp(RespHeader header) throws BusinessException {
		OnlinePINResp response = new OnlinePINResp(header);
		return 	response;
	}
	
	protected OnlinePINVO getOnlinePINFromSession(MobileSession mobileSession,OnlinePINReq request) {
		Account selectedCard = mobileSession.getCards().get(Integer.parseInt(mobileSession.getSelectedAccountIndex()));
		String accountNum ="";
		String cardSuffix ="";
		Date expiryDate =null;
		if(selectedCard instanceof DebitCardAccount){
			accountNum = ((DebitCardAccount)selectedCard).getCardNumber();
			cardSuffix = ((DebitCardAccount)selectedCard).getIssueNumber();		
			expiryDate =((DebitCardAccount)selectedCard).getExpiryDate();
		}
		else if(selectedCard instanceof CreditCardAccount){
			accountNum = ((CreditCardAccount)selectedCard).getAccountId().getAccountNumber();
			cardSuffix = ((CreditCardAccount)selectedCard).getCardIssueNum();
			expiryDate =((CreditCardAccount)selectedCard).getCardExpiryDateFull();
		}
		else if(selectedCard instanceof GCCAccount){
			accountNum = ((GCCAccount)selectedCard).getCardNumber();
			//cardSuffix = ((GCCAccount)selectedCard).getIssueNumber();
			//expiryDate =((GCCAccount)selectedCard).getCardExpiryDateFull();
		}
		OnlinePINVO vo =new OnlinePINVO();
		vo.setCardNum(accountNum);
		vo.setIssueNum(cardSuffix);
		vo.setExpiryDate(expiryDate);
		vo.setRandomNum(mobileSession.getOnlinePINRandomNum());	
		vo.setEncryptedPIN(request.getEncryptedPIN());
		vo.setEncodingParameter(request.getEncodingParam());
		vo.setChangePIN(true); // If it is not from activation, it will be change PIn always
		vo.setSetPINFlow(false);
		return vo;
	}
	
	protected OnlinePINVO getOnlinePINFromSessionGlobalWallet(MobileSession mobileSession,OnlinePINGlobalWalletReq request) {
		Account selectedCard = mobileSession.getCards().get(Integer.parseInt(mobileSession.getSelectedAccountIndex()));
		String accountNum ="";
		String cardSuffix ="";
		Date expiryDate =null;
		if(selectedCard instanceof DebitCardAccount){
			accountNum = ((DebitCardAccount)selectedCard).getCardNumber();
			cardSuffix = ((DebitCardAccount)selectedCard).getIssueNumber();		
			expiryDate =((DebitCardAccount)selectedCard).getExpiryDate();
		}
		else if(selectedCard instanceof CreditCardAccount){
			accountNum = ((CreditCardAccount)selectedCard).getAccountId().getAccountNumber();
			cardSuffix = ((CreditCardAccount)selectedCard).getCardIssueNum();
			expiryDate =((CreditCardAccount)selectedCard).getCardExpiryDateFull();
		}
		else if(selectedCard instanceof GCCAccount){
			accountNum = ((GCCAccount)selectedCard).getCardNumber();
			//cardSuffix = ((GCCAccount)selectedCard).getIssueNumber();
			//expiryDate =((GCCAccount)selectedCard).getCardExpiryDateFull();
		}
		OnlinePINVO vo =new OnlinePINVO();
		vo.setCardNum(accountNum);
		vo.setIssueNum(cardSuffix);
		vo.setExpiryDate(expiryDate);
		vo.setRandomNum(mobileSession.getOnlinePINRandomNum());	
		vo.setEncryptedPIN(request.getEncryptedPIN());		
		vo.setChangePIN(true); // If it is not from activation, it will be change PIn always
		vo.setSetPINFlow(false);
		return vo;
	}
	
	protected OnlinePINVO getOnlinePINFromCardActivationSession(MobileSession mobileSession,OnlinePINReq request) {
		CardActivation serviceVo = mobileSession.getCardActivation();
		OnlinePINVO vo =new OnlinePINVO();
		if(serviceVo != null){
			vo.setCardNum(serviceVo.getCardNumber());
			vo.setIssueNum(serviceVo.getIssueNum());
			vo.setExpiryDate(serviceVo.getExpiryDate());
			vo.setRandomNum(mobileSession.getOnlinePINRandomNum());	
			vo.setEncryptedPIN(request.getEncryptedPIN());
			vo.setEncodingParameter(request.getEncodingParam());
			vo.setChangePIN(!serviceVo.isNewCard());
			if(serviceVo.isNewCard())
				vo.setSetPINFlow(true);
			else
				vo.setSetPINFlow(false);			
		}
		return vo;
	}

	
	protected OnlinePINVO getOnlinePINFromCardActivationSessionGlobalWallet(MobileSession mobileSession,OnlinePINGlobalWalletReq request) {
		CardActivation serviceVo = mobileSession.getCardActivation();
		OnlinePINVO vo =new OnlinePINVO();
		if(serviceVo != null){
			vo.setCardNum(serviceVo.getCardNumber());
			vo.setIssueNum(serviceVo.getIssueNum());
			vo.setExpiryDate(serviceVo.getExpiryDate());
			vo.setRandomNum(mobileSession.getOnlinePINRandomNum());	
			vo.setEncryptedPIN(request.getEncryptedPIN());			
			vo.setChangePIN(!serviceVo.isNewCard());
			if(serviceVo.isNewCard())
				vo.setSetPINFlow(true);
			else
				vo.setSetPINFlow(false);
			
			if(null != serviceVo.getGwCardBrand())
				vo.setGwCardBrand(serviceVo.getGwCardBrand());
		}
		return vo;
	}

	//Updated this method to return blank OnlibePINVO object because we are not using the values which were being set in this object for getting the secure code,
	//But we still need a blank object in the verifySecureCode method else it will fail
	protected OnlinePINVO populateOnlinePINVO(MobileSession mobileSession) {
		OnlinePINVO vo = new OnlinePINVO();
		CardActivation serviceVo = mobileSession.getCardActivation();
		if(serviceVo != null){
			vo.setCardNum(serviceVo.getCardNumber());
		}else{
			Account selectedCard = mobileSession.getCards().get(Integer.parseInt(mobileSession.getSelectedAccountIndex()));
			String accountNum ="";
			String cardSuffix ="";
			Date expiryDate = null;
			if(selectedCard instanceof DebitCardAccount){
				accountNum = ((DebitCardAccount)selectedCard).getCardNumber();
				cardSuffix = ((DebitCardAccount)selectedCard).getIssueNumber();		
				expiryDate =((DebitCardAccount)selectedCard).getExpiryDate();
			}
			else if(selectedCard instanceof CreditCardAccount){
				accountNum = ((CreditCardAccount)selectedCard).getAccountId().getAccountNumber();
				cardSuffix = ((CreditCardAccount)selectedCard).getCardIssueNum();
				expiryDate =((CreditCardAccount)selectedCard).getCardExpiryDateFull();
			}
			else if(selectedCard instanceof GCCAccount){
				accountNum = ((GCCAccount)selectedCard).getCardNumber();
				//cardSuffix = ((GCCAccount)selectedCard).getIssueNumber();
				//expiryDate =((GCCAccount)selectedCard).getCardExpiryDateFull();
			}
			vo.setCardNum(accountNum);
			vo.setIssueNum(cardSuffix);
			vo.setExpiryDate(expiryDate);
			vo.setSetPINFlow(false); 
		}
		return vo;
	}
	
	public long getInsertionPointCode(String insertionPointString){
		List<CodesVO> CodesVOList = (List<CodesVO>) IBankParams.getCodesDataList(IBankParams.DEFAULT_ORIGIN, ServicetationConstants.CD_CATEGORY_SERVICETATION_INSERTION_PT);
		long insertionPointValue = 0;
		for(CodesVO codesVO : CodesVOList){
			if(codesVO.getMessage().trim().equalsIgnoreCase(insertionPointString)){
				if(StringMethods.isValidString(codesVO.getCode())){
					insertionPointValue = Long.parseLong(codesVO.getCode());
					break;
				}
			}
		}
		if(insertionPointValue == 0){
			Logger.warn("NO match found in RELEASECODES table for the insertion point "+insertionPointString, this.getClass());
		}
		return insertionPointValue;
	}
	
	public OnlinePINResp populateServiceStationResponse(OnlinePINResp resp,ServiceStationVO serviceStationVO) 
	{
		ServiceStationResp ssResponse = null;
		if(null!=serviceStationVO)
		{
			ServiceStationResp serviceResponse = new ServiceStationResp();
			if(null!=serviceStationVO.getContent())
			{
				serviceResponse.setContent(serviceStationVO.getContent());
			}			
			if(null!=serviceStationVO.getServiceStationMsg())
			{
				serviceResponse.setInsertionPointValue(new Long(serviceStationVO.getServiceStationMsg().getInsertionPointValue()).toString());	
			}
			if(null!=serviceStationVO.getSubject())
			{
				serviceResponse.setSubject(serviceStationVO.getSubject());
			}
			if(null!=serviceStationVO.getServiceStationMsg().getFunctionLink())
			{
				serviceResponse.setFunctionLink(serviceStationVO.getServiceStationMsg().getFunctionLink());
			}
			if(null!=serviceStationVO.getServiceStationMsg().getMessageAction())
			{
				serviceResponse.setMessageAction(serviceStationVO.getServiceStationMsg().getMessageAction());
			}
			if(null!=serviceStationVO.getServiceStationMsg())
			{
			    serviceResponse.setMsgID(new Long(serviceStationVO.getServiceStationMsg().getMsgID()).toString());
			}
			
			resp.setServiceStation(serviceResponse);			
		}		
	  else
		{
			resp.setServiceStation(ssResponse);	
		}		
		return resp;
	}
	
	/**
	 * Added for 20E1 : SBGEXP-7950<br><br>
	 * 
	 * Converts the response from set/change PIN API to GlobalWalletChangePINResponse which is returned to UI.
	 * <br><br>
	 * 
	 * This will include all cards along with their change PIN status returned from API.
	 * <br><br>
	 * 
	 * @param resp
	 * @param globalWalletDetails
	 */
	public void setGlobalWalletChangePINResponse(OnlinePINResp resp, GlobalWalletDetails globalWalletDetails) {
		if(null != globalWalletDetails.getSetPINs()) {
			List<GlobalWalletChangePINResponse> responseList = new ArrayList<GlobalWalletChangePINResponse>();
			
			for(GlobalWalletSetPIN globalWalletSetPIN: globalWalletDetails.getSetPINs()){
				GlobalWalletChangePINResponse response = new GlobalWalletChangePINResponse();
				response.setArrangementId(globalWalletSetPIN.getArrangementId());
				response.setArrangementIdDisplay(globalWalletSetPIN.getArrangementIdDisplay());
				response.setArrangementIdSetPINDisplay(StringUtil.formatCompassAccountNumber(globalWalletSetPIN.getArrangementId()));				
				response.setStatus(globalWalletSetPIN.getSetPINStatus());
				responseList.add(response);
			}
			resp.setGlobalWalletChangePINResponse(responseList);
		}
	}


	public OnlinePINVO populateOnlinePINVOForWWW(MobileSession mobileSession) {
		return populateOnlinePINVO(mobileSession);
	}	

}
