package au.com.stgeorge.mbank.controller.services;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Service;

import au.com.stgeorge.framework.common.logging.Logger;
import au.com.stgeorge.framework.common.util.DateMethods;
import au.com.stgeorge.ibank.businessobject.BusinessException;
import au.com.stgeorge.ibank.businessobject.StatisticsService;
import au.com.stgeorge.ibank.common.cache.IBankParams;
import au.com.stgeorge.ibank.valueobject.Account;
import au.com.stgeorge.ibank.valueobject.PushNotificationVO;
import au.com.stgeorge.ibank.valueobject.Statistic;
import au.com.stgeorge.ibank.valueobject.sms.Alert;
import au.com.stgeorge.ibank.valueobject.sms.SMSAccount;
import au.com.stgeorge.ibank.valueobject.transfer.IBankCommonData;
import au.com.stgeorge.mbank.model.common.IMBResp;
import au.com.stgeorge.mbank.model.common.RespHeader;
import au.com.stgeorge.mbank.model.request.services.AlertReq;
import au.com.stgeorge.mbank.model.response.StatusResp;
import au.com.stgeorge.mbank.model.response.services.AlertAccountsResp;
import au.com.stgeorge.mbank.model.response.services.AlertResp;
import au.com.stgeorge.mbank.model.response.services.AlertsAccountResp;
import au.com.stgeorge.mbank.model.response.services.AlertsSummaryResp;
import au.com.stgeorge.mbank.model.response.services.PushNotfRegResp;
import au.com.stgeorge.mbank.session.MobileSession;
import au.com.stgeorge.mbank.util.MBAppUtils;
import au.com.stgeorge.mbank.util.ServiceConstants;
import au.com.stgeorge.security.util.StringMethods;

/**
 * Alerts service helper
 * 
 * @author C38854
 * 
 */
@Service
public class AlertsHelper {

	/** Default from date for Alert Summary **/
	public static final String ALERT_SUMMARY_DEFAULT_FROM_DATE = "19900101";
	/** Default to date for Alert Summary **/
	public static final String ALERT_SUMMARY_DEFAULT_TO_DATE = "20991231";
	/** End date for Balance alert alert **/
	public static final String ALERT_END_DATE = "99991231";
	/** date format for default from and to date for Alert Summary **/
	public static final String DEFAULT_DATE_FORMAT = "yyyyMMdd";

	// Alert Frequencies
	public static final String DAILY_FREQUENCY_TYPE = "DAILY";
	public static final String MONTHLY_FREQUENCY_TYPE = "MONTHLY";
	public static final String FORNIGHTLY_FREQUENCY_TYPE = "FORTNIGHTLY";
	public static final String WEEKLY_FREQUENCY_TYPE = "WEEKLY";
	public static final String ONCEONLY_FREQUENCY_TYPE = "ONE OFF";
	public static final String ONGOING_FREQUENCY_TYPE = "ONGOING";
	
	public static final BigDecimal DEPOSIT_WITHDRAW_TO_AMOUNT = new BigDecimal("1000000000");

	private static HashMap<String, Integer> alertMethods;
	static {
		alertMethods = new HashMap<String, Integer>();
		alertMethods.put("EMAIL", 0);
		alertMethods.put("SMS", 1);
		alertMethods.put("SMS_EMAIL", 2);
		alertMethods.put("BOTH", 3);
	}

	private static HashMap<String, Integer> frequencies;
	static {
		frequencies = new HashMap<String, Integer>();
		frequencies.put(ONCEONLY_FREQUENCY_TYPE, 0);
		frequencies.put(DAILY_FREQUENCY_TYPE, 1);
		frequencies.put(WEEKLY_FREQUENCY_TYPE, 2);
		frequencies.put(FORNIGHTLY_FREQUENCY_TYPE, 3);
		frequencies.put(MONTHLY_FREQUENCY_TYPE, 4);
	}

	// Alert type ids for SMS Alert
	public static final int BALANCE_ALERT_TYPE = 1;
	public static final int HI_BALANCE_ALERT_TYPE = 2;
	public static final int LOW_BALANCE_ALERT_TYPE = 3;
	public static final int DEPOSIT_ALERT_TYPE = 4;
	public static final int WITHDRAW_ALERT_TYPE = 5;
	public static final int AUTHORISATION_ALERT_TYPE = 10; // ver 1.0.1
	public static final int DISHONOUR_ALERT_TYPE = 11; // ver 2.0.1
	public static final int CC_REMINDER_ALERT_TYPE=12;
	
	//Onboarding Application
	public static final String APPLICATION_ONBOARDING = "ONBOARDING";
	public static final String GDW_DESC_ONBOARDING_DEPOSIT_ALERT = "Deposit";
	public static final String GDW_DESC_ONBOARDING_WITHDRAWAL_ALERT = "Withdrawal";
	
	private static HashMap<Integer, String> descriptions;
	static {
		descriptions = new HashMap<Integer, String>();
		descriptions.put(BALANCE_ALERT_TYPE, "Notify me <frequency> of my account balance through <alertMethod>.");
		descriptions.put(HI_BALANCE_ALERT_TYPE, "Notify me <frequency> my balance goes above <amount> through <alertMethod>.");
		descriptions.put(LOW_BALANCE_ALERT_TYPE, "Notify me <frequency> my balance goes under <amount> through <alertMethod>.");
		descriptions.put(DEPOSIT_ALERT_TYPE, "Notify me <frequency> <amount> or more is deposited into my account through <alertMethod>.");
		descriptions.put(WITHDRAW_ALERT_TYPE, "Notify me <frequency> <amount> or more is debited from my account through <alertMethod>.");
		descriptions.put(AUTHORISATION_ALERT_TYPE, "Notify me <frequency> my account has a card authorisation for <amount> or more through <alertMethod>.");
		descriptions.put(DISHONOUR_ALERT_TYPE, "Notify me whenever my account is charged a dishonour fee through <alertMethod>.");
		descriptions.put(CC_REMINDER_ALERT_TYPE, "Notify me <frequency> my credit card repayment is due through <alertMethod>.");
	}

	private static HashMap<Integer, String> receiptDescriptions;
	static {
		receiptDescriptions = new HashMap<Integer, String>();
		receiptDescriptions.put(BALANCE_ALERT_TYPE, "We will notify you regarding your|balance <frequency> by <alertMethod>.");
		receiptDescriptions.put(LOW_BALANCE_ALERT_TYPE, "We will notify you <frequency> your|balance goes under|by <alertMethod>.");
		receiptDescriptions.put(HI_BALANCE_ALERT_TYPE, "We will notify you <frequency> your|balance goes above|by <alertMethod>.");
		receiptDescriptions.put(DEPOSIT_ALERT_TYPE, "We will notify you <frequency> your|has a deposit of|or more by <alertMethod>.");
		receiptDescriptions.put(WITHDRAW_ALERT_TYPE, "We will notify you <frequency> your|has a debit of|or more by <alertMethod>.");
		receiptDescriptions.put(AUTHORISATION_ALERT_TYPE, "We will notify you <frequency> your|has a card authorisation for|or more by <alertMethod>.");
		receiptDescriptions.put(DISHONOUR_ALERT_TYPE, "We will notify you <frequency> your|has been overdrawn by a cheque, direct debit or periodical payment by <alertMethod>.");
		receiptDescriptions.put(CC_REMINDER_ALERT_TYPE, "We will notify you <frequency> your|repayment is due by <alertMethod>.");
	}

	public static final String END_DATE_FORMAT = "yyyyMMdd";

	/**
	 * Populate alerts summary response
	 * 
	 * @param header
	 * @param registered
	 * @param alerts
	 * @param customerAccounts
	 * @return
	 */
	protected IMBResp populateSummaryResponse(RespHeader header, boolean registered, List<Alert> alerts, List<Account> customerAccounts, List<String> deviceList, Alert alert) {
		AlertsSummaryResp response = new AlertsSummaryResp(header);
		response.setIsRegistered(registered);
		if (registered) {
			response.setAlerts(new ArrayList<AlertResp>());
			if (alerts != null){
				populateAlerts(alerts, customerAccounts, response);
			}
		}
		
		if(deviceList != null && deviceList.size() > 0){
			List<String> deviceNames = new ArrayList<String>();
			for(String deviceName : deviceList)
				deviceNames.add(deviceName);
			
			response.setPushDeviceNames(deviceNames);			
		}
		
		if(alert != null){
			response.setReceiptDescription(getReceiptDescription(alert));
		}else{
			response.setReceiptDescription(null);
		}
		
	/*	HI_BALANCE_ALERT_TYPE
		LOW_BALANCE_ALERT_TYPE
		DEPOSIT_ALERT_TYPE
		WITHDRAW_ALERT_TYPE
		AUTHORISATION_ALERT_TYPE
		*/
		
		Logger.info("Response: " + response, this.getClass());
		return response;
	}

	/**
	 * Populate accounts response
	 * 
	 * @param header
	 * @param status
	 * @param validSMSAccountArray
	 * @param customerAccounts
	 * @param smsAllowedAccountIndexes
	 * @return
	 */
	protected IMBResp populateAccountsResp(RespHeader header, Integer status, SMSAccount[] validDisonourSMSAccountArray, List<Account> customerAccounts,
			List<Integer> smsAllowedAccountIndexes, String origin, HttpServletRequest httpRequest) {
		AlertAccountsResp alertAccountsResp = new AlertAccountsResp(header);
		alertAccountsResp.setStatus(status);
		alertAccountsResp.setAccounts(new ArrayList<AlertsAccountResp>());

		for (Integer index : smsAllowedAccountIndexes) {
			AlertsAccountResp accResp = new AlertsAccountResp();
			accResp.setAllowDishonourAlert(false);
			accResp.setAccountIndex(index);			
			Account account = customerAccounts.get(index);
			//check if account =CRA, set allow credit card reminder as true
			if(account!=null && account.getAccountId()!=null && account.getAccountId().getApplicationId() !=null && account.getAccountId().getApplicationId().trim().equals(Account.CRA)){
				accResp.setAllowCreditCardReminderAlert(true);
			}else{
				accResp.setAllowCreditCardReminderAlert(false);
			}
			
			for (int k = 0; validDisonourSMSAccountArray != null && k < validDisonourSMSAccountArray.length; k++)
				if (validDisonourSMSAccountArray[k].getAccountNumber().compareTo(account.getAccountId().getAccountNumber()) == 0
						&& validDisonourSMSAccountArray[k].getBranchKey().compareTo(account.getAccountId().getBranchKey()) == 0)
					accResp.setAllowDishonourAlert(true);
			alertAccountsResp.getAccounts().add(accResp);
		}
		
		// For Onboarding Process 
		alertAccountsResp.setDefaultAmtDeposit(IBankParams.getCodesData(IBankParams.DEFAULT_ORIGIN,IBankParams.ONBOARDING_PROPERTIES, IBankParams.DEFAULT_AMOUNT_DEPOSIT).getMessage());
		alertAccountsResp.setDefaultAmtWithdrawal(IBankParams.getCodesData(IBankParams.DEFAULT_ORIGIN,IBankParams.ONBOARDING_PROPERTIES, IBankParams.DEFAULT_AMOUNT_WITHDRAWAL).getMessage());
		alertAccountsResp.setMinAmtDeposit(IBankParams.getCodesData(IBankParams.DEFAULT_ORIGIN,IBankParams.ONBOARDING_PROPERTIES, IBankParams.MINIMUM_AMOUNT_DEPOSIT).getMessage());
		alertAccountsResp.setMinAmtWithdrawal(IBankParams.getCodesData(IBankParams.DEFAULT_ORIGIN,IBankParams.ONBOARDING_PROPERTIES, IBankParams.MINIMUM_AMOUNT_WITHDRAWAL).getMessage());

		if (alertAccountsResp.getAccounts().size() > 0) {
			Logger.info("Response: " + alertAccountsResp, this.getClass());
			return alertAccountsResp;
		} else {
			return MBAppUtils.createErrorResp(origin, BusinessException.ALERTS_NO_ELIGIBLE_ACCOUNTS, ServiceConstants.ALERTS_ACCOUNTS_SERVICE, httpRequest);
		}
	}

	/**
	 * Populate register response
	 * 
	 * @param header
	 * @param status
	 * @return
	 */
	protected IMBResp populateRegisterResponse(RespHeader header, Integer status) {
		StatusResp response = new StatusResp(header);
		response.setStatus(status);
		Logger.info("Response: " + response, this.getClass());
		return response;
	}

	/**
	 * Populate alert
	 * 
	 * @param smsBean
	 * @param customerAccounts
	 * @param gcis
	 * @return
	 */
	protected Alert populateAlert(AlertReq smsBean, List<Account> customerAccounts, String gcis) {

		if (smsBean.getIsAuthorisation()==null) smsBean.setIsAuthorisation(false);
		if (smsBean.getIsOnceOnly()==null) smsBean.setIsOnceOnly(false);
		if (smsBean.getIncludeBalance()==null) smsBean.setIncludeBalance(false);
		
		Alert alert = new Alert();
		if (smsBean.getAlertID() != null)
			alert.setId(smsBean.getAlertID());
		if (smsBean.getReceiptDOW()==null) smsBean.setReceiptDOW("");
		Account account = customerAccounts.get(smsBean.getAccountIndex());
		// account details
		alert.setAccountNickname(account.getAlias());
		alert.setAccountNumber(account.getAccountId().getAccountKey());
		
		alert.setAccountTypeCode(getAccountTypeCode(account));
		
		alert.setBranchKey(account.getAccountId().getBranchKey());
		alert.setApplicationId(account.getAccountId().getApplicationId());
						
		// As part of PushNotification project, AlertMethod will be String between numbers 1 to 7 
		alert.setAlertMethod(smsBean.getAlertMethod().toString());
		/* 
		if (smsBean.getAlertMethod() == 2) {
			alert.setAlertMethod("BOTH");
		} else {
			for (String method : alertMethods.keySet()) {
				if (alertMethods.get(method) == smsBean.getAlertMethod()) {
					alert.setAlertMethod(method.toUpperCase());
				}
			}
		}
		*/
		alert.setDisplayFlag(smsBean.getIncludeBalance());
		
		alert.setTypeId(smsBean.getAlertType());
		if (alert.getTypeId() == BALANCE_ALERT_TYPE) {
			Date startDate = smsBean.getStartDate();
			if (smsBean.getFrequency() == frequencies.get(ONCEONLY_FREQUENCY_TYPE)) {
				alert.setFrequency(DAILY_FREQUENCY_TYPE);
				alert.setOneOffFlag(true);
				alert.setStartDate(startDate);
				alert.setEndDate(DateMethods.getUtilDateTime(ALERT_END_DATE, END_DATE_FORMAT));
			} else if (smsBean.getFrequency() == frequencies.get(DAILY_FREQUENCY_TYPE)) {
				alert.setFrequency(DAILY_FREQUENCY_TYPE);
				alert.setStartDate(startDate);
				alert.setEndDate(DateMethods.getUtilDateTime(ALERT_END_DATE, END_DATE_FORMAT));
			} else if (smsBean.getFrequency() == frequencies.get(WEEKLY_FREQUENCY_TYPE)) {
				alert.setFrequency(WEEKLY_FREQUENCY_TYPE);
				alert.setReceiptDayOfTheWeek(smsBean.getReceiptDOW().toUpperCase());
			} else if (smsBean.getFrequency() == frequencies.get(FORNIGHTLY_FREQUENCY_TYPE)) {
				alert.setFrequency(FORNIGHTLY_FREQUENCY_TYPE);
				alert.setReceiptDayOfTheWeek(smsBean.getReceiptDOW().toUpperCase());
			} else if (smsBean.getFrequency() == frequencies.get(MONTHLY_FREQUENCY_TYPE)) {
				alert.setFrequency(MONTHLY_FREQUENCY_TYPE);
				alert.setStartDate(startDate);
				alert.setEndDate(DateMethods.getUtilDateTime(ALERT_END_DATE, END_DATE_FORMAT));
			}
		} else if (alert.getTypeId() == HI_BALANCE_ALERT_TYPE) {
			alert.setTargetBalance(new BigDecimal(smsBean.getTargetBalance()));
			alert.setOneOffFlag(smsBean.getIsOnceOnly());
		} else if (alert.getTypeId() == LOW_BALANCE_ALERT_TYPE) {
			alert.setTargetBalance(new BigDecimal(smsBean.getTargetBalance()));
			alert.setOneOffFlag(smsBean.getIsOnceOnly());
		} else if (alert.getTypeId() == DEPOSIT_ALERT_TYPE) {
			alert.setAmountFrom(new BigDecimal(smsBean.getTargetBalance()));
			alert.setAmountTo(DEPOSIT_WITHDRAW_TO_AMOUNT);
			alert.setOneOffFlag(smsBean.getIsOnceOnly());
		} else if (alert.getTypeId() == WITHDRAW_ALERT_TYPE) {
			alert.setAmountFrom(new BigDecimal(smsBean.getTargetBalance()));
			alert.setAmountTo(DEPOSIT_WITHDRAW_TO_AMOUNT);
			alert.setOneOffFlag(smsBean.getIsOnceOnly());
			if (smsBean.getIsAuthorisation()) {
				alert.setTypeId(AUTHORISATION_ALERT_TYPE);
			}
			alert.setAmountFrom(new BigDecimal(smsBean.getTargetBalance()));
			alert.setAmountTo(DEPOSIT_WITHDRAW_TO_AMOUNT);
			alert.setOneOffFlag(smsBean.getIsOnceOnly());
		}else if( alert.getTypeId() == CC_REMINDER_ALERT_TYPE){
			alert.setCcAmtType(smsBean.getCcAmtType());
			alert.setOneOffFlag(smsBean.getIsOnceOnly());
		}

		if(!StringMethods.isEmptyString(smsBean.getApplication()) && APPLICATION_ONBOARDING.equalsIgnoreCase(smsBean.getApplication())){
			Logger.info("Setting the value of created by: " + smsBean.getApplication(), this.getClass());
			alert.setCreatedBy(smsBean.getApplication());
		}
		
		alert.setReminderText(smsBean.getReminderText());
		alert.setUserId(gcis);
		alert.setGCISNumber(gcis);
		return alert;
	}

	
	protected String getAccountTypeCode(Account account) {
		if (account.getAccountId().getApplicationId().trim().equals(Account.CRA)) {
			return account.getCreditCardAccountType();
		} else {
			return account.getAccountId().getSubProductCode();
		}
	}
	
	/**
	 * Validate alert
	 * 
	 * @param smsBean
	 * @param isNew
	 * @throws BusinessException
	 */
	protected void validateAlert(AlertReq smsBean, boolean isNew) throws BusinessException {

		boolean error = false;
		// id required
		if (!isNew && smsBean.getAlertID() == null) {
			error = true;
		}

		if (smsBean.getAlertMethod() == null || smsBean.getAlertType() == null || smsBean.getAccountIndex() == null)
			error = true;
			
		if (BALANCE_ALERT_TYPE == smsBean.getAlertType()) {
			if (smsBean.getFrequency() == null) {
				error = true;
			} else if ((smsBean.getFrequency() == frequencies.get(ONCEONLY_FREQUENCY_TYPE) || smsBean.getFrequency() == frequencies.get(DAILY_FREQUENCY_TYPE) || smsBean.getFrequency() == frequencies.get(MONTHLY_FREQUENCY_TYPE))	&& (smsBean.getStartDate() == null))
				error = true;

		} else if ((smsBean.getAlertType().equals(WITHDRAW_ALERT_TYPE) || smsBean.getAlertType().equals(DEPOSIT_ALERT_TYPE)
				|| smsBean.getAlertType().equals(LOW_BALANCE_ALERT_TYPE) || smsBean.getAlertType().equals(HI_BALANCE_ALERT_TYPE))

				&& (StringMethods.isEmptyString(smsBean.getTargetBalance()) || !StringMethods.isPositiveNumber(smsBean.getTargetBalance()))) {
			error = true;
		}else if(smsBean.getAlertType().equals(CC_REMINDER_ALERT_TYPE) && StringMethods.isEmptyString(smsBean.getCcAmtType())){
			error = true;
		}

		if (!StringMethods.isEmptyString(smsBean.getReminderText()) && smsBean.getReminderText().length() > 100)
			error = true;
		if (error)
			throw new BusinessException(BusinessException.GENERIC_ERROR);// existing behavior
	}
	
	private void populateAlerts(List<Alert> alerts, List<Account> customerAccounts, List<AlertResp> alertsResp) {
		for (Alert alert : alerts) {
			AlertResp alertResp = new AlertResp();
			int i = 0;
			for (Account account : customerAccounts) {
				if (alert.getAccountNumber().equals(account.getAccountId().getAccountKey())) {
					alertResp.setAccountIndex(i);
					break;
				}
				i++;
			}
			alertResp.setAlertID(alert.getId());
			
			// As part of PushNotification project, AlertMethod will be String between numbers 1 to 7
			alertResp.setAlertMethod(Integer.parseInt(alert.getAlertMethod()));
			/*
			alertResp.setAlertMethod(alertMethods.get(alert.getAlertMethod()));
			if (alertResp.getAlertMethod() != null && alertResp.getAlertMethod() == 3)
				alertResp.setAlertMethod(2);				
			*/	
			alertResp.setCreateDate(alert.getCreateDate());
			alertResp.setFrequency(frequencies.get(alert.getFrequency()));
			alertResp.setIncludeBalance(alert.isDisplayFlag());
			alertResp.setIsAuthorisation(false);
			alertResp.setAlertType(alert.getTypeId());
			if (alert.getTypeId() == AUTHORISATION_ALERT_TYPE) {
				alertResp.setAlertType(WITHDRAW_ALERT_TYPE);
				alertResp.setIsAuthorisation(true);
			}
			if (!StringMethods.isEmptyString(alert.getFrequency())) {
				if (alert.getTypeId() == BALANCE_ALERT_TYPE) {
					if (alert.isOneOffFlag()) {
						alertResp.setFrequency(frequencies.get(ONCEONLY_FREQUENCY_TYPE));
					} else {
						alertResp.setFrequency(frequencies.get(alert.getFrequency()));
					}
					
					if (FORNIGHTLY_FREQUENCY_TYPE.equals(alert.getFrequency()) || WEEKLY_FREQUENCY_TYPE.equals(alert.getFrequency())){
						alertResp.setReceiptDOW(alert.getReceiptDayOfTheWeek().substring(0,1).toUpperCase() + alert.getReceiptDayOfTheWeek().substring(1,alert.getReceiptDayOfTheWeek().length()).toLowerCase());
					}
				}
			}
			alertResp.setReminderText(alert.getReminderText());
			alertResp.setIsOnceOnly(alert.isOneOffFlag());
			alertResp.setStartDate(alert.getStartDate());
			alertResp.setCcAmtType(alert.getCcAmtType());
			
			
			alertResp.setTargetBalance(alert.getTargetBalance().setScale(2).toPlainString());

			if (alert.getTypeId() == DEPOSIT_ALERT_TYPE || alert.getTypeId() == WITHDRAW_ALERT_TYPE || alert.getTypeId() == AUTHORISATION_ALERT_TYPE){
				alertResp.setTargetBalance(alert.getAmountFrom().setScale(2).toPlainString());
				alertResp.setTargetBalance(alert.getAmountFrom().setScale(2).toPlainString());
			}
			
			alertsResp.add(alertResp);
		}
	}
	
	private void populateAlerts(List<Alert> alerts, List<Account> customerAccounts, AlertsSummaryResp summaryResp) {
		for (Alert alert : alerts) {
			AlertResp alertResp = new AlertResp();
			int i = 0;
			for (Account account : customerAccounts) {
				if (alert.getAccountNumber().equals(account.getAccountId().getAccountKey())) {
					alertResp.setAccountIndex(i);
					break;
				}
				i++;
			}
			alertResp.setAlertID(alert.getId());
			
			// As part of PushNotification project, AlertMethod will be String between numbers 1 to 7
			alertResp.setAlertMethod(Integer.parseInt(alert.getAlertMethod()));
			/*
			alertResp.setAlertMethod(alertMethods.get(alert.getAlertMethod()));
			if (alertResp.getAlertMethod() != null && alertResp.getAlertMethod() == 3)
				alertResp.setAlertMethod(2);				
			*/	
			alertResp.setCreateDate(alert.getCreateDate());
			alertResp.setFrequency(frequencies.get(alert.getFrequency()));
			alertResp.setIncludeBalance(alert.isDisplayFlag());
			alertResp.setIsAuthorisation(false);
			alertResp.setAlertType(alert.getTypeId());
			if (alert.getTypeId() == AUTHORISATION_ALERT_TYPE) {
				alertResp.setAlertType(WITHDRAW_ALERT_TYPE);
				alertResp.setIsAuthorisation(true);
			}
			if (!StringMethods.isEmptyString(alert.getFrequency())) {
				if (alert.getTypeId() == BALANCE_ALERT_TYPE) {
					if (alert.isOneOffFlag()) {
						alertResp.setFrequency(frequencies.get(ONCEONLY_FREQUENCY_TYPE));
					} else {
						alertResp.setFrequency(frequencies.get(alert.getFrequency()));
					}
					
					if (FORNIGHTLY_FREQUENCY_TYPE.equals(alert.getFrequency()) || WEEKLY_FREQUENCY_TYPE.equals(alert.getFrequency())){
						alertResp.setReceiptDOW(alert.getReceiptDayOfTheWeek().substring(0,1).toUpperCase() + alert.getReceiptDayOfTheWeek().substring(1,alert.getReceiptDayOfTheWeek().length()).toLowerCase());
					}
				}
			}
			alertResp.setReminderText(alert.getReminderText());
			alertResp.setIsOnceOnly(alert.isOneOffFlag());
			alertResp.setStartDate(alert.getStartDate());
			alertResp.setCcAmtType(alert.getCcAmtType());
			
			
			alertResp.setTargetBalance(alert.getTargetBalance().setScale(2).toPlainString());

			if (alert.getTypeId() == DEPOSIT_ALERT_TYPE || alert.getTypeId() == WITHDRAW_ALERT_TYPE || alert.getTypeId() == AUTHORISATION_ALERT_TYPE){
				alertResp.setTargetBalance(alert.getAmountFrom().setScale(2).toPlainString());
				alertResp.setTargetBalance(alert.getAmountFrom().setScale(2).toPlainString());
			}
			
			alertResp.setDesc(getDescription(alert));

			switch(alert.getTypeId()){
				case BALANCE_ALERT_TYPE:
					summaryResp.getBalanceAlert().getAlerts().add(alertResp);
					break;
				case HI_BALANCE_ALERT_TYPE:
					summaryResp.getHighBalanceAlert().getAlerts().add(alertResp);
					break;
				case LOW_BALANCE_ALERT_TYPE:
					summaryResp.getLowBalanceAlert().getAlerts().add(alertResp);
					break;
				case DEPOSIT_ALERT_TYPE:
					summaryResp.getDepositsAlert().getAlerts().add(alertResp);
					break;
				case WITHDRAW_ALERT_TYPE:
					summaryResp.getWithdrawalAlert().getAlerts().add(alertResp);
					break;
				case AUTHORISATION_ALERT_TYPE:
					summaryResp.getWithdrawalAlert().getAlerts().add(alertResp);
					break;
				case DISHONOUR_ALERT_TYPE:
					summaryResp.getDishonourAlert().getAlerts().add(alertResp);
					break;
				case CC_REMINDER_ALERT_TYPE:
					summaryResp.getCcReminderAlert().getAlerts().add(alertResp);
					break;					
			}
			
		}
	}
	
	private String getDescription(Alert alert){
		Integer alertType = new Integer(alert.getTypeId());
		String desc = descriptions.get(alertType);
		
		SimpleDateFormat df = new SimpleDateFormat("d MMM yyyy");
		String result = "";
		
		String freq = "when";
		if (!alert.isOneOffFlag()){
			freq = "whenever";
		}
		
		desc = desc.replace("<alertMethod>", getAlertMethodDesc(Integer.parseInt(alert.getAlertMethod())));
		
		switch(alert.getTypeId()){
			case BALANCE_ALERT_TYPE:
				if (alert.isOneOffFlag()) {
					freq = "";
				} else {
					freq = alert.getFrequency().toLowerCase();
				}
				
				if (MONTHLY_FREQUENCY_TYPE.equalsIgnoreCase(alert.getFrequency())){
					result = df.format(alert.getStartDate());
					freq = freq + " starting " + result;
				}
				
				if (FORNIGHTLY_FREQUENCY_TYPE.equals(alert.getFrequency()) || WEEKLY_FREQUENCY_TYPE.equals(alert.getFrequency())){
					String dayWeek = getDayOfWeek(alert);
					freq = freq + " on " + dayWeek + " ";
				}
				
				break;
			case HI_BALANCE_ALERT_TYPE:
			case LOW_BALANCE_ALERT_TYPE:	
				desc = desc.replace("<amount>", MBAppUtils.getFormattedWholeAmount(alert.getTargetBalance()));
				break;
			case DEPOSIT_ALERT_TYPE:
			case WITHDRAW_ALERT_TYPE:
			case AUTHORISATION_ALERT_TYPE:
				desc = desc.replace("<amount>", MBAppUtils.getFormattedWholeAmount(alert.getAmountFrom()));
				break;
			//DISHONOUR_ALERT_TYPE, CC_REMINDER_ALERT_TYPE
			//do nothing
		}
		
		desc = desc.replace("<frequency>", freq);
		
		return desc;
		
	}

	private String getDayOfWeek(Alert alert) {
		String dayWeek = "";
		if ("sun".equalsIgnoreCase(alert.getReceiptDayOfTheWeek())){
			dayWeek = "Sunday";			
		}else if ("mon".equalsIgnoreCase(alert.getReceiptDayOfTheWeek())){
			dayWeek = "Monday";
		}else if ("tue".equalsIgnoreCase(alert.getReceiptDayOfTheWeek())){
			dayWeek = "Tuesday";
		}else if ("wed".equalsIgnoreCase(alert.getReceiptDayOfTheWeek())){
			dayWeek = "Wednesday";
		}else if ("thu".equalsIgnoreCase(alert.getReceiptDayOfTheWeek())){
			dayWeek = "Thursday";
		}else if ("fri".equalsIgnoreCase(alert.getReceiptDayOfTheWeek())){
			dayWeek = "Friday";
		}else if ("sat".equalsIgnoreCase(alert.getReceiptDayOfTheWeek())){
			dayWeek = "Saturday";
		}
		return dayWeek;
	}
	
	private String getAlertMethodDesc (int method){
		String desc = null;
		
		switch (method){
			case 7:
				desc = "SMS, email and notification";
				break;
			case 3:
				desc = "SMS and email";
				break;
			case 6:
				desc = "email and notification";
				break;
			case 5:
				desc = "SMS and notification";
				break;
			case 2:
				desc = "email";
				break;
			case 1:
				desc = "SMS";
				break;	
			case 4:
				desc = "notification";
				break;				
		}
		
		return desc;
	}
	
	protected IMBResp populatePushRegResponse(RespHeader header, boolean isOtherUserRegistered) {
		PushNotfRegResp response = new PushNotfRegResp();
		
		response.setHeader(header);
		response.setIsDeviceRegToOtherUser(isOtherUserRegistered);
				
		Logger.info("Response: " + response, this.getClass());
		return response;
	}
	
	public PushNotificationVO populatePushNotfRegistrationVO(MobileSession mobileSession){
		PushNotificationVO vo = new PushNotificationVO();
		
		vo.setGcisNum(mobileSession.getCustomer().getGcis());
		vo.setDeviceId(mobileSession.getDeviceID());				
		
		return vo;
	}

	/**
	 * Populate register response
	 * 
	 * @param header
	 * @param status
	 * @return
	 */
	protected IMBResp populateOverwritePushRegResponse(RespHeader header, Integer status) {
		StatusResp response = new StatusResp(header);
		response.setStatus(status);
		Logger.info("Response: " + response, this.getClass());
		return response;
	}
	
	private String getReceiptDescription(Alert alert){
		Integer alertType = new Integer(alert.getTypeId());
		String desc = receiptDescriptions.get(alertType);
		
		SimpleDateFormat df = new SimpleDateFormat("d MMM yyyy");
		String result = "";
		
		String freq = "when";
		if (!alert.isOneOffFlag()){
			freq = "whenever";
		}
		
		desc = desc.replace("<alertMethod>", getAlertMethodDesc(Integer.parseInt(alert.getAlertMethod())));
		
		if(alert.getTypeId() == BALANCE_ALERT_TYPE){
					if (alert.isOneOffFlag()) {
						freq = "";
					} else {
						freq = alert.getFrequency().toLowerCase();
					}
					
					if (MONTHLY_FREQUENCY_TYPE.equalsIgnoreCase(alert.getFrequency())){
						result = df.format(alert.getStartDate());
						freq = freq + " starting " + result;
					}
					
					if (FORNIGHTLY_FREQUENCY_TYPE.equals(alert.getFrequency()) || WEEKLY_FREQUENCY_TYPE.equals(alert.getFrequency())){
						String dayWeek = getDayOfWeek(alert);
						freq = freq + " on " + dayWeek + " ";
					}
			}
		
		desc = desc.replace("<frequency>", freq);
		
		return desc;
	}
	
	public static void statisticsLogAlertsOnboarding(String gdwAction, String gdwDescription, Alert alert, IBankCommonData commonData) {

			Statistic s = new Statistic();			
			s.setAction(gdwAction);
			s.setDescription(gdwDescription);
			s.setGcisNumber(commonData.getUser().getGCISNumber());
			s.setOriginBank(commonData.getOrigin());
			s.setGDWOriginBank(commonData.getGdwOrigin());
			s.setAccountNumberFrom(null);
			
			if(alert != null){
				s.setAmount(alert.getAmountFrom());
				s.setAccountTypeFrom(alert.getApplicationId());
			}else{
				s.setAccountTypeFrom(null);
			}
			
			s.setApplIdFrom(null);
			s.setProdCodeFrom(null);
			s.setIpAddress(commonData.getIpAddress());
			s.setSessionId(commonData.getSessionId());
		try {
			StatisticsService.logStatistic(s);
		}catch (Exception e) {
			Logger.error(" Mobile - Failed!! Statistic log for Alerts Onboarding ", e,AlertsHelper.class);
		}
	}
}
