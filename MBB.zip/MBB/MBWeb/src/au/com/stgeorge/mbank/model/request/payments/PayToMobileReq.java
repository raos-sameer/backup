package au.com.stgeorge.mbank.model.request.payments;

import javax.validation.constraints.Pattern;

import org.apache.commons.lang.builder.ReflectionToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;
import org.hibernate.validator.constraints.Length;
import org.hibernate.validator.constraints.NotEmpty;

import au.com.stgeorge.ibank.businessobject.BusinessException;

/**
 * Pay to mobile request
 * 
 * @author C38854
 * 
 */
public class PayToMobileReq extends TransferReq {
	private static final long serialVersionUID = -9193183050975007159L;

	private static final String BLOCK_CHARS_PATTERN = "^[0-9A-Za-z',. &/\\-]*$";

	@NotEmpty(message = "{errors.recipent.required}")
	@Length(max = 32, message = "{errors.recipent.maxlength}")
	@Pattern(regexp = BLOCK_CHARS_PATTERN, message = "{errors.recipent.blockchar}")
	private String receiverName;

	@NotEmpty(message = "{errors.mobileNumber.required}")
	@Length(max = 10, min = 10, message = "" + BusinessException.P2P_INVALID_MOBILE_NUM)
	@Pattern(regexp = MASK_NUMBERS, message = "" + BusinessException.P2P_INVALID_MOBILE_NUM)
	private String mobileNumber;
	
	@NotEmpty(message = "{errors.payerName.required}")
	@Pattern(regexp = BLOCK_CHARS_PATTERN, message = "{errors.payerName.blockchar}")
	@Length(max = 30, message = "{errors.payerName.maxlength}")
	private String payerName;
	
	private Boolean fromNativeContacts;
	
	private Integer accountIndex;

	private Boolean sendPayerEmail;
	private String recipientEmail;
	
	private Integer dupCount;
	
	private String entryPoint;

	public String getPayerName() {
		return payerName;
	}

	public String getReceiverName() {
		return receiverName;
	}

	public String getMobileNumber() {
		return mobileNumber;
	}
	
	public Boolean getFromNativeContacts() {
		return fromNativeContacts;
	}
	
	public Integer getAccountIndex() {
		return accountIndex;
	}

	public void setAccountIndex(Integer accountIndex) {
		this.accountIndex = accountIndex;
	}

	public Boolean getSendPayerEmail() {
		return sendPayerEmail;
	}

	public void setSendPayerEmail(Boolean sendPayerEmail) {
		this.sendPayerEmail = sendPayerEmail;
	}

	public String getRecipientEmail() {
		return recipientEmail;
	}

	public void setRecipientEmail(String recipientEmail) {
		this.recipientEmail = recipientEmail;
	}

	public Integer getDupCount() {
		return dupCount;
	}
	
	public String getEntryPoint() {
		return entryPoint;
	}

	public void setEntryPoint(String entryPoint) {
		this.entryPoint = entryPoint;
	}

	@Override
	public String toString() {
		return ReflectionToStringBuilder.toString(this, ToStringStyle.MULTI_LINE_STYLE);
	}

}
