package au.com.stgeorge.mbank.controller.customer;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import au.com.stgeorge.digitalsec.logger.DigitalSecLogger;
import au.com.stgeorge.digitalsec.logger.DigitalSecLogggerVO;
import au.com.stgeorge.framework.common.logging.Logger;
import au.com.stgeorge.framework.common.model.User;
import au.com.stgeorge.framework.common.util.StringMethods;
import au.com.stgeorge.ibank.businessobject.BusinessException;
import au.com.stgeorge.ibank.businessobject.ContactDetailsValidationService;
import au.com.stgeorge.ibank.businessobject.HeartBeat;
import au.com.stgeorge.ibank.businessobject.IBankSecureService;
import au.com.stgeorge.ibank.businessobject.MemoryThrottlingService;
import au.com.stgeorge.ibank.businessobject.PRMUpdateService;
import au.com.stgeorge.ibank.businessobject.ResourceException;
import au.com.stgeorge.ibank.businessobject.assembler.CustomerVOAssembler;
import au.com.stgeorge.ibank.businessobject.emailupdation.EmailUpdationService;
import au.com.stgeorge.ibank.businessobject.model.commdtlsvaldatn.AddressErrorResult;
import au.com.stgeorge.ibank.businessobject.model.commdtlsvaldatn.AddressResult;
import au.com.stgeorge.ibank.businessobject.model.commdtlsvaldatn.AddressValidationReq;
import au.com.stgeorge.ibank.businessobject.model.commdtlsvaldatn.AddressValidationReq.CustomerRiskAssessmentIndicator;
import au.com.stgeorge.ibank.businessobject.model.commdtlsvaldatn.AddressValidationResp;
import au.com.stgeorge.ibank.businessobject.model.commdtlsvaldatn.AddressValidationSuccess;
import au.com.stgeorge.ibank.businessobject.model.commdtlsvaldatn.Customer.BrandSilo;
import au.com.stgeorge.ibank.businessobject.model.commdtlsvaldatn.CustomerId;
import au.com.stgeorge.ibank.businessobject.model.commdtlsvaldatn.CustomerId.IdScheme;
import au.com.stgeorge.ibank.businessobject.model.commdtlsvaldatn.ErrorPartialResult;
import au.com.stgeorge.ibank.businessobject.model.commdtlsvaldatn.NonStandardAddress;
import au.com.stgeorge.ibank.businessobject.model.commdtlsvaldatn.PhoneDetails;
import au.com.stgeorge.ibank.businessobject.model.commdtlsvaldatn.PhoneDetails.UsageType;
import au.com.stgeorge.ibank.businessobject.model.commdtlsvaldatn.RiskAssessRequest;
import au.com.stgeorge.ibank.businessobject.model.commdtlsvaldatn.RiskAssessRequest.ApplicantRoleType;
import au.com.stgeorge.ibank.businessobject.model.commdtlsvaldatn.RiskAssessRequest.AppliedProductType;
import au.com.stgeorge.ibank.businessobject.model.fraudassmntevntmaint.DeviceRisk;
import au.com.stgeorge.ibank.common.cache.IBankParams;
import au.com.stgeorge.ibank.messagecentre.util.MessageCentreConstants;
import au.com.stgeorge.ibank.messagecentre.valueobject.MessageSearch;
import au.com.stgeorge.ibank.safi.businessobject.Safi2Service;
import au.com.stgeorge.ibank.safi.util.SafiConstants;
import au.com.stgeorge.ibank.safi.valueobject.SafiUpdatePhoneVO;
import au.com.stgeorge.ibank.service.businessobject.ManagePayIdService;
import au.com.stgeorge.ibank.service.valueobject.SafiRespVO;
import au.com.stgeorge.ibank.servicestation.businessobject.ServiceStation;
import au.com.stgeorge.ibank.servicestation.businessobject.ServiceStationImpl;
import au.com.stgeorge.ibank.servicestation.businessobject.valueobject.ServiceStationVO;
import au.com.stgeorge.ibank.servicestation.util.ServicetationConstants;
import au.com.stgeorge.ibank.util.CommonBusinessUtil;
import au.com.stgeorge.ibank.util.ServiceHelper;
import au.com.stgeorge.ibank.valueobject.Account;
import au.com.stgeorge.ibank.valueobject.Address;
import au.com.stgeorge.ibank.valueobject.ContactDetail;
import au.com.stgeorge.ibank.valueobject.Customer;
import au.com.stgeorge.ibank.valueobject.CustomerTypes;
import au.com.stgeorge.ibank.valueobject.ManagePayIdDetails;
import au.com.stgeorge.ibank.valueobject.PhoneNumber;
import au.com.stgeorge.ibank.valueobject.Statistic;
import au.com.stgeorge.ibank.valueobject.collection.LabelValueMap;
import au.com.stgeorge.ibank.valueobject.database.OriginsVO;
import au.com.stgeorge.ibank.valueobject.transfer.IBankCommonData;
import au.com.stgeorge.mbank.controller.IMBController;
import au.com.stgeorge.mbank.controller.SafiWebHelper;
import au.com.stgeorge.mbank.controller.SecureCodeHelper;
import au.com.stgeorge.mbank.model.common.AccountKeyInfoResp;
import au.com.stgeorge.mbank.model.common.IMBReq;
import au.com.stgeorge.mbank.model.common.IMBResp;
import au.com.stgeorge.mbank.model.common.ReqHeader;
import au.com.stgeorge.mbank.model.common.RespHeader;
import au.com.stgeorge.mbank.model.request.EmptyReq;
import au.com.stgeorge.mbank.model.request.SecureCodeReq;
import au.com.stgeorge.mbank.model.request.customer.ContactDetailsReq;
import au.com.stgeorge.mbank.model.request.customer.PhoneDetailReq;
import au.com.stgeorge.mbank.model.response.ErrorResp;
import au.com.stgeorge.mbank.model.response.SingleBooleanFlagResp;
import au.com.stgeorge.mbank.model.response.SuccessResp;
import au.com.stgeorge.mbank.model.response.customer.ContactDetailsResp;
import au.com.stgeorge.mbank.session.MobileSession;
import au.com.stgeorge.mbank.session.MobileSessionImpl;
import au.com.stgeorge.mbank.util.FraudLogger;
import au.com.stgeorge.mbank.util.MBAppConstants;
import au.com.stgeorge.mbank.util.MBAppHelper;
import au.com.stgeorge.mbank.util.MBAppUtils;
import au.com.stgeorge.mbank.util.MBAppValidator;
import au.com.stgeorge.mbank.util.ServiceConstants;
import au.com.stgeorge.mobilebank.businessobject.MobileBankService;
import au.com.stgeorge.mobilebank.businessobject.impl.MobileBankServiceImpl;
import au.com.stgeorge.perflogger.PerformanceLogger;
import au.com.stgeorge.mbank.model.common.PhoneReq;
import java.util.Iterator;

@Controller
@RequestMapping("/contactdetail")
public class ContactDetailController implements IMBController
{

	private static final String UPDATE_CONTACT_SRV_NAME = "updatecontactdtls";
	private static final String GET_CONTACT_SRV_NAME = "getcontactdtls";
	private FraudLogger fraudLogger;
		
	@Autowired
	private SecureCodeHelper secureCodeHelper;

	@Autowired
	private MobileBankService mobileBankService;

	@Autowired
	private MBAppHelper mbAppHelper;
	
	@Autowired
	private ContactDetailHelper contactDetailHelper;
	
	@Autowired
	private LogonHelper logonHelper;
	
	@Autowired
    private DigitalSecLogger digitalSecurityLogger;
	
    @Autowired
	private ServiceStation serviceStationService;
    
    @Autowired
    private ManagePayIdService managePayIdService;
    
    @Autowired
	private MemoryThrottlingService memoryThrottlingService;   
    
	@Autowired
	private Safi2Service safi2Service; 
	
	@Autowired
    private EmailUpdationService emailUpdationService;
	
	@Autowired
	private ContactDetailsValidationService contactDetValService;

	@RequestMapping(value="view", method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public IMBResp getContactDtls(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse,
			@RequestBody final ContactDetailsReq req)
	{
		Logger.debug("In getContactDtls ( ContactDetailController )  for Customer " +  "  " + httpServletRequest.getContentType() + " "
				+ httpServletRequest.getRemoteAddr() + "  " + httpServletResponse.getCharacterEncoding() + httpServletResponse.getLocale() +
				" True IP >> " + httpServletRequest.getHeader(IBankParams.trueClientIP()), this.getClass());

		PerformanceLogger performanceLogger = new PerformanceLogger();
		fraudLogger = new FraudLogger();
		performanceLogger.startAllLogs();
		String logName = MBAppUtils.getLogName(httpServletRequest);
		performanceLogger.startLog(logName);
		ObjectMapper mapper = new ObjectMapper();
		MobileSession mbSession = null;
		try
		{
			mbSession = mbAppHelper.getMobileSession(httpServletRequest);		
			Logger.info("getContactDtls JSON Request :" + mapper.writeValueAsString(req), this.getClass());
			validateRequestHeader( req.getHeader(), httpServletRequest );

			ErrorResp errorResp = validate(req, httpServletRequest);
			if (errorResp != null && errorResp.getErrors() != null && errorResp.getErrors().size() > 0)
			{
				return errorResp;
			}

			//Remove SAFI vo for update phone and updated contact number saved in session
			mbSession.removeUpdatePhoneDetails();
			
			if(null != mbSession.getSafiRequestVO() && mbSession.getSafiRequestVO() instanceof SafiUpdatePhoneVO) {
				mbSession.removeSafiRequestVO();
			}
			
			Customer customer=mbSession.getCustomer();
			User user=mbSession.getUser();
			
//			IBankCommonData ibankCommonData = populateIBankCommonData(customer,user);
			IBankCommonData ibankCommonData=mbAppHelper.populateIBankCommonData(mbSession,httpServletRequest);

			ContactDetail contactDetail =  mobileBankService.getContactDetails(ibankCommonData);
			boolean isEditable =  IBankParams.YES.equalsIgnoreCase(logonHelper.isCustomerSecCodeExempted(customer));
			if(customer!=null){
			contactDetail.setCustomerOfTypeGHS(customer.isCustomerOfTypeGHS());
			}
			
			try{
				String modInd = mobileBankService.getUcmModIndicator(ibankCommonData);  
				if(modInd != null)
					mbSession.setUcmModIndicator(modInd);
				else
					Logger.info("Failure : 258 Fails to fetch UCM ModInd .Error Bypassed ", this.getClass());
				
			}catch(Exception e){
				Logger.error("Error : 258 Fails to fetch UCM ModInd .Error Bypassed ", this.getClass());
			}
			
			IMBResp serviceResponse = contactDetailHelper.populateResponse(contactDetail, isEditable, mbSession.getOrigin());
			
			boolean isCustomerOver14 = contactDetailHelper.isCustomerOver14(customer);
			((ContactDetailsResp)serviceResponse).setCustomerOver14(isCustomerOver14);
			
			Logger.info("getContactDtls JSON Response :" + mapper.writeValueAsString(serviceResponse), this.getClass());

			boolean showUpdatePhoneNoButton = true;

			if (IBankParams.isGlobalByPass()) {
				Logger.info("isGlobalByPass : true", this.getClass());
				showUpdatePhoneNoButton = false;
			} else if (customer.isCHSCustomer()) {
				Logger.info("isCHSCustomer : true", this.getClass());
				showUpdatePhoneNoButton = false;
			} else if (IBankSecureService.isCustomerExempt(customer.getIBankSecureDetails())) {
				Logger.info("isCustomerExempt : true", this.getClass());
				showUpdatePhoneNoButton = false;
			} else if (CustomerVOAssembler.BUSINESS_CUSTOMER.equalsIgnoreCase(contactDetail.getCustTypeInd())) {
				Logger.info("isGHS_Business : true", this.getClass());
				showUpdatePhoneNoButton = false;
			}
			((ContactDetailsResp)serviceResponse).setShowUpdatePhoneNoButton(showUpdatePhoneNoButton);
			RespHeader headerResp = populateResponseHeader(req.getHeader().getServiceName(), mbSession );
			serviceResponse.setHeader(headerResp);
			
			if (req.isSourceSecurityWellBeingCheck() && mbSession.getSWBInfoMsg() == null ) {
				mbSession.setSWBInfoMsg(Boolean.TRUE);
			}
			else {
				mbSession.removeSWBInfoMsg();
			}
			if (IBankParams.isEmailUpdationSwitchOn()) {
				//20E4 - Email Updation splash page - if user has come from Email Updation spash page then increment counter. Splash page will stop coming after logon 
				// once the max skip count is reached.
				MessageSearch messageSearch = mbSession.getSplashInfoMsg();
				if(messageSearch!=null && isEmailUpdationSplashMsg(messageSearch)) {
					if (req.isSourceEuSplashPage()) {
						emailUpdationService.updateSkipCounter(messageSearch, ibankCommonData, true);
						emailUpdationService.addStatisticsLog(ibankCommonData);
					} else {
						mbSession.removeSplashInfoMsg();
					}
				}
			}
			mbSession.removeDigitalSecLoggerMap();
			LabelValueMap digiSecMap = new LabelValueMap();
			digiSecMap.put(DigitalSecLogger.PREV_CONTACT_DETAILS,contactDetail.toDigitalSecurityLog(true,get2FAExemptType(mbSession.getCustomer()),null, isCHSorCombinedCustomer(customer)));
			mbSession.setDigitalSecLoggerMap(digiSecMap);
			
			return serviceResponse;
		} catch (BusinessException e)
		{
			Logger.error("Exception Inside getContactDtls() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			BusinessException exp = new BusinessException(e.getKey());
			IMBResp resp1 = MBAppUtils.createErrorResp(mbSession.getOrigin() , exp, MBAppConstants.SMPL_GETCONTACTDTLS_RESP_NAME, httpServletRequest);
			return resp1;
		} catch (Exception e)
		{	
			Logger.error("Exception Inside getContactDtls() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			BusinessException exp = new BusinessException(BusinessException.SMPL_SYS_ERROR);
			IMBResp resp1 = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, MBAppConstants.SMPL_GETCONTACTDTLS_RESP_NAME, httpServletRequest);
			return resp1;
		} finally
		{
			performanceLogger.endLog(logName);
			performanceLogger.endAllLogs();
		}
	}

	@RequestMapping(value="reqsecurecode", method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public IMBResp reqSecureCode(HttpServletRequest httpRequest, HttpServletResponse httpServletResponse,
			@RequestBody final SecureCodeReq request)
	{
		Logger.debug("In reqSecCode ( ContactDetailController )  for Customer " +  "  " + httpRequest.getContentType() + " "
				+ httpRequest.getRemoteAddr() + "  " + httpServletResponse.getCharacterEncoding() + httpServletResponse.getLocale() +
				" True IP >> " + httpRequest.getHeader(IBankParams.trueClientIP()), this.getClass());

		PerformanceLogger performanceLogger = new PerformanceLogger();
		fraudLogger = new FraudLogger();
		performanceLogger.startAllLogs();
		String logName = MBAppUtils.getLogName(httpRequest);
		performanceLogger.startLog(logName);
		MobileSession mbSession = null;
		try {
			mbSession = mbAppHelper.getMobileSession(httpRequest);
			validateRequestHeader( request.getHeader(), httpRequest );
			
			ErrorResp errorResponse = validate(request, httpRequest);
			if (errorResponse.hasErrors())
				return errorResponse;
			
			
			//check SafiUpdatePhoneVO exists in session.
			SafiUpdatePhoneVO safiVO = null;
			String safiAction = null;
			
			//check if this me
			if(null != mbSession.getSafiRequestVO() && mbSession.getSafiRequestVO() instanceof SafiUpdatePhoneVO) {
				
				Logger.debug("SAFI VO available in session. ", this.getClass());
				
				safiVO = (SafiUpdatePhoneVO) mbSession.getSafiRequestVO();
				
				if(null != safiVO.getSafiRespVO())
					safiAction = safiVO.getSafiRespVO().getSafiAction();
			} 
			
			IBankCommonData commonData=mbAppHelper.populateIBankCommonData(mbSession,httpRequest);
			
			IMBResp response = secureCodeHelper.reqSecureCode(commonData, mbSession, mbSession.getTransaction(), request, ServiceConstants.CONTACTDTLS_SECURE_CODE_SERVICE, httpRequest);
			
			//In case of error log the errors
			if(response instanceof ErrorResp){			
				errorResponse = (ErrorResp) response;
				if (errorResponse.hasErrors()){
					DigitalSecLogggerVO digitalSecLoggerVO =new DigitalSecLogggerVO();
					digitalSecLoggerVO.setUserAgent(commonData.getUserAgent()); 
					digitalSecLoggerVO.setTranName(DigitalSecLogger.UPDATE_CONTACT_DETAILS);
					digitalSecLoggerVO.setStatus(DigitalSecLogger.FAILURE_2FA);
					digitalSecLoggerVO.setPrevValues(mbSession.getDigitalSecLoggerMap().get(DigitalSecLogger.PREV_CONTACT_DETAILS));
					digitalSecurityLogger.log(digitalSecLoggerVO);
					
					//SAFI notify call in case 2FA_SUSPENDED and SAFI_ACTION is a CHALLENGE
					if(errorResponse.getStatus() ==  ErrorResp.STATUS_2FA_SUSPENDED  && !(StringMethods.isEmptyString(safiAction)) && safiAction.equalsIgnoreCase(SafiConstants.SAFI_ACTION_CHALLENGE)){
						Logger.debug("SAFI : reqSecureCode(): Notify Call:START : SafiAction :Challenge: STATUS_2FA_SUSPENDED",this.getClass());
						callSafiNotify(httpRequest, httpServletResponse, false, commonData);
						Logger.debug("SAFI : reqSecureCode(): Notify Call:END : SafiAction :Challenge: STATUS_2FA_SUSPENDED",this.getClass());
					}
					
					return errorResponse;
				}
			}
			
			mbSession.removeDigitalSecLoggerMap();
			LabelValueMap digitalSecLoggerMap = new LabelValueMap();
			PhoneNumber phoneNumber = CommonBusinessUtil.get2FAPhoneNumber(commonData, request.getPhone());
			Customer customer=mbSession.getCustomer();
			ContactDetail contactDetail = (ContactDetail) customer.getContactDetail();
			digitalSecLoggerMap.put(DigitalSecLogger.PREV_CONTACT_DETAILS,contactDetail.toDigitalSecurityLog(true,request.getDeliveryMethod(), phoneNumber.getAreaCode()+phoneNumber.getPhoneNumber(), isCHSorCombinedCustomer(customer)));
			mbSession.setDigitalSecLoggerMap(digitalSecLoggerMap);
			
			return response;
		}
		catch (BusinessException e)
		{
			Logger.error("Exception Inside reqUpdSecCode() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			IMBResp resp1 = MBAppUtils.createErrorResp(mbSession.getOrigin(), e, MBAppConstants.SMPL_GETCONTACTDTLS_RESP_NAME, httpRequest);
			return resp1;
		} catch (Exception e)
		{
			Logger.error("Exception Inside reqUpdSecCode() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			BusinessException exp = new BusinessException(BusinessException.SMPL_SYS_ERROR);
			IMBResp resp1 = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, MBAppConstants.SMPL_GETCONTACTDTLS_RESP_NAME, httpRequest);
			return resp1;
		} finally
		{
			performanceLogger.endLog(logName);
			performanceLogger.endAllLogs();
		}
	}

	@RequestMapping(value="viewsecure", method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public IMBResp verifySecUpddtls(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse,
			@RequestBody final SecureCodeReq req)
	{
		Logger.debug("In verifySecUpddtls ( ContactDetailsController )  for Customer " +  "  " + httpServletRequest.getContentType() + " "
				+ httpServletRequest.getRemoteAddr() + "  " + httpServletResponse.getCharacterEncoding() + httpServletResponse.getLocale() +
				" True IP >> " + httpServletRequest.getHeader(IBankParams.trueClientIP()), this.getClass());

		PerformanceLogger performanceLogger = new PerformanceLogger();
		fraudLogger = new FraudLogger();
		performanceLogger.startAllLogs();
		String logName = MBAppUtils.getLogName(httpServletRequest);
		performanceLogger.startLog(logName);
		ObjectMapper mapper = new ObjectMapper();
		String devicePrintForLogger = null;
		MobileSession mbSession = null;
		DigitalSecLogggerVO digitalSecLoggerVO =new DigitalSecLogggerVO();
		ContactDetailsResp updatePhoneResp = new ContactDetailsResp();
		boolean isUpdatePhone = false;
		
		try
		{
			mbSession = mbAppHelper.getMobileSession(httpServletRequest);

			validateRequestHeader( req.getHeader(), httpServletRequest );

			ErrorResp errorResp = validate(req, httpServletRequest);
			if (errorResp != null && errorResp.getErrors() != null && errorResp.getErrors().size() > 0)
			{
				return errorResp;
			}
			
			boolean isMobileApp = ((logonHelper.loadCordova(httpServletRequest)) == -1) ? false:true;
			if(isMobileApp){
				String sdkDevicePrint = mbSession.getSafiLogonInfo()!= null ? mbSession.getSafiLogonInfo().getDevicePrint():null;
				try{
					JsonNode jsonNode = mapper.readValue(sdkDevicePrint, JsonNode.class);
					devicePrintForLogger = jsonNode!= null? jsonNode.toString() : "";
				}catch (Exception e) {
					//Swallow the exception if not able to derive sdk device print 
				}
			}

			//check SafiUpdatePhoneVO exists in session.
			SafiUpdatePhoneVO safiVO = null;
			String safiAction = null;
			
			//check if this me
			if(null != mbSession.getSafiRequestVO() && mbSession.getSafiRequestVO() instanceof SafiUpdatePhoneVO) {
				
				Logger.debug("SAFI VO available in session. ", this.getClass());
				
				safiVO = (SafiUpdatePhoneVO) mbSession.getSafiRequestVO();
			
				if(safiVO.isAnalyseSuccess())
					isUpdatePhone = true;
				
				if(null != safiVO.getSafiRespVO())
					safiAction = safiVO.getSafiRespVO().getSafiAction();
			}
			
			Customer customer=mbSession.getCustomer();
			
			IBankCommonData ibankCommonData=mbAppHelper.populateIBankCommonData(mbSession,httpServletRequest);
						
			ContactDetail contactDetail = (ContactDetail) customer.getContactDetail();
			
			ErrorResp errorResponse = secureCodeHelper.verifySecureCode(ibankCommonData, mbSession, mbSession.getTransaction(), req, ServiceConstants.UPD_CONTACT_DTL_SECURE_SERVICE, httpServletRequest);
			if (errorResponse.hasErrors() && isUpdatePhone){
				digitalSecLoggerVO.setCommonLogData(mbAppHelper.getCommonLogData(ibankCommonData));
				digitalSecLoggerVO.setUserAgent(ibankCommonData.getUserAgent()); 
				digitalSecLoggerVO.setTranName(DigitalSecLogger.UPDATE_PHONE_NUMBER_SAFI_ANALYSE);
				digitalSecLoggerVO.setStatus(DigitalSecLogger.FAILURE_2FA);
				try {
					digitalSecLoggerVO.setValues(contactDetailHelper.populateChangedPhoneNumbers(mbSession.getUpdatePhoneDetails(), mbSession.getCustomer().getContactDetail(),devicePrintForLogger));					
					digitalSecurityLogger.log(digitalSecLoggerVO);
				}catch(Exception e) {
					Logger.warn("Exception occurred while making Digital security logger entry (suppressing error) ", e, this.getClass());
				}
				
				//SAFI notify call in case 2FA_SUSPENDED and SAFI_ACTION is a CHALLENGE
				if(errorResponse.getStatus() ==  ErrorResp.STATUS_2FA_SUSPENDED  && !(StringMethods.isEmptyString(safiAction)) && safiAction.equalsIgnoreCase(SafiConstants.SAFI_ACTION_CHALLENGE)){
					Logger.debug("SAFI : verifySecUpddtls(): Notify Call:START : SafiAction :Challenge: STATUS_2FA_SUSPENDED",this.getClass());
					callSafiNotify(httpServletRequest, httpServletResponse, false, ibankCommonData);
					Logger.debug("SAFI : verifySecUpddtls(): Notify Call:END : SafiAction :Challenge: STATUS_2FA_SUSPENDED",this.getClass());
				}
				
				return errorResponse;
			}else if (errorResponse.hasErrors()){
				digitalSecLoggerVO.setCommonLogData(mbAppHelper.getCommonLogData(ibankCommonData));
				digitalSecLoggerVO.setUserAgent(ibankCommonData.getUserAgent()); 
				digitalSecLoggerVO.setTranName(DigitalSecLogger.UPDATE_CONTACT_DETAILS);
				digitalSecLoggerVO.setStatus(DigitalSecLogger.FAILURE_2FA);
				digitalSecLoggerVO.setPrevValues(mbSession.getDigitalSecLoggerMap().get(DigitalSecLogger.PREV_CONTACT_DETAILS));
				digitalSecurityLogger.log(digitalSecLoggerVO);
				
				//SAFI notify call in case 2FA_SUSPENDED and SAFI_ACTION is a CHALLENGE
				if(errorResponse.getStatus() ==  ErrorResp.STATUS_2FA_SUSPENDED  && !(StringMethods.isEmptyString(safiAction)) && safiAction.equalsIgnoreCase(SafiConstants.SAFI_ACTION_CHALLENGE)){
					Logger.debug("SAFI : verifySecUpddtls(): Notify Call:START : SafiAction :Challenge: STATUS_2FA_SUSPENDED",this.getClass());
					callSafiNotify(httpServletRequest, httpServletResponse, false, ibankCommonData);
					Logger.debug("SAFI : verifySecUpddtls(): Notify Call:END : SafiAction :Challenge: STATUS_2FA_SUSPENDED",this.getClass());
				}
				
				return errorResponse;
			}
			
			if(isUpdatePhone) {
				digitalSecLoggerVO.setCommonLogData(mbAppHelper.getCommonLogData(ibankCommonData));
				digitalSecLoggerVO.setUserAgent(ibankCommonData.getUserAgent()); 
				digitalSecLoggerVO.setTranName(DigitalSecLogger.UPDATE_PHONE_NUMBER_SAFI_ANALYSE);
				digitalSecLoggerVO.setStatus(DigitalSecLogger.SUCCESS);
				try{
					digitalSecLoggerVO.setValues(contactDetailHelper.populateChangedPhoneNumbers(mbSession.getUpdatePhoneDetails(), mbSession.getCustomer().getContactDetail(),devicePrintForLogger));
					digitalSecurityLogger.log(digitalSecLoggerVO);
				}catch(Exception e) {
					Logger.warn("Exception occurred while making Digital security logger entry (suppressing error) ", e, this.getClass());
				}
				if(IBankParams.isUpdateContactDetailsSwitchOn()) {
					return updateCustPhoneNumberNew(mbSession.getUpdatePhoneDetails(), ibankCommonData, mbSession, updatePhoneResp, httpServletRequest, httpServletResponse);	
				}else {
					return updateCustPhoneNumber(mbSession.getUpdatePhoneDetails(), ibankCommonData, mbSession, updatePhoneResp, httpServletRequest, httpServletResponse);	
				}
			}
			
			mbSession.setSecureCodeVerifiedTranName(ServiceConstants.UPD_CONTACT_DTL_SECURE_SERVICE);
			
			IMBResp serviceResponse = contactDetailHelper.populateResponse(contactDetail, true, mbSession.getOrigin());
			Logger.info("verifySecUpddtls JSON Response :" + mapper.writeValueAsString(serviceResponse), this.getClass());
			RespHeader headerResp = populateResponseHeader(ServiceConstants.UPDCONTACTDTL_RESPONSE, mbSession);
			serviceResponse.setHeader(headerResp);
			
						
			return serviceResponse;
		} catch (BusinessException e)
		{
			Logger.error("Exception Inside verifysecupddtls() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			
			if(!updatePhoneResp.isSuccess())
				return updatePhoneResp;
			IMBResp resp1 = null;
			if (e.getKey() == BusinessException.UPDATE_PHONE_DEAD || e.getKey() == BusinessException.UPDATE_PHONE_UNVERIFIED) {
				BusinessException exp = new BusinessException(e.getKey());
				resp1 = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, MBAppConstants.SMPL_UPDCONTACTDTLS_RESP_NAME, httpServletRequest);
			}else {
				resp1 = MBAppUtils.createErrorResp( mbSession.getOrigin(), e, MBAppConstants.SMPL_UPDCONTACTDTLS_RESP_NAME, httpServletRequest);
			}
			return resp1;
		} catch (Exception e)
		{
			Logger.error("Exception Inside verifysecupddtls() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			
			if(!updatePhoneResp.isSuccess())
				return updatePhoneResp;
			
			BusinessException exp = new BusinessException(BusinessException.SMPL_SYS_ERROR);
			IMBResp resp1 = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, MBAppConstants.SMPL_UPDCONTACTDTLS_RESP_NAME, httpServletRequest);
			return resp1;
		} finally
		{
			performanceLogger.endLog(logName);
			performanceLogger.endAllLogs();
		}
	}
	
	@RequestMapping(value="update", method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public IMBResp updContactDtls(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse,
			@RequestBody final ContactDetailsReq req)
	{
		Logger.debug("In updContactDtls ( ContactDetailsController )  for Customer " +  "  " + httpServletRequest.getContentType() + " "
				+ httpServletRequest.getRemoteAddr() + "  " + httpServletResponse.getCharacterEncoding() + httpServletResponse.getLocale() +
				" True IP >> " + httpServletRequest.getHeader(IBankParams.trueClientIP()), this.getClass());

		PerformanceLogger performanceLogger = new PerformanceLogger();
		fraudLogger = new FraudLogger();
		performanceLogger.startAllLogs();
		String logName = MBAppUtils.getLogName(httpServletRequest);
		performanceLogger.startLog(logName);
		ObjectMapper mapper = new ObjectMapper();
		String pageInfoMsg = null;
		String origin = null;
		MobileSession mbSession = null;
		DigitalSecLogggerVO digitalSecurityLogVO =new DigitalSecLogggerVO();
		digitalSecurityLogVO.setTranName(DigitalSecLogger.UPDATE_CONTACT_DETAILS);
		ArrayList<AccountKeyInfoResp> accntDispList =null;
		ArrayList<AccountKeyInfoResp> accntNotDispList =null;
		
		try
		{
			mbSession = mbAppHelper.getMobileSession(httpServletRequest);
            validateRequestHeader( req.getHeader(), httpServletRequest );
			origin = mbSession.getOrigin();
//			Logger.info("updContactDtls JSON Request :" + mapper.writeValueAsString(req), this.getClass());
			ErrorResp errorResp = validate(req, httpServletRequest);
			if (errorResp != null && errorResp.getErrors() != null && errorResp.getErrors().size() > 0)
			{
				return errorResp;
			}
			
			//Remove SAFI vo for update phone and updated contact number saved in session
			mbSession.removeUpdatePhoneDetails();
			
			if(null != mbSession.getSafiRequestVO() && mbSession.getSafiRequestVO() instanceof SafiUpdatePhoneVO) {
				mbSession.removeSafiRequestVO();
			}
			
			Customer customer=mbSession.getCustomer();
			customer.getContactDetail().getCustTypeInd();
			User user=mbSession.getUser();
			
			if (  "N".equalsIgnoreCase(logonHelper.isCustomerSecCodeExempted(customer)) )
			{
				if ( ! ServiceConstants.UPD_CONTACT_DTL_SECURE_SERVICE.equalsIgnoreCase(mbSession.getSecureCodeVerifiedTranName()) )
				{
					Logger.error("Secure not verified. Session Sec Code Vale : "+ mbSession.getSecureCodeVerifiedTranName(), this.getClass());
					throw new ResourceException(ResourceException.SYSTEM_ERROR, "Secure not verified. Session Sec Code Vale : "+ mbSession.getSecureCodeVerifiedTranName());
				}
			}
//			IBankCommonData ibankCommonData = populateIBankCommonData(customer,user);
			IBankCommonData ibankCommonData=mbAppHelper.populateIBankCommonData(mbSession,httpServletRequest);
			digitalSecurityLogVO.setCommonLogData(mbAppHelper.getCommonLogData(ibankCommonData));
			digitalSecurityLogVO.setUserAgent(ibankCommonData.getUserAgent()); 

			ContactDetail newContactDetail=null;
			boolean isModified = false;
			boolean isModifiedAddress=false;
			boolean isModifiedEmail=false;
			
			ContactDetail contactDetail = contactDetailHelper.getContactDetail(req, customer);

			if ( customer.isGHSCustomer() )
			{
				if ( contactDetail.getResidentialAddress() != null && ! contactDetailHelper.isValidPostCode(contactDetail.getResidentialAddress(), customer))
				{
					BusinessException exp = new BusinessException(0, "Please enter a valid residential postcode for the selected state." );
					errorResp = MBAppUtils.createErrorResp( mbSession.getOrigin() , exp.getKey(), "Please enter a valid residential postcode for the selected state.", "ContactDetails", httpServletRequest);
					return errorResp;
				}

				if ( contactDetail.getMailingAddress() != null && ! contactDetailHelper.isValidPostCode(contactDetail.getMailingAddress(), customer))
				{
					BusinessException exp = new BusinessException(0, "Please enter a valid mailing postcode for the selected state." );
					errorResp = MBAppUtils.createErrorResp( mbSession.getOrigin() , exp.getKey(), "Please enter a valid mailing postcode for the selected state.", "ContactDetails", httpServletRequest);
					return errorResp;
				}			
			}
			
			//validation for email consent
			if(StringMethods.isEmptyString(contactDetail.getEmail()) && !contactDetail.isEmailConsent()){
			    String[] errorParams = { "Email", "email address" };
			    throw new BusinessException(BusinessException.EMAIL_ADDRESS_REQUIRED, errorParams);
			}

			ArrayList<Boolean> changeStatus=contactDetailHelper.isModified(customer.getContactDetail(), contactDetail, req.isSameAddress());
			if (changeStatus!=null && changeStatus.size()>0)
			{						
				isModified=changeStatus.get(0);
				isModifiedAddress=changeStatus.get(1);
				isModifiedEmail=changeStatus.get(2);
				
				Logger.info("Contact Details isModified :" +isModified , this.getClass());
				Logger.info("Contact Details isModifiedAddress :" +isModifiedAddress , this.getClass());
				Logger.info("Contact Details isModifiedEmail :" + isModifiedEmail, this.getClass());
				
				if(isModified)
				{
						Logger.info("Contact Details :" + contactDetail.getResidentialAddress() + "  *** " + contactDetail.getMailingAddress() + "  contactDetailsObj.getCustomerType() "+ contactDetail.getCustomerType(), this.getClass());
						mobileBankService.validateContactDetails(contactDetail, ibankCommonData);
						if((customer.getContactDetail().getMailingAddress() != null) && !(customer.getContactDetail().getMailingAddress()).equals(contactDetail.getMailingAddress())){
							contactDetail.setMailingAddrModified(true);
						}
						String desc = "";
						if (IBankParams.isEmailUpdationSwitchOn()) {
							MessageSearch messageSearch = mbSession.getSplashInfoMsg();
							if(messageSearch!=null && isEmailUpdationSplashMsg(messageSearch)){
								desc = desc+ " ;Email Updation Source = EmailSplash Page ";
								mbSession.removeSplashInfoMsg();
							}
						}
						if (mbSession.getSWBInfoMsg() != null && Boolean.TRUE.equals(mbSession.getSWBInfoMsg()) ) {
							desc = desc + ";" + ServiceConstants.SOURCE_SECURITY_WELLBEING;
							mbSession.removeSWBInfoMsg();
						}
						contactDetail.setGdwSourceDescription(desc);
						newContactDetail = mobileBankService.updateContactDetails(contactDetail, ibankCommonData, mbSession.getUcmModIndicator());
						pageInfoMsg = MBAppUtils.getMessage( mbSession.getOrigin() , BusinessException.CONTACT_DTL_UPDATED);
						isModified = true;
				}
				else
				{
					newContactDetail = customer.getContactDetail();
					isModified = false;
					pageInfoMsg = MBAppUtils.getMessage( mbSession.getOrigin() , BusinessException.IBANK_SECURE_CNTDTL_NOT_CHANGED);
				}				
			}			
			
			//17E4 : Change Statement Address changes : to populate eligible/not eligible list in response.
			
			if(null!=newContactDetail.getEligibleAccntList() && newContactDetail.getEligibleAccntList().size()>0)
			{
				Logger.info("17E4inside getEligiblelist :>>", this.getClass());
				accntDispList = populateFinalListsForDisplay(ibankCommonData, newContactDetail.getEligibleAccntList());
			}
			
			if(null!=newContactDetail.getNotEligibleAccntList() && newContactDetail.getNotEligibleAccntList().size()>0)
			{
				Logger.info("17E4inside getNotEligiblelist :>>", this.getClass());
				accntNotDispList = populateFinalListsForDisplay(ibankCommonData, newContactDetail.getNotEligibleAccntList());
			}
			
			//EmailConsent
			if(contactDetail.isEmailConsent()){
				MobileBankServiceImpl.logStatistics(ibankCommonData, Statistic.EMAIL_CONSENT, "No Email consent provided");
			}
			ContactDetail updatedContactDetail = contactDetailHelper.populateNewContactDetails(newContactDetail, customer);
								
			ContactDetailsResp contactDetailsResp = new ContactDetailsResp();
			if (updatedContactDetail.getEmail()!=null)
			contactDetailsResp.setEmail(updatedContactDetail.getEmail());
			contactDetailsResp.setModified(isModified);
			contactDetailsResp.setPageInfoMsg(pageInfoMsg);
			contactDetailsResp.setSameAddress(req.isSameAddress());
			
			if(isModifiedEmail && !isModifiedAddress)
			{
				Logger.info("inside setting in rsponse" , this.getClass());
				contactDetailsResp.setOnlyEmailUpdated(true);
			}
			
			// Getting the service station VO and Setting the service station response.
			long insertionPt = contactDetailHelper.getInsertionPointCode(ServicetationConstants.UPDATE_CONTACT_DETAILS_CONFIRMATION);
			ServiceStationVO servicestationVO=populateServiceMessage(insertionPt,ServiceStationImpl.CHANNEL_MOBILE, ibankCommonData);
			
			IMBResp serviceResponse = contactDetailHelper.populateContact(updatedContactDetail, contactDetailsResp, origin, servicestationVO,accntDispList,accntNotDispList);		
			if(null!=servicestationVO)
			{
				mbSession.setServiceStationMessage(servicestationVO.getServiceStationMsg());
			}
			
			Logger.info("updcontactdtls JSON Response :" + mapper.writeValueAsString(serviceResponse), this.getClass());
			RespHeader headerResp = populateResponseHeader(ServiceConstants.UPDCONTACTDTL_RESPONSE, mbSession);
			serviceResponse.setHeader(headerResp);
			mbSession.setSecureCodeVerifiedTranName(" ");
			
			digitalSecurityLogVO.setStatus(DigitalSecLogger.SUCCESS);
			LabelValueMap digitalSecMap = mbSession.getDigitalSecLoggerMap();
			String prevValues = digitalSecMap.get(DigitalSecLogger.PREV_CONTACT_DETAILS);
			digitalSecurityLogVO.setPrevValues(prevValues);
			digitalSecurityLogVO.setValues(contactDetail.toDigitalSecurityLog(false,get2FAExemptType(mbSession.getCustomer()),null,isCHSorCombinedCustomer(customer)));
			digitalSecurityLogger.log(digitalSecurityLogVO);
			mbSession.removeDigitalSecLoggerMap();
			//setting again as user can update again from same screen
			LabelValueMap digiSecMap = new LabelValueMap();
			digiSecMap.put(DigitalSecLogger.PREV_CONTACT_DETAILS,contactDetail.toDigitalSecurityLog(true,get2FAExemptType(mbSession.getCustomer()),null, isCHSorCombinedCustomer(customer)));
			mbSession.setDigitalSecLoggerMap(digiSecMap);
			
			return serviceResponse;
		} catch (BusinessException e)
		{
			digitalSecurityLogVO.setStatus(DigitalSecLogger.FAILURE);
			digitalSecurityLogger.log(digitalSecurityLogVO);
			
			IMBResp resp1 = null;
			Logger.error("Exception Inside updContactDtls() for Customer "+ e.getKey(), e, this.getClass());
			if (e.getValues() != null)
	    {
			  resp1 = MBAppUtils.createErrorResp(origin , e, e.getValues(), MBAppConstants.SMPL_UPDCONTACTDTLS_RESP_NAME, httpServletRequest);
			}
			else if ( e.getKey() == 9898) //  HOST ERROR TRANSACTION ROLLBACK
			{
				BusinessException exp = new BusinessException(BusinessException.GENERIC_ERROR);
				resp1 = MBAppUtils.createErrorResp(origin, exp, MBAppConstants.SMPL_UPDCONTACTDTLS_RESP_NAME, httpServletRequest);
			}
			else{
	    	resp1 = MBAppUtils.createErrorResp(origin, e, MBAppConstants.SMPL_UPDCONTACTDTLS_RESP_NAME, httpServletRequest);
	    }
			return resp1;
		} catch (Exception e)
		{
			Logger.error("Exception Inside updContactDtls() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			BusinessException exp = new BusinessException(BusinessException.GENERIC_ERROR);
			IMBResp resp1 = MBAppUtils.createErrorResp(origin, exp, MBAppConstants.SMPL_UPDCONTACTDTLS_RESP_NAME, httpServletRequest);
			return resp1;
		} finally
		{
			performanceLogger.endLog(logName);
			performanceLogger.endAllLogs();
		}
	}
	
	@RequestMapping(value="verify", method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public IMBResp VerifyCustDtls(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse,
			@RequestBody final ContactDetailsReq req)
	{
		Logger.debug("In VerifyCustDtls ( ContactDetailController )  for Customer " +  "  " + httpServletRequest.getContentType() + " "
				+ httpServletRequest.getRemoteAddr() + "  " + httpServletResponse.getCharacterEncoding() + httpServletResponse.getLocale() +
				" True IP >> " + httpServletRequest.getHeader(IBankParams.trueClientIP()), this.getClass());

		PerformanceLogger performanceLogger = new PerformanceLogger();
		fraudLogger = new FraudLogger();
		performanceLogger.startAllLogs();
		String logName = MBAppUtils.getLogName(httpServletRequest);
		performanceLogger.startLog(logName);
		ObjectMapper mapper = new ObjectMapper();
		MobileSession mbSession = null;
		try
		{
			mbSession = mbAppHelper.getMobileSession(httpServletRequest);		
			Logger.info("VerifyCustDtls JSON Request :" + mapper.writeValueAsString(req), this.getClass());
			validateRequestHeader( req.getHeader(), httpServletRequest );

			ErrorResp errorResp = validate(req, httpServletRequest);
			if (errorResp != null && errorResp.getErrors() != null && errorResp.getErrors().size() > 0)
			{
				return errorResp;
			}

			Customer customer=mbSession.getCustomer();			
			
			IBankCommonData ibankCommonData=mbAppHelper.populateIBankCommonData(mbSession,httpServletRequest);

			ContactDetail contactDetail =  mobileBankService.getContactDetails(ibankCommonData);
			boolean isEditable =  IBankParams.YES.equalsIgnoreCase(logonHelper.isCustomerSecCodeExempted(customer));			
						
			String modInd = mobileBankService.getUcmModIndicator(ibankCommonData);  
			if(modInd != null)
				mbSession.setUcmModIndicator(modInd);
			else if(CustomerTypes.TYPE_GHS.equalsIgnoreCase(contactDetail.getCustomerType()))				
				throw new BusinessException(BusinessException.ECE_SVC_ERROR); 
										
			IMBResp serviceResponse = contactDetailHelper.populateResponse(contactDetail, isEditable, mbSession.getOrigin());
			
			Logger.info("VerifyCustDtls JSON Response :" + mapper.writeValueAsString(serviceResponse), this.getClass());
			RespHeader headerResp = populateResponseHeader(req.getHeader().getServiceName(), mbSession );
			serviceResponse.setHeader(headerResp);
			return serviceResponse;
		} catch (BusinessException e)
		{
			IMBResp resp1 = null;
			Logger.error("Exception Inside VerifyCustDtls() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			BusinessException exp = new BusinessException(e.getKey());
			if(e.getKey() == BusinessException.ECE_SVC_ERROR)
			{
				OriginsVO allOriginVO  = IBankParams.getOrigin(IBankParams.BRAND_ORIGIN);			
				String[] values = {allOriginVO.getBpayPhone()};	
				resp1  = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, values, ServiceConstants.CUSTDTL_REVIEW_SERVICE, httpServletRequest);
			}else
				resp1 = MBAppUtils.createErrorResp(mbSession.getOrigin() , exp, ServiceConstants.CUSTDTL_REVIEW_SERVICE, httpServletRequest);
			
			return resp1;
		} catch (Exception e)
		{
			Logger.error("Exception Inside VerifyCustDtls() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			BusinessException exp = new BusinessException(BusinessException.SMPL_SYS_ERROR);
			IMBResp resp1 = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, ServiceConstants.CUSTDTL_REVIEW_SERVICE, httpServletRequest);
			return resp1;
		} finally
		{
			performanceLogger.endLog(logName);
			performanceLogger.endAllLogs();
		}
	}
	
	@RequestMapping(value="confirm", method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public IMBResp confirmCustDtls(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse,
			@RequestBody final ContactDetailsReq req)
	{
		Logger.debug("In confirmCustDtls ( ContactDetailController )  for Customer " +  "  " + httpServletRequest.getContentType() + " "
				+ httpServletRequest.getRemoteAddr() + "  " + httpServletResponse.getCharacterEncoding() + httpServletResponse.getLocale() +
				" True IP >> " + httpServletRequest.getHeader(IBankParams.trueClientIP()), this.getClass());

		PerformanceLogger performanceLogger = new PerformanceLogger();
		fraudLogger = new FraudLogger();
		performanceLogger.startAllLogs();
		String logName = MBAppUtils.getLogName(httpServletRequest);
		performanceLogger.startLog(logName);
		ObjectMapper mapper = new ObjectMapper();
		MobileSession mbSession = null;
		Boolean isUcmUpdated = null;
		try
		{
			mbSession = mbAppHelper.getMobileSession(httpServletRequest);		
			Logger.info("confirmCustDtls JSON Request :" + mapper.writeValueAsString(req), this.getClass());
			validateRequestHeader( req.getHeader(), httpServletRequest );

			ErrorResp errorResp = validate(req, httpServletRequest);
			if (errorResp != null && errorResp.getErrors() != null && errorResp.getErrors().size() > 0)
			{
				return errorResp;
			}			
			
			IBankCommonData ibankCommonData=mbAppHelper.populateIBankCommonData(mbSession,httpServletRequest);
				
			if(mbSession.getUcmModIndicator() == null)
				throw new BusinessException(BusinessException.SMPL_SYS_ERROR);
			else
				isUcmUpdated = mobileBankService.confirmUcmDetail(ibankCommonData, mbSession.getUcmModIndicator());										
				
			SuccessResp serviceResponse = new SuccessResp();
			RespHeader headerResp = populateResponseHeader(req.getHeader().getServiceName(), mbSession );
			serviceResponse.setHeader(headerResp);
			if(isUcmUpdated != null && isUcmUpdated)
				serviceResponse.setIsSuccess(true);
			else
				throw new BusinessException(BusinessException.ECE_SVC_ERROR);
			
			Logger.info("confirmCustDtls JSON Response :" + mapper.writeValueAsString(serviceResponse), this.getClass());
			
			return serviceResponse;
		} catch (BusinessException e)
		{
			IMBResp resp1 = null;
			Logger.error("Exception Inside confirmCustDtls() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			BusinessException exp = new BusinessException(e.getKey());
			if(e.getKey() == BusinessException.ECE_SVC_ERROR)
			{
				OriginsVO allOriginVO  = IBankParams.getOrigin(IBankParams.BRAND_ORIGIN);			
				String[] values = {allOriginVO.getBpayPhone()};	
				resp1  = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, values, ServiceConstants.CUSTDTL_CONFIRM_SERVICE, httpServletRequest);
			}else
				resp1 = MBAppUtils.createErrorResp(mbSession.getOrigin() , exp, ServiceConstants.CUSTDTL_CONFIRM_SERVICE, httpServletRequest);
			return resp1;
		} catch (Exception e)
		{
			Logger.error("Exception Inside confirmCustDtls() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			BusinessException exp = new BusinessException(BusinessException.SMPL_SYS_ERROR);
			IMBResp resp1 = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, ServiceConstants.CUSTDTL_CONFIRM_SERVICE, httpServletRequest);
			return resp1;
		} finally
		{
			performanceLogger.endLog(logName);
			performanceLogger.endAllLogs();
		}
	}
	
	@RequestMapping(value="updateCntDtlNew", method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public IMBResp updContactDtlsNew(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse,
			@RequestBody final ContactDetailsReq req)
	{
		Logger.debug("In updContactDtlsNew ( ContactDetailsController )  for Customer " +  "  " + httpServletRequest.getContentType() + " "
				+ httpServletRequest.getRemoteAddr() + "  " + httpServletResponse.getCharacterEncoding() + httpServletResponse.getLocale() +
				" True IP >> " + httpServletRequest.getHeader(IBankParams.trueClientIP()), this.getClass());
		PerformanceLogger performanceLogger = new PerformanceLogger();
		fraudLogger = new FraudLogger();
		performanceLogger.startAllLogs();
		String logName = MBAppUtils.getLogName(httpServletRequest);
		performanceLogger.startLog(logName);
		ObjectMapper mapper = new ObjectMapper();
		String pageInfoMsg = null;
		String origin = null;
		MobileSession mbSession = null;
		DigitalSecLogggerVO digitalSecurityLogVO =new DigitalSecLogggerVO();
		digitalSecurityLogVO.setTranName(DigitalSecLogger.UPDATE_CONTACT_DETAILS);
		ArrayList<AccountKeyInfoResp> accntDispList =null;
		ArrayList<AccountKeyInfoResp> accntNotDispList =null;
		String changeType = req.getChangeType() ;
		String qasHomeAddress = "";
		String qasHomeId="";
		String qasMailingAddress = "";
		String qasMailingId="";
		boolean callCapApiForHome = false;
		boolean callCapApiForMailing = false;
		try
		{
			mbSession = mbAppHelper.getMobileSession(httpServletRequest);
            validateRequestHeader( req.getHeader(), httpServletRequest );
			origin = mbSession.getOrigin();
//			Logger.info("updContactDtls JSON Request :" + mapper.writeValueAsString(req), this.getClass());
			ErrorResp errorResp = validate(req, httpServletRequest);
			if (errorResp != null && errorResp.getErrors() != null && errorResp.getErrors().size() > 0)
			{
				return errorResp;
			}
			
			//Remove SAFI vo for update phone and updated contact number saved in session
			mbSession.removeUpdatePhoneDetails();
			
			if(null != mbSession.getSafiRequestVO() && mbSession.getSafiRequestVO() instanceof SafiUpdatePhoneVO) {
				mbSession.removeSafiRequestVO();
			}
			
			Customer customer=mbSession.getCustomer();
			customer.getContactDetail().getCustTypeInd();
			
			if (  "N".equalsIgnoreCase(logonHelper.isCustomerSecCodeExempted(customer)) )
			{
				if ( ! ServiceConstants.UPD_CONTACT_DTL_SECURE_SERVICE.equalsIgnoreCase(mbSession.getSecureCodeVerifiedTranName()) )
				{
					Logger.error("Secure not verified. Session Sec Code Vale : "+ mbSession.getSecureCodeVerifiedTranName(), this.getClass());
					throw new ResourceException(ResourceException.SYSTEM_ERROR, "Secure not verified. Session Sec Code Vale : "+ mbSession.getSecureCodeVerifiedTranName());
				}
			}
//			IBankCommonData ibankCommonData = populateIBankCommonData(customer,user);
			IBankCommonData ibankCommonData=mbAppHelper.populateIBankCommonData(mbSession,httpServletRequest);
			digitalSecurityLogVO.setCommonLogData(mbAppHelper.getCommonLogData(ibankCommonData));
			digitalSecurityLogVO.setUserAgent(ibankCommonData.getUserAgent()); 

			ContactDetail newContactDetail=null;
			boolean isModified = false;
			boolean isModifiedAddress=false;
			boolean isModifiedEmail=false;
			boolean isMailingAddModified = false;
			boolean isHomeAddModified = false;
			boolean isCapApiResRec = false;
			boolean isCapApiMailRec = false;
			boolean isInvalidResAdd = false;
			boolean isInvalidMailAdd = false;
			ContactDetail contactDetail = contactDetailHelper.getContactDetailNew(req, customer);

			if ( customer.isGHSCustomer() )
			{
				if (req.getChangeType() != null && ("A").equalsIgnoreCase(req.getChangeType())) {
					
					AddressValidationReq addValReq = new AddressValidationReq();
					au.com.stgeorge.ibank.businessobject.model.commdtlsvaldatn.Customer cust = new au.com.stgeorge.ibank.businessobject.model.commdtlsvaldatn.Customer();
					CustomerId custId = new CustomerId();
					//custId.setId(ibankCommonData.getCustomer().getGcis());
					custId.setIdScheme(IdScheme.valueOf("CustomerInternalId"));
					//cust.setCustomerId(custId);
					CustomerTypes customerTypes_ = ibankCommonData.getCustomer().getCustomerTypes();
					if (customerTypes_.contains(CustomerTypes.TYPE_GHS)) {
						custId.setId(ibankCommonData.getCustomer().getGHSCISNumber());
					} else if (customerTypes_.contains(CustomerTypes.TYPE_CHS)) {
						custId.setId(ibankCommonData.getCustomer().getCHSCISNumber());
					} else if (customerTypes_.contains(CustomerTypes.TYPE_CHS_GHS)) {
						custId.setId(ibankCommonData.getCustomer().getGHSCISNumber());
					}
					cust.setCustomerId(custId);
					cust.setFirstName(ibankCommonData.getCustomer().getFirstName());
					cust.setLastName(ibankCommonData.getCustomer().getLastName());
					cust.setBrandSilo(BrandSilo.valueOf("SGBBSA"));
					addValReq.setCustomer(cust);
					addValReq.setCustomerRiskAssessmentIndicator(CustomerRiskAssessmentIndicator.valueOf("Unknown"));
					addValReq.setSessionID(ibankCommonData.getSessionId());
					RiskAssessRequest riskAssessmentPurpose = new RiskAssessRequest();
					riskAssessmentPurpose.setApplicantRoleType(ApplicantRoleType.valueOf("INDIVIDUAL"));
					riskAssessmentPurpose.setAppliedProductType(AppliedProductType.valueOf("SAVINGS"));
					addValReq.setRiskAssessmentPurpose(riskAssessmentPurpose);
					List<au.com.stgeorge.ibank.businessobject.model.commdtlsvaldatn.Address> addList =  new ArrayList<au.com.stgeorge.ibank.businessobject.model.commdtlsvaldatn.Address>();
					au.com.stgeorge.ibank.businessobject.model.commdtlsvaldatn.Address addRes =  new au.com.stgeorge.ibank.businessobject.model.commdtlsvaldatn.Address();
					au.com.stgeorge.ibank.businessobject.model.commdtlsvaldatn.Address addMailing =  new au.com.stgeorge.ibank.businessobject.model.commdtlsvaldatn.Address();

					if(req.getAddressTypeHome()!=null && ("QH").equalsIgnoreCase(req.getAddressTypeHome())) {
						//isHomeAddModified= true;
						//qasHomeAddress = req.getQasHomeAddress();
						qasHomeAddress = "";
						qasHomeId = req.getQasHomeSearchId();
						callCapApiForHome = true;
						addRes.setAddressLine1("");
						addRes.setExternalAddressReferenceId(qasHomeId);
						if(req.isSameAddress()) {
							addMailing.setAddressLine1("");
							addMailing.setExternalAddressReferenceId(qasHomeId);
						}
					
					}else if(req.getAddressTypeHome()!=null && ("HA").equalsIgnoreCase(req.getAddressTypeHome())) {
						//isHomeAddModified= true;
						//qasHomeAddress =  getAddressForContactDetailValidation(contactDetail,true,false);
						qasHomeId = "";
						callCapApiForHome = true;
						addRes.setExternalAddressReferenceId(qasHomeId);
						addRes.setAddressLine1(contactDetail.getResidentialAddress().getLine1());
						addRes.setAddressLine2(contactDetail.getResidentialAddress().getLine2());
						addRes.setAddressLine3(contactDetail.getResidentialAddress().getLine3());
						addRes.setCity(contactDetail.getResidentialAddress().getSuburb());
						addRes.setPostCode(contactDetail.getResidentialAddress().getPostZipcode());
						addRes.setState(contactDetail.getResidentialAddress().getState());
						if(req.isSameAddress()) {
							addMailing.setExternalAddressReferenceId(qasHomeId);
							addMailing.setAddressLine1(contactDetail.getResidentialAddress().getLine1());
							addMailing.setAddressLine2(contactDetail.getResidentialAddress().getLine2());
							addMailing.setAddressLine3(contactDetail.getResidentialAddress().getLine3());
							addMailing.setCity(contactDetail.getResidentialAddress().getSuburb());
							addMailing.setPostCode(contactDetail.getResidentialAddress().getPostZipcode());
							addMailing.setState(contactDetail.getResidentialAddress().getState());
						}
					}
					if(req.isSameAddress()) {
						if(callCapApiForHome) {
							qasMailingAddress = qasHomeAddress;
							qasMailingId =  qasHomeId;
							//isMailingAddModified = true;
							callCapApiForMailing = true;
						}
					}else {
						if(req.getAddressTypeMailing()!=null && ("QM").equalsIgnoreCase(req.getAddressTypeMailing())) {
							//isMailingAddModified = true;
							callCapApiForMailing = true;
							//qasMailingAddress =  req.getQasMailingAddress();
							qasMailingAddress ="";
							qasMailingId = req.getQasMailingSearchId();
							addMailing.setExternalAddressReferenceId(qasMailingId);
							addMailing.setAddressLine1("");
						}else if(req.getAddressTypeMailing()!=null &&  ("MA").equalsIgnoreCase(req.getAddressTypeMailing())) {
							qasMailingAddress = getAddressForContactDetailValidation(contactDetail, false, true);
							//isMailingAddModified =  true;
							callCapApiForMailing = true;
							qasMailingId ="";
							addMailing.setExternalAddressReferenceId(qasMailingId);
							addMailing.setAddressLine1(contactDetail.getMailingAddress().getLine1());
							addMailing.setAddressLine2(contactDetail.getMailingAddress().getLine2());
							addMailing.setAddressLine3(contactDetail.getMailingAddress().getLine3());
							addMailing.setCity(contactDetail.getMailingAddress().getSuburb());
							addMailing.setPostCode(contactDetail.getMailingAddress().getPostZipcode());
							addMailing.setState(contactDetail.getMailingAddress().getState());
						}
						
					}
					
					if(callCapApiForHome || callCapApiForMailing) {
						if(callCapApiForHome) {
							/*au.com.stgeorge.ibank.businessobject.model.commdtlsvaldatn.Address add =  new au.com.stgeorge.ibank.businessobject.model.commdtlsvaldatn.Address();
							add.setAddressLine1(qasHomeAddress);
							add.setCountryCode("AU");
							//add.setPostCode(contactDetail.getResidentialAddress().getPostZipcode());
							//add.setState(contactDetail.getResidentialAddress().getState());
							add.setExternalAddressReferenceId(qasHomeId);
							add.setUsageType(au.com.stgeorge.ibank.businessobject.model.commdtlsvaldatn.Address.UsageType.valueOf("RESIDENTIAL"));
							addList.add(add);*/
							addRes.setCountryCode("AU");
							addRes.setUsageType(au.com.stgeorge.ibank.businessobject.model.commdtlsvaldatn.Address.UsageType.valueOf("RESIDENTIAL"));
							addList.add(addRes);
						}
						if(callCapApiForMailing) {
							/*au.com.stgeorge.ibank.businessobject.model.commdtlsvaldatn.Address add =  new au.com.stgeorge.ibank.businessobject.model.commdtlsvaldatn.Address();
							add.setAddressLine1(qasMailingAddress);
							add.setCountryCode("AU");
							//add.setPostCode(contactDetail.getMailingAddress().getPostZipcode());
							//add.setState(contactDetail.getMailingAddress().getState());
							add.setExternalAddressReferenceId(qasMailingId);
							add.setUsageType(au.com.stgeorge.ibank.businessobject.model.commdtlsvaldatn.Address.UsageType.valueOf("MAILING"));
							addList.add(add);*/
							addMailing.setCountryCode("AU");
							addMailing.setUsageType(au.com.stgeorge.ibank.businessobject.model.commdtlsvaldatn.Address.UsageType.valueOf("MAILING"));
							addList.add(addMailing);
						}
						addValReq.setPhysicalAddresses(addList);
						AddressValidationResp addValRes = contactDetValService.validateCustomerContactDetails(
								ibankCommonData, UUID.randomUUID(), addValReq, "A");
						if(addValRes!=null) {
							ErrorPartialResult errRes = addValRes.getResult();
							if(errRes!=null) {
								List<AddressErrorResult> errList = errRes.getErrors();
								if(errList!=null && errList.size()>0) {
									for(AddressErrorResult adderr: errList) {
										if(adderr!=null) {
											Integer errCode = adderr.getCode();
											if(errCode!=null ) {
												if(errCode.intValue()==15006 || errCode.intValue()== 1008) {
													throw new BusinessException(BusinessException.UPDATE_ADD_POBOX);
												}else if(errCode.intValue()==15009 || errCode.intValue()==1012 || errCode.intValue()==1003) {
													throw new BusinessException(BusinessException.UPDATE_ADD_INVALID);
												}												
												/*else if (errCode.intValue()==15003 || errCode.intValue()== 15004 || errCode.intValue()==15008) {
													throw new BusinessException(BusinessException.UPDATE_ADD_INVALID);
												}*/
											}
										}
										
									}
								}
							}
						}						
						if(addValRes!=null && addValRes.getData()!=null) {
							AddressValidationSuccess addValSucc =  addValRes.getData();
							if(addValSucc!=null) {
								if(addValSucc.getRiskAssessment()!=null) {
									contactDetail.setRiskDecision(addValSucc.getRiskAssessment().getDecision());
									contactDetail.setRiskScore(addValSucc.getRiskAssessment().getScore());
									contactDetail.setRiskDecisionText(addValSucc.getRiskAssessment().getDecisionText());
								}
							}
							if(addValSucc!=null && addValSucc.getPhysicalAddresses()!=null && addValSucc.getPhysicalAddresses().size()>0) {
								for(AddressResult addResult: addValSucc.getPhysicalAddresses()) {
									if(addResult.getUsageType()!=null && ("MAILING").equalsIgnoreCase(addResult.getUsageType())) {
										NonStandardAddress nonStdAdd =  addResult.getNonStandard();
										if(callCapApiForMailing) {
											if(nonStdAdd!=null) {
												isCapApiMailRec = true;
												if(req.getAddressTypeMailing()!=null && ("QM").equalsIgnoreCase(req.getAddressTypeMailing())) {
													if(StringMethods.isEmptyString(nonStdAdd.getAddressLine1())) {
														isInvalidMailAdd = true;
													}else {
														if(nonStdAdd.getAddressLine1().length()>40) {
															isInvalidMailAdd = true;
														}
													}
													if(!StringMethods.isEmptyString(nonStdAdd.getAddressLine2())) {
														if(nonStdAdd.getAddressLine2().length()>40) {
															isInvalidMailAdd = true;
														}
													}
													if(!StringMethods.isEmptyString(nonStdAdd.getAddressLine3())) {
														if(nonStdAdd.getAddressLine3().length()>40) {
															isInvalidMailAdd = true;
														}
													}
													if(!StringMethods.isEmptyString(nonStdAdd.getCity())) {
														if(nonStdAdd.getCity().length()>25) {
															isInvalidMailAdd = true;
														}
													}
													
													if(!isInvalidMailAdd) {
													if(contactDetail.getMailingAddress()==null)
													{
														Address mailAdd =  new Address();
														contactDetail.setMailingAddress(mailAdd);
													}
													contactDetail.getMailingAddress().setLine1(StringMethods.isEmptyString(nonStdAdd.getAddressLine1())?"":nonStdAdd.getAddressLine1());
													contactDetail.getMailingAddress().setLine2(StringMethods.isEmptyString(nonStdAdd.getAddressLine2())?"":nonStdAdd.getAddressLine2());
													contactDetail.getMailingAddress().setLine3(StringMethods.isEmptyString(nonStdAdd.getAddressLine3())?"":nonStdAdd.getAddressLine3());
													contactDetail.getMailingAddress().setSuburb(StringMethods.isEmptyString(nonStdAdd.getCity())?"":nonStdAdd.getCity());
													contactDetail.getMailingAddress().setState(StringMethods.isEmptyString(nonStdAdd.getState())?"":nonStdAdd.getState());
													contactDetail.getMailingAddress().setPostZipcode(StringMethods.isEmptyString(nonStdAdd.getPostCode())?"":nonStdAdd.getPostCode());
													contactDetail.getMailingAddress().setCountryName("Australia");
													contactDetail.getMailingAddress().setCountry(" ");
													}
												}
											}else {
												//throw new BusinessException(BusinessException.UPDATE_ADD_CAPRES_NULL);
											}
										}										
									}
									if(addResult.getUsageType()!=null && ("RESIDENTIAL").equalsIgnoreCase(addResult.getUsageType())) {
										NonStandardAddress nonStdAdd =  addResult.getNonStandard();
										if(callCapApiForHome) {
											if(nonStdAdd!=null) {
												isCapApiResRec= true;
												if(req.getAddressTypeHome()!=null && ("QH").equalsIgnoreCase(req.getAddressTypeHome())) {
													if(StringMethods.isEmptyString(nonStdAdd.getAddressLine1())) {
														isInvalidResAdd = true;
													}else {
														if(nonStdAdd.getAddressLine1().length()>40) {
															isInvalidResAdd = true;
														}
													}
													if(!StringMethods.isEmptyString(nonStdAdd.getAddressLine2())) {
														if(nonStdAdd.getAddressLine2().length()>40) {
															isInvalidResAdd = true;
														}
													}
													if(!StringMethods.isEmptyString(nonStdAdd.getAddressLine3())) {
														if(nonStdAdd.getAddressLine3().length()>40) {
															isInvalidResAdd = true;
														}
													}
													if(!StringMethods.isEmptyString(nonStdAdd.getCity())) {
														if(nonStdAdd.getCity().length()>25) {
															isInvalidResAdd = true;
														}
													}
													if(!isInvalidResAdd) {
													if(contactDetail.getResidentialAddress()==null)
													{
														Address resiAdd =  new Address();
														contactDetail.setResidentialAddress(resiAdd);
													}
													contactDetail.getResidentialAddress().setLine1(StringMethods.isEmptyString(nonStdAdd.getAddressLine1())?"":nonStdAdd.getAddressLine1());
													contactDetail.getResidentialAddress().setLine2(StringMethods.isEmptyString(nonStdAdd.getAddressLine2())?"":nonStdAdd.getAddressLine2());
													contactDetail.getResidentialAddress().setLine3(StringMethods.isEmptyString(nonStdAdd.getAddressLine3())?"":nonStdAdd.getAddressLine3());
													contactDetail.getResidentialAddress().setSuburb(StringMethods.isEmptyString(nonStdAdd.getCity())?"":nonStdAdd.getCity());
													contactDetail.getResidentialAddress().setState(StringMethods.isEmptyString(nonStdAdd.getState())?"":nonStdAdd.getState());
													contactDetail.getResidentialAddress().setPostZipcode(StringMethods.isEmptyString(nonStdAdd.getPostCode())?"":nonStdAdd.getPostCode());
													contactDetail.getResidentialAddress().setCountryName("Australia");
													contactDetail.getResidentialAddress().setCountry(" ");
													}
												}
											}else {
												//throw new BusinessException(BusinessException.UPDATE_ADD_CAPRES_NULL);
											}
										}										
									}
								}
								
							}else {
								//throw new BusinessException(BusinessException.UPDATE_ADD_CAPRES_NULL);
							}
						}else {
							//throw new BusinessException(BusinessException.UPDATE_ADD_CAPRES_NULL);
						}
						if(isInvalidResAdd && isInvalidMailAdd) {
							throw new BusinessException(BusinessException.UPDATE_ADD_EXCEED_LENGTH_RESMAIL);
						}else if(isInvalidResAdd) {
							throw new BusinessException(BusinessException.UPDATE_ADD_EXCEED_LENGTH_RES);
						}else if(isInvalidMailAdd) {
							throw new BusinessException(BusinessException.UPDATE_ADD_EXCEED_LENGTH_MAIL);
						}

						if(callCapApiForHome) {
							if(!isCapApiResRec) {
								if(req.getAddressTypeHome()!=null && ("QH").equalsIgnoreCase(req.getAddressTypeHome())) {
									throw new BusinessException(BusinessException.UPDATE_ADD_CAPRES_NULL);
								}
							}
						}
						if(callCapApiForMailing) {
							if(!isCapApiMailRec) {
								if(req.getAddressTypeMailing()!=null && ("QM").equalsIgnoreCase(req.getAddressTypeMailing())) {
									throw new BusinessException(BusinessException.UPDATE_ADD_CAPRES_NULL);
								}
							}
						}
							
					}
					
					if ( contactDetail.getResidentialAddress() != null && ! contactDetailHelper.isValidPostCode(contactDetail.getResidentialAddress(), customer))
					{
						BusinessException exp = new BusinessException(0, "Please enter a valid residential postcode for the selected state." );
						errorResp = MBAppUtils.createErrorResp( mbSession.getOrigin() , exp.getKey(), "Please enter a valid residential postcode for the selected state.", "ContactDetails", httpServletRequest);
						return errorResp;
					}
	
					if ( contactDetail.getMailingAddress() != null && ! contactDetailHelper.isValidPostCode(contactDetail.getMailingAddress(), customer))
					{
						BusinessException exp = new BusinessException(0, "Please enter a valid mailing postcode for the selected state." );
						errorResp = MBAppUtils.createErrorResp( mbSession.getOrigin() , exp.getKey(), "Please enter a valid mailing postcode for the selected state.", "ContactDetails", httpServletRequest);
						return errorResp;
					}	
				}
			}
			
			//validation for email consent
			/*if(StringMethods.isEmptyString(contactDetail.getEmail()) && !contactDetail.isEmailConsent()){
			    String[] errorParams = { "Email", "email address" };
			    throw new BusinessException(BusinessException.EMAIL_ADDRESS_REQUIRED, errorParams);
			}*/

			ArrayList<Boolean> changeStatus=contactDetailHelper.isModifiedNew(customer.getContactDetail(), contactDetail, req.isSameAddress());
			if (changeStatus!=null && changeStatus.size()>0)
			{						
				isModified=changeStatus.get(0);
				isModifiedAddress=changeStatus.get(1);
				isModifiedEmail=changeStatus.get(2);
				
				Logger.info("Contact Details isModified :" +isModified , this.getClass());
				Logger.info("Contact Details isModifiedAddress :" +isModifiedAddress , this.getClass());
				Logger.info("Contact Details isModifiedEmail :" + isModifiedEmail, this.getClass());
				
				if(isModified)
				{
						Logger.info("Contact Details :" + contactDetail.getResidentialAddress() + "  *** " + contactDetail.getMailingAddress() + "  contactDetailsObj.getCustomerType() "+ contactDetail.getCustomerType(), this.getClass());
						mobileBankService.validateContactDetails(contactDetail, ibankCommonData);
						/*if((customer.getContactDetail().getMailingAddress() != null) && !(customer.getContactDetail().getMailingAddress()).equals(contactDetail.getMailingAddress())){
							contactDetail.setMailingAddrModified(true);
						}*/
						if((customer.getContactDetail().getMailingAddress() != null) && !(customer.getContactDetail().getMailingAddress().toString()).equalsIgnoreCase(contactDetail.getMailingAddress().toString())){
							contactDetail.setMailingAddrModified(true);
						}else {
							contactDetail.setMailingAddress(customer.getContactDetail().getMailingAddress());
						}
						
						if((customer.getContactDetail().getResidentialAddress() != null) && (customer.getContactDetail().getResidentialAddress().toString()).equalsIgnoreCase(contactDetail.getResidentialAddress().toString())){
							contactDetail.setResidentialAddress(customer.getContactDetail().getResidentialAddress());
						}
						
						String desc = "";
						if (IBankParams.isEmailUpdationSwitchOn()) {
							MessageSearch messageSearch = mbSession.getSplashInfoMsg();
							if(messageSearch!=null && isEmailUpdationSplashMsg(messageSearch)){
								desc = desc+ " ;Email Updation Source = EmailSplash Page ";
								mbSession.removeSplashInfoMsg();
							}
						}
						if (mbSession.getSWBInfoMsg() != null && Boolean.TRUE.equals(mbSession.getSWBInfoMsg()) ) {
							desc = desc + ";" + ServiceConstants.SOURCE_SECURITY_WELLBEING;
							mbSession.removeSWBInfoMsg();
			 			}
						contactDetail.setGdwSourceDescription(desc);
											
						if(changeType!=null && ("E").equalsIgnoreCase(changeType)) {
							if(IBankParams.isContactDetCapApiValSwitchOn()) {
								AddressValidationSuccess capApiValSuc = contactDetValService.validateContactDetailsCapApi(ibankCommonData, contactDetail, changeType);
								//contactDetail.setRiskProfile(capApiValSuc.getRiskAssessment());
								if(capApiValSuc!=null) {
									if(capApiValSuc.getRiskAssessment()!=null) {
										contactDetail.setRiskDecision(capApiValSuc.getRiskAssessment().getDecision());
										contactDetail.setRiskScore(capApiValSuc.getRiskAssessment().getScore());
		                                contactDetail.setRiskDecisionText(capApiValSuc.getRiskAssessment().getDecisionText());
		                            }
								}
							}
						} 
						contactDetail.setChangeType(req.getChangeType());
						newContactDetail = mobileBankService.updateContactDetails(contactDetail, ibankCommonData, mbSession.getUcmModIndicator());
						pageInfoMsg = MBAppUtils.getMessage( mbSession.getOrigin() , BusinessException.CONTACT_DTL_UPDATED);
						isModified = true;
				}
				else
				{
					newContactDetail = customer.getContactDetail();
					isModified = false;
					pageInfoMsg = MBAppUtils.getMessage( mbSession.getOrigin() , BusinessException.IBANK_SECURE_CNTDTL_NOT_CHANGED);
				}				
			}			
			
			//17E4 : Change Statement Address changes : to populate eligible/not eligible list in response.
			
			if(null!=newContactDetail.getEligibleAccntList() && newContactDetail.getEligibleAccntList().size()>0)
			{
				Logger.info("17E4inside getEligiblelist :>>", this.getClass());
				accntDispList = populateFinalListsForDisplay(ibankCommonData, newContactDetail.getEligibleAccntList());
			}
			
			if(null!=newContactDetail.getNotEligibleAccntList() && newContactDetail.getNotEligibleAccntList().size()>0)
			{
				Logger.info("17E4inside getNotEligiblelist :>>", this.getClass());
				accntNotDispList = populateFinalListsForDisplay(ibankCommonData, newContactDetail.getNotEligibleAccntList());
			}
			
			//EmailConsent
			if(contactDetail.isEmailConsent()){
				MobileBankServiceImpl.logStatistics(ibankCommonData, Statistic.EMAIL_CONSENT, "No Email consent provided");
			}
			ContactDetail updatedContactDetail = contactDetailHelper.populateNewContactDetails(newContactDetail, customer);
								
			ContactDetailsResp contactDetailsResp = new ContactDetailsResp();
			if (updatedContactDetail.getEmail()!=null)
			contactDetailsResp.setEmail(updatedContactDetail.getEmail());
			contactDetailsResp.setModified(isModified);
			contactDetailsResp.setPageInfoMsg(pageInfoMsg);
			contactDetailsResp.setSameAddress(req.isSameAddress());
			
			if(isModifiedEmail && !isModifiedAddress)
			{
				Logger.info("inside setting in rsponse" , this.getClass());
				contactDetailsResp.setOnlyEmailUpdated(true);
			}
			
			// Getting the service station VO and Setting the service station response.
			long insertionPt = contactDetailHelper.getInsertionPointCode(ServicetationConstants.UPDATE_CONTACT_DETAILS_CONFIRMATION);
			ServiceStationVO servicestationVO=populateServiceMessage(insertionPt,ServiceStationImpl.CHANNEL_MOBILE, ibankCommonData);
			
			IMBResp serviceResponse = contactDetailHelper.populateContact(updatedContactDetail, contactDetailsResp, origin, servicestationVO,accntDispList,accntNotDispList);		
			if(null!=servicestationVO)
			{
				mbSession.setServiceStationMessage(servicestationVO.getServiceStationMsg());
			}
			
			Logger.info("updcontactdtls JSON Response :" + mapper.writeValueAsString(serviceResponse), this.getClass());
			RespHeader headerResp = populateResponseHeader(ServiceConstants.UPDCONTACTDTL_RESPONSE, mbSession);
			serviceResponse.setHeader(headerResp);
			mbSession.setSecureCodeVerifiedTranName(" ");
			
			digitalSecurityLogVO.setStatus(DigitalSecLogger.SUCCESS);
			LabelValueMap digitalSecMap = mbSession.getDigitalSecLoggerMap();
			String prevValues = digitalSecMap.get(DigitalSecLogger.PREV_CONTACT_DETAILS);
			digitalSecurityLogVO.setPrevValues(prevValues);
			digitalSecurityLogVO.setValues(contactDetail.toDigitalSecurityLog(false,get2FAExemptType(mbSession.getCustomer()),null,isCHSorCombinedCustomer(customer)));
			
			digitalSecurityLogger.log(digitalSecurityLogVO);
			mbSession.removeDigitalSecLoggerMap();
			//setting again as user can update again from same screen
			LabelValueMap digiSecMap = new LabelValueMap();
			digiSecMap.put(DigitalSecLogger.PREV_CONTACT_DETAILS,contactDetail.toDigitalSecurityLog(true,get2FAExemptType(mbSession.getCustomer()),null, isCHSorCombinedCustomer(customer)));
			mbSession.setDigitalSecLoggerMap(digiSecMap);
			
			return serviceResponse;
		} catch (BusinessException e)
		{
			digitalSecurityLogVO.setStatus(DigitalSecLogger.FAILURE);
			digitalSecurityLogger.log(digitalSecurityLogVO);
			
			IMBResp resp1 = null;
			Logger.error("Exception Inside updContactDtls() for Customer "+ e.getKey(), e, this.getClass());
			if (e.getValues() != null)
			{
			  resp1 = MBAppUtils.createErrorResp(origin , e, e.getValues(), MBAppConstants.SMPL_UPDCONTACTDTLS_RESP_NAME, httpServletRequest);
			}
			else if ( e.getKey() == 9898 ) {
				BusinessException exp = new BusinessException(BusinessException.GENERIC_ERROR);
				resp1 = MBAppUtils.createErrorResp(origin, exp, MBAppConstants.SMPL_UPDCONTACTDTLS_RESP_NAME, httpServletRequest);
			}else if( e.getKey()== BusinessException.UPDATE_EMAIL_BLANK ||e.getKey()==BusinessException.UPDATE_EMAIL_DISABLE
					|| e.getKey() == BusinessException.UPDATE_EMAIL_DISPOSABLE || e.getKey()==BusinessException.UPDATE_EMAIL_ILLIGITIMATE 
					|| e.getKey() == BusinessException.UPDATE_EMAIL_LOCALPARTSPAM || e.getKey() == BusinessException.UPDATE_EMAIL_NOTEXIST
					|| e.getKey() == BusinessException.UPDATE_EMAIL_ROLE_ACT || e.getKey() == BusinessException.UPDATE_EMAIL_SYNTAX_FAILURE 
					|| e.getKey() == BusinessException.UPDATE_EMAIL_SYNTAX_FAILURE
					|| e.getKey() == BusinessException.UPDATE_ADD_CAPRES_NULL
					|| e.getKey() == BusinessException.UPDATE_ADD_POBOX
					|| e.getKey() == BusinessException.UPDATE_ADD_INVALID
					|| e.getKey() == BusinessException.UPDATE_EMAIL_UNREACHABLE
					|| e.getKey() == BusinessException.UPDATE_ADD_EXCEED_LENGTH_RES
					|| e.getKey() == BusinessException.UPDATE_ADD_EXCEED_LENGTH_MAIL
					|| e.getKey() == BusinessException.UPDATE_ADD_EXCEED_LENGTH_RESMAIL) //  HOST ERROR TRANSACTION ROLLBACK
			{
			   BusinessException exp = new BusinessException(e.getKey());
			   resp1 = MBAppUtils.createErrorResp(origin, exp, MBAppConstants.SMPL_UPDCONTACTDTLS_RESP_NAME, httpServletRequest);
			}else{
				resp1 = MBAppUtils.createErrorResp(origin, e, MBAppConstants.SMPL_UPDCONTACTDTLS_RESP_NAME, httpServletRequest);
			}
			
			return resp1;
		} catch (Exception e)
		{
			Logger.error("Exception Inside updContactDtls() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			BusinessException exp = new BusinessException(BusinessException.GENERIC_ERROR);
			IMBResp resp1 = MBAppUtils.createErrorResp(origin, exp, MBAppConstants.SMPL_UPDCONTACTDTLS_RESP_NAME, httpServletRequest);
			return resp1;
		} finally
		{
			performanceLogger.endLog(logName);
			performanceLogger.endAllLogs();
		}
	}
	

/*	public IBankCommonData populateIBankCommonData(Customer customer,User user){
			IBankCommonData commonData=new IBankCommonData();
			commonData.setUser(user);
			commonData.setOrigin((String)user.getAttribute(IBankParams.USEROBJ_BRAND));
			commonData.setCustomer(customer);
			return commonData;
		}  */

	public ErrorResp validate(IMBReq serviceRequest, HttpServletRequest httpServletRequest)
	{
		return mbAppValidator.validate(serviceRequest, httpServletRequest);
	}
	public void validateRequestHeader(ReqHeader header, HttpServletRequest request) throws ResourceException
	{
		mbAppValidator.validateRequestHeader(header,  request);
	}
	public RespHeader populateResponseHeader(String serviceName)
	{
		return mbAppHelper.populateResponseHeader(serviceName);
	}

	public RespHeader populateResponseHeader(String serviceName, MobileSession mobSession )
	{
		return mbAppHelper.populateResponseHeader(serviceName, mobSession);
	}
	
	
	@Autowired
	private MBAppValidator mbAppValidator;

	
	private String get2FAExemptType(Customer customer) throws BusinessException {
		if( IBankSecureService.isGlobalByPass() ){
			return DigitalSecLogger.BYPASS;
		} else if (IBankSecureService.isCustomerExempt(customer.getIBankSecureDetails())){
			return DigitalSecLogger.EXEMPTED;
		} else {
			return DigitalSecLogger.BLANK_CHAR;
		}
	}
	
	
	private boolean isCHSorCombinedCustomer(Customer customer){
		return customer.isCHSCustomer() || customer.isCHSGHSCustomer();
	}
	
	private ServiceStationVO populateServiceMessage(long insertionPoint,String channel, IBankCommonData commonData)
	{
		ServiceStationVO serviceStationAdminVo=null;
		try
		{
		 serviceStationAdminVo= serviceStationService.getServiceMessage(insertionPoint, ServiceStationImpl.CHANNEL_MOBILE, commonData);			
		}
		 catch(BusinessException ex){
			Logger.error("An error occurred while getting service station message for mobile accoutn details", ex, this.getClass());
		}
		return serviceStationAdminVo;
	}
	
	/*
	 * 17E4 CSA: To populate the eligible and not eligible account lists
	 */
	private ArrayList<AccountKeyInfoResp> populateFinalListsForDisplay(IBankCommonData commonData,List<String> accntList){
		ArrayList<AccountKeyInfoResp> accntDispList=new ArrayList<AccountKeyInfoResp>();
		List<Account> custAccountList = commonData.getCustomer().getAccounts();
		String formattedProfileAccountNo = null;
		if(null!=accntList && accntList.size() > 0){
			for(Account a : custAccountList){
				if(null!= a.getAccountId().getBranchKey())
					formattedProfileAccountNo = a.getAccountId().getBranchKey()+a.getAccountId().getAccountKey();
				else
					formattedProfileAccountNo = a.getAccountId().getAccountKey();

				for(String filteredAccnt : accntList){	
					if(filteredAccnt.equalsIgnoreCase(formattedProfileAccountNo)){
						AccountKeyInfoResp ap = new AccountKeyInfoResp();
						ap.setAccountName(a.getAlias());
						ap.setAccountNum(a.getAccountId().getFormattedAccountNumber());
						if(StringMethods.isValidString(a.getAccountId().getFormattedBSBNumber())){
						  ap.setFormattedBsb((a.getAccountId().getFormattedBSBNumber()));
						}
						else if(a.getAccountId().getFormattedBSBNumber().equals("")){
							ap.setFormattedBsb("");
						}
						else
						{
							ap.setFormattedBsb("");
						}
						accntDispList.add(ap);
						break;
					}
				}
			
			}
		}
		return accntDispList;
	}
	
	
	@PostMapping(path="enterPhoneUpdate", headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public IMBResp enterPhoneUpdate(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse,
			@RequestBody final EmptyReq req)
	{
		PerformanceLogger performanceLogger = new PerformanceLogger();
		fraudLogger = new FraudLogger();
		performanceLogger.startAllLogs();
		String logName = MBAppUtils.getLogName(httpServletRequest);
		performanceLogger.startLog(logName);
		ObjectMapper mapper = new ObjectMapper();
		MobileSession mbSession = null;
		SingleBooleanFlagResp serviceResponse = new SingleBooleanFlagResp();
		//default show the payId banner
		serviceResponse.setFlag(true);
		
		try
		{
			mbSession = mbAppHelper.getMobileSession(httpServletRequest);
			Logger.info("enterPhoneUpdate JSON Request :" + mapper.writeValueAsString(req), this.getClass());
			validateRequestHeader( req.getHeader(), httpServletRequest );

			ErrorResp errorResp = validate(req, httpServletRequest);
			if (errorResp != null && errorResp.getErrors() != null && errorResp.getErrors().size() > 0)
			{
				return errorResp;
			}
			
			RespHeader headerResp = populateResponseHeader(req.getHeader().getServiceName(), mbSession );
			serviceResponse.setHeader(headerResp);
			
			IBankCommonData ibankCommonData=mbAppHelper.populateIBankCommonData(mbSession,httpServletRequest);
			ManagePayIdDetails managePayIdDetails = managePayIdService.checkPayIDRegistration(ibankCommonData);
			Logger.debug("PayId Mobile number:" +  managePayIdDetails.getPayIdMobileNumber(), getClass());
			Logger.debug("PayId Status:" +  managePayIdDetails.getPayIdStatusCode() + "|" + managePayIdDetails.getPayIdStatus(), getClass());
			
			if(StringMethods.isEmptyString(managePayIdDetails.getPayIdMobileNumber())){
				serviceResponse.setFlag(false);
			}
			
			return serviceResponse;
		} catch (Exception e)
		{	
			Logger.warn("Exception in enterPhoneUpdate",e, getClass());
			return serviceResponse;
		} finally
		{
			performanceLogger.endLog(logName);
			performanceLogger.endAllLogs();
		}
	}
	
	
	@PostMapping(path="updatePhoneNumber", headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public IMBResp updatePhoneNumber(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse,
			@RequestBody final PhoneDetailReq req)
	{
		PerformanceLogger performanceLogger = new PerformanceLogger();
		fraudLogger = new FraudLogger();
		performanceLogger.startAllLogs();
		String logName = MBAppUtils.getLogName(httpServletRequest);
		performanceLogger.startLog(logName);
		String origin = null;
		MobileSession mbSession = null;
				
		DigitalSecLogggerVO digitalSecurityLogVO =new DigitalSecLogggerVO();
		digitalSecurityLogVO.setTranName(DigitalSecLogger.UPDATE_PHONE_NUMBER);
		
		try
		{
			mbSession = mbAppHelper.getMobileSession(httpServletRequest);
            validateRequestHeader( req.getHeader(), httpServletRequest );
			origin = mbSession.getOrigin();

			ErrorResp errorResp = validate(req, httpServletRequest);
			if (errorResp != null && errorResp.getErrors() != null && errorResp.getErrors().size() > 0)
			{
				return errorResp;
			}
			Customer customer=mbSession.getCustomer();
						
			IBankCommonData ibankCommonData=mbAppHelper.populateIBankCommonData(mbSession,httpServletRequest);
			ContactDetail changedContactDetails = contactDetailHelper.getPhoneDetails(req, customer);
			mbSession.setUpdatePhoneDetails(changedContactDetails);
			
			ContactDetailsResp contactDetailsResp = new ContactDetailsResp();
			
			RespHeader headerResp = populateResponseHeader(req.getHeader().getServiceName(), mbSession );
			contactDetailsResp.setHeader(headerResp);
			
			boolean isSafiUpdPhoneSwitchOn = IBankParams.isSwitchOn(IBankParams.DEFAULT_ORIGIN, IBankParams.SAFI_UPDATE_PHONE_SWITCH);
			Logger.debug("SAFI : updatePhoneNumber:: Safi update phone Switch Value: "+isSafiUpdPhoneSwitchOn, this.getClass());
			boolean isSafiServiceAvailable = false;
			
			if(isSafiUpdPhoneSwitchOn){
				isSafiServiceAvailable = HeartBeat.isApplicationAvailable(HeartBeat.SAFI2_SERVICE_APPLICATION);
				Logger.info("SAFI : updatePhoneNumber:: SAFI2_SERVICE_APPLICATION STATUS: "+isSafiServiceAvailable, this.getClass());
			}
			
			if(isSafiServiceAvailable){
				
				boolean	isThrottleAllowed = memoryThrottlingService.processThrottling(IBankParams.THROTTLE_CAT_UPD_PHONE, customer.getGcis(), mbSession.getSessionID());
										
				if(isThrottleAllowed){
					ContactDetailsResp response = (ContactDetailsResp) callSafiAnalyse(httpServletRequest, httpServletResponse, mbSession, ibankCommonData, req, contactDetailsResp);
					
					if(response.isSecureCodeReqd())
						return response;
				}
			} else {				
				contactDetailsResp.setSecureCodeReqd(true);
				return contactDetailsResp;
			}
			
			return updateCustPhoneNumber(changedContactDetails, ibankCommonData, mbSession, contactDetailsResp, httpServletRequest, httpServletResponse);
			
		} catch (BusinessException e)
		{
			digitalSecurityLogVO.setStatus(DigitalSecLogger.FAILURE);
			digitalSecurityLogger.log(digitalSecurityLogVO);
			
			IMBResp resp1 = null;
			Logger.error("Exception Inside updContactDtls() for Customer "+ e.getKey(), e, this.getClass());
			
			if (e.getValues() != null) {
				resp1 = MBAppUtils.createErrorResp(origin , e, e.getValues(), MBAppConstants.SMPL_UPDCONTACTDTLS_RESP_NAME, httpServletRequest);
			} else if ( e.getKey() == 9898) { //  HOST ERROR TRANSACTION ROLLBACK 
				BusinessException exp = new BusinessException(BusinessException.GENERIC_ERROR);
				resp1 = MBAppUtils.createErrorResp(origin, exp, MBAppConstants.SMPL_UPDCONTACTDTLS_RESP_NAME, httpServletRequest);
			} else{
				resp1 = MBAppUtils.createErrorResp(origin, e, MBAppConstants.SMPL_UPDCONTACTDTLS_RESP_NAME, httpServletRequest);
			}
			return resp1;
			
		} catch (Exception e)
		{
			digitalSecurityLogVO.setStatus(DigitalSecLogger.FAILURE);
			digitalSecurityLogger.log(digitalSecurityLogVO);
			
			Logger.error("Exception Inside updContactDtls() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			BusinessException exp = new BusinessException(BusinessException.GENERIC_ERROR);
			IMBResp resp1 = MBAppUtils.createErrorResp(origin, exp, MBAppConstants.SMPL_UPDCONTACTDTLS_RESP_NAME, httpServletRequest);
			return resp1;
		} finally
		{
			performanceLogger.endLog(logName);
			performanceLogger.endAllLogs();
		}
	}

	/**
	 * 20E2 - Phone Update - Populate the Device risk details from SAFI response
	 * 
	 * @param mbSession
	 * @param commonData
	 * @return DeviceRisk
	 */
	private DeviceRisk populateDeviceRiskDetails(MobileSession mbSession, IBankCommonData commonData) {
		
		SafiUpdatePhoneVO safiUpdatePhoneVO  = null;
		
		if(null != mbSession.getSafiRequestVO() && mbSession.getSafiRequestVO() instanceof SafiUpdatePhoneVO) 			
			 safiUpdatePhoneVO  = (SafiUpdatePhoneVO) mbSession.getSafiRequestVO();
		
		DeviceRisk deviceRiskDetails = new DeviceRisk();
		
		if(null != safiUpdatePhoneVO) {
			if(null != safiUpdatePhoneVO.getSafiRespVO()) {
				if(null != safiUpdatePhoneVO.getSafiRespVO().getSafiAction())
					deviceRiskDetails.setAction(safiUpdatePhoneVO.getSafiRespVO().getSafiAction());
			
				if(null != safiUpdatePhoneVO.getSafiRespVO().getSafiRiskScore())
					deviceRiskDetails.setScore(String.valueOf(safiUpdatePhoneVO.getSafiRespVO().getSafiRiskScore()));
				
				if(null != safiUpdatePhoneVO.getSafiRespVO().getSafiRuleName())
					deviceRiskDetails.setRuleName(safiUpdatePhoneVO.getSafiRespVO().getSafiRuleName());
			}
		}
		
		deviceRiskDetails.setDeviceId(mbSession.getDeviceID());
        deviceRiskDetails.setIpAddress(commonData.getIpAddress());
                
		return deviceRiskDetails;
	}

	/**
	 * 20E2 - Added for Update Phone SAFI analyze call
	 * 
	 * @param httpServletRequest
	 * @param httpServletResponse
	 * @param mobileSession
	 * @param commonData
	 * @param request
	 * @param response
	 * @return IMBResp
	 * @throws ResourceException
	 * @throws BusinessException
	 */
	private IMBResp callSafiAnalyse(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, MobileSession mobileSession, IBankCommonData commonData,
			PhoneDetailReq request, ContactDetailsResp response) throws ResourceException, BusinessException {
   		
		SafiUpdatePhoneVO safiVO = new SafiUpdatePhoneVO(); 
		
		try {
			safiVO = contactDetailHelper.populateSafiVO(httpServletRequest, mobileSession, commonData, request);
			
			mobileBankService.safiAnalyzeForUpdatePhone(commonData, safiVO);
			
			if(null != safiVO && null != safiVO.getSafiRespVO() && null != safiVO.getSafiRespVO().getSafiAction()) {
				if(SafiConstants.SAFI_ACTION_ALLOW.equalsIgnoreCase(safiVO.getSafiRespVO().getSafiAction()) || SafiConstants.SAFI_ACTION_REVIEW.equalsIgnoreCase(safiVO.getSafiRespVO().getSafiAction()))
					response.setSecureCodeReqd(false);
			}
			
			} catch(BusinessException be){
				//Only in case of Challenge - set setSecureCodeReqd to TRUE
				//Otherwise throw exception
				if (be.getKey() == BusinessException.IBANK_SECURE_REQUIRED) {
					response.setSecureCodeReqd(true);
				} else{
					throw be;
				}
			}finally{
				mobileSession.setSafiRequestVO(safiVO);
				contactDetailHelper.handleSafiResponseinCookies(httpServletRequest ,httpServletResponse, safiVO.getSafiRespVO());
			}
		
	   		return response;
   	}	
	

	/**
	 * 20E2 - Added for Update Phone SAFI notify call
	 * 
	 * @param httpServletRequest
	 * @param httpServletResponse
	 * @param status2FA
	 */
	private void callSafiNotify(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, boolean status2FA, IBankCommonData ibankCommonData) {
		MobileSession mobileSession = new MobileSessionImpl();
		
		try{
		mobileSession.getSessionContext(httpServletRequest);
				
		if(mobileSession.getSafiRequestVO() != null && mobileSession.getSafiRequestVO() instanceof SafiUpdatePhoneVO) {
			SafiUpdatePhoneVO safiVO = SafiWebHelper.populateSafiVOForUpdatePhoneNotify(httpServletRequest, mobileSession, ibankCommonData,  status2FA);
			
			SafiRespVO safiRespVO = safi2Service.notifySafiForUpdatePhone(ibankCommonData, safiVO);
			
			contactDetailHelper.handleSafiResponseinCookies(httpServletRequest, httpServletResponse, safiRespVO);
		}
		}catch(BusinessException be){
			Logger.warn("Exception in callSafiNotify: ", be , getClass());
		}finally{
			mobileSession.removeSafiRequestVO();
		}
	}
	
	/**
	 * 20E2 - This method will update the phone numbers in Compass and also call PRM WDP API
	 * 
	 * @param changedContactDetails
	 * @param ibankCommonData
	 * @param mbSession
	 * @param contactDetailsResp
	 * @return IMBResp
	 * @throws Exception 
	 * @throws ResourceException
	 * @throws BusinessException
	 */
	private IMBResp updateCustPhoneNumber(ContactDetail changedContactDetails, IBankCommonData ibankCommonData, MobileSession mbSession, ContactDetailsResp contactDetailsResp,
			HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse) throws Exception {
		
		Logger.debug("updateCustPhoneNumber START for - "+ibankCommonData.getCustomer().getGcis(), this.getClass());
		
		String devicePrintForLogger = null;
		ObjectMapper mapper = new ObjectMapper();
		
		boolean isMobileApp = ((logonHelper.loadCordova(httpServletRequest)) == -1) ? false:true;
		if(isMobileApp){
			String sdkDevicePrint = mbSession.getSafiLogonInfo()!= null ? mbSession.getSafiLogonInfo().getDevicePrint():null;
			try{
				JsonNode jsonNode = mapper.readValue(sdkDevicePrint, JsonNode.class);
				devicePrintForLogger = jsonNode!= null? jsonNode.toString() : "";
			}catch (Exception e) {
				//Swallow the exception if not able to derive sdk device print 
			}
		}
		
		DigitalSecLogggerVO digitalSecurityLogVO =new DigitalSecLogggerVO();
		digitalSecurityLogVO.setTranName(DigitalSecLogger.UPDATE_PHONE_NUMBER);
		digitalSecurityLogVO.setCommonLogData(mbAppHelper.getCommonLogData(ibankCommonData));
		digitalSecurityLogVO.setUserAgent(ibankCommonData.getUserAgent()); 
		
		try {		
			String desc = "";
			if (IBankParams.isEmailUpdationSwitchOn()) {
				MessageSearch messageSearch = mbSession.getSplashInfoMsg();
				if(messageSearch!=null && isEmailUpdationSplashMsg(messageSearch)){
					desc = desc + ";Email Updation Source = EmailSplash Page";
					mbSession.removeSplashInfoMsg();
				}
			}
			if (mbSession.getSWBInfoMsg() != null && Boolean.TRUE.equals(mbSession.getSWBInfoMsg()) ) {
				desc = desc + ";" + ServiceConstants.SOURCE_SECURITY_WELLBEING;
				mbSession.removeSWBInfoMsg();
			}
			changedContactDetails.setGdwSourceDescription(desc);
			mobileBankService.updatePhoneDetails(changedContactDetails , ibankCommonData, mbSession.getUcmModIndicator());
			
			//calling PRM WDP upon phone number update
			PRMUpdateService prmServiceBean = (PRMUpdateService) ServiceHelper.getBean("prmServiceBean");
			DeviceRisk deviceRiskDetails = populateDeviceRiskDetails(mbSession, ibankCommonData);
			prmServiceBean.sendUpdatePhoneNumberDetailsToPRM(ibankCommonData, changedContactDetails, mbSession.getCustomer().getContactDetail(), deviceRiskDetails);
	
			RespHeader headerResp = populateResponseHeader(ServiceConstants.UPDCONTACTDTL_RESPONSE, mbSession);
			contactDetailsResp.setSuccess(true);
			
			
			contactDetailsResp.setHeader(headerResp);
			mbSession.setSecureCodeVerifiedTranName(" ");
			digitalSecurityLogVO.setStatus(DigitalSecLogger.SUCCESS);
			try {
				digitalSecurityLogVO.setValues(contactDetailHelper.populateChangedPhoneNumbers(changedContactDetails, mbSession.getCustomer().getContactDetail(),devicePrintForLogger));
				digitalSecurityLogger.log(digitalSecurityLogVO);
			}catch(Exception e) {
				Logger.warn("Exception occurred while making Digital security logger entry (suppressing error) ", e, this.getClass());
			}
			mbSession.removeDigitalSecLoggerMap();
			
			//setting again as user can update again from same screen
			LabelValueMap digiSecMap = new LabelValueMap();
			digiSecMap.put(DigitalSecLogger.PREV_CONTACT_DETAILS,changedContactDetails.toDigitalSecurityLog(true,get2FAExemptType(mbSession.getCustomer()),null, isCHSorCombinedCustomer(mbSession.getCustomer())));
			mbSession.setDigitalSecLoggerMap(digiSecMap);
			
			//Make a notify call after successful 2FA and phone update
			if(null != mbSession.getSafiRequestVO() && mbSession.getSafiRequestVO() instanceof SafiUpdatePhoneVO) {
				
				SafiUpdatePhoneVO safiUpdatePhoneVO  = (SafiUpdatePhoneVO) mbSession.getSafiRequestVO();
				
				if(null != safiUpdatePhoneVO.getSafiRespVO() && null != safiUpdatePhoneVO.getSafiRespVO().getSafiAction() && safiUpdatePhoneVO.getSafiRespVO().getSafiAction().equals(SafiConstants.SAFI_ACTION_CHALLENGE))
					callSafiNotify(httpServletRequest, httpServletResponse, true, ibankCommonData);
			}

			//set new phone number in session post notify call
			mbSession.getCustomer().setContactDetail(changedContactDetails);
			
			//Remove updated phone details
			mbSession.removeUpdatePhoneDetails();
			
			//Remove SAFI VO for update phone call
			mbSession.removeSafiRequestVO();
			
		} catch (Exception e) {
			Logger.error("Exception while updating phonme number in mthod - updateCustPhoneNumber: "+e, this.getClass());
			contactDetailsResp.setSuccess(false);
			throw e;		
		} finally {
			Logger.debug("updateCustPhoneNumber END ", this.getClass());
		}
		
		return contactDetailsResp;
	}
	
	private boolean isEmailUpdationSplashMsg(MessageSearch messageSearch){			

		if(!MessageCentreConstants.SPLASH_OB_MSG_CODE.equalsIgnoreCase(messageSearch.getMsgType()))
				return false;
		
		if(MessageCentreConstants.EMAIL_UPDATION_MSG_ACTION.equalsIgnoreCase(messageSearch.getMessageAction())){
			return true;
		}
		
		return false;
	}
	
	
	@PostMapping(path="updatePhoneNumberNew", headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public IMBResp updatePhoneNumberNew(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse,
			@RequestBody final PhoneDetailReq req)
	{
		PerformanceLogger performanceLogger = new PerformanceLogger();
		fraudLogger = new FraudLogger();
		performanceLogger.startAllLogs();
		String logName = MBAppUtils.getLogName(httpServletRequest);
		performanceLogger.startLog(logName);
		String origin = null;
		MobileSession mbSession = null;
				
		DigitalSecLogggerVO digitalSecurityLogVO =new DigitalSecLogggerVO();
		digitalSecurityLogVO.setTranName(DigitalSecLogger.UPDATE_PHONE_NUMBER);
		boolean callCapApiForMob = false;
		try
		{
			mbSession = mbAppHelper.getMobileSession(httpServletRequest);
            validateRequestHeader( req.getHeader(), httpServletRequest );
			origin = mbSession.getOrigin();

			ErrorResp errorResp = validate(req, httpServletRequest);
			if (errorResp != null && errorResp.getErrors() != null && errorResp.getErrors().size() > 0)
			{
				return errorResp;
			}
			Customer customer=mbSession.getCustomer();
						
			IBankCommonData ibankCommonData=mbAppHelper.populateIBankCommonData(mbSession,httpServletRequest);
			ContactDetail changedContactDetails = contactDetailHelper.getPhoneDetailsNew(req, customer);
			mbSession.setUpdatePhoneDetails(changedContactDetails);
			
			ContactDetailsResp contactDetailsResp = new ContactDetailsResp();
			
			RespHeader headerResp = populateResponseHeader(req.getHeader().getServiceName(), mbSession );
			contactDetailsResp.setHeader(headerResp);
			
			if(IBankParams.isContactDetCapApiValSwitchOn()) {
				ArrayList<PhoneReq> phoneList = req.getPhones();
				Iterator<PhoneReq> it = phoneList.iterator();
		
				while (it.hasNext())
				{
					PhoneReq tempPhone = it.next();
					if (tempPhone.getIsPhnNoChange()) {
						if ("MOBILE".equalsIgnoreCase(tempPhone.getPhoneType()))
						{
							callCapApiForMob = true;
						}
					}	
				}
				if(callCapApiForMob) {
					AddressValidationSuccess contactDetailValidationSuccess = contactDetValService.validateContactDetailsCapApi(ibankCommonData, changedContactDetails, "P");
				}
			}
				
		
			boolean isSafiUpdPhoneSwitchOn = IBankParams.isSwitchOn(IBankParams.DEFAULT_ORIGIN, IBankParams.SAFI_UPDATE_PHONE_SWITCH);
			Logger.debug("SAFI : updatePhoneNumber:: Safi update phone Switch Value: "+isSafiUpdPhoneSwitchOn, this.getClass());
			boolean isSafiServiceAvailable = false;
			
			if(isSafiUpdPhoneSwitchOn){
				isSafiServiceAvailable = HeartBeat.isApplicationAvailable(HeartBeat.SAFI2_SERVICE_APPLICATION);
				Logger.info("SAFI : updatePhoneNumber:: SAFI2_SERVICE_APPLICATION STATUS: "+isSafiServiceAvailable, this.getClass());
			}
			
			if(isSafiServiceAvailable){
				
				boolean	isThrottleAllowed = memoryThrottlingService.processThrottling(IBankParams.THROTTLE_CAT_UPD_PHONE, customer.getGcis(), mbSession.getSessionID());
										
				if(isThrottleAllowed){
					ContactDetailsResp response = (ContactDetailsResp) callSafiAnalyse(httpServletRequest, httpServletResponse, mbSession, ibankCommonData, req, contactDetailsResp);
					
					if(response.isSecureCodeReqd())
						return response;
				}
			} else {				
				contactDetailsResp.setSecureCodeReqd(true);
				return contactDetailsResp;
			}
			
			return updateCustPhoneNumberNew(changedContactDetails, ibankCommonData, mbSession, contactDetailsResp, httpServletRequest, httpServletResponse);
			
		} catch (BusinessException e)
		{
			digitalSecurityLogVO.setStatus(DigitalSecLogger.FAILURE);
			digitalSecurityLogger.log(digitalSecurityLogVO);
			
			IMBResp resp1 = null;
			Logger.error("Exception Inside updContactDtls() for Customer "+ e.getKey(), e, this.getClass());
			
			if (e.getValues() != null) {
				resp1 = MBAppUtils.createErrorResp(origin , e, e.getValues(), MBAppConstants.SMPL_UPDCONTACTDTLS_RESP_NAME, httpServletRequest);
			} else if ( e.getKey() == 9898) { //  HOST ERROR TRANSACTION ROLLBACK 
				BusinessException exp = new BusinessException(BusinessException.GENERIC_ERROR);
				resp1 = MBAppUtils.createErrorResp(origin, exp, MBAppConstants.SMPL_UPDCONTACTDTLS_RESP_NAME, httpServletRequest);
			} else if (e.getKey() == BusinessException.UPDATE_PHONE_DEAD || e.getKey() == BusinessException.UPDATE_PHONE_UNVERIFIED) {
				BusinessException exp = new BusinessException(e.getKey());
				resp1 = MBAppUtils.createErrorResp(origin, exp, MBAppConstants.SMPL_UPDCONTACTDTLS_RESP_NAME, httpServletRequest);
			}else{
				resp1 = MBAppUtils.createErrorResp(origin, e, MBAppConstants.SMPL_UPDCONTACTDTLS_RESP_NAME, httpServletRequest);
			}
			return resp1;
			
		} catch (Exception e)
		{
			digitalSecurityLogVO.setStatus(DigitalSecLogger.FAILURE);
			digitalSecurityLogger.log(digitalSecurityLogVO);
			
			Logger.error("Exception Inside updContactDtls() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			BusinessException exp = new BusinessException(BusinessException.GENERIC_ERROR);
			IMBResp resp1 = MBAppUtils.createErrorResp(origin, exp, MBAppConstants.SMPL_UPDCONTACTDTLS_RESP_NAME, httpServletRequest);
			return resp1;
		} finally
		{
			performanceLogger.endLog(logName);
			performanceLogger.endAllLogs();
		}
	}
	
	private IMBResp updateCustPhoneNumberNew(ContactDetail changedContactDetails, IBankCommonData ibankCommonData, MobileSession mbSession, ContactDetailsResp contactDetailsResp,
			HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse) throws BusinessException, Exception {
		
		Logger.debug("updateCustPhoneNumber START for - "+ibankCommonData.getCustomer().getGcis(), this.getClass());
		
		String devicePrintForLogger = null;
		ObjectMapper mapper = new ObjectMapper();
		
		boolean isMobileApp = ((logonHelper.loadCordova(httpServletRequest)) == -1) ? false:true;
		if(isMobileApp){
			String sdkDevicePrint = mbSession.getSafiLogonInfo()!= null ? mbSession.getSafiLogonInfo().getDevicePrint():null;
			try{
				JsonNode jsonNode = mapper.readValue(sdkDevicePrint, JsonNode.class);
				devicePrintForLogger = jsonNode!= null? jsonNode.toString() : "";
			}catch (Exception e) {
				//Swallow the exception if not able to derive sdk device print 
			}
		}
		
		DigitalSecLogggerVO digitalSecurityLogVO =new DigitalSecLogggerVO();
		digitalSecurityLogVO.setTranName(DigitalSecLogger.UPDATE_PHONE_NUMBER);
		digitalSecurityLogVO.setCommonLogData(mbAppHelper.getCommonLogData(ibankCommonData));
		digitalSecurityLogVO.setUserAgent(ibankCommonData.getUserAgent()); 
		
		try {		
			String desc = "";
			if (IBankParams.isEmailUpdationSwitchOn()) {
				MessageSearch messageSearch = mbSession.getSplashInfoMsg();
				if(messageSearch!=null && isEmailUpdationSplashMsg(messageSearch)){
					desc = desc + ";Email Updation Source = EmailSplash Page";
					mbSession.removeSplashInfoMsg();
				}
			}
			if (mbSession.getSWBInfoMsg() != null && Boolean.TRUE.equals(mbSession.getSWBInfoMsg()) ) {
				desc = desc + ";" + ServiceConstants.SOURCE_SECURITY_WELLBEING;
				mbSession.removeSWBInfoMsg();
			}
			changedContactDetails.setGdwSourceDescription(desc);
//			boolean isContDetVal = contactDetValService.validateContactDetailsCapApi(ibankCommonData, changedContactDetails, "P");
			
			mobileBankService.updatePhoneDetails(changedContactDetails , ibankCommonData, mbSession.getUcmModIndicator());
			
			//calling PRM WDP upon phone number update
			PRMUpdateService prmServiceBean = (PRMUpdateService) ServiceHelper.getBean("prmServiceBean");
			DeviceRisk deviceRiskDetails = populateDeviceRiskDetails(mbSession, ibankCommonData);
			prmServiceBean.sendUpdatePhoneNumberDetailsToPRM(ibankCommonData, changedContactDetails, mbSession.getCustomer().getContactDetail(), deviceRiskDetails);
	
			RespHeader headerResp = populateResponseHeader(ServiceConstants.UPDCONTACTDTL_RESPONSE, mbSession);
			contactDetailsResp.setSuccess(true);
			
			
			contactDetailsResp.setHeader(headerResp);
			mbSession.setSecureCodeVerifiedTranName(" ");
			digitalSecurityLogVO.setStatus(DigitalSecLogger.SUCCESS);
			try {
				digitalSecurityLogVO.setValues(contactDetailHelper.populateChangedPhoneNumbers(changedContactDetails, mbSession.getCustomer().getContactDetail(),devicePrintForLogger));
				digitalSecurityLogger.log(digitalSecurityLogVO);
			}catch(Exception e) {
				Logger.warn("Exception occurred while making Digital security logger entry (suppressing error) ", e, this.getClass());
			}
			mbSession.removeDigitalSecLoggerMap();
			
			//setting again as user can update again from same screen
			LabelValueMap digiSecMap = new LabelValueMap();
			digiSecMap.put(DigitalSecLogger.PREV_CONTACT_DETAILS,changedContactDetails.toDigitalSecurityLog(true,get2FAExemptType(mbSession.getCustomer()),null, isCHSorCombinedCustomer(mbSession.getCustomer())));
			mbSession.setDigitalSecLoggerMap(digiSecMap);
			
			//Make a notify call after successful 2FA and phone update
			if(null != mbSession.getSafiRequestVO() && mbSession.getSafiRequestVO() instanceof SafiUpdatePhoneVO) {
				
				SafiUpdatePhoneVO safiUpdatePhoneVO  = (SafiUpdatePhoneVO) mbSession.getSafiRequestVO();
				
				if(null != safiUpdatePhoneVO.getSafiRespVO() && null != safiUpdatePhoneVO.getSafiRespVO().getSafiAction() && safiUpdatePhoneVO.getSafiRespVO().getSafiAction().equals(SafiConstants.SAFI_ACTION_CHALLENGE))
					callSafiNotify(httpServletRequest, httpServletResponse, true, ibankCommonData);
			}

			//set new phone number in session post notify call
			mbSession.getCustomer().setContactDetail(changedContactDetails);
			
			//Remove updated phone details
			mbSession.removeUpdatePhoneDetails();
			
			//Remove SAFI VO for update phone call
			mbSession.removeSafiRequestVO();
			
		} catch(BusinessException be) {
			Logger.error("Exception while updating phonme number in mthod - updateCustPhoneNumber: "+be, this.getClass());
			//contactDetailsResp.setSuccess(false);
			throw new BusinessException(be.getKey());
		} catch (Exception e) {	
			e.printStackTrace();
			Logger.error("Exception while updating phonme number in mthod - updateCustPhoneNumber: "+e, this.getClass());
			contactDetailsResp.setSuccess(false);
			throw e;		
		} finally {
			Logger.debug("updateCustPhoneNumber END ", this.getClass());
		}
		
		return contactDetailsResp;
	}
	
	private AddressValidationReq createCapValidationReq(ContactDetail changedContactDetails, IBankCommonData commonData,
			String changeType) {
		ContactDetail oldContactDetails = commonData.getCustomer().getContactDetail();
		AddressValidationReq req = new AddressValidationReq();
		boolean sendReq = false;
		au.com.stgeorge.ibank.businessobject.model.commdtlsvaldatn.Customer cust = new au.com.stgeorge.ibank.businessobject.model.commdtlsvaldatn.Customer();
		CustomerId custId = new CustomerId();
		custId.setId(commonData.getCustomer().getGcis());
		// custId.setId("123456789");
		custId.setIdScheme(IdScheme.valueOf("CustomerInternalId"));
		cust.setCustomerId(custId);
		cust.setFirstName(commonData.getCustomer().getFirstName());
		cust.setLastName(commonData.getCustomer().getLastName());
		cust.setBrandSilo(BrandSilo.valueOf("SGBBSA"));
		req.setCustomer(cust);
		req.setCustomerRiskAssessmentIndicator(CustomerRiskAssessmentIndicator.valueOf("Unknown"));
		req.setSessionID(commonData.getSessionId());
		RiskAssessRequest riskAssessmentPurpose = new RiskAssessRequest();
		riskAssessmentPurpose.setApplicantRoleType(ApplicantRoleType.valueOf("INDIVIDUAL"));
		riskAssessmentPurpose.setAppliedProductType(AppliedProductType.valueOf("SAVINGS"));

		if (changeType != null && ("P").equalsIgnoreCase(changeType)) {
			List<PhoneDetails> phoneDtlist = new ArrayList<PhoneDetails>();

			/*
			 * if ( (changedContactDetails.getHomeNumber() != null ) &&
			 * (!(changedContactDetails.getHomeNumber().equals(oldContactDetails.
			 * getHomeNumber())))) { sendReq = true; PhoneDetails phoneDet = new
			 * PhoneDetails();
			 * phoneDet.setPhoneNumber(changedContactDetails.getHomePhone());
			 * phoneDet.setUsageType(UsageType.valueOf("HOME")); phoneDtlist.add(phoneDet);
			 * } if ((changedContactDetails.getWorkNumber() != null ) &&
			 * (!(changedContactDetails.getWorkNumber().equals(oldContactDetails.
			 * getWorkNumber())))) { sendReq = true; PhoneDetails phoneDet = new
			 * PhoneDetails();
			 * phoneDet.setPhoneNumber(changedContactDetails.getWorkPhone());
			 * phoneDet.setUsageType(UsageType.valueOf("WORK")); phoneDtlist.add(phoneDet);
			 * }
			 */
			if ((changedContactDetails.getMobileNumber() != null)
					&& (!(changedContactDetails.getMobileNumber().equals(oldContactDetails.getMobileNumber())))) {
				sendReq = true;
				PhoneDetails phoneDet = new PhoneDetails();
				phoneDet.setPhoneNumber(changedContactDetails.getMobilePhone());
				phoneDet.setUsageType(UsageType.valueOf("OTHER"));
				phoneDtlist.add(phoneDet);
			}
			if (sendReq) {
				req.setTelecomAddresses(phoneDtlist);
			} else {
				req = null;
			}
		} else if (changeType != null && ("E").equalsIgnoreCase(changeType)) {
			req.setEmailAddress(changedContactDetails.getEmail());
		}
		return req;
	}
	
	private String getAddressForContactDetailValidation(ContactDetail contactDetail,boolean isResAdd, boolean isMailAdd) {
		String qasAddress = "";
		if(isResAdd) {
			qasAddress = contactDetail.getResidentialAddress().getLine1();
			if(contactDetail.getResidentialAddress().getLine2()!=null && contactDetail.getResidentialAddress().getLine2()!="") {
				qasAddress = qasAddress +", " + contactDetail.getResidentialAddress().getLine2();
			}
			if(contactDetail.getResidentialAddress().getLine3()!=null  && contactDetail.getResidentialAddress().getLine2()!="") {
				qasAddress = qasAddress +", " + contactDetail.getResidentialAddress().getLine3();
			}
			if(contactDetail.getResidentialAddress().getSuburb()!=null  && contactDetail.getResidentialAddress().getLine3()!="") {
				qasAddress = qasAddress +", " + contactDetail.getResidentialAddress().getSuburb();
			}
			if(contactDetail.getResidentialAddress().getState()!=null  && contactDetail.getResidentialAddress().getState()!="") {
				qasAddress = qasAddress +", " + contactDetail.getResidentialAddress().getState();
			}
			if(contactDetail.getResidentialAddress().getPostZipcode()!=null  && contactDetail.getResidentialAddress().getPostZipcode()!="") {
				qasAddress = qasAddress +", " + contactDetail.getResidentialAddress().getPostZipcode();
			}
		}
		if(isMailAdd) {
			qasAddress = contactDetail.getMailingAddress().getLine1();
			if(contactDetail.getMailingAddress().getLine2()!=null && contactDetail.getMailingAddress().getLine2()!=null) {
				qasAddress = qasAddress +", " + contactDetail.getMailingAddress().getLine2();
			}
			if(contactDetail.getMailingAddress().getLine3()!=null && contactDetail.getMailingAddress().getLine3()!=null) {
				qasAddress = qasAddress +", " + contactDetail.getMailingAddress().getLine3();
			}
			if(contactDetail.getMailingAddress().getSuburb()!=null && contactDetail.getMailingAddress().getSuburb()!=null) {
				qasAddress = qasAddress +", " + contactDetail.getMailingAddress().getSuburb();
			}
			if(contactDetail.getMailingAddress().getState()!=null && contactDetail.getMailingAddress().getState()!=null) {
				qasAddress = qasAddress +", " + contactDetail.getMailingAddress().getState();
			}
			if(contactDetail.getMailingAddress().getPostZipcode()!=null && contactDetail.getMailingAddress().getPostZipcode()!=null) {
				qasAddress = qasAddress +", " + contactDetail.getMailingAddress().getPostZipcode();
			}
		}
		
		return qasAddress;	

	}
	
}

