
package au.com.stgeorge.mbank.controller.customer;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import au.com.stgeorge.digitalsec.logger.DigitalSecLogger;
import au.com.stgeorge.digitalsec.logger.DigitalSecLogggerVO;
import au.com.stgeorge.framework.common.logging.Logger;
import au.com.stgeorge.framework.common.model.User;
import au.com.stgeorge.framework.common.util.StringMethods;
import au.com.stgeorge.ibank.businessobject.BusinessException;
import au.com.stgeorge.ibank.businessobject.EmailService;
import au.com.stgeorge.ibank.businessobject.IBankSecureService;
import au.com.stgeorge.ibank.businessobject.ResourceException;
import au.com.stgeorge.ibank.common.cache.IBankParams;
import au.com.stgeorge.ibank.evcrs.businessobject.CRSService;
import au.com.stgeorge.ibank.evcrs.businessobject.valueobject.CRSInfo;
import au.com.stgeorge.ibank.loanApplication.LoanApplicationDetail;
import au.com.stgeorge.ibank.loanApplication.util.LoanAppConstants;
import au.com.stgeorge.ibank.loanApplication.util.LoanAppUtil;
import au.com.stgeorge.ibank.mail.EmailDetails;
import au.com.stgeorge.ibank.messagecentre.util.MessageCentreConstants;
import au.com.stgeorge.ibank.messagecentre.valueobject.CustomerMessage;
import au.com.stgeorge.ibank.messagecentre.valueobject.MessageSearch;
import au.com.stgeorge.ibank.safi.util.SafiConstants;
import au.com.stgeorge.ibank.safi.valueobject.SafiLogonInfo;
import au.com.stgeorge.ibank.servicestation.businessobject.ServiceStation;
import au.com.stgeorge.ibank.servicestation.businessobject.ServiceStationImpl;
import au.com.stgeorge.ibank.servicestation.businessobject.valueobject.ServiceStationVO;
import au.com.stgeorge.ibank.servicestation.util.ServicetationConstants;
import au.com.stgeorge.ibank.util.CommonBusinessUtil;
import au.com.stgeorge.ibank.util.ServiceHelper;
import au.com.stgeorge.ibank.valueobject.AutoApplyRetentionInfo;
import au.com.stgeorge.ibank.valueobject.ContactDetail;
import au.com.stgeorge.ibank.valueobject.Customer;
import au.com.stgeorge.ibank.valueobject.MsgCentreInfo;
import au.com.stgeorge.ibank.valueobject.database.OriginsVO;
import au.com.stgeorge.ibank.valueobject.transfer.IBankCommonData;
import au.com.stgeorge.mbank.controller.IMBController;
import au.com.stgeorge.mbank.model.common.ErrorInfo;
import au.com.stgeorge.mbank.model.common.IMBReq;
import au.com.stgeorge.mbank.model.common.IMBResp;
import au.com.stgeorge.mbank.model.common.ReqHeader;
import au.com.stgeorge.mbank.model.common.RespHeader;
import au.com.stgeorge.mbank.model.common.SplashPageResp;
import au.com.stgeorge.mbank.model.request.customer.ActivationReq;
import au.com.stgeorge.mbank.model.request.customer.CredentialReq;
import au.com.stgeorge.mbank.model.response.ErrorResp;
import au.com.stgeorge.mbank.model.response.customer.LogonResp;
import au.com.stgeorge.mbank.session.MobileSession;
import au.com.stgeorge.mbank.util.FraudLogger;
import au.com.stgeorge.mbank.util.MBAppConstants;
import au.com.stgeorge.mbank.util.MBAppHelper;
import au.com.stgeorge.mbank.util.MBAppUtils;
import au.com.stgeorge.mbank.util.MBAppValidator;
import au.com.stgeorge.mbank.util.ServiceConstants;
import au.com.stgeorge.mobilebank.businessobject.ActivationService;
import au.com.stgeorge.mobilebank.businessobject.MobileBankService;
import au.com.stgeorge.mobilebank.businessobject.MobileMsgCntrService;
import au.com.stgeorge.perflogger.PerformanceLogger;

import com.fasterxml.jackson.databind.ObjectMapper;

@Controller
@RequestMapping(method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE)
public class CredentialController implements IMBController
{
	private FraudLogger fraudLogger;
	private static final String CRS_SPLASH_TYPE = "CRS";

	
	@Autowired
	private MobileBankService mobileBankService;
	
	@Autowired
	private MBAppHelper mbAppHelper;
	
	@Autowired
	private PerformanceLogger perfLogger;
	
	@Autowired
	private ActivationService activationService;

	@Autowired
    private DigitalSecLogger digitalSecLogger;
	
	@Autowired
	private ServiceStation serviceStationService;

	@Autowired
    private CRSService crsService;
	
	@RequestMapping("/changepwd")
	@ResponseBody
	public IMBResp changePassword(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse,
			@RequestBody final CredentialReq req)
	{
		Logger.debug("In changePassword ( ChangePwdSecNumController )  for Customer " +  "  " + httpServletRequest.getContentType() + " "
				+ httpServletRequest.getRemoteAddr() + "  " + httpServletResponse.getCharacterEncoding() + httpServletResponse.getLocale() +
				" True IP >> " + httpServletRequest.getHeader(IBankParams.trueClientIP()), this.getClass());
		perfLogger.startAllLogs();
		String logName = MBAppUtils.getLogName(httpServletRequest);
		perfLogger.startLog(logName);
		ObjectMapper mapper = new ObjectMapper();
		MobileSession mbSession = null;
		DigitalSecLogggerVO digitalSecurityLogVO =new DigitalSecLogggerVO();
		digitalSecurityLogVO.setTranName(DigitalSecLogger.CHANGE_PASSWORD);
		
		try
		{
//			Logger.info("ChangePassword JSON Request :" + mapper.writeValueAsString(req), this.getClass());
			mbSession = mbAppHelper.getMobileSession(httpServletRequest);		
			validateRequestHeader( req.getHeader(), httpServletRequest );
			ErrorResp errorResp;
			if (StringMethods.isEmptyString(req.getOldPassword()) || StringMethods.isEmptyString(req.getNewPassword()))
			{
				BusinessException exp = new BusinessException(BusinessException.WSVC_INVALID_INPUT_PARAM);
				errorResp = (ErrorResp) MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, ServiceConstants.CHANGEPWDSECNUM_RESPONSE , httpServletRequest );
				return errorResp;
				
			}
			errorResp = validate(req, httpServletRequest);
			if (errorResp != null && errorResp.getErrors() != null && errorResp.getErrors().size() > 0)
			{
				return errorResp;
			}
			IBankCommonData ibankCommonData = mbAppHelper.populateIBankCommonData(mbSession, httpServletRequest);
			digitalSecurityLogVO.setCommonLogData(mbAppHelper.getCommonLogData(ibankCommonData));
			digitalSecurityLogVO.setUserAgent(ibankCommonData.getUserAgent()); 
			if(req.isSourceSecurityWellBeingCheck()) {
				mobileBankService.changePassword(ibankCommonData, req.getOldPassword(), req.getNewPassword(), ibankCommonData.getUser().getUserId() + ";" + ServiceConstants.SOURCE_SECURITY_WELLBEING);
			}
			else {
				mobileBankService.changePassword(ibankCommonData, req.getOldPassword(), req.getNewPassword());
			}
			// Get Service Message
			long insertionPt = logonHelper.getInsertionPointCode(ServicetationConstants.CHANGE_PASSWORD);
			ServiceStationVO servicestationVO=populateServiceMessage(insertionPt,ServiceStationImpl.CHANNEL_MOBILE, ibankCommonData);
			if(null!=servicestationVO)
			{
				mbSession.setServiceStationMessage(servicestationVO.getServiceStationMsg());
			}
						
			IMBResp serviceResponse = CredentialHelper.populateResponse(servicestationVO);
			Logger.info("changePassword JSON Response :" + mapper.writeValueAsString(serviceResponse), this.getClass());
			RespHeader headerResp = populateResponseHeader(req.getHeader().getServiceName(), mbSession);
			serviceResponse.setHeader(headerResp);
			
			digitalSecurityLogVO.setStatus(DigitalSecLogger.SUCCESS);
			digitalSecLogger.log(digitalSecurityLogVO);
			return serviceResponse;

		} catch (BusinessException e)
		{
			Logger.error("Exception Inside changePassword() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			digitalSecurityLogVO.setStatus(DigitalSecLogger.FAILURE);
			digitalSecLogger.log(digitalSecurityLogVO);
			
			IMBResp response = null;
			if ( e.getKey() == BusinessException.INVALID_USERID_PASSWORD )
				response = MBAppUtils.createErrorResp( mbSession.getOrigin(), BusinessException.INVALID_CURRENT_PWD_SEC_NUM, MBAppConstants.SMPL_CHANGEPWD_RESP_NAME, httpServletRequest);
			else
				response = MBAppUtils.createErrorResp( mbSession.getOrigin(), e.getKey(), MBAppConstants.SMPL_CHANGEPWD_RESP_NAME, httpServletRequest);
			return response;
		} catch (Exception e)
		{
			Logger.error("Exception Inside changePassword() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			IMBResp response = MBAppUtils.createErrorResp(mbSession.getOrigin(), BusinessException.SYSTEM_UNAVILABLE, MBAppConstants.SMPL_CHANGEPWD_RESP_NAME, httpServletRequest);
			return response;
		} finally
		{
			perfLogger.endLog(logName);
			perfLogger.endAllLogs();
		}
	}
	
	
	@RequestMapping("/changesecnum")
	@ResponseBody
	public IMBResp changeSecNum(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse,
			@RequestBody final CredentialReq req)
	{
		Logger.debug("In changesecnum ( ChangePwdSecNumController )  for Customer " +  "  " + httpServletRequest.getContentType() + " "
				+ httpServletRequest.getRemoteAddr() + "  " + httpServletResponse.getCharacterEncoding() + httpServletResponse.getLocale() +
				" True IP >> " + httpServletRequest.getHeader(IBankParams.trueClientIP()), this.getClass());
		perfLogger.startAllLogs();
		String logName = MBAppUtils.getLogName(httpServletRequest);
		perfLogger.startLog(logName);
		ObjectMapper mapper = new ObjectMapper();
		MobileSession mbSession = null;
        DigitalSecLogggerVO digitalSecLoggerVO =new DigitalSecLogggerVO();
        digitalSecLoggerVO.setTranName(DigitalSecLogger.CHANGE_SECURITY_NUMBER);
        digitalSecLoggerVO.setStatus(DigitalSecLogger.SUCCESS);
        
		try
		{
//			Logger.debug("changesecnum JSON Request :" + mapper.writeValueAsString(req), this.getClass());
			mbSession = mbAppHelper.getMobileSession(httpServletRequest);		
			validateRequestHeader( req.getHeader(), httpServletRequest );

			ErrorResp errorResp;
			if (StringMethods.isEmptyString(req.getOldSecNum()) || StringMethods.isEmptyString(req.getNewSecurityNumber()))
			{
				BusinessException exp = new BusinessException(BusinessException.WSVC_INVALID_INPUT_PARAM);
				errorResp = (ErrorResp) MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, ServiceConstants.CHANGEPWDSECNUM_RESPONSE , httpServletRequest);
				return errorResp;
			}
			errorResp = validate(req, httpServletRequest);
			if (errorResp != null && errorResp.getErrors() != null && errorResp.getErrors().size() > 0)
			{				
				return errorResp;
			}
			IBankCommonData ibankCommonData = mbAppHelper.populateIBankCommonData(mbSession, httpServletRequest);
			digitalSecLoggerVO.setCommonLogData(mbAppHelper.getCommonLogData(ibankCommonData));
			digitalSecLoggerVO.setUserAgent(ibankCommonData.getUserAgent());
			
			if(req.isSourceSecurityWellBeingCheck()) {
				mobileBankService.changeSecNum(ibankCommonData, req.getOldSecNum(), req.getNewSecurityNumber(), ibankCommonData.getUser().getUserId() + ";" + ServiceConstants.SOURCE_SECURITY_WELLBEING);
			}
			else {
				mobileBankService.changeSecNum(ibankCommonData, req.getOldSecNum(), req.getNewSecurityNumber());
			}
			
			// Get Service Message
			long insertionPt = logonHelper.getInsertionPointCode(ServicetationConstants.CHANGE_SECURITY_NUMBER);
			ServiceStationVO servicestationVO=populateServiceMessage(insertionPt,ServiceStationImpl.CHANNEL_MOBILE, ibankCommonData);
			if(null!=servicestationVO)
			{
				mbSession.setServiceStationMessage(servicestationVO.getServiceStationMsg());
			}
			digitalSecLogger.log(digitalSecLoggerVO);
			IMBResp serviceResponse = CredentialHelper.populateResponse(servicestationVO);
			
			Logger.info("changePassword JSON Response :" + mapper.writeValueAsString(serviceResponse), this.getClass());
//			RespHeader headerResp = populateResponseHeader(req.getHeader().getServiceName());
			RespHeader headerResp = populateResponseHeader(req.getHeader().getServiceName(), mbSession);
			serviceResponse.setHeader(headerResp);
			return serviceResponse;
		} catch (BusinessException e)
		{
			Logger.error("Exception Inside changePassword() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			digitalSecLoggerVO.setStatus(DigitalSecLogger.FAILURE);
			digitalSecLogger.log(digitalSecLoggerVO);
			IMBResp response = null;
			if ( e.getKey() == BusinessException.INVALID_USERID_PASSWORD )
				response = MBAppUtils.createErrorResp( mbSession.getOrigin(), BusinessException.INVALID_CURRENT_PWD_SEC_NUM, MBAppConstants.SMPL_CHANGESECNUM_RESP_NAME, httpServletRequest);
			else
				response = MBAppUtils.createErrorResp( mbSession.getOrigin(), e.getKey(), MBAppConstants.SMPL_CHANGESECNUM_RESP_NAME, httpServletRequest);
			 
			return response;
		} catch (Exception e)
		{
			Logger.error("Exception Inside changePassword() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			IMBResp response = MBAppUtils.createErrorResp(mbSession.getOrigin(), BusinessException.SYSTEM_UNAVILABLE, MBAppConstants.SMPL_CHANGEPWD_RESP_NAME, httpServletRequest);
			return response;
		} finally
		{
			perfLogger.endLog(logName);
			perfLogger.endAllLogs();
		}
	}
	
	
	@RequestMapping("/changeInitPwd")
	@ResponseBody
	public IMBResp changeInitPassword(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse,
			@RequestBody final CredentialReq req)
	{
		Logger.debug("In change Init Password ( ChangePwdSecNumController )  for Customer " +  "  " + httpServletRequest.getContentType() + " "
				+ httpServletRequest.getRemoteAddr() + "  " + httpServletResponse.getCharacterEncoding() + httpServletResponse.getLocale() +
				" True IP >> " + httpServletRequest.getHeader(IBankParams.trueClientIP()), this.getClass());
		perfLogger.startAllLogs();
		String logName = MBAppUtils.getLogName(httpServletRequest);
		perfLogger.startLog(logName);
		ObjectMapper mapper = new ObjectMapper();
		MobileSession mbSession = null;
		DigitalSecLogggerVO digitalSecurityLogVO =new DigitalSecLogggerVO();
		digitalSecurityLogVO.setTranName(DigitalSecLogger.SET_PASSWORD);
		List populateSplashPageResult = null;
		
		try
		{
//			Logger.info("Change Init Password JSON Request :" + mapper.writeValueAsString(req), this.getClass());
			mbSession = mbAppHelper.getMobileSession(httpServletRequest);		
			ErrorResp errorResp;
			if ( StringMethods.isEmptyString(req.getNewPassword()))
			{
				BusinessException exp = new BusinessException(BusinessException.WSVC_INVALID_INPUT_PARAM);
				errorResp = (ErrorResp) MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, ServiceConstants.CHANGEPWDSECNUM_RESPONSE , httpServletRequest);
				return errorResp;
				
			}
			errorResp = validate(req, httpServletRequest);
			if (errorResp != null && errorResp.getErrors() != null && errorResp.getErrors().size() > 0)
			{
				return errorResp;
			}
			IBankCommonData ibankCommonData = mbAppHelper.populateIBankCommonData(mbSession, httpServletRequest);
			digitalSecurityLogVO.setCommonLogData(mbAppHelper.getCommonLogData(ibankCommonData));
			digitalSecurityLogVO.setUserAgent(ibankCommonData.getUserAgent());
			
			mobileBankService.resetPassword(ibankCommonData,  req.getNewPassword());
			Customer customer=mbSession.getCustomer();
			if ( customer == null )
			{
				customer = getCustomer(ibankCommonData, null);
				mbSession.setCustomer(customer);
				ibankCommonData.setCustomer(customer);
			}
			User user=mbSession.getUser();
			int unreadMsgCount = -1;

//			Splash page update MsgCount							
			Logger.debug("Processing splashPageInfo", this.getClass());
			boolean isECorrespondenceSupported = CommonBusinessUtil.isECorrespondenceSupported(httpServletRequest);
			
			MsgCentreInfo msgCentreInfo= processMsgCentre(mbSession.getOrigin(),customer.getGcis(),isECorrespondenceSupported);
			//List<Object> splashPageInfo= processMsgCentre(mbSession.getOrigin(),customer.getGcis(),isECorrespondenceSupported);
			List<MessageSearch> splashPageInfo = msgCentreInfo.getSplashPageInfo();
			     
			
			List<AutoApplyRetentionInfo> digiRetInfoList=		msgCentreInfo.getApplyRetentionInfo();
			AutoApplyRetentionInfo autoApplyRetentionInfo =null;
		/*	if(digiRetInfoList!= null && digiRetInfoList.size()>0 && digiRetInfoList.get(0)!=null ){
				 autoApplyRetentionInfo = digiRetInfoList.get(0);
				//customer.setDigiretAccountNumber(autoApplyRetentionInfo.getAccountNumber());
			//	genericSession.setAttribute(MobileSessionImpl.AUTO_APPLY_RETENTION_SESSION, autoApplyRetentionInfo);
				mbSession.setAutoApplyRetentionInfo(autoApplyRetentionInfo);
			}
			*/
			
			if(digiRetInfoList!= null && digiRetInfoList.size()>0 ){
				try{
				 autoApplyRetentionInfo = digiRetInfoList.get(0);
			
				 Logger.debug("Auto Apply retention info message seen: "+autoApplyRetentionInfo.getAccountNumber(), this.getClass());
				 
				 mbSession.setAutoApplyRetentionInfo(autoApplyRetentionInfo);
				}
				catch(Exception e){
					Logger.info("CredentialController:changeInitPassword() autoApplyRetentionInfo is null", this.getClass());
				}
			}
			
			if(splashPageInfo != null && !splashPageInfo.isEmpty()){
				MessageSearch messageSearch = (MessageSearch)splashPageInfo.get(0);
				mbSession.setSplashInfoMsg(messageSearch);
				//unreadMsgCount = (Integer)splashPageInfo.get(0);
				unreadMsgCount = msgCentreInfo.getUnreadMessageCount();
				Logger.debug("splashPageInfo - unreadMsgCount: "+unreadMsgCount, this.getClass());
			}
			
			// call service to get ServiceAdminVo
		    long insertionPt = logonHelper.getInsertionPointCode(ServicetationConstants.DASHBOARD);
			ServiceStationVO servicestationVO=populateServiceMessage(insertionPt,ServiceStationImpl.CHANNEL_MOBILE, ibankCommonData);
			if(null!=servicestationVO)
			{
				mbSession.setServiceStationDashboardMessage(servicestationVO.getServiceStationMsg());
			}

			IMBResp serviceResponse = logonHelper.populateResponse(customer,user,unreadMsgCount, httpServletRequest , httpServletResponse, false,servicestationVO,autoApplyRetentionInfo);				

			Logger.info("Change Init Password JSON Request :" + mapper.writeValueAsString(serviceResponse), this.getClass());
			mbSession.setLoggedonState(LogonHelper.LOGGEDON_STATE_COMPLETE);
			
			boolean hasSecureCodeConstraints = hasSecureCodeConstraints(customer);
			SafiLogonInfo safiLogonInfo = mbSession.getSafiLogonInfo();
			String safiAction = safiLogonInfo != null ? safiLogonInfo.getSafiAction():null;
			if(!StringMethods.isEmptyString(safiAction) && safiAction.equalsIgnoreCase(SafiConstants.SAFI_ACTION_CHALLENGE) && !hasSecureCodeConstraints){
				Logger.info("SAFI : CredentialController:changeInitPassword(): Setting LoggedOnState - SafiChallenge: SafiAction : "+safiAction+" GCISNumber: "+customer.getGcis(), this.getClass());
				((LogonResp) serviceResponse).setCustomer(null);
				((LogonResp) serviceResponse).setShowSafiChallenge(true);
				((LogonResp) serviceResponse).setContactInfo(logonHelper.populateContact(customer.getContactDetail()));
				((LogonResp) serviceResponse).setSecureCodeInfo(logonHelper.populateSecureCodeInfo(customer));
				mbSession.setLoggedonState(LogonHelper.LOGGEDON_STATE_SAFI_CHALLENGE);

			}else{
				//Populate the ghost tile Response
				if(customer.getPreference() != null){
					
					//20E2-CSH -SBGEXP-8227 - added condition to check CSH/Efinance/Homeloan combination
					int cshIndicator = LoanAppUtil.getCSHTileIndicator(customer.getPreference().getCcPLLoanInd());
					
					if(customer.getPreference().getCcPLLoanInd() == LoanAppConstants.PRF_CCLOANIND_EFINANCE || customer.getPreference().getCcPLLoanInd() == LoanAppConstants.PRF_CCLOANIND_EFINANCE_HOMELOAN_BOTH
							|| cshIndicator == LoanAppConstants.PRF_CCLOANIND_EFINANCE
							|| cshIndicator == LoanAppConstants.PRF_CCLOANIND_EFINANCE_HOMELOAN_BOTH){						
						LoanApplicationDetail loanAppDetail = logonHelper.populateLoanApplicationDetail(ibankCommonData,serviceResponse);
						mbSession.setLoanApplicationDetail(loanAppDetail);			
					}
					
					//20E2-CSH -SBGEXP-8227 - populate the details for CSH tile
					if(cshIndicator == LoanAppConstants.PRF_CCLOANIND_CSH ||
							cshIndicator == LoanAppConstants.PRF_CCLOANIND_EFINANCE ||	
							cshIndicator == LoanAppConstants.PRF_CCLOANIND_HOMELOAN ||
							cshIndicator == LoanAppConstants.PRF_CCLOANIND_EFINANCE_HOMELOAN_BOTH) {
						Logger.debug("CSH : Populate CSH Tile. ", getClass());
						logonHelper.populateCSHApplicationDetail(ibankCommonData,serviceResponse);						 
					}
					
					//20E2-CSH -SBGEXP-8227 - added condition to check CSH/Efinance/Homeloan combination
					if(customer.getPreference().getCcPLLoanInd() == LoanAppConstants.PRF_CCLOANIND_HOMELOAN || customer.getPreference().getCcPLLoanInd() == LoanAppConstants.PRF_CCLOANIND_EFINANCE_HOMELOAN_BOTH
							|| cshIndicator == LoanAppConstants.PRF_CCLOANIND_HOMELOAN
							|| cshIndicator == LoanAppConstants.PRF_CCLOANIND_EFINANCE_HOMELOAN_BOTH){
						logonHelper.populateHomeLoanGhostTile(ibankCommonData, serviceResponse);
						//TODO set in session post confirmation
					}

				}
				//			Populate the SplashPage Response
				Logger.debug("Before populate splashPageInfo", this.getClass());
				if(splashPageInfo != null && splashPageInfo.size() > 0 && splashPageInfo.get(0) != null){
					//populateSplashPage(splashPageInfo, mbSession.getOrigin(), customer, ibankCommonData, serviceResponse);
					populateSplashPageResult=populateSplashPage(splashPageInfo, mbSession.getOrigin(), customer, ibankCommonData, serviceResponse);
					if(null!= populateSplashPageResult){
						boolean crsSplash = (boolean) populateSplashPageResult.get(0);
						Logger.debug("After populateSplashPage : crsSlpash :"+crsSplash , this.getClass());
						if(crsSplash){
							if(populateSplashPageResult.size() > 1){
								mbSession.setCrsRegistrationNumber((String)populateSplashPageResult.get(1));
								Logger.debug("In CredentialController :: CRS Flag "+(String)populateSplashPageResult.get(1), this.getClass());
							}

							if(isCrsHardPrompt3(splashPageInfo)){
								Logger.debug("This is hard prompt three ..Setting logged on state..", this.getClass());
								mbSession.setLoggedonState(LogonHelper.LOGGEDON_STATE_CRS_HARD_PROMPT);
							}
						}
					}
				}
			}
//			RespHeader headerResp = populateResponseHeader(req.getHeader().getServiceName());
			RespHeader headerResp = populateResponseHeader(req.getHeader().getServiceName(), mbSession);
			serviceResponse.setHeader(headerResp);
			
			digitalSecurityLogVO.setStatus(DigitalSecLogger.SUCCESS);
			digitalSecLogger.log(digitalSecurityLogVO);
			
			return serviceResponse;

		} catch (BusinessException e)
		{
			Logger.error("Exception Inside changePassword() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			digitalSecurityLogVO.setStatus(DigitalSecLogger.FAILURE);
			digitalSecLogger.log(digitalSecurityLogVO);
			IMBResp response = MBAppUtils.createErrorResp(mbSession.getOrigin(), e.getKey(), MBAppConstants.SMPL_CHANGEPWD_RESP_NAME,httpServletRequest);
			return response;
		} catch (Exception e)
		{
			Logger.error("Exception Inside changePassword() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			IMBResp response = MBAppUtils.createErrorResp(mbSession.getOrigin(), BusinessException.SYSTEM_UNAVILABLE, MBAppConstants.SMPL_CHANGEPWD_RESP_NAME, httpServletRequest);
			return response;
		} finally
		{
			perfLogger.endLog(logName);
			perfLogger.endAllLogs();
		}
	}

	@RequestMapping(value="changePwdAndSecnum", method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public IMBResp actResetPwdSecNum(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse,
			@RequestBody final ActivationReq req)
	{
		Logger.debug("In reset pwd secnum( ActivationController )  for Customer " +  "  " + httpServletRequest.getContentType() + " "
				+ httpServletRequest.getRemoteAddr() + "  " + httpServletResponse.getCharacterEncoding() + httpServletResponse.getLocale() +
				" True IP >> " + httpServletRequest.getHeader(IBankParams.trueClientIP()), this.getClass());
		fraudLogger = new FraudLogger();
		perfLogger.startAllLogs();
		String logName = MBAppUtils.getLogName(httpServletRequest);
		perfLogger.startLog(logName);
		ObjectMapper mapper = new ObjectMapper();
		int unreadMsgCount = -1;
		MobileSession mbSession = null;
        DigitalSecLogggerVO digitalSecLoggerVO =new DigitalSecLogggerVO();
        digitalSecLoggerVO.setTranName(DigitalSecLogger.SET_PASSWORD_SECURITY_NUMBER);
        digitalSecLoggerVO.setStatus(DigitalSecLogger.SUCCESS);
        
		try
		{
			Logger.info("reset pwd secnum JSON Request :" , this.getClass());
			mbSession = mbAppHelper.getMobileSession(httpServletRequest);			
			ErrorResp errorResp = validate(req, httpServletRequest);
			if (errorResp != null && errorResp.getErrors() != null && errorResp.getErrors().size() > 0)
			{
				return errorResp;
			}
			mbSession.getSessionContext(httpServletRequest);
			User user=mbSession.getUser();
			IBankCommonData ibankCommonData = mbAppHelper.populateIBankCommonData(mbSession, httpServletRequest);
			digitalSecLoggerVO.setCommonLogData(mbAppHelper.getCommonLogData(ibankCommonData));
			digitalSecLoggerVO.setUserAgent(ibankCommonData.getUserAgent());
			activationService.setInitialPwdSecurityNumber(ibankCommonData, "Test Ref", req.getNewPassword(), req.getNewSecNum(), "RESMS");
			digitalSecLogger.log(digitalSecLoggerVO);
			
			// update Email Address at the time of Activation
			if( StringMethods.isEmptyString(ibankCommonData.getCustomer().getContactDetail().getEmail()) &&  !StringMethods.isEmptyString(req.getNewEmail())){
				try{ 
				ContactDetail myContactDetails = ibankCommonData.getCustomer().getContactDetail();
				 myContactDetails.setEmail(req.getNewEmail());
			     activationService.updateEmailAddressAtActivation(myContactDetails, ibankCommonData);
				}
				catch (BusinessException e)
				{
					Logger.error("Exception Inside activation while updating email address: :", e, this.getClass());
				}
				 catch (Exception e)
				{
					 Logger.error("Exception Inside activation while updating email address: :", e, this.getClass()); 
				}
			 }
			
			Customer customer=mbSession.getCustomer();
			if ( customer == null || StringMethods.isEmptyString( customer.getGcis() ) )
			{
				customer = mobileBankService.getCustomer(ibankCommonData);
				mbSession.setCustomer(customer);
				ibankCommonData.setCustomer(customer);
			}
			
			sendNotification(mbSession);

//			Splash page update MsgCount							
			Logger.debug("Processing splashPageInfo", this.getClass());
			boolean isECorrespondenceSupported = CommonBusinessUtil.isECorrespondenceSupported(httpServletRequest);
			
			MsgCentreInfo msgCentreInfo			= processMsgCentre(mbSession.getOrigin(),customer.getGcis(),isECorrespondenceSupported);
			
			List<MessageSearch> splashPageInfo =  msgCentreInfo.getSplashPageInfo();
			
			if(splashPageInfo != null && !splashPageInfo.isEmpty()){
				MessageSearch messageSearch = splashPageInfo.get(0);
				mbSession.setSplashInfoMsg(messageSearch);
				//unreadMsgCount = (Integer)splashPageInfo.get(0);
				unreadMsgCount =msgCentreInfo.getUnreadMessageCount() ;
				Logger.debug("splashPageInfo - unreadMsgCount: "+unreadMsgCount, this.getClass());
			}
			
			// call service to get ServiceAdminVo
		    long insertionPt = logonHelper.getInsertionPointCode(ServicetationConstants.DASHBOARD);
			ServiceStationVO servicestationVO=populateServiceMessage(insertionPt,ServiceStationImpl.CHANNEL_MOBILE, ibankCommonData);
			if(null!=servicestationVO)
			{
				mbSession.setServiceStationDashboardMessage(servicestationVO.getServiceStationMsg());
			}
			mbSession.setLoggedonState(LogonHelper.LOGGEDON_STATE_COMPLETE);			
		
			List<AutoApplyRetentionInfo> digiRetInfoList=		msgCentreInfo.getApplyRetentionInfo();
			AutoApplyRetentionInfo autoApplyRetentionInfo =null;
		
			
			if(digiRetInfoList!= null && digiRetInfoList.size()>0 ){
				try{
				 autoApplyRetentionInfo = digiRetInfoList.get(0);
			
				 Logger.debug("Auto Apply retention info message seen: "+autoApplyRetentionInfo.getAccountNumber(), this.getClass());
				 
				 mbSession.setAutoApplyRetentionInfo(autoApplyRetentionInfo);
				}
				catch(Exception e){
					Logger.info("CredentialController:changeInitPassword() autoApplyRetentionInfo is null", this.getClass());
				}
			}
		
			
			
			
			IMBResp serviceResponse = logonHelper.populateResponse(customer,user,unreadMsgCount, httpServletRequest , httpServletResponse, false,servicestationVO,autoApplyRetentionInfo);

			boolean hasSecureCodeConstraints = hasSecureCodeConstraints(customer);
			SafiLogonInfo safiLogonInfo = mbSession.getSafiLogonInfo();
			String safiAction = safiLogonInfo != null ? safiLogonInfo.getSafiAction():null;
			if(!StringMethods.isEmptyString(safiAction) &&  safiAction.equalsIgnoreCase(SafiConstants.SAFI_ACTION_CHALLENGE) && !hasSecureCodeConstraints){
				Logger.info("CredentialController:changePwdAndSecnum(): Setting LoggedOnState - SafiChallenge: SafiAction : "+safiAction+" GCISNumber: "+customer.getGcis(), this.getClass());
				((LogonResp) serviceResponse).setCustomer(null);
				((LogonResp) serviceResponse).setShowSafiChallenge(true);
				((LogonResp) serviceResponse).setContactInfo(logonHelper.populateContact(customer.getContactDetail()));
				((LogonResp) serviceResponse).setSecureCodeInfo(logonHelper.populateSecureCodeInfo(customer));
				mbSession.setLoggedonState(LogonHelper.LOGGEDON_STATE_SAFI_CHALLENGE);

			}else{
				//Populate the ghost tile Response
				if(customer.getPreference() != null){
					
					//20E2-CSH -SBGEXP-8227 - added condition to check CSH/Efinance/Homeloan combination
					int cshIndicator = LoanAppUtil.getCSHTileIndicator(customer.getPreference().getCcPLLoanInd());
					
					if(customer.getPreference().getCcPLLoanInd() == LoanAppConstants.PRF_CCLOANIND_EFINANCE || customer.getPreference().getCcPLLoanInd() == LoanAppConstants.PRF_CCLOANIND_EFINANCE_HOMELOAN_BOTH
							|| cshIndicator == LoanAppConstants.PRF_CCLOANIND_EFINANCE
							|| cshIndicator == LoanAppConstants.PRF_CCLOANIND_EFINANCE_HOMELOAN_BOTH){						
						LoanApplicationDetail loanAppDetail = logonHelper.populateLoanApplicationDetail(ibankCommonData,serviceResponse);
						mbSession.setLoanApplicationDetail(loanAppDetail);

					}
					
					//20E2-CSH -SBGEXP-8227 - populate the details for CSH tile
					if(cshIndicator == LoanAppConstants.PRF_CCLOANIND_CSH ||
							cshIndicator == LoanAppConstants.PRF_CCLOANIND_EFINANCE ||	
							cshIndicator == LoanAppConstants.PRF_CCLOANIND_HOMELOAN ||
							cshIndicator == LoanAppConstants.PRF_CCLOANIND_EFINANCE_HOMELOAN_BOTH) {
						Logger.debug("CSH : Populate CSH Tile. ", getClass());
						logonHelper.populateCSHApplicationDetail(ibankCommonData,serviceResponse);						 
					}
					
					//20E2-CSH -SBGEXP-8227 - added condition to check CSH/Efinance/Homeloan combination
					if(customer.getPreference().getCcPLLoanInd() == LoanAppConstants.PRF_CCLOANIND_HOMELOAN || customer.getPreference().getCcPLLoanInd() == LoanAppConstants.PRF_CCLOANIND_EFINANCE_HOMELOAN_BOTH
							|| cshIndicator == LoanAppConstants.PRF_CCLOANIND_HOMELOAN
							|| cshIndicator == LoanAppConstants.PRF_CCLOANIND_EFINANCE_HOMELOAN_BOTH){
						logonHelper.populateHomeLoanGhostTile(ibankCommonData, serviceResponse);
						//TODO set in session post confirmation
					}

				}

				//			Populate the SplashPage Response
				Logger.debug("Before populate splashPageInfo", this.getClass());
				List<Object> populateSplashPageResult=null;
				if(splashPageInfo != null && splashPageInfo.size() > 0 && splashPageInfo.get(0) != null){
					//populateSplashPage(splashPageInfo, mbSession.getOrigin(), customer, ibankCommonData, serviceResponse);
					populateSplashPageResult=populateSplashPage(splashPageInfo, mbSession.getOrigin(), customer, ibankCommonData, serviceResponse);
					if(null!= populateSplashPageResult){
						boolean crsSplash = (boolean) populateSplashPageResult.get(0);
						Logger.debug("After actResetPwdSecNum populateSplashPage : crsSlpash :"+crsSplash , this.getClass());
						if(crsSplash){
							if(populateSplashPageResult.size() > 1){
								mbSession.setCrsRegistrationNumber((String)populateSplashPageResult.get(1));
								Logger.debug("In actResetPwdSecNum CredentialController :: CRS Flag "+(String)populateSplashPageResult.get(1), this.getClass());
							}

							if(isCrsHardPrompt3(splashPageInfo)){
								Logger.debug("This actResetPwdSecNum is hard prompt three ..Setting logged on state..", this.getClass());
								mbSession.setLoggedonState(LogonHelper.LOGGEDON_STATE_CRS_HARD_PROMPT);
							}
						}
					}
				}			
			}
			Logger.info("reset pwd secnum JSON Response :" + mapper.writeValueAsString(serviceResponse), this.getClass());
			RespHeader headerResp = populateResponseHeader(req.getHeader().getServiceName(), mbSession);
			serviceResponse.setHeader(headerResp);
			return serviceResponse;

		} catch (BusinessException e)
		{
			Logger.error("Exception Inside reset password secnum for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			digitalSecLoggerVO.setStatus(DigitalSecLogger.FAILURE);
			digitalSecLogger.log(digitalSecLoggerVO);
//			BusinessException exp = new BusinessException(e.getKey());
			IMBResp resp1 = MBAppUtils.createErrorResp(mbSession.getOrigin() , e, MBAppConstants.SMPL_CHANGEPWD_RESP_NAME, httpServletRequest);
			return resp1;
		} catch (Exception e)
		{
			Logger.error("Exception Inside reset pwd secnum for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			BusinessException exp = new BusinessException(BusinessException.SMPL_SYS_ERROR);
			IMBResp resp1 = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, MBAppConstants.SMPL_CHANGEPWD_RESP_NAME, httpServletRequest);
			return resp1;
		} finally
		{
			perfLogger.endLog(logName);
			perfLogger.endAllLogs();
		}
	}

//	Populate the SplashPage Response
	public List populateSplashPage(/*List<Object> splashPageInfo*/List<MessageSearch> splashPageInfo  , String origin, Customer customer, IBankCommonData ibankCommonData, IMBResp serviceResponse) throws au.com.stgeorge.framework.common.exception.ResourceException, BusinessException{
		Logger.debug("Inside populateSplashPage, GCIS: "+customer.getGcis(), this.getClass());
		SplashPageResp splashPageResp = null;
		MessageSearch messageSearch = splashPageInfo.get(0);
		CRSInfo crsInfo = null;
		boolean showSplash=false;
		List populateSplashPageResult = null;
		boolean showHardPrompt3=false;
		
		//switch check for CRS Hard prompt
		if(!IBankParams.isSwitchOn(IBankParams.CRS_PRODUCT_READY_SWITCH) ){
			Logger.debug("CRS Hard Prompt Switch is OFF :: Kindly do not populate splash resp", this.getClass());
					
		}else{
			if(MessageSearch.messageActionCRSList.contains(messageSearch.getMessageAction())){
				populateSplashPageResult = new ArrayList();
				//				Call 258
				try{				
					Logger.debug("populateSplashPage CRS Update  ",  this.getClass());
					crsInfo = crsService.getCrsInfo(ibankCommonData);		
					CustomerMessage customerMessage = new CustomerMessage();
					customerMessage.setId(messageSearch.getCustMsgID());
					customerMessage.setMsgID(messageSearch.getMsgID());
					customerMessage.setModifiedBy(ibankCommonData.getCustomer().getGcis());
					customerMessage.setAppField1(messageSearch.getAppField1());
					customerMessage.setGcisNumber(ibankCommonData.getCustomer().getGcis());
					customerMessage.setExpiryDate(messageSearch.getCustMessageExpiry());
					Logger.debug("258 response & crsInfo  : "+crsInfo, this.getClass());
					if(crsInfo != null && !"X".equalsIgnoreCase(crsInfo.getRegistrationNumber())){
						Logger.debug("Inside populateSplashPage : ",this.getClass());
						crsService.updateMsgDeleteStatus(messageSearch,ibankCommonData);
					}
					else{
						if(MessageCentreConstants.SPLASH_ACTION_CRS_HARD_PROMPT_3.equalsIgnoreCase(messageSearch.getMessageAction())){
							Logger.debug("Hard prompt 3",this.getClass());
							showHardPrompt3 = true;
							if(messageSearch.getXrefId() == null){
								Logger.debug("Inside XrefID NULL::>>", this.getClass());
								crsService.updateCRSPromptDetails(ibankCommonData, customerMessage, messageSearch.getMessageAction());
								showSplash=true;
								((LogonResp) serviceResponse).setCustomer(null);
								((LogonResp) serviceResponse).setFirstName(customer.getFirstName());
							}
						}
						else{
							Logger.debug("HP2 or Hp1", this.getClass());
							splashPageResp = new SplashPageResp();
							String hardPromptType = getHardPrompt(messageSearch.getMessageAction());
							splashPageResp.setSplashType(CRS_SPLASH_TYPE); // TODO Remove Hardcode
							splashPageResp.setPromptType(hardPromptType);
							/*if(MessageCentreConstants.SPLASH_ACTION_CRS_HARD_PROMPT_1.equalsIgnoreCase(messageSearch.getMessageAction())){
								Logger.debug("Inside HP1",  this.getClass());
								if(messageSearch.getCustMessageExpiry() != null){
									splashPageResp.setExpiryDate(logonHelper.convertExpiryDateForCRSPrompt(messageSearch.getCustMessageExpiry()));
								}else{
									splashPageResp.setExpiryDate(logonHelper.getExpiryDateForCRSPrompt(messageSearch.getAppField1()!=null?Integer.valueOf(messageSearch.getAppField1()).intValue():0));
						    	}							}else{

								Logger.debug("Inside HP2 or HP3",  this.getClass());
								splashPageResp.setExpiryDate(logonHelper.convertExpiryDateForCRSPrompt(messageSearch.getCustMessageExpiry()));
							}*/
							Date expiryDate = customerMessage.getExpiryDate();
							Logger.debug("ExpiryDate in customer message is "+expiryDate,getClass());
							Logger.debug("XrefID::>>"+messageSearch.getXrefId(), this.getClass());
							if(messageSearch.getXrefId() == null){
								Logger.debug("Inside XrefID NULL::>>", this.getClass());
								splashPageResp.setShowCRSAsTile(false);
								expiryDate = crsService.updateCRSPromptDetails(ibankCommonData, customerMessage, messageSearch.getMessageAction());
								showSplash=true;
							}
							else{
								Logger.debug("Inside XrefID NOT NULL::>>", this.getClass());
								splashPageResp.setShowCRSAsTile(true);
							}
							Logger.debug("Inside HP2 or HP3",  this.getClass());
							splashPageResp.setExpiryDate(logonHelper.convertExpiryDateForCRSPrompt(expiryDate));
						}
															
					}
				} catch(BusinessException e){
					Logger.warn("Business Exception:" + e.getKey() + " Mesage : "+ e.getMessage(), e, this.getClass());
					//saveError(getServletRequest(), e.getKey());		
					splashPageResp = null;		
				}						
				if(serviceResponse != null && serviceResponse instanceof LogonResp){				
					if(null!=customer){
						Logger.debug("Setting customer type ::"+customer.getCustTypeInd(), this.getClass());
						((LogonResp) serviceResponse).setCustTypeInd(customer.getCustTypeInd());
					}
					if(((LogonResp) serviceResponse).getCustomer() != null && null!= splashPageResp){
						Logger.debug("Setting the SplashPageResp in LogonResp", this.getClass());
						((LogonResp) serviceResponse).getCustomer().setSplashPage(splashPageResp);
						
					}else if(null == splashPageResp && showHardPrompt3){
						Logger.debug("Setting showHardPrompt as true b'cuz its HP3", this.getClass());
						((LogonResp) serviceResponse).setShowHardPrompt(showHardPrompt3);
					}
				}
			}
			
			populateSplashPageResult.add(showSplash);
			if(null!= crsInfo){
				populateSplashPageResult.add(crsInfo.getRegistrationNumber());
				Logger.debug("In populateSplashPage :: flag value ::"+crsInfo.getRegistrationNumber(), this.getClass());
			}	
			
		}
		return populateSplashPageResult;
		
	}	

	private String getHardPrompt(String msgActionType ){		
		String hardPromptType =  "";
		switch(msgActionType){
		case "C1":
			hardPromptType = "H1";		   
			return hardPromptType;
		case "C2":
			hardPromptType = "H2";	
			return hardPromptType;
		case "C3":
			hardPromptType = "H3";	
			return hardPromptType;
		default:
			return hardPromptType;
		}
	}

	public Customer getCustomer(IBankCommonData commonData , String statistic) throws BusinessException,
	ResourceException
	{
		//	IBankCommonData commonData = populateIBankCommonData(sessionId,user , origin, ipAddress);
		MobileBankService mobileBankService = (MobileBankService) ServiceHelper.getBean(MBAppConstants.SPRING_MOBILE_SERVICE_BEAN);
		Customer customer = mobileBankService.getCustomer(commonData, statistic);
		return customer;
	}

//	//Create new branded messages for customer & return an unread count
//	private int processMsgCentre(String origin, String gcisNum) throws BusinessException, ResourceException{
//		
//		int unreadMsgCount = -1;
//		
//		if (HeartBeat.isApplicationAvailable(HeartBeat.MSGCENTRE_APPLICATION_ID)) {
//			
//			if ( msgCntrService == null ){
//				msgCntrService = (MobileMsgCntrService) ServiceHelper.getBean("msgCntrService");
//			}
//			
//			OriginsVO originVO= IBankParams.getOrigin(origin);
//			msgCntrService.addBrandCustMsg(originVO.getBankName(),gcisNum);
//			unreadMsgCount = msgCntrService.findMobCustMsgUnreadCount(gcisNum);				
//		}
//		
//		return unreadMsgCount;
//	}
	private /*List<Object>*/ MsgCentreInfo processMsgCentre(String origin, String gcisNum,boolean isECorrespondenceSupported) throws BusinessException, ResourceException{
		OriginsVO originVO= IBankParams.getOrigin(origin);
		msgCntrService.addBrandCustMsg(originVO.getBankName(),gcisNum);
		return msgCntrService.getCustomerMessageInfo(gcisNum,isECorrespondenceSupported, origin);				
	}

	
	public ErrorResp validate(IMBReq serviceRequest, HttpServletRequest request) {
		ErrorResp errorResp = mbAppValidator.validate(serviceRequest, request);
		if ( errorResp.getErrors()!= null && errorResp.getErrors().size() > 1 )
		{
			ArrayList<ErrorInfo> errors = new ArrayList<ErrorInfo>();
			errors.add(errorResp.getErrors().get(0));
			errorResp.setErrors(errors);
		}
		return errorResp;
	}
	public void validateRequestHeader(ReqHeader header, HttpServletRequest request) throws ResourceException
	{
//		MBAppValidator mbAppValidator = new MBAppValidator();
		mbAppValidator.validateRequestHeader(header,  request);
	}
	
	public RespHeader populateResponseHeader(String serviceName, MobileSession mobSession )
	{
		return mbAppHelper.populateResponseHeader(ServiceConstants.CHANGEPWDSECNUM_RESPONSE, mobSession);
	}
	

	private  void sendNotification(MobileSession mobSession) throws ResourceException, BusinessException 
	{
		try{
			User user = mobSession.getUser();
			EmailDetails emailDet = new EmailDetails();
			String emailAddr = null;
			emailDet.setBrand(mobSession.getOrigin());
			emailDet.setActionType(EmailDetails.ACTIV_ACTION);
			emailAddr = mobSession.getCustomer().getContactDetail().getEmail();
			
			if (!StringMethods.isEmptyString(emailAddr)) {
				emailDet.setEmailAddress(emailAddr);
				emailDet.setGcisNumber(user.getGCISNumber());
				EmailService emailService = (EmailService) ServiceHelper.getBean("emailService");
				emailService.sendAlerts(emailDet);
			}
		}catch (Exception e){
			Logger.error("Error Sending Activation email :" + e.getMessage(), ActivationHelper.class);
		}
	}
	
	private ServiceStationVO populateServiceMessage(long insertionPoint,String channel, IBankCommonData commonData)
	{
		ServiceStationVO serviceStationAdminVo=null;
		try
		{
		 serviceStationAdminVo= serviceStationService.getServiceMessage(insertionPoint, ServiceStationImpl.CHANNEL_MOBILE, commonData);			
		}
		 catch(BusinessException ex){
			Logger.error("An error occurred while getting service station message for mobile accoutn details", ex, this.getClass());
		}
		return serviceStationAdminVo;
	}
	
	public boolean isCrsHardPrompt3(/*List<Object>*/ List<MessageSearch> splashPageInfo){
		Logger.debug("Inside isCrsHardPrompt3", this.getClass());
		boolean isCrsHardPrompt3=false;
		if(splashPageInfo.size() > 0){
			
			MessageSearch messageSearch = /*(MessageSearch)*/splashPageInfo.get(0);			
			if(MessageCentreConstants.SPLASH_ACTION_CRS_HARD_PROMPT_3.equalsIgnoreCase(messageSearch.getMessageAction())){
				isCrsHardPrompt3 = true;
			}			
		}
		
		return isCrsHardPrompt3;
	}

	private boolean hasSecureCodeConstraints(Customer customer) {
		
		boolean resp = false;
		
		try{
			if(IBankParams.isGlobalByPass()){
				resp = true;
			}else if (IBankSecureService.isCustomerExempt(customer.getIBankSecureDetails())){
				resp = true;
			}
		}catch (Exception e){
			resp = false;
			Logger.error("Error Logon hasSecureCodeConstraints: " + customer.getGcis(), this.getClass());			
		}
		
		return resp;
	}
	
	@Autowired
	private MobileMsgCntrService msgCntrService;
	
	@Autowired
	private LogonHelper logonHelper;
	
	
	@Autowired
	private MBAppValidator mbAppValidator;

}
