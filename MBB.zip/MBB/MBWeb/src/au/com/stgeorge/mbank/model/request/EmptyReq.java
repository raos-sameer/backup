package au.com.stgeorge.mbank.model.request;

import java.io.Serializable;

import org.apache.commons.lang.builder.ReflectionToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;

import au.com.stgeorge.mbank.model.common.IMBReq;
import au.com.stgeorge.mbank.model.common.ReqHeader;

/**
 * Empty request
 * 
 * @author C38854
 *
 */
public class EmptyReq implements IMBReq, Serializable {
	
	private static final long serialVersionUID = 4763864240678127390L;
//	@Valid TODO
	private ReqHeader header;

	public ReqHeader getHeader() {
		return header;
	}

	public void setHeader(ReqHeader header) {
		this.header = header;
	}
	
	@Override
	public String toString() {
		return ReflectionToStringBuilder.toString(this, ToStringStyle.MULTI_LINE_STYLE);
	}


}
