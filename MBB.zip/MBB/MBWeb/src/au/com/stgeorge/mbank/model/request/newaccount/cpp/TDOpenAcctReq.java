package au.com.stgeorge.mbank.model.request.newaccount.cpp;

import javax.validation.constraints.Pattern;

import au.com.stgeorge.mbank.model.common.IMBReq;
import au.com.stgeorge.mbank.model.common.ReqHeader;

public class TDOpenAcctReq implements IMBReq {

	/**
	 * 
	 */
	private static final long serialVersionUID = -1405917563276004326L;
	
	private ReqHeader header;

	public ReqHeader getHeader() {
		return header;
	}

	public void setHeader(ReqHeader header) {
		this.header = header;
	}	
	protected static final String BLOCK_CHARS_PATTERN = "^[0-9A-Za-z',. &/\\-]*$";
	
	private int tdTerm;
	private String fundsFromAcctIndex;
	private int termDepositProductIndex;
	private String intrPayInst;
	private String intrPayToAcctIndex;
	//private String regionId;
	@Pattern(regexp = BLOCK_CHARS_PATTERN, message = "{errors.branchId.blockchar}")
	private String branchId;
	private String leadIdTda;
	
	//19E3 TFN Changes
	private String selectedOption;
	private String taxFileNumber;
	private String selectedExemption;
	
	
	public String getFundsFromAcctIndex() {
		return fundsFromAcctIndex;
	}

	public void setFundsFromAcctIndex(String fundsFromAcctIndex) {
		this.fundsFromAcctIndex = fundsFromAcctIndex;
	}

	public int getTermDepositProductIndex() {
		return termDepositProductIndex;
	}

	public void setTermDepositProductIndex(int termDepositProductIndex) {
		this.termDepositProductIndex = termDepositProductIndex;
	}

	public String getIntrPayInst() {
		return intrPayInst;
	}

	public void setIntrPayInst(String intrPayInst) {
		this.intrPayInst = intrPayInst;
	}

	public String getIntrPayToAcctIndex() {
		return intrPayToAcctIndex;
	}

	public void setIntrPayToAcctIndex(String intrPayToAcctIndex) {
		this.intrPayToAcctIndex = intrPayToAcctIndex;
	}

//	public String getRegionId() {
//		return regionId;
//	}
//
//	public void setRegionId(String regionId) {
//		this.regionId = regionId;
//	}

	public String getBranchId() {
		return branchId;
	}

	public void setBranchId(String branchId) {
		this.branchId = branchId;
	}

	public int getTdTerm() {
		return tdTerm;
	}

	public void setTdTerm(int tdTerm) {
		this.tdTerm = tdTerm;
	}


    public String getTaxFileNumber() {
		return taxFileNumber;
	}

	public void setTaxFileNumber(String taxFileNumber) {
		this.taxFileNumber = taxFileNumber;
	}

	public String getSelectedExemption() {
		return selectedExemption;
	}

	public void setSelectedExemption(String selectedExemption) {
		this.selectedExemption = selectedExemption;
	}

	public String getSelectedOption() {
		return selectedOption;
	}

	public void setSelectedOption(String selectedOption) {
		this.selectedOption = selectedOption;
	}

	public String getLeadIdTda() {
		return leadIdTda;
	}

	public void setLeadIdTda(String leadIdTda) {
		this.leadIdTda = leadIdTda;
	}	
}
