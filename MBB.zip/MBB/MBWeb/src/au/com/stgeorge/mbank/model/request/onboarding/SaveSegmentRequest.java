package au.com.stgeorge.mbank.model.request.onboarding;

import java.io.Serializable;
import java.util.List;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.NotEmpty;

import au.com.stgeorge.ibank.businessobject.BusinessException;
import au.com.stgeorge.mbank.model.common.IMBReq;
import au.com.stgeorge.mbank.model.common.ReqHeader;

public class SaveSegmentRequest implements IMBReq, Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 94501329694799012L;

	private ReqHeader header;
	
	@NotNull(message = "" + BusinessException.WSVC_INVALID_INPUT_PARAM)
	@NotEmpty(message = "" + BusinessException.WSVC_INVALID_INPUT_PARAM)
	@Size(max = 50, message = "" + BusinessException.WSVC_INVALID_INPUT_PARAM)
	private List<Long> segments;
	
	public List<Long> getSegments() {
		return segments;
	}

	public void setSegments(List<Long> segments) {
		this.segments = segments;
	}

	@Override
	public ReqHeader getHeader() {
		// TODO Auto-generated method stub
		return this.header;
	}

	@Override
	public void setHeader(ReqHeader header) {
		// TODO Auto-generated method stub
		this.header = header;
	}

}
