package au.com.stgeorge.mbank.controller.onlinereg;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.builder.ReflectionToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import au.com.stgeorge.digitalsec.logger.DigitalSecLogger;
import au.com.stgeorge.digitalsec.logger.DigitalSecLogggerVO;
import au.com.stgeorge.framework.common.logging.Logger;
import au.com.stgeorge.framework.common.model.User;
import au.com.stgeorge.framework.common.util.StringMethods;
import au.com.stgeorge.ibank.businessobject.BusinessException;
import au.com.stgeorge.ibank.businessobject.ResourceException;
import au.com.stgeorge.ibank.businessobject.assembler.CustomerVOAssembler;
import au.com.stgeorge.ibank.businessobject.ecorrespondence.ECorrespondenceService;
import au.com.stgeorge.ibank.businessobject.onlinereg.OnlineRegistrationService;
import au.com.stgeorge.ibank.common.cache.IBankParams;
import au.com.stgeorge.ibank.onlinereg.util.OnlineRegStatusEnum;
import au.com.stgeorge.ibank.onlinereg.valueobject.OnlineRegReqLogVO;
import au.com.stgeorge.ibank.onlinereg.valueobject.OnlineRegistrationDetails;
import au.com.stgeorge.ibank.onlinereg.valueobject.RegisterCustomerVO;
import au.com.stgeorge.ibank.service.valueobject.SafiVO;
import au.com.stgeorge.ibank.util.CommonBusinessUtil;
import au.com.stgeorge.ibank.valueobject.Customer;
import au.com.stgeorge.ibank.valueobject.PhoneNumber;
import au.com.stgeorge.ibank.valueobject.collection.LabelValueMap;
import au.com.stgeorge.ibank.valueobject.database.CodesVO;
import au.com.stgeorge.ibank.valueobject.database.OriginsVO;
import au.com.stgeorge.ibank.valueobject.database.SecurityCodeVO;
import au.com.stgeorge.ibank.valueobject.transfer.IBankCommonData;
import au.com.stgeorge.mbank.controller.IMBController;
import au.com.stgeorge.mbank.controller.SecureCodeHelper;
import au.com.stgeorge.mbank.controller.customer.LogonHelper;
import au.com.stgeorge.mbank.model.common.ErrorInfo;
import au.com.stgeorge.mbank.model.common.IMBReq;
import au.com.stgeorge.mbank.model.common.IMBResp;
import au.com.stgeorge.mbank.model.common.ReqHeader;
import au.com.stgeorge.mbank.model.common.RespHeader;
import au.com.stgeorge.mbank.model.request.CustomerRegReq;
import au.com.stgeorge.mbank.model.request.OnlineRegReq;
import au.com.stgeorge.mbank.model.request.SecureCodeReq;
import au.com.stgeorge.mbank.model.response.CustomerRegResp;
import au.com.stgeorge.mbank.model.response.ErrorResp;
import au.com.stgeorge.mbank.model.response.OnlineRegResp;
import au.com.stgeorge.mbank.session.IGenericSession;
import au.com.stgeorge.mbank.session.MobileSession;
import au.com.stgeorge.mbank.session.MobileSessionImpl;
import au.com.stgeorge.mbank.util.MBAppConstants;
import au.com.stgeorge.mbank.util.MBAppHelper;
import au.com.stgeorge.mbank.util.MBAppUtils;
import au.com.stgeorge.mbank.util.MBAppValidator;
import au.com.stgeorge.mbank.util.ServiceConstants;
import au.com.stgeorge.perflogger.PerformanceLogger;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;


@Controller
@RequestMapping("/onlinereg")
public class OnlineRegistrationController implements IMBController {

    @Autowired
    private DigitalSecLogger digitalSecLogger;

    @Autowired
    private MBAppHelper mbAppHelper;

    @Autowired
    private MBAppValidator mbAppValidator;

    @Autowired
    private PerformanceLogger perfLogger;

    @Autowired
    private OnlineRegHelper onlineRegHelper;
    
	@Autowired
	private LogonHelper logonHelper;

	@Autowired
	private SecureCodeHelper secureCodeHelper;	
	
    @Autowired
    private OnlineRegistrationService onlineRegistrationService;
    
    @Autowired
    private DigitalSecLogger digitalSecurityLogger;
    
    @Autowired
    private ECorrespondenceService  eCorrespondenceService;
    
    private static String EMAIL_MASK_REGEX = "(?<!^.?).";
    private static String EMAIL_MASK_CHAR = "*";
    private static String ONLINE_REG_SESSION_ID_PREFIX = "SR_";
    private static String IB_SSO_URL = "/ibank/onlineregsso.action";
    private static String MB_SSO_URL = "onlineregsso";
    private static String SUCCESS = "SUCCESS";
    
    
    @RequestMapping(value = "validate", method = RequestMethod.POST, headers = "content-type=application/json", produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    public IMBResp validateData(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, @RequestBody final OnlineRegReq req) {
	String logName = startPerformanceLog(httpServletRequest);
	String origin = null;
	String status= null;
	IGenericSession genericSession = null;
	MobileSession mobileSession = new MobileSessionImpl();
	DigitalSecLogggerVO digitalSecLoggerVO = new DigitalSecLogggerVO();
	digitalSecLoggerVO.setTranName(DigitalSecLogger.SELFREG_FOR_ONLINE_BANKING);
	try {
	    //origin = req.getOrigin();
	    boolean originTriggerMb = req.isOriginMb();
	    origin = mbAppHelper.getOrigin(httpServletRequest);
	    
	    if(!originTriggerMb)
	    {
		origin = origin.substring(1);
	    }
	    
	    CodesVO codesVo = IBankParams.getCodesData(origin, IBankParams.ONLINE_REG_STATUS, IBankParams.ONLINEREG_SUCCESS_STATUS);
	    if (codesVo != null) {
	    	status = codesVo.getMessage();
	    }
	    digitalSecLoggerVO.setStatus(status);
	    mobileSession.getSessionContext(httpServletRequest);
	    IBankCommonData commonData = new MBAppHelper().populateIBankCommonData(mobileSession, httpServletRequest);
	    String sessionId = null;
	    commonData.setOrigin(origin);
	    digitalSecLoggerVO.setCommonLogData(mbAppHelper.getCommonLogDataForOnlineReg(commonData, sessionId));
	    digitalSecLoggerVO.setUserAgent(commonData.getUserAgent());

	    if (IBankParams.isGlobalByPass()) {
			Logger.info("The 2FA is global security bypassed. Throwing an error", this.getClass());
			throw new BusinessException(BusinessException.ONLINE_REG_FATAL_ERROR);
	    }
	    
	    if (!IBankParams.isSwitchOn(IBankParams.ONLINE_REG_SWITCH)) {
			Logger.info("OnlineRegSwitch is OFF. throwing error", this.getClass());
			throw new BusinessException(BusinessException.ONLINE_REG_FATAL_ERROR);
	    }

	    validateRequestHeader(req.getHeader(), httpServletRequest);
	    ErrorResp errorResponse = validate(req, httpServletRequest);
	    if (errorResponse.hasErrors()){
	    	return errorResponse;
	    }

	    if (origin != null && origin.contains("BSA") && req.getAccessNumber().length() <= 12) {
		if (req.getBsbNumber() == null)
		    throw new BusinessException(BusinessException.EMPTY_BSB_NUMBER);
	    }
	    
	    SecurityCodeVO securityCodeVO = onlineRegHelper.validateCardDobData(httpServletRequest, origin, req);
	    OnlineRegReqLogVO onlineRegReqLogVO = onlineRegHelper.populateOnlineRegReqToVO(req, origin,securityCodeVO);
	    SafiVO safiVO = onlineRegHelper.populateSafiVO(httpServletRequest, onlineRegReqLogVO);
	    digitalSecLoggerVO.setValues(onlineRegReqLogVO.toDigitalSecurityLog());

	    Customer customer = onlineRegistrationService.performChecksAndGetCustomer(commonData, onlineRegReqLogVO, safiVO, digitalSecLoggerVO);
	    commonData.setCustomer(customer);
	    createSession(commonData, onlineRegReqLogVO, httpServletRequest, httpServletResponse,mobileSession, logName);
	    

	    OnlineRegResp serviceResponse = populateResponse(onlineRegReqLogVO, ServiceConstants.ONLINE_REG, mobileSession,commonData,httpServletRequest);
	    serviceResponse.setStatus("SUCCESS");
	    RespHeader headerResp = populateResponseHeader(ServiceConstants.ONLINE_REG, mobileSession);
	    serviceResponse.setHeader(headerResp);
	    Logger.info("validateData :", this.getClass());

	    return serviceResponse;

	} catch (BusinessException e) {
	    Logger.info("BusinessException in OnlineRegistrationController - validateData() - [key: " + e.getKey() + "]", e, this.getClass());

	    if ((e.getKey() == BusinessException.ONLINE_REG_GENERIC_ERROR || e.getKey() == BusinessException.ONLINE_REG_FATAL_ERROR)
	    		&& !DigitalSecLogger.SUCCESS.equalsIgnoreCase(digitalSecLoggerVO.getStatus())) {
		  digitalSecLogger.log(digitalSecLoggerVO);
	    }
	    OriginsVO myOriginVO = IBankParams.getOrigin(origin);
	    OriginsVO baseOrigin = IBankParams.getOrigin(myOriginVO.getBankName());
	    String[] values = { baseOrigin.getPhone() };
	    ErrorResp errorResp = MBAppUtils.createErrorResp(origin, e, values, ServiceConstants.ONLINE_REG, httpServletRequest);
	    if(e.getKey() == BusinessException.ONLINE_REG_FATAL_ERROR){
	    	errorResp.setStatus(ErrorResp.ONLINE_REG_FATAL);
	    }
	    return errorResp;
	} catch (Exception e) {
	    Logger.error("Exception Inside OnlineRegistrationController - validateData() ", e, this.getClass());
	    BusinessException exp = new BusinessException(BusinessException.SYSTEM_UNAVILABLE);
	    IMBResp resp = MBAppUtils.createErrorResp(origin, exp, ServiceConstants.ONLINE_REG, httpServletRequest);
	    return resp;
	} finally {
	    if (genericSession != null) {
		genericSession.updateSession();
	    }
	    endPerformanceLog(logName);
	}
    }

    
    @RequestMapping(method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE, value = "reqsecurecode")
	@ResponseBody
	public IMBResp reqSecureCode(HttpServletRequest httpRequest, @RequestBody final SecureCodeReq request) {
		Logger.debug("OnlineRegistrationController - reqSecureCode(). Request: " + request, this.getClass());
		String logName = startPerformanceLog(httpRequest);
		MobileSession mobileSession = new MobileSessionImpl();
		IBankCommonData commonData = null;
		OnlineRegistrationDetails onlineRegistrationDetails = null;
		PhoneNumber phoneNumber = null;
		try {
			mobileSession.getSessionContext(httpRequest);
			mobileSession.removeDigitalSecLoggerMap();
			commonData = new MBAppHelper().populateIBankCommonData(mobileSession, httpRequest);
			
			validateRequestHeader(request.getHeader(), httpRequest);
			ErrorResp errorResponse = validate(request, httpRequest);// validate json
			if (errorResponse.hasErrors())
				return errorResponse;
			
			if (ServiceConstants.ONLINE_REG_TRAN_CODE != request.getTranType()){
				return MBAppUtils.createInvalid2FATransactionTypeResponse(ServiceConstants.REQ_2FA_ONLINEREG);
			}
			OnlineRegReqLogVO onlineRegReqLogVO =new OnlineRegReqLogVO();			
			onlineRegistrationDetails = mobileSession.getOnlineRegistrationDetails();
			onlineRegReqLogVO.setOnlineRegCardAcctInfoID(onlineRegistrationDetails.getOnlineRegCardAcctInfoID());
			LabelValueMap digitalSecLoggerMap = new LabelValueMap();
			digitalSecLoggerMap.put(DigitalSecLogger.AUTHTYPE, request.getDeliveryMethod());
			phoneNumber = CommonBusinessUtil.get2FAPhoneNumber(commonData, request.getPhone());
			digitalSecLoggerMap.put(DigitalSecLogger.AUTHPHONE, phoneNumber.getAreaCode()+phoneNumber.getPhoneNumber());
			mobileSession.setDigitalSecLoggerMap(digitalSecLoggerMap);
			
			return secureCodeHelper.reqSecureCode(commonData, mobileSession, null, onlineRegistrationDetails, request, ServiceConstants.REQ_2FA_ONLINEREG, httpRequest);
		} catch (ResourceException e) {
			Logger.error("ResourceException in OnlineRegistrationController - reqSecureCode() - [key: " + e.getKey() + "], GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());
			mobileSession.removeSecureCodeDetails();
			return MBAppUtils.createErrorResp("ALL", BusinessException.SYSTEM_UNAVILABLE, ServiceConstants.REQ_2FA_ONLINEREG, httpRequest);
		}
		catch (Exception e) {
			Logger.error("Exception OnlineRegistrationController - reqSecureCode(): GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "]", e, this.getClass());
			mobileSession.removeSecureCodeDetails();
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.GENERIC_ERROR, ServiceConstants.REQ_2FA_ONLINEREG, httpRequest);
		} finally {
			endPerformanceLog(logName);
		}

	}	
    
    
	@RequestMapping(method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE, value = "verifysecurecode")
	@ResponseBody
	public IMBResp verifySecureCode(HttpServletRequest httpRequest, @RequestBody final SecureCodeReq request) {
		Logger.debug("OnlineRegistrationController - verifySecureCode(). Request: " + request, this.getClass());
		String logName = startPerformanceLog(httpRequest);
		MobileSession mobileSession = new MobileSessionImpl();
		DigitalSecLogggerVO digitalSecLoggerVO =new DigitalSecLogggerVO();
		try {
			mobileSession.getSessionContext(httpRequest);
			IBankCommonData commonData = new MBAppHelper().populateIBankCommonData(mobileSession, httpRequest);
			validateRequestHeader(request.getHeader(), httpRequest);
			ErrorResp errorResponse = validate(request, httpRequest);// validate json
			if (errorResponse.hasErrors())
				return errorResponse;

			if (ServiceConstants.ONLINE_REG_TRAN_CODE != request.getTranType()){
				return MBAppUtils.createInvalid2FATransactionTypeResponse(ServiceConstants.REQ_2FA_ONLINEREG);
			}			
			OnlineRegistrationDetails onlineRegistrationDetails = mobileSession.getOnlineRegistrationDetails();
			 OnlineRegReqLogVO onlineRegReqLogVO =new OnlineRegReqLogVO();
			    onlineRegReqLogVO.setOnlineRegReqLogID(onlineRegistrationDetails.getOnlineRegReqLogId());
			errorResponse = secureCodeHelper.verifySecureCode(commonData, mobileSession, onlineRegistrationDetails, request, ServiceConstants.VERIFY_2FA_PWDRESET, httpRequest);
			if (errorResponse.hasErrors()) {
			    digitalSecLoggerVO.setCommonLogData(mbAppHelper.getCommonLogDataForOnlineReg(commonData, mobileSession.getSessionID()));
			    digitalSecLoggerVO.setUserAgent(commonData.getUserAgent()); 
			    digitalSecLoggerVO.setTranName(DigitalSecLogger.SELFREG_FOR_ONLINE_BANKING);
			    digitalSecLoggerVO.setStatus(DigitalSecLogger.FAILURE_2FA);
			    onlineRegistrationService.updateRequestStatus(onlineRegReqLogVO, OnlineRegStatusEnum.FAIL_2FA_COUNTER,onlineRegistrationDetails.getGcis());
			    LabelValueMap digitalSecMap = mobileSession.getDigitalSecLoggerMap();
			    digitalSecLoggerVO.setValues(onlineRegistrationDetails.toDigitalSecurityLog(digitalSecMap.get(DigitalSecLogger.AUTHTYPE),digitalSecMap.get(DigitalSecLogger.AUTHPHONE)));
			    digitalSecurityLogger.log(digitalSecLoggerVO);
			    return errorResponse;
			} else{
				//set the logged on state to 2FA done
				mobileSession.setLoggedonState(LogonHelper.LOGGEDON_STATE_ONLINE_REGISTRATION_2FA);
				OnlineRegResp resp = new OnlineRegResp();
				onlineRegistrationService.updateRequestStatus(onlineRegReqLogVO, OnlineRegStatusEnum.SUCCESS,onlineRegistrationDetails.getGcis());
				resp.setStatus(SUCCESS);
				//set a value in session if 2fa verification is successful. This will be used to validate in reset pwd and sec num
				mobileSession.setSecureCodeVerifiedTranName(ServiceConstants.REQ_2FA_PWDRESET);
				return resp;
			}
			
		} catch (ResourceException e) {
			Logger.error("Exception OnlineRegistrationController - verifySecureCode(): GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "]", e, this.getClass());
			mobileSession.removeTransaction();
			mobileSession.removeSecureCodeDetails();
			return MBAppUtils.createErrorResp("ALL", BusinessException.SYSTEM_UNAVILABLE, ServiceConstants.VERIFY_2FA_PWDRESET, httpRequest);
		} 
		catch (Exception e) {
			Logger.error("Exception OnlineRegistrationController - verifySecureCode(): GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "]", e, this.getClass());
			mobileSession.removeTransaction();
			mobileSession.removeSecureCodeDetails();
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.GENERIC_ERROR, ServiceConstants.VERIFY_2FA_PWDRESET, httpRequest);
		} finally {
			endPerformanceLog(logName);
		}

	}	
    
    
	@RequestMapping(value="registercustomer", method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public IMBResp registerCustomer(HttpServletRequest httpRequest, HttpServletResponse httpServletResponse, @RequestBody final CustomerRegReq request){
		Logger.debug("OnlineRegistrationController - registerCustomer(). Request: " + request, this.getClass());
		String logName = startPerformanceLog(httpRequest);
		MobileSession mobileSession = new MobileSessionImpl();
		String status=null;
		String origin = null;
		try {
			//origin = mbAppHelper.getOrigin(httpRequest);
			mobileSession.getSessionContext(httpRequest);
			origin = mobileSession.getOrigin();
			
			IBankCommonData commonData = new MBAppHelper().populateIBankCommonData(mobileSession, httpRequest);
			//origin = commonData.getOrigin();

			DigitalSecLogggerVO digitalSecLoggerVO =new DigitalSecLogggerVO();
			digitalSecLoggerVO.setTranName(DigitalSecLogger.SELFREG_FOR_ONLINE_BANKING);
			
			 CodesVO codesVo = IBankParams.getCodesData(origin, IBankParams.ONLINE_REG_STATUS, IBankParams.ONLINEREG_SUCCESS_STATUS);
			    if (codesVo != null) {
			    	status = codesVo.getMessage();
			    }
			digitalSecLoggerVO.setStatus(status);
			digitalSecLoggerVO.setUserAgent(commonData.getUserAgent());
			
			validateRequestHeader(request.getHeader(), httpRequest);
			ErrorResp errorResponse = validate(request, httpRequest);// validate json
		    if (errorResponse.hasErrors()){
		    	List<ErrorInfo> errors = errorResponse.getErrors();
		    	List<ErrorInfo> uniqueErrors = new ArrayList<ErrorInfo>(new HashSet<ErrorInfo>(errors));
		    	errorResponse.setErrors(uniqueErrors);
		    	return errorResponse;
		    }
		    
		    
		    SecurityCodeVO securityCodeVO = onlineRegHelper.validateAuthenticationData(httpRequest,origin,request);
			OnlineRegistrationDetails onlineRegistrationDetails = mobileSession.getOnlineRegistrationDetails();
			RegisterCustomerVO registerCustomerVO = onlineRegHelper.populateRegisterCustomerVO(request, onlineRegistrationDetails,origin,securityCodeVO);
			// The ECorrespondenceConsent is null in case of Non GHS customers
			// Update Preferences table only when the ECorrespondenceConsent object is set from UI (GHS and GHS Primary Customer)
			
			
			//CSH Auto Reg changes : If customer is not registered, proceed with CSH WDP API reg flow, else existing flow.
			//If CSH switch is ON only, calling IDM enquiry to check customer is not registered
			//Below logic is moved from service to controller, to send same flag to UI.
			boolean isRegistered = false;
			boolean cshAutoRegFlag = false;
			if(IBankParams.isSwitchOn(IBankParams.DEFAULT_ORIGIN, IBankParams.CSH_AUTO_REG_SWITCH)) {
				isRegistered = onlineRegistrationService.isCustomerRegistered(commonData.getCustomer());
				if(!isRegistered) {
					cshAutoRegFlag = true;
				}
			}
					
			//String can = onlineRegistrationService.registerCustomer(commonData,registerCustomerVO, isRegistered);
			String can = onlineRegistrationService.registerCustomer(commonData,registerCustomerVO, isRegistered,true);
			
			if(IBankParams.isSwitchOn(IBankParams.ECORRESPONDENCE_SWITCH)){
				if (null != request.geteCorrespondenceConsent()) {
					eCorrespondenceService.updateConsentPrefAndStatisticsLog(commonData, ECorrespondenceService.REGISTRATION_SOURCE,request.geteCorrespondenceConsent());
					Logger.debug(
							"OnlineRegistrationController - registerCustomer() Updated the Ecorrespondence Preference table and GDW entry for GCIS: "
									+ commonData.getCustomer().getGcis(), this.getClass());
				}
			}
			mobileSession.setLoggedonState(LogonHelper.LOGGEDON_STATE_COMPLETE);
			
			Customer customer = commonData.getCustomer();
			CustomerRegResp customerRegResp = new CustomerRegResp();
			customerRegResp.setCan(can);
			customerRegResp.setCshAutoRegFlag(cshAutoRegFlag);
			
			/*if(!origin.startsWith("M"))
			{
				String jwtToken=onlineRegistrationService.getSignedJWTForOnlineReg(customer.getGcis(), mobileSession.getSessionID(),origin );
				customerRegResp.setJwtToken(jwtToken);
				customerRegResp.setTargetURL(IB_SSO_URL);
			}
			else {
			    customerRegResp.setTargetURL(MB_SSO_URL);
			}*/
			customerRegResp.setFirstName(customer.getFirstName());

			commonData.getUser().setUserId(can);
			
			digitalSecLoggerVO.setCommonLogData(mbAppHelper.getCommonLogData(commonData));
			LabelValueMap digitalSecMap = mobileSession.getDigitalSecLoggerMap();
			digitalSecLoggerVO.setValues(onlineRegistrationDetails.toDigitalSecurityLog(digitalSecMap.get(DigitalSecLogger.AUTHTYPE),digitalSecMap.get(DigitalSecLogger.AUTHPHONE)));
			digitalSecLogger.log(digitalSecLoggerVO);			
			
			RespHeader headerResp = populateResponseHeader(ServiceConstants.ONLINE_REG, null);
			customerRegResp.setHeader(headerResp);
			onlineRegHelper.deleteSecurityCodeVO(origin,request);//Delete SecurityCode Data after successful validation
		
			return customerRegResp;
			
		}catch(BusinessException e) {
			Logger.error("Exception OnlineRegistrationController - registerCustomer(): GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "]", e, this.getClass());
			mobileSession.removeTransaction();
			mobileSession.removeSecureCodeDetails();
			return MBAppUtils.createErrorResp("ALL", e.getKey(), ServiceConstants.ONLINE_REG, httpRequest);
		}catch (ResourceException e) {
			Logger.error("Exception OnlineRegistrationController - registerCustomer(): GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "]", e, this.getClass());
			mobileSession.removeTransaction();
			mobileSession.removeSecureCodeDetails();
			return MBAppUtils.createErrorResp("ALL", BusinessException.SYSTEM_UNAVILABLE, ServiceConstants.ONLINE_REG, httpRequest);
		} catch (Exception e) {
			Logger.error("Exception OnlineRegistrationController - registerCustomer(): GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "]", e, this.getClass());
			mobileSession.removeTransaction();
			mobileSession.removeSecureCodeDetails();
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.GENERIC_ERROR, ServiceConstants.ONLINE_REG, httpRequest);
		} finally {
			mobileSession.removeDigitalSecLoggerMap();
			endPerformanceLog(logName);
		}
	
	}
	
	@RequestMapping(value="continueSSO", method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE)
	      @ResponseBody
	      public IMBResp continueSSO(HttpServletRequest httpRequest, HttpServletResponse httpServletResponse){
	            //Logger.debug("OnlineRegistrationController - continuesso(). Request: " + request, this.getClass());
	            String logName = startPerformanceLog(httpRequest);
	            MobileSession mobileSession = new MobileSessionImpl();
	            String origin = null;
	            try {
	                  mobileSession.getSessionContext(httpRequest);
	                  origin = mobileSession.getOrigin();
	                  
	                  IBankCommonData commonData = new MBAppHelper().populateIBankCommonData(mobileSession, httpRequest);
	                  //validateRequestHeader(request.getHeader(), httpRequest);
	                  //ErrorResp errorResponse = validate(request, httpRequest);// validate json
	                /*if (errorResponse.hasErrors()){
	                  List<ErrorInfo> errors = errorResponse.getErrors();
	                  List<ErrorInfo> uniqueErrors = new ArrayList<ErrorInfo>(new HashSet<ErrorInfo>(errors));
	                  errorResponse.setErrors(uniqueErrors);
	                  return errorResponse;
	                }*/
	                  Customer customer = commonData.getCustomer();
	                  CustomerRegResp customerRegResp = new CustomerRegResp();
	            
	                  if(!origin.startsWith("M"))
	                  {
	                        String jwtToken=onlineRegistrationService.getSignedJWTForOnlineReg(customer.getGcis(), mobileSession.getSessionID(),origin );
	                        customerRegResp.setJwtToken(jwtToken);
	                        customerRegResp.setTargetURL(IB_SSO_URL);
	                  }
	                  else {
	                      customerRegResp.setTargetURL(MB_SSO_URL);
	                  }
	                  return customerRegResp;
	                  
	            } catch (ResourceException e) {
	                  Logger.error("Exception OnlineRegistrationController - continuesso(): GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "]", e, this.getClass());
	                  mobileSession.removeTransaction();
	                  mobileSession.removeSecureCodeDetails();
	                  return MBAppUtils.createErrorResp("ALL", BusinessException.SYSTEM_UNAVILABLE, ServiceConstants.ONLINE_REG, httpRequest);
	            } catch (Exception e) {
	                  Logger.error("Exception OnlineRegistrationController - continuesso(): GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "]", e, this.getClass());
	                  mobileSession.removeTransaction();
	                  mobileSession.removeSecureCodeDetails();
	                  return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.GENERIC_ERROR, ServiceConstants.ONLINE_REG, httpRequest);
	            } finally {
	                  endPerformanceLog(logName);
	            }
	      
	      }

	

    @Override
    public void validateRequestHeader(ReqHeader headerReq, HttpServletRequest request) throws BusinessException {
		Logger.debug("Request header validation: " + ReflectionToStringBuilder.toString(headerReq, ToStringStyle.MULTI_LINE_STYLE), this.getClass());
		new MBAppValidator().validateRequestHeader(headerReq, request);
    }

    public ErrorResp validate(IMBReq serviceRequest, HttpServletRequest request) {
		Logger.info("Service request object - " + ReflectionToStringBuilder.toString(serviceRequest), this.getClass());
		return mbAppValidator.validate(serviceRequest, request);
    }

    @Override
    public RespHeader populateResponseHeader(String serviceName, MobileSession mobileSession) {
    	return mbAppHelper.populateResponseHeader(serviceName, mobileSession);
    }

    private String startPerformanceLog(HttpServletRequest httpRequest) {
		perfLogger.startAllLogs();
		String logName = MBAppUtils.getLogName(httpRequest);
		perfLogger.startLog(logName);
		return logName;
    }

    private void endPerformanceLog(String logName) {
		perfLogger.endLog(logName);
		perfLogger.endAllLogs();
    }


	private void createSession(IBankCommonData commonData, OnlineRegReqLogVO onlineRegReqVO, HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse,MobileSession mbsession, String logName) throws BusinessException{
		IGenericSession genericSession = null ;
		User myUser = commonData.getUser(); 		
		
		if(onlineRegReqVO.getIsCard()){
			String card = onlineRegReqVO.getAcctNum() + onlineRegReqVO.getIssueNum();
			myUser.setAttribute(IBankParams.USEROBJ_CARDNUMBER, card);		
		}

		myUser.setAttribute(IBankParams.USEROBJ_IPADDRESS, commonData.getIpAddress());
		commonData.setUser(myUser);
		
		commonData.setOrigin(onlineRegReqVO.getOrigin());

		OnlineRegistrationDetails onlineRegistrationDetails = new OnlineRegistrationDetails();
		onlineRegistrationDetails.setGcis(onlineRegReqVO.getGcisNumber());
		onlineRegistrationDetails.setIsCard(onlineRegReqVO.getIsCard());
		onlineRegistrationDetails.setOnlineRegReqLogId(onlineRegReqVO.getOnlineRegReqLogID());
		onlineRegistrationDetails.setOnlineRegCardAcctInfoID(onlineRegReqVO.getOnlineRegCardAcctInfoID());
		onlineRegistrationDetails.setCardBSBAcctInfoConcat(onlineRegReqVO.getCardAcctNum());
		onlineRegistrationDetails.setBsb(onlineRegReqVO.getBSB());
		onlineRegistrationDetails.setCardAcctNum(onlineRegReqVO.getCardAcctNum());
		onlineRegistrationDetails.setAcctNum(onlineRegReqVO.getAcctNum());
		onlineRegistrationDetails.setBranchKey(onlineRegReqVO.getBranchKey());
		onlineRegistrationDetails.setIssueNum(onlineRegReqVO.getIssueNum());
		onlineRegistrationDetails.setDob(onlineRegReqVO.getDOB());
		onlineRegistrationDetails.setIsAlreadyRegistered(onlineRegReqVO.isAlreadyRegistered());
		
		
		try{
			genericSession = logonHelper.createCompassSession(myUser, commonData.getOrigin(), "WebSrv", httpServletRequest, ONLINE_REG_SESSION_ID_PREFIX);			
			genericSession.setAttribute(MobileSessionImpl.CUSTOMER_OBLECT, commonData.getCustomer());
			genericSession.setAttribute(MobileSessionImpl.ORIGIN_OBLECT, commonData.getOrigin());	
			genericSession.setAttribute(MobileSessionImpl.ONLINE_REGISTRATION_DETAILS, onlineRegistrationDetails);
			genericSession.setLoggedonState(LogonHelper.LOGGEDON_STATE_ONLINE_REGISTRATION);
			Logger.info("***User-Agent: " +  "***SessionId: " + genericSession.getId(), this.getClass());
			httpServletResponse.setHeader("Set-Cookie", MBAppConstants.ONLINE_REG_SESS_CONSTANT + "=" + genericSession.getId()   + "; HttpOnly ; Secure    " + "; path=/mb");		
		} catch (Exception e){
			Logger.error("Exception Inside createSession() ", e, this.getClass());
			throw new BusinessException(BusinessException.SYSTEM_UNAVILABLE);
		} finally {
			if ( genericSession != null )
				genericSession.updateSession();				
		}		
	}
	

	private OnlineRegResp populateResponse(OnlineRegReqLogVO onlineRegReqVO, String serviceName, MobileSession mbsession,IBankCommonData commonData,HttpServletRequest request) throws JsonParseException, JsonMappingException, IOException{
		OnlineRegResp resp = new OnlineRegResp();
		resp.setSecureCodeInfo(onlineRegHelper.populateSecureCodeResponse(onlineRegReqVO.getSecureCodeDetails()));
		String email = "";
		if(!StringMethods.isEmptyString(onlineRegReqVO.getEmail())){
			email = onlineRegReqVO.getEmail();
			String emailStart = email.substring(0,email.indexOf("@"));
			String emailEnd = email.substring(email.indexOf("@"));
			emailStart = emailStart.replaceAll(EMAIL_MASK_REGEX, EMAIL_MASK_CHAR);
			email = emailStart + emailEnd;
		}
		//E-correspondence Check Box for the consent capture
		if(CommonBusinessUtil.isECorrespondenceSupported(request)){
			if(null != commonData.getCustomer() && commonData.getCustomer().isCustomerOfTypeGHS() &&
					CustomerVOAssembler.PERSONAL_CUSTOMER.equals(commonData.getCustomer().getCustTypeInd())) {
				resp.seteCorConsentCaptureRequired(true);
			}
		}
		resp.setEmail(email);
		return resp;
	}

}
