package au.com.stgeorge.mbank.model.request.payments;

import org.apache.commons.lang.builder.ReflectionToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;
import org.hibernate.validator.constraints.Length;

public class DonationTransferReq extends TransferReq {

	private static final long serialVersionUID = -5925462050152885499L;
	
	@Length(max = 140, message = "{errors.payerName.maxlength}")
	private String payerName;

	private String devicePrint;	
	
	public String getDevicePrint() {
		return devicePrint;
	}

	public void setDevicePrint(String devicePrint) {
		this.devicePrint = devicePrint;
	}

	public String getPayerName() {
		return payerName;
	}

	@Override
	public String toString() {
		return ReflectionToStringBuilder.toString(this, ToStringStyle.MULTI_LINE_STYLE);
	}

}