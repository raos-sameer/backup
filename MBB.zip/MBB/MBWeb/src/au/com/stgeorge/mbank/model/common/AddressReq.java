package au.com.stgeorge.mbank.model.common;

import javax.validation.constraints.Pattern;

import au.com.stgeorge.ibank.businessobject.BusinessException;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
@JsonInclude(Include.NON_NULL)
public class AddressReq
{
	private static final String VALID_CHAR_SET = "^[0-9A-Za-z'\\-,. &/]*$";
  private String addrType;
	
  //@NotEmpty (message = ""+BusinessException.WSVC_INVALID_INPUT_PARAM)
  @Pattern(regexp="^[0-9A-Za-z',. &;/]*-?[0-9A-Za-z',. &;/]*$",message = ""+BusinessException.SMPL_INV_INP_PARAMS)
  private String line1;
  
  @Pattern(regexp="^[0-9A-Za-z',. &;/]*-?[0-9A-Za-z',. &;/]*$",message = ""+BusinessException.SMPL_INV_INP_PARAMS)
  private String line2;
  
  @Pattern(regexp="^[0-9A-Za-z',. &;/]*-?[0-9A-Za-z',. &;/]*$",message = ""+BusinessException.SMPL_INV_INP_PARAMS)
  private String line3;
  
  @Pattern(regexp=VALID_CHAR_SET,message = ""+BusinessException.SMPL_INV_INP_PARAMS)
  private String suburb;
  
  @Pattern(regexp="^[0-9A-Za-z',. &;/]*-?[0-9A-Za-z',. &;/]*$",message = ""+BusinessException.SMPL_INV_INP_PARAMS)
  private String state;
  
  @Pattern(regexp="^[0-9A-Za-z',. &;/]*-?[0-9A-Za-z',. &;/]*$",message = ""+BusinessException.SMPL_INV_INP_PARAMS)
  private String postCode;
  
  private String countryName;
  
  
  public String getAddrType()
	{
		return addrType;
	}
	public void setAddrType(String addrType)
	{
		this.addrType = addrType;
	}
	public String getLine1()
	{
		return line1;
	}
	public void setLine1(String line1)
	{
		this.line1 = line1;
	}
	public String getLine2()
	{
		return line2;
	}
	public void setLine2(String line2)
	{
		this.line2 = line2;
	}
	public String getLine3()
	{
		return line3;
	}
	public void setLine3(String line3)
	{
		this.line3 = line3;
	}
	public String getSuburb()
	{
		return suburb;
	}
	public void setSuburb(String suburb)
	{
		this.suburb = suburb;
	}
	public String getState()
	{
		return state;
	}
	public void setState(String state)
	{
		this.state = state;
	}
	public String getPostCode()
	{
		return postCode;
	}
	public void setPostCode(String postCode)
	{
		this.postCode = postCode;
	}
	public String getCountryName()
	{
		return countryName;
	}
	public void setCountryName(String countryName)
	{
		this.countryName = countryName;
	}
	
	
}
