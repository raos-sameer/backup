/**
 * 
 */
package au.com.stgeorge.mbank.controller.categorisation;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;

import au.com.stgeorge.framework.common.logging.Logger;
import au.com.stgeorge.ibank.businessobject.BusinessException;
import au.com.stgeorge.ibank.businessobject.ResourceException;
import au.com.stgeorge.ibank.businessobject.categorisation.CategorisationService;
import au.com.stgeorge.ibank.common.cache.IBankParams;
import au.com.stgeorge.ibank.valueobject.Account;
import au.com.stgeorge.ibank.valueobject.AccountingTransactionHistory;
import au.com.stgeorge.ibank.valueobject.Customer;
import au.com.stgeorge.ibank.valueobject.LabelValueVO;
import au.com.stgeorge.ibank.valueobject.Statistic;
import au.com.stgeorge.ibank.valueobject.TranHistoryByMonth;
import au.com.stgeorge.ibank.valueobject.TransactionHistory;
import au.com.stgeorge.ibank.valueobject.TransactionInfo;
import au.com.stgeorge.ibank.valueobject.database.CodesVO;
import au.com.stgeorge.ibank.valueobject.transfer.IBankCommonData;
import au.com.stgeorge.mbank.controller.IMBController;
import au.com.stgeorge.mbank.model.common.IMBReq;
import au.com.stgeorge.mbank.model.common.IMBResp;
import au.com.stgeorge.mbank.model.common.ReqHeader;
import au.com.stgeorge.mbank.model.common.RespHeader;
import au.com.stgeorge.mbank.model.request.categorisation.TranCategorisationReq;
import au.com.stgeorge.mbank.model.request.categorisation.TranCategorisationStatReq;
import au.com.stgeorge.mbank.model.response.ErrorResp;
import au.com.stgeorge.mbank.model.response.SuccessResp;
import au.com.stgeorge.mbank.session.MobileSession;
import au.com.stgeorge.mbank.util.MBAppHelper;
import au.com.stgeorge.mbank.util.MBAppUtils;
import au.com.stgeorge.mbank.util.MBAppValidator;
import au.com.stgeorge.mbank.util.ServiceConstants;
import au.com.stgeorge.perflogger.PerformanceLogger;
import au.com.stgeorge.security.util.StringMethods;
import au.com.stgeorge.tranhistory.valueobject.TranCategorisationDetailVO;



import com.fasterxml.jackson.databind.ObjectMapper;


/**
 * @author C69727
 *
 */

@Controller
@RequestMapping("/tran")
public class TransactionCategorisationController implements IMBController{
	
	@Autowired
	private TransactionCategorisationHelper tranCategorisationHelper;
	
	@Autowired
	private MBAppHelper mbAppHelper;
	
	@Autowired
	private MBAppValidator mbAppValidator;
		
	@Autowired
	private PerformanceLogger perfLogger;
	
	@Autowired
	private CategorisationService categorisationService;
	
	@RequestMapping(value= "categorisation" , method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public IMBResp processTransactioncategorisation(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse,
			@RequestBody final TranCategorisationReq req)
	{				
				
		ObjectMapper objectMapper = new ObjectMapper();				
		TransactionHistory trxnHist = null;
		
		perfLogger.startAllLogs();
		String logName = MBAppUtils.getLogName(httpServletRequest);
		perfLogger.startLog(logName);
		
		//fraudLogger = new FraudLogger();
		MobileSession mbSession = null;
		
		int monthsForErrorMessage = IBankParams.SIX_MONTH_MSG;
		
		Map<Integer,Date> monthsList = null;
		try{	
			
			mbSession = mbAppHelper.getMobileSession(httpServletRequest);		
			Logger.info("tran Categorisation JSON Request :" + objectMapper.writeValueAsString(req), this.getClass());
			validateRequestHeader(req.getHeader(), httpServletRequest);
			ErrorResp errorResp = validate(req, httpServletRequest);
			if (errorResp != null && errorResp.getErrors() != null && errorResp.getErrors().size() > 0)
			{				
				//fraudLogger.logInvalidInput();
				return errorResp;
			}
			
			int myAcctIndex = req.getAccountIndex();
			Customer customer=mbSession.getCustomer();			
						
			Account selectedAcct=mbAppHelper.getAccountFromCustomer(customer, myAcctIndex);
			
			IBankCommonData commonData=null;
			TranCategorisationDetailVO tranCategorisationDetail = null;
			
			
			if(selectedAcct!=null){
				
				commonData=mbAppHelper.populateIBankCommonData(mbSession,httpServletRequest);
				
				boolean isExtendTranHistSwitchOn = IBankParams.isExtendTranHistSwitchOn(commonData.getOrigin(), selectedAcct.getAccountId().getApplicationId(), customer.getGcis());
				
				if(isExtendTranHistSwitchOn){
					monthsForErrorMessage = IBankParams.TWELVE_MONTH_MSG;
				}
						
				monthsList = categorisationService.getCategorisationMonths(commonData, selectedAcct);
				
				if(monthsList != null && monthsList.size() > 0){
					DateFormat DATE_FORMATTER =  new SimpleDateFormat("yyyyMM");
					Calendar startDate = Calendar.getInstance();
					Integer monthReq = Integer.parseInt(DATE_FORMATTER.format(startDate.getTime()).toString());
					Date fromDate =null;
					if(req.getMonth() != null){
						monthReq = req.getMonth();
					}
					fromDate  = monthsList.get(monthReq);
					
							if(fromDate != null){
							//Only for CRA and DDA AppId 
							if ( Account.CRA.equalsIgnoreCase(selectedAcct.getAccountId().getApplicationId()) || Account.DDA.equalsIgnoreCase(selectedAcct.getAccountId().getApplicationId())){
								TranHistoryByMonth tranHistoryByMonth = null;
								tranHistoryByMonth = getTranHistForMonthFromSession( fromDate, mbSession );
								if ( tranHistoryByMonth == null )
								{
									perfLogger.startLog("getTranHistoryForCategorisation from jar");
									Logger.debug("Getting TransactionHistory list from Jar  ...", this.getClass());
									trxnHist = categorisationService.getTranHistoryForCategorisation(selectedAcct.getAccountId(), commonData, fromDate);
									//tranCategorisationHelper.updateTransactionHistoryInSession(null , fromDate , trxnHist, mbSession);
									perfLogger.endLog("getTranHistoryForCategorisation from jar");
								}
		
								else
								{
									if ( "F".equalsIgnoreCase(tranHistoryByMonth.getStatus()) )
									{
										Logger.debug("Using Session data ...", this.getClass());
										trxnHist  = tranHistoryByMonth.getTransactionHistory();
									}
									else
									{
										perfLogger.startLog("getTranHistoryForCategorisation from jar P");
										Logger.debug("Getting TransactionHistory list from Jar  ...", this.getClass());
										trxnHist = categorisationService.getTranHistoryForCategorisation(selectedAcct.getAccountId(), commonData, fromDate);
										//updateTransactionHistoryInSession(tranHistoryByMonth , fromDate , trxnHist, mbSession);
										perfLogger.endLog("getTranHistoryForCategorisation from jar P");
									}
								}
									 
									
								}else{
									throw new BusinessException(BusinessException.NO_INFORMATION,"Transaction Categoriation is available only for CRA and DDA accounts. Selected account is : "+selectedAcct.getAccountId().getApplicationId());
									}
									
							//For Graph
							//if(trxnHist != null && trxnHist.getTransactions() != null && trxnHist.getTransactions().size() > 0){
							if(trxnHist != null && trxnHist.getTransactions() != null && trxnHist.getTransactions().size() > 0){						
								tranCategorisationDetail= categorisationService.getCategoryDetail(trxnHist.getTransactions(), selectedAcct.getAccountId().getApplicationId());
							}
							else{
								trxnHist = null;//If there are no transactions also, empty object is coming. So, making trxnHist = null, to avoid populating history response. 
							}
						}
						else{
							throw new BusinessException(BusinessException.CATEGORISATION_UNAVAILABLE,"Invalid Month.");
						}
				}
				else
					throw new BusinessException(BusinessException.NO_INFORMATION,"Error while getting Eligible Months.");
			}
			else
				throw new BusinessException(BusinessException.NO_INFORMATION,"Error while getting selected account information.");
			
			String action = Statistic.TRAN_CATE_CATEGORY;
			String desc = IBankParams.BLANK_STRING;
			
			boolean validCategory = false;
			String categoryName = req.getCategoryName();
			
			try{
				if(!StringMethods.isEmptyString(categoryName)){//If request comes from Transaction details, statistic logging will be done for Sub Category else for Category.
				
					validCategory = categorisationService.validateCategoryName(categoryName, selectedAcct.getAccountId().getApplicationId());
					
					if(validCategory){
					action = Statistic.TRAN_CATE_SUB_CATEGORY;
						if(req.isDebit() != null){
							if(req.isDebit()){
								categoryName = CategorisationService.SPENDINGS+"|"+categoryName;
							}
							else{
								categoryName = CategorisationService.DEPOSITS+"|"+categoryName;
							}
						}
						else{
							throw new Exception("Not a valid category type.");
						}
					desc = categoryName;
					}
					else{
						throw new Exception("Not a valid category.");
					}
					
				}
			categorisationService.logStatistic(selectedAcct, commonData, action, desc);
			}
			catch(Exception e){
				Logger.error(" Unable to create statistics entry in categorisation() for Categorisation info. ", this.getClass());
			}
			
			
			IMBResp serviceResponse = null;	
			if(req.isMonthDataReq() != null && req.isMonthDataReq() == true){
				serviceResponse = tranCategorisationHelper.populateResp(mbSession, trxnHist, tranCategorisationDetail, monthsList, commonData, selectedAcct.getAccountId().getApplicationId());
			}
			else{
			serviceResponse = tranCategorisationHelper.populateResp(mbSession, trxnHist, tranCategorisationDetail, null, commonData, selectedAcct.getAccountId().getApplicationId());
			}

			RespHeader headerResp = populateResponseHeader(ServiceConstants.TRAN_CATEGORIATION_SERVICE, mbSession);
			serviceResponse.setHeader(headerResp);
			
			Logger.info("Tran categorisation JSON Response populated for GCIS: " + ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "")
					+", No of transactions : " + ((trxnHist!=null && trxnHist.getTransactions()!=null)?trxnHist.getTransactions().size():" TranHist is empty"),  this.getClass());
		
				
			if(Logger.isDebugEnabled(this.getClass())){
				
				Logger.debug("Tran categorisation JSON Response populated for GCIS: :" + objectMapper.writeValueAsString(serviceResponse), this.getClass());
			}	
			return serviceResponse;	
		}catch (BusinessException e)
		{
			Logger.info("BusinessException Inside processTransactioncategorisation() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "]", e, this.getClass());		
			BusinessException exp = new BusinessException(e.getKey());
			IMBResp resp1 = null;
			if(e.getKey()==BusinessException.CATEGORISATION_UNAVAILABLE){
				resp1  = MBAppUtils.createErrorResp(mbSession.getOrigin() ,exp,new Integer[]{monthsForErrorMessage}, ServiceConstants.TRAN_CATEGORIATION_SERVICE, httpServletRequest);
			}else{
				resp1  = MBAppUtils.createErrorResp(mbSession.getOrigin() ,exp, ServiceConstants.TRAN_CATEGORIATION_SERVICE, httpServletRequest);
			}
			return resp1;
		}catch (ResourceException e) {
			Logger.error("ResourceException Inside processTransactioncategorisation() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "]", e, this.getClass());			
			ResourceException exp = new ResourceException(e.getKey());
			IMBResp resp1  = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, ServiceConstants.TRAN_CATEGORIATION_SERVICE, httpServletRequest);
			return resp1;
		}catch (Exception e)
		{			
			Logger.error("Exception Inside processTransactioncategorisation() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "]", e, this.getClass());
			BusinessException exp = new BusinessException(BusinessException.GENERIC_ERROR);
			IMBResp resp1  = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, ServiceConstants.TRAN_CATEGORIATION_SERVICE, httpServletRequest);
			return resp1;
		} finally
		{
			perfLogger.endLog(logName);
			perfLogger.endAllLogs();
		}				
	}
	
	
	/**
	 * To make GDW For Transaction Categorisation(statistic logging will be done for Sub Category, when customer click on Category bar in the graph)
	 * 
	 * @param httpRequest
	 * @param request
	 * @return
	 */
	@RequestMapping(method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE, value = "categorisationStat")
	@ResponseBody
	public IMBResp updateStatisticsLog(HttpServletRequest httpRequest, @RequestBody final TranCategorisationStatReq request) {
		Logger.debug("TransactionCategorisationController - updateStatisticsLog(). Request: " + request, this.getClass());
		
		ObjectMapper objectMapper = new ObjectMapper();	
		perfLogger.startAllLogs();
		String logName = MBAppUtils.getLogName(httpRequest);
		perfLogger.startLog(logName);

		MobileSession mobileSession = null;
		try {
			mobileSession = mbAppHelper.getMobileSession(httpRequest);
			Logger.info("tran categorisationStat JSON Request :" + objectMapper.writeValueAsString(request), this.getClass());
			
			validateRequestHeader(request.getHeader(), httpRequest);
			ErrorResp errorResp = validate(request, httpRequest);// validate json
			if (errorResp != null && errorResp.getErrors() != null && errorResp.getErrors().size() > 0)
				return errorResp;
			
			int myAcctIndex = request.getAccountIndex();
			Customer customer=mobileSession.getCustomer();	
			Account selectedAcct=mbAppHelper.getAccountFromCustomer(customer, myAcctIndex);
			
			if(selectedAcct!=null){
			IBankCommonData commonData=mbAppHelper.populateIBankCommonData(mobileSession,httpRequest);
			Logger.info("TransactionCategorisationController - updateStatisticsLog -- Selected Category :" + request.getCategoryName(), this.getClass());
			String action = Statistic.TRAN_CATE_CATEGORY;
			String desc = IBankParams.BLANK_STRING;
			boolean validCategory = false;
			String categoryName = request.getCategoryName();
			
			try{
				if(!StringMethods.isEmptyString(categoryName)){//If request comes from Category graph bar click, statistic logging will be done for Sub Category, else means clicking on back button in sub category graph(so GDW for Category.).
				
					validCategory = categorisationService.validateCategoryName(categoryName, selectedAcct.getAccountId().getApplicationId());
					
					if(validCategory){
					action = Statistic.TRAN_CATE_SUB_CATEGORY;
					
						if(request.isDebit() != null){
							if(request.isDebit()){
								categoryName = CategorisationService.SPENDINGS+"|"+categoryName;
							}
							else{
								categoryName = CategorisationService.DEPOSITS+"|"+categoryName;
							}
						}
						else{
							throw new Exception("Not a valid category type.");
						}
					
					desc = categoryName;
					}
					else{
						throw new Exception("Not a valid category.");
					}
					
				}
				categorisationService.logStatistic(selectedAcct, commonData, action, desc);
				}
				catch(Exception e){
					Logger.error(" Unable to create statistics entry in updateStatisticsLog(). ", this.getClass());
				}
			}
			else{
				Logger.error(" Error while getting selected account information. Unable to create statistics entry in updateStatisticsLog(). ", this.getClass());
			}
			SuccessResp successResp = new SuccessResp();																			
			RespHeader headerResp = populateResponseHeader(ServiceConstants.TRAN_CATE_STAT_LOG, mobileSession);
			successResp.setHeader(headerResp);
			successResp.setIsSuccess(true);
			
			Logger.info("TransactionCategorisationController - updateStatisticsLog JSON Response :" + objectMapper.writeValueAsString(successResp), this.getClass());

			return successResp;

		} catch (ResourceException e) {
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.SYSTEM_UNAVILABLE, ServiceConstants.TRAN_CATE_STAT_LOG,
					httpRequest);
		} catch (Exception e) {
			Logger.error("Exception TransactionCategorisationController - updateStatisticsLog(): GCIS: ["
					+ ((mobileSession != null && mobileSession.getCustomer() != null) ? mobileSession.getCustomer().getGcis() : "") + "] :", e, this
					.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), ResourceException.MOBILE_NON_FINANCIAL_FATAL_ERR,
					ServiceConstants.TRAN_CATE_STAT_LOG, httpRequest);
		} finally {
			perfLogger.endLog(logName);
			perfLogger.endAllLogs();
		}

	}
	
    private static final String DATE_MMYYYY = "MMyyyy";

    
    
	private TranHistoryByMonth getTranHistForMonthFromSession(Date fromDateStart,MobileSession mbSession )
	{
		
		String parammmYYYY = new SimpleDateFormat(DATE_MMYYYY).format(fromDateStart);

		//Collection<TranHistoryByMonth> tranHistByMonth = mbSession.getTranHistoryByMonthList();
		Map<String,LabelValueVO> tranHistMonthStatus = mbSession.getTranHistoryMonthListStatus();
		Logger.debug("getTranHistForMonthInSession. Month Key : " + parammmYYYY  , this.getClass());
		
		if ( tranHistMonthStatus == null )
		{
			return null;
		}  
		TranHistoryByMonth sessTranHistoryByMonth = null;
		if ( tranHistMonthStatus != null & tranHistMonthStatus.size() > 0 )
		{
			Iterator<String> iterator =tranHistMonthStatus.keySet().iterator();
			while (iterator.hasNext() )
			{
				String monthKey = iterator.next();
				if ( parammmYYYY.equalsIgnoreCase(monthKey) && "F".equalsIgnoreCase( ((LabelValueVO)tranHistMonthStatus.get(monthKey)).getValue() ))
				{
					Logger.debug("Already In Session. Month Key : " + parammmYYYY  , this.getClass());
					sessTranHistoryByMonth =  new TranHistoryByMonth();
					sessTranHistoryByMonth.setStatus("F");
					sessTranHistoryByMonth.setFromDate(fromDateStart);
					sessTranHistoryByMonth.setMonthYYYY(monthKey);
					TranHistoryByMonth tranHistoryByMonth = new TranHistoryByMonth();
					TransactionHistory transactionHistory = new AccountingTransactionHistory();
					tranHistoryByMonth.setTransactionHistory(transactionHistory);
					sessTranHistoryByMonth.setTransactionHistory(filterTransactionHistoryForMonth(parammmYYYY, mbSession.getTransactionHistory(), tranHistoryByMonth));
					//sessTranHistoryByMonth = tranHistoryByMonth;
					break;
				}
				else if ( parammmYYYY.equalsIgnoreCase(monthKey) && "P".equalsIgnoreCase( ((LabelValueVO)tranHistMonthStatus.get(monthKey)).getValue()))
				{
					Logger.debug("Partially In Session. Month Key : " + parammmYYYY  , this.getClass());
					sessTranHistoryByMonth =  new TranHistoryByMonth();
					sessTranHistoryByMonth.setStatus("P");
					sessTranHistoryByMonth.setFromDate(fromDateStart);
					sessTranHistoryByMonth.setMonthYYYY(monthKey);
					sessTranHistoryByMonth.setTransactionHistory(null);
					//sessTranHistoryByMonth = tranHistoryByMonth;
					break;
				}
				
			}
		}
		
		return sessTranHistoryByMonth;
	}

	private TransactionHistory filterTransactionHistoryForMonth(String parammmYYYY, TransactionHistory trxnHist , TranHistoryByMonth tranHistoryByMonth )
	{
		perfLogger.startLog("filterTransactionHistoryForMonth");
		if(trxnHist != null && trxnHist.getTransactions() != null && trxnHist.getTransactions().size() > 0){
			
			List<TransactionInfo> transaction = trxnHist.getTransactions();
			
			if (transaction != null && transaction.size() > 0  )
			{
				Iterator iterator = transaction.iterator();
				while ( iterator.hasNext())
				{
					TransactionInfo transactionInfo = ( TransactionInfo ) iterator.next();
					String tranDate = new SimpleDateFormat(DATE_MMYYYY).format(transactionInfo.getDate());
					if ( parammmYYYY.equalsIgnoreCase(tranDate))
					{
						if ( tranHistoryByMonth.getTransactionHistory().getTransactions() == null )
						{
							List<TransactionInfo> tempTransaction  = new ArrayList();  
							tranHistoryByMonth.getTransactionHistory().setTransactions(tempTransaction);
						}
						tranHistoryByMonth.getTransactionHistory().getTransactions().add(transactionInfo);
					}
				}
			}
			
			List<TransactionInfo> crTransaction = trxnHist.getCreditTransactions();
			
			if (crTransaction != null && crTransaction.size() > 0  )
			{
				Iterator iterator = crTransaction.iterator();
				while ( iterator.hasNext())
				{
					TransactionInfo transactionInfo = ( TransactionInfo ) iterator.next();
					String tranDate = new SimpleDateFormat(DATE_MMYYYY).format(transactionInfo.getDate());
					if ( parammmYYYY.equalsIgnoreCase(tranDate))
					{
						if ( tranHistoryByMonth.getTransactionHistory().getCreditTransactions() == null )
						{
							List<TransactionInfo> tempTransaction  = new ArrayList();  
							tranHistoryByMonth.getTransactionHistory().setCreditTransactions(tempTransaction);
						}
						tranHistoryByMonth.getTransactionHistory().getCreditTransactions().add(transactionInfo);
					}
				}
			}
	
			List<TransactionInfo> drTransaction = trxnHist.getDebitTransactions();
			
			if (drTransaction != null && drTransaction.size() > 0  )
			{
				Iterator iterator = drTransaction.iterator();
				while ( iterator.hasNext())
				{
					TransactionInfo transactionInfo = ( TransactionInfo ) iterator.next();
					String tranDate = new SimpleDateFormat(DATE_MMYYYY).format(transactionInfo.getDate());
					if ( parammmYYYY.equalsIgnoreCase(tranDate))
					{
						if ( tranHistoryByMonth.getTransactionHistory().getDebitTransactions() == null )
						{
							List<TransactionInfo> tempTransaction  = new ArrayList();  
							tranHistoryByMonth.getTransactionHistory().setDebitTransactions(tempTransaction);
						}
						Logger.debug("Adding Transaction History . " + transactionInfo.getDescription1() + " Amount " +transactionInfo.getAmount() + " Merchant. " +  transactionInfo.getMerchantCategoryCode() +  " Catg. " +  transactionInfo.getCategoryCode()  + "  Sub Catg. :" + transactionInfo.getTranSubCategory() , this.getClass());
						tranHistoryByMonth.getTransactionHistory().getDebitTransactions().add(transactionInfo);
					}
				}
			}
			
		}
		perfLogger.endLog("filterTransactionHistoryForMonth");
		return tranHistoryByMonth.getTransactionHistory();
	
	}
	
	
	/**
	 * Response for invalid body request 
	 * 
	 * @return
	 */
	@ExceptionHandler({org.springframework.http.converter.HttpMessageNotReadableException.class})
	@ResponseStatus(org.springframework.http.HttpStatus.OK)
	@ResponseBody
	public IMBResp resolveException() {		
		return MBAppUtils.createInvalidMessageBodyResponse(ServiceConstants.TRAN_CATEGORIATION_SERVICE);
	}
	
	public ErrorResp validate(IMBReq serviceRequest, HttpServletRequest request) {
		return mbAppValidator.validate(serviceRequest, request);
	}
	
	public void validateRequestHeader(ReqHeader header, HttpServletRequest request) throws ResourceException
	{	
		mbAppValidator.validateRequestHeader(header,  request);	
	}
	
	public RespHeader populateResponseHeader(String ServiceName)
	{		
		return mbAppHelper.populateResponseHeader(ServiceName);
	}			
	
	public RespHeader populateResponseHeader(String serviceName, MobileSession mobSession )
	{
		return mbAppHelper.populateResponseHeader(serviceName, mobSession);
	}


	
}
