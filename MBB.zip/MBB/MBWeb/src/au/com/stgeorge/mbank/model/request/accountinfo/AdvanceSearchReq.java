package au.com.stgeorge.mbank.model.request.accountinfo;

import java.io.Serializable;

import org.hibernate.validator.constraints.Length;
import org.hibernate.validator.constraints.NotEmpty;

import au.com.stgeorge.ibank.businessobject.BusinessException;

public class AdvanceSearchReq implements Serializable{

	private static final long serialVersionUID = 5297519451570513390L;	
	
	@Length(max = 26, message = ""+BusinessException.WSVC_INVALID_INPUT_PARAM)
	private String description;
	
	@NotEmpty (message = ""+BusinessException.WSVC_INVALID_INPUT_PARAM)	
	private String fromDate;
	
	@NotEmpty (message = ""+BusinessException.WSVC_INVALID_INPUT_PARAM)	
	private String toDate;
	
	@NotEmpty (message = ""+BusinessException.WSVC_INVALID_INPUT_PARAM)	
	private String fromAmount;
	
	@NotEmpty (message = ""+BusinessException.WSVC_INVALID_INPUT_PARAM)	
	private String toAmount;
	
	private int entryPoint;
	
	public int getEntryPoint() {
		return entryPoint;
	}

	public void setEntryPoint(int entryPoint) {
		this.entryPoint = entryPoint;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getFromDate() {
		return fromDate;
	}

	public void setFromDate(String fromDate) {
		this.fromDate = fromDate;
	}

	public String getToDate() {
		return toDate;
	}

	public void setToDate(String toDate) {
		this.toDate = toDate;
	}

	public String getFromAmount() {
		return fromAmount;
	}

	public void setFromAmount(String fromAmount) {
		this.fromAmount = fromAmount;
	}

	public String getToAmount() {
		return toAmount;
	}

	public void setToAmount(String toAmount) {
		this.toAmount = toAmount;
	}

}
