package au.com.stgeorge.mbank.model.request.customer.ev;

import java.util.List;

import au.com.stgeorge.ibank.evcrs.businessobject.valueobject.EVCountryDetailVO;
import au.com.stgeorge.mbank.model.response.customer.ev.EVCountryDetail;

public class CRSInfo {
	
	private boolean foreignTaxResident;
	private List<TaxResidency> taxResidencyList;
	private List<WidgetTaxResidency> widgetTaxResidencyList;
	private List<String> mandatoryTINReasons; // CRS
	private List<String> optionalTINReasons; // crs
	private List<EVCountryDetail> evForeignCountryResp; // crs
	private List<EVCountryDetailVO> countries;
	
	public List<WidgetTaxResidency> getWidgetTaxResidencyList() {
		return widgetTaxResidencyList;
	}
	public void setWidgetTaxResidencyList(
			List<WidgetTaxResidency> widgetTaxResidencyList) {
		this.widgetTaxResidencyList = widgetTaxResidencyList;
	}
	public boolean isForeignTaxResident() {
		return foreignTaxResident;
	}
	public void setForeignTaxResident(boolean foreignTaxResident) {
		this.foreignTaxResident = foreignTaxResident;
	}
	public List<TaxResidency> getTaxResidencyList() {
		return taxResidencyList;
	}
	public void setTaxResidencyList(List<TaxResidency> taxResidencyList) {
		this.taxResidencyList = taxResidencyList;
	}
	public List<String> getMandatoryTINReasons() {
		return mandatoryTINReasons;
	}
	public void setMandatoryTINReasons(List<String> mandatoryTINReasons) {
		this.mandatoryTINReasons = mandatoryTINReasons;
	}
	public List<String> getOptionalTINReasons() {
		return optionalTINReasons;
	}
	public void setOptionalTINReasons(List<String> optionalTINReasons) {
		this.optionalTINReasons = optionalTINReasons;
	}
	public List<EVCountryDetail> getEvForeignCountryResp() {
		return evForeignCountryResp;
	}
	public void setEvForeignCountryResp(List<EVCountryDetail> evForeignCountryResp) {
		this.evForeignCountryResp = evForeignCountryResp;
	}
	public List<EVCountryDetailVO> getCountries() {
		return countries;
	}
	public void setCountries(List<EVCountryDetailVO> countries) {
		this.countries = countries;
	}
	
	
}
