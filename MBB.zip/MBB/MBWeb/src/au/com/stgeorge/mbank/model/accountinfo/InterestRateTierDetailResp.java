/**
 * 
 */
package au.com.stgeorge.mbank.model.accountinfo;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
/**
 * @author C50216
 *
 */

@JsonInclude(Include.NON_NULL)
public class InterestRateTierDetailResp {

	private String minAmt;
	private String maxAmt;
	private String rate;
	
	public String getMinAmt() {
		return minAmt;
	}
	public void setMinAmt(String minAmt) {
		this.minAmt = minAmt;
	}
	public String getMaxAmt() {
		return maxAmt;
	}
	public void setMaxAmt(String maxAmt) {
		this.maxAmt = maxAmt;
	}
	public String getRate() {
		return rate;
	}
	public void setRate(String rate) {
		this.rate = rate;
	}
			
}
