package au.com.stgeorge.mbank.model.mortgageinfo;

import java.io.Serializable;
import java.util.List;

import javax.validation.Valid;
import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.Length;
import org.hibernate.validator.constraints.Range;

import au.com.stgeorge.ibank.businessobject.BusinessException;


import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_NULL)
public class ApplicantInfo implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = -3511955740636187428L;
	private static final String BLOCK_CHARS_PATTERN = "^[0-9A-Za-z',. &/\\-]*$";
	
	@Range(min=0, max=1, message = ""+BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE)
	private int index;
	
	private Boolean ntbInd;
	
	private String title;

	@Pattern(regexp = BLOCK_CHARS_PATTERN , message = ""+BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE)
	@Length(max = 30, message = ""+BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE)
	private String firstName;
	
	@Pattern(regexp = BLOCK_CHARS_PATTERN , message = ""+BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE)
	@Length(max = 30, message = ""+BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE)
	private String middleName;
	
	@Pattern(regexp = BLOCK_CHARS_PATTERN , message = ""+BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE)
	@Length(max = 30, message = ""+BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE)
	private String lastName;
	
	@Pattern(regexp = BLOCK_CHARS_PATTERN , message = ""+BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE)
	@Length(max = 30, message = ""+BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE)
	private String otherName;
	
	private String maritalStatus;
	
	private String dateOfBirth;
	
	@Email(message = ""+BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE)
	@Length(max = 40, message = ""+BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE)
	private String emailAddress;
	
	@Pattern(regexp="([+]?[0-9]+)",message = ""+BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE)
	private String mobileNum;
	
	private String residentialStatus;
	
	@Valid
	private AddressInfo address;
	
	@Valid
	private List<IncomeInfo> incomes;

	@Range(min=0, max=9, message = ""+BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE)
	private Long numberOfDependants;
	
	private Boolean ownershipInd;
	
	private Boolean foreignTaxResiInd;
	
	private Boolean threeYrsAtCurrAddrInd;
	
	
	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getMaritalStatus() {
		return maritalStatus;
	}

	public void setMaritalStatus(String maritalStatus) {
		this.maritalStatus = maritalStatus;
	}

	public AddressInfo getAddress() {
		return address;
	}

	public void setAddress(AddressInfo address) {
		this.address = address;
	}

	public int getIndex() {
		return index;
	}

	public void setIndex(int index) {
		this.index = index;
	}


	public Boolean getNtbInd() {
		return ntbInd;
	}

	public void setNtbInd(Boolean ntbInd) {
		this.ntbInd = ntbInd;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public String getEmailAddress() {
		return emailAddress;
	}

	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}

	public String getMobileNum() {
		return mobileNum;
	}

	public void setMobileNum(String mobileNum) {
		this.mobileNum = mobileNum;
	}

	public String getResidentialStatus() {
		return residentialStatus;
	}

	public void setResidentialStatus(String residentialStatus) {
		this.residentialStatus = residentialStatus;
	}

	public List<IncomeInfo> getIncomes() {
		return incomes;
	}

	public void setIncomes(List<IncomeInfo> incomes) {
		this.incomes = incomes;
	}

	public Long getNumberOfDependants() {
		return numberOfDependants;
	}

	public void setNumberOfDependants(Long numberOfDependants) {
		this.numberOfDependants = numberOfDependants;
	}

	public Boolean getOwnershipInd() {
		return ownershipInd;
	}

	public void setOwnershipInd(Boolean ownershipInd) {
		this.ownershipInd = ownershipInd;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public String getMiddleName() {
		return middleName;
	}

	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}

	public String getOtherName() {
		return otherName;
	}

	public void setOtherName(String otherName) {
		this.otherName = otherName;
	}

	public Boolean getForeignTaxResiInd() {
		return foreignTaxResiInd;
	}

	public void setForeignTaxResiInd(Boolean foreignTaxResiInd) {
		this.foreignTaxResiInd = foreignTaxResiInd;
	}

	public Boolean getThreeYrsAtCurrAddrInd() {
		return threeYrsAtCurrAddrInd;
	}

	public void setThreeYrsAtCurrAddrInd(Boolean threeYrsAtCurrAddrInd) {
		this.threeYrsAtCurrAddrInd = threeYrsAtCurrAddrInd;
	}
	
}
