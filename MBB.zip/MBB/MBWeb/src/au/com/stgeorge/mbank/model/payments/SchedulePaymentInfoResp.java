/**
 * 
 */
package au.com.stgeorge.mbank.model.payments;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
/**
 * @author C50216
 *
 */

@JsonInclude(Include.NON_NULL)
public class SchedulePaymentInfoResp {

	private TransferScheduleResp tranSchedule;
	private Boolean isInProgress=false;
	private Boolean isAccountExpired=false;
	private Boolean isBTSchedule=false;
	private String tranType;
	private String amt;
	private String desc;
	private String status;
	private Boolean isFromAccountInvalid;
	private String fromAccountName;
	private String fromAccountNumDisp;
	private String fromBsbDisp;
	private Boolean isToAccountInvalid;
	private String toAccountName;
	private String toAccountNumDisp;
	private String toBsbDisp;
	private String payeeName;
	private String payeeNum;
	private String payeeBsbDisp;
	private String billerAlias;
	private String billerCode;
	private String crn;
	
	public TransferScheduleResp getTranSchedule() {
		return tranSchedule;
	}
	public void setTranSchedule(TransferScheduleResp tranSchedule) {
		this.tranSchedule = tranSchedule;
	}
	public Boolean getIsInProgress() {
		return isInProgress;
	}
	public void setIsInProgress(Boolean isInProgress) {
		this.isInProgress = isInProgress;
	}
	public Boolean getIsAccountExpired() {
		return isAccountExpired;
	}
	public void setIsAccountExpired(Boolean isAccountExpired) {
		this.isAccountExpired = isAccountExpired;
	}
	public Boolean getIsBTSchedule() {
		return isBTSchedule;
	}
	public void setIsBTSchedule(Boolean isBTSchedule) {
		this.isBTSchedule = isBTSchedule;
	}
	
	public String getTranType() {
		return tranType;
	}

	public void setTranType(String tranType) {
		this.tranType = tranType;
	}
	
	public String getAmt() {
		return amt;
	}
	public void setAmt(String amt) {
		this.amt = amt;
	}
	
	public String getDesc() {
		return desc;
	}

	public void setDesc(String desc) {
		this.desc = desc;
	}
	
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}	
	public Boolean getIsFromAccountInvalid() {
		return isFromAccountInvalid;
	}
	public void setIsFromAccountInvalid(Boolean isFromAccountInvalid) {
		this.isFromAccountInvalid = isFromAccountInvalid;
	}
	public String getFromAccountName() {
		return fromAccountName;
	}
	public void setFromAccountName(String fromAccountName) {
		this.fromAccountName = fromAccountName;
	}
	public String getFromAccountNumDisp() {
		return fromAccountNumDisp;
	}
	public void setFromAccountNumDisp(String fromAccountNumDisp) {
		this.fromAccountNumDisp = fromAccountNumDisp;
	}
	public String getFromBsbDisp() {
		return fromBsbDisp;
	}
	public void setFromBsbDisp(String fromBsbDisp) {
		this.fromBsbDisp = fromBsbDisp;
	}
	
	public Boolean getIsToAccountInvalid() {
		return isToAccountInvalid;
	}
	public void setIsToAccountInvalid(Boolean isToAccountInvalid) {
		this.isToAccountInvalid = isToAccountInvalid;
	}
	public String getToAccountName() {
		return toAccountName;
	}
	public void setToAccountName(String toAccountName) {
		this.toAccountName = toAccountName;
	}
	public String getToAccountNumDisp() {
		return toAccountNumDisp;
	}
	public void setToAccountNumDisp(String toAccountNumDisp) {
		this.toAccountNumDisp = toAccountNumDisp;
	}
	public String getToBsbDisp() {
		return toBsbDisp;
	}
	public void setToBsbDisp(String toBsbDisp) {
		this.toBsbDisp = toBsbDisp;
	}
	public String getPayeeName() {
		return payeeName;
	}
	public void setPayeeName(String payeeName) {
		this.payeeName = payeeName;
	}
	public String getPayeeNum() {
		return payeeNum;
	}
	public void setPayeeNum(String payeeNum) {
		this.payeeNum = payeeNum;
	}
	public String getPayeeBsbDisp() {
		return payeeBsbDisp;
	}
	public void setPayeeBsbDisp(String payeeBsbDisp) {
		this.payeeBsbDisp = payeeBsbDisp;
	}
	public String getBillerAlias() {
		return billerAlias;
	}
	public void setBillerAlias(String billerAlias) {
		this.billerAlias = billerAlias;
	}
	public String getBillerCode() {
		return billerCode;
	}
	public void setBillerCode(String billerCode) {
		this.billerCode = billerCode;
	}
	public String getCrn() {
		return crn;
	}
	public void setCrn(String crn) {
		this.crn = crn;
	}
	
	
	
}
