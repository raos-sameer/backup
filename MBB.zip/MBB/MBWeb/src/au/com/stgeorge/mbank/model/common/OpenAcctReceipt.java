package au.com.stgeorge.mbank.model.common;

import java.io.Serializable;
import java.util.Date;

import au.com.stgeorge.mbank.util.JsonDateTimeSerializer;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;

@JsonInclude(Include.NON_NULL)
public class OpenAcctReceipt implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -4579874005826863167L;
	private String receiptNumDisp;
	private Date dateTime;
	private OpenAcctDetail fromAccountDetail;
	private OpenAcctDetail toAccountDetail;
	
	
	public String getReceiptNumDisp() {
		return receiptNumDisp;
	}
	public void setReceiptNumDisp(String receiptNumDisp) {
		this.receiptNumDisp = receiptNumDisp;
	}
	
	@JsonSerialize(using = JsonDateTimeSerializer.class)
	@JsonInclude(Include.NON_NULL)
	public Date getDateTime() {
		return dateTime;
	}
	public void setDateTime(Date dateTime) {
		this.dateTime = dateTime;
	}
	public OpenAcctDetail getFromAccountDetail() {
		return fromAccountDetail;
	}
	public void setFromAccountDetail(OpenAcctDetail fromAccountDetail) {
		this.fromAccountDetail = fromAccountDetail;
	}
	public OpenAcctDetail getToAccountDetail() {
		return toAccountDetail;
	}
	public void setToAccountDetail(OpenAcctDetail toAccountDetail) {
		this.toAccountDetail = toAccountDetail;
	}
	
	

}
