package au.com.stgeorge.mbank.controller.util;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import au.com.stgeorge.framework.common.logging.Logger;
import au.com.stgeorge.framework.common.util.StringMethods;
import au.com.stgeorge.ibank.businessobject.BusinessException;
import au.com.stgeorge.ibank.businessobject.ResourceException;
import au.com.stgeorge.ibank.common.cache.IBankParams;
import au.com.stgeorge.ibank.util.ServiceHelper;
import au.com.stgeorge.ibank.valueobject.database.CodesVO;
import au.com.stgeorge.ibank.valueobject.transfer.IBankCommonData;
import au.com.stgeorge.mbank.controller.IMBController;
import au.com.stgeorge.mbank.model.common.IMBReq;
import au.com.stgeorge.mbank.model.common.IMBResp;
import au.com.stgeorge.mbank.model.common.ReqHeader;
import au.com.stgeorge.mbank.model.common.RespHeader;
import au.com.stgeorge.mbank.model.request.util.ExternalReq;
import au.com.stgeorge.mbank.model.response.ErrorResp;
import au.com.stgeorge.mbank.model.response.util.ExternalResp;
import au.com.stgeorge.mbank.session.MobileSession;
import au.com.stgeorge.mbank.util.MBAppConstants;
import au.com.stgeorge.mbank.util.MBAppHelper;
import au.com.stgeorge.mbank.util.MBAppUtils;
import au.com.stgeorge.mbank.util.MBAppValidator;
import au.com.stgeorge.mobilebank.businessobject.ExternalLinkService;
import au.com.stgeorge.perflogger.PerformanceLogger;

@Controller
@RequestMapping("/util")
public class ExternalLinkController implements IMBController
{
	private static final String FEATURES = "Features";
	
	@Autowired
	private MBAppHelper mbAppHelper;
	
	@RequestMapping(value="externalLink", method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public IMBResp getUrl(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, @RequestBody final ExternalReq request)
	{
		String logName = startPerformanceLog(httpServletRequest);
		String url = null;
		MobileSession mbSession = null;
		try
		{
			mbSession = mbAppHelper.getMobileSession(httpServletRequest);		
			validateRequestHeader( request.getHeader(), httpServletRequest );
			ErrorResp errorResp = validate(request, httpServletRequest);

			String linkType = request.getLinkType();
			
			Logger.debug("linkType in request is ::"+linkType, this.getClass());
			
			IBankCommonData commonData=mbAppHelper.populateIBankCommonData(mbSession,httpServletRequest);
			
			if(!StringMethods.isEmptyString(linkType)){
				try{
					CodesVO myCodesVO = null;
					myCodesVO = IBankParams.getCodesData(IBankParams.getBaseOriginCode(mbSession.getOrigin()),FEATURES,linkType);
					url = myCodesVO.getMessage();
					Logger.debug("getting Url from database ::"+url, this.getClass());
					ExternalLinkService extService = ServiceHelper.getBean("externalLinkService");
					extService.createLogStatistics(commonData, true, linkType);
				}
				catch (Exception e) {
					Logger.error("Exception in getting the external URL for linkType ::"+linkType, this.getClass());
					BusinessException exp = new BusinessException(BusinessException.SYSTEM_UNAVILABLE);
					IMBResp resp1 = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, MBAppConstants.EXTERNAL_LINK_RESP_NAME, httpServletRequest);
					return resp1;
				}
			}
			
			ExternalResp externalResp = new ExternalResp();
			externalResp.setUrl(url);
			RespHeader headerResp = populateResponseHeader(request.getHeader().getServiceName(), mbSession);
			externalResp.setHeader(headerResp);
			return externalResp;
		}
		catch (Exception e)
		{
			Logger.error("Exception Inside getUrl method for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			BusinessException exp = new BusinessException(BusinessException.SYSTEM_UNAVILABLE);
			IMBResp resp1 = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, MBAppConstants.EXTERNAL_LINK_RESP_NAME, httpServletRequest);
			return resp1;
		}
		finally
		{
			if (mbSession != null){
				mbSession.invalidateSession();
			}
			endPerformanceLog(logName);
		}
	}
	
	public ErrorResp validate(IMBReq serviceRequest, HttpServletRequest request) {
		return  mbAppValidator.validate(serviceRequest, request);
	}

	public RespHeader populateResponseHeader(String serviceName, MobileSession mobSession )
	{
		return mbAppHelper.populateResponseHeader(serviceName, mobSession);
	}

	public void validateRequestHeader(ReqHeader header, HttpServletRequest request) throws ResourceException
	{
		mbAppValidator.validateRequestHeader(header,  request);
	}

	@Autowired
	private MBAppValidator mbAppValidator;

	@Autowired
	private PerformanceLogger perfLogger;
	
	private String startPerformanceLog(HttpServletRequest httpServletRequest){
		perfLogger.startAllLogs();
		String logName = MBAppUtils.getLogName(httpServletRequest);
		perfLogger.startLog(logName);
		return logName;
	}
	
	private void endPerformanceLog(String logName){
		perfLogger.endLog(logName);
		perfLogger.endAllLogs();
	}

}