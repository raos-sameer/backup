package au.com.stgeorge.mbank.controller.accountinfo;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import org.springframework.stereotype.Service;
import au.com.stgeorge.framework.common.logging.Logger;
import au.com.stgeorge.ibank.common.cache.IBankParams;
import au.com.stgeorge.ibank.cpp.valueobjects.CustomerPricingDetails;
import au.com.stgeorge.ibank.valueobject.Account;
import au.com.stgeorge.ibank.valueobject.ChequeAccount;
import au.com.stgeorge.ibank.valueobject.Customer;
import au.com.stgeorge.ibank.valueobject.DdaAccount;
import au.com.stgeorge.ibank.valueobject.IntRateDetailsVO;
import au.com.stgeorge.ibank.valueobject.InterestTierVO;
import au.com.stgeorge.ibank.valueobject.database.CodesVO;
import au.com.stgeorge.mbank.model.accountinfo.AccountDetailResp;
import au.com.stgeorge.mbank.model.accountinfo.CustomerPricingResp;
import au.com.stgeorge.mbank.model.accountinfo.DDAAccountDetailResp;
import au.com.stgeorge.mbank.model.accountinfo.InterestAmtDetailResp;
import au.com.stgeorge.mbank.model.accountinfo.InterestRateDetailResp;
import au.com.stgeorge.mbank.model.accountinfo.InterestRateTierDetailResp;
import au.com.stgeorge.mbank.model.accountinfo.OverdraftDetailResp;
import au.com.stgeorge.mbank.model.common.AccountKeyInfoResp;
import au.com.stgeorge.mbank.util.MBAppConstants;

@Service
public class CustomerPricingHelper {	
	
	private static final String BUSINESS_ACCESS_SAVER_PROD_CODE = "3610";
	
	protected CustomerPricingResp populateResp(CustomerPricingDetails customerPricingDetails) {
		
		CustomerPricingResp serviceResponse = new CustomerPricingResp();
		
		serviceResponse.setBonusRate(customerPricingDetails.getBonusRate());
		serviceResponse.setBonusTerm(customerPricingDetails.getBonusTerm());
		
		return serviceResponse;
		
	}
	
	protected AccountDetailResp populateAcctDetailResp(Customer customer, Account acct, String origin) {		
		
		AccountDetailResp acctDtl = new AccountDetailResp(); 
		Map<String,String> map = new HashMap<String,String>();
		String interestRate = null;		
		
		if(Account.SAVING_ACCOUNT.equalsIgnoreCase(acct.getAccountId().getEhubProductCode())){
									
			DdaAccount ddaAcct = (DdaAccount)acct;			
			DDAAccountDetailResp mbDDADtl = getSAVAcctResp(origin,customer,ddaAcct,map);
								
			mbDDADtl.setGetCashEligible(checkGetCashEligibility(acct));			
			acctDtl.setDdaDetail(mbDDADtl);			
			
			interestRate = map.get("interestRate");
		}
		else if(Account.CHEQUE_ACCOUNT.equalsIgnoreCase(acct.getAccountId().getEhubProductCode())){
																	
			ChequeAccount chqAcct = (ChequeAccount)acct;			
			DDAAccountDetailResp mbDDADtl = getCHQAcctResp(origin,chqAcct,map);
			mbDDADtl.setGetCashEligible(checkGetCashEligibility(acct));
			acctDtl.setDdaDetail(mbDDADtl);																								
			interestRate = map.get("interestRate");	
		}		
		
		acctDtl.setInterestRate(interestRate);		

		return acctDtl;		
	}
	
	private boolean checkGetCashEligibility(Account acct){
		CodesVO codeItem=IBankParams.getCodesData(IBankParams.BRAND_ORIGIN, IBankParams.PARAMETER,IBankParams.GET_CASH_ELIGIBLE_PRODUCTS);
		
		if(codeItem != null){
			if(codeItem.getMessage().indexOf(";"+acct.getAccountId().getSubProductCode()+";") >= 0)
				return true;
		}
		
		return false;
	}
	
	private DDAAccountDetailResp getSAVAcctResp(String origin, Customer customer,DdaAccount ddaAcct,Map<String,String> map) {
		
		DDAAccountDetailResp acctDtl = new DDAAccountDetailResp();												
		
		CodesVO codeItem=IBankParams.getCodesData(IBankParams.BRAND_ORIGIN, IBankParams.PARAMETER,IBankParams.MIN_INT_RATE_DISPLAY);		
		BigDecimal minInterestRate=new BigDecimal(0);		
		if (codeItem != null) {
			minInterestRate = new BigDecimal(codeItem.getMessage());
		}		
				
		if (!IBankParams.isAccountInterestRateDetlsReq(ddaAcct.getAccountId().getSubProductCode())){
				
			if(!MBAppConstants.RATE_TYPE_SPLIT.equalsIgnoreCase(ddaAcct.getRateInd())) {			
				BigDecimal currentIntRate = ddaAcct.getCurrentIntRate();
				if (currentIntRate != null && (currentIntRate.compareTo(minInterestRate) >= 0)) {				
					if (MBAppConstants.RATE_TYPE_BAL.equalsIgnoreCase(ddaAcct.getRateInd()))
						acctDtl.setStandardInterestRate(currentIntRate.toString());						
					else
						map.put("interestRate",currentIntRate.toString());						
				}								
			}
			if (MBAppConstants.RATE_TYPE_BONUS.equalsIgnoreCase(ddaAcct.getRateInd())) {
				BigDecimal bonusRate = ddaAcct.getBonusRate();			
				if (bonusRate != null && (bonusRate.compareTo(minInterestRate) >= 0)) {
					acctDtl.setBonusRate(bonusRate.toString());					
				}
			}
		}else
			acctDtl.setInterestRateDetail(getInterestRateDetail(origin,ddaAcct));
							
		if (ddaAcct.getAccountId().isSenseAccount()){ 
			if (ddaAcct.getSenseLinkAcctKey()!=null && ddaAcct.getSenseLinkAcctKey().length()>0){						
				
				AccountKeyInfoResp keyInfo = new AccountKeyInfoResp();
				keyInfo.setAccountNum(ddaAcct.getSenseLinkAcctKey());
				keyInfo.setBsb(Integer.parseInt(ddaAcct.getSenseLinkBranchKey()));
				keyInfo.setAccountType(Account.DDA);				
				
				acctDtl.setLinkedAccount(keyInfo);						
			}			
		}		
		if (ddaAcct.getAccountId().isSenseSavingAccount()){
			acctDtl.setSavingsTargetAmt(ddaAcct.getTargetBal().toString());				
		}
		
		if(ddaAcct.isOverDraftAllowed()){
			
			OverdraftDetailResp overDraftDet = new OverdraftDetailResp();
			overDraftDet.setLimitAmt(ddaAcct.getOverDraftLimit().toString());
			overDraftDet.setRate(ddaAcct.getOverDraftRate().toString());
			
			acctDtl.setOverdraft(overDraftDet);
			
		}
							
		acctDtl.setInterestCharged(getInterestAmtDetail(ddaAcct.getIntChargedLastYear(),ddaAcct.getIntChargedThisYear()));
		acctDtl.setInterestEarned(getInterestAmtDetail(ddaAcct.getInterestLastYear(),ddaAcct.getInterestThisYear()));
																						
		return acctDtl;
		
	}

	private DDAAccountDetailResp getCHQAcctResp(String origin, ChequeAccount chqAcct,Map<String,String> map){
	
		DDAAccountDetailResp acctDtl = new DDAAccountDetailResp();		
								
		CodesVO codeItem=IBankParams.getCodesData(IBankParams.BRAND_ORIGIN, IBankParams.PARAMETER,IBankParams.MIN_INT_RATE_DISPLAY);
		BigDecimal minInterestRate=new BigDecimal(0);		
		if (codeItem != null) {
			minInterestRate = new BigDecimal(codeItem.getMessage());
		}		
				
		if (!IBankParams.isAccountInterestRateDetlsReq(chqAcct.getAccountId().getSubProductCode())){
			if(!MBAppConstants.RATE_TYPE_SPLIT.equalsIgnoreCase(chqAcct.getRateInd())) {
				BigDecimal currentIntRate = chqAcct.getCurrentIntRate();
				if (currentIntRate != null && (currentIntRate.compareTo(minInterestRate) >= 0)) {
					if (MBAppConstants.RATE_TYPE_BAL.equalsIgnoreCase(chqAcct.getRateInd()))
						acctDtl.setStandardInterestRate(currentIntRate.toString());						
					else
						map.put("interestRate",currentIntRate.toString());						
				}					
			}			
			if(MBAppConstants.RATE_TYPE_BONUS.equalsIgnoreCase(chqAcct.getRateInd())) {
				BigDecimal bonusRate = chqAcct.getBonusRate();			
				if (bonusRate != null && (bonusRate.compareTo(minInterestRate) >= 0)) {
					acctDtl.setBonusRate(bonusRate.toString());					
				}
			}
		}else
			acctDtl.setInterestRateDetail(getInterestRateDetail(origin,chqAcct));
			
		if(chqAcct.isOverDraftAllowed()){
			
			OverdraftDetailResp overDraftDet = new OverdraftDetailResp();
			overDraftDet.setLimitAmt(chqAcct.getOverDraftLimit().toString());
			overDraftDet.setRate(chqAcct.getOverDraftRate().toString());
			
			acctDtl.setOverdraft(overDraftDet);
			
		}
							
		acctDtl.setInterestCharged(getInterestAmtDetail(chqAcct.getIntChargedLastYear(),chqAcct.getIntChargedThisYear()));							
		acctDtl.setInterestEarned(getInterestAmtDetail(chqAcct.getInterestLastYear(),chqAcct.getInterestThisYear()));
		
		return acctDtl;	
}

	private InterestAmtDetailResp getInterestAmtDetail(BigDecimal lastYearAmt, BigDecimal thisYearAmt){
	
		InterestAmtDetailResp intAmtDtl = null; 
		
		if(lastYearAmt == null)
			lastYearAmt = new BigDecimal(0);
				
		if(thisYearAmt == null)
			thisYearAmt = new BigDecimal(0);
							
		if (lastYearAmt.compareTo(new BigDecimal(0)) != 0 || thisYearAmt.compareTo(new BigDecimal(0)) != 0){
			
			intAmtDtl = new InterestAmtDetailResp();
			intAmtDtl.setLastYearAmt(lastYearAmt.toString());
			intAmtDtl.setThisYearAmt(thisYearAmt.toString());
		}
		return intAmtDtl;
	}

	private InterestRateDetailResp getInterestRateDetail(String origin, DdaAccount account){
		InterestRateDetailResp rateDetail = new InterestRateDetailResp();
		
		// if interest rate not available due to system issue
		if (account.getIntRateDetailsVO() == null && DdaAccount.INTRATE_RATE_NOT_AVAILABLE == account.getInterestRateAvail()) {
			String error = IBankParams.getErrorMessage(IBankParams.DEFAULT_ORIGIN, IBankParams.INTEREST_RATE_ERROR_MSG);
			rateDetail.setErrorDesc(error);
			return rateDetail;
		}
		
		IntRateDetailsVO intRateDetailsVO = account.getIntRateDetailsVO();
		rateDetail.setIsAdditionalDetail(true);
		rateDetail.setBaseRate(intRateDetailsVO.getInterestRate().toString());
		
		if(intRateDetailsVO.isCampignExists()){
			
			rateDetail.setBonusRateType(intRateDetailsVO.getCampignType());//FULL,PARTIAL
			
			if(intRateDetailsVO.getCampignRate() != null)
				rateDetail.setBonusRate(intRateDetailsVO.getCampignRate().toString());
			
			rateDetail.setBonusExpiryDate(intRateDetailsVO.getCampignExpDate());
			
			if(intRateDetailsVO.getInterestRateWithBonus() != null)
				rateDetail.setTotalRate(intRateDetailsVO.getInterestRateWithBonus().toString());					
		}		
		
		//hiding link if its override rate or Zero rate without campaign without expiry
		if ((IntRateDetailsVO.CALC_INRATEIND_OVER
				.equalsIgnoreCase(intRateDetailsVO.getCalRateTypeInd()) || (intRateDetailsVO.isRequesteZeroIntRate()))
				&& intRateDetailsVO.getExpDate() == null) {
		
			Logger.info("#Hiding show details link either over ride rate or zero interest rate withour expiry date:"+account.getAccountId().getAccountKey() , this.getClass());
			rateDetail.setIsAdditionalDetail(false);
			return rateDetail;
		}
		
		//hiding link if flat rate without campaign and  without expiry
		if ( IntRateDetailsVO.INTRATETYPE_FLAT.equalsIgnoreCase(intRateDetailsVO.getInterestRateType()) &&
				!(intRateDetailsVO.isCampignExists()) && intRateDetailsVO.getExpDate() == null) {
			
			Logger.info("#Hiding show details link, flat rate without campign withour expiry date:"+account.getAccountId().getAccountKey() , this.getClass());
			rateDetail.setIsAdditionalDetail(false);
			return rateDetail;
		}
						
		rateDetail.setBaseRateType(intRateDetailsVO.getCalRateTypeInd());//BASE,DISC,OVER
		rateDetail.setBaseExpiryDate(intRateDetailsVO.getExpDate());
		
		if(intRateDetailsVO.getInterestTiers() != null){
			rateDetail.setTierType(intRateDetailsVO.getInterestRateType());//SP,TR,FL
			rateDetail.setTierDetail(getInterestTierInfo(intRateDetailsVO));
		}
					
		String tempURLSubprodCode = "";
		if ( BUSINESS_ACCESS_SAVER_PROD_CODE.equalsIgnoreCase(account.getAccountId().getSubProductCode() ) )
		{
			tempURLSubprodCode = "-"+ account.getAccountId().getSubProductCode();
		}
		
		CodesVO codesVO = IBankParams.getCodesData(origin,
				IBankParams.EXTERNAL_LINKS,
				IBankParams.INTEREST_RATE_DETAILS_LINK + tempURLSubprodCode);
		
		rateDetail.setExternalLink(codesVO.getMessage());
		
	
		return rateDetail;
	}

	private List<InterestRateTierDetailResp> getInterestTierInfo(IntRateDetailsVO intRateDetailsVO){
		List<InterestRateTierDetailResp> tierList = null;
		
		List<InterestTierVO> interestTiers = intRateDetailsVO.getInterestTiers();
		
		if(interestTiers!=null && interestTiers.size() > 0){
			tierList = new ArrayList<InterestRateTierDetailResp>();
			Iterator<InterestTierVO> iterator = interestTiers.iterator();
			boolean firstTier = true;
			boolean lastTier = false;
			
			while (iterator.hasNext()) {
				InterestTierVO interestTierVO = iterator.next();
				InterestRateTierDetailResp tierDetail = new InterestRateTierDetailResp();
				lastTier = !iterator.hasNext();
				if (IntRateDetailsVO.INTRATETYPE_SPLIT.equalsIgnoreCase(intRateDetailsVO.getInterestRateType())) {
					if (lastTier) {
						tierDetail.setMinAmt(interestTierVO.getStarValue().toString());					
					} else {
						tierDetail.setMinAmt(interestTierVO.getStarValue().toString());
						tierDetail.setMaxAmt(interestTierVO.getEndValue().toString());
					}
					tierDetail.setRate(interestTierVO.getInterestRate().toString());
					
				} else if (IntRateDetailsVO.INTRATETYPE_TIERED.equalsIgnoreCase(intRateDetailsVO.getInterestRateType())) {
					if (lastTier) {
						tierDetail.setMinAmt(interestTierVO.getStarValue().toString());
						tierDetail.setRate(interestTierVO.getInterestRate().toString());
					}
					else {
						if (firstTier) {
							tierDetail.setMaxAmt(interestTierVO.getEndValue().toString());					
							tierDetail.setRate(interestTierVO.getInterestRate().toString());
							firstTier = false;
						} else {
							tierDetail.setMinAmt(interestTierVO.getStarValue().toString());
							tierDetail.setMaxAmt(interestTierVO.getEndValue().toString());
						}
						tierDetail.setRate(interestTierVO.getInterestRate().toString());
					}
				}
				tierList.add(tierDetail);
			}				
		}
		return tierList;		
	}

}
