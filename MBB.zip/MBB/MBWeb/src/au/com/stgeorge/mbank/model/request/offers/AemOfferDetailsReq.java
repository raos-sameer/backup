package au.com.stgeorge.mbank.model.request.offers;


import javax.validation.constraints.NotNull;

import au.com.stgeorge.ibank.businessobject.BusinessException;
import au.com.stgeorge.mbank.model.common.IMBReq;
import au.com.stgeorge.mbank.model.common.ReqHeader;

public class AemOfferDetailsReq implements IMBReq{
		
	private static final long serialVersionUID = -246356619485659486L;

	private ReqHeader header;	

	@NotNull(message = "" + BusinessException.WSVC_INVALID_INPUT_PARAM)
	private String campaignCode; 	
	
	public ReqHeader getHeader()
	{
		return header;
	}
	public void setHeader(ReqHeader header)
	{
		this.header = header;
	}
	public String getCampaignCode() {
		return campaignCode;
	}
	public void setCampaignCode(String campaignCode) {
		this.campaignCode = campaignCode;
	}					
}
