package au.com.stgeorge.mbank.controller.recurringdirectdebits;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.builder.ReflectionToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import au.com.stgeorge.framework.common.logging.Logger;
import au.com.stgeorge.framework.common.util.DateMethods;
import au.com.stgeorge.framework.common.util.StringMethods;
import au.com.stgeorge.ibank.businessobject.BusinessException;
import au.com.stgeorge.ibank.businessobject.ResourceException;
import au.com.stgeorge.ibank.businessobject.recurringedirectdebits.RecurringDirectDebitsService;
import au.com.stgeorge.ibank.common.cache.IBankParams;
import au.com.stgeorge.ibank.common.cache.IBankRefershParams;
import au.com.stgeorge.ibank.valueobject.Account;
import au.com.stgeorge.ibank.valueobject.PDFStore;
import au.com.stgeorge.ibank.valueobject.RecurringDirectDebit;
import au.com.stgeorge.ibank.valueobject.transfer.IBankCommonData;
import au.com.stgeorge.mbank.controller.IMBController;
import au.com.stgeorge.mbank.model.common.AccountKeyInfoResp;
import au.com.stgeorge.mbank.model.common.IMBReq;
import au.com.stgeorge.mbank.model.common.IMBResp;
import au.com.stgeorge.mbank.model.common.ReqHeader;
import au.com.stgeorge.mbank.model.common.RespHeader;
import au.com.stgeorge.mbank.model.request.EmptyReq;
import au.com.stgeorge.mbank.model.request.IndexReq;
import au.com.stgeorge.mbank.model.request.RecurringDirectDebitRequest;
import au.com.stgeorge.mbank.model.request.RecurringDirectDebitTranRequest;
import au.com.stgeorge.mbank.model.response.ErrorResp;
import au.com.stgeorge.mbank.model.response.recurringdirectdebit.ClosedAccountResp;
import au.com.stgeorge.mbank.model.response.recurringdirectdebit.DirectDebitAccountResp;
import au.com.stgeorge.mbank.model.response.recurringdirectdebit.DirectDebitMerchantResp;
import au.com.stgeorge.mbank.model.response.recurringdirectdebit.DirectDebitTokenResp;
import au.com.stgeorge.mbank.model.response.recurringdirectdebit.RecurringDirectDebitResp;
import au.com.stgeorge.mbank.session.MobileSession;
import au.com.stgeorge.mbank.session.MobileSessionImpl;
import au.com.stgeorge.mbank.util.MBAppHelper;
import au.com.stgeorge.mbank.util.MBAppUtils;
import au.com.stgeorge.mbank.util.MBAppValidator;
import au.com.stgeorge.mbank.util.ServiceConstants;
import au.com.stgeorge.perflogger.PerformanceLogger;

@Controller
@RequestMapping("/recurringdirectdebit")
public class RecurringDirectDebitController implements IMBController
{
	@Autowired
	private MBAppHelper mbAppHelper;

	@Autowired
	private MBAppValidator mbAppValidator;
	
	@Autowired
	private PerformanceLogger perfLogger;
	
	@Autowired
	private RecurringDirectDebitsService directDebitsService;
	
	private IBankRefershParams ibankRefreshParams;
	
	public IBankRefershParams getIbankRefreshParams() {
		return ibankRefreshParams;
	}

	public void setIbankRefreshParams(IBankRefershParams ibankRefreshParams) {
		this.ibankRefreshParams = ibankRefreshParams;
	}

	private static final String GLOBAL_SERVICES_MENU_ENTRY_POINT="Global Services Menu";
	private static final String DEEPLINK_ENTRY_POINT="DeepLink";
	private static final String PDF_GEN_ENTRY_POINT="PDF Generation";
	private static final String PDF_GEN_ENTRY_POINT_NATIVE_APP="PDF Generation Native App";
	private static final String VIEW_DIRECTDEBIT_TRANSACTIONLIST_ENTRY_POINT="View Direct Debit transaction list";
	private static final String DOWNLOAD_DIRECTDEBIT_TRANSACTIONLIST_ENTRY_POINT="Download Direct Debit transaction list";
	private static final String ACCOUNT_STATUS_CLOSED="Closed";
	private static final String ACCOUNT_STATUS_OPEN="Open";
	private static final String RECURRING_ALL_ON = "ALLON";
	private static final String RECURRING_CRA_ON = "CRAON";
	private static final String RECURRING_CRA_DDA_ON = "CRADDAON";
	private static final String RPDD_PILOT = "RPDDPilot";
	
	@RequestMapping(method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE, value = "accounts")
	@ResponseBody
	public IMBResp getAccounts(HttpServletRequest httpRequest, @RequestBody final EmptyReq request) {
		Logger.debug("RecurringDirectDebitsController - getAccounts. Request: " + request, this.getClass());
		String logName = startPerformanceLog(httpRequest);
		MobileSession mobileSession = new MobileSessionImpl();
		DirectDebitAccountResp resp = null;
		
		List<Account> activeAccounts=new ArrayList<Account>();
		List<Account> closedAccounts=new ArrayList<Account>();
		
		try {
			mobileSession.getSessionContext(httpRequest);
			validateRequestHeader(request.getHeader(), httpRequest);
			ErrorResp errorResponse = validate(request, httpRequest);
			if (errorResponse.hasErrors())
			{
				return errorResponse;
			}
			
			IBankCommonData commonData = mbAppHelper.populateIBankCommonData(mobileSession, httpRequest);
			
			if(!mobileSession.getDirectDebitsAccounts()){
				directDebitsService.getCustomerArrangements(commonData);
				mobileSession.setDirectDebitsAccounts(true);
			}

			activeAccounts = directDebitsService.getEligibleActiveAccounts(commonData.getCustomer(), commonData.getOrigin(),commonData.getCustomer().getGcis());				
			closedAccounts = directDebitsService.getEligibleClosedAccounts(commonData,commonData.getCustomer().getGcis());
			
			String helpDeskNumber=directDebitsService.getHelpDeskPhoneNumber(commonData.getOrigin());
			
			resp = populateAccountsResponse(populateResponseHeader(ServiceConstants.RECURRING_DIRECT_DEBITS_SERVICE, mobileSession ), activeAccounts, closedAccounts,helpDeskNumber);
			
			try{
				directDebitsService.addStatLogsForRecurringDirectDebits(commonData,null,null,GLOBAL_SERVICES_MENU_ENTRY_POINT,null,null);
			}catch(Exception ex){
				Logger.error("Exception caught while makin  stats entry", this.getClass());
			}
			
			return resp;
		} catch (BusinessException e) {
			Logger.info("BusinessException in RecurringDirectDebitsController - getAccounts() - [key: " + e.getKey() + "] : GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), e, ServiceConstants.RECURRING_DIRECT_DEBITS_SERVICE, httpRequest);
		} catch (ResourceException e) {
			Logger.error("ResourceException in RecurringDirectDebitsController - getAccounts() - [key: " + e.getKey() + "] : GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.SYSTEM_UNAVILABLE, ServiceConstants.RECURRING_DIRECT_DEBITS_SERVICE, httpRequest);
		} catch (Exception e) {
			Logger.error("Exception RecurringDirectDebitsController - getAccounts(): GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), ResourceException.MOBILE_NON_FINANCIAL_FATAL_ERR, ServiceConstants.RECURRING_DIRECT_DEBITS_SERVICE, httpRequest);
		} finally {
			endPerformanceLog(logName);
		}
	}
	
	@RequestMapping(method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE, value = "merchants")
	@ResponseBody
	public IMBResp getMerchants(HttpServletRequest httpRequest, @RequestBody final RecurringDirectDebitRequest request) {
		Logger.debug("RecurringDirectDebitsController - getMerchants. Request: " + request, this.getClass());
		String logName = startPerformanceLog(httpRequest);
		MobileSession mobileSession = new MobileSessionImpl();
		DirectDebitMerchantResp resp = null;
		String accountStatus=null;
		boolean isCRAEligible=false;
		boolean isCRADDAEligible=false;
		boolean isAllEligible=false;
		
		try {
			mobileSession.getSessionContext(httpRequest);
			validateRequestHeader(request.getHeader(), httpRequest);
			ErrorResp errorResponse = validate(request, httpRequest);
			if (errorResponse.hasErrors())
			{
				return errorResponse;
			}
			IBankCommonData commonData = mbAppHelper.populateIBankCommonData(mobileSession, httpRequest);
			Account account = null;
			
			String switchVal=null;
			
			switchVal=IBankParams.getRPDDSwitchVal(commonData.getOrigin(), IBankParams.RECURRING_DIRECT_DEBITS_SWITCH);
			
			if(RECURRING_ALL_ON.equalsIgnoreCase(switchVal)){			
				isAllEligible=true;			
			}
			if(RECURRING_CRA_ON.equalsIgnoreCase(switchVal)){			
				isCRAEligible=true;			
			}
			if(RECURRING_CRA_DDA_ON.equalsIgnoreCase(switchVal)){			
				isCRADDAEligible=true;			
			}
			
			if(request.isDeepLink()){			
				if(!mobileSession.getDirectDebitsAccounts()){
					directDebitsService.getCustomerArrangements(commonData);
					mobileSession.setDirectDebitsAccounts(true);
				}
			}
			
			if (request.isDeepLink()
					|| "A".equalsIgnoreCase(request.getAccountType())
					|| mobileSession.getCustomer().getClosedAccountsDirectDebits() == null 
					|| (mobileSession.getCustomer().getClosedAccountsDirectDebits() != null 
							&& mobileSession.getCustomer().getClosedAccountsDirectDebits().size() == 0
						)
				){
				account = mobileSession.getCustomer().getAccounts().get(Integer.parseInt(request.getIndex()));
			}
			else{
				account = mobileSession.getCustomer().getClosedAccountsDirectDebits().get(Integer.parseInt(request.getIndex()));
			}			
			if(null!=account.getCloseDate()){
				accountStatus=ACCOUNT_STATUS_CLOSED;
			}else{
				accountStatus=ACCOUNT_STATUS_OPEN;
			}
			
			if(request.isDeepLink()){				
				Logger.debug("RecurringDirectDebitsController - from deeplink", this.getClass());
				if(!directDebitsService.isAccountEligible(account, null, null, null, isCRAEligible, isCRADDAEligible, isAllEligible)){
					Logger.debug("RecurringDirectDebitsController - from deeplink: no eligible accounts", this.getClass());
					throw new BusinessException(BusinessException.RECURRING_DIRECT_DEBITS_NO_ELIGIBLE_ACCOUNTS);
				}
				Logger.debug("RecurringDirectDebitsController - from deeplink:  eligible account", this.getClass());
			}
				
			List<RecurringDirectDebit> merchants = directDebitsService.getMerchants(commonData, account);
			
			resp = populateMerchantsResponse(populateResponseHeader(ServiceConstants.RECURRING_DIRECT_DEBITS_SERVICE, mobileSession ), merchants);
			
			try{
				if(request.isDeepLink()){
					directDebitsService.addStatLogsForRecurringDirectDebits(commonData,account.getAccountId().getAccountNumber(),account.getAccountId().getProductName(),DEEPLINK_ENTRY_POINT,accountStatus,null);
				}else{
					directDebitsService.addStatLogsForRecurringDirectDebits(commonData,account.getAccountId().getAccountNumber(),account.getAccountId().getProductName(),GLOBAL_SERVICES_MENU_ENTRY_POINT,accountStatus,null);
				}
				
			}catch(Exception ex){
				Logger.error("Exception caught while makin  stats entry", this.getClass());
			}
			return resp;
		} catch (BusinessException e) {
			Logger.info("BusinessException in RecurringDirectDebitsController - getMerchants() - [key: " + e.getKey() + "] : GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), e, ServiceConstants.RECURRING_DIRECT_DEBITS_SERVICE, httpRequest);
		} catch (ResourceException e) {
			Logger.error("ResourceException in RecurringDirectDebitsController - getMerchants() - [key: " + e.getKey() + "] : GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.SYSTEM_UNAVILABLE, ServiceConstants.RECURRING_DIRECT_DEBITS_SERVICE, httpRequest);
		} catch (Exception e) {
			Logger.error("Exception RecurringDirectDebitsController - getMerchants(): GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), ResourceException.MOBILE_NON_FINANCIAL_FATAL_ERR, ServiceConstants.RECURRING_DIRECT_DEBITS_SERVICE, httpRequest);
		} finally {
			endPerformanceLog(logName);
		}
	}
	
	@RequestMapping(method = RequestMethod.GET, value = "download")
	@ResponseBody
	public IMBResp downloadDirectDebit(HttpServletRequest httpRequest, HttpServletResponse httpResponse) {
		Logger.debug("RecurringDirectDebitsController - downloadDirectDebit. Request: " + httpRequest, this.getClass());
		String logName = startPerformanceLog(httpRequest);
		Account account=null;
		IBankCommonData commonData=null;
		MobileSession mobileSession = new MobileSessionImpl();
		String accountStatus=null;
		try {						
			String accountIndex = httpRequest.getParameter("index");			
			String accountType = httpRequest.getParameter("accountType");		
			String token = httpRequest.getParameter("token");
			
			byte[] pdfData = null;
			String pdfFileName = null;
			
			if(!StringMethods.isEmptyString(token)){
				
				PDFStore pdfStore = directDebitsService.getPDFDocTokenDetails(token);
				
				if(pdfStore == null){
					throw new BusinessException(BusinessException.PDF_STATEMENT_NOT_FOUND);//TODO check msg
				}
				pdfData = pdfStore.getPdfData();
				pdfFileName = pdfStore.getPdfFilename();
				
				directDebitsService.deletePDFDocTokenDetails(token);
			}else{				
				mobileSession.getSessionContext(httpRequest);
				
				//TODO validate index and handle closed account
				
				if("A".equalsIgnoreCase(accountType))
				{
					account = mobileSession.getCustomer().getAccounts().get(Integer.parseInt(accountIndex));
				}
				else{
					account = mobileSession.getCustomer().getClosedAccountsDirectDebits().get(Integer.parseInt(accountIndex));
				}
				
				if(null!=account.getCloseDate()){
					accountStatus=ACCOUNT_STATUS_CLOSED;
				}else{
					accountStatus=ACCOUNT_STATUS_OPEN;
				}
				
				commonData = mbAppHelper.populateIBankCommonData(mobileSession, httpRequest);
				
				pdfData = directDebitsService.generateDirectDebitDocument(commonData, account);
				
				pdfFileName = directDebitsService.getDirectDebitDocumentName(commonData, account);
				
			}
			
			httpResponse.setContentType("application/pdf");
			httpResponse.setHeader("Content-Disposition", "attachment;filename=" + pdfFileName + ".pdf");
			httpResponse.setContentLength(pdfData.length);
			httpResponse.getOutputStream().write(pdfData, 0, pdfData.length);
			
			httpResponse.getOutputStream().flush();
			httpResponse.getOutputStream().close();
			httpResponse.flushBuffer();
			
			try{
				if(null!=account){
					directDebitsService.addStatLogsForRecurringDirectDebits(commonData,account.getAccountId().getAccountNumber(),account.getAccountId().getProductName(),PDF_GEN_ENTRY_POINT,accountStatus,null);
				}				
				
			}catch(Exception ex){
				Logger.error("Exception caught while makin  stats entry", this.getClass());
			}
						
			return null;
		} catch (BusinessException e) {
			Logger.error("BusinessException RecurringDirectDebitsController - downloadDirectDebit(): GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			httpRequest.setAttribute("errorCode",String.valueOf(e.getKey()));
			httpRequest.setAttribute(MBAppHelper.HTTP_ORIGIN_ATTRIBUTE, mbAppHelper.getOrigin(httpRequest));
			try {
				httpRequest.getRequestDispatcher("/jsp/error/serviceError.jsp").forward(httpRequest, httpResponse);
			} catch (ServletException e1) {
				return MBAppUtils.createErrorResp(mobileSession.getOrigin(), ResourceException.MOBILE_NON_FINANCIAL_FATAL_ERR, ServiceConstants.RECURRING_DIRECT_DEBITS_SERVICE, httpRequest);
			} catch (IOException e1) {
				return MBAppUtils.createErrorResp(mobileSession.getOrigin(), ResourceException.MOBILE_NON_FINANCIAL_FATAL_ERR, ServiceConstants.RECURRING_DIRECT_DEBITS_SERVICE, httpRequest);
			}
		} 
		catch(Exception ex){
			Logger.error("Exception RecurringDirectDebitsController - downloadDirectDebit(): GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", ex, this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), ResourceException.MOBILE_NON_FINANCIAL_FATAL_ERR, ServiceConstants.RECURRING_DIRECT_DEBITS_SERVICE, httpRequest);
		}
		finally {
			endPerformanceLog(logName);
		}
		return null;
	}
	
	@RequestMapping(method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE, value = "downloadToken")
	@ResponseBody
	public IMBResp getDownloadToken(HttpServletRequest httpRequest, @RequestBody final IndexReq request) {
		Logger.debug("RecurringDirectDebitsController - getDownloadToken. Request: " + request, this.getClass());
		String logName = startPerformanceLog(httpRequest);
		MobileSession mobileSession = new MobileSessionImpl();
		DirectDebitTokenResp resp = null;
		String accountStatus=null;
		try {
			mobileSession.getSessionContext(httpRequest);
			validateRequestHeader(request.getHeader(), httpRequest);
			ErrorResp errorResponse = validate(request, httpRequest);
			if (errorResponse.hasErrors())
			{
				return errorResponse;
			}
			
			Account account = null;
			if("A".equalsIgnoreCase(request.getAccountType()))
			{
				account = mobileSession.getCustomer().getAccounts().get(Integer.parseInt(request.getIndex()));
			}
			else{
				account = mobileSession.getCustomer().getClosedAccountsDirectDebits().get(Integer.parseInt(request.getIndex()));
			}
			
			if(null!=account.getCloseDate()){
				accountStatus=ACCOUNT_STATUS_CLOSED;
			}else{
				accountStatus=ACCOUNT_STATUS_OPEN;
			}
			
			IBankCommonData commonData = mbAppHelper.populateIBankCommonData(mobileSession, httpRequest);
			
			byte[] pdfData = directDebitsService.generateDirectDebitDocument(commonData, account);
			
			String pdfFileName = directDebitsService.getDirectDebitDocumentName(commonData, account);
			
			PDFStore pdfStore = new PDFStore();
			Date today = new Date();
			
			String pdfToken = mbAppHelper.getPdfDocToken();
			pdfStore.setToken(pdfToken);
			pdfStore.setCreatedby(mobileSession.getUser().getUserId());
			pdfStore.setCreatedon(today);
			pdfStore.setExpiryTime(getExpiryDate(today));
			pdfStore.setGcisNumber(mobileSession.getCustomer().getGcis());
			pdfStore.setPdfData(pdfData);
			pdfStore.setPdfFilename(pdfFileName);
			
			directDebitsService.addPDFDocTokenDetails(pdfStore);
			
			resp = populateDownloadTokenResponse(populateResponseHeader(ServiceConstants.RECURRING_DIRECT_DEBITS_SERVICE, mobileSession ), pdfToken);
			
			try{
				directDebitsService.addStatLogsForRecurringDirectDebits(commonData,account.getAccountId().getAccountNumber(),account.getAccountId().getProductName(),PDF_GEN_ENTRY_POINT_NATIVE_APP,accountStatus,null);							
			}catch(Exception ex){
				Logger.error("Exception caught while makin  stats entry", this.getClass());
			}
			
			return resp;
		} catch (BusinessException e) {
			Logger.info("BusinessException in RecurringDirectDebitsController - getDownloadToken() - [key: " + e.getKey() + "] : GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), e, ServiceConstants.RECURRING_DIRECT_DEBITS_SERVICE, httpRequest);
		} catch (ResourceException e) {
			Logger.error("ResourceException in RecurringDirectDebitsController - getDownloadToken() - [key: " + e.getKey() + "] : GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.SYSTEM_UNAVILABLE, ServiceConstants.RECURRING_DIRECT_DEBITS_SERVICE, httpRequest);
		} catch (Exception e) {
			Logger.error("Exception RecurringDirectDebitsController - getDownloadToken(): GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), ResourceException.MOBILE_NON_FINANCIAL_FATAL_ERR, ServiceConstants.RECURRING_DIRECT_DEBITS_SERVICE, httpRequest);
		} finally {
			endPerformanceLog(logName);
		}
	}
	
	@RequestMapping(method = RequestMethod.GET, value = "downloadDirectDebitTransactions")
	@ResponseBody
	public IMBResp downloadDirectDebitTransactions(HttpServletRequest httpRequest, HttpServletResponse httpResponse) {
		Logger.debug("RecurringDirectDebitsController - downloadDirectDebitTransactions. Request: " + httpRequest, this.getClass());
		String logName = startPerformanceLog(httpRequest);
		Account account=null;
		IBankCommonData commonData=null;
		MobileSession mobileSession = new MobileSessionImpl();
		String accountStatus=null;
		try {						
			String accountIndex = httpRequest.getParameter("index");			
			String accountType = httpRequest.getParameter("accountType");		
			String token = httpRequest.getParameter("token");
			String merchantName = httpRequest.getParameter("merchantName");
			
			byte[] pdfData = null;
			String pdfFileName = null;
			
			if(!StringMethods.isEmptyString(token)){
				
				PDFStore pdfStore = directDebitsService.getPDFDocTokenDetails(token);
				
				if(pdfStore == null){
					throw new BusinessException(BusinessException.PDF_STATEMENT_NOT_FOUND);//TODO check msg
				}
				pdfData = pdfStore.getPdfData();
				pdfFileName = pdfStore.getPdfFilename();
				
				directDebitsService.deletePDFDocTokenDetails(token);
			}else{				
				mobileSession.getSessionContext(httpRequest);
				
				//TODO validate index and handle closed account
				
				if("A".equalsIgnoreCase(accountType))
				{
					account = mobileSession.getCustomer().getAccounts().get(Integer.parseInt(accountIndex));
				}
				else{
					account = mobileSession.getCustomer().getClosedAccountsDirectDebits().get(Integer.parseInt(accountIndex));
				}
				
				if(null!=account.getCloseDate()){
					accountStatus=ACCOUNT_STATUS_CLOSED;
				}else{
					accountStatus=ACCOUNT_STATUS_OPEN;
				}
				
				commonData = mbAppHelper.populateIBankCommonData(mobileSession, httpRequest);
				
				//pdfData = directDebitsService.generateDirectDebitDocument(commonData, account);
				
				pdfFileName = directDebitsService.getDirectDebitDocumentName(commonData, account);
				
				pdfData = directDebitsService.generateDirectDebitTransactionDocument(commonData, account, merchantName);
			}
			
			httpResponse.setContentType("application/pdf");
			httpResponse.setHeader("Content-Disposition", "attachment;filename=" + pdfFileName + ".pdf");
			httpResponse.setContentLength(pdfData.length);
			httpResponse.getOutputStream().write(pdfData, 0, pdfData.length);
			
			httpResponse.getOutputStream().flush();
			httpResponse.getOutputStream().close();
			httpResponse.flushBuffer();
			
			try{
				if(null!=account && null!=merchantName){
					directDebitsService.addStatLogsForRecurringDirectDebits(commonData,account.getAccountId().getAccountNumber(),account.getAccountId().getProductName(),DOWNLOAD_DIRECTDEBIT_TRANSACTIONLIST_ENTRY_POINT,accountStatus, merchantName);
				}				
				
			}catch(Exception ex){
				Logger.error("Exception caught while makin  stats entry", this.getClass());
			}
						
			return null;
		} catch (BusinessException e) {
			Logger.error("BusinessException RecurringDirectDebitsController - downloadDirectDebitTransactions(): GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			httpRequest.setAttribute("errorCode",String.valueOf(e.getKey()));
			httpRequest.setAttribute(MBAppHelper.HTTP_ORIGIN_ATTRIBUTE, mbAppHelper.getOrigin(httpRequest));
			try {
				httpRequest.getRequestDispatcher("/jsp/error/serviceError.jsp").forward(httpRequest, httpResponse);
			} catch (ServletException e1) {
				return MBAppUtils.createErrorResp(mobileSession.getOrigin(), ResourceException.MOBILE_NON_FINANCIAL_FATAL_ERR, ServiceConstants.RECURRING_DIRECT_DEBITS_SERVICE, httpRequest);
			} catch (IOException e1) {
				return MBAppUtils.createErrorResp(mobileSession.getOrigin(), ResourceException.MOBILE_NON_FINANCIAL_FATAL_ERR, ServiceConstants.RECURRING_DIRECT_DEBITS_SERVICE, httpRequest);
			}
		} 
		catch(Exception ex){
			Logger.error("Exception RecurringDirectDebitsController - downloadDirectDebitTransactions(): GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", ex, this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), ResourceException.MOBILE_NON_FINANCIAL_FATAL_ERR, ServiceConstants.RECURRING_DIRECT_DEBITS_SERVICE, httpRequest);
		}
		finally {
			endPerformanceLog(logName);
		}
		return null;
	}
	
	@RequestMapping(method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE, value = "downloadDirectDebitTransactionsToken")
	@ResponseBody
	public IMBResp getDirectDebitTransactionsToken(HttpServletRequest httpRequest, @RequestBody final RecurringDirectDebitTranRequest request) {
		Logger.debug("RecurringDirectDebitsController - getDirectDebitTransactionsToken. Request: " + request, this.getClass());
		String logName = startPerformanceLog(httpRequest);
		MobileSession mobileSession = new MobileSessionImpl();
		DirectDebitTokenResp resp = null;
		String accountStatus=null;
		try {
			mobileSession.getSessionContext(httpRequest);
			validateRequestHeader(request.getHeader(), httpRequest);
			ErrorResp errorResponse = validate(request, httpRequest);
			if (errorResponse.hasErrors())
			{
				return errorResponse;
			}
			
			Account account = null;
			if("A".equalsIgnoreCase(request.getAccountType()))
			{
				account = mobileSession.getCustomer().getAccounts().get(Integer.parseInt(request.getIndex()));
			}
			else{
				account = mobileSession.getCustomer().getClosedAccountsDirectDebits().get(Integer.parseInt(request.getIndex()));
			}
			
			if(null!=account.getCloseDate()){
				accountStatus=ACCOUNT_STATUS_CLOSED;
			}else{
				accountStatus=ACCOUNT_STATUS_OPEN;
			}
			
			String merchantName = request.getMerchantName();
			
			IBankCommonData commonData = mbAppHelper.populateIBankCommonData(mobileSession, httpRequest);
			
			byte[] pdfData = directDebitsService.generateDirectDebitTransactionDocument(commonData, account, merchantName);
			
			String pdfFileName = directDebitsService.getDirectDebitDocumentName(commonData, account);
			
			PDFStore pdfStore = new PDFStore();
			Date today = new Date();
			
			String pdfToken = mbAppHelper.getPdfDocToken();
			pdfStore.setToken(pdfToken);
			pdfStore.setCreatedby(mobileSession.getUser().getUserId());
			pdfStore.setCreatedon(today);
			pdfStore.setExpiryTime(getExpiryDate(today));
			pdfStore.setGcisNumber(mobileSession.getCustomer().getGcis());
			pdfStore.setPdfData(pdfData);
			pdfStore.setPdfFilename(pdfFileName);
			
			directDebitsService.addPDFDocTokenDetails(pdfStore);
			
			resp = populateDownloadTokenResponse(populateResponseHeader(ServiceConstants.RECURRING_DIRECT_DEBITS_SERVICE, mobileSession ), pdfToken);
			
			try{
				if(null!=account && null!=merchantName){
					directDebitsService.addStatLogsForRecurringDirectDebits(commonData,account.getAccountId().getAccountNumber(),account.getAccountId().getProductName(),DOWNLOAD_DIRECTDEBIT_TRANSACTIONLIST_ENTRY_POINT,accountStatus,merchantName);	
				}
			}catch(Exception ex){
				Logger.error("Exception caught while makin  stats entry", this.getClass());
			}
			
			return resp;
		} catch (BusinessException e) {
			Logger.info("BusinessException in RecurringDirectDebitsController - getDirectDebitTransactionsToken() - [key: " + e.getKey() + "] : GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), e, ServiceConstants.RECURRING_DIRECT_DEBITS_SERVICE, httpRequest);
		} catch (ResourceException e) {
			Logger.error("ResourceException in RecurringDirectDebitsController - getDirectDebitTransactionsToken() - [key: " + e.getKey() + "] : GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.SYSTEM_UNAVILABLE, ServiceConstants.RECURRING_DIRECT_DEBITS_SERVICE, httpRequest);
		} catch (Exception e) {
			Logger.error("Exception RecurringDirectDebitsController - getDirectDebitTransactionsToken(): GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), ResourceException.MOBILE_NON_FINANCIAL_FATAL_ERR, ServiceConstants.RECURRING_DIRECT_DEBITS_SERVICE, httpRequest);
		} finally {
			endPerformanceLog(logName);
		}
	}
	
	@RequestMapping(method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE, value = "merchantTransactions")
	@ResponseBody
	public IMBResp viewDirectDebitTransactions(HttpServletRequest httpRequest, @RequestBody final RecurringDirectDebitTranRequest request) 
			throws IOException ,ResourceException, BusinessException{
	    	Logger.debug("RecurringDirectDebitsController - merchantTransactions Request: " + request, this.getClass());
		String logName = startPerformanceLog(httpRequest);
		MobileSession mobileSession = new MobileSessionImpl();
		DirectDebitMerchantResp resp = null;
		String accountStatus=null;
		try {
			mobileSession.getSessionContext(httpRequest);
			validateRequestHeader(request.getHeader(), httpRequest);
			ErrorResp errorResponse = validate(request, httpRequest);
			if (errorResponse.hasErrors())
			{
				return errorResponse;
			}
			Account account = null;
			if("A".equalsIgnoreCase(request.getAccountType()))
			{
				account = mobileSession.getCustomer().getAccounts().get(Integer.parseInt(request.getIndex()));
			}
			else{
				account = mobileSession.getCustomer().getClosedAccountsDirectDebits().get(Integer.parseInt(request.getIndex()));
			}
			
			if(null!=account.getCloseDate()){
				accountStatus=ACCOUNT_STATUS_CLOSED;
			}else{
				accountStatus=ACCOUNT_STATUS_OPEN;
			}
			String merchantName = request.getMerchantName();
			IBankCommonData commonData = mbAppHelper.populateIBankCommonData(mobileSession, httpRequest);
			if(!IBankParams.isRecurringDirectDebitTransactionSwitchON(commonData.getOrigin())){
				Logger.error("Switch is OFF for this origin - ", getClass());
				throw new BusinessException(BusinessException.SYSTEM_UNAVILABLE);
			}
			if(account != null && merchantName != null){
				List<RecurringDirectDebit> merchantTransactions = directDebitsService.getMerchantsTransactions(commonData, account, merchantName);
				if(merchantTransactions != null && merchantTransactions.size() > 0){
					resp = populateMerchantsResponse(populateResponseHeader(ServiceConstants.RECURRING_DIRECT_DEBITS_SERVICE, mobileSession ), merchantTransactions);
				}
				try{
					directDebitsService.addStatLogsForRecurringDirectDebits(commonData,account.getAccountId().getAccountNumber(),account.getAccountId().getProductName(),VIEW_DIRECTDEBIT_TRANSACTIONLIST_ENTRY_POINT,accountStatus,merchantName);
				}catch(Exception ex){
					Logger.error("Exception caught while making  stats entry in viewDirectDebitTransactions ", this.getClass());
				}	
			}
			return resp;			
		}catch (BusinessException e) {
		    Logger.info("BusinessException in RecurringDirectDebitsController - getMerchants() - [key: " + e.getKey() + "] : GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());
		    return MBAppUtils.createErrorResp(mobileSession.getOrigin(), e, ServiceConstants.RECURRING_DIRECT_DEBITS_SERVICE, httpRequest);
		}catch (ResourceException e) {			
		    Logger.error("ResourceException in RecurringDirectDebitsController - getMerchants() - [key: " + e.getKey() + "] : GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());
		    return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.SYSTEM_UNAVILABLE, ServiceConstants.RECURRING_DIRECT_DEBITS_SERVICE, httpRequest);
		}catch(Exception e){
		    Logger.error("Exception RecurringDirectDebitsController - getMerchants(): GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
		    return MBAppUtils.createErrorResp(mobileSession.getOrigin(), ResourceException.MOBILE_NON_FINANCIAL_FATAL_ERR, ServiceConstants.RECURRING_DIRECT_DEBITS_SERVICE, httpRequest);
		}
		finally{
		    endPerformanceLog(logName);
		}
	}
	
	private String startPerformanceLog(HttpServletRequest httpRequest){
		perfLogger.startAllLogs();
		String logName = MBAppUtils.getLogName(httpRequest);
		perfLogger.startLog(logName);
		return logName;
	}
	
	private void endPerformanceLog(String logName){
		perfLogger.endLog(logName);
		perfLogger.endAllLogs();
	}
	
	public ErrorResp validate(IMBReq serviceRequest, HttpServletRequest request) {
		if(Logger.isDebugEnabled(this.getClass())){
			Logger.debug("Service request object - " + ReflectionToStringBuilder.toString(serviceRequest), this.getClass());
		}
		return mbAppValidator.validate(serviceRequest, request);
	}

	public void validateRequestHeader(ReqHeader headerReq, HttpServletRequest request) throws BusinessException {
		if(Logger.isDebugEnabled(this.getClass())){
			Logger.debug("Request header validation: " + ReflectionToStringBuilder.toString(headerReq, ToStringStyle.MULTI_LINE_STYLE), this.getClass());
		}
		mbAppValidator.validateRequestHeader(headerReq, request);
	}
	
	public RespHeader populateResponseHeader(String serviceName, MobileSession mobSession) {
		return mbAppHelper.populateResponseHeader(serviceName, mobSession);
	}
	
	private DirectDebitAccountResp populateAccountsResponse(RespHeader header, List<Account> activeAccounts, List<Account> closedAccounts, String helpDeskNumber){
		DirectDebitAccountResp response = new DirectDebitAccountResp(header);
		
		List<AccountKeyInfoResp> activeAccountList = null;
		if(activeAccounts != null && !activeAccounts.isEmpty()){
			activeAccountList = new ArrayList<AccountKeyInfoResp>();
			for(Account activeAccount:activeAccounts){
				AccountKeyInfoResp keyInfoResp = mbAppHelper.getAcctKeyInfoResp(activeAccount);
				keyInfoResp.setAccountName(activeAccount.getAlias());
				activeAccountList.add(keyInfoResp);
			}
		}
		response.setActiveAccounts(activeAccountList);
		
		
		List<ClosedAccountResp> closedAccountList = null;
		if(closedAccounts != null && !closedAccounts.isEmpty()){
			closedAccountList = new ArrayList<ClosedAccountResp>();

			for(Account closedAccount:closedAccounts){
				ClosedAccountResp cAccountInfoResp = new  ClosedAccountResp();
				cAccountInfoResp.setAccountIndex(closedAccount.getIndex());
				
				if(closedAccount.getCloseDate() != null){
					cAccountInfoResp.setCloseDate(DateMethods.formatDate("dd MMM yyyy", closedAccount.getCloseDate()));
				}
				
				if(closedAccount.getOpenDate() != null){
					cAccountInfoResp.setOpenDate(DateMethods.formatDate("dd MMM yyyy", closedAccount.getOpenDate()));
				}else{
					Calendar cal = Calendar.getInstance();
					cal.setTime(closedAccount.getCloseDate());
					cal.add(Calendar.MONTH, -6); 
					cAccountInfoResp.setOpenDate(DateMethods.formatDate("dd MMM yyyy", cal.getTime()));
				}
				
				cAccountInfoResp.setAccountNum(closedAccount.getAccountId().getAccountNumber());
				cAccountInfoResp.setAccountName(closedAccount.getAlias());
				cAccountInfoResp.setAccountType(closedAccount.getAccountId().getApplicationId());
				closedAccountList.add(cAccountInfoResp);
			}
		}
		response.setClosedAccounts(closedAccountList);
		response.setHelpDeskNumber(helpDeskNumber);
		
		return response;
	}
	
	private DirectDebitMerchantResp populateMerchantsResponse(RespHeader header, List<RecurringDirectDebit> merchants){
		DirectDebitMerchantResp response = new DirectDebitMerchantResp(header);
		
		List<RecurringDirectDebitResp> merchantRespList = null;
		
		if(merchants != null && !merchants.isEmpty()){
			merchantRespList = new ArrayList<RecurringDirectDebitResp>();
			
			for(RecurringDirectDebit directDebit:merchants){
				merchantRespList.add(createRecurringDirectDebitResp(directDebit));
			}
		}
		response.setMerchants(merchantRespList);
		return response;
	}
	
	private DirectDebitTokenResp populateDownloadTokenResponse(RespHeader header, String token){
		DirectDebitTokenResp response = new DirectDebitTokenResp();
		response.setHeader(header);
		response.setToken(token);
		return response;
	}

	private RecurringDirectDebitResp createRecurringDirectDebitResp(RecurringDirectDebit directDebit) {
		RecurringDirectDebitResp debitResp = new RecurringDirectDebitResp();
		debitResp.setMerchantName(directDebit.getMerchantName());
		debitResp.setAmount(directDebit.getFormattedAmount());
		debitResp.setPaymentDate(directDebit.getFormattedDate());
		return debitResp;
	}
	
	private Date getExpiryDate(Date today){
		Calendar cal = Calendar.getInstance(); 
	    cal.setTime(today); 
	    cal.add(Calendar.MINUTE, 3);
	    return cal.getTime();
	}
}
