package au.com.stgeorge.mbank.model.request.newaccount;

import java.io.Serializable;
import java.util.ArrayList;

import javax.validation.Valid;
import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.Length;

import au.com.stgeorge.ibank.businessobject.BusinessException;
import au.com.stgeorge.mbank.model.common.AddressReq;
import au.com.stgeorge.mbank.model.common.IMBReq;
import au.com.stgeorge.mbank.model.common.ReqHeader;

public class GCCDetailsReq implements IMBReq, Serializable{
	
	private static final long serialVersionUID = -256469501889499119L;
	private static final String REGEX_PATTERN = "^[0-9A-Za-z',. &amp;/]*-?[0-9A-Za-z',. &amp;/]*$";

	@Length(max = 50, message = ""+BusinessException.WSVC_INVALID_INPUT_PARAM)
	@Email(message = ""+BusinessException.SMPL_INV_INP_PARAMS)
	private String email;

	@Pattern(regexp = REGEX_PATTERN, message = "{generic.error}")
	private String selPhoneType;
	
	@Pattern(regexp = REGEX_PATTERN, message = "{generic.error}")
	private String phone;
	
	private String leadId;
			
    public String getLeadId() {
		return leadId;
	}
	public void setLeadId(String leadId) {
		this.leadId = leadId;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getSelPhoneType() {
		return selPhoneType;
	}
	public void setSelPhoneType(String selPhoneType) {
		this.selPhoneType = selPhoneType;
	}

	private ReqHeader header;

 	public AddressReq getAddress() {
		return address;
	}
	public void setAddress(AddressReq address) {
		this.address = address;
	}
	@Valid
	private AddressReq  address;


 	
 	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	
	public ReqHeader getHeader()
	{
		return header;
	}
	public void setHeader(ReqHeader header)
	{
		this.header = header;
	}
	
	public static long getSerialVersionUID() {
		return serialVersionUID;
	}
	
		
	private Boolean isAddressValidated;

	public Boolean getIsAddressValidated()
	{
		return isAddressValidated;
	}
	public void setIsAddressValidated(Boolean isAddressValidated)
	{
		this.isAddressValidated = isAddressValidated;
	}

	@Pattern(regexp = REGEX_PATTERN, message = "{generic.error}")
	private String requestFrom;

	public String getRequestFrom() {
		return requestFrom;
	}
	public void setRequestFrom(String requestFrom) {
		this.requestFrom = requestFrom;
	}
	
	
}
