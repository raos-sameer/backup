package au.com.stgeorge.mbank.model.request.newaccount;

import javax.validation.constraints.Pattern;

import org.apache.commons.lang.builder.ReflectionToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;

import au.com.stgeorge.mbank.model.common.IMBReq;
import au.com.stgeorge.mbank.model.common.ReqHeader;

public class BTDetailsReq implements IMBReq {

	private static final long serialVersionUID = 1266078559926695727L;

	private static final String REGEX_PATTERN = "^[0-9A-Za-z',. &amp;/]*-?[0-9A-Za-z',. &amp;/]*$";
	private static final String BLOCK_CHARS_PATTERN = "^[0-9A-Za-z',. &/\\-]*$";


//	@Pattern(regexp = BLOCK_CHARS_PATTERN, message = "{generic.error}")
	private Integer index;
	
	
	private ReqHeader header;
	
//	@Pattern(regexp = BLOCK_CHARS_PATTERN, message = "{generic.error}")
	private String leadId;
	
	
//	@Pattern(regexp = REGEX_PATTERN, message = "{generic.error}")
	private String action;

	public String getLeadId() {
		return leadId;
	}

	public void setLeadId(String leadId) {
		this.leadId = leadId;
	}

	public Integer getIndex() {
		return index;
	}

	public void setIndex(Integer index) {
		this.index = index;
	}

	public ReqHeader getHeader() {
		return header;
	}

	public void setHeader(ReqHeader header) {
		this.header = header;
	}
	
	//@Pattern(regexp = REGEX_PATTERN, message = "{generic.error}")
	private String requestFrom;

	public String getRequestFrom() {
		return requestFrom;
	}
	public void setRequestFrom(String requestFrom) {
		this.requestFrom = requestFrom;
	}

	
	public String getAction() {
		return action;
	}

	public void setAction(String action) {
		this.action = action;
	}

	@Override
	public String toString() {
		return ReflectionToStringBuilder.toString(this, ToStringStyle.MULTI_LINE_STYLE);
	}
	
	
	
}
