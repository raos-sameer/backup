package au.com.stgeorge.mbank.controller.loanApplication;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import au.com.stgeorge.framework.common.logging.Logger;
import au.com.stgeorge.framework.common.util.StringMethods;
import au.com.stgeorge.ibank.businessobject.BusinessException;
import au.com.stgeorge.ibank.businessobject.loanapplication.LoanApplicationService;
import au.com.stgeorge.ibank.businessobject.mortgage.MortgageService;
import au.com.stgeorge.ibank.common.cache.IBankParams;
import au.com.stgeorge.ibank.common.cache.IBankRefershParams;
import au.com.stgeorge.ibank.loanApplication.LoanApplicationDetail;
import au.com.stgeorge.ibank.loanApplication.util.LoanAppConstants;
import au.com.stgeorge.ibank.loanApplication.util.LoanAppUtil;
import au.com.stgeorge.ibank.mortgage.util.MortgageUtil;
import au.com.stgeorge.ibank.util.CommonBusinessUtil;
import au.com.stgeorge.ibank.util.ServiceHelper;
import au.com.stgeorge.ibank.valueobject.ExternalLinkVO;
import au.com.stgeorge.ibank.valueobject.database.CodesVO;
import au.com.stgeorge.ibank.valueobject.database.OriginsVO;
import au.com.stgeorge.ibank.valueobject.transfer.IBankCommonData;
import au.com.stgeorge.mbank.controller.customer.LogonHelper;
import au.com.stgeorge.mbank.model.common.IMBResp;
import au.com.stgeorge.mbank.model.common.RespHeader;
import au.com.stgeorge.mbank.model.loanApplication.LoanStatusResp;
import au.com.stgeorge.mbank.model.request.EmptyReq;
import au.com.stgeorge.mbank.model.response.SuccessResp;
import au.com.stgeorge.mbank.model.response.mortgage.MortgageLogonResp;
import au.com.stgeorge.mbank.model.response.newaccount.LoanApplicationStatusResp;
import au.com.stgeorge.mbank.session.MobileSession;
import au.com.stgeorge.mbank.session.MobileSessionImpl;
import au.com.stgeorge.mbank.util.MBAppConstants;
import au.com.stgeorge.mbank.util.MBAppHelper;
import au.com.stgeorge.mbank.util.MBAppUtils;
import au.com.stgeorge.mbank.util.ServiceConstants;
import au.com.stgeorge.mobilebank.businessobject.ExternalLinkService;
import au.com.stgeorge.mobilebank.businessobject.impl.ExternalLinkServiceImpl;

import com.fasterxml.jackson.databind.ObjectMapper;

@Controller
@RequestMapping("/loanstatus")
public class LoanStatusController {	
	
	@Autowired
	private LoanApplicationService loanService;
	
	@Autowired
	private MortgageService mortgageService;
	
	@Autowired
	private LoanApplicationHelper loanApplicationHelper;
	
	@Autowired
	private LogonHelper logonHelper;
	
	@Autowired
	private IBankRefershParams ibankRefreshParams;
	
	public static final String AEM_HOME_LOAN= "AEMHomeLoan";
	
	public static final String MB_CSH_APPLY_ONLINE_URL = "/mb/cshApplyOnline";
	public static final String SESSION_DEEPLINK ="sessiondeeplink";
	public static final String APP_URL_IND_0 = "&appUrlInd=0";
	public static final String APP_URL_IND_1 = "&appUrlInd=1";
	public static final String APP_URL_IND_2 = "&appUrlInd=2";
    
    @RequestMapping(value="sendIncompleteApplicationStatus", method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    public IMBResp sendIncompleteApplicationStatus(HttpServletRequest httpRequest, HttpServletResponse httpServletResponse, @RequestBody final EmptyReq req){
        Logger.debug("LoanApplicationController - sendIncompleteApplicationStatus(). start: ", this.getClass());        
        MobileSession mobileSession = new MobileSessionImpl();
        LoanApplicationDetail loanDetails=null;
        String aceUrl = null;
        ExternalLinkVO  externalLinkVO = null;
        
        try {            
            mobileSession.getSessionContext(httpRequest);
            IBankCommonData commonData = new MBAppHelper().populateIBankCommonData(mobileSession, httpRequest);
            loanDetails=loanService.getLoanApplicationDetails(commonData);
                              
            if(null!=loanDetails){
            	loanService.performGDWEntry(commonData, loanDetails.getSourceApplRefNum(), true);
                
//                externalLinkVO=loanService.getACEUrlAndJWSToken(commonData, loanDetails);
                aceUrl = loanService.getACEUrl(commonData, loanDetails);
                ExternalLinkService extService = ServiceHelper.getBean("externalLinkService");
                externalLinkVO = ((ExternalLinkServiceImpl) extService).processAcePOSTRequest(commonData.getCustomer().getGcis(), aceUrl, loanDetails.getSourceApplRefNum(), LoanAppConstants.FROM_EFINANCE+LoanAppConstants.EFINANCE_DELIMITER+commonData.getCustomer().getGHSCISNumber(), null, null);
                IMBResp serviceResponse=loanApplicationHelper.populateIncompleteStatusResp(httpRequest,mobileSession,commonData, externalLinkVO);
                RespHeader headerResp = populateResponseHeader(ServiceConstants.ONLINE_REG, null);
                serviceResponse.setHeader(headerResp);
                
                /**
                 * Commenting below as a fix for 19E1 FSv changes to remove session timeout for all Compass - ACE interactions
                 * */
                //Terminating the session
            	/*if ( mobileSession != null )
    				mobileSession.invalidateSession();
                */
                return serviceResponse; 
            }
            else{
            	return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.GENERIC_ERROR, ServiceConstants.ONLINE_REG, httpRequest);
            }            
        } catch (Exception e) {                    
            return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.GENERIC_ERROR, ServiceConstants.ONLINE_REG, httpRequest);
        } finally {
        }    
    }
    
    @RequestMapping(value="sendIncomeVerificationStatus", method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    public IMBResp sendIncomeVerificationStatus(HttpServletRequest httpRequest, HttpServletResponse httpServletResponse, @RequestBody final EmptyReq req){
        Logger.debug("LoanStatusController - sendIncomeVerificationStatus(). start: ", this.getClass());        
        MobileSession mobileSession = new MobileSessionImpl();       
        LoanApplicationDetail loanDetails=null;
        ObjectMapper mapper = new ObjectMapper();
        try {            
            mobileSession.getSessionContext(httpRequest);
            IBankCommonData commonData = new MBAppHelper().populateIBankCommonData(mobileSession, httpRequest);
               
            loanDetails=loanService.getLoanApplicationDetails(commonData);
           // loanApplicationHelper.performGDWEntry(commonData, loanDetails, false);
            if(null!=loanDetails){
            	loanService.performGDWEntry(commonData, loanDetails.getSourceApplRefNum(), false);	
            }            
            IMBResp serviceResponse=loanApplicationHelper.populateCustomerRegResponse(loanDetails, commonData,null);
			Logger.info("sendIncomeVerificationStatus: LOANAPPLICATION JSON Response :" + mapper.writeValueAsString(serviceResponse), this.getClass());
			RespHeader headerResp = populateResponseHeader(ServiceConstants.ONLINE_REG, null);
			serviceResponse.setHeader(headerResp);
		
			return serviceResponse;
        } catch (Exception e) {                    
            return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.GENERIC_ERROR, ServiceConstants.ONLINE_REG, httpRequest);
        } finally {            
        }    
    }
    
	@RequestMapping(method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE, value = "checkApplicationStatus")
	@ResponseBody
    public IMBResp checkApplicationStatus(HttpServletRequest httpRequest, HttpServletResponse httpServletResponse, @RequestBody final EmptyReq req){
        Logger.debug("LoanApplicationController - checkApplicationStatus(). start: ", this.getClass());        
        MobileSession mobileSession = new MobileSessionImpl();
        boolean applicationLocked=false;
        try {            
            mobileSession.getSessionContext(httpRequest);
            String origin=mobileSession.getOrigin();
            IBankCommonData commonData = new MBAppHelper().populateIBankCommonData(mobileSession, httpRequest);
            
            boolean isDocUploadAllowed = logonHelper.isDocUploadAllowed(httpRequest);
            
            applicationLocked=mortgageService.checkApplicationStatus(origin,commonData.getCustomer().getGcis().trim(), commonData, isDocUploadAllowed);
            
            if(!applicationLocked){           	
            	
            	SuccessResp successResp = new SuccessResp();																			
				RespHeader headerResp = populateResponseHeader(req.getHeader().getServiceName(), mobileSession);
				successResp.setHeader(headerResp);
				successResp.setIsSuccess(true);	
				return successResp;
            }
            else{
            	String originHelpDeskPhone=null;
            	originHelpDeskPhone=loanApplicationHelper.getHelpDeskContactNumber(origin);
        		String[] value={originHelpDeskPhone};
        		Logger.info("Brand Contact Number returned from  origins :" + originHelpDeskPhone, this.getClass());
        		return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.DIGITAL_MORTGAGE_APPLICATION_LOCKED, MBAppUtils.getMessage(mobileSession.getOrigin(), BusinessException.DIGITAL_MORTGAGE_APPLICATION_LOCKED, value), ServiceConstants.MORTGAGE_SERVICE, httpRequest);         
            }           
        }catch (BusinessException e)
        {	 
        	if(e.getKey()==BusinessException.DIGITAL_MORTGAGE_DOC_UPLOAD_NOT_ALLOWED) {
				String originCode = IBankParams.getBaseOriginCode(mobileSession.getOrigin());
				OriginsVO originVO  = IBankParams.getOrigin(originCode);
				return MBAppUtils.createErrorResp(originCode, e, new String[]{originVO.getName()}, ServiceConstants.MORTGAGE_SERVICE, httpRequest);
			}
        	return MBAppUtils.createErrorResp(mobileSession.getOrigin(), e,ServiceConstants.MORTGAGE_SERVICE, httpRequest);
        }
        catch (Exception e) {                    
            return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.GENERIC_ERROR, ServiceConstants.MORTGAGE_SERVICE, httpRequest);
        } finally {
        }    
    }
	
	
	@RequestMapping(method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE, value = "getHomeLoanUrl")
	@ResponseBody
    public IMBResp getHomeLoanUrl(HttpServletRequest httpRequest, HttpServletResponse httpServletResponse, @RequestBody final EmptyReq req){
        Logger.debug("LoanApplicationController - getHomeLoanUrl(). start: ", this.getClass());        
        MobileSession mobileSession = new MobileSessionImpl();
        boolean isCshHomeLoanSwitchOn = false;
        try {   
            mobileSession.getSessionContext(httpRequest);
            String origin=mobileSession.getOrigin();
            IBankCommonData commonData = new MBAppHelper().populateIBankCommonData(mobileSession, httpRequest);
            String targetUrl = IBankParams.BLANK_STRING; 
            LoanApplicationStatusResp loanStatusResp = new LoanApplicationStatusResp();
            RespHeader headerResp = populateResponseHeader(req.getHeader().getServiceName(), mobileSession);
            loanStatusResp.setHeader(headerResp);  
            
            String baseOrigin = IBankParams.getBaseOriginCode(commonData.getOrigin());
            isCshHomeLoanSwitchOn = ibankRefreshParams.isMBCshHomeLoanSwitchOn(baseOrigin);
            //If CSH ETB swicth is ON, then the target URL is CSH ETB flow AEM URL
			if (isCshHomeLoanSwitchOn) {
				targetUrl = IBankParams.getCodesMessage(baseOrigin, IBankParams.EXTERNAL_LINKS, IBankParams.CSH_HOME_LOAN_AEM_URL);
				//appUrlInd - not passed = Desktop , 0 = new app , 1 = old app , 2 = msite
				String appURLInd = APP_URL_IND_2;
				boolean isMobileApp = ((logonHelper.loadCordova(httpRequest)) == -1) ? false : true;
				if (isMobileApp) {
					Cookie appVersionCookie = CommonBusinessUtil.getCookie(httpRequest, IBankParams.APP_VER_COOKIE);
					boolean isSessionDeeplinkPresent  = CommonBusinessUtil.cookieContainsValue(appVersionCookie, SESSION_DEEPLINK);
					Logger.debug("LoanApplicationController - getHomeLoanUrl(): SessionDeeplink Present in Cookie: "+isSessionDeeplinkPresent, this.getClass());        
					appURLInd = isSessionDeeplinkPresent?APP_URL_IND_0:APP_URL_IND_1;
					Logger.debug("LoanApplicationController - getHomeLoanUrl(): appURLInd Value: "+appURLInd, this.getClass());      
				}
				targetUrl = targetUrl + appURLInd;
				if (StringMethods.isEmptyString(targetUrl)) {
					throw new BusinessException(BusinessException.GENERIC_ERROR);
				}
				mobileSession.setLaunchedApp(AEM_HOME_LOAN);

			} else {

				String lenderid = mobileSession.getDMLenderId();

				Logger.info("Lender id from session " + lenderid, this.getClass());

				String signedToken = mortgageService.getSignedJWT(commonData, lenderid);
				CodesVO vo = IBankParams.getCodesData(IBankParams.getBaseOriginCode(origin), IBankParams.EXTERNAL_LINKS,
						MortgageService.MORTGAGE_URL);
				targetUrl = vo.getMessage();

				/*
				 * String lenderid = mobileSession.getDMLenderId(); if ( !
				 * StringMethods.isEmptyString(lenderid )) { mortgageUrl = mortgageUrl +
				 * "?lenderid="+ lenderid; Logger.info("Mortgage URL with lenedr " + mortgageUrl
				 * , this.getClass()); }
				 */

				if (StringMethods.isEmptyString(targetUrl)) {
					throw new BusinessException(BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE);
				}
				loanStatusResp.setToken(signedToken);
			}
			loanStatusResp.setTargetURL(targetUrl);
			
			
			return loanStatusResp;
        }catch (BusinessException e)
        {	 
        	return MBAppUtils.createErrorResp(mobileSession.getOrigin(), e,ServiceConstants.MORTGAGE_SERVICE, httpRequest);
        }
        catch (Exception e) {                    
            return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.GENERIC_ERROR, ServiceConstants.MORTGAGE_SERVICE, httpRequest);
        } finally {
        	if(mobileSession != null && !isCshHomeLoanSwitchOn){
        		mobileSession.invalidateSession();
        		Cookie sessCookie = logonHelper.getCookie(httpRequest , MBAppConstants.SMPL_SESS_CONSTANT);
        		if ( sessCookie != null )
        		{
              Logger.info("Deleting cookie - ( Mortgage) Session Id : " + sessCookie.getValue(), this.getClass());        
              
        			sessCookie.setValue(null);
        			sessCookie.setMaxAge(0);
        			httpServletResponse.addCookie(sessCookie);
        		}
        		MBAppHelper.diplayCookie(httpRequest ); 
        		MBAppHelper.expireCookie(MBAppConstants.SMPL_SESS_CONSTANT,  httpServletResponse);
        	}
        }    
    }
	
	@RequestMapping(method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE, value = "checkCustomerEligiblity")
	@ResponseBody
    public IMBResp checkCustomerEligiblity(HttpServletRequest httpRequest, HttpServletResponse httpServletResponse, @RequestBody final EmptyReq req){
        Logger.debug("LoanApplicationController - checkCustomerEligiblity(). start: ", this.getClass());        
        MobileSession mobileSession = new MobileSessionImpl();
        MortgageLogonResp mortgageLogonResp = new MortgageLogonResp();
        try
        {       
            mobileSession.getSessionContext(httpRequest);
            
            if(!IBankParams.isSwitchOn(mobileSession.getOrigin(), IBankParams.MORTGAGE_SWITCH)){
            	return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE, ServiceConstants.MORTGAGE_SERVICE, httpRequest);
        	}           
            IBankCommonData commonData = new MBAppHelper().populateIBankCommonData(mobileSession, httpRequest);

            if(mortgageService.isCustomerEligible(commonData.getCustomer()) && mortgageService.isValidCustomerContactDetail(commonData.getCustomer().getContactDetail()) && !StringMethods.isEmptyString(commonData.getCustomer().getFirstName())){
				mortgageLogonResp.setSuccess(MortgageUtil.LOGON_SUCCESS);
				mortgageLogonResp.setBusinessCustomer(false);
            }
            else{
            	mortgageLogonResp.setSuccess(MortgageUtil.LOGON_INELIGIBLE);// HS 1
            }
        }
        catch (BusinessException e)
        {	//HS 2
			if(e.getKey()==BusinessException.DIGITAL_MORTGAGE_CLAS_GETCUSTOMER_INELIGIBILE_MOBILE_AND_EMAIL_MISSING) {
				mortgageLogonResp.setSuccess(MortgageUtil.LOGON_ERROR_CONTACT_DETAILS);
				return mortgageLogonResp;
			}
			if(e.getKey()==BusinessException.MORTGAGE_MAX_APPLICATION_REACHED) {
				Logger.info("Max application limit for the gcis has excedded :", e, this.getClass());
				OriginsVO myOriginVO  = IBankParams.getOrigin(mobileSession.getOrigin());
        		String[] values = { myOriginVO.getPhone() };
        		return MBAppUtils.createErrorResp(mobileSession.getOrigin(), e, values, ServiceConstants.MORTGAGE_SERVICE, httpRequest);
			}
			if(e.getKey()==BusinessException.DIGITAL_MORTGAGE_CLAS_GETCUSTOMER_INELIGIBILE_MOBILE_MISSING) {
				mortgageLogonResp.setSuccess(MortgageUtil.LOGON_ERROR_MOBILE);
				return mortgageLogonResp;
			}
			if(e.getKey()==BusinessException.DIGITAL_MORTGAGE_CLAS_GETCUSTOMER_INELIGIBILE_EMAIL_MISSING) {
				mortgageLogonResp.setSuccess(MortgageUtil.LOGON_ERROR_EMAIL);
				return mortgageLogonResp;
			}			
			if(e.getKey()==BusinessException.DIGITAL_MORTGAGE_CLAS_GETCUSTOMER_INELIGIBILE_BUSINESS) {
				mortgageLogonResp.setSuccess(MortgageUtil.LOGON_INELIGIBLE);
				mortgageLogonResp.setBusinessCustomer(true);
				return mortgageLogonResp;
			}
		} 
        catch (Exception e) {                    
            return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.DIGITAL_MORTGAGES_NTB_INVALID_LOGIN_CREDENTIALS, ServiceConstants.MORTGAGE_SERVICE, httpRequest);
        }
        return mortgageLogonResp;
    }
		
	public RespHeader populateResponseHeader(String serviceName, MobileSession mobSession )
	{
		RespHeader headerResp = new RespHeader();
		headerResp.setClientApiVersion(ServiceConstants.API_VERSION);
		String newNameId = null;		
		headerResp.setServiceName(serviceName);
		Logger.info(" populateResponseHeader (2). serviceName  " + serviceName + " newNameId "+ newNameId, this.getClass());
		return headerResp;
	}

	/**
	 * Added for Income Verification : SBGEXP-4263 <br/>
	 * User to be displayed to new compass screen after click on "Next" button on "What's next" page.<br/>
	 * When user clicks on "Verify Doc" button on the new screen, user is redirected to ACE page,
	 * with JWT token and post parameter : IV=Y <br/><br/>
	 *  
	 * @param httpRequest
	 * @param httpServletResponse
	 * @param req
	 * @return IMBResp
	 */
    @RequestMapping(value="redirectToIncomeVerification", method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    public IMBResp redirectToIncomeVerification(HttpServletRequest httpRequest, HttpServletResponse httpServletResponse, @RequestBody final EmptyReq req){
        
    	Logger.debug("LoanStatusController - redirectToIncomeVerification() - Start.", this.getClass());       
        
        MobileSession mobileSession = new MobileSessionImpl();
        LoanApplicationDetail loanDetails=null;
        String aceUrl = null;
        ExternalLinkVO  externalLinkVO = null;
        
        try {            
            mobileSession.getSessionContext(httpRequest);
            IBankCommonData commonData = new MBAppHelper().populateIBankCommonData(mobileSession, httpRequest);
            loanDetails=loanService.getLoanApplicationDetails(commonData);
                              
            if(null!=loanDetails){              
                aceUrl = loanService.getACEUrl(commonData, loanDetails);
                ExternalLinkService extService = ServiceHelper.getBean("externalLinkService");
                externalLinkVO = ((ExternalLinkServiceImpl) extService).processAcePOSTRequest(commonData.getCustomer().getGcis(), aceUrl, loanDetails.getSourceApplRefNum(), LoanAppConstants.FROM_EFINANCE + LoanAppConstants.EFINANCE_DELIMITER + commonData.getCustomer().getGHSCISNumber(), null, null);
                
                IMBResp serviceResponse=loanApplicationHelper.populateIncomeVerificationResp(httpRequest,mobileSession,commonData, externalLinkVO);               
                RespHeader headerResp = populateResponseHeader(ServiceConstants.EFINANCE, null);
                serviceResponse.setHeader(headerResp);
                
                return serviceResponse; 
            }
            else{
            	return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.GENERIC_ERROR, ServiceConstants.EFINANCE, httpRequest);
            }
            
        } catch(Exception e) {                    
            return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.GENERIC_ERROR, ServiceConstants.EFINANCE, httpRequest);
            
        } finally {
        	Logger.debug("LoanStatusController - redirectToIncomeVerification() - End.", this.getClass()); 
        }    
    }
    
    /**
     * Added for Income Verification : SBGEXP-4263 <br/>
     * @param httpRequest
     * @param httpServletResponse
     * @param req
     * @return IMBResp
     */
    @RequestMapping(value="redirectToDashBoard", method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    public IMBResp redirectToDashBoard(HttpServletRequest httpRequest, HttpServletResponse httpServletResponse, @RequestBody final EmptyReq req){
        
    	Logger.debug("LoanStatusController - redirectToDashBoard() - Start.", this.getClass());       
        
        MobileSession mobileSession = new MobileSessionImpl();
        LoanApplicationDetail loanDetails=null;
        LoanStatusResp serviceResponse = null;
        
        try {            
            mobileSession.getSessionContext(httpRequest);
            IBankCommonData commonData = new MBAppHelper().populateIBankCommonData(mobileSession, httpRequest);
            loanDetails=loanService.getLoanApplicationDetails(commonData);
            RespHeader headerResp = populateResponseHeader(ServiceConstants.EFINANCE, null);
            
            
            if(null!=loanDetails){
            	
				if(commonData.getCustomer().getPreference() != null){
					
					//20E2-CSH -SBGEXP-8227 - added condition to check CSH/Efinance/Homeloan combination
					int cshIndicator = LoanAppUtil.getCSHTileIndicator(commonData.getCustomer().getPreference().getCcPLLoanInd());
					
					if(commonData.getCustomer().getPreference().getCcPLLoanInd() == LoanAppConstants.PRF_CCLOANIND_EFINANCE || commonData.getCustomer().getPreference().getCcPLLoanInd() == LoanAppConstants.PRF_CCLOANIND_EFINANCE_HOMELOAN_BOTH
							|| cshIndicator == LoanAppConstants.PRF_CCLOANIND_EFINANCE
							|| cshIndicator == LoanAppConstants.PRF_CCLOANIND_EFINANCE_HOMELOAN_BOTH){
						serviceResponse=loanApplicationHelper.populateLoanApplicationDetail(commonData, loanService);
					}
				}              
                
				if(null != serviceResponse)
					serviceResponse.setHeader(headerResp);

                return (IMBResp)serviceResponse; 
            }
            else{
            	return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.GENERIC_ERROR, ServiceConstants.ONLINE_REG, httpRequest);
            }
            
        } catch(Exception e) {                    
            return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.GENERIC_ERROR, ServiceConstants.ONLINE_REG, httpRequest);
            
        } finally {
        	Logger.debug("LoanStatusController - redirectToDashBoard() - End.", this.getClass()); 
        }    
    }
}
