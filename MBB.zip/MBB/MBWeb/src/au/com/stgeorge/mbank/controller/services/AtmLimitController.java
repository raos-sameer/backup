/**
 * 
 */
package au.com.stgeorge.mbank.controller.services;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;

import au.com.stgeorge.framework.common.logging.Logger;
import au.com.stgeorge.ibank.businessobject.BusinessException;
import au.com.stgeorge.ibank.businessobject.CardService;
import au.com.stgeorge.ibank.businessobject.ResourceException;
import au.com.stgeorge.ibank.common.cache.IBankParams;
import au.com.stgeorge.ibank.valueobject.ATMLimitUpdate;
import au.com.stgeorge.ibank.valueobject.transfer.IBankCommonData;
import au.com.stgeorge.mbank.controller.IMBController;
import au.com.stgeorge.mbank.model.common.IMBReq;
import au.com.stgeorge.mbank.model.common.IMBResp;
import au.com.stgeorge.mbank.model.common.ReqHeader;
import au.com.stgeorge.mbank.model.common.RespHeader;
import au.com.stgeorge.mbank.model.request.EmptyReq;
import au.com.stgeorge.mbank.model.request.services.AtmLimitUpdateReq;
import au.com.stgeorge.mbank.model.response.ErrorResp;
import au.com.stgeorge.mbank.session.MobileSession;
import au.com.stgeorge.mbank.util.MBAppHelper;
import au.com.stgeorge.mbank.util.MBAppUtils;
import au.com.stgeorge.mbank.util.MBAppValidator;
import au.com.stgeorge.mbank.util.ServiceConstants;
import au.com.stgeorge.perflogger.PerformanceLogger;

import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * @author c50216
 *
 */
@Controller
@RequestMapping("/atmlimit")
public class AtmLimitController implements IMBController{

	@Autowired
	private CardService cardService;
	
	@Autowired
	private MBAppHelper mbAppHelper;
	
	@Autowired
	private MBAppValidator mbAppValidator;
	
	@Autowired
	private PerformanceLogger perfLogger;
	
	@Autowired
	private AtmLimitHelper atmLimitHelper;			
	
	@RequestMapping(value= "cards" , method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public IMBResp processCards(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse,
			@RequestBody final EmptyReq req)
	{				
				
		ObjectMapper objectMapper = new ObjectMapper();							
		perfLogger.startAllLogs();
		String logName = MBAppUtils.getLogName(httpServletRequest);
		perfLogger.startLog(logName);		
		MobileSession mbSession = null;		
		try{	
			
			mbSession = mbAppHelper.getMobileSession(httpServletRequest);												
			Logger.info("atmlimit.processCards check Info JSON Request :" + objectMapper.writeValueAsString(req), this.getClass());
			
			validateRequestHeader(req.getHeader(), httpServletRequest);
			ErrorResp errorResp = validate(req, httpServletRequest);
			if (errorResp != null && errorResp.getErrors() != null && errorResp.getErrors().size() > 0)
			{									
				return errorResp;
			}								
			
			IBankCommonData commonData=mbAppHelper.populateIBankCommonData(mbSession, httpServletRequest);
			
			List<ATMLimitUpdate> cardList = (ArrayList<ATMLimitUpdate>)cardService.getCardsListForATMUpdate(mbSession.getUser().getGCISNumber(), commonData);
			
			mbSession.setAtmLimitCardList(cardList);			
			
			IMBResp serviceResponse = atmLimitHelper.populateCardsResp(cardList);						
			RespHeader headerResp = populateResponseHeader(ServiceConstants.ATM_LIMIT_GET_CARDS, mbSession);
			serviceResponse.setHeader(headerResp);			
			Logger.info("atmlimit.processCards JSON Response :" + objectMapper.writeValueAsString(serviceResponse), this.getClass());
			
			return serviceResponse;		
			
		}catch (BusinessException e)
		{
			BusinessException exp = null;
			Logger.info("BusinessException Inside atmlimit.processCards() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "]", e, this.getClass());		
			
			exp = new BusinessException(e.getKey());
			IMBResp resp1  = MBAppUtils.createErrorResp(mbSession.getOrigin() ,exp, ServiceConstants.ATM_LIMIT_GET_CARDS, httpServletRequest);
			return resp1;
		}catch (ResourceException e) {
			Logger.error("ResourceException Inside atmlimit.processCards() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "]", e, this.getClass());			
			ResourceException exp = new ResourceException(e.getKey());
			IMBResp resp1  = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, ServiceConstants.ATM_LIMIT_GET_CARDS, httpServletRequest);
			return resp1;
		}catch (Exception e)
		{			
			Logger.error("Exception Inside atmlimit.processCards() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "]", e, this.getClass());
			BusinessException exp = new BusinessException(BusinessException.GENERIC_ERROR);
			IMBResp resp1  = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, ServiceConstants.ATM_LIMIT_GET_CARDS, httpServletRequest);
			return resp1;
		} finally
		{
			perfLogger.endLog(logName);
			perfLogger.endAllLogs();
		}				
	}
	
	@RequestMapping(value= "update" , method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public IMBResp processUpdate(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse,
			@RequestBody final AtmLimitUpdateReq req)
	{				
				
		ObjectMapper objectMapper = new ObjectMapper();							
		perfLogger.startAllLogs();
		String logName = MBAppUtils.getLogName(httpServletRequest);
		perfLogger.startLog(logName);		
		MobileSession mbSession = null;		
		try{	
			
			mbSession = mbAppHelper.getMobileSession(httpServletRequest);												
			Logger.info("atmlimit.processCards check Info JSON Request :" + objectMapper.writeValueAsString(req), this.getClass());
			
			validateRequestHeader(req.getHeader(), httpServletRequest);
			ErrorResp errorResp = validate(req, httpServletRequest);
			if (errorResp != null && errorResp.getErrors() != null && errorResp.getErrors().size() > 0)
			{									
				return errorResp;
			}								
			
			IBankCommonData commonData=mbAppHelper.populateIBankCommonData(mbSession, httpServletRequest);						
			List<ATMLimitUpdate> cardList = mbSession.getAtmLimitCardList();
				
			//17E2 Service Interaction and Cross Sell -- Updating the GDW description if originated from Transaction Cross Sell
			String application = null;
			if(req.getFromCrossSell()){
				application = IBankParams.TNX_CROSSSELL;
			}
			
			cardService.updateATMLimit( atmLimitHelper.getAtmLimitAccountFromIndex(req.getIndex(), cardList ), Integer.parseInt(req.getNewLimit()), commonData, application);
			
			List<ATMLimitUpdate> updatedCardList = atmLimitHelper.populateUpdatedCardList(cardList, req.getIndex(), req.getNewLimit());
			mbSession.setAtmLimitCardList(updatedCardList);
			
			IMBResp serviceResponse = atmLimitHelper.populateCardsResp(updatedCardList);
			RespHeader headerResp = populateResponseHeader(ServiceConstants.ATM_LIMIT_UPDATE, mbSession );
			serviceResponse.setHeader(headerResp);						
			
			Logger.info("atmlimit.processCards JSON Response :" + objectMapper.writeValueAsString(serviceResponse), this.getClass());
					
			return serviceResponse;					
		}catch (BusinessException e)
		{
			BusinessException exp = null;
			Logger.info("BusinessException Inside atmlimit.processUpdate() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "]", e, this.getClass());		
			
			exp = new BusinessException(e.getKey());
			IMBResp resp1  = MBAppUtils.createErrorResp(mbSession.getOrigin() ,exp, ServiceConstants.ATM_LIMIT_UPDATE, httpServletRequest);
			return resp1;
		}catch (ResourceException e) {
			Logger.error("ResourceException Inside atmlimit.processUpdate() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "]", e, this.getClass());			
			ResourceException exp = new ResourceException(e.getKey());
			IMBResp resp1  = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, ServiceConstants.ATM_LIMIT_UPDATE, httpServletRequest);
			return resp1;
		}catch (Exception e)
		{			
			Logger.error("Exception Inside atmlimit.processUpdate() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "]", e, this.getClass());
			BusinessException exp = new BusinessException(BusinessException.GENERIC_ERROR);
			IMBResp resp1  = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, ServiceConstants.ATM_LIMIT_UPDATE, httpServletRequest);
			return resp1;
		} finally
		{
			perfLogger.endLog(logName);
			perfLogger.endAllLogs();
		}				
	}
	
	/**
	 * Response for invalid body request 
	 * 
	 * @return
	 */
	@ExceptionHandler({org.springframework.http.converter.HttpMessageNotReadableException.class})
	@ResponseStatus(org.springframework.http.HttpStatus.OK)
	@ResponseBody
	public IMBResp resolveException() {		
		return MBAppUtils.createInvalidMessageBodyResponse(ServiceConstants.ATM_LIMIT_UPDATE);
	}
	
	public ErrorResp validate(IMBReq serviceRequest, HttpServletRequest request) {
		return mbAppValidator.validate(serviceRequest, request);
	}
	
	public void validateRequestHeader(ReqHeader header, HttpServletRequest request) throws ResourceException
	{	
		mbAppValidator.validateRequestHeader(header,  request);	
	}
	
	public RespHeader populateResponseHeader(String serviceName, MobileSession mobSession )
	{
		return mbAppHelper.populateResponseHeader(serviceName, mobSession);
	}
	
}
