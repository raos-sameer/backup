package au.com.stgeorge.mbank.controller.services;

import au.com.stgeorge.framework.common.logging.Logger;
import au.com.stgeorge.framework.common.util.StringMethods;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class OIDCHelper {

    public static void addCompassAppTypeCookie(String origin, HttpServletRequest request, HttpServletResponse response, String name, String value) {
        String domainName = request.getServerName();
        if(domainName.contains(".")){
            domainName = domainName.substring(domainName.indexOf("."));
        }
        if(! StringMethods.isEmptyString(domainName)){
            response.addHeader("Set-Cookie", name + "=" + value + "; path=/" + "; domain="+domainName);
        }
        else{
            response.addHeader("Set-Cookie", name + "=" + value + "; path=/");
        }

        Logger.info(" Added "+ name + " = "+ value, OIDCHelper.class);
    }



}
