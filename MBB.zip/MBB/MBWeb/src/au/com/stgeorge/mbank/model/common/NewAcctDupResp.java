package au.com.stgeorge.mbank.model.common;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import au.com.stgeorge.mbank.util.JsonDateTimeSerializer;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;

@JsonInclude(Include.NON_NULL)
public class NewAcctDupResp implements Serializable {

	public int getId() {
		return seqid;
	}
	public void setId(int seqid) {
		this.seqid = seqid;
	}

	public BigDecimal getTerm() {
		return newAcctDupTerm;
	}
	public void setTerm(BigDecimal newAcctDupTerm) {
		this.newAcctDupTerm = newAcctDupTerm;
	}
	public String getFromAcct() {
		return newAcctDupFromAcct;
	}
	public void setFromAcct(String newAcctDupFromAcct) {
		this.newAcctDupFromAcct = newAcctDupFromAcct;
	}

	@JsonSerialize(using = JsonDateTimeSerializer.class)
	@JsonInclude(Include.NON_NULL)
	public Date getDateTime() {
		return newAcctDupReqDate;
	}
	public void setDateTime(Date newAcctDupReqDate) {
		this.newAcctDupReqDate = newAcctDupReqDate;
	}
	public String getStatus() {
		return newAcctDupReqStatus;
	}
	public void setStatus(String newAcctDupReqStatus) {
		this.newAcctDupReqStatus = newAcctDupReqStatus;
	}
	public String getAmt() {
		return newAcctDupAmt;
	}
	public void setAmt(String newAcctDupAmt) {
		this.newAcctDupAmt = newAcctDupAmt;
	}

	private int seqid;
	private String newAcctDupAmt;
	private BigDecimal newAcctDupTerm;
	private String newAcctDupFromAcct;
	private Date newAcctDupReqDate;
	private String newAcctDupReqStatus;
	
}
