package au.com.stgeorge.mbank.controller.customer;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.fasterxml.jackson.databind.ObjectMapper;

import au.com.stgeorge.framework.common.logging.Logger;
import au.com.stgeorge.ibank.businessobject.BusinessException;
import au.com.stgeorge.ibank.businessobject.ContactDetailsService;
import au.com.stgeorge.ibank.messagecentre.valueobject.MessageSearch;
import au.com.stgeorge.ibank.valueobject.Customer;
import au.com.stgeorge.ibank.valueobject.CustomerTypes;
import au.com.stgeorge.ibank.valueobject.transfer.IBankCommonData;
import au.com.stgeorge.mbank.controller.IMBController;
import au.com.stgeorge.mbank.model.common.ErrorInfo;
import au.com.stgeorge.mbank.model.common.IMBReq;
import au.com.stgeorge.mbank.model.common.IMBResp;
import au.com.stgeorge.mbank.model.common.ReqHeader;
import au.com.stgeorge.mbank.model.common.RespHeader;
import au.com.stgeorge.mbank.model.request.customer.EmailBounceBackReq;
import au.com.stgeorge.mbank.model.response.ErrorResp;
import au.com.stgeorge.mbank.model.response.SuccessResp;
import au.com.stgeorge.mbank.session.MobileSession;
import au.com.stgeorge.mbank.util.MBAppHelper;
import au.com.stgeorge.mbank.util.MBAppUtils;
import au.com.stgeorge.mbank.util.MBAppValidator;
import au.com.stgeorge.mobilebank.businessobject.EmailBounceBackService;
import au.com.stgeorge.perflogger.PerformanceLogger;
import au.com.stgeorge.wmqi.schema.customer.customerupd.CustUpdResp;

@Controller
@RequestMapping("/emailBounceBack")
public class EmailBounceBackController implements IMBController {

	private static final String EMAIL_LOOKS_CORRECT = "emailLooksCorrect";
	private static final String SKIP_NOW = "skipNow";
	private static final String UPDATE_EMAIL = "updateEmail";

	private static final String EBB_ERROR_MESSAGE = "Something went wrong while updating email address. Please try again later.";

	@Autowired
	private EmailBounceBackService emailBounceBackService;

	@Autowired
	private MBAppHelper mbAppHelper;

	@Autowired
	private MBAppValidator mbAppValidator;

	@Autowired
	private PerformanceLogger perfLogger;

	@RequestMapping(value = "splashPage", method = RequestMethod.POST, headers = "content-type=application/json", produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public IMBResp ebbSplashPageActions(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse,
			@RequestBody final EmailBounceBackReq ebbReq) {

		final String methodName = "EmailBounceBackController.ebbSplashPageActions():";

		String actionType = ebbReq.getActionType();
		Logger.debug(methodName + "actionType: " + actionType, this.getClass());

		IMBResp i5mbResponse = null;

		if (actionType.equals(SKIP_NOW)) {
			i5mbResponse = skipEBBSplashPage(httpServletRequest, httpServletResponse, ebbReq);
		} else if (actionType.equals(EMAIL_LOOKS_CORRECT)) {
			i5mbResponse = emailLooksCorrect(httpServletRequest, httpServletResponse, ebbReq);
		} else if (actionType.equals(UPDATE_EMAIL)) {
			i5mbResponse = updateEmailAddress(httpServletRequest, httpServletResponse, ebbReq);
		}

		return i5mbResponse;
	}

	public IMBResp emailLooksCorrect(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse,
			@RequestBody final EmailBounceBackReq ebbReq) {
		final String methodName = "EmailBounceBackController.emailLooksCorrect():";

		String logName = startPerformanceLog(httpServletRequest);
		MobileSession mbSession = null;
		IBankCommonData commonData = null;
		ObjectMapper mapper = new ObjectMapper();
		String gcisNumber = null;
		Customer customer = null;

		try {
			mbSession = mbAppHelper.getMobileSession(httpServletRequest);
			commonData = new MBAppHelper().populateIBankCommonData(mbSession, httpServletRequest);
			customer = commonData.getCustomer();

			gcisNumber = customer.getGcis();
			Logger.debug(methodName + "gcisNumber: " + gcisNumber, this.getClass());

			validateRequestHeader(ebbReq.getHeader(), httpServletRequest);

			Logger.debug(methodName + "JSON Request: " + mapper.writeValueAsString(ebbReq), this.getClass());

			MessageSearch messageSearch = mbSession.getSplashInfoMsg();

			if (messageSearch != null) {
				Logger.debug(methodName + "getMsgID(): " + messageSearch.getMsgID(), this.getClass());
				Logger.debug(methodName + "getAppField1(): " + messageSearch.getAppField1(), this.getClass());
				Logger.debug(methodName + "getAppField2(): " + messageSearch.getAppField2(), this.getClass());
				Logger.debug(methodName + "getMessageAction(): " + messageSearch.getMessageAction(), this.getClass());
				Logger.debug(methodName + "customer--GCIS# " + gcisNumber, this.getClass());
				Logger.debug(methodName + "user--GCIS# " + commonData.getUser().getGCISNumber(), this.getClass());

				String customerEmail_ = (messageSearch.getAppField2() == null) ? "" : messageSearch.getAppField2();
				Logger.debug(methodName + "customerEmail_: " + customerEmail_, this.getClass());

				String custTypeInd = customer.getCustTypeInd();
				Logger.debug(methodName + "custTypeInd: " + custTypeInd, this.getClass());

				CustomerTypes customerTypes_ = customer.getCustomerTypes();

				String customerNumber_ = null;

				if (customerTypes_.contains(CustomerTypes.TYPE_GHS)) {
					Logger.debug(methodName + "TYPE_GHS: True", this.getClass());
					customerNumber_ = customer.getGHSCISNumber();
				} else if (customerTypes_.contains(CustomerTypes.TYPE_CHS)) {
					Logger.debug(methodName + "TYPE_CHS: True", this.getClass());
					customerNumber_ = customer.getCHSCISNumber();
				} else if (customerTypes_.contains(CustomerTypes.TYPE_CHS_GHS)) {
					Logger.debug(methodName + "TYPE_CHS_GHS: True", this.getClass());
					customerNumber_ = customer.getGHSCISNumber();
				}

				Logger.debug(methodName + "customerNumber_: " + customerNumber_, this.getClass());

				if (customerNumber_ != null) {
					try {
						try {
							CustUpdResp custUpdateResponse = ContactDetailsService
									.updateCustomerEmailAddress(customerEmail_, customerNumber_, custTypeInd);

							if (custUpdateResponse != null) {
								Logger.debug(methodName + "MQSI Response: " + custUpdateResponse.getResp(),
										this.getClass());
							
								if (customer.getContactDetail() != null) {
									customer.getContactDetail().setEmail(customerEmail_);
								}
							}
						} catch (Exception excp) {
							Logger.error(methodName + "Exception caught while MQ email update for GCIS# " + gcisNumber
									+ excp.getMessage(), this.getClass());
						}

						emailBounceBackService.deleteCustomerMessage(messageSearch, commonData);
						emailBounceBackService.addStatisticLog(messageSearch, commonData, "emailLooksCorrect",
								customerEmail_);
						emailBounceBackService.logForensics(commonData, mbAppHelper.getCommonLogData(commonData),
								customerEmail_, customerEmail_);
					} catch (Exception bExc) {
						Logger.error(methodName + "Exception caught while email update for GCIS# " + gcisNumber
								+ bExc.getMessage(), this.getClass());
					}
				}
			}
		} catch (Exception exc) {
			Logger.error(methodName + "Exception caught: GCIS# " + gcisNumber + exc.getMessage(), this.getClass());
		} finally {
			endPerformanceLog(logName);
		}

		SuccessResp successResp = new SuccessResp();
		RespHeader headerResp = populateResponseHeader(ebbReq.getHeader().getServiceName(), mbSession);
		successResp.setHeader(headerResp);

		mbSession.removeSplashInfoMsg();
		successResp.setIsSuccess(Boolean.TRUE);

		mbSession.setLoggedonState(LogonHelper.LOGGEDON_STATE_COMPLETE);

		return successResp;
	}

	private void endPerformanceLog(String logName) {
		perfLogger.endLog(logName);
		perfLogger.endAllLogs();
	}

	@Override
	public RespHeader populateResponseHeader(String serviceName, MobileSession mobileSession) {
		return mbAppHelper.populateResponseHeader(serviceName, mobileSession);
	}

	public IMBResp skipEBBSplashPage(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse,
			@RequestBody final EmailBounceBackReq ebbReq) {
		final String methodName = "EmailBounceBackController.skipEBBSplashPage():";

		String logName = startPerformanceLog(httpServletRequest);
		MobileSession mbSession = null;
		IBankCommonData commonData = null;
		ObjectMapper mapper = new ObjectMapper();
		String gcisNumber = null;

		try {
			mbSession = mbAppHelper.getMobileSession(httpServletRequest);
			commonData = new MBAppHelper().populateIBankCommonData(mbSession, httpServletRequest);

			gcisNumber = commonData.getCustomer().getGcis();

			validateRequestHeader(ebbReq.getHeader(), httpServletRequest);

			Logger.debug(methodName + "JSON Request: " + mapper.writeValueAsString(ebbReq), this.getClass());

			MessageSearch messageSearch = mbSession.getSplashInfoMsg();

			if (messageSearch != null) {
				Logger.debug(methodName + "getMsgID(): " + messageSearch.getMsgID(), this.getClass());
				Logger.debug(methodName + "getAppField1(): " + messageSearch.getAppField1(), this.getClass());
				Logger.debug(methodName + "getAppField2(): " + messageSearch.getAppField2(), this.getClass());
				Logger.debug(methodName + "getMessageAction(): " + messageSearch.getMessageAction(), this.getClass());
				Logger.debug(methodName + "getStatus(): " + messageSearch.getStatus(), this.getClass());
				Logger.debug(methodName + "customer--gcisNumber: " + gcisNumber, this.getClass());
				Logger.debug(methodName + "user--gcisNumber: " + commonData.getUser().getGCISNumber(), this.getClass());

				emailBounceBackService.updateSkipCounter(messageSearch, commonData, "");
			}

			mbSession.removeSplashInfoMsg();
		} catch (Exception exc) {
			Logger.error(methodName + "Exception caught: GCIS# " + gcisNumber + exc.getMessage(), this.getClass());
		} finally {
			endPerformanceLog(logName);
		}

		SuccessResp successResp = new SuccessResp();
		RespHeader headerResp = populateResponseHeader(ebbReq.getHeader().getServiceName(), mbSession);
		successResp.setHeader(headerResp);
		successResp.setIsSuccess(Boolean.TRUE);
		mbSession.setLoggedonState(LogonHelper.LOGGEDON_STATE_COMPLETE);

		return successResp;
	}

	private String startPerformanceLog(HttpServletRequest httpRequest) {
		perfLogger.startAllLogs();
		String logName = MBAppUtils.getLogName(httpRequest);
		perfLogger.startLog(logName);
		return logName;
	}

	public IMBResp updateEmailAddress(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse,
			@RequestBody final EmailBounceBackReq ebbReq) {
		final String methodName = "EmailBounceBackController.updateEmailAddress():";

		String logName = startPerformanceLog(httpServletRequest);
		MobileSession mbSession = null;
		IBankCommonData commonData = null;
		ObjectMapper mapper = new ObjectMapper();
		String gcisNumber = null;
		Customer customer = null;
		ErrorInfo errorInfo = null;
		try {
			mbSession = mbAppHelper.getMobileSession(httpServletRequest);
			commonData = new MBAppHelper().populateIBankCommonData(mbSession, httpServletRequest);

			customer = commonData.getCustomer();
			gcisNumber = customer.getGcis();

			String updatedEmail = ebbReq.getEmailAddress();
			Logger.debug(methodName + "updatedEmail: " + updatedEmail, this.getClass());

			validateRequestHeader(ebbReq.getHeader(), httpServletRequest);

			Logger.debug(methodName + "JSON Request: " + mapper.writeValueAsString(ebbReq), this.getClass());

			MessageSearch messageSearch = mbSession.getSplashInfoMsg();

			if (messageSearch != null) {
				Logger.debug(methodName + "getMsgID(): " + messageSearch.getMsgID(), this.getClass());
				Logger.debug(methodName + "getAppField1(): " + messageSearch.getAppField1(), this.getClass());
				Logger.debug(methodName + "getAppField2(): " + messageSearch.getAppField2(), this.getClass());
				Logger.debug(methodName + "getMessageAction(): " + messageSearch.getMessageAction(), this.getClass());
				Logger.debug(methodName + "customer--GCIS# " + gcisNumber, this.getClass());
				Logger.debug(methodName + "user--GCIS# " + commonData.getUser().getGCISNumber(), this.getClass());

				String custTypeInd = customer.getCustTypeInd();
				Logger.debug(methodName + "custTypeInd: " + custTypeInd, this.getClass());

				CustomerTypes customerTypes_ = customer.getCustomerTypes();

				String customerNumber_ = null;

				if (customerTypes_.contains(CustomerTypes.TYPE_GHS)) {
					Logger.debug(methodName + "TYPE_GHS: True", this.getClass());
					customerNumber_ = customer.getGHSCISNumber();
				} else if (customerTypes_.contains(CustomerTypes.TYPE_CHS)) {
					Logger.debug(methodName + "TYPE_CHS: True", this.getClass());
					customerNumber_ = customer.getCHSCISNumber();
				} else if (customerTypes_.contains(CustomerTypes.TYPE_CHS_GHS)) {
					Logger.debug(methodName + "TYPE_CHS_GHS: True", this.getClass());
					customerNumber_ = customer.getGHSCISNumber();
				}

				Logger.debug(methodName + "customerNumber_: " + customerNumber_, this.getClass());

				if (customerNumber_ != null) {
					try {
						UUID appCorrelationId = UUID.randomUUID();
						boolean isEmailAddUpdateRequired = emailBounceBackService.isEmailAddressUpdateRequired(customer,
								updatedEmail, appCorrelationId, commonData);
						Logger.debug(methodName + "isEmailAddUpdateRequired: " + isEmailAddUpdateRequired,
								this.getClass());

						CustUpdResp custUpdateResponse = ContactDetailsService.updateCustomerEmailAddress(updatedEmail,
								customerNumber_, custTypeInd);

						if (custUpdateResponse != null) {
							Logger.debug(methodName + "MQSI Response: " + custUpdateResponse.getResp(),
									this.getClass());
							if (customer.getContactDetail() != null) {
								customer.getContactDetail().setEmail(updatedEmail);
							}
						}

						emailBounceBackService.deleteCustomerMessage(messageSearch, commonData);
						emailBounceBackService.addStatisticLog(messageSearch, commonData, "updateEmail", updatedEmail);
						emailBounceBackService.logForensics(commonData, mbAppHelper.getCommonLogData(commonData),
								customer.getContactDetail().getEmail(), updatedEmail);
					} catch (BusinessException bExc) {
						int exceptionKey = bExc.getKey();
						String additionalDetails = (bExc.getAdditionalDetails() == null) ? null
								: (String) bExc.getAdditionalDetails();

						Logger.debug(
								methodName + "Business exception caught: " + exceptionKey + " : " + additionalDetails,
								this.getClass());

						if (additionalDetails != null) {
							errorInfo = new ErrorInfo();
							errorInfo.setCode(String.valueOf(exceptionKey));
							errorInfo.setMessage(additionalDetails);
						} else {
							errorInfo = new ErrorInfo();
							errorInfo.setCode(String.valueOf(1));
							errorInfo.setMessage(EBB_ERROR_MESSAGE);
						}
					} catch (Exception bExc) {
						Logger.error(methodName + "Exception caught while email update for GCIS# " + gcisNumber
								+ bExc.getMessage(), this.getClass());
						errorInfo = new ErrorInfo();
						errorInfo.setCode(String.valueOf(1));
						errorInfo.setMessage(EBB_ERROR_MESSAGE);
					}
				}
			}
		} catch (Exception exc) {
			Logger.error(methodName + "Exception caught: GCIS# " + gcisNumber + exc.getMessage(), this.getClass());
		} finally {
			endPerformanceLog(logName);
		}

		SuccessResp successResp = new SuccessResp();
		RespHeader headerResp = populateResponseHeader(ebbReq.getHeader().getServiceName(), mbSession);
		successResp.setHeader(headerResp);

		if (errorInfo == null) {
			mbSession.removeSplashInfoMsg();
			successResp.setIsSuccess(Boolean.TRUE);
		} else {
			successResp.setIsSuccess(Boolean.FALSE);
			List<ErrorInfo> errorList = new ArrayList<ErrorInfo>();
			errorList.add(errorInfo);
			successResp.setErrors(errorList);
		}

		mbSession.setLoggedonState(LogonHelper.LOGGEDON_STATE_COMPLETE);

		return successResp;
	}

	@Override
	public ErrorResp validate(IMBReq serviceRequest, HttpServletRequest httpRequest) throws BusinessException {
		return mbAppValidator.validate(serviceRequest, httpRequest);
	}

	@Override
	public void validateRequestHeader(ReqHeader headerReq, HttpServletRequest request) throws BusinessException {
		mbAppValidator.validateRequestHeader(headerReq, request);
	}

}