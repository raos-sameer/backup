package au.com.stgeorge.mbank.model.common;

import java.io.Serializable;

public class CrossSellDetail implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 7600567667382685471L;
	private ProductReq product;
	public ProductReq getProduct() {
		return product;
	}
	public void setProduct(ProductReq product) {
		this.product = product;
	}
	

}
