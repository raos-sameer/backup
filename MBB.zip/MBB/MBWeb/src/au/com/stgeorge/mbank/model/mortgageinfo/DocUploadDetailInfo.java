package au.com.stgeorge.mbank.model.mortgageinfo;

import java.io.Serializable;
import java.util.List;

import javax.validation.Valid;
import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.Length;
import org.hibernate.validator.constraints.Range;

import au.com.stgeorge.ibank.businessobject.BusinessException;


import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_NULL)
public class DocUploadDetailInfo implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = -3511955740636187428L;
		
	private String maxDocumentSize;	

	private String maxDocumentsUploadSize;
	
	private Long maxDocumentsPerUpload;

	private List<String> allowedDocumentTypes;	

	private String docUploadURL;	
	
	private Boolean showIntro;

	private List<ApplicantInfo> applicants;
	
	private List<DocCategoryDetailInfo> docCategoryDetails;	
	
	private Long clasNum;
		
	public Long getClasNum() {
		return clasNum;
	}

	public void setClasNum(Long clasNum) {
		this.clasNum = clasNum;
	}

	public List<ApplicantInfo> getApplicants() {
		return applicants;
	}

	public void setApplicants(List<ApplicantInfo> applicants) {
		this.applicants = applicants;
	}

	public List<DocCategoryDetailInfo> getDocCategoryDetails() {
		return docCategoryDetails;
	}

	public void setDocCategoryDetails(List<DocCategoryDetailInfo> docCategoryDetails) {
		this.docCategoryDetails = docCategoryDetails;
	}

	public String getMaxDocumentSize() {
		return maxDocumentSize;
	}

	public void setMaxDocumentSize(String maxDocumentSize) {
		this.maxDocumentSize = maxDocumentSize;
	}

	public String getMaxDocumentsUploadSize() {
		return maxDocumentsUploadSize;
	}

	public void setMaxDocumentsUploadSize(String maxDocumentsUploadSize) {
		this.maxDocumentsUploadSize = maxDocumentsUploadSize;
	}

	public Long getMaxDocumentsPerUpload() {
		return maxDocumentsPerUpload;
	}

	public void setMaxDocumentsPerUpload(Long maxDocumentsPerUpload) {
		this.maxDocumentsPerUpload = maxDocumentsPerUpload;
	}

	public List<String> getAllowedDocumentTypes() {
		return allowedDocumentTypes;
	}

	public void setAllowedDocumentTypes(List<String> allowedDocumentTypes) {
		this.allowedDocumentTypes = allowedDocumentTypes;
	}

	public String getDocUploadURL() {
		return docUploadURL;
	}

	public void setDocUploadURL(String docUploadURL) {
		this.docUploadURL = docUploadURL;
	}

	public Boolean getShowIntro() {
		return showIntro;
	}

	public void setShowIntro(Boolean showIntro) {
		this.showIntro = showIntro;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
}
