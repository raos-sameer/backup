package au.com.stgeorge.mbank.controller.payments;

import java.math.BigDecimal;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang.builder.ReflectionToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import au.com.stgeorge.digitalsec.logger.DigitalSecLogger;
import au.com.stgeorge.digitalsec.logger.DigitalSecLogggerVO;
import au.com.stgeorge.framework.common.logging.Logger;
import au.com.stgeorge.framework.common.util.DateMethods;
import au.com.stgeorge.framework.common.util.StringMethods;
import au.com.stgeorge.ibank.businessobject.BusinessException;
import au.com.stgeorge.ibank.businessobject.DuplicateException;
import au.com.stgeorge.ibank.businessobject.ErrorItem;
import au.com.stgeorge.ibank.businessobject.GCCService;
import au.com.stgeorge.ibank.businessobject.globalWallet.GlobalWalletPaymentService;
import au.com.stgeorge.ibank.businessobject.globalWallet.GlobalWalletUtil;
import au.com.stgeorge.ibank.common.cache.IBankParams;
import au.com.stgeorge.ibank.servicestation.businessobject.ServiceStation;
import au.com.stgeorge.ibank.servicestation.businessobject.ServiceStationImpl;
import au.com.stgeorge.ibank.servicestation.businessobject.valueobject.ServiceStationMessage;
import au.com.stgeorge.ibank.servicestation.businessobject.valueobject.ServiceStationVO;
import au.com.stgeorge.ibank.servicestation.util.ServicetationConstants;
import au.com.stgeorge.ibank.util.ServiceHelper;
import au.com.stgeorge.ibank.valueobject.Account;
import au.com.stgeorge.ibank.valueobject.AccountId;
import au.com.stgeorge.ibank.valueobject.AccountPayment;
import au.com.stgeorge.ibank.valueobject.CreditCardAccount;
import au.com.stgeorge.ibank.valueobject.CreditCardPayment;
import au.com.stgeorge.ibank.valueobject.Customer;
import au.com.stgeorge.ibank.valueobject.LoanAccount;
import au.com.stgeorge.ibank.valueobject.Payment;
import au.com.stgeorge.ibank.valueobject.PaymentDuplicateVO;
import au.com.stgeorge.ibank.valueobject.PaymentsLog;
import au.com.stgeorge.ibank.valueobject.Receipt;
import au.com.stgeorge.ibank.valueobject.Statistic;
import au.com.stgeorge.ibank.valueobject.database.CodesVO;
import au.com.stgeorge.ibank.valueobject.database.OriginsVO;
import au.com.stgeorge.ibank.valueobject.transfer.IBankCommonData;
import au.com.stgeorge.mbank.model.common.IMBResp;
import au.com.stgeorge.mbank.model.common.RespHeader;
import au.com.stgeorge.mbank.model.request.payments.AcctTransferReq;
import au.com.stgeorge.mbank.model.response.payments.CCDetailResp;
import au.com.stgeorge.mbank.model.response.payments.CCInfoResp;
import au.com.stgeorge.mbank.model.response.payments.DDAMessageResp;
import au.com.stgeorge.mbank.model.response.payments.FundTDAResp;
import au.com.stgeorge.mbank.model.response.payments.RedrawFeeResp;
import au.com.stgeorge.mbank.model.response.payments.RedrawMessageResp;
import au.com.stgeorge.mbank.model.response.payments.TransferReceiptResp;
import au.com.stgeorge.mbank.model.response.payments.TransferResp;
import au.com.stgeorge.mbank.session.MobileSession;
import au.com.stgeorge.mbank.util.MBAppHelper;
import au.com.stgeorge.mbank.util.MBAppUtils;
import au.com.stgeorge.mbank.util.ServiceConstants;
import au.com.stgeorge.mobilebank.businessobject.MobileBankService;
import au.com.stgeorge.mobilebank.businessobject.TransactService;

/**
 * Account to account transfer service helper
 * 
 * @author C38854
 * 
 */


@Service
public class AccountTransferHelper extends TransferHelper {
	
    private static Integer MIN_AMT_CC_TRANSFER_TYPE = 0;
	private static Integer LAST_STMT_AMT_CC_TRANSFER_TYPE = 1;
	private static Integer CURR_BAL_CC_TRANSFER_TYPE = 2;
	private static Integer OTHER_CC_TRANSFER_TYPE = 3;

	private static HashMap<Integer, String> ccTransTypes;
	
	static {
		ccTransTypes = new HashMap<Integer, String>();
		ccTransTypes.put(MIN_AMT_CC_TRANSFER_TYPE, CreditCardPayment.OPTION_MINIMUM);
		ccTransTypes.put(LAST_STMT_AMT_CC_TRANSFER_TYPE, CreditCardPayment.OPTION_STETEMENT_BALANCE);
		ccTransTypes.put(CURR_BAL_CC_TRANSFER_TYPE, CreditCardPayment.OPTION_FULL);
		ccTransTypes.put(OTHER_CC_TRANSFER_TYPE, CreditCardPayment.OPTION_AMOUNT);
	}
	
	@Autowired
	private MobileBankService mobileBankService;

	@Autowired
	private GlobalWalletPaymentService globalWalletPaymentService;
	
	/**
	 * Additional validation for transfer request
	 * 
	 * @param req
	 * @throws BusinessException
	 */
	protected void validateTransferReq(AcctTransferReq request) throws BusinessException {
		if (request.getScheduleDetail() != null) {
			validateTransferSchedule(request.getScheduleDetail());
		}
		
//		if (req.getCcPaymentType() != null && ccTransTypes.get(req.getCcPaymentType()) == null) {
//			throw new BusinessException(BusinessException.CC_INVALID_PAYMENT_OPTION);
//		}
	}

	/**
	 * Populate Payment bean for transfer
	 * 
	 * @param customer
	 * @param commonData
	 * @param request
	 * @param ip
	 * @param sessionId
	 * @return
	 * @throws BusinessException
	 */
	private Payment populatePayment(Account fromAccount, Account toAccount, Customer customer, IBankCommonData commonData, AcctTransferReq request) throws BusinessException {
		String customerName = customer.getFirstName() + " " + customer.getLastName();
		if (customerName.length() > 24) {
			customerName = customerName.substring(0, 24);
		}
		Payment payment;
		if (Account.CRA.equalsIgnoreCase(toAccount.getAccountId().getApplicationId())) {
			payment = new CreditCardPayment();
			((CreditCardPayment) payment).setToCard(toAccount.getAccountId());

			if (request.getCcPaymentType() != null) {
				((CreditCardPayment) payment).setPaymentOption(ccTransTypes.get(request.getCcPaymentType()));
			} else {
				throw new BusinessException(BusinessException.CC_INVALID_PAYMENT_OPTION);
			}
		} else {
			payment = new AccountPayment();
			((AccountPayment) payment).setToAccount(toAccount.getAccountId());

			if (Account.CDA.equalsIgnoreCase(toAccount.getAccountId().getApplicationId())) {
				if (toAccount.getAvailableBalance().compareTo(BigDecimal.ZERO) == 0) {
					((AccountPayment) payment).setTransferType(Statistic.TD_INIT_DEPOSIT);
				} else {
					((AccountPayment) payment).setTransferType(Statistic.TD_ADNL_DEPOSIT);
				}
			}
		}

		if (fromAccount.isApplicationIdLis()) {
			LoanAccount fromLoanAccount = getLoanAccountById(fromAccount.getAccountId(), commonData);
			if (fromAccount.isApplicationIdLis() && fromLoanAccount != null) {
				payment.setFromLoanLimits(fromLoanAccount.getLimits());
				payment.setFromLoanRedrawFee(fromLoanAccount.getRedrawFee());
			}
		}

		if ((request.getScheduleID() !=null && !"".equals(request.getScheduleID())) || request.getScheduleDetail() != null){
			payment.setSchedule(true);
			payment.setScheduleDetails(populateScheduleDetails(request.getScheduleID(), commonData, request.getScheduleDetail(), request.getSendEmail(), customer.getContactDetail()
					.getEmail()));
		} else {
			payment.setSchedule(false);
		}
		payment.setBatch(false);
		payment.setCommonData(commonData);
		payment.setFromAccount(fromAccount.getAccountId());
		payment.setAmount(new BigDecimal(request.getAmt()));
		payment.setDescription(request.getDesc());
		if (payment.getDescription() == null) {
			payment.setDescription("");
		}
		// if to account is TDA change transfer type
		payment.setIpAddress(commonData.getIpAddress());
		payment.setSessionId(commonData.getSessionId());
		payment.setBrand(commonData.getOrigin());
		payment.setCheckForDuplicate(true);
		if (request.getOverrideDup() != null)
			payment.setCheckForDuplicate(!request.getOverrideDup());
		if (request.getDupCount() != null)
			payment.setDuplicatePaymentCount(request.getDupCount());
		payment.setPayerName(customerName);
		
		if (request.getFavTranID()!=null) payment.setFavTranId(request.getFavTranID());
		
		payment.setOrigination(request.getOrigination());
		
		return payment;
	}

	public LoanAccount getLoanAccountById(AccountId accountId, IBankCommonData commonData) throws BusinessException {
		LoanAccount fromLoanAccount = (LoanAccount) mobileBankService.getAccount(accountId, commonData);
		return fromLoanAccount;
	}

	/**
	 * Populate response
	 */
	protected TransferResp populateTransferResponse(RespHeader header, Receipt receipt, Payment payment, Customer updatedCustomer, AccountId toAccountId,IBankCommonData commonData) {

		return populateTransferResponse(header,receipt,payment,updatedCustomer,toAccountId,commonData,null,null);
	}
		
	public TransferResp populateTransferResponse(RespHeader header, Receipt receipt, Payment payment, Customer updatedCustomer, AccountId toAccountId,IBankCommonData commonData,MobileSession mbsession,ServiceStationVO serviceStationVO) {
		
		TransferResp response = super.populateTransferResponse(header, receipt, payment, updatedCustomer);
		response = super.populateTeaserResponse(response, commonData,"Account To Account Transfer Receipt");
		if(null!=response.getTeaserResp())
		{
			if(null!=response.getTeaserResp().getSalesOfferTeaserResp())
			{
				if(null==response.getTeaserResp().getSalesOfferTeaserResp().getIsAccountTfrReceipt())
				{
					if(null!=serviceStationVO)
					{
					   response=super.populateServiceStationResponse(response, serviceStationVO);
					   if(null!=mbsession)
						{
							mbsession.setServiceStationMessage(serviceStationVO.getServiceStationMsg());
						}
					}
				}
			}
		}		
		Account toAccount = MBAppHelper.getAccountbyAccountId(toAccountId, updatedCustomer.getAccounts());
		
		if (toAccount != null) {
			if (toAccount.getAvailableBalance() != null) {
				response.getReceipt().setToAccountAvailBalance(String.valueOf(toAccount.getAvailableBalance()));
			}
			
			if (toAccount.getBalanceDisplay() != null) {
				response.getReceipt().setToAccountBalance(String.valueOf(toAccount.getBalanceDisplay()));
			}
			
			response.getReceipt().setToAccountNum(toAccount.getAccountId().getAccountNumber());								
		}
		
		//Used for WWW transactions. PaymentLog() is needed for pooling
		if(mbsession != null && receipt != null && receipt.getPaymentLog() != null && receipt.getPaymentLog().getXrefType() != null){
			
			String xRefType = receipt.getPaymentLog().getXrefType();
			if(xRefType.equalsIgnoreCase(PaymentsLog.TYPE_TRANSFER_WWW_LOAD) || xRefType.equalsIgnoreCase(PaymentsLog.TYPE_TRANSFER_WWW_UNLOAD)){
				mbsession.setPaymentsLogId(receipt.getPaymentLog().getId()+"");
			}
			
			//Store the selected from account index in session. It will be used in pooling service.
			if(xRefType.equalsIgnoreCase(PaymentsLog.TYPE_TRANSFER_WWW_LOAD)){
				Account fromAccount = MBAppHelper.getAccountbyAccountId(payment.getFromAccount(), updatedCustomer.getAccounts());
				if (fromAccount != null) {
					mbsession.setSelectedAccountIndex(fromAccount.getIndexAsString());	
				}
				
			}
			
			//Store the selected to account index in session. It will be used in pooling service.
			if(xRefType.equalsIgnoreCase(PaymentsLog.TYPE_TRANSFER_WWW_UNLOAD)){
				if (toAccount != null) {
					mbsession.setSelectedAccountIndex(toAccount.getIndexAsString());	
				}
				
			}
			
		}
		
		Logger.debug("AccountTransferHelper - performTransfer(). Response: " + response, this.getClass());
		return response;
	}

	/**
	 * Populate CC Details response
	 * 
	 * @param header
	 * @param account
	 * @return
	 */
	protected CCDetailResp populateCCDetailResponse(RespHeader header, CreditCardAccount account) {
		CCDetailResp response = new CCDetailResp(header);
		response.setCreditCardInfo(new CCInfoResp());
		response.getCreditCardInfo().setPaymentOverDue(
				account.getNextPaymentDate() != null && account.getNextPaymentDate().before(DateMethods.getUtilDate()));
		response.getCreditCardInfo().setNextPaymentDate(account.getNextPaymentDate());
		BigDecimal minPay = account.getMinimumPaymentAmount();
		if (account.getPayNowAmount().compareTo(account.getMinimumPaymentAmount()) == 1)
			minPay = account.getPayNowAmount();
		if (minPay.compareTo(new BigDecimal("0")) == -1)
			minPay = new BigDecimal("0");
		response.getCreditCardInfo().setCcMinPaymentAmt(/* mobileHelper.getFormattedAmount */String.valueOf(minPay));
		response.getCreditCardInfo().setCcFullPayoutAmt(/* mobileHelper.getFormattedAmount */String.valueOf(account.getFullPayoutAmount()));
		// response.getCreditCardInfo().set(/*mobileHelper.getFormattedAmount*/String.valueOf(account.getPayNowAmount()));
		response.getCreditCardInfo().setStmtBalanceAmt(/* mobileHelper.getFormattedAmount */String.valueOf(account.getStmtBalAmount()));
		response.getCreditCardInfo().setLastStmtDate(/* mobileHelper.getFormattedAmount */account.getLastStatementDate());
		response.getCreditCardInfo().setAllowMinPayment(minPay.compareTo(new BigDecimal("0")) > 0);
		response.getCreditCardInfo().setAllowFullAmtPayment(account.getFullPayoutAmount().compareTo(new BigDecimal("0")) > 0);
		response.getCreditCardInfo().setAllowStmtBalancePayment(account.getStmtBalAmount().compareTo(new BigDecimal("0")) > 0);
		response.getCreditCardInfo().setCurrentDate(new Date());
		Logger.info("Response: " + response, this.getClass());
		return response;
	}
	
	/**
	 * Populate Fund TDA response
	 * 
	 * @param header
	 * @param account
	 * @return
	 */
	protected FundTDAResp populateTDAFundingDetailResponse(RespHeader header, String billerCodeOrigin, String termDepBillerCode) {
		FundTDAResp response = new FundTDAResp(header);
		response.setBillerCodeOrigin(billerCodeOrigin);
		response.setTermDepBillerCode(termDepBillerCode);
		Logger.info("Response: " + response, this.getClass());
		return response;
	}

	/**
	 * 
	 * @param header
	 * @param fee
	 * @return
	 */
	protected IMBResp populateRedrawFeeResponse(RespHeader header, String fee) {
		RedrawFeeResp response = new RedrawFeeResp(header);
		response.setFee(fee);
		Logger.info("Response: " + response, this.getClass());
		return response;
	}
	
	/**
	 * 
	 * @param header
	 * @param message
	 * @return
	 */
	protected IMBResp populateRedrawMessageResponse(RespHeader header, String message, String bcopResponse) {
		RedrawMessageResp response = new RedrawMessageResp(header);
		response.setMessage(message);
		response.setBcopFixedResiLoanMessage(bcopResponse);
		Logger.info("Response: " + response, this.getClass());
		return response;
	}
	protected IMBResp populateDDAMessageResponse(RespHeader header, String ddaResponse) {
		DDAMessageResp response = new DDAMessageResp(header);
		response.setBcopPortfolioFixedLoanMessage(ddaResponse);
		Logger.info("Response: " + response, this.getClass());
		return response;
	}
	
	public long getInsertionPointCode(String insertionPointString){
		List<CodesVO> CodesVOList = (List<CodesVO>) IBankParams.getCodesDataList(IBankParams.DEFAULT_ORIGIN, ServicetationConstants.CD_CATEGORY_SERVICETATION_INSERTION_PT);
		long insertionPointValue = 0;
		for(CodesVO codesVO : CodesVOList){
			if(codesVO.getMessage().trim().equalsIgnoreCase(insertionPointString)){
				if(StringMethods.isValidString(codesVO.getCode())){
					insertionPointValue = Long.parseLong(codesVO.getCode());
					break;
				}
			}
		}
		if(insertionPointValue == 0){
			Logger.warn("NO match found in RELEASECODES table for the insertion point "+insertionPointString, this.getClass());
		}
		return insertionPointValue;
	}
	
	public ServiceStationVO populateServiceMessage(ServiceStation serviceStationService, long insertionPoint, String channel, IBankCommonData commonData) {
		ServiceStationVO serviceStationAdminVo = null;
		try	{			
		   serviceStationAdminVo = serviceStationService.getServiceMessage(insertionPoint, ServiceStationImpl.CHANNEL_MOBILE, commonData);			
		} catch(BusinessException ex) {
			Logger.error("An error occurred while getting service station message for mobile accoutn details", ex, this.getClass());
		}
		
		return serviceStationAdminVo;
	}
	
	public Receipt pay(Payment payment, boolean isScheduled, Account toAccount , Account fromAccount, GCCService gccService, TransactService transactService) throws BusinessException {
		Logger.debug("Payment object - " + ReflectionToStringBuilder.toString(payment, ToStringStyle.MULTI_LINE_STYLE), this.getClass());
		//Receipt receipt = transactService.performTransfer(payment);
		Receipt receipt = null;

		if (Account.GCC.equalsIgnoreCase(toAccount.getAccountId().getApplicationId())) {
			receipt = gccService.performTransfer(fromAccount, toAccount, payment.getAmount(), payment.getCommonData(), payment.isCheckForDuplicate(), payment.getDuplicatePaymentCount() );
		} 
/*		else if (Account.GWC.equalsIgnoreCase(toAccount.getAccountId().getApplicationId()) || Account.GWC.equalsIgnoreCase(fromAccount.getAccountId().getApplicationId())) {
			receipt = globalWalletPaymentService.performTransfer(payment, toAccount , fromAccount );
		}*/
		else if (Account.GWC.equalsIgnoreCase(toAccount.getAccountId().getApplicationId())) {
			receipt = globalWalletPaymentService.loadGlobalWallet(payment, toAccount , fromAccount );
		} else if (Account.GWC.equalsIgnoreCase(fromAccount.getAccountId().getApplicationId())) {
				receipt = globalWalletPaymentService.unloadGlobalWallet(payment, toAccount , fromAccount );
		} else {
			receipt = transactService.performTransfer(payment);
		}
		
		Logger.debug("Receipt - " + ReflectionToStringBuilder.toString(receipt, ToStringStyle.MULTI_LINE_STYLE), this.getClass());		
		return receipt;
	}
	
	public IMBResp performTransfer(MobileSession mobileSession, 
								   Account fromAccount, 
								   Account toAccount, 
								   IBankCommonData commonData, 
								   AcctTransferReq request,
								   HttpServletRequest httpRequest, 
								   MBAppHelper mbAppHelper, 
								   GCCService gccService, 
								   TransactService transactService,
								   ServiceStation serviceStationService,
								   DigitalSecLogger digitalSecLogger,
								   boolean isScheduled, 
								   String caller) throws BusinessException {
		
		Payment payment = populatePayment(fromAccount, toAccount, mobileSession.getCustomer(), commonData, request);			
		Boolean sendMail = isValidSendMailFlag(request.getSendEmail());		
		mobileSession.setSendPaymentEmail(sendMail);
		
		DigitalSecLogggerVO digitalSecLoggerVO = createDigitalSecurityLogVO(commonData, mbAppHelper);
		
		try {			
			if (Account.GCC.equalsIgnoreCase(toAccount.getAccountId().getApplicationId())) {
				GCCService thisGccService = (GCCService) ServiceHelper.getBean("gccService");
				ErrorItem errorItem = thisGccService.verifyGCCTranDetail(toAccount,payment.getAmount(),payment.getCommonData());
				if (errorItem != null) {
					Logger.warn("GCC verify Failed ... Key : "+errorItem.getKey()  , this.getClass());
					if (errorItem.getValues() != null) {
						return MBAppUtils.createErrorResp(mobileSession.getOrigin(), errorItem.getKey(), MBAppUtils.getMessage(mobileSession.getOrigin(), errorItem.getKey(), errorItem.getValues()), caller, httpRequest);
					} else {
						return MBAppUtils.createErrorResp(mobileSession.getOrigin(), errorItem.getKey(), ServiceConstants.ACCOUNT_TRANSFER_SERVICE, httpRequest);
					}
				}
			}
			
/*
			
			// To Be Removed Boby
			if (Account.GWC.equalsIgnoreCase(toAccount.getAccountId().getApplicationId()) || Account.GWC.equalsIgnoreCase(fromAccount.getAccountId().getApplicationId()) ) {

				Logger.info("Stubbed Data for GWC " , this.getClass());

				TransferResp transferResponse = new TransferResp( populateResponseHeader(ServiceConstants.ACCOUNT_TRANSFER_SERVICE, mobileSession, mbAppHelper)  );
				transferResponse.setReceipt(new TransferReceiptResp());
				transferResponse.getReceipt().setAmt("1000".toString());
				transferResponse.getReceipt().setStatus(0);
				transferResponse.getReceipt().setStatusDescription("");
				transferResponse.getReceipt().setTranTypeDisp("A/C Transfer");
				transferResponse.getReceipt().setTranDateTime(new Date());
				transferResponse.getReceipt().setFromAccountAvailBalance(fromAccount.getAvailableBalance().toString());
				transferResponse.getReceipt().setFromAccountBalance(fromAccount.getBalance().toString());

				transferResponse.getReceipt().setFromAccountNum(fromAccount.getAccountId().getAccountNumber());
				transferResponse.getReceipt().setReceiptNumDisp("M 1168 8003");
				transferResponse.getReceipt().setPaymentLogId(new Integer("1222222"));

				if ( toAccount != null && toAccount.getBalance() != null )
				{
					transferResponse.getReceipt().setToAccountAvailBalance(toAccount.getBalance().toString());
					transferResponse.getReceipt().setToAccountBalance(toAccount.getBalance().toString());
					transferResponse.getReceipt().setToAccountNum(toAccount.getAccountId().getAccountNumber());
				}
				transferResponse.getReceipt().setOnUsTransfer(false);
				transferResponse.getReceipt().setIsStatusUnknown(false);
				Logger.info("Stubbed Data for GWC End " , this.getClass());
						
				return transferResponse;
			}

*/
			Receipt receipt = pay(payment, isScheduled, toAccount,fromAccount, gccService, transactService);
			
			Customer updatedCustomer = payment.getCommonData().getCustomer();
			mobileSession.setCustomer(updatedCustomer);
			
			// send email if needed
			if (mobileSession.isSendPaymentEmail() != null && mobileSession.isSendPaymentEmail() && !isScheduled) {
				// if an email needs to be sent to cust, call sendAcctEmailReceipt
				transactService.sendAcctEmailReceipt(payment, receipt, MBAppHelper.getAccountbyAccountId(payment.getFromAccount(), updatedCustomer.getAccounts()), toAccount);
			}
			
			doDigitalSecurityLog(mobileSession, toAccount, payment,	digitalSecLogger, digitalSecLoggerVO);
			
			if (payment.getFavTranId() != null) {
				try {
					mobileBankService.updateFavouriteTransactionAmount(commonData, payment.getFavTranId(), payment.getAmount().doubleValue());
				} catch (Throwable e) {
					// do nothing
					Logger.info("Exception when updating favourite transaction - GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
				}
			}
			
			// removing the service station message from session			
			ServiceStationMessage serviceMessage = mobileSession.getServiceStationMessage();
			if(serviceMessage != null)
			{
				mobileSession.removeServiceStationMessage();
			}		
			
			// Getting the  Service Station VO			
			long insertionPt = getInsertionPointCode(ServicetationConstants.ACCOUNT_TRANSFER_RECEIPT);
			ServiceStationVO servicestationVO = populateServiceMessage(serviceStationService, insertionPt,ServiceStationImpl.CHANNEL_MOBILE, commonData);		
			
			return populateTransferResponse(populateResponseHeader(ServiceConstants.ACCOUNT_TRANSFER_SERVICE, mobileSession, mbAppHelper), receipt, payment, mobileSession.getCustomer(), toAccount.getAccountId(), commonData, mobileSession, servicestationVO);
		}
		catch (DuplicateException e) {
			Logger.info("DuplicateException in AccountTransferHelper - transfer() - [key: " + e.getKey() + "] : GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());
			if (e.getKey() == BusinessException.DUPLICATE_PAYMENT) {
				return populateTransferResponse(populateResponseHeader(caller, mobileSession, mbAppHelper), (List<PaymentDuplicateVO>) ((DuplicateException) e).getDuplicatePaymentList(), mobileSession.getCustomer().getAccounts());
			}
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), e, caller, httpRequest);
		} catch (BusinessException e) {			
			Logger.info("BusinessException in AccountTransferHelper - transfer() - [key: " + e.getKey() + "] : GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());
			
			if (Account.CRA.equalsIgnoreCase(toAccount.getAccountId().getApplicationId())){
				digitalSecLoggerVO.setTranName(DigitalSecLogger.CREDIT_CARD_TRANSFER);
			}
			
			digitalSecLoggerVO.setStatus(DigitalSecLogger.FAILURE);
			digitalSecLogger.log(digitalSecLoggerVO);
			
			if (e.getKey() == BusinessException.GCC_ESB_TECH_ERROR) {
				String[] phoneNumbers = getGCCPhoneNumber(commonData.getOrigin());
				return MBAppUtils.createErrorResp(mobileSession.getOrigin(), e, phoneNumbers, ServiceConstants.ACCOUNT_TRANSFER_SERVICE, httpRequest);
			} else if (e.getKey() == BusinessException.ACCOUNT_AMT_BELOW_MIN_REDRAW) {
				String minAmt = "";
				if (fromAccount != null && fromAccount.getLimits() != null) {
					minAmt = String.valueOf(fromAccount.getLimits().getMinimumRedrawAmount());
				}
				
				return MBAppUtils.createErrorResp(mobileSession.getOrigin(), e.getKey(), MBAppUtils.getMessage(mobileSession.getOrigin(), e.getKey(), new String[] { minAmt }), caller, httpRequest);
			} else if(e.getKey() == BusinessException.EXCEED_DAILY_LIMIT){//No to show TP error message
				return MBAppUtils.createErrorResp("ALL", e.getKey(), ServiceConstants.ACCOUNT_TRANSFER_SERVICE, httpRequest);
			} else if (e.getKey() == BusinessException.INVALID_CHAR_SET) {
				throw new BusinessException(BusinessException.INVALID_CHAR_SET, "Invalid Character");
			} else if (e.getKey() == BusinessException.AMT_EXCEEDS_AVAILABLE_AMT){
				return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.EXCEED_AVAILABLE_BALANCE, MBAppUtils.getMessage(mobileSession.getOrigin(), BusinessException.EXCEED_AVAILABLE_BALANCE), caller, httpRequest);
			} else if (e.getKey() == BusinessException.GLOBAL_WALLET_MAX_LOAD_AMOUNT_FAILED){
				BigDecimal dailyLimit = GlobalWalletUtil.MAX_LOAD_AMOUNT;
				CodesVO codes = IBankParams.getCodesData(IBankParams.getBaseOriginCode(commonData.getOrigin()), IBankParams.CATEGORY_GLOBAL_WALLET, IBankParams.GLOBAL_WALLET_LOAD_DAILY_LIMIT);
				if(null != codes && !StringMethods.isEmptyString(codes.getMessage())){
					dailyLimit = new BigDecimal(codes.getMessage().trim());
		    	}

				//Format the amount and send error message
				String[] dailyLimits = new String[] {MBAppUtils.getFormattedWholeAmount(dailyLimit)};
				return MBAppUtils.createErrorResp(mobileSession.getOrigin(), e, dailyLimits, ServiceConstants.ACCOUNT_TRANSFER_SERVICE, httpRequest);

			}else if (e.getKey() == BusinessException.GLOBAL_WALLET_LIMIT_CHECK_ACCT_BAL_AND_ROLLING_BAL_FAILED){//20E2 -- WWW -- If checkLimit failed for ACCT_BAL and ROLLING_BAL .
				return MBAppUtils.createErrorResp(mobileSession.getOrigin(), e, e.getValues(), ServiceConstants.ACCOUNT_TRANSFER_SERVICE, httpRequest);

			} else if(e.getValues() !=null){
				return MBAppUtils.createErrorResp(mobileSession.getOrigin(), e.getKey(), MBAppUtils.getMessage(mobileSession.getOrigin(), e.getKey(), e.getValues()), caller, httpRequest);
			} else {
				return MBAppUtils.createErrorResp(mobileSession.getOrigin(), e.getKey(), MBAppUtils.getMessage(mobileSession.getOrigin(), e.getKey()), caller, httpRequest);
			}
		} 
	}

	private DigitalSecLogggerVO createDigitalSecurityLogVO(IBankCommonData commonData, MBAppHelper mbAppHelper) {
		DigitalSecLogggerVO digitalSecLoggerVO = new DigitalSecLogggerVO();
        digitalSecLoggerVO.setTranName(DigitalSecLogger.ACCT_TO_ACCT_TRANSFER);
        digitalSecLoggerVO.setStatus(DigitalSecLogger.SUCCESS);
		digitalSecLoggerVO.setCommonLogData(mbAppHelper.getCommonLogData(commonData));
		digitalSecLoggerVO.setUserAgent(commonData.getUserAgent());
		return digitalSecLoggerVO;
	}

	private void doDigitalSecurityLog(MobileSession mobileSession, Account toAccount, Payment payment, DigitalSecLogger digitalSecLogger, DigitalSecLogggerVO digitalSecLoggerVO) {
		String emailId = "";
		boolean isSendPaymentEmail = false;
		
		if (mobileSession.isSendPaymentEmail() != null && mobileSession.isSendPaymentEmail()) {
			mobileSession.removeSendPaymentEmail();
			isSendPaymentEmail = true;
			emailId = payment.getCommonData().getCustomer().getContactDetail().getEmail();
		}			
		
		if ((!Account.CRA.equalsIgnoreCase(toAccount.getAccountId().getApplicationId()) && (payment.getScheduleDetails() == null))
				||	((!Account.CRA.equalsIgnoreCase(toAccount.getAccountId().getApplicationId())&&(payment.getScheduleDetails() != null))
						&& (payment.getScheduleDetails().getId() == null || "".equals(payment.getScheduleDetails().getId())))) {
			
			digitalSecLoggerVO.setValues(((AccountPayment)payment).toDigitalSecurityLog(isSendPaymentEmail, emailId));
			digitalSecLogger.log(digitalSecLoggerVO);
		}
		
		if ((Account.CRA.equalsIgnoreCase(toAccount.getAccountId().getApplicationId()) && (payment.getScheduleDetails() == null))
				|| 	((Account.CRA.equalsIgnoreCase(toAccount.getAccountId().getApplicationId()) && (payment.getScheduleDetails() != null)) 
						&& (payment.getScheduleDetails().getId() == null || "".equals(payment.getScheduleDetails().getId())))) {
			 
			digitalSecLoggerVO.setTranName(DigitalSecLogger.CREDIT_CARD_TRANSFER);
			digitalSecLoggerVO.setValues(((CreditCardPayment)payment).toDigitalSecurityLog(isSendPaymentEmail, emailId));
			digitalSecLogger.log(digitalSecLoggerVO);
		}
	}
	
	public RespHeader populateResponseHeader(String serviceName, MobileSession mobSession, MBAppHelper mbAppHelper) {
		return mbAppHelper.populateResponseHeader(serviceName, mobSession);
	}
	
	public String[] getGCCPhoneNumber(String origin){
		String[] phoneNumbers = new String[2];
		OriginsVO myOriginVO  = IBankParams.getOrigin(origin);
		OriginsVO baseOrigin  = IBankParams.getOrigin(myOriginVO.getBankName());
		CodesVO codesVO = IBankParams.getCodesData(baseOrigin.getBankName(), "GCCDetails", GCCService.GCC_HELPDESKCONTACT);
		phoneNumbers[0] = codesVO.getMessage(); 
		CodesVO overSeaeNumCodesVO = IBankParams.getCodesData(baseOrigin.getBankName(), "GCCDetails", GCCService.GCC_OVERSEASCONTACT);
		phoneNumbers[1] = overSeaeNumCodesVO.getMessage(); 
		return phoneNumbers ;
	}

}
