package au.com.stgeorge.mbank.model.request.businessaccount;

import java.util.List;

import javax.validation.Valid;

import au.com.stgeorge.mbank.model.common.AddressReq;
import au.com.stgeorge.mbank.model.common.IMBReq;
import au.com.stgeorge.mbank.model.common.ReqHeader;
import au.com.stgeorge.mbank.model.request.customer.ev.CRSInfo;

public class BusinessAccountOpenReq implements IMBReq{

	/**
	 * 
	 */
	private static final long serialVersionUID = -2962071236500731154L;
	private String abnNumber;
	private String acnNumber;
	private String companyName;
	private String businessName;
	@Valid
	private AddressReq companyAddress;
	private String companyAddressId;
	private String addressId;
	@Valid
	private AddressReq businessAddress;
	private String businessAddressId;
	private String industryType;
	private boolean crossSell;
	private CRSInfo crsInfo;
	private List<String> sourceOfFunds;
	private List<String> sourceOfWealth;
	private String employmentType;
	private String occupationType;
    private boolean alternateNameCaptured;
	private boolean pobrCaptured;
	private String stateOfRegistration;
	private boolean sameAsBusinessAddress;
	private String tradingName;
	private String companyABN;
	
	private String additionalSourceOfFund;
	private String additionalSourceOfWealth;
	
	private boolean isActivate;
	
	private ReqHeader header;
	
	public ReqHeader getHeader()
	{
		return header;
	}
	public void setHeader(ReqHeader header)
	{
		this.header = header;
	}
	public String getBusinessName() {
		return businessName;
	}
	public void setBusinessName(String businessName) {
		this.businessName = businessName;
	}
	
	public String getIndustryType() {
		return industryType;
	}
	public void setIndustryType(String industryType) {
		this.industryType = industryType;
	}
	public boolean isCrossSell() {
		return crossSell;
	}
	public void setCrossSell(boolean crossSell) {
		this.crossSell = crossSell;
	}
	public String getAbnNumber() {
		return abnNumber;
	}
	public void setAbnNumber(String abnNumber) {
		this.abnNumber = abnNumber;
	}
	public String getAddressId() {
		return addressId;
	}
	public void setAddressId(String addressId) {
		this.addressId = addressId;
	}
	public CRSInfo getCrsInfo() {
		return crsInfo;
	}
	public void setCrsInfo(CRSInfo crsInfo) {
		this.crsInfo = crsInfo;
	}
	public String getAcnNumber() {
		return acnNumber;
	}
	public void setAcnNumber(String acnNumber) {
		this.acnNumber = acnNumber;
	}
	public String getCompanyName() {
		return companyName;
	}
	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}
	public List<String> getSourceOfFunds() {
		return sourceOfFunds;
	}
	public void setSourceOfFunds(List<String> sourceOfFunds) {
		this.sourceOfFunds = sourceOfFunds;
	}
	public List<String> getSourceOfWealth() {
		return sourceOfWealth;
	}
	public void setSourceOfWealth(List<String> sourceOfWealth) {
		this.sourceOfWealth = sourceOfWealth;
	}
	public AddressReq getCompanyAddress() {
		return companyAddress;
	}
	public void setCompanyAddress(AddressReq companyAddress) {
		this.companyAddress = companyAddress;
	}
	public String getCompanyAddressId() {
		return companyAddressId;
	}
	public void setCompanyAddressId(String companyAddressId) {
		this.companyAddressId = companyAddressId;
	}
	public AddressReq getBusinessAddress() {
		return businessAddress;
	}
	public void setBusinessAddress(AddressReq businessAddress) {
		this.businessAddress = businessAddress;
	}
	public String getBusinessAddressId() {
		return businessAddressId;
	}
	public void setBusinessAddressId(String businessAddressId) {
		this.businessAddressId = businessAddressId;
	}
	public String getStateOfRegistration() {
		return stateOfRegistration;
	}
	public void setStateOfRegistration(String stateOfRegistration) {
		this.stateOfRegistration = stateOfRegistration;
	}
	public boolean isSameAsBusinessAddress() {
		return sameAsBusinessAddress;
	}
	public void setSameAsBusinessAddress(boolean sameAsBusinessAddress) {
		this.sameAsBusinessAddress = sameAsBusinessAddress;
	}
	public String getTradingName() {
		return tradingName;
	}
	public void setTradingName(String tradingName) {
		this.tradingName = tradingName;
	}
	public String getCompanyABN() {
		return companyABN;
	}
	public void setCompanyABN(String companyABN) {
		this.companyABN = companyABN;
	}
	public boolean isActivate() {
		return isActivate;
	}
	public void setActivate(boolean isActivate) {
		this.isActivate = isActivate;
	}
	public String getAdditionalSourceOfFund() {
		return additionalSourceOfFund;
	}
	public void setAdditionalSourceOfFund(String additionalSourceOfFund) {
		this.additionalSourceOfFund = additionalSourceOfFund;
	}
	public String getAdditionalSourceOfWealth() {
		return additionalSourceOfWealth;
	}
	public void setAdditionalSourceOfWealth(String additionalSourceOfWealth) {
		this.additionalSourceOfWealth = additionalSourceOfWealth;
	}
	public String getEmploymentType() {
		return employmentType;
	}
	public void setEmploymentType(String employmentType) {
		this.employmentType = employmentType;
	}
	public String getOccupationType() {
		return occupationType;
	}
	public void setOccupationType(String occupationType) {
		this.occupationType = occupationType;
	}
	public boolean isAlternateNameCaptured() {
		return alternateNameCaptured;
	}
	public void setAlternateNameCaptured(boolean alternateNameCaptured) {
		this.alternateNameCaptured = alternateNameCaptured;
	}
	public boolean isPobrCaptured() {
		return pobrCaptured;
	}
	public void setPobrCaptured(boolean pobrCaptured) {
		this.pobrCaptured = pobrCaptured;
	}
	
	
}
