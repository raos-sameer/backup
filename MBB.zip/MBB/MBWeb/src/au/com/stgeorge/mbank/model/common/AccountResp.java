package au.com.stgeorge.mbank.model.common;

import java.math.BigDecimal;
import java.util.ArrayList;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
@JsonInclude(Include.NON_NULL)
public class AccountResp
{
	AccountKeyInfoResp accountKeyInfo;
	BigDecimal balance;
	BigDecimal availBalance;
	BigDecimal audFee;
	BigDecimal nonAudFee;
	
	AccountControlResp accountControl;
	AccountKeyInfoResp nominatedAccount;
	boolean tdaInInitGrace;

	boolean tdaInRenewGrace;
	boolean craNeedsActivation;
	boolean craInProductTransfer;
	boolean tdaIsFlexiDeposit;
	boolean makeInitialFunding;  // Make a deposit.
	

	BigDecimal loanRedrawFee;
	
	
	ArrayList<Integer> linkedIndexes;
	
	boolean directSaver;
	boolean senseSavings;
	boolean senseEveryday;
	boolean isNOMAccount;
	boolean isHISAAccount;
	
	Boolean isSystemAvail;
	boolean  cardTransfered;
	
	String replaceAcctNum;
	Boolean craOnHold;
	private Boolean isIncentiveSaver;
	
	private boolean autoApplyRetentionInd;   
	private String custMsgId;
	private Boolean ccClosureTile = false;
	private boolean showCashAdvChk;
	private boolean showBcopGoldInvestMsg;
	private String goldCashInvestmentFees;
	
	private String homeLoanDigiOfferFlag;
	private String homeLoanDigiMaturityDate;
	private boolean newHomeLoanDigiOffer;
	  
	//private Boolean isGCCMasterCard;
	private boolean isSBlockCard; //Added to set indicator for sBlockCard
	private String transitionFlag;
	private Integer smartPlanActivePlans;
	private BigDecimal smartPlanTotalRemAmt;
	
	//21E1Madisonreplacement card change
	
	private Boolean isReplacementCard;
	private Boolean isTempReplacementCard;
 
	public String getGoldCashInvestmentFees() {
		return goldCashInvestmentFees;
	}
	public void setGoldCashInvestmentFees(String goldCashInvestmentFees) {
		this.goldCashInvestmentFees = goldCashInvestmentFees;
	}
	public BigDecimal getAudFee() {
		return audFee;
	}
	public void setAudFee(BigDecimal audFee) {
		this.audFee = audFee;
	}
	public BigDecimal getNonAudFee() {
		return nonAudFee;
	}
	public void setNonAudFee(BigDecimal nonAudFee) {
		this.nonAudFee = nonAudFee;
	}

	
	public Boolean getIsIncentiveSaver() {
		return isIncentiveSaver;
	}
	public void setIsIncentiveSaver(Boolean isIncentiveSaver) {
		this.isIncentiveSaver = isIncentiveSaver;
	}
	
	
	public Boolean getCraOnHold()
	{
		return craOnHold;
	}
	public void setCraOnHold(Boolean craOnHold)
	{
		this.craOnHold = craOnHold;
	}
	public String getReplaceAcctNum()
	{
		return replaceAcctNum;
	}
	public void setReplaceAcctNum(String replaceAcctNum)
	{
		this.replaceAcctNum = replaceAcctNum;
	}

	public boolean isTdaInInitGrace()
	{
		return tdaInInitGrace;
	}

	public void setTdaInInitGrace(boolean tdaInInitGrace)
	{
		this.tdaInInitGrace = tdaInInitGrace;
	}

	

	public boolean isIsNOMAccount()
	{
		return isNOMAccount;
	}

	public void setNOMAccount(boolean isNOMAccount)
	{
		this.isNOMAccount = isNOMAccount;
	}

	public boolean isIsDirectSaver()
	{
		return directSaver;
	}

	public void setDirectSaver(boolean directSaver)
	{
		this.directSaver = directSaver;
	}

	public boolean isIsSenseSavings()
	{
		return senseSavings;
	}

	public void setSenseSavings(boolean senseSavings)
	{
		this.senseSavings = senseSavings;
	}

	public boolean isIsSenseEveryday()
	{
		return senseEveryday;
	}

	public void setSenseEveryday(boolean senseEveryday)
	{
		this.senseEveryday = senseEveryday;
	}

	


	
	public ArrayList<Integer> getLinkedIndexes()
	{
		return linkedIndexes;
	}

	public void setLinkedIndexes(ArrayList<Integer> linkedIndexes)
	{
		this.linkedIndexes = linkedIndexes;
	}



	public AccountKeyInfoResp getAccountKeyInfo()
	{
		return accountKeyInfo;
	}

	public void setAccountKeyInfo(AccountKeyInfoResp accountID)
	{
		this.accountKeyInfo = accountID;
	}

	public BigDecimal getBalance()
	{
		return balance;
	}

	public void setBalance(BigDecimal balance)
	{
		this.balance = balance;
	}

	public BigDecimal getAvailBalance()
	{
		return availBalance;
	}

	public void setAvailBalance(BigDecimal availBalance)
	{
		this.availBalance = availBalance;
	}

	public AccountControlResp getAccountControl()
	{
		return accountControl;
	}

	public void setAccountControl(AccountControlResp accountControl)
	{
		this.accountControl = accountControl;
	}

	public AccountKeyInfoResp getNominatedAccount()
	{
		return nominatedAccount;
	}

	public void setNominatedAccount(AccountKeyInfoResp nominatedAccount)
	{
		this.nominatedAccount = nominatedAccount;
	}


	public boolean isTdaInRenewGrace()
	{
		return tdaInRenewGrace;
	}

	public void setTdaInRenewGrace(boolean tdaInRenewGraceal)
	{
		this.tdaInRenewGrace = tdaInRenewGraceal;
	}

	public boolean isCraNeedsActivation()
	{
		return craNeedsActivation;
	}

	public void setCraNeedsActivation(boolean craNeedsActivation)
	{
		this.craNeedsActivation = craNeedsActivation;
	}

	public boolean isCraInProductTransfer()
	{
		return craInProductTransfer;
	}

	public void setCraInProductTransfer(boolean craInProductTransfer)
	{
		this.craInProductTransfer = craInProductTransfer;
	}

	public boolean isTdaIsFlexiDeposit()
	{
		return tdaIsFlexiDeposit;
	}

	public void setTdaIsFlexiDeposit(boolean tdaIsFlexiDeposit)
	{
		this.tdaIsFlexiDeposit = tdaIsFlexiDeposit;
	}

	public BigDecimal getLoanRedrawFee()
	{
		return loanRedrawFee;
	}

	public void setLoanRedrawFee(BigDecimal loanRedrawFee)
	{
		this.loanRedrawFee = loanRedrawFee;
	}
	
	public boolean isMakeInitialFunding()
	{
		return makeInitialFunding;
	}

	public void setMakeInitialFunding(boolean makeInitialFunding)
	{
		this.makeInitialFunding = makeInitialFunding;
	}

	public Boolean getIsSystemAvail() {
		return isSystemAvail;
	}

	public void setIsSystemAvail(Boolean isSystemAvail) {
		this.isSystemAvail = isSystemAvail;
	}

	public boolean getIsHISAAccount() {
		return isHISAAccount;
	}

	public void setIsHISAAccount(boolean isHISAAccount) {
		this.isHISAAccount = isHISAAccount;
	}
	public boolean isAutoApplyRetentionInd() {
		return autoApplyRetentionInd;
	}
	public void setAutoApplyRetentionInd(boolean autoApplyRetentionInd) {
		this.autoApplyRetentionInd = autoApplyRetentionInd;
	}
	public String getCustMsgId() {
		return custMsgId;
	}
	public void setCustMsgId(String custMsgId) {
		this.custMsgId = custMsgId;
	}
	public Boolean getCcClosureTile() {
		return ccClosureTile;
	}
	public void setCcClosureTile(Boolean ccClosureTile) {
		this.ccClosureTile = ccClosureTile;
	}
	public boolean isShowCashAdvChk() {
		return showCashAdvChk;
	}
	public void setShowCashAdvChk(boolean showCashAdvChk) {
		this.showCashAdvChk = showCashAdvChk;
	}
	public boolean isShowBcopGoldInvestMsg() {
		return showBcopGoldInvestMsg;
	}
	public void setShowBcopGoldInvestMsg(boolean showBcopGoldInvestMsg) {
		this.showBcopGoldInvestMsg = showBcopGoldInvestMsg;
	}
	public String getHomeLoanDigiOfferFlag() {
		return homeLoanDigiOfferFlag;
	}
	public void setHomeLoanDigiOfferFlag(String homeLoanDigiOfferFlag) {
		this.homeLoanDigiOfferFlag = homeLoanDigiOfferFlag;
	}
	public String getHomeLoanDigiMaturityDate() {
		return homeLoanDigiMaturityDate;
	}
	public void setHomeLoanDigiMaturityDate(String homeLoanDigiMaturityDate) {
		this.homeLoanDigiMaturityDate = homeLoanDigiMaturityDate;
	}
	/*@JsonInclude(Include.NON_DEFAULT)
	public Boolean getIsGCCMasterCard() {
		return isGCCMasterCard;
	}
	public void setIsGCCMasterCard(Boolean isGCCMasterCard) {
		this.isGCCMasterCard = isGCCMasterCard;
	}*/
	public boolean isNewHomeLoanDigiOffer() {
		return newHomeLoanDigiOffer;
	}
	public void setNewHomeLoanDigiOffer(boolean newHomeLoanDigiOffer) {
		this.newHomeLoanDigiOffer = newHomeLoanDigiOffer;
	}
	public Boolean getIsSBlockCard() {
		return isSBlockCard;
	}
	public void setIsSBlockCard(Boolean isSBlockCard) {
		this.isSBlockCard = isSBlockCard;
	}
	public String getTransitionFlag() {
		return transitionFlag;
	}
	public void setTransitionFlag(String transitionFlag) {
		this.transitionFlag = transitionFlag;
	}
	public Integer getSmartPlanActivePlans() {
		return smartPlanActivePlans;
	}
	public void setSmartPlanActivePlans(Integer smartPlanActivePlans) {
		this.smartPlanActivePlans = smartPlanActivePlans;
	}
	public BigDecimal getSmartPlanTotalRemAmt() {
		return smartPlanTotalRemAmt;
	}
	public void setSmartPlanTotalRemAmt(BigDecimal smartPlanTotalRemAmt) {
		this.smartPlanTotalRemAmt = smartPlanTotalRemAmt; 
	}
	public Boolean getIsReplacementCard() {
		return isReplacementCard;
	}
	public void setIsReplacementCard(Boolean isReplacementCard) {
		this.isReplacementCard = isReplacementCard;
	}
	public Boolean getIsTempReplacementCard() {
		return isTempReplacementCard;
	}
	public void setIsTempReplacementCard(Boolean isTempReplacementCard) {
		this.isTempReplacementCard = isTempReplacementCard;
	}
	
	
}
