package au.com.stgeorge.mbank.controller.payments;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import au.com.stgeorge.framework.common.logging.Logger;
import au.com.stgeorge.framework.common.util.StringMethods;
import au.com.stgeorge.ibank.businessobject.BusinessException;
import au.com.stgeorge.ibank.businessobject.globalWallet.GlobalWalletPaymentService;
import au.com.stgeorge.ibank.businessobject.globalWallet.GlobalWalletUtil;
//import au.com.stgeorge.ibank.businessobject.globalWallet.GlobalWalletUtil.GlobalWalletPaymentStatusMappingEnum;
import au.com.stgeorge.ibank.common.cache.IBankParams;
import au.com.stgeorge.ibank.common.cache.IBankRefershParams;
import au.com.stgeorge.ibank.npp.NPPStatus;
import au.com.stgeorge.ibank.npp.NPPTransactionStatusEnum;
import au.com.stgeorge.ibank.servicestation.businessobject.valueobject.ServiceStationVO;
import au.com.stgeorge.ibank.util.DateUtils;
import au.com.stgeorge.ibank.util.NPPUtil;
import au.com.stgeorge.ibank.util.ServiceHelper;
import au.com.stgeorge.ibank.valueobject.Account;
import au.com.stgeorge.ibank.valueobject.AccountId;
import au.com.stgeorge.ibank.valueobject.AccountPayment;
import au.com.stgeorge.ibank.valueobject.Customer;
import au.com.stgeorge.ibank.valueobject.Invitation;
import au.com.stgeorge.ibank.valueobject.NPPPayment;
import au.com.stgeorge.ibank.valueobject.Payment;
import au.com.stgeorge.ibank.valueobject.PaymentDuplicateVO;
import au.com.stgeorge.ibank.valueobject.PaymentsLog;
import au.com.stgeorge.ibank.valueobject.Receipt;
import au.com.stgeorge.ibank.valueobject.ScheduleDetails;
import au.com.stgeorge.ibank.valueobject.ThirdParty;
import au.com.stgeorge.ibank.valueobject.database.PaymentsLogVO;
import au.com.stgeorge.ibank.valueobject.globalWallet.GlobalWalletReceipt;
import au.com.stgeorge.ibank.valueobject.transfer.IBankCommonData;
import au.com.stgeorge.mbank.controller.offers.SalesOfferHelper;
import au.com.stgeorge.mbank.model.common.IMBResp;
import au.com.stgeorge.mbank.model.common.RespHeader;
import au.com.stgeorge.mbank.model.request.payments.TransferScheduleReq;
import au.com.stgeorge.mbank.model.response.offers.SalesOfferTeaserResp;
import au.com.stgeorge.mbank.model.response.offers.TeaserResp;
import au.com.stgeorge.mbank.model.response.payments.ChangePayeeLimitResp;
import au.com.stgeorge.mbank.model.response.payments.DuplicatePaymentResp;
import au.com.stgeorge.mbank.model.response.payments.NPPValidationsResp;
import au.com.stgeorge.mbank.model.response.payments.TransferReceiptResp;
import au.com.stgeorge.mbank.model.response.payments.TransferResp;
import au.com.stgeorge.mbank.model.response.servicestation.ServiceStationResp;
import au.com.stgeorge.mbank.session.MobileSession;
import au.com.stgeorge.mbank.util.MBAppHelper;
import au.com.stgeorge.mbank.util.MBAppUtils;
import au.com.stgeorge.mbank.util.ServiceConstants;
import au.com.stgeorge.mobilebank.businessobject.MobileBankService;
import au.com.stgeorge.mobilebank.businessobject.ScheduledPaymentService;

/**
 * Generic Transfer Service Helper
 * 
 * @author C38854
 * 
 */

@Service
public class TransferHelper {

	protected static HashMap<String, String> schedules;
	
	@Autowired
	private ScheduledPaymentService scheduledPaymentService;
	
	@Autowired
	private IBankRefershParams ibankRefreshParams;

	static {
		schedules = new HashMap<String, String>();
		schedules.put(ServiceConstants.SCHEDULE_DAILY, ScheduleDetails.FREQUENCY_DAILY);
		schedules.put(ServiceConstants.SCHEDULE_FORTHNIGHTLY, ScheduleDetails.FREQUENCY_FORTNIGHTLY);
		schedules.put(ServiceConstants.SCHEDULE_HALF_YEARLY, ScheduleDetails.FREQUENCY_HALF_YEARLY);
		schedules.put(ServiceConstants.SCHEDULE_MONTHLY, ScheduleDetails.FREQUENCY_MONTHLY);
		schedules.put(ServiceConstants.SCHEDULE_ONCE_ONLY, ScheduleDetails.FREQUENCY_ONCE_ONLY);
		schedules.put(ServiceConstants.SCHEDULE_QUATERLY, ScheduleDetails.FREQUENCY_QUATERLY);
		schedules.put(ServiceConstants.SCHEDULE_WEEKLY, ScheduleDetails.FREQUENCY_WEEKLY);
	}

	/**
	 * Populate service response - receipt
	 * 
	 * @param header
	 * @param receipt
	 * @param payment
	 * @param updatedCustomer
	 * @return
	 */
	protected TransferResp populateTransferResponse(RespHeader header, Receipt receipt, Payment payment, Customer updatedCustomer) {
		TransferResp transferResponse = new TransferResp(header);
		transferResponse.setReceipt(new TransferReceiptResp());
		transferResponse.getReceipt().setAmt(payment.getAmount().toString());
		
		String receiptNumber = null;
		
		if(receipt != null){
			receiptNumber = receipt.getReceiptNumber();
		}
		if (payment.isSchedule() && !StringMethods.isEmptyString(receiptNumber)){
			receiptNumber = "S" + receiptNumber;
		}
		if(!StringMethods.isEmptyString(receiptNumber)){
			transferResponse.getReceipt().setReceiptNumDisp(MBAppUtils.formatReceiptNumber(receiptNumber));
		}else if(receipt.getPaymentLog() != null){
			transferResponse.getReceipt().setReceiptNumDisp(populateReceiptNumberText(receipt.getPaymentLog().getStatus()));
		}
		if (receipt != null && receipt.getPaymentLog() != null){
			
			//19E3: Set the status only in case of NPPPayment
			if(payment != null && payment instanceof NPPPayment){
				transferResponse.getReceipt().setStatus(NPPTransactionStatusEnum.getNppTransactionDisplayStatus(receipt.getPaymentLog().getStatus()));
			}
			//20E2 WWW 
			
			//Start
			AccountPayment accountPayment = null;            
	        if (payment instanceof AccountPayment)
			{
	        	accountPayment = (AccountPayment) payment;

	        	if(accountPayment != null){
		        	if (Account.GWC.equalsIgnoreCase(accountPayment.getToAccount().getApplicationId()) 
							|| Account.GWC.equalsIgnoreCase(accountPayment.getFromAccount().getApplicationId())) {
		        		//transferResponse.getReceipt().setStatus(GlobalWalletPaymentStatusMappingEnum.getWWWTransactionDisplayStatus(receipt.getPaymentLog().getStatus()));
		        		
						//AS SUGGESTED, INSTEAD OF GETTING THE MAPPING STATUS FROM SERVICE UTIL, DOING IN WEB LAYER
		        		int status = -1;
						if(GlobalWalletUtil.isSuccess(receipt.getPaymentLog().getStatus())){
							status = GlobalWalletUtil.PAYMENTS_SUCCESSFUL;//PaymentsLog.PAYMENTSLOG_SUCCESSFUL_TRANSACTION;
						}
						else if(GlobalWalletUtil.isFailure(receipt.getPaymentLog().getStatus())){
							status = GlobalWalletUtil.PAYMENTS_ERROR;//PaymentsLog.PAYMENTSLOG_ERROR_TRANSACTION;
						}
						else if(GlobalWalletUtil.isStillProcessing(receipt.getPaymentLog().getStatus())){
							status = GlobalWalletUtil.PROCESSING_RECEIPT_STATUS;

							if(StringMethods.isEmptyString(receiptNumber)){
								transferResponse.getReceipt().setReceiptNumDisp(GlobalWalletPaymentService.AVAILABLE_AFTER_PROCESSING);								
							}

						}
						transferResponse.getReceipt().setStatus(status);
		        		
						//Commented below code, since now for processing new status has been updated in pl_status. So, moved to above condition.
						/*
		        		//TODO based on pl_status
		        		if(receipt.getPaymentLog().getStatus() == 2){
		        			transferResponse.getReceipt().setReceiptNumDisp(GlobalWalletPaymentService.AVAILABLE_AFTER_PROCESSING);
		        		}
						*/
		        		
		        		if (receipt instanceof GlobalWalletReceipt)
		    			{
		        			GlobalWalletReceipt globalWalletReceipt = (GlobalWalletReceipt)receipt;
		        			
		        			if(globalWalletReceipt.getErrorVO() != null){
		        				transferResponse.getReceipt().setStatusDescription(globalWalletReceipt.getErrorVO().getMessage());
		        				Logger.debug("GWC receipt StatusDescription :"+transferResponse.getReceipt().getStatusDescription(), getClass());
		        			}
		    			}
					}
	        		
	        	}

			}

			//End

			transferResponse.getReceipt().setPaymentLogId(receipt.getPaymentLog().getId());
			transferResponse.getReceipt().setTranTypeDisp(getLastTransactionType(receipt.getPaymentLog().getXrefType()));
			if ( receipt.getPaymentLog().getStatus() == 1 )
			{
				// 435 Failed for GCC
				transferResponse.getReceipt().setWarningCode("GCC015");	
			}
			
		}
		transferResponse.getReceipt().setTranDateTime(receipt.getTimestamp());
		transferResponse.getReceipt().setFromAccountNum(payment.getFromAccount().getAccountNumber());
		Account acc = MBAppHelper.getAccountbyAccountId(payment.getFromAccount(), updatedCustomer.getAccounts());
		if(acc.getAvailableBalance() != null)
			transferResponse.getReceipt().setFromAccountAvailBalance(acc.getAvailableBalance().toString());
		if(acc.getBalanceDisplay() != null)
			transferResponse.getReceipt().setFromAccountBalance(acc.getBalanceDisplay().toString());
		
		NPPPayment nppPayment = null;
		if(payment instanceof NPPPayment && receipt != null && receipt.getPaymentLog() != null && NPPStatus.isFailure(receipt.getPaymentLog().getStatus())) {
			nppPayment = (NPPPayment) payment;
			
			if(nppPayment.isPayIDPayment()) {
				//	populate error message for pay id payment
				transferResponse.getReceipt().setStatusDescription(NPPUtil.getPayIdPaymentRejectionMessage(null, receipt.getPaymentLog().getRejectCode()));
				Logger.debug("Setting payment rejection reason for pay id payment:"+transferResponse.getReceipt().getStatusDescription(), getClass());
				
			} else {
				//	populate error message for Osko BSB/Account payment
				transferResponse.getReceipt().setStatusDescription(NPPUtil.getNPPPaymentRejectionMessage(null, receipt.getPaymentLog().getRejectCode()));
				Logger.debug("Setting payment rejection reason for Osko BSB/Account payment:"+transferResponse.getReceipt().getStatusDescription(), getClass());
			}
		}
		
		Logger.info("Response populated: " + transferResponse, this.getClass());
		return transferResponse;
	}
	
	protected TransferResp populatePaymentLogStatusResp(RespHeader header,PaymentsLogVO paymentsLogVO, Account fromAccount){
		TransferResp transferResponse = new TransferResp(header);
		TransferReceiptResp receipt = new TransferReceiptResp();
		String receiptNumber = null;
		
		if(paymentsLogVO != null){
			
			receiptNumber = paymentsLogVO.getReceiptNumber();
			if(!StringMethods.isEmptyString(receiptNumber)){
				receipt.setReceiptNumDisp(MBAppUtils.formatReceiptNumber(receiptNumber));
			}else{
				receipt.setReceiptNumDisp(populateReceiptNumberText(paymentsLogVO.getStatus()));
			}
			receipt.setStatus(NPPTransactionStatusEnum.getNppTransactionDisplayStatus(paymentsLogVO.getStatus()));
			
			if(NPPUtil.isBsbAccOskoTransfer(paymentsLogVO.getXrefType()) && NPPStatus.isFailure(paymentsLogVO.getStatus())){
				receipt.setStatusDescription(NPPUtil.getNPPPaymentRejectionMessage(null, paymentsLogVO.getRejectCode()));
			}
			
			if(NPPUtil.isPayId(paymentsLogVO.getXrefType()) && NPPStatus.isFailure(paymentsLogVO.getStatus())){
				receipt.setStatusDescription(NPPUtil.getPayIdPaymentRejectionMessage(null, paymentsLogVO.getRejectCode()));
			}
			
			receipt.setIsStatusUnknown(NPPStatus.isUnknown(paymentsLogVO.getStatus()));
			if(null != fromAccount) {
				if(fromAccount.getAvailableBalance() != null)
					receipt.setFromAccountAvailBalance(fromAccount.getAvailableBalance().toString());
				if(fromAccount.getBalanceDisplay() != null)
					receipt.setFromAccountBalance(fromAccount.getBalanceDisplay().toString());
			}
		}
		
		transferResponse.setReceipt(receipt);
		return transferResponse;
	}

	protected TransferResp populateTeaserResponse(TransferResp resp, IBankCommonData commonData,String insertionPoint) {
		
		TeaserResp teaserResp = new TeaserResp();
        SalesOfferTeaserResp salesOfferTeaserResp = new SalesOfferTeaserResp();
        try{ 
        MobileBankService mobileBankService = (MobileBankService) ServiceHelper.getBean("mobileBankService");
        Invitation invitation = (Invitation) mobileBankService.getTeaser(commonData, insertionPoint);
        if(invitation != null)
        	teaserResp.setUnreadOfferCount(invitation.getOfferCount());
        
        SalesOfferHelper offerHelper = (SalesOfferHelper) ServiceHelper.getBean("salesOfferHelper");
        Customer customer = new Customer();
        customer.setInvitation(invitation);
        salesOfferTeaserResp = offerHelper.populateTeaserResp(customer);
        }catch(Exception e){
        	Logger.error("error in getting teaser offers for Account transfer: " + e.getMessage(), this.getClass());
        }
        teaserResp.setSalesOfferTeaserResp(salesOfferTeaserResp);
        resp.setTeaserResp(teaserResp);
		Logger.info("Offer Response populated: ", this.getClass());
		return resp;
	}
	
	/**
	 * Populate service response - duplicate
	 * 
	 * @param header
	 * @param duplicates
	 * @return
	 */
	protected TransferResp populateTransferResponse(RespHeader header, List<PaymentDuplicateVO> duplicates, List<Account> accountList) {
		TransferResp payeeTransferResponse = new TransferResp(header);
		payeeTransferResponse.setDupList(new ArrayList<DuplicatePaymentResp>());
		for (PaymentDuplicateVO duplicateVO : duplicates) {
			DuplicatePaymentResp duplResp = new DuplicatePaymentResp();
			duplResp.setDesc(duplicateVO.getReferenceNumber());
			//if BPAY - desc is null
//			if (this instanceof BPayHelper) duplResp.setDesc(null); - reverted
			duplResp.setFromAccountNumDisp(duplicateVO.getAccountNumberFrom());
			for (Account fromAccount : accountList) {
				if (fromAccount != null && fromAccount.getAccountId() != null) {
					if (fromAccount.getAccountId().getAccountNumber().equals(duplicateVO.getAccountNumberFrom())) {
						duplResp.setFromAccountName(fromAccount.getAlias());
						duplResp.setFromAccountNumDisp(new MBAppHelper().getFormattedAcctNumber(fromAccount
							    .getAccountId().getAccountNumber(), fromAccount.getAccountId()
							    .getApplicationId(), fromAccount.getAccountId().getBsb()));
					}
				}
			}
			duplResp.setTranDateTime(duplicateVO.getPDate());
			duplResp.setSeqNum(duplicateVO.getId());
			payeeTransferResponse.getDupList().add(duplResp);
		}
		return payeeTransferResponse;
	}

	protected NPPValidationsResp populateNPPValidationsResponse(RespHeader header,boolean isOsko,String description,String payerName) {
		NPPValidationsResp nppValidationsResponse = new NPPValidationsResp(header);
		nppValidationsResponse.setOsko(isOsko);
		nppValidationsResponse.setDesc(description);
		nppValidationsResponse.setPayerName(payerName);
		return nppValidationsResponse;		
	}
	
	/**
	 * Populate service response - secure required
	 * 
	 * @param header
	 * @param duplicates
	 * @return
	 */
	protected IMBResp populateSecureRequiredResponse(RespHeader header, Customer customer, String origin, String caller, HttpServletRequest httpRequest) {
		TransferResp payeeTransferResponse = new TransferResp(header);
		payeeTransferResponse.setSecureCodeReqd(Boolean.TRUE);
		if (!new MBAppHelper().hasAnyContactNumbers(customer)){
			return MBAppUtils.createErrorResp(origin, BusinessException.IBANK_SECURE_NO_PHONE_EXIST, caller, httpRequest);
		}
		Logger.debug("Response populated: " + payeeTransferResponse, this.getClass());
		return payeeTransferResponse;
	}

	/**
	 * Populate schedule details
	 * 
	 * @param jsonSchedule
	 * @param sendEmail
	 * @param email
	 * @return
	 * @throws BusinessException
	 */
	protected ScheduleDetails populateScheduleDetails(Integer scheduleID, IBankCommonData commonData, TransferScheduleReq jsonSchedule, Boolean sendEmail, String email) throws BusinessException {
		ScheduleDetails schedule = new ScheduleDetails();
		if (scheduleID!=null && !"".equals(scheduleID)){
			schedule.setId(String.valueOf(scheduleID));
			schedule.setStatusCode(scheduledPaymentService.getScheduledPayment(String.valueOf(scheduleID), commonData).getScheduleDetails().getStatusCode());
		}
		schedule.setFrequency(schedules.get(jsonSchedule.getFreq()));
		if (sendEmail == null) sendEmail = Boolean.FALSE;
		schedule.setEmailReceipt(sendEmail);
		if (sendEmail)
			schedule.setEmailAddress(email);
		
		Calendar firstPay =Calendar.getInstance();
		firstPay.setTime(DateUtils.StringtoDate(jsonSchedule.getFirstPayDate(), DateUtils.ISO_8601_CALENDAR_DATE_FORMAT_PATTERN));
		firstPay.set(Calendar.HOUR_OF_DAY, 0);
		firstPay.set(Calendar.MINUTE, 0);
		firstPay.set(Calendar.SECOND, 0);
		firstPay.set(Calendar.MILLISECOND, 0);		
		
		schedule.setFirstPaymentDate(firstPay.getTime());

		if (!ScheduleDetails.FREQUENCY_ONCE_ONLY.equals(schedule.getFrequency())){
			Calendar lastPay =Calendar.getInstance();
			lastPay.setTime(DateUtils.StringtoDate(jsonSchedule.getLastPayDate(), DateUtils.ISO_8601_CALENDAR_DATE_FORMAT_PATTERN));
			lastPay.set(Calendar.HOUR_OF_DAY, 0);
			lastPay.set(Calendar.MINUTE, 0);
			lastPay.set(Calendar.SECOND, 0);
			lastPay.set(Calendar.MILLISECOND, 0);				
			
			schedule.setLastPaymentDate(lastPay.getTime());
		}
		schedule.setNextPaymentDate(firstPay.getTime());
		
		if (jsonSchedule.getRecreate() != null && jsonSchedule.getRecreate())
			schedule.setDeleteFlag(true);
		
		return schedule;
	}
	
	/**
	 * Validate schedule
	 * 
	 * @param scheduleRequest
	 * @throws BusinessException
	 */
	public void validateTransferSchedule(TransferScheduleReq scheduleRequest) throws BusinessException {
		Date firstPayDate = null;
		Date lastPayDate = null;
		
		if (scheduleRequest.getFirstPayDate() != null && !"".equals(scheduleRequest.getFirstPayDate())) {
			try{
				firstPayDate = DateUtils.StringtoDate(scheduleRequest.getFirstPayDate(), DateUtils.ISO_8601_CALENDAR_DATE_FORMAT_PATTERN);
			}
			catch(BusinessException be){
				if(be.getKey() == BusinessException.WSVC_INVALID_INPUT_PARAM){
					throw new BusinessException(BusinessException.SCHEDULE_PAYMENT_INVALID_FIRST_DATE);
				}
			}
		}
		else
			throw new BusinessException(BusinessException.SCHEDULE_PAYMENT_INVALID_FIRST_DATE);
		
		if (scheduleRequest.getLastPayDate() != null && !"".equals(scheduleRequest.getLastPayDate())) {
//			if (!scheduleRequest.getLastPayDate().after(new Date())) {
//				throw new BusinessException(BusinessException.SCHEDULE_PAYMENT_INVALID_LAST_DATE);
//			} else 
			try{
				lastPayDate = DateUtils.StringtoDate(scheduleRequest.getLastPayDate(), DateUtils.ISO_8601_CALENDAR_DATE_FORMAT_PATTERN);
			}
			catch(BusinessException be){
				if(be.getKey() == BusinessException.WSVC_INVALID_INPUT_PARAM){
					throw new BusinessException(BusinessException.SCHEDULE_PAYMENT_INVALID_LAST_DATE);
				}
			}
			if (lastPayDate.before(firstPayDate)) {
				throw new BusinessException(BusinessException.SCHEDULE_PAYMENT_DATE_FIRST_BEFORE_LAST);
			}
		}
		
		if (schedules.get(scheduleRequest.getFreq()) == null)
			throw new BusinessException(BusinessException.SCHEDULE_PAYMENT_INVALID_FREQUENCY);

		if (!ScheduleDetails.FREQUENCY_ONCE_ONLY.equals(schedules.get(scheduleRequest.getFreq())) && scheduleRequest.getLastPayDate() == null) {
			throw new BusinessException(BusinessException.SCHEDULE_PAYMENT_INVALID_LAST_DATE);
		}
	}
	
	private String getLastTransactionType(String xrefType) {
		String type = IBankParams.getCodesData("ALL", "XrefType", xrefType).getMessage();
		if (type != null) {
			return type;
		}
		return "";
	}
	
	public Boolean isValidSendMailFlag(Boolean sendMail){
		if(sendMail==null){
			return false;
		}
		return sendMail;
	}
	
	/*
	 * 
	 * Common populateResponse for all Transfers for service Station
	 * 
	 */
	
	protected TransferResp populateServiceStationResponse(TransferResp resp,ServiceStationVO serviceStationVO) 
	{
		ServiceStationResp ssResponse = null;
		if(null!=serviceStationVO)
		{
			ServiceStationResp serviceResponse = new ServiceStationResp();
			if(null!=serviceStationVO.getContent())
			{
				serviceResponse.setContent(serviceStationVO.getContent());
			}			
			if(null!=serviceStationVO.getServiceStationMsg())
			{
				serviceResponse.setInsertionPointValue(new Long(serviceStationVO.getServiceStationMsg().getInsertionPointValue()).toString());	
			}
			if(null!=serviceStationVO.getSubject())
			{
				serviceResponse.setSubject(serviceStationVO.getSubject());
			}
			if(null!=serviceStationVO.getServiceStationMsg().getFunctionLink())
			{
				serviceResponse.setFunctionLink(serviceStationVO.getServiceStationMsg().getFunctionLink());
			}
			if(null!=serviceStationVO.getServiceStationMsg().getMessageAction())
			{
				serviceResponse.setMessageAction(serviceStationVO.getServiceStationMsg().getMessageAction());
			}
			if(null!=serviceStationVO.getServiceStationMsg())
			{
			    serviceResponse.setMsgID(new Long(serviceStationVO.getServiceStationMsg().getMsgID()).toString());
			}
			
			resp.setServiceStation(serviceResponse);			
		}		
	  else
		{
			resp.setServiceStation(ssResponse);	
		}		
		return resp;
	}	
	
	/**
	 * @param resp
	 * @param receipt
	 * @param commonData
	 * @return
	 */
	protected TransferResp populateDescriptionPayer(MobileSession mobileSession, TransferResp resp, Receipt receipt, IBankCommonData commonData) {
		if (/*ibankRefreshParams.isNPPOutwardSwitchON(commonData.getOrigin(), mobileSession.getCustomer().getGcis())*/
				"osko".equalsIgnoreCase(mobileSession.getPaymentType())
				&& null != receipt
				&& null != receipt.getPaymentLog()
				&& null != receipt.getPaymentLog().getXrefType()
				&& (receipt.getPaymentLog().getXrefType().equals(PaymentsLog.TYPE_TRANSFER_NPP_DE_RETRY_CUSTOMER) || receipt
						.getPaymentLog().getXrefType().equals(PaymentsLog.TYPE_TRANSFER_NPP_DE_RETRY_BANK))) {
			resp.getReceipt().setDesc(receipt.getPaymentLog().getReferenceNumber());
			resp.getReceipt().setPayerName(receipt.getPaymentLog().getPayerName());
			resp.getReceipt().setEndToEndID(receipt.getPaymentLog().getEndToEndId());
		}
		return resp;
	}
	
	/**
	 * @param receiptNumber
	 * @param paymentsLog
	 * @return
	 */
	protected String populateReceiptNumberText(int status) {
		if (NPPStatus.isStillProcessing(status)) {
			return NPPStatus.AVAILABLE_AFTER_PROCESSING;
		}
		return null;
	}
	
	protected IMBResp populateChangePayeeLimitResponse(RespHeader header, ThirdParty payee, Customer customer, String origin, String caller, HttpServletRequest httpRequest) {
		ChangePayeeLimitResp changePayeeLimitResp = new ChangePayeeLimitResp();
		changePayeeLimitResp.setHeader(header);
		if(payee.getBankSetup()){
			changePayeeLimitResp.setIsUpperLimit(true);
		}else{
			if (!new MBAppHelper().hasAnyContactNumbers(customer)){
				return MBAppUtils.createErrorResp(origin, BusinessException.IBANK_SECURE_NO_PHONE_EXIST, caller, httpRequest);
			}
			changePayeeLimitResp.setIsUpperLimit(false);
		}
		Logger.debug("Response populated: " + changePayeeLimitResp, this.getClass());
		return changePayeeLimitResp;
	}

	//TODO to review
	protected TransferResp populateWWWPaymentLogStatusResp(RespHeader header,PaymentsLogVO paymentsLog, IBankCommonData commonData){
		TransferResp transferResponse = new TransferResp(header);
		TransferReceiptResp receipt = new TransferReceiptResp();
		String receiptNumber = null;
		
		if(paymentsLog != null){
			
			receiptNumber = paymentsLog.getReceiptNumber();
			if(!StringMethods.isEmptyString(receiptNumber)){
				receipt.setReceiptNumDisp(MBAppUtils.formatReceiptNumber(receiptNumber));
			}else{
				receipt.setReceiptNumDisp(populateWWWReceiptNumberText(paymentsLog.getStatus()));
			}
			receipt.setStatus(0);//TODO
			
			
    		int status = -1;
			if(GlobalWalletUtil.isSuccess(paymentsLog.getStatus())){
				status = GlobalWalletUtil.PAYMENTS_SUCCESSFUL;//PaymentsLog.PAYMENTSLOG_SUCCESSFUL_TRANSACTION;
			}
			else if(GlobalWalletUtil.isFailure(paymentsLog.getStatus())){
				status = GlobalWalletUtil.PAYMENTS_ERROR;//PaymentsLog.PAYMENTSLOG_ERROR_TRANSACTION;
				
				String internetBankingCopy = null;
				String errMsg = IBankParams.getErrorMessage( IBankParams.getBaseOriginCode(commonData.getOrigin()), BusinessException.GLOBAL_WALLET_ERDM_FAILURE+"");
				
				if ( paymentsLog.getRejectCode() != null )
				{
					internetBankingCopy = errMsg +"(" + paymentsLog.getRejectCode() +").";
				}
				else
				{
					internetBankingCopy = errMsg +"."; 
				}

				receipt.setStatusDescription(internetBankingCopy);
				Logger.debug("GWC receipt StatusDescription :"+receipt.getStatusDescription(), getClass());

			}
			else if(GlobalWalletUtil.isStillProcessing(paymentsLog.getStatus())){
				status = GlobalWalletUtil.PROCESSING_RECEIPT_STATUS;
			}
			receipt.setStatus(status);

			
			//receipt.setStatusDescription("");//TODO
			
			receipt.setIsStatusUnknown(false);//TODO
/*			if(null != fromAccount) {
				if(fromAccount.getAvailableBalance() != null)
					receipt.setFromAccountAvailBalance(fromAccount.getAvailableBalance().toString());
				if(fromAccount.getBalanceDisplay() != null)
					receipt.setFromAccountBalance(fromAccount.getBalanceDisplay().toString());
			}
*/		}
		
		transferResponse.setReceipt(receipt);
		return transferResponse;
	}
	
	protected String populateWWWReceiptNumberText(int status) {
		if (status > 0) {//TODO need to add the logic
			return GlobalWalletPaymentService.AVAILABLE_AFTER_PROCESSING;
		}
		return null;
	}


}