package au.com.stgeorge.mbank.controller.services;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import org.springframework.stereotype.Service;

import au.com.stgeorge.framework.common.logging.Logger;
import au.com.stgeorge.ibank.businessobject.BusinessException;
import au.com.stgeorge.ibank.businessobject.ResourceException;
import au.com.stgeorge.ibank.businessobject.TaxFileNumberService;
import au.com.stgeorge.ibank.common.cache.IBankParams;
import au.com.stgeorge.ibank.util.StringUtil;
import au.com.stgeorge.ibank.valueobject.database.CodesVO;
import au.com.stgeorge.ibank.valueobject.transfer.IBankCommonData;
import au.com.stgeorge.mbank.model.common.IMBResp;
import au.com.stgeorge.mbank.model.common.KeyValueResp;
import au.com.stgeorge.mbank.model.common.RespHeader;
import au.com.stgeorge.mbank.model.response.StatusResp;
import au.com.stgeorge.mbank.model.response.services.TFNCheckResp;
import au.com.stgeorge.mbank.session.MobileSession;
import au.com.stgeorge.tranhistory.util.StringMethods;
/**
 * Provide TFN service helper
 * 
 * @author C38854
 * 
 */
@Service
public class TFNHelper {
	
	public static final String NUMERIC_REGEX = "^[0-9]*$";
	private static final String ACTION_SUCCESSFUL = "ACTION SUCCESSFUL";

	/**
	 * Populate TFN provided response
	 * 
	 * @param header
	 * @param status
	 * @return
	 */
	public IMBResp populateStatusResponse(RespHeader header, Integer status) {
		StatusResp response = new StatusResp(header);
		response.setStatus(status);
		Logger.info("Response: " + response, this.getClass());
		return response;
	}

	/**
	 * Populate if TFN provided response
	 * 
	 * @param header
	 * @param status
	 * @return
	 */
	protected IMBResp populateTFNCheckResponse(RespHeader header, Boolean tfnExcemption, Boolean tfnHeld) {
		TFNCheckResp response = new TFNCheckResp(header);
		response.setTfnExemption(tfnExcemption);
		response.setTfnHeld(tfnHeld);
		Logger.info("Response: " + response, this.getClass());
		return response;
	}

	/**
	 * Is TFN valid validator
	 * 
	 * @param taxFileNumber
	 * @return
	 */
	public boolean isValidTFN(String taxFileNumber) {
		int[] weights = { 1, 4, 3, 7, 5, 8, 6, 9, 10 };
		long total = 0;
		for (int i = 0; i < 9; i++)
			total = total + (weights[i] * Integer.parseInt(StringUtil.EMPTY_STRING + taxFileNumber.charAt(i)));
		return !(total == 0 || total % 11 != 0);

	}
	
	
	//19E3 Change
	
	public Boolean showTfn(IBankCommonData ibankCommonData, MobileSession mbSession)throws BusinessException {
		Boolean showTfn = null;
		Logger.debug("TFNHelper - showTfn", this.getClass());
		try{
			if(IBankParams.isSwitchOn(ibankCommonData.getOrigin(), IBankParams.TFN_SWITCH)){

				String description = TaxFileNumberService.getTFNDescription(mbSession.getCustomer());
				//throw new Exception();
			    if (!description.equalsIgnoreCase(TaxFileNumberService.TAX_FILE_NUMBER_HELD))
				    showTfn = true;
			    else
			    	showTfn = false;
				 
			}
		}catch(Exception e){
			Logger.warn("TFNHelper - showTfn - something went wrong ..", this.getClass());
			throw new BusinessException(BusinessException.GENERIC_ERROR); 
		}
		
		
		return showTfn;
		
	}
	public List<KeyValueResp> getTFNExemptOptList(){
		List<CodesVO>exemptFrmRlsCode = (List<CodesVO>)(IBankParams.getCodesDataList(IBankParams.BRAND_ORIGIN, IBankParams.TFN_PROPERTIES));
		List<KeyValueResp> exemptTFNOptList = new ArrayList<KeyValueResp>();
		for(CodesVO codeexemptOptListObj : exemptFrmRlsCode){
			KeyValueResp obj = new KeyValueResp();
			obj.setId(codeexemptOptListObj.getCode());
			obj.setName(codeexemptOptListObj.getMessage());
			exemptTFNOptList.add(obj);
		}
		
		Collections.sort(exemptTFNOptList, new Comparator<KeyValueResp>() {
			@Override
			public int compare(KeyValueResp s1, KeyValueResp s2) 
			{
			   return s1.getId().compareToIgnoreCase(s2.getId());
			}
		  });
		
		return exemptTFNOptList;
	}
	
	
	public List<KeyValueResp> getTFNOptionList(){
	  
	  List<KeyValueResp> tfnOptionList = new ArrayList<KeyValueResp>();
	  
	  KeyValueResp keyValueResp1 = new KeyValueResp();
	  keyValueResp1.setId("0");
	  keyValueResp1.setName("I'd like to provide my TFN");
	  
	  KeyValueResp keyValueResp2 = new KeyValueResp();
	  keyValueResp2.setId("1");
	  keyValueResp2.setName("I'll provide my TFN later");
	  
	  
	  KeyValueResp keyValueResp3 = new KeyValueResp();
	  keyValueResp3.setId("2");
	  keyValueResp3.setName("I've got a TFN exemption");
	  
	  tfnOptionList.add(keyValueResp1);
	  tfnOptionList.add(keyValueResp2);
	  tfnOptionList.add(keyValueResp3);

	  return tfnOptionList;
	}
	
	
	//19E3 Changes
	public void validateTFN(String selectedTfnOpt, String tfnNumber ,String selectedExmptValue) throws BusinessException{
		if(!StringMethods.isValidString(selectedTfnOpt))
			throw new BusinessException(BusinessException.TFN_INVALID);
		
		switch(selectedTfnOpt) {
			 case "0" : {
				 Logger.debug("TFNHelper - for tfn validation", this.getClass());
				 if(isValid(tfnNumber)){
					 boolean isValidCheckDigit = isValidTFN(tfnNumber);
					 if(!isValidCheckDigit)
						 throw new BusinessException(BusinessException.TFN_INVALID);
				 }
				 else
					throw new BusinessException(BusinessException.TFN_INVALID);			  
			  
				break; 
			 }
			 case "1":
				 Logger.debug("TFNHelper - provide later. skip validation", this.getClass());
				 break;
			 case "2":{
				 Logger.debug("TFNHelper - for exemption validation", this.getClass());
				 if(!isValid(selectedExmptValue)){
					 throw new BusinessException(BusinessException.CPP_INVALID_TFN_EXEMPTION);
				 }
				 break;
			 }
			 default :
				 throw new BusinessException(BusinessException.TFN_INVALID);
				 
      }
		
	}
	
	//19e3 cHanges
	public boolean updateTFN(IBankCommonData ibankCommonData,String selectedTfnOpt, String tfnNum ,String selectedExmptValue) throws BusinessException, ResourceException{
		String tfnNumber ="";
        boolean updateTfn = false;
        
		switch(selectedTfnOpt) {
		 case "0" : 
			Logger.debug("TFNHelper - updateTFN - updating Tax file Number.", this.getClass());
			tfnNumber = tfnNum;
			break; 
		  case "2":
			 Logger.debug("TFNHelper - updateTFN - updating TFn Exemption.", this.getClass());
			 tfnNumber = selectedExmptValue;
			 break;	 
			 
		}
		String tfnUpdateResp = TaxFileNumberService.submitTaxFileNumber(ibankCommonData.getCustomer(), tfnNumber, ibankCommonData);
		Logger.debug("TFNHelper - updateTFN - tfnupdateResp::"+tfnUpdateResp, this.getClass());
		if(ACTION_SUCCESSFUL.equalsIgnoreCase(tfnUpdateResp)){
			updateTfn = true;
		}/*else{
			//throw some exception to handle not action successful;
		}*/
		
		return updateTfn;
	}
	
	
	public boolean isValid(String selectedVal){
		boolean isValid = false;
		try{
			if(StringMethods.isValidString(selectedVal) && selectedVal.length() == 9){
				if(StringUtil.isValidData(selectedVal, NUMERIC_REGEX)){
					Logger.debug("TFNHelper - valid for length and numeric regex", this.getClass());
					isValid = true;
				}	
			}
		}catch(Exception e){
			// Do nothing ; Just return ""
			Logger.warn("TFNHelper - Something went wrong in validating TFN ", this.getClass());
		}
		return isValid;
	}
	

}
