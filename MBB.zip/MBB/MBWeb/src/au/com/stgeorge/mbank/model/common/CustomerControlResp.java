package au.com.stgeorge.mbank.model.common;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
@JsonInclude(Include.NON_NULL)
public class CustomerControlResp
{
	private boolean allowCchangePwdReqd;
	private boolean allowCchangePwdAndSecNumReqd;
	private boolean allowtAndCAcceptanceReqd;
	private boolean mbUsageInd;

	private boolean allowAccountOpening;
	private boolean allowCardActivation;
	private boolean allowTFNCapture;
	private boolean allowEstmt;
	private boolean allowSMS;
	private boolean allowInitialFunding;
	private boolean allowGetCash;
	private boolean splashPage;
	private boolean allowChangeCardPIN;
	private boolean allowCreditLimitDec;
	private boolean allowExpenseSplitter;
	private boolean allowOffer;
	private String evStatus;
    private boolean sendNativeFirstName;
    private String firstNameDisp;
	private boolean allowCRSOngoing;
	private boolean allowECorrespondence;
	
	private boolean allowBusinessAccOpening;
	private boolean showDirectDebits;
	private boolean showDonations;
	private boolean showOnlineSecurityCheck;

	public boolean isAllowECorrespondence() {
		return allowECorrespondence;
	}

	public void setAllowECorrespondence(boolean allowECorrespondence) {
		this.allowECorrespondence = allowECorrespondence;
	}

	public boolean isAllowCRSOngoing() {
		return allowCRSOngoing;
	}

	public void setAllowCRSOngoing(boolean allowCRSOngoing) {
		this.allowCRSOngoing = allowCRSOngoing;
	}

	public boolean isAllowInitialFunding()
	{
		return allowInitialFunding;
	}

	public void setAllowInitialFunding(boolean allowInitialFunding)
	{
		this.allowInitialFunding = allowInitialFunding;
	}

	private boolean tTReg;
	
	public boolean isTTReg()
	{
		return tTReg;
	}

	public void setTTReg(boolean reg)
	{
		tTReg = reg;
	}

	private boolean firstTimeHelp;

	public boolean isFirstTimeHelp()
	{
		return firstTimeHelp;
	}

	public void setFirstTimeHelp(boolean firstTimeHelp)
	{
		this.firstTimeHelp = firstTimeHelp;
	}

	private boolean schPayEmailNotifyPref;

	public boolean isAllowCchangePwdReqd()
	{
		return allowCchangePwdReqd;
	}

	public void setAllowCchangePwdReqd(boolean allowCchangePwdReqd)
	{
		this.allowCchangePwdReqd = allowCchangePwdReqd;
	}

	public boolean isAllowCchangePwdAndSecNumReqd()
	{
		return allowCchangePwdAndSecNumReqd;
	}

	public void setAllowCchangePwdAndSecNumReqd(boolean allowCchangePwdAndSecNumReqd)
	{
		this.allowCchangePwdAndSecNumReqd = allowCchangePwdAndSecNumReqd;
	}

	public boolean isAllowtAndCAcceptanceReqd()
	{
		return allowtAndCAcceptanceReqd;
	}

	public void setAllowtAndCAcceptanceReqd(boolean allowtAndCAcceptanceReqd)
	{
		this.allowtAndCAcceptanceReqd = allowtAndCAcceptanceReqd;
	}

	public boolean isMbUsageInd()
	{
		return mbUsageInd;
	}

	public void setMbUsageInd(boolean mbUsageInd)
	{
		this.mbUsageInd = mbUsageInd;
	}

	public boolean isAllowAccountOpening()
	{
		return allowAccountOpening;
	}

	public void setAllowAccountOpening(boolean allowAccountOpening)
	{
		this.allowAccountOpening = allowAccountOpening;
	}

	public boolean isAllowCardActivation()
	{
		return allowCardActivation;
	}

	public void setAllowCardActivation(boolean allowCardActivation)
	{
		this.allowCardActivation = allowCardActivation;
	}

	public boolean isAllowTFNCapture()
	{
		return allowTFNCapture;
	}

	public void setAllowTFNCapture(boolean allowTFNCapture)
	{
		this.allowTFNCapture = allowTFNCapture;
	}

	public boolean isAllowEstmt()
	{
		return allowEstmt;
	}

	public void setAllowEstmt(boolean allowEstmt)
	{
		this.allowEstmt = allowEstmt;
	}

	public boolean isAllowSMS()
	{
		return allowSMS;
	}

	public void setAllowSMS(boolean allowSMS)
	{
		this.allowSMS = allowSMS;
	}

	public boolean isSchPayEmailNotifyPref()
	{
		return schPayEmailNotifyPref;
	}

	public void setSchPayEmailNotifyPref(boolean schPayEmailNotifyPref)
	{
		this.schPayEmailNotifyPref = schPayEmailNotifyPref;
	}

	public boolean isAllowGetCash() {
		return allowGetCash;
	}

	public void setAllowGetCash(boolean allowGetCash) {
		this.allowGetCash = allowGetCash;
	}

	public void setSplashPage(boolean splashPage) {
		this.splashPage = splashPage;
	}

	public boolean isSplashPage() {
		return splashPage;
	}

	public boolean isAllowChangeCardPIN() {
		return allowChangeCardPIN;
	}

	public void setAllowChangeCardPIN(boolean allowChangeCardPIN) {
		this.allowChangeCardPIN = allowChangeCardPIN;
	}
	
	public boolean isAllowCreditLimitDec() {
		return allowCreditLimitDec;
	}

	public void setAllowCreditLimitDec(boolean allowCreditLimitDec) {
		this.allowCreditLimitDec = allowCreditLimitDec;
	}

	public boolean isAllowExpenseSplitter() {
		return allowExpenseSplitter;
	}

	public void setAllowExpenseSplitter(boolean allowExpenseSplitter) {
		this.allowExpenseSplitter = allowExpenseSplitter;
	}

	public boolean isAllowOffer()
	{
		return allowOffer;
	}

	public void setAllowOffer(boolean allowOffer)
	{
		this.allowOffer = allowOffer;
	}

	public String getEvStatus() {
		return evStatus;
	}

	public void setEvStatus(String evStatus) {
		this.evStatus = evStatus;
	}
	public boolean isSendNativeFirstName() {
		return sendNativeFirstName;
	}

	public void setSendNativeFirstName(boolean sendNativeFirstName) {
		this.sendNativeFirstName = sendNativeFirstName;
	}

	public String getFirstNameDisp() {
		return firstNameDisp;
	}

	public void setFirstNameDisp(String firstNameDisp) {
		this.firstNameDisp = firstNameDisp;
	}

	public boolean isAllowBusinessAccOpening() {
		return allowBusinessAccOpening;
	}

	public void setAllowBusinessAccOpening(boolean allowBusinessAccOpening) {
		this.allowBusinessAccOpening = allowBusinessAccOpening;
	}
	public boolean isShowDirectDebits() {
		return showDirectDebits;
	}

	public void setShowDirectDebits(boolean showDirectDebits) {
		this.showDirectDebits = showDirectDebits;
	}
	public boolean isShowDonations() {
		return showDonations;
	}

	public void setShowDonations(boolean showDonations) {
		this.showDonations = showDonations;
	}

	public boolean isShowOnlineSecurityCheck() {
		return showOnlineSecurityCheck;
	}

	public void setShowOnlineSecurityCheck(boolean showOnlineSecurityCheck) {
		this.showOnlineSecurityCheck = showOnlineSecurityCheck;
	}
	
}
