package au.com.stgeorge.mbank.controller;

import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.UUID;
import java.util.regex.Pattern;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import au.com.stgeorge.ibank.common.cache.IBankRefershParams;
import au.com.stgeorge.ibank.common.cache.IBankRefreshParamsImpl;
import org.apache.commons.lang.builder.ReflectionToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import au.com.stgeorge.framework.common.logging.Logger;
import au.com.stgeorge.framework.common.util.StringMethods;
import au.com.stgeorge.ibank.businessobject.BusinessException;
import au.com.stgeorge.ibank.businessobject.ContextHandoverService;
import au.com.stgeorge.ibank.businessobject.OIDCService;
import au.com.stgeorge.ibank.businessobject.ResourceException;
import au.com.stgeorge.ibank.businessobject.SystemInformation;
import au.com.stgeorge.ibank.businessobject.globalWallet.GlobalWalletService;
import au.com.stgeorge.ibank.businessobject.homeloan.HomeLoanOBPService;
import au.com.stgeorge.ibank.businessobject.homeloan.HomeLoanOBPServiceHelper;
import au.com.stgeorge.ibank.businessobject.impl.OIDCServiceImpl;
import au.com.stgeorge.ibank.businessobject.model.contexthandover.uiutils.Inline_response_200_1_data_fields;
import au.com.stgeorge.ibank.businessobject.model.contexthandover.uiutils.PostHandoverDataReq;
import au.com.stgeorge.ibank.businessobject.model.contexthandover.uiutils.PostHandoverDataResp;
import au.com.stgeorge.ibank.businessobject.wdp.WDPConstants;
import au.com.stgeorge.ibank.common.cache.IBankParams;
import au.com.stgeorge.ibank.safi.businessobject.Safi2Service;
import au.com.stgeorge.ibank.util.ServiceHelper;
import au.com.stgeorge.ibank.util.StringUtil;
import au.com.stgeorge.ibank.valueobject.Account;
import au.com.stgeorge.ibank.valueobject.Customer;
import au.com.stgeorge.ibank.valueobject.IDPSSODetails;
import au.com.stgeorge.ibank.valueobject.SmartPlanActiveInstalment;
import au.com.stgeorge.ibank.valueobject.Statistic;
import au.com.stgeorge.ibank.valueobject.database.CodesVO;
import au.com.stgeorge.ibank.valueobject.database.GlobalWallet;
import au.com.stgeorge.ibank.valueobject.database.OriginsVO;
import au.com.stgeorge.ibank.valueobject.homeloan.HomeLoanTileContentVO;
import au.com.stgeorge.ibank.valueobject.transfer.IBankCommonData;
import au.com.stgeorge.mbank.controller.customer.LogonHelper;
import au.com.stgeorge.mbank.model.common.IMBResp;
import au.com.stgeorge.mbank.model.common.ReqHeader;
import au.com.stgeorge.mbank.model.common.RespHeader;
import au.com.stgeorge.mbank.model.request.PartnerVendorRequest;
import au.com.stgeorge.mbank.model.response.SuccessResp;
import au.com.stgeorge.mbank.session.MobileSession;
import au.com.stgeorge.mbank.util.MBAppHelper;
import au.com.stgeorge.mbank.util.MBAppUtils;
import au.com.stgeorge.mbank.util.MBAppValidator;
import au.com.stgeorge.mbank.util.ServiceConstants;

@Controller
public class IdpMainController {
	
	private static final int iosApp = 1;

	@Autowired
	private MBAppHelper mbAppHelper; 	
	
	@Autowired
	private HomeLoanOBPServiceHelper homeLoanOBPServiceHelper;
	
	@Autowired
	private HomeLoanOBPService homeLoanOBPService;
	
	@Autowired
	private ContextHandoverService contextHandoverService;	
	
	private static String APP_CSH = "CSHWdp";
	private static String APP_HARDSHIP_FORM= "COVIDWdp";
	private static String APP_CSH_JUPITER = "CSHWdpJupiter";
	private static String APP_CSH_APPLY_ONLINE = "CSHApplyOnline";
	private static String APP_CSH_APPLY_ONLINE_ETB = "CSHApplyOnlineEtb";
	private static String APP_HARDSHIP_FORM_EXIT_EXTEND= "COVIDExitAndExtend";
	private static String APP_COVID_SUPPORT_HUB= "COVIDSupportHub";
	private static final String IBANK_REFRESH_PARAMS_BEAN = "ibankRefreshParams";
	
	@Autowired
	private GlobalWalletService globalWalletService;
	@RequestMapping("/launch") 
	public ModelAndView lanunchApp(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, @RequestParam("app") String app, @RequestParam(value="tId", required = false) String tId, @RequestParam(value="pId", required = false) String pId, @RequestParam(value="locationId", required = false) String locationId,
			@RequestParam(value="fid", required = false) String fid, @RequestParam(value="cid", required = false) String cid, @RequestParam(value="deeplink", required = false) boolean deeplink, 
			@RequestParam(value="appid", required = false) String appid, @RequestParam(value="pid", required = false) String pid, @RequestParam(value="appcnt", required = false) Integer appcnt,
			@RequestParam(value="index", required = false) String index, @RequestParam(value="planType", required = false) String planType) throws BusinessException
	{
		MobileSession mbSession =  null;
		ModelAndView model = null;
		String wdpUrl = IBankParams.BLANK_STRING;
		try{
			mbSession = mbAppHelper.getMobileSession(httpServletRequest);
			IBankCommonData commonData = mbAppHelper.populateIBankCommonData(mbSession, httpServletRequest);
			String baseOrigin = IBankParams.getBaseOriginCode(commonData.getOrigin());
			OIDCService oidcService = (OIDCService) ServiceHelper.getBean("oidcService");

			if(StringUtil.isValidAlphaNumeric(app)){
				Logger.info("launched application >>: "+app, this.getClass());

				//21E2 - Check if CanopusPingSSOSwitch is ON for Autopay & SmartPlans and launch WDP via Ping SSO
				IBankRefershParams ibankRefreshParams = (IBankRefreshParamsImpl) ServiceHelper.getBean(IBANK_REFRESH_PARAMS_BEAN);
				if((app.equalsIgnoreCase(IBankParams.AUTOPAY) || app.equalsIgnoreCase(IBankParams.INSTALMENT_PLANS) || app.equalsIgnoreCase(IBankParams.GAMBLING_BLOCK)) && ibankRefreshParams.isCanopusPingSSOSwitchOn() ) {
					Logger.info("CanopusPingSSOSwitch is ON", getClass());
					return launchCanopusWithPingSSO(httpServletRequest, httpServletResponse, app, index, planType);
				}

				//Create cookie to know which application(IB or MB) has launched WDP
				String name = IBankParams.COMPASS_APP_TYPE_COOKIE;
				String value = IBankParams.COMPASS_APP_TYPE_COOKIE_VALUE_MB;
				
				if ( oidcService.isIDPNewCookieSwitchON())
				{
					name = IBankParams.COMPASS_IDP_TOKEN_COOKIE;
					value = "";
				
					IDPSSODetails idpSSODetails = new IDPSSODetails();
					idpSSODetails.setCreationTime(new Date() );
					idpSSODetails.setCustomerType("P");
					idpSSODetails.setGcisNumber( commonData.getUser().getGCISNumber());

					idpSSODetails.setSessionId(mbSession.getSessionID());
					idpSSODetails.setTokenType(SRV_TOKEN_TYPE);

					value= IBankParams.COMPASS_APP_TYPE_COOKIE_VALUE_MB + ":"+ oidcService.getServiceTokenId(idpSSODetails, commonData, SRV_TOKEN_TYPE, true);
					mbSession.setidpSSODetails(idpSSODetails);
				}

				Logger.info("IDP Cookie details Cookie Name : "+ name + " Value :"+  value + " Session Id : " + mbSession.getSessionID()  , this.getClass());
				
				if(IBankParams.GCC_ORIGINATION.equalsIgnoreCase(app)) {
					setLastAuthorisedTime(  commonData,  mbSession );
				}
				
				addCompassAppTypeCookie(baseOrigin, httpServletRequest, httpServletResponse, name, value);
				
				//Adding LaunchedApp = app in session
				mbSession.setLaunchedApp(app);

				
				 if(APP_HARDSHIP_FORM.equalsIgnoreCase(app)){		
					
					Logger.debug("Getting Hardship URL: ", this.getClass());
					String queryParams = "";
					String formRefId = "";
					wdpUrl = IBankParams.getCodesMessage(IBankParams.getBaseOriginCode(commonData.getOrigin()), IBankParams.EXTERNAL_LINKS, IBankParams.COVID_URL);
					
					if (mbSession.getCustomer() == null) {
						Logger.info("launch Covid hardship mbSession.getCustomer is null", this.getClass());
						throw new BusinessException(BusinessException.SYSTEM_UNAVILABLE);
					}
					
					List<Account> accountsList = new ArrayList<Account>();
					if (mbSession.getCustomer().getAccounts() != null) {
						Logger.info("launch Covid hardship # of accounts: " + mbSession.getCustomer().getAccounts().size(), this.getClass());
						accountsList = mbSession.getCustomer().getAccounts();
					}else {
						Logger.info("launch Covid hardship mbSession.getCustomer.getAccounts is null", this.getClass());
					}
					
					PostHandoverDataReq request = contextHandoverService.getHandoverRequestForCovid(accountsList, app);
					PostHandoverDataResp resp = contextHandoverService.postContextHandoverData(WDPConstants.ORGINATIONSYSTEMID_SIRIUS, request);
					
					formRefId = resp.getData().getReferenceId();
					
					queryParams = "?formRefId=" + formRefId;
					
					if(!StringUtils.isEmpty(queryParams)) {
						Logger.info("Inside launchApp() covid hardship - wdpURL:" + wdpUrl, getClass());
						Logger.info("Inside launchApp() covid hardship - queryParams:" + queryParams , getClass());  
						wdpUrl = wdpUrl.concat(queryParams);
					}
					
				}
				else if(APP_HARDSHIP_FORM_EXIT_EXTEND.equalsIgnoreCase(app)){		
					
					Logger.debug("Getting Hardship URL FOR EXIT AND EXTEND: ", this.getClass());
					String queryParams = "";
					String formRefId = "";
					wdpUrl = IBankParams.getCodesMessage(IBankParams.getBaseOriginCode(commonData.getOrigin()), IBankParams.EXTERNAL_LINKS, IBankParams.COVID_EXIT_EXTEND);
					Logger.debug("Getting Hardship URL FOR EXIT AND EXTEND: wdp url>> "+wdpUrl, this.getClass());
					
					if (mbSession.getCustomer() == null) {
						Logger.info("launch Covid hardship mbSession.getCustomer is null", this.getClass());
						throw new BusinessException(BusinessException.SYSTEM_UNAVILABLE);
					}
					
					List<Account> accountsList = new ArrayList<Account>();
					if (mbSession.getCustomer().getAccounts() != null) {
						Logger.info("launch Covid hardship # of accounts: " + mbSession.getCustomer().getAccounts().size(), this.getClass());
						accountsList = mbSession.getCustomer().getAccounts();
					}else {
						Logger.info("launch Covid hardship mbSession.getCustomer.getAccounts is null", this.getClass());
					}
					
					PostHandoverDataReq request = contextHandoverService.getHandoverRequestForCovid(accountsList, app);
					PostHandoverDataResp resp = contextHandoverService.postContextHandoverData(WDPConstants.ORGINATIONSYSTEMID_SIRIUS, request);
					
					formRefId = resp.getData().getReferenceId();
					
					if(null!=wdpUrl && wdpUrl.contains("swimlane")) {
						queryParams = "&formRefId=" + formRefId;
					}else {
						queryParams = "?formRefId=" + formRefId;
					}
					//queryParams = "?formRefId=" + formRefId;
					
					if(!StringUtils.isEmpty(queryParams)) {
						Logger.info("Inside launchApp() covid hardship - wdpURL:" + wdpUrl, getClass());
						Logger.info("Inside launchApp() covid hardship - queryParams:" + queryParams , getClass());  
						wdpUrl = wdpUrl.concat(queryParams);
					}
					
				}
				else if(APP_COVID_SUPPORT_HUB.equalsIgnoreCase(app)){		
					
					Logger.debug("Inside Hardship Hub: ", this.getClass());
					String queryParams = "";
					String formRefId = "";
					wdpUrl = IBankParams.getCodesMessage(IBankParams.getBaseOriginCode(commonData.getOrigin()), IBankParams.EXTERNAL_LINKS, IBankParams.COVID_SUPPORT_HUB);
					Logger.debug("Getting Hardship Hub URL: wdp url>> "+wdpUrl, this.getClass());
					
					if (mbSession.getCustomer() == null) {
						Logger.info("launch Covid hardship mbSession.getCustomer is null", this.getClass());
						throw new BusinessException(BusinessException.SYSTEM_UNAVILABLE);
					}
					
					List<Account> accountsList = new ArrayList<Account>();
					if (mbSession.getCustomer().getAccounts() != null) {
						Logger.info("launch Covid hardship # of accounts: " + mbSession.getCustomer().getAccounts().size(), this.getClass());
						accountsList = mbSession.getCustomer().getAccounts();
					}else {
						Logger.info("launch Covid hardship mbSession.getCustomer.getAccounts is null", this.getClass());
					}
					
					PostHandoverDataReq request = contextHandoverService.getHandoverRequestForCovid(accountsList, app);
					PostHandoverDataResp resp = contextHandoverService.postContextHandoverData(WDPConstants.ORGINATIONSYSTEMID_SIRIUS, request);
					
					formRefId = resp.getData().getReferenceId();
					
					if(null!=wdpUrl && wdpUrl.contains("swimlane")) {
						queryParams = "&formRefId=" + formRefId;
					}else {
						queryParams = "?formRefId=" + formRefId;
					}
					//queryParams = "?formRefId=" + formRefId;
					
					if(!StringUtils.isEmpty(queryParams)) {
						Logger.info("Inside launchApp() covid hardship - wdpURL:" + wdpUrl, getClass());
						Logger.info("Inside launchApp() covid hardship - queryParams:" + queryParams , getClass());  
						wdpUrl = wdpUrl.concat(queryParams);
					}
					
				}
				else {
				    if(!app.equalsIgnoreCase(IBankParams.UOD)) {
						wdpUrl = IBankParams.getCodesMessage(baseOrigin, IBankParams.EXTERNAL_LINKS, app);
				    }
				}
				
				
				if(app.equalsIgnoreCase(IBankParams.GCC_ORIGINATION)){		
					
					if ( ! IBankParams.isGCCMasterCardOriginationSwitchOn(commonData.getOrigin(), commonData.getCustomer().getGcis()) )
					{
						Logger.debug("Redirecting to launch action...", this.getClass());
						model = new ModelAndView("redirect:" + "return");
						return model;
					}
					
					duplicateIOSOldAppCookie(httpServletRequest, httpServletResponse, commonData);
					
					//Initiate GlobalWallet
					GlobalWallet globalWallet = globalWalletService.initiateGlobalWallet(commonData);
					
					//Adding InitiatedGlobalWalletCardId in session
					mbSession.setInitiatedGlobalWalletId(globalWallet.getRequestId());
					
					//GDW
					globalWalletService.createStatForLaunchingGCC(commonData);
					
					//Add query parameters [tid, pid, locationid] to WDP URL for tagging  - BEGIN
					Logger.debug("Inside lanunchApp() tId:"+tId+ ",pId:"+pId+",locationId:"+locationId , getClass());
					String queryParams = "";
					if(!StringUtils.isEmpty(tId)) {
						if(StringUtils.isEmpty(queryParams)) {
							queryParams = queryParams.concat("?tid="+tId);	
						} else {
							queryParams = queryParams.concat("&tid="+tId);
						}
						
					}
					if(!StringUtils.isEmpty(pId)) {
						if(StringUtils.isEmpty(queryParams)) {
							queryParams = queryParams.concat("?pid="+pId);
						} else {
							queryParams = queryParams.concat("&pid="+pId);
						}
					}
					if(!StringUtils.isEmpty(locationId)) {
						if(StringUtils.isEmpty(queryParams)) {
							queryParams = queryParams.concat("?locationid="+locationId);
						} else {
							queryParams = queryParams.concat("&locationid="+locationId);
						}
					}
					
					String transitionSwitch = IBankParams.getCodesMessage(baseOrigin, IBankParams.CONFIGURATION_PROPERTIES, "GCCTransitionSwitch");
					if (  transitionSwitch==null || StringMethods.isEmptyString(transitionSwitch) )
					{
						transitionSwitch = IBankParams.ON;
					}

					if(StringUtils.isEmpty(queryParams)) {
						queryParams = queryParams.concat("?transitionSwitch="+transitionSwitch);
					} else {
						queryParams = queryParams.concat("&transitionSwitch="+transitionSwitch);
					}

					
					if(!StringUtils.isEmpty(queryParams)) {
						Logger.info("Inside lanunchApp() adding query parameters to WDP URL - queryParams:"+queryParams , getClass());  
						wdpUrl = wdpUrl.concat(queryParams);
					}
					//Add query parameters [tid, pid, locationid] to WDP URL for tagging  - END
				}
				
				if(app.equalsIgnoreCase(IBankParams.ECONTRACT)){
					Logger.debug("Inside EContract flow", getClass());
					String arn = "";
					
					
					if ( ! ServiceConstants.ECONTRACT_VERIFY_SECURE_CODE.equalsIgnoreCase(mbSession.getSecureCodeVerifiedTranName()) )
					{
						Logger.error("Secure not verified. Session Sec Code Value : "+ mbSession.getSecureCodeVerifiedTranName(), this.getClass());
						throw new ResourceException(ResourceException.SYSTEM_ERROR, "Secure not verified. Session Sec Code Vale : "+ mbSession.getSecureCodeVerifiedTranName());
					}
					
					if(mbSession.getLoanApplicationDetail()!=null){
						Logger.debug("mbSession getLoanApplicationDetail not null", getClass());
						arn = mbSession.getLoanApplicationDetail().getAppRefNum();
						Logger.debug("arn from session is ::"+arn, getClass());
					}
					wdpUrl = wdpUrl.concat(arn);
				}
				
				if(app.equalsIgnoreCase(IBankParams.UOD)) {
					Logger.debug("Inside Unarranged Overdrawn flow", getClass());
					Customer customer=null;
					
					String queryParams = "";
					String formRefId = "";
					wdpUrl = IBankParams.getCodesMessage(IBankParams.getBaseOriginCode(commonData.getOrigin()), IBankParams.EXTERNAL_LINKS, IBankParams.UNARRANGED_OVERDRAFT_URL);
					Logger.debug("Getting UOD Url from release codes: wdp url>> "+wdpUrl, this.getClass());
					
					if (mbSession.getCustomer() == null) {
						Logger.info("launch Covid hardship mbSession.getCustomer is null", this.getClass());
						throw new BusinessException(BusinessException.SYSTEM_UNAVILABLE);
					}
					
					if (mbSession.getCustomer() != null) {
						Logger.info("Unaranged Overdrawn GCUS Number " + mbSession.getCustomer().getGcis(), this.getClass());
						 customer = mbSession.getCustomer();
					}else {
						Logger.info("launch Unaranged Overdrawn mbSession.getCustomer is null", this.getClass());
					}
					
					PostHandoverDataReq request = contextHandoverService.getHandoverRequestForUOD(customer,baseOrigin);
					
					PostHandoverDataResp resp = contextHandoverService.postContextHandoverData(WDPConstants.ORGINATIONSYSTEMID_SIRIUS, request,"vesit2");
					
					formRefId = resp.getData().getReferenceId();
					
					if(null!=wdpUrl && wdpUrl.contains("swimlane")) {
						queryParams = "&contextRefId=" + formRefId;
					}else {
						queryParams = "?contextRefId=" + formRefId;
					}
					
					if(!StringUtils.isEmpty(queryParams)) {
						Logger.info("Inside launchApp() Unarranged Overdraft - wdpURL:" + wdpUrl, getClass());
						Logger.info("Inside launchApp() Unarranged Overdraft - queryParams:" + queryParams , getClass()); 
						Logger.debug("Inside launchApp() Unarranged Overdraft - wdpURL:" + wdpUrl, getClass());
						Logger.debug("Inside launchApp() Unarranged Overdraft - queryParams:" + queryParams , getClass()); 
						wdpUrl = wdpUrl.concat(queryParams);
					}					
					Logger.info("Inside lanunchApp() Unaranged Overdrawn - wdpURL:" + wdpUrl, getClass());
					Logger.debug("Inside lanunchApp() Unaranged Overdrawn - wdpURL:" + wdpUrl, getClass());
					
				}
				
				if(app.equalsIgnoreCase(IBankParams.AUTOPAY)){
					
					Logger.debug("Smart Plan: cardservicing autopay flow", getClass());
					
					Logger.info("Smart Plan: cardservicing autopay selected account index : "+index, getClass());
					
					if(StringMethods.isEmptyString(index)) {
						throw new BusinessException(BusinessException.SYSTEM_UNAVILABLE);
					}
					
					int accountIndex = Integer.parseInt(index);
					
					PostHandoverDataReq request = contextHandoverService.getHandoverRequestForAutoPay(commonData , accountIndex);					
					
					PostHandoverDataResp resp = contextHandoverService.postContextHandoverData(WDPConstants.ORGINATIONSYSTEMID_SIRIUS, request);
					
					wdpUrl = IBankParams.getCodesMessage(IBankParams.getBaseOriginCode(commonData.getOrigin()), IBankParams.EXTERNAL_LINKS, app);
					
					Logger.info("Smart Plan: cardservicing autopay Getting autopay wdp url>> "+wdpUrl, this.getClass());
					
					String formRefId = "";
					String queryParams = "";
					
					if(resp!=null && resp.getData()!=null) {
						formRefId = resp.getData().getReferenceId();
					}
					
					if(!StringMethods.isEmptyString(formRefId)) {
						
						if(null!=wdpUrl && wdpUrl.contains("swimlane")) {
							queryParams = "&contextRefId=" + formRefId;
						}else {
							queryParams = "?contextRefId=" + formRefId;
						}
						
						if(!StringUtils.isEmpty(queryParams)) {
							Logger.info("Inside launchApp() Smart Plan autopay - wdpURL:" + wdpUrl, getClass());
							Logger.info("Inside launchApp() Smart Plan autopay - queryParams:" + queryParams , getClass()); 
							wdpUrl = wdpUrl.concat(queryParams);
						}
					}
				}
				
				if(app.equalsIgnoreCase(IBankParams.INSTALMENT_PLANS)){
					
					Logger.debug("Smart Plan: cardservicing instalmentPlans flow", getClass());
					
					Logger.info("Smart Plan: cardservicing instalmentPlans selected account index : "+index, getClass());
					Logger.info("Smart Plan: cardservicing instalmentPlans selected planType : "+planType, getClass());
					
					if(StringMethods.isEmptyString(index) || StringMethods.isEmptyString(planType)) {
						throw new BusinessException(BusinessException.SYSTEM_UNAVILABLE);
					}

					int accountIndex = Integer.parseInt(index);
					
					String tramsReferenceNumber = httpServletRequest.getParameter("refNum");
					String planNbr = httpServletRequest.getParameter("planNbr");
					String planRecNbr = httpServletRequest.getParameter("planRecNbr");
					Logger.info("Smart Plan: cardservicing autopay selected account refNum : "+tramsReferenceNumber+" planRecNbr : "+planRecNbr+" planNbr : "+planNbr, getClass());
										
					List<SmartPlanActiveInstalment> smartPlanActiveInstalmentList = mbSession.getSmartPlanActiveInstalmentList();
					PostHandoverDataReq request = contextHandoverService.getHandoverRequestForInstalmentPlans(commonData , accountIndex, planType, planNbr, planRecNbr, smartPlanActiveInstalmentList);
					
					if(request !=null && request.getFields() !=null) {
						if(!StringMethods.isEmptyString(tramsReferenceNumber) && StringUtil.isValidAlphaNumeric(tramsReferenceNumber)) {							
							Inline_response_200_1_data_fields field = new Inline_response_200_1_data_fields();
							field.setFieldName("tramsReferenceNumber");
							field.setValue(tramsReferenceNumber);
							request.getFields().add(field);							
						}
					}
					
					PostHandoverDataResp resp = contextHandoverService.postContextHandoverData(WDPConstants.ORGINATIONSYSTEMID_SIRIUS, request);
					
					wdpUrl = IBankParams.getCodesMessage(IBankParams.getBaseOriginCode(commonData.getOrigin()), IBankParams.EXTERNAL_LINKS, app);
					
					Logger.info("Smart Plan: cardservicing instalmentPlans Getting instalmentPlans wdp url>> "+wdpUrl, this.getClass());
					
					String formRefId = "";
					String queryParams = "";
					
					if(resp!=null && resp.getData()!=null) {
						formRefId = resp.getData().getReferenceId();
					}
					
					if(!StringMethods.isEmptyString(formRefId)) {
						
						if(null!=wdpUrl && wdpUrl.contains("swimlane")) {
							queryParams = "&contextRefId=" + formRefId;
						}else {
							queryParams = "?contextRefId=" + formRefId;
						}
						
						if(!StringUtils.isEmpty(queryParams)) {
							Logger.info("Inside launchApp() Smart Plan instalmentPlans - wdpURL:" + wdpUrl, getClass());
							Logger.info("Inside launchApp() Smart Plan instalmentPlans - queryParams:" + queryParams , getClass());
							wdpUrl = wdpUrl.concat(queryParams);
						}
					}
				}
				
				model = new ModelAndView("redirect:" + wdpUrl);

			}
			else{
				Logger.error("Not a valid app : "+app, this.getClass());
				throw new BusinessException(BusinessException.SYSTEM_UNAVILABLE);
			}
				
		}
		catch (BusinessException e) {
			Logger.warn("Business Exception:" + e.getKey() + " Message : "+ e.getMessage(), e, this.getClass());
			if(e.getKey() == BusinessException.NO_RECORDS_FOUND){
				Logger.error("No url from db for "+app, this.getClass());
				throw new BusinessException(BusinessException.SYSTEM_UNAVILABLE);
			}
			throw new BusinessException(BusinessException.SYSTEM_UNAVILABLE);
		}catch(ResourceException re) {
			Logger.warn("Trying to acccess Econtract wdp UI without 2FA", getClass());
			throw new BusinessException(BusinessException.SYSTEM_UNAVILABLE);
		}
		catch(Exception e){
			Logger.error("Wdp url is not configured in DB.", e, getClass());
			//model = new ModelAndView("redirect:" + "https://www.dev1.ui.stgeorge.com.au/vega");
			throw new BusinessException(BusinessException.SYSTEM_UNAVILABLE);
		}
		finally{
			Logger.debug("End : lanunchApp", this.getClass());
		}
		return model;
	}


	private void duplicateIOSOldAppCookie(HttpServletRequest httpServletRequest,
			HttpServletResponse httpServletResponse, IBankCommonData commonData) {
		//Cookie handling for iOS old App 1. pm_dp  2. ds_psm 
		try {
			int nativeApp = logonHelper.getAppOsType(httpServletRequest);
			if(nativeApp == iosApp) {
				if(logonHelper.isIOSOldVersion(httpServletRequest)) {
					logonHelper.createSafiCookieWithDifferentDomain(httpServletRequest, httpServletResponse, commonData.getOrigin());
				}
			}
		} catch(Exception ex) {
			Logger.info("Exception while changing Cookie domain for old iOS App", this.getClass());
		}
	}


	private ModelAndView launchCanopusWithPingSSO(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse,String app, String index, String planType) throws BusinessException
	{
		Logger.debug("START : launchCanopusWithPingSSO", this.getClass());
		String wdpUrl = IBankParams.BLANK_STRING;
		MobileSession mbSession =  null;
		mbSession = mbAppHelper.getMobileSession(httpServletRequest);
		try {
			IBankCommonData commonData = mbAppHelper.populateIBankCommonData(mbSession, httpServletRequest);
			Customer customer = commonData.getCustomer();
			String baseOrigin = IBankParams.getBaseOriginCode(commonData.getOrigin());

			Logger.info("launchCanopusWithPingSSO - launchCanopusWithPingSSO - launched application Ping POC : "+app, this.getClass());
			String cookieName = "IBVrfyTk";
			String cookieValue = "";

			duplicateIOSOldAppCookie(httpServletRequest, httpServletResponse, commonData);


			//Create cookie to know which application(IB or MB) has launched WDP
			OIDCServiceImpl oidcService  = new OIDCServiceImpl();
			IDPSSODetails idpSSODetails = new IDPSSODetails();
			idpSSODetails.setCreationTime(new Date() );
			idpSSODetails.setCustomerType("P");
			idpSSODetails.setGcisNumber( commonData.getUser().getGCISNumber());

			idpSSODetails.setSessionId(mbSession.getSessionID());
			idpSSODetails.setTokenType(SRV_TOKEN_TYPE);
			
			Logger.info("launchCanopusWithPingSSO - trackingId : "+customer.getPreference().getTrackingId(), this.getClass());
			idpSSODetails.setTrackingId(customer.getPreference().getTrackingId());

			Logger.info("launchCanopusWithPingSSO - About to get Token : "+app, this.getClass());

			if(APP_CSH.equalsIgnoreCase(app) || APP_CSH_APPLY_ONLINE.equalsIgnoreCase(app)) {
				setLastAuthorisedTime(  commonData,  mbSession );
			}

			cookieValue = oidcService.getServiceTokenId(idpSSODetails, commonData, SRV_TOKEN_TYPE, true);

			Logger.info("launchCanopusWithPingSSO - Got Token : "+ cookieValue , this.getClass());

			mbSession.setidpSSODetails(idpSSODetails);

			Logger.info("launchCanopusWithPingSSO - Update Session Got Token : "+ cookieValue + "Sess Id " + idpSSODetails.getSessionId() , this.getClass());

			addCompassAppTypeCookie(baseOrigin, httpServletRequest, httpServletResponse, cookieName, "MB:"+cookieValue);

			//Adding LaunchedApp = app in session
			mbSession.setLaunchedApp(app);

			if (app.equalsIgnoreCase(IBankParams.AUTOPAY)) {

				Logger.debug("launchCanopusWithPingSSO - Smart Plan: cardservicing autopay flow", getClass());

				Logger.info("launchCanopusWithPingSSO - Smart Plan: cardservicing autopay selected account index : "+index, getClass());

				if(StringMethods.isEmptyString(index)) {
					throw new BusinessException(BusinessException.SYSTEM_UNAVILABLE);
				}

				int accountIndex = Integer.parseInt(index);

				PostHandoverDataReq request = contextHandoverService.getHandoverRequestForAutoPay(commonData , accountIndex);

				PostHandoverDataResp resp = contextHandoverService.postContextHandoverData(WDPConstants.ORGINATIONSYSTEMID_SIRIUS, request);

				wdpUrl = IBankParams.getCodesMessage(IBankParams.getBaseOriginCode(commonData.getOrigin()), IBankParams.EXTERNAL_LINKS, app);

				Logger.info("launchCanopusWithPingSSO - Smart Plan: cardservicing autopay Getting autopay wdp url>> "+wdpUrl, this.getClass());

				String formRefId = "";
				String queryParams = "";

				if(resp!=null && resp.getData()!=null) {
					formRefId = resp.getData().getReferenceId();
				}

				if(!StringMethods.isEmptyString(formRefId)) {

					if(null!=wdpUrl && wdpUrl.contains("swimlane")) {
						queryParams = "&contextRefId=" + formRefId;
					}else {
						queryParams = "?contextRefId=" + formRefId;
					}

					if(!StringUtils.isEmpty(queryParams)) {
						Logger.info("Inside launchCanopusWithPingSSO() Smart Plan autopay - wdpURL:" + wdpUrl, getClass());
						Logger.info("Inside launchCanopusWithPingSSO() Smart Plan autopay - queryParams:" + queryParams , getClass());
						wdpUrl = wdpUrl.concat(queryParams);
					}
				}
			}
			else if(app.equalsIgnoreCase(IBankParams.INSTALMENT_PLANS)){
				Logger.debug("launchCanopusWithPingSSO - Smart Plan: cardservicing instalmentPlans flow", getClass());

				Logger.info("launchCanopusWithPingSSO - Smart Plan: cardservicing instalmentPlans selected account index : "+index, getClass());
				Logger.info("launchCanopusWithPingSSO - Smart Plan: cardservicing instalmentPlans selected planType : "+planType, getClass());

				if(StringMethods.isEmptyString(index) || StringMethods.isEmptyString(planType)) {
					throw new BusinessException(BusinessException.SYSTEM_UNAVILABLE);
				}

				int accountIndex = Integer.parseInt(index);

				String tramsReferenceNumber = httpServletRequest.getParameter("refNum");
				String planNbr = httpServletRequest.getParameter("planNbr");
				String planRecNbr = httpServletRequest.getParameter("planRecNbr");
				Logger.info("launchCanopusWithPingSSO - Smart Plan: cardservicing autopay selected account refNum : "+tramsReferenceNumber+" planRecNbr : "+planRecNbr+" planNbr : "+planNbr, getClass());

				List<SmartPlanActiveInstalment> smartPlanActiveInstalmentList = mbSession.getSmartPlanActiveInstalmentList();
				PostHandoverDataReq request = contextHandoverService.getHandoverRequestForInstalmentPlans(commonData , accountIndex, planType, planNbr, planRecNbr, smartPlanActiveInstalmentList);

				if(request !=null && request.getFields() !=null) {
					if(!StringMethods.isEmptyString(tramsReferenceNumber) && StringUtil.isValidAlphaNumeric(tramsReferenceNumber)) {
						Inline_response_200_1_data_fields field = new Inline_response_200_1_data_fields();
						field.setFieldName("tramsReferenceNumber");
						field.setValue(tramsReferenceNumber);
						request.getFields().add(field);
					}
				}

				PostHandoverDataResp resp = contextHandoverService.postContextHandoverData(WDPConstants.ORGINATIONSYSTEMID_SIRIUS, request);

				wdpUrl = IBankParams.getCodesMessage(IBankParams.getBaseOriginCode(commonData.getOrigin()), IBankParams.EXTERNAL_LINKS, app);

				Logger.info("launchCanopusWithPingSSO - Smart Plan: cardservicing instalmentPlans Getting instalmentPlans wdp url>> "+wdpUrl, this.getClass());

				String formRefId = "";
				String queryParams = "";

				if(resp!=null && resp.getData()!=null) {
					formRefId = resp.getData().getReferenceId();
				}

				if(!StringMethods.isEmptyString(formRefId)) {

					if(null!=wdpUrl && wdpUrl.contains("swimlane")) {
						queryParams = "&contextRefId=" + formRefId;
					}else {
						queryParams = "?contextRefId=" + formRefId;
					}

					if(!StringUtils.isEmpty(queryParams)) {
						Logger.info("Inside launchCanopusWithPingSSO() Smart Plan instalmentPlans - wdpURL:" + wdpUrl, getClass());
						Logger.info("Inside launchCanopusWithPingSSO() Smart Plan instalmentPlans - queryParams:" + queryParams , getClass());
						wdpUrl = wdpUrl.concat(queryParams);
					}
				}
			}
			else {
				CodesVO codesVo = IBankParams.getCodesData(baseOrigin, IBankParams.EXTERNAL_LINKS, app );
				if (codesVo == null || codesVo.getMessage() == null )
				{
					Logger.info("launchCanopusWithPingSSO - WDP UI launch URL not found for  "+app , this.getClass());
					throw new BusinessException(BusinessException.SYSTEM_UNAVILABLE);
				}
				wdpUrl = codesVo.getMessage();
			}
			Logger.info("launchCanopusWithPingSSO - Redirect to : "+ wdpUrl + "Sess Id " + idpSSODetails.getSessionId() , this.getClass());

			wdpUrl = "redirect:"+wdpUrl;
			return new ModelAndView(wdpUrl);
		}
		catch(Exception e){
			Logger.info("launchCanopusWithPingSSO - Exception in launchWDPUrl for "+app ,e, this.getClass());
			throw new BusinessException(BusinessException.SYSTEM_UNAVILABLE);
		}
		finally{
			Logger.debug("End : launchCanopusWithPingSSO", this.getClass());
		}

	}
	
	@RequestMapping(value = "/cshApplyOnline", method = { RequestMethod.GET, RequestMethod.POST })
	public ModelAndView cshApplyOnline(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse,
			@RequestParam("purpose") String purpose, @RequestParam(value = "stage", required = false) String stage,
			@RequestParam(value = "jnt", required = false) String jnt) throws BusinessException {
		Logger.debug("START : cshApplyOnline", this.getClass());
		Logger.debug("cshApplyOnline purpose" + purpose, this.getClass());
		Logger.debug("cshApplyOnline stage" + stage, this.getClass());
		Logger.debug("cshApplyOnline jnt" + jnt, this.getClass());
		String redirectUrl = IBankParams.BLANK_STRING;

		MobileSession mbSession =  null;
		try {
			mbSession = mbAppHelper.getMobileSession(httpServletRequest);
			if (isValidCHSApplyOnlineParameter(purpose, stage, jnt)) {

				mbSession.removeLaunchedApp();

				IBankCommonData commonData = mbAppHelper.populateIBankCommonData(mbSession, httpServletRequest);

				String baseOrigin = IBankParams.getBaseOriginCode(commonData.getOrigin());
				
				Logger.debug("cshApplyOnline baseOrigin" + baseOrigin, this.getClass());

				String cookieName = "IBVrfyTk";
				String cookieValue = "";
				setLastAuthorisedTime(commonData, mbSession);

				// Create cookie to know which application(IB or MB) has launched WDP
				OIDCServiceImpl oidcService = new OIDCServiceImpl();
				IDPSSODetails idpSSODetails = new IDPSSODetails();
				idpSSODetails.setCreationTime(new Date());
				idpSSODetails.setCustomerType("P");
				idpSSODetails.setGcisNumber(commonData.getUser().getGCISNumber());

				idpSSODetails.setSessionId(mbSession.getSessionID());
				idpSSODetails.setTokenType(SRV_TOKEN_TYPE);

				// Logger.info("About to get Token : "+app, this.getClass());

				cookieValue = oidcService.getServiceTokenId(idpSSODetails, commonData, SRV_TOKEN_TYPE, true);

				Logger.info("Got Token : " + cookieValue, this.getClass());

				mbSession.setidpSSODetails(idpSSODetails);

				Logger.info("Update Session Got Token : " + cookieValue + "Sess Id " + idpSSODetails.getSessionId(),
						this.getClass());

				addCompassAppTypeCookie(baseOrigin, httpServletRequest, httpServletResponse, cookieName,
						"MB:" + cookieValue);

				Logger.debug("Getting apply online URL: ", this.getClass());

				String wdpUrl = IBankParams.getCodesMessage(IBankParams.getBaseOriginCode(commonData.getOrigin()),
						IBankParams.EXTERNAL_LINKS, IBankParams.CSH_APPLY_ONLINE_URL);
				if (!wdpUrl.isEmpty()) {
					Logger.debug("Apply online URL:>" + wdpUrl, this.getClass()); 
					redirectUrl = wdpUrl+( StringUtils.endsWith(wdpUrl, "?") ? "" : "&" )+ "purpose=" + purpose + "&stage=" + stage + "&jnt=" + jnt;
				}
				Logger.debug("WDP URL for CSH prepareonline jupiter: " + redirectUrl, getClass());

				Logger.debug("CSH Apply Online Redirect URL: " + redirectUrl, getClass());
				
				Logger.debug("CSH Apply Online Setting CSH APPLY ONLINE REDIRECT FLAG to true", this.getClass());
				mbSession.setIsCshApplyOnlineRedirect(true);
				Logger.debug("CSH Apply Online Setting CSH APPLY ONLINE REDIRECT FLAG Value: "+mbSession.getIsCshApplyOnlineRedirect(), this.getClass());
			
				HomeLoanTileContentVO tileContentVO = mbSession.getHomeLoanTileContentVO();
				
				if(tileContentVO != null) {
					mbSession.removeHomeLoanTileContentVO();
					Logger.debug("CSH Apply Online : HomeLoanTileContentVO is not NULL, Removed it from session", this.getClass());
				}
			} else {
				Logger.error("Invalid Params : ", this.getClass());
				httpServletResponse.sendRedirect(httpServletRequest.getContextPath()+"/?appAction=logout");
				return null;
			}

			// Adding LaunchedApp = app in session
			// compassSessionContext.setLaunchedApp(app);
			redirectUrl = "redirect:" + redirectUrl;
			return new ModelAndView(redirectUrl);

		} catch (BusinessException e) {
			Logger.warn("Business Exception:" + e.getKey() + " Message : " + e.getMessage(), e, this.getClass());
			if (e.getKey() == BusinessException.NO_RECORDS_FOUND) {
				// Logger.error("No url from db for "+app, this.getClass());
				throw new BusinessException(BusinessException.SYSTEM_UNAVILABLE);
			}
			throw new BusinessException(BusinessException.SYSTEM_UNAVILABLE);
		} catch (Exception e) {
			// Logger.info("Exception in launchWDPUrl for "+app ,e, this.getClass());
			throw new BusinessException(BusinessException.SYSTEM_UNAVILABLE);
		} finally {
			Logger.debug("End : CSH Apply Online ", this.getClass());
		}
	}
	
	private boolean isValidCHSApplyOnlineParameter(String purpose, String stage, String jnt) {
		Pattern purposeSatgePattern = Pattern.compile("^[a-zA-Z]{2,2}$");
		Pattern jntPattern = Pattern.compile("^[a-zA-Z]{1,1}$");
		if (purposeSatgePattern.matcher(purpose).matches() && purposeSatgePattern.matcher(stage).matches()
				&& jntPattern.matcher(jnt).matches()) {
			return true;
		}
		return false;
	}


	/**
	 * addCompassAppTypeCookie() is used to add the CompassAppType cookie in session.
	 * 
	 * @param origin
	 * @param request
	 * @param response
	 */
	public void addCompassAppTypeCookie(String origin, HttpServletRequest request, HttpServletResponse response, String name, String value) {
		String domainName = request.getServerName();
		if(domainName.contains(".")){
			domainName = domainName.substring(domainName.indexOf("."));
		}		
		if(! StringMethods.isEmptyString(domainName)){
			response.addHeader("Set-Cookie", name + "=" + value + "; path=/" + "; domain="+domainName);
		}
		else{
			response.addHeader("Set-Cookie", name + "=" + value + "; path=/");
		}

		Logger.info(" Added "+ name + " = "+ value, this.getClass());
	}

	private static final String SRV_TOKEN_TYPE = "OIDCToken"; 

	
	@RequestMapping(value = "/startwdp", method = {RequestMethod.GET, RequestMethod.POST})
	//@ResponseBody
	public ModelAndView launchpingPocl(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, 
			@RequestParam("app")  String app,
			@RequestParam(value="fid", required = false) String fid, 
			@RequestParam(value="cid", required = false) String cid, 
			@RequestParam(value="deeplink", required = false) boolean deeplink, 
			@RequestParam(value="appid", required = false) String appid, 
			@RequestParam(value="pid", required = false) String pid, 
			@RequestParam(value="appcnt", required = false) Integer appcnt,
			@RequestParam(value="purpose", required = false)  String purpose,
			@RequestParam(value="oid", required = false)  String oid,
			@RequestParam(value="lid", required = false)  String lid,
			@RequestParam(value="hmac", required = false)  String hmac,
			@RequestParam(value="stage", required = false)  String stage,
			@RequestParam(value="jnt", required = false)  String jnt,
			@RequestParam(value="sid", required = false)  String sid,
			@RequestParam(value="ctx", required = false)  String ctx
			) throws BusinessException
    {
		Logger.debug("START : launchWDPUrl", this.getClass());
		String wdpUrl = IBankParams.BLANK_STRING;
		MobileSession mbSession =  null;
		
		mbSession = mbAppHelper.getMobileSession(httpServletRequest);
		try {
			IBankCommonData commonData = mbAppHelper.populateIBankCommonData(mbSession, httpServletRequest);
			Customer customer = commonData.getCustomer();
			String baseOrigin = IBankParams.getBaseOriginCode(commonData.getOrigin());
			
				Logger.info("launched application Ping POC : "+app, this.getClass());
				String cookieName = "IBVrfyTk";
				String cookieValue = "";

				duplicateIOSOldAppCookie(httpServletRequest, httpServletResponse, commonData);
				
				
				//Create cookie to know which application(IB or MB) has launched WDP
				OIDCServiceImpl oidcService  = new OIDCServiceImpl();
				IDPSSODetails idpSSODetails = new IDPSSODetails();
				idpSSODetails.setCreationTime(new Date() );
				idpSSODetails.setCustomerType("P");
				idpSSODetails.setGcisNumber( commonData.getUser().getGCISNumber());

				idpSSODetails.setSessionId(mbSession.getSessionID());
				idpSSODetails.setTokenType(SRV_TOKEN_TYPE);
				
				Logger.info("launchpingPocl - trackingId : "+customer.getPreference().getTrackingId(), this.getClass());
				idpSSODetails.setTrackingId(customer.getPreference().getTrackingId());

				Logger.info("About to get Token : "+app, this.getClass());
				
				if(APP_CSH.equalsIgnoreCase(app) || APP_CSH_APPLY_ONLINE.equalsIgnoreCase(app)) {
					setLastAuthorisedTime(  commonData,  mbSession );
				}
				
				 cookieValue = oidcService.getServiceTokenId(idpSSODetails, commonData, SRV_TOKEN_TYPE, true);

				Logger.info("Got Token : "+ cookieValue , this.getClass());

				mbSession.setidpSSODetails(idpSSODetails);

				Logger.info("Update Session Got Token : "+ cookieValue + "Sess Id " + idpSSODetails.getSessionId() , this.getClass());

				addCompassAppTypeCookie(baseOrigin, httpServletRequest, httpServletResponse, cookieName, "MB:"+cookieValue);

				//Adding LaunchedApp = app in session
				mbSession.setLaunchedApp(app);
			
		/*		if (  mbSession.getOrigin().indexOf("BSA") >= 0 )
					wdpUrl  =  "https://www.uat1.ui.banksa.com.au/customer";
				else
					wdpUrl  = "https://www.uat1.ui.stgeorge.com.au/customer";
		 */
			
//				For CSH, URL will vary based on Single or Multi app
				if(APP_CSH.equalsIgnoreCase(app)){
					
					Logger.debug("Getting Home loan tile content from Session with sesion id: " + mbSession.getSessionID(), this.getClass());
					
					Logger.debug("CHS :: appid :: "+appid+" ,  appcnt :: "+appcnt+" , pid :: "+ pid + " , fid :: "+fid+ " , cid :: "+cid+" , deeplink :: "+deeplink, this.getClass());
					
					//GDW entry - CSH tile display
					StringBuffer description = new StringBuffer();
					HomeLoanTileContentVO tileContentVO = mbSession.getHomeLoanTileContentVO();
					Logger.debug("tileContentVO in session>>"+tileContentVO, this.getClass());
					
					//if tileContentVO is present in session, remove it from session
					if(null!=tileContentVO) {
						mbSession.removeHomeLoanTileContentVO();
					}else {
						 tileContentVO = homeLoanOBPService.getTileContent(commonData, UUID.randomUUID());
					}
					
					if(null!=tileContentVO) {
					Logger.debug("tileContentVO isDraftSubmissionAvailable====="+tileContentVO.isDraftSubmissionAvailable()+",tileContentVO "+tileContentVO.getApplicationId()+", Origin===="+commonData.getOrigin()+", Base Origin======"+IBankParams.getBaseOriginCode(commonData.getOrigin()), this.getClass());
					}
					
					if(null != appcnt) {
						
						if(appcnt > 1){
							wdpUrl = IBankParams.getCodesMessage(IBankParams.getBaseOriginCode(commonData.getOrigin()), IBankParams.EXTERNAL_LINKS, IBankParams.CSH_MULTI_APP_CTA_URL);
							description.append("AppCount:").append(appcnt);
						}else if(appcnt == 1){							
							Object[] values = {appid};
							if(tileContentVO != null && !tileContentVO.isDraftSubmissionAvailable()) {
								wdpUrl = MessageFormat.format(IBankParams.getCodesMessage(IBankParams.getBaseOriginCode(commonData.getOrigin()), IBankParams.EXTERNAL_LINKS, IBankParams.CSH_SING_APP_CTA_URL), values);
							}else {
								wdpUrl = MessageFormat.format(IBankParams.getCodesMessage(IBankParams.getBaseOriginCode(commonData.getOrigin()), IBankParams.EXTERNAL_LINKS, IBankParams.CSH_JUPITER_URL), values);
								if(!StringMethods.isEmptyString(tileContentVO.getApplicationId()) && !wdpUrl.isEmpty() ) {
                                    wdpUrl = wdpUrl+( StringUtils.endsWith(wdpUrl, "?") ? "" : "&" )+"sid="+tileContentVO.getApplicationId();
                                }
							}
							
							description.append("AppCount:1;AppID:").append(appid);
						}
						
						if(null != pid && !wdpUrl.isEmpty())
							wdpUrl = wdpUrl+( StringUtils.endsWith(wdpUrl, "?") ? "" : "&" )+"pid="+pid;
						
						if(null != fid && !fid.isEmpty() && !wdpUrl.isEmpty()) {
							wdpUrl = wdpUrl+( StringUtils.endsWith(wdpUrl, "?") ? "" : "&" )+"fid=" + fid;
						}
						
						if(null != cid && !cid.isEmpty() && !wdpUrl.isEmpty()) {
							wdpUrl = wdpUrl +( StringUtils.endsWith(wdpUrl, "?") ? "" : "&" )+ "cid=" + cid;
						}
						
						if(!description.toString().isEmpty()) {
							
							if(deeplink)
								description.append(",IsDeeplink:true");
							else
								description.append(",IsDeeplink:false");
							
							homeLoanOBPServiceHelper.addStatistics(Statistic.CSH_TILE_CLICK, description.toString(), commonData);
						}
						
					} 
					
					Logger.debug("WDP URL for CSH : "+wdpUrl, getClass());
				}
				else if(APP_CSH_JUPITER.equalsIgnoreCase(app)){					
					Logger.debug("Getting prepareonline from Session with sesion id: " + mbSession.getSessionID(), this.getClass());					
					Logger.debug("CHS :: purpose :: "+purpose+" ,  oid :: "+oid+" , hmac :: "+ hmac + " , stage :: "+stage+ " , jnt :: "+jnt, this.getClass());
																
					wdpUrl = IBankParams.getCodesMessage(IBankParams.getBaseOriginCode(commonData.getOrigin()), IBankParams.EXTERNAL_LINKS, IBankParams.CSH_JUPITER_URL);
					if(null != purpose && !purpose.isEmpty())
						wdpUrl = wdpUrl+( StringUtils.endsWith(wdpUrl, "?") ? "" : "&" )+"purpose="+purpose;
					
					if(null != oid && !oid.isEmpty() && !wdpUrl.isEmpty()) {
						wdpUrl = wdpUrl+( StringUtils.endsWith(wdpUrl, "?") ? "" : "&" )+"oid=" + oid;
					}
					if(null != lid && !lid.isEmpty() && !wdpUrl.isEmpty()) {
						wdpUrl = wdpUrl+( StringUtils.endsWith(wdpUrl, "?") ? "" : "&" )+"lid=" + lid;
					}
					if(null != hmac && !hmac.isEmpty() && !wdpUrl.isEmpty()) {
						wdpUrl = wdpUrl +( StringUtils.endsWith(wdpUrl, "?") ? "" : "&" )+ "a=" + hmac;
					}
					if(null != stage && !stage.isEmpty() && !wdpUrl.isEmpty()) {
						wdpUrl = wdpUrl +( StringUtils.endsWith(wdpUrl, "?") ? "" : "&" )+ "stage=" + stage;
					}
					if(null != jnt && !jnt.isEmpty() && !wdpUrl.isEmpty()) {
						wdpUrl = wdpUrl +( StringUtils.endsWith(wdpUrl, "?") ? "" : "&" )+ "jnt=" + jnt;
					}	
										
					if(null != sid && !sid.isEmpty() && !wdpUrl.isEmpty()) {
						wdpUrl = wdpUrl +( StringUtils.endsWith(wdpUrl, "?") ? "" : "&" )+ "sid=" + sid;
					}
					if(null != ctx && !ctx.isEmpty() && !wdpUrl.isEmpty()) {
						wdpUrl = wdpUrl +( StringUtils.endsWith(wdpUrl, "?") ? "" : "&" )+ "ctx=" + ctx;
					}
					
					mbSession.setIsPrepareOnlineRedirect(true);
					
					Logger.debug("WDP URL for CSH prepareonline jupiter"+wdpUrl, getClass());
				}
				else if(APP_CSH_APPLY_ONLINE.equalsIgnoreCase(app)){					
				
					Logger.debug("CHS Apply online :: purpose :: "+purpose+" , stage :: "+stage+ " , jnt :: "+jnt, this.getClass());
																
					wdpUrl = IBankParams.getCodesMessage(IBankParams.getBaseOriginCode(commonData.getOrigin()), IBankParams.EXTERNAL_LINKS, IBankParams.CSH_APPLY_ONLINE_URL);
					Logger.debug("Apply online URL:>"+wdpUrl, this.getClass());
					
					if(null != purpose && !purpose.isEmpty()) {
						wdpUrl = wdpUrl+( StringUtils.endsWith(wdpUrl, "?") ? "" : "&" )+"purpose="+purpose;
					}						
					if(null != stage && !stage.isEmpty() && !wdpUrl.isEmpty()) {
						wdpUrl = wdpUrl +( StringUtils.endsWith(wdpUrl, "?") ? "" : "&" )+ "stage=" + stage;
					}
					if(null != jnt && !jnt.isEmpty() && !wdpUrl.isEmpty()) {
						wdpUrl = wdpUrl +( StringUtils.endsWith(wdpUrl, "?") ? "" : "&" )+ "jnt=" + jnt;
					}					
					Logger.debug("WDP URL for CSH apply online jupiter>"+wdpUrl, getClass());
				}else if(APP_CSH_APPLY_ONLINE_ETB.equalsIgnoreCase(app)){					
				
					Logger.debug("CHS Apply online :: purpose :: "+purpose+" , stage :: "+stage+ " , jnt :: "+jnt, this.getClass());
																
					wdpUrl = IBankParams.getCodesMessage(IBankParams.getBaseOriginCode(commonData.getOrigin()), IBankParams.EXTERNAL_LINKS, IBankParams.CSH_APPLY_ONLINE_URL);
					Logger.debug("Apply online URL:>"+wdpUrl, this.getClass());
					
					if(null != purpose && !purpose.isEmpty()) {
						wdpUrl = wdpUrl+( StringUtils.endsWith(wdpUrl, "?") ? "" : "&" )+"purpose="+purpose;
					}						
					if(null != stage && !stage.isEmpty() && !wdpUrl.isEmpty()) {
						wdpUrl = wdpUrl +( StringUtils.endsWith(wdpUrl, "?") ? "" : "&" )+ "stage=" + stage;
					}
					if(null != jnt && !jnt.isEmpty() && !wdpUrl.isEmpty()) {
						wdpUrl = wdpUrl +( StringUtils.endsWith(wdpUrl, "?") ? "" : "&" )+ "jnt=" + jnt;
					}					
					Logger.debug("WDP URL for CSH apply online jupiter>"+wdpUrl, getClass());
				}

				else {
					CodesVO codesVo = IBankParams.getCodesData(baseOrigin, IBankParams.EXTERNAL_LINKS, app );
					if (codesVo == null || codesVo.getMessage() == null )
					{
						Logger.info("WDP UI launch URL not found for  "+app , this.getClass());
						throw new BusinessException(BusinessException.SYSTEM_UNAVILABLE); 
					}
					wdpUrl = codesVo.getMessage();	
				}
				
				Logger.info("Redirect to : "+ wdpUrl + "Sess Id " + idpSSODetails.getSessionId() , this.getClass());
				
			wdpUrl = "redirect:"+wdpUrl;
			return new ModelAndView(wdpUrl);

		}
		catch(Exception e){
			Logger.info("Exception in launchWDPUrl for "+app ,e, this.getClass());
			throw new BusinessException(BusinessException.SYSTEM_UNAVILABLE);
		}
		finally{
			Logger.debug("End : launchWDPUrl", this.getClass());
		}
       
    } 


    //20E4 -- New page with customer SECURE_ACCESS suspended message, from WDP to compass redirection
	@RequestMapping("/showSuspendPage")
	public ModelAndView showSuspendPage(HttpServletRequest request, HttpServletResponse response) throws Exception
	{
		
		ModelAndView model = null;
		String origin = null;
		String numKeyType = null;
		String numKeyTypePattern = null;
		try
		{
			logonHelper.setWebReadyCookie(request, response , "0" );
			
			origin = logonHelper.resolveOrigin(request);

			request.setAttribute(MainController.WEB_CONTEXT, logonHelper.getMBWebResourceContext());
			
			if ( StringMethods.isEmptyString(origin) )
			{
				origin = "MSTG";
				request.setAttribute(LogonHelper.ORIGIN, origin);
				Logger.info("Unable to resolve the origin  Request Details. URL : "+ request.getRequestURL() + " IP :" + request.getRemoteAddr() +
						" True IP >> " + request.getHeader(IBankParams.trueClientIP()), this.getClass());
				model = new ModelAndView("404");
			}
			else
			{
				request.setAttribute(LogonHelper.ORIGIN, origin);
				request.setAttribute(MainController.PRELOAD_VALUE, 2);  // Complete
				
				numKeyType =  logonHelper.getNumKeyBoardType(request);
				numKeyTypePattern =  logonHelper.getNumKeyBoardPattern(request);
				request.setAttribute(MainController.NUM_KEYBOARD_TYPE, numKeyType);
				request.setAttribute(MainController.NUM_KEYBOARD_PATTERN_TYPE, numKeyTypePattern);
				if ( this.systemInformation == null )
				{
					Logger.info("************ Loading systemInformation *************** "+ request.getRequestURL()   , this.getClass());
					this.systemInformation = getSystemInformationDtls();
				}
				request.setAttribute(MainController.SYS_VERSION, this.systemInformation.getMB3PackageVersion());
				OriginsVO originVO = IBankParams.getOrigin(origin);
				request.setAttribute(MainController.ORIGIN_NAME, originVO.getName());
			//	
/*				String pwdResetUrl = IBankParams.getCodesData( originVO.getBankName(),IBankParams.EXTERNAL_LINKS,  MainController.PWD_URL).getMessage();	
				request.setAttribute(MainController.PWD_RESET_URL, pwdResetUrl);
				
				String canRetrievalUrl = IBankParams.getCodesData( originVO.getBankName(),IBankParams.EXTERNAL_LINKS,  MainController.CAN_RETRIEVAL_URL).getMessage();
				request.setAttribute(MainController.CAN_RETRIEVAL_URL, canRetrievalUrl);
*/				
				request.setAttribute(MainController.HELP_DESK_NO, originVO.getPhone());
				
				request.setAttribute(MainController.ANDROID_BACK_BTN, "ON");
				
				Logger.info(originVO.toXml() + " \nInside IdpMainController showSuspendPage Request Details. URL : "+ request.getRequestURL() + " IP :" + request.getRemoteAddr()  +
						" True IP >> " + request.getHeader(IBankParams.trueClientIP()), this.getClass());

				
				Logger.info("Redirecting to UI for SUSPENDED page.", this.getClass());
				request.setAttribute("baseorigin", IBankParams.getBaseOriginCode(origin));					
				model = new ModelAndView("SuspendedPage");
				model.addObject("error",MBAppUtils.getMessage(origin, BusinessException.WDP_TO_COMPASS_IBANK_SECURE_ACCESS_SUSPENDED));
				
				return model;
				

			}
			return model;
		}
		catch ( Exception e)
		{
			origin = "MSTG";
			request.setAttribute(LogonHelper.ORIGIN, origin);
			model = new ModelAndView("404");
			Logger.error("Error in IdpMainController showSuspendPage " , e, this.getClass());
			return model;
		}
		finally
		{
			//numberOfRequests--;
		}
	}
	
	private SystemInformation getSystemInformationDtls()
	{
		SystemInformation systemInformation = (SystemInformation) ServiceHelper.getBean("systemInformation");
		return systemInformation;

	}
	
	@RequestMapping(value = "/launchVendor", method = {RequestMethod.GET, RequestMethod.POST})
	//@ResponseBody
	public IMBResp launchVendor(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, @RequestBody final PartnerVendorRequest request) throws BusinessException
    {
		Logger.debug("START : launchVendor", this.getClass());
		MobileSession mbSession =  null;
		String app=null;
		mbSession = mbAppHelper.getMobileSession(httpServletRequest);
		try {
			validateRequestHeader(request.getHeader(), httpServletRequest);
			if(null!=request) {
				app=request.getAppName();
			}
			
			IBankCommonData commonData = mbAppHelper.populateIBankCommonData(mbSession, httpServletRequest);
			String baseOrigin = IBankParams.getBaseOriginCode(commonData.getOrigin());
				String cookieName = "IBVrfyTk";
				String cookieValue = "";							
				//Create cookie to know which application(IB or MB) has launched Vendor
				OIDCServiceImpl oidcService  = new OIDCServiceImpl();
				IDPSSODetails idpSSODetails = new IDPSSODetails();
				idpSSODetails.setCreationTime(new Date() );
				idpSSODetails.setCustomerType("P");
				idpSSODetails.setGcisNumber( commonData.getUser().getGCISNumber());
				idpSSODetails.setSessionId(mbSession.getSessionID());
				idpSSODetails.setTokenType(SRV_TOKEN_TYPE);
				
				Logger.info("About to get Token : "+app, this.getClass());

				cookieValue = oidcService.getServiceTokenId(idpSSODetails, commonData, SRV_TOKEN_TYPE, true);

				Logger.info("Got Token for vendor launch: "+ cookieValue , this.getClass());

				mbSession.setidpSSODetails(idpSSODetails);

				Logger.info("Update Session Got Token : "+ cookieValue + "Sess Id " + idpSSODetails.getSessionId() , this.getClass());

				addCompassAppTypeCookie(baseOrigin, httpServletRequest, httpServletResponse, cookieName, "MB:"+cookieValue);

				//Adding LaunchedApp = app in session
				mbSession.setLaunchedApp(app);				
				//returning success response
				RespHeader headerResp = populateResponseHeader(ServiceConstants.EXTERNAL_VENDOR, mbSession);			
				SuccessResp successResp = new SuccessResp();
				successResp.setHeader(headerResp);
				successResp.setIsSuccess(true);	
				return successResp;
		}

		catch (ResourceException e) {
			Logger.error("ResourceException in IdpController - launchVendor - [key: " + e.getKey() + "] : GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());
			return MBAppUtils.createErrorResp(mbSession.getOrigin(), BusinessException.SYSTEM_UNAVILABLE, ServiceConstants.EXTERNAL_VENDOR, httpServletRequest);
		} catch (Exception e) {
			Logger.error("Exception IdpController - launchVendor: GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			return MBAppUtils.createErrorResp(mbSession.getOrigin(), ResourceException.MOBILE_NON_FINANCIAL_FATAL_ERR, ServiceConstants.EXTERNAL_VENDOR, httpServletRequest);
		}    
    }
	public RespHeader populateResponseHeader(String serviceName, MobileSession mobSession) {
		return mbAppHelper.populateResponseHeader(serviceName, mobSession);
	}
	
	public void validateRequestHeader(ReqHeader headerReq, HttpServletRequest request) throws BusinessException {
		Logger.debug("Request header validation: " + ReflectionToStringBuilder.toString(headerReq, ToStringStyle.MULTI_LINE_STYLE), this.getClass());
		new MBAppValidator().validateRequestHeader(headerReq, request);
	}
	
	@Autowired
	private LogonHelper logonHelper;
	
	@Autowired
	private SystemInformation systemInformation;

	
	public void setLastAuthorisedTime( IBankCommonData commonData, MobileSession compassSessionContext )
	{
		try
		{
			if ( compassSessionContext.getSafiLast2FASuccessTime() == null )
			{
				Logger.info("compassSessionContext.getSafiLast2FASuccessTime() is  NULLL. Not calling SAFI API", this.getClass());
			}
			else
			{
				Safi2Service safi2Service = (Safi2Service) ServiceHelper.getBean("safi2Service");
				safi2Service.setLastAuthorisedTime(commonData,  compassSessionContext.getSafiLast2FASuccessTime());
				Logger.info("compassSessionContext.getSafiLast2FASuccessTime() is  setL SAFI API" + commonData.getUser().getGCISNumber() + " " +  compassSessionContext.getSafiLast2FASuccessTime() , this.getClass());

			}
		}
		catch (Exception e)
		{
			Logger.error("Error in setLastAuthorisedTime ", e, this.getClass());
		}
	}
	


}