package au.com.stgeorge.mbank.model.request.customer.ev;

public class TaxResidency {
	
	private String country;
	private boolean foreignTINProvided;
	private String foreignTIN;
	private String reason;
	public boolean isForeignTINProvided() {
		return foreignTINProvided;
	}
	public void setForeignTINProvided(boolean foreignTINProvided) {
		this.foreignTINProvided = foreignTINProvided;
	}
	public String getForeignTIN() {
		return foreignTIN;
	}
	public void setForeignTIN(String foreignTIN) {
		this.foreignTIN = foreignTIN;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public String getReason() {
		return reason;
	}
	public void setReason(String reason) {
		this.reason = reason;
	}
	
}
