/**
 * 
 */
package au.com.stgeorge.mbank.model.request.offers;


import au.com.stgeorge.mbank.model.common.IMBReq;
import au.com.stgeorge.mbank.model.common.ReqHeader;

/**
 * @author C50216
 *
 */
public class SalesOfferAemReq implements IMBReq{			
	/**
	 * 
	 */
	private static final long serialVersionUID = -1827351686856568422L;
		
	private ReqHeader header;	

	private Boolean displayMyInvitation; 	
	
	public ReqHeader getHeader()
	{
		return header;
	}
	public void setHeader(ReqHeader header)
	{
		this.header = header;
	}	
	
	public Boolean getDisplayMyInvitation() {
		return displayMyInvitation;
	}
	public void setDisplayMyInvitation(Boolean displayMyInvitation) {
		this.displayMyInvitation = displayMyInvitation;
	}
					
}
