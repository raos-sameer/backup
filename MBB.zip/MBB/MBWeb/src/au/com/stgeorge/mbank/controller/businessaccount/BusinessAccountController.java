package au.com.stgeorge.mbank.controller.businessaccount;

import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import au.com.stgeorge.digitalsec.logger.DigitalSecLogger;
import au.com.stgeorge.digitalsec.logger.DigitalSecLogggerVO;
import au.com.stgeorge.framework.common.logging.Logger;
import au.com.stgeorge.framework.common.util.StringMethods;
import au.com.stgeorge.ibank.businessobject.BusinessException;
import au.com.stgeorge.ibank.businessobject.ResourceException;
import au.com.stgeorge.ibank.common.cache.IBankParams;
import au.com.stgeorge.ibank.evcrs.businessobject.CRSService;
import au.com.stgeorge.ibank.evcrs.businessobject.EVService;
import au.com.stgeorge.ibank.evcrs.businessobject.valueobject.EVForeignCountryDetail;
import au.com.stgeorge.ibank.messagecentre.valueobject.MessageSearch;
import au.com.stgeorge.ibank.service.businessobject.BusinessAccountService;
import au.com.stgeorge.ibank.service.valueobject.BusinessAccountDetails;
import au.com.stgeorge.ibank.service.valueobject.DeltaInformationCapturedVO;
import au.com.stgeorge.ibank.valueobject.Account;
import au.com.stgeorge.ibank.valueobject.AccountId;
import au.com.stgeorge.ibank.valueobject.Address;
import au.com.stgeorge.ibank.valueobject.ContactDetail;
import au.com.stgeorge.ibank.valueobject.LabelValueVO;
import au.com.stgeorge.ibank.valueobject.NewBusinessAccountDetails;
import au.com.stgeorge.ibank.valueobject.ThreatMatrix;
import au.com.stgeorge.ibank.valueobject.database.CodesVO;
import au.com.stgeorge.ibank.valueobject.transfer.IBankCommonData;
import au.com.stgeorge.mbank.controller.IMBController;
import au.com.stgeorge.mbank.controller.customer.ContactDetailHelper;
import au.com.stgeorge.mbank.controller.customer.LogonHelper;
import au.com.stgeorge.mbank.controller.customer.ev.CRSHelper;
import au.com.stgeorge.mbank.model.common.BusinessAccountReceiptResp;
import au.com.stgeorge.mbank.model.common.ErrorInfo;
import au.com.stgeorge.mbank.model.common.IMBReq;
import au.com.stgeorge.mbank.model.common.IMBResp;
import au.com.stgeorge.mbank.model.common.ReqHeader;
import au.com.stgeorge.mbank.model.common.RespHeader;
import au.com.stgeorge.mbank.model.request.EmptyReq;
import au.com.stgeorge.mbank.model.request.businessaccount.BusinessAccountAbnReq;
import au.com.stgeorge.mbank.model.request.businessaccount.BusinessAccountAcnReq;
import au.com.stgeorge.mbank.model.request.businessaccount.BusinessAccountOpenReq;
import au.com.stgeorge.mbank.model.request.businessaccount.BusinessAccountReq;
import au.com.stgeorge.mbank.model.request.customer.ev.CRSInfo;
import au.com.stgeorge.mbank.model.response.ErrorResp;
import au.com.stgeorge.mbank.model.response.businessaccount.BusinessAccountResp;
import au.com.stgeorge.mbank.session.MobileSession;
import au.com.stgeorge.mbank.util.MBAppConstants;
import au.com.stgeorge.mbank.util.MBAppHelper;
import au.com.stgeorge.mbank.util.MBAppUtils;
import au.com.stgeorge.mbank.util.MBAppValidator;
import au.com.stgeorge.mobilebank.businessobject.MobileBankService;
import au.com.stgeorge.perflogger.PerformanceLogger;


@Controller
@RequestMapping("/businessaccount")
public class BusinessAccountController implements IMBController
{
	
	@Autowired
	private BusinessAccountHelper businessAccountHelper;
	
	@Autowired
	private MBAppHelper mbAppHelper;
	
	@Autowired
	private MBAppValidator mbAppValidator;
		
	@Autowired
	private MobileBankService mobileBankService;
	
	@Autowired
	private PerformanceLogger perfLogger;
	
	@Autowired
	private BusinessAccountService businessAccountService;
	
	@Autowired
	private EVService evService;
	
	@Autowired
	private CRSHelper crsHelper;
	
	@Autowired
    private CRSService crsService;
	
	@Autowired
	private ContactDetailHelper contactDetailHelper;
	
	@Autowired
    private LogonHelper logonHelper;
	
	private static final String PRODUCT_TYPE_FREEDOM_BUSINESS = "FREEDOM_BUSINESS";
	private static final String PRODUCT_TYPE_SAVING_BUSINESS = "SAVING_BUSINESS";
	
	private static final String FREEDOM_DEFAULT_NAME = "Freedom Business Account";
	private static final String SAVING_DEFAULT_NAME = "Business Access Saver";
	
	private static final String DEFAULT_MSG_HEADER = "We are sorry.";
	private static final String BUSINESS_TYPE_IDENTIFIER = "B";
	
	
	@RequestMapping(value= "details" , method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public IMBResp getDetails(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse,
			@RequestBody final BusinessAccountReq req)
	{				
				
		Logger.debug("In BusinessAccountController.getDetails " + httpServletRequest.getContentType() + " "
				+ httpServletRequest.getRemoteAddr() + "  " + httpServletResponse.getCharacterEncoding() + httpServletResponse.getLocale() +
				" True IP >> " + httpServletRequest.getHeader(IBankParams.trueClientIP()), this.getClass());

		perfLogger.startAllLogs();
		String logName = MBAppUtils.getLogName(httpServletRequest);
		perfLogger.startLog(logName);
		MobileSession mbSession = null;
		try
		{
			mbSession = mbAppHelper.getMobileSession(httpServletRequest);	
			
			validateRequestHeader( req.getHeader(), httpServletRequest );

			ErrorResp errorResp = validate(req, httpServletRequest);
			if (errorResp != null && errorResp.getErrors() != null && errorResp.getErrors().size() > 0)
			{
				populateErrorHeader(errorResp);
				return errorResp;
			}
			
			IBankCommonData ibankCommonData=mbAppHelper.populateIBankCommonData(mbSession,httpServletRequest);
			
			if(!IBankParams.isSwitchOn(ibankCommonData.getOrigin(), IBankParams.BUSINESS_ACCOUNT_SWITCH))
			{
				throw new BusinessException(BusinessException.SYSTEM_UNAVILABLE);
			}
			
			
			if(!PRODUCT_TYPE_FREEDOM_BUSINESS.equalsIgnoreCase(req.getProductType()) && !PRODUCT_TYPE_SAVING_BUSINESS.equalsIgnoreCase(req.getProductType()))
			{
				throw new BusinessException(BusinessException.SYSTEM_UNAVILABLE);
			}
			
			if(!CustomerTypeEnum.SOLE.getCode().equalsIgnoreCase(req.getCustomerType()) && !CustomerTypeEnum.PARTNERSHIP.getCode().equalsIgnoreCase(req.getCustomerType()) && !CustomerTypeEnum.COMPANY.getCode().equalsIgnoreCase(req.getCustomerType()))
			{
				throw new BusinessException(BusinessException.SYSTEM_UNAVILABLE);
			}

			
			if(CustomerTypeEnum.PARTNERSHIP.getCode().equalsIgnoreCase(req.getCustomerType())) //TODO: Apply Switch Check here for Sole Director once Switch is made
			{
				
				String url = getBusinessAccountExternalUrl(IBankParams.getBaseOriginCode(ibankCommonData.getOrigin()), req.getCustomerType(), req.getProductType());
				
				IMBResp serviceResponse = businessAccountHelper.populateResponse(url);
				
				RespHeader headerResp = populateResponseHeader(req.getHeader().getServiceName(), mbSession );
				serviceResponse.setHeader(headerResp);
				
				mbSession.invalidateSession();
				return serviceResponse;
			}
			
			boolean isCompanyAccount = false;
			
			//only for company account reidv check is required
			if(CustomerTypeEnum.COMPANY.getCode().equalsIgnoreCase(req.getCustomerType())){
				isCompanyAccount = true;
			}
			
			businessAccountService.verifyAccountOpenEligibility(ibankCommonData, isCompanyAccount);
				
			if(CustomerTypeEnum.SOLE.getCode().equalsIgnoreCase(req.getCustomerType())){
				return populateSoleTraderResponse(req, mbSession, ibankCommonData);
			}else{
				String url = getBusinessAccountExternalUrl(IBankParams.getBaseOriginCode(ibankCommonData.getOrigin()), req.getCustomerType(), req.getProductType());
				
				return populateSoleDirResponse(req, mbSession, ibankCommonData,url);
			}
		} catch (BusinessException e)
		{
			Logger.error("Exception Inside BusinessAccountController.getDetails: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			return createErrorResp(mbSession.getOrigin() , e.getKey(), MBAppConstants.BUSINESS_ACCOUNT_SERVICE, httpServletRequest);
		} catch (Exception e)
		{	
			Logger.error("Exception Inside BusinessAccountController.getDetails: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			BusinessException exp = new BusinessException(BusinessException.SYSTEM_UNAVILABLE);
			return createErrorResp(mbSession.getOrigin(), exp.getKey(), MBAppConstants.BUSINESS_ACCOUNT_SERVICE, httpServletRequest);
		} finally
		{
			perfLogger.endLog(logName);
			perfLogger.endAllLogs();
		}			
	}


	private IMBResp populateSoleTraderResponse(final BusinessAccountReq req, MobileSession mbSession, IBankCommonData ibankCommonData) throws BusinessException {
		//Check is activate/unlock
		
		Boolean activate = false;
		String newGcis = null;
		String abn = null;
		
		BusinessAccountDetails businessAccountDetails = businessAccountService.getNewBusinessAccountStatus(ibankCommonData);
		
		if(businessAccountDetails != null)
		{
			newGcis = businessAccountDetails.getNinGcisNumber();
			 if(!StringMethods.isEmptyString(newGcis))
				{
					//Activate
					activate = true;
				}
			 abn = businessAccountDetails.getAbn();
		}
		
		List<LabelValueVO> tradingCodeNames = null;
		String abnRequestId = null;
		if(abn != null)
		{
			//activate
			//Initialize with the default value, in case the polling fails, it will has the default value
			List<String> businessNames = new ArrayList<String>();
			businessNames.add(BusinessAccountService.DEFAULT_TRADING_NAME);
			tradingCodeNames = businessAccountHelper.populateBusinessNames(businessNames);
			businessAccountDetails.setBusinessNames(tradingCodeNames);
			try
			{										
				abnRequestId = businessAccountService.searchAbn(abn,ibankCommonData);								
			}
			catch (Exception e)
			{
				//Do nothing, already default value initialized
			}
		}

		//Check transaction account required (cross sell)
		
		Boolean crossSell = null;
		if(PRODUCT_TYPE_SAVING_BUSINESS.equalsIgnoreCase(req.getProductType()))
		{
			crossSell = true;
			if(activate)
			{
				boolean hasTransAcc = businessAccountService.isTransactionAccountExists(ibankCommonData, newGcis);
				if(hasTransAcc)
				{
					crossSell = false;
				}
			}
		}
		
		if(businessAccountDetails == null)
		{
			businessAccountDetails = new BusinessAccountDetails();
		}
		
		String foreignTaxResident = null;
		CRSInfo crsInfo = null;
		boolean isCrsInfoProvided = false;
		DeltaInformationCapturedVO deltaInformationCapturedVO=null;
		if(!activate)//unlock
		{
			au.com.stgeorge.ibank.evcrs.businessobject.valueobject.CRSInfo crsMaintainInfoVO = crsService.getCrsInfo(ibankCommonData);
			 if(crsMaintainInfoVO == null)
		     {	
				 Logger.info("CRS data doesn't exists for the customer"+ ibankCommonData.getCustomer().getGcis(), this.getClass());
				isCrsInfoProvided = false;
				foreignTaxResident = "notprovided";
				crsInfo = crsHelper.populateCRSInfo(IBankParams.getForeignTINDetails());
		     }
			 else if(crsMaintainInfoVO != null && "X".equalsIgnoreCase(crsMaintainInfoVO.getRegistrationNumber()))
			{
			    Logger.info("crsInfoVO not null and ResgistrationNumber is X ", this.getClass());
			    foreignTaxResident = "notprovided";
				crsInfo = crsHelper.populateCRSInfo(IBankParams.getForeignTINDetails());
				businessAccountDetails.setCrsRegistrationNumber(crsMaintainInfoVO.getRegistrationNumber());
			}
			else
			{
				isCrsInfoProvided = true;
				crsInfo = new CRSInfo();
			    Logger.info("CRS data exists for the customer"+ ibankCommonData.getCustomer().getGcis(), this.getClass());
			    crsHelper.populateCRSInfo(crsMaintainInfoVO, crsInfo);
				foreignTaxResident = crsMaintainInfoVO.isForeignTaxResident() ? "yes" : "no";
			}
			//19E4 Tech Debt Start:Switch Removal
	/*		 if(IBankParams.isUnlockActivateDeltaInfoSwitchON()){*/
				 deltaInformationCapturedVO=businessAccountService.getDeltaInformationDetails(ibankCommonData);
				 populateDeltaInformation(businessAccountDetails,deltaInformationCapturedVO);
		/*	 }*/
				//19E4 Tech Debt End:Switch Removal
		}
			
			businessAccountDetails.setProductType(req.getProductType());
			businessAccountDetails.setIsActivate(activate);
			businessAccountDetails.setHasCrossSell(crossSell);
			businessAccountDetails.setCrsInfoProvided(isCrsInfoProvided);
		  
		ThreatMatrix threatMatrix = null;
		if(!activate)//unlock
		{
			threatMatrix = businessAccountService.getThreatMatrixInfoForBusAccount(mbSession.getEVThreatMatrixSessionID());
		}
		ContactDetail contactDetail =  mobileBankService.getContactDetails(ibankCommonData);
		
		BusinessAccountResp serviceResponse = businessAccountHelper.populateResponse(contactDetail, activate, crossSell, abn, tradingCodeNames, foreignTaxResident, crsInfo, threatMatrix, mbSession.getEVThreatMatrixSessionID(),deltaInformationCapturedVO);
		
		if(!StringMethods.isEmptyString(abnRequestId))
		{
			businessAccountDetails.setRequestId(abnRequestId);
			businessAccountDetails.setAbnRetriveCount(0);
			serviceResponse.setPollingStatus("P");
			serviceResponse.setPollingDelay( IBankParams.abnVerifyTimeout(mbSession.getOrigin()));				
		}
		
		businessAccountDetails.setLeadId(req.getLeadId());
		mbSession.setBusinessAccountDetails(businessAccountDetails);
		
		if(mbSession.getEVThreatMatrixSessionID() == null && threatMatrix != null){
			mbSession.setEVThreatMatrixSessionID(threatMatrix.getTrackingID());
		}
		
		RespHeader headerResp = populateResponseHeader(req.getHeader().getServiceName(), mbSession );
		serviceResponse.setHeader(headerResp);
		
		return serviceResponse;
	}


	/**
	 * @param businessAccountDetails
	 * @param deltaInformationCapturedVO
	 */
	private void populateDeltaInformation(
			BusinessAccountDetails businessAccountDetails,
			DeltaInformationCapturedVO deltaInformationCapturedVO) {
		if(deltaInformationCapturedVO!=null)
		{
			businessAccountDetails.setSofCaptured(deltaInformationCapturedVO.isSofCaptured());
			businessAccountDetails.setSowCaptured(deltaInformationCapturedVO.isSowCaptured());
			businessAccountDetails.setEmpTypeCaptured(deltaInformationCapturedVO.isEmpTypeCaptured());
			businessAccountDetails.setOccupationCodeCaptured(deltaInformationCapturedVO.isOccupationCodeCaptured());
			businessAccountDetails.setPobrCaptured(deltaInformationCapturedVO.isPobrCaptured());
			//businessAccountDetails.setAlternateNameCaptured(deltaInformationCapturedVO.isAlternateNameCaptured());
			
			if(!deltaInformationCapturedVO.isSofCaptured())
			{
				businessAccountDetails.setSourceOfFundsList(IBankParams.getTraderSourceOfFundsList());
			}
			if(!deltaInformationCapturedVO.isSowCaptured())
			{
				businessAccountDetails.setSourceOfWealthList(IBankParams.getTraderSourceOfWealthList());
			}
			/*if(!deltaInformationCapturedVO.isOccupationCodeCaptured()){
		        businessAccountDetails.setOccupationCodeList(IBankParams.getCustOccupationList());
			}*/
			if(!deltaInformationCapturedVO.isEmpTypeCaptured()){
				businessAccountDetails.setEmployerTypeList(IBankParams.getCustEmployeeCodeList());
			}
		}
	}
	
	private IMBResp populateSoleDirResponse(final BusinessAccountReq req, MobileSession mbSession, IBankCommonData ibankCommonData, String url) throws BusinessException {
		//Check is activate/unlock
		
		//clear old business account details from session 
		mbSession.removeBusinessAccountDetails();
		mbSession.removeBusinessAccountDetailsList();
		
		Boolean activate = false;

		List<BusinessAccountDetails> businessAccountDtlsList = businessAccountService.getNewBusinessAcctStatusSolDir(ibankCommonData);		
		
		if(businessAccountDtlsList.size()>0){
			mbSession.setBusinessAccountDetailsList(businessAccountDtlsList);
			activate = true;
		}
		
		Boolean crossSell = true;
		
		String foreignTaxResident = null;
		CRSInfo crsInfo = null;
		ThreatMatrix threatMatrix = null;
	
		foreignTaxResident = "notprovided";
		crsInfo = crsHelper.populateCRSInfo(IBankParams.getForeignTINDetails(), BUSINESS_TYPE_IDENTIFIER);
		
		BusinessAccountDetails businessAccountDetails = new BusinessAccountDetails();
		businessAccountDetails.setProductType(req.getProductType());
		businessAccountDetails.setHasCrossSell(crossSell);
		businessAccountDetails.setIsActivate(activate);
		businessAccountDetails.setExternalUrl(url);
		businessAccountDetails.setLeadId(req.getLeadId());
		mbSession.setBusinessAccountDetails(businessAccountDetails);
		
		ContactDetail contactDetail =  mobileBankService.getContactDetails(ibankCommonData);
		BusinessAccountResp serviceResponse = businessAccountHelper.populateResponseSolDir(activate, businessAccountDtlsList,contactDetail,foreignTaxResident,crsInfo,threatMatrix,mbSession.getEVThreatMatrixSessionID(),url);
		RespHeader headerResp = populateResponseHeader(req.getHeader().getServiceName(), mbSession );
		serviceResponse.setHeader(headerResp);
		
		return serviceResponse;
	}

	@RequestMapping(value= "retrieveAbn" , method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public IMBResp retrieveAbn(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse,
			@RequestBody final EmptyReq req)
	{	
		Logger.debug("In BusinessAccountController.retrieveAbn " + httpServletRequest.getContentType() + " "
				+ httpServletRequest.getRemoteAddr() + "  " + httpServletResponse.getCharacterEncoding() + httpServletResponse.getLocale() +
				" True IP >> " + httpServletRequest.getHeader(IBankParams.trueClientIP()), this.getClass());

		perfLogger.startAllLogs();
		String logName = MBAppUtils.getLogName(httpServletRequest);
		perfLogger.startLog(logName);
		MobileSession mbSession = null;
		BusinessAccountDetails businessAccountDetails = null;
		try
		{
			mbSession = mbAppHelper.getMobileSession(httpServletRequest);	
			
			validateRequestHeader( req.getHeader(), httpServletRequest );

			ErrorResp errorResp = validate(req, httpServletRequest);
			if (errorResp != null && errorResp.getErrors() != null && errorResp.getErrors().size() > 0)
			{
				populateErrorHeader(errorResp);
				return errorResp;
			}
			
			businessAccountDetails = mbSession.getBusinessAccountDetails();
			
			IBankCommonData ibankCommonData=mbAppHelper.populateIBankCommonData(mbSession,httpServletRequest);
			businessAccountDetails.setAbnRetriveCount(businessAccountDetails.getAbnRetriveCount() + 1);
			BusinessAccountDetails accountDetails = businessAccountService.verifyAbnAndGetTradingNames(businessAccountDetails.getAbn(),businessAccountDetails.getAbnRetriveCount(),businessAccountDetails.getRequestId(),ibankCommonData);
			BusinessAccountResp serviceResponse = null;
			if(accountDetails != null)
			{
				List<String> tradingNames = accountDetails.getTradingNames();
				
				businessAccountDetails.setAbnName(accountDetails.getAbnName());
				
				List<LabelValueVO> tradingCodeNames = businessAccountHelper.populateBusinessNames(tradingNames);
				businessAccountDetails.setBusinessNames(tradingCodeNames);
				
				serviceResponse = businessAccountHelper.populateResponse(tradingCodeNames);
				serviceResponse.setPollingStatus("S");
		    }
		    else
		    {
		    	serviceResponse  = new BusinessAccountResp();
		    	serviceResponse.setPollingStatus("P");
		    }
			RespHeader headerResp = populateResponseHeader(req.getHeader().getServiceName(), mbSession );
			serviceResponse.setHeader(headerResp);
			
			return serviceResponse;
		} catch (BusinessException e)
		{
			businessAccountDetails.setAbn(null);
			businessAccountDetails.setAbnName(null);
			if(businessAccountDetails.getIsActivate())
			{
				return getDefaultAbnTradingNameResponse();
			}
			Logger.error("Exception Inside BusinessAccountController.getDetails: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			return createErrorResp(mbSession.getOrigin() , e.getKey(), MBAppConstants.BUSINESS_ACCOUNT_SERVICE, httpServletRequest);
		} catch (Exception e)
		{	
			businessAccountDetails.setAbn(null);
			businessAccountDetails.setAbnName(null);
			if(businessAccountDetails.getIsActivate())
			{
				return getDefaultAbnTradingNameResponse();
			}
			Logger.error("Exception Inside BusinessAccountController.getDetails: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			BusinessException exp = new BusinessException(BusinessException.BUSINESS_ACCOUNT_SVC_UNAVAILABLE);
			return createErrorResp(mbSession.getOrigin(), exp.getKey(), MBAppConstants.BUSINESS_ACCOUNT_SERVICE, httpServletRequest);
		} finally
		{
			perfLogger.endLog(logName);
			perfLogger.endAllLogs();
		}			
	}
	private BusinessAccountResp getDefaultAbnTradingNameResponse()
	{
		List<String> businessNames = new ArrayList<String>();
		businessNames.add(BusinessAccountService.DEFAULT_TRADING_NAME);
		List<LabelValueVO> tradingCodeNames = businessAccountHelper.populateBusinessNames(businessNames);
		BusinessAccountResp businessAccountResp = new BusinessAccountResp();
		businessAccountResp.setTradingNames(tradingCodeNames);
		businessAccountResp.setPollingStatus("S");
		return businessAccountResp;
	}
	
	@RequestMapping(value= "verifyAbn" , method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public IMBResp verifyAbn(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse,
			@RequestBody final BusinessAccountAbnReq req)
	{				
				
		Logger.debug("In BusinessAccountController.verifyAbn " + httpServletRequest.getContentType() + " "
				+ httpServletRequest.getRemoteAddr() + "  " + httpServletResponse.getCharacterEncoding() + httpServletResponse.getLocale() +
				" True IP >> " + httpServletRequest.getHeader(IBankParams.trueClientIP()), this.getClass());

		perfLogger.startAllLogs();
		String logName = MBAppUtils.getLogName(httpServletRequest);
		perfLogger.startLog(logName);
		MobileSession mbSession = null;
		try
		{
			mbSession = mbAppHelper.getMobileSession(httpServletRequest);	
			
			validateRequestHeader( req.getHeader(), httpServletRequest );

			ErrorResp errorResp = validate(req, httpServletRequest);
			if (errorResp != null && errorResp.getErrors() != null && errorResp.getErrors().size() > 0)
			{
				populateErrorHeader(errorResp);
				return errorResp;
			}

			IBankCommonData ibankCommonData=mbAppHelper.populateIBankCommonData(mbSession,httpServletRequest);
			
			String requestId = businessAccountService.searchAbn(req.getAbnNumber(),ibankCommonData);
			
			
			BusinessAccountDetails businessAccountDetails = mbSession.getBusinessAccountDetails();
			businessAccountDetails.setRequestId(requestId);
			businessAccountDetails.setAbn(req.getAbnNumber());
			businessAccountDetails.setAbnRetriveCount(0);
			
			
			BusinessAccountResp serviceResponse = new BusinessAccountResp();
			serviceResponse.setPollingDelay( IBankParams.abnVerifyTimeout(mbSession.getOrigin()));
			RespHeader headerResp = populateResponseHeader(req.getHeader().getServiceName(), mbSession );
			serviceResponse.setHeader(headerResp);
			
			return serviceResponse;
		} catch (BusinessException e)
		{
			Logger.error("Exception Inside BusinessAccountController.getDetails: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			return createErrorResp(mbSession.getOrigin() , e.getKey(), MBAppConstants.BUSINESS_ACCOUNT_SERVICE, httpServletRequest);
		} catch (Exception e)
		{	
			Logger.error("Exception Inside BusinessAccountController.getDetails: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			BusinessException exp = new BusinessException(BusinessException.BUSINESS_ACCOUNT_SVC_UNAVAILABLE);
			return createErrorResp(mbSession.getOrigin(), exp.getKey(), MBAppConstants.BUSINESS_ACCOUNT_SERVICE, httpServletRequest);
		} finally
		{
			perfLogger.endLog(logName);
			perfLogger.endAllLogs();
		}			
	}
	

	@RequestMapping(value= "savings" , method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public IMBResp openSavingsAccount(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse,
			@RequestBody final BusinessAccountOpenReq req)
	{				
		
		Logger.debug("In BusinessAccountController.openSavingsAccount " + httpServletRequest.getContentType() + " "
				+ httpServletRequest.getRemoteAddr() + "  " + httpServletResponse.getCharacterEncoding() + httpServletResponse.getLocale() +
				" True IP >> " + httpServletRequest.getHeader(IBankParams.trueClientIP()), this.getClass());
		
		perfLogger.startAllLogs();
		String logName = MBAppUtils.getLogName(httpServletRequest);
		perfLogger.startLog(logName);
		MobileSession mbSession = null;
		IBankCommonData commonData= null;
		try
		{
			mbSession = mbAppHelper.getMobileSession(httpServletRequest);	
			commonData = mbAppHelper.populateIBankCommonData(mbSession,httpServletRequest);
			
			return openAccount(httpServletRequest, httpServletResponse, req, mbSession, PRODUCT_TYPE_SAVING_BUSINESS);
		} catch (BusinessException e)
		{
			Logger.error("Exception Inside BusinessAccountController.openSavingsAccount: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			if(e.getKey() == BusinessException.BUS_ACCOUNT_ABN_FUZZY_MATCH_TO_CUTOMER_NAME_FAILED ||
					e.getKey() == BusinessException.BUS_ACCOUNT_SPLIT_ADDRESS ||
					e.getKey() == BusinessException.BUS_ACCOUNT_VERIFY_BLACK_LISTED_IPS_FAILED )
            {
				businessAccountService.closeInvitationLead(commonData, mbSession.getBusinessAccountDetails().getLeadId());
            }
			return createErrorResp(mbSession.getOrigin() , e.getKey(), MBAppConstants.BUSINESS_ACCOUNT_SERVICE, httpServletRequest);
		} catch (Exception e)
		{	
			Logger.error("Exception Inside BusinessAccountController.openSavingsAccount: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			BusinessException exp = new BusinessException(BusinessException.BUSINESS_ACCOUNT_PROBLEMS_TRY_LATER);
			return createErrorResp(mbSession.getOrigin(), exp.getKey(), MBAppConstants.BUSINESS_ACCOUNT_SERVICE, httpServletRequest);
		} finally
		{
			perfLogger.endLog(logName);
			perfLogger.endAllLogs();
		}			
	}
	
	@RequestMapping(value= "freedom" , method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public IMBResp openFreedomAccount(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse,
			@RequestBody final BusinessAccountOpenReq req)
	{				
				
		Logger.debug("In BusinessAccountController.openFreedomAccount " + httpServletRequest.getContentType() + " "
				+ httpServletRequest.getRemoteAddr() + "  " + httpServletResponse.getCharacterEncoding() + httpServletResponse.getLocale() +
				" True IP >> " + httpServletRequest.getHeader(IBankParams.trueClientIP()), this.getClass());

		
		perfLogger.startAllLogs();
		String logName = MBAppUtils.getLogName(httpServletRequest);
		perfLogger.startLog(logName);
		MobileSession mbSession = null;
		IBankCommonData commonData = null;
		try
		{
    		    ErrorResp errorResp = validate(req, httpServletRequest);
    			if (errorResp != null && errorResp.getErrors() != null && errorResp.getErrors().size() > 0)
    			{
    				populateErrorHeader(errorResp);
    				return errorResp;
    			}
    		    mbSession = mbAppHelper.getMobileSession(httpServletRequest);	
    		    commonData = mbAppHelper.populateIBankCommonData(mbSession,httpServletRequest);
    		    return openAccount(httpServletRequest, httpServletResponse, req, mbSession, PRODUCT_TYPE_FREEDOM_BUSINESS);
		} catch (BusinessException e)
		{
			Logger.error("Exception Inside BusinessAccountController.openFreedomAccount: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			if(e.getKey() == BusinessException.BUS_ACCOUNT_ABN_FUZZY_MATCH_TO_CUTOMER_NAME_FAILED ||
					e.getKey() == BusinessException.BUS_ACCOUNT_SPLIT_ADDRESS ||
					e.getKey() == BusinessException.BUS_ACCOUNT_VERIFY_BLACK_LISTED_IPS_FAILED )
            {
				businessAccountService.closeInvitationLead(commonData, mbSession.getBusinessAccountDetails().getLeadId());
            }
			return createErrorResp(mbSession.getOrigin() , e.getKey(), MBAppConstants.BUSINESS_ACCOUNT_SERVICE, httpServletRequest);
		} catch (Exception e)
		{	
			Logger.error("Exception Inside BusinessAccountController.openFreedomAccount: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			BusinessException exp = new BusinessException(BusinessException.BUSINESS_ACCOUNT_PROBLEMS_TRY_LATER);
			return createErrorResp(mbSession.getOrigin(), exp.getKey(), MBAppConstants.BUSINESS_ACCOUNT_SERVICE, httpServletRequest);
		} finally
		{
			perfLogger.endLog(logName);
			perfLogger.endAllLogs();
		}			
	}
	
	private String getBusinessNameFromCode(String code, List<LabelValueVO> valueVOs)
	{
		if(StringMethods.isEmptyString(code))
		{
			return null;
		}
		for(LabelValueVO vo:valueVOs)
		{
			if(code.equals(vo.getValue()))
			{
				return vo.getLabel();
			}
		}
		return null;
	}
	
	private void validateIndustryTypeCode(String code, List<LabelValueVO> valueVOs) throws BusinessException
	{
		if(StringMethods.isEmptyString(code))
		{
			Logger.error("Invalid Industry type from request", this.getClass());
			throw new BusinessException(BusinessException.SYSTEM_UNAVILABLE);
		}
		for(LabelValueVO vo:valueVOs)
		{
			if(code.equals(vo.getValue()))
			{
				return;
			}
		}
		Logger.error("Invalid Industry type from request", this.getClass());
		throw new BusinessException(BusinessException.SYSTEM_UNAVILABLE);
	}
	
	private void validateOccupationTypeCode(String code, List<LabelValueVO> valueVOs) throws BusinessException
	{
		if(StringMethods.isEmptyString(code))
		{
			Logger.error("Invalid Occupation type from request", this.getClass());
			throw new BusinessException(BusinessException.SYSTEM_UNAVILABLE);
		}
		for(LabelValueVO vo:valueVOs)
		{
			if(code.equals(vo.getValue()))
			{
				return;
			}
		}
		Logger.error("Invalid Occupation type from request", this.getClass());
		throw new BusinessException(BusinessException.SYSTEM_UNAVILABLE);
	}
	
	private IMBResp openAccount(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse,BusinessAccountOpenReq req, MobileSession mbSession, String productType) throws BusinessException, InterruptedException{
		validateRequestHeader( req.getHeader(), httpServletRequest );

		ErrorResp errorResp = validate(req, httpServletRequest);
		if (errorResp != null && errorResp.getErrors() != null && errorResp.getErrors().size() > 0)
		{
			populateErrorHeader(errorResp);
			return errorResp;
		}

		IBankCommonData ibankCommonData=mbAppHelper.populateIBankCommonData(mbSession,httpServletRequest);
		
		BusinessAccountDetails businessAccountDetails = mbSession.getBusinessAccountDetails();
		
		if(!productType.equalsIgnoreCase(businessAccountDetails.getProductType()))
		{
			Logger.error("BusinessAccountController.openAccount: productType doesn't match with the one in Session ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", this.getClass());
			throw new BusinessException(BusinessException.SYSTEM_UNAVILABLE);
		}
		
		if(!StringMethods.isEmptyString(req.getBusinessName()))
		{
			String businessRegName = getBusinessNameFromCode(req.getBusinessName(), businessAccountDetails.getBusinessNames());
			businessAccountDetails.setBusinessRegisteredName(businessRegName);
		}else if(StringMethods.isEmptyString(req.getAbnNumber()))
		{
			businessAccountDetails.setBusinessRegisteredName(BusinessAccountService.DEFAULT_TRADING_NAME);
		}
		
		if(!businessAccountDetails.getIsActivate())//Unlock
		{
			validateIndustryTypeCode(req.getIndustryType(), businessAccountDetails.getIndustryList());
			businessAccountDetails.setIndustryTypeCode(req.getIndustryType());
			
			if(req.getBusinessAddress() != null)
			{
				Address address = contactDetailHelper.getAddress(req.getBusinessAddress());
				businessAccountService.validateAddress(null, null, address);
				businessAccountDetails.setBusinessAddress(address);
			}
			
			businessAccountDetails.setBusinessAddressId(req.getAddressId());
			if(req.getBusinessAddress() == null && StringMethods.isEmptyString(req.getAddressId()))
			{
				 businessAccountDetails.setBusinessAddress(ibankCommonData.getCustomer().getContactDetail().getResidentialAddress() );
			}
			
			CRSInfo crsInfo = req.getCrsInfo();
			if(crsInfo != null)
			{
				List<EVForeignCountryDetail> evForeignCountryDtls = IBankParams.getForeignTINDetails();
				crsHelper.validateCRSData(crsInfo, evForeignCountryDtls);
				
				au.com.stgeorge.ibank.evcrs.businessobject.valueobject.CRSInfo crsInfoVo=crsHelper.populateCRSInfoVo(crsInfo,evForeignCountryDtls);
				businessAccountDetails.setCrsInfo(crsInfoVo);
			}
			//19E4 Tech Debt Start:Switch Removal
			/*if(IBankParams.isUnlockActivateDeltaInfoSwitchON()){*/
				//Delta Info
				if(req.getSourceOfFunds() != null && req.getSourceOfFunds().size()>0)
				{
					businessAccountDetails.setSourceOfFunds(req.getSourceOfFunds());	 
				}
				if(req.getSourceOfWealth() != null && req.getSourceOfWealth().size()>0)
				{
					businessAccountDetails.setSourceOfWealth(req.getSourceOfWealth());
				}
				if(req.getEmploymentType() != null && !StringMethods.isEmptyString(req.getEmploymentType()))
				{
					businessAccountDetails.setEmploymentType(req.getEmploymentType());
				}
				if(req.getOccupationType() != null && !StringMethods.isEmptyString(req.getOccupationType()))
				{
					businessAccountDetails.setOccupationType(req.getOccupationType());
				}
				businessAccountDetails.setAlternateNameCaptured(req.isAlternateNameCaptured());
				businessAccountDetails.setPobrCaptured(req.isPobrCaptured());
		/*	}*/
				//19E4 Tech Debt End:Switch Removal
		}
		
		if(PRODUCT_TYPE_FREEDOM_BUSINESS.equalsIgnoreCase(productType))
		{
			businessAccountDetails.setHasCrossSell(req.isCrossSell());
		}
		
		if(StringMethods.isEmptyString(req.getAbnNumber()))
		{
			businessAccountDetails.setAbn(null);
			businessAccountDetails.setAbnName(null);
		}
		
		businessAccountDetails.setCorrelationId(mbSession.getEVThreatMatrixSessionID());
		
		if(businessAccountDetails.getIsActivate())
		{
			if(PRODUCT_TYPE_FREEDOM_BUSINESS.equalsIgnoreCase(productType))
			{
				businessAccountDetails.setAccountType(BusinessAccountDetails.BusAccountEnum.FREEDOM.name());
				businessAccountService.activateBusinessFreedomAccount(businessAccountDetails, ibankCommonData);
			}else{
				businessAccountDetails.setAccountType(BusinessAccountDetails.BusAccountEnum.SAVING.name());
				businessAccountService.activateBusinessSavingAccount(businessAccountDetails, ibankCommonData);
			}
			
		}else{
			DigitalSecLogggerVO digitalSecLogggerVO = getDigitalSecLogggerVO(ibankCommonData, DigitalSecLogger.CRS_MAINTENANCE_ACTION_ADD);
			try{				
				if(PRODUCT_TYPE_FREEDOM_BUSINESS.equalsIgnoreCase(productType))
				{
					businessAccountDetails.setAccountType(BusinessAccountDetails.BusAccountEnum.FREEDOM.name());
					businessAccountService.unlockBusinessFreedomAccount(businessAccountDetails, ibankCommonData);
				}else{
					businessAccountDetails.setAccountType(BusinessAccountDetails.BusAccountEnum.SAVING.name());
					businessAccountService.unlockBusinessSavingAccount(businessAccountDetails, ibankCommonData);
				}
			}finally{
				fraudLogForCRS(businessAccountDetails, digitalSecLogggerVO);
			}
		}		
		
		businessAccountDetails.setAccountRetriveCount(0);
		
		RespHeader headerResp = populateResponseHeader(req.getHeader().getServiceName(), mbSession );
		BusinessAccountResp accountOpenResp = new BusinessAccountResp();
		accountOpenResp.setPollingDelay(IBankParams.businessAccountRetrieveTimeout(mbSession.getOrigin()));
		
		if ( ! businessAccountDetails.isUpdateCRSFailed() )
		{
		   if ( removedCRSTile(mbSession, ibankCommonData) )
		   {
			   accountOpenResp.setRemoveCRSTile("Y");
			}
		}

		accountOpenResp.setHeader(headerResp);

		
		return accountOpenResp;
	}
	
	@RequestMapping(value= "retrieveAccount" , method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public IMBResp retrieveAccount(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse,
			@RequestBody final EmptyReq req)
	{	
		Logger.debug("In BusinessAccountController.retrieveAccount " + httpServletRequest.getContentType() + " "
				+ httpServletRequest.getRemoteAddr() + "  " + httpServletResponse.getCharacterEncoding() + httpServletResponse.getLocale() +
				" True IP >> " + httpServletRequest.getHeader(IBankParams.trueClientIP()), this.getClass());

		perfLogger.startAllLogs();
		String logName = MBAppUtils.getLogName(httpServletRequest);
		perfLogger.startLog(logName);
		MobileSession mbSession = null;
		try
		{
			validateRequestHeader( req.getHeader(), httpServletRequest );
			
			ErrorResp errorResp = validate(req, httpServletRequest);
			if (errorResp != null && errorResp.getErrors() != null && errorResp.getErrors().size() > 0)
			{
				populateErrorHeader(errorResp);
				return errorResp;
			}
			
			mbSession = mbAppHelper.getMobileSession(httpServletRequest);	
			
			IBankCommonData ibankCommonData=mbAppHelper.populateIBankCommonData(mbSession,httpServletRequest);
			
			BusinessAccountDetails businessAccountDetails = mbSession.getBusinessAccountDetails();
			
			businessAccountDetails.setAccountRetriveCount(businessAccountDetails.getAccountRetriveCount() + 1);
			
			NewBusinessAccountDetails newBusinessAccountDetails = businessAccountService.retrieveAccountCreationStatus(businessAccountDetails, ibankCommonData, false);		

			BusinessAccountResp accountOpenResp = new BusinessAccountResp();			
			if(newBusinessAccountDetails != null)
			{
				accountOpenResp.setPollingStatus("S");
				
				accountOpenResp.setStatus(AccountReceiptStatus.HARD_BLOCK.getValue());
				if(!StringMethods.isEmptyString(newBusinessAccountDetails.getAccountNumber()))
				{
					BusinessAccountReceiptResp primaryAccount = new BusinessAccountReceiptResp();
					primaryAccount.setAccountNumDisp(mbAppHelper.getFormattedAcctNumber(newBusinessAccountDetails.getAccountNumber(),Account.DDA,null));
					accountOpenResp.setAccount(primaryAccount);
					if(PRODUCT_TYPE_FREEDOM_BUSINESS.equalsIgnoreCase(businessAccountDetails.getProductType()))
					{
						primaryAccount.setAccountName(FREEDOM_DEFAULT_NAME);
						accountOpenResp.setHasDebitCard(!StringMethods.isEmptyString(newBusinessAccountDetails.getDebitCardNumber()) ? true:false);
					}
					else
					{
						primaryAccount.setAccountName(SAVING_DEFAULT_NAME);
					}
					AccountId pAccountId = new AccountId();
					pAccountId.setAccountNumber(newBusinessAccountDetails.getAccountNumber());
					if ( "MBSA".equalsIgnoreCase(ibankCommonData.getOrigin()) )
					{
						pAccountId.setAccountNumber("900"+ newBusinessAccountDetails.getAccountNumber()); // For BSA the Branch code is 900
					
					}
					pAccountId.setApplicationId(Account.DDA);
					accountOpenResp.setIndex(mbAppHelper.getAccountIndexByAccountId(ibankCommonData.getCustomer().getAccounts(), pAccountId));
					accountOpenResp.setStatus(AccountReceiptStatus.CONFIRM.getValue());
				}
				if(!StringMethods.isEmptyString(newBusinessAccountDetails.getAccountNumberCrossSell()))
				{
					BusinessAccountReceiptResp crossSellAccount = new BusinessAccountReceiptResp();
					
					crossSellAccount.setAccountNumDisp(mbAppHelper.getFormattedAcctNumber(newBusinessAccountDetails.getAccountNumberCrossSell(),Account.DDA,null));
					accountOpenResp.setAccountCrossSell(crossSellAccount);
					if(PRODUCT_TYPE_FREEDOM_BUSINESS.equalsIgnoreCase(businessAccountDetails.getProductType()))
					{
						crossSellAccount.setAccountName(SAVING_DEFAULT_NAME);						
					}
					else
					{
						crossSellAccount.setAccountName(FREEDOM_DEFAULT_NAME);
						accountOpenResp.setHasDebitCard(!StringMethods.isEmptyString(newBusinessAccountDetails.getDebitCardNumber()) ? true:false);
					}
					AccountId pAccountId = new AccountId();
					pAccountId.setAccountNumber(newBusinessAccountDetails.getAccountNumberCrossSell());
					if ( "MBSA".equalsIgnoreCase(ibankCommonData.getOrigin()) )
					{
						pAccountId.setAccountNumber("900"+ newBusinessAccountDetails.getAccountNumberCrossSell());
					}
					pAccountId.setApplicationId(Account.DDA);
					accountOpenResp.setIndexCrossSell(mbAppHelper.getAccountIndexByAccountId(ibankCommonData.getCustomer().getAccounts(), pAccountId));
				}
				else if(businessAccountDetails.getHasCrossSell())
				{
					accountOpenResp.setIndexCrossSell(-1);
				}
				
				
				if(newBusinessAccountDetails.getInfoList() != null && !newBusinessAccountDetails.getInfoList().isEmpty())
				{
					LabelValueVO secondaryAccountFailure = null;
					List<LabelValueVO> labelValueVOs = new ArrayList(newBusinessAccountDetails.getInfoList());
					for(LabelValueVO labelValueVO:labelValueVOs)
					{
						if((""+BusinessException.BUS_ACCOUNT_OPEN_SECONDRY_FAILED_BSA).equals(labelValueVO.getLabel()))
						{
							BusinessAccountReceiptResp crossSellAccount = new BusinessAccountReceiptResp();
							String msg = MBAppUtils.getMessage(mbSession.getOrigin(), Integer.valueOf(labelValueVO.getLabel()));
							crossSellAccount.setErrorMessage(msg);
							accountOpenResp.setAccountCrossSell(crossSellAccount);
							secondaryAccountFailure = labelValueVO;
							if(PRODUCT_TYPE_FREEDOM_BUSINESS.equalsIgnoreCase(businessAccountDetails.getProductType()))
							{
								crossSellAccount.setAccountName(SAVING_DEFAULT_NAME);
							}
							else
							{
								crossSellAccount.setAccountName(FREEDOM_DEFAULT_NAME);
							}
						}
					}
					if(secondaryAccountFailure != null)
					{
						labelValueVOs.remove(secondaryAccountFailure);
					}					
					if(!labelValueVOs.isEmpty())
					{
						LabelValueVO valueVO = labelValueVOs.get(0);
						Integer msgkey = Integer.valueOf(valueVO.getLabel()); 
						if(msgkey == BusinessException.BUS_ACCOUNT_ORG_IDV_FAILED)
						{
							accountOpenResp.setIsPcoBlocked(true);
							accountOpenResp.setWarningMsg(MBAppUtils.getMessage(mbSession.getOrigin(), msgkey));
						}
						else
						{
							populateError(accountOpenResp, mbSession.getOrigin(), Integer.valueOf(valueVO.getLabel()));
						}
						if("H".equals(valueVO.getValue()))
						{
							accountOpenResp.setStatus(AccountReceiptStatus.HARD_BLOCK.getValue());
						}else if("R".equals(valueVO.getValue()))
						{
							accountOpenResp.setStatus(AccountReceiptStatus.CONFIRM.getValue());
						}
					}					
				}
				else if(StringMethods.isEmptyString(newBusinessAccountDetails.getAccountNumber()))
				{
					throw new BusinessException(BusinessException.SYSTEM_UNAVILABLE);
				}
			}else
			{
				accountOpenResp.setPollingStatus("P");
			}
			
			mbSession.setCustomer(ibankCommonData.getCustomer());
			List<au.com.stgeorge.mbank.model.common.AccountResp> accountList = logonHelper.populateAccountList(ibankCommonData.getCustomer(),mbSession.getAutoApplyRetentionInfo());
			accountOpenResp.setAccounts(accountList);
			Logger.debug("Account resp status: "+accountOpenResp.getStatus() + " Block Val: "+ AccountReceiptStatus.HARD_BLOCK.getValue() + "Condition eval: "+ Integer.valueOf(accountOpenResp.getStatus()).equals(AccountReceiptStatus.HARD_BLOCK.getValue()), getClass());
			
			//if there is no hard block, closing the invitation lead
			if(! Integer.valueOf(accountOpenResp.getStatus()).equals(AccountReceiptStatus.HARD_BLOCK.getValue())){
				businessAccountService.closeInvitationLead(ibankCommonData, businessAccountDetails.getLeadId() );
			}
			RespHeader headerResp = populateResponseHeader(req.getHeader().getServiceName(), mbSession );
			accountOpenResp.setHeader(headerResp);
			
			return accountOpenResp;
		} catch (BusinessException e)
		{
			Logger.error("Exception Inside BusinessAccountController.retrieveAccount: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			return createErrorResp(mbSession.getOrigin() , e.getKey(), MBAppConstants.BUSINESS_ACCOUNT_SERVICE, httpServletRequest);
		} catch (Exception e)
		{	
			Logger.error("Exception Inside BusinessAccountController.retrieveAccount: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			BusinessException exp = new BusinessException(BusinessException.BUSINESS_ACCOUNT_PROBLEMS_TRY_LATER);
			return createErrorResp(mbSession.getOrigin(), exp.getKey(), MBAppConstants.BUSINESS_ACCOUNT_SERVICE, httpServletRequest);
		} finally
		{
			perfLogger.endLog(logName);
			perfLogger.endAllLogs();
		}
	}
	
	@RequestMapping(value= "retrieveAccountSoleDirector" , method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public IMBResp retrieveAccountSoleDirector(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, @RequestBody final EmptyReq req)
	{	
		Logger.debug("In BusinessAccountController.retrieveAccountSoleDirector " + httpServletRequest.getContentType() + " " + httpServletRequest.getRemoteAddr() + "  " + httpServletResponse.getCharacterEncoding() + httpServletResponse.getLocale(), this.getClass());

		perfLogger.startAllLogs();
		String logName = MBAppUtils.getLogName(httpServletRequest);
		perfLogger.startLog(logName);
		MobileSession mbSession = null;
		try
		{
			validateRequestHeader( req.getHeader(), httpServletRequest );
			
			ErrorResp errorResp = validate(req, httpServletRequest);
			if (errorResp != null && errorResp.getErrors() != null && errorResp.getErrors().size() > 0)
			{
				populateErrorHeader(errorResp);
				return errorResp;
			}
			
			mbSession = mbAppHelper.getMobileSession(httpServletRequest);	
			
			IBankCommonData ibankCommonData=mbAppHelper.populateIBankCommonData(mbSession,httpServletRequest);
			
			BusinessAccountDetails businessAccountDetails = mbSession.getBusinessAccountDetails();
			
			businessAccountDetails.setAccountRetriveCount(businessAccountDetails.getAccountRetriveCount() + 1);
			
			NewBusinessAccountDetails newBusinessAccountDetails = businessAccountService.retrieveAccountCreationStatus(businessAccountDetails, ibankCommonData, true);		

			BusinessAccountResp accountOpenResp = new BusinessAccountResp();			
			if(newBusinessAccountDetails != null)
			{
				accountOpenResp.setPollingStatus("S");
				
				accountOpenResp.setStatus(AccountReceiptStatus.HARD_BLOCK.getValue());
				if(!StringMethods.isEmptyString(newBusinessAccountDetails.getAccountNumber()))
				{
					BusinessAccountReceiptResp primaryAccount = new BusinessAccountReceiptResp();
					primaryAccount.setAccountNumDisp(mbAppHelper.getFormattedAcctNumber(newBusinessAccountDetails.getAccountNumber(),Account.DDA,null));
					accountOpenResp.setAccount(primaryAccount);
					if(PRODUCT_TYPE_FREEDOM_BUSINESS.equalsIgnoreCase(businessAccountDetails.getProductType()))
					{
						primaryAccount.setAccountName(FREEDOM_DEFAULT_NAME);
						accountOpenResp.setHasDebitCard(!StringMethods.isEmptyString(newBusinessAccountDetails.getDebitCardNumber()) ? true:false);
					}
					else
					{
						primaryAccount.setAccountName(SAVING_DEFAULT_NAME);
					}
					AccountId pAccountId = new AccountId();
					pAccountId.setAccountNumber(newBusinessAccountDetails.getAccountNumber());
					if ( "MBSA".equalsIgnoreCase(ibankCommonData.getOrigin()) )
					{
						pAccountId.setAccountNumber("900"+ newBusinessAccountDetails.getAccountNumber()); // For BSA the Branch code is 900
					
					}
					pAccountId.setApplicationId(Account.DDA);
					accountOpenResp.setIndex(mbAppHelper.getAccountIndexByAccountId(ibankCommonData.getCustomer().getAccounts(), pAccountId));
					accountOpenResp.setStatus(AccountReceiptStatus.CONFIRM.getValue());
				}
				if(!StringMethods.isEmptyString(newBusinessAccountDetails.getAccountNumberCrossSell()))
				{
					BusinessAccountReceiptResp crossSellAccount = new BusinessAccountReceiptResp();
					
					crossSellAccount.setAccountNumDisp(mbAppHelper.getFormattedAcctNumber(newBusinessAccountDetails.getAccountNumberCrossSell(),Account.DDA,null));
					accountOpenResp.setAccountCrossSell(crossSellAccount);
					if(PRODUCT_TYPE_FREEDOM_BUSINESS.equalsIgnoreCase(businessAccountDetails.getProductType()))
					{
						crossSellAccount.setAccountName(SAVING_DEFAULT_NAME);						
					}
					else
					{
						crossSellAccount.setAccountName(FREEDOM_DEFAULT_NAME);
						accountOpenResp.setHasDebitCard(!StringMethods.isEmptyString(newBusinessAccountDetails.getDebitCardNumber()) ? true:false);
					}
					AccountId pAccountId = new AccountId();
					pAccountId.setAccountNumber(newBusinessAccountDetails.getAccountNumberCrossSell());
					if ( "MBSA".equalsIgnoreCase(ibankCommonData.getOrigin()) )
					{
						pAccountId.setAccountNumber("900"+ newBusinessAccountDetails.getAccountNumberCrossSell());
					}
					pAccountId.setApplicationId(Account.DDA);
					accountOpenResp.setIndexCrossSell(mbAppHelper.getAccountIndexByAccountId(ibankCommonData.getCustomer().getAccounts(), pAccountId));
				}
				else if(businessAccountDetails.getHasCrossSell())
				{
					accountOpenResp.setIndexCrossSell(-1);
				}
				
				
				if(newBusinessAccountDetails.getInfoList() != null && !newBusinessAccountDetails.getInfoList().isEmpty())
				{
					LabelValueVO secondaryAccountFailure = null;
					List<LabelValueVO> labelValueVOs = new ArrayList(newBusinessAccountDetails.getInfoList());
					for(LabelValueVO labelValueVO:labelValueVOs)
					{
						if((""+BusinessException.BUS_ACCOUNT_OPEN_SECONDRY_FAILED_BSA).equals(labelValueVO.getLabel()))
						{
							BusinessAccountReceiptResp crossSellAccount = new BusinessAccountReceiptResp();
							String msg = MBAppUtils.getMessage(mbSession.getOrigin(), Integer.valueOf(labelValueVO.getLabel()));
							crossSellAccount.setErrorMessage(msg);
							accountOpenResp.setAccountCrossSell(crossSellAccount);
							secondaryAccountFailure = labelValueVO;
							if(PRODUCT_TYPE_FREEDOM_BUSINESS.equalsIgnoreCase(businessAccountDetails.getProductType()))
							{
								crossSellAccount.setAccountName(SAVING_DEFAULT_NAME);
							}
							else
							{
								crossSellAccount.setAccountName(FREEDOM_DEFAULT_NAME);
							}
						}
					}
					if(secondaryAccountFailure != null)
					{
						labelValueVOs.remove(secondaryAccountFailure);
					}					
					if(!labelValueVOs.isEmpty())
					{
						LabelValueVO valueVO = labelValueVOs.get(0);
						Integer msgkey = Integer.valueOf(valueVO.getLabel()); 
						if(msgkey == BusinessException.BUS_ACCOUNT_ORG_IDV_FAILED)
						{
							accountOpenResp.setIsPcoBlocked(true);
							accountOpenResp.setWarningMsg(MBAppUtils.getMessage(mbSession.getOrigin(), msgkey));
						}
						else
						{
							populateError(accountOpenResp, mbSession.getOrigin(), Integer.valueOf(valueVO.getLabel()));
						}
						if("H".equals(valueVO.getValue()))
						{
							accountOpenResp.setStatus(AccountReceiptStatus.HARD_BLOCK.getValue());
						}else if("R".equals(valueVO.getValue()))
						{
							accountOpenResp.setStatus(AccountReceiptStatus.CONFIRM.getValue());
						}
					}					
				}
				else if(StringMethods.isEmptyString(newBusinessAccountDetails.getAccountNumber()))
				{
					throw new BusinessException(BusinessException.SYSTEM_UNAVILABLE);
				}
			}else
			{
				accountOpenResp.setPollingStatus("P");
			}
			
			mbSession.setCustomer(ibankCommonData.getCustomer());
			List<au.com.stgeorge.mbank.model.common.AccountResp> accountList = logonHelper.populateAccountList(ibankCommonData.getCustomer(),mbSession.getAutoApplyRetentionInfo());
			accountOpenResp.setAccounts(accountList);
			
			Logger.debug("Account resp status: "+accountOpenResp.getStatus() + " Block Val: "+ AccountReceiptStatus.HARD_BLOCK.getValue() + "Condition eval: "+ Integer.valueOf(accountOpenResp.getStatus()).equals(AccountReceiptStatus.HARD_BLOCK.getValue()), getClass());
			//if there is no hard block, closing the invitation lead
			if(! Integer.valueOf(accountOpenResp.getStatus()).equals(AccountReceiptStatus.HARD_BLOCK.getValue())){
				businessAccountService.closeInvitationLead(ibankCommonData, businessAccountDetails.getLeadId() );
			}
			
			RespHeader headerResp = populateResponseHeader(req.getHeader().getServiceName(), mbSession );
			accountOpenResp.setHeader(headerResp);
			
			return accountOpenResp;
		} catch (BusinessException e)
		{
			Logger.error("Exception Inside BusinessAccountController.retrieveAccount: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			return createErrorResp(mbSession.getOrigin() , e.getKey(), MBAppConstants.BUSINESS_ACCOUNT_SERVICE, httpServletRequest);
		} catch (Exception e)
		{	
			Logger.error("Exception Inside BusinessAccountController.retrieveAccount: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			BusinessException exp = new BusinessException(BusinessException.BUSINESS_ACCOUNT_PROBLEMS_TRY_LATER);
			return createErrorResp(mbSession.getOrigin(), exp.getKey(), MBAppConstants.BUSINESS_ACCOUNT_SERVICE, httpServletRequest);
		} finally
		{
			perfLogger.endLog(logName);
			perfLogger.endAllLogs();
		}
	}
	

	public ErrorResp validate(IMBReq serviceRequest, HttpServletRequest request) {
		return mbAppValidator.validate(serviceRequest, request);
	}
	
	public void validateRequestHeader(ReqHeader header, HttpServletRequest request) throws ResourceException
	{	
		mbAppValidator.validateRequestHeader(header,  request);	
	}
	
	public RespHeader populateResponseHeader(String serviceName, MobileSession mobSession )
	{
		return mbAppHelper.populateResponseHeader(serviceName, mobSession);
	}
	
	enum AccountReceiptStatus{
		HARD_BLOCK(0),
		SETUP(1),
		CONFIRM(2);
		
		private int value;

    	private AccountReceiptStatus(int i) {
		          this.value = i;
		}
		public int getValue() {
			return value;
		}
	}
	
	@RequestMapping(value= "industryTypeList" , method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public IMBResp getIndustryTypeList(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse,
			@RequestBody final BusinessAccountReq req)
	{				
				
		Logger.debug("In BusinessAccountController.industryTypeList " + httpServletRequest.getContentType() + " "
				+ httpServletRequest.getRemoteAddr() + "  " + httpServletResponse.getCharacterEncoding() + httpServletResponse.getLocale() +
				" True IP >> " + httpServletRequest.getHeader(IBankParams.trueClientIP()), this.getClass());

		perfLogger.startAllLogs();
		String logName = MBAppUtils.getLogName(httpServletRequest);
		perfLogger.startLog(logName);
		MobileSession mbSession = null;
		try
		{
			mbSession = mbAppHelper.getMobileSession(httpServletRequest);	
			
			validateRequestHeader( req.getHeader(), httpServletRequest );

			ErrorResp errorResp = validate(req, httpServletRequest);
			if (errorResp != null && errorResp.getErrors() != null && errorResp.getErrors().size() > 0)
			{
				populateErrorHeader(errorResp);
				return errorResp;
			}

			List<LabelValueVO> industryTypes = getAllIndustryTypes(req.getIndustryType(), mbSession);
			
			IMBResp serviceResponse = businessAccountHelper.populateIndustryTypeResponse(industryTypes);
			
			RespHeader headerResp = populateResponseHeader(req.getHeader().getServiceName(), mbSession );
			serviceResponse.setHeader(headerResp);
			
			return serviceResponse;
		} catch (BusinessException e)
		{
			Logger.error("Exception Inside BusinessAccountController.industryTypeList: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			return createErrorResp(mbSession.getOrigin() , e.getKey(), MBAppConstants.BUSINESS_ACCOUNT_SERVICE, httpServletRequest);
		} catch (Exception e)
		{	
			Logger.error("Exception Inside BusinessAccountController.industryTypeList: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			BusinessException exp = new BusinessException(BusinessException.BUSINESS_ACCOUNT_SVC_UNAVAILABLE);
			return createErrorResp(mbSession.getOrigin(), exp.getKey(), MBAppConstants.BUSINESS_ACCOUNT_SERVICE, httpServletRequest);
		} finally
		{
			perfLogger.endLog(logName);
			perfLogger.endAllLogs();
		}			
	}
	
	private List<LabelValueVO> getAllIndustryTypes(String searchString, MobileSession mbSession) throws BusinessException 
	{
		List<LabelValueVO> labelValueBeanList = new ArrayList<LabelValueVO>();
		
		//Check if IndustryTypes are already in session, if not fetch from database table
		List<LabelValueVO> industryList = null;
		
		if(mbSession.getBusinessAccountDetails()!=null && mbSession.getBusinessAccountDetails().getIndustryList() != null) {
			industryList = mbSession.getBusinessAccountDetails().getIndustryList();
		} else {
			//Make a service call and add the list to session to cache. BusinessAccountDetails is cached in session, so setting the list on BusinessAccountDetails
			industryList = businessAccountService.findIndustryTypes();
			if(mbSession.getBusinessAccountDetails()!=null) {
				mbSession.getBusinessAccountDetails().setIndustryList(industryList);
			}
		}
		if(industryList != null)
		{
			for(LabelValueVO labelValueVO:industryList)
			{
				if(labelValueVO.getLabel().indexOf(searchString) != -1){
					labelValueBeanList.add(labelValueVO);
				}
			}
		}
		return labelValueBeanList;
	}
	
	@RequestMapping(value= "occuTypeList" , method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public IMBResp getOccupationList(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse,
			@RequestBody final BusinessAccountReq req)
	{				
				
		Logger.debug("In BusinessAccountController.occuTypeList " + httpServletRequest.getContentType() + " "
				+ httpServletRequest.getRemoteAddr() + "  " + httpServletResponse.getCharacterEncoding() + httpServletResponse.getLocale() +
				" True IP >> " + httpServletRequest.getHeader(IBankParams.trueClientIP()), this.getClass());

		perfLogger.startAllLogs();
		String logName = MBAppUtils.getLogName(httpServletRequest);
		perfLogger.startLog(logName);
		MobileSession mbSession = null;
		try
		{
			mbSession = mbAppHelper.getMobileSession(httpServletRequest);	
			
			validateRequestHeader( req.getHeader(), httpServletRequest );

			ErrorResp errorResp = validate(req, httpServletRequest);
			if (errorResp != null && errorResp.getErrors() != null && errorResp.getErrors().size() > 0)
			{
				populateErrorHeader(errorResp);
				return errorResp;
			}

			List<LabelValueVO> occupationTypes = getAllOccupationTypes(req.getOccupationType(), mbSession);
			
			IMBResp serviceResponse = businessAccountHelper.populateOccupationTypeResponse(occupationTypes);
			
			RespHeader headerResp = populateResponseHeader(req.getHeader().getServiceName(), mbSession );
			serviceResponse.setHeader(headerResp);
			
			return serviceResponse;
		} catch (BusinessException e)
		{
			Logger.error("Exception Inside BusinessAccountController.occuTypeList: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			return createErrorResp(mbSession.getOrigin() , e.getKey(), MBAppConstants.BUSINESS_ACCOUNT_SERVICE, httpServletRequest);
		} catch (Exception e)
		{	
			Logger.error("Exception Inside BusinessAccountController.occuTypeList: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			BusinessException exp = new BusinessException(BusinessException.BUSINESS_ACCOUNT_SVC_UNAVAILABLE);
			return createErrorResp(mbSession.getOrigin(), exp.getKey(), MBAppConstants.BUSINESS_ACCOUNT_SERVICE, httpServletRequest);
		} finally
		{
			perfLogger.endLog(logName);
			perfLogger.endAllLogs();
		}			
	}
	
	private List<LabelValueVO> getAllOccupationTypes(String searchString, MobileSession mbSession) throws BusinessException 
	{
		List<LabelValueVO> labelValueBeanList = new ArrayList<LabelValueVO>();
		
		//Check if IndustryTypes are already in session, if not fetch from database table
		List<LabelValueVO> occupationList = null;
		
		if(mbSession.getBusinessAccountDetails()!=null && mbSession.getBusinessAccountDetails().getOccupationCodeList() != null) {
			occupationList = mbSession.getBusinessAccountDetails().getOccupationCodeList();
		} else {
			//Make a service call and add the list to session to cache. BusinessAccountDetails is cached in session, so setting the list on BusinessAccountDetails
			occupationList = IBankParams.getCustOccupationList();
			if(mbSession.getBusinessAccountDetails()!=null) {
				mbSession.getBusinessAccountDetails().setOccupationCodeList(occupationList);
			}
		}
		if(occupationList != null)
		{
			for(LabelValueVO labelValueVO:occupationList)
			{
				if(labelValueVO.getLabel().indexOf(searchString) != -1){
					labelValueBeanList.add(labelValueVO);
				}
			}
		}
		return labelValueBeanList;
	}
	private String getBusinessAccountExternalUrl(String origin, String customerType, String productType)
	{
		CodesVO codeItem=IBankParams.getCodesData(origin,IBankParams.EXTERNAL_LINKS, IBankParams.BUSINESS_ACCOUNTS_EXTERNAL_URL_PREFIX+productType+"|"+customerType);
		return codeItem != null ? codeItem.getMessage():null; 
	}
	
	public enum CustomerTypeEnum {
		
		  SOLE ( "S" ),
		  PARTNERSHIP ( "P" ),
		  COMPANY ( "C" );
		  
		  private String value;

		  private CustomerTypeEnum(String value) {
		          this.value = value;
		  }
		  public String getCode() {
				return value;
			}
		};
		
		private void populateError(BusinessAccountResp errorResp, String origin, Integer exceptionKey) {
			String errorMessage = MBAppUtils.getMessage(origin, exceptionKey);	
			if(exceptionKey == BusinessException.BUS_ACCOUNT_VERIFY_BLACK_LISTED_IPS_FAILED)
			{
				Object[] values = {IBankParams.getOrigin(origin).getName()};
                errorMessage = MessageFormat.format(errorMessage.replaceAll("'", "''"), values);
			}
			if (errorMessage==null){
				errorMessage = String.valueOf(exceptionKey);			
			}
			
			String header = businessAccountHelper.getHardStopMsgHeader(exceptionKey);
			if(!StringMethods.isEmptyString(header))
			{
				errorResp.setStatus(AccountReceiptStatus.HARD_BLOCK.getValue());
			}
			else
			{
				header = businessAccountHelper.getErrorMsgHeader(exceptionKey);
			}
			if(StringMethods.isEmptyString(header))
			{
				header = DEFAULT_MSG_HEADER;
			}
			List<ErrorInfo> errorList = getErrorList(origin, header, errorMessage);
			errorResp.setErrors(errorList);
			Logger.debug(errorResp, MBAppUtils.class);
			Logger.info("Error response populated: " + errorResp, MBAppUtils.class);
		}
		private ErrorResp createErrorResp(String origin, Integer exceptionKey, String serviceName,HttpServletRequest httpRequest) {
			ErrorResp errorResp = new ErrorResp(mbAppHelper.populateResponseHeader(serviceName, httpRequest));

			String errorMessage = MBAppUtils.getMessage(origin, exceptionKey);	
			Logger.info("Error response populated: 1 :  " + errorMessage, this.getClass());
			if(exceptionKey == BusinessException.BUS_ACCOUNT_VERIFY_BLACK_LISTED_IPS_FAILED)
			{
				Object[] values = {IBankParams.getOrigin(origin).getName()};
                errorMessage = MessageFormat.format(errorMessage.replaceAll("'", "''"), values);
			}
			Logger.info("Error response populated: 2 :  " + errorMessage, this.getClass());
			if (errorMessage==null){
				errorMessage = String.valueOf(exceptionKey);			
			}
			Logger.info("Error response populated: 3 :  " + errorMessage, this.getClass());
			String header = businessAccountHelper.getHardStopMsgHeader(exceptionKey);
			if(!StringMethods.isEmptyString(header))
			{
				errorResp.setStatus(AccountReceiptStatus.HARD_BLOCK.getValue());
			}
			else
			{
				header = businessAccountHelper.getErrorMsgHeader(exceptionKey);
			}
			if(StringMethods.isEmptyString(header) && !(exceptionKey == BusinessException.BUSINESS_ACCOUNT_ACN_SVC_UNAVAILABLE)){
				header = DEFAULT_MSG_HEADER;
			}else if(StringMethods.isEmptyString(header) && exceptionKey == BusinessException.BUSINESS_ACCOUNT_ACN_SVC_UNAVAILABLE){
				header = String.valueOf(exceptionKey);
			}
			List<ErrorInfo> errorList = getErrorList(origin, header, errorMessage);
			errorResp.setErrors(errorList);
			Logger.debug(errorResp, MBAppUtils.class);
			Logger.info("Error response populated: " + errorResp, MBAppUtils.class);
			return errorResp;
		}
		private List<ErrorInfo> getErrorList(String origin, String header, String message) {
			List<ErrorInfo> errorList = new ArrayList<ErrorInfo>();
			ErrorInfo eachError = new ErrorInfo();
			eachError.setCode(header);			
			eachError.setMessage(message);
			errorList.add(eachError);
			return errorList;
		}
		
		private void populateErrorHeader(ErrorResp errorResp)
		{
			if(errorResp !=null && errorResp.getErrors() != null)
			{
				for(ErrorInfo errorInfo:errorResp.getErrors())
				{
					if(errorInfo != null)
					{
						errorInfo.setCode(DEFAULT_MSG_HEADER);
					}
				}
			}
		}
		
		
	private DigitalSecLogggerVO getDigitalSecLogggerVO(IBankCommonData commonData, String action) {
		DigitalSecLogggerVO digitalSecLoggerVO = new DigitalSecLogggerVO();
		digitalSecLoggerVO.setTranName(DigitalSecLogger.CRS_HARDPROMPT);
		digitalSecLoggerVO.setAction(action);
		digitalSecLoggerVO.setCommonLogData(mbAppHelper.getCommonLogData(commonData));
		digitalSecLoggerVO.setUserAgent(commonData.getUserAgent());
		return digitalSecLoggerVO;
	}

	private void fraudLogForCRS(BusinessAccountDetails sessionBusinessAccountDetails,DigitalSecLogggerVO digitalSecLoggerVO) {
		try {
			au.com.stgeorge.ibank.evcrs.businessobject.valueobject.CRSInfo crsInfo = sessionBusinessAccountDetails.getCrsInfo();
			if(crsInfo != null)
			{
				digitalSecLoggerVO.setValues(crsInfo.toDigitalSecurityLog(null, null, DigitalSecLogger.COUNTRY, DigitalSecLogger.TIN));
				businessAccountService.updaeCrsFrodLog(sessionBusinessAccountDetails, digitalSecLoggerVO);
			}
		} catch (Exception e) {
			Logger.error("frodLogForCRS update exception", e, getClass());
		}
	}
	
	private boolean removedCRSTile(MobileSession mbSession, IBankCommonData commonData)
	{
		try
		{
			MessageSearch messageSearch=mbSession.getSplashInfoMsg();
			if ( messageSearch != null )
			{
				crsService.updateMsgDeleteStatus(messageSearch,commonData);
				mbSession.removeSplashInfoMsg();
				return true;
			}
		}
		catch (Exception e)
		{
			Logger.error("removeCRSTile failed", e, getClass());
		}
		return false;
	}
	
	@RequestMapping(value= "verifyAcn" , method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public IMBResp verifyAcn(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, @RequestBody final BusinessAccountAcnReq req)
	{				
		
		Logger.debug("In BusinessAccountController.verifyAcn " + httpServletRequest.getContentType() + " "
				+ httpServletRequest.getRemoteAddr() + "  " + httpServletResponse.getCharacterEncoding() + httpServletResponse.getLocale() +
				" True IP >> " + httpServletRequest.getHeader(IBankParams.trueClientIP()), this.getClass());

		perfLogger.startAllLogs();
		String logName = MBAppUtils.getLogName(httpServletRequest);
		perfLogger.startLog(logName);
		MobileSession mbSession = null;
		BusinessAccountDetails businessAccountDetails = null;
		String ninGcis = null;

		try
		{
			mbSession = mbAppHelper.getMobileSession(httpServletRequest);	
			
			businessAccountDetails=mbSession.getBusinessAccountDetails();
			
			validateRequestHeader( req.getHeader(), httpServletRequest );

			ErrorResp errorResp = validate(req, httpServletRequest);
			if (errorResp != null && errorResp.getErrors() != null && errorResp.getErrors().size() > 0)
			{
				populateErrorHeader(errorResp);
				return errorResp;
			}

			IBankCommonData ibankCommonData=mbAppHelper.populateIBankCommonData(mbSession,httpServletRequest);
			
			/**/
			boolean crossSell = true;
			
			//Check transaction account required (cross sell)
			if(PRODUCT_TYPE_SAVING_BUSINESS.equalsIgnoreCase(req.getProductType()))
			{
				if(req.isActivate())
				{
					boolean hasTransAcc = businessAccountService.isTransactionAccountExists(ibankCommonData, ninGcis);
					if(hasTransAcc)
					{
						crossSell = false;
					}
				}
			}
			/**/
			
			String requestId = null;
			
			try{
				requestId = businessAccountService.searchAcn(req.getAcnNumber(),ibankCommonData);
			}catch(BusinessException be){
				if(be.getKey() == BusinessException.BUSINESS_ACCOUNT_ACN_SVC_UNAVAILABLE){
					businessAccountDetails.setVerifyACNFailed(true);
					businessAccountDetails.setRequestId(requestId);
					businessAccountDetails.setAcn(req.getAcnNumber());
					businessAccountDetails.setAcnRetrieveCount(0);
					businessAccountDetails.setHasCrossSell(crossSell);
					mbSession.setBusinessAccountDetails(businessAccountDetails);
				}
				throw be;
			}	
			
			businessAccountDetails.setVerifyACNFailed(false);
			businessAccountDetails.setRequestId(requestId);
			businessAccountDetails.setAcn(req.getAcnNumber());
			businessAccountDetails.setAcnRetrieveCount(0);
			businessAccountDetails.setHasCrossSell(crossSell);
			mbSession.setBusinessAccountDetails(businessAccountDetails);
			
			
			BusinessAccountResp serviceResponse = new BusinessAccountResp();
			serviceResponse.setCrossSell(crossSell);
			serviceResponse.setPollingDelay( IBankParams.acnVerifyTimeout(mbSession.getOrigin()));
			RespHeader headerResp = populateResponseHeader(req.getHeader().getServiceName(), mbSession );
			serviceResponse.setHeader(headerResp);
			
			return serviceResponse;
		} catch (BusinessException e)
		{
			Logger.error("Exception Inside BusinessAccountController.verifyAcn: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			return createErrorResp(mbSession.getOrigin() , e.getKey(), MBAppConstants.BUSINESS_ACCOUNT_SERVICE, httpServletRequest);
		} catch (Exception e)
		{	
			Logger.error("Exception Inside BusinessAccountController.verifyAcn: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			BusinessException exp = new BusinessException(BusinessException.BUSINESS_ACCOUNT_SVC_UNAVAILABLE);
			return createErrorResp(mbSession.getOrigin(), exp.getKey(), MBAppConstants.BUSINESS_ACCOUNT_SERVICE, httpServletRequest);
		} finally
		{
			perfLogger.endLog(logName);
			perfLogger.endAllLogs();
		}			
	}
	
/*	@RequestMapping(value= "submitAcnFull" , method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody*/
	private void submitAcnFull(BusinessAccountDetails businessAccountDetails, MobileSession mbSession, IBankCommonData ibankCommonData) throws BusinessException
	{								
		Logger.debug("In BusinessAccountController.submitAcnFull ", this.getClass());
		try
		{			
			businessAccountDetails.setAcnRetrieveCount(0);
			
			String requestId = businessAccountService.searchAcnFull(businessAccountDetails.getAcn(),ibankCommonData);
			
			businessAccountDetails.setRequestId(requestId);
			
			mbSession.setBusinessAccountDetails(businessAccountDetails);
		} catch (BusinessException e) { 
			Logger.error("BusinessException Inside BusinessAccountController.submitAcnFull: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			throw e;
		} catch (Exception e) {	
			Logger.error("Exception Inside BusinessAccountController.submitAcnFull: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			BusinessException exp = new BusinessException(BusinessException.BUSINESS_ACCOUNT_SVC_UNAVAILABLE);
			throw exp;
		}		
	}
	
	@RequestMapping(value= "retrieveAcn" , method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public IMBResp retrieveAcn(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse,
			@RequestBody final EmptyReq req)
	{	
		Logger.debug("In BusinessAccountController.retrieveAcn " + httpServletRequest.getContentType() + " "
				+ httpServletRequest.getRemoteAddr() + "  " + httpServletResponse.getCharacterEncoding() + httpServletResponse.getLocale() +
				" True IP >> " + httpServletRequest.getHeader(IBankParams.trueClientIP()), this.getClass());

		perfLogger.startAllLogs();
		String logName = MBAppUtils.getLogName(httpServletRequest);
		perfLogger.startLog(logName);
		MobileSession mbSession = null;
		BusinessAccountDetails businessAccountDetails = null;
		try
		{
			mbSession = mbAppHelper.getMobileSession(httpServletRequest);	
			
			validateRequestHeader( req.getHeader(), httpServletRequest );

			ErrorResp errorResp = validate(req, httpServletRequest);
			if (errorResp != null && errorResp.getErrors() != null && errorResp.getErrors().size() > 0)
			{
				populateErrorHeader(errorResp);
				return errorResp;
			}
			
			businessAccountDetails = mbSession.getBusinessAccountDetails();
			
			IBankCommonData ibankCommonData=mbAppHelper.populateIBankCommonData(mbSession,httpServletRequest);
			businessAccountDetails.setAcnRetrieveCount(businessAccountDetails.getAcnRetrieveCount() + 1);
			
			BusinessAccountDetails accountDetails = null;
			if(!businessAccountDetails.isVerifyACNFailed()){
				try{
					accountDetails = businessAccountService.verifyAcn(businessAccountDetails.getAcn(),businessAccountDetails ,ibankCommonData);
				}catch(BusinessException be){
					if(be.getKey() == BusinessException.BUSINESS_ACCOUNT_ACN_SVC_UNAVAILABLE){
						businessAccountDetails.setVerifyACNFailed(true);
						throw be;
					}else if(be.getKey() == BusinessException.BUSINESS_ACCOUNT_INACTIVE_ACN || be.getKey() == BusinessException.BUSINESS_ACCOUNT_NOT_VALID_ACN){
						throw be;
					}else{
						businessAccountDetails.setVerifyACNFailed(true);
						Logger.error("BusinessException occurred while retrieving Basic ACN Search result ", be, this.getClass());
					}
				}
			}
			
			BusinessAccountResp serviceResponse = null;
			if(accountDetails != null) {				
				serviceResponse = new BusinessAccountResp();;
				serviceResponse.setPollingStatus("S");
				businessAccountDetails.setAcn(accountDetails.getAcn());
				submitAcnFull(businessAccountDetails,mbSession,ibankCommonData);
		    } else if(businessAccountDetails.isVerifyACNFailed()){
		    	serviceResponse  = new BusinessAccountResp();
		    	serviceResponse.setPollingStatus("S");
		    	mbSession.setBusinessAccountDetails(businessAccountDetails);
		    } else {
		    	serviceResponse  = new BusinessAccountResp();
		    	serviceResponse.setPollingStatus("P");
		    	mbSession.setBusinessAccountDetails(businessAccountDetails);
		    }
			RespHeader headerResp = populateResponseHeader(req.getHeader().getServiceName(), mbSession );
			serviceResponse.setHeader(headerResp);
			
			return serviceResponse;
		} catch (BusinessException e) {
			Logger.error("Exception Inside BusinessAccountController.retrieveAcn: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			return createErrorResp(mbSession.getOrigin() , e.getKey(), MBAppConstants.BUSINESS_ACCOUNT_SERVICE, httpServletRequest);
		} catch (Exception e) {	
			Logger.error("Exception Inside BusinessAccountController.retrieveAcn: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			BusinessException exp = new BusinessException(BusinessException.BUSINESS_ACCOUNT_SVC_UNAVAILABLE);
			return createErrorResp(mbSession.getOrigin(), exp.getKey(), MBAppConstants.BUSINESS_ACCOUNT_SERVICE, httpServletRequest);
		} finally {
			perfLogger.endLog(logName);
			perfLogger.endAllLogs();
		}			
	}
	
	@RequestMapping(value= "freedomSoleDirector" , method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public IMBResp openFreedomAccountSoleDirector(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse,
			@RequestBody final BusinessAccountOpenReq req)
	{	
		Logger.debug("In BusinessAccountController.openFreedomAccountSoleDir " + httpServletRequest.getContentType() + " "
				+ httpServletRequest.getRemoteAddr() + "  " + httpServletResponse.getCharacterEncoding() + httpServletResponse.getLocale() +
				" True IP >> " + httpServletRequest.getHeader(IBankParams.trueClientIP()), this.getClass());

		perfLogger.startAllLogs();
		String logName = MBAppUtils.getLogName(httpServletRequest);
		perfLogger.startLog(logName);
		MobileSession mbSession = null;
		BusinessAccountDetails businessAccountDetails = null;
		IBankCommonData ibankCommonData = null;
		
		try
		{
			mbSession = mbAppHelper.getMobileSession(httpServletRequest);	
			ibankCommonData=mbAppHelper.populateIBankCommonData(mbSession,httpServletRequest);
			validateRequestHeader( req.getHeader(), httpServletRequest );

			ErrorResp errorResp = validate(req, httpServletRequest);
			if (errorResp != null && errorResp.getErrors() != null && errorResp.getErrors().size() > 0)
			{
				populateErrorHeader(errorResp);
				return errorResp;
			}
			
			businessAccountDetails = mbSession.getBusinessAccountDetails();
			businessAccountDetails.setIsActivate(req.isActivate());// Getting from request and setting in businessAccountDetails which will update in session as well
			
		
			//Call svc 327 for Advanced ACN search with polling from services side if basic search did'nt fail
			
			BusinessAccountDetails accountDetails = null;
			if(!businessAccountDetails.isVerifyACNFailed() && !businessAccountDetails.isVerifyACNFullDone()){
				accountDetails = businessAccountService.verifyAcnFullWithPolling(businessAccountDetails.getAcn(),businessAccountDetails.getRequestId(),ibankCommonData);
				if(accountDetails!=null){
					/*accountDetails.setProductType(businessAccountDetails.getProductType());
					accountDetails.setHasCrossSell(businessAccountDetails.getHasCrossSell());
					accountDetails.setIsActivate(businessAccountDetails.getIsActivate());
					accountDetails.setIndustryList(businessAccountDetails.getIndustryList());*/
					businessAccountDetails.setVerifyACNFullDone(true);
					businessAccountDetails.setTradingNames(accountDetails.getTradingNames());
					businessAccountDetails.setAcnEntityName(accountDetails.getAcnEntityName());
					businessAccountDetails.setDateOfRegistration(accountDetails.getDateOfRegistration());
					/*mbSession.setBusinessAccountDetails(accountDetails);*/
				}else{
					businessAccountDetails.setVerifyACNFailed(true);
				}
			}
			
		    if(businessAccountDetails.isVerifyACNFullDone() && !businessAccountDetails.getIsActivate()){//only in case of unlock, we have to validate the company name
		    		businessAccountService.isValidCompanyName(req.getCompanyName(), businessAccountDetails.getTradingNames());
		    }
				
		   return openAccountSoleDirector(httpServletRequest, httpServletResponse, req, mbSession, PRODUCT_TYPE_FREEDOM_BUSINESS);
				
		} catch (BusinessException e) {
			Logger.error("Exception Inside BusinessAccountController.openFreedomAccountSoleDir: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			if(e.getKey() == BusinessException.BUS_ACCOUNT_ACN_FAILED || e.getKey() == BusinessException.BUS_ACCOUNT_VERIFY_BLACK_LISTED_IPS_FAILED )
            {
				businessAccountService.closeInvitationLead(ibankCommonData , businessAccountDetails.getLeadId());
            }
			return createErrorResp(mbSession.getOrigin() , e.getKey(), MBAppConstants.BUSINESS_ACCOUNT_SERVICE, httpServletRequest);
		} catch (Exception e) {	
			Logger.error("Exception Inside BusinessAccountController.openFreedomAccountSoleDir: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			BusinessException exp = new BusinessException(BusinessException.BUSINESS_ACCOUNT_SVC_UNAVAILABLE);
			return createErrorResp(mbSession.getOrigin(), exp.getKey(), MBAppConstants.BUSINESS_ACCOUNT_SERVICE, httpServletRequest);
		} finally {
			perfLogger.endLog(logName);
			perfLogger.endAllLogs();
		}			
	}
	
	private IMBResp openAccountSoleDirector(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse,BusinessAccountOpenReq req, MobileSession mbSession, String productType) throws Exception{
		validateRequestHeader( req.getHeader(), httpServletRequest );

		ErrorResp errorResp = validate(req, httpServletRequest);
		if (errorResp != null && errorResp.getErrors() != null && errorResp.getErrors().size() > 0)
		{
			populateErrorHeader(errorResp);
			return errorResp;
		}

		IBankCommonData ibankCommonData=mbAppHelper.populateIBankCommonData(mbSession,httpServletRequest);
		
		BusinessAccountDetails businessAccountDetails = mbSession.getBusinessAccountDetails();
		/*if(!productType.equalsIgnoreCase(businessAccountDetails.getProductType()))
		{
			Logger.error("BusinessAccountController.openAccountSoleDirector: productType doesn't match with the one in Session ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", this.getClass());
			throw new BusinessException(BusinessException.SYSTEM_UNAVILABLE);
		}*/
		
		//Check if Business Name is required for Opening account for Sole Director
/*		if(!StringMethods.isEmptyString(req.getBusinessName()))
		{
			String businessRegName = getBusinessNameFromCode(req.getBusinessName(), businessAccountDetails.getBusinessNames());
			businessAccountDetails.setBusinessRegisteredName(businessRegName);
		}else if(StringMethods.isEmptyString(req.getAbnNumber()))
		{
			businessAccountDetails.setBusinessRegisteredName(BusinessAccountService.DEFAULT_TRADING_NAME);
		}*/
		
		if(!businessAccountDetails.getIsActivate())//Unlock
		{
			validateIndustryTypeCode(req.getIndustryType(), businessAccountDetails.getIndustryList());
			businessAccountDetails.setIndustryTypeCode(req.getIndustryType());
			businessAccountDetails.setBusinessRegisteredName(req.getCompanyName());

			if(req.getCompanyAddress() != null){
				Address address = contactDetailHelper.getAddress(req.getCompanyAddress());
				businessAccountService.validateAddress(null, null, address);
				businessAccountDetails.setCompanyAddress(address);
			}
			
			businessAccountDetails.setCompanyAddressId(req.getCompanyAddressId());
			
			if(req.getCompanyAddress() == null && StringMethods.isEmptyString(req.getCompanyAddressId())){
				 businessAccountDetails.setCompanyAddress(ibankCommonData.getCustomer().getContactDetail().getResidentialAddress() );
			}

			if(req.isSameAsBusinessAddress()){
				businessAccountDetails.setBusinessAddress(businessAccountDetails.getCompanyAddress());
				businessAccountDetails.setBusinessAddressId(businessAccountDetails.getCompanyAddressId());
			}else{
				if(req.getBusinessAddress() != null){
					Address address = contactDetailHelper.getAddress(req.getBusinessAddress());
					businessAccountService.validateAddress(null, null, address);
					businessAccountDetails.setBusinessAddress(address);
				}
				businessAccountDetails.setBusinessAddressId(req.getBusinessAddressId());
				if(req.getBusinessAddress() == null && StringMethods.isEmptyString(req.getBusinessAddressId())){
					 businessAccountDetails.setBusinessAddress(ibankCommonData.getCustomer().getContactDetail().getResidentialAddress() );
				}
			}
			
			businessAccountDetails.setStateOfRegistration(req.getStateOfRegistration());
			businessAccountDetails.setSourceOfFunds(req.getSourceOfFunds());
			businessAccountDetails.setSourceOfWealth(req.getSourceOfWealth());
			
			businessAccountDetails.setAdditionalSourceOfFund(req.getAdditionalSourceOfFund());
			businessAccountDetails.setAdditionalSourceOfWealth(req.getAdditionalSourceOfWealth());
			
/*			List<String> tradingName = new ArrayList<String>();
			tradingName.add(req.getTradingName());
			
			businessAccountDetails.setTradingNames(tradingName);*/
			businessAccountDetails.setBusinessTradingName(req.getTradingName());
			businessAccountDetails.setAbn(req.getCompanyABN());

			CRSInfo crsInfo = req.getCrsInfo();
			if(crsInfo != null)
			{
				List<EVForeignCountryDetail> evForeignCountryDtls = IBankParams.getForeignTINDetails();
				crsHelper.validateCRSData(crsInfo, evForeignCountryDtls);
				
				au.com.stgeorge.ibank.evcrs.businessobject.valueobject.CRSInfo crsInfoVo=crsHelper.populateCRSInfoVo(crsInfo,evForeignCountryDtls);
				businessAccountDetails.setCrsInfo(crsInfoVo);
			}
		}
		
		if(PRODUCT_TYPE_FREEDOM_BUSINESS.equalsIgnoreCase(productType))
		{
			businessAccountDetails.setHasCrossSell(req.isCrossSell());
		}
		
/*		if(StringMethods.isEmptyString(req.getAcnNumber()))
		{
			businessAccountDetails.setAcn(null);
			businessAccountDetails.setAcnName(null);
		}*/
		
		//TODO Moved to backlog only if we need to do blacklist check for individual
		//businessAccountDetails.setCorrelationId(mbSession.getEVThreatMatrixSessionID());
		
		if(businessAccountDetails.getIsActivate())
		{
			List<BusinessAccountDetails> businessAccountDetailsList = mbSession.getBusinessAccountDetailsList();
			for(BusinessAccountDetails account: businessAccountDetailsList){
				if(businessAccountDetails.getAcn().equals(account.getAcn())){
					businessAccountDetails.setNinGcisNumber(account.getNinGcisNumber());
					businessAccountDetails.setBusinessRegisteredName(account.getAcnName());
					Logger.debug("Setting NinGcis in BusinessAccountDetails: " +businessAccountDetails.getNinGcisNumber(), getClass());
					break;
				}
			}
			
			if(PRODUCT_TYPE_FREEDOM_BUSINESS.equalsIgnoreCase(productType))
			{
				businessAccountDetails.setAccountType(BusinessAccountDetails.BusAccountEnum.FREEDOM.name());
				businessAccountService.activateBusinessFreedomAccountSoleDirector(businessAccountDetails, ibankCommonData);
			}else{
				businessAccountDetails.setAccountType(BusinessAccountDetails.BusAccountEnum.SAVING.name());
				businessAccountService.activateBusinessSavingAccountSoleDirector(businessAccountDetails, ibankCommonData);
			}
			
		}else{
			DigitalSecLogggerVO digitalSecLogggerVO = getDigitalSecLogggerVO(ibankCommonData, DigitalSecLogger.CRS_MAINTENANCE_ACTION_ADD);
			try{				
				if(PRODUCT_TYPE_FREEDOM_BUSINESS.equalsIgnoreCase(productType))
				{
					businessAccountDetails.setAccountType(BusinessAccountDetails.BusAccountEnum.FREEDOM.name());
					businessAccountService.unlockBusinessFreedomAccountSoleDirector(businessAccountDetails, ibankCommonData, req.getCompanyName());
				}else{
					businessAccountDetails.setAccountType(BusinessAccountDetails.BusAccountEnum.SAVING.name());
					businessAccountService.unlockBusinessSaverAccountSoleDirector(businessAccountDetails, ibankCommonData, req.getCompanyName());
				}
			}finally{
				fraudLogForCRS(businessAccountDetails, digitalSecLogggerVO);
			}
		}		
		
		businessAccountDetails.setAccountRetriveCount(0);
		
		RespHeader headerResp = populateResponseHeader(req.getHeader().getServiceName(), mbSession );
		BusinessAccountResp accountOpenResp = new BusinessAccountResp();
		accountOpenResp.setPollingDelay(IBankParams.businessAccountRetrieveTimeout(mbSession.getOrigin()));

		accountOpenResp.setHeader(headerResp);

		return accountOpenResp;
	}
	
	
	@RequestMapping(value= "savingsSoleDirector" , method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public IMBResp openSavingsAccountSoleDirector(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse,
			@RequestBody final BusinessAccountOpenReq req)
	{	
		Logger.debug("In BusinessAccountController.openSavingsAccountSoleDirector " + httpServletRequest.getContentType() + " "
				+ httpServletRequest.getRemoteAddr() + "  " + httpServletResponse.getCharacterEncoding() + httpServletResponse.getLocale() +
				" True IP >> " + httpServletRequest.getHeader(IBankParams.trueClientIP()), this.getClass());

		perfLogger.startAllLogs();
		String logName = MBAppUtils.getLogName(httpServletRequest);
		perfLogger.startLog(logName);
		MobileSession mbSession = null;
		BusinessAccountDetails businessAccountDetails = null;
		IBankCommonData ibankCommonData = null;
		
		try
		{
			mbSession = mbAppHelper.getMobileSession(httpServletRequest);
			ibankCommonData=mbAppHelper.populateIBankCommonData(mbSession,httpServletRequest);
			businessAccountDetails = mbSession.getBusinessAccountDetails();
			validateRequestHeader( req.getHeader(), httpServletRequest );

			ErrorResp errorResp = validate(req, httpServletRequest);
			if (errorResp != null && errorResp.getErrors() != null && errorResp.getErrors().size() > 0)
			{
				populateErrorHeader(errorResp);
				return errorResp;
			}
			
			businessAccountDetails.setIsActivate(req.isActivate());// Getting from request and setting in businessAccountDetails which will update in session as well
			
			
			//Call svc 327 for Advanced ACN search with polling from services side
			
			BusinessAccountDetails accountDetails = null;
			if(!businessAccountDetails.isVerifyACNFailed() && !businessAccountDetails.isVerifyACNFullDone()){
				accountDetails = businessAccountService.verifyAcnFullWithPolling(businessAccountDetails.getAcn(),businessAccountDetails.getRequestId(),ibankCommonData);
				if(accountDetails!=null){
				/*	accountDetails.setProductType(businessAccountDetails.getProductType());
					accountDetails.setHasCrossSell(businessAccountDetails.getHasCrossSell());
					accountDetails.setIsActivate(businessAccountDetails.getIsActivate());
					accountDetails.setIndustryList(businessAccountDetails.getIndustryList());*/
					businessAccountDetails.setVerifyACNFullDone(true);
					businessAccountDetails.setTradingNames(accountDetails.getTradingNames());
					businessAccountDetails.setAcnEntityName(accountDetails.getAcnEntityName());
					businessAccountDetails.setDateOfRegistration(accountDetails.getDateOfRegistration());
					
					/*mbSession.setBusinessAccountDetails(accountDetails);*/
				}else{
					businessAccountDetails.setVerifyACNFailed(true);
				}
			}
			
		    if(businessAccountDetails.isVerifyACNFullDone() && !businessAccountDetails.getIsActivate()){//only in case of unlock, we have to validate the company name
		    		businessAccountService.isValidCompanyName(req.getCompanyName(), businessAccountDetails.getTradingNames());
		    }
				
			return openAccountSoleDirector(httpServletRequest, httpServletResponse, req, mbSession, PRODUCT_TYPE_SAVING_BUSINESS);
			
		} catch (BusinessException e) {
			Logger.error("Exception Inside BusinessAccountController.openSavingsAccountSoleDirector: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			if(e.getKey() == BusinessException.BUS_ACCOUNT_ACN_FAILED || e.getKey() == BusinessException.BUS_ACCOUNT_VERIFY_BLACK_LISTED_IPS_FAILED )
            {
				businessAccountService.closeInvitationLead(ibankCommonData , businessAccountDetails.getLeadId());
            }
			
			return createErrorResp(mbSession.getOrigin() , e.getKey(), MBAppConstants.BUSINESS_ACCOUNT_SERVICE, httpServletRequest);
		} catch (Exception e) {	
			Logger.error("Exception Inside BusinessAccountController.openSavingsAccountSoleDirector: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			BusinessException exp = new BusinessException(BusinessException.BUSINESS_ACCOUNT_SVC_UNAVAILABLE);
			return createErrorResp(mbSession.getOrigin(), exp.getKey(), MBAppConstants.BUSINESS_ACCOUNT_SERVICE, httpServletRequest);
		} finally {
			perfLogger.endLog(logName);
			perfLogger.endAllLogs();
		}			
	}
}