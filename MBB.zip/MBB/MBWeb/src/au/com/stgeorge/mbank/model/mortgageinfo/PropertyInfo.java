package au.com.stgeorge.mbank.model.mortgageinfo;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_NULL)
public class PropertyInfo implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 3606641281641479093L;
	private int index;//Long
	private String customerEstimatedValue;
	private String propertyInsightValue;
    private Boolean useAsSecInd;
	private Boolean keepPropertyInd;
	private Boolean mortgagedInd;
	private Boolean shareOwnershipInd;
	private Boolean rentalIncomeInd;
	private Boolean refinanceInd;
	private String propertyType;
	private AddressInfo address;
	private PropertyInsightValuationInfo propertyInsightValuationInfo;
	private Integer bedrooms;
	private Integer bathrooms;
	private Integer carparks; 
	private Boolean primaryResidenceInd;
	
	
	public Boolean getPrimaryResidenceInd() {
		return primaryResidenceInd;
	}
	public void setPrimaryResidenceInd(Boolean primaryResidenceInd) {
		this.primaryResidenceInd = primaryResidenceInd;
	}
	public PropertyInsightValuationInfo getPropertyInsightValuationInfo() {
		return propertyInsightValuationInfo;
	}
	public void setPropertyInsightValuationInfo(
			PropertyInsightValuationInfo propertyInsightValuationInfo) {
		this.propertyInsightValuationInfo = propertyInsightValuationInfo;
	}

	public String getCustomerEstimatedValue() {
		return customerEstimatedValue;
	}
	public void setCustomerEstimatedValue(String customerEstimatedValue) {
		this.customerEstimatedValue = customerEstimatedValue;
	}
	public AddressInfo getAddress() {
		return address;
	}
	public void setAddress(AddressInfo address) {
		this.address = address;
	}
	public int getIndex() {
		return index;
	}
	public void setIndex(int index) {
		this.index = index;
	}
	public String getPropertyInsightValue() {
		return propertyInsightValue;
	}
	public void setPropertyInsightValue(String propertyInsightValue) {
		this.propertyInsightValue = propertyInsightValue;
	}
	public Boolean getUseAsSecInd() {
		return useAsSecInd;
	}
	public void setUseAsSecInd(Boolean useAsSecInd) {
		this.useAsSecInd = useAsSecInd;
	}
	public Boolean getKeepPropertyInd() {
		return keepPropertyInd;
	}
	public void setKeepPropertyInd(Boolean keepPropertyInd) {
		this.keepPropertyInd = keepPropertyInd;
	}
	public Boolean getMortgagedInd() {
		return mortgagedInd;
	}
	public void setMortgagedInd(Boolean mortgagedInd) {
		this.mortgagedInd = mortgagedInd;
	}
	public Boolean getShareOwnershipInd() {
		return shareOwnershipInd;
	}
	public void setShareOwnershipInd(Boolean shareOwnershipInd) {
		this.shareOwnershipInd = shareOwnershipInd;
	}
	public Boolean getRentalIncomeInd() {
		return rentalIncomeInd;
	}
	public void setRentalIncomeInd(Boolean rentalIncomeInd) {
		this.rentalIncomeInd = rentalIncomeInd;
	}
	public Boolean getRefinanceInd() {
		return refinanceInd;
	}
	public void setRefinanceInd(Boolean refinanceInd) {
		this.refinanceInd = refinanceInd;
	}
	public String getPropertyType() {
		return propertyType;
	}
	public void setPropertyType(String propertyType) {
		this.propertyType = propertyType;
	}
	public Integer getBedrooms() {
		return bedrooms;
	}
	public void setBedrooms(Integer bedrooms) {
		this.bedrooms = bedrooms;
	}
	public Integer getBathrooms() {
		return bathrooms;
	}
	public void setBathrooms(Integer bathrooms) {
		this.bathrooms = bathrooms;
	}
	public Integer getCarparks() {
		return carparks;
	}
	public void setCarparks(Integer carparks) {
		this.carparks = carparks;
	}
	
	
}
