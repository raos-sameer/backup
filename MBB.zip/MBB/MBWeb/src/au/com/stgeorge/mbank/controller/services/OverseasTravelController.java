package au.com.stgeorge.mbank.controller.services;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang.builder.ReflectionToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;

import au.com.stgeorge.framework.common.logging.Logger;
import au.com.stgeorge.ibank.businessobject.BusinessException;
import au.com.stgeorge.ibank.businessobject.OverseasTravelService;
import au.com.stgeorge.ibank.businessobject.ResourceException;
import au.com.stgeorge.ibank.valueobject.Customer;
import au.com.stgeorge.ibank.valueobject.sessionInfo.OverseasTravelSessionVO;
import au.com.stgeorge.ibank.valueobject.transfer.IBankCommonData;
import au.com.stgeorge.mbank.controller.IMBController;
import au.com.stgeorge.mbank.controller.SecureCodeHelper;
import au.com.stgeorge.mbank.controller.customer.LogonHelper;
import au.com.stgeorge.mbank.model.common.IMBReq;
import au.com.stgeorge.mbank.model.common.IMBResp;
import au.com.stgeorge.mbank.model.common.ReqHeader;
import au.com.stgeorge.mbank.model.common.RespHeader;
import au.com.stgeorge.mbank.model.request.SecureCodeReq;
import au.com.stgeorge.mbank.model.request.services.OverseasTravelReq;
import au.com.stgeorge.mbank.model.response.ErrorResp;
import au.com.stgeorge.mbank.session.MobileSession;
import au.com.stgeorge.mbank.session.MobileSessionImpl;
import au.com.stgeorge.mbank.util.MBAppHelper;
import au.com.stgeorge.mbank.util.MBAppUtils;
import au.com.stgeorge.mbank.util.MBAppValidator;
import au.com.stgeorge.mbank.util.ServiceConstants;
import au.com.stgeorge.perflogger.PerformanceLogger;

/**
 * Overseas Travel service
 * 
 * @author C38854
 * 
 */
@Controller
@RequestMapping("/overseas")
public class OverseasTravelController implements IMBController {

	@Autowired
	private OverseasTravelHelper helper;

	@Autowired
	private OverseasTravelService overseasTravelService;

	@Autowired
	private SecureCodeHelper secureCodeHelper;
	
	@Autowired
	private MBAppValidator mbAppValidator;
	
	@Autowired
	private MBAppHelper mbAppHelper;
	
	@Autowired
	private LogonHelper logonHelper;
	

	/**
	 * Request overseas travel operation
	 * 
	 * @param httpRequest
	 * @param request
	 * @return
	 */
	@RequestMapping(method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE, value = "travel")
	@ResponseBody
	public IMBResp travel(HttpServletRequest httpRequest, @RequestBody final OverseasTravelReq request) {
		Logger.debug("OverseasTravelHelper - request(). Request: " + request, this.getClass());
		String logName = startPerformanceLog(httpRequest);
		MobileSession mobileSession = new MobileSessionImpl();

		try {
			mobileSession.getSessionContext(httpRequest);
			validateRequestHeader(request.getHeader(), httpRequest);
			ErrorResp errorResponse = validate(request, httpRequest);
			if (errorResponse.hasErrors())
				return errorResponse;
			
			Customer customer = mobileSession.getCustomer();
			
			if (  "N".equalsIgnoreCase(logonHelper.isCustomerSecCodeExempted(customer)) )
			{
				if ( !ServiceConstants.OVERSEAS_TRAVEL_REQUEST_SERVICE.equalsIgnoreCase(mobileSession.getSecureCodeVerifiedTranName()) )
				{
					Logger.error("Secure not verified. Session Sec Code Vale : "+ mobileSession.getSecureCodeVerifiedTranName(), this.getClass());
					throw new ResourceException(ResourceException.SYSTEM_ERROR, "Secure not verified. Session Sec Code Vale : "+ mobileSession.getSecureCodeVerifiedTranName());
				}
			}
			
			OverseasTravelSessionVO travelRequest = helper.populateTravelRequest(
					populateResponseHeader(ServiceConstants.OVERSEAS_TRAVEL_REQUEST_SERVICE, mobileSession), request);
			overseasTravelService.updateTravelDetails(travelRequest, new MBAppHelper().populateIBankCommonData(mobileSession, httpRequest));
			mobileSession.setSecureCodeVerifiedTranName(" ");
			return helper.populateSuccessResponse(populateResponseHeader(ServiceConstants.OVERSEAS_TRAVEL_REQUEST_SERVICE, mobileSession));
		} catch (BusinessException e) {
			Logger.info("BusinessException in OverseasTravelController - request() - [key: " + e.getKey() + "] : GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			if (e.getKey() == BusinessException.ADMIN_MI_BLOCK_NOTE_FAILED) {
				return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.SYSTEM_UNAVILABLE,
						ServiceConstants.OVERSEAS_TRAVEL_REQUEST_SERVICE, httpRequest);
			}
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), e, ServiceConstants.OVERSEAS_TRAVEL_REQUEST_SERVICE, httpRequest);
		} catch (ResourceException e) {
			Logger.error("ResourceException in OverseasTravelController - request() - [key: " + e.getKey() + "] : GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.SYSTEM_UNAVILABLE,
					ServiceConstants.OVERSEAS_TRAVEL_REQUEST_SERVICE, httpRequest);
		} catch (Exception e) {
			Logger.error("Exception OverseasTravelController - request(): GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), ResourceException.MOBILE_NON_FINANCIAL_FATAL_ERR,
					ServiceConstants.OVERSEAS_TRAVEL_REQUEST_SERVICE, httpRequest);
		} finally {
			endPerformanceLog(logName);
		}
	}

	/**
	 * Request security code service operation
	 * 
	 * @param request
	 * @return
	 */
	@RequestMapping(method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE, value = "reqsecurecode")
	@ResponseBody
	public IMBResp reqSecureCode(HttpServletRequest httpRequest, @RequestBody final SecureCodeReq request) {
		Logger.debug("OverseasTravelController - reqSecureCode(). Request: " + request, this.getClass());
		String logName = startPerformanceLog(httpRequest);
		MobileSession mobileSession = new MobileSessionImpl();

		try {
			mobileSession.getSessionContext(httpRequest);
			IBankCommonData commonData = new MBAppHelper().populateIBankCommonData(mobileSession, httpRequest);

			validateRequestHeader(request.getHeader(), httpRequest);
			ErrorResp errorResponse = validate(request, httpRequest);// validate json
			if (errorResponse.hasErrors())
				return errorResponse;

			if (ServiceConstants.OVERSEAS_TRAVEL_2FA_TRAN_CODE != request.getTranType()) {
				return MBAppUtils.createInvalid2FATransactionTypeResponse(ServiceConstants.OVERSEAS_TRAVEL_SECURE_CODE_SERVICE);
			}

			return secureCodeHelper.reqSecureCode(commonData, mobileSession, mobileSession.getTransaction(), null, request,
					ServiceConstants.OVERSEAS_TRAVEL_SECURE_CODE_SERVICE, httpRequest);
		} catch (ResourceException e) {
			Logger.error("ResourceException in OverseasTravelController - reqSecureCode() - [key: " + e.getKey() + "] : GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			mobileSession.removeSecureCodeDetails();
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.SYSTEM_UNAVILABLE, ServiceConstants.OVERSEAS_TRAVEL_SECURE_CODE_SERVICE, httpRequest);
		} catch (Exception e) {
			Logger.error("Exception OverseasTravelController - reqSecureCode(): GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			mobileSession.removeSecureCodeDetails();
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.GENERIC_ERROR,
					ServiceConstants.OVERSEAS_TRAVEL_SECURE_CODE_SERVICE, httpRequest);
		} finally {
			endPerformanceLog(logName);
		}
	}

	/**
	 * Secure transfer service operation
	 * 
	 * @param request
	 * @return
	 */
	@RequestMapping(method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE, value = "verifysecurecode")
	@ResponseBody
	public IMBResp verify(HttpServletRequest httpRequest, @RequestBody final SecureCodeReq request) {
		Logger.debug("OverseasTravelController - transferSecure(). Request: " + request, this.getClass());
		String logName = startPerformanceLog(httpRequest);
		MobileSession mobileSession = new MobileSessionImpl();

		try {
			mobileSession.getSessionContext(httpRequest);
			IBankCommonData commonData = new MBAppHelper().populateIBankCommonData(mobileSession, httpRequest);

			validateRequestHeader(request.getHeader(), httpRequest);
			ErrorResp errorResponse = validate(request, httpRequest);// validate json
			if (errorResponse.hasErrors())
				return errorResponse;

			if (ServiceConstants.OVERSEAS_TRAVEL_2FA_TRAN_CODE != request.getTranType())
				return MBAppUtils.createInvalid2FATransactionTypeResponse(ServiceConstants.OVERSEAS_TRAVEL_VERIFY_SECURE_SERVICE);
			errorResponse = secureCodeHelper.verifySecureCode(commonData, mobileSession, new OverseasTravelSessionVO(), request,
					ServiceConstants.OVERSEAS_TRAVEL_VERIFY_SECURE_SERVICE, httpRequest);
			if (errorResponse.hasErrors())
				return errorResponse;
			
			mobileSession.setSecureCodeVerifiedTranName(ServiceConstants.OVERSEAS_TRAVEL_REQUEST_SERVICE);
			
			return helper.populateSuccessResponse(populateResponseHeader(ServiceConstants.OVERSEAS_TRAVEL_VERIFY_SECURE_SERVICE, mobileSession));
		} catch (ResourceException e) {
			Logger.info("Exception - [key: " + e.getKey() + "] : GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			mobileSession.removeSecureCodeDetails();
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.SYSTEM_UNAVILABLE, ServiceConstants.OVERSEAS_TRAVEL_VERIFY_SECURE_SERVICE, httpRequest);
		} catch (Exception e) {
			Logger.error("Exception OverseasTravelController - reqSecureCode(): GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			mobileSession.removeSecureCodeDetails();
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.GENERIC_ERROR,
					ServiceConstants.OVERSEAS_TRAVEL_VERIFY_SECURE_SERVICE, httpRequest);
		} finally {
			endPerformanceLog(logName);
		}
	}

	public ErrorResp validate(IMBReq serviceRequest, HttpServletRequest request) {
		Logger.info("Service request object - " + ReflectionToStringBuilder.toString(serviceRequest), this.getClass());
		return mbAppValidator.validate(serviceRequest, request);
	}

	public void validateRequestHeader(ReqHeader headerReq, HttpServletRequest request) throws BusinessException {
		Logger.debug("Request header validation: " + ReflectionToStringBuilder.toString(headerReq, ToStringStyle.MULTI_LINE_STYLE), this.getClass());
		mbAppValidator.validateRequestHeader(headerReq, request);
	}

	/**
	 * Response for invalid body request
	 * 
	 * @return
	 */
	@ExceptionHandler( { org.springframework.http.converter.HttpMessageNotReadableException.class })
	@ResponseStatus(org.springframework.http.HttpStatus.OK)
	@ResponseBody
	public IMBResp resolveException() {
		return MBAppUtils.createInvalidMessageBodyResponse(ServiceConstants.OVERSEAS_TRAVEL_REQUEST_SERVICE);
	}

	
	public RespHeader populateResponseHeader(String serviceName, MobileSession mobSession) {
		return mbAppHelper.populateResponseHeader(serviceName, mobSession);
	}

	
	@Autowired
	private PerformanceLogger perfLogger;
	
	private String startPerformanceLog(HttpServletRequest httpRequest){
		perfLogger.startAllLogs();
		String logName = MBAppUtils.getLogName(httpRequest);
		perfLogger.startLog(logName);
		return logName;
	}
	
	private void endPerformanceLog(String logName){
		perfLogger.endLog(logName);
		perfLogger.endAllLogs();
	}
}
