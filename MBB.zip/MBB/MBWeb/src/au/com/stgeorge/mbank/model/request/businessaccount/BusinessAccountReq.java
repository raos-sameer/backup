package au.com.stgeorge.mbank.model.request.businessaccount;

import au.com.stgeorge.mbank.model.common.IMBReq;
import au.com.stgeorge.mbank.model.common.ReqHeader;

public class BusinessAccountReq implements IMBReq{

	private String productType;
	
	private String customerType;
	
	private String industryType;
	
	private String occupationType;
	
	private ReqHeader header;
	
	private String leadId;
	
	public ReqHeader getHeader()
	{
		return header;
	}
	public void setHeader(ReqHeader header)
	{
		this.header = header;
	}
	public String getProductType() {
		return productType;
	}
	public void setProductType(String productType) {
		this.productType = productType;
	}
	public String getIndustryType() {
		return industryType;
	}
	public void setIndustryType(String industryType) {
		this.industryType = industryType;
	}
	public String getCustomerType() {
		return customerType;
	}
	public void setCustomerType(String customerType) {
		this.customerType = customerType;
	}
	public String getOccupationType() {
		return occupationType;
	}
	public void setOccupationType(String occupationType) {
		this.occupationType = occupationType;
	}
	public String getLeadId() {
		return leadId;
	}
	public void setLeadId(String leadId) {
		this.leadId = leadId;
	}
	
	
}
