/**
 * 
 */
package au.com.stgeorge.mbank.model.payments;

import java.util.Date;

import au.com.stgeorge.mbank.util.JsonDateSerializer;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;

/**
 * @author C50216
 *
 */
@JsonInclude(Include.NON_NULL)
public class TransferScheduleResp {	
		
	private int scheduleId;
	private String scheduleIdDisp;
	private String freq;		
	private Date nextPayDate;	
	private Date lastPayDate;	
	private Date firstPaymentDate;
	private long dueDaysCount;
	private Date createdOn;
	
	public int getScheduleId() {
		return scheduleId;
	}

	public void setScheduleId(int scheduleId) {
		this.scheduleId = scheduleId;
	}

	public String getScheduleIdDisp() {
		return scheduleIdDisp;
	}

	public void setScheduleIdDisp(String scheduleIdDisp) {
		this.scheduleIdDisp = scheduleIdDisp;
	}

	public String getFreq() {
		return freq;
	}

	public void setFreq(String freq) {
		this.freq = freq;
	}
	
	@JsonSerialize(using = JsonDateSerializer.class)
	@JsonInclude(Include.NON_NULL)
	public Date getNextPayDate() {
		return nextPayDate;
	}

	public void setNextPayDate(Date nextPayDate) {
		this.nextPayDate = nextPayDate;
	}
	
	@JsonSerialize(using = JsonDateSerializer.class)
	@JsonInclude(Include.NON_NULL)
	public Date getLastPayDate() {
		return lastPayDate;
	}

	public void setLastPayDate(Date lastPayDate) {
		this.lastPayDate = lastPayDate;
	}

	@JsonSerialize(using = JsonDateSerializer.class)
	@JsonInclude(Include.NON_NULL)
	public Date getFirstPaymentDate() {
		return firstPaymentDate;
	}

	public void setFirstPaymentDate(Date firstPaymentDate) {
		this.firstPaymentDate = firstPaymentDate;
	}

	public long getDueDaysCount() {
		return dueDaysCount;
	}

	public void setDueDaysCount(long dueDaysCount) {
		this.dueDaysCount = dueDaysCount;
	}

	@JsonSerialize(using = JsonDateSerializer.class)
	@JsonInclude(Include.NON_NULL)
	public Date getCreatedOn() {
		return createdOn;
	}

	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}	
}
