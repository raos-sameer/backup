package au.com.stgeorge.mbank.controller.offers;

import au.com.stgeorge.ibank.valueobject.Invitation;
import au.com.stgeorge.mbank.model.response.offers.AemRetentionResponse;

public class AemOfferHelper {

	/**
	 * This method will populate response for validateRetention method.
	 * 
	 * @param invitation
	 * @return AemRetentionResponse
	 */
	public AemRetentionResponse populateAemRetentionResponse(Invitation invitation ){
		AemRetentionResponse response = new AemRetentionResponse();
		
		response.setEligible(!invitation.isOfferApplied());
		
		return response;
	}
}
