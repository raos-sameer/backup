package au.com.stgeorge.mbank.model.request.payments;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

import org.apache.commons.lang.builder.ReflectionToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;
import org.hibernate.validator.constraints.Length;

/**
 * BPay Transfer request
 * 
 * @author C38854
 * 
 */
public class BPayTransferReq extends TransferReq {

	private static final long serialVersionUID = -1055600115110686978L;

	private static final String CUST_REF_NUMBER_PATTERN = "^[0-9, ,-]*$";

	@NotNull(message = "Please select a biller")
	private Integer toBillerIndex;

	@Pattern(regexp = CUST_REF_NUMBER_PATTERN, message = "{errors.billerCRN.pattern}")
	private String custRefNum;

	@Pattern(regexp = BLOCK_CHARS_PATTERN, message = "{errors.payerName.blockchar}")
	@Length(max = 26, message = "{errors.payerName.maxlength}")
	private String payerName;

	private String devicePrint;
	
	private String fromAccountNumber;	
	private String fromAccountNumberMasked;	
	private String toBillerCode;	
	
	public String getPayerName() {
		return payerName;
	}

	public Integer getToBillerIndex() {
		return toBillerIndex;
	}

	public String getCustRefNum() {
		return custRefNum;
	}

	@Override
	public String toString() {
		return ReflectionToStringBuilder.toString(this, ToStringStyle.MULTI_LINE_STYLE);
	}

	public String getDevicePrint() {
		return devicePrint;
	}

	public void setDevicePrint(String devicePrint) {
		this.devicePrint = devicePrint;
	}

	public String getFromAccountNumber() {
		return fromAccountNumber;
	}

	public void setFromAccountNumber(String fromAccountNumber) {
		this.fromAccountNumber = fromAccountNumber;
	}

	public String getFromAccountNumberMasked() {
		return fromAccountNumberMasked;
	}

	public void setFromAccountNumberMasked(String fromAccountNumberMasked) {
		this.fromAccountNumberMasked = fromAccountNumberMasked;
	}

	public String getToBillerCode() {
		return toBillerCode;
	}

	public void setToBillerCode(String toBillerCode) {
		this.toBillerCode = toBillerCode;
	}

}
