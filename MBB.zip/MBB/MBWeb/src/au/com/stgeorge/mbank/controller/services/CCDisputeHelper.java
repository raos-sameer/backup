package au.com.stgeorge.mbank.controller.services;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

import au.com.stgeorge.framework.common.exception.BaseException;
import au.com.stgeorge.framework.common.logging.Logger;
import au.com.stgeorge.ibank.businessobject.BusinessException;
import au.com.stgeorge.ibank.businessobject.CustomerMaintenanceService;
import au.com.stgeorge.ibank.businessobject.assembler.CreditCardChargeBackRequestVOAssemblerFactory;
import au.com.stgeorge.ibank.businessobject.impl.CardDisputeServiceImpl;
import au.com.stgeorge.ibank.common.cache.IBankParams;
import au.com.stgeorge.ibank.enumerated.CreditCardChargeBackDisputeReason;
import au.com.stgeorge.ibank.enumerated.CreditCardChargeBackRequestState;
import au.com.stgeorge.ibank.enumerated.CreditCardTransactionType;
import au.com.stgeorge.ibank.enumerated.CreditCardType;
import au.com.stgeorge.ibank.enumerated.PreferredContactMethod;
import au.com.stgeorge.ibank.service.valueobject.PhoneToken;
import au.com.stgeorge.ibank.valueobject.Account;
import au.com.stgeorge.ibank.valueobject.CreditCardChargeBackRequestVO;
import au.com.stgeorge.ibank.valueobject.CreditCardChargeBackTransactionVO;
import au.com.stgeorge.ibank.valueobject.Customer;
import au.com.stgeorge.ibank.valueobject.TransactionInfo;
import au.com.stgeorge.ibank.valueobject.transfer.IBankCommonData;
import au.com.stgeorge.mbank.model.common.IMBResp;
import au.com.stgeorge.mbank.model.common.RespHeader;
import au.com.stgeorge.mbank.model.request.services.CCDisputeReq;
import au.com.stgeorge.mbank.model.response.StatusResp;
import au.com.stgeorge.mbank.model.response.services.CCDisputeDetailResp;
import au.com.stgeorge.mbank.model.response.services.DebitCardResponse;
import au.com.stgeorge.mbank.model.response.services.PhoneTokenResp;
import au.com.stgeorge.mbank.session.MobileSession;
import au.com.stgeorge.security.util.StringMethods;
import au.com.stgeorge.ibank.util.StringUtil;
import au.com.stgeorge.wmqi.schema.common.LinkAccts;
import au.com.stgeorge.wmqi.schema.common.PlasticCardDetails;

/**
 * 
 * CC Dispute tnx helper
 * 
 * @author C38854
 * 
 */
@Service
public class CCDisputeHelper {

	/**
	 * Make CC Dispute details response
	 * 
	 * @param header
	 * @param helpDeskPhoneNumber
	 * @param disputeReasons
	 * @param cardIndexes
	 * @return
	 */
	protected IMBResp populateCCDisputeDetailsResponse(CardDisputeServiceImpl cardDisputeService,RespHeader header, String helpDeskPhoneNumber, String[] disputeReasons, Integer[] cardIndexes, Integer connectThreshold,Customer customer) {
		CCDisputeDetailResp response = new CCDisputeDetailResp(header);
		response.setCardIndexes(cardIndexes);
		response.setDisputeReasons(disputeReasons);
		response.setCcDisputeContact(helpDeskPhoneNumber);
		response.setConnectThreshold(connectThreshold);
		response.setDebitCards(getDebitCards(customer,cardDisputeService));
		Logger.info("Response: " + response, this.getClass());
		return response;
	}
	
	/**
	 * Make CC Dispute details response incorprating debit cards and their linked accounts
	 * 
	 * @param header
	 * @param helpDeskPhoneNumber
	 * @param disputeReasons
	 * @param cardIndexes
	 * @return
	 */
	protected IMBResp populateCCDisputeDetailsResponse(RespHeader header, String helpDeskPhoneNumber, String[] disputeReasons, Integer[] cardIndexes, Integer connectThreshold,Customer customer) {
		CCDisputeDetailResp response = new CCDisputeDetailResp(header);
		response.setCardIndexes(cardIndexes);
		response.setDisputeReasons(disputeReasons);
		response.setCcDisputeContact(helpDeskPhoneNumber);
		response.setConnectThreshold(connectThreshold);
		Logger.info("Response: " + response, this.getClass());
		return response;
	}
	

	/**
	 * Populate service request
	 * 
	 * @param request
	 * @param customer
	 * @param selectedAcct
	 * @param mobileSession
	 * @param ip
	 * @return
	 * @throws BaseException
	 */
	protected CreditCardChargeBackRequestVO createCreditCardChargeBackRequestVo(CCDisputeReq request, IBankCommonData commonData, Customer customer,
			Account selectedAcct, MobileSession mobileSession, String ip) throws BaseException {
		
		if (mobileSession.getTransactionHistory() == null || mobileSession.getTransactionHistory().getTransactions() == null) 
			throw new BusinessException(BusinessException.TRANSACTION_HISTORY_NO_RESULTS);

		
		List<TransactionInfo> txnHistoryList = (List<TransactionInfo>) mobileSession.getTransactionHistory().getTransactions();
		List<CreditCardChargeBackTransactionVO> txnList = new ArrayList<CreditCardChargeBackTransactionVO>();

		
			TransactionInfo transactionInfo = (TransactionInfo) txnHistoryList.get(request.getDisputeTran().getTranIndex() - 1);
			
			CreditCardChargeBackDisputeReason ccChargeBackDisputeReason = null;
			if (request.getDisputeTran().getReason().contains("Service") || request.getDisputeTran().getReason().contains("Merchandise")) {
				ccChargeBackDisputeReason = CreditCardChargeBackDisputeReason.SERVICE_OR_MERCHANDISE_NOT_RECEIVED;
			} else if (request.getDisputeTran().getReason().contains("Others")) {
				ccChargeBackDisputeReason = CreditCardChargeBackDisputeReason.OTHER;
			} else {
				ccChargeBackDisputeReason = CreditCardChargeBackDisputeReason.fromString(request.getDisputeTran().getReason());
			}
			CreditCardTransactionType transType = transactionInfo.getAmount().signum() == 1 ? CreditCardTransactionType.CR
					: CreditCardTransactionType.DR;
			String desription = StringMethods.isEmptyString(transactionInfo.getDescription1()) ? transactionInfo.getDescription2() : transactionInfo
					.getDescription1();
			CreditCardChargeBackTransactionVO newCcVo = new CreditCardChargeBackTransactionVO(null, null, transactionInfo.getDate(), desription,
					transactionInfo.getAmount(), transType,// TransactionType
					ccChargeBackDisputeReason,// Disputed Reason
					(request.getDisputeTran().getAdditionalInfo()==null)? "" : request.getDisputeTran().getAdditionalInfo());// Additonal Info
			txnList.add(newCcVo);
		
		String customerName = customer.getFirstName() + " " + customer.getLastName();
		if (customerName.length() > 24)
			customerName = customerName.substring(0, 24);

		String emailAddr = null;
		if (customer.getContactDetail() != null)
			emailAddr = customer.getContactDetail().getEmail();

		PreferredContactMethod preferredContactNumber = null;
		if (StringMethods.isEmptyString(request.getPrefContact())) {
			preferredContactNumber = PreferredContactMethod.NONE;
		} else {
			preferredContactNumber = PreferredContactMethod.fromString(request.getPrefContact());
		}

		CreditCardChargeBackRequestVO ccChargeBackRequestVO = CreditCardChargeBackRequestVOAssemblerFactory.getInstance()
				.createCreditCardChargeBackRequestVO(CreditCardChargeBackRequestState.NEW, customer.getGcis(), selectedAcct.getBrand(),
						selectedAcct.getAccountId(), selectedAcct.getAssociatedAlias(), customerName, request.getCardName(),
						CreditCardType.fromString(CreditCardType.fromLogoCodeStringVP(selectedAcct.getAccountId().getGroupCode()).stringValue()),
						preferredContactNumber, emailAddr, (request.getSendEmail() != null) ? request.getSendEmail() : false, customer.getGcis(),
						txnList.toArray(new CreditCardChargeBackTransactionVO[txnList.size()]), mobileSession.getSessionID(), ip);
		ccChargeBackRequestVO.setGdwOrigin(commonData.getGdwOrigin());
		
		return ccChargeBackRequestVO;
	}


	/**
	 * Populate cc dispute response
	 * 
	 * @param header
	 * @param status
	 * @return
	 */
	protected IMBResp populateCCDisputeResponse(RespHeader header, Integer status) {
		StatusResp response = new StatusResp(header);
		response.setStatus(status);
		Logger.info("Response: " + response, this.getClass());
		return response;
	}
	
	/**
	 * Populate the response for GDW entry for CC Transaction Desc google Search. 
	 * @param header
	 * @param status
	 * @return
	 */
	protected IMBResp populateSearchCCTransactionDescResponse(RespHeader header, Integer status) {
		StatusResp response = new StatusResp(header);
		response.setStatus(status);
		Logger.info("Response: " + response, this.getClass());
		return response;
	}
	
	/**
	 * Populate the response for Phone Token
	 * @param header
	 * @param status
	 * @return
	 */
	protected IMBResp populatePhoneTokenResponse(RespHeader header, PhoneToken phoneToken) {
		PhoneTokenResp response = new PhoneTokenResp(header);
		response.setContactCentreStatus(phoneToken.getContactCentreStatus());
		response.setPhoneNumber(phoneToken.getPhoneNumber());
		response.setToken(phoneToken.getToken());
		Logger.info("Response: " + response, this.getClass());
		return response;
	}
	
	/**
	 * Get all debit Cards and their linked accounts for card dispute
	 * 
	 * */
	
	public List<DebitCardResponse> getDebitCards(Customer customer,CardDisputeServiceImpl cardDisputeService){
		
		
		List<DebitCardResponse> debitCards = new ArrayList<DebitCardResponse>();
		List<Account> accountDDAList = customer.getAccounts();
		//PlasticCardDetails[] details =CustomerMaintenanceService.getPlasticCardList(customer.getGcis(), false);
		
		List<PlasticCardDetails> details = cardDisputeService.getValidPlasticCardDetailsForDispute(customer.getGcis());
		int index=0;
		for(PlasticCardDetails plasticCard:   details){
			
			
			
			DebitCardResponse debitCard = new DebitCardResponse();
			debitCard.setAccountName(plasticCard.getCardName());
			debitCard.setAccountNum(plasticCard.getCardNum());
			if(IBankParams.isSwitchOn(IBankParams.CARD_NUM_MASK_SWITCH)) {
				debitCard.setAccountNumDisp(StringUtil.formatCardNumber(plasticCard.getCardNum()));
			}
			else {
	            debitCard.setAccountNumDisp(StringUtil.formatDDAAccountNumber(plasticCard.getCardNum()));
			}
			LinkAccts[] linkedAccts =  plasticCard.getLinkAccts();
			List<Integer> accountsList = new ArrayList<Integer>();
			 index=0;
			 
				Logger.debug("CCDisputeHelper:::getDebitCards()Card Name=="+plasticCard.getCardName(),this.getClass());
			 
			for(LinkAccts linkedAccount:linkedAccts){
				
				
			for(Account account:accountDDAList ){
				if(linkedAccount!=null && linkedAccount.getAcct()!=null /*&& linkedAccount.getAcct().trim().length()>0 
						&&  linkedAccount.getAcct().trim().equalsIgnoreCase(account.getAccountId().getAccountNumber().trim())*/
						&& StringMethods.removeLeadingZero(linkedAccount.getAcct()).
						equalsIgnoreCase(StringMethods.removeLeadingZero(account.getAccountId().getAccountNumber()))){
					
					Logger.debug("CCDisputeHelper:::getDebitCards()Match found Linked Account=="+account.getAccountId().getAccountNumber()+"--index=="+ String.valueOf(index),this.getClass());
					accountsList.add(account.getIndex());
					break;
				}
				
			}
			}
			if(accountsList.size()>0){
				debitCard.setLinkedAcctIndexes(accountsList);
				debitCards.add(debitCard);
			}
			
			
			
		}
		
		
		
		
	return debitCards;
}

	
}
