package au.com.stgeorge.mbank.model.request.offers;


import javax.validation.constraints.NotNull;

import au.com.stgeorge.ibank.businessobject.BusinessException;
import au.com.stgeorge.mbank.model.common.IMBReq;
import au.com.stgeorge.mbank.model.common.ReqHeader;

public class LeadDetailsReq implements IMBReq{
	
	private static final long serialVersionUID = 577366400103361583L;

	private ReqHeader header;	

	@NotNull(message = "" + BusinessException.WSVC_INVALID_INPUT_PARAM)
	private String leadId; 	
	
	public ReqHeader getHeader()
	{
		return header;
	}
	public void setHeader(ReqHeader header)
	{
		this.header = header;
	}
	public String getLeadId() {
		return leadId;
	}
	public void setLeadId(String leadId) {
		this.leadId = leadId;
	}						
}
