package au.com.stgeorge.mbank.model.request.customer.ev;

import java.util.ArrayList;

public class CustInfo {
	
	private String otherName;
	private String empTtypeCode;
	private String occupationCode;
	private ArrayList<String> sourceOfWealth;
	private ArrayList<String> sourceOfFunds;
	
	public String getOtherName() {
		return otherName;
	}
	public void setOtherName(String otherName) {
		this.otherName = otherName;
	}
	public String getEmpTtypeCode() {
		return empTtypeCode;
	}
	public void setEmpTtypeCode(String empTtypeCode) {
		this.empTtypeCode = empTtypeCode;
	}
	public String getOccupationCode() {
		return occupationCode;
	}
	public void setOccupationCode(String occupationCode) {
		this.occupationCode = occupationCode;
	}
	public ArrayList<String> getSourceOfWealth() {
		return sourceOfWealth;
	}
	public void setSourceOfWealth(ArrayList<String> sourceOfWealth) {
		this.sourceOfWealth = sourceOfWealth;
	}
	public ArrayList<String> getSourceOfFunds() {
		return sourceOfFunds;
	}
	public void setSourceOfFunds(ArrayList<String> sourceOfFunds) {
		this.sourceOfFunds = sourceOfFunds;
	}
}
