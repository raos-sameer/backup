package au.com.stgeorge.mbank.model.request.newaccount.cpp;

import java.io.Serializable;

import au.com.stgeorge.mbank.model.common.IMBReq;
import au.com.stgeorge.mbank.model.common.ReqHeader;

public class TDGetRatesReq implements IMBReq, Serializable {

	private static final long serialVersionUID = 1L;
	
	private ReqHeader header;
    private String tdaAmount;    
	private Integer tdaTerm;
	private String selSourceAcct;
	private String tdaInterestPaid;
	private Integer renewalOption;
	private String renewalAmount;
	private String actIndx;
	private Boolean isRenew;
	
	public ReqHeader getHeader() {
		return header;
	}
	public void setHeader(ReqHeader header) {
		this.header = header;
	}
	public String getTdaAmount() {
		return tdaAmount;
	}
	public void setTdaAmount(String tdaAmount) {
		this.tdaAmount = tdaAmount;
	}
	public Integer getTdaTerm() {
		return tdaTerm;
	}
	public void setTdaTerm(Integer tdaTerm) {
		this.tdaTerm = tdaTerm;
	}
	public String getSelSourceAcct() {
		return selSourceAcct;
	}
	public void setSelSourceAcct(String selSourceAcct) {
		this.selSourceAcct = selSourceAcct;
	}
	public String getTdaInterestPaid() {
		return tdaInterestPaid;
	}
	public void setTdaInterestPaid(String tdaInterestPaid) {
		this.tdaInterestPaid = tdaInterestPaid;
	}
	public Integer getRenewalOption() {
		return renewalOption;
	}
	public void setRenewalOption(Integer renewalOption) {
		this.renewalOption = renewalOption;
	}
	public String getRenewalAmount() {
		return renewalAmount;
	}
	public void setRenewalAmount(String renewalAmount) {
		this.renewalAmount = renewalAmount;
	}
	public String getActIndx() {
		return actIndx;
	}
	public void setActIndx(String actIndx) {
		this.actIndx = actIndx;
	}
	public Boolean getIsRenew() {
		return isRenew;
	}
	public void setIsRenew(Boolean isRenew) {
		this.isRenew = isRenew;
	}
		
}
