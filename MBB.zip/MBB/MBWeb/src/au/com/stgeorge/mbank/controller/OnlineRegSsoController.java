package au.com.stgeorge.mbank.controller;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.AbstractController;

import au.com.stgeorge.framework.common.logging.Logger;
import au.com.stgeorge.framework.common.model.User;
import au.com.stgeorge.ibank.businessobject.BusinessException;
import au.com.stgeorge.ibank.businessobject.PreferencesService;
import au.com.stgeorge.ibank.businessobject.ResourceException;
import au.com.stgeorge.ibank.businessobject.SystemInformation;
import au.com.stgeorge.ibank.businessobject.onlinereg.OnlineRegistrationService;
import au.com.stgeorge.ibank.common.cache.IBankParams;
import au.com.stgeorge.ibank.onlinereg.valueobject.OnlineRegistrationDetails;
import au.com.stgeorge.ibank.valueobject.database.OriginsVO;
import au.com.stgeorge.ibank.valueobject.transfer.IBankCommonData;
import au.com.stgeorge.mbank.controller.customer.LogonHelper;
import au.com.stgeorge.mbank.session.IGenericSession;
import au.com.stgeorge.mbank.session.MobileSession;
import au.com.stgeorge.mbank.session.MobileSessionImpl;
import au.com.stgeorge.mbank.util.MBAppConstants;
import au.com.stgeorge.mbank.util.MBAppHelper;

public class OnlineRegSsoController extends AbstractController{
	
	private static final String PAGE_NAME = "Index";
	private static final String ERROR_VIEW = "404";
	private static final String NUM_KEYBOARD_TYPE = "NumKeyBoardType";
	private static final String NUM_KEYBOARD_PATTERN_TYPE = "NumKeyBoardTypePattern";	
	private static final String SYS_VERSION = "SysVersion";
	private static final String ORIGIN_NAME = "OriginName";
	private static final String HELP_DESK_NO = "HelpDeskNo";
	private static final String REQ_LOAD_CORDOVA = "LoadCordova";
	private static final String REQ_DASHBOARD = "DASHBOARD";   
	
	
	@Autowired
	private LogonHelper logonHelper;
	
	@Autowired
	private SystemInformation systemInformation;
	
    @Autowired
    private OnlineRegistrationService onlineRegistrationService;
	
	@Override
	protected ModelAndView handleRequestInternal(HttpServletRequest request,HttpServletResponse response) throws Exception {
		
		ModelAndView model = null;
		String origin = "MSTG";
		String numKeyType = null;
		String numKeyTypePattern = null;
		MobileSession mobileSession = new MobileSessionImpl();
		
		try{
			Logger.info("Starting onlineregsso request" , this.getClass());
			origin = LogonHelper.resolveOrigin(request);
			Cookie cookie = getCookie(request, MBAppConstants.ONLINE_REG_SESS_CONSTANT);
			Logger.info("Cookie SRMBWebSrv=" + cookie == null ? "" : cookie.getValue() , this.getClass());
			mobileSession.getSessionContext(request);
			IBankCommonData commonData = new MBAppHelper().populateIBankCommonData(mobileSession, request);

			//invalidate SR_ session
			mobileSession.invalidateSession();
			deleteCookie(cookie, request, response);
			
			commonData.setOrigin(origin);
			//create new session
			createSession(commonData, request, response);
			PreferencesService.updateLastLogonDate(commonData.getUser());
			onlineRegistrationService.addSecurityLog(commonData);
			
			logonHelper.setWebReadyCookie(request, response , "0" );
			request.setAttribute(MainController.WEB_CONTEXT, logonHelper.getMBWebResourceContext());
			
			request.setAttribute(LogonHelper.ORIGIN, origin);
			request.setAttribute(MainController.PRELOAD_VALUE, 2);

			numKeyType =  logonHelper.getNumKeyBoardType(request);
			numKeyTypePattern =  logonHelper.getNumKeyBoardPattern(request);
			request.setAttribute(NUM_KEYBOARD_TYPE, numKeyType);
			request.setAttribute(NUM_KEYBOARD_PATTERN_TYPE, numKeyTypePattern);
			
			request.setAttribute(SYS_VERSION, this.systemInformation.getMB3PackageVersion());
			OriginsVO originVO = IBankParams.getOrigin(origin);
			request.setAttribute(ORIGIN_NAME, originVO.getName());

			String pwdResetUrl = IBankParams.getCodesData( originVO.getBankName(),IBankParams.EXTERNAL_LINKS,  MainController.PWD_URL).getMessage();	
			request.setAttribute(MainController.PWD_RESET_URL, pwdResetUrl);
			String canRetrievalUrl = IBankParams.getCodesData( originVO.getBankName(),IBankParams.EXTERNAL_LINKS,  MainController.CAN_RETRIEVAL_URL).getMessage();
			request.setAttribute(MainController.CAN_RETRIEVAL_URL, canRetrievalUrl);
			
			request.setAttribute(HELP_DESK_NO, originVO.getPhone());
			
			model = new ModelAndView(PAGE_NAME);

			request.setAttribute( MainController.REQ_ACTION_STR ,REQ_DASHBOARD );
			int loadCordova = logonHelper.loadCordova(request);
			request.setAttribute(REQ_LOAD_CORDOVA, String.valueOf(loadCordova));

			if(logonHelper.isCardlessTokenSupported(request)){
				request.setAttribute( MainController.GET_CASH_INDICATOR , "1");
			}
			
			return model;
		}
		
		catch ( Exception e) {
			origin = "MSTG";
			request.setAttribute(LogonHelper.ORIGIN, origin);
			model = new ModelAndView(ERROR_VIEW);
			Logger.error("Error in Main Controller " , e, this.getClass());
			return model;
		}

	}
	
	

	private void createSession(IBankCommonData commonData, HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse) throws BusinessException{
		IGenericSession genericSession = null ;
		User myUser = commonData.getUser(); 		
		myUser.setAttribute(LogonHelper.SMS_RESET_STATUS, new Boolean(false));
		myUser.setAttribute(IBankParams.USEROBJ_IPADDRESS, commonData.getIpAddress());
		commonData.setUser(myUser);

		try{
			genericSession = logonHelper.createCompassSession(myUser, commonData.getOrigin(), "WebSrv", httpServletRequest, "");			
			genericSession.setAttribute(MobileSessionImpl.ORIGIN_OBLECT, commonData.getOrigin());

			commonData.setSessionId(genericSession.getId());
			
			//add empty OnlineRegistrationDetails, this will be used on LogonContoroller to bypass validatetermsAndCondCookie()
			genericSession.setAttribute(MobileSessionImpl.ONLINE_REGISTRATION_DETAILS, new OnlineRegistrationDetails());
			Logger.info("***User-Agent: " +  "***SessionId: " + genericSession.getId(), this.getClass());
			httpServletResponse.setHeader("Set-Cookie", MBAppConstants.SMPL_SESS_CONSTANT + "=" + genericSession.getId()   + "; HttpOnly ; Secure "+ "; path=/"); //+ "; path=/mb"	19E3 added path /	
			
		} catch (Exception e){
			Logger.error("Exception Inside createSession() ", e, this.getClass());
			throw new BusinessException(BusinessException.SYSTEM_UNAVILABLE);
		} finally {
			if ( genericSession != null )
				genericSession.updateSession();				
		}		
	}
	
	
	private Cookie getCookie(HttpServletRequest request, String cookieName) throws ResourceException {
		Cookie[] cookies = request.getCookies();
		Cookie cookie = null;
		if (cookies != null){
			for (int i = 0; i < cookies.length; i++){
				if (cookies[i].getName().equals(cookieName)){
						cookie = cookies[i]; 
						Logger.info("Cookie " + cookieName + " found in the request. Value : " + cookie.getValue() , this.getClass());
					  break;
				}
			}
		}
		return cookie;
	}
	
	
	private void deleteCookie(Cookie cookieToBeDeleted, HttpServletRequest request, HttpServletResponse response) {
		if(cookieToBeDeleted != null){
			cookieToBeDeleted.setMaxAge(0);
			response.addCookie(cookieToBeDeleted);
		}
	}
	
	

}
