package au.com.stgeorge.mbank.model.request.mortgage;

import java.io.Serializable;

import javax.validation.constraints.Pattern;

import au.com.stgeorge.mbank.model.common.IMBReq;
import au.com.stgeorge.mbank.model.common.ReqHeader;

public class ChatEventReq implements IMBReq, Serializable {

	private static final long serialVersionUID = 5202245552218156634L;

	private ReqHeader header;
	
	@Pattern(regexp = "^[A-Z]*$", message = "{error.chatEvent.invalid}")
	private String chatEvent;
	
	private boolean isbackGroundCall;

	public ReqHeader getHeader() {
		return header;
	}

	public void setHeader(ReqHeader header) {
		this.header = header;
	}

	public String getChatEvent() {
		return chatEvent;
	}

	public void setChatEvent(String chatEvent) {
		this.chatEvent = chatEvent;
	}

	public boolean isIsbackGroundCall() {
		return isbackGroundCall;
	}

	public void setIsbackGroundCall(boolean isbackGroundCall) {
		this.isbackGroundCall = isbackGroundCall;
	}

}
