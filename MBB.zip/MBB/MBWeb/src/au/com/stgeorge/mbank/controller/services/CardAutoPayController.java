package au.com.stgeorge.mbank.controller.services;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang.builder.ReflectionToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import au.com.stgeorge.framework.common.logging.Logger;
import au.com.stgeorge.ibank.businessobject.BusinessException;
import au.com.stgeorge.ibank.businessobject.CardAutoPayService;
import au.com.stgeorge.ibank.businessobject.CustomerService;
import au.com.stgeorge.ibank.businessobject.HeartBeat;
import au.com.stgeorge.ibank.businessobject.ResourceException;
import au.com.stgeorge.ibank.businessobject.impl.CardServiceImpl;
import au.com.stgeorge.ibank.common.cache.IBankParams;
import au.com.stgeorge.ibank.common.log.IBankLog;
import au.com.stgeorge.ibank.valueobject.Account;
import au.com.stgeorge.ibank.valueobject.CreditCardAccount;
import au.com.stgeorge.ibank.valueobject.Customer;
import au.com.stgeorge.ibank.valueobject.Statistic;
import au.com.stgeorge.ibank.valueobject.database.CodesVO;
import au.com.stgeorge.ibank.valueobject.transfer.IBankCommonData;
import au.com.stgeorge.mbank.controller.IMBController;
import au.com.stgeorge.mbank.model.common.IMBReq;
import au.com.stgeorge.mbank.model.common.IMBResp;
import au.com.stgeorge.mbank.model.common.ReqHeader;
import au.com.stgeorge.mbank.model.common.RespHeader;
import au.com.stgeorge.mbank.model.request.services.CardAutoPayEligibleListReq;
import au.com.stgeorge.mbank.model.request.services.CardAutoPayLogStatsReq;
import au.com.stgeorge.mbank.model.response.ErrorResp;
import au.com.stgeorge.mbank.model.response.SuccessResp;
import au.com.stgeorge.mbank.model.response.services.CardAutoPayEligibleCardResp;
import au.com.stgeorge.mbank.model.response.services.CardAutoPayResp;
import au.com.stgeorge.mbank.session.MobileSession;
import au.com.stgeorge.mbank.session.MobileSessionImpl;
import au.com.stgeorge.mbank.util.MBAppHelper;
import au.com.stgeorge.mbank.util.MBAppUtils;
import au.com.stgeorge.mbank.util.MBAppValidator;
import au.com.stgeorge.mbank.util.ServiceConstants;
import au.com.stgeorge.perflogger.PerformanceLogger;

@Controller
@RequestMapping("/cardautopay")
public class CardAutoPayController implements IMBController {
	
	private static final String SOURCE_SERVICES = "Services";
	private static final String SOURCE_PAYMENTDEEPLINK = "PaymentDeeplink";
	private static final String SOURCE_ACCOUNTSERVICES = "AccountServices";
	
	@Autowired
	private PerformanceLogger perfLogger;
	
	@Autowired 
	private CardAutoPayService cardAutoPayService;
	
	@Autowired
	private MBAppValidator mbAppValidator;
	
	@Autowired
	private MBAppHelper mbAppHelper;
	
	/**
	 * Get eligible Credit Cards list for AutoPay	 * 
	 * @param httpRequest
	 * @param request
	 * @return
	 */
	@RequestMapping(method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE, value = "getEligibleCardList")
	@ResponseBody
	public IMBResp getEligibleCardList(HttpServletRequest httpRequest, @RequestBody final CardAutoPayEligibleListReq request){
		Logger.debug("CardAutoPayController - getEligibleCardList(). Request: " + request, this.getClass());
		String logName = startPerformanceLog(httpRequest);
		MobileSession mobileSession = new MobileSessionImpl();
		
		List<Account> crAccounts = new ArrayList<>();
		try {
			// Checking HearBeat for Vision Plus
			if(!HeartBeat.isApplicationAvailable(HeartBeat.VISION_PLUS)) {
				Logger.error("CardAutoPayController - getEligibleCardList() : Vision Plus is Not Available.", this.getClass());
				throw new Exception("Vision Plus is Not Available..");
			}
			mobileSession.getSessionContext(httpRequest);
			validateRequestHeader(request.getHeader(), httpRequest);
			ErrorResp errorResponse = validate(request, httpRequest);
			if (errorResponse.hasErrors())
				return errorResponse;
			IBankCommonData commonData = new MBAppHelper().populateIBankCommonData(mobileSession, httpRequest);
			
			crAccounts = getEligibleCreditCardsForAutoPay(commonData);
			
			if(crAccounts.size() > 0) {
				return populateAutoPayCardListResponse(commonData, populateResponseHeader(ServiceConstants.CARD_AUTO_PAY_SERVICE, mobileSession ), (List<Account>) crAccounts);
			}else {
				throw new BusinessException(BusinessException.CARD_AUTO_PAY_NO_ELIGIBLE_ACCOUNTS);
			}
		} catch (BusinessException e) {
			Logger.info("BusinessException in CardAutoPayController - getEligibleCardList():  - [key: " + e.getKey() + "] : GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), e, ServiceConstants.CARD_AUTO_PAY_SERVICE, httpRequest);
		} catch (ResourceException e) {
			Logger.error("ResourceException in CardAutoPayController - getEligibleCardList():  - [key: " + e.getKey() + "] : GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.SYSTEM_UNAVILABLE, ServiceConstants.CARD_AUTO_PAY_SERVICE, httpRequest);
		}catch (Exception e) {
			Logger.error("Exception CardAutoPayController - getEligibleCardList(): GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(),ResourceException.MOBILE_NON_FINANCIAL_FATAL_ERR, ServiceConstants.CARD_AUTO_PAY_SERVICE, httpRequest);
		} finally {
			endPerformanceLog(logName);
		}
	}
	
	public  List<Account> getEligibleCreditCardsForAutoPay(IBankCommonData commonData) throws BusinessException,ResourceException{
		ArrayList<Account> validCardList = new ArrayList<Account>();
		try{
			//Get the credit cards from customer
			Customer customer = commonData.getCustomer();
			if (customer == null)
			{
				customer = CustomerService.getCustomer(commonData);
			}
			List<Account> accountList = (List<Account>) customer.getAccounts();

			if (accountList != null){ 

				for (Account account : accountList) {
					try{
						if(Account.CRA.equalsIgnoreCase(account.getAccountId().getApplicationId())){
							boolean isAccountEligibleForAutoPay = cardAutoPayService.isCardAutoPayEligible(account);
							if(isAccountEligibleForAutoPay) {
								validCardList.add(account);
							}
						}
					}
					catch (Exception e) {
						IBankLog.logWRN("Unable to get valid credit card", e,CardServiceImpl.class);
					}
				}//end of outer for 			
			}
		}
		finally
		{
			perfLogger.endLog("getEligibleCreditCardsForAutoPay");
		}

		IBankLog.logTRC("valid cr cards:"+validCardList.size(),CardServiceImpl.class);
		return validCardList;
	}
	
	protected IMBResp populateAutoPayCardListResponse(IBankCommonData commonData, RespHeader header, List<Account> crAccounts) throws BusinessException {
		CardAutoPayEligibleCardResp response = new CardAutoPayEligibleCardResp(header);
		List<CardAutoPayResp> cardsResp = new ArrayList<CardAutoPayResp>();
		int index = 0;
		String cardArtUrl = null;
		
		for (Account crAccount : crAccounts) {
			CardAutoPayResp cardResp = new CardAutoPayResp();
			cardResp.setIndex(String.valueOf(crAccount.getIndex()));			
					
			if (crAccount instanceof CreditCardAccount) {			
				cardResp.setAccountNumDisp(new MBAppHelper().getFormattedAcctNumber(crAccount.getAccountId().getAccountNumber(), crAccount.getAccountId().getApplicationId(), crAccount.getAccountId().getBsb()));
				String cardLogo =crAccount.getCreditCardAdditionalInfo().getLogo();				
				
				cardArtUrl = IBankParams.getCardArtImageURL(commonData.getOrigin(), cardLogo);	    		
				if(cardArtUrl == null){
					cardArtUrl = IBankParams.getCardArtImageURL(commonData.getOrigin(),  "999");	    		
				}
				cardResp.setCardImageUrl(cardArtUrl);
				
				cardResp.setProductName(crAccount.getAlias());

			}					

			index++;
			cardsResp.add(cardResp);
		}

		response.setAutoPayCards(cardsResp);
		Logger.info("Response: " + response, this.getClass());
		return response;
	}

	private String startPerformanceLog(HttpServletRequest httpRequest){
		perfLogger.startAllLogs();
		String logName = MBAppUtils.getLogName(httpRequest);
		perfLogger.startLog(logName);
		return logName;
	}

	private void endPerformanceLog(String logName){
		perfLogger.endLog(logName);
		perfLogger.endAllLogs();
	}
	
	public ErrorResp validate(IMBReq serviceRequest, HttpServletRequest request) {
		Logger.info("Service request object - " + ReflectionToStringBuilder.toString(serviceRequest), this.getClass());
		return mbAppValidator.validate(serviceRequest, request);
	}

	public void validateRequestHeader(ReqHeader headerReq, HttpServletRequest request) throws BusinessException {
		Logger.debug("Request header validation: " + ReflectionToStringBuilder.toString(headerReq, ToStringStyle.MULTI_LINE_STYLE), this.getClass());
		mbAppValidator.validateRequestHeader(headerReq, request);
	}

	public RespHeader populateResponseHeader(String serviceName, MobileSession mobSession) {
		return mbAppHelper.populateResponseHeader(serviceName, mobSession);
	}
	
	@RequestMapping(method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE, value = "logStats")
	@ResponseBody
	public IMBResp logStats(HttpServletRequest httpRequest, @RequestBody final CardAutoPayLogStatsReq request){
		Logger.debug("CardAutoPayController - logStats(). Request: " + request, this.getClass());
		String logName = startPerformanceLog(httpRequest);
		MobileSession mobileSession = new MobileSessionImpl();
		Account selAccount = null;
		String accountNumberFrom = null;
		
		try {

			mobileSession.getSessionContext(httpRequest);
			validateRequestHeader(request.getHeader(), httpRequest);
			ErrorResp errorResponse = validate(request, httpRequest);
			if (errorResponse.hasErrors())
				return errorResponse;
			IBankCommonData commonData = new MBAppHelper().populateIBankCommonData(mobileSession, httpRequest);
		
			if(request.getFromAccountIndex() != null) {
				selAccount = commonData.getCustomer().getAccounts().get(request.getFromAccountIndex());
				if (selAccount == null || !Account.CRA.equals(selAccount.getAccountId().getApplicationId())) {
					throw new BusinessException(BusinessException.SYSTEM_UNAVILABLE);
				}
			}
			//GDW
			accountNumberFrom = (selAccount == null) ? null : selAccount.getAccountId().getAccountNumber();
			if (SOURCE_ACCOUNTSERVICES.equalsIgnoreCase(request.getSource())){
				cardAutoPayService.logStatistic(commonData, Statistic.CARD_AUTOPAY, SOURCE_ACCOUNTSERVICES, accountNumberFrom);
			} else if (SOURCE_SERVICES.equalsIgnoreCase(request.getSource())){
				cardAutoPayService.logStatistic(commonData, Statistic.CARD_AUTOPAY, SOURCE_SERVICES, accountNumberFrom);
			} else if (SOURCE_PAYMENTDEEPLINK.equalsIgnoreCase(request.getSource())){
				cardAutoPayService.logStatistic(commonData, Statistic.CARD_AUTOPAY, SOURCE_PAYMENTDEEPLINK, accountNumberFrom);
			}
			
			SuccessResp resp = new SuccessResp();
			resp.setHeader(populateResponseHeader(ServiceConstants.CARD_AUTO_LOG_STATS, mobileSession));
			resp.setIsSuccess(true);
			return resp;
			
		} catch (BusinessException e) {
			Logger.info("BusinessException in CardAutoPayController - logStats():  - [key: " + e.getKey() + "] : GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), e, ServiceConstants.CARD_AUTO_LOG_STATS, httpRequest);
		} catch (ResourceException e) {
			Logger.error("ResourceException in CardAutoPayController - logStats():  - [key: " + e.getKey() + "] : GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.SYSTEM_UNAVILABLE, ServiceConstants.CARD_AUTO_LOG_STATS, httpRequest);
		}catch (Exception e) {
			Logger.error("Exception CardAutoPayController - logStats(): GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(),ResourceException.MOBILE_NON_FINANCIAL_FATAL_ERR, ServiceConstants.CARD_AUTO_LOG_STATS, httpRequest);
		} finally {
			endPerformanceLog(logName);
		}
	}

}
