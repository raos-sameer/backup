package au.com.stgeorge.mbank.controller.mortgage;

import static au.com.stgeorge.ibank.common.cache.IBankParams.getCodesData;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang3.EnumUtils;

import au.com.stgeorge.ibank.businessobject.BusinessException;
import au.com.stgeorge.ibank.businessobject.ResourceException;
import au.com.stgeorge.ibank.businessobject.mortgage.MortgageService;
import au.com.stgeorge.ibank.common.cache.IBankParams;
import au.com.stgeorge.ibank.common.cache.MortgageParams;
import au.com.stgeorge.ibank.mortgage.util.MortgageUtil;
import au.com.stgeorge.ibank.util.CommonBusinessUtil;
import au.com.stgeorge.ibank.util.ServiceHelper;
import au.com.stgeorge.ibank.valueobject.LabelValueVO;
import au.com.stgeorge.ibank.valueobject.database.CodesVO;
import au.com.stgeorge.ibank.valueobject.database.OriginsVO;
import au.com.stgeorge.ibank.valueobject.mortgage.DMRefDataVO;
import au.com.stgeorge.mbank.controller.customer.LogonHelper;
import au.com.stgeorge.mbank.model.mortgage.MortgageAppParams;

public class MortgageRefDataHelper {
	
	private static final String CHAT = "chat/";
	private LogonHelper logonHelper;
	
	public LogonHelper getLogonHelper()
	{
		return logonHelper;
	}

	public void setLogonHelper(LogonHelper logonHelper)
	{
		this.logonHelper = logonHelper;
	}
	public MortgageAppParams getInitialRefData(String origin, HttpServletRequest httpRequest) throws ResourceException, BusinessException {
		MortgageAppParams appParams = new MortgageAppParams();
		MortgageParams mortgageParams = ServiceHelper.getBean("mortgageParams");

		appParams.setOrigin(origin);
		OriginsVO myOriginVO  = IBankParams.getOrigin(origin);
		if (  myOriginVO != null  )
		{
			appParams.setOriginName(myOriginVO.getName());
			appParams.setCanRetrievalURL(IBankParams.getCodesData( myOriginVO.getBankName(),IBankParams.EXTERNAL_LINKS,  IBankParams.CAN_RETRIEVAL_URL).getMessage());
			appParams.setResetPwdURL(IBankParams.getCodesData( myOriginVO.getBankName(),IBankParams.EXTERNAL_LINKS,  IBankParams.PWD_URL).getMessage());
			appParams.setUpdateContactUrl(IBankParams.getCodesData( myOriginVO.getBankName(),IBankParams.EXTERNAL_LINKS,  IBankParams.UPDATE_CONTACT_DETAILS_URL).getMessage());
		}		
		appParams.setQasUrl(IBankParams.getAddressTypeaheadURL(origin));
		
		appParams.setKeyboardAmountType(logonHelper.getKeyboardAmountType(httpRequest));
		appParams.setKeyboardNumType(logonHelper.getNumKeyBoardType(httpRequest));
		appParams.setSystemDate(new Date());
		
		//Set data from DMCodes
		appParams.setHelpDeskPhone(getHelpDeskContactNumber(origin));
		appParams.setMaxEntries(getMaxBucketEntries(origin));
		
		appParams.setStandardCCCNumber(getCCCNumber(origin)); // For Hard Stop 1
		appParams.setCallCentreNumber(getOriginNumber(origin)); //  For Hard Stop 2
		
		//Set Dtm Url
		String tempOrigin = mortgageParams.getBaseOriginCode(origin);
		LabelValueVO labelValueVO = mortgageParams.getDMCodesDataLabelValueVO(tempOrigin, MortgageUtil.MORTGAGE_DTM_URL, MortgageUtil.MORTGAGE_ADOBE_DTM_URL);
		if (labelValueVO != null && labelValueVO.getLabel() != null) {
				appParams.setDtmUrl(labelValueVO.getLabel());
		}
		LabelValueVO labelValueLPSiteVO = mortgageParams.getDMCodesDataLabelValueVO(MortgageUtil.ORIGIN_ALL, MortgageUtil.MORTGAGE_LP_CHAT, MortgageUtil.MORTGAGE_LP_SITEID);
		if (labelValueLPSiteVO != null && labelValueLPSiteVO.getLabel() != null) {
				appParams.setLpSiteId(labelValueLPSiteVO.getLabel());
		}
		LabelValueVO labelValueLPKeyVO = mortgageParams.getDMCodesDataLabelValueVO(MortgageUtil.ORIGIN_ALL, MortgageUtil.MORTGAGE_LP_CHAT, MortgageUtil.MORTGAGE_LP_APPKEY);
		if (labelValueLPKeyVO != null && labelValueLPKeyVO.getLabel() != null) {
				appParams.setLpAppKey(labelValueLPKeyVO.getLabel());
		}
		
		appParams.setRefiLVRIntOnly(getRefinanceInterestOnlyLVR());
		appParams.setRefiLVRPAndI(getRefinancePrincipalAndInterestLVR());		
		appParams.setMinBorrowAmt(getMinimumBorrowingAmount());
		appParams.setSpinnerText(getLoanOutcomeSpinnerTextList());
		
		//Set Reference data
		appParams.setTitle(getLabelValueVOList(mortgageParams.getTitleRefData(MortgageUtil.COMPASS_REFERENCE_DATA_STATUS_IN_USE)));
		appParams.setMaritalStatus(getLabelValueVOList(mortgageParams.getMaritalStatusRefData(MortgageUtil.COMPASS_REFERENCE_DATA_STATUS_IN_USE)));
		appParams.setMaritalStatusJoint(getLabelValueVOList(mortgageParams.getMaritalStatusJointRefData(MortgageUtil.COMPASS_REFERENCE_DATA_STATUS_IN_USE)));
		appParams.setFrequency(getLabelValueVOList(mortgageParams.getFrequencyRefData(MortgageUtil.COMPASS_REFERENCE_DATA_STATUS_IN_USE)));
		appParams.setExpenseFrequency(getLabelValueVOList(mortgageParams.getExpenseFrequencyRefData(MortgageUtil.COMPASS_REFERENCE_DATA_STATUS_IN_USE)));
		appParams.setRepaymentFrequency(getLabelValueVOList(mortgageParams.getRepaymentFrequencyRefData(MortgageUtil.COMPASS_REFERENCE_DATA_STATUS_IN_USE)));
		appParams.setEmploymentType(getLabelValueVOList(mortgageParams.getEmploymentTypeRefData(MortgageUtil.COMPASS_REFERENCE_DATA_STATUS_IN_USE)));
		appParams.setBankBrand(getLabelValueVOList(mortgageParams.getBankBrandRefData(MortgageUtil.COMPASS_REFERENCE_DATA_STATUS_IN_USE), origin));
		appParams.setBankBrandRefinance(getLabelValueVOList(mortgageParams.getBankBrandRefinanceRefData(MortgageUtil.COMPASS_REFERENCE_DATA_STATUS_IN_USE), origin));
		appParams.setCustomerSituation(getLabelValueVOList(mortgageParams.getCustomerSituationRefData(MortgageUtil.COMPASS_REFERENCE_DATA_STATUS_IN_USE)));
		appParams.setIncomeCategory(getLabelValueVOList(mortgageParams.getIncomeCategoryRefData(MortgageUtil.COMPASS_REFERENCE_DATA_STATUS_IN_USE)));
		appParams.setAssetCategory(getLabelValueVOList(mortgageParams.getAssetCategoryRefData(MortgageUtil.COMPASS_REFERENCE_DATA_STATUS_IN_USE)));
		appParams.setExpenseCategory(getLabelValueVOList(mortgageParams.getExpenseCategoryRefData(MortgageUtil.COMPASS_REFERENCE_DATA_STATUS_IN_USE)));
		appParams.setLiabilityCategory(getLabelValueVOList(mortgageParams.getLiabilityCategoryRefData(MortgageUtil.COMPASS_REFERENCE_DATA_STATUS_IN_USE)));
		//appParams.setIncomeType(getLabelValueVOList(mortgageParams.getIncomeTypeRefData(MortgageUtil.COMPASS_REFERENCE_DATA_STATUS_IN_USE)));
		appParams.setIncomeTypePension(getLabelValueVOList(mortgageParams.getIncomeTypePensionRefData(MortgageUtil.COMPASS_REFERENCE_DATA_STATUS_IN_USE)));
		appParams.setIncomeTypeOther(getLabelValueVOList(mortgageParams.getIncomeTypeOtherRefData(MortgageUtil.COMPASS_REFERENCE_DATA_STATUS_IN_USE)));
		appParams.setLiabilityType(getLabelValueVOList(mortgageParams.getLiabilityTypeRefData(MortgageUtil.COMPASS_REFERENCE_DATA_STATUS_IN_USE)));
		appParams.setLiabilityTypeOther(getLabelValueVOList(mortgageParams.getLiabilityTypeOtherRefData(MortgageUtil.COMPASS_REFERENCE_DATA_STATUS_IN_USE)));
		appParams.setExpenseType(getLabelValueVOList(mortgageParams.getExpenseTypeRefData(MortgageUtil.COMPASS_REFERENCE_DATA_STATUS_IN_USE)));
		appParams.setAssetType(getLabelValueVOList(mortgageParams.getAssetTypeRefData(MortgageUtil.COMPASS_REFERENCE_DATA_STATUS_IN_USE)));
		appParams.setRepaymentType(getLabelValueVOList(mortgageParams.getRepaymentTypeRefData(MortgageUtil.COMPASS_REFERENCE_DATA_STATUS_IN_USE)));
		appParams.setPropertyType(getLabelValueVOList(mortgageParams.getPropertyTypeRefData(MortgageUtil.COMPASS_REFERENCE_DATA_STATUS_IN_USE)));                
		
		appParams.setPropertyTypeRefinance(getLabelValueVOList(mortgageParams.getPropertyTypeRefinRefData(MortgageUtil.COMPASS_REFERENCE_DATA_STATUS_IN_USE)));
		
		//appParams.setLoanPurpose(getLabelValueVOList(MortgageParams.getLoanPurposeRefData(MortgageUtil.COMPASS_REFERENCE_DATA_STATUS_IN_USE)));
		//appParams.setLoanType(getLabelValueVOList(MortgageParams.getLoanTypeRefData(MortgageUtil.COMPASS_REFERENCE_DATA_STATUS_IN_USE)));
		
		// check existing switch value
		Boolean existingCustomerSwitch = IBankParams.getSwitch(origin, IBankParams.MORTGAGE_SWITCH);
			if(null!=existingCustomerSwitch){
				 appParams.setExistingCustomerSwitch(existingCustomerSwitch);
			}else{
				 appParams.setExistingCustomerSwitch(false);
			}
		
		Boolean refinanceSwitch = IBankParams.getSwitch(origin, IBankParams.REFINANCE_NEWAPP_SWITCH);
		if(null!=refinanceSwitch){
			appParams.setRefinNewAppSwitch(refinanceSwitch);				
		}else{
			appParams.setRefinNewAppSwitch(false);
		}
		
		Boolean refinanceRetrievalSwitch = IBankParams.getSwitch(origin, IBankParams.REFINANCE_RETRIEVAL_SWITCH);
		if(null!=refinanceRetrievalSwitch){
			appParams.setRefinRetrievalSwitch(refinanceRetrievalSwitch);				
		}else{
			appParams.setRefinRetrievalSwitch(false);
		}
		
		Boolean dtmLoanAttributesSwitch = IBankParams.getSwitch(origin, IBankParams.DTM_LOAN_ATTRIBUTES_SWITCH);
		if (dtmLoanAttributesSwitch != null) {
			appParams.setDTMLoanAttributesSwitch(dtmLoanAttributesSwitch);				
		}else{
			appParams.setDTMLoanAttributesSwitch(false);
		}
		
		appParams.setClientTimeout(mortgageParams.getCLASAssessTimeout());
		
		//appParams.setEmploymentIndustry(getLabelValueVOList(mortgageParams.getEmpIndustryRefData(MortgageUtil.COMPASS_REFERENCE_DATA_STATUS_IN_USE)));
		appParams.setEmploymentRole(getLabelValueVOList(mortgageParams.getEmpRoleRefData(MortgageUtil.COMPASS_REFERENCE_DATA_STATUS_IN_USE)));

		// check Doc Upload switch value
		Boolean docUploadSwitch = IBankParams.getSwitch(origin, IBankParams.MORTGAGE_DOC_UPLOAD_SWITCH);
		if(null!=docUploadSwitch){
		   appParams.setMortgageDocUploadSwitch(docUploadSwitch);
		}
		else{
		   appParams.setMortgageDocUploadSwitch(false);
		}
		//19E1 credit decision swith values
		MortgageService mortgageService = (MortgageService)ServiceHelper.getBean("mortgageService");
		appParams.setCreditCheckSwitchOff(mortgageService.getCreditDecisionSwitchOffValues(mortgageParams.getBaseOriginCode(origin)));

		Boolean existingShowConfitty = IBankParams.getSwitch(origin, IBankParams.SHOWCONFITTI_SWITCH);
		
		appParams.setShowConfitti(false);
		if ( existingShowConfitty == null || existingShowConfitty.booleanValue() )
		{
			appParams.setShowConfitti(true);
		}
		//19E2 AppDynamics
		Boolean appDynamicsDMSwitch = IBankParams.getSwitch(origin, IBankParams.APP_DYNAMICS_DM_SWITCH);
		if(null!=appDynamicsDMSwitch){
		    appParams.setAppDynamicsDMSwitch(appDynamicsDMSwitch);
		}
		else{
		    appParams.setAppDynamicsDMSwitch(false);
		}
		Boolean appDynamicsMBSwitch = IBankParams.getSwitch(origin, IBankParams.APP_DYNAMICS_MB_SWITCH);
		if(null!=appDynamicsMBSwitch){
		    appParams.setAppDynamicsMBSwitch(appDynamicsMBSwitch);
		}
		else{
		    appParams.setAppDynamicsMBSwitch(false);
		}
		
		//19E4 DM_APRA_SWITCH
		Boolean dmApraSwitch= IBankParams.getSwitch(origin, IBankParams.DM_APRA_SWITCH);
		if(null!=dmApraSwitch){
		    appParams.setDmApraSwitch(dmApraSwitch);
		}
		else{
		    appParams.setDmApraSwitch(false);
		}
		
		//20E2
		Boolean dmNewLoanTermSwitch = IBankParams.getSwitch(IBankParams.DEFAULT_ORIGIN, IBankParams.MORTGAGE_NEW_LOAN_TERM_SWITCH);
		if(null!=dmNewLoanTermSwitch && dmNewLoanTermSwitch==true){
		   appParams.setDmNewLoanTermSwitch(dmNewLoanTermSwitch);
		}
		else{
		   appParams.setDmNewLoanTermSwitch(false);
		}
		
		//20E4
		Boolean lpMessagingSwitch = IBankParams.getSwitch(IBankParams.getBaseOriginCode(origin), IBankParams.LP_MESSAGING_SWITCH);
		if(null!=lpMessagingSwitch && lpMessagingSwitch==true){
		   appParams.setLpMessagingSwitch(lpMessagingSwitch);
		}
		else{
		   appParams.setLpMessagingSwitch(false);
		}
		Cookie appVerCookie = CommonBusinessUtil.getCookie(httpRequest, IBankParams.APP_VER_COOKIE);
		appParams.setLpNativeOldApp(!CommonBusinessUtil.cookieContainsValue(appVerCookie,CHAT));
		return appParams;
	}

	//DMReferenceData related methods ---- BEGIN
	public void setRefData() {
	}
	private List<LabelValueVO> getLabelValueVOList(List<DMRefDataVO> listDMRefDataVO) {
		List<LabelValueVO> listLabelValueVO = null;
		if(listDMRefDataVO != null && !listDMRefDataVO.isEmpty()) {
			listLabelValueVO = new ArrayList<LabelValueVO>();
			for(DMRefDataVO dmRefDataVO : listDMRefDataVO) {
				listLabelValueVO.add(new LabelValueVO(dmRefDataVO.getDescription(), dmRefDataVO.getCompassCode()));
			}
		}
		return listLabelValueVO;
	}
	
	private List<LabelValueVO> getLabelValueVOList(List<DMRefDataVO> listDMRefDataVO, String origin) {
		List<LabelValueVO> listLabelValueVO = null;
		if(listDMRefDataVO != null && !listDMRefDataVO.isEmpty()) {
			listLabelValueVO = new ArrayList<LabelValueVO>();
			int brandIndex = -1;
			for(int i=0; i<listDMRefDataVO.size(); i++) {
				DMRefDataVO dmRefDataVO = listDMRefDataVO.get(i);
				listLabelValueVO.add(new LabelValueVO(dmRefDataVO.getDescription(), dmRefDataVO.getCompassCode()));
				if(EnumUtils.isValidEnum(MortgageUtil.BankBrandBaseEnum.class, dmRefDataVO.getCompassCode())){
					OriginsVO originVO = IBankParams.getOrigin(origin);
					String bankName = originVO.getBankName();
					if(MortgageUtil.BankBrandBaseEnum.valueOf(dmRefDataVO.getCompassCode()).getOrigin().equalsIgnoreCase(bankName)){
						brandIndex = i;
					}
				}
			}
			if(brandIndex > 0){
				LabelValueVO labelValueVOFirst = listLabelValueVO.get(0);
				LabelValueVO labelValueVOBrand = listLabelValueVO.get(brandIndex);
				listLabelValueVO.set(brandIndex, labelValueVOFirst);
				listLabelValueVO.set(0, labelValueVOBrand);
			}
		}
		return listLabelValueVO;
	}
	//DMReferenceData related methods ---- END

	//DMCodes related methods ---- BEGIN
	public LabelValueVO getDMCodesData(String origin, String category, String code) {
		MortgageParams mortgageParams = ServiceHelper.getBean("mortgageParams");
		if(origin == null || origin.isEmpty()) {
			origin = MortgageUtil.ORIGIN_ALL;
		}
		LabelValueVO labelValueVO = mortgageParams.getDMCodesDataLabelValueVO(origin, category, code);
		return labelValueVO;
	}
	
	private  List<LabelValueVO> getDMCodesData(String origin, String category) {
		MortgageParams mortgageParams = ServiceHelper.getBean("mortgageParams");
		if(origin == null || origin.isEmpty()) {
			origin = MortgageUtil.ORIGIN_ALL;
		}
		List<LabelValueVO> labelValueVOList = mortgageParams.getDMCodesDataLabelValueVOList(origin, category);
		return labelValueVOList;
	}
	
	public boolean isValidCode(List<DMRefDataVO> listDMRefDataVO, String code) {
		List<LabelValueVO> listLabelValueVO = getLabelValueVOList(listDMRefDataVO);
		boolean isValid = false;
		if (listLabelValueVO != null && !listLabelValueVO.isEmpty()) {
			for(LabelValueVO labelVO : listLabelValueVO) {
				if (labelVO.getValue().equals(code)) {
					isValid = true;
					break;
				}
			}
		} 
		return isValid;
	}

	public String getHelpDeskContactNumber(String origin) {
		MortgageParams mortgageParams = ServiceHelper.getBean("mortgageParams");
		String baseOrigin = mortgageParams.getBaseOriginCode(origin);
		String originHelpDeskPhone = null;
		if(MortgageUtil.ORIGIN_SGB.equals(baseOrigin)) {
			baseOrigin = MortgageUtil.ORIGIN_ALL;
		}
		List<LabelValueVO> labelValueVOList = getDMCodesData(baseOrigin,MortgageUtil.REF_DATA_CATEGORY_HELP_DESK);
		if (labelValueVOList != null && !labelValueVOList.isEmpty()) {
			//baseOrigin = IBankParams.getBaseOriginCode(origin);
			for (LabelValueVO labelValueVO : labelValueVOList) {
				if(labelValueVO.getValue().equals(baseOrigin)) {
					originHelpDeskPhone = labelValueVO.getLabel();
					break;
				} 
			}
			if(originHelpDeskPhone == null) {
				originHelpDeskPhone = labelValueVOList.get(0).getLabel();
			}
			
		}
		return originHelpDeskPhone;
	}
	
	public String getCCCNumber(String origin) {
		MortgageParams mortgageParams = ServiceHelper.getBean("mortgageParams");
		String originHelpDeskPhone = null;
		String baseOrigin = mortgageParams.getBaseOriginCode(origin);
		
		if(MortgageUtil.ORIGIN_SGB.equals(baseOrigin)) {
			baseOrigin = MortgageUtil.ORIGIN_ALL;
		}
		CodesVO helpDeskNo = getCodesData(baseOrigin, IBankParams.CC_BALANCE_TRANSFER, IBankParams.HELP_DESK_PHONE_NUMBER);
		
		if(null!=helpDeskNo){
			originHelpDeskPhone=helpDeskNo.getMessage();
		}
		
		return originHelpDeskPhone;
	}
	
	public String getOriginNumber(String origin) {
		//MortgageParams mortgageParams = ServiceHelper.getBean("mortgageParams");
		String originHelpDeskPhone = null;
		//String baseOrigin = mortgageParams.getBaseOriginCode(origin);	
	
		/*if(MortgageUtil.ORIGIN_SGB.equals(baseOrigin)) {
			baseOrigin = MortgageUtil.ORIGIN_ALL;
		}
		*/
		OriginsVO originVo = IBankParams.getOrigin(origin); 
				
		if(null!=originVo){
			originHelpDeskPhone=originVo.getPhone();
		}		
		return originHelpDeskPhone;
	}
	
	public Integer getMaxBucketEntries(String origin) {
		LabelValueVO labelValueVO = getDMCodesData(origin,MortgageUtil.REF_DATA_CATEGORY_MAX_BUCKET_ENTRIES, MortgageUtil.REF_DATA_CODE_MAX_BUCKET_ENTRIES);
		Integer maxBucketEntries = null;
		if(labelValueVO != null && labelValueVO.getLabel() != null && !labelValueVO.getLabel().isEmpty()) {
			maxBucketEntries = new Integer(labelValueVO.getLabel());
		}
		return maxBucketEntries;
	}
	
	public Integer getRefinanceInterestOnlyLVR() {
		LabelValueVO labelValueInterestOnlyLVRVO = getDMCodesData(MortgageUtil.ORIGIN_ALL, MortgageUtil.MORTGAGE_REFI_LVR, MortgageUtil.MORTGAGE_REFI_LVR_INTEREST_ONLY);
		return getInteger(labelValueInterestOnlyLVRVO);		
	}
	
	public Integer getRefinancePrincipalAndInterestLVR() {
		LabelValueVO labelValuePrincipalAndInterestLVRVO = getDMCodesData(MortgageUtil.ORIGIN_ALL, MortgageUtil.MORTGAGE_REFI_LVR, MortgageUtil.MORTGAGE_REFI_LVR_PRINCIPAL_AND_INTEREST);
		return getInteger(labelValuePrincipalAndInterestLVRVO);		
	}
	
	public String getMinimumBorrowingAmount() {
		LabelValueVO labelValueMinimumLoanAmountVO = getDMCodesData(MortgageUtil.ORIGIN_ALL, MortgageUtil.MORTGAGE_PARAMETER, MortgageUtil.MORTGAGE_MIN_BORROWING_AMOUNT);
		return labelValueMinimumLoanAmountVO.getLabel();		
	}
	
	private Integer getInteger(LabelValueVO labelValueVO) {
		Integer convertedInteger = null;
		if (labelValueVO != null && labelValueVO.getLabel() != null && !labelValueVO.getLabel().isEmpty()) {
			convertedInteger = new Integer(labelValueVO.getLabel());
		}
		return convertedInteger;
	}
	
	public List<String> getLoanOutcomeSpinnerTextList(){
		List<String> spinnerTextList = null;
		LabelValueVO labelValueSpinnerTextVO = getDMCodesData(MortgageUtil.ORIGIN_ALL, MortgageUtil.MORTGAGE_LOANOUTCOME_SPINNER_TEXT_CATEGORY, MortgageUtil.MORTGAGE_LOANOUTCOME_SPINNER_TEXT_CODE);
		if(labelValueSpinnerTextVO != null && !StringUtils.isEmpty(labelValueSpinnerTextVO.getLabel())) {
			spinnerTextList = new ArrayList<String>(Arrays.asList(labelValueSpinnerTextVO.getLabel().split(MortgageUtil.MORTGAGE_LOANOUTCOME_SPINNER_TEXT_SEPERATOR)));
		}
		return spinnerTextList;
	}
	//DMCodes related methods ---- END

	
	
}