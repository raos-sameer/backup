package au.com.stgeorge.mbank.model.common;

import java.util.ArrayList;
import java.util.List;

import au.com.stgeorge.mbank.model.response.onboarding.OBSegmentResp;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_NULL)
public class OnboardingTileResp {
	  private String tileStatus;
	  private Integer accountIndex;
	  private String viewStatus;
	  private boolean isSegmentSaved;
	  private String productName;
	  private String accountNumber;
	  private List<OBSegmentResp> obSegments = new ArrayList<OBSegmentResp>();
	  
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public String getTileStatus() {
		return tileStatus;
	}
	public String getViewStatus() {
		return viewStatus;
	}
	public void setViewStatus(String viewStatus) {
		this.viewStatus = viewStatus;
	}
	public boolean isSegmentSaved() {
		return isSegmentSaved;
	}
	public void setSegmentSaved(boolean isSegmentSaved) {
		this.isSegmentSaved = isSegmentSaved;
	}
	public void setTileStatus(String tileStatus) {
		this.tileStatus = tileStatus;
	}
	public Integer getAccountIndex() {
		return accountIndex;
	}
	public void setAccountIndex(Integer accountIndex) {
		this.accountIndex = accountIndex;
	}
	public List<OBSegmentResp> getObSegments() {
		return obSegments;
	}
	public void setObSegments(List<OBSegmentResp> obSegments) {
		this.obSegments = obSegments;
	}
	public String getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}
	
	
}
