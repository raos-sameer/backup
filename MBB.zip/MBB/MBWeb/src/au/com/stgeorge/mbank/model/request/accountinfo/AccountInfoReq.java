package au.com.stgeorge.mbank.model.request.accountinfo;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.NotEmpty;

import au.com.stgeorge.ibank.businessobject.BusinessException;
import au.com.stgeorge.mbank.model.common.IMBReq;
import au.com.stgeorge.mbank.model.common.ReqHeader;

public class AccountInfoReq implements IMBReq{

	private static final long serialVersionUID = -8619853234497299425L;
	//19E1 CI - Removing increase transaction history CI item
	//private static final String HISTORY_PERIOD_PATTERN = "((?i)(0|30|60|90|all))";
	private static final String HISTORY_PERIOD_PATTERN = "((?i)(0|30|60|all))";
	private ReqHeader header;
	
	private AdvanceSearchReq advanceSearch;
	
	public AdvanceSearchReq getAdvanceSearch() {
		return advanceSearch;
	}
	
	public void setAdvanceSearch(AdvanceSearchReq advanceSearch) {
		this.advanceSearch = advanceSearch;
	}

	//TODO	
	@NotNull(message = "" + BusinessException.WSVC_INVALID_INPUT_PARAM)
	private Integer accountIndex;
	
	//TODO
	@NotEmpty (message = ""+BusinessException.WSVC_INVALID_INPUT_PARAM)	
	@Pattern(regexp = HISTORY_PERIOD_PATTERN ,message = ""+BusinessException.WSVC_INVALID_INPUT_PARAM)	 
	private String historyPeriod;
	
	private Boolean ccDispute;
	
	private String toDate;
	
	public Integer getAccountIndex() {
		return accountIndex;
	}	
	public void setAccountIndex(Integer accountIndex) {
		this.accountIndex = accountIndex;
	}
	
	public ReqHeader getHeader()
	{
		return header;
	}
	public void setHeader(ReqHeader header)
	{
		this.header = header;
	}
				
	public String getHistoryPeriod() {
		return historyPeriod;
	}
	public void setHistoryPeriod(String historyPeriod) {
		this.historyPeriod = historyPeriod;
	}
	
	public static long getSerialVersionUID() {
		return serialVersionUID;
	}
	
	public Boolean getCcDispute() {
		return ccDispute;
	}
	public String getToDate() {
		return toDate;
	}
	
	public void setToDate(String toDate) {
		this.toDate = toDate;
	}
}
