package au.com.stgeorge.mbank.controller.services;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import au.com.stgeorge.ibank.businessobject.BusinessException;
import au.com.stgeorge.ibank.businessobject.ResourceException;
import au.com.stgeorge.ibank.common.cache.IBankParams;
import au.com.stgeorge.ibank.valueobject.transfer.IBankCommonData;
import au.com.stgeorge.mbank.controller.IMBController;
import au.com.stgeorge.mbank.controller.customer.LogonHelper;
import au.com.stgeorge.mbank.model.common.IMBReq;
import au.com.stgeorge.mbank.model.common.IMBResp;
import au.com.stgeorge.mbank.model.common.ReqHeader;
import au.com.stgeorge.mbank.model.common.RespHeader;
import au.com.stgeorge.mbank.model.response.ErrorResp;
import au.com.stgeorge.mbank.model.response.SuccessResp;
import au.com.stgeorge.mbank.session.MobileSession;
import au.com.stgeorge.mbank.util.MBAppHelper;
import au.com.stgeorge.mbank.util.MBAppValidator;
import au.com.stgeorge.tranhistory.util.Logger;

@Controller
public class ServiceBadgingController implements IMBController {
	
	
	@Autowired
	private MBAppValidator mbAppValidator;
	
	@Autowired
	private MBAppHelper mbAppHelper;
	
	@Autowired
	private LogonHelper logonHelper;
	
	
	@RequestMapping(value= "setBadgeCookie" , method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public IMBResp createServiceBadgingCookie(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse)
	{	
		MobileSession mbSession = null;
		SuccessResp response = new SuccessResp();
		try {
			if(IBankParams.isSwitchOn(IBankParams.SERVICE_BADGING_SWITCH)) {
				mbSession = mbAppHelper.getMobileSession(httpServletRequest);
				String encryptedCookieUserid = logonHelper.getEncryptedUserID(mbSession.getUser().getUserId());
				logonHelper.setServiceBadgeCookie(httpServletRequest,httpServletResponse,encryptedCookieUserid);
				response.setIsSuccess(true);	
			}
			else {
				Logger.info("Service Badge switch is off", this.getClass());
				response.setIsSuccess(false);
			}
			
		} catch (BusinessException e) {
			response.setIsSuccess(false);
			Logger.error("Error in creating service badge cookie", this.getClass());
		}
		catch (Exception e) {
			response.setIsSuccess(false);
			Logger.error("Error in creating service badge cookie", this.getClass());
		}
		
		return response;
	}

	public ErrorResp validate(IMBReq serviceRequest, HttpServletRequest request) {
		return mbAppValidator.validate(serviceRequest, request);
	}
	
	public void validateRequestHeader(ReqHeader header, HttpServletRequest request) throws ResourceException
	{	
		mbAppValidator.validateRequestHeader(header,  request);	
	}
	
	public RespHeader populateResponseHeader(String serviceName, MobileSession mobSession )
	{
		return mbAppHelper.populateResponseHeader(serviceName, mobSession);
	}

}
