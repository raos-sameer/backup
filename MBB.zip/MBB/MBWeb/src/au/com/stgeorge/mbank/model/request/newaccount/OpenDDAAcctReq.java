package au.com.stgeorge.mbank.model.request.newaccount;

import java.io.Serializable;

import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.Length;

import au.com.stgeorge.mbank.model.common.IMBReq;
import au.com.stgeorge.mbank.model.common.ProductReq;
import au.com.stgeorge.mbank.model.common.ReqHeader;

public class OpenDDAAcctReq implements IMBReq, Serializable{

	/**
	 * 
	 */
	protected static final String BLOCK_CHARS_PATTERN = "^[0-9A-Za-z',. &/\\-]*$";
	protected static final String AMT_PATTERN = "^[0-9]*\\.{0,1}(\\d{1,2}){0,1}$";
	
	private static final long serialVersionUID = -6192646895153010474L;
    private ReqHeader header;    
	private ProductReq product;	
	private Boolean overrideDuplicate;
	
	@Pattern(regexp = BLOCK_CHARS_PATTERN, message = "{errors.regionId.blockchar}")
	private String regionId;
	
	@Pattern(regexp = BLOCK_CHARS_PATTERN, message = "{errors.branchId.blockchar}")
	private String branchId;
	
	//used for working account for maxi saver
	private ProductReq additionalProduct;
	
	//set when the account is opened via cross sell
	private boolean comingFromCrossSell;
	private String leadId;
	
	@Length(max = 14, message = "{errors.amt.maxlength}")
	@Pattern(regexp = AMT_PATTERN, message = "{errors.amt.blockchar}")	
	private String savingTargetAmount; //used for sense account opening
	
	private boolean comingFromSavingsHabit;
	
	
	//19E3 TFN Changes
	private String selectedOption;
	private String taxFileNumber;
	private String selectedExemption;
	
	public String getLeadId() {
		return leadId;
	}
	public void setLeadId(String leadId) {
		this.leadId = leadId;
	}
	
	public ProductReq getProduct() {
		return product;
	}
	public void setProduct(ProductReq product) {
		this.product = product;
	}    
    
	public ReqHeader getHeader()
	{
		return header;
	}
	public void setHeader(ReqHeader header)
	{
		this.header = header;
	}
	public Boolean getOverrideDuplicate() {
		return overrideDuplicate;
	}
	public void setOverrideDuplicate(Boolean overrideDuplicate) {
		this.overrideDuplicate = overrideDuplicate;
	}
	public String getRegionId() {
		return regionId;
	}
	public void setRegionId(String regionId) {
		this.regionId = regionId;
	}
	public String getBranchId() {
		return branchId;
	}
	public void setBranchId(String branchId) {
		this.branchId = branchId;
	}
	public ProductReq getAdditionalProduct() {
		return additionalProduct;
	}
	public void setAdditionalProduct(ProductReq additionalProduct) {
		this.additionalProduct = additionalProduct;
	}
	public Boolean getComingFromCrossSell() {
		return comingFromCrossSell;
	}
	public void setComingFromCrossSell(Boolean comingFromCrossSell) {
		this.comingFromCrossSell = comingFromCrossSell;
	}
	public String getSavingTargetAmount() {
		return savingTargetAmount;
	}
	public void setSavingTargetAmount(String savingTargetAmount) {
		this.savingTargetAmount = savingTargetAmount;
	}
	public boolean isComingFromSavingsHabit() {
		return comingFromSavingsHabit;
	}
	public void setComingFromSavingsHabit(boolean comingFromSavingsHabit) {
		this.comingFromSavingsHabit = comingFromSavingsHabit;
	}
	public String getSelectedOption() {
		return selectedOption;
	}
	public void setSelectedOption(String selectedOption) {
		this.selectedOption = selectedOption;
	}
	public String getTaxFileNumber() {
		return taxFileNumber;
	}
	public void setTaxFileNumber(String taxFileNumber) {
		this.taxFileNumber = taxFileNumber;
	}
	public String getSelectedExemption() {
		return selectedExemption;
	}
	public void setSelectedExemption(String selectedExemption) {
		this.selectedExemption = selectedExemption;
	}
}
