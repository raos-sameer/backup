package au.com.stgeorge.mbank.controller.loanApplication;

import java.util.Date;
import java.util.UUID;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import au.com.stgeorge.framework.common.exception.BaseException;
import au.com.stgeorge.framework.common.logging.Logger;
import au.com.stgeorge.framework.common.model.User;
import au.com.stgeorge.framework.common.util.StringMethods;
import au.com.stgeorge.ibank.businessobject.BusinessException;
import au.com.stgeorge.ibank.businessobject.PreferencesService;
import au.com.stgeorge.ibank.businessobject.ResourceException;
import au.com.stgeorge.ibank.businessobject.homeloan.HomeLoanOBPService;
import au.com.stgeorge.ibank.businessobject.impl.OIDCServiceImpl;
import au.com.stgeorge.ibank.common.cache.IBankParams;
import au.com.stgeorge.ibank.loanApplication.util.LoanAppConstants;
import au.com.stgeorge.ibank.loanApplication.util.LoanAppUtil;
import au.com.stgeorge.ibank.valueobject.Customer;
import au.com.stgeorge.ibank.valueobject.IDPSSODetails;
import au.com.stgeorge.ibank.valueobject.Preference;
import au.com.stgeorge.ibank.valueobject.homeloan.HomeLoanTileContentVO;
import au.com.stgeorge.ibank.valueobject.transfer.IBankCommonData;
import au.com.stgeorge.mbank.controller.IMBController;
import au.com.stgeorge.mbank.model.common.IMBReq;
import au.com.stgeorge.mbank.model.common.IMBResp;
import au.com.stgeorge.mbank.model.common.ReqHeader;
import au.com.stgeorge.mbank.model.common.RespHeader;
import au.com.stgeorge.mbank.model.request.AppTrackerRequest;
import au.com.stgeorge.mbank.model.response.ErrorResp;
import au.com.stgeorge.mbank.model.response.homeloan.HomeLoanTileContentResp;
import au.com.stgeorge.mbank.session.MobileSession;
import au.com.stgeorge.mbank.session.MobileSessionImpl;
import au.com.stgeorge.mbank.util.MBAppHelper;
import au.com.stgeorge.mbank.util.MBAppUtils;
import au.com.stgeorge.mbank.util.MBAppValidator;
import au.com.stgeorge.mbank.util.ServiceConstants;
import au.com.stgeorge.perflogger.PerformanceLogger;

@Controller
@RequestMapping("/homeLoanApp")
public class HomeLoanApplicationController implements IMBController
{

	@Autowired
	private HomeLoanOBPService homeloanService;
	
	@Autowired
	private HomeLoanApplicationHelper homeLoanApplicationHelper;
	
	@Autowired
	private MBAppHelper mbAppHelper;

	@Autowired
	private PerformanceLogger perfLogger;
	
	private String startPerformanceLog(HttpServletRequest httpRequest){
		perfLogger.startAllLogs();
		String logName = MBAppUtils.getLogName(httpRequest);
		perfLogger.startLog(logName);
		return logName;
	}
	
	private void endPerformanceLog(String logName){
		perfLogger.endLog(logName);
		perfLogger.endAllLogs();
	}
	


	public IBankCommonData populateIBankCommonData(Customer customer, User user)
	{
		IBankCommonData commonData = new IBankCommonData();
		commonData.setUser(user);
		commonData.setOrigin((String) user.getAttribute(IBankParams.USEROBJ_BRAND));
		commonData.setCustomer(customer);
		return commonData;
	}

	public ErrorResp validate(IMBReq serviceRequest, HttpServletRequest request)
	{
		return mbAppValidator.validate(serviceRequest, request);
	}

	public void validateRequestHeader(ReqHeader header, HttpServletRequest request) throws ResourceException
	{
		mbAppValidator.validateRequestHeader(header, request);
	}

	public RespHeader populateResponseHeader(String serviceName, MobileSession mobSession)
	{
		return mbAppHelper.populateResponseHeader(serviceName, mobSession);
	}

	@Autowired
	private MBAppValidator mbAppValidator;
	

	@RequestMapping(method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE, value = "getTileContentAsync")
	@ResponseBody
	public IMBResp getTileContentAsync(HttpServletRequest httpRequest, HttpServletResponse httpServletResponse, @RequestBody final AppTrackerRequest request) {
		Logger.debug("getTileContentAsync(). Request: " + request, this.getClass());
		String logName = startPerformanceLog(httpRequest);
		MobileSession mobileSession = new MobileSessionImpl(); 
		HomeLoanTileContentResp resp = new HomeLoanTileContentResp();
		resp.setTileExpired(true);
		HomeLoanTileContentVO tileContentVO = null;
		boolean isTilePresent=false;
		
		try {
			perfLogger.startLog("getTileContentAsync");
			mobileSession.getSessionContext(httpRequest);
			IBankCommonData commonData = new MBAppHelper().populateIBankCommonData(mobileSession, httpRequest);
			//bypassing nameID validation for Async Calls
			//validateRequestHeader(request.getHeader(), httpRequest);
			ErrorResp errorResponse = validateAsync(request, httpRequest);
			if (errorResponse.hasErrors())
				return errorResponse;			


			RespHeader headerResp = mbAppHelper.populateAsyncResponseHeader(ServiceConstants.HOME_LOAN_SERVICE, mobileSession);
			
			String cshTilePresent=mobileSession.getCSHTilePresent();
			
			if(IBankParams.NO.equalsIgnoreCase(cshTilePresent) || null == cshTilePresent) {
				Preference myPreference = PreferencesService.getPreferenceForMobileBank(commonData.getUser());
				if(null!=myPreference) {
					int cshIndicator = LoanAppUtil.getCSHTileIndicator(myPreference.getCcPLLoanInd());
					
					if((cshIndicator == LoanAppConstants.PRF_CCLOANIND_EFINANCE
							|| cshIndicator == LoanAppConstants.PRF_CCLOANIND_HOMELOAN
							|| cshIndicator == LoanAppConstants.PRF_CCLOANIND_EFINANCE_HOMELOAN_BOTH
							|| cshIndicator == LoanAppConstants.PRF_CCLOANIND_CSH)) {
						isTilePresent=true;
					}						
				}
			}else if(IBankParams.YES.equalsIgnoreCase(cshTilePresent)) {
				isTilePresent=true;
			}
			if(isTilePresent) {
				if(homeloanService.isActiveCSHTileExists(commonData.getUser().getGCISNumber())) {
					
					tileContentVO=mobileSession.getHomeLoanTileContentVO();
					
					if(tileContentVO==null) {
						tileContentVO = homeloanService.getTileContent(commonData, UUID.randomUUID());	
					}
					
					if(tileContentVO != null) {
						int appCount=tileContentVO.getAppCount();
						Logger.debug("App count for tile content async" + appCount, this.getClass());
						if(appCount==1 && tileContentVO.isDraftSubmissionAvailable() && !IBankParams.isSwitchOn(IBankParams.DEFAULT_ORIGIN, IBankParams.CSH_PREPARE_ONLINE_SWITCH)) {
							Logger.debug("App count 1, draft sub available but switch off>>", this.getClass());
							resp.setTileExpired(true);
							resp.setHeader(headerResp);
							return  resp;
						}else {
							Logger.debug("inside else>>", this.getClass());
							homeLoanApplicationHelper.populateHomeLoanTileContentResp(resp, tileContentVO);
							Logger.debug("Putting Home loan tile content in Session with session id: " + mobileSession.getSessionID()+ " with tileContentVO value :"+tileContentVO, this.getClass());
							mobileSession.setHomeLoanTileContentVO(tileContentVO);
						}
					}
					
					boolean isDeepLink = request.getIsDeepLink();
					
					Logger.debug("isDeepLink : "+isDeepLink, this.getClass());
					
					if(isDeepLink) {
						
						int cshIndicator = LoanAppUtil.getCSHTileIndicator(commonData.getCustomer().getPreference().getCcPLLoanInd());
						
						if(cshIndicator == LoanAppConstants.PRF_CCLOANIND_CSH ||
								cshIndicator == LoanAppConstants.PRF_CCLOANIND_EFINANCE ||	
								cshIndicator == LoanAppConstants.PRF_CCLOANIND_HOMELOAN ||
								cshIndicator == LoanAppConstants.PRF_CCLOANIND_EFINANCE_HOMELOAN_BOTH) {
							resp.setLaunchDeeplink(true);
						}
						
						if(null != tileContentVO && tileContentVO.isErrorResponse()) {
							resp.setLaunchDeeplink(false);
							resp.setTileExpired(false);
						}
						
					}
					
				}
			}else {
				resp.setTileExpired(true);
			}		
			//RespHeader headerResp = mbAppHelper.populateAsyncResponseHeader(ServiceConstants.HOME_LOAN_SERVICE, mobileSession);
			resp.setHeader(headerResp);
			return  resp;
			
		} catch (BusinessException e) {
			Logger.info("BusinessException in getTileContentAsync() - [key: " + e.getKey() + "], GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());
			return MBAppUtils.createErrorRespAsync(mobileSession.getOrigin(), e, ServiceConstants.HOME_LOAN_SERVICE, httpRequest);
		} catch (ResourceException e) {
			Logger.error("ResourceException in getTileContentAsync() - [key: " + e.getKey() + "], GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());
			return MBAppUtils.createErrorRespAsync(mobileSession.getOrigin(), new ResourceException(BusinessException.SYSTEM_UNAVILABLE), ServiceConstants.HOME_LOAN_SERVICE, httpRequest);
		} catch (Exception e) {
			Logger.error("Exception getTileContentAsync(): GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			return MBAppUtils.createErrorRespAsync(mobileSession.getOrigin(), new BusinessException(BusinessException.GENERIC_ERROR), ServiceConstants.HOME_LOAN_SERVICE, httpRequest);
		} finally {
			perfLogger.endLog("getTileContentAsync");
			endPerformanceLog(logName);
		}
	}

	public ErrorResp validateAsync(IMBReq serviceRequest, HttpServletRequest httpRequest) throws BusinessException {
		return  mbAppValidator.validateAsync(serviceRequest, httpRequest);
	}		
	

		
	@RequestMapping(method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE, value = "initMGRP")
	@ResponseBody
	public IMBResp initMGRP(HttpServletRequest httpRequest, HttpServletResponse httpServletResponse)throws BaseException{
		Logger.debug("START initMGRP ", this.getClass());
		String logName = startPerformanceLog(httpRequest);
		MobileSession mbSession = new MobileSessionImpl(); 
		IBankCommonData commonData = null;
//		UI doesnt bother about Response... so just sending any response
		HomeLoanTileContentResp resp = new HomeLoanTileContentResp();
		try {


			mbSession = mbAppHelper.getMobileSession(httpRequest);
			commonData = mbAppHelper.populateIBankCommonData(mbSession, httpRequest);
			String baseOrigin = IBankParams.getBaseOriginCode(commonData.getOrigin());
			
			String cookieName = "IBVrfyTk";
			String cookieValue = "SESSIONID0123456789";
			String SRV_TOKEN_TYPE = "OIDCToken"; 
			
			//Create cookie to know which application(IB or MB) has launched WDP
			OIDCServiceImpl oidcService  = new OIDCServiceImpl();
			IDPSSODetails idpSSODetails = new IDPSSODetails();
			idpSSODetails.setCreationTime(new Date() );
			idpSSODetails.setCustomerType("P");
			idpSSODetails.setGcisNumber( commonData.getUser().getGCISNumber());

			idpSSODetails.setSessionId(mbSession.getSessionID());
			idpSSODetails.setTokenType(SRV_TOKEN_TYPE);
			


			 cookieValue = oidcService.getServiceTokenId(idpSSODetails, commonData, SRV_TOKEN_TYPE, true);

			Logger.info("Got Token : "+ cookieValue , this.getClass());

			mbSession.setidpSSODetails(idpSSODetails);

			Logger.info("Update Session Got Token : "+ cookieValue + " ,Sess Id " + idpSSODetails.getSessionId() , this.getClass());

			addCompassAppTypeCookie(baseOrigin, httpRequest, httpServletResponse, cookieName, "MB:"+cookieValue);

			
			RespHeader headerResp = mbAppHelper.populateResponseHeader("MGRP", mbSession);
			resp.setHeader(headerResp);
			return  resp;
			
		} catch (Exception e) {
			Logger.error("Exception initMGRP: GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			return MBAppUtils.createErrorResp(mbSession.getOrigin(), BusinessException.GENERIC_ERROR, ServiceConstants.PAYEE_TRANSFER_SERVICE, httpRequest);
		} finally {
			Logger.debug("END initMGRP ", this.getClass());
			endPerformanceLog(logName);
		}
	}	
	
	public void addCompassAppTypeCookie(String origin, HttpServletRequest request, HttpServletResponse response, String name, String value) {
		String domainName = request.getServerName();
		if(domainName.contains(".")){
			domainName = domainName.substring(domainName.indexOf("."));
		}		
		if(! StringMethods.isEmptyString(domainName)){
			response.addHeader("Set-Cookie", name + "=" + value + "; path=/" + "; domain="+domainName);
		}
		else{
			response.addHeader("Set-Cookie", name + "=" + value + "; path=/");
		}

		Logger.info(" Added "+ name + " = "+ value, this.getClass());
	}

}