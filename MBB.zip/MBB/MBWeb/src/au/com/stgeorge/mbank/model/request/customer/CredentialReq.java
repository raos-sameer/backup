package au.com.stgeorge.mbank.model.request.customer;

import java.io.Serializable;

import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.ConstraintComposition;

import au.com.stgeorge.framework.common.logging.Logger;
import au.com.stgeorge.ibank.businessobject.BusinessException;
import au.com.stgeorge.mbank.model.common.ReqHeader;
import au.com.stgeorge.mbank.model.common.IMBReq;

public class CredentialReq implements IMBReq, Serializable{
	
	private static final long serialVersionUID = -256469501889499119L;

	
	@Size(max = 12,message = ""+BusinessException.INVALID_CURRENT_PWD_SEC_NUM)
	@Pattern(regexp="([a-zA-Z0-9]+)",message = ""+BusinessException.INVALID_CURRENT_PWD_SEC_NUM)
	private String oldPassword;

	
	@Size(max = 12,message = ""+BusinessException.INVALID_CURRENT_PWD_SEC_NUM)
	@Pattern(regexp="([a-zA-Z0-9]+)",message = ""+BusinessException.INVALID_CURRENT_PWD_SEC_NUM)
	private String newPassword;

	@Size(max = 6,message = ""+BusinessException.INVALID_CURRENT_PWD_SEC_NUM)
	@Pattern(regexp="([0-9]+)",message = ""+BusinessException.INVALID_CURRENT_PWD_SEC_NUM)
	private String oldSecNum;
	

    @Size(max = 6,message = ""+BusinessException.INVALID_CURRENT_PWD_SEC_NUM)
	@Pattern(regexp="([0-9]+)",message = ""+BusinessException.INVALID_CURRENT_PWD_SEC_NUM)
	private String newSecNum;

    private ReqHeader header;
    private boolean sourceSecurityWellBeingCheck; 
	

	public ReqHeader getHeader()
	{
		return header;
	}
	public void setHeader(ReqHeader header)
	{
		this.header = header;
	}
	
	public String getOldPassword() {
		return oldPassword;
	}
	public void setOldPassword(String oldPassword) {
		this.oldPassword = oldPassword;
	}
	public String getOldSecNum() {
		return oldSecNum;
	}
	public void setOldSecNum(String oldSecNum) {
		this.oldSecNum = oldSecNum;
	}
	public String getNewPassword() {
		return newPassword;
	}
	public void setNewPassword(String newPassword) {
		this.newPassword = newPassword;
	}
	public String getNewSecurityNumber() {
		return newSecNum;
	}
	public void setNewSecNum(String newSecNum) {
		this.newSecNum = newSecNum;
	}
	public static long getSerialVersionUID() {
		return serialVersionUID;
	}
	
  private boolean returnCustomer;
  
  
  	
	
	public boolean isSourceSecurityWellBeingCheck() {
		return sourceSecurityWellBeingCheck;
	}
	public void setSourceSecurityWellBeingCheck(boolean sourceSecurityWellBeingCheck) {
		this.sourceSecurityWellBeingCheck = sourceSecurityWellBeingCheck;
	}
	public boolean isReturnCustomer()
	{
		return returnCustomer;
	}
	public void setReturnCustomer(boolean returnCustomer)
	{
		this.returnCustomer = returnCustomer;
	}
	public void toXML()
	{
		//Logger.debug("Objcet " + oldPassword + " " + newPassword + " " + getHeader().getNameId() + " " + oldSecNum + " " + getHeader().getClientApiVersion() , this.getClass());
		
	}
 
}
