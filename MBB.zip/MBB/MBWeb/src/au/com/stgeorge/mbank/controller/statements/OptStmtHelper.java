package au.com.stgeorge.mbank.controller.statements;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import au.com.stgeorge.ibank.businessobject.BusinessException;
import au.com.stgeorge.ibank.valueobject.Account;
import au.com.stgeorge.ibank.valueobject.Customer;
import au.com.stgeorge.ibank.valueobject.transfer.IBankCommonData;
import au.com.stgeorge.mbank.model.response.statements.OptStmtAcctListResp;
import au.com.stgeorge.mbank.model.response.statements.OptStmtResp;
import au.com.stgeorge.mbank.util.MBAppHelper;
import au.com.stgeorge.mobilebank.businessobject.EStatementsService;
@Service
public class OptStmtHelper {

	@Autowired
	private EStatementsService mobileEStatementService;
	
	@Autowired
	private MBAppHelper mbAppHelper;
	
	protected OptStmtAcctListResp populateUnsuppressableAcctListResp(IBankCommonData commonData,Customer customer) throws BusinessException {
	
		OptStmtAcctListResp resp = new OptStmtAcctListResp();
		try{
			List<Account> accountList = mobileEStatementService.getMobileUnSuppressableAccountsList(commonData, customer);
			resp.setAccountList(mbAppHelper.getAccountIndexList(accountList));
						
		}catch(BusinessException e){
			
			if(BusinessException.PAPER_STMT_ACCT_ELIGIBLE_COUNT == e.getKey())
				resp.setNoEligibility(true);
			else if(BusinessException.PAPER_STMT_UNSUPPESSED_ALREADY == e.getKey())
				resp.setAllAcctUnsuppressed(true);
			else
				throw new BusinessException(e.getKey());
		}		
		return resp;
	}
	
	protected OptStmtAcctListResp populateSuppressableAcctListResp(IBankCommonData commonData,Customer customer) throws BusinessException {
		
		OptStmtAcctListResp resp = new OptStmtAcctListResp();
		try{
			List<Account> accountList = mobileEStatementService.getMobileSuppressableAccountsList(commonData,customer);	
			resp.setAccountList(mbAppHelper.getAccountIndexList(accountList));
						
		}catch(BusinessException e){
			
			if(BusinessException.STOP_STMT_ACCT_ELIGIBLE_COUNT == e.getKey())
				resp.setNoEligibility(true);
			else if(BusinessException.STOP_STMT_SUPPESSED_ALREADY == e.getKey())
				resp.setAllAcctSuppressed(true);
			else
				throw new BusinessException(e.getKey());
		}		
		return resp;
	}

	protected OptStmtResp populateResp(List<Account> accounts) throws BusinessException {
		
		OptStmtResp resp = new OptStmtResp();
				
		resp.setAccountList(mbAppHelper.getAccountIndexList(accounts));
		resp.setSystemDate(new Date());
						
		return resp;
	}
}
