package au.com.stgeorge.mbank.controller.customer;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.AbstractController;

import au.com.stgeorge.framework.common.logging.Logger;
import au.com.stgeorge.ibank.businessobject.BusinessException;
import au.com.stgeorge.ibank.businessobject.ResourceException;
import au.com.stgeorge.ibank.businessobject.mgrp.MgrpSAMLService;
import au.com.stgeorge.ibank.businessobject.mgrp.MgrpSAMLServiceHelper;
import au.com.stgeorge.ibank.common.cache.IBankParams;
import au.com.stgeorge.ibank.valueobject.SAMLStore;
import au.com.stgeorge.ibank.valueobject.transfer.IBankCommonData;
import au.com.stgeorge.mbank.session.MobileSession;
import au.com.stgeorge.mbank.util.MBAppHelper;
import au.com.stgeorge.mbank.util.MBAppUtils;
import au.com.stgeorge.perflogger.PerformanceLogger;
import au.com.stgeorge.security.util.StringMethods;



@Controller
public class MgrpExternalController extends AbstractController
{
	private static final String MGRP = "mgrpExternal";
	
	@Autowired
	private PerformanceLogger perfLogger;
	
	@Autowired
	private MgrpSAMLService mgrpSAMLService;
	
	@Autowired
	private MBAppHelper mbAppHelper;

	@Override
	protected ModelAndView handleRequestInternal(HttpServletRequest request, HttpServletResponse response) throws Exception
	{
		Logger.debug("FileShareSamlPostController - handleRequestInternal(). Request: " + request, this.getClass());	
		perfLogger.startAllLogs();
		String logName = MBAppUtils.getLogName(request);
		perfLogger.startLog(logName);
		
		String actionType = request.getParameter("actionType");	
		String token = request.getParameter("token");
		String brand = request.getParameter("brand");
		String origin = null;
		
		ModelAndView model = null;
		
		Logger.debug("ActionType :: " + actionType, this.getClass());	
		Logger.debug("Token :: " + token, this.getClass());	
		Logger.debug("Brand :: " + brand, this.getClass());	
		
		MobileSession mbSession = null;
		
		try
		{
			mbSession = mbAppHelper.getMobileSession(request);
			
			if ((MGRP.equalsIgnoreCase(actionType) && !StringMethods.isEmptyString(token) ))
			{
								
				SAMLStore samlStore = mgrpSAMLService.getSAMLToken(token, MgrpSAMLServiceHelper.MGRP);
				
				if(samlStore == null){
					throw new BusinessException(BusinessException.PDF_STATEMENT_NOT_FOUND);
				}
				
				String samlData = samlStore.getSamlData();						
				mgrpSAMLService.deleteSAMLTokenDetails(token, MgrpSAMLServiceHelper.MGRP);
				model = new ModelAndView(MGRP);
				
				if(brand.contains("Melbourne")) {
					origin="BOM";
				}else if (brand.contains("St.George")) {
					origin="STG";
				}else if(brand.contains("BankSA")) {
					origin="BSA";
				}
				
				Logger.debug("origin**** " + origin, this.getClass());		
				
				IBankCommonData commonData=  new IBankCommonData();
				commonData.setOrigin(origin);
   		  						
				String mgrpBrand =  (String) request.getParameter("mgrpBrand");
				Logger.info("MGRP :: handleRequestInternal :: brand: " +mgrpBrand, this.getClass());
				
				if(StringUtils.isEmpty(mgrpBrand)) {
					mgrpBrand = IBankParams.STG_ORIGIN;
					Logger.info("MGRP :: handleRequestInternal :: brand set to default STG: " +mgrpBrand, this.getClass());
				}
		 	  						
				model.addObject("targetUrl", "/mb/jsp/mgrpExternal.jsp");
				model.addObject("samlHTTPPOSTBindingURL", mgrpSAMLService.getRecipientURL(mgrpBrand));
				model.addObject("SAMLResponse", mgrpSAMLService.encodeBase64(samlData));
				
				Logger.debug("SAML recepient********* " + mgrpSAMLService.getRecipientURL(mgrpBrand), this.getClass());	
				Logger.debug("SAML -  samlresponse ********** " + mgrpSAMLService.encodeBase64(samlData), this.getClass());				
				
				return model;
			}		

		} catch (BusinessException be) {
			Logger.error("BusinessException : " , be , this.getClass());
		} catch (ResourceException re) {
			Logger.error("ResourceException : " , re , this.getClass());
		} catch (Exception ex) {
			Logger.error("Exception : " , ex , this.getClass());		
		} finally {
			perfLogger.endLog(logName);
			perfLogger.endAllLogs();
			
			if(null != mbSession)
				mbSession.invalidateSession();
		}	
		return model;
	}

	
}
