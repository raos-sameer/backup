package au.com.stgeorge.mbank.model.mortgageinfo;

import java.io.Serializable;

import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.Length;
import org.hibernate.validator.constraints.Range;

import au.com.stgeorge.ibank.businessobject.BusinessException;


import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_NULL)
public class IncomeInfo  implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 9201792273718640173L;
	private static final String BLOCK_CHARS_PATTERN = "^[0-9A-Za-z',. ()&/\\-]*$";
	
	private String category;
	private String employmentType;
	private String incomeType;
	
	@Range(min=0, max=9999999, message = ""+BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE)
	@Pattern(regexp="([0-9]+[.]?[0-9]?[0-9]?)",message = ""+BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE)
	private String baseAmt;
	
	@Range(min=0, max=9999999, message = ""+BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE)
	@Pattern(regexp="([0-9]+[.]?[0-9]?[0-9]?)",message = ""+BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE)
	private String otherAmt;
	
	private String baseFrequency;
	private String otherFrequency;
	
	@Range(min=0, max=9999999, message = ""+BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE)
	@Pattern(regexp="([0-9]+[.]?[0-9]?[0-9]?)",message = ""+BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE)
	private String selfEmployedNetIncome;
	
	private String selfEmployedNetIncomeFrequency;
	
	private String empIndustry;
	private String empOccupationCode;

	@Pattern(regexp = BLOCK_CHARS_PATTERN , message = ""+BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE)
	@Length(max = 100, message = ""+BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE)
	private String employerName;
	
	private Boolean threeYrsAtCurrEmployerInd;
	
	private Integer propertyIndex;
	private Integer assetIndex; 
	
	
	private int index;
	
	
	
	public Integer getAssetIndex() {
		return assetIndex;
	}
	public void setAssetIndex(Integer assetIndex) {
		this.assetIndex = assetIndex;
	}
	public String getIncomeType() {
		return incomeType;
	}
	public void setIncomeType(String incomeType) {
		this.incomeType = incomeType;
	}
	public String getOtherFrequency() {
		return otherFrequency;
	}
	public void setOtherFrequency(String otherFrequency) {
		this.otherFrequency = otherFrequency;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public String getEmploymentType() {
		return employmentType;
	}
	public void setEmploymentType(String employmentType) {
		this.employmentType = employmentType;
	}
	public String getBaseAmt() {
		return baseAmt;
	}
	public void setBaseAmt(String baseAmt) {
		this.baseAmt = baseAmt;
	}
	public String getOtherAmt() {
		return otherAmt;
	}
	public void setOtherAmt(String otherAmt) {
		this.otherAmt = otherAmt;
	}
	public String getBaseFrequency() {
		return baseFrequency;
	}
	public void setBaseFrequency(String baseFrequency) {
		this.baseFrequency = baseFrequency;
	}
	public String getSelfEmployedNetIncome() {
		return selfEmployedNetIncome;
	}
	public void setSelfEmployedNetIncome(String selfEmployedNetIncome) {
		this.selfEmployedNetIncome = selfEmployedNetIncome;
	}
	public String getSelfEmployedNetIncomeFrequency() {
		return selfEmployedNetIncomeFrequency;
	}
	public void setSelfEmployedNetIncomeFrequency(
			String selfEmployedNetIncomeFrequency) {
		this.selfEmployedNetIncomeFrequency = selfEmployedNetIncomeFrequency;
	}

	public Integer getPropertyIndex() {
		return propertyIndex;
	}
	public void setPropertyIndex(Integer propertyIndex) {
		this.propertyIndex = propertyIndex;
	}
	public int getIndex() {
		return index;
	}
	public void setIndex(int index) {
		this.index = index;
	}
	public String getEmpIndustry() {
		return empIndustry;
	}
	public void setEmpIndustry(String empIndustry) {
		this.empIndustry = empIndustry;
	}
	public String getEmpOccupationCode() {
		return empOccupationCode;
	}
	public void setEmpOccupationCode(String empOccupationCode) {
		this.empOccupationCode = empOccupationCode;
	}
	public String getEmployerName() {
		return employerName;
	}
	public void setEmployerName(String employerName) {
		this.employerName = employerName;
	}
	public Boolean getThreeYrsAtCurrEmployerInd() {
		return threeYrsAtCurrEmployerInd;
	}
	public void setThreeYrsAtCurrEmployerInd(Boolean threeYrsAtCurrEmployerInd) {
		this.threeYrsAtCurrEmployerInd = threeYrsAtCurrEmployerInd;
	}
	
}
