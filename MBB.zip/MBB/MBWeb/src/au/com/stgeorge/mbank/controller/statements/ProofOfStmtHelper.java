package au.com.stgeorge.mbank.controller.statements;

import java.util.ArrayList;
import java.util.List;

import au.com.stgeorge.ibank.businessobject.BusinessException;
import au.com.stgeorge.ibank.valueobject.Account;
import au.com.stgeorge.mbank.model.common.ErrorInfo;
import au.com.stgeorge.mbank.model.common.IMBResp;
import au.com.stgeorge.mbank.model.common.KeyValueResp;
import au.com.stgeorge.mbank.model.response.statements.ProofOfStmtResp;
import au.com.stgeorge.mbank.util.MBAppUtils;

/**
 * @author C50216
 *
 */

public class ProofOfStmtHelper {
		
	public static String ORIGIN_ALL = "ALL";
	
	protected IMBResp populateProofOfBalanceAcctListResp(List<Account> acctList){
		
		ProofOfStmtResp resp = new ProofOfStmtResp();
		
		if(acctList != null && acctList.size() > 0){
			List<Integer> respAccountInfoList = null;
			respAccountInfoList = new ArrayList<Integer>();
			
			ArrayList <KeyValueResp> acctDetailsResp = null ; 
			acctDetailsResp =  new ArrayList <KeyValueResp> ();

			for(Account account:acctList){
				respAccountInfoList.add(account.getIndex());
				
				KeyValueResp keyResp = new KeyValueResp();
				keyResp.setId(String.valueOf(account.getIndex()));
				keyResp.setName(account.getAccountId().getProductName());
				acctDetailsResp.add(keyResp);
			}
			resp.setAccountList(respAccountInfoList);
			resp.setAccounts(acctDetailsResp);
		} else {
			List<ErrorInfo> errorList = MBAppUtils.getErrorList(ORIGIN_ALL, BusinessException.PDF_STATEMENT_NO_ELEIGIBLE_ACCOUNT, null);
			resp.setErrors(errorList);
		} 
		
		return resp;
	}
	
}
