package au.com.stgeorge.mbank.model.request.customer;

import java.io.Serializable;

import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import au.com.stgeorge.ibank.businessobject.BusinessException;
import au.com.stgeorge.mbank.model.common.IMBReq;
import au.com.stgeorge.mbank.model.common.ReqHeader;

public class AutoInitPwdSecNumReq implements IMBReq, Serializable{

	private static final long serialVersionUID = 7078868733828154446L;
	private ReqHeader header;
	
	@Size(max = 6,message = ""+BusinessException.INVALID_USERID_PASSWORD)
	@Pattern(regexp="([0-9]+)",message = ""+BusinessException.INVALID_USERID_PASSWORD)
	private String newSecNum;
	
	@Size(max = 12,message = ""+BusinessException.INVALID_USERID_PASSWORD)
	@Pattern(regexp="([a-zA-Z0-9]+)",message = ""+BusinessException.INVALID_USERID_PASSWORD)
	
	private String newPassword;
	
	private String emailAddress;
	
	private Boolean switchToEStmt;
	
	private Boolean eCorrespondenceConsent;
	
	private String actionType;


	public ReqHeader getHeader() {
		return header;
	}

	public void setHeader(ReqHeader header) {
		this.header = header;
	}

	public String getNewSecNum() {
		return newSecNum;
	}

	public void setNewSecNum(String newSecNum) {
		this.newSecNum = newSecNum;
	}

	public String getNewPassword() {
		return newPassword;
	}

	public void setNewPassword(String newPassword) {
		this.newPassword = newPassword;
	}

	public String getEmailAddress() {
		return emailAddress;
	}

	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}

	public Boolean getSwitchToEStmt() {
		return switchToEStmt;
	}

	public void setSwitchToEStmt(Boolean switchToEStmt) {
		this.switchToEStmt = switchToEStmt;
	}
	
	public Boolean geteCorrespondenceConsent() {
		return eCorrespondenceConsent;
	}

	public void seteCorrespondenceConsent(Boolean eCorrespondenceConsent) {
		this.eCorrespondenceConsent = eCorrespondenceConsent;
	}

	public String getActionType() {
		return actionType;
	}

	public void setActionType(String actionType) {
		this.actionType = actionType;
	}
	
}
