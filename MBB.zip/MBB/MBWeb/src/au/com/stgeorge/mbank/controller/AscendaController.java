package au.com.stgeorge.mbank.controller;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang.builder.ReflectionToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import au.com.stgeorge.framework.common.logging.Logger;
import au.com.stgeorge.framework.common.util.StringMethods;
import au.com.stgeorge.ibank.businessobject.AscendaService;
import au.com.stgeorge.ibank.businessobject.BusinessException;
import au.com.stgeorge.ibank.businessobject.ResourceException;
import au.com.stgeorge.ibank.businessobject.StatisticsService;
import au.com.stgeorge.ibank.businessobject.impl.AscendaServiceHelper;
import au.com.stgeorge.ibank.businessobject.wdp.WDPConstants;
import au.com.stgeorge.ibank.common.cache.IBankParams;
import au.com.stgeorge.ibank.common.cache.IBankRefershParams;
import au.com.stgeorge.ibank.util.ServiceHelper;
import au.com.stgeorge.ibank.valueobject.Account;
import au.com.stgeorge.ibank.valueobject.SAMLStore;
import au.com.stgeorge.ibank.valueobject.Statistic;
import au.com.stgeorge.ibank.valueobject.database.CodesVO;
import au.com.stgeorge.ibank.valueobject.transfer.IBankCommonData;
import au.com.stgeorge.mbank.controller.customer.LogonHelper;
import au.com.stgeorge.mbank.model.common.IMBReq;
import au.com.stgeorge.mbank.model.common.IMBResp;
import au.com.stgeorge.mbank.model.common.ReqHeader;
import au.com.stgeorge.mbank.model.common.RespHeader;
import au.com.stgeorge.mbank.model.request.AscendaReq;
import au.com.stgeorge.mbank.model.request.PushAscendaContextInfoReq;
import au.com.stgeorge.mbank.model.response.AscendaResponse;
import au.com.stgeorge.mbank.model.response.ErrorResp;
import au.com.stgeorge.mbank.model.response.PushAscendaContextInfoResp;
import au.com.stgeorge.mbank.session.MobileSession;
import au.com.stgeorge.mbank.session.MobileSessionImpl;
import au.com.stgeorge.mbank.util.MBAppHelper;
import au.com.stgeorge.mbank.util.MBAppUtils;
import au.com.stgeorge.mbank.util.MBAppValidator;
import au.com.stgeorge.mbank.util.ServiceConstants;
import au.com.stgeorge.perflogger.PerformanceLogger;

/**
 * Ascenda controller
 * 
 */
@Controller
@RequestMapping("/ascenda")
public class AscendaController implements IMBController {
	
	@Autowired
	private MBAppValidator mbAppValidator;
	
	@Autowired
	private MBAppHelper mbAppHelper;
    
    @Autowired
	private PerformanceLogger perfLogger;
    
	@Autowired
	private AscendaService ascendaService;

	@Autowired
	private LogonHelper logonHelper;
    
	@RequestMapping(method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE, value = "checkEligibilityForMFR")
	@ResponseBody
	public IMBResp getEligibityForServicesMenu(HttpServletRequest httpRequest, @RequestBody final AscendaReq request) {
		Logger.debug("AscendaController - getEligibityForServicesMenu. Request: " + request, this.getClass());
		String logName = startPerformanceLog(httpRequest);
		MobileSession mobileSession = new MobileSessionImpl();
		AscendaResponse resp = null;
		boolean isSuccess=false;
		Boolean ageEligible=false;
		Boolean productEligible=false;
		String clientId=null,redirectUri=null,issuerURI=null,scope=null,authorityURI=null,authorizationEndpoint=null,jwksURI=null,tokenEndpoint=null,offersUri=null;
		List<Boolean> eligibleItems=new ArrayList<Boolean>();
		
		CodesVO codeItem=null;
		String launchPoint=null;

		try {
			mobileSession.getSessionContext(httpRequest);
			validateRequestHeader(request.getHeader(), httpRequest);
			ErrorResp errorResponse = validate(request, httpRequest);
			if (errorResponse.hasErrors())
			{
				return errorResponse;
			}
			
			IBankCommonData commonData = mbAppHelper.populateIBankCommonData(mobileSession, httpRequest);
			int accountIndex=request.getAccountIndex();
			
			if(request.getLaunchPoint().equals("GlobalServicesMenu"))
				launchPoint= "Global Services Menu";
			else if (request.getLaunchPoint().equals("AccountDetailsServiceMenu"))
					launchPoint="Account Details Service Menu";
			else launchPoint= "NBA Tile";
			List<Account> accountList=commonData.getCustomer().getAccounts();
			
			String accountNumber=accountList.get(accountIndex).getAccountId().getAccountNumber();

			Logger.debug("AscendaController - account number >>" + accountNumber, this.getClass());
			IBankRefershParams iBankRefreshParams = (IBankRefershParams) ServiceHelper.getBean("ibankRefreshParams");
			
			boolean ascendaSwitch = iBankRefreshParams.isAscendaSwitchON();
			if(ascendaSwitch){
				if(null!=request)
				{
							Logger.debug("AscendaController - inside check eligibility ", this.getClass());
							eligibleItems=ascendaService.getEligibility(commonData.getCustomer(),accountNumber,request.getLaunchPoint());
							if(null!=eligibleItems) {
								ageEligible=eligibleItems.get(0);
								productEligible=eligibleItems.get(1);
								Logger.debug("AscendaController - ageEligible> "+ageEligible, this.getClass());
								Logger.debug("AscendaController - productEligible> "+productEligible, this.getClass());
							}
				}
							
							
			   codeItem=IBankParams.getCodesData(IBankParams.getBaseOriginCode( commonData.getOrigin()) , IBankParams.FEATURES,IBankParams.ASCENDA_CLIENT_ID);
				if ( codeItem != null && ! StringMethods.isEmptyString(codeItem.getMessage()))
				{
					clientId=codeItem.getMessage();
					Logger.debug("AscendaController - clientId " + clientId, this.getClass());
				}
				
				codeItem=IBankParams.getCodesData(IBankParams.getBaseOriginCode( commonData.getOrigin()) , IBankParams.FEATURES,IBankParams.ASCENDA_MB_REDIRECT_URI);
				if ( codeItem != null && ! StringMethods.isEmptyString(codeItem.getMessage()))
				{
					redirectUri=codeItem.getMessage();
					Logger.debug("AscendaController - redirectUri " + redirectUri, this.getClass());
				}
				
				
				codeItem=IBankParams.getCodesData(IBankParams.getBaseOriginCode( commonData.getOrigin()) , IBankParams.FEATURES,IBankParams.ASCENDA_ISSUER_URI);
				if ( codeItem != null && ! StringMethods.isEmptyString(codeItem.getMessage()))
				{
					issuerURI=codeItem.getMessage();
					Logger.debug("AscendaController - issuerURI " + issuerURI, this.getClass());
				}
				
				codeItem=IBankParams.getCodesData(IBankParams.getBaseOriginCode( commonData.getOrigin()) , IBankParams.ASCENDA_CATEGORY,IBankParams.ASCENDA_SCOPE);
				if ( codeItem != null && ! StringMethods.isEmptyString(codeItem.getMessage()))
				{
					scope=codeItem.getMessage();
					Logger.debug("AscendaController - scope " + scope, this.getClass());
				}
				
				codeItem=IBankParams.getCodesData(IBankParams.getBaseOriginCode( commonData.getOrigin()) , IBankParams.FEATURES,IBankParams.ASCENDA_AUTHORITY_URI);
				if ( codeItem != null && ! StringMethods.isEmptyString(codeItem.getMessage()))
				{
					authorityURI=codeItem.getMessage();
					Logger.debug("AscendaController - authorityURI " + authorityURI, this.getClass());
				}
				
				codeItem=IBankParams.getCodesData(IBankParams.getBaseOriginCode( commonData.getOrigin()) , IBankParams.FEATURES,IBankParams.ASCENDA_AUTHORIZATION_ENDPOINT_URI);
				if ( codeItem != null && ! StringMethods.isEmptyString(codeItem.getMessage()))
				{
					authorizationEndpoint=codeItem.getMessage();
					Logger.debug("AscendaController - authorizationEndpoint " + authorizationEndpoint, this.getClass());
				} 
				
				codeItem=IBankParams.getCodesData(IBankParams.getBaseOriginCode( commonData.getOrigin()) , IBankParams.FEATURES,IBankParams.ASCENDA_JWKS_URI);
				if ( codeItem != null && ! StringMethods.isEmptyString(codeItem.getMessage()))
				{
					jwksURI=codeItem.getMessage();
					Logger.debug("AscendaController - jwksURI " + jwksURI, this.getClass());
				}
				
				codeItem=IBankParams.getCodesData(IBankParams.getBaseOriginCode( commonData.getOrigin()) , IBankParams.FEATURES,IBankParams.ASCENDA_TOKEN_URI);
				if ( codeItem != null && ! StringMethods.isEmptyString(codeItem.getMessage()))
				{
					tokenEndpoint=codeItem.getMessage();
					Logger.debug("AscendaController - tokenEndpoint " + tokenEndpoint, this.getClass());
				}
				
				codeItem=IBankParams.getCodesData(IBankParams.getBaseOriginCode( commonData.getOrigin()) , IBankParams.FEATURES,IBankParams.ASCENDA_OFFERS_URI);
				if ( codeItem != null && ! StringMethods.isEmptyString(codeItem.getMessage()))
				{
					offersUri=codeItem.getMessage();
					Logger.debug("AscendaController - offersUri " + offersUri, this.getClass());
				}
			}
			isSuccess=true;
			resp = populateAscendaResponse(populateResponseHeader(ServiceConstants.EXTERNAL_VENDOR, mobileSession),isSuccess,productEligible, ageEligible, clientId,redirectUri,issuerURI,scope,authorityURI,authorizationEndpoint,jwksURI,tokenEndpoint, offersUri);
            String action="MFRENT";
            setStatisticGDWLog(commonData,action,launchPoint);
			return resp;
			
		} catch (BusinessException e) {
			Logger.error("BusinessException in AscendaController - getEligibityForServicesMenu - [key: " + e.getKey() + "] : GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), e, ServiceConstants.EXTERNAL_VENDOR, httpRequest);
		} catch (ResourceException e) {
			Logger.error("ResourceException in AscendaController - getEligibityForServicesMenu - [key: " + e.getKey() + "] : GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.SYSTEM_UNAVILABLE, ServiceConstants.EXTERNAL_VENDOR, httpRequest);
		} catch (Exception e) {
			Logger.error("Exception AscendaController - getEligibityForServicesMenu: GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), ResourceException.MOBILE_NON_FINANCIAL_FATAL_ERR, ServiceConstants.EXTERNAL_VENDOR, httpRequest);
		} finally {
			endPerformanceLog(logName);
		}
	}
	
	@RequestMapping(method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE, value = "pushAscendaContextInfo")
	@ResponseBody
	public IMBResp pushAscendaContextInfo(HttpServletRequest httpRequest, @RequestBody final PushAscendaContextInfoReq request) {
		Logger.debug("AscendaController - pushAscendaContextInfo. Request: " + request, this.getClass());
		String logName = startPerformanceLog(httpRequest);
		MobileSession mobileSession = new MobileSessionImpl();
		PushAscendaContextInfoResp resp = null;

		try {
			validateRequestHeader(request.getHeader(), httpRequest);
			ErrorResp errorResponse = validate(request, httpRequest);
			if (errorResponse.hasErrors())
			{
				return errorResponse;
			}
			
			mobileSession = mbAppHelper.getMobileSession(httpRequest);
			IBankCommonData commonData = mbAppHelper.populateIBankCommonData(mobileSession, httpRequest);
			
			//will always be constant
			String referrer = WDPConstants.ASCENDA_PUSH_CONTEXT_INFO_APP_ID;
			
			//try {
				if(commonData!=null  && commonData.getCustomer()!=null && commonData.getCustomer().getPreference()!=null) {
					Logger.info("Old ppid ::::::"+ commonData.getCustomer().getPreference().getPpidAscenda()+"  for gcis "+commonData.getCustomer().getGcis(), this.getClass());
				}
				ascendaService.updatePPIDPreference(commonData, request.getPpId());
				//mobileSession.setCustomer(commonData.getCustomer());
				if(commonData!=null  && commonData.getCustomer()!=null && commonData.getCustomer().getPreference()!=null) {
					Logger.info("Updated ppid ::::::"+ commonData.getCustomer().getPreference().getPpidAscenda()+" for gcis "+commonData.getCustomer().getGcis(), this.getClass());
				}
			/*}
			catch(Exception e) {
				//throw e;
				Logger.error("Error in updating preference",e,this.getClass());
			}
			*/
			
			String reference = ascendaService.pushAscendaContextInfo(WDPConstants.ASCENDA_PUSH_CONTEXT_INFO_APP_ID, commonData, referrer, request.getPpId());
			
			boolean isMobileApp = ((logonHelper.loadCordova(httpRequest)) == -1)? false:true;
			
			//save reference in DB
			if(null != reference && isMobileApp) {
				SAMLStore samlStore = new SAMLStore();
				samlStore.setToken(reference);
				samlStore.setCreatedBy(mobileSession.getUser().getUserId());
				samlStore.setCreatedOn(new Date());
				samlStore.setGcisNumber(mobileSession.getCustomer().getGcis());
				samlStore.setSamlData(request.getIdToken());
				samlStore.setFeature(AscendaServiceHelper.ASCENDA);
				ascendaService.addIDTokenToStore(samlStore);
			}
			String action="MFRLNC";
			String launchPoint=null;
			if(request.getLaunchPoint().equals("GlobalServicesMenu"))
				launchPoint="Global Services Menu";
			else if(request.getLaunchPoint().equals("AccountDetailsServiceMenu"))
				launchPoint="Account Details Service Menu";
			else launchPoint= "NBA Tile";
			String desc="EntryPoint: "+launchPoint+ " ;  PPID:" +request.getPpId();
			setStatisticGDWLog(commonData,action,desc);
			resp = populateAscendaContextInfoResp(populateResponseHeader(ServiceConstants.EXTERNAL_VENDOR, mobileSession), AscendaServiceHelper.getAscendaRedirectURL(commonData.getOrigin()), reference);
			
			return resp;
			
		} catch (BusinessException e) {
			Logger.error("BusinessException in AscendaController - pushAscendaContextInfo - [key: " + e.getKey() + "] : GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), e, ServiceConstants.EXTERNAL_VENDOR, httpRequest);
		} catch (ResourceException e) {
			Logger.error("ResourceException in AscendaController - pushAscendaContextInfo - [key: " + e.getKey() + "] : GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.SYSTEM_UNAVILABLE, ServiceConstants.EXTERNAL_VENDOR, httpRequest);
		} catch (Exception e) {
			Logger.error("Exception AscendaController - pushAscendaContextInfo: GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), ResourceException.MOBILE_NON_FINANCIAL_FATAL_ERR, ServiceConstants.EXTERNAL_VENDOR, httpRequest);
		} finally {
			endPerformanceLog(logName);
		}
	}	
	
    public ErrorResp validate(IMBReq serviceRequest, HttpServletRequest request) {
		Logger.debug("Service request object - " + ReflectionToStringBuilder.toString(serviceRequest), this.getClass());
		return mbAppValidator.validate(serviceRequest, request);
	}

	public RespHeader populateResponseHeader(String serviceName, MobileSession mobSession) {
		return mbAppHelper.populateResponseHeader(serviceName, mobSession);
	}
	
	public void validateRequestHeader(ReqHeader headerReq, HttpServletRequest request) throws BusinessException {
		Logger.debug("Request header validation: " + ReflectionToStringBuilder.toString(headerReq, ToStringStyle.MULTI_LINE_STYLE), this.getClass());
		new MBAppValidator().validateRequestHeader(headerReq, request);
	}
	
	private String startPerformanceLog(HttpServletRequest httpRequest){
		perfLogger.startAllLogs();
		String logName = MBAppUtils.getLogName(httpRequest);
		perfLogger.startLog(logName);
		return logName;
	}
	
	private void endPerformanceLog(String logName){
		perfLogger.endLog(logName);
		perfLogger.endAllLogs();
	}
	
	
    private AscendaResponse populateAscendaResponse(RespHeader header, boolean isSuccess,boolean productEligible, boolean ageEligble, String clientId, String redirectUri,String issuerURI,String scope,String authorityURI,String authorizationEndpoint,String jwksURI,String tokenEndpoint, String offersUri) {
    	AscendaResponse ascendaResp = new AscendaResponse(header);
    	
    	ascendaResp.setIsSuccess(isSuccess);
    	ascendaResp.setClientId(clientId);
    	
    	ascendaResp.setRedirectUri(redirectUri);
    	ascendaResp.setIssuerURI(issuerURI);
    	ascendaResp.setScope(scope);
    	ascendaResp.setAuthorityURI(authorityURI);
    	ascendaResp.setAuthorizationEndpoint(authorizationEndpoint);
    	ascendaResp.setJwksURI(jwksURI);
    	ascendaResp.setTokenEndpoint(tokenEndpoint);
    	ascendaResp.setProductEligible(productEligible);
    	ascendaResp.setAgeEligible(ageEligble);
    	ascendaResp.setMyOffersURI(offersUri);
		return ascendaResp;
		
	}
    
    private PushAscendaContextInfoResp populateAscendaContextInfoResp(RespHeader header, String redirectUri, String reference) {
    	
    	PushAscendaContextInfoResp ascendaResp = new PushAscendaContextInfoResp();
    	
    	ascendaResp.setHeader(header);
    	ascendaResp.setRedirectUrl(redirectUri);
    	ascendaResp.setReferenceId(reference);
    	
		return ascendaResp;
		
	}
    public void setStatisticGDWLog(IBankCommonData commonData,String action,String desc) {
        try {
            Statistic statistic = new Statistic();

            statistic.setGcisNumber(commonData.getCustomer().getGcis());
            statistic.setAction(action);
            statistic.setOriginBank(commonData.getOrigin());
            statistic.setGDWOriginBank(commonData.getGdwOrigin());
            statistic.setDescription(desc);
            statistic.setSessionId(commonData.getSessionId());
            statistic.setIpAddress(commonData.getIpAddress());

            StatisticsService.logStatistic(statistic);
        } catch (Exception e) {
            Logger.debug("AscendaController Unable to create statistic entry for GCIS "
                    + commonData.getUser().getGCISNumber(), e, this.getClass());

        }
    }
}

