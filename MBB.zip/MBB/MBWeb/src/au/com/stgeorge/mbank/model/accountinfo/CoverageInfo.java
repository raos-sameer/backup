package au.com.stgeorge.mbank.model.accountinfo;

import java.util.List;

import au.com.stgeorge.mbank.model.common.AddressResp;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_NULL)
public class CoverageInfo{

	private String coverageName;
	private List<SumInsuredInfo> insuredList;
	private String insType;
	private CarInfo carDetails;
	private AddressResp  riskAddress;
	
	public String getCoverageName() {
		return coverageName;
	}
	public void setCoverageName(String coverageName) {
		this.coverageName = coverageName;
	}
	public List<SumInsuredInfo> getInsuredList() {
		return insuredList;
	}
	public void setInsuredList(List<SumInsuredInfo> insuredList) {
		this.insuredList = insuredList;
	}
	public String getInsType() {
		return insType;
	}
	public void setInsType(String insType) {
		this.insType = insType;
	}
	public CarInfo getCarDetails() {
		return carDetails;
	}
	public void setCarDetails(CarInfo carDetails) {
		this.carDetails = carDetails;
	}
	public AddressResp getRiskAddress() {
		return riskAddress;
	}
	public void setRiskAddress(AddressResp riskAddress) {
		this.riskAddress = riskAddress;
	}
	
	
}
