package au.com.stgeorge.mbank.controller.offers;

import java.io.IOException;
import java.io.PrintWriter;
import java.net.URLEncoder;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;

import au.com.stgeorge.framework.common.logging.Logger;
import au.com.stgeorge.framework.common.util.StringMethods;
import au.com.stgeorge.ibank.businessobject.BusinessException;
import au.com.stgeorge.ibank.businessobject.InsuranceService;
import au.com.stgeorge.ibank.businessobject.OfferService;
import au.com.stgeorge.ibank.businessobject.ResourceException;
import au.com.stgeorge.ibank.common.cache.IBankParams;
import au.com.stgeorge.ibank.service.valueobject.OfferDetails;
import au.com.stgeorge.ibank.util.ServiceHelper;
import au.com.stgeorge.ibank.valueobject.Customer;
import au.com.stgeorge.ibank.valueobject.Invitation;
import au.com.stgeorge.ibank.valueobject.LeadDetails;
import au.com.stgeorge.ibank.valueobject.database.OriginsVO;
import au.com.stgeorge.ibank.valueobject.transfer.IBankCommonData;
import au.com.stgeorge.mbank.controller.IMBController;
import au.com.stgeorge.mbank.model.common.IMBReq;
import au.com.stgeorge.mbank.model.common.IMBResp;
import au.com.stgeorge.mbank.model.common.ReqHeader;
import au.com.stgeorge.mbank.model.common.RespHeader;
import au.com.stgeorge.mbank.model.request.EmptyReq;
import au.com.stgeorge.mbank.model.request.offers.ExternalLinkReq;
import au.com.stgeorge.mbank.model.request.offers.SalesOfferAemReq;
import au.com.stgeorge.mbank.model.request.offers.SalesOfferReq;
import au.com.stgeorge.mbank.model.response.ErrorResp;
import au.com.stgeorge.mbank.model.response.offers.OfferTeaserResp;
import au.com.stgeorge.mbank.session.MobileSession;
import au.com.stgeorge.mbank.session.MobileSessionImpl;
import au.com.stgeorge.mbank.util.MBAppHelper;
import au.com.stgeorge.mbank.util.MBAppUtils;
import au.com.stgeorge.mbank.util.MBAppValidator;
import au.com.stgeorge.mbank.util.ServiceConstants;
import au.com.stgeorge.mobilebank.businessobject.ExternalLinkService;
import au.com.stgeorge.perflogger.PerformanceLogger;

import com.fasterxml.jackson.databind.ObjectMapper;

@Controller
@RequestMapping("/salesoffer")
public class SalesOfferController  implements IMBController{
		
	@Autowired
	private OfferService offerService;
	
	@Autowired
	private SalesOfferHelper salesOfferHelper;
	
	@Autowired
	private MBAppHelper mbAppHelper;
	
	@Autowired
	private MBAppValidator mbAppValidator;
	
	@Autowired
	private PerformanceLogger perfLogger;
	
	@Autowired
	private InsuranceService insuranceService;

	
	
	@RequestMapping(value = "detail", method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public void processOfferContent(HttpServletRequest httpServletRequest,HttpServletResponse httpServletResponse,
			@RequestBody final SalesOfferReq req) { 
				
		ObjectMapper objectMapper = new ObjectMapper();										
		
		perfLogger.startAllLogs();
		String logName = MBAppUtils.getLogName(httpServletRequest);
		perfLogger.startLog(logName);					
		String offerContent = "";
		PrintWriter out = null;	
		MobileSession mbSession = null;
		try{			
			mbSession = mbAppHelper.getMobileSession(httpServletRequest);
			httpServletResponse.setContentType("text/html");
			out = httpServletResponse.getWriter();
			Logger.info("Message Content JSON Request :" + objectMapper.writeValueAsString(req), this.getClass());
			ErrorResp errorResp = validate(req, httpServletRequest);
					
			if (errorResp != null && errorResp.getErrors() != null && errorResp.getErrors().size() > 0)
			{				
				//fraudLogger.logInvalidInput();				
				out.print("{} && " + objectMapper.writeValueAsString(errorResp));				
			}else{
				
//				if (!HeartBeat
//						.isApplicationAvailable(HeartBeat.FIREFLY_APPLICATION_ID)) {
//					throw new BusinessException(BusinessException.MC_MSG_CNTR_UNAVAILABLE);
//				}
								
				Customer customer = mbSession.getCustomer();
								
				IBankCommonData commonData=mbAppHelper.populateIBankCommonData(mbSession,httpServletRequest);
				
				Invitation invitation = offerService.getOffer(commonData, req.getLeadId(), mbSession.getOrigin());
						
				OfferDetails offerDetails = new OfferDetails();
				if(invitation.getOfferEndDate()!=null){
					offerDetails.setExpiryDate(invitation.getOfferEndDate());
				}
				//offerDetails.setExpiryDate(new Date()); Hardcoded value TODO
				
				mbSession.setOfferDetails(offerDetails);
				
				offerContent = URLEncoder.encode(invitation.getTemplateContent());//ISG : Sanitise offer content before sending it to mobile
				
				Logger.info("Offer Content text Response :" + offerContent ,this.getClass());			
				out.print(offerContent);
				if(invitation.isOfferApplied()){
					// redirect to the new page showing an existing offer has already been applied
					throw new BusinessException(BusinessException.RETENTION_CUSTOM_ERROR);//TODO need to change to RETENTION_CUSTOM_ERROR
				}
			}
							
		}catch (BusinessException e)
		{
			Logger.info("BusinessException Inside processOfferContent() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			BusinessException exp = new BusinessException(e.getKey());
			//17E2 Change: If case of any exception in Personalizing the data, need to show new error message in Offer details page with phone number.
			//IMBResp resp1  = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, ServiceConstants.OFFER_DETAIL_SERVICE, httpServletRequest);
			IMBResp resp1 = null;
			if(e.getKey() == BusinessException.MYINVITATION_INVALID_OFFER)
			{
				OriginsVO myOriginVO  = IBankParams.getOrigin(mbSession.getOrigin());
				OriginsVO baseOrigin  = IBankParams.getOrigin(myOriginVO.getBankName());
				String[] values = {baseOrigin.getPhone()};	
				resp1  = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, values, ServiceConstants.OFFER_DETAIL_SERVICE, httpServletRequest);
			}
			else if(BusinessException.RETENTION_CUSTOM_ERROR == e.getKey() 
	    			|| BusinessException.RETENTION_SAVINGS_ACCEPT_FAILED == e.getKey()){
				OriginsVO myOriginVO  = IBankParams.getOrigin(mbSession.getOrigin());
				OriginsVO baseOrigin  = IBankParams.getOrigin(myOriginVO.getBankName());
				String[] values = {baseOrigin.getPhone()};	
				resp1  = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp,values,ServiceConstants.OFFER_DETAIL_SERVICE, httpServletRequest);
	    	}
			else{
				
				resp1  = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, ServiceConstants.OFFER_DETAIL_SERVICE, httpServletRequest);
			}
			try {
				Logger.info(e.getMessage(), this.getClass());	
				if(BusinessException.RETENTION_CUSTOM_ERROR == e.getKey() 
		    			|| BusinessException.RETENTION_SAVINGS_ACCEPT_FAILED == e.getKey()){
					//objectMapper.configure(org.codehaus.jackson.JsonParser.Feature.ALLOW_SINGLE_QUOTES, true);
					out.print(objectMapper.writeValueAsString(resp1).replace("'", "\'"));
				
				}
				else{
					out.print("{} && " + objectMapper.writeValueAsString(resp1));
				}
			}catch (IOException e1) {
				Logger.info("IOException: "+e1.getMessage(), this.getClass());	
			}
						
		}catch (ResourceException e){
			Logger.error("ResourceException Inside processOfferContent() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			ResourceException exp = new ResourceException(e.getKey());
			IMBResp resp1  = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, ServiceConstants.OFFER_DETAIL_SERVICE, httpServletRequest);
			try {
				Logger.error(e.getMessage(), this.getClass());					
				out.print("{} && " + objectMapper.writeValueAsString(resp1));
			}catch (IOException e1) {
				Logger.error(e1.getMessage(), this.getClass());	
			}					
		} catch (Exception e)
		{
			Logger.error("Exception Inside processOfferContent() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			BusinessException exp = new BusinessException(BusinessException.GENERIC_ERROR);
			IMBResp resp1  = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, ServiceConstants.OFFER_DETAIL_SERVICE, httpServletRequest);			
			try {
				Logger.error("Exception Inside processOfferContent():"+e.getMessage(), this.getClass());				
				out.print("{} && " + objectMapper.writeValueAsString(resp1));
			}catch (IOException e1) {
				Logger.error("IOException Inside processOfferContent():"+e1.getMessage(), this.getClass());	
			}
			
		} finally
		{
			perfLogger.endLog(logName);
			perfLogger.endAllLogs();
		}						
	}	
	
	@RequestMapping(value = "tnc", method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public void processOfferTnC(HttpServletRequest httpServletRequest,HttpServletResponse httpServletResponse,
			@RequestBody final SalesOfferReq req) { 
				
		ObjectMapper objectMapper = new ObjectMapper();										
		
		perfLogger.startAllLogs();
		String logName = MBAppUtils.getLogName(httpServletRequest);
		perfLogger.startLog(logName);					
		String offerTnCContent = "";
		PrintWriter out = null;	
		MobileSession mbSession = null;
		try{			
			mbSession = mbAppHelper.getMobileSession(httpServletRequest);
			httpServletResponse.setContentType("text/html");
			out = httpServletResponse.getWriter();
			Logger.info("Offer TnC Content JSON Request :" + objectMapper.writeValueAsString(req), this.getClass());
			ErrorResp errorResp = validate(req, httpServletRequest);
					
			if (errorResp != null && errorResp.getErrors() != null && errorResp.getErrors().size() > 0)
			{				
				//fraudLogger.logInvalidInput();				
				out.print("{} && " + objectMapper.writeValueAsString(errorResp));				
			}else{
				
//				if (!HeartBeat
//						.isApplicationAvailable(HeartBeat.FIREFLY_APPLICATION_ID)) {
//					throw new BusinessException(BusinessException.MC_MSG_CNTR_UNAVAILABLE);
//				}
								
				Customer customer = mbSession.getCustomer();
								
				IBankCommonData commonData=mbAppHelper.populateIBankCommonData(mbSession,httpServletRequest);
				
				Invitation invitation = offerService.getOffer(commonData, req.getLeadId(), mbSession.getOrigin());
											
				offerTnCContent = URLEncoder.encode(invitation.getTcContent());//ISG : Sanitise offer content before sending it to mobile
				
				Logger.info("Offer tnc Content text Response :" + offerTnCContent ,this.getClass());			
				out.print(offerTnCContent);
			}
							
		}catch (BusinessException e)
		{
			Logger.info("BusinessException Inside processOfferTnC() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			BusinessException exp = new BusinessException(e.getKey());
			//17E2 Change: If case of any exception in Personalizing the data, need to show new error message in Offer details page with phone number.
			//IMBResp resp1  = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, ServiceConstants.OFFER_TNC_SERVICE, httpServletRequest);
			IMBResp resp1 = null;
			if(e.getKey() == BusinessException.MYINVITATION_INVALID_OFFER)
			{
				OriginsVO myOriginVO  = IBankParams.getOrigin(mbSession.getOrigin());
				OriginsVO baseOrigin  = IBankParams.getOrigin(myOriginVO.getBankName());
				String[] values = {baseOrigin.getPhone()};	
				resp1  = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, values, ServiceConstants.OFFER_TNC_SERVICE, httpServletRequest);
			}
			else{
				
				resp1  = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, ServiceConstants.OFFER_TNC_SERVICE, httpServletRequest);
			}
			try {
				Logger.info("BusinessException Inside processOfferTnC():"+e.getMessage(), this.getClass());					
				out.print("{} && " + objectMapper.writeValueAsString(resp1));
			}catch (IOException e1) {
				Logger.info("BusinessException Inside processOfferTnC():"+e1.getMessage(), this.getClass());	
			}
						
		}catch (ResourceException e){
			Logger.error("ResourceException Inside processOfferTnC() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			ResourceException exp = new ResourceException(e.getKey());
			IMBResp resp1  = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, ServiceConstants.OFFER_TNC_SERVICE, httpServletRequest);
			try {
				Logger.error("ResourceException Inside processOfferTnC():"+e.getMessage(),this.getClass());			
				out.print("{} && " + objectMapper.writeValueAsString(resp1));
			}catch (IOException e1) {
				Logger.error("IOException Inside processOfferTnC():"+e1.getMessage(),this.getClass());		
			}					
		} catch (Exception e)
		{
			Logger.error("Exception Inside processOfferTnC() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			BusinessException exp = new BusinessException(BusinessException.GENERIC_ERROR);
			IMBResp resp1  = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, ServiceConstants.OFFER_TNC_SERVICE, httpServletRequest);			
			try {
				Logger.error(e.getMessage(),this.getClass());				
				out.print("{} && " + objectMapper.writeValueAsString(resp1));
			}catch (IOException e1) {
				Logger.error(e1.getMessage(),this.getClass());
			}
			
		} finally
		{
			perfLogger.endLog(logName);
			perfLogger.endAllLogs();
		}						
	}
	
	@RequestMapping(value= "teaser" , method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public IMBResp processTeaser(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse,
			@RequestBody final EmptyReq req)
	{				
				
		ObjectMapper objectMapper = new ObjectMapper();								
		perfLogger.startAllLogs();
		String logName = MBAppUtils.getLogName(httpServletRequest);
		perfLogger.startLog(logName);
				
		MobileSession mbSession = null;
		try{	
			
			mbSession = mbAppHelper.getMobileSession(httpServletRequest);		
			Logger.info("processTeaser JSON Request :" + objectMapper.writeValueAsString(req), this.getClass());
			validateRequestHeader(req.getHeader(), httpServletRequest);
			ErrorResp errorResp = validate(req, httpServletRequest);
			if (errorResp != null && errorResp.getErrors() != null && errorResp.getErrors().size() > 0)
			{				
				//fraudLogger.logInvalidInput();
				return errorResp;
			}			
																						
			Customer customer=mbSession.getCustomer();		
			String insertionPoint = IBankParams.IB_DASHBOARD_INS_PT_NAME; // Added for MyInvitations : Additional Insertion Points									
			IBankCommonData commonData=mbAppHelper.populateIBankCommonData(mbSession,httpServletRequest);
			Invitation invitation = offerService.getLeadDetails(commonData,insertionPoint);
			customer.setInvitation(invitation);
							
			IMBResp serviceResponse = salesOfferHelper.populateNextTeaserResp(customer);
									
			RespHeader headerResp = populateResponseHeader(ServiceConstants.PROCESS_NEXT_OFFER_TEASER, mbSession);
			serviceResponse.setHeader(headerResp);
			
			Logger.info("processTeaser JSON Response :" + objectMapper.writeValueAsString(serviceResponse), this.getClass());
			
			return serviceResponse;		
		}catch (BusinessException e)
		{
			BusinessException exp = null;
			Logger.info("BusinessException Inside processTeaser() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "]", e, this.getClass());		
			exp = new BusinessException(BusinessException.SYSTEM_UNAVILABLE);
			IMBResp resp1  = MBAppUtils.createErrorResp(mbSession.getOrigin() ,exp, ServiceConstants.PROCESS_NEXT_OFFER_TEASER, httpServletRequest);
			return resp1;
		}catch (ResourceException e) {
			Logger.error("ResourceException Inside processTeaser() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "]", e, this.getClass());			
			ResourceException exp = new ResourceException(BusinessException.SYSTEM_UNAVILABLE);
			IMBResp resp1  = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, ServiceConstants.PROCESS_NEXT_OFFER_TEASER, httpServletRequest);
			return resp1;
		}catch (Exception e)
		{			
			Logger.error("Exception Inside processTeaser() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "]", e, this.getClass());
			BusinessException exp = new BusinessException(BusinessException.SYSTEM_UNAVILABLE);
			IMBResp resp1  = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, ServiceConstants.PROCESS_NEXT_OFFER_TEASER, httpServletRequest);
			return resp1;
		} finally
		{
			perfLogger.endLog(logName);
			perfLogger.endAllLogs();
		}				
	}
	
	@RequestMapping(value = "data", method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public IMBResp processOfferDDA(HttpServletRequest httpServletRequest,HttpServletResponse httpServletResponse,@RequestBody final SalesOfferReq req)
	{ 				
		ObjectMapper objectMapper = new ObjectMapper();	
		perfLogger.startAllLogs();
		String logName = MBAppUtils.getLogName(httpServletRequest);
		perfLogger.startLog(logName);	
		MobileSession mbSession = null;
		IMBResp serviceResponse=null;
		
		//String offerContent = "";
		PrintWriter out = null;
		
		try
		{			
			mbSession = mbAppHelper.getMobileSession(httpServletRequest);
			IBankCommonData commonData=mbAppHelper.populateIBankCommonData(mbSession,httpServletRequest);
			Customer customer=mbSession.getCustomer();
			Logger.info("processOfferDDA JSON Request :" + objectMapper.writeValueAsString(req), this.getClass());
			validateRequestHeader(req.getHeader(), httpServletRequest);
			ErrorResp errorResp = validate(req, httpServletRequest);
			if (errorResp != null && errorResp.getErrors() != null && errorResp.getErrors().size() > 0)
			{
				return errorResp;
			}			
			
			else
			{
				if(!IBankParams.isMyInvInsPtSwitchON(commonData.getOrigin()))
				{
					throw new BusinessException(BusinessException.DEEPLINK_ERROR_MSG);
				}
				else
				{			
					Invitation invitation = offerService.getOfferDeeplink(commonData, req.getLeadId(), mbSession.getOrigin());
					
					OfferDetails offerDetails = new OfferDetails();
					if(invitation.getOfferEndDate()!=null){
						offerDetails.setExpiryDate(invitation.getOfferEndDate());
					}
					//offerDetails.setExpiryDate(new Date()); Hardcoded value TODO
					
					mbSession.setOfferDetails(offerDetails);
					
					//offerContent = URLEncoder.encode(invitation.getTemplateContent());//ISG : Sanitise offer content before sending it to mobile
					
					/*Logger.info("Offer Content text Response :" + offerContent ,this.getClass());			
					out.print(offerContent);*/
					if(invitation.isOfferApplied()){
						// redirect to the new page showing an existing offer has already been applied
						throw new BusinessException(BusinessException.RETENTION_CUSTOM_ERROR);//TODO need to change to RETENTION_CUSTOM_ERROR
					}
					
					
					customer.setInvitation(invitation);
					serviceResponse = salesOfferHelper.populateOfferDeepLink(customer);
					
					RespHeader headerResp = populateResponseHeader(ServiceConstants.OFFER_DETAIL_DDA_DEEPLINK, mbSession); //
					serviceResponse.setHeader(headerResp);
					
					Logger.info("processOfferDDA JSON Response :" + objectMapper.writeValueAsString(serviceResponse), this.getClass());	
				}
				
			
			}
			return serviceResponse;	
		}
		catch (BusinessException e)
		{
			Logger.info("BusinessException Inside processOfferDDA() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			BusinessException exp = new BusinessException(e.getKey());
			IMBResp resp1 = null;
			if(e.getKey() == BusinessException.DEEPLINK_ERROR_MSG){
			  resp1  = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, ServiceConstants.OFFER_DETAIL_DDA_DEEPLINK, ErrorResp.STATUS_ERROR, httpServletRequest);
			}else if(BusinessException.RETENTION_CUSTOM_ERROR == e.getKey() 
	    			|| BusinessException.RETENTION_SAVINGS_ACCEPT_FAILED == e.getKey()){
				OriginsVO myOriginVO  = IBankParams.getOrigin(mbSession.getOrigin());
				OriginsVO baseOrigin  = IBankParams.getOrigin(myOriginVO.getBankName());
				String[] values = {baseOrigin.getPhone()};	
				resp1  = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, values,ServiceConstants.OFFER_DETAIL_DDA_DEEPLINK, httpServletRequest);
	    	}
			else{
			  resp1  = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, ServiceConstants.OFFER_DETAIL_DDA_DEEPLINK, httpServletRequest);
			}
			
			Logger.info(e.getMessage(), this.getClass());
			return resp1;
						
		}
		catch (ResourceException e)
		{
			Logger.error("ResourceException Inside processOfferDDA() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			ResourceException exp = new ResourceException(e.getKey());
			IMBResp resp1  = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, ServiceConstants.OFFER_DETAIL_DDA_DEEPLINK, httpServletRequest);
			Logger.error(e.getMessage(), this.getClass());	
			return resp1;
		}
		catch (Exception e)
		{
			Logger.error("Exception Inside processOfferDDA() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			BusinessException exp = new BusinessException(BusinessException.GENERIC_ERROR);
			IMBResp resp1  = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, ServiceConstants.OFFER_DETAIL_DDA_DEEPLINK, httpServletRequest);
			Logger.error("Exception Inside processOfferDDA():"+e.getMessage(), this.getClass());	
			return resp1;
		
			
		} finally
		{
			perfLogger.endLog(logName);
			perfLogger.endAllLogs();
		}
	}	
	
	@RequestMapping(value= "getUrl" , method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public IMBResp processExternalLink(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse,
			@RequestBody final ExternalLinkReq req)
	{				
				
		ObjectMapper objectMapper = new ObjectMapper();								
		perfLogger.startAllLogs();
		String logName = MBAppUtils.getLogName(httpServletRequest);
		perfLogger.startLog(logName);
				
		MobileSession mbSession = null;
		String url = "";
		try{	
			
			mbSession = mbAppHelper.getMobileSession(httpServletRequest);		
			Logger.info("processExternalLink JSON Request :" + objectMapper.writeValueAsString(req), this.getClass());
			validateRequestHeader(req.getHeader(), httpServletRequest);
			ErrorResp errorResp = validate(req, httpServletRequest);
			if (errorResp != null && errorResp.getErrors() != null && errorResp.getErrors().size() > 0)
			{				
				//fraudLogger.logInvalidInput();
				return errorResp;
			}			
																						
			Customer customer=mbSession.getCustomer();			
												
			IBankCommonData commonData=mbAppHelper.populateIBankCommonData(mbSession,httpServletRequest);
			
			ExternalLinkService extService = ServiceHelper.getBean("externalLinkService");
			
			//16E4 Comet Insurance SSO for car, home and landlord 
			String productType  = null;
			
			if(req.getApplicationType().contains("car")){
				productType = "car";
			}else if(req.getApplicationType().contains("home")){
				productType = "home";
			}else if(req.getApplicationType().contains("land")){
				productType = "land";
			}else if(req.getApplicationType().contains("travel")){
				productType = "travel";
			}
			
			if(productType != null && ((IBankParams.isInsuranceSSOSwitchON() && (productType.equals("home") || productType.equals("land")))||(IBankParams.isMotorInsuranceSSOSwitchON() && productType.equals("car") ) 
					|| (IBankParams.isTravelInsuranceSSOSwitchON() && productType.equals("travel") ))){
				try{
					url= insuranceService.getSSOUrl(commonData, mbSession.getOrigin(), req.getApplicationType(), productType, req.getLeadId());
					extService.createLogStatistics(commonData, true, req.getApplicationType());
					if(StringMethods.isEmptyString(url)){
						throw new BusinessException (BusinessException.SYSTEM_UNAVILABLE, "Insurance SSO url is empty" );
					}
				}catch(Exception e){
					url= extService.getExternalURLForOffers(commonData, true, req.getApplicationType(), req.getLeadId());		
				}
			}else{
				url= extService.getExternalURLForOffers(commonData, true, req.getApplicationType(), req.getLeadId());			
			}
			//String url= extService.getExternalURLForOffers(commonData, true, req.getApplicationType(), req.getLeadId());			
													
			IMBResp serviceResponse = salesOfferHelper.populateExternalLinkURLResp(url);
									
			RespHeader headerResp = populateResponseHeader(ServiceConstants.PROCESS_EXTERNAL_URL, mbSession);
			serviceResponse.setHeader(headerResp);
			
			Logger.info("processExternalLink JSON Response :" + objectMapper.writeValueAsString(serviceResponse), this.getClass());
			
			return serviceResponse;		
		}catch (BusinessException e)
		{
			BusinessException exp = null;
			Logger.info("BusinessException Inside processExternalLink() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "]", e, this.getClass());		
			exp = new BusinessException(BusinessException.SYSTEM_UNAVILABLE);
			IMBResp resp1  = MBAppUtils.createErrorResp(mbSession.getOrigin() ,exp, ServiceConstants.PROCESS_EXTERNAL_URL, httpServletRequest);
			return resp1;
		}catch (ResourceException e) {
			Logger.error("ResourceException Inside processExternalLink() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "]", e, this.getClass());			
			ResourceException exp = new ResourceException(BusinessException.SYSTEM_UNAVILABLE);
			IMBResp resp1  = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, ServiceConstants.PROCESS_EXTERNAL_URL, httpServletRequest);
			return resp1;
		}catch (Exception e)
		{			
			Logger.error("Exception Inside processExternalLink() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "]", e, this.getClass());
			BusinessException exp = new BusinessException(BusinessException.SYSTEM_UNAVILABLE);
			IMBResp resp1  = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, ServiceConstants.PROCESS_EXTERNAL_URL, httpServletRequest);
			return resp1;
		} finally
		{			
			/*if ( mbSession != null )
				mbSession.invalidateSession();*/
						
			perfLogger.endLog(logName);
			perfLogger.endAllLogs();
		}				
	}
	
	@RequestMapping(value = "updateTeaserCountAsyn", method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public IMBResp updateTeaserCountForAem(HttpServletRequest httpRequest, HttpServletResponse httpServletResponse,@RequestBody final SalesOfferAemReq request) {
		Logger.debug("SalesOfferController - updateTeaserCountForAem(). Request: " + request, this.getClass());
		String logName = MBAppUtils.getLogName(httpRequest);
		MobileSession mobileSession = new MobileSessionImpl(); 		
		LeadDetails leadDetail = null;
		IMBResp serviceResponse = new OfferTeaserResp();
		try {
			perfLogger.startLog("updateTeaserCountForAem");
			mobileSession.getSessionContext(httpRequest);		
			
			//Added for SBGEXP-8092 - Fix issue of name id getting generated for async error response
			validateRequestHeader(request.getHeader(), httpRequest);
			ErrorResp errorResponse = validateAsync(request, httpRequest);
			if (errorResponse.hasErrors()) {
				return errorResponse;
			}
			
			Customer customer=mobileSession.getCustomer();	
			if((customer != null && customer.getInvitation() != null) && customer.getInvitation().getLeadId() != null){
				 leadDetail = offerService.findByLeadId(customer.getInvitation().getLeadId());
			}
			if(leadDetail != null){				
					if(!request.getDisplayMyInvitation()){
						if(leadDetail.getTeaserCounter() >0){	
							offerService.updateTeaserCounter(leadDetail, leadDetail.getTeaserCounter()-1);
						}
					}else{
						offerService.updateTeaserCounter(leadDetail, leadDetail.getTeaserCounter()+1);
					}					
			}
			RespHeader headerResp = mbAppHelper.populateAsyncResponseHeader(ServiceConstants.OFFER_DETAIL_SERVICE, mobileSession);
			serviceResponse.setHeader(headerResp);
			return  serviceResponse;
			
		} catch (BusinessException e) {
			Logger.info("BusinessException in SalesOfferController - updateTeaserCountForAem()", e,this.getClass());
			return MBAppUtils.createErrorRespAsync(mobileSession.getOrigin(), e, ServiceConstants.OFFER_DETAIL_SERVICE, httpRequest);
		} catch (ResourceException e) {
			Logger.error("ResourceException in SalesOfferController - updateTeaserCountForAem()", e,this.getClass());
			return MBAppUtils.createErrorRespAsync(mobileSession.getOrigin(), new ResourceException(BusinessException.SYSTEM_UNAVILABLE), ServiceConstants.OFFER_DETAIL_SERVICE, httpRequest);
		} catch (Exception e) {
			Logger.error("Exception SalesOfferController - updateTeaserCountForAem()", e, this.getClass());
			return MBAppUtils.createErrorRespAsync(mobileSession.getOrigin(), new BusinessException(BusinessException.GENERIC_ERROR), ServiceConstants.OFFER_DETAIL_SERVICE, httpRequest);
		} finally {
			perfLogger.endLog("updateTeaserCountForAem");
			perfLogger.endLog(logName);
			perfLogger.endAllLogs();
		}
	}
	
	/**
	 * Response for invalid body request 
	 * 
	 * @return
	 */
	@ExceptionHandler({org.springframework.http.converter.HttpMessageNotReadableException.class})
	@ResponseStatus(org.springframework.http.HttpStatus.OK)
	@ResponseBody
	public IMBResp resolveException() {		
		return MBAppUtils.createInvalidMessageBodyResponse(ServiceConstants.MSGCENTRE_LIST_SERVICE);
	}
	
	public ErrorResp validate(IMBReq serviceRequest, HttpServletRequest request) {
		return  mbAppValidator.validate(serviceRequest, request);
	}
	
	public void validateRequestHeader(ReqHeader header, HttpServletRequest request) throws ResourceException
	{	
		mbAppValidator.validateRequestHeader(header,  request);	
	}
	
	public RespHeader populateResponseHeader(String ServiceName)
	{		
		return mbAppHelper.populateResponseHeader(ServiceName);
	}				
	
	
	public RespHeader populateResponseHeader(String serviceName, MobileSession mobSession )
	{
		return mbAppHelper.populateResponseHeader(serviceName, mobSession);
	}
	
	/**
	 * SBGEXP-8092 - Fix issue of name id getting generated for async error response
	 *  
	 * @param serviceRequest
	 * @param httpRequest
	 * @return ErrorResp
	 * @throws BusinessException
	 */	
	public ErrorResp validateAsync(IMBReq serviceRequest, HttpServletRequest httpRequest) throws BusinessException {
		return  mbAppValidator.validateAsync(serviceRequest, httpRequest);
	}		
	
}
