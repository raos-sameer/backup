package au.com.stgeorge.mbank.model.common;

import java.io.Serializable;
import java.math.BigDecimal;

import javax.validation.constraints.Pattern;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_NULL)
public class OpenAcctDetail implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 7745327661939574108L;
	protected static final String BLOCK_CHARS_PATTERN = "^[0-9A-Za-z',. &/\\-]*$";
	
	@Pattern(regexp = BLOCK_CHARS_PATTERN, message = "{errors.accountNum.blockchar}")
	private String accountNum;
	
	@Pattern(regexp = BLOCK_CHARS_PATTERN, message = "{errors.accountNum.blockchar}")
	private String accountNumDisp;
	
	@Pattern(regexp = BLOCK_CHARS_PATTERN, message = "{errors.bsb.blockchar}")
	private String bsb;
	
	@Pattern(regexp = BLOCK_CHARS_PATTERN, message = "{errors.bsb.blockchar}")
	private String bsbDisp;
	
	@Pattern(regexp = BLOCK_CHARS_PATTERN, message = "{errors.accountType.blockchar}")
	private String accountType;	
	
	private Integer accountIndex ;
	
	private BigDecimal balance;
	
	private BigDecimal availBalance;
	
	private ProductReq product;	
	
	@Pattern(regexp = BLOCK_CHARS_PATTERN, message = "{errors.bsb.blockchar}")
	private String branchKey ;	
	
	
	public String getBranchKey() {
		return branchKey;
	}

	public void setBranchKey(String branchKey) {
		this.branchKey = branchKey;
	}

	public ProductReq getProduct() {
		return product;
	}

	public void setProduct(ProductReq product) {
		this.product = product;
	}

	public String getAccountNum() {
		return accountNum;
	}

	public void setAccountNum(String accountNum) {
		this.accountNum = accountNum;
	}

	public String getAccountNumDisp() {
		return accountNumDisp;
	}

	public void setAccountNumDisp(String accountNumDisp) {
		this.accountNumDisp = accountNumDisp;
	}

	public String getBsb() {
		return bsb;
	}

	public void setBsb(String bsb) {
		this.bsb = bsb;
	}

	public String getBsbDisp() {
		return bsbDisp;
	}

	public void setBsbDisp(String bsbDisp) {
		this.bsbDisp = bsbDisp;
	}

	public String getAccountType() {
		return accountType;
	}

	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}

	public Integer getAccountIndex() {
		return accountIndex;
	}

	public void setAccountIndex(Integer accountIndex) {
		this.accountIndex = accountIndex;
	}

	public BigDecimal getBalance() {
		return balance;
	}

	public void setBalance(BigDecimal balance) {
		this.balance = balance;
	}

	public BigDecimal getAvailBalance() {
		return availBalance;
	}

	public void setAvailBalance(BigDecimal availBalance) {
		this.availBalance = availBalance;
	}	
	
	
	
}
