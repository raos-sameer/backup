package au.com.stgeorge.mbank.model.common;

public class PhoneReq {
	
	String phoneType;
	String phoneNum;
	Boolean isPhnNoChange;

	public Boolean getIsPhnNoChange() {
		return isPhnNoChange;
	}

	public void setIsPhnNoChange(Boolean isPhnNoChange) {
		this.isPhnNoChange = isPhnNoChange;
	}

	public String getPhoneType()
	{
		return phoneType;
	}

	public void setPhoneType(String phoneType)
	{
		this.phoneType = phoneType;
	}

	public String getPhoneNum()
	{
		return phoneNum;
	}

	public void setPhoneNum(String phoneNum)
	{
		this.phoneNum = phoneNum;
	}

}
