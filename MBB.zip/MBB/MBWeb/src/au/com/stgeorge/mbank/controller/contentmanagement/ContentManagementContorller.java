package au.com.stgeorge.mbank.controller.contentmanagement;

import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import au.com.stgeorge.framework.common.logging.Logger;
import au.com.stgeorge.framework.common.util.StringMethods;
import au.com.stgeorge.ibank.businessobject.BusinessException;
import au.com.stgeorge.ibank.businessobject.ContentManagementService;
import au.com.stgeorge.ibank.businessobject.ResourceException;
import au.com.stgeorge.ibank.common.cache.IBankParams;
import au.com.stgeorge.ibank.valueobject.AEMContent.AEMCRAProdEnum;
import au.com.stgeorge.ibank.valueobject.CRAContent;
import au.com.stgeorge.ibank.valueobject.CRAProductContent;
import au.com.stgeorge.ibank.valueobject.transfer.IBankCommonData;
import au.com.stgeorge.mbank.controller.IMBController;
import au.com.stgeorge.mbank.controller.customer.LogonHelper;
import au.com.stgeorge.mbank.model.common.IMBReq;
import au.com.stgeorge.mbank.model.common.IMBResp;
import au.com.stgeorge.mbank.model.common.ReqHeader;
import au.com.stgeorge.mbank.model.common.RespHeader;
import au.com.stgeorge.mbank.model.request.contentmanagement.ContentManagementReq;
import au.com.stgeorge.mbank.model.response.ErrorResp;
import au.com.stgeorge.mbank.model.response.newaccount.ProductContentResp;
import au.com.stgeorge.mbank.model.response.newaccount.ProductDetailsContentResp;
import au.com.stgeorge.mbank.model.response.newaccount.ProductDetailsResp;
import au.com.stgeorge.mbank.model.response.newaccount.ProductDisclaimerResp;
import au.com.stgeorge.mbank.model.response.newaccount.ProductListItemResp;
import au.com.stgeorge.mbank.session.MobileSession;
import au.com.stgeorge.mbank.util.MBAppHelper;
import au.com.stgeorge.mbank.util.MBAppUtils;
import au.com.stgeorge.mbank.util.MBAppValidator;
import au.com.stgeorge.mbank.util.ServiceConstants;
import au.com.stgeorge.perflogger.PerformanceLogger;

import com.fasterxml.jackson.databind.ObjectMapper;

@Controller
@RequestMapping("/newaccount")
public class ContentManagementContorller implements IMBController{

	
	@Autowired
	private ContentManagementService contentManagementService;
	
	@Autowired
	private MBAppHelper mbAppHelper;
	
	@Autowired
	private MBAppValidator mbAppValidator;
		
	@Autowired
	private PerformanceLogger perfLogger;
	
	
	@Autowired
	private LogonHelper logonHelper;
	
	@RequestMapping(value= "productDetails" , method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public IMBResp processContentPreview(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse,
			@RequestBody final ContentManagementReq req)
	{	
		ObjectMapper objectMapper = new ObjectMapper();
		perfLogger.startAllLogs();
		String logName = MBAppUtils.getLogName(httpServletRequest);
		perfLogger.startLog(logName);
		
		//fraudLogger = new FraudLogger();
		MobileSession mbSession = null;
		try{
			mbSession = mbAppHelper.getMobileSession(httpServletRequest);		
			Logger.info("Content Management JSON Request :" + objectMapper.writeValueAsString(req), this.getClass());
			validateRequestHeader(req.getHeader(), httpServletRequest);
			ErrorResp errorResp = validate(req, httpServletRequest);
			if (errorResp != null && errorResp.getErrors() != null && errorResp.getErrors().size() > 0)
			{				
				//fraudLogger.logInvalidInput();
				return errorResp;
			}
			RespHeader headerResp = populateResponseHeader(req.getHeader().getServiceName(), mbSession);
			IBankCommonData ibankCommonData = mbAppHelper.populateIBankCommonData(mbSession,httpServletRequest);
			
			CRAProductContent productContent = null;
			
			boolean isDemo = logonHelper.isDemo();
			if (isDemo)
			{
				Logger.info("isDemo :" + isDemo, this.getClass());
				String encodedDemoDigest = mbSession.getAEMDigester();
				Logger.info("encodedDemoDigest :" + encodedDemoDigest, this.getClass());
				if(!StringMethods.isEmptyString(encodedDemoDigest) && encodedDemoDigest.length() > 5){
					productContent = contentManagementService.getCreditCardProdDetailsContentForDemo( req.getProductName(), encodedDemoDigest, IBankParams
						    .getBaseOriginCode(ibankCommonData.getOrigin()));
				}
				else{
					//TODO
					productContent = contentManagementService.getCreditCardProdDetailsContentForDemo( req.getProductName(), "", IBankParams
						    .getBaseOriginCode(ibankCommonData.getOrigin()));
				}
			}
			else{
				//CAll Prod content
				productContent = contentManagementService.getCreditCardProdDetailsContentForProd( req.getProductName(), IBankParams.getBaseOriginCode(ibankCommonData.getOrigin()));
			}
							
		
		IMBResp serviceResponse = populateCreditCardProdDetails(productContent, req, IBankParams.getBaseOriginCode(ibankCommonData.getOrigin()));
		serviceResponse.setHeader(headerResp);
		
		return serviceResponse;
		}
		catch (BusinessException e)
		{
			Logger.info("BusinessException Inside processContentPreview() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "]", e, this.getClass());		
			BusinessException exp = new BusinessException(e.getKey());
			IMBResp resp1  = MBAppUtils.createErrorResp(mbSession.getOrigin() ,exp, ServiceConstants.CONTENT_MANAGEMENT_SERVICE, httpServletRequest);
			return resp1;
		}catch (ResourceException e) {
			Logger.error("ResourceException Inside processContentPreview() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "]", e, this.getClass());			
			ResourceException exp = new ResourceException(e.getKey());
			IMBResp resp1  = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, ServiceConstants.CONTENT_MANAGEMENT_SERVICE, httpServletRequest);
			return resp1;
		}catch (Exception e)
		{			
			Logger.error("Exception Inside processContentPreview() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "]", e, this.getClass());
			BusinessException exp = new BusinessException(BusinessException.GENERIC_ERROR);
			IMBResp resp1  = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, ServiceConstants.CONTENT_MANAGEMENT_SERVICE, httpServletRequest);
			return resp1;
		} finally
		{
			perfLogger.endLog(logName);
			perfLogger.endAllLogs();
		}		
		
	}
	
	private IMBResp populateCreditCardProdDetails(CRAProductContent craProductContent, ContentManagementReq req,  String origin ) {
			
		ProductDetailsResp productDetailsResp = new ProductDetailsResp();
		ProductDetailsContentResp creditCardContentDetails = null;
		if(craProductContent != null ){
			//productDetailsResp = new ProductDetailsResp();
			creditCardContentDetails = new ProductDetailsContentResp();
			creditCardContentDetails.setHeaderName("Credit Cards");
			creditCardContentDetails.setCpcCode(  getCPCCode( req.getProductName(), origin) );
			ProductContentResp productContentResp = null ;
        		
    		String aemProdKey = craProductContent.getProductKey();
    		aemProdKey = aemProdKey.toUpperCase().replace("-", "_");
    		if(AEMCRAProdEnum.valueOf(aemProdKey) != null){
    			
        		productContentResp = new ProductContentResp();
        		productContentResp.setProductName(AEMCRAProdEnum.valueOf(aemProdKey).getValue());
        		productContentResp.setProductTitle(craProductContent.getProduct());
        		
        		if(craProductContent.getLineItems() != null && craProductContent.getLineItems().size() > 0){
        			List<ProductListItemResp> productContentList = new ArrayList<ProductListItemResp>();
        			List<ProductListItemResp> productCtatList = new ArrayList<ProductListItemResp>();
        			//ProductDisclaimerResp productDisclaimerResp = new ProductDisclaimerResp();
        			//List<ProductListItemResp> productDisclaimertList = new ArrayList<ProductListItemResp>();
        			ProductListItemResp productListItemResp = null;
        			for(CRAContent craContent : craProductContent.getLineItems()){
        				if(!StringMethods.isEmptyString(craContent.getContentText())){
        				if(craContent.getContentType().equalsIgnoreCase(ContentManagementService.JSON_CONTENT_TITLE)){
        					productContentResp.setProductSubTitle(craContent.getContentText());
        				}
        				else{
	        				productListItemResp = new ProductListItemResp();
	        				productListItemResp.setContentType(craContent.getContentType());
//	        				productListItemResp.setContent(craContent.getContentText());
	        				
	        				String content = URLEncoder.encode(craContent.getContentText());//ISG : Sanitise msg before sending it to mobile
	        				productListItemResp.setContent(content);
	        				productListItemResp.setType(craContent.getPriority());
	        				productListItemResp.setSrText(craContent.getAccessibilityText());
	        				
	        				if(craContent.getContentType().equalsIgnoreCase(ContentManagementService.JOSN_CONTENT_CTA)){
	        					productCtatList.add(productListItemResp);
	        				}
	        				/*else if(craContent.getContentType().equalsIgnoreCase("tysk")){
	        					productDisclaimertList.add(productListItemResp);
	        				}*/
	        				else{
	        					productContentList.add(productListItemResp);
	        				}
        				//productContentList.add(productListItemResp);
        				}
        				}
        			}
        			
        			if(productContentList.size() > 0){
                		productContentResp.setProductContent(productContentList);
                	}
        			if(productCtatList.size() > 0){
                		productContentResp.setProductCta(productCtatList);
                	}
        			/*if(productDisclaimertList.size() > 0){
        				productDisclaimerResp.setHeaderName(ContentManagementService.TYSK_HEADING);
        				productDisclaimerResp.setContent(productDisclaimertList);
        				creditCardContentDetails.setDisclaimer(productDisclaimerResp);
                	}*/
        			creditCardContentDetails.setProducts(productContentResp);
        			
        		}
        		
        		
        		if(craProductContent.getDisclaimerItems() != null && craProductContent.getDisclaimerItems().size() > 0){
        			
        			ProductDisclaimerResp productDisclaimerResp = new ProductDisclaimerResp();
        			List<ProductListItemResp> productDisclaimertList = new ArrayList<ProductListItemResp>();
        			ProductListItemResp productListItemResp = null;
        			for(CRAContent craContent : craProductContent.getDisclaimerItems()){
        				
        				productListItemResp = new ProductListItemResp();
        				productListItemResp.setContentType(craContent.getContentType());
        				//productListItemResp.setContent(craContent.getContentText());
        				String content = URLEncoder.encode(craContent.getContentText());//ISG : Sanitise msg before sending it to mobile
        				productListItemResp.setContent(content);
        				productListItemResp.setType(craContent.getPriority());
        				productListItemResp.setSrText(craContent.getAccessibilityText());
        				
       					productDisclaimertList.add(productListItemResp);
            				
        				//productContentList.add(productListItemResp);
        				}
        			if(productDisclaimertList.size() > 0){
        				
        				//Get the Disclaimer title from Brand Variables
        				HashMap brandMap = IBankParams.getAEMBrandMap();
        				
        				String matchedMacro = origin + ".CFRTE.BV." + ContentManagementService.JSON_CONTENT_DISCLAIMER_TITLE;
        				String tyskHeading = (String) brandMap.get(matchedMacro.toUpperCase());
        				if(!StringMethods.isEmptyString(tyskHeading)){
        					productDisclaimerResp.setHeaderName(tyskHeading);
        				}
        				else{
        					productDisclaimerResp.setHeaderName(ContentManagementService.TYSK_HEADING);
        				}
        				
        				//productDisclaimerResp.setHeaderName(ContentManagementService.TYSK_HEADING);
        				productDisclaimerResp.setContent(productDisclaimertList);
        				creditCardContentDetails.setDisclaimer(productDisclaimerResp);
                	}    			
        		}
        		
        		}
        		productDetailsResp.setCreditCardContentDetails(creditCardContentDetails);
        		
        	}
        
		
		return productDetailsResp;
	}

	public ErrorResp validate(IMBReq serviceRequest, HttpServletRequest request) {
		return mbAppValidator.validate(serviceRequest, request);
	}
	
	public void validateRequestHeader(ReqHeader header, HttpServletRequest request) throws ResourceException
	{	
		mbAppValidator.validateRequestHeader(header,  request);	
	}
	
	public RespHeader populateResponseHeader(String ServiceName)
	{		
		return mbAppHelper.populateResponseHeader(ServiceName);
	}			
	
	public RespHeader populateResponseHeader(String serviceName, MobileSession mobSession )
	{
		return mbAppHelper.populateResponseHeader(serviceName, mobSession);
	}


	private String getCPCCode(String prod,  String brand )
	{
	
		  String origin = IBankParams.getBaseOriginCode(brand);
		  HashMap<String,String> hash = new HashMap<String,String>();
		  hash.put("VERTIGO_STG","7ebae3d81493438ab3ca2ddb02a38db6");
		  hash.put("VERTIGO_PLATINUM_STG","c8e56bb778df446b86b90e89f30f0bb9");
		  hash.put("AMPLIFY_STG","9e3790bc55034cf0896bf8a8d4a45d52");
		  hash.put("AMPLIFY_PLATINUM_STG","b71765cf47a54132adb6766132e744c9");
		  hash.put("AMPLIFY_SIGNATURE_STG","068fa1e8d691470bad44af4a052fdb05");
		  hash.put("AMPLIFY_BUSINESS_STG","4a200d993d6f409296b8dd574b271c88");


		  //  hash.put("//BOM);
		  hash.put("VERTIGO_BOM","7ebae3d81493438ab3ca2ddb02a38db6");
		  hash.put("VERTIGO_PLATINUM_BOM","9f1e9f7299164e6e96246bdcb6a86eb0");
		  hash.put("AMPLIFY_BOM","c4b1bc79744346f3a63fefdd3bba0d35");
		  hash.put("AMPLIFY_PLATINUM_BOM","fc716d1d881e4541887659b84f2a53db");
		  hash.put("AMPLIFY_SIGNATURE_BOM","52313da0ebae4c3381b73b6bede9a9d9");
		  hash.put("AMPLIFY_BUSINESS_BOM","4f95a87fab1c4a3bad71387327310de8");


		  //hash.put("//BSA);
		  hash.put("VERTIGO_BSA","17b3fc5d843545ea9c6f21890b15239d");
		  hash.put("VERTIGO_PLATINUM_BSA","c49869daadef421e980b9b7b117672a2");
		  hash.put("AMPLIFY_BSA","77c2dc6662b04fbf8044e825e0df9838");
		  hash.put("AMPLIFY_PLATINUM_BSA","14f2a4d53cb945b0a61048a01fb7e20d");
		  hash.put("AMPLIFY_SIGNATURE_BSA","98d45e1bdea945f2b5f69510e9bddb56");
		  hash.put("AMPLIFY_BUSINESS_BSA","9ee589b2b48a4167b6d0496b106afb97");

		  
		  String cpcCode = hash.get(prod.toUpperCase()+"_"+ origin.toUpperCase());
		  if ( StringMethods.isEmptyString(cpcCode))
		  {
			  Logger.info("CPC Not found for "+ prod.toUpperCase()+"_"+ origin.toUpperCase() , this.getClass());
			  return "cpc not found";
		  }
		  else
		  {
			  return cpcCode;
		  }
	}

}