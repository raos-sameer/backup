package au.com.stgeorge.mbank.model.common;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_NULL)
public class DismissInvitationInfoResp implements IMBResp {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private RespHeader header;
	
	private InvitationInfoResp invitationInfoResp;
	
	private boolean success;

	public boolean getSuccess() {
		return success;
	}

	public void setSuccess(boolean success) {
		this.success = success;
	}

	public InvitationInfoResp getInvitationInfoResp() {
		return invitationInfoResp;
	}

	public void setInvitationInfoResp(InvitationInfoResp infoResp) {
		this.invitationInfoResp = infoResp;
	}

	public RespHeader getHeader() {
		return header;
	}

	public void setHeader(RespHeader header) {
		this.header = header;
	}


	
}
