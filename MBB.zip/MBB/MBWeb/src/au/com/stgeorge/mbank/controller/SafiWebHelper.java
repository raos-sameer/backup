package au.com.stgeorge.mbank.controller;


import java.util.Calendar;
import java.util.Date;
import java.util.List;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;

import au.com.stgeorge.digitalsec.logger.DigitalSecLogger;
import au.com.stgeorge.framework.common.logging.Logger;
import au.com.stgeorge.framework.common.util.DateMethods;
import au.com.stgeorge.framework.common.util.StringMethods;
import au.com.stgeorge.ibank.businessobject.BPayService;
import au.com.stgeorge.ibank.businessobject.ThirdPartyTransferHelper;
import au.com.stgeorge.ibank.common.cache.IBankParams;
import au.com.stgeorge.ibank.npp.dao.valueobject.NPPPayIdPayee;
import au.com.stgeorge.ibank.safi.util.SafiConstants;
import au.com.stgeorge.ibank.safi.util.SafiUtil;
import au.com.stgeorge.ibank.safi.valueobject.SafiBillerDetails;
import au.com.stgeorge.ibank.safi.valueobject.SafiDeviceInfo;
import au.com.stgeorge.ibank.safi.valueobject.SafiFileshareVO;
import au.com.stgeorge.ibank.safi.valueobject.SafiLogonInfo;
import au.com.stgeorge.ibank.safi.valueobject.SafiMadisonVO;
import au.com.stgeorge.ibank.safi.valueobject.SafiMgrpVO;
import au.com.stgeorge.ibank.safi.valueobject.SafiPayIdDetails;
import au.com.stgeorge.ibank.safi.valueobject.SafiPayIdVO;
import au.com.stgeorge.ibank.safi.valueobject.SafiPayTranVO;
import au.com.stgeorge.ibank.safi.valueobject.SafiPayeeAccountDetails;
import au.com.stgeorge.ibank.safi.valueobject.SafiPayerAccountDetails;
import au.com.stgeorge.ibank.safi.valueobject.SafiPwdResetVO;
import au.com.stgeorge.ibank.safi.valueobject.SafiReactivateOnlineVO;
import au.com.stgeorge.ibank.safi.valueobject.SafiUpdatePhoneVO;
import au.com.stgeorge.ibank.service.valueobject.SafiRespVO;
import au.com.stgeorge.ibank.service.valueobject.SafiVO;
import au.com.stgeorge.ibank.util.CommonBusinessUtil;
import au.com.stgeorge.ibank.util.NPPUtil;
import au.com.stgeorge.ibank.valueobject.AccountId;
import au.com.stgeorge.ibank.valueobject.BPayPayment;
import au.com.stgeorge.ibank.valueobject.Biller;
import au.com.stgeorge.ibank.valueobject.ContactDetail;
import au.com.stgeorge.ibank.valueobject.ManageExistingPayIdDetails;
import au.com.stgeorge.ibank.valueobject.ManagePayIdDetails;
import au.com.stgeorge.ibank.valueobject.PayIDResolution;
import au.com.stgeorge.ibank.valueobject.PayIdDetails;
import au.com.stgeorge.ibank.valueobject.PhoneNumber;
import au.com.stgeorge.ibank.valueobject.Preference;
import au.com.stgeorge.ibank.valueobject.ScheduleDetails;
import au.com.stgeorge.ibank.valueobject.SecureCodeDetails;
import au.com.stgeorge.ibank.valueobject.TelegraphicTransfer;
import au.com.stgeorge.ibank.valueobject.ThirdParty;
import au.com.stgeorge.ibank.valueobject.ThirdPartyPayment;
import au.com.stgeorge.ibank.valueobject.collection.LabelValueMap;
import au.com.stgeorge.ibank.valueobject.database.FavouriteBillersVO;
import au.com.stgeorge.ibank.valueobject.transfer.IBankCommonData;
import au.com.stgeorge.mbank.session.MobileSession;
import au.com.stgeorge.mbank.util.MBAppHelper;

public class SafiWebHelper {
	
	private static final String BSA_DOMAIN =".banksa.com.au"; 
	private static final String STG_DOMAIN = ".stgeorge.com.au";
	private static final String BOM_DOMAIN=".bankofmelbourne.com.au";	
	private static final String ONUSBSB = "OnUsBSB";
	private static final String CATEGORY_ONUS = "OnUsTransfers";
	private static final int NORMALIZED_ACCOUNT_NUMBER_LENGTH = 9;
	private static final int NEW_PAYID_INDEX = -1;
	
	public static Cookie readCookies(HttpServletRequest request){
		Cookie[] cookies = request.getCookies();
		Cookie pmdata2Present = null ;
		
		if (cookies != null) {			
			for (Cookie c : cookies) {
				if (c.getName().equalsIgnoreCase(SafiConstants.MOBILE_PMDATA2_COOKIE)) {
					Logger.info("PMDATA2 is recieved from browser at logon : Name ::"+c.getName(), SafiWebHelper.class);
					pmdata2Present = c;
					break;
				}					
			}

		}else{
			Logger.info("No cookies found at browser logon.", SafiWebHelper.class);
		}
		return pmdata2Present;
	}
	
	  public static Cookie createOrUpdatePmdata2Cookie(HttpServletRequest request , Cookie oldCookie , String newValue){
		 Logger.debug("In createOrUpdatePmdata2Cookie", SafiWebHelper.class);
		 
		 String domainName = request.getServerName();
 		 if(domainName.contains(".")){
			domainName = domainName.substring(domainName.indexOf("."));
		 }	

		 Cookie cookie = null ;
		 int maxAge = 365*24*60*60 ;
		 
		 if(null == oldCookie){
			 //cookie not present - create cookie
			 Logger.info("Creating PMData2 cookie ..", SafiWebHelper.class);
			 cookie = new Cookie(SafiConstants.MOBILE_PMDATA2_COOKIE, newValue);
			 
		 }else{
	 		 if ( domainName != null && oldCookie.getDomain() != null && oldCookie.getDomain().indexOf(domainName ) > 1 )
	 		 {
	 			 Logger.info("Creating New PMData2 cookie . Domain : "+ oldCookie.getDomain() + " new domain :"+ domainName    , SafiWebHelper.class);
				 cookie = new Cookie(SafiConstants.MOBILE_PMDATA2_COOKIE, newValue);
				 oldCookie.setMaxAge(-1);
	 		 }
	 		 else 
	 		 {
				 //cookie present - update cookie
				 Logger.info("Updating PMData2 cookie ..", SafiWebHelper.class);
				 cookie = oldCookie;
				 cookie.setValue(newValue);
	 		 }
		 }
		 //cookie.setDomain(getDomainName(request));
		 cookie.setSecure(true);
		 cookie.setPath("/;HttpOnly");
		 cookie.setMaxAge(maxAge);
		 cookie.setDomain(domainName);
		 return cookie;
	 }
	 
	 
	 public static SafiVO populateSafiVO(HttpServletRequest request,String devicePrint,IBankCommonData commonData,boolean isMobileApp,SafiVO safiVO,String last2FASuccessTime) {

		 Logger.debug("populateSafiVO(): isMobileApp: "+isMobileApp,SafiWebHelper.class);
		 
		 if(!isMobileApp){
			 Logger.debug("populateSafiVOForNotify(): setting HTTP Attributes: ",SafiWebHelper.class);
			 
			 String httpAccept = request.getHeader(SafiConstants.HTTP_ACCEPT);
			 Logger.debug("SAFI : httpAccept :"+httpAccept, SafiWebHelper.class);
			 safiVO.setHttpAccept(SafiUtil.isValidHttpAccept(httpAccept) ? httpAccept : "");
			 
			 String httpAcceptCharset = request.getHeader(SafiConstants.HTTP_ACCEPT_CHARSET);
			 Logger.debug("SAFI : httpAcceptCharset :"+httpAcceptCharset, SafiWebHelper.class);
			 safiVO.setHttpAcceptChars(SafiUtil.isValidHttpCharset(httpAcceptCharset) ? httpAcceptCharset : "");
			 
			 String httpAcceptEncoding = request.getHeader(SafiConstants.HTTP_ACCEPT_ENCODING);
			 Logger.debug("SAFI : httpAcceptEncoding :"+httpAcceptEncoding, SafiWebHelper.class);
			 safiVO.setHttpAcceptEncoding(SafiUtil.isValidHttpEncoding(httpAcceptEncoding) ? httpAcceptEncoding : "");
			 
			 String httpAcceptLanguage = request.getHeader(SafiConstants.HTTP_ACCEPT_LANGUAGE);
			 Logger.debug("SAFI : httpAcceptLanguage :"+httpAcceptLanguage, SafiWebHelper.class);
			 safiVO.setHttpAcceptLanguage(SafiUtil.isValidHttpLanguage(httpAcceptLanguage) ? httpAcceptLanguage : "");
			 
			 String httpAcceptReferer = request.getHeader(SafiConstants.HTTP_ACCEPT_REFERER);
			 Logger.debug("SAFI : httpAcceptReferer :"+httpAcceptReferer, SafiWebHelper.class);
			 safiVO.setHttpReferrer(SafiUtil.isValidHttpReferer(httpAcceptReferer) ? httpAcceptReferer : "");
			 
			 String userAgent = request.getHeader(SafiConstants.HTTP_USER_AGENT);
			 Logger.debug("SAFI : userAgent :"+userAgent, SafiWebHelper.class);
			 safiVO.setUserAgent(SafiUtil.isValidUserAgent(userAgent) ? userAgent : "");
			 
			 safiVO.setDevicePrint(devicePrint);
		 }else{
			 Logger.debug("populateSafiVO(): isMobileApp: "+isMobileApp+" setting value of mobileInfoSdk as devicePrint ",SafiWebHelper.class);
			 safiVO.setMobileInfoSdk(devicePrint);
		 }
		 
		 safiVO.setIpAddress(MBAppHelper.resolveIPAddress(request, commonData.getOrigin()));

		 Cookie pmdata2Cookie = readCookies(request);
		 if(null!= pmdata2Cookie &&  !StringMethods.isEmptyString(pmdata2Cookie.getValue())){
			 safiVO.setDeviceTokenValue(pmdata2Cookie.getValue());
		 }
		 
		 
		 safiVO.setOrigin(commonData.getOrigin());
		 safiVO.setGcis(commonData.getCustomer().getGcis());
		 
		 if(!StringMethods.isEmptyString(last2FASuccessTime)){
		    safiVO.setSafiLast2FASuccessTime(last2FASuccessTime);
		 }
		 return safiVO;
	 }
	 
	 public static SafiVO populateSafiVOForNotify(HttpServletRequest request,IBankCommonData commonData,MobileSession mobileSession,Boolean status2FA,boolean isMobileApp,String last2FASuccessTime){
		
		 String devicePrint = null;
		 String safiChallengeEventRefId = null;
		 String safiSessionId = null;
		 String deviceTokenVal = null;
		 Boolean phonePerms = null;
		 Boolean locationPerms = null;
		 String appVersion = null;
		 SafiLogonInfo safiLogonInfo =  mobileSession.getSafiLogonInfo();
		
		 if(safiLogonInfo != null){
			 devicePrint =safiLogonInfo.getDevicePrint();
			 safiChallengeEventRefId = safiLogonInfo.getSafiChallengeEventRefId();
			 safiSessionId = safiLogonInfo.getSafiSessionId();
			 deviceTokenVal =  safiLogonInfo.getDeviceToken();
			 phonePerms =  safiLogonInfo.getPhonePerms();
			 locationPerms = safiLogonInfo.getLocationPerms();
			 appVersion = safiLogonInfo.getAppVersion();
		 }
		 
		 SafiVO safiVO = new SafiVO();
		 populateSafiVO(request, devicePrint, commonData, isMobileApp,safiVO,last2FASuccessTime);
		 safiVO.setSafiChallengeSuccess(status2FA);
		 safiVO.setSafiChallengeEventRefId(safiChallengeEventRefId);
		 safiVO.setSafiSessionId(safiSessionId);
		 if(mobileSession.getSecureCodeDetails() != null){
			 PhoneNumber phoneNumber = CommonBusinessUtil.get2FAPhoneNumber(commonData, mobileSession.getSecureCodeDetails().getPhoneNumber());		 
			 safiVO.setOtpPhoneUsed(phoneNumber != null ? phoneNumber.getAreaCode()+phoneNumber.getPhoneNumber(): null);
			 safiVO.setOtpDeliveryMethod(mobileSession.getSecureCodeDetails().getDeliveryMethod());
		 }
		 safiVO.setDeviceTokenValue(deviceTokenVal);
		 safiVO.setPhonePerms(phonePerms);
		 safiVO.setLocationPerms(locationPerms);
		 safiVO.setAppVersion(appVersion);
		 
		 return safiVO;

	 }
	
	 public static boolean isPhoneNumberAvailable(ContactDetail contactDetail){

		 boolean isPhoneExists = true;
		 
		 if(contactDetail != null){
			 PhoneNumber homePhone = contactDetail.getHomeNumber();
			 PhoneNumber workPhone = contactDetail.getWorkNumber();
			 PhoneNumber mobilePhone = contactDetail.getMobileNumber();

			 if(!(homePhone != null && !StringMethods.isEmptyString(homePhone.getAreaCode()) && !StringMethods.isEmptyString(homePhone.getPhoneNumber())) &&
					 !(workPhone != null && !StringMethods.isEmptyString(workPhone.getAreaCode()) && !StringMethods.isEmptyString(workPhone.getPhoneNumber())) &&
					 !(mobilePhone != null && !StringMethods.isEmptyString(mobilePhone.getAreaCode()) && !StringMethods.isEmptyString(mobilePhone.getPhoneNumber()))){
				 isPhoneExists = false;
			 }
		 } 
		 
		 return isPhoneExists;
	 }

	 public static SafiPayTranVO populateSafiPayTranVOForTT(HttpServletRequest request,TelegraphicTransfer tt,IBankCommonData commonData,String devicePrint,MobileSession mobileSession,boolean isMobileApp){
		 
		 Logger.debug("SAFI : SafiWebHelper.populateSafiPayTranVOForTT() for Safi Analyse Call : START: isMobileApp: "+isMobileApp,SafiWebHelper.class);
		 
		 SafiPayTranVO safiPayTranVO = new SafiPayTranVO();
		 String last2FASuccessTime = null;
		 
		 last2FASuccessTime = getLast2FASuccessTime(mobileSession);
		 
		 SafiLogonInfo safiLogonInfo =  mobileSession.getSafiLogonInfo();
		 if(safiLogonInfo != null && isMobileApp){
			 devicePrint = safiLogonInfo.getDevicePrint();
			 safiPayTranVO.setPhonePerms(safiLogonInfo.getPhonePerms());
			 safiPayTranVO.setLocationPerms(safiLogonInfo.getLocationPerms());
			 safiPayTranVO.setAppVersion(safiLogonInfo.getAppVersion());
		 }
		 
		 populateSafiVO(request, devicePrint, commonData, isMobileApp,safiPayTranVO,last2FASuccessTime);
		 
		 //myAccountData
		 SafiPayerAccountDetails payerDetails = new SafiPayerAccountDetails();
		 payerDetails.setAccountNumber(tt.getFromAccount().getAccountNumber());
		 payerDetails.setRoutingCode(tt.getFromAccount().getBsb());
		 AccountId fromAccount = tt.getFromAccount();
		 
		 if(fromAccount != null && AccountId.EHUB_CODE_SAVING.equalsIgnoreCase(fromAccount.getEhubProductCode())){
			 payerDetails.setAccountType(SafiConstants.PAYER_ACC_TYPE_SAVINGS);
		 }else{
			 payerDetails.setAccountType(SafiConstants.PAYER_ACC_TYPE_CHECKING);
		 }
		//otherAccountData
		 SafiPayeeAccountDetails payeeDetails = new SafiPayeeAccountDetails();
		
		 String beneficiaryAccountNumber = tt.getBeneficiaryAccountNumber();
		 if(!StringMethods.isEmptyString(beneficiaryAccountNumber)){
			 beneficiaryAccountNumber = beneficiaryAccountNumber.replaceAll("\\s","");
		 }
		 payeeDetails.setAccountNumber(beneficiaryAccountNumber);
		 
		 String beneficiarySwiftBic = tt.getBeneficiaryBank().getSwiftBicAddress();
		 payeeDetails.setIbanSwiftBic(beneficiarySwiftBic);
		 
		 if(StringMethods.isEmptyString(beneficiarySwiftBic)){
			 payeeDetails.setDestinationAccountNumber(beneficiaryAccountNumber);
			 payeeDetails.setRoutingCode(SafiConstants.IBAN_TT);
		 }else{
			 payeeDetails.setDestinationAccountNumber(beneficiarySwiftBic+beneficiaryAccountNumber);
			 payeeDetails.setRoutingCode(beneficiarySwiftBic);
		 }

		 safiPayTranVO.setPayerDetails(payerDetails);
		 safiPayTranVO.setPayeeDetails(payeeDetails);
		 safiPayTranVO.setDueDate(new java.util.Date());
		 safiPayTranVO.setAmount(tt.getForeignCurrencyAmount());
		 safiPayTranVO.setCurrencyCode(tt.getCurrency());
		 String desc = SafiUtil.validateAndReplace(tt.getPaymentDetails());
		 desc = desc.length() > SafiConstants.PAYEE_DESCRIPTION_LIMIT ? desc.substring(0, SafiConstants.PAYEE_DESCRIPTION_LIMIT) : desc;
		 safiPayTranVO.setDescription(desc);
		 
		 boolean isNewPayee = (tt.getFirstPaymentDate() == null)?true:false;
		 safiPayTranVO.setNewPayee(isNewPayee);
		 boolean isPayee2FAd = ((!StringMethods.isEmptyString(tt.getTrusted())) && SafiConstants.TRUSTED_STATUS.equalsIgnoreCase(tt.getTrusted()))?true:false;
		 safiPayTranVO.setPayee2FAd(isPayee2FAd);
		 if(tt.isTtRestrictHighRiskCountriesSwitchOn()) {
			 safiPayTranVO.setCountryCode(tt.getBeneficiaryBank().getCountryCode());
			 safiPayTranVO.setAud_value(tt.getAmount().subtract(tt.getFeeAmount()));
		 }
		 Logger.debug("SAFI : SafiWebHelper.populateSafiPayTranVOForTT() for Safi Analyse Call : END"+isMobileApp,SafiWebHelper.class);
		 
		 return safiPayTranVO;
		 
	 }
	 

	 public static void populateSafiVOForNotifyTT(HttpServletRequest request,TelegraphicTransfer tt,MobileSession mobileSession,Boolean status2FA,boolean isPaymentSuccess,String otpPhoneUsed,String otpDeliveryMethod){

		 Logger.debug("SAFI : SafiWebHelper.populateSafiVOForNotifyTT() for Safi Notify Call : START",SafiWebHelper.class);

		 SafiPayTranVO safiPayTranVO = tt.getSafiPayTranVO();
		 SafiRespVO safiAnalyseCallRespVO = tt.getSafiRespVO();

		 if(safiAnalyseCallRespVO != null){
			 safiPayTranVO.setSafiChallengeEventRefId(safiAnalyseCallRespVO.getSafiChallengeEventRefId());
			 safiPayTranVO.setSafiSessionId(safiAnalyseCallRespVO.getSafiSessionId());
		 }

		 Cookie pmdata2Cookie = readCookies(request);

		 if(null!= pmdata2Cookie &&  !StringMethods.isEmptyString(pmdata2Cookie.getValue())){
			 safiPayTranVO.setDeviceTokenValue(pmdata2Cookie.getValue());
		 }


		 safiPayTranVO.setOtpPhoneUsed(otpPhoneUsed);
		 safiPayTranVO.setOtpDeliveryMethod(otpDeliveryMethod);
		 safiPayTranVO.setSafiChallengeSuccess(status2FA);
		 safiPayTranVO.setPaymentSuccessful(isPaymentSuccess);

		 Logger.debug("SAFI : SafiWebHelper.populateSafiVOForNotifyTT() for Safi Notify Call : END",SafiWebHelper.class);

	 }

	 public static void populateSafiVOForNotifyBPay(HttpServletRequest request,BPayPayment payment,MobileSession mobileSession,Boolean status2FA,boolean isPaymentSuccess,String otpPhoneUsed,String otpDeliveryMethod){

		 Logger.debug("SAFI : SafiWebHelper.populateSafiVOForNotifyBPay() for Safi Notify Call : START",SafiWebHelper.class);

		 SafiPayTranVO safiPayTranVO = payment.getSafiPayTranVO();
		 SafiRespVO safiAnalyseCallRespVO = payment.getSafiRespVO();

		 if(safiAnalyseCallRespVO != null){
			 safiPayTranVO.setSafiChallengeEventRefId(safiAnalyseCallRespVO.getSafiChallengeEventRefId());
			  safiPayTranVO.setSafiSessionId(safiAnalyseCallRespVO.getSafiSessionId());
		 }

		 Cookie pmdata2Cookie = readCookies(request);

		 if(null!= pmdata2Cookie &&  !StringMethods.isEmptyString(pmdata2Cookie.getValue())){
			 safiPayTranVO.setDeviceTokenValue(pmdata2Cookie.getValue());
		 }

		 safiPayTranVO.setOtpPhoneUsed(otpPhoneUsed);
		 safiPayTranVO.setOtpDeliveryMethod(otpDeliveryMethod);
		 safiPayTranVO.setSafiChallengeSuccess(status2FA);
		 safiPayTranVO.setPaymentSuccessful(isPaymentSuccess);

		 Logger.debug("SAFI : SafiWebHelper.populateSafiVOForNotifyBPay() for Safi Notify Call : END",SafiWebHelper.class);
	 }
	 
public static SafiPayTranVO populateSafiPayTranVOForThirdPartyPayment(HttpServletRequest request,ThirdPartyPayment thirdPartyPayment,IBankCommonData commonData,String devicePrint,MobileSession mobileSession,boolean isMobileApp){
		  
		 Logger.debug("SAFI : SafiWebHelper.populateSafiPayTranVOForThirdPartyPayment() for Safi Analyse Call : START: isMobileApp: "+isMobileApp+" devicePrint: "+devicePrint,SafiWebHelper.class);
		 
		 SafiPayTranVO safiPayTranVO = new SafiPayTranVO();
		 String last2FASuccessTime = null;
		 
		 last2FASuccessTime = getLast2FASuccessTime(mobileSession);
		 
		 SafiLogonInfo safiLogonInfo =  mobileSession.getSafiLogonInfo();
		 if(safiLogonInfo != null && isMobileApp){ 
			 Logger.debug("SAFI : From NATIVE APP - SafiWebHelper.populateSafiPayTranVOForThirdPartyPayment() :devicePrint1: "+devicePrint,SafiWebHelper.class);
			 devicePrint = safiLogonInfo.getDevicePrint();
			 Logger.debug("SAFI : From NATIVE APP - devicePrint taken from safiLogonInfo :devicePrint2: "+devicePrint,SafiWebHelper.class);
			 safiPayTranVO.setPhonePerms(safiLogonInfo.getPhonePerms());
			 Logger.debug("SAFI : From NATIVE APP - PhonePerms taken from safiLogonInfo :PhonePerms: "+safiLogonInfo.getPhonePerms(),SafiWebHelper.class);
			 safiPayTranVO.setLocationPerms(safiLogonInfo.getLocationPerms());
			 Logger.debug("SAFI : From NATIVE APP - LocationPerms taken from safiLogonInfo :LocationPerms: "+safiLogonInfo.getLocationPerms(),SafiWebHelper.class);
			 safiPayTranVO.setAppVersion(safiLogonInfo.getAppVersion());
			 Logger.debug("SAFI : From NATIVE APP - AppVersion taken from safiLogonInfo :AppVersion: "+safiLogonInfo.getAppVersion(),SafiWebHelper.class);
		 }
		 
		 populateSafiVO(request, devicePrint, commonData, isMobileApp,safiPayTranVO,last2FASuccessTime);
		 
		 Logger.debug("SAFI : SafiWebHelper.populateSafiPayTranVOForThirdPartyPayment() after populateSafiVO() - safiPayTranVO: "+safiPayTranVO,SafiWebHelper.class);
		 
		//Set to true if the customer has already been challenged in the past when: adding the payee to the payee�s list; or when attempting a payment.
		safiPayTranVO.setPayee2FAd(thirdPartyPayment.getToThirdParty().isTrustedThirdParty());
		
		//Making DB call to get latest data for first payment date for Osko payment as it will be updated based on 502 response and not available in cache
		 boolean isNewPayee;
		 if(SafiConstants.OSKO.equalsIgnoreCase(mobileSession.getPaymentType())) {
			 
			 if(thirdPartyPayment.getToThirdParty().getFirstPaymentDate() == null){
				 isNewPayee = ThirdPartyTransferHelper.isFirstPaymentDateAvailableForThirdParty(thirdPartyPayment) == true ? false : true;
			 }else{
				 isNewPayee = false;
			 }

		 } else {
			 isNewPayee = (thirdPartyPayment.getToThirdParty().getFirstPaymentDate() == null) ? true : false;
		 }
		 
		if(isNewPayee) {
			 safiPayTranVO.setNewPayee(true);
		 } else {
			 safiPayTranVO.setNewPayee(false);
		 }
		
		if(SafiConstants.OSKO.equalsIgnoreCase(mobileSession.getPaymentType())){
			safiPayTranVO.setPayeeType(SafiConstants.CLIENT_DEFINED_EVENT_TYPE_OSKO);
		}else{
			safiPayTranVO.setPayeeType(SafiConstants.PAY_ANYONE_PAYEE_TYPE);
		}
		safiPayTranVO.setAmount(thirdPartyPayment.getAmount());
		safiPayTranVO.setCurrencyCode(SafiConstants.CURRENCY_TYPE_AUD);
		
		//For all non scheduled payments, set the current date in yyyy-MM-dd format as due date
		//This includes On Us, DE and OSKO transfers
		safiPayTranVO.setDueDate(new Date());
		
		boolean isStgGroupTransfer = isStgGroupTransfer(thirdPartyPayment.getToThirdParty(), commonData.getOrigin());
		boolean isOnUsTransfer = ThirdPartyTransferHelper.isOnUsTransferForDE(thirdPartyPayment, thirdPartyPayment.getToThirdParty());
		Logger.debug("SAFI : SafiWebHelper.populateSafiPayTranVOForThirdPartyPayment(): isOnUsTransfer payment:  "+isOnUsTransfer, SafiWebHelper.class);
		
		 if(isOnUsTransfer || SafiConstants.OSKO.equalsIgnoreCase(mobileSession.getPaymentType())) {
			 safiPayTranVO.setExecutionSpeed(SafiConstants.REAL_TIME_EXECUTION_SPEED);
		 } else {
			 safiPayTranVO.setExecutionSpeed(SafiConstants.OVER_NIGHT_EXECUTION_SPEED);
		 }

		 safiPayTranVO.setSchedule(SafiConstants.IMMEDIATE_TRANSFER);

		 setOtherAccountDetails(safiPayTranVO, isStgGroupTransfer);
			 
		 SafiPayerAccountDetails payerDetails = new SafiPayerAccountDetails();
		 SafiPayeeAccountDetails payeeDetails = new SafiPayeeAccountDetails();
		 setPayerDetails(thirdPartyPayment, payerDetails);
		 
		 setPayeeDetails(thirdPartyPayment, safiPayTranVO, payeeDetails);
		 
		 if(SafiConstants.OSKO.equalsIgnoreCase(mobileSession.getPaymentType())) {
			 safiPayTranVO.setEventType(SafiConstants.PAY_OSKO_PAYEE_TYPE);
		 } else {
			 safiPayTranVO.setEventType(SafiConstants.PAY_ANYONE_PAYEE_TYPE);
		 }
		 
		 setEventDescription(thirdPartyPayment, safiPayTranVO);
		 
		 safiPayTranVO.setPayerDetails(payerDetails);
		 safiPayTranVO.setPayeeDetails(payeeDetails);
		 safiPayTranVO.setDescription(thirdPartyPayment.getDescription());

		 Logger.debug("SAFI : SafiWebHelper.populateSafiPayTranVOForThirdPartyPayment(): SafiPayerAccountDetails:  "+payerDetails, SafiWebHelper.class);
		 Logger.debug("SAFI : SafiWebHelper.populateSafiPayTranVOForThirdPartyPayment(): SafiPayeeAccountDetails:  "+payeeDetails, SafiWebHelper.class); 

		 Logger.debug("SAFI : SafiWebHelper.populateSafiPayTranVOForThirdPartyPayment() for Safi Analyse Call : END: isMobileApp: "+isMobileApp+" devicePrint: "+devicePrint,SafiWebHelper.class);
		 
		 return safiPayTranVO;
		 
	 }	 

public static SafiPayTranVO populateSafiPayTranVOForPayIdPayment(HttpServletRequest request,ThirdPartyPayment thirdPartyPayment,IBankCommonData commonData,String devicePrint,MobileSession mobileSession,boolean isMobileApp){
	  
	 Logger.debug("SAFI : SafiWebHelper.populateSafiPayTranVOForPayIdPayment() for Safi Analyse Call : START: isMobileApp: "+isMobileApp+" devicePrint: "+devicePrint,SafiWebHelper.class);
	 
	 SafiPayTranVO safiPayTranVO = new SafiPayTranVO();
	 String last2FASuccessTime = null;
	 
	 last2FASuccessTime = getLast2FASuccessTime(mobileSession);
	 
	 SafiLogonInfo safiLogonInfo =  mobileSession.getSafiLogonInfo();
	 if(safiLogonInfo != null && isMobileApp){ 
		 Logger.debug("SAFI : From NATIVE APP - SafiWebHelper.populateSafiPayTranVOForPayIdPayment() :devicePrint1: "+devicePrint,SafiWebHelper.class);
		 devicePrint = safiLogonInfo.getDevicePrint();
		 Logger.debug("SAFI : From NATIVE APP - devicePrint taken from safiLogonInfo :devicePrint2: "+devicePrint,SafiWebHelper.class);
		 safiPayTranVO.setPhonePerms(safiLogonInfo.getPhonePerms());
		 Logger.debug("SAFI : From NATIVE APP - PhonePerms taken from safiLogonInfo :PhonePerms: "+safiLogonInfo.getPhonePerms(),SafiWebHelper.class);
		 safiPayTranVO.setLocationPerms(safiLogonInfo.getLocationPerms());
		 Logger.debug("SAFI : From NATIVE APP - LocationPerms taken from safiLogonInfo :LocationPerms: "+safiLogonInfo.getLocationPerms(),SafiWebHelper.class);
		 safiPayTranVO.setAppVersion(safiLogonInfo.getAppVersion());
		 Logger.debug("SAFI : From NATIVE APP - AppVersion taken from safiLogonInfo :AppVersion: "+safiLogonInfo.getAppVersion(),SafiWebHelper.class);
	 }
	 
	 populateSafiVO(request, devicePrint, commonData, isMobileApp,safiPayTranVO,last2FASuccessTime);
	 
	 Logger.debug("SAFI : SafiWebHelper.populateSafiPayTranVOForPayIdPayment() after populateSafiVO() - safiPayTranVO: "+safiPayTranVO,SafiWebHelper.class);
	 
	safiPayTranVO.setPayeeType(SafiConstants.CLIENT_DEFINED_EVENT_TYPE_PAYID);
		
	safiPayTranVO.setAmount(thirdPartyPayment.getAmount());
	safiPayTranVO.setCurrencyCode(SafiConstants.CURRENCY_TYPE_AUD);
	
	//For all non scheduled payments, set the current date in yyyy-MM-dd format as due date
	//This includes On Us, DE and OSKO transfers
	safiPayTranVO.setDueDate(new Date());
	
	//Check if setOtherAccountBankType is required 
	boolean isStgGroupTransfer = isStgGroupTransfer(thirdPartyPayment.getToThirdParty(), commonData.getOrigin());
	boolean isOnUsTransfer = ThirdPartyTransferHelper.isOnUsTransferForDE(thirdPartyPayment, thirdPartyPayment.getToThirdParty());
	Logger.debug("SAFI : SafiWebHelper.populateSafiPayTranVOForPayIdPayment(): isOnUsTransfer payment:  "+isOnUsTransfer, SafiWebHelper.class);
	
	safiPayTranVO.setExecutionSpeed(SafiConstants.REAL_TIME_EXECUTION_SPEED);

	safiPayTranVO.setSchedule(SafiConstants.IMMEDIATE_TRANSFER);

	setOtherAccountDetails(safiPayTranVO, isStgGroupTransfer);
	
	SafiPayerAccountDetails payerDetails = new SafiPayerAccountDetails();
	SafiPayeeAccountDetails payeeDetails = new SafiPayeeAccountDetails();
	SafiPayIdDetails payIdDetails = new SafiPayIdDetails();
	
	setPayerDetails(thirdPartyPayment, payerDetails);
	
	setPayeeDetails(thirdPartyPayment, safiPayTranVO, payeeDetails);
	
	setPayIdDetails(mobileSession, payIdDetails);
	
	safiPayTranVO.setSafiPayIdDetails(payIdDetails);
	 
	safiPayTranVO.setEventType(SafiConstants.PAY_OSKO_PAYEE_TYPE);
	
	setEventDescription(thirdPartyPayment, safiPayTranVO);
	
	safiPayTranVO.setPayerDetails(payerDetails);
	safiPayTranVO.setPayeeDetails(payeeDetails);
	safiPayTranVO.setDescription(thirdPartyPayment.getDescription());
	safiPayTranVO.setNewPayee(mobileSession.getPayIDResolution().isNewPayIDPayee());
	//set payee 2FA flag as true based on payid resolution 2FA or if the payee already trusted.
	if (mobileSession.getPayIDResolution().isIs2FAdone() || isPayIDPayeeTrusted(
			commonData.getCustomer().getNppPayIdPayees(), mobileSession.getPayIDResolution())) {
		safiPayTranVO.setPayee2FAd(true);
	}

	Logger.debug("SAFI : SafiWebHelper.populateSafiPayTranVOForPayIdPayment(): SafiPayeeAccountDetails:  "+payeeDetails, SafiWebHelper.class); 

	Logger.debug("SAFI : SafiWebHelper.populateSafiPayTranVOForPayIdPayment() for Safi Analyse Call : END: isMobileApp: "+isMobileApp+" devicePrint: "+devicePrint,SafiWebHelper.class);
	 
	return safiPayTranVO;
	 
}

	private static boolean isPayIDPayeeTrusted(List<NPPPayIdPayee> payIdPayeeList, PayIDResolution payIDResolution) {
		boolean isTrusted = false;
		if(null != payIdPayeeList) {
			for (NPPPayIdPayee nppPayIdPayee : payIdPayeeList) {
				if (nppPayIdPayee.getPayId().equals(payIDResolution.getPayIDValue())
						&& nppPayIdPayee.getPayIdType().equals(payIDResolution.getPayIDTypeOrig())
						&& nppPayIdPayee.getTrusted().equals(NPPPayIdPayee.TRUSTED_STATUS)) {
					isTrusted = true;
					break;
				}
			}
		}
		return isTrusted;
	}

	public static SafiPayTranVO populateSafiPayIdResolutionVO(HttpServletRequest request, IBankCommonData commonData,
			String devicePrint, MobileSession mobileSession, boolean isMobileApp, String payIdType, String payIdValue,
			int payeePayIDindex) {

		Logger.debug("SAFI : SafiWebHelper.populateSafiPayIdResolutionVO() for Safi Analyse Call : START: isMobileApp: "
				+ isMobileApp + " devicePrint: " + devicePrint, SafiWebHelper.class);

		SafiPayTranVO safiPayTranVO = new SafiPayTranVO();
		SafiLogonInfo safiLogonInfo = mobileSession.getSafiLogonInfo();

		if (safiLogonInfo != null && isMobileApp) {
			Logger.debug("SAFI : From NATIVE APP - SafiWebHelper.populateSafiPayIdResolutionVO() :devicePrint1: "
					+ devicePrint, SafiWebHelper.class);
			devicePrint = safiLogonInfo.getDevicePrint();
			Logger.debug("SAFI : From NATIVE APP - devicePrint taken from safiLogonInfo :devicePrint2: " + devicePrint,
					SafiWebHelper.class);
			safiPayTranVO.setPhonePerms(safiLogonInfo.getPhonePerms());
			Logger.debug("SAFI : From NATIVE APP - PhonePerms taken from safiLogonInfo :PhonePerms: "
					+ safiLogonInfo.getPhonePerms(), SafiWebHelper.class);
			safiPayTranVO.setLocationPerms(safiLogonInfo.getLocationPerms());
			Logger.debug("SAFI : From NATIVE APP - LocationPerms taken from safiLogonInfo :LocationPerms: "
					+ safiLogonInfo.getLocationPerms(), SafiWebHelper.class);
			safiPayTranVO.setAppVersion(safiLogonInfo.getAppVersion());
			Logger.debug("SAFI : From NATIVE APP - AppVersion taken from safiLogonInfo :AppVersion: "
					+ safiLogonInfo.getAppVersion(), SafiWebHelper.class);
		}

		populateSafiVO(request, devicePrint, commonData, isMobileApp, safiPayTranVO,
				getLast2FASuccessTime(mobileSession));
		Logger.debug("SAFI : SafiWebHelper.populateSafiPayIdResolutionVO() after populateSafiVO() - safiPayTranVO: "
				+ safiPayTranVO, SafiWebHelper.class);

		SafiPayIdDetails payIdDetails = new SafiPayIdDetails();

		// Passing false all the time, needs to be revised once compass starts storing
		// Payid in Address book
		if (!StringUtils.isEmpty(payIdType) && !StringUtils.isEmpty(payIdValue)) {
			payIdDetails.setPayIdType(NPPUtil.getSafiPayIdType(payIdType));
			payIdDetails.setPayIdValue(NPPUtil.payIdCustomFactsFormatting(payIdValue, payIdType));

			// Below two values has to be persisted and sent to MB UI when user successfully
			// completes 2FA challenge from SAFI
			payIdDetails.setPayIdUserValue(payIdValue);
			payIdDetails.setPayIdTypeUserValue(payIdType);

			safiPayTranVO.setSafiPayIdDetails(payIdDetails);
			// set new payee and 2FA flag accordingly
			if (payeePayIDindex == NEW_PAYID_INDEX) {
				safiPayTranVO.setNewPayee(true);
			} else {
				try {
					if(null != commonData.getCustomer().getNppPayIdPayees()) {
						NPPPayIdPayee nppPayIdPayee = commonData.getCustomer().getNppPayIdPayees().get(payeePayIDindex);
						if (StringUtils.isNotEmpty(nppPayIdPayee.getTrusted())
								&& nppPayIdPayee.getTrusted().equals(NPPPayIdPayee.TRUSTED_STATUS)) {
							safiPayTranVO.setPayee2FAd(true);
						}
					}
				} catch (Exception e) {
					Logger.error(
							"SAFI : SafiWebHelper.populateSafiPayIdResolutionVO() Error while getting payID payee from session - safiPayTranVO: "
									+ safiPayTranVO,
							SafiWebHelper.class);
				}
			}

			Logger.debug("SAFI : SafiWebHelper.populateSafiPayIdResolutionVO(): SafiPayIdDetails:  " + payIdDetails,
					SafiWebHelper.class);
		}

		Logger.debug("SAFI : SafiWebHelper.populateSafiPayIdResolutionVO() for Safi Analyse Call : END: isMobileApp: "
				+ isMobileApp + " devicePrint: " + devicePrint, SafiWebHelper.class);

		return safiPayTranVO;
	}

public static void populateSafiVOForNotifyPayIdResolution(HttpServletRequest httpRequest, MobileSession mobileSession, LabelValueMap digitalSecMap,Boolean status2FA) {
	
	SafiPayTranVO safiPayTranVO = mobileSession.getSafiPayTranVOForPayIdResolution();

	if(safiPayTranVO != null && mobileSession.getSafiPayTranVOForPayIdResolution().getSafiRespVO() != null){
		Logger.debug("mobileSession.getSafiPayTranVO().getSafiRespVO().getSafiChallengeEventRefId() : "+mobileSession.getSafiPayTranVOForPayIdResolution().getSafiRespVO().getSafiChallengeEventRefId(), SafiWebHelper.class);
		safiPayTranVO.setSafiChallengeEventRefId(mobileSession.getSafiPayTranVOForPayIdResolution().getSafiRespVO().getSafiChallengeEventRefId());
		safiPayTranVO.setSafiSessionId(mobileSession.getSafiPayTranVOForPayIdResolution().getSafiRespVO().getSafiSessionId());
		Logger.debug("Session id from safiLogonInfo in populateSafiVOForNotifyPayIdResolution():"+safiPayTranVO.getSafiSessionId(), SafiWebHelper.class);
	}
	
	if(digitalSecMap.get(DigitalSecLogger.AUTHTYPE) != null){
		safiPayTranVO.setOtpDeliveryMethod(digitalSecMap.get(DigitalSecLogger.AUTHTYPE));
	}
	
	if(digitalSecMap.get(DigitalSecLogger.AUTHPHONE) != null) {
		safiPayTranVO.setOtpPhoneUsed(digitalSecMap.get(DigitalSecLogger.AUTHPHONE));
	}
	
	Cookie pmdata2Cookie = readCookies(httpRequest);
	if (null != pmdata2Cookie && !StringMethods.isEmptyString(pmdata2Cookie.getValue())) {
		safiPayTranVO.setDeviceTokenValue(pmdata2Cookie.getValue());
		Logger.debug("populateSafiVOForNotifyPayIdResolution() Setting new value for device token from PMDATA2 cookie : "+pmdata2Cookie.getValue(), SafiWebHelper.class); 
	}
	
	safiPayTranVO.setSafiChallengeSuccess(status2FA);
}

private static void setPayIdDetails(MobileSession mobileSession, SafiPayIdDetails payIdDetails) {
	PayIDResolution payIdResolution = mobileSession.getPayIDResolution();
	
	if(null != payIdResolution){
		
		//Passing false all the time, needs to be revised once compass starts storing Payid in Address book
		payIdDetails.setPayIdShortNameChanged(false);
		payIdDetails.setPayIdAccountType(payIdResolution.getSchemeName().equalsIgnoreCase("AIIN")?"CC":"BSB");
		payIdDetails.setPayIdValue(NPPUtil.payIdCustomFactsFormatting(payIdResolution.getPayIDValue(), payIdResolution.getPayIDType()));
		payIdDetails.setPayIdShortName(NPPUtil.payIdCustomFactsFormatting(payIdResolution.getShortName(), payIdResolution.getPayIDType()));
		payIdDetails.setPayIdType(NPPUtil.getSafiPayIdType(payIdResolution.getPayIDTypeOrig()));
		payIdDetails.setCustomerType(NPPUtil.populateCustomerType(mobileSession.getCustomer()));
		Logger.debug("SAFI : SafiWebHelper.populateSafiPayTranVOForPayIdPayment(): SafiPayIdDetails:  "+payIdDetails, SafiWebHelper.class);
	}else{
		Logger.debug("SAFI : SafiWebHelper.populateSafiPayTranVOForPayIdPayment(): SafiPayIdDetails not populated.", SafiWebHelper.class);
	}
}

private static void setPayeeDetails(ThirdPartyPayment thirdPartyPayment,
		SafiPayTranVO safiPayTranVO, SafiPayeeAccountDetails payeeDetails) {
	ThirdParty toThirdParty = thirdPartyPayment.getToThirdParty();
	if(toThirdParty != null) {
		payeeDetails.setAccountName(SafiUtil.validateAndReplace(toThirdParty.getName() != null && toThirdParty.getName().length() > SafiConstants.PAYEE_ACCOUNT_NAME_LIMIT
				? toThirdParty.getName().substring(0, SafiConstants.PAYEE_ACCOUNT_NAME_LIMIT) : toThirdParty.getName()));
		 payeeDetails.setAccountNumber(toThirdParty.getNumber().length() > SafiConstants.PAYEE_ACCOUNT_NUM_LIMIT 
				 ? toThirdParty.getNumber().substring(0, SafiConstants.PAYEE_ACCOUNT_NUM_LIMIT) : toThirdParty.getNumber());
		 payeeDetails.setRoutingCode(toThirdParty.getBsb().length() > SafiConstants.PAYEE_BSB_LIMIT 
				 ? toThirdParty.getBsb().substring(0, SafiConstants.PAYEE_ACCOUNT_NUM_LIMIT) : toThirdParty.getBsb());
		 safiPayTranVO.setDestinationAccount(toThirdParty.getBsb()+toThirdParty.getNumber());
	}
}

private static String getLast2FASuccessTime(MobileSession mobileSession) {
	String last2FASuccessTime;
	if(mobileSession.getSafiLast2FASuccessTime() != null){
		 last2FASuccessTime = SafiUtil.calculateLast2FASuccessTime(mobileSession.getSafiLast2FASuccessTime());
	 }else{
		 last2FASuccessTime = SafiConstants.DEFAULT_TIME_LAST2FA_SUCCESS;
	 }
	return last2FASuccessTime;
}

private static void setOtherAccountDetails(SafiPayTranVO safiPayTranVO,
		boolean isStgGroupTransfer) {
	if(isStgGroupTransfer) {
		safiPayTranVO.setOtherAccountBankType(SafiConstants.OTHER_BANK_ACCOUNT_TYPE_STG_TRANSFER);
	} else {
		safiPayTranVO.setOtherAccountBankType(SafiConstants.OTHER_BANK_ACCOUNT_TYPE_ALL_TRANSFER);
	}

	safiPayTranVO.setOtherAccountOwnershipType(SafiConstants.OTHER_ACCOUNT_OWNERSHIP);
	safiPayTranVO.setOtherAccountType(SafiConstants.OTHER_ACCOUNT_TYPE_ALL);
	safiPayTranVO.setTransferMediumType(SafiConstants.TRANSFER_MEDIUM_OTHERS);
}

private static void setPayerDetails(ThirdPartyPayment thirdPartyPayment,
		SafiPayerAccountDetails payerDetails) {
	AccountId fromAccount = thirdPartyPayment.getFromAccount();
	 if(fromAccount != null) {
		 if(!StringMethods.isEmptyString(fromAccount.getAccountNumber())) {
			 payerDetails.setAccountNumber(fromAccount.getAccountNumber().length() > SafiConstants.PAYER_ACCOUNT_NUM_LIMIT 
					 ? fromAccount.getAccountNumber().substring(0, SafiConstants.PAYER_ACCOUNT_NUM_LIMIT) : fromAccount.getAccountNumber()); 
		 }
		 
		 if(fromAccount.getEhubProductCode().equalsIgnoreCase(AccountId.EHUB_CODE_SAVING)) {
			 payerDetails.setAccountType(SafiConstants.PAYER_ACC_TYPE_SAVINGS);
		 } else {
			 payerDetails.setAccountType(SafiConstants.PAYER_ACC_TYPE_CHECKING);
		 }

		 if(!StringMethods.isEmptyString(fromAccount.getBsb())) {
			 payerDetails.setRoutingCode(fromAccount.getBsb().length() > SafiConstants.PAYER_BSB_LIMIT 
					 ? fromAccount.getBsb().substring(0, SafiConstants.PAYER_BSB_LIMIT) : fromAccount.getBsb());
		 }
	 }
}

private static void setEventDescription(ThirdPartyPayment thirdPartyPayment,
		SafiPayTranVO safiPayTranVO) {
	if(!StringMethods.isEmptyString(thirdPartyPayment.getDescription())) {
		 safiPayTranVO.setEventDescription(SafiUtil.validateAndReplace(thirdPartyPayment.getDescription().length() > SafiConstants.PAYEE_DESCRIPTION_LIMIT 
				 ? thirdPartyPayment.getDescription().substring(0, SafiConstants.PAYEE_DESCRIPTION_LIMIT) : thirdPartyPayment.getDescription()));
	 } else {
		 safiPayTranVO.setEventDescription("");
	 }
}

/**
 * This method checks whether the BSB is St.George group or not from parametarised BSBs
 * 
 * @param ThirdParty
 * @return
 */
private static boolean isStgGroupTransfer(ThirdParty toThirdParty, String origin) {
	Logger.debug("Start of isStgGroupTransfer: PayeeBSB : [ " + toThirdParty.getBsb() + " ]", SafiWebHelper.class);
	boolean onUsBSB = false;
	List<String> onusBSBList = (List<String>) IBankParams.getArrayListFromString(IBankParams.getCodesData(origin, CATEGORY_ONUS, ONUSBSB).getMessage());
	if (onusBSBList.size() > 0 && onusBSBList.contains(toThirdParty.getBsb().substring(0, 2))) {
		onUsBSB = true;
	}
	Logger.debug("End of isStgGroupTransfer  ? " + onUsBSB, SafiWebHelper.class);
	return onUsBSB;
}
	
	public static void populateSafiVOForNotifyThirdPartyPayment(HttpServletRequest httpRequest, MobileSession mobileSession, ThirdPartyPayment payment,LabelValueMap digitalSecMap,Boolean status2FA,boolean isPaymentSuccess){
	
		SafiPayTranVO safiPayTranVO = payment.getSafiPayTranVO();

		if(payment != null && payment.getSafiRespVO() != null){
			Logger.debug("payment.getSafiRespVO().getSafiChallengeEventRefId() : "+payment.getSafiRespVO().getSafiChallengeEventRefId(), SafiWebHelper.class);
			safiPayTranVO.setSafiChallengeEventRefId(payment.getSafiRespVO().getSafiChallengeEventRefId());
			safiPayTranVO.setSafiSessionId(payment.getSafiRespVO().getSafiSessionId());
			Logger.debug("Session id from safiLogonInfo in populateSafiVOForNotifyThirdPartyPayment():"+safiPayTranVO.getSafiSessionId(), SafiWebHelper.class);
		}
		
		if(digitalSecMap.get(DigitalSecLogger.AUTHTYPE) != null){
			safiPayTranVO.setOtpDeliveryMethod(digitalSecMap.get(DigitalSecLogger.AUTHTYPE));
		}
		
		if(digitalSecMap.get(DigitalSecLogger.AUTHPHONE) != null) {
			safiPayTranVO.setOtpPhoneUsed(digitalSecMap.get(DigitalSecLogger.AUTHPHONE));
		}
		
		Cookie pmdata2Cookie = readCookies(httpRequest);
		if (null != pmdata2Cookie && !StringMethods.isEmptyString(pmdata2Cookie.getValue())) {
			safiPayTranVO.setDeviceTokenValue(pmdata2Cookie.getValue());
			Logger.debug("populateSafiVOForNotifyThirdPartyPayment() Setting new value for device token from PMDATA2 cookie : "+pmdata2Cookie.getValue(), SafiWebHelper.class); 
		}
		
		safiPayTranVO.setSafiChallengeSuccess(status2FA);
		safiPayTranVO.setPaymentSuccessful(isPaymentSuccess);
	}
	
	public static SafiPayTranVO populateSafiPayTranVOForBPay(HttpServletRequest request,BPayPayment bpayPayment,IBankCommonData commonData,String devicePrint,MobileSession mobileSession,boolean isMobileApp){
		Logger.debug("SAFI : SafiWebHelper.populateSafiPayTranVOForBPay() for Safi Analyse Call : START: isMobileApp: "+isMobileApp,SafiWebHelper.class);

		SafiPayTranVO safiPayTranVO = new SafiPayTranVO();
		String last2FASuccessTime = null;
		String sdkDevicePrint = null;

		last2FASuccessTime = getLast2FASuccessTime(mobileSession);

		SafiLogonInfo safiLogonInfo =  mobileSession.getSafiLogonInfo();

		if(safiLogonInfo != null && isMobileApp){
			sdkDevicePrint = safiLogonInfo.getDevicePrint();
			safiPayTranVO.setPhonePerms(safiLogonInfo.getPhonePerms());
			safiPayTranVO.setLocationPerms(safiLogonInfo.getLocationPerms());
			safiPayTranVO.setAppVersion(safiLogonInfo.getAppVersion());
			populateSafiVO(request, sdkDevicePrint, commonData, isMobileApp,safiPayTranVO,last2FASuccessTime);
		}else{
			populateSafiVO(request, devicePrint, commonData, isMobileApp,safiPayTranVO,last2FASuccessTime);
		}

		SafiBillerDetails billerDetails = new SafiBillerDetails();
		Biller biller = bpayPayment.getToBiller();

		boolean isNewBiller = isNewBiller(commonData.getCustomer().getGcis(), biller.getCode(),biller.getLastReferenceNumber());		
		billerDetails.setBillerCode(biller.getCode());
		billerDetails.setBillerCodeReference(bpayPayment.getReferenceNumber());		
		billerDetails.setWhiteListedBiller(IBankParams.isSafeBiller(biller.getCode()));
		billerDetails.setTrustedBiller(!IBankParams.isHighRiskBiller(biller.getCode()));

		safiPayTranVO.setSafiBillerDetails(billerDetails);
		safiPayTranVO.setPayee2FAd(isBiller2FAD(biller, commonData));
		safiPayTranVO.setNewPayee(isNewBiller);
		safiPayTranVO.setPayeeType(SafiConstants.BPAY_PAYEE_TYPE);
		safiPayTranVO.setAmount(bpayPayment.getAmount());
		safiPayTranVO.setCurrencyCode(SafiConstants.CURRENCY_TYPE_AUD);
		Date dueDate = isImmediateTransfer(bpayPayment) ? getCurrentDate() : getScheduleDate(bpayPayment);
		safiPayTranVO.setDueDate(dueDate);
		String schedule =  getSchedule(bpayPayment);
		safiPayTranVO.setSchedule(schedule);

		SafiPayerAccountDetails payerAccountDetails = getSafiPayerAccountDetails(bpayPayment);
		safiPayTranVO.setPayerDetails(payerAccountDetails);

		SafiPayeeAccountDetails payeeAccountDetails = getSafiPayeeAccountDetails(bpayPayment, biller);
		safiPayTranVO.setPayeeDetails(payeeAccountDetails);

		Logger.debug("SAFI : SafiWebHelper.populateSafiPayTranVOForBPay() for Safi Analyse Call : END"+isMobileApp,SafiWebHelper.class);
		return safiPayTranVO;
	}
	 
	private static Date getCurrentDate(){
		Date currentDate = Calendar.getInstance().getTime();
		return currentDate;		
	}
	
	private static Date getScheduleDate(BPayPayment bpayPayment){
		Date date = null;
		ScheduleDetails scheduleDetails = bpayPayment.getScheduleDetails();
		if (isRecurringTransfer(scheduleDetails)){
			date = scheduleDetails.getFirstPaymentDate();
		}else{
			date = scheduleDetails.getLastPaymentDate();
		}		
		return date;
	}

	private static SafiPayerAccountDetails getSafiPayerAccountDetails(BPayPayment bpayPayment){
		SafiPayerAccountDetails payerAccountDetails = new SafiPayerAccountDetails();
		AccountId accountId = bpayPayment.getFromAccount();
		payerAccountDetails.setAccountNumber(accountId.getAccountNumber());

		if(accountId != null && AccountId.EHUB_CODE_SAVING.equalsIgnoreCase(accountId.getEhubProductCode())){
			payerAccountDetails.setAccountType(SafiConstants.PAYER_ACC_TYPE_SAVINGS);
		}else{
			payerAccountDetails.setAccountType(SafiConstants.PAYER_ACC_TYPE_CHECKING);
		}
		
		payerAccountDetails.setRoutingCode(accountId.getBsb());
		return payerAccountDetails;
	}
	
	private static SafiPayeeAccountDetails getSafiPayeeAccountDetails(BPayPayment bpayPayment, Biller biller){
		SafiPayeeAccountDetails payeeAccountDetails = new SafiPayeeAccountDetails();
		
		payeeAccountDetails.setAccountName(SafiUtil.validateAndReplace(biller.getBillerAlias()));
		payeeAccountDetails.setAccountNumber(bpayPayment.getReferenceNumber());
		payeeAccountDetails.setRoutingCode(biller.getCode());
		return payeeAccountDetails;
	}	
	
	private static boolean isRecurringTransfer(ScheduleDetails scheduleDetails){
		return !ScheduleDetails.FREQUENCY_ONCE_ONLY.equalsIgnoreCase(scheduleDetails.getFrequency());
	}
	
	private static boolean isImmediateTransfer(BPayPayment bpayPayment){
		return bpayPayment.getScheduleDetails() == null;
	}
	private static String getSchedule(BPayPayment bpayPayment){
		String schedule = null;		
		schedule = isImmediateTransfer(bpayPayment) ? SafiConstants.IMMEDIATE_TRANSFER : getSchedule(bpayPayment.getScheduleDetails());
		return schedule;
	}
	
	private static String getSchedule(ScheduleDetails scheduleDetails){
		String schedule = null;
		if (isRecurringTransfer(scheduleDetails)){
			schedule = SafiConstants.RECURRING_TRANSFER;
		}else{
			schedule = SafiConstants.SCHEDULED_TRANSFER;
		}
		
		return schedule;
	}
	
	private static boolean isNewBiller(String gcisNumber, String billerCode,String lastReferenceNumber){			
		FavouriteBillersVO favBiller = BPayService.getFavBiller(gcisNumber, billerCode,lastReferenceNumber);
		boolean isNewBiller = favBiller == null ? true : favBiller.getFirstPaymentDate() != null ? false : true;
		return isNewBiller;
	}
	
	private static boolean isBiller2FAD(Biller biller, IBankCommonData commonData){
		String trustedStatus = BPayService.findTrustedBiller(biller, commonData);
		return trustedStatus.equalsIgnoreCase(SafiConstants.TRUSTED_STATUS) ? true : false;			
	}
	
	 public static SafiPayIdVO populateSafiPayIdVO(HttpServletRequest request, String devicePrint, MobileSession mobileSession,
			 boolean isMobileApp, IBankCommonData commonData, PayIdDetails payIdDetails, boolean isNppABNPayIdRegSwitchOn) {
		SafiPayIdVO safiPayIdVO = new SafiPayIdVO(); 
		safiPayIdVO = (SafiPayIdVO)populateSafiVO(request,devicePrint, commonData , isMobileApp, safiPayIdVO, getLast2FASuccessTime(mobileSession));
		setNativeAppCustomFacts(mobileSession, isMobileApp, safiPayIdVO);
		 
		 ManagePayIdDetails payIdDetailsFromSession = mobileSession.getPayIdDetails();
		 if(payIdDetailsFromSession != null && payIdDetailsFromSession.isUpdateFlow()){
			 safiPayIdVO.setEventType(SafiConstants.CLIENT_DEFINED_EVENT_TYPE_UPDATE_PAYID);
			 if(isNppABNPayIdRegSwitchOn) {
				 ManageExistingPayIdDetails existingPayIdDetails = payIdDetailsFromSession.getActivePayIdDetailsMap().get(ManageExistingPayIdDetails.PayIdTypeEnum.valueOf(payIdDetailsFromSession.getSelectedPayIdType()));
				 payIdDetails.setPayIdStatus(existingPayIdDetails.getPayIdStatus());
			 }else {
				 payIdDetails.setPayIdStatus(payIdDetailsFromSession.getPayIdStatus());
			 }
		 }else{
			 safiPayIdVO.setEventType(SafiConstants.CLIENT_DEFINED_EVENT_TYPE_REGISTER_PAYID);
		 }
		 populateSafiPayIdCustomFacts(safiPayIdVO, payIdDetails);
		 return safiPayIdVO;
	 }
	 
	 private static void populateSafiPayIdCustomFacts(SafiPayIdVO safiPayIdVO, PayIdDetails payIdDetails) {
		 String payId = (NPPUtil.PAYID_TYPE_ABNACN.equals(payIdDetails.getPayIdType())) ? payIdDetails.getPayIdNumber() : payIdDetails.getPayIdMobileNumber();
		 safiPayIdVO.setPayIdType(NPPUtil.getSafiPayIdType(payIdDetails.getPayIdType()));
		 safiPayIdVO.setPayIdValue(NPPUtil.payIdCustomFactsFormatting(payId , payIdDetails.getPayIdType()));
		 safiPayIdVO.setPayIdShortName(NPPUtil.payIdCustomFactsFormatting(payIdDetails.getPayIdName(),payIdDetails.getPayIdType()));
		 safiPayIdVO.setPayIdAccountType("BSB");			
		 safiPayIdVO.setDestinationAccount(NPPUtil.payIdCustomFactsFormatting(payIdDetails.getDestBSB() + payIdDetails.getDestAccountNumber(), payIdDetails.getPayIdType()));	 
		 safiPayIdVO.setPayIdStatus(StringUtils.upperCase(payIdDetails.getPayIdStatus()));
	 }
	 
	 public static SafiPayIdVO populateSafiVOForPayIdNotify(HttpServletRequest httpServletRequest,
			 MobileSession mobileSession, IBankCommonData commonData, boolean isChallengeSuccessful){
			
		 SafiPayIdVO safiPayIdVO = (SafiPayIdVO)mobileSession.getSafiRequestVO();
		 SafiRespVO safiRespVO = safiPayIdVO.getSafiRespVO();
		 SecureCodeDetails secureCodeDetails = mobileSession.getSecureCodeDetails();
		 
		 safiPayIdVO.setSafiChallengeSuccess(isChallengeSuccessful);
		 safiPayIdVO.setSafiChallengeEventRefId(safiRespVO.getSafiChallengeEventRefId());
		 safiPayIdVO.setSafiSessionId(safiRespVO.getSafiSessionId());
		 safiPayIdVO.setDeviceTokenValue(fetchDeviceTokenValue(httpServletRequest));
		 safiPayIdVO.setOtpDeliveryMethod(secureCodeDetails.getDeliveryMethod());
		 
		 PhoneNumber phoneNumber = CommonBusinessUtil.get2FAPhoneNumber(commonData, secureCodeDetails.getPhoneNumber());
		 safiPayIdVO.setOtpPhoneUsed(phoneNumber.getAreaCode()+phoneNumber.getPhoneNumber());
		 
		 return safiPayIdVO;
	 }
	
	 public static String fetchDeviceTokenValue(HttpServletRequest httpServletRequest){
			String deviceTokenValue = null;
			 Cookie pmdata2Cookie = readCookies(httpServletRequest);
				if (null != pmdata2Cookie && !StringMethods.isEmptyString(pmdata2Cookie.getValue())) {
					deviceTokenValue = pmdata2Cookie.getValue();
				}
			return deviceTokenValue;
	 }
	 
	 
	 private static void setNativeAppCustomFacts(MobileSession mobileSession, boolean isMobileApp, SafiVO safiVO) {
		 SafiLogonInfo safiLogonInfo =  mobileSession.getSafiLogonInfo();
		 Logger.debug("Setting Native App Custom facts  isMobileApp " + isMobileApp, SafiWebHelper.class);
			
			if(safiLogonInfo != null && isMobileApp){ 
				safiVO.setPhonePerms(safiLogonInfo.getPhonePerms());
				safiVO.setLocationPerms(safiLogonInfo.getLocationPerms());
				safiVO.setAppVersion(safiLogonInfo.getAppVersion());
			}
	 }
	 
	 /**
	  * 20E2 - Added for Update Phone SAFI call
	  * 
	  * @param request
	  * @param devicePrint
	  * @param commonData
	  * @param isMobileApp
	  * @param safiVO
	  * @param mobileSession
	  * @return SafiUpdatePhoneVO
	  */
	 public static SafiUpdatePhoneVO populateSafiVOForPhoneUpdate(HttpServletRequest request, String devicePrint, IBankCommonData commonData, boolean isMobileApp, SafiUpdatePhoneVO safiVO, MobileSession mobileSession) {
		 
		 safiVO =   (SafiUpdatePhoneVO) populateSafiVO(request, devicePrint, commonData, isMobileApp, safiVO, getLast2FASuccessTime(mobileSession));
		 setNativeAppCustomFacts(mobileSession, isMobileApp, safiVO);
		 if(null != safiVO)
			 safiVO.setEventType(SafiConstants.CLIENT_DEFINED_EVENT_TYPE_CHANGE_SECURE_CODE);
		 
		 return safiVO;
	 }
	 
	 /**
	  * 20E2 - Added for Update Phone SAFI call
	  * 
	  * @param httpServletRequest
	  * @param mobileSession
	  * @param commonData
	  * @param isChallengeSuccessful
	  * @return SafiUpdatePhoneVO
	  */
	 public static SafiUpdatePhoneVO populateSafiVOForUpdatePhoneNotify(HttpServletRequest httpServletRequest,
			 MobileSession mobileSession, IBankCommonData commonData, boolean isChallengeSuccessful){
			
		 SafiUpdatePhoneVO safiVO = (SafiUpdatePhoneVO)mobileSession.getSafiRequestVO();
		 SafiRespVO safiRespVO = safiVO.getSafiRespVO();
		 SecureCodeDetails secureCodeDetails = mobileSession.getSecureCodeDetails();
		 
		 safiVO.setSafiChallengeSuccess(isChallengeSuccessful);
		 safiVO.setSafiChallengeEventRefId(safiRespVO.getSafiChallengeEventRefId());
		 safiVO.setSafiSessionId(safiRespVO.getSafiSessionId());
		 safiVO.setDeviceTokenValue(fetchDeviceTokenValue(httpServletRequest));
		 safiVO.setOtpDeliveryMethod(secureCodeDetails.getDeliveryMethod());
		 
		 PhoneNumber phoneNumber = CommonBusinessUtil.get2FAPhoneNumber(commonData, secureCodeDetails.getPhoneNumber());
		 safiVO.setOtpPhoneUsed(phoneNumber.getAreaCode()+phoneNumber.getPhoneNumber());
		 
		 return safiVO;
	 }	 
	 

	 public static SafiFileshareVO populateSafiVOForFileshare(HttpServletRequest request, String devicePrint, IBankCommonData commonData, boolean isMobileApp, SafiFileshareVO safiVO, MobileSession mobileSession) {
		 
		 safiVO =   (SafiFileshareVO) populateSafiVO(request, devicePrint, commonData, isMobileApp, safiVO, getLast2FASuccessTime(mobileSession));
		 
		 setNativeAppCustomFacts(mobileSession, isMobileApp, safiVO);
		 
		 if(null != safiVO)
			 safiVO.setEventType(SafiConstants.CLIENT_DEFINED_EVENT_TYPE_FILESHARE);
		 
		 return safiVO;
	 }
	 

	 public static SafiFileshareVO populateSafiVOForFileshareNotify(HttpServletRequest httpServletRequest, MobileSession mobileSession, IBankCommonData commonData, boolean isChallengeSuccessful){
			
		 SafiFileshareVO safiVO = (SafiFileshareVO) mobileSession.getSafiRequestVO();
		 SafiRespVO safiRespVO = safiVO.getSafiRespVO();
		 SecureCodeDetails secureCodeDetails = mobileSession.getSecureCodeDetails();
		 
		 safiVO.setSafiChallengeSuccess(isChallengeSuccessful);
		 safiVO.setSafiChallengeEventRefId(safiRespVO.getSafiChallengeEventRefId());
		 safiVO.setSafiSessionId(safiRespVO.getSafiSessionId());
		 safiVO.setDeviceTokenValue(fetchDeviceTokenValue(httpServletRequest));
		 safiVO.setOtpDeliveryMethod(secureCodeDetails.getDeliveryMethod());
		 
		 PhoneNumber phoneNumber = CommonBusinessUtil.get2FAPhoneNumber(commonData, secureCodeDetails.getPhoneNumber());
		 safiVO.setOtpPhoneUsed(phoneNumber.getAreaCode()+phoneNumber.getPhoneNumber());
		 
		 return safiVO;
	 }
	 
	 public static SafiPwdResetVO populateSafiVOForPwdReset(HttpServletRequest request, String devicePrint, IBankCommonData commonData, boolean isMobileApp, SafiPwdResetVO safiVO, MobileSession mobileSession, SafiDeviceInfo safiDeviceInfo) {
		 safiVO =   (SafiPwdResetVO) populateSafiVO(request, devicePrint, commonData, isMobileApp, safiVO, getLast2FASuccessTime(mobileSession));
		 if(safiDeviceInfo != null && isMobileApp){ 
			safiVO.setPhonePerms(safiDeviceInfo.getPhonePerms());
			safiVO.setLocationPerms(safiDeviceInfo.getLocationPerms());
			safiVO.setAppVersion(safiDeviceInfo.getAppVersion());
		}
		 if(null != safiVO)
			 safiVO.setEventType(SafiConstants.CLIENT_DEFINED_EVENT_TYPE_FORGOTTEN_LOGON_CREDENTIALS);
		 
		 return safiVO;
	 }
	
	 public static SafiPwdResetVO populateSafiVOForPwdResetNotify(HttpServletRequest httpServletRequest,
			 MobileSession mobileSession, IBankCommonData commonData, boolean isChallengeSuccessful){
			
		 SafiPwdResetVO safiVO = (SafiPwdResetVO)mobileSession.getSafiRequestVO();
		 SafiRespVO safiRespVO = safiVO.getSafiRespVO();
		 SecureCodeDetails secureCodeDetails = mobileSession.getSecureCodeDetails();
		 
		 safiVO.setSafiChallengeSuccess(isChallengeSuccessful);
		 safiVO.setSafiChallengeEventRefId(safiRespVO.getSafiChallengeEventRefId());
		 safiVO.setSafiSessionId(safiRespVO.getSafiSessionId());
		 safiVO.setDeviceTokenValue(fetchDeviceTokenValue(httpServletRequest));
		 safiVO.setOtpDeliveryMethod(secureCodeDetails.getDeliveryMethod());
		 
		 PhoneNumber phoneNumber = CommonBusinessUtil.get2FAPhoneNumber(commonData, secureCodeDetails.getPhoneNumber());
		 safiVO.setOtpPhoneUsed(phoneNumber.getAreaCode()+phoneNumber.getPhoneNumber());
		 
		 return safiVO;
	 }
	 
public static SafiMgrpVO populateSafiVOForMgrp(HttpServletRequest request, String devicePrint, IBankCommonData commonData, boolean isMobileApp, SafiMgrpVO safiVO, MobileSession mobileSession) {
		 
		 safiVO =   (SafiMgrpVO) populateSafiVO(request, devicePrint, commonData, isMobileApp, safiVO, getLast2FASuccessTime(mobileSession));
		 
		 if(isMobileApp) {
			 safiVO.setCalledFrom(SafiConstants.NATIVE);
			 }
		 else {
				 safiVO.setCalledFrom(SafiConstants.MOBILE);
				 }
		 
		 
		 setNativeAppCustomFacts(mobileSession, isMobileApp, safiVO);
		 
		 if(null != safiVO)
			 safiVO.setEventType(SafiConstants.CLIENT_DEFINED_EVENT_TYPE_FILESHARE);
		 
		 return safiVO;
	 }
	 

	 public static SafiMgrpVO populateSafiVOForMgrpNotify(HttpServletRequest httpServletRequest, MobileSession mobileSession, IBankCommonData commonData, boolean isChallengeSuccessful){
			
		 SafiMgrpVO safiVO = (SafiMgrpVO) mobileSession.getSafiRequestVO();
		 SafiRespVO safiRespVO = safiVO.getSafiRespVO();
		 SecureCodeDetails secureCodeDetails = mobileSession.getSecureCodeDetails();
		 
		 safiVO.setSafiChallengeSuccess(isChallengeSuccessful);
		 safiVO.setSafiChallengeEventRefId(safiRespVO.getSafiChallengeEventRefId());
		 safiVO.setSafiSessionId(safiRespVO.getSafiSessionId());
		 safiVO.setDeviceTokenValue(fetchDeviceTokenValue(httpServletRequest));
		 safiVO.setOtpDeliveryMethod(secureCodeDetails.getDeliveryMethod());
		 
		 PhoneNumber phoneNumber = CommonBusinessUtil.get2FAPhoneNumber(commonData, secureCodeDetails.getPhoneNumber());
		 safiVO.setOtpPhoneUsed(phoneNumber.getAreaCode()+phoneNumber.getPhoneNumber());
		 
		 return safiVO;
	 }
	
	 
	 public static void readCookiesForDeviceInfo(HttpServletRequest request , SafiDeviceInfo deviceInfo){		
		Cookie[] cookies = request.getCookies();
		if (cookies != null) {
			for (Cookie c : cookies) {
				if (c.getName().equalsIgnoreCase(SafiConstants.MOBILE_PM_DP_COOKIE)) {
					Logger.debug("SAFI : Pm_dp is recieved from native : Name ::"+c.getName(), SafiWebHelper.class);
					
					String validVal = SafiUtil.validateSdkCookieVal(c.getName(),c.getValue());
					if(StringMethods.isValidString(validVal)){
						deviceInfo.setValidDevicePrintJson(validVal);
					}
				}
				if(c.getName().equalsIgnoreCase(SafiConstants.MOBILE_DS_PRM_COOKIE)){
					Logger.debug("SAFI : ds_prm is recieved from native at logon : Name ::"+c.getName(), SafiWebHelper.class);
				
					String validVal = SafiUtil.validateSdkCookieVal(c.getName(),c.getValue());
					if(StringMethods.isValidString(validVal)){
						SafiUtil.splitAndPopulateDeviceInfo(validVal , deviceInfo);
					}
				}					
			}
		}else{
			Logger.debug("SAFI : No device information cookies found", SafiWebHelper.class);
		}
	 }
	 
	 public static void readCookieForAppPermissionInfoVersion(HttpServletRequest request, SafiDeviceInfo deviceInfo) {
		Cookie[] cookies = request.getCookies();
		if (cookies != null) {
			for (Cookie c : cookies) {
				if(c.getName().equalsIgnoreCase(SafiConstants.MOBILE_DS_PRM_COOKIE)){
					Logger.debug("SAFI : ds_prm is recieved from native in readCookieForAppVersion : Name ::"+c.getName(), SafiWebHelper.class);
				
					String validVal = SafiUtil.validateSdkCookieVal(c.getName(),c.getValue());
					if(StringMethods.isValidString(validVal)){
						SafiUtil.splitAndPopulateDeviceInfo(validVal , deviceInfo);
					}
				}					
			}
		}else{
			Logger.debug("SAFI : No device information cookies found", SafiWebHelper.class);
		}
	 }
	 public static SafiReactivateOnlineVO populateSafiReactivateOnlineVO(HttpServletRequest request, String devicePrint, IBankCommonData commonData, boolean isMobileApp) {
		Logger.debug("SAFI : populateSafiVOForReactivateOnline START", SafiWebHelper.class) ;
		
		SafiReactivateOnlineVO safiReactivateOnlineVO = new SafiReactivateOnlineVO();
		safiReactivateOnlineVO = (SafiReactivateOnlineVO) populateSafiVO(request, devicePrint, commonData, isMobileApp, safiReactivateOnlineVO, SafiConstants.DEFAULT_TIME_LAST2FA_SUCCESS);
		
		safiReactivateOnlineVO.setAuthType(SafiConstants.AUTH_TYPE_OTP); 

		//Set custom facts data
		if(commonData.getCustomer().getPreference() != null) {
			Date today = new Date();
			Preference preference = commonData.getCustomer().getPreference();
			if(preference.getLastFullLogonDate() != null) {
				safiReactivateOnlineVO.setDaysSinceLastFullAuthLogon(DateMethods.dateDiffInDays(today, preference.getLastFullLogonDate()));
			}
			if(preference.getLastOTPLogonDate() != null) {
				safiReactivateOnlineVO.setDaysSinceLastOTPLogon(DateMethods.dateDiffInDays(today, preference.getLastOTPLogonDate()));
			}
			if(preference.getLastSimplifiedLogonDate() != null) {
				safiReactivateOnlineVO.setDaysSinceLastSimplifiedLogon(DateMethods.dateDiffInDays(today, preference.getLastSimplifiedLogonDate()));
			}
		}
		
		Logger.debug("SAFI : populateSafiVOForReactivateOnline END", SafiWebHelper.class) ;
		
		return safiReactivateOnlineVO;
	 }
	 
	 public static SafiReactivateOnlineVO populateSafiReactivateOnlineVOForNotify(HttpServletRequest request,IBankCommonData commonData,MobileSession mobileSession,Boolean status2FA,boolean isMobileApp,String last2FASuccessTime){
		 Logger.debug("SAFI : populateSafiReactivateOnlineVOForNotify START", SafiWebHelper.class) ;	
		 String devicePrint = null;
		 String safiChallengeEventRefId = null;
		 String safiSessionId = null;
		 String deviceTokenVal = null;
		 Boolean phonePerms = null;
		 Boolean locationPerms = null;
		 String appVersion = null;
		 SafiLogonInfo safiLogonInfo =  mobileSession.getSafiLogonInfo();
		
		 if(safiLogonInfo != null){
			 devicePrint =safiLogonInfo.getDevicePrint();
			 safiChallengeEventRefId = safiLogonInfo.getSafiChallengeEventRefId();
			 safiSessionId = safiLogonInfo.getSafiSessionId();
			 deviceTokenVal =  safiLogonInfo.getDeviceToken();
			 phonePerms =  safiLogonInfo.getPhonePerms();
			 locationPerms = safiLogonInfo.getLocationPerms();
			 appVersion = safiLogonInfo.getAppVersion();
		 }
		 
		 SafiReactivateOnlineVO safiVO = new SafiReactivateOnlineVO();
		 populateSafiVO(request, devicePrint, commonData, isMobileApp,safiVO,last2FASuccessTime);
		 safiVO.setSafiChallengeSuccess(status2FA);
		 safiVO.setSafiChallengeEventRefId(safiChallengeEventRefId);
		 safiVO.setSafiSessionId(safiSessionId);
		 if(mobileSession.getSecureCodeDetails() != null){
			 PhoneNumber phoneNumber = CommonBusinessUtil.get2FAPhoneNumber(commonData, mobileSession.getSecureCodeDetails().getPhoneNumber());		 
			 safiVO.setOtpPhoneUsed(phoneNumber != null ? phoneNumber.getAreaCode()+phoneNumber.getPhoneNumber(): null);
			 safiVO.setOtpDeliveryMethod(mobileSession.getSecureCodeDetails().getDeliveryMethod());
		 }
		 safiVO.setDeviceTokenValue(deviceTokenVal);
		 safiVO.setPhonePerms(phonePerms);
		 safiVO.setLocationPerms(locationPerms);
		 safiVO.setAppVersion(appVersion);
		 
		//Set custom facts data
		if(commonData.getCustomer().getPreference() != null) {
			Date today = new Date();
			Preference preference = commonData.getCustomer().getPreference();
			if(preference.getLastFullLogonDate() != null) {
				safiVO.setDaysSinceLastFullAuthLogon(DateMethods.dateDiffInDays(today, preference.getLastFullLogonDate()));
			}
			if(preference.getLastOTPLogonDate() != null) {
				safiVO.setDaysSinceLastOTPLogon(DateMethods.dateDiffInDays(today, preference.getLastOTPLogonDate()));
			}
			if(preference.getLastSimplifiedLogonDate() != null) {
				safiVO.setDaysSinceLastSimplifiedLogon(DateMethods.dateDiffInDays(today, preference.getLastSimplifiedLogonDate()));
			}
		}
		Logger.debug("SAFI : populateSafiReactivateOnlineVOForNotify END", SafiWebHelper.class) ;
		return safiVO;

	 }

	 
	 public static SafiMadisonVO populateSafiVOForMadison(HttpServletRequest request, String devicePrint, IBankCommonData commonData, boolean isMobileApp, SafiMadisonVO safiVO, MobileSession mobileSession) {
		 
		 safiVO =   (SafiMadisonVO) populateSafiVO(request, devicePrint, commonData, isMobileApp, safiVO, getLast2FASuccessTime(mobileSession));
		 
		 setNativeAppCustomFacts(mobileSession, isMobileApp, safiVO);
		 
		 if(null != safiVO)
			 safiVO.setEventType(SafiConstants.CLIENT_DEFINED_EVENT_TYPE_MADISON);
		 
		 return safiVO;
	 }
	 

	 public static SafiMadisonVO populateSafiVOForMadisonNotify(HttpServletRequest httpServletRequest, MobileSession mobileSession, IBankCommonData commonData, boolean isChallengeSuccessful){
			
		 SafiMadisonVO safiVO = (SafiMadisonVO) mobileSession.getSafiRequestVO();
		 SafiRespVO safiRespVO = safiVO.getSafiRespVO();
		 SecureCodeDetails secureCodeDetails = mobileSession.getSecureCodeDetails();
		 
		 safiVO.setSafiChallengeSuccess(isChallengeSuccessful);
		 safiVO.setSafiChallengeEventRefId(safiRespVO.getSafiChallengeEventRefId());
		 safiVO.setSafiSessionId(safiRespVO.getSafiSessionId());
		 safiVO.setDeviceTokenValue(fetchDeviceTokenValue(httpServletRequest));
		 safiVO.setOtpDeliveryMethod(secureCodeDetails.getDeliveryMethod());
		 
		 PhoneNumber phoneNumber = CommonBusinessUtil.get2FAPhoneNumber(commonData, secureCodeDetails.getPhoneNumber());
		 safiVO.setOtpPhoneUsed(phoneNumber.getAreaCode()+phoneNumber.getPhoneNumber());
		 
		 return safiVO;
	 }
}
