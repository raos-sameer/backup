/**
 * 
 */
package au.com.stgeorge.mbank.model.request.offers;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

import au.com.stgeorge.ibank.businessobject.BusinessException;
import au.com.stgeorge.mbank.model.common.IMBReq;
import au.com.stgeorge.mbank.model.common.ReqHeader;

/**
 * @author C50216
 *
 */
public class SalesOfferReq implements IMBReq{			
	/**
	 * 
	 */
	private static final long serialVersionUID = -1827351686856568422L;
	
	protected static final String MASK_NUMBERS = "^[0-9]+$";
	
	private ReqHeader header;	

	private Boolean displayMyInvitation; 
	
	@NotNull(message = "" + BusinessException.WSVC_INVALID_INPUT_PARAM)
	@Pattern(regexp = MASK_NUMBERS, message = "" + BusinessException.WSVC_INVALID_INPUT_PARAM)
	private String leadId;
			
	public String getLeadId() {
		return leadId;
	}
	public void setLeadId(String leadId) {
		this.leadId = leadId;
	}
	public ReqHeader getHeader()
	{
		return header;
	}
	public void setHeader(ReqHeader header)
	{
		this.header = header;
	}	
	
	public Boolean getDisplayMyInvitation() {
		return displayMyInvitation;
	}
	public void setDisplayMyInvitation(Boolean displayMyInvitation) {
		this.displayMyInvitation = displayMyInvitation;
	}
					
}
