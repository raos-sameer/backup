package au.com.stgeorge.mbank.controller.services;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;

import au.com.stgeorge.framework.common.util.StringMethods;
import au.com.stgeorge.ibank.businessobject.BusinessException;
import au.com.stgeorge.ibank.businessobject.CustomerService;
import au.com.stgeorge.ibank.businessobject.ResourceException;
import au.com.stgeorge.ibank.businessobject.TaxFileNumberService;
import au.com.stgeorge.ibank.valueobject.Account;
import au.com.stgeorge.ibank.valueobject.Customer;
import au.com.stgeorge.ibank.valueobject.TermDepositAccount;
import au.com.stgeorge.ibank.valueobject.ThirdParty;
import au.com.stgeorge.ibank.valueobject.transfer.IBankCommonData;
import au.com.stgeorge.ibank.valueobject.transfer.TermDepositInterestInstruction;
import au.com.stgeorge.mbank.model.response.services.ManagedTDDetailsResp;
import au.com.stgeorge.mbank.model.response.services.ManagedTDUpdateResp;
import au.com.stgeorge.mbank.util.MBAppConstants;

public class ManageTermDepositHelper {

    /**
     * This method will populate the response for the getDetails method of @ManageTermDepositController.
     * 
     * @param tdaAccount
     * @param paidToInterestAccounts
     * @param customer
     * @return ManagedTDDetailsResp
     */
    public ManagedTDDetailsResp getManagedTDDetailsResp(TermDepositAccount tdaAccount, Collection<Account>  paidToInterestAccounts, Customer customer) throws BusinessException{
    	
    	ManagedTDDetailsResp resp = new ManagedTDDetailsResp();
    	
       	switch(tdaAccount.getInterestInstruction().getInterestInstruction()) {
			case "TA" : 
				resp.setInstruction("Add to principal"); 
				break;
				
			case "TT" : 
				resp.setInstruction("Paid to account");
       	}	
       	     	
    	resp.setInterestToAccntIndexes(populatePaidToInterestAccounts(paidToInterestAccounts, customer));
    	
    	String intPaidToAcct = tdaAccount.getInterestInstruction().getInterestAccount();    	
    	String intPaidToAcctIndex = null; 
    	
    	if(null != intPaidToAcct) {    		    	
	    	for(Account acct : paidToInterestAccounts){	    		
	    		if(StringMethods.removeLeadingZero(acct.getAccountId().getAccountKey()).equals(StringMethods.removeLeadingZero(intPaidToAcct))){
	    			intPaidToAcctIndex = String.valueOf(acct.getIndex());
	    			break;  		
	    		}
	    	}    		    	
    	}    		
    	
    	if(null == intPaidToAcctIndex){
    		int index = 0;
    		for(ThirdParty tp : customer.getThirdParties()){
    			if(StringMethods.removeLeadingZero(tp.getNumber()).equals(intPaidToAcct)){
    				intPaidToAcctIndex = "T|"+String.valueOf(index);  
    				break;
	    			}
    			index++;
    		}
    	}
    	
    	resp.setSelectedIntrToAccntIndex(intPaidToAcctIndex);
    	    	
    	resp.setIsIntrAtMaturity(tdaAccount.getInterestInstruction().getInterestFreq().equals("00") ? true : false);
    	
    	return resp;
    	
    }

	private ArrayList<String> populatePaidToInterestAccounts(Collection<Account>  paidToInterestAccounts, Customer customer) {
		ArrayList<Account> accts = createAcctListfromSession(customer, paidToInterestAccounts);
		ArrayList<String> interestToAccntIndexesList = new ArrayList<String>();

		if(accts != null){
			for (Iterator<Account> iterator = accts.iterator(); iterator.hasNext();) {
				Account eachAccount = iterator.next();
				interestToAccntIndexesList.add(String.valueOf(eachAccount.getIndex()));
			}
		}
		if (customer.getThirdParties() != null )
		{
			ArrayList<ThirdParty> thirdPartyList = (ArrayList<ThirdParty>) customer.getThirdParties();

			int thirdPartyListLen = thirdPartyList.size();
			for (int i = 0; i < thirdPartyListLen; i++) {
				interestToAccntIndexesList.add("T|"+i);
				}
		}
		return interestToAccntIndexesList;
	}
	
    public ArrayList<Account> createAcctListfromSession(Customer customer, Collection<Account> accounts){
		ArrayList<Account> resultList = new ArrayList<Account>();
		
		if(accounts != null){
			ArrayList<Account> acctList = (ArrayList<Account>)accounts;
			Account acct = new Account();
			Account custAcct = new Account();
			ArrayList<Account> custAcctList = (ArrayList<Account>)customer.getAccounts();
			String acctKey ="";
			for (int i = 0; i < acctList.size(); i++){
				acct = (Account) acctList.get(i);
				acctKey = acct.getAccountId().getAccountKey();
				for(int j=0; j < custAcctList.size(); j++){
					custAcct = (Account) custAcctList.get(j);
					if(custAcct.getAccountId().getAccountKey().equalsIgnoreCase(acctKey)){
						resultList.add(custAcct);
						break;
					}
				}
			}
		}
		return resultList;
	}	
    
    public TermDepositInterestInstruction getTDInterestInstruction(TermDepositAccount tdaAccount, IBankCommonData commonData, 
    		Collection<Account> paidToInterestAccountsList, String intrPayToAcctIndex, String intrPayInst) throws ResourceException, BusinessException {
    	TermDepositInterestInstruction transfer = new TermDepositInterestInstruction();
		    	    	
		transfer.setAccount(tdaAccount);
		
		Customer cust = CustomerService.getCustomer(commonData);
		transfer.setCustomer(cust);		
		transfer.setCommonData(commonData);		
		
		transfer.setTermLength(String.valueOf(tdaAccount.getTermLength()));
		transfer.setTermCode(tdaAccount.getTermCode());
		
		switch (intrPayInst) {
			case "Add to principal": 
				transfer.setInterestPaymentOption("TA");
				break;
			
			case "Pay to account" :
				transfer.setInterestPaymentOption("TT");
				break;		
		}
		
		//ELead not to be set as not available.				
		
		if(!StringMethods.isEmptyString(intrPayToAcctIndex)){
			intrPayToAcctIndex = intrPayToAcctIndex.replace('|',',');
			String[] tempStr = intrPayToAcctIndex.split(",");
			if(tempStr.length < 2){
				String acctIndex = tempStr[0].trim();
				Account intrToAcct = getAccountFromCustomer(commonData.getCustomer(), Integer.parseInt(acctIndex));
				if(intrToAcct != null){
					transfer.setSelectedToAccount(intrToAcct.getAccountId());
				}
			}
			else if(MBAppConstants.KEY_IDENTIFIER_THIRD_PARTY.equalsIgnoreCase(tempStr[0].trim())){
				String acctIndex = tempStr[1].trim();
				ThirdParty intrToTP = getThirdPartyFromCustomer(commonData.getCustomer(), Integer.parseInt(acctIndex));
				transfer.setSelectedToAccount(intrToTP);
			}
		}
		
		return transfer;
    }

	public Account getAccountFromCustomer(Customer customer, int index) {
		Account account = null;
		if (customer.getAccounts() != null && customer.getAccounts().size() > 0) {
			ArrayList acctList = (ArrayList) customer.getAccounts();
			int acctListLen = customer.getAccounts().size();
			for (int i = 0; i < acctListLen; i++) {
				if (index == i) {
					account = (Account) acctList.get(i);
					break;
				}
			}
		}
		return account;
	}

	private ThirdParty getThirdPartyFromCustomer(Customer customer, int index) {
		ThirdParty thirdParty = null;
		if (customer.getThirdParties() != null
				&& customer.getThirdParties().size() > 0) {
			ArrayList thirdPartyList = (ArrayList) customer.getThirdParties();
			int thirdPartyListLen = customer.getThirdParties().size();
			for (int i = 0; i < thirdPartyListLen; i++) {
				if (index == i) {
					thirdParty = (ThirdParty) thirdPartyList.get(i);
					break;
				}
			}
		}
		return thirdParty;
	}
	
    public ManagedTDUpdateResp getManagedTDUpdateResp(Customer customer) throws ResourceException, BusinessException {
    	
    	ManagedTDUpdateResp resp = new ManagedTDUpdateResp();
		
		String description = TaxFileNumberService.getTFNDescription(customer);
		boolean tfnHeld = false;
		boolean tfnExemption = false;
		
		if (description.equalsIgnoreCase(TaxFileNumberService.TAX_FILE_NUMBER_HELD))
			tfnHeld = true;
		else if (description.equalsIgnoreCase(TaxFileNumberService.FOREIGN_EXEMPTION))
			tfnExemption = true;
		
		resp.setTfnHeld(tfnHeld);
    	resp.setTfnExemption(tfnExemption);   
    	
    	resp.setIsSuccess(true);
    	
		return resp;
    }
}
