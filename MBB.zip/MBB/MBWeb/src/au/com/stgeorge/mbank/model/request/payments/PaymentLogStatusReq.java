/**
 * 
 */
package au.com.stgeorge.mbank.model.request.payments;

import au.com.stgeorge.mbank.model.common.IMBReq;
import au.com.stgeorge.mbank.model.common.ReqHeader;
/**
 * @author C86611
 *
 */
public class PaymentLogStatusReq implements IMBReq{

	private static final long serialVersionUID = -5873428913164538454L;
	private ReqHeader header;
	private int paymentsLogID;
	/**
	 * @return the paymentsLogID
	 */
	public int getPaymentsLogID() {
		return paymentsLogID;
	}
	/**
	 * @param paymentsLogID the paymentsLogID to set
	 */
	public void setPaymentsLogID(int paymentsLogID) {
		this.paymentsLogID = paymentsLogID;
	}
	@Override
	public ReqHeader getHeader() {
		// TODO Auto-generated method stub
		return header;
	}
	@Override
	public void setHeader(ReqHeader header) {
		this.header = header;

	} 


}
