package au.com.stgeorge.mbank.model.request;

import au.com.stgeorge.mbank.model.common.IMBReq;
import au.com.stgeorge.mbank.model.common.ReqHeader;

public class ManageEStmtDetailReq implements IMBReq{

	private static final long serialVersionUID = 5915450800795076567L;

	private ReqHeader header;
	
	private int accountIndex;
	
	private String estmtAcctStatus;

	
	public ReqHeader getHeader()
	{
		return header;
	}
	
	public void setHeader(ReqHeader header)
	{
		this.header = header;
	}
	
	public int getAccountIndex() {
		return accountIndex;
	}

	public void setAccountIndex(int accountIndex) {
		this.accountIndex = accountIndex;
	}

	public String getEstmtAcctStatus() {
		return estmtAcctStatus;
	}

	public void setEstmtAcctStatus(String estmtAcctStatus) {
		this.estmtAcctStatus = estmtAcctStatus;
	}
	
	
	
}
