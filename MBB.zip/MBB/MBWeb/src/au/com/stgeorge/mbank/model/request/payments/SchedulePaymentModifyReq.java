/**
 * 
 */
package au.com.stgeorge.mbank.model.request.payments;

import java.io.Serializable;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.NotEmpty;

import au.com.stgeorge.ibank.businessobject.BusinessException;
import au.com.stgeorge.mbank.model.common.IMBReq;
import au.com.stgeorge.mbank.model.common.ReqHeader;

/**
 * @author C50216
 *
 */
public class SchedulePaymentModifyReq implements IMBReq,Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -4745369814987338706L;
	private static final String SCHEDULE_STATUS_PATTERN = "((?i)(H|S))";

	private ReqHeader header;
			
	@NotNull(message = "" + BusinessException.WSVC_INVALID_INPUT_PARAM)
	private Integer scheduleId;
	
	@NotEmpty (message = ""+BusinessException.WSVC_INVALID_INPUT_PARAM)	
	@Pattern(regexp = SCHEDULE_STATUS_PATTERN ,message = ""+BusinessException.WSVC_INVALID_INPUT_PARAM)
	private String status;
	
	public ReqHeader getHeader() {
		return header;
	}

	public void setHeader(ReqHeader header) {
		this.header = header;
	}

	public Integer getScheduleId() {
		return scheduleId;
	}

	public void setScheduleId(Integer scheduleId) {
		this.scheduleId = scheduleId;
	}	
	
	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}			
}
