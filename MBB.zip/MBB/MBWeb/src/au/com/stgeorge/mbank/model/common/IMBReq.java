package au.com.stgeorge.mbank.model.common;

import java.io.Serializable;

public interface IMBReq extends Serializable {

	public ReqHeader getHeader();

	public void setHeader(ReqHeader header);

}
