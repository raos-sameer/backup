package au.com.stgeorge.mbank.model.request.businessaccount;

import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.Length;
import org.hibernate.validator.constraints.NotEmpty;

import au.com.stgeorge.ibank.businessobject.BusinessException;
import au.com.stgeorge.mbank.model.common.IMBReq;
import au.com.stgeorge.mbank.model.common.ReqHeader;

public class BusinessAccountAcnReq implements IMBReq{

	/**
	 * 
	 */
	private static final long serialVersionUID = -7081894749285125985L;

	@NotEmpty(message = "" + BusinessException.BUSINESS_ACCOUNT_NOT_VALID_ACN)
	@Length(min = 9, max = 9, message = "" + BusinessException.BUSINESS_ACCOUNT_NOT_VALID_ACN)
	@Pattern(regexp = "[\\d]{9}", message = "" + BusinessException.BUSINESS_ACCOUNT_NOT_VALID_ACN)
	private String acnNumber; 
	
	private ReqHeader header;
    private String productType;
    private boolean activate;
	
	
	public String getProductType() {
		return productType;
	}
	public void setProductType(String productType) {
		this.productType = productType;
	}
	public ReqHeader getHeader()
	{
		return header;
	}
	public void setHeader(ReqHeader header)
	{
		this.header = header;
	}
	public String getAcnNumber() {
		return acnNumber;
	}
	public void setAcnNumber(String acnNumber) {
		this.acnNumber = acnNumber;
	}
	public boolean isActivate() {
		return activate;
	}
	public void setActivate(boolean activate) {
		this.activate = activate;
	}

}
