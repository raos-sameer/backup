package au.com.stgeorge.mbank.controller.customer.ev;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.springframework.stereotype.Service;

import au.com.stgeorge.framework.common.logging.Logger;
import au.com.stgeorge.framework.common.util.StringMethods;
import au.com.stgeorge.ibank.businessobject.BusinessException;
import au.com.stgeorge.ibank.common.cache.IBankParams;
import au.com.stgeorge.ibank.evcrs.businessobject.valueobject.EVCountryDetailVO;
import au.com.stgeorge.ibank.evcrs.businessobject.valueobject.EVForeignCountryDetail;
import au.com.stgeorge.ibank.evcrs.util.EVConstants;
import au.com.stgeorge.ibank.valueobject.database.CodesVO;
import au.com.stgeorge.mbank.model.request.customer.ev.CRSInfo;
import au.com.stgeorge.mbank.model.request.customer.ev.TaxResidency;
import au.com.stgeorge.mbank.model.request.customer.ev.WidgetTaxResidency;
import au.com.stgeorge.mbank.model.response.customer.CRSMaintenanceResp;
import au.com.stgeorge.mbank.model.response.customer.ev.EVCountryDetail;

@Service
public class CRSHelper {
	
	public static final String MASKED_TIN = "XXXXXXXX";
	public static final String FOREIGN_TAX_INFO_VALUE_YES = "yes";
	public static final String FOREIGN_TAX_INFO_VALUE_NO = "no";
	
	public List<String> getMandatoryReasonList(String... custTypeInd)
	{
		ArrayList<String> reasonList = null;	

			List<CodesVO>tempReasonList =(List<CodesVO>)(IBankParams.getCodesDataList("ALL", "evForeignTINReason")); 
			Iterator<CodesVO> iterator = tempReasonList.iterator();
			if (tempReasonList != null && tempReasonList.size() > 0)
			{
				reasonList = new ArrayList<String>();
				while (iterator.hasNext())
				{
					CodesVO codesVO = (CodesVO)iterator.next();
					if ( StringMethods.isEmptyString(codesVO.getCode()) )
					{
						codesVO.setCode(" ");
					}
					String tempReason =codesVO.getMessage();
					if(!codesVO.getCode().equalsIgnoreCase("RC000001")){
						if(null!= custTypeInd && custTypeInd.length > 0 && custTypeInd[0].equalsIgnoreCase("B") && codesVO.getCode().equalsIgnoreCase("RC000002")){
							//dont add
						}else
							reasonList.add(tempReason);	
						
					}					
				}
				
				Collections.sort(reasonList, new Comparator<String>() {
					@Override
					public int compare(String s1, String s2) 
					{
					   return s1.compareToIgnoreCase(s2);
					}
				  });
			}						
	 return reasonList;
	}
	
	public List<String> getOptionalReasonList(String... custTypeInd)
	{
		ArrayList<String> reasonList = null;	

			List<CodesVO>tempReasonList =(List<CodesVO>)(IBankParams.getCodesDataList("ALL", "evForeignTINReason")); 
			Iterator<CodesVO> iterator = tempReasonList.iterator();
			if (tempReasonList != null && tempReasonList.size() > 0)
			{
				reasonList = new ArrayList<String>();
				while (iterator.hasNext())
				{
					CodesVO codesVO = (CodesVO)iterator.next();
					if ( StringMethods.isEmptyString(codesVO.getCode()) )
					{
						codesVO.setCode(" ");
					}
					if(null!= custTypeInd && custTypeInd.length > 0 && custTypeInd[0].equalsIgnoreCase("B") && codesVO.getCode().equalsIgnoreCase("RC000002")){
						//dont add
					}else{
						String tempReason =codesVO.getMessage();
						reasonList.add(tempReason);
					}					
				}

				Collections.sort(reasonList, new Comparator<String>() {
					@Override
					public int compare(String s1, String s2) 
					{
					   return s1.compareToIgnoreCase(s2);
					}
				  });
			}						
	 return reasonList;
	}
	
	
	public  List<EVCountryDetail> getForeignCountriesAndTINRegex(List<EVForeignCountryDetail> evForeignCountryDetails){				
		List<EVCountryDetail> evFrnDtls=null;
		if(null!=evForeignCountryDetails){
			evFrnDtls=new ArrayList<EVCountryDetail>();
			for(EVForeignCountryDetail evFr:evForeignCountryDetails){
				EVCountryDetail evForeignCntDtls=new EVCountryDetail();
				evForeignCntDtls.setCountryCode(evFr.getCountryCode());
				evForeignCntDtls.setTinRegex(evFr.getTinRegex());
				evForeignCntDtls.setTinRegexException(evFr.getTinRegexException());
				evForeignCntDtls.setCountryHelpText(evFr.getCountryHelpText());
				evForeignCntDtls.setIsTINApplicable(!evFr.isNoTin());
				evForeignCntDtls.setIsTINMandatory(evFr.isTINMandatory());								
				evFrnDtls.add(evForeignCntDtls);
			}
		}
		return evFrnDtls;
	}
	
	public void validateCRSData(CRSInfo crsInfo,List<EVForeignCountryDetail> evForeignCountryDtls) throws BusinessException{		
		
		List<TaxResidency> trList=crsInfo.getTaxResidencyList();
		boolean validateTR=false;
		ArrayList<String> countryList=new ArrayList<String>();
		
		if(null!=trList)
		{
			for(TaxResidency tr:trList)
			{	
				EVForeignCountryDetail evForeignDetails=new EVForeignCountryDetail();			
				if(null==tr.getCountry())
				{
				    throw new BusinessException(BusinessException.COUNTRY_CODE_REQUIRED);	
				}
				if(tr.isForeignTINProvided() && null==tr.getForeignTIN())
				{
			     throw new BusinessException(BusinessException.FOREIGN_TIN_REQUIRED);
				}
				if(null!=tr.getCountry())
				{
					countryList.add(tr.getCountry());
					evForeignDetails.setCountryCode(tr.getCountry());
				}
				
				for(EVForeignCountryDetail evFR: evForeignCountryDtls)
				{
					if(tr.getCountry().equalsIgnoreCase(evFR.getCountryCode()))
					{
						validateTR=true;
						evForeignDetails=evFR;
						break;
					}
					else
					{
						validateTR=false;
					}
				}		
				if(validateTR)
				{
					if(null!=evForeignDetails && (!evForeignDetails.isNoTin() && !tr.isForeignTINProvided() &&  tr.getReason() == null))
					{
					    throw new BusinessException(BusinessException.NO_FOREIGN_TIN_CODE_REQUIRED);
					}
					if(null!=evForeignDetails && (!evForeignDetails.isNoTin() && tr.isForeignTINProvided()))
					{
						validateTINandRegex(tr.getForeignTIN(),evForeignDetails);
					}				
				}
				else
				{
					validateTINandRegexCountryNotInJSON(tr.getForeignTIN(),tr.isForeignTINProvided(),tr.getReason());
				}				
			}
			int count=getDupCount(countryList);
			if(count>0)
			{
				throw new BusinessException(BusinessException.DUPLICATE_COUNTRY_IN_CRS);
			}
		}
	}
	
	
	protected void validateTINandRegex(String foreignTIN,EVForeignCountryDetail evFrnDtls) throws BusinessException
	{
		boolean isValidTIN=false;
		if(null!=foreignTIN && checkSpecialCharactersGeneric(foreignTIN))
		{
			throw new BusinessException(BusinessException.INVALID_FOREIGN_TIN);
		}
		else
		{
			isValidTIN=true;
		}
		if(null!=foreignTIN && checkForeignTIN(foreignTIN))
		{
			throw new BusinessException(BusinessException.INVALID_FOREIGN_TIN);
		}
		else
		{
			isValidTIN=true;
		}
		
		if(null!=evFrnDtls.getTinRegex())
		{						
		   for(String str: evFrnDtls.getTinRegex())
			 {				
			    if(foreignTIN.matches(str))
				{
				   isValidTIN=true;
				   break;
				}
				if(!foreignTIN.matches(str))
				{
					if(null!=evFrnDtls.getTinRegexException() && !foreignTIN.matches(evFrnDtls.getTinRegexException()))
					{
				       isValidTIN=false;
					}
					else if(null!=evFrnDtls.getTinRegexException() && foreignTIN.matches(evFrnDtls.getTinRegexException()))
					{
						isValidTIN=true;
						break;
					}
					else
					{
						isValidTIN=false;
					}
				}				
			 }
		}
	   if(evFrnDtls.getTinRegex()==null && null!=evFrnDtls.getTinRegexException())
		{
			if(!foreignTIN.matches(evFrnDtls.getTinRegexException()))
			{
				isValidTIN=false;

			}
			else
			{
		       isValidTIN=true;
			}
		
		}
	
		if(!isValidTIN)
		{
			throw new BusinessException(BusinessException.INVALID_FOREIGN_TIN);
		}
	}
	
	protected void validateTINandRegexCountryNotInJSON(String foreignTIN, boolean foreignTINProvided, String reason) throws BusinessException{
		
		if(foreignTINProvided && foreignTIN==null)
		{
			 throw new BusinessException(BusinessException.FOREIGN_TIN_REQUIRED);
		}
		
		if(!foreignTINProvided && reason==null)
		{
			 throw new BusinessException(BusinessException.NO_FOREIGN_TIN_CODE_REQUIRED);
		}
		
		if(null!=foreignTIN && checkSpecialCharactersGeneric(foreignTIN))
		{
			throw new BusinessException(BusinessException.SPECIAL_CHARACTERS_IN_FOREIGN_TIN);
		}
		if(null!=foreignTIN && checkForeignTIN(foreignTIN))
		{
		   throw new BusinessException(BusinessException.INVALID_FOREIGN_TIN);
		}
	}
	
    public int getDupCount(ArrayList<String> countryList)
    {
        int cnt = 0;
        HashSet<String> h = new HashSet<String>(countryList);
        for (String token : h)
        {
            if (Collections.frequency(countryList, token) > 1)
                cnt++;
        }         
        return cnt;
    }
    
	
	public boolean  checkSpecialCharacters(String value){
		boolean result=false;
		String REGEX = "[a-zA-Z0-9.-]*";
		Pattern pattern = Pattern.compile(REGEX);
		Matcher matcher = pattern.matcher(value);
		if (matcher.matches()){
		  result=true;
		}
		else{
			result=false;
		}
		return result;
	}
	
	public boolean  checkCharacters(String value){
		boolean result=false;
		String REGEX = "[a-zA-Z]*";
		Pattern pattern = Pattern.compile(REGEX);
		Matcher matcher = pattern.matcher(value);
		if (matcher.matches()){
		  result=true;
		}
		else{
			result=false;
		}
		return result;
	}
	public boolean  checkSpecialCharactersGeneric(String value){
		boolean result=false;
		String REGEX = "\\$:%?>=}|@#!`";
		Pattern pattern = Pattern.compile(REGEX);
		Matcher matcher = pattern.matcher(value);
		if (matcher.matches()){
		  result=true;
		}
		else{
			result=false;
		}
		return result;
	}
	
	public boolean  checkForeignTIN(String value){
		boolean result=false;
		value=value.trim();		
		if(value.equalsIgnoreCase("N/A") || value.equalsIgnoreCase("NA") || value.equalsIgnoreCase("Not Applicable") || value.equalsIgnoreCase("Not available") || value.equalsIgnoreCase("TBC")){
			result=true;
		}
		else{
			result=false;
		}
		return result;
	}
	
	// to populate details in CRS screen.
	public  CRSInfo populateCRSInfo(List<EVForeignCountryDetail> evForeignCountryDetails, String... custTypeInd){
		CRSInfo crsInfo =new CRSInfo();
		crsInfo.setMandatoryTINReasons(getMandatoryReasonList(custTypeInd));
		crsInfo.setOptionalTINReasons(getOptionalReasonList(custTypeInd));
		crsInfo.setEvForeignCountryResp(getForeignCountriesAndTINRegex(evForeignCountryDetails));
		crsInfo.setCountries(getCountryList());
		return crsInfo;
	}
	
	public au.com.stgeorge.ibank.evcrs.businessobject.valueobject.CRSInfo populateCRSInfoVo(CRSInfo crsInfo,List<EVForeignCountryDetail> evForeignCountryDtls)
	{
	   au.com.stgeorge.ibank.evcrs.businessobject.valueobject.CRSInfo crsInfoVo = new au.com.stgeorge.ibank.evcrs.businessobject.valueobject.CRSInfo();
	   crsInfoVo.setForeignTaxResident(crsInfo.isForeignTaxResident());	   
	   List<au.com.stgeorge.ibank.evcrs.businessobject.valueobject.TaxResidency> taxResidencyList = new ArrayList<au.com.stgeorge.ibank.evcrs.businessobject.valueobject.TaxResidency>();
	   
	   if(crsInfo.isForeignTaxResident()){
		   for(TaxResidency trList: crsInfo.getTaxResidencyList()){			   
			  au.com.stgeorge.ibank.evcrs.businessobject.valueobject.TaxResidency taxResidency = new au.com.stgeorge.ibank.evcrs.businessobject.valueobject.TaxResidency();
			  String countryCD="";
			  boolean isTinApplicable=false;
		          if(null!=trList.getCountry()){
		        	  countryCD=trList.getCountry();
		        	  taxResidency.setCountryCode(trList.getCountry());
		          }
		          for(EVForeignCountryDetail evFr:evForeignCountryDtls){
		        	  if(countryCD.equalsIgnoreCase(evFr.getCountryCode())){
		        		  isTinApplicable=!evFr.isNoTin();
		        		  break;
		        	  }
		        	  else{
		        		  isTinApplicable=true; 
		        	  }
		          }
		          if(null!=trList.getForeignTIN()){
		        	  taxResidency.setForeignTIN(trList.getForeignTIN());
		          }
		          taxResidency.setForeignTINProvided(trList.isForeignTINProvided());
		          if(!trList.isForeignTINProvided()){
		        		  if(isTinApplicable){
		        			  if(null!=trList.getReason()){
		        				  taxResidency.setNoForeignTINCode(getReasonCode(trList.getReason())); 
		        			  }
		        			  else{
		        				  taxResidency.setNoForeignTINCode(EVConstants.TIN_NOT_ISSUED);
		        			  }
		        		  }
		        		  else{
		        			  taxResidency.setNoForeignTINCode(EVConstants.TIN_NOT_ISSUED);
		        		  }
		          }	          
		          taxResidencyList.add(taxResidency);
		     }
		    crsInfoVo.setTaxResidencyList(taxResidencyList);
	   }
	    return crsInfoVo;	            
	 }

	public  String getReasonCode(String reasonName){
		String reasonCode="";
		HashMap<String,String> hm=new HashMap<String,String>();

		List<CodesVO>tempCountryList = (List<CodesVO>)(IBankParams.getCodesDataList("ALL", "evForeignTINReason"));
		Iterator<CodesVO> iterator = tempCountryList.iterator();
		if (tempCountryList != null && tempCountryList.size() > 0)
		{	
			while (iterator.hasNext())
			{
				CodesVO codesVO = (CodesVO)iterator.next();
				hm.put(codesVO.getCode(),codesVO.getMessage());				
			}
		}		
        for(Map.Entry entry: hm.entrySet()){
            if(reasonName.equals(entry.getValue())){
            	reasonCode = (String)entry.getKey();
                break;
            }
        }		
		return reasonCode;
	}
	
	/**
	 * This will populate response for getCRSInfo.If crsInfo is available then isCRSInfoAvailable flag is set to true otherwise false.
	 * @param crsInfoVO
	 * @param crsInfoObj
	 * @return CRSMaintenanceResp
	 */
	public CRSMaintenanceResp populateGetCRSInfoResponse(au.com.stgeorge.ibank.evcrs.businessobject.valueobject.CRSInfo crsInfoVO, au.com.stgeorge.mbank.model.request.customer.ev.CRSInfo crsInfoObj){

		//Populate Response
		CRSMaintenanceResp response = new CRSMaintenanceResp();
		if(crsInfoVO != null){
			Logger.info("crsInfoVO not null", this.getClass());
			populateCRSInfo(crsInfoVO, crsInfoObj);
			response.setCrsInfoAvailable(true);
			response.setCrsInfo(crsInfoObj);
		}else{
			Logger.info("crsInfoVO null", this.getClass());
			response.setCrsInfoAvailable(false);
			crsInfoObj.setMandatoryTINReasons(getMandatoryReasonList());
			Logger.info("crsInfoVO getMandatoryReasonList=" + getMandatoryReasonList()!=null?getMandatoryReasonList().size():"null", this.getClass());
			crsInfoObj.setOptionalTINReasons(getOptionalReasonList());
			Logger.info("crsInfoVO getOptionalReasonList="+getOptionalReasonList()!=null?getOptionalReasonList().size():"null", this.getClass());
			List<EVForeignCountryDetail> evForeignCountryDtls=IBankParams.getForeignTINDetails();
			Logger.info("crsInfoVO evForeignCountryDtls="+evForeignCountryDtls!=null?evForeignCountryDtls.size():"null", this.getClass());
			crsInfoObj.setEvForeignCountryResp(getForeignCountriesAndTINRegex(evForeignCountryDtls));
			Logger.info("crsInfoVO getEvForeignCountryResp="+crsInfoObj.getEvForeignCountryResp(), this.getClass());
			response.setCrsInfo(crsInfoObj);
			response.setCountries(getCountryList());
		}
		return response;
	}
	
	


	/**
	 * This method will populate crsInfoObj with data from crsInfoVO which is retrieved from CRSService call svc0258
	 * @param crsInfoVO
	 * @param crsInfoObj
	 */
	public void populateCRSInfo(au.com.stgeorge.ibank.evcrs.businessobject.valueobject.CRSInfo crsInfoVO, au.com.stgeorge.mbank.model.request.customer.ev.CRSInfo crsInfoObj){
		Logger.info("populateCRSInfo start", this.getClass());
		if(crsInfoVO != null){
			Logger.info("populateCRSInfo isForeignTaxResident=" +crsInfoVO.isForeignTaxResident(), this.getClass());
			au.com.stgeorge.mbank.model.request.customer.ev.TaxResidency tResidencyRes = null;
			List<au.com.stgeorge.mbank.model.request.customer.ev.TaxResidency> tResidencyResList = null;

			if(crsInfoVO.isForeignTaxResident()){

				List<au.com.stgeorge.ibank.evcrs.businessobject.valueobject.TaxResidency> taxResidencyList = crsInfoVO.getTaxResidencyList();
				
				if(taxResidencyList != null && !taxResidencyList.isEmpty()){
					Logger.info("populateCRSInfo taxResidencyList.size()=" +taxResidencyList.size(), this.getClass());
					tResidencyResList = new ArrayList<au.com.stgeorge.mbank.model.request.customer.ev.TaxResidency>();
					for(au.com.stgeorge.ibank.evcrs.businessobject.valueobject.TaxResidency tResidency : taxResidencyList){

						tResidencyRes = new au.com.stgeorge.mbank.model.request.customer.ev.TaxResidency();
					
							String countryDisp = IBankParams.getCodeDescFromList(IBankParams.CATEGORY_COUNTRY, tResidency.getCountryCode());
							Logger.info("populateCRSInfo countryDisp=" +countryDisp, this.getClass());
							tResidencyRes.setCountry(countryDisp);
							if(tResidency.getForeignTIN() != null && !tResidency.getForeignTIN().isEmpty()){
								tResidencyRes.setForeignTIN(MASKED_TIN);
							}
						
						
						tResidencyRes.setForeignTINProvided(tResidency.isForeignTINProvided());
						
						if(!tResidency.isForeignTINProvided()){
							String noForeignTinReasonDisp = IBankParams.getCodeDescFromList(EVConstants.EV_FOREIGN_TIN_REASON, tResidency.getNoForeignTINCode());
							tResidencyRes.setReason(noForeignTinReasonDisp);
						}
						
						tResidencyResList.add(tResidencyRes);
					}
					
					crsInfoObj.setTaxResidencyList(tResidencyResList);
				}
			}

			crsInfoObj.setForeignTaxResident(crsInfoVO.isForeignTaxResident());
		
		}

	}

	/**
	 * This method will populate crsInfoObj with data from crsInfoVO which is retrieved from CRSService call svc0258
	 * @param crsInfoVO
	 * @param crsInfoObj
	 */
	public void populateCRSInfoForUpdate(au.com.stgeorge.ibank.evcrs.businessobject.valueobject.CRSInfo crsInfoVO, au.com.stgeorge.mbank.model.request.customer.ev.CRSInfo crsInfoObj){

		if(crsInfoVO != null){

			List<WidgetTaxResidency> tResidencyResList = null;
			
			List<EVForeignCountryDetail> evForeignCountryDtls=IBankParams.getForeignTINDetails();
			
			if(crsInfoVO.isForeignTaxResident()){

				List<au.com.stgeorge.ibank.evcrs.businessobject.valueobject.TaxResidency> taxResidencyList = crsInfoVO.getTaxResidencyList();

				if(taxResidencyList != null && !taxResidencyList.isEmpty()){
					tResidencyResList = new ArrayList<WidgetTaxResidency>();
					for(int taxDataIndex = 0;taxDataIndex< taxResidencyList.size();taxDataIndex++){

						au.com.stgeorge.ibank.evcrs.businessobject.valueobject.TaxResidency tResidency = taxResidencyList.get(taxDataIndex);
						WidgetTaxResidency tResidencyRes = new WidgetTaxResidency();

						String countryCode = tResidency.getCountryCode();
						boolean foreignTINProvided = tResidency.isForeignTINProvided();
						
						tResidencyRes.setCountryCode(countryCode);

						if(foreignTINProvided){
							tResidencyRes.setForeignTaxInfoAvailable(true);
						}else{
							String noForeignTinReasonDisp = IBankParams.getCodeDescFromList(EVConstants.EV_FOREIGN_TIN_REASON, tResidency.getNoForeignTINCode());
							tResidencyRes.setReason(noForeignTinReasonDisp);
						}

						tResidencyRes.setForeignTaxInfovalue(foreignTINProvided?FOREIGN_TAX_INFO_VALUE_YES:FOREIGN_TAX_INFO_VALUE_NO);
						tResidencyRes.setForeignTaxIDNumber(tResidency.getForeignTIN());

						if((tResidency.getForeignTIN() != null && !tResidency.getForeignTIN().isEmpty()) || (tResidency.getNoForeignTINCode() != null && !tResidency.getNoForeignTINCode().isEmpty())){
							tResidencyRes.setShowTaxInputType(true);
						}else{
							tResidencyRes.setShowTaxInputType(false);
						}

						tResidencyRes.setTaxDataIndex(taxDataIndex);

						for(EVForeignCountryDetail evForeignCountryDetail : evForeignCountryDtls){
							if(countryCode != null && !countryCode.isEmpty() && countryCode.equalsIgnoreCase(evForeignCountryDetail.getCountryCode())){
								tResidencyRes.setRegexList(evForeignCountryDetail.getTinRegex());
								tResidencyRes.setTinRegexException(evForeignCountryDetail.getTinRegexException());
								tResidencyRes.setTINApplicable(!evForeignCountryDetail.isNoTin());
								tResidencyRes.setShowForNoTIN(evForeignCountryDetail.isTINMandatory());
							}
						}

						tResidencyResList.add(tResidencyRes);
					}

					tResidencyResList.get(tResidencyResList.size() - 1).setShowAddBtn(true);

					crsInfoObj.setWidgetTaxResidencyList(tResidencyResList);

				}
			}

			crsInfoObj.setForeignTaxResident(crsInfoVO.isForeignTaxResident());
		
		}

	}

	
	public List<EVCountryDetailVO> getCountryList()
	{
		List<EVCountryDetailVO> countryNameList = new ArrayList<EVCountryDetailVO>();	

			List<CodesVO>tempCountryList = (List<CodesVO>)(IBankParams.getCodesDataList("ALL", "Country"));
			Iterator<CodesVO> iterator = tempCountryList.iterator();
			if (tempCountryList != null && tempCountryList.size() > 0)
			{
				while (iterator.hasNext())
				{
					CodesVO codesVO = (CodesVO)iterator.next();
					if ( StringMethods.isEmptyString(codesVO.getCode()) )
					{
						codesVO.setCode(" ");
					}
					EVCountryDetailVO countryListVO=new EVCountryDetailVO();
					String countryCode = codesVO.getCode();
					String countryName = codesVO.getMessage();
					countryListVO.setCountryName(countryName);
					countryListVO.setCountryCode(countryCode);
					if ( ! StringMethods.isEmptyString(countryCode) &&   ! "AUS".equalsIgnoreCase(countryCode ))
					{
						countryNameList.add(countryListVO);
					}
				}
				Collections.sort(countryNameList, new Comparator<EVCountryDetailVO>(){
					@Override
					public int compare(EVCountryDetailVO s1, EVCountryDetailVO s2) 
					{
					   return s1.getCountryName().compareToIgnoreCase(s2.getCountryName());
					}
				  });
			}
	 return countryNameList;
	}
	
		
}
