package au.com.stgeorge.mbank.controller.services;

import java.util.Collection;
import java.util.List;
import java.util.UUID;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang.builder.ReflectionToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import au.com.stgeorge.framework.common.logging.Logger;
import au.com.stgeorge.ibank.businessobject.BusinessException;
import au.com.stgeorge.ibank.businessobject.OnlinePINService;
import au.com.stgeorge.ibank.businessobject.ResourceException;
import au.com.stgeorge.ibank.businessobject.globalWallet.GlobalWalletService;
import au.com.stgeorge.ibank.businessobject.globalWallet.GlobalWalletServiceHelper;
import au.com.stgeorge.ibank.common.cache.IBankParams;
import au.com.stgeorge.ibank.servicestation.businessobject.ServiceStation;
import au.com.stgeorge.ibank.servicestation.businessobject.ServiceStationImpl;
import au.com.stgeorge.ibank.servicestation.businessobject.valueobject.ServiceStationVO;
import au.com.stgeorge.ibank.servicestation.util.ServicetationConstants;
import au.com.stgeorge.ibank.util.StringUtil;
import au.com.stgeorge.ibank.valueobject.Account;
import au.com.stgeorge.ibank.valueobject.OnlinePINVO;
import au.com.stgeorge.ibank.valueobject.database.OriginsVO;
import au.com.stgeorge.ibank.valueobject.globalWallet.GlobalWalletDetails;
import au.com.stgeorge.ibank.valueobject.transfer.IBankCommonData;
import au.com.stgeorge.mbank.controller.IMBController;
import au.com.stgeorge.mbank.controller.SecureCodeHelper;
import au.com.stgeorge.mbank.model.common.IMBReq;
import au.com.stgeorge.mbank.model.common.IMBResp;
import au.com.stgeorge.mbank.model.common.ReqHeader;
import au.com.stgeorge.mbank.model.common.RespHeader;
import au.com.stgeorge.mbank.model.request.EmptyReq;
import au.com.stgeorge.mbank.model.request.SecureCodeReq;
import au.com.stgeorge.mbank.model.request.services.OnlinePINGlobalWalletReq;
import au.com.stgeorge.mbank.model.request.services.OnlinePINReq;
import au.com.stgeorge.mbank.model.response.ErrorResp;
import au.com.stgeorge.mbank.model.response.services.OnlinePINResp;
import au.com.stgeorge.mbank.session.MobileSession;
import au.com.stgeorge.mbank.session.MobileSessionImpl;
import au.com.stgeorge.mbank.util.FraudLogger;
import au.com.stgeorge.mbank.util.MBAppHelper;
import au.com.stgeorge.mbank.util.MBAppUtils;
import au.com.stgeorge.mbank.util.MBAppValidator;
import au.com.stgeorge.mbank.util.ServiceConstants;
import au.com.stgeorge.perflogger.PerformanceLogger;
@Controller
@RequestMapping("/onlinepin")
public class OnlinePINController implements IMBController {

	@Autowired
	private OnlinePINService onlinePinService;

	@Autowired
	private OnlinePINHelper helper;

	@Autowired
	private MBAppValidator mbAppValidator;
	
	@Autowired
	private MBAppHelper mbAppHelper;

	@Autowired
	private PerformanceLogger perfLogger;
	
	@Autowired
	private SecureCodeHelper secureCodeHelper;
	
    @Autowired
	private ServiceStation serviceStationService;
    
    @Autowired
	private GlobalWalletService globalWalletService;
    
    @Autowired
	private GlobalWalletServiceHelper gwServiceHelper;

	private FraudLogger fraudLogger;
	public static final String FRAUD_TXN_CHANGE_CARD_PIN = "ChangeCardPIN";
	public static final String FRAUD_TXN_SET_CARD_PIN = "SetCardPIN";
	public static final String FRAUD_FAIL_SYSTEM_ERR = "System error";
	public static final String FRAUD_FAIL_2FA_ERR = "2FA error";
	private static final int ENCRYPTION_ENCODING_LENGTH = 1500;
    private static final String ENCRYPTION_ENCODING_REGEX = "^[0-9a-zA-Z]*$";



	/**
	 * Get Cards service operation
	 * 
	 * @param httpRequest
	 * @param request
	 * @return
	 */
	@RequestMapping(method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE, value = "cards")
	@ResponseBody
	public IMBResp getCards(HttpServletRequest httpRequest, @RequestBody final EmptyReq request) {
		Logger.debug("OnlinePINController - getCards(). Request: " + request, this.getClass());
		String logName = startPerformanceLog(httpRequest);
		MobileSession mobileSession = new MobileSessionImpl();
		OnlinePINResp resp = null;

		try {
			mobileSession.getSessionContext(httpRequest);
			validateRequestHeader(request.getHeader(), httpRequest);
			ErrorResp errorResponse = validate(request, httpRequest);
			if (errorResponse.hasErrors())
				return errorResponse;
			IBankCommonData commonData = new MBAppHelper().populateIBankCommonData(mobileSession, httpRequest);
			Collection<Account> cards = onlinePinService.getEligibleCards(commonData);
			
			mobileSession.setCards((List<Account>) cards);
			resp = helper.populateCardListResponse(populateResponseHeader(ServiceConstants.ONLINE_PIN_SERVICE, mobileSession ), (List<Account>) cards);
			return resp;
		} catch (BusinessException e) {
			Logger.info("BusinessException in OnlinePINController - getCards() - [key: " + e.getKey() + "] : GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());
			if ( e.getKey() ==  BusinessException.ONLINE_PIN_GLOBAL_BYPASS_OR_EXEMPT ){
				return MBAppUtils.createErrorResp(mobileSession.getOrigin(), e, ServiceConstants.ONLINE_PIN_SERVICE, ErrorResp.GLOBAL_BYPASS, httpRequest);
			}
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), e, ServiceConstants.ONLINE_PIN_SERVICE, httpRequest);
		} catch (ResourceException e) {
			Logger.error("ResourceException in OnlinePINController - getCards() - [key: " + e.getKey() + "] : GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.SYSTEM_UNAVILABLE, ServiceConstants.ONLINE_PIN_SERVICE, httpRequest);
		} catch (Exception e) {
			Logger.error("Exception OnlinePINController - getCards(): GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), ResourceException.MOBILE_NON_FINANCIAL_FATAL_ERR, ServiceConstants.ONLINE_PIN_SERVICE, httpRequest);
		} finally {
			endPerformanceLog(logName);
		}
	}
	
	/**
	 * select card
	 * 
	 * @param httpRequest
	 * @param request
	 * @return
	 */
	@RequestMapping(method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE, value = "selectcard")
	@ResponseBody
	public IMBResp selectOnlinePINcard(HttpServletRequest httpRequest, @RequestBody final OnlinePINReq request) {
		Logger.debug("OnlinePINController - selectOnlinePINcard(). Request: " + request, this.getClass());
		String logName = startPerformanceLog(httpRequest);
		MobileSession mobileSession = new MobileSessionImpl();		

		try {
			mobileSession.getSessionContext(httpRequest);
			validateRequestHeader(request.getHeader(), httpRequest);
			ErrorResp errorResponse = validate(request, httpRequest);
			if (errorResponse.hasErrors())
				return errorResponse;
			IBankCommonData commonData = new MBAppHelper().populateIBankCommonData(mobileSession, httpRequest);			
			//add the selected card index in session
			mobileSession.setSelectedAccountIndex(""+request.getCardIndex());			
			OnlinePINResp response = new OnlinePINResp(populateResponseHeader(ServiceConstants.ONLINE_PIN_SERVICE, mobileSession ));
			return response;
		} catch (BusinessException e) {
			Logger.info("BusinessException in OnlinePINController - selectOnlinePINcard() - [key: " + e.getKey() + "] : GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());		
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), e, ServiceConstants.ONLINE_PIN_SERVICE, httpRequest);
		} catch (ResourceException e) {
			Logger.error("ResourceException in OnlinePINController - selectOnlinePINcard() - [key: " + e.getKey() + "] : GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.SYSTEM_UNAVILABLE, ServiceConstants.ONLINE_PIN_SERVICE, httpRequest);
		} catch (Exception e) {
			Logger.error("Exception OnlinePINController - selectOnlinePINcard(): GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), ResourceException.MOBILE_NON_FINANCIAL_FATAL_ERR, ServiceConstants.ONLINE_PIN_SERVICE, httpRequest);
		} finally {
			endPerformanceLog(logName);
		}
	}
	
	/**
	 * req change pin securecode
	 * 
	 * @param httpRequest
	 * @param request
	 * @return
	 */
	@RequestMapping(method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE, value = "reqchangepinsecurecode")
	@ResponseBody
	public IMBResp reqChangePINSecureCode(HttpServletRequest httpRequest, @RequestBody final SecureCodeReq request) {
		Logger.debug("OnlinePINController - reqChangePINSecureCode(). Request: " + request, this.getClass());
		String logName = startPerformanceLog(httpRequest);
		MobileSession mobileSession = new MobileSessionImpl();
		IMBResp resp = null;

		try {
			mobileSession.getSessionContext(httpRequest);
			IBankCommonData commonData = new MBAppHelper().populateIBankCommonData(mobileSession, httpRequest);
			
			validateRequestHeader(request.getHeader(), httpRequest);
			ErrorResp errorResponse = validate(request, httpRequest);// validate json
			if (errorResponse.hasErrors())
				return errorResponse;
			
			if (ServiceConstants.CHANGE_CARD_PIN_TRAN_CODE != request.getTranType()){
				return MBAppUtils.createInvalid2FATransactionTypeResponse(ServiceConstants.ONLINE_PIN_SERVICE);
			}
			OnlinePINVO onlinePINVO = helper.populateOnlinePINVO(mobileSession);

			resp = secureCodeHelper.reqSecureCode(commonData, mobileSession, null, onlinePINVO, request, ServiceConstants.ONLINE_PIN_SERVICE, httpRequest);
			if(resp instanceof ErrorResp){
				errorResponse = (ErrorResp) resp;
				if (errorResponse.hasErrors()){
					fraudLogger = new FraudLogger();
					fraudLogger.logOnlinePINFraud(commonData.getSessionId(), commonData.getUser().getUserId(), commonData.getUser().getGCISNumber(), onlinePINVO.getCardNum(), onlinePINVO.getIssueNum(), commonData.getOrigin(), commonData.getIpAddress(), onlinePINVO.isSetPINFlow() ? FRAUD_TXN_SET_CARD_PIN : FRAUD_TXN_CHANGE_CARD_PIN, commonData.getUserAgent(),  FRAUD_FAIL_2FA_ERR);
				}
			}
			return resp;
			
		} catch (ResourceException e) {
			Logger.error("ResourceException in OnlinePINController - reqChangePINSecureCode() - [key: " + e.getKey() + "], GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());
			mobileSession.removeSecureCodeDetails();
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.SYSTEM_UNAVILABLE, ServiceConstants.ONLINE_PIN_SERVICE, httpRequest);
		} catch (Exception e) {			
			Logger.error("Exception OnlinePINController - reqChangePINSecureCode(): GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "]", e, this.getClass());
			mobileSession.removeSecureCodeDetails();
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.GENERIC_ERROR, ServiceConstants.ONLINE_PIN_SERVICE, httpRequest);
		} finally {
			endPerformanceLog(logName);
		}
	}		
	
	
	/**
	 * verify change pin securecode
	 * 
	 * @param httpRequest
	 * @param request
	 * @return
	 */
	@RequestMapping(method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE, value = "verifychangepinsecurecode")
	@ResponseBody
	public IMBResp verifyChangePINSecureCode(HttpServletRequest httpRequest, @RequestBody final SecureCodeReq request) {
		Logger.debug("OnlinePINController - verifychangepinsecurecode(). Request: " + request, this.getClass());
		String logName = startPerformanceLog(httpRequest);
		MobileSession mobileSession = new MobileSessionImpl();
		OnlinePINResp resp = null;
		try {
			mobileSession.getSessionContext(httpRequest);
			IBankCommonData commonData = new MBAppHelper().populateIBankCommonData(mobileSession, httpRequest);
			
			validateRequestHeader(request.getHeader(), httpRequest);
			ErrorResp errorResponse = validate(request, httpRequest);// validate json
			if (errorResponse.hasErrors())
				return errorResponse;
			
			if (ServiceConstants.CHANGE_CARD_PIN_TRAN_CODE != request.getTranType()){
				return MBAppUtils.createInvalid2FATransactionTypeResponse(ServiceConstants.ONLINE_PIN_SERVICE);
			}
			OnlinePINVO onlinePINVO = helper.populateOnlinePINVO(mobileSession);
				
			errorResponse = secureCodeHelper.verifySecureCode(commonData, mobileSession, onlinePINVO, request, ServiceConstants.ONLINE_PIN_SERVICE, httpRequest);
			if (errorResponse instanceof ErrorResp && errorResponse.hasErrors()){
				fraudLogger = new FraudLogger();
				fraudLogger.logOnlinePINFraud(commonData.getSessionId(), commonData.getUser().getUserId(), commonData.getUser().getGCISNumber(), onlinePINVO.getCardNum(), onlinePINVO.getIssueNum(), commonData.getOrigin(), commonData.getIpAddress(), onlinePINVO.isSetPINFlow() ? FRAUD_TXN_SET_CARD_PIN : FRAUD_TXN_CHANGE_CARD_PIN, commonData.getUserAgent(),  FRAUD_FAIL_2FA_ERR);
				return errorResponse;
			}
			else{
				
				// Check for the GlobalWallet Card
				Boolean globalWalletCardChangePIN = false;
				//19E4 - Check the switch for GlobalWallet and call the GlobalWallet card encryption details service if the BINs are matching
				if(globalWalletService.isGlobalWalletSwitchOn(commonData.getCustomer().getGcis())){
					//check the BIN numbers 
					String brand = gwServiceHelper.isGlobalWalletCard(onlinePINVO.getCardNum());
					if(null != brand){
						//call the backend service to return the modulus, exponent
						onlinePINVO =onlinePinService.getEncryptionDetailsForGlobalWallet();
						onlinePINVO.setGwCardBrand(brand);
						resp =helper.populateEncryptionDetails(populateResponseHeader(ServiceConstants.ONLINE_PIN_SERVICE, mobileSession ), onlinePINVO);
						//set the secure code verified tran name 
						mobileSession.setSecureCodeVerifiedTranName(ServiceConstants.ONLINE_PIN_SERVICE);
						globalWalletCardChangePIN = true;
						resp.setGlobalWalletCardChangePIN(true);
					}
				}
				
				if(!globalWalletCardChangePIN) {
					//all good. call the backend service to return the modulus, exponent and random number
					onlinePINVO =onlinePinService.getEncryptionDetails(commonData);
					resp =helper.populateEncryptionDetails(populateResponseHeader(ServiceConstants.ONLINE_PIN_SERVICE, mobileSession ), onlinePINVO);
					//set the secure code verified tran name 
					mobileSession.setSecureCodeVerifiedTranName(ServiceConstants.ONLINE_PIN_SERVICE);	
					//set the random num in session
					mobileSession.setOnlinePINRandomNum(resp.getRandomNum());
				}
				return resp;
			}			
			
		} catch (ResourceException e) {
			Logger.error("ResourceException in OnlinePINController - verifychangepinsecurecode() - [key: " + e.getKey() + "], GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());
			mobileSession.removeSecureCodeDetails();
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.SYSTEM_UNAVILABLE, ServiceConstants.ONLINE_PIN_SERVICE, httpRequest);
		} catch (Exception e) {			
			Logger.error("Exception OnlinePINController - verifychangepinsecurecode(): GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "]", e, this.getClass());
			mobileSession.removeSecureCodeDetails();
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.GENERIC_ERROR, ServiceConstants.ONLINE_PIN_SERVICE, httpRequest);
		} finally {
			endPerformanceLog(logName);
		}
	}	
	

	/**
	 * change card PIN 
	 * 
	 * @param httpRequest
	 * @param request
	 * @return
	 */
	@RequestMapping(method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE, value = "changecardpin")
	@ResponseBody
	public IMBResp changeCardPIN(HttpServletRequest httpRequest, @RequestBody final OnlinePINReq request) {
		Logger.debug("OnlinePINController - changecardpin(). Request: " + request, this.getClass());
		boolean errExists = false;
		fraudLogger = new FraudLogger();
		IBankCommonData commonData = null;
		String logName = startPerformanceLog(httpRequest);
		MobileSession mobileSession = new MobileSessionImpl();
		OnlinePINResp resp = null;
		OnlinePINVO vo = null;
		
		try {
			mobileSession.getSessionContext(httpRequest);
			commonData = new MBAppHelper().populateIBankCommonData(mobileSession, httpRequest);
			
			validateRequestHeader(request.getHeader(), httpRequest);
			ErrorResp errorResponse = validate(request, httpRequest);// validate json
			if (errorResponse.hasErrors())
				return errorResponse;
			//get the selected card from session
			if(request.isFromActivationFlow()){
				vo = helper.getOnlinePINFromCardActivationSession(mobileSession, request);
			}
			else{
				vo = helper.getOnlinePINFromSession(mobileSession,request);
			}
			
			//Validation of encrypted PIN and encoding parameter
             if(!StringUtil.isFieldValid(vo.getEncryptedPIN(), ENCRYPTION_ENCODING_LENGTH, ENCRYPTION_ENCODING_REGEX)
                         || !StringUtil.isFieldValid(vo.getEncodingParameter(), ENCRYPTION_ENCODING_LENGTH, ENCRYPTION_ENCODING_REGEX)){
            	 return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.SYSTEM_UNAVILABLE, ServiceConstants.ONLINE_PIN_SERVICE, httpRequest);
              }           

			//check if 2fa is verified
			if(mobileSession.getSecureCodeVerifiedTranName() !=null && ServiceConstants.ONLINE_PIN_SERVICE.equalsIgnoreCase(mobileSession.getSecureCodeVerifiedTranName())){
				//call the backend service to set PIN
				
				//17E2 Service Interaction and Cross Sell -- Updating the GDW description if originated from Transaction Cross Sell
				String application = null;
				if(request.getFromCrossSell()){
					application = IBankParams.TNX_CROSSSELL;
				}
				
				onlinePinService.updateCardPIN(commonData, vo, application);				
				resp =helper.populateChangePINResp(populateResponseHeader(ServiceConstants.ONLINE_PIN_SERVICE, mobileSession ));
				resp.setEmailSent(vo.isEmailSent());				
				
				if(vo.isSetPINFlow()) // Service station will be shown only in the set pin flow.
				{
					long insertionPt = helper.getInsertionPointCode(ServicetationConstants.CARD_ACTIVATION);
					ServiceStationVO servicestationVO=populateServiceMessage(insertionPt,ServiceStationImpl.CHANNEL_MOBILE, commonData);
					resp=helper.populateServiceStationResponse(resp,servicestationVO);
					
					if(null!=servicestationVO)
					{
						mobileSession.setServiceStationMessage(servicestationVO.getServiceStationMsg());
					}
				}				
				//delete from the session after successful change of card PIN
				mobileSession.setSecureCodeVerifiedTranName(null);				
				return resp;
			}
			else{
				//2fa was not verified. throw an error
				Logger.error("BusinessException OnlinePINController- No 2FA for changecardpin GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "]", this.getClass());
				fraudLogger.logOnlinePINFraud(commonData.getSessionId(), commonData.getUser().getUserId(), commonData.getUser().getGCISNumber(), vo.getCardNum(), vo.getIssueNum(), commonData.getOrigin(), commonData.getIpAddress(), vo.isSetPINFlow() ? FRAUD_TXN_SET_CARD_PIN : FRAUD_TXN_CHANGE_CARD_PIN, commonData.getUserAgent(), errExists ? FRAUD_FAIL_2FA_ERR : null);				
				throw new ResourceException(ResourceException.SYSTEM_ERROR);
			}
			
		} catch (ResourceException e) {
			errExists = true;
			Logger.error("ResourceException in OnlinePINController - changecardpin() - [key: " + e.getKey() + "], GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());
			mobileSession.removeSecureCodeDetails();
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.SYSTEM_UNAVILABLE, ServiceConstants.ONLINE_PIN_SERVICE, httpRequest);
		} catch (Exception e) {
			errExists = true;
			Logger.error("Exception OnlinePINController - changecardpin(): GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "]", e, this.getClass());
			mobileSession.removeSecureCodeDetails();
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.GENERIC_ERROR, ServiceConstants.ONLINE_PIN_SERVICE, httpRequest);
		} finally {
			fraudLogger.logOnlinePINFraud(commonData != null ? commonData.getSessionId() : "", commonData != null ? commonData.getUser().getUserId() : "", commonData != null ? commonData.getUser().getGCISNumber() : "", vo.getCardNum(), vo.getIssueNum(), commonData != null ? commonData.getOrigin() : "", commonData != null ? commonData.getIpAddress() : "", vo.isSetPINFlow() ? FRAUD_TXN_SET_CARD_PIN : FRAUD_TXN_CHANGE_CARD_PIN, commonData != null ? commonData.getUserAgent() : "", errExists ? FRAUD_FAIL_SYSTEM_ERR : null);			
			endPerformanceLog(logName);
		}
	}
	

	public RespHeader populateResponseHeader(String serviceName, MobileSession mobSession) {
		return mbAppHelper.populateResponseHeader(serviceName, mobSession);
	}
	
	private String startPerformanceLog(HttpServletRequest httpRequest){
		perfLogger.startAllLogs();
		String logName = MBAppUtils.getLogName(httpRequest);
		perfLogger.startLog(logName);
		return logName;
	}
	
	private void endPerformanceLog(String logName){
		perfLogger.endLog(logName);
		perfLogger.endAllLogs();
	}

	public ErrorResp validate(IMBReq serviceRequest, HttpServletRequest request) {
		Logger.info("Service request object - " + ReflectionToStringBuilder.toString(serviceRequest), this.getClass());
		return mbAppValidator.validate(serviceRequest, request);
	}

	public void validateRequestHeader(ReqHeader headerReq, HttpServletRequest request) throws BusinessException {
		Logger.debug("Request header validation: " + ReflectionToStringBuilder.toString(headerReq, ToStringStyle.MULTI_LINE_STYLE), this.getClass());
		mbAppValidator.validateRequestHeader(headerReq, request);
	}
	

	/**
	 * req change pin securecode
	 * 
	 * @param httpRequest
	 * @param request
	 * @return
	 */
	@RequestMapping(method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE, value = "reqsetpinsecurecode")
	@ResponseBody
	public IMBResp reqSetPINSecureCode(HttpServletRequest httpRequest, @RequestBody final SecureCodeReq request) {
		Logger.debug("OnlinePINController - reqChangePINSecureCode(). Request: " + request, this.getClass());
		String logName = startPerformanceLog(httpRequest);
		MobileSession mobileSession = new MobileSessionImpl();
		IMBResp resp = null;

		try {
			mobileSession.getSessionContext(httpRequest);
			IBankCommonData commonData = new MBAppHelper().populateIBankCommonData(mobileSession, httpRequest);
			
			validateRequestHeader(request.getHeader(), httpRequest);
			ErrorResp errorResponse = validate(request, httpRequest);// validate json
			if (errorResponse.hasErrors())
				return errorResponse;
			
			if (ServiceConstants.SET_CARD_PIN_TRAN_CODE != request.getTranType()){
				return MBAppUtils.createInvalid2FATransactionTypeResponse(ServiceConstants.ONLINE_PIN_SERVICE);
			}
			OnlinePINVO onlinePINVO = helper.populateOnlinePINVO(mobileSession);
			
			resp = secureCodeHelper.reqSecureCode(commonData, mobileSession, null, onlinePINVO, request, ServiceConstants.ONLINE_PIN_SERVICE, httpRequest);
			if(resp instanceof ErrorResp){			
				errorResponse = (ErrorResp) resp;
				if (errorResponse.hasErrors()){
					fraudLogger = new FraudLogger();
					fraudLogger.logOnlinePINFraud(commonData.getSessionId(), commonData.getUser().getUserId(), commonData.getUser().getGCISNumber(), onlinePINVO.getCardNum(), onlinePINVO.getIssueNum(), commonData.getOrigin(), commonData.getIpAddress(), onlinePINVO.isSetPINFlow() ? FRAUD_TXN_SET_CARD_PIN : FRAUD_TXN_CHANGE_CARD_PIN, commonData.getUserAgent(),  FRAUD_FAIL_2FA_ERR);
				}
			}
			return resp;
		} catch (ResourceException e) {
			Logger.error("ResourceException in OnlinePINController - reqSetPINSecureCode() - [key: " + e.getKey() + "], GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());
			mobileSession.removeSecureCodeDetails();
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.SYSTEM_UNAVILABLE, ServiceConstants.ONLINE_PIN_SERVICE, httpRequest);
		} catch (Exception e) {			
			Logger.error("Exception OnlinePINController - reqSetPINSecureCode(): GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "]", e, this.getClass());
			mobileSession.removeSecureCodeDetails();
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.GENERIC_ERROR, ServiceConstants.ONLINE_PIN_SERVICE, httpRequest);
		} finally {
			endPerformanceLog(logName);
		}
	}		
	
	
	/**
	 * verify change pin securecode
	 * 
	 * @param httpRequest
	 * @param request
	 * @return
	 */
	@RequestMapping(method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE, value = "verifysetpinsecurecode")
	@ResponseBody
	public IMBResp verifySetPINSecureCode(HttpServletRequest httpRequest, @RequestBody final SecureCodeReq request) {
		Logger.debug("OnlinePINController - verifychangepinsecurecode(). Request: " + request, this.getClass());
		String logName = startPerformanceLog(httpRequest);
		MobileSession mobileSession = new MobileSessionImpl();
		OnlinePINResp resp = null;
		try {
			mobileSession.getSessionContext(httpRequest);
			IBankCommonData commonData = new MBAppHelper().populateIBankCommonData(mobileSession, httpRequest);
			
			validateRequestHeader(request.getHeader(), httpRequest);
			ErrorResp errorResponse = validate(request, httpRequest);// validate json
			if (errorResponse.hasErrors())
				return errorResponse;
			
			if (ServiceConstants.SET_CARD_PIN_TRAN_CODE != request.getTranType()){
				return MBAppUtils.createInvalid2FATransactionTypeResponse(ServiceConstants.ONLINE_PIN_SERVICE);
			}
			OnlinePINVO onlinePINVO = helper.populateOnlinePINVO(mobileSession);
				
			errorResponse = secureCodeHelper.verifySecureCode(commonData, mobileSession, onlinePINVO, request, ServiceConstants.ONLINE_PIN_SERVICE, httpRequest);
			if (errorResponse instanceof ErrorResp && errorResponse.hasErrors()){
				fraudLogger = new FraudLogger();
				fraudLogger.logOnlinePINFraud(commonData.getSessionId(), commonData.getUser().getUserId(), commonData.getUser().getGCISNumber(), onlinePINVO.getCardNum(), onlinePINVO.getIssueNum(), commonData.getOrigin(), commonData.getIpAddress(), onlinePINVO.isSetPINFlow() ? FRAUD_TXN_SET_CARD_PIN : FRAUD_TXN_CHANGE_CARD_PIN, commonData.getUserAgent(),  FRAUD_FAIL_2FA_ERR);
				return errorResponse;
			}
			else{
				//all good. call the backend service to return the modulus, exponent and random number
				
				// Check for the GlobalWallet Card
				Boolean globalWalletCardActivation = false;
				//19E4 - Check the switch for GlobalWallet and call the GlobalWallet card encryption details service if the BINs are matching
				if(globalWalletService.isGlobalWalletSwitchOn(commonData.getCustomer().getGcis())){
					//check the BIN numbers 
					String brand = gwServiceHelper.isGlobalWalletCard(onlinePINVO.getCardNum());
					if(null != brand){
						//call the backend service to return the modulus, exponent
						onlinePINVO =onlinePinService.getEncryptionDetailsForGlobalWallet();	
						onlinePINVO.setGwCardBrand(brand);
						resp =helper.populateEncryptionDetails(populateResponseHeader(ServiceConstants.ONLINE_PIN_SERVICE, mobileSession ), onlinePINVO);
						//set the secure code verified tran name 
						mobileSession.setSecureCodeVerifiedTranName(ServiceConstants.ONLINE_PIN_SERVICE);
						globalWalletCardActivation = true;
						resp.setGlobalWalletCardSetPIN(true);
					}
				}
				if(!globalWalletCardActivation)
				{
					onlinePINVO =onlinePinService.getEncryptionDetails(commonData);
					resp =helper.populateEncryptionDetails(populateResponseHeader(ServiceConstants.ONLINE_PIN_SERVICE, mobileSession ), onlinePINVO);
					//set the secure code verified tran name 
					mobileSession.setSecureCodeVerifiedTranName(ServiceConstants.ONLINE_PIN_SERVICE);	
					//set the random num in session
					mobileSession.setOnlinePINRandomNum(resp.getRandomNum());
				}
				return resp;
			}			
			
		} catch (ResourceException e) {
			Logger.error("ResourceException in OnlinePINController - verifySetPINSecureCode() - [key: " + e.getKey() + "], GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());
			mobileSession.removeSecureCodeDetails();
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.SYSTEM_UNAVILABLE, ServiceConstants.ONLINE_PIN_SERVICE, httpRequest);
		} catch (Exception e) {			
			Logger.error("Exception OnlinePINController - verifySetPINSecureCode(): GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "]", e, this.getClass());
			mobileSession.removeSecureCodeDetails();
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.GENERIC_ERROR, ServiceConstants.ONLINE_PIN_SERVICE, httpRequest);
		} finally {
			endPerformanceLog(logName);
		}
	}	
	
	private ServiceStationVO populateServiceMessage(long insertionPoint,String channel, IBankCommonData commonData)
	{
		ServiceStationVO serviceStationAdminVo=null;
		try
		{
		 serviceStationAdminVo= serviceStationService.getServiceMessage(insertionPoint, ServiceStationImpl.CHANNEL_MOBILE, commonData);			
		}
		 catch(BusinessException ex){
			Logger.error("An error occurred while getting service station message for mobile accoutn details", ex, this.getClass());
		}
		return serviceStationAdminVo;
	}
	
	
	/**
	 * change card PIN for globalWallet Card 
	 * 
	 * @param httpRequest
	 * @param request
	 * @return
	 */
	@RequestMapping(method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE, value = "globalwalletchangecardpin")
	@ResponseBody
	public IMBResp changeCardPINGlobalWallet(HttpServletRequest httpRequest, @RequestBody final OnlinePINGlobalWalletReq request) {
		Logger.debug("OnlinePINController - changeCardPINGlobalWallet(). Request: " + request, this.getClass());
		boolean errExists = false;
		fraudLogger = new FraudLogger();
		IBankCommonData commonData = null;
		String logName = startPerformanceLog(httpRequest);
		MobileSession mobileSession = new MobileSessionImpl();
		OnlinePINResp resp = null;
		OnlinePINVO vo = null;
		
		try {
			mobileSession.getSessionContext(httpRequest);
			commonData = new MBAppHelper().populateIBankCommonData(mobileSession, httpRequest);
			
			validateRequestHeader(request.getHeader(), httpRequest);
			ErrorResp errorResponse = validate(request, httpRequest);// validate json
			if (errorResponse.hasErrors())
				return errorResponse;
			//get the selected card from session
			if(request.isFromActivationFlow()){
				vo = helper.getOnlinePINFromCardActivationSessionGlobalWallet(mobileSession, request);
			}else{
				vo = helper.getOnlinePINFromSessionGlobalWallet(mobileSession,request);
			}
			if(request.isGlobalWalletCardChangePIN()){
				vo.setChangePIN(true);
			}
			
			//SBGEXP-8078 - Cross Brand Validations 
			String brand = gwServiceHelper.isGlobalWalletCard(vo.getCardNum());
			vo.setGwCardBrand(brand);
			
			//Validation of encrypted PIN and encoding parameter
            /* if(!StringUtil.isFieldValid(vo.getEncryptedPIN(), ENCRYPTION_ENCODING_LENGTH, ENCRYPTION_ENCODING_REGEX)
                         || !StringUtil.isFieldValid(vo.getEncodingParameter(), ENCRYPTION_ENCODING_LENGTH, ENCRYPTION_ENCODING_REGEX)){
            	 return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.SYSTEM_UNAVILABLE, ServiceConstants.ONLINE_PIN_SERVICE, httpRequest);
              }*/           

			//check if 2fa is verified
			if(mobileSession.getSecureCodeVerifiedTranName() !=null && ServiceConstants.ONLINE_PIN_SERVICE.equalsIgnoreCase(mobileSession.getSecureCodeVerifiedTranName())){
				//call the backend service to set PIN
				
				//17E2 Service Interaction and Cross Sell -- Updating the GDW description if originated from Transaction Cross Sell
				String application = null;
				if(request.getFromCrossSell()){
					application = IBankParams.TNX_CROSSSELL;
				}
				// Call the GlobalWallet Set PIN 
				String gcisNumber = mobileSession.getCustomer().getGcis().trim();
				GlobalWalletDetails globalWalletDetails = globalWalletService.setGlobalWalletCardPIN(commonData, UUID.randomUUID(),vo, gcisNumber, application,mobileSession.getCardActivation());
				resp =helper.populateChangePINResp(populateResponseHeader(ServiceConstants.ONLINE_PIN_SERVICE, mobileSession ));
				if(request.isGlobalWalletCardChangePIN()){
					resp.setGlobalWalletCardChangePIN(globalWalletDetails.getSetPINSuccess());
				}
				if(request.isGlobalWalletCardSetPIN()){
					resp.setGlobalWalletCardSetPIN(globalWalletDetails.getSetPINSuccess());
				}
				resp.setEmailSent(vo.isEmailSent());
				
				//20E1: SBGEXP-7950 - set the response from change PIN API
				helper.setGlobalWalletChangePINResponse(resp, globalWalletDetails);
											
				mobileSession.setSecureCodeVerifiedTranName(null);				
				return resp;
			}
			else{
				//2fa was not verified. throw an error
				Logger.error("BusinessException OnlinePINController- No 2FA for changeCardPINGlobalWallet GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "]", this.getClass());
				fraudLogger.logOnlinePINFraud(commonData.getSessionId(), commonData.getUser().getUserId(), commonData.getUser().getGCISNumber(), vo.getCardNum(), vo.getIssueNum(), commonData.getOrigin(), commonData.getIpAddress(), vo.isSetPINFlow() ? FRAUD_TXN_SET_CARD_PIN : FRAUD_TXN_CHANGE_CARD_PIN, commonData.getUserAgent(), errExists ? FRAUD_FAIL_2FA_ERR : null);				
				throw new ResourceException(ResourceException.SYSTEM_ERROR);
			}
			
		} catch (BusinessException e){ // added for 19E4: Global Wallet - SBGEXP-6898
			IMBResp resp1 = null;
			Logger.info("BusinessException Inside changeCardPIN() for Customer GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());			
			BusinessException exp = new BusinessException(e.getKey());
			
			if(e.getKey() == BusinessException.GLOBAL_WALLET_COULD_NOT_PROCESS_REQUEST_ERROR)
			{
				OriginsVO myOriginVO  = IBankParams.getOrigin(mobileSession.getOrigin());
				OriginsVO baseOrigin  = IBankParams.getOrigin(myOriginVO.getBankName());
				String[] values = {baseOrigin.getPhone()};	
				resp1  = MBAppUtils.createErrorResp(mobileSession.getOrigin(), exp, values, ServiceConstants.ONLINE_PIN_SERVICE, httpRequest);
			} else{				
				resp1  = MBAppUtils.createErrorResp(mobileSession.getOrigin(), exp, ServiceConstants.ONLINE_PIN_SERVICE, httpRequest);
			}
			return resp1;
		} catch (ResourceException e) {
			errExists = true;
			Logger.error("ResourceException in OnlinePINController - changeCardPINGlobalWallet() - [key: " + e.getKey() + "], GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());
			mobileSession.removeSecureCodeDetails();
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.SYSTEM_UNAVILABLE, ServiceConstants.ONLINE_PIN_SERVICE, httpRequest);
		} catch (Exception e) {
			errExists = true;
			Logger.error("Exception OnlinePINController - changeCardPINGlobalWallet(): GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "]", e, this.getClass());
			mobileSession.removeSecureCodeDetails();
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.GENERIC_ERROR, ServiceConstants.ONLINE_PIN_SERVICE, httpRequest);
		} finally {
			fraudLogger.logOnlinePINFraud(commonData != null ? commonData.getSessionId() : "", commonData != null ? commonData.getUser().getUserId() : "", commonData != null ? commonData.getUser().getGCISNumber() : "", vo.getCardNum(), vo.getIssueNum(), commonData != null ? commonData.getOrigin() : "", commonData != null ? commonData.getIpAddress() : "", vo.isSetPINFlow() ? FRAUD_TXN_SET_CARD_PIN : FRAUD_TXN_CHANGE_CARD_PIN, commonData != null ? commonData.getUserAgent() : "", errExists ? FRAUD_FAIL_SYSTEM_ERR : null);			
			endPerformanceLog(logName);
		}
	}
}
