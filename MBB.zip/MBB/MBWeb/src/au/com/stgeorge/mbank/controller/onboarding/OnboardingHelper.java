package au.com.stgeorge.mbank.controller.onboarding;

import java.util.regex.Pattern;

import org.springframework.stereotype.Service;
import au.com.stgeorge.framework.common.logging.Logger;
import au.com.stgeorge.ibank.businessobject.StatisticsService;
import au.com.stgeorge.ibank.common.cache.IBankParams;
import au.com.stgeorge.ibank.common.log.IBankLog;
import au.com.stgeorge.ibank.valueobject.Statistic;
import au.com.stgeorge.ibank.valueobject.transfer.IBankCommonData;
import au.com.stgeorge.security.util.StringMethods;

@Service
public class OnboardingHelper {

	public static void addStatisticsLog(IBankCommonData commonData,String statAction, String description){
		
		Statistic s = new Statistic();	
		
		s.setAction(statAction);
		s.setGcisNumber(commonData.getUser().getGCISNumber());		
		s.setOriginBank(commonData.getOrigin());	
				
		if(!StringMethods.isEmptyString(description)){
			if (description.length() > 255) {
				description = description.substring(0, 255);
			}
		}else{
			description = "";
		}
		
			
		s.setDescription(description);
		s.setIpAddress(commonData.getIpAddress());
		s.setSessionId(commonData.getSessionId());	
		
		try{
			StatisticsService.logStatistic(s);
		}
		catch (Throwable t) {
			IBankLog.logWRN("Failed to create a statistic entry for GDW", t, OnboardingHelper.class);
		}		
	}
	
	/**/
	
	protected String getGdwOrigin(String origin){
		String baseOrigin = IBankParams.getBaseOriginCode(origin);
		Logger.debug("Base origin for GDW is :: "+baseOrigin, OnboardingHelper.class);
		return IBankParams.MOBILE_INDICATOR + baseOrigin;
	}
	
	/**/
	
	
	private static String IP_ADDRESS_REG_EX = "\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}" ;
	
	public static boolean isValidIPAddress(String str) {
	  Pattern ipPattern = Pattern.compile(IP_ADDRESS_REG_EX);
	  return ipPattern.matcher(str).matches();
	}
	
	
	
}
