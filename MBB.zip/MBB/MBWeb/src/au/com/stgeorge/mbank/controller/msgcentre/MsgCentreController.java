/**
 * 
 */
package au.com.stgeorge.mbank.controller.msgcentre;

import java.io.IOException;
import java.io.PrintWriter;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;

import au.com.stgeorge.framework.common.logging.Logger;
import au.com.stgeorge.ibank.businessobject.BusinessException;
import au.com.stgeorge.ibank.businessobject.HeartBeat;
import au.com.stgeorge.ibank.businessobject.ResourceException;
import au.com.stgeorge.ibank.evcrs.businessobject.valueobject.EVCustDetails;
import au.com.stgeorge.ibank.messagecentre.util.MessageCentreConstants;
import au.com.stgeorge.ibank.messagecentre.valueobject.MessageSearch;
import au.com.stgeorge.ibank.util.CommonBusinessUtil;
import au.com.stgeorge.ibank.valueobject.Customer;
import au.com.stgeorge.ibank.valueobject.transfer.IBankCommonData;
import au.com.stgeorge.mbank.controller.IMBController;
import au.com.stgeorge.mbank.model.common.IMBReq;
import au.com.stgeorge.mbank.model.common.IMBResp;
import au.com.stgeorge.mbank.model.common.ReqHeader;
import au.com.stgeorge.mbank.model.common.RespHeader;
import au.com.stgeorge.mbank.model.request.EmptyReq;
import au.com.stgeorge.mbank.model.request.msgcentre.MsgCentreReq;
import au.com.stgeorge.mbank.model.response.ErrorResp;
import au.com.stgeorge.mbank.model.response.SuccessResp;
import au.com.stgeorge.mbank.session.MobileSession;
import au.com.stgeorge.mbank.util.FraudLogger;
import au.com.stgeorge.mbank.util.MBAppHelper;
import au.com.stgeorge.mbank.util.MBAppUtils;
import au.com.stgeorge.mbank.util.MBAppValidator;
import au.com.stgeorge.mbank.util.ServiceConstants;
import au.com.stgeorge.mobilebank.businessobject.MobileMsgCntrService;
import au.com.stgeorge.perflogger.PerformanceLogger;

import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * @author C50216
 *
 */

@Controller
@RequestMapping("/msgcentre")
public class MsgCentreController implements IMBController{
	
	private FraudLogger fraudLogger;
	
	@Autowired
	private MobileMsgCntrService msgCntrService;
	
	@Autowired
	private MBAppHelper mbAppHelper;
	
	@Autowired
	private MBAppValidator mbAppValidator;
	
	@Autowired
	private MsgCentreHelper msgCentreHelper;
	
	@Autowired
	private PerformanceLogger perfLogger;
	
	@RequestMapping(value = "list", method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public IMBResp processMsgList(HttpServletRequest httpServletRequest,HttpServletResponse httpServletResponse,
			@RequestBody final EmptyReq req){ 
				
		ObjectMapper objectMapper = new ObjectMapper();			
		List<MessageSearch> msgList = null;
		MessageSearch messageSearch = new MessageSearch();				
				
		perfLogger.startAllLogs();
		String logName = MBAppUtils.getLogName(httpServletRequest);
		perfLogger.startLog(logName);		
		fraudLogger = new FraudLogger();		
		MobileSession mbSession = null;
		try{
			mbSession = mbAppHelper.getMobileSession(httpServletRequest);
			Logger.info("Message List JSON Request :" + objectMapper.writeValueAsString(req), this.getClass());
			validateRequestHeader(req.getHeader(), httpServletRequest);
			ErrorResp errorResp = validate(req, httpServletRequest);
					
			if (errorResp != null && errorResp.getErrors() != null && errorResp.getErrors().size() > 0)
			{				
				//fraudLogger.logInvalidInput();
				return errorResp;
			}			
						
			if (!HeartBeat
				    .isApplicationAvailable(HeartBeat.MSGCENTRE_APPLICATION_ID)) {
					throw new BusinessException(BusinessException.MC_MSG_CNTR_UNAVAILABLE);
				}
															
			Customer customer = mbSession.getCustomer();
			messageSearch.setGcisNumber(customer.getGcis());
						
			IBankCommonData commonData=mbAppHelper.populateIBankCommonData(mbSession,httpServletRequest);
			boolean isECorrespondenceSupported = CommonBusinessUtil.isECorrespondenceSupported(httpServletRequest);
			msgList = msgCntrService.getMobileCustMsgList(messageSearch,commonData,isECorrespondenceSupported);
			int unreadCount = msgCntrService.findMobCustMsgUnreadCount(customer.getGcis(),isECorrespondenceSupported,commonData.getOrigin());
			
			for(MessageSearch msg : msgList){		    	  
		    	  if (msg != null && msg.getMsgType() != null && msg.getMsgType().equalsIgnoreCase(MessageCentreConstants.CD_MSG_TYPE)) {          	
		    		MessageSearch tempMsg = msgCntrService.findMobMsg(msg);
		          	msg.setMobSubject(msgCntrService.getSubjectWithReplacedFields(tempMsg, true));          	
		          }
		    	//20E1-HomeLoan
		    	  if (msg != null && msg.getMsgType() != null && msg.getMsgType().equalsIgnoreCase(MessageCentreConstants.HOMELOAN_DIGI_TYP)) {          	
			          	
		    		  	MessageSearch tempMsg = msgCntrService.findMobMsg(msg);
			          	msg.setMobSubject(msgCntrService.getSubjectWithReplacedFields(tempMsg, true));          	
			          }
		    }
			
			IMBResp serviceResponse = msgCentreHelper.populateMsgListResp(msgList, unreadCount);
			
			RespHeader headerResp = populateResponseHeader(ServiceConstants.MSGCENTRE_LIST_SERVICE, mbSession);
			serviceResponse.setHeader(headerResp);
			
			Logger.info("Message List JSON Response :" + objectMapper.writeValueAsString(serviceResponse), this.getClass());
									
			return serviceResponse;
					
		}catch (BusinessException e)
		{
			Logger.info("BusinessException Inside processMsgList() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			BusinessException exp = new BusinessException(e.getKey());
			IMBResp resp1  = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, ServiceConstants.MSGCENTRE_LIST_SERVICE, httpServletRequest);
			return resp1;
		}catch (ResourceException e){
			Logger.error("ResourceException Inside processMsgList() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			ResourceException exp = new ResourceException(e.getKey());
			IMBResp resp1  = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, ServiceConstants.MSGCENTRE_LIST_SERVICE, httpServletRequest);
			return resp1;
		} catch (Exception e)
		{
			Logger.error("Exception Inside processMsgList() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			BusinessException exp = new BusinessException(BusinessException.GENERIC_ERROR);
			IMBResp resp1  = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, ServiceConstants.MSGCENTRE_LIST_SERVICE, httpServletRequest);
			return resp1;
		} finally
		{
			perfLogger.endLog(logName);
			perfLogger.endAllLogs();
		}	
						
	}
				
	@RequestMapping(value = "detail", method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public void processMsgContent(HttpServletRequest httpServletRequest,HttpServletResponse httpServletResponse,
			@RequestBody final MsgCentreReq req) { 
				
		ObjectMapper objectMapper = new ObjectMapper();					
		MessageSearch messageSearch = new MessageSearch();				
		
		perfLogger.startAllLogs();
		String logName = MBAppUtils.getLogName(httpServletRequest);
		perfLogger.startLog(logName);		
		fraudLogger = new FraudLogger();		
		String msgContent = "";
		PrintWriter out = null;	
		MobileSession mbSession = null;
		try{			
			mbSession = mbAppHelper.getMobileSession(httpServletRequest);
			httpServletResponse.setContentType("text/html");
			out = httpServletResponse.getWriter();
			Logger.info("Message Content JSON Request :" + objectMapper.writeValueAsString(req), this.getClass());
			ErrorResp errorResp = validate(req, httpServletRequest);
					
			if (errorResp != null && errorResp.getErrors() != null && errorResp.getErrors().size() > 0)
			{				
				//fraudLogger.logInvalidInput();				
				out.print("{} && " + objectMapper.writeValueAsString(errorResp));				
			}else{
				
				if (!HeartBeat
						.isApplicationAvailable(HeartBeat.MSGCENTRE_APPLICATION_ID)) {
					throw new BusinessException(BusinessException.MC_MSG_CNTR_UNAVAILABLE);
				}
								
				Customer customer = mbSession.getCustomer();
				messageSearch.setGcisNumber(customer.getGcis());
				messageSearch.setCustMsgID(req.getCustomerMsgId());
				messageSearch.setMsgType(req.getType());

				IBankCommonData commonData=mbAppHelper.populateIBankCommonData(mbSession,httpServletRequest);
				
				MessageSearch msgDetails = msgCntrService.getMobileCustMsgDetails(messageSearch,commonData,mbSession.getOrigin());
				
				EVCustDetails evCustDetails=getReIDVFunctionlink(msgDetails);
				mbSession.setEvCustDetails(evCustDetails);
				
				msgContent = msgCentreHelper.replaceLinks(msgDetails.getMobContentWithData());
								
				msgContent = URLEncoder.encode(msgContent);//ISG : Sanitise msg before sending it to mobile
				
				Logger.info("Message Content text Response :" + msgContent ,this.getClass());			
				out.print(msgContent);
			}
							
		}catch (BusinessException e)
		{
			Logger.info("BusinessException Inside processMsgContent() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			BusinessException exp = new BusinessException(e.getKey());
			IMBResp resp1  = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, ServiceConstants.MSGCENTRE_DETAIL_SERVICE, httpServletRequest);
			try {
				Logger.error("Business Exception inside processMsgContent() ", e, this.getClass());
				out.print("{} && " + objectMapper.writeValueAsString(resp1));
			}catch (IOException e1) {
				Logger.error("Business Exception inside processMsgContent() IOException", e1, this.getClass());
			}
						
		}catch (ResourceException e){
			Logger.error("ResourceException Inside processMsgContent() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			ResourceException exp = new ResourceException(e.getKey());
			IMBResp resp1  = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, ServiceConstants.MSGCENTRE_DETAIL_SERVICE, httpServletRequest);
			try {
				Logger.error("Resource Exception inside processMsgContent() ", e, this.getClass());
				out.print("{} && " + objectMapper.writeValueAsString(resp1));
			}catch (IOException e1) {
				Logger.error("Resource Exception inside processMsgContent() IOException", e1, this.getClass());
			}					
		} catch (Exception e)
		{
			Logger.error("Exception Inside processMsgContent() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			BusinessException exp = new BusinessException(BusinessException.GENERIC_ERROR);
			IMBResp resp1  = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, ServiceConstants.MSGCENTRE_DETAIL_SERVICE, httpServletRequest);			
			try {
				Logger.error("Exception inside processMsgContent() ", e, this.getClass());
				out.print("{} && " + objectMapper.writeValueAsString(resp1));
			}catch (IOException e1) {
				Logger.error("Exception inside processMsgContent() IOException", e1, this.getClass());
			}
			
		} finally
		{
			perfLogger.endLog(logName);
			perfLogger.endAllLogs();
		}						
	}
	
	@RequestMapping(value = "delete", method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public IMBResp processMsgDelete(HttpServletRequest httpServletRequest,HttpServletResponse httpServletResponse,
			@RequestBody final MsgCentreReq req){ 
				
		ObjectMapper objectMapper = new ObjectMapper();			
		List<MessageSearch> msgList = null;
		MessageSearch messageSearch = new MessageSearch();					
		List deletionList = new ArrayList();
										
		perfLogger.startAllLogs();
		String logName = MBAppUtils.getLogName(httpServletRequest);
		perfLogger.startLog(logName);		
		fraudLogger = new FraudLogger();		
		MobileSession mbSession = null;
		try{
			mbSession = mbAppHelper.getMobileSession(httpServletRequest);
			Logger.info("Message Delete JSON Request :" + objectMapper.writeValueAsString(req), this.getClass());
			validateRequestHeader(req.getHeader(), httpServletRequest);
			ErrorResp errorResp = validate(req, httpServletRequest);			
			
			if (errorResp != null && errorResp.getErrors() != null && errorResp.getErrors().size() > 0)
			{				
				//fraudLogger.logInvalidInput();
				return errorResp;
			}			
			
			if (!HeartBeat
				    .isApplicationAvailable(HeartBeat.MSGCENTRE_APPLICATION_ID)) {
					throw new BusinessException(BusinessException.MC_MSG_CNTR_UNAVAILABLE);
				}
												
			long custMsgId = req.getCustomerMsgId(); 			
			Customer customer = mbSession.getCustomer();
			String gcisNumber = customer.getGcis();
			messageSearch.setGcisNumber(gcisNumber);
			IBankCommonData commonData=mbAppHelper.populateIBankCommonData(mbSession,httpServletRequest);
			
			
			long msgId = msgCntrService.getMsgId(custMsgId, gcisNumber);
			deletionList.add(custMsgId);		
			msgCntrService.deleteCustomerMessages(deletionList,customer.getGcis(),commonData,msgId);
			boolean isECorrespondenceSupported = CommonBusinessUtil.isECorrespondenceSupported(httpServletRequest);
			int unreadCount = msgCntrService.findMobCustMsgUnreadCount(gcisNumber,isECorrespondenceSupported,commonData.getOrigin());
			msgList = msgCntrService.getMobileCustMsgList(messageSearch,commonData,isECorrespondenceSupported);
			
			IMBResp serviceResponse = msgCentreHelper.populateMsgListResp(msgList, unreadCount);
			
			RespHeader headerResp = populateResponseHeader(ServiceConstants.MSGCENTRE_DELETE_SERVICE, mbSession);
			serviceResponse.setHeader(headerResp);
			
			Logger.info("Message Delete JSON Response :" + objectMapper.writeValueAsString(serviceResponse), this.getClass());
			
			return serviceResponse;
					
		}catch (BusinessException e){
			Logger.info("BusinessException Inside processMsgDelete() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			BusinessException exp = new BusinessException(e.getKey());
			IMBResp resp1  = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, ServiceConstants.MSGCENTRE_DELETE_SERVICE, httpServletRequest);
			return resp1;
		}catch (ResourceException e){
			Logger.error("ResourceException Inside processMsgDelete() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			ResourceException exp = new ResourceException(e.getKey());
			IMBResp resp1  = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, ServiceConstants.MSGCENTRE_DELETE_SERVICE, httpServletRequest);
			return resp1;
		} catch (Exception e){
			Logger.error("Exception Inside processMsgDelete() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			BusinessException exp = new BusinessException(BusinessException.GENERIC_ERROR);
			IMBResp resp1  = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, ServiceConstants.MSGCENTRE_DELETE_SERVICE, httpServletRequest);
			return resp1;
		} finally
		{
			perfLogger.endLog(logName);
			perfLogger.endAllLogs();
		}	
						
	}	
	
	@RequestMapping(value = "logGDWForAutoApply", method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public IMBResp logGDWForAutoApply(HttpServletRequest httpServletRequest,HttpServletResponse httpServletResponse,@RequestBody final EmptyReq req){
	
		ObjectMapper objectMapper = new ObjectMapper();			
										
		perfLogger.startAllLogs();
		String logName = MBAppUtils.getLogName(httpServletRequest);
		perfLogger.startLog(logName);		
		fraudLogger = new FraudLogger();		
		MobileSession mbSession = null;
	
		
		try{
			mbSession = mbAppHelper.getMobileSession(httpServletRequest);
			Logger.info("GDWForAutoApply JSON Request :" + objectMapper.writeValueAsString(req), this.getClass());
			validateRequestHeader(req.getHeader(), httpServletRequest);
			ErrorResp errorResp = validate(req, httpServletRequest);			
			
			if (errorResp != null && errorResp.getErrors() != null && errorResp.getErrors().size() > 0)
			{				
				//fraudLogger.logInvalidInput();
				return errorResp;
			}			
			
			if (!HeartBeat
				    .isApplicationAvailable(HeartBeat.MSGCENTRE_APPLICATION_ID)) {
					throw new BusinessException(BusinessException.MC_MSG_CNTR_UNAVAILABLE);
				}
			IBankCommonData commonData=mbAppHelper.populateIBankCommonData(mbSession,httpServletRequest);
			
			mbAppHelper.logGDWForAutoApply(commonData);
			
			
			
			SuccessResp successResp = new SuccessResp();																			
			RespHeader headerResp = populateResponseHeader(ServiceConstants.AUTO_APPLY_GDW_LOG, mbSession);
			successResp.setHeader(headerResp);
			successResp.setIsSuccess(true);
			
			
			
			return successResp;
			
		}
		catch (BusinessException e){
			Logger.info("BusinessException Inside logGDWForAutoApply() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			BusinessException exp = new BusinessException(e.getKey());
			IMBResp resp1  = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, ServiceConstants.AUTO_APPLY_GDW_LOG, httpServletRequest);
			return resp1;
		}catch (ResourceException e){
			Logger.error("ResourceException Inside logGDWForAutoApply() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			ResourceException exp = new ResourceException(e.getKey());
			IMBResp resp1  = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, ServiceConstants.AUTO_APPLY_GDW_LOG, httpServletRequest);
			return resp1;
		} catch (Exception e){
			Logger.error("Exception Inside logGDWForAutoApply() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			BusinessException exp = new BusinessException(BusinessException.GENERIC_ERROR);
			IMBResp resp1  = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, ServiceConstants.AUTO_APPLY_GDW_LOG, httpServletRequest);
			return resp1;
		} finally
		{
			perfLogger.endLog(logName);
			perfLogger.endAllLogs();
		}
		
		
	}
	
	
	
	
	
	
	/**
	 * Response for invalid body request 
	 * 
	 * @return
	 */
	@ExceptionHandler({org.springframework.http.converter.HttpMessageNotReadableException.class})
	@ResponseStatus(org.springframework.http.HttpStatus.OK)
	@ResponseBody
	public IMBResp resolveException() {		
		return MBAppUtils.createInvalidMessageBodyResponse(ServiceConstants.MSGCENTRE_LIST_SERVICE);
	}
	
	public ErrorResp validate(IMBReq serviceRequest, HttpServletRequest request) {
		return  mbAppValidator.validate(serviceRequest, request);
	}
	
	public void validateRequestHeader(ReqHeader header, HttpServletRequest request) throws ResourceException
	{	
		mbAppValidator.validateRequestHeader(header,  request);	
	}
	
	public RespHeader populateResponseHeader(String ServiceName)
	{		
		return mbAppHelper.populateResponseHeader(ServiceName);
	}				
	
	
	public RespHeader populateResponseHeader(String serviceName, MobileSession mobSession )
	{
		return mbAppHelper.populateResponseHeader(serviceName, mobSession);
	}
	
	private EVCustDetails getReIDVFunctionlink(MessageSearch messages)
	{
        EVCustDetails evCustDetails = new EVCustDetails();
        if(null!= messages && null!= messages.getMobContent()){                                                                          
              Pattern pattern = Pattern.compile("\\[link " + MessageCentreConstants.CUST_MSG_REIDV_FUNCTIONLINK + "\\]");
              Matcher matcher = pattern.matcher(messages.getMobContent());
              while (matcher.find()) {                                          
                    evCustDetails.setReIDVMsg(true);
              }
        }
        return evCustDetails;
  }


}
