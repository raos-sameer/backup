package au.com.stgeorge.mbank.model.request.fixedhomeloan;

import javax.validation.constraints.NotNull;

import au.com.stgeorge.ibank.businessobject.BusinessException;
import au.com.stgeorge.mbank.model.common.IMBReq;
import au.com.stgeorge.mbank.model.common.ReqHeader;

public class FixedHomeLoanFormReq implements IMBReq{

	private static final long serialVersionUID = -1219853234497299425L;
	
	private ReqHeader header;
	@NotNull(message = "" + BusinessException.WSVC_INVALID_INPUT_PARAM)
	private Integer accountIndex;
	private String bannerClickedFrom;
	
	public Integer getAccountIndex() {
		return accountIndex;
	}
	
	public void setAccountIndex(Integer accountIndex) {
		this.accountIndex = accountIndex;
	}
	
	public String getBannerClickedFrom() {
		return bannerClickedFrom;
	}

	public void setBannerClickedFrom(String bannerClickedFrom) {
		this.bannerClickedFrom = bannerClickedFrom;
	}

	public ReqHeader getHeader(){
		return header;
	}
	
	public void setHeader(ReqHeader header){
		this.header = header;
	}
	
	
}
