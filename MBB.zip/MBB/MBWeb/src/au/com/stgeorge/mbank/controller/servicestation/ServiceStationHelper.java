package au.com.stgeorge.mbank.controller.servicestation;

import org.springframework.stereotype.Service;

import au.com.stgeorge.mbank.model.common.RespHeader;
import au.com.stgeorge.mbank.model.response.SuccessResp;



@Service
public class ServiceStationHelper {
	
	
	protected SuccessResp populateSuccessResp(RespHeader headerResp){
		SuccessResp serviceResponse = new SuccessResp();
		serviceResponse.setHeader(headerResp);
		serviceResponse.setIsSuccess(true);
		return serviceResponse;
	}
	
	
}
