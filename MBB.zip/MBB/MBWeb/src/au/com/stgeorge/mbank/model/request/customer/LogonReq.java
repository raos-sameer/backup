package au.com.stgeorge.mbank.model.request.customer;

import java.io.Serializable;

import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.NotEmpty;

import au.com.stgeorge.framework.common.logging.Logger;
import au.com.stgeorge.ibank.businessobject.BusinessException;
import au.com.stgeorge.mbank.model.common.ReqHeader;
import au.com.stgeorge.mbank.model.common.IMBReq;

public class LogonReq implements IMBReq, Serializable{
	
	private static final long serialVersionUID = -256469501889499119L;

	//@NotEmpty (message = ""+BusinessException.WSVC_INVALID_INPUT_PARAM)
	@Size(max = 16,message = ""+BusinessException.INVALID_USERID_PASSWORD)
	@Pattern(regexp="([0-9]+)",message = ""+BusinessException.INVALID_USERID_PASSWORD)
	private String accessNumber;

	
//	@NotEmpty (message = ""+BusinessException.WSVC_INVALID_INPUT_PARAM)
	@Size(max = 6,message = ""+BusinessException.INVALID_USERID_PASSWORD)
	@Pattern(regexp="([0-9]+)",message = ""+BusinessException.INVALID_USERID_PASSWORD)
	private String securityNumber;

	// @NotEmpty (message = ""+BusinessException.WSVC_INVALID_INPUT_PARAM)
	@Size(max = 12,message = ""+BusinessException.INVALID_USERID_PASSWORD)
	@Pattern(regexp="([a-zA-Z0-9]+)",message = ""+BusinessException.INVALID_USERID_PASSWORD)
	private String password;
	

//	@NotEmpty (message = ""+BusinessException.WSVC_INVALID_INPUT_PARAM)
  @Size(max = 1,message = ""+BusinessException.INVALID_USERID_PASSWORD)
	@Pattern(regexp="([a-zA-Z0-9]+)",message = ""+BusinessException.INVALID_USERID_PASSWORD)
	private String issueNumber;
	
/*	@NotEmpty (message = ""+BusinessException.WSVC_INVALID_INPUT_PARAM)
	@Size(max = 50,message = ""+BusinessException.SMPL_INV_INP_PARAMS)
	@Pattern(regexp="([a-zA-Z0-9]+)",message = ""+BusinessException.SMPL_INV_INP_PARAMS)
	private String token;  */
	
	private boolean rememberMe;
	private boolean saveCan;
	private String devicePrint;
	private String actionType;
	
	public boolean isSaveCan()
	{
		return saveCan;
	}
	public void setSaveCan(boolean saveCan)
	{
		this.saveCan = saveCan;
	}
	public boolean isRememberMe()
	{
		return rememberMe;
	}
	public void setRememberMe(boolean rememberMe)
	{
		this.rememberMe = rememberMe;
	}

	private ReqHeader header;
	

	public ReqHeader getHeader()
	{
		return header;
	}
	public void setHeader(ReqHeader header)
	{
		this.header = header;
	}
	
	public String getAccessNumber() {
		return accessNumber;
	}
	public void setAccessNumber(String accessNumber) {
		this.accessNumber = accessNumber;
	}
	public String getSecurityNumber() {
		return securityNumber;
	}
	public void setSecurityNumber(String securityNumber) {
		this.securityNumber = securityNumber;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getIssueNumber() {
		return issueNumber;
	}
	public void setIssueNumber(String issueNumber) {
		this.issueNumber = issueNumber;
	}
	public static long getSerialVersionUID() {
		return serialVersionUID;
	}
	
	/* @NotEmpty (message = ""+BusinessException.WSVC_INVALID_INPUT_PARAM)
	//@Size(max = 10,message = ServiceConstants.INVALID_INPUT_PARAMS)
	@Pattern(regexp="([a-zA-Z0-9]+)",message = ""+BusinessException.WSVC_INVALID_INPUT_PARAM)
	private String nameId;

	public String getNameId()
	{
		return nameId;
	}

	public void setNameId(String nameId)
	{
		this.nameId = nameId;
	} */

	
	private String tcViewed;
	private String action;
	
	
	public String getAction()
	{
		return action;
	}
	public void setAction(String action)
	{
		this.action = action;
	}
	public String getTcViewed()
	{
		return tcViewed;
	}
	public void setTcViewed(String tcViewed)
	{
		this.tcViewed = tcViewed;
	}
	public void toXML()
	{
		Logger.debug("Objcet " + accessNumber + " " + issueNumber + " " + getHeader().getNameId() + " " + password + " " + getHeader().getClientApiVersion() , this.getClass());
		
	}
	public String getDevicePrint() {
		return devicePrint;
	}
	public void setDevicePrint(String devicePrint) {
		this.devicePrint = devicePrint;
	}
	public String getActionType() {
		return actionType;
	}
	public void setActionType(String actionType) {
		this.actionType = actionType;
	}
 
}
