package au.com.stgeorge.mbank.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import au.com.stgeorge.framework.common.logging.Logger;
import au.com.stgeorge.ibank.businessobject.BusinessException;
import au.com.stgeorge.ibank.common.cache.IBankParams;
import au.com.stgeorge.ibank.util.StringUtil;
import au.com.stgeorge.ibank.valueobject.database.CodesVO;
import au.com.stgeorge.mbank.model.common.IMBReq;
import au.com.stgeorge.mbank.model.common.IMBResp;
import au.com.stgeorge.mbank.model.common.ReqHeader;
import au.com.stgeorge.mbank.model.common.RespHeader;
import au.com.stgeorge.mbank.model.response.ErrorResp;
import au.com.stgeorge.mbank.session.MobileSession;
import au.com.stgeorge.mbank.util.MBAppHelper;
import au.com.stgeorge.mbank.util.MBAppUtils;
import au.com.stgeorge.mbank.util.MBAppValidator;
import au.com.stgeorge.mbank.util.ServiceConstants;

/**
 * This class is created to populate deep links for IB to MB flow.<br><br> 
 * 
 * Based on the "ActionType" which is the request parameter, redirection URL to be retrieved from RELEASECODES Table.<br><br> 
 *
 * When "ActionType" is null or contains junk chars, user will be redirected to IB dash board.<br><br>
 * 
 */

@Controller
public class RedirectToDesktopController implements IMBController {

	private static final String REQ_ACTION_TYPE = "ActionType";	
	private static final String BLOCK_CHARS = "^[0-9A-Za-z',. &/\\-_]*$";
	private static final String IBANK_CONTEXT = "/ibank/";
	private static final String ACTION_DEFAULT = "default";
	
	@Autowired
	private MBAppValidator mbAppValidator;
	
	@Autowired
	private MBAppHelper mbAppHelper;	
	
	@Autowired
	private RedirectToDesktopHelper redirectToDesktopHelper;
	
	@RequestMapping(value="redirectToDesktop", method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public IMBResp redirectToDesktop(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse)
	{
		
		Logger.debug("CPP : redirectToDesktop Start. ", this.getClass());
				
		MobileSession mbSession =  null;
		IMBResp serviceResponse = null;
		
		try {	
			
			mbSession = mbAppHelper.getMobileSession(httpServletRequest);
			
			String actionType = httpServletRequest.getParameter(REQ_ACTION_TYPE);
			
			// In case of actionType is null or invalid, it will be set to "default" redirecting to dashboard
			if(null == actionType || !isValidActionType(actionType)){
				Logger.warn("CPP : Action Type is null or contains nnvalid characters " + actionType,  this.getClass());
				actionType = ACTION_DEFAULT;
			}
			
			String url = getRedirectURL(actionType);
			
			if(actionType.equalsIgnoreCase("updateDetails") && IBankParams.isUpdateContactDetailsSwitchOn()) {
				
				url="showContactDetails.html";
				Logger.debug("Contact detail new  : redirectURL :: "+url, this.getClass());
			}
			
			//In case actionType is not present in release codes table, redirect to dashboard
			if(null == url)
				url = getRedirectURL(ACTION_DEFAULT);
			
			String redirectURL = createRedirectURL(httpServletRequest, url);
			
			Logger.debug("CPP : redirectURL :: "+redirectURL, this.getClass());
			
			serviceResponse = redirectToDesktopHelper.populateResponse(redirectURL);
			
			return serviceResponse;
						
		} catch (Exception e) {			
			Logger.error("CPP : Exception in redirectToDesktop :: ", e, this.getClass());
			BusinessException exp = new BusinessException(BusinessException.SYSTEM_UNAVILABLE);
			IMBResp errorResponse = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, ServiceConstants.CPP_TD_IB_MB_REDIRECT, httpServletRequest);
			return errorResponse;
			
		} finally {
			Logger.debug("CPP : redirectToDesktop End. ", this.getClass());
		}		
	}
	
	private String createRedirectURL(HttpServletRequest httpServletRequest, String url){		
		if(null == url)
			return null;	
		
		String redirectURL = httpServletRequest.getScheme().concat("://").concat(httpServletRequest.getHeader("Host")).concat(IBANK_CONTEXT).concat(url);				
		return redirectURL;
	}
	
	private boolean isValidActionType(String actionType){

		if(StringUtil.isValidData(actionType, BLOCK_CHARS))
			return true;
		 
		return false;
	}

	@Override
	public void validateRequestHeader(ReqHeader headerReq, HttpServletRequest request) throws BusinessException {
		mbAppValidator.validateRequestHeader(headerReq,  request);		
	}

	@Override
	public ErrorResp validate(IMBReq serviceRequest, HttpServletRequest httpRequest) throws BusinessException {
		return  mbAppValidator.validate(serviceRequest, httpRequest);
	}

	@Override
	public RespHeader populateResponseHeader(String serviceName, MobileSession mobileSession) {
		return mbAppHelper.populateResponseHeader(serviceName, mobileSession);
	}
		
	/**
	 * IBank relative URL to be fetched from ReleaseCodes table based on actionType
	 * @param actionType
	 * @return String - redirect URL
	 */
    public String getRedirectURL(String actionType){
    	
    	CodesVO codes = IBankParams.getCodesData(IBankParams.DEFAULT_ORIGIN, IBankParams.IB_MB_REDIRECT_CATEGORY, actionType);
    	
    	if(null != codes)
    		return codes.getMessage();
    	
    	return null;    	
    } 
}
