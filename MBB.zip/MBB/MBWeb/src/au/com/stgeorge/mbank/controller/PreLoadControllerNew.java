package au.com.stgeorge.mbank.controller;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.AbstractController;

import au.com.stgeorge.framework.common.logging.Logger;
import au.com.stgeorge.ibank.businessobject.SystemInformation;
import au.com.stgeorge.ibank.common.cache.IBankParams;
import au.com.stgeorge.ibank.common.cache.IBankRefershParams;
import au.com.stgeorge.ibank.common.cache.IBankRefreshParamsImpl;
import au.com.stgeorge.ibank.util.CommonBusinessUtil;
import au.com.stgeorge.ibank.util.ServiceHelper;
import au.com.stgeorge.ibank.valueobject.database.CodesVO;
import au.com.stgeorge.ibank.valueobject.database.OriginsVO;
import au.com.stgeorge.mbank.controller.customer.CookieLogonBean;
import au.com.stgeorge.mbank.controller.customer.LogonHelper;
import au.com.stgeorge.mbank.util.MBAppUtils;
import au.com.stgeorge.perflogger.PerformanceLogger;
import au.com.stgeorge.security.util.StringMethods;

public class PreLoadControllerNew extends AbstractController
{

	private static volatile int numberOfRequests = 0;
	public static final String REQ_ACTION_STR = "action";
	private static final String REQ_IGNORE_SEC_FLAG =  "SIMPLE-LOGON" ;
	private static final String REQ_PRELOAD = "PRELOAD";
	public static final String MAIN_VIEW = "Index";
	private static final String ERROR_VIEW = "404";
	public static final String REQ_LOAD_CORDOVA = "LoadCordova";

	public static final String NUM_KEYBOARD_TYPE = "NumKeyBoardType";
	public static final String NUM_KEYBOARD_PATTERN_TYPE = "NumKeyBoardTypePattern";
	
	public static final String SYS_VERSION = "SysVersion";
	
	public static final String ORIGIN_NAME = "OriginName";
	
	
	
	@Override
	protected ModelAndView handleRequestInternal(HttpServletRequest request, HttpServletResponse response) throws Exception
	{
		PerformanceLogger performanceLogger = new PerformanceLogger();
		performanceLogger.startAllLogs();
		String logName = MBAppUtils.getLogName(request);
		performanceLogger.startLog(logName);
		
		ModelAndView model = null;
		String origin = null;
		String numKeyType = null;
		String numKeyTypePattern = null;
		
		try
		{
			numberOfRequests ++;
			logonHelper.setWebReadyCookie(request, response , "0" );
			request.setAttribute(MainController.WEB_CONTEXT, logonHelper.getMBWebResourceContext());

			origin = LogonHelper.resolveOrigin(request);
			
			if ( StringMethods.isEmptyString(origin) )
			{
				origin = "MSTG";
				request.setAttribute(LogonHelper.ORIGIN, origin);
				Logger.info("Unable to resolve the origin  Request Details. URL : "+ request.getRequestURL() + " IP :" + request.getRemoteAddr() + " Number Of Requests : "+ numberOfRequests +
						" True IP >> " + request.getHeader(IBankParams.trueClientIP()), this.getClass());
				model = new ModelAndView(ERROR_VIEW);
			}
			else
			{
				request.setAttribute(LogonHelper.ORIGIN, origin);
				
				numKeyType =  logonHelper.getNumKeyBoardType(request);
				numKeyTypePattern =  logonHelper.getNumKeyBoardPattern(request);
				request.setAttribute(MainController.NUM_KEYBOARD_TYPE, numKeyType);
				request.setAttribute(MainController.NUM_KEYBOARD_PATTERN_TYPE, numKeyTypePattern);
				request.setAttribute(MainController.SYS_VERSION, systemInformation.getMB3PackageVersion());
				OriginsVO originVO = IBankParams.getOrigin(origin);
				request.setAttribute(MainController.ORIGIN_NAME, originVO.getName());
				String pwdResetUrl = IBankParams.getCodesData( IBankParams.DEFAULT_ORIGIN,IBankParams.EXTERNAL_LINKS, originVO.getBankName()+ MainController.PWD_RESET_URL).getMessage();
				request.setAttribute(MainController.PWD_RESET_URL, pwdResetUrl);
				request.setAttribute(MainController.HELP_DESK_NO, originVO.getPhone());
				request.setAttribute(MainController.PRELOAD_VALUE, 1);  // Init loading 
				Cookie appVersionCookie = CommonBusinessUtil.getCookie(request, IBankParams.APP_VER_COOKIE);
				
				String lpMessagingSwitch = "OFF";
				CodesVO codesVO = IBankParams.getCodesData(IBankParams.getBaseOriginCode(origin),	IBankParams.CONFIGURATION_PROPERTIES, IBankParams.LP_MESSAGING_SWITCH);
				if ( (codesVO == null) || codesVO != null  && "ON".equalsIgnoreCase(codesVO.getMessage())){
					lpMessagingSwitch = "ON";
				}
				request.setAttribute(MainController.LP_MESSAGING_SWITCH, lpMessagingSwitch);
				
				Boolean isLpOldAppVersion = !CommonBusinessUtil.cookieContainsValue(appVersionCookie, MainController.CHAT);
				if(isLpOldAppVersion) {
					request.setAttribute(MainController.LP_NATIVE_OLD_APP_SWITCH, IBankParams.ON);
				}else {
					request.setAttribute(MainController.LP_NATIVE_OLD_APP_SWITCH, IBankParams.OFF);
				}
				
				
				//20E3 UI Switch cleanup start
				/*String androidBackButtonSwitch="OFF";
				if(logonHelper.isAndroidBackBtnSupported(request)){
					androidBackButtonSwitch="ON";
				}
				request.setAttribute(MainController.ANDROID_BACK_BTN, androidBackButtonSwitch);*/
				//20E3 UI Switch cleanup end
				
				Logger.info(originVO.toXml() + " \nInside PreLoadController2 Request Details. URL : "+ request.getRequestURL() + " IP :" + request.getRemoteAddr() + " Number Of Requests : "+ numberOfRequests +
						" True IP >> " + request.getHeader(IBankParams.trueClientIP()), this.getClass());
				findPageToBeDsiaplyed(request, response);
				model = new ModelAndView(MAIN_VIEW);

			}
			return model;
		}
		catch ( Exception e)
		{
			origin = "MSTG";
			request.setAttribute(LogonHelper.ORIGIN, origin);
			model = new ModelAndView(ERROR_VIEW);
			Logger.error("Error in PreLoadController2 " , e, this.getClass());
			return model;
		}
		finally
		{
			IBankRefershParams iBankRefreshParams =  (IBankRefershParams)ServiceHelper.getBean("ibankRefreshParams");
			boolean logonSpeedSwitch = iBankRefreshParams.isNativeLogonSpeedSwitch(origin);
			String nativeSwitchVal = "false";
			if (logonSpeedSwitch) {
				nativeSwitchVal = "true";
			}
			request.setAttribute(IBankRefreshParamsImpl.NATIVE_LOGON_SPEED_SWITCH, nativeSwitchVal);
			numberOfRequests--;
			performanceLogger.endLog(logName);
			performanceLogger.endAllLogs();
		}
	}

	private void findPageToBeDsiaplyed(HttpServletRequest request, HttpServletResponse response)
	{
		request.setAttribute(REQ_ACTION_STR, REQ_PRELOAD);
		request.setAttribute(REQ_IGNORE_SEC_FLAG, IBankParams.NO);
		int loadCordova = logonHelper.loadCordova(request);
		request.setAttribute(REQ_LOAD_CORDOVA, String.valueOf(loadCordova));
		

	}

	

	@Autowired
	private LogonHelper logonHelper;
	
	@Autowired
	private SystemInformation systemInformation;
	

}