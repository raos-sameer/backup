package au.com.stgeorge.mbank.controller.services;

import java.math.BigDecimal;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

import au.com.stgeorge.framework.common.logging.Logger;
import au.com.stgeorge.framework.common.util.DateMethods;
import au.com.stgeorge.ibank.common.cache.IBankParams;
import au.com.stgeorge.ibank.servicestation.businessobject.valueobject.ServiceStationVO;
import au.com.stgeorge.ibank.servicestation.util.ServicetationConstants;
import au.com.stgeorge.ibank.valueobject.Account;
import au.com.stgeorge.ibank.valueobject.AccountId;
import au.com.stgeorge.ibank.valueobject.FinancialYearInterest;
import au.com.stgeorge.ibank.valueobject.database.CodesVO;
import au.com.stgeorge.mbank.model.common.RespHeader;
import au.com.stgeorge.mbank.model.response.services.FinancialYearInterestDatesResp;
import au.com.stgeorge.mbank.model.response.services.FinancialYearInterestResp;
import au.com.stgeorge.mbank.model.response.services.FinancialYearInterestSummaryResp;
import au.com.stgeorge.mbank.model.response.servicestation.ServiceStationResp;
import au.com.stgeorge.mbank.util.MBAppHelper;
import au.com.stgeorge.security.util.StringMethods;

/**
 * Financial interest service helper
 * 
 * @author C38854
 * 
 */
@Service
public class FinancialYearInterestHelper {

	/**
	 * Populate summary response
	 * 
	 * @param populateResponseHeader
	 * @param finInterest
	 * @param customerAccounts
	 * @return
	 */
	protected FinancialYearInterestSummaryResp populateSummaryResponse(RespHeader header, List<FinancialYearInterest> finInterest,List<Account> customerAccounts) 
	{
		return populateSummaryResponse(header,finInterest,customerAccounts,null);
	}
	
	protected FinancialYearInterestSummaryResp populateSummaryResponse(RespHeader header, List<FinancialYearInterest> finInterest,List<Account> customerAccounts, ServiceStationVO serviceStationVO){
		FinancialYearInterestSummaryResp response = new FinancialYearInterestSummaryResp(header);
		ServiceStationResp resp=null;
		response.setAccountList(new ArrayList<FinancialYearInterestResp>());

		BigDecimal totalInterestChargedThisYear = new BigDecimal(0);
		BigDecimal totalInterestEarnedThisYear = new BigDecimal(0);
		BigDecimal totalInterestChargedLastYear = new BigDecimal(0);
		BigDecimal totalInterestEarnedLastYear = new BigDecimal(0);

		if (finInterest != null) {
			FinancialYearInterest finInterestVO;
			for (int i = 0; i < finInterest.size(); i++) {
				finInterestVO = (FinancialYearInterest) finInterest.get(i);

				if (finInterestVO.getInterestChargedLastYear() == null)
					finInterestVO.setInterestChargedLastYear(new BigDecimal(0));
				if (finInterestVO.getInterestChargedThisYear() == null)
					finInterestVO.setInterestChargedThisYear(new BigDecimal(0));
				if (finInterestVO.getInterestEarnedLastYear() == null)
					finInterestVO.setInterestEarnedLastYear(new BigDecimal(0));
				if (finInterestVO.getInterestEarnedThisYear() == null)
					finInterestVO.setInterestEarnedThisYear(new BigDecimal(0));

				// To get an account name for each account
				AccountId accountId = new AccountId();
				accountId.setApplicationId(finInterestVO.getApplicationId());
				accountId.setAccountNumber(finInterestVO.getAccountNumber());
				Account account = MBAppHelper.getAccountbyAccountId(accountId, customerAccounts);
				if (account != null && StringMethods.isValidString(account.getAlias())) {
					finInterestVO.setAccountName(account.getAlias());
				}
				if (account != null) {
					String formattedAcctNum = new MBAppHelper().getFormattedAcctNumber(account.getAccountId().getAccountNumber(), account
							.getAccountId().getApplicationId(), account.getAccountId().getBsb());
					finInterestVO.setAccountNumber(formattedAcctNum);
				} else {
					finInterestVO.setAccountNumber(accountId.getFormattedAccountNumber());
				}

				FinancialYearInterestResp financialYearInterestResp = new FinancialYearInterestResp();
				financialYearInterestResp.setAccountName(finInterestVO.getAccountName());
				financialYearInterestResp.setAccountNumDisp(finInterestVO.getAccountNumber());
				financialYearInterestResp.setIntChargedCurrent(finInterestVO.getInterestChargedThisYear().setScale(2).toPlainString());
				financialYearInterestResp.setIntChargedPrevious(finInterestVO.getInterestChargedLastYear().setScale(2).toPlainString());
				financialYearInterestResp.setIntEarnedCurrent(finInterestVO.getInterestEarnedThisYear().setScale(2).toPlainString());
				financialYearInterestResp.setIntEarnedPrevious(finInterestVO.getInterestEarnedLastYear().setScale(2).toPlainString());

				response.getAccountList().add(financialYearInterestResp);

				totalInterestChargedThisYear = totalInterestChargedThisYear.add(finInterestVO.getInterestChargedThisYear());
				totalInterestEarnedThisYear = totalInterestEarnedThisYear.add(finInterestVO.getInterestEarnedThisYear());
				totalInterestChargedLastYear = totalInterestChargedLastYear.add(finInterestVO.getInterestChargedLastYear());
				totalInterestEarnedLastYear = totalInterestEarnedLastYear.add(finInterestVO.getInterestEarnedLastYear());

			}
		}

		response.setIntChargedTotalCurrent(totalInterestChargedThisYear.setScale(2).toPlainString());
		response.setIntChargedTotalPrevious(totalInterestChargedLastYear.setScale(2).toPlainString());
		response.setIntEarnedTotalCurrent(totalInterestEarnedThisYear.setScale(2).toPlainString());
		response.setIntEarnedTotalPrevious(totalInterestEarnedLastYear.setScale(2).toPlainString());

		int currentYear = DateMethods.getCurrentYear();
		int currentMonth = DateMethods.getCurrentMonth();

		// If the current month is either July or after that then it is a next financial year.
		if (currentMonth >= 7) {
			currentYear = currentYear + 1;
		}
		int lastYear = currentYear - 1;
		int secondLastYear = currentYear - 2;

		response.setPreviousYear(new FinancialYearInterestDatesResp());
		response.setCurrentYear(new FinancialYearInterestDatesResp());

		SimpleDateFormat format = new SimpleDateFormat("dd/MM/yyyy");
		try {
			response.getPreviousYear().setFromDate(format.parse("01/07/" + secondLastYear));
		} catch (ParseException e) {
			Logger.error("Error parsing FYI date", this.getClass());
		}
		try {
			response.getPreviousYear().setToDate(format.parse("30/06/" + lastYear));
		} catch (ParseException e) {
			Logger.error("Error parsing FYI date", this.getClass());
		}
		try {
			response.getCurrentYear().setFromDate(format.parse("01/07/" + lastYear));
		} catch (ParseException e) {
			Logger.error("Error parsing FYI date", this.getClass());
		}
		
		if(null!=serviceStationVO)
		{
			resp=populateServiceStationResp(serviceStationVO);
			if(null!=resp)
			{
				response.setServiceStation(resp);
			}
		}
		Logger.info("### FinInterest" + response, this.getClass());
		return response;
	}
	
	public long getInsertionPointCode(String insertionPointString){
		List<CodesVO> CodesVOList = (List<CodesVO>) IBankParams.getCodesDataList(IBankParams.DEFAULT_ORIGIN, ServicetationConstants.CD_CATEGORY_SERVICETATION_INSERTION_PT);
		long insertionPointValue = 0;
		for(CodesVO codesVO : CodesVOList){
			if(codesVO.getMessage().trim().equalsIgnoreCase(insertionPointString)){
				if(StringMethods.isValidString(codesVO.getCode())){
					insertionPointValue = Long.parseLong(codesVO.getCode());
					break;
				}
			}
		}
		if(insertionPointValue == 0){
			Logger.warn("NO match found in RELEASECODES table for the insertion point "+insertionPointString, this.getClass());
		}
		return insertionPointValue;
	}
	
	public  ServiceStationResp populateServiceStationResp(ServiceStationVO serviceStationVO){
		ServiceStationResp resp = null;		
		
		if(null!=serviceStationVO)
		{
			resp=new ServiceStationResp();
			if(null!=serviceStationVO.getContent())
			{
			   resp.setContent(serviceStationVO.getContent());
			}			
			if(null!=serviceStationVO.getServiceStationMsg())
			{
				resp.setInsertionPointValue(new Long(serviceStationVO.getServiceStationMsg().getInsertionPointValue()).toString());	
			}
			if(null!=serviceStationVO.getSubject())
			{
			   resp.setSubject(serviceStationVO.getSubject());
			}
			if(null!=serviceStationVO.getServiceStationMsg().getFunctionLink())
			{
			   resp.setFunctionLink(serviceStationVO.getServiceStationMsg().getFunctionLink());
			}
			if(null!=serviceStationVO.getServiceStationMsg().getMessageAction())
			{
			   resp.setMessageAction(serviceStationVO.getServiceStationMsg().getMessageAction());
			}
			if(null!=serviceStationVO.getServiceStationMsg())
			{
				resp.setMsgID(new Long(serviceStationVO.getServiceStationMsg().getMsgID()).toString());	
			}
		}		
		return resp;
	}

}
