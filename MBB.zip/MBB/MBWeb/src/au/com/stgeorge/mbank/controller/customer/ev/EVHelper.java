package au.com.stgeorge.mbank.controller.customer.ev;
import static au.com.stgeorge.ibank.common.cache.IBankParams.DEFAULT_ORIGIN;
import static au.com.stgeorge.ibank.common.cache.IBankParams.getCodesData;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Service;

import au.com.stgeorge.framework.common.logging.Logger;
import au.com.stgeorge.framework.common.util.StringMethods;
import au.com.stgeorge.ibank.businessobject.BusinessException;
import au.com.stgeorge.ibank.common.cache.IBankParams;
import au.com.stgeorge.ibank.common.log.IBankLog;
import au.com.stgeorge.ibank.evcrs.businessobject.valueobject.EVCRSDetail;
import au.com.stgeorge.ibank.evcrs.businessobject.valueobject.EVCountryDetailVO;
import au.com.stgeorge.ibank.evcrs.businessobject.valueobject.EVCustDetails;
import au.com.stgeorge.ibank.evcrs.businessobject.valueobject.EVForeignCountryDetail;
import au.com.stgeorge.ibank.evcrs.businessobject.valueobject.ReIDVInfoVO;
import au.com.stgeorge.ibank.evcrs.util.EVConstants;
import au.com.stgeorge.ibank.service.businessobject.TokenService;
import au.com.stgeorge.ibank.util.ServiceHelper;
import au.com.stgeorge.ibank.valueobject.database.CodesVO;
import au.com.stgeorge.ibank.valueobject.transfer.IBankCommonData;
import au.com.stgeorge.mbank.model.common.AddressResp;
import au.com.stgeorge.mbank.model.common.ErrorInfo;
import au.com.stgeorge.mbank.model.common.IMBResp;
import au.com.stgeorge.mbank.model.request.customer.ev.EVReq;
import au.com.stgeorge.mbank.model.request.customer.ev.ReIDVReq;
import au.com.stgeorge.mbank.model.request.customer.ev.TaxResidency;
import au.com.stgeorge.mbank.model.response.ErrorResp;
import au.com.stgeorge.mbank.model.response.customer.ev.CustInfo;
import au.com.stgeorge.mbank.model.response.customer.ev.EVCountryDetail;
import au.com.stgeorge.mbank.model.response.customer.ev.EVErrorResp;
import au.com.stgeorge.mbank.model.response.customer.ev.EVMainResponse;
import au.com.stgeorge.mbank.model.response.customer.ev.EVResp;
import au.com.stgeorge.mbank.model.response.customer.ev.ReIDVResp;
import au.com.stgeorge.mbank.model.response.customer.ev.VerifyEVResp;
import au.com.stgeorge.mbank.session.MobileSession;
import au.com.stgeorge.mbank.util.MBAppHelper;
import au.com.stgeorge.mbank.util.MBAppUtils;
import au.com.stgeorge.mbank.controller.customer.ev.CRSHelper;
@Service
public class EVHelper 
{
	public IMBResp populateResponse(EVCRSDetail evCRSDetail,MobileSession mbSession,List<EVForeignCountryDetail> evForeignCountryDtls,IBankCommonData ibankCommonData) throws BusinessException
	{
		EVResp evResp = null;
		CRSHelper crsHelper=new CRSHelper();
		int currentYear=getCurrentYear();
		
		if(null!=evCRSDetail)
		{
			evResp=new EVResp();
			evResp.setCrsInfo(crsHelper.populateCRSInfo(evForeignCountryDtls));
			evResp.setShowCRSInfo(!(evCRSDetail.isCrsInfoProvided()));
			evResp.setCountries(getCountryList());
			evResp.setPassportCountryOfIssue(getPassportCountryList());
			evResp.setMedicarePositionList(getMedicarePosNumList());
			evResp.setMedicareMonthList(getMonthList());
			evResp.setMedicareYearList(getMedicareValidToYearList(currentYear));
			evResp.setStates(getStateList());
			evResp.setCustResidentialAddr(populateCustResidentialAddress(mbSession));
			evResp=(EVResp)populateThreatMatrixInfo(evResp,mbSession,ibankCommonData);			
		}
		return evResp;
	}
	public IMBResp populateReIDVResponse(EVCRSDetail evCRSDetail,MobileSession mbSession,List<EVForeignCountryDetail> evForeignCountryDtls, boolean reIdvCompleted, IBankCommonData ibankCommonData) throws BusinessException
	{
		ReIDVResp reIDVResp = null;
		int currentYear=getCurrentYear();
		CRSHelper crsHelper=new CRSHelper();
		if(null!=evCRSDetail)
		{
			reIDVResp=new ReIDVResp();
			reIDVResp.setCrsInfo(crsHelper.populateCRSInfo(evForeignCountryDtls));
			reIDVResp.setCustInfoResp(getReIDVInfo(mbSession));
			reIDVResp.setCountries(getCountryList());
			reIDVResp.setPassportCountryOfIssue(getPassportCountryList());
			reIDVResp.setMedicarePositionList(getMedicarePosNumList());
			reIDVResp.setMedicareMonthList(getMonthList());
			reIDVResp.setMedicareYearList(getMedicareValidToYearList(currentYear));
			reIDVResp.setStates(getStateList());
			reIDVResp.setCustResidentialAddr(populateCustResidentialAddress(mbSession));			
			reIDVResp=(ReIDVResp) populateThreatMatrixInfo(reIDVResp,mbSession, ibankCommonData);			
			reIDVResp.setReIdvCompleted(reIdvCompleted);			
		}
		return reIDVResp;
	}
	
	public IMBResp populateReIDVDoneResponse(boolean reIdvCompleted)
	{
		ReIDVResp reIDVResp = new ReIDVResp();
		reIDVResp.setReIdvCompleted(reIdvCompleted);
		return reIDVResp;
	}
	
	public AddressResp populateCustResidentialAddress(MobileSession mbsession){
		AddressResp addrResponse=null;
		if(null!=mbsession && null!=mbsession.getCustomer().getContactDetail().getResidentialAddress()){
			addrResponse=new AddressResp();
			addrResponse.setAddrType("RES");
			if(null!=mbsession.getCustomer().getContactDetail().getResidentialAddress().getLine1()){
				addrResponse.setLine1(mbsession.getCustomer().getContactDetail().getResidentialAddress().getLine1());	
			}
			if(null!=mbsession.getCustomer().getContactDetail().getResidentialAddress().getLine2()){
				addrResponse.setLine2(mbsession.getCustomer().getContactDetail().getResidentialAddress().getLine2());
			}
			if(null!=mbsession.getCustomer().getContactDetail().getResidentialAddress().getLine3()){
				addrResponse.setLine3(mbsession.getCustomer().getContactDetail().getResidentialAddress().getLine3());	
			}
			if(null!=mbsession.getCustomer().getContactDetail().getResidentialAddress().getSuburb()){
				addrResponse.setSuburb(mbsession.getCustomer().getContactDetail().getResidentialAddress().getSuburb());	
			}
			if(null!=mbsession.getCustomer().getContactDetail().getResidentialAddress().getState()){
				addrResponse.setState(mbsession.getCustomer().getContactDetail().getResidentialAddress().getState());	
			}
			if(null!=mbsession.getCustomer().getContactDetail().getResidentialAddress().getPostZipcode()){
				addrResponse.setPostCode(mbsession.getCustomer().getContactDetail().getResidentialAddress().getPostZipcode());	
			}
			if(null!=mbsession.getCustomer().getContactDetail().getResidentialAddress().getCountryName()){
				addrResponse.setCountryName(mbsession.getCustomer().getContactDetail().getResidentialAddress().getCountryName());	
			}			
		}
		return addrResponse;
	}
	
	public  List<EVCountryDetail> getForeignCountriesAndTINRegex(List<EVForeignCountryDetail> evForeignCountryDetails){				
		List<EVCountryDetail> evFrnDtls=new ArrayList<EVCountryDetail>();		
		for(EVForeignCountryDetail evFr:evForeignCountryDetails){
			EVCountryDetail evForeignCntDtls=new EVCountryDetail();
			evForeignCntDtls.setCountryCode(evFr.getCountryCode());
			evForeignCntDtls.setTinRegex(evFr.getTinRegex());
			evForeignCntDtls.setTinRegexException(evFr.getTinRegexException());
			evForeignCntDtls.setCountryHelpText(evFr.getCountryHelpText());
			evForeignCntDtls.setIsTINApplicable(!evFr.isNoTin());
			evForeignCntDtls.setIsTINMandatory(evFr.isTINMandatory());								
			evFrnDtls.add(evForeignCntDtls);
		}
		return evFrnDtls;
	}
	
	public  CustInfo getReIDVInfo(MobileSession mbSession){				
		CustInfo custInfo=new CustInfo();
		custInfo.setSourceOfWealth(getSourceOfWealthList());
		custInfo.setSourceOfFunds(getSourceOfFundList());
		custInfo.setProducts(getCustReasonForProductList());
		custInfo.setOccupation(getCustOccupationList());
		custInfo.setEmpType(getCustEmployeeCodeList());	
		return custInfo;
	}
	
	protected void validateEVReq(EVReq request,List<EVForeignCountryDetail> evForeignCountryDtls) throws BusinessException 
	{
		Calendar now = Calendar.getInstance();
		int currYear=now.get(Calendar.YEAR);
		int currMonth=now.get(Calendar.MONTH) + 1;
		int currDate=now.get(Calendar.DATE);
		int birthDate=0;
		int birthMonth=0;
		int birthYear=0;
		
		int birthCertPrintDate=0;
		int birthCertPrintMonth=0;
		int birthCertPrintYear=0;
		
		CRSHelper crsHelper=new CRSHelper();
		
		if(request.getCrsInfo() != null)
			crsHelper.validateCRSData(request.getCrsInfo(),evForeignCountryDtls);

		if (request.getEvInfo().isAusBirthCertificate()==false && request.getEvInfo().isDriversLicence()==false && request.getEvInfo().isMedicareCard()==false && request.getEvInfo().isPassport()==false && request.getEvInfo().isNswPhotoCard()==false){
		 throw new BusinessException(BusinessException.EV_ID_REQUIRED);
		}
		if(request.getEvInfo().isDriversLicence()==true){
			if(request.getEvInfo().getDlStateOfIssue()==null){
				throw new BusinessException(BusinessException.DLSTATE_OF_ISSUE_REQUIRED);
			}
			if(request.getEvInfo().getDlicenceNum()==null){
				throw new BusinessException(BusinessException.DL_NUMBER_REQUIRED);
			}
			if(null!=request.getEvInfo().getDlicenceNum()){
				if(!checkSpecialCharacters(request.getEvInfo().getDlicenceNum())){
					throw new BusinessException(BusinessException.SPECIAL_CHARACTERS_IN_DLNUMBER);
				}
				if(request.getEvInfo().getDlicenceNum().length()<4 || request.getEvInfo().getDlicenceNum().length()>9){
					throw new BusinessException(BusinessException.INVALID_DL_LENGTH);
				}			
			}
		}		
		if(request.getEvInfo().isMedicareCard()==true){
			if(request.getEvInfo().getMedicareNum()==null){
				throw new BusinessException(BusinessException.MEDICARE_NUMBER_REQUIRED);
			}
			if(request.getEvInfo().getMedicarePosNum()==null){
				throw new BusinessException(BusinessException.MEDICARE_POSITION_NUMBER_REQUIRED);
			}
			if(request.getEvInfo().getMedicareValidToMon()==null){
				throw new BusinessException(BusinessException.MEDICARE_VALID_TO_MONTH_REQUIRED);
			}
			if(request.getEvInfo().getMedicareValidToYear()==null){
				throw new BusinessException(BusinessException.MEDICARE_VALID_TO_YEAR_REQUIRED);
			}
			if(null!=request.getEvInfo().getMedicareNum() && !request.getEvInfo().getMedicareNum().matches("[0-9]+")){                           // medicare number should only be number
				throw new BusinessException(BusinessException.CHARACTERS_IN_MEDICARE_NUMBER);
			}
			if(null!=request.getEvInfo().getMedicareMiddleInitial() && !checkCharacters(request.getEvInfo().getMedicareMiddleInitial())){        // medicare middle ini should only be letter
				throw new BusinessException(BusinessException.SPECIAL_CHARACTERS_IN_MEDICARE_MIDDLE_INITIAL);
			}
			if(null!=request.getEvInfo().getMedicareValidToYear() && Integer.parseInt(request.getEvInfo().getMedicareValidToYear())<currYear){    // valid to year should not be less than current year.
				throw new BusinessException(BusinessException.INVALID_MEDICARE_VALID_TO_YEAR);
			}
			if(null!=request.getEvInfo().getMedicareValidToMon() && null!=request.getEvInfo().getMedicareValidToYear() && Integer.parseInt(request.getEvInfo().getMedicareValidToYear())== currYear && Integer.parseInt(request.getEvInfo().getMedicareValidToMon())<currMonth){    // valid to month should not be less than current month.
				throw new BusinessException(BusinessException.INVALID_MEDICARE_VALID_TO_MONTH);
			}
		}
		
		if(request.getEvInfo().isPassport()==true){
			if(request.getEvInfo().getPassportCountryOfIssue()==null){
				throw new BusinessException(BusinessException.PASSPORT_COUNTRY_OF_ISSUE_REQUIRED);
			}
			if(request.getEvInfo().getPassportNum()==null){
				throw new BusinessException(BusinessException.PASSPORT_NUMBER_REQUIRED);
			}
			if(null!=request.getEvInfo().getPassportNum())
			{
				if(request.getEvInfo().getPassportNum().length()<8 || request.getEvInfo().getPassportNum().length()>12){
					throw new BusinessException(BusinessException.INVALID_PASSPORT_NUMBER_LENGTH);
				}
				if(!(checkCharactersAndNumbers(request.getEvInfo().getPassportNum()))){                //Passport number should be alpha numeric
					throw new BusinessException(BusinessException.SPECIAL_CHARACTERS_IN_PASSPORT_NUMBER);
				}
			}
		}
		
		if(request.getEvInfo().isAusBirthCertificate()==true){
			
			if(null!=request.getEvInfo().getBirthCertRegDate())
			{
				String comDT=request.getEvInfo().getBirthCertRegDate();
				birthDate=Integer.parseInt(comDT.substring(8));
				birthMonth=Integer.parseInt(comDT.substring(5,7));
				birthYear=Integer.parseInt(comDT.substring(0,4));
			}
			
			if(request.getEvInfo().getBirthCertRegNum()==null){
				throw new BusinessException(BusinessException.BIRTH_CERTIFICATE_REG_NUMBER_REQUIRED);
			}
			if(request.getEvInfo().getBirthCertStateOfIssue()==null){
				throw new BusinessException(BusinessException.BIRTH_CERTIFICATE_STATE_OF_ISSUE_REQUIRED);
			}
			if(request.getEvInfo().getBirthCertRegDate()==null){
				throw new BusinessException(BusinessException.BIRTH_CERTIFICATE_REG_YEAR_REQUIRED);
			}
			
			if(null!=request.getEvInfo().getBirthCertRegDate()){
				
				if(!checkSpecialCharInDate(request.getEvInfo().getBirthCertRegDate())){
					throw new BusinessException(BusinessException.INVALID_BIRTH_REG_DATE);
				}
				
				String comDT=request.getEvInfo().getBirthCertRegDate();
				birthDate=Integer.parseInt(comDT.substring(8));
				birthMonth=Integer.parseInt(comDT.substring(5,7));
				birthYear=Integer.parseInt(comDT.substring(0,4));
				
				if(request.getEvInfo().getBirthCertRegNum().length()>25){
					throw new BusinessException(BusinessException.INVALID_BIRTH_REG_NUMBER_LENGTH);
				}
				
				if(birthYear>currYear){
					throw new BusinessException(BusinessException.INVALID_BIRTH_REG_DATE);
				}
				else{
					if(birthYear==currYear && birthMonth>currMonth){
						throw new BusinessException(BusinessException.INVALID_BIRTH_REG_DATE);
					}
					else{
						if(birthMonth==currMonth && birthDate>currDate){
							throw new BusinessException(BusinessException.INVALID_BIRTH_REG_DATE);
						}
					}				
				}				
			}
			if(null!=request.getEvInfo().getBirthCertStateOfIssue()){
				if(request.getEvInfo().getBirthCertStateOfIssue().equalsIgnoreCase("SA") || request.getEvInfo().getBirthCertStateOfIssue().equalsIgnoreCase("ACT") || request.getEvInfo().getBirthCertStateOfIssue().equalsIgnoreCase("NT")){
					if(request.getEvInfo().getBirthCertDateOfPrint()==null){
						throw new BusinessException(BusinessException.BIRTH_CERT_PRINT_DATE_REQUIRED);
					}
					
					if(request.getEvInfo().getBirthCertificateNumber()==null){
						throw new BusinessException(BusinessException.BIRTH_CERT_NUMBER_REQUIRED);
					}
				}
				
			}
			
			if(null!=request.getEvInfo().getBirthCertificateNumber() && request.getEvInfo().getBirthCertificateNumber().length()>25){
				throw new BusinessException(BusinessException.INVALID_LENGTH_BIRTH_CERT_NUMBER);
			}
			if(null!=request.getEvInfo().getBirthCertificateNumber() && !checkNumbers(request.getEvInfo().getBirthCertificateNumber())){
				throw new BusinessException(BusinessException.INVALID_LENGTH_BIRTH_CERT_NUMBER);
			}
			// Validating the Birth Certificate Print date 
			if(null!=request.getEvInfo().getBirthCertDateOfPrint()){
				
				if(!checkSpecialCharInDate(request.getEvInfo().getBirthCertDateOfPrint())){
					throw new BusinessException(BusinessException.INVALID_BIRTH_CERT_PRINT_DATE);
				}				
				String comDT=request.getEvInfo().getBirthCertDateOfPrint();
				birthCertPrintDate=Integer.parseInt(comDT.substring(8));
				birthCertPrintMonth=Integer.parseInt(comDT.substring(5,7));
				birthCertPrintYear=Integer.parseInt(comDT.substring(0,4));
				
				if(birthCertPrintYear>currYear){
					throw new BusinessException(BusinessException.INVALID_BIRTH_CERT_PRINT_DATE);
				}
				else{
					if(birthCertPrintYear==currYear && birthCertPrintMonth>currMonth){
						throw new BusinessException(BusinessException.INVALID_BIRTH_CERT_PRINT_DATE);
					}
					else{
						if(birthCertPrintMonth==currMonth && birthCertPrintDate>currDate){
							throw new BusinessException(BusinessException.INVALID_BIRTH_CERT_PRINT_DATE);
						}
					}					
				}
			}
		}
		
		if(request.getEvInfo().isNswPhotoCard()==true){
			if(request.getEvInfo().getPhotoCardNum()==null){
				throw new BusinessException(BusinessException.NSW_PHOTO_CARD_NUMBER_REQUIRED);	
			}
			if(request.getEvInfo().getPhotoCardPCNum()==null){
				throw new BusinessException(BusinessException.NSW_PHOTO_CARD_PC_NUMBER_REQUIRED);	
			}
			if(null!=request.getEvInfo().getPhotoCardNum() && request.getEvInfo().getPhotoCardNum().length()!=10){
				throw new BusinessException(BusinessException.INVALID_PHOTO_CARD_NUMBER_LENGTH);	
			}
			if(null!=request.getEvInfo().getPhotoCardPCNum()){
				if(request.getEvInfo().getPhotoCardPCNum().length()<6 || request.getEvInfo().getPhotoCardPCNum().length()>10){
					throw new BusinessException(BusinessException.INVALID_PHOTO_CARD_PC_NUMBER_LENGTH);	
				}				
			}
		}
	}
	
	public static au.com.stgeorge.ibank.evcrs.businessobject.valueobject.CustInfo populateCustInfo(ReIDVReq request) throws BusinessException
	{
		au.com.stgeorge.ibank.evcrs.businessobject.valueobject.CustInfo custInfo=new au.com.stgeorge.ibank.evcrs.businessobject.valueobject.CustInfo();
		if(null!=request.getReIDVInfo().getOtherName()){
			String otherName=request.getReIDVInfo().getOtherName();
			custInfo.setOtherName(otherName);
		}
		custInfo.setEmpTypeCode(request.getReIDVInfo().getEmpType());
		custInfo.setOccupationCode(request.getReIDVInfo().getOccupation());
		custInfo.setPobr(request.getReIDVInfo().getProducts());
		custInfo.setSourceOfFunds(request.getReIDVInfo().getSourceOfFunds());
		custInfo.setSourceOfWealth(request.getReIDVInfo().getSourceOfWealth());	    
	    return custInfo;
	}
	
	protected void validateReIDVReq(ReIDVReq request,List<EVForeignCountryDetail> evForeignCountryDtls) throws BusinessException 
	{
		EVReq evReq=new EVReq();
		evReq.setCrsInfo(request.getCrsInfo());
		evReq.setEvInfo(request.getEvInfo());
		String otherName=request.getReIDVInfo().getOtherName();
	    List<String> sourceOfWealth=request.getReIDVInfo().getSourceOfWealth();
	    List<String> sourceOfFund=request.getReIDVInfo().getSourceOfFunds();
	    List<String> products=request.getReIDVInfo().getProducts();
	    String occupation=request.getReIDVInfo().getOccupation();
	    String empType=request.getReIDVInfo().getEmpType();
	    if(sourceOfWealth==null || sourceOfWealth.size()==0)
	    {
	    	throw new BusinessException(BusinessException.SOURCE_OF_WEALTH_REQUIRED);
	    }
	    if(null!=sourceOfWealth || sourceOfWealth.size()>0)
	    {
	    	for (String str:sourceOfWealth)
	    	{
	    		if(checkSpecialCharactersGeneric(str))
	    		{
	    			throw new BusinessException(BusinessException.SPECIAL_CHARACTER_PRESENT);
	    		}
	    	}
	    }
	    if(sourceOfFund==null || sourceOfFund.size()==0)
	    {
	    	throw new BusinessException(BusinessException.SOURCE_OF_FUND_REQUIRED);
	    }
	    if(null!=sourceOfFund || sourceOfFund.size()>0)
	    {
	    	for (String str1:sourceOfFund)
	    	{
	    		if(checkSpecialCharactersGeneric(str1))
	    		{
	    			throw new BusinessException(BusinessException.SPECIAL_CHARACTER_PRESENT);
	    		}
	    	}
	    }
	    if(products==null || products.size()==0)
	    {
	    	throw new BusinessException(BusinessException.PRODUCT_REQUIRED);
	    }
	    if(null!=products || products.size()>0)
	    {
	    	for (String str2:products)
	    	{
	    		if(checkSpecialCharactersGeneric(str2))
	    		{
	    			throw new BusinessException(BusinessException.SPECIAL_CHARACTER_PRESENT);
	    		}
	    	}
	    }
	    if(occupation==null)
	    {
	    	throw new BusinessException(BusinessException.OCCUPATION_CODE_REQUIRED);
	    }
	    if(null!=occupation && checkSpecialCharactersGeneric(occupation))
	    {
	    	throw new BusinessException(BusinessException.SPECIAL_CHARACTER_PRESENT);
	    }
	    if(empType==null)
	    {
	    	throw new BusinessException(BusinessException.EMPLOYEE_CODE_REQUIRED);
	    }
	    if(null!=empType && checkSpecialCharactersGeneric(empType))
	    {
	    	throw new BusinessException(BusinessException.SPECIAL_CHARACTER_PRESENT);
	    }
	    if(null!=otherName && checkSpecialCharactersGeneric(otherName))
	    {
	    	throw new BusinessException(BusinessException.SPECIAL_CHARACTER_IN_OTHER_NAME); //SPECIAL_CHARACTER_PRESENT
	    }
	    
	    validateEVReq(evReq,evForeignCountryDtls);
	}
    public int getDupCount(ArrayList<String> countryList)
    {
        int cnt = 0;
        HashSet<String> h = new HashSet<String>(countryList);
        for (String token : h)
        {
            if (Collections.frequency(countryList, token) > 1)
                cnt++;
        }         
        return cnt;
    }
	protected void validateTINandRegex(String foreignTIN,EVForeignCountryDetail evFrnDtls) throws BusinessException
	{
		boolean isValidTIN=false;
		if(null!=foreignTIN && checkSpecialCharactersGeneric(foreignTIN))
		{
			throw new BusinessException(BusinessException.INVALID_FOREIGN_TIN);
		}
		else
		{
			isValidTIN=true;
		}
		if(null!=foreignTIN && checkForeignTIN(foreignTIN))
		{
			throw new BusinessException(BusinessException.INVALID_FOREIGN_TIN);
		}
		else
		{
			isValidTIN=true;
		}
		
		if(null!=evFrnDtls.getTinRegex())
		{						
		   for(String str: evFrnDtls.getTinRegex())
			 {				
			    if(foreignTIN.matches(str))
				{
				   isValidTIN=true;
				   break;
				}
				if(!foreignTIN.matches(str))
				{
					if(null!=evFrnDtls.getTinRegexException() && !foreignTIN.matches(evFrnDtls.getTinRegexException()))
					{
				       isValidTIN=false;
					}
					else if(null!=evFrnDtls.getTinRegexException() && foreignTIN.matches(evFrnDtls.getTinRegexException()))
					{
						isValidTIN=true;
						break;
					}
					else
					{
						isValidTIN=false;
					}
				}				
			 }
		}
	   if(evFrnDtls.getTinRegex()==null && null!=evFrnDtls.getTinRegexException())
		{
			if(!foreignTIN.matches(evFrnDtls.getTinRegexException()))
			{
				isValidTIN=false;

			}
			else
			{
		       isValidTIN=true;
			}
		
		}
	
		if(!isValidTIN)
		{
			throw new BusinessException(BusinessException.INVALID_FOREIGN_TIN);
		}
	}
	
	protected void validateTINandRegexCountryNotInJSON(String foreignTIN, boolean foreignTINProvided, String reason) throws BusinessException{
		
		if(foreignTINProvided && foreignTIN==null)
		{
			 throw new BusinessException(BusinessException.FOREIGN_TIN_REQUIRED);
		}
		
		if(!foreignTINProvided && reason==null)
		{
			 throw new BusinessException(BusinessException.NO_FOREIGN_TIN_CODE_REQUIRED);
		}
		
		if(null!=foreignTIN && checkSpecialCharactersGeneric(foreignTIN))
		{
			throw new BusinessException(BusinessException.SPECIAL_CHARACTERS_IN_FOREIGN_TIN);
		}
		if(null!=foreignTIN && checkForeignTIN(foreignTIN))
		{
		   throw new BusinessException(BusinessException.INVALID_FOREIGN_TIN);
		}
	}
	
	public boolean  checkSpecialCharacters(String value){
		boolean result=false;
		String REGEX = "[a-zA-Z0-9.-]*";
		Pattern pattern = Pattern.compile(REGEX);
		Matcher matcher = pattern.matcher(value);
		if (matcher.matches()){
		  result=true;
		}
		else{
			result=false;
		}
		return result;
	}
	
	public boolean  checkCharacters(String value){
		boolean result=false;
		String REGEX = "[a-zA-Z]*";
		Pattern pattern = Pattern.compile(REGEX);
		Matcher matcher = pattern.matcher(value);
		if (matcher.matches()){
		  result=true;
		}
		else{
			result=false;
		}
		return result;
	}
	public boolean  checkSpecialCharactersGeneric(String value){
		boolean result=false;
		String REGEX = "\\$:%?>=}|@#!`";
		Pattern pattern = Pattern.compile(REGEX);
		Matcher matcher = pattern.matcher(value);
		if (matcher.matches()){
		  result=true;
		}
		else{
			result=false;
		}
		return result;
	}
	
	public boolean  checkForeignTIN(String value){
		boolean result=false;
		value=value.trim();		
		if(value.equalsIgnoreCase("N/A") || value.equalsIgnoreCase("NA") || value.equalsIgnoreCase("Not Applicable") || value.equalsIgnoreCase("Not available") || value.equalsIgnoreCase("TBC")){
			result=true;
		}
		else{
			result=false;
		}
		return result;
	}
	
	public boolean  checkNumbers(String value){
		boolean result=false;
		String REGEX = "[0-9]*";
		Pattern pattern = Pattern.compile(REGEX);
		Matcher matcher = pattern.matcher(value);
		if (matcher.matches()){
		  result=true;
		}
		else{
			result=false;
		}
		return result;
	}
	public boolean  checkSpecialCharInDate(String value){
		boolean result=false;
		String REGEX = "[0-9-]*";
		Pattern pattern = Pattern.compile(REGEX);
		Matcher matcher = pattern.matcher(value);
		if (matcher.matches()){
		  result=true;
		}
		else{
			result=false;
		}
		return result;
	}
	public boolean  checkCharactersAndNumbers(String value){
		boolean result=false;
		String REGEX = "[a-zA-Z0-9]*";
		Pattern pattern = Pattern.compile(REGEX);
		Matcher matcher = pattern.matcher(value);
		if (matcher.matches()){
		  result=true;
		}
		else{
			result=false;
		}
		return result;
	}

	public List<EVCountryDetailVO> getCountryList()
	{
		List<EVCountryDetailVO> countryNameList = new ArrayList<EVCountryDetailVO>();	

			List<CodesVO>tempCountryList = (List<CodesVO>)(IBankParams.getCodesDataList("ALL", "Country"));
			Iterator<CodesVO> iterator = tempCountryList.iterator();
			if (tempCountryList != null && tempCountryList.size() > 0)
			{
				while (iterator.hasNext())
				{
					CodesVO codesVO = (CodesVO)iterator.next();
					if ( StringMethods.isEmptyString(codesVO.getCode()) )
					{
						codesVO.setCode(" ");
					}
					EVCountryDetailVO countryListVO=new EVCountryDetailVO();
					String countryCode = codesVO.getCode();
					String countryName = codesVO.getMessage();
					countryListVO.setCountryName(countryName);
					countryListVO.setCountryCode(countryCode);
					countryNameList.add(countryListVO);			
				}
				Collections.sort(countryNameList, new Comparator<EVCountryDetailVO>(){
					@Override
					public int compare(EVCountryDetailVO s1, EVCountryDetailVO s2) 
					{
					   return s1.getCountryName().compareToIgnoreCase(s2.getCountryName());
					}
				  });
			}
	 return countryNameList;
	}
	
	public static List<EVCountryDetailVO> getPassportCountryList()
	{
		List<EVCountryDetailVO> countryNameList = new ArrayList<EVCountryDetailVO>();	

			List<CodesVO>tempCountryList = (List<CodesVO>)(IBankParams.getCodesDataList("ALL", "evCountry"));
			Iterator<CodesVO> iterator = tempCountryList.iterator();
			if (tempCountryList != null && tempCountryList.size() > 0)
			{
				while (iterator.hasNext())
				{
					CodesVO codesVO = (CodesVO)iterator.next();
					if ( StringMethods.isEmptyString(codesVO.getCode()) )
					{
						codesVO.setCode(" ");
					}
					EVCountryDetailVO countryListVO=new EVCountryDetailVO();
					String countryCode = codesVO.getCode();
					String countryName = codesVO.getMessage();
					countryListVO.setCountryName(countryName);
					countryListVO.setCountryCode(countryCode);
					countryNameList.add(countryListVO);			
				}
				Collections.sort(countryNameList, new Comparator<EVCountryDetailVO>(){
					@Override
					public int compare(EVCountryDetailVO s1, EVCountryDetailVO s2) 
					{
					   return s1.getCountryName().compareToIgnoreCase(s2.getCountryName());
					}
				  });
			}
	 return countryNameList;
	}
		
	public List<String> getStateList()
	{
	   List<String> resultList = new ArrayList<String>();
	   resultList.add("ACT");
	   resultList.add("NSW");
	   resultList.add("NT");
	   resultList.add("QLD");
	   resultList.add("SA");
	   resultList.add("TAS");
	   resultList.add("VIC");
	   resultList.add("WA");
	   
	  Collections.sort(resultList, new Comparator<String>() {
	  @Override
	  public int compare(String v1, String v2) 
	    {
		   return v1.compareToIgnoreCase(v2);
	    }
	   });									
	  return resultList;
	}
	
	public static List<String> getMedicarePosNumList() {
		List<String> resultList = new ArrayList<String>();
		for(int i=0; i<IBankParams.MEDICARE_MAX_POS_NO; i++){
			resultList.add(i, Integer.toString(i+1));
		}
		return resultList;
	}
	
	public static List<String> getMonthList() {
		List<String> resultList = new ArrayList<String>();
		for(int i=0; i<IBankParams.MAX_MONTH; i++){
			resultList.add(i, Integer.toString(i+1));
		}
		return resultList;
	}
	
	public static List<String> getMedicareValidToYearList(int currentYear) {
		List<String> resultList = new ArrayList<String>();
		for(int i=currentYear, j=0; i<(currentYear+IBankParams.MEDICARE_YEAR_EXPIRY_UPTO); i++, j++){
			resultList.add(j, Integer.toString(i));
		}
		return resultList;
	}
	
	public static int getCurrentYear(){
		Calendar cal=Calendar.getInstance();
		return cal.get(Calendar.YEAR);
	}
	
	public static au.com.stgeorge.ibank.evcrs.businessobject.valueobject.EVInfo populateEvInfoVo(EVReq req){
		au.com.stgeorge.ibank.evcrs.businessobject.valueobject.EVInfo evInfoVO = new au.com.stgeorge.ibank.evcrs.businessobject.valueobject.EVInfo();
		evInfoVO.setDriverLicenseSelected(req.getEvInfo().isDriversLicence());
		if(null!=req.getEvInfo().getDlicenceNum()){
			evInfoVO.setDlLicenseNum(req.getEvInfo().getDlicenceNum());
		}
		if(null!=req.getEvInfo().getDlStateOfIssue()){
			evInfoVO.setDlStateOfIssue(req.getEvInfo().getDlStateOfIssue());
		}
		evInfoVO.setMedicareSelected(req.getEvInfo().isMedicareCard());
		if(null!=req.getEvInfo().getMedicareNum()){
			evInfoVO.setMedicareNum(req.getEvInfo().getMedicareNum());
		}
		if(null!=req.getEvInfo().getMedicarePosNum()){
			evInfoVO.setMedicarePosNum(req.getEvInfo().getMedicarePosNum());
		}
		if(null!=req.getEvInfo().getMedicareMiddleInitial()){
			evInfoVO.setMedicareMiddleInitial(req.getEvInfo().getMedicareMiddleInitial());
		}
		if(null!=req.getEvInfo().getMedicareValidToMon()){
			String monthVal=String.format("%02d",Integer.parseInt(req.getEvInfo().getMedicareValidToMon()));
			evInfoVO.setMedicareValidToMon(monthVal);
		}
		if(null!=req.getEvInfo().getMedicareValidToYear()){
			evInfoVO.setMedicareValidToYear(req.getEvInfo().getMedicareValidToYear());
		}
		evInfoVO.setPassportSelected(req.getEvInfo().isPassport());
		if(null!=req.getEvInfo().getPassportCountryOfIssue()){
			evInfoVO.setPassportCountryOfissue(req.getEvInfo().getPassportCountryOfIssue());
		}
		if(null!=req.getEvInfo().getPassportNum()){
			evInfoVO.setPassportNum(req.getEvInfo().getPassportNum());	
		}
		evInfoVO.setBirthCertificateSelected(req.getEvInfo().isAusBirthCertificate());
		if(null!=req.getEvInfo().getBirthCertRegNum()){
			evInfoVO.setBirthCertRegNum(req.getEvInfo().getBirthCertRegNum());
		}
		if(null!=req.getEvInfo().getBirthCertRegNum()){
			evInfoVO.setBirthCertRegNum(req.getEvInfo().getBirthCertRegNum());
		}
		if(null!=req.getEvInfo().getBirthCertStateOfIssue()){
			evInfoVO.setBirthCertStateOfIssue(req.getEvInfo().getBirthCertStateOfIssue());
		}
		if(null!=req.getEvInfo().getBirthCertRegDate()){
			String birthCertRegdate=req.getEvInfo().getBirthCertRegDate();
			String birthDate=birthCertRegdate.substring(8);
			String birthMonth=birthCertRegdate.substring(5,7);
			String birthYear=birthCertRegdate.substring(0,4);
			
			evInfoVO.setBirthCertRegDateYear(birthYear);
			evInfoVO.setBirthCertRegDateMon(birthMonth);
			evInfoVO.setBirthCertRegDateDay(birthDate);
		}		
		evInfoVO.setPhotoCardSelected(req.getEvInfo().isNswPhotoCard());
		if(null!=req.getEvInfo().getPhotoCardNum()){
			evInfoVO.setPhotoCardNum(req.getEvInfo().getPhotoCardNum());
		}
		if(null!=req.getEvInfo().getPhotoCardPCNum()){
			evInfoVO.setPhotoCardPCNum(req.getEvInfo().getPhotoCardPCNum());
		}				
		return evInfoVO;
	}
	
	public IMBResp populateValidateEVResponse(List<String> responseList) throws BusinessException
	{
		VerifyEVResp evResp = new VerifyEVResp();
		if(null!=responseList){
			String validationStatus=responseList.get(0);
			String attemptCountDesc=responseList.get(1);
			
			Logger.debug("validationStatus ::>::"+validationStatus, this.getClass());
			Logger.debug("attemptCountDesc ::>::"+attemptCountDesc, this.getClass());
			
			if(validationStatus.equalsIgnoreCase("ACCEPT") || validationStatus.equalsIgnoreCase("ACCPET")){
				evResp.setIdVerified(true);
				evResp.setMaxAttemtReached(false);
			}
			else if(validationStatus.equalsIgnoreCase("REJECT")){
			  evResp.setIdVerified(false);				
			  if(null!=attemptCountDesc && attemptCountDesc.indexOf(EVConstants.EV_MAX_REACHED) != -1){
					evResp.setMaxAttemtReached(true);
				}
				else{
					evResp.setMaxAttemtReached(false);
				}
			}
		}
		return evResp;
	}
	
	public static String getCountryCode(String countryName){
		String countryCode="";
		HashMap<String,String> hm=new HashMap<String,String>();

		List<CodesVO>tempCountryList = (List<CodesVO>)(IBankParams.getCodesDataList("ALL", "Country"));
		Iterator<CodesVO> iterator = tempCountryList.iterator();
		if (tempCountryList != null && tempCountryList.size() > 0)
		{	
			while (iterator.hasNext())
			{
				CodesVO codesVO = (CodesVO)iterator.next();
				hm.put(codesVO.getCode(),codesVO.getMessage());				
			}
		}		
        for(Map.Entry entry: hm.entrySet()){
            if(countryName.equals(entry.getValue())){
            	countryCode = (String)entry.getKey();
                break;
            }
        }		
		return countryCode;
	}	
	public static String getReasonCode(String reasonName){
		String reasonCode="";
		HashMap<String,String> hm=new HashMap<String,String>();

		List<CodesVO>tempCountryList = (List<CodesVO>)(IBankParams.getCodesDataList("ALL", "evForeignTINReason"));
		Iterator<CodesVO> iterator = tempCountryList.iterator();
		if (tempCountryList != null && tempCountryList.size() > 0)
		{	
			while (iterator.hasNext())
			{
				CodesVO codesVO = (CodesVO)iterator.next();
				hm.put(codesVO.getCode(),codesVO.getMessage());				
			}
		}		
        for(Map.Entry entry: hm.entrySet()){
            if(reasonName.equals(entry.getValue())){
            	reasonCode = (String)entry.getKey();
                break;
            }
        }		
		return reasonCode;
	}
	
	public static String getCountryName(String countryCode){
		String countryName="";
		HashMap<String,String> hm=new HashMap<String,String>();

		List<CodesVO>tempCountryList = (List<CodesVO>)(IBankParams.getCodesDataList("ALL", "Country"));
		Iterator<CodesVO> iterator = tempCountryList.iterator();
		if (tempCountryList != null && tempCountryList.size() > 0)
		{	
			while (iterator.hasNext())
			{
				CodesVO codesVO = (CodesVO)iterator.next();
				hm.put(codesVO.getCode(),codesVO.getMessage());				
			}
		}		
        for(Map.Entry entry: hm.entrySet()){
            if(countryCode.equals(entry.getKey())){
            	countryName = (String)entry.getValue();
                break;
            }
        }		
		return countryName;
	}
	public List<ReIDVInfoVO> getSourceOfWealthList()
	{
		List<ReIDVInfoVO> infoList = new ArrayList<ReIDVInfoVO>();	

			List<CodesVO>tempCountryList = (List<CodesVO>)(IBankParams.getCodesDataList("ALL", "evCustSourceOfWealth"));
			Iterator<CodesVO> iterator = tempCountryList.iterator();
			if (tempCountryList != null && tempCountryList.size() > 0)
			{
				while (iterator.hasNext())
				{
					CodesVO codesVO = (CodesVO)iterator.next();
					if ( StringMethods.isEmptyString(codesVO.getCode()) )
					{
						codesVO.setCode(" ");
					}
					ReIDVInfoVO reIDVInfoVO=new ReIDVInfoVO();
					String code = codesVO.getCode();
					String description = codesVO.getMessage();
					reIDVInfoVO.setCode(code);
					reIDVInfoVO.setDescription(description);
					infoList.add(reIDVInfoVO);			
				}
				Collections.sort(infoList, new Comparator<ReIDVInfoVO>(){
					@Override
					public int compare(ReIDVInfoVO s1, ReIDVInfoVO s2) 
					{
					   return s1.getCode().compareToIgnoreCase(s2.getCode());
					}
				  });
			}
	 return infoList;
	}
	public List<ReIDVInfoVO> getSourceOfFundList()
	{
		List<ReIDVInfoVO> infoList = new ArrayList<ReIDVInfoVO>();	

			List<CodesVO>tempCountryList = (List<CodesVO>)(IBankParams.getCodesDataList("ALL", "evCustSourceOfFund"));
			Iterator<CodesVO> iterator = tempCountryList.iterator();
			if (tempCountryList != null && tempCountryList.size() > 0)
			{
				while (iterator.hasNext())
				{
					CodesVO codesVO = (CodesVO)iterator.next();
					if ( StringMethods.isEmptyString(codesVO.getCode()) )
					{
						codesVO.setCode(" ");
					}
					ReIDVInfoVO reIDVInfoVO=new ReIDVInfoVO();
					String code = codesVO.getCode();
					String description = codesVO.getMessage();
					reIDVInfoVO.setCode(code);
					reIDVInfoVO.setDescription(description);
					infoList.add(reIDVInfoVO);			
				}
				Collections.sort(infoList, new Comparator<ReIDVInfoVO>(){
					@Override
					public int compare(ReIDVInfoVO s1, ReIDVInfoVO s2) 
					{
					   return s1.getCode().compareToIgnoreCase(s2.getCode());
					}
				  });
			}
	 return infoList;
	}
	public List<ReIDVInfoVO> getCustReasonForProductList()
	{
		List<ReIDVInfoVO> infoList = new ArrayList<ReIDVInfoVO>();	

			List<CodesVO>tempCountryList = (List<CodesVO>)(IBankParams.getCodesDataList("ALL", "evCustReasonForProduct"));
			Iterator<CodesVO> iterator = tempCountryList.iterator();
			if (tempCountryList != null && tempCountryList.size() > 0)
			{
				while (iterator.hasNext())
				{
					CodesVO codesVO = (CodesVO)iterator.next();
					if ( StringMethods.isEmptyString(codesVO.getCode()) )
					{
						codesVO.setCode(" ");
					}
					ReIDVInfoVO reIDVInfoVO=new ReIDVInfoVO();
					String code = codesVO.getCode();
					String description = codesVO.getMessage();
					reIDVInfoVO.setCode(code);
					reIDVInfoVO.setDescription(description);
					infoList.add(reIDVInfoVO);			
				}
				
				Collections.sort(infoList, new Comparator<ReIDVInfoVO>(){
					@Override
					public int compare(ReIDVInfoVO s1, ReIDVInfoVO s2) 
					{
					   return s1.getCode().compareToIgnoreCase(s2.getCode());
					}
				  });
			}
	 return infoList;
	}
	
	public List<ReIDVInfoVO> getCustOccupationList()
	{
		List<ReIDVInfoVO> infoList = new ArrayList<ReIDVInfoVO>();	

			List<CodesVO>tempCountryList = (List<CodesVO>)(IBankParams.getCodesDataList("ALL", "evCustOccupationCode"));
			Iterator<CodesVO> iterator = tempCountryList.iterator();
			if (tempCountryList != null && tempCountryList.size() > 0)
			{
				while (iterator.hasNext())
				{
					CodesVO codesVO = (CodesVO)iterator.next();
					if ( StringMethods.isEmptyString(codesVO.getCode()) )
					{
						codesVO.setCode(" ");
					}
					ReIDVInfoVO reIDVInfoVO=new ReIDVInfoVO();
					String code = codesVO.getCode();
					String description = codesVO.getMessage();
					reIDVInfoVO.setCode(code);
					reIDVInfoVO.setDescription(description);
					infoList.add(reIDVInfoVO);			
				}
				
				Collections.sort(infoList, new Comparator<ReIDVInfoVO>(){
					@Override
					public int compare(ReIDVInfoVO s1, ReIDVInfoVO s2) 
					{
					   return s1.getCode().compareToIgnoreCase(s2.getCode());
					}
				  });
			}
	 return infoList;
	}
	
	public List<ReIDVInfoVO> getCustEmployeeCodeList()
	{
		List<ReIDVInfoVO> infoList = new ArrayList<ReIDVInfoVO>();	

			List<CodesVO>tempCountryList = (List<CodesVO>)(IBankParams.getCodesDataList("ALL", "evCustEmploymentType"));
			Iterator<CodesVO> iterator = tempCountryList.iterator();
			if (tempCountryList != null && tempCountryList.size() > 0)
			{
				while (iterator.hasNext())
				{
					CodesVO codesVO = (CodesVO)iterator.next();
					if ( StringMethods.isEmptyString(codesVO.getCode()) )
					{
						codesVO.setCode(" ");
					}
					ReIDVInfoVO reIDVInfoVO=new ReIDVInfoVO();
					String code = codesVO.getCode();
					String description = codesVO.getMessage();
					reIDVInfoVO.setCode(code);
					reIDVInfoVO.setDescription(description);
					infoList.add(reIDVInfoVO);			
				}
				
				Collections.sort(infoList, new Comparator<ReIDVInfoVO>(){
					@Override
					public int compare(ReIDVInfoVO s1, ReIDVInfoVO s2) 
					{
					   return s1.getCode().compareToIgnoreCase(s2.getCode());
					}
				  });
			}
	 return infoList;
	}
	
	private String getReIDVOrgID(){
		String retVal = "";
		try {
				CodesVO code = getCodesData(DEFAULT_ORIGIN, "EV",EVConstants.ORG_ID);
				if (code != null) {
					retVal = code.getMessage();
				}
		} catch (Exception e) {
			IBankLog
			    .logERR("Exception in getReIDVOrgID ", e, this.getClass());
		}
		return retVal;
	}
	
	private String getReIDVPageID(){
		String retVal = "";
		try {
				CodesVO code = getCodesData(DEFAULT_ORIGIN, "EV",EVConstants.PAGE_ID);
				if (code != null) {
					retVal = code.getMessage();
				}
		} catch (Exception e) {
			IBankLog
			    .logERR("Exception in getReIDVPageID ", e, this.getClass());
		}
		return retVal;
	}
	
	private String getReIDVThreatMatrixURL(){
		String retVal = "";
		try {
				CodesVO code = getCodesData(DEFAULT_ORIGIN, "EV",EVConstants.THREAT_MATRIX_URL);
				if (code != null) {
					retVal = code.getMessage();
				}
		} catch (Exception e) {
			IBankLog
			    .logERR("Exception in getReIDVThreatMatrixURL ", e, this.getClass());
		}
		return retVal;
	}
	
	public static au.com.stgeorge.ibank.evcrs.businessobject.valueobject.EVInfo populateEvInfoVo_ReIDV(ReIDVReq req){
		au.com.stgeorge.ibank.evcrs.businessobject.valueobject.EVInfo evInfoVO = new au.com.stgeorge.ibank.evcrs.businessobject.valueobject.EVInfo();
		evInfoVO.setDriverLicenseSelected(req.getEvInfo().isDriversLicence());
		if(null!=req.getEvInfo().getDlicenceNum()){
			evInfoVO.setDlLicenseNum(req.getEvInfo().getDlicenceNum());
		}
		if(null!=req.getEvInfo().getDlStateOfIssue()){
			evInfoVO.setDlStateOfIssue(req.getEvInfo().getDlStateOfIssue());
		}
		evInfoVO.setMedicareSelected(req.getEvInfo().isMedicareCard());
		if(null!=req.getEvInfo().getMedicareNum()){
			evInfoVO.setMedicareNum(req.getEvInfo().getMedicareNum());
		}
		if(null!=req.getEvInfo().getMedicarePosNum()){
			evInfoVO.setMedicarePosNum(req.getEvInfo().getMedicarePosNum());
		}
		if(null!=req.getEvInfo().getMedicareMiddleInitial()){
			evInfoVO.setMedicareMiddleInitial(req.getEvInfo().getMedicareMiddleInitial());
		}
		if(null!=req.getEvInfo().getMedicareValidToMon()){
			String monthVal=String.format("%02d",Integer.parseInt(req.getEvInfo().getMedicareValidToMon()));
			evInfoVO.setMedicareValidToMon(monthVal);
		}
		if(null!=req.getEvInfo().getMedicareValidToYear()){
			evInfoVO.setMedicareValidToYear(req.getEvInfo().getMedicareValidToYear());
		}
		evInfoVO.setPassportSelected(req.getEvInfo().isPassport());
		if(null!=req.getEvInfo().getPassportCountryOfIssue()){
			evInfoVO.setPassportCountryOfissue(req.getEvInfo().getPassportCountryOfIssue()); //getCountryCode
			//evInfoVO.setPassportCountryOfissue(getCountryCode(req.getEvInfo().getPassportCountryOfIssue()));
		}
		if(null!=req.getEvInfo().getPassportNum()){
			evInfoVO.setPassportNum(req.getEvInfo().getPassportNum());	
		}
		evInfoVO.setBirthCertificateSelected(req.getEvInfo().isAusBirthCertificate());
		if(null!=req.getEvInfo().getBirthCertRegNum()){
			evInfoVO.setBirthCertRegNum(req.getEvInfo().getBirthCertRegNum());
		}
		if(null!=req.getEvInfo().getBirthCertRegNum()){
			evInfoVO.setBirthCertRegNum(req.getEvInfo().getBirthCertRegNum());
		}
		if(null!=req.getEvInfo().getBirthCertStateOfIssue()){
			evInfoVO.setBirthCertStateOfIssue(req.getEvInfo().getBirthCertStateOfIssue());
		}
		if(null!=req.getEvInfo().getBirthCertRegDate()){
			String birthCertRegdate=req.getEvInfo().getBirthCertRegDate();
			String birthDate=birthCertRegdate.substring(8);
			String birthMonth=birthCertRegdate.substring(5,7);
			String birthYear=birthCertRegdate.substring(0,4);
			
			evInfoVO.setBirthCertRegDateYear(birthYear);
			evInfoVO.setBirthCertRegDateMon(birthMonth);
			evInfoVO.setBirthCertRegDateDay(birthDate);
		}		
		evInfoVO.setPhotoCardSelected(req.getEvInfo().isNswPhotoCard());
		if(null!=req.getEvInfo().getPhotoCardNum()){
			evInfoVO.setPhotoCardNum(req.getEvInfo().getPhotoCardNum());
		}
		if(null!=req.getEvInfo().getPhotoCardPCNum()){
			evInfoVO.setPhotoCardPCNum(req.getEvInfo().getPhotoCardPCNum());
		}				
		return evInfoVO;
	}
	
	public static au.com.stgeorge.ibank.evcrs.businessobject.valueobject.CRSInfo populateCRSInfoVo_ReIDV(ReIDVReq req,List<EVForeignCountryDetail> evForeignCountryDtls)
	{
	   au.com.stgeorge.ibank.evcrs.businessobject.valueobject.CRSInfo crsInfoVo = new au.com.stgeorge.ibank.evcrs.businessobject.valueobject.CRSInfo();
	   crsInfoVo.setForeignTaxResident(req.getCrsInfo().isForeignTaxResident());	   
	   List<au.com.stgeorge.ibank.evcrs.businessobject.valueobject.TaxResidency> taxResidencyList = new ArrayList<au.com.stgeorge.ibank.evcrs.businessobject.valueobject.TaxResidency>();
	   
	   if(req.getCrsInfo().isForeignTaxResident()){
		   for(TaxResidency trList: req.getCrsInfo().getTaxResidencyList()){			   
			  au.com.stgeorge.ibank.evcrs.businessobject.valueobject.TaxResidency taxResidency = new au.com.stgeorge.ibank.evcrs.businessobject.valueobject.TaxResidency();
			  String countryCD="";
			  boolean isTinApplicable=false;
		          if(null!=trList.getCountry()){
		        	  countryCD=trList.getCountry();
		        	  taxResidency.setCountryCode(trList.getCountry());  
		          }
		          for(EVForeignCountryDetail evFr:evForeignCountryDtls){
		        	  if(countryCD.equalsIgnoreCase(evFr.getCountryCode())){
		        		  isTinApplicable=!evFr.isNoTin();
		        		  break;
		        	  }
		        	  else{
		        		  isTinApplicable=true; 
		        	  }
		          }
		          if(null!=trList.getForeignTIN()){
		        	  taxResidency.setForeignTIN(trList.getForeignTIN());
		          }
		          taxResidency.setForeignTINProvided(trList.isForeignTINProvided());
		          if(!trList.isForeignTINProvided()){
		        		  if(isTinApplicable){
		        			  if(null!=trList.getReason()){
		        				  taxResidency.setNoForeignTINCode(getReasonCode(trList.getReason())); 
		        			  }
		        			  else{
		        				  taxResidency.setNoForeignTINCode(EVConstants.TIN_NOT_ISSUED);
		        			  }
		        		  }
		        		  else{
		        			  taxResidency.setNoForeignTINCode(EVConstants.TIN_NOT_ISSUED);
		        		  }
		          }	          
		          taxResidencyList.add(taxResidency);
		     }
		    crsInfoVo.setTaxResidencyList(taxResidencyList);
	   }
	    return crsInfoVo;	            
	 }
	
	public EVMainResponse populateThreatMatrixInfo(EVMainResponse evResp, MobileSession mbSession, IBankCommonData ibankCommonData) throws BusinessException
	{
		boolean threatMatrixReqd=false;
		if(null!=evResp){
			
			if(null==mbSession.getEVThreatMatrixSessionID()){
				threatMatrixReqd=true;
				String token = TokenService.generatetToken();
				evResp.setSessionId(token);
				mbSession.setEVThreatMatrixSessionID(token);
			}
			else{
				threatMatrixReqd=false;
				evResp.setSessionId(mbSession.getEVThreatMatrixSessionID());
			}			
			evResp.setOrgId(getReIDVOrgID());
			evResp.setPageId(getReIDVPageID());
			evResp.setThreatMatrixURL(getReIDVThreatMatrixURL());
			evResp.setThreatMatrixReqd(threatMatrixReqd);	
		}	
		return evResp;
	}
	
	public static ErrorResp createErrorResp(MobileSession mbSession, BusinessException e, String serviceName, HttpServletRequest httpRequest) {
		MBAppHelper mbAppHelper = (MBAppHelper) ServiceHelper.getBean("mbAppHelper");
		EVErrorResp evErrorResp = new EVErrorResp(mbAppHelper.populateResponseHeader(serviceName, httpRequest));
		List<ErrorInfo> errorList = MBAppUtils.getErrorList(mbSession.getOrigin(), BusinessException.SYSTEM_UNAVILABLE, MBAppUtils.getMessage(mbSession.getOrigin(), BusinessException.SYSTEM_UNAVILABLE));
		evErrorResp.setErrors(errorList);
		if(BusinessException.CRS_UPDATE_FAILED == e.getKey()){
			evErrorResp.setHideCRS(false);
		}else{
			evErrorResp.setHideCRS(true);
			// for not triggering subsequent CRS service calls ,in case of 1st 2nd attempt
			EVCustDetails evCustDetails = mbSession.getEvCustDetails();
			evCustDetails.setCrsInfoRequired(false);
			mbSession.setEvCustDetails(evCustDetails);
		}
					
		Logger.debug(evErrorResp, MBAppUtils.class);
		Logger.info("Error response populated: " + evErrorResp, MBAppUtils.class);
		return evErrorResp;
	}
}