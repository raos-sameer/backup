package au.com.stgeorge.mbank.model.request.payments;

import javax.validation.constraints.Pattern;

import org.apache.commons.lang.builder.ReflectionToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;
import org.hibernate.validator.constraints.Length;
import org.hibernate.validator.constraints.NotEmpty;

import au.com.stgeorge.ibank.businessobject.BusinessException;
import au.com.stgeorge.mbank.model.common.IMBReq;
import au.com.stgeorge.mbank.model.common.ReqHeader;

/**
 * Add biller request
 * 
 * @author C38854
 * 
 */
public class AddBillerReq implements IMBReq {

	private static final long serialVersionUID = 6845533065596722230L;

	private static final String BILLER_CODE_PATTERN = "^[0-9]*$";
	private static final String CUST_REF_NUMBER_PATTERN = "^[0-9, ,-]*$";

	// @Valid TODO
	private ReqHeader header;

	@Pattern(regexp = CUST_REF_NUMBER_PATTERN, message = "{errors.billerCRN.pattern}")
	private String crn;

	@Length(max = 50, message = "{errors.billerAlias.maxlength}")
	private String billerAlias;

	@NotEmpty(message = "" + BusinessException.BPAY_INVALID_BIILER_CODE)
	@Pattern(regexp = BILLER_CODE_PATTERN, message = "{errors.billerCode.pattern}")
	private String billerCode;

	private Boolean variableCRN;

	public ReqHeader getHeader() {
		return header;
	}

	public void setHeader(ReqHeader header) {
		this.header = header;
	}

	public String getCrn() {
		return crn;
	}

	public String getBillerAlias() {
		return billerAlias;
	}

	public String getBillerCode() {
		return billerCode;
	}

	public Boolean getVariableCRN() {
		return variableCRN;
	}
	
	@Override
	public String toString() {
		return ReflectionToStringBuilder.toString(this, ToStringStyle.MULTI_LINE_STYLE);
	}

}