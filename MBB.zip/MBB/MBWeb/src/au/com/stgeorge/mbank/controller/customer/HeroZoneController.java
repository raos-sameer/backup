package au.com.stgeorge.mbank.controller.customer;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import au.com.stgeorge.framework.common.logging.Logger;
import au.com.stgeorge.ibank.businessobject.BusinessException;
import au.com.stgeorge.ibank.businessobject.FavTranService;
import au.com.stgeorge.ibank.businessobject.ResourceException;
import au.com.stgeorge.ibank.valueobject.Account;
import au.com.stgeorge.ibank.valueobject.AccountId;
import au.com.stgeorge.ibank.valueobject.Biller;
import au.com.stgeorge.ibank.valueobject.Customer;
import au.com.stgeorge.ibank.valueobject.FavTran;
import au.com.stgeorge.ibank.valueobject.PaymentsLog;
import au.com.stgeorge.ibank.valueobject.ThirdParty;
import au.com.stgeorge.ibank.valueobject.transfer.IBankCommonData;
import au.com.stgeorge.mbank.controller.IMBController;
import au.com.stgeorge.mbank.model.common.FavTranReq;
import au.com.stgeorge.mbank.model.common.FavTranResp;
import au.com.stgeorge.mbank.model.common.IMBReq;
import au.com.stgeorge.mbank.model.common.IMBResp;
import au.com.stgeorge.mbank.model.common.ReqHeader;
import au.com.stgeorge.mbank.model.common.RespHeader;
import au.com.stgeorge.mbank.model.response.ErrorResp;
import au.com.stgeorge.mbank.model.response.customer.HeroZoneResp;
import au.com.stgeorge.mbank.session.MobileSession;
import au.com.stgeorge.mbank.util.MBAppConstants;
import au.com.stgeorge.mbank.util.MBAppHelper;
import au.com.stgeorge.mbank.util.MBAppUtils;
import au.com.stgeorge.mbank.util.MBAppValidator;
import au.com.stgeorge.mbank.util.ServiceConstants;
import au.com.stgeorge.mobilebank.businessobject.MobileBankService;
import au.com.stgeorge.perflogger.PerformanceLogger;

@Controller
@RequestMapping(method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE)
public class HeroZoneController implements IMBController
{

	@RequestMapping("/getFavouriteTransList")
	@ResponseBody
	public IMBResp getFavouriteTransaction(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse)
	{
		String logName = startPerformanceLog(httpServletRequest);
		MobileSession mobileSession = null;
		try
		{
			// validate(req, httpServletRequest);
			mobileSession = mbAppHelper.getMobileSession(httpServletRequest);
			/*Logger.error("getFavouriteTransList ##################  " + mobileSession.getUser().getGCISNumber(), this.getClass());*/
			Logger.info("getFavouriteTransList ##################  " + mobileSession.getUser().getGCISNumber(), this.getClass());
			IBankCommonData iBankCommonData = mbAppHelper.populateIBankCommonData(mobileSession, httpServletRequest);
			Collection<FavTran> favList = mobileBankService.getFavouriteTransactionList(iBankCommonData);
			IMBResp serviceResponse = populateResponse(favList);
			RespHeader headerResp = populateResponseHeader(ServiceConstants.HERO_RESPONSE, mobileSession);
			serviceResponse.setHeader(headerResp);
			return serviceResponse;
		} catch (BusinessException e)
		{
			Logger.error("Exception Inside processLogon() for Customer GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			IMBResp resp1 = MBAppUtils.createErrorResp(mobileSession.getOrigin() , e, MBAppConstants.SMPL_LOGON_RESP_NAME, httpServletRequest);
			return resp1;
		} catch (Exception e)
		{
			Logger.error("Exception Inside processLogon() for Customer GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			BusinessException exp = new BusinessException(BusinessException.SMPL_SYS_ERROR);
			IMBResp resp1 = MBAppUtils.createErrorResp(mobileSession.getOrigin() , exp, MBAppConstants.SMPL_LOGON_RESP_NAME, httpServletRequest );
			return resp1;
		} finally {
			endPerformanceLog(logName);
		}
	}

	@RequestMapping("/addFavouriteTransactionOld")
	@ResponseBody
	public IMBResp addFavouriteTransactionOld(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse,
			@RequestBody final FavTranReq req)
	{
		String logName = startPerformanceLog(httpServletRequest);
		MobileSession mobileSession = null;
		try
		{
			mobileSession = mbAppHelper.getMobileSession(httpServletRequest);
      validateRequestHeader( req.getHeader(), httpServletRequest );
			
			IBankCommonData iBankCommonData = mbAppHelper.populateIBankCommonData(mobileSession, httpServletRequest);
			int favCount = mobileBankService.getFavouriteTransactionsCountByGCIS(iBankCommonData);
			
			/*Logger.error("update fav Tran ##################  " + mobileSession.getUser().getGCISNumber() + " Index :  " + req.getTranIndex() + " Count : "+ favCount, this
					.getClass());*/
			Logger.info("update fav Tran ##################  " + mobileSession.getUser().getGCISNumber() + " Index :  " + req.getTranIndex() + " Count : "+ favCount, this
					.getClass());
			
			if ( favCount >= 5 )
			{
				//	Maximum number of favourite transaction allowed is 5.
				throw new BusinessException(BusinessException.FAV_TRAN_MAX_EXCEEDED);
			}
			
			FavTran favTran = new FavTran();


			Account account = mbAppHelper.getAccountFromCustomer(iBankCommonData.getCustomer(), req.getFromAccountIndex());
			favTran.setAccountNumberFrom(account.getAccountId().getAccountNumber());
			favTran.setBsbNumberFrom(account.getAccountId().getBsb());
			favTran.setFromAppID(account.getAccountId().getApplicationId());
			
			if ( req.getTranType() == 0  )  // Account To ACCount
			{
				Account toAccount = mbAppHelper.getAccountFromCustomer(iBankCommonData.getCustomer(), req.getToItemIndex());
				favTran.setAccountNumberTo(toAccount.getAccountId().getAccountNumber());
				favTran.setBsbNumberTo(toAccount.getAccountId().getBsb());
				favTran.setToAppID(toAccount.getAccountId().getApplicationId());
				favTran.setTransType(PaymentsLog.TYPE_STG_TO_STG_ACCOUNT_TRANSFER);
				favTran.setAliasName( account.getAlias());
			} 
			else if ( req.getTranType() == 1  )  // Thirdparty
			{
				ThirdParty thirdParty = mbAppHelper.getThirdPartyFromCustomer(iBankCommonData.getCustomer(), req.getToItemIndex());
				favTran.setAccountNumberTo(thirdParty.getNumber());
				favTran.setBsbNumberTo(thirdParty.getBsb());
				favTran.setTransType(PaymentsLog.TYPE_TRANSFER_TO_3RD_PARTY);
				favTran.setAliasName(thirdParty.getName());
			}  
			else if ( req.getTranType() == 2  )  // Biller
			{
				Biller biller = mbAppHelper.getBillerFromCustomer(iBankCommonData.getCustomer(), req.getToItemIndex());
				favTran.setBillerCode(biller.getCode());
				favTran.setBillerCRN(biller.getLastReferenceNumber() );
				favTran.setTransType(PaymentsLog.TYPE_BPAY);
				favTran.setAliasName(biller.getBillerAlias());
			}  
			
			favTran.setPayeeEmail(req.getPayeeEmail());
			favTran.setEmailNotifFlag(req.isSendEmail());
			favTran.setFavouriteFlag(req.isFavouriteFlag());
			favTran.setPaymentLogId(req.getPaymentLogId());
	//		mobileBankService.addFavouriteTransaction(iBankCommonData, favTran);
			
			Collection<FavTran> favList = mobileBankService.getFavouriteTransactionList(iBankCommonData);
			IMBResp serviceResponse = populateResponse(favList);
			RespHeader headerResp = populateResponseHeader(ServiceConstants.HERO_RESPONSE, mobileSession);
			serviceResponse.setHeader(headerResp);
			return serviceResponse;

		} catch (BusinessException e)
		{
			Logger.error("Exception Inside processLogon() for Customer GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			IMBResp resp1 = MBAppUtils.createErrorResp(mobileSession.getOrigin(), e, MBAppConstants.SMPL_LOGON_RESP_NAME,httpServletRequest );
			return resp1;
		} catch (Exception e)
		{
			Logger.error("Exception Inside processLogon() for Customer GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			BusinessException exp = new BusinessException(BusinessException.SMPL_SYS_ERROR);
			IMBResp resp1 = MBAppUtils.createErrorResp(mobileSession.getOrigin(), exp, MBAppConstants.SMPL_LOGON_RESP_NAME, httpServletRequest);
			return resp1;
		} finally {
			endPerformanceLog(logName);
		}
	
	}

	@RequestMapping("/addFavouriteTransaction")
	@ResponseBody
	public IMBResp addFavouriteTransaction(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse,
			@RequestBody final FavTranReq req)
	{
		String logName = startPerformanceLog(httpServletRequest);
		MobileSession mobileSession = null;
		try
		{
			mobileSession = mbAppHelper.getMobileSession(httpServletRequest);
      validateRequestHeader( req.getHeader(), httpServletRequest );
			
			
			IBankCommonData iBankCommonData = mbAppHelper.populateIBankCommonData(mobileSession, httpServletRequest);
			int favCount = mobileBankService.getFavouriteTransactionsCountByGCIS(iBankCommonData);
			
			Logger.debug("Add fav Tran ##################  " + mobileSession.getUser().getGCISNumber() + " Index :  " + req.getTranIndex() + " Count : "+ favCount, this
					.getClass());

			
			if ( favCount >= 5 )
			{
				//	Maximum number of favourite transaction allowed is 5.
				throw new BusinessException(BusinessException.FAV_TRAN_MAX_EXCEEDED);
			}
			
			PaymentsLog paymentsLog =favTranService.getPaymentsLog(iBankCommonData, req.getPaymentLogId());

			Logger.debug(" Payments Log  ##################  " + paymentsLog.getAmount() + " req.getPaymentLogId()  " + req.getPaymentLogId() + " req.getFromAccountIndex() "+ req.getFromAccountIndex() + " req.getToItemIndex() " + req.getToItemIndex()  + " Trans "+ paymentsLog.getXrefType(), this
					.getClass());

	
			
			FavTran favTran = new FavTran();
	
			Account fromAccount = null;
			if ( req.getFromAccountIndex() != null )
			{
				 fromAccount = mbAppHelper.getAccountFromCustomer(iBankCommonData.getCustomer(), req.getFromAccountIndex());
			}
			else
			{
				 fromAccount = mbAppHelper.getAccountByAccountKey(iBankCommonData.getCustomer().getAccounts(), paymentsLog.getAccountNumberFrom());
			}

/*			if ( ! paymentsLog.getXrefType().equals( PaymentsLog.TYPE_CREDIT_CARD_AMOUNT) && Account.CRA.equalsIgnoreCase( fromAccount.getAccountId().getApplicationId())  )
			{
			   Logger.info("Invalid Transaction Type " + paymentsLog.getXrefType() + " for ID : " + paymentsLog.getId() , this.getClass());
			   throw new BusinessException( BusinessException.FAV_TRAN_INVALID_FROM_ACCOUNT, "Invalid Transaction Type " + paymentsLog.getXrefType() + " for ID : " + paymentsLog.getId()  );
			}  */

			
			if ( fromAccount == null ||   Account.LIS.equalsIgnoreCase( fromAccount.getAccountId().getApplicationId()) || 
					( Account.CRA.equalsIgnoreCase( fromAccount.getAccountId().getApplicationId()) && ! paymentsLog.getXrefType().equals( PaymentsLog.TYPE_BPAY) ) 
					)
			{
				Logger.info("Invalid FromAccount " + paymentsLog.getXrefType() + " for ID : " + paymentsLog.getId() , this.getClass());
		   throw new BusinessException( BusinessException.FAV_TRAN_INVALID_FROM_ACCOUNT, "FromAccount Not found in Customer Object " + paymentsLog.getXrefType() + " for ID : " + paymentsLog.getId()  );
			}
			else if ( paymentsLog.getXrefType().equals( PaymentsLog.TYPE_P2P_TRANSFER))
			{
				   Logger.info("Can't set up a Pay to Mobile payment as Quick Pay for ID : " + paymentsLog.getId() , this.getClass());
				   throw new BusinessException( BusinessException.FAV_TRAN_INVALID_FOR_P2M_PAYMENT);
			}
			
			favTran.setAccountNumberFrom(fromAccount.getAccountId().getAccountNumber());
			favTran.setBsbNumberFrom(fromAccount.getAccountId().getBsb());
			favTran.setFromAppID(fromAccount.getAccountId().getApplicationId());
			req.setTranType( getRequestType(paymentsLog) );
			
			if ( req.getTranType() == 0  )  // Account To ACCount
			{
				Account toAccount = null;
				if ( req.getToItemIndex() != null )
					  toAccount = mbAppHelper.getAccountFromCustomer(iBankCommonData.getCustomer(), req.getToItemIndex());
				else
					 toAccount = mbAppHelper.getAccountByAccountKey(iBankCommonData.getCustomer().getAccounts(), paymentsLog.getAccountNumberTo());
					
				if ( toAccount == null || Account.CDA.equalsIgnoreCase( toAccount.getAccountId().getApplicationId()) )
				{
					Logger.info("ToAccount Not found in Customer Object " + paymentsLog.getXrefType() + " for ID : " + paymentsLog.getId() , this.getClass());
			   throw new BusinessException( BusinessException.FAV_TRAN_INVALID_TO_ACCOUNT, "ToAccount Not found in Customer Object " + paymentsLog.getXrefType() + " for ID : " + paymentsLog.getId()  );
				}
				favTran.setAccountNumberTo(toAccount.getAccountId().getAccountNumber());
				favTran.setBsbNumberTo(toAccount.getAccountId().getBsb());
				favTran.setToAppID(toAccount.getAccountId().getApplicationId());
				favTran.setTransType(PaymentsLog.TYPE_STG_TO_STG_ACCOUNT_TRANSFER);
				favTran.setAliasName( toAccount.getAlias());
			} 
			else if ( req.getTranType() == 1  )  // Thirdparty
			{
				ThirdParty thirdParty = null;
				if ( req.getToItemIndex() != null )
				   thirdParty = mbAppHelper.getThirdPartyFromCustomer(iBankCommonData.getCustomer(), req.getToItemIndex());
				else
					 thirdParty = mbAppHelper.getThirdPartyFromCustomer(iBankCommonData.getCustomer(), paymentsLog.getBsbNumberTo(), paymentsLog.getAccountNumberTo()  );
				
				if ( thirdParty == null)
				{
					Logger.info("Thirdparty  Not found in Customer Object " + paymentsLog.getXrefType() + " for ID : " + paymentsLog.getId() , this.getClass());
			   throw new BusinessException( BusinessException.FAV_TRAN_INVALID_TO_ACCOUNT, "Thirdparty Not found in Customer Object " + paymentsLog.getXrefType() + " for ID : " + paymentsLog.getId()  );
				}
				favTran.setAccountNumberTo(thirdParty.getNumber());
				favTran.setBsbNumberTo(thirdParty.getBsb());
				favTran.setTransType(paymentsLog.getXrefType());
				favTran.setAliasName(thirdParty.getName());
			}  
			else if ( req.getTranType() == 2  )  // Biller
			{
				Biller biller = null;
				if ( req.getToItemIndex() != null )
					 biller = mbAppHelper.getBillerFromCustomer(iBankCommonData.getCustomer(), req.getToItemIndex());
				else
				{
					Biller tempBiller = new Biller();
					tempBiller.setCode(paymentsLog.getBillerCode());
					tempBiller.setLastReferenceNumber(paymentsLog.getReferenceNumber());
					biller = mbAppHelper.getBillerFromCustomer(iBankCommonData.getCustomer(), tempBiller, false);
					if ( biller == null)
					{
						biller = mbAppHelper.getBillerFromCustomer(iBankCommonData.getCustomer(), tempBiller, true);
						if ( biller != null && biller.getVariableCRN() != 0)
						{
								Logger.info("Variable CRN " + biller.getVariableCRN() + " for ID : " + paymentsLog.getId() , this.getClass());
						   throw new BusinessException( BusinessException.FAV_TRAN_INVALID_BPAY_REQ, "Variable CRN " + biller.getVariableCRN() + " for ID : " + paymentsLog.getId()  );
						}
					}					
				}
				if ( biller == null)
				{
					Logger.info("Biller Not found in Customer Object " + paymentsLog.getXrefType() + " for ID : " + paymentsLog.getId() , this.getClass());
			   throw new BusinessException( BusinessException.FAV_TRAN_INVALID_TO_ACCOUNT, "Biller Not found in Customer Object " + paymentsLog.getXrefType() + " for ID : " + paymentsLog.getId()  );
				}
				else
				{
					if ( biller.getVariableCRN() != 0)
					{
							Logger.info("Variable CRN " + biller.getVariableCRN() + " for ID : " + paymentsLog.getId() , this.getClass());
					   throw new BusinessException( BusinessException.FAV_TRAN_INVALID_BPAY_REQ, "Variable CRN " + biller.getVariableCRN() + " for ID : " + paymentsLog.getId()  );
					}
				}
				
				favTran.setBillerCode(biller.getCode());
				favTran.setBillerCRN(biller.getLastReferenceNumber() );
				favTran.setTransType(PaymentsLog.TYPE_BPAY);
				favTran.setAliasName(biller.getBillerAlias());
				favTran.setFavBillerID(String.valueOf(biller.getId()) );
			}  
			
			favTran.setPayeeEmail(req.getPayeeEmail());
			favTran.setEmailNotifFlag(req.isSendEmail());
			favTran.setFavouriteFlag(req.isFavouriteFlag());
			favTran.setPaymentLogId(req.getPaymentLogId());
			favTranService.addFavouriteTransaction(iBankCommonData, favTran, paymentsLog);
			
			Collection<FavTran> favList = mobileBankService.getFavouriteTransactionList(iBankCommonData);
			IMBResp serviceResponse = populateResponse(favList);
			RespHeader headerResp = populateResponseHeader(ServiceConstants.HERO_RESPONSE, mobileSession);
			serviceResponse.setHeader(headerResp);
			return serviceResponse;

		} catch (BusinessException e)
		{
			Logger.error("Exception Inside processLogon() for Customer GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			IMBResp resp1 = MBAppUtils.createErrorResp( mobileSession.getOrigin() , e, MBAppConstants.SMPL_LOGON_RESP_NAME, httpServletRequest);
			return resp1;
		} catch (Exception e)
		{
			Logger.error("Exception Inside processLogon() for Customer GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			BusinessException exp = new BusinessException(BusinessException.SMPL_SYS_ERROR);
			IMBResp resp1 = MBAppUtils.createErrorResp(mobileSession.getOrigin(), exp, MBAppConstants.SMPL_LOGON_RESP_NAME, httpServletRequest);
			return resp1;
		} finally {
			endPerformanceLog(logName);
		}
	
	}

	
	
	@RequestMapping("/updateMostFavouriteTransaction")
	@ResponseBody
	public IMBResp saveFavouriteTransaction(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse,
			@RequestBody final FavTranReq req)
	{
		String logName = startPerformanceLog(httpServletRequest);
		MobileSession mobileSession = null;
		try
		{
			mobileSession = mbAppHelper.getMobileSession(httpServletRequest);
      validateRequestHeader( req.getHeader(), httpServletRequest );
      
			/*Logger.error("update fav Tran ##################  " + mobileSession.getUser().getGCISNumber() + " Index :  " + req.getTranIndex(), this
					.getClass());*/
      		Logger.info("update fav Tran ##################  " + mobileSession.getUser().getGCISNumber() + " Index :  " + req.getTranIndex(), this
				.getClass());
			IBankCommonData iBankCommonData = mbAppHelper.populateIBankCommonData(mobileSession, httpServletRequest);
			mobileBankService.updateFavouriteTransaction(iBankCommonData, new Long(req.getTranIndex()));
			IMBResp serviceResponse = populateResponseForUpdate(req.getTranIndex());
			RespHeader headerResp = populateResponseHeader(ServiceConstants.HERO_RESPONSE, mobileSession);
			serviceResponse.setHeader(headerResp);
			return serviceResponse;

		} catch (BusinessException e)
		{
			Logger.error("Exception Inside processLogon() for Customer GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			IMBResp resp1 = MBAppUtils.createErrorResp(mobileSession.getOrigin(), e, MBAppConstants.SMPL_LOGON_RESP_NAME, httpServletRequest);
			return resp1;
		} catch (Exception e)
		{
			Logger.error("Exception Inside processLogon() for Customer GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			BusinessException exp = new BusinessException(BusinessException.SMPL_SYS_ERROR);
			IMBResp resp1 = MBAppUtils.createErrorResp(mobileSession.getOrigin(), exp, MBAppConstants.SMPL_LOGON_RESP_NAME, httpServletRequest);
			return resp1;
		} finally {
			endPerformanceLog(logName);
		}
	}

	@RequestMapping("/deleteFavouriteTrans")
	@ResponseBody
	public IMBResp deleteFavouriteTransaction(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse,
			@RequestBody final FavTranReq req)
	{
		String logName = startPerformanceLog(httpServletRequest);
		MobileSession mobileSession = null;
		try
		{
			mobileSession = mbAppHelper.getMobileSession(httpServletRequest);
      validateRequestHeader( req.getHeader(), httpServletRequest );
			
			/*Logger.error("update fav Tran ##################  " + mobileSession.getUser().getGCISNumber() + " Index :  " + req.getTranIndex(), this
					.getClass());*/
      		Logger.info("update fav Tran ##################  " + mobileSession.getUser().getGCISNumber() + " Index :  " + req.getTranIndex(), this
    		  .getClass());
			IBankCommonData iBankCommonData = mbAppHelper.populateIBankCommonData(mobileSession, httpServletRequest);
			mobileBankService.deleteFavouriteTransaction(iBankCommonData, new Long(req.getTranIndex()));
			IMBResp serviceResponse = populateResponseForUpdate(req.getTranIndex());
			RespHeader headerResp = populateResponseHeader(ServiceConstants.HERO_RESPONSE, mobileSession);
			serviceResponse.setHeader(headerResp);
			return serviceResponse;

		} catch (BusinessException e)
		{
			Logger.error("Exception Inside processLogon() for Customer GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
//			BusinessException exp = new BusinessException(e.getKey());
			IMBResp resp1 = MBAppUtils.createErrorResp(mobileSession.getOrigin(), e, MBAppConstants.SMPL_LOGON_RESP_NAME,httpServletRequest );
			return resp1;
		} catch (Exception e)
		{
			Logger.error("Exception Inside processLogon() for Customer GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			BusinessException exp = new BusinessException(BusinessException.SMPL_SYS_ERROR);
			IMBResp resp1 = MBAppUtils.createErrorResp(mobileSession.getOrigin(), exp, MBAppConstants.SMPL_LOGON_RESP_NAME, httpServletRequest);
			return resp1;
		} finally {
			endPerformanceLog(logName);
		}
	}

	
	@RequestMapping("/getFavouriteTransaction")
	@ResponseBody
	public IMBResp getFavouriteTransaction(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse,
			@RequestBody final FavTranReq req)
	{
		String logName = startPerformanceLog(httpServletRequest);
		MobileSession mobileSession =  null;
		try
		{
			mobileSession = mbAppHelper.getMobileSession(httpServletRequest);
      validateRequestHeader( req.getHeader(), httpServletRequest );
			
			/*Logger.error("Get fav Tran ##################  " + mobileSession.getUser().getGCISNumber() + " Index :  " + req.getTranIndex(), this
					.getClass());*/
      		Logger.info("Get fav Tran ##################  " + mobileSession.getUser().getGCISNumber() + " Index :  " + req.getTranIndex(), this
				.getClass());
			IBankCommonData iBankCommonData = mbAppHelper.populateIBankCommonData(mobileSession, httpServletRequest);
			FavTran favTran  = mobileBankService.getFavouriteTransaction(iBankCommonData, new Long(req.getTranIndex()));
			IMBResp serviceResponse = populateResponseGet(favTran, mobileSession);
			RespHeader headerResp = populateResponseHeader(ServiceConstants.HERO_RESPONSE, mobileSession);
			serviceResponse.setHeader(headerResp);
			return serviceResponse;

		} catch (BusinessException e)
		{
			Logger.error("Exception Inside processLogon() for Customer GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
//			BusinessException exp = new BusinessException(e.getKey());
			IMBResp resp1 = MBAppUtils.createErrorResp(mobileSession.getOrigin(), e, MBAppConstants.SMPL_LOGON_RESP_NAME,httpServletRequest );
			return resp1;
		} catch (Exception e)
		{
			Logger.error("Exception Inside processLogon() for Customer GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			BusinessException exp = new BusinessException(BusinessException.SMPL_SYS_ERROR);
			IMBResp resp1 = MBAppUtils.createErrorResp(mobileSession.getOrigin(), exp, MBAppConstants.SMPL_LOGON_RESP_NAME, httpServletRequest);
			return resp1;
		} finally {
			endPerformanceLog(logName);
		}
	}
	
	
	public ErrorResp validate(IMBReq serviceRequest, HttpServletRequest httpServletRequest)
	{
//		MBAppValidator mbAppValidator = new MBAppValidator();
		 return mbAppValidator.validate(serviceRequest, httpServletRequest);
	}

	public void validateRequestHeader(ReqHeader header, HttpServletRequest request) throws ResourceException
	{
		// Nothing to do in case of logon as Session is not created. Session is
		// created after only successful logon
//		MBAppValidator mbAppValidator = new MBAppValidator();
		mbAppValidator.validateRequestHeader(header, request);

	}


	private IMBResp populateResponseForUpdate(long tranIndex)
	{
		HeroZoneResp heroZoneResp = new HeroZoneResp();
		heroZoneResp.setTranIndex(tranIndex);
		return heroZoneResp;
	}

	private IMBResp populateResponse(Collection<FavTran> favList)
	{
		HeroZoneResp heroZoneResp = new HeroZoneResp();
		if (favList != null)
		{
			ArrayList list = new ArrayList();
			DecimalFormat favAmtFormat = new DecimalFormat("0.00"); 
			
			for (FavTran favTran : favList)
			{
				FavTranResp favTranResp = new FavTranResp();
				favTranResp.setAliasName(favTran.getAliasName());
//				favTranResp.setAmount(String.valueOf(favTran.getAmount()));
				
//				String bigString = String.valueOf(favTran.getAmount());
//				if (bigString != null && bigString.endsWith(".0")   ){
//					bigString = bigString.replace(".0", ".00");  
//				}
				//favTranResp.setAmount(bigString);
				favTranResp.setAmount(favAmtFormat.format(favTran.getAmount()));
				
				favTranResp.setFavouriteFlag(favTran.isFavouriteFlag());
				favTranResp.setTranIndex(favTran.getId().intValue());
				list.add(favTranResp);
			}
			heroZoneResp.setFavTrans(list);
		}
		return heroZoneResp;
	}

	private IMBResp populateResponseGet(FavTran favTran,MobileSession mobileSession )
	{
			HeroZoneResp heroZoneResp = new HeroZoneResp();
			heroZoneResp.setTranIndex(favTran.getId().intValue());
			FavTranResp favTranResp = new FavTranResp();
			favTranResp.setTranIndex(favTran.getId().intValue());
			favTranResp.setAliasName(favTran.getAliasName());
			favTranResp.setAmount(String.valueOf(favTran.getAmount()));
			favTranResp.setFavouriteFlag(favTran.isFavouriteFlag());
			favTranResp.setTranIndex(favTran.getId().intValue());
			
			AccountId fromAccountID = new AccountId();
			fromAccountID.setAccountNumber(favTran.getAccountNumberFrom() );
			fromAccountID.setApplicationId(favTran.getFromAppID() );
			
			int fromAccountIndex = mbAppHelper.getAccountIndexByAccountId(mobileSession.getCustomer().getAccounts(),fromAccountID);
			favTranResp.setFromAccountIndex(fromAccountIndex);
			
			int toAccIndex = -1;
			
			if ( favTran.isEmailNotifFlag() )
			{
				favTranResp.setSendEmail(true);
			}
			
			favTranResp.setPayerName(favTran.getPayerName());

			if ( 	PaymentsLog.TYPE_STG_TO_STG_ACCOUNT_TRANSFER.equalsIgnoreCase(favTran.getTransType()) )
			{
				AccountId toAccountID = new AccountId();
				toAccountID.setAccountNumber(favTran.getAccountNumberTo() );
				toAccountID.setApplicationId(favTran.getToAppID() );
				toAccIndex = mbAppHelper.getAccountIndexByAccountId(mobileSession.getCustomer().getAccounts(),toAccountID);
				favTranResp.setToItemIndex(toAccIndex);
				favTranResp.setTranType("0");
			}
			else if ( 	PaymentsLog.TYPE_TRANSFER_TO_3RD_PARTY.equalsIgnoreCase(favTran.getTransType())
						|| PaymentsLog.TYPE_TRANSFER_TO_3RD_PARTY_SETUP.equalsIgnoreCase(favTran.getTransType())
						|| PaymentsLog.TYPE_TRANSFER_TO_3RD_PARTY_ON_US.equalsIgnoreCase(favTran.getTransType())
						|| PaymentsLog.TYPE_TRANSFER_TO_3RD_PARTY_SETUP_ON_US.equalsIgnoreCase(favTran.getTransType())
						|| PaymentsLog.TYPE_TRANSFER_TO_3RD_PARTY_MOBILE.equalsIgnoreCase(favTran.getTransType())
						|| PaymentsLog.TYPE_TRANSFER_NPP_CUSTOMER_SETUP.equalsIgnoreCase(favTran.getTransType())
						|| PaymentsLog.TYPE_TRANSFER_NPP_BANK_SETUP.equalsIgnoreCase(favTran.getTransType())
						|| PaymentsLog.TYPE_TRANSFER_NPP_DE_RETRY_CUSTOMER.equalsIgnoreCase(favTran.getTransType())
						|| PaymentsLog.TYPE_TRANSFER_NPP_DE_RETRY_BANK.equalsIgnoreCase(favTran.getTransType()))
			{
				toAccIndex = mbAppHelper.getThirdPartyIndexFromCustomer(mobileSession.getCustomer(), favTran.getBsbNumberTo(), favTran.getAccountNumberTo());
				favTranResp.setPayerName( "");
				favTranResp.setToItemIndex(toAccIndex);
				if ( toAccIndex >= 0)
				{
					ThirdParty thirdParty = mbAppHelper.getThirdPartyFromCustomer(mobileSession.getCustomer(), toAccIndex);
					if ( thirdParty != null )
					{
						// 	Payer Name is not used from FAV Table. used from ThirdParty ( Defect : 1274 - 14E4 29-08-2014 )
						favTranResp.setPayerName( thirdParty.getPayerName());  
						if ( favTran.isEmailNotifFlag() )
						{
								favTranResp.setPayeeEmail(thirdParty.getEmailPayee());
								favTranResp.setSendEmail(true);
						}
					}
					else
					{
						favTranResp.setSendEmail(false);
					}
				}
				favTranResp.setTranType("1");
			} 
			else if ( 	PaymentsLog.TYPE_BPAY.equalsIgnoreCase(favTran.getTransType()) )
			{
				Biller biller = new Biller();
				biller.setCode(favTran.getBillerCode());
				biller.setLastReferenceNumber(favTran.getBillerCRN());
//				toAccIndex = mbAppHelper.getBillerIndexFromCustomer(mobileSession.getCustomer(),  biller, false);
				toAccIndex = getBillerIndex( mobileSession, Integer.parseInt( favTran.getFavBillerID() ) );
				favTranResp.setToItemIndex(toAccIndex);
				favTranResp.setCustRefNum(favTran.getBillerCRN());
				favTranResp.setTranType("2");
			} 
			
			favTranResp.setDesc(favTran.getTransDesc());
			favTranResp.setSuccess(true);
			heroZoneResp.setFavTranResp(favTranResp);
			heroZoneResp.setSuccuss(true);
			return heroZoneResp;
	}
	
	private int getBillerIndex(MobileSession mobileSession, int favBillerID )
	{
		Customer customer = mobileSession.getCustomer();
		int tempBillerId = -1;
		boolean isFound = false;
		
		if ( customer.getBillers() != null && customer.getBillers().size() > 0 )
		{
			for (Iterator<Biller> iterator = customer.getBillers().iterator(); iterator.hasNext();) {
				Biller biller  = iterator.next();
				tempBillerId ++;
				if ( biller.getId() == favBillerID )
				{
					isFound = true;
					break;
				}
				
			}
		}
		
		if ( isFound )
			return tempBillerId;
		else
			return -1;  
		
	}

	
	
	@Autowired
	private MobileBankService mobileBankService;

	
	@Autowired
	private FavTranService favTranService;
	
	/*
	 * private MobileBankService mobileBankService;
	 * 
	 * public MobileBankService getMobileBankService() { return new
	 * MobileBankServiceImpl(); // return mobileBankService; }
	 * 
	 * 
	 * public void setMobileBankService(MobileBankService mobileBankService) {
	 * this.mobileBankService = mobileBankService; }
	 */

	@Autowired
	private MBAppHelper mbAppHelper;
	
	@Autowired
	private MBAppValidator mbAppValidator;

	/*
	 * public MBAppHelper getMbAppHelper() { // return mbAppHelper; return new
	 * MBAppHelper(); }
	 * 
	 * 
	 * 
	 * public void setMbAppHelper(MBAppHelper mbAppHelper) { this.mbAppHelper =
	 * mbAppHelper; }
	 */
	
	private int getRequestType(PaymentsLog paymentsLog)
	{
		 if (paymentsLog != null)
		 {
			 if ( paymentsLog.getXrefType().equals( PaymentsLog.TYPE_TRANSFER_TO_3RD_PARTY)
	    || paymentsLog.getXrefType().equals(PaymentsLog.TYPE_TRANSFER_TO_3RD_PARTY_SETUP)
	    || paymentsLog.getXrefType().equals( PaymentsLog.TYPE_TRANSFER_TO_3RD_PARTY_SETUP_ON_US)
	    || paymentsLog.getXrefType().equals(PaymentsLog.TYPE_TRANSFER_TO_3RD_PARTY_ON_US)
	    || paymentsLog.getXrefType().equals( PaymentsLog.TYPE_TRANSFER_TO_3RD_PARTY_MOBILE)
	    || paymentsLog.getXrefType().equals( PaymentsLog.TYPE_TRANSFER_NPP_CUSTOMER_SETUP)
	    || paymentsLog.getXrefType().equals( PaymentsLog.TYPE_TRANSFER_NPP_BANK_SETUP)
	    || paymentsLog.getXrefType().equals( PaymentsLog.TYPE_TRANSFER_NPP_DE_RETRY_CUSTOMER)
	    || paymentsLog.getXrefType().equals( PaymentsLog.TYPE_TRANSFER_NPP_DE_RETRY_BANK))
			 {
				 return 1;
			 }
			 else 	 if ( paymentsLog.getXrefType().equals( PaymentsLog.TYPE_BPAY) || paymentsLog.getXrefType().equals( PaymentsLog.TYPE_BPAY_VIEW))
			 {
				 return 2;
			 }
			 else
			 {
				 return 0;
			 }
		
		 }
		 return -1;

	}
	
	public RespHeader populateResponseHeader(String serviceName, MobileSession mobSession )
	{
		return mbAppHelper.populateResponseHeader(serviceName, mobSession);
	}


	@Autowired
	private PerformanceLogger perfLogger;
	
	private String startPerformanceLog(HttpServletRequest httpServletRequest){
		perfLogger.startAllLogs();
		String logName = MBAppUtils.getLogName(httpServletRequest);
		perfLogger.startLog(logName);
		return logName;
	}
	
	private void endPerformanceLog(String logName){
		perfLogger.endLog(logName);
		perfLogger.endAllLogs();
	}


}
