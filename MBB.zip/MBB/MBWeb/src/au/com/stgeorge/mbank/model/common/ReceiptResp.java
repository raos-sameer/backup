package au.com.stgeorge.mbank.model.common;

import java.util.Date;

import au.com.stgeorge.mbank.util.JsonDateTimeSerializer;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;

@JsonInclude(Include.NON_NULL)
public class ReceiptResp {
	public String getReceiptNumDisp() {
		return receiptNumDisp;
	}
	public void setReceiptNumDisp(String receiptNumDisp) {
		this.receiptNumDisp = receiptNumDisp;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getNewAccountNum() {
		return newAccountNum;
	}
	public void setNewAccountNum(String newAccountNum) {
		this.newAccountNum = newAccountNum;
	}
	public String getNewSNSAccountNum() {
		return newSNSAccountNum;
	}
	public void setNewSNSAccountNum(String newSNSAccountNum) {
		this.newSNSAccountNum = newSNSAccountNum;
	}
	public String getNewWorkAccountNum() {
		return newWorkAccountNum;
	}
	public void setNewWorkAccountNum(String newWorkAccountNum) {
		this.newWorkAccountNum = newWorkAccountNum;
	}
	public String getNewWorkAccountStatus() {
		return newWorkAccountStatus;
	}
	public void setNewWorkAccountStatus(String newWorkAccountStatus) {
		this.newWorkAccountStatus = newWorkAccountStatus;
	}

	@JsonSerialize(using = JsonDateTimeSerializer.class)
	@JsonInclude(Include.NON_NULL)
	public Date getDateTime() {
		return date;
	}
	public void setDateTime(Date date) {
		this.date = date;
	}
	private String receiptNumDisp;
    private Date date;
	private String status;
	private String newAccountNum;
	private String newSNSAccountNum;
	private String newWorkAccountNum;
	private String newWorkAccountStatus;
	
}
