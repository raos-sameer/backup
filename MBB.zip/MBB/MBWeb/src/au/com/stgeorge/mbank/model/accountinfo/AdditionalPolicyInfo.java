package au.com.stgeorge.mbank.model.accountinfo;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_NULL)
public class AdditionalPolicyInfo{

	private String componentType;
	private String componentAmt;
	public String getComponentType() {
		return componentType;
	}
	public void setComponentType(String componentType) {
		this.componentType = componentType;
	}
	public String getComponentAmt() {
		return componentAmt;
	}
	public void setComponentAmt(String componentAmt) {
		this.componentAmt = componentAmt;
	}
}
