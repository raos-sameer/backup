package au.com.stgeorge.mbank.controller.statements;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;

import au.com.stgeorge.framework.common.logging.Logger;
import au.com.stgeorge.framework.common.util.StringMethods;
import au.com.stgeorge.ibank.businessobject.BusinessException;
import au.com.stgeorge.ibank.businessobject.ResourceException;
import au.com.stgeorge.ibank.businessobject.globalWallet.GlobalWalletEstatementService;
import au.com.stgeorge.ibank.businessobject.globalWallet.GlobalWalletService;
import au.com.stgeorge.ibank.messagecentre.valueobject.TokenDetails;
import au.com.stgeorge.ibank.valueobject.Account;
import au.com.stgeorge.ibank.valueobject.AcctStatement;
import au.com.stgeorge.ibank.valueobject.Customer;
import au.com.stgeorge.ibank.valueobject.StatementOrderTransaction;
import au.com.stgeorge.ibank.valueobject.transfer.IBankCommonData;
import au.com.stgeorge.mbank.controller.IMBController;
import au.com.stgeorge.mbank.model.common.IMBReq;
import au.com.stgeorge.mbank.model.common.IMBResp;
import au.com.stgeorge.mbank.model.common.ReqHeader;
import au.com.stgeorge.mbank.model.common.RespHeader;
import au.com.stgeorge.mbank.model.request.EmptyReq;
import au.com.stgeorge.mbank.model.request.statements.EStmtInfoReq;
import au.com.stgeorge.mbank.model.response.ErrorResp;
import au.com.stgeorge.mbank.session.MobileSession;
import au.com.stgeorge.mbank.util.FraudLogger;
import au.com.stgeorge.mbank.util.MBAppConstants;
import au.com.stgeorge.mbank.util.MBAppHelper;
import au.com.stgeorge.mbank.util.MBAppUtils;
import au.com.stgeorge.mbank.util.MBAppValidator;
import au.com.stgeorge.mbank.util.ServiceConstants;
import au.com.stgeorge.mobilebank.businessobject.EStatementsService;
import au.com.stgeorge.perflogger.PerformanceLogger;

import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * @author C50216
 *
 */

@Controller
@RequestMapping("/stmt")
public class EStmtController implements IMBController{

	private FraudLogger fraudLogger;
	
	@Autowired
	private MBAppHelper mbAppHelper;
	
	@Autowired
	private MBAppValidator mbAppValidator;
	
	@Autowired
	private EStatementsService mobileEStatementService;
	
	@Autowired
	private EStmtHelper eStmtHelper;
	
	@Autowired
	private PerformanceLogger perfLogger;
	
	@Autowired
	private GlobalWalletService globalWalletService;

	@Autowired
	private GlobalWalletEstatementService globalWalletEstatementService;
	
	@RequestMapping(value= "list" , method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public IMBResp processStmtList(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse,
			@RequestBody final EStmtInfoReq req)
	{				
				
		ObjectMapper objectMapper = new ObjectMapper();								
		perfLogger.startAllLogs();
		String logName = MBAppUtils.getLogName(httpServletRequest);
		perfLogger.startLog(logName);
		List<AcctStatement> stmtList = null;
		List<TokenDetails> tokenList = null;
		List<TokenDetails> sessionTokenList = null;
		fraudLogger = new FraudLogger();
		MobileSession mbSession = null;
		boolean isClosedCCAccount = false;
		try{	
			
			mbSession = mbAppHelper.getMobileSession(httpServletRequest);		
			Logger.info("EStmt List JSON Request :" + objectMapper.writeValueAsString(req), this.getClass());
			validateRequestHeader(req.getHeader(), httpServletRequest);
			ErrorResp errorResp = validate(req, httpServletRequest);
			if (errorResp != null && errorResp.getErrors() != null && errorResp.getErrors().size() > 0)
			{				
				//fraudLogger.logInvalidInput();
				return errorResp;
			}
			
			Customer customer=mbSession.getCustomer();			
			
			int myAcctIndex = req.getAccountIndex();
			//Added By Deepti for EStatements for Closed Accounts.
			boolean isClosedAccount = false;
			if(req.getIsClosedAccount() != null){
				isClosedAccount = req.getIsClosedAccount(); 
			}
			Account account = null;
			if(isClosedAccount){
				account = mbAppHelper.getClosedAccountFromCustomer(customer, myAcctIndex);
				isClosedCCAccount = account.isAccountCreditCard();
			//Added By Deepti for EStatements for Closed Accounts.
			}else{
				account = mbAppHelper.getAccountFromCustomer(customer, myAcctIndex);
			}
			String stmtType = req.getAction();
			StatementOrderTransaction stmtOrderTransaction = new StatementOrderTransaction();
			stmtOrderTransaction.setAmountFromAccount(account.getAccountId());
			
			Date fromDate = req.getFromDate();
			Date toDate = req.getToDate();	
			
			if(stmtType.equalsIgnoreCase(MBAppConstants.STMT_TYPE_RANGE)){
				
				if(!eStmtHelper.validateDateRange(fromDate, toDate))
					throw new BusinessException(BusinessException.INVALID_DATE_RANGE );
				
				stmtOrderTransaction.setStatementFromDate(fromDate);
				stmtOrderTransaction.setStatementToDate(toDate);
				
			}else if(stmtType.equalsIgnoreCase(MBAppConstants.STMT_TYPE_LAST_YEAR)){
				
				Calendar toCal = Calendar.getInstance();
				Calendar fromCal = Calendar.getInstance();
				fromCal.add(Calendar.YEAR, -1);
				
				stmtOrderTransaction.setStatementFromDate(fromCal.getTime());
				stmtOrderTransaction.setStatementToDate(toCal.getTime());			
			}
				
			//In order to avoid pop-blocker complications at client side, will store token w/o stmtId.StmtId will be set when cust click on most recent button to view the pdf.
			//the moment customer comes to Estatement tab, mostRecent service will be called, just to store token w/o making service call.
			IBankCommonData commonData=mbAppHelper.populateIBankCommonData(mbSession,httpServletRequest);
			if(Account.GWC.equalsIgnoreCase(account.getAccountId().getApplicationId())) {
				
				boolean isIndexChanged = true;
				
				if(!StringMethods.isEmptyString(mbSession.getSelectedAccountIndex()) && String.valueOf(myAcctIndex).equalsIgnoreCase(mbSession.getSelectedAccountIndex())) {
					isIndexChanged = false;
				}
				mbSession.setSelectedAccountIndex(String.valueOf(myAcctIndex));
				if(isIndexChanged || mbSession.getGwcStmtDetail()==null || mbSession.getGwcStmtDetail().isEmpty()) {
					mbSession.setGwcStmtDetail(null);
					stmtList = globalWalletEstatementService.getStatementPeriodsList(account, commonData);
					sessionTokenList = getGWCTokenIdLists(stmtList, account, mbSession);
					mbSession.setGwcStmtDetail(sessionTokenList);
				}else {
					sessionTokenList = mbSession.getGwcStmtDetail();
				}
				
				if(sessionTokenList!=null && !sessionTokenList.isEmpty()) {
					if(stmtType.equalsIgnoreCase(MBAppConstants.STMT_TYPE_RECENT)){
						tokenList = new ArrayList<>();
						tokenList.add(sessionTokenList.get(0));
					}else {
						tokenList = eStmtHelper.filterGWCAccountStatementList(sessionTokenList, req.getFromDate(), req.getToDate());
					}
				}
				
			}else {
				if(!stmtType.equalsIgnoreCase(MBAppConstants.STMT_TYPE_RECENT)){					
					stmtList = mobileEStatementService.getMobileEStatementIDList(stmtOrderTransaction, commonData, isClosedAccount);
					if(isClosedCCAccount){
						stmtList = eStmtHelper.getFilteredClosedCCStmtList(account,stmtList,commonData);
					}
				}
			}
			
			if(!Account.GWC.equalsIgnoreCase(account.getAccountId().getApplicationId())) {
				tokenList = getTokenIdLists(stmtType, stmtList, account, mbSession);
			}
			
			IMBResp serviceResponse = eStmtHelper.populateStmtListResp(tokenList);
									
			RespHeader headerResp = populateResponseHeader(ServiceConstants.ESTMT_LIST_SERVICE, mbSession);
			serviceResponse.setHeader(headerResp);
			
			Logger.info("EStmt List  JSON Response :" + objectMapper.writeValueAsString(serviceResponse), this.getClass());
			
			return serviceResponse;		
		}catch (BusinessException e)
		{
			Logger.info("BusinessException Inside processStmtList() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			IMBResp resp1  = null;
			BusinessException exp = new BusinessException(e.getKey());
			if(e.getKey() == BusinessException.PDF_STATEMENT_NOT_FOUND)
				resp1  = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, ServiceConstants.ESTMT_LIST_SERVICE, ErrorResp.STATUS_INFO, httpServletRequest);
			else
				resp1  = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, ServiceConstants.ESTMT_LIST_SERVICE, httpServletRequest);
			return resp1;
		}catch (ResourceException e) {
			Logger.error("ResourceException Inside processStmtList() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			ResourceException exp = new ResourceException(e.getKey());
			IMBResp resp1  = MBAppUtils.createErrorResp(mbSession.getOrigin(),exp, ServiceConstants.ESTMT_LIST_SERVICE, httpServletRequest);
			return resp1;
		}catch (Exception e)
		{
			Logger.error("Exception Inside processStmtList() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			BusinessException exp = new BusinessException(BusinessException.GENERIC_ERROR);
			IMBResp resp1  = MBAppUtils.createErrorResp(mbSession.getOrigin(),exp, ServiceConstants.ESTMT_LIST_SERVICE, httpServletRequest);
			return resp1;
		} finally
		{
			perfLogger.endLog(logName);
			perfLogger.endAllLogs();
		}				
	}

	private List<TokenDetails> getTokenIdLists(String stmtType, List<AcctStatement> acctStatementList, Account account, MobileSession mbSession)
	throws BusinessException, ResourceException {	
		
	ArrayList<TokenDetails> arryList = new ArrayList<TokenDetails>();
	
	//In case of Recent stmt, we store token w/o stmtId. token & account detail will be used to get the StmtId when customer click on Recent stmt button.
	if(stmtType.equalsIgnoreCase(MBAppConstants.STMT_TYPE_RECENT)){
				
		TokenDetails tokenDetails = new TokenDetails();		
		Date today = new Date();
		
		tokenDetails.setAccountNum(account.getAccountId().getAccountNumber());
		tokenDetails.setApplId(account.getAccountId().getApplicationId());
		tokenDetails.setBsb(account.getAccountId().getBsb());
		tokenDetails.setGcisNumber(mbSession.getCustomer().getGcis());
		tokenDetails.setStmtId("");//TokenDetails table  StmtId & StmtEndDate shouldn't be null
		tokenDetails.setProdName(account.getAccountId().getProductName());
		tokenDetails.setStmtEndDate(today);
		tokenDetails.setCreatedOn(today);
		tokenDetails.setSessionId(mbSession.getSessionID());		
		tokenDetails.setOriginBank(mbSession.getGDWOrigin());
		tokenDetails.setAccountType(account.getAccountId().getEhubProductCode());
		tokenDetails.setSubProdCode(account.getAccountId().getSubProductCode());
		
//        CodesVO codesVORelCodes = IBankParams.getCodesData(IBankParams.DEFAULT_ORIGIN, IBankParams.SENSE_ACCT_OWNERS, IBankParams.STMT_REL_CODES);
//        if(codesVORelCodes.getMessage().indexOf(account.getAccountId().getRelationshipCode()) != -1){
//        	tokenDetails.setStmtAddrMaskInd("N");
//        }else{
//        	tokenDetails.setStmtAddrMaskInd("Y");
//        }
		
		//Need to save RelationshipCode, ViewEStmtController will call method to decide masking
    	tokenDetails.setStmtAddrMaskInd(account.getAccountId().getRelationshipCode());
    	
    	String pdfToken = mbAppHelper.getPdfDocToken();
		tokenDetails.setToken(pdfToken);		
		
		mobileEStatementService.addPDFDocTokenDetails(tokenDetails);
		
		arryList.add(tokenDetails);
		
	}else{
		
		for (AcctStatement acctStmt : acctStatementList) {
			TokenDetails tokenDetails = new TokenDetails();
			tokenDetails.setAccountNum(account.getAccountId().getAccountNumber());
			tokenDetails.setApplId(account.getAccountId().getApplicationId());
			tokenDetails.setBsb(account.getAccountId().getBsb());
			tokenDetails.setGcisNumber(mbSession.getCustomer().getGcis());
			tokenDetails.setStmtId(acctStmt.getStatementId());
			tokenDetails.setProdName(account.getAccountId().getProductName());
			tokenDetails.setStmtEndDate(acctStmt.getDateTo());
			tokenDetails.setCreatedOn(new Date());
			tokenDetails.setSessionId(mbSession.getSessionID());
			tokenDetails.setOriginBank(mbSession.getGDWOrigin());
			tokenDetails.setAccountType(account.getAccountId().getEhubProductCode());
			tokenDetails.setSubProdCode(account.getAccountId().getSubProductCode());
			tokenDetails.setStmtAddrMaskInd(acctStmt.getStmtAddrMaskInd());
			String pdfToken = mbAppHelper.getPdfDocToken();
			tokenDetails.setToken(pdfToken);		
			
			mobileEStatementService.addPDFDocTokenDetails(tokenDetails);
			
			arryList.add(tokenDetails);
		}
		
	}
	return arryList;
	}
	
	private List<TokenDetails> getGWCTokenIdLists(List<AcctStatement> acctStatementList, Account account, MobileSession mbSession)
			throws BusinessException, ResourceException {	
				
			ArrayList<TokenDetails> arryList = new ArrayList<TokenDetails>();
			
			
			if(acctStatementList!=null && !acctStatementList.isEmpty()) {	
				for (AcctStatement acctStmt : acctStatementList) {
					TokenDetails tokenDetails = new TokenDetails();
					tokenDetails.setAccountNum(account.getAccountId().getAccountNumber());
					tokenDetails.setApplId(account.getAccountId().getApplicationId());
					tokenDetails.setBsb(account.getAccountId().getBsb());
					tokenDetails.setGcisNumber(mbSession.getCustomer().getGcis());
					tokenDetails.setStmtId(acctStmt.getCardNumber());
					tokenDetails.setProdName(account.getAccountId().getProductName());
					tokenDetails.setStmtEndDate(acctStmt.getDateTo());
					tokenDetails.setCreatedOn(acctStmt.getDateFrom() );
					tokenDetails.setSessionId(mbSession.getSessionID());
					tokenDetails.setOriginBank(account.getBrand());
					tokenDetails.setAccountType(account.getAccountId().getEhubProductCode());
					tokenDetails.setSubProdCode(account.getAccountId().getSubProductCode());
					String pdfToken = mbAppHelper.getPdfDocToken();
					tokenDetails.setToken(pdfToken);
					arryList.add(tokenDetails);
				}
				
			}
			return arryList;
	}
	
	@RequestMapping(value= "closedAcctlist" , method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public IMBResp processClosedAccountsList(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse,
			@RequestBody final EmptyReq req)
	{				

		ObjectMapper objectMapper = new ObjectMapper();								
		perfLogger.startAllLogs();
		String logName = MBAppUtils.getLogName(httpServletRequest);
		perfLogger.startLog(logName);
		fraudLogger = new FraudLogger();
		MobileSession mbSession = null;
		List<Account> closedAccountsList = null;
		try{	

			mbSession = mbAppHelper.getMobileSession(httpServletRequest);		
			validateRequestHeader(req.getHeader(), httpServletRequest);
			ErrorResp errorResp = validate(req, httpServletRequest);
			if (errorResp != null && errorResp.getErrors() != null && errorResp.getErrors().size() > 0)
			{				
			
				return errorResp;
			}

			IBankCommonData commonData=mbAppHelper.populateIBankCommonData(mbSession,httpServletRequest);
			closedAccountsList = mobileEStatementService.getClosedAccounts(commonData);
			
			if(closedAccountsList == null || (closedAccountsList != null && closedAccountsList.size() <= 0)){
				throw new BusinessException(BusinessException.CLOSED_ACCOUNT_LIST_EMPTY);
			}
			IMBResp serviceResponse = eStmtHelper.populateClosedAccountListResp(closedAccountsList);

			RespHeader headerResp = populateResponseHeader(ServiceConstants.ESTMT_LIST_SERVICE, mbSession);
			serviceResponse.setHeader(headerResp);

			Logger.info("Closed Account List  JSON Response :" + objectMapper.writeValueAsString(serviceResponse) +  " GCC Closed acct " + globalWalletService.isEstatementsAvailableForClosedGlobalWalletAccount(mbSession.getOrigin()), this.getClass());

			return serviceResponse;	
			
		}catch (BusinessException e)
		{
			Logger.info("BusinessException Inside processClosedAccountsList() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			BusinessException exp = new BusinessException(e.getKey());
			IMBResp resp1 = null;
			if(e.getKey() == BusinessException.CLOSED_ACCOUNT_LIST_EMPTY)
			    resp1  = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, ServiceConstants.ESTMT_LIST_SERVICE, ErrorResp.STATUS_INFO, httpServletRequest);
			else
				resp1  = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, ServiceConstants.ESTMT_LIST_SERVICE, httpServletRequest);
			return resp1;
			
		}catch (ResourceException e) {
			Logger.error("ResourceException Inside processClosedAccountsList() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			ResourceException exp = new ResourceException(e.getKey());
			IMBResp resp1  = MBAppUtils.createErrorResp(mbSession.getOrigin(),exp, ServiceConstants.ESTMT_LIST_SERVICE, httpServletRequest);
			return resp1;
		}catch (Exception e)
		{
			Logger.error("Exception Inside processClosedAccountsList() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			BusinessException exp = new BusinessException(BusinessException.GENERIC_ERROR);
			IMBResp resp1  = MBAppUtils.createErrorResp(mbSession.getOrigin(),exp, ServiceConstants.ESTMT_LIST_SERVICE, httpServletRequest);
			return resp1;
		} finally
		{
			perfLogger.endLog(logName);
			perfLogger.endAllLogs();
		}				
}
	
	@RequestMapping(value= "getToken" , method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public IMBResp processStmtGetToken(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse,
			@RequestBody final EStmtInfoReq req)
	{				
				
		ObjectMapper objectMapper = new ObjectMapper();								
		perfLogger.startAllLogs();
		String logName = MBAppUtils.getLogName(httpServletRequest);
		perfLogger.startLog(logName);
		List<TokenDetails> tokenList = null;
		fraudLogger = new FraudLogger();
		MobileSession mbSession = null;
		try{	
			
			mbSession = mbAppHelper.getMobileSession(httpServletRequest);	
			Logger.info("EStmt getToken JSON Request :" + objectMapper.writeValueAsString(req), this.getClass());
			validateRequestHeader(req.getHeader(), httpServletRequest);
			ErrorResp errorResp = validate(req, httpServletRequest);
			if (errorResp != null && errorResp.getErrors() != null && errorResp.getErrors().size() > 0)
			{				
				//fraudLogger.logInvalidInput();
				return errorResp;
			}
			
			String selectedToken = req.getToken();
			if(StringMethods.isEmptyString(selectedToken)) {
				throw new BusinessException(BusinessException.SYSTEM_UNAVILABLE, "Selected token is empty");
			}
			
			Logger.info("Selected token :" + selectedToken, this.getClass());
			tokenList = addGWCPDFToken(mbSession, selectedToken);		
			
			IMBResp serviceResponse = eStmtHelper.populateStmtListResp(tokenList);
									
			RespHeader headerResp = populateResponseHeader(ServiceConstants.ESTMT_LIST_SERVICE, mbSession);
			serviceResponse.setHeader(headerResp);
			
			Logger.info("EStmt getToken JSON Response :" + objectMapper.writeValueAsString(serviceResponse), this.getClass());
			
			return serviceResponse;		
		}catch (BusinessException e)
		{
			Logger.info("BusinessException Inside processStmtGetToken() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			IMBResp resp1  = null;
			BusinessException exp = new BusinessException(e.getKey());
			if(e.getKey() == BusinessException.PDF_STATEMENT_NOT_FOUND)
				resp1  = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, ServiceConstants.ESTMT_GET_TOKEN_SERVICE, ErrorResp.STATUS_INFO, httpServletRequest);
			else
				resp1  = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, ServiceConstants.ESTMT_GET_TOKEN_SERVICE, httpServletRequest);
			return resp1;
		}catch (ResourceException e) {
			Logger.error("ResourceException Inside processStmtGetToken() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			ResourceException exp = new ResourceException(e.getKey());
			IMBResp resp1  = MBAppUtils.createErrorResp(mbSession.getOrigin(),exp, ServiceConstants.ESTMT_GET_TOKEN_SERVICE, httpServletRequest);
			return resp1;
		}catch (Exception e)
		{
			Logger.error("Exception Inside processStmtGetToken() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			BusinessException exp = new BusinessException(BusinessException.GENERIC_ERROR);
			IMBResp resp1  = MBAppUtils.createErrorResp(mbSession.getOrigin(),exp, ServiceConstants.ESTMT_GET_TOKEN_SERVICE, httpServletRequest);
			return resp1;
		} finally
		{
			perfLogger.endLog(logName);
			perfLogger.endAllLogs();
		}				
	}
	
	private List<TokenDetails> addGWCPDFToken(MobileSession mbSession, String selectedToken ) throws ResourceException, BusinessException {
		List<TokenDetails> tokenList =  new ArrayList<TokenDetails>();
		boolean isSelTokenInSession = false;
		List<TokenDetails> sessionTokenList = mbSession.getGwcStmtDetail();
		
		if(sessionTokenList!=null) {
			for(TokenDetails token : sessionTokenList) {
				if(token.getToken().equalsIgnoreCase(selectedToken)) {
					isSelTokenInSession =true;
					
					TokenDetails tokenDetails = new TokenDetails();
					tokenDetails.setAccountNum(token.getAccountNum());
					tokenDetails.setApplId(token.getApplId());
					tokenDetails.setBsb(token.getBsb());
					tokenDetails.setGcisNumber(token.getGcisNumber());
					tokenDetails.setStmtId(token.getStmtId());
					tokenDetails.setProdName(token.getProdName());
					tokenDetails.setStmtEndDate(token.getStmtEndDate());
					tokenDetails.setCreatedOn(token.getCreatedOn());
					tokenDetails.setSessionId(token.getSessionId());
					tokenDetails.setOriginBank(token.getOriginBank());
					tokenDetails.setAccountType(token.getAccountType());
					tokenDetails.setSubProdCode(token.getSubProdCode());
					String pdfToken = mbAppHelper.getPdfDocToken();
					tokenDetails.setToken(pdfToken);
					
					tokenList.add(tokenDetails);
					
					mobileEStatementService.addPDFDocTokenDetails(tokenDetails);
					break;
				}
			}
		}		
		
		if(!isSelTokenInSession) {
			Logger.info("Selected token "+selectedToken +" not found in session", this.getClass());
			throw new BusinessException(BusinessException.SYSTEM_UNAVILABLE);
		}
		
		return tokenList;
	}
	
	/**
	 * Response for invalid body request 
	 * 
	 * @return
	 */
	@ExceptionHandler({org.springframework.http.converter.HttpMessageNotReadableException.class})
	@ResponseStatus(org.springframework.http.HttpStatus.OK)
	@ResponseBody
	public IMBResp resolveException() {		
		return MBAppUtils.createInvalidMessageBodyResponse(ServiceConstants.ESTMT_LIST_SERVICE);
	}
	
	public ErrorResp validate(IMBReq serviceRequest, HttpServletRequest request) {
		return mbAppValidator.validate(serviceRequest, request);
	}
	
	public void validateRequestHeader(ReqHeader header, HttpServletRequest request) throws ResourceException
	{	
		mbAppValidator.validateRequestHeader(header,  request);	
	}
	
	public RespHeader populateResponseHeader(String ServiceName)
	{		
		return mbAppHelper.populateResponseHeader(ServiceName);
	}
	
	public RespHeader populateResponseHeader(String serviceName, MobileSession mobSession )
	{
		return mbAppHelper.populateResponseHeader(serviceName, mobSession);
	}

	
}
