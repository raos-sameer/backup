package au.com.stgeorge.mbank.controller;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.AbstractController;
import au.com.stgeorge.framework.common.logging.Logger;
import au.com.stgeorge.framework.common.util.StringMethods;
import au.com.stgeorge.ibank.businessobject.ResourceException;
import au.com.stgeorge.mbank.util.MBAppConstants;

public class ReturnFromExternalAppController extends AbstractController {
	
	@Autowired
	private ReturnFromExternalAppHelper returnFromExternalAppHelper;
	
    private static final String COMPASS_REDIRECT_URL = "/page?ActionType=aceToCompass";
    
    /* (non-Javadoc)
     * @see org.springframework.web.servlet.mvc.AbstractController#handleRequestInternal(javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse)
     * This method is directly called from ACE and it validates whether the compass session is still alive
     */
    @Override
	protected ModelAndView handleRequestInternal(HttpServletRequest request, HttpServletResponse response) throws Exception {
		try{
			String sessionId = getSessionID(request);
			if(sessionId == null || StringMethods.isEmptyString(sessionId)) {
				Logger.info("SessionId is null", this.getClass());
				return null;
			}
			try {
				returnFromExternalAppHelper.validateSession(sessionId);
			} catch (Exception e) {
				Logger.error("Exception while validating session for Session id: "+sessionId + e.getMessage(), this.getClass());
			}
		}catch (Exception e) {
			Logger.error("Exception while validating session while navigating back from ACE to Compass: " + e.getMessage(), this.getClass());
		}
		response.sendRedirect(request.getContextPath()+COMPASS_REDIRECT_URL);
		return null;
	}
			
	/**
	 * This method is used to get the Session Id from request cookie
	 * @param httpServletRequest
	 * @return sessionId
	 */
	private String getSessionID(HttpServletRequest httpServletRequest)
	{
		String sessionId = null;
		Cookie sessionCookie = getCookie( httpServletRequest, MBAppConstants.SMPL_SESS_CONSTANT);
		if(sessionCookie == null || sessionCookie.getValue().length() < 2){
			Logger.error("Not getting session from cookie", this.getClass() );
		}
		else{
			sessionId = (String)sessionCookie.getValue();
		}
		Logger.info("SessionID from cookie :"+sessionId, this.getClass() );
		return sessionId;
	}
	
	/**
	 * This method is used to get the cookie name from request
	 * @param request
	 * @param cookieName
	 * @return cookie
	 * @throws ResourceException
	 */
	public Cookie getCookie(HttpServletRequest request, String cookieName) throws ResourceException
	{
		Cookie[] cookies = request.getCookies();
		Cookie cookie = null;
		if (cookies != null){
			for (int i = 0; i < cookies.length; i++){
				Logger.debug("Cookie Name" + cookies[i].getName() + " found in the request. Value : " + cookies[i].getValue() , this.getClass());
				if (cookies[i].getName().equals(cookieName)){
					cookie = cookies[i]; 
					Logger.info("Cookie " + cookieName + " found in the request. Value : " + cookie.getValue() , this.getClass());
					break;
				}
			}
		}
		return cookie;
	}
}
