package au.com.stgeorge.mbank.controller.customer;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import au.com.stgeorge.framework.common.logging.Logger;
import au.com.stgeorge.framework.common.model.User;
import au.com.stgeorge.framework.common.util.StringMethods;
import au.com.stgeorge.ibank.businessobject.BusinessException;
import au.com.stgeorge.ibank.businessobject.EmailService;
import au.com.stgeorge.ibank.businessobject.HeartBeat;
import au.com.stgeorge.ibank.businessobject.ResourceException;
import au.com.stgeorge.ibank.common.cache.IBankParams;
import au.com.stgeorge.ibank.mail.EmailDetails;
import au.com.stgeorge.ibank.servicestation.businessobject.ServiceStation;
import au.com.stgeorge.ibank.servicestation.businessobject.ServiceStationImpl;
import au.com.stgeorge.ibank.servicestation.businessobject.valueobject.ServiceStationVO;
import au.com.stgeorge.ibank.servicestation.util.ServicetationConstants;
import au.com.stgeorge.ibank.util.CommonBusinessUtil;
import au.com.stgeorge.ibank.util.ServiceHelper;
import au.com.stgeorge.ibank.valueobject.AutoApplyRetentionInfo;
import au.com.stgeorge.ibank.valueobject.Customer;
import au.com.stgeorge.ibank.valueobject.database.OriginsVO;
import au.com.stgeorge.ibank.valueobject.transfer.AuthenticationData;
import au.com.stgeorge.ibank.valueobject.transfer.IBankCommonData;
import au.com.stgeorge.mbank.controller.IMBController;
import au.com.stgeorge.mbank.controller.SecureCodeHelper;
import au.com.stgeorge.mbank.model.common.IMBReq;
import au.com.stgeorge.mbank.model.common.IMBResp;
import au.com.stgeorge.mbank.model.common.ReqHeader;
import au.com.stgeorge.mbank.model.common.RespHeader;
import au.com.stgeorge.mbank.model.request.SecureCodeReq;
import au.com.stgeorge.mbank.model.request.customer.ActivationReq;
import au.com.stgeorge.mbank.model.response.ErrorResp;
import au.com.stgeorge.mbank.session.GenericSessionFactory;
import au.com.stgeorge.mbank.session.IGenericSession;
import au.com.stgeorge.mbank.session.MobileSession;
import au.com.stgeorge.mbank.session.MobileSessionImpl;
import au.com.stgeorge.mbank.useragent.UserAgentParser;
import au.com.stgeorge.mbank.util.FraudLogger;
import au.com.stgeorge.mbank.util.MBAppConstants;
import au.com.stgeorge.mbank.util.MBAppHelper;
import au.com.stgeorge.mbank.util.MBAppUtils;
import au.com.stgeorge.mbank.util.MBAppValidator;
import au.com.stgeorge.mbank.util.ServiceConstants;
import au.com.stgeorge.mobilebank.businessobject.ActivationService;
import au.com.stgeorge.mobilebank.businessobject.MobileBankService;
import au.com.stgeorge.mobilebank.businessobject.MobileMsgCntrService;
import au.com.stgeorge.perflogger.PerformanceLogger;

import com.fasterxml.jackson.databind.ObjectMapper;

@Controller
@RequestMapping("/activation")
public class ActivationController implements IMBController
{

	private static final String ACTIVATE_SRV_NAME = "activate";

	private FraudLogger fraudLogger;
	
	@Autowired
	private SecureCodeHelper secureCodeHelper;

	@Autowired
	private MobileBankService mobileBankService;
	
	@Autowired
	private ActivationService activationService;
	

	@Autowired
	private MBAppHelper mbAppHelper;
	
	@Autowired
	private ActivationHelper activationHelper;

	@Autowired
	private MobileMsgCntrService msgCntrService;
	
	@Autowired
	private LogonHelper logonHelper;
	
	@Autowired
	private PerformanceLogger perfLogger;
	
	@Autowired
	private ServiceStation serviceStationService;
	
	@RequestMapping(value="activate", method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public IMBResp activateAccount(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse,
			@RequestBody final ActivationReq req)
	{
		Logger.debug("In activateAccount ( ActivationController )  for Customer " +  "  " + httpServletRequest.getContentType() + " "
				+ httpServletRequest.getRemoteAddr() + "  " + httpServletResponse.getCharacterEncoding() + httpServletResponse.getLocale() +
				" True IP >> " + httpServletRequest.getHeader(IBankParams.trueClientIP()), this.getClass());
		fraudLogger = new FraudLogger();
		perfLogger.startAllLogs();
		String logName = MBAppUtils.getLogName(httpServletRequest);
		perfLogger.startLog(logName);
		UserAgentParser bean = (UserAgentParser) ServiceHelper.getBean(ServiceConstants.USER_AGENT_PARSER);
		ObjectMapper mapper = new ObjectMapper();
		String origin = logonHelper.resolveOrigin(httpServletRequest);
		IGenericSession genericSession = null;
		
		try
		{
			ErrorResp errorResp = validate(req, httpServletRequest);
			if  (errorResp.hasErrors())
			{
				return errorResp;
			}
			String userAgent = httpServletRequest.getHeader("User-Agent");
			Logger.debug("Activation origin" + origin + ": User-Agent :" + userAgent, this.getClass());
			IBankCommonData ibankCommonData = new IBankCommonData();
			ibankCommonData.setUserAgent(userAgent);
			ibankCommonData.setIpAddress(MBAppHelper.resolveIPAddress(httpServletRequest, origin));
			ibankCommonData.setOrigin(origin);
			AuthenticationData authenticationData = populateAuthenticationData(req, origin, MBAppHelper.resolveIPAddress(httpServletRequest, origin));
			User user = activationService.authenticate(authenticationData);
			if(IBankParams.isStaffAssRegSwitchOn()){
				String autoInitStatus=(String)user.getAttribute(IBankParams.REG_STATUS);
				if(IBankParams.AUTO_INIT_ADMIN.equalsIgnoreCase(autoInitStatus)){
					Logger.warn("Trying to access activation in staff rego flow", getClass());
					throw new BusinessException(BusinessException.SYSTEM_UNAVILABLE);
				}
			}
			genericSession = logonHelper.createCompassSession(user, origin, "WebSrv", httpServletRequest);
			Logger.info("***User-Agent: " + userAgent.toLowerCase() + "***SessionId: " + genericSession.getId(), this.getClass());
			String tempStrSession = MBAppConstants.SMPL_SESS_CONSTANT + "=" + genericSession.getId()   + "; HttpOnly ; secure ;  path=/ "; //19E3 changed path to /
			httpServletResponse.setHeader("Set-Cookie", tempStrSession );

			authenticationData.setSessionId(genericSession.getId());
			ibankCommonData.setUser(user);
			String gdwOrigin  = logonHelper.getGDWOrigin( req.getHeader(),  origin);
			ibankCommonData.setGdwOrigin(gdwOrigin);
			Customer customer = mobileBankService.getCustomer(ibankCommonData);
			mbAppHelper.addSecurityLog(user, authenticationData);
			mbAppHelper.makeStatisticsLog(authenticationData, user, httpServletRequest);
			IMBResp serviceResponse = activationHelper.populateResponse(customer, user, origin, ServiceConstants.ACTIVATION_RESPONSE, httpServletRequest);
			genericSession.setAttribute(MobileSessionImpl.CUSTOMER_OBLECT, customer);
			genericSession.setAttribute(MobileSessionImpl.ORIGIN_OBLECT, origin);
			authenticationData.setUserAgent(replaceString(httpServletRequest.getHeader("user-agent")));
			authenticationData.setRefWebsite(httpServletRequest.getHeader("referer"));
			authenticationData.setSessionId(genericSession.getId());
			Logger.info("Activation JSON Response :" + mapper.writeValueAsString(serviceResponse), this.getClass());
			RespHeader headerResp = populateResponseHeader(ServiceConstants.ACTIVATION_RESPONSE, null);
			serviceResponse.setHeader(headerResp);
			setSecurityUniqueId( genericSession, headerResp);
			user.setAttribute(IBankParams.USEROBJ_BRAND,origin );
			return serviceResponse;
		} catch (BusinessException e)
		{
			Logger.error("Exception Inside activateAccount() for Customer ", e, this.getClass());
			BusinessException exp = new BusinessException(e.getKey());
			IMBResp resp1 = MBAppUtils.createErrorResp(origin, exp, MBAppConstants.SMPL_ACTIVATE_RESP_NAME, httpServletRequest);
			return resp1;
		} catch (Exception e)
		{
			Logger.error("Exception Inside activateAccount() for Customer ", e, this.getClass());
			BusinessException exp = new BusinessException(BusinessException.SMPL_SYS_ERROR);
			IMBResp resp1 = MBAppUtils.createErrorResp(origin, exp, MBAppConstants.SMPL_ACTIVATE_RESP_NAME, httpServletRequest);
			return resp1;
		} finally
		{
			if ( genericSession != null )
				genericSession.updateSession();
			perfLogger.endLog(logName);
			perfLogger.endAllLogs();
		}
	}

	@RequestMapping(value="reqSecureCode", method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public IMBResp reqActSecCode(HttpServletRequest httpRequest, HttpServletResponse httpServletResponse,
			@RequestBody final SecureCodeReq request)
	{
		Logger.debug("In reqSecCode ( ActivationController )  for Customer " +  "  " + httpRequest.getContentType() + " "
				+ httpRequest.getRemoteAddr() + "  " + httpServletResponse.getCharacterEncoding() + httpServletResponse.getLocale() +
				" True IP >> " + httpRequest.getHeader(IBankParams.trueClientIP()), this.getClass());
		fraudLogger = new FraudLogger();
		perfLogger.startAllLogs();
		MobileSession mbSession = null;
		String logName = MBAppUtils.getLogName(httpRequest);
		perfLogger.startLog(logName);
		ObjectMapper mapper = new ObjectMapper();
		String origin = logonHelper.resolveOrigin(httpRequest);
		IBankCommonData commonData = MBAppHelper.populateIBankCommonData(GenericSessionFactory.getInstance(httpRequest.getSession().getId()), origin,
				MBAppHelper.resolveIPAddress(httpRequest, origin));
		try {
			mbSession = new MobileSessionImpl();
			mbSession.getSessionContext(httpRequest);
			commonData.setCustomer(mbSession.getCustomer());
			validateRequestHeader(request.getHeader(), httpRequest);
			ErrorResp errorResponse = validate(request, httpRequest);
			if (errorResponse.hasErrors())
				return errorResponse;
			return secureCodeHelper.reqSecureCode(commonData, mbSession, mbSession.getTransaction(), request, ServiceConstants.ACTIVATE_SECURE_CODE_SERVICE, httpRequest);
		}
		catch (BusinessException e)
		{
			Logger.error("Exception Inside reqactseccode() for Customer ", e, this.getClass());
//			BusinessException exp = new BusinessException(e.getKey());
			IMBResp resp1 = MBAppUtils.createErrorResp( mbSession.getOrigin(), e, MBAppConstants.SMPL_ACTIVATE_RESP_NAME, httpRequest);
			return resp1;
		} catch (Exception e)
		{
			Logger.error("Exception Inside reqactseccode() for Customer ", e, this.getClass());
			BusinessException exp = new BusinessException(BusinessException.SMPL_SYS_ERROR);
			IMBResp resp1 = MBAppUtils.createErrorResp( mbSession.getOrigin(), exp, MBAppConstants.SMPL_ACTIVATE_RESP_NAME, httpRequest);
			return resp1;
		} finally
		{
			perfLogger.endLog(logName);
			perfLogger.endAllLogs();
		}
	}

	@RequestMapping(value="verifySecCode", method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public IMBResp verifySecAct(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse,
			@RequestBody final SecureCodeReq req)
	{
		Logger.debug("In verifysecact ( ActivationController )  for Customer " +  "  " + httpServletRequest.getContentType() + " "
				+ httpServletRequest.getRemoteAddr() + "  " + httpServletResponse.getCharacterEncoding() + httpServletResponse.getLocale() +
				" True IP >> " + httpServletRequest.getHeader(IBankParams.trueClientIP()), this.getClass());
		fraudLogger = new FraudLogger();
		perfLogger.startAllLogs();
		String logName = MBAppUtils.getLogName(httpServletRequest);
		perfLogger.startLog(logName);
		ObjectMapper mapper = new ObjectMapper();
		MobileSession mbSession = null;
		try
		{
//			Logger.info("verifysecact JSON Request :" + mapper.writeValueAsString(req), this.getClass());
			ErrorResp errorResp = validate(req, httpServletRequest);
			if (errorResp != null && errorResp.getErrors() != null && errorResp.getErrors().size() > 0)
			{
				return errorResp;
			}
			mbSession = mbAppHelper.getMobileSession(httpServletRequest);		
			mbSession.getSessionContext(httpServletRequest);
			IBankCommonData ibankCommonData = mbAppHelper.populateIBankCommonData(mbSession, httpServletRequest);
			ErrorResp errorResponse = secureCodeHelper.verifySecureCode(ibankCommonData, mbSession, mbSession.getTransaction(), req, ServiceConstants.ACTIVATE_SECURE_CODE_SERVICE, httpServletRequest);
			if (errorResponse.hasErrors())
				return errorResponse;
			IMBResp serviceResponse = activationHelper.populateSecureResponse();
			Logger.info("verifysecupddtls JSON Response :" + mapper.writeValueAsString(serviceResponse), this.getClass());
			RespHeader headerResp = populateResponseHeader(ServiceConstants.ACTIVATION_RESPONSE, mbSession  );
			serviceResponse.setHeader(headerResp);
			return serviceResponse;

		} catch (BusinessException e)
		{
			Logger.error("Exception Inside verifysecupddtls() for Customer ", e, this.getClass());
			IMBResp resp1 = MBAppUtils.createErrorResp( mbSession.getOrigin(), e, MBAppConstants.SMPL_ACTIVATE_RESP_NAME, httpServletRequest);
			return resp1;
		} catch (Exception e)
		{
			Logger.error("Exception Inside verifysecupddtls() for Customer ", e, this.getClass());
			BusinessException exp = new BusinessException(BusinessException.SMPL_SYS_ERROR);
			IMBResp resp1 = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, MBAppConstants.SMPL_ACTIVATE_RESP_NAME, httpServletRequest);
			return resp1;
		} finally
		{
			perfLogger.endLog(logName);
			perfLogger.endAllLogs();
		}
	}

	@RequestMapping(value="changePwdAndSecnum", method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public IMBResp actResetPwdSecNum(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse,
			@RequestBody final ActivationReq req)
	{
		Logger.debug("In reset pwd secnum( ActivationController )  for Customer " +  "  " + httpServletRequest.getContentType() + " "
				+ httpServletRequest.getRemoteAddr() + "  " + httpServletResponse.getCharacterEncoding() + httpServletResponse.getLocale() +
				" True IP >> " + httpServletRequest.getHeader(IBankParams.trueClientIP()), this.getClass());
		fraudLogger = new FraudLogger();
		perfLogger.startAllLogs();
		String logName = MBAppUtils.getLogName(httpServletRequest);
		perfLogger.startLog(logName);
		ObjectMapper mapper = new ObjectMapper();
		int unreadMsgCount = -1;
		MobileSession mbSession = null;AutoApplyRetentionInfo info=null;
		try
		{
			Logger.info("reset pwd secnum JSON Request :" , this.getClass());
			ErrorResp errorResp = validate(req, httpServletRequest);
			if (errorResp != null && errorResp.getErrors() != null && errorResp.getErrors().size() > 0)
			{
				return errorResp;
			}
			mbSession = mbAppHelper.getMobileSession(httpServletRequest);			
			mbSession.getSessionContext(httpServletRequest);
			User user=mbSession.getUser();
			IBankCommonData ibankCommonData = mbAppHelper.populateIBankCommonData(mbSession, httpServletRequest);
			activationService.setInitialPwdSecurityNumber(ibankCommonData, "Test Ref", req.getNewPassword(), req.getNewSecNum(), "RESMS");
			
			Customer customer=mbSession.getCustomer();
			if ( customer == null || StringMethods.isEmptyString( customer.getGcis() ) )
			{
				customer = mobileBankService.getCustomer(ibankCommonData);
				mbSession.setCustomer(customer);
				ibankCommonData.setCustomer(customer);
			}
			
			sendNotification(mbSession);
			boolean isECorrespondenceSupported = CommonBusinessUtil.isECorrespondenceSupported(httpServletRequest);
			unreadMsgCount = processMsgCentre(mbSession.getOrigin(),customer.getGcis(),isECorrespondenceSupported);
			// call service to get ServiceAdminVo
		    long insertionPt = logonHelper.getInsertionPointCode(ServicetationConstants.DASHBOARD);
			ServiceStationVO servicestationVO=populateServiceMessage(insertionPt,ServiceStationImpl.CHANNEL_MOBILE, ibankCommonData);
			if(null!=servicestationVO)
			{
				mbSession.setServiceStationDashboardMessage(servicestationVO.getServiceStationMsg());
			}
			mbSession.setLoggedonState(LogonHelper.LOGGEDON_STATE_COMPLETE);
			info=mbSession.getAutoApplyRetentionInfo();
			IMBResp serviceResponse = logonHelper.populateResponse(customer,user,unreadMsgCount, httpServletRequest , httpServletResponse, false,servicestationVO,info);
			Logger.info("reset pwd secnum JSON Response :" + mapper.writeValueAsString(serviceResponse), this.getClass());
			RespHeader headerResp = populateResponseHeader(req.getHeader().getServiceName(), mbSession);
			serviceResponse.setHeader(headerResp);
			return serviceResponse;

		} catch (BusinessException e)
		{
			Logger.error("Exception Inside reset password secnum for Customer ", e, this.getClass());
//			BusinessException exp = new BusinessException(e.getKey());
			IMBResp resp1 = MBAppUtils.createErrorResp(mbSession.getOrigin() , e, MBAppConstants.SMPL_CHANGEPWD_RESP_NAME, httpServletRequest);
			return resp1;
		} catch (Exception e)
		{
			Logger.error("Exception Inside reset pwd secnum for Customer ", e, this.getClass());
			BusinessException exp = new BusinessException(BusinessException.SMPL_SYS_ERROR);
			IMBResp resp1 = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, MBAppConstants.SMPL_CHANGEPWD_RESP_NAME, httpServletRequest);
			return resp1;
		} finally
		{
			perfLogger.endLog(logName);
			perfLogger.endAllLogs();
		}
	}
	private AuthenticationData populateAuthenticationData(ActivationReq req, String origin, String ipAddress)
	{
		AuthenticationData authenticationData = new AuthenticationData();
		authenticationData.setUserId(req.getAccessNumber());
		authenticationData.setPassword(req.getPassword());
		authenticationData.setOrigin(origin);
		authenticationData.setIpAddress(ipAddress);
		return authenticationData;
	}
	public String replaceString(String userAgent)
	{
		String data = userAgent;
		data = data.replaceAll("&", "&amp;");
		data = data.replaceAll("<", "&lt;");
		data = data.replaceAll(">", "&gt;");
		data = data.replaceAll("'", "&apos;");
		data = data.replaceAll("\"", "&quot;");
		return data;
	}
	public ErrorResp validate(IMBReq serviceRequest, HttpServletRequest httpServletRequest)
	{
		MBAppValidator mbAppValidator = new MBAppValidator();
		return mbAppValidator.validate(serviceRequest, httpServletRequest);
	}
	public void validateRequestHeader(ReqHeader header, HttpServletRequest request) throws ResourceException
	{
		MBAppValidator mbAppValidator = new MBAppValidator();
		mbAppValidator.validateRequestHeader(header,  request);
	}
	public RespHeader populateResponseHeader(String serviceName)
	{
		return mbAppHelper.populateResponseHeader(serviceName);
		
	}
	
	private  void sendNotification(MobileSession mobSession) throws ResourceException, BusinessException 
	{
		try{
			User user = mobSession.getUser();
			EmailDetails emailDet = new EmailDetails();
			String emailAddr = null;
			emailDet.setBrand(mobSession.getOrigin());
			emailDet.setActionType(EmailDetails.ACTIV_ACTION);
			emailAddr = mobSession.getCustomer().getContactDetail().getEmail();
			
			if (!StringMethods.isEmptyString(emailAddr)) {
				emailDet.setEmailAddress(emailAddr);
				emailDet.setGcisNumber(user.getGCISNumber());
				EmailService emailService = (EmailService) ServiceHelper.getBean("emailService");
				emailService.sendAlerts(emailDet);
			}
		}catch (Exception e){
			Logger.error("Error Sending Activation email :" + e.getMessage(), ActivationHelper.class);
		}
	}	
	
	//Create new branded messages for customer & return an unread count
	private int processMsgCentre(String origin, String gcisNum,boolean isECorrespondenceSupported) throws BusinessException, ResourceException{
		
		int unreadMsgCount = -1;
		
		if (HeartBeat.isApplicationAvailable(HeartBeat.MSGCENTRE_APPLICATION_ID)) {
			
			OriginsVO originVO= IBankParams.getOrigin(origin);
			msgCntrService.addBrandCustMsg(originVO.getBankName(),gcisNum);
			unreadMsgCount = msgCntrService.findMobCustMsgUnreadCount(gcisNum,isECorrespondenceSupported,origin);				
		}
		
		return unreadMsgCount;
	}
	
	public RespHeader populateResponseHeader(String serviceName, MobileSession mobSession )
	{
		return mbAppHelper.populateResponseHeader(serviceName, mobSession);
	}

	private void setSecurityUniqueId (IGenericSession genericSession , RespHeader headerResp )
	{
		String newNameId = mbAppHelper.getSecurityUniqueID();
		headerResp.setNameId(newNameId);
		genericSession.setAttribute(MobileSessionImpl.SECURITY_UNIQUE_ID, newNameId);
	}
	
	private ServiceStationVO populateServiceMessage(long insertionPoint,String channel, IBankCommonData commonData)
	{
		ServiceStationVO serviceStationAdminVo=null;
		try
		{
		 serviceStationAdminVo= serviceStationService.getServiceMessage(insertionPoint, ServiceStationImpl.CHANNEL_MOBILE, commonData);			
		}
		 catch(BusinessException ex){
			Logger.error("An error occurred while getting service station message for mobile accoutn details", ex, this.getClass());
		}
		return serviceStationAdminVo;
	}
	
}
