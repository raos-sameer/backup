package au.com.stgeorge.mbank.model.request.newaccount;

import java.io.Serializable;

import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.NotEmpty;

import au.com.stgeorge.ibank.businessobject.BusinessException;
import au.com.stgeorge.mbank.model.common.IMBReq;
import au.com.stgeorge.mbank.model.common.ReqHeader;

public class GlobalWalletPurseTransferReq implements IMBReq, Serializable {
	private static final long serialVersionUID = 1443800813031317764L;
	private ReqHeader header;
	
	//@NotEmpty(message = "" + BusinessException.GLOBAL_WALLET_PURSE_TRANSFER_SVC_UNAVAILABLE)
	//@Pattern(regexp = "^[0-9]*$", message = "" + BusinessException.GLOBAL_WALLET_PURSE_TRANSFER_SVC_UNAVAILABLE) //^(0|[1-9][0-9]*)$
	private Integer accountIndex;

	@NotEmpty(message = "" + BusinessException.GLOBAL_WALLET_PURSE_TRANSFER_SVC_UNAVAILABLE)
	private String fromCurrencyCode; //Debit Currency

	@NotEmpty(message = "" + BusinessException.GLOBAL_WALLET_PURSE_TRANSFER_SVC_UNAVAILABLE)
	private String toCurrencyCode; //Credit Currency

	@NotEmpty(message = "" + BusinessException.GLOBAL_WALLET_PURSE_TRANSFER_SVC_UNAVAILABLE)
	//@Pattern(regexp = "([0-9]+[.]?[0-9]?[0-9]?)", message = "" + BusinessException.GLOBAL_WALLET_PURSE_TRANSFER_SVC_UNAVAILABLE)
	private String exchangeRate;

	@NotEmpty(message = "" + BusinessException.GLOBAL_WALLET_PURSE_TRANSFER_SVC_UNAVAILABLE)
	@Pattern(regexp = "([0-9]+[.]?[0-9]?[0-9]?)", message = "" + BusinessException.GLOBAL_WALLET_PURSE_TRANSFER_SVC_UNAVAILABLE)
	private String transferAmt; //Debit Amt

	@NotEmpty(message = "" + BusinessException.GLOBAL_WALLET_PURSE_TRANSFER_SVC_UNAVAILABLE)
	@Pattern(regexp = "([0-9]+[.]?[0-9]?[0-9]?)", message = "" + BusinessException.GLOBAL_WALLET_PURSE_TRANSFER_SVC_UNAVAILABLE)
	private String exchangeAmt; //Credit Amt

	public ReqHeader getHeader() {
		return header;
	}

	public void setHeader(ReqHeader header) {
		this.header = header;
	}

	public Integer getAccountIndex() {
		return accountIndex;
	}

	public void setAccountIndex(Integer accountIndex) {
		this.accountIndex = accountIndex;
	}

	public String getFromCurrencyCode() {
		return fromCurrencyCode;
	}

	public void setFromCurrencyCode(String fromCurrencyCode) {
		this.fromCurrencyCode = fromCurrencyCode;
	}

	public String getToCurrencyCode() {
		return toCurrencyCode;
	}

	public void setToCurrencyCode(String toCurrencyCode) {
		this.toCurrencyCode = toCurrencyCode;
	}

	public String getExchangeRate() {
		return exchangeRate;
	}

	public void setExchangeRate(String exchangeRate) {
		this.exchangeRate = exchangeRate;
	}

	public String getTransferAmt() {
		return transferAmt;
	}

	public void setTransferAmt(String transferAmt) {
		this.transferAmt = transferAmt;
	}

	public String getExchangeAmt() {
		return exchangeAmt;
	}

	public void setExchangeAmt(String exchangeAmt) {
		this.exchangeAmt = exchangeAmt;
	}

}
