package au.com.stgeorge.mbank.model.request.mortgage;

import java.io.Serializable;
import java.util.List;

import javax.validation.Valid;
import au.com.stgeorge.mbank.model.common.IMBReq;
import au.com.stgeorge.mbank.model.common.ReqHeader;
import au.com.stgeorge.mbank.model.mortgageinfo.DocUploadInfo;

public class DocUploadDetailReq implements IMBReq, Serializable{

	private static final long serialVersionUID = -3957399316805322647L;
	private ReqHeader header;
	@Valid
	private List<DocUploadInfo> docUploadInfoList;
	
	public List<DocUploadInfo> getDocUploadInfoList() {
		return docUploadInfoList;
	}

	public void setDocUploadInfoList(List<DocUploadInfo> docUploadInfoList) {
		this.docUploadInfoList = docUploadInfoList;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public ReqHeader getHeader() {
		return header;
	}

	public void setHeader(ReqHeader header) {
		this.header = header;
	}

}
