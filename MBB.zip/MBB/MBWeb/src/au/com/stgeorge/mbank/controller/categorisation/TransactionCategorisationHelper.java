/**
 * 
 */
package au.com.stgeorge.mbank.controller.categorisation;

import java.math.BigDecimal;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;

import au.com.stgeorge.framework.common.logging.Logger;
import au.com.stgeorge.framework.common.util.StringMethods;
import au.com.stgeorge.ibank.businessobject.MerchantTransactionInfoService;
import au.com.stgeorge.ibank.npp.NPPReturnEnum;
import au.com.stgeorge.ibank.servicestation.businessobject.ServiceStation;
import au.com.stgeorge.ibank.servicestation.businessobject.ServiceStationImpl;
import au.com.stgeorge.ibank.servicestation.businessobject.valueobject.ServiceStationVO;
import au.com.stgeorge.ibank.servicestation.util.ServicetationConstants;
import au.com.stgeorge.ibank.util.ServiceHelper;
import au.com.stgeorge.ibank.valueobject.TranHistoryByMonth;
import au.com.stgeorge.ibank.valueobject.TransactionHistory;
import au.com.stgeorge.ibank.valueobject.TransactionInfo;
import au.com.stgeorge.ibank.valueobject.transfer.IBankCommonData;
import au.com.stgeorge.mbank.controller.accountinfo.AccountInfoHelper;
import au.com.stgeorge.mbank.model.accountinfo.MonthsInfo;
import au.com.stgeorge.mbank.model.accountinfo.TranCategory;
import au.com.stgeorge.mbank.model.accountinfo.TranCategoryDetailInfo;
import au.com.stgeorge.mbank.model.accountinfo.TranCategoryInfo;
import au.com.stgeorge.mbank.model.accountinfo.TranCategoryList;
import au.com.stgeorge.mbank.model.accountinfo.TranDetailResp;
import au.com.stgeorge.mbank.model.accountinfo.TranHistoryResp;
import au.com.stgeorge.mbank.model.common.IMBResp;
import au.com.stgeorge.mbank.model.response.categoriation.TranCategorisationResp;
import au.com.stgeorge.mbank.model.response.servicestation.ServiceStationResp;
import au.com.stgeorge.mbank.session.MobileSession;
import au.com.stgeorge.tranhistory.valueobject.TranCategorisationDetailVO;
import au.com.stgeorge.tranhistory.valueobject.TranCategorisationInfoVO;
import au.com.stgeorge.tranhistory.valueobject.TranCategoryVO;
import au.com.stgeorge.tranhistory.valueobject.TranSubCategoryVO;


/**
 * @author C50216
 *
 */
@Service
public class TransactionCategorisationHelper {

	protected IMBResp populateResp(MobileSession mbSession , TransactionHistory trxnHist, TranCategorisationDetailVO tranCategorisationDetail, Map<Integer,Date> monthsList, IBankCommonData commonData, String accountType) {		
		TranCategorisationResp tranCategorisationResp = new TranCategorisationResp();

		if(trxnHist != null){
		populateAcctHistoryResp(tranCategorisationResp, trxnHist, accountType);
		}
		if(tranCategorisationDetail != null){
		populateTranCategorisationResp(tranCategorisationResp, tranCategorisationDetail);
		}
		if(monthsList != null && monthsList.size() > 0){
			populateMonthData(tranCategorisationResp, monthsList);
		}
		
    	 ServiceStationResp serviceStationResp = getServiceStationResp( mbSession ,  commonData );
		
    	 if ( serviceStationResp != null  )
    	 {
    		 tranCategorisationResp.setServiceStation(serviceStationResp);
    	 }
		
		return tranCategorisationResp;

	}	
	
	protected void populateAcctHistoryResp(TranCategorisationResp resp,TransactionHistory trxnHist, String accountType){
		
		if(trxnHist != null && trxnHist.getTransactions() != null){
			TranHistoryResp histResp = new TranHistoryResp();
			histResp.setTranList(getTrxnHistoryResp(trxnHist, accountType));
			
			if(("Y").equalsIgnoreCase(trxnHist.getMoreToCome()))
				histResp.setHasMoreTran(true);					
			
			resp.setTranHistory(histResp);			
		}
	}
	
	protected void populateMonthData(TranCategorisationResp resp,Map<Integer,Date> monthsList){
		
		if(monthsList != null && monthsList.size() > 0){
			List<MonthsInfo> months =  new ArrayList<MonthsInfo>(); 
			MonthsInfo eachMonth = null;
			Iterator it = monthsList.entrySet().iterator();
			while(it.hasNext()){
				eachMonth = new MonthsInfo();
				Map.Entry month =(Map.Entry)it.next();
				if(month.getKey() != null && month.getValue() != null){
					eachMonth.setId(Integer.parseInt(month.getKey().toString()));
					
					Date startdate = (Date) month.getValue();
					DateFormat DATE_FORMATTER =  new SimpleDateFormat("MMMM yyyy");
					
					eachMonth.setName(DATE_FORMATTER.format(startdate).toString());
					months.add(eachMonth);
				}
				
			}
			
			
			/*
			 
			while (iterator.hasNext()) {
			java.util.Map.Entry me = (java.util.Map.Entry) iterator.next();
			String chainId = (String) me.getValue();
			String key = (String) me.getKey();*/
			
			//resp.setTranHistory(histResp);	
			resp.setMonths(months);
		}
	}
	
	
	
	
	private List<TranDetailResp> getTrxnHistoryResp(TransactionHistory trxnHist, String accountType){
		List<TranDetailResp> trxnHistList = null; 
		
		TranDetailResp tranDet;
		MerchantTransactionInfoService merchantTransactionInfoService = ServiceHelper.getBean("merchantTransactionInfoService");
		if(trxnHist != null && trxnHist.getTransactions().size() > 0 ){
			trxnHistList = new ArrayList<TranDetailResp>();
			ArrayList list=(ArrayList)trxnHist.getTransactions();
			Iterator it = list.iterator();
			while(it.hasNext()){
				tranDet = new TranDetailResp();
				TransactionInfo eachTransactionInfo=(TransactionInfo)it.next();
				tranDet.setDate(eachTransactionInfo.getDate());
				
				if(StringMethods.isValidString(eachTransactionInfo.getDescription1()))					
					tranDet.setDesc(eachTransactionInfo.getDescription1());				
	
				if(StringMethods.isValidString(eachTransactionInfo.getDescription2()))
					tranDet.setDesc2(eachTransactionInfo.getDescription2());
				
				//17E3 Transaction Categorisation : updating tranHistory with Category, SubCategory and iconName.
				tranDet.setIconName(eachTransactionInfo.getIconName());
				tranDet.setTranCategory(eachTransactionInfo.getTranCategory());
				tranDet.setTranCategoryId(eachTransactionInfo.getTranCategoryId());
				tranDet.setTranSubCategory(eachTransactionInfo.getTranSubCategory());
				
				//17E4 Google Search.
				tranDet.setSearchFlag(eachTransactionInfo.getSearchFlag());
				tranDet.setSearchString(eachTransactionInfo.getSearchString());
				tranDet.setpRPaymentId(eachTransactionInfo.getpRPaymentId());

				String nppTranType = NPPReturnEnum.getNppTranType(eachTransactionInfo.getBranchTranCode(),eachTransactionInfo.getMicrCode(),eachTransactionInfo.getUserID());
				tranDet.setNppTranType(nppTranType);
				
				tranDet.setEffectiveDate(eachTransactionInfo.getEffectiveDate());
				
				String amtValue = "";
				BigDecimal amount=eachTransactionInfo.getAmount();
				if (amount !=null){
					if (amount.signum() == -1) {
						tranDet.setDebit(true);
						BigDecimal negatedAmt = amount.negate();
						amtValue=negatedAmt.toString();
					}
					else{
						amtValue=amount.toString();
					}
				}
				tranDet.setAmt(amtValue);	
				
				tranDet.setLwcDesc(merchantTransactionInfoService.populateLWCTranDesc(eachTransactionInfo, accountType));
				
				trxnHistList.add(tranDet);
			}
		}
		
		return trxnHistList;
	}
	protected void populateTranCategorisationResp(TranCategorisationResp tranCategorisationResp, TranCategorisationDetailVO tranCategorisationDetail){
		List<TranCategoryInfo> trxnHistList = null; 
		List<TranCategoryDetailInfo> trxnSubList = null;
		TranCategoryInfo tranDet;
		TranCategoryDetailInfo tranSubDet;
		TranCategoryList categoryList = null;
		
		if(tranCategorisationDetail.getDebit() != null){
			
			if(categoryList == null){
				categoryList = new TranCategoryList();
			}
			TranCategorisationInfoVO infoVO = tranCategorisationDetail.getDebit();
			TranCategory categories = new TranCategory();
			categories.setTotal(infoVO.getAmount().toString());
			categories.setPercentage(infoVO.getCatPercentage().toString());
			
			if(infoVO.getTranCategories() != null && infoVO.getTranCategories().size() > 0 ){
				trxnHistList = new ArrayList<TranCategoryInfo>();
				Iterator it = infoVO.getTranCategories().iterator();
				while(it.hasNext()){
					tranDet = new TranCategoryInfo();
					TranCategoryVO eachTransactionInfo=(TranCategoryVO)it.next();
					tranDet.setName(eachTransactionInfo.getName());
					tranDet.setAmount(eachTransactionInfo.getAmount().toString());
					tranDet.setImageId(eachTransactionInfo.getImageId());
					tranDet.setPercentage(eachTransactionInfo.getCatPercentage().toString());
					if(eachTransactionInfo.getTranSubCategoryVO() != null && eachTransactionInfo.getTranSubCategoryVO().size() > 0){
						trxnSubList = new ArrayList<TranCategoryDetailInfo>();
						Iterator subCateInfo = eachTransactionInfo.getTranSubCategoryVO().iterator();
						while(subCateInfo.hasNext()){
							tranSubDet = new TranCategoryDetailInfo();
							TranSubCategoryVO eachSubTransactionInfo=(TranSubCategoryVO)subCateInfo.next();
							tranSubDet.setName(eachSubTransactionInfo.getName());
							tranSubDet.setAmount(eachSubTransactionInfo.getAmount().toString());
							tranSubDet.setPercentage(eachSubTransactionInfo.getSubCatPercentage().toString());
							trxnSubList.add(tranSubDet);
						}
						tranDet.setSubCategories(trxnSubList);
					}
					
					
					trxnHistList.add(tranDet);
				}
				categories.setCategoryList(trxnHistList);				
			}	
			categoryList.setDebit(categories);
		}
		
		if(tranCategorisationDetail.getCredit() != null){
			
			if(categoryList == null){
				categoryList = new TranCategoryList();
			}
			TranCategorisationInfoVO infoVO = tranCategorisationDetail.getCredit();
			TranCategory categories = new TranCategory();
			categories.setTotal(infoVO.getAmount().toString());
			categories.setPercentage(infoVO.getCatPercentage().toString());
			
			if(infoVO.getTranCategories() != null && infoVO.getTranCategories().size() > 0 ){
				trxnHistList = new ArrayList<TranCategoryInfo>();
				Iterator it = infoVO.getTranCategories().iterator();
				while(it.hasNext()){
					tranDet = new TranCategoryInfo();
					TranCategoryVO eachTransactionInfo=(TranCategoryVO)it.next();
					tranDet.setName(eachTransactionInfo.getName());
					tranDet.setAmount(eachTransactionInfo.getAmount().toString());
					tranDet.setImageId(eachTransactionInfo.getImageId());
					tranDet.setPercentage(eachTransactionInfo.getCatPercentage().toString());
					if(eachTransactionInfo.getTranSubCategoryVO() != null && eachTransactionInfo.getTranSubCategoryVO().size() > 0){
						trxnSubList = new ArrayList<TranCategoryDetailInfo>();
						Iterator subCateInfo = eachTransactionInfo.getTranSubCategoryVO().iterator();
						while(subCateInfo.hasNext()){
							tranSubDet = new TranCategoryDetailInfo();
							TranSubCategoryVO eachSubTransactionInfo=(TranSubCategoryVO)subCateInfo.next();
							tranSubDet.setName(eachSubTransactionInfo.getName());
							tranSubDet.setAmount(eachSubTransactionInfo.getAmount().toString());
							tranSubDet.setPercentage(eachSubTransactionInfo.getSubCatPercentage().toString());
							trxnSubList.add(tranSubDet);
						}
						tranDet.setSubCategories(trxnSubList);
					}
					
					
					trxnHistList.add(tranDet);
				}
				categories.setCategoryList(trxnHistList);				
			}	
			categoryList.setCredit(categories);
		}
		
		if(categoryList != null){
		tranCategorisationResp.setCategories(categoryList);
		}
	}
	
	
	private ServiceStationResp getServiceStationResp(MobileSession mbSession , IBankCommonData commonData )
	{
		try
		{
			AccountInfoHelper accountInfoHelper = ServiceHelper.getBean("accountInfoHelper");
			long insertionPt = accountInfoHelper.getInsertionPointCode(ServicetationConstants.TRAN_CATEGARISATION);
			ServiceStation serviceStationService = ServiceHelper.getBean("serviceStationService");
			ServiceStationVO serviceStationVo = serviceStationService.getServiceMessage(insertionPt, ServiceStationImpl.CHANNEL_MOBILE, commonData);					
			if(null!=serviceStationVo)
			{
				mbSession.setServiceStationAccountDetailMessage(serviceStationVo.getServiceStationMsg());
			}					
			ServiceStationResp resp = accountInfoHelper.populateServiceStationResp(serviceStationVo);
			return resp;
			
		}
		catch( Exception e)
		{
			Logger.info("getServiceStationResp Failed", e , this.getClass());
			return null;
		}
	}

	public static String DATE_MMYYYY = "MMyyyy";
	public TranHistoryByMonth getTranHistForMonthFromSession(Date fromDateStart,MobileSession mbSession )
	{
		
		
		String parammmYYYY = new SimpleDateFormat(DATE_MMYYYY).format(fromDateStart);

		Collection<TranHistoryByMonth> tranHistByMonth = mbSession.getTranHistoryByMonthList();
		Logger.debug("setTranHistForMonthInSession. Month Key : " + parammmYYYY  , this.getClass());
		
		if ( tranHistByMonth == null )
		{
			return null;
		}  
		TranHistoryByMonth sessTranHistoryByMonth = null;
		if ( tranHistByMonth != null & tranHistByMonth.size() > 0 )
		{
			Iterator iterator =tranHistByMonth.iterator();
			while (iterator.hasNext() )
			{
				TranHistoryByMonth tranHistoryByMonth = (TranHistoryByMonth) iterator.next();
				if ( parammmYYYY.equalsIgnoreCase(tranHistoryByMonth.getMonthYYYY() ) && "F".equalsIgnoreCase(tranHistoryByMonth.getStatus())   )
				{
					Logger.debug("Already In Session. Month Key : " + parammmYYYY  , this.getClass());
					sessTranHistoryByMonth = tranHistoryByMonth;
					break;
				}
				else if ( parammmYYYY.equalsIgnoreCase(tranHistoryByMonth.getMonthYYYY() ) && "P".equalsIgnoreCase(tranHistoryByMonth.getStatus())   )
				{
					Logger.debug("Already In Session. Month Key : " + parammmYYYY  , this.getClass());
					sessTranHistoryByMonth = tranHistoryByMonth;
					break;
				}
				
			}
		}

		return sessTranHistoryByMonth;
	}

	public void updateTransactionHistoryInSession(TranHistoryByMonth tranHistoryByMonth , Date date , TransactionHistory transactionHistory, MobileSession mbSession)
	{
		
		mbSession.setTransHistFlag("Y");
		String tranDate = new SimpleDateFormat(DATE_MMYYYY).format(date);

		Logger.debug("Adding New entry in Session. Month Key : " + tranDate + " From date : " + date , this.getClass());
		if ( tranHistoryByMonth == null )
		 tranHistoryByMonth = new TranHistoryByMonth();
		tranHistoryByMonth.setMonthYYYY(tranDate);
//		Date tempDate = DateMethods.getUtilDateTime(labelValueVO.getLabel(), DATE_DDMMYYYY);
		tranHistoryByMonth.setFromDate(date);
		tranHistoryByMonth.setStatus("F");
		tranHistoryByMonth.setTransactionHistory(transactionHistory);
		if ( mbSession.getTranHistoryByMonthList() == null )
		{
			ArrayList<TranHistoryByMonth> arrList = new ArrayList<TranHistoryByMonth>();
			mbSession.setTranHistoryByMonthList(arrList);
			
		}
		ArrayList<TranHistoryByMonth> arrList = ( ArrayList<TranHistoryByMonth> ) mbSession.getTranHistoryByMonthList();
		arrList.add(tranHistoryByMonth);
		mbSession.setTranHistoryByMonthList(arrList);
	}

	
	
}