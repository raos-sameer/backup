package au.com.stgeorge.mbank.model.common;

import java.io.Serializable;

public interface IMBResp extends Serializable {

	public RespHeader getHeader();

	public void setHeader(RespHeader header);

}
