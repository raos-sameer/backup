package au.com.stgeorge.mbank.controller.newaccount;

import java.io.InputStream;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import org.w3c.dom.Document;
import javax.xml.bind.Unmarshaller;

public class NewAcctStructureLocator
{	
	private Unmarshaller unmarshaller;
	private String newAcctXMLConfig;

	private NewAcctStructure newAcctStructure;

	public void initStructures() throws Exception
	{
		
		InputStream newAccountsIs = null;

		try
		{			
			ClassLoader classLoader = getClass().getClassLoader();			
			newAccountsIs = classLoader.getResourceAsStream(newAcctXMLConfig);
			DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();	
			//set below to avoid security defects
			dbf.setFeature("http://xml.org/sax/features/external-general-entities", false);
			dbf.setFeature("http://xml.org/sax/features/external-parameter-entities", false);
			dbf.setXIncludeAware(false);
		    dbf.setExpandEntityReferences(false);
		    dbf.setFeature("http://javax.xml.XMLConstants/feature/secure-processing", true);
		    
			DocumentBuilder db = dbf.newDocumentBuilder();
			Document document = db.parse(newAccountsIs);
			newAcctStructure = (NewAcctStructure) unmarshaller.unmarshal(document);			
						
		} finally
		{
		
			
			if (newAccountsIs != null)
			{
				newAccountsIs.close();
			}
		
		}
	}

	public NewAcctStructure getNewAcctStructure()
	{
		return newAcctStructure;
	}



	public void setNewAcctXMLConfig(String newAcctXMLConfig)
	{
		this.newAcctXMLConfig = newAcctXMLConfig;
	}


	public void setUnmarshaller(Unmarshaller unmarshaller) {
		this.unmarshaller = unmarshaller;
	}

	public String geNewAcctXMLConfig() {
		return newAcctXMLConfig;
	}

	

}

