package au.com.stgeorge.mbank.controller.payments;

import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import au.com.stgeorge.framework.common.logging.Logger;
import au.com.stgeorge.ibank.businessobject.BusinessException;
import au.com.stgeorge.ibank.businessobject.ResourceException;
import au.com.stgeorge.ibank.businessobject.TTService;
import au.com.stgeorge.ibank.common.cache.IBankParams;
import au.com.stgeorge.ibank.common.log.IBankLog;
import au.com.stgeorge.ibank.valueobject.Account;
import au.com.stgeorge.ibank.valueobject.Address;
import au.com.stgeorge.ibank.valueobject.Currency;
import au.com.stgeorge.ibank.valueobject.Customer;
import au.com.stgeorge.ibank.valueobject.OverseaBank;
import au.com.stgeorge.ibank.valueobject.OverseasTTBeneficiary;
import au.com.stgeorge.ibank.valueobject.Payment;
import au.com.stgeorge.ibank.valueobject.Receipt;
import au.com.stgeorge.ibank.valueobject.TTDuplicateVO;
import au.com.stgeorge.ibank.valueobject.TTPurposeCode;
import au.com.stgeorge.ibank.valueobject.TTReceipt;
import au.com.stgeorge.ibank.valueobject.TelegraphicTransfer;
import au.com.stgeorge.ibank.valueobject.database.CodesVO;
import au.com.stgeorge.ibank.valueobject.transfer.IBankCommonData;
import au.com.stgeorge.mbank.model.common.AddressResp;
import au.com.stgeorge.mbank.model.common.ErrorInfo;
import au.com.stgeorge.mbank.model.common.IMBResp;
import au.com.stgeorge.mbank.model.common.RespHeader;
import au.com.stgeorge.mbank.model.request.payments.TTGetFeeDetailReq;
import au.com.stgeorge.mbank.model.request.payments.TTTransferReq;
import au.com.stgeorge.mbank.model.response.payments.DuplicatePaymentResp;
import au.com.stgeorge.mbank.model.response.payments.TTBeneficiariesResp;
import au.com.stgeorge.mbank.model.response.payments.TTBeneficiaryResp;
import au.com.stgeorge.mbank.model.response.payments.TTCountryCurrencyResp;
import au.com.stgeorge.mbank.model.response.payments.TTCurrencyResp;
import au.com.stgeorge.mbank.model.response.payments.TTFeeDetailResp;
import au.com.stgeorge.mbank.model.response.payments.TransferResp;
import au.com.stgeorge.mbank.util.MBAppHelper;
import au.com.stgeorge.mbank.util.MBAppUtils;
import au.com.stgeorge.mobilebank.businessobject.OverseasTransService;
import au.com.stgeorge.wmqi.schema.financial.telgrphctrnsfrordtrnsctn.Charge;
import au.com.stgeorge.wmqi.schema.financial.telgrphctrnsfrordtrnsctn.OseasBankCharge;

/**
 * Overseas Telegraphic Transfer Helper
 * 
 * @author C38854
 * 
 */

@Service
public class TTHelper extends TransferHelper {

	private static final String STAFF_ACCOUNT = "S";
	private static final int TT_SENDER_NAME_LENGTH = 35;
	private final static String TT_DESC = "Telegraphic Transfer";
	private final static String TT_OSEAS_CHARGE_CODE_SHR = "SHA";
	public static final String AMOUNT_FORMAT = "$#,###,###,##0.00";
	public static final String FOREX_AMOUNT_FORMAT = "#,###,###,##0.00";
	private static final String CURRENCY_CODE_AUD = "AUD";
	private static final String CURRENCY_CODE_NONAUD = "NONAUD";
	
	@Autowired
	private TTService ttService;
	
	@Autowired
	private OverseasTransService overseasTransService;

	/**
	 * Populate beneficiaries response - service response
	 * 
	 * @param header
	 * @param beneficiaries
	 * @return
	 */
	protected TTBeneficiariesResp populateBeneficiariesResponse(RespHeader header, List<OverseasTTBeneficiary> beneficiaries) {
		TTBeneficiariesResp response = new TTBeneficiariesResp(header);
		List<TTBeneficiaryResp> benes = new ArrayList<TTBeneficiaryResp>();
		for (OverseasTTBeneficiary beneficiary : beneficiaries) {
			TTBeneficiaryResp ben = new TTBeneficiaryResp();
			ben.setBankAddress(beneficiary.getBankAddress());
			ben.setBankCity(beneficiary.getBankCity());
			ben.setBankCountry(beneficiary.getBankCountry());
			ben.setBankName(beneficiary.getBankName());
			ben.setBankNumber(beneficiary.getBankNo());
			ben.setBankSwiftBicCode(beneficiary.getSwiftBic());
			ben.setBeneficiaryAccountNum(beneficiary.getAccountNo());
			ben.setBeneficiaryAddress(beneficiary.getAddress1());
			ben.setBeneficiaryAlias(beneficiary.getAlias());
			ben.setBeneficiaryCity(beneficiary.getAddress2());
			ben.setBeneficiaryCountry(beneficiary.getCountry());
			ben.setBeneficiaryName(beneficiary.getName());
			ben.setBeneficiaryId(beneficiary.getId());
			
			//18E4 - Tech Debt to populate country codes
			ben.setBeneficiaryCountryCode(beneficiary.getCountryCode());
			ben.setBankCountryCode(beneficiary.getBankCountryCode());
			
			benes.add(ben);
		}
		response.setBeneficiaries(benes);
		Logger.info("Response: " + response, this.getClass());
		return response;
	}

	/**
	 * Populate country - currencies response - service response
	 * 
	 * @param header
	 * @param beneficiaries
	 * @return
	 */
	protected TTCountryCurrencyResp populateCountryCurrenciesResponse(String origin, RespHeader header, String defaultCurrency,
			List<Currency> currencies, List<TTPurposeCode> paymentReasons, Address senderAddress) {
		TTCountryCurrencyResp response = new TTCountryCurrencyResp(header);
		List<TTCurrencyResp> currenciesList = new ArrayList<TTCurrencyResp>();
		for (Currency currency : currencies) {
			TTCurrencyResp ttCurrency = new TTCurrencyResp();
			ttCurrency.setCode(currency.getCurrencyCode());
			ttCurrency.setName(currency.getDescription());
			ttCurrency.setIsNonDecimal(isNoDecimalCurrency(origin, currency.getCurrencyCode()));
			ttCurrency.setRate(currency.getSellRate());

			currenciesList.add(ttCurrency);
		}
		response.setCurrencies(currenciesList);
		
		response.setPurposeCodes(paymentReasons);

		AddressResp address = new AddressResp();
		address.setAddrType("RES");
		address.setCountryName(senderAddress.getCountryName());
		address.setLine1(senderAddress.getLine1());
		address.setLine2(senderAddress.getLine2());
		address.setLine3(senderAddress.getLine3());
		address.setPostCode(senderAddress.getPostZipcode());
		address.setState(senderAddress.getState());
		address.setSuburb(senderAddress.getSuburb());
		response.setSenderAddress(address);

		response.setDefaultCurrency(defaultCurrency);
		
		Logger.info("Response: " + response, this.getClass());
		return response;
	}

	private boolean isNoDecimalCurrency(String origin, String currCode) {
		try {
			CodesVO myCodesVO = IBankParams.getCodesData(origin, IBankParams.TT_NONDEC_CURRENCY, currCode);
			IBankLog.logTRC("No Decimal Currency " + myCodesVO.getMessage(), this.getClass());
			return true;
		} catch (Exception e) {
			return false;
		}

	}

	/**
	 * Populate fee details response
	 * 
	 * @param header
	 * @param fee
	 * @param totalAmt
	 * @return
	 */
	protected IMBResp populateFeeDetailResponse(String origin, Customer customer, RespHeader header, String fee, String totalAmt) {
		TTFeeDetailResp response = new TTFeeDetailResp(header);
		response.setFee(fee);
		response.setTotalAmt(totalAmt);

		Address customerAddress = customer.getContactDetail().getResidentialAddress();
		if (customerAddress == null) {
			List<ErrorInfo> errorList;
			if (customer.isGHSCustomer()) {
				IBankLog.logERR("TT_ALREADY_REG_WITH_POBOX_GHS", getClass());
				errorList = MBAppUtils.getErrorList(origin, BusinessException.TT_ALREADY_REG_WITH_POBOX_GHS, MBAppUtils.getMessage(origin,
						BusinessException.TT_ALREADY_REG_WITH_POBOX_GHS));

			} else {
				IBankLog.logERR("TT_ALREADY_REG_WITH_POBOX", getClass());
				errorList = MBAppUtils.getErrorList(origin, BusinessException.TT_ALREADY_REG_WITH_POBOX_GHS, MBAppUtils.getMessage(origin,
						BusinessException.TT_ALREADY_REG_WITH_POBOX));
			}

			response.setErrors(errorList);
		} else if (isPoboxAddress(customerAddress)) {
			List<ErrorInfo> errorList = MBAppUtils.getErrorList(origin, BusinessException.TT_PO_BOX_INVALID, MBAppUtils.getMessage(origin,
					BusinessException.TT_PO_BOX_INVALID));
			response.setErrors(errorList);
		}

		return response;
	}

	private boolean isPoboxAddress(Address address) {
		String addressLine1 = address.getLine1();
		String addressLine2 = address.getLine2();
		String addressLine3 = address.getLine3();
		return ((addressLine1 != null && addressLine1.length() > 0 || addressLine2 != null && addressLine2.length() > 0 || addressLine3 != null && addressLine3.length() > 0) && 
				(!ttService.checkForPOBoxAddress(addressLine1) || !ttService.checkForPOBoxAddress(addressLine2) || !ttService.checkForPOBoxAddress(addressLine3)));
	}
	
	/**
	 * Get fee
	 * 
	 * @param origin
	 * @param account
	 * @return
	 * @throws ResourceException
	 * @throws BusinessException
	 *//*
	protected BigDecimal getFee(String origin, Account account,String feeType) throws ResourceException, BusinessException {
		IBankLog.logTRC("Calculate the fee", this.getClass());
		String userType = account.getEmpAcctInd();
		if (userType == null || userType.length() == 0 || !userType.equals(STAFF_ACCOUNT)){
			
			if(feeType.equalsIgnoreCase("AUD")){
				userType = IBankParams.DEFAULT_CODE;
			}else{
				userType="NonAud";
			}
			
		}else {
			IBankLog.logTRC("Staff Account Id :  " + account.getAccountId().getAccountKey(), this.getClass());
			userType = IBankParams.STAFF_CODE;
		}
		String fee;
		try {

			try {
				CodesVO codesVO = IBankParams.getCodesData(origin, IBankParams.FEE_TT_REQUEST, userType);
				fee = codesVO.getMessage();
			} catch (Exception e) {
				// If any Exception happends, it is madatory to get Default fee
				CodesVO codesVO = IBankParams.getCodesData(origin, IBankParams.FEE_TT_REQUEST, IBankParams.DEFAULT_CODE);
				fee = codesVO.getMessage();
			}
		} catch (Exception e) {
			IBankLog.logERR(e.getMessage(), this.getClass());
			throw new BusinessException(BusinessException.GENERIC_ERROR, "Unable to get code for Order TT Fee");
		}
		return new BigDecimal(fee.replace('$', '0'));
	}*/

	/**
	 * Additional validation for Get fee request
	 * 
	 * @param origin
	 * @param request
	 * @param fromAccount
	 * @param gcis
	 * @throws BusinessException
	 */
	protected void validateGetFeeReq(String origin, TTGetFeeDetailReq request, Account fromAccount, String gcis, String customerType) throws BusinessException {
		overseasTransService.checkSanctioned(request.getCountry(), request.getCurrency(), gcis);
		BigDecimal thisAmount = new BigDecimal(request.getAmt());
		String feeType = MBAppUtils.findFeeType(request.getCurrency());
		BigDecimal fee = MBAppUtils.getUpdatedFee(origin, fromAccount,feeType);
		BigDecimal totalAmount = thisAmount.add(fee);
		ttService.checkLimitsForRestrictedCountries(new BigDecimal(request.getAmt()), customerType, request.getBankCountryCode());
        
		if (totalAmount != null && totalAmount.compareTo(fromAccount.getAvailableBalance()) > 0) {
			throw new BusinessException(BusinessException.EXCEED_AVAILABLE_BALANCE);
		}
		overseasTransService.checkLimit(thisAmount, origin);
	}

	/**
	 * Build TT transfer
	 * 
	 * @param beneficiary
	 * @param fromAccount
	 * @param customer
	 * @param commonData
	 * @param request
	 * @return
	 * @throws BusinessException
	 */
	protected TelegraphicTransfer populatePayment(OverseasTTBeneficiary beneficiary, Account fromAccount, Customer customer,
			IBankCommonData commonData, TTTransferReq request) throws BusinessException {
		TelegraphicTransfer tt = new TelegraphicTransfer();
		String origin = commonData.getOrigin();
		tt.setFromAccount(fromAccount.getAccountId());
		tt.setCommonData(commonData);
		tt.setBrand(origin);

		tt.setCurrency(request.getCurrency());
		tt.setBaseCurrencyCode(request.getCurrency());
		String feeType = MBAppUtils.findFeeType(request.getCurrency());
		tt.setFeeAmount(MBAppUtils.getUpdatedFee(origin, fromAccount,feeType));
		tt.setExchangeRate(request.getExchangeRate());
		tt.setAmount(new BigDecimal(request.getTotalAmt())); // total amount
		tt.setAudAmount(new BigDecimal(request.getAudAmt()));
		tt.setForeignCurrencyAmount(new BigDecimal(request.getForeignAmt()));

		if (isNoDecimalCurrency(origin, request.getCurrency())) {
			// For japanese yen,Indonesian rupiah dont show decimal places.
			tt.setForeignCurrencyAmount(tt.getForeignCurrencyAmount().setScale(0, BigDecimal.ROUND_DOWN));
		} 
		
		tt.setSenderContactNumber(request.getContactNum());
		// Flag AUD is Base. Used only for ttExists (duplicate payment check)
		tt.setAudIsBase(request.getIsAUDBase());
		// Beneficiary Details
		Address beneAddress = new Address();
		beneAddress.setCountry(beneficiary.getCountry());
		beneAddress.setCountryName(beneficiary.getCountry());
		beneAddress.setLine1(beneficiary.getAddress1());
		beneAddress.setLine2("");
		beneAddress.setPostZipcode("");
		beneAddress.setState("");
		beneAddress.setSuburb(beneficiary.getAddress2());
		tt.setBeneficiaryAddress(beneAddress);
		// Beneficiary Bank Details
		OverseaBank bank = new OverseaBank();
		bank.setAddress(beneficiary.getBankAddress());
		bank.setBankNumber(beneficiary.getBankNo());
		bank.setBankName(beneficiary.getBankName());
		bank.setBankCode("");// only for compass, if comes from search
		bank.setCity(beneficiary.getBankCity());
		bank.setCountry(beneficiary.getBankCountry());
		bank.setLocation("");
		bank.setCountryCode(beneficiary.getCountryCode());
		bank.setSwiftBicAddress(beneficiary.getSwiftBic());
		tt.setBeneficiaryBank(bank);
		tt.setBeneficiaryAccountNumber(beneficiary.getAccountNo());
		tt.setBeneficiaryName(beneficiary.getName());
		tt.setBeneficiaryAlias(beneficiary.getAlias());
		tt.setPaymentDetails(request.getDesc());
		if(request.getPurposeCode() != null){
			tt.setPurposeCode(request.getPurposeCode());
		}
		tt.setSenderName((TT_SENDER_NAME_LENGTH >= customer.getFullName().length()) ? customer.getFullName() : customer.getFullName().substring(0,
				TT_SENDER_NAME_LENGTH));

		Address senderAddress = customer.getContactDetail().getResidentialAddress();
		senderAddress.setCountryName("");
		senderAddress.setCountry("");
		tt.setSenderAddress(senderAddress);

		tt.setSenderEmail(customer.getContactDetail().getEmail());

		tt.setSessionId(commonData.getSessionId());
		tt.setIpAddress(commonData.getIpAddress());

		tt.setBatch(false);
		tt.setDescription(TT_DESC);
		tt.setPayerName(tt.getSenderName());
		tt.setSchedule(false);

		tt.setCheckForDuplicate(true);
		OseasBankCharge oseasBankCharge = new OseasBankCharge();
		Charge lCharge = new Charge();
		lCharge.setCode(TT_OSEAS_CHARGE_CODE_SHR);
		oseasBankCharge.setCharge(lCharge);
		tt.setOseasBankCharge(oseasBankCharge);

		tt.setCheckForDuplicate(true);
		if (request.getOverrideDup() != null)
			tt.setCheckForDuplicate(!request.getOverrideDup());
		if (request.getDupCount() != null)
			tt.setDuplicatePaymentCount(request.getDupCount());
		tt.setCommonData(commonData);
		//18E4 Safi
		tt.setFirstPaymentDate(beneficiary.getFirstPaymentDate());
		tt.setTrusted(beneficiary.getTrusted());
		tt.setBeneficiaryId(beneficiary.getId());
		//18E4 Safi
		return tt;

	}

	/**
	 * Receipt response
	 * 
	 */
	@Override
	protected TransferResp populateTransferResponse(RespHeader header, Receipt receipt, Payment payment, Customer updatedCustomer) {
		TransferResp response = super.populateTransferResponse(header, receipt, payment, updatedCustomer);
		TTReceipt ttReceipt = (TTReceipt) receipt;
		response.getReceipt().setAmt(null);
		response.getReceipt().setFee(String.valueOf(ttReceipt.getFee()));		
		response.getReceipt().setForeignAmt(new DecimalFormat(FOREX_AMOUNT_FORMAT).format(ttReceipt.getForeignAmount()));
		response.getReceipt().setAudAmt(new DecimalFormat(AMOUNT_FORMAT).format(ttReceipt.getAudAmount()));
		response.getReceipt().setTotalAmt(new DecimalFormat(AMOUNT_FORMAT).format(payment.getAmount()));
		response.getReceipt().setFormNum(receipt.getPaymentLog().getReferenceNumber());
		return response;
	}

	/**
	 * Get beneficiary by Id
	 * 
	 * @param id
	 * @param gcis
	 * @return
	 * @throws ResourceException
	 * @throws BusinessException
	 */
	protected OverseasTTBeneficiary getBeneficiaryById(Long id, String gcis) throws ResourceException, BusinessException {
		OverseasTTBeneficiary benef = overseasTransService.findBeneficiaryById(String.valueOf(id));
		if (benef == null || !benef.getGCISNumber().equalsIgnoreCase(gcis))
			throw new ResourceException(ResourceException.MOBILE_NON_FINANCIAL_FATAL_ERR);
		return benef;
	}

	/**
	 * Populate service response - duplicate
	 * 
	 * @param header
	 * @param duplicates
	 * @return
	 */
	
	protected IMBResp populateTransferResponse1(RespHeader header, List<TTDuplicateVO> duplicates, List<Account> accountList) {
		TransferResp payeeTransferResponse = new TransferResp(header);
		payeeTransferResponse.setDupList(new ArrayList<DuplicatePaymentResp>());
		for (TTDuplicateVO duplicateVO : duplicates) {
			DuplicatePaymentResp duplResp = new DuplicatePaymentResp();
			duplResp.setFromAccountNumDisp(duplicateVO.getFromAccount());
			for (Account fromAccount : accountList) {
				if (fromAccount != null && fromAccount.getAccountId() != null) {
					if (fromAccount.getAccountId().getAccountNumber().equals(duplicateVO.getFromAccount())) {
						duplResp.setFromAccountName(fromAccount.getAlias());
						duplResp.setFromAccountNumDisp(new MBAppHelper().getFormattedAcctNumber(fromAccount
							    .getAccountId().getAccountNumber(), fromAccount.getAccountId()
							    .getApplicationId(), fromAccount.getAccountId().getBsb()));
					}
				}
			}
			duplResp.setTranDateTime(duplicateVO.getTtDate());
			duplResp.setSeqNum(duplicateVO.getId());
			payeeTransferResponse.getDupList().add(duplResp);
		}
		Logger.info("Response: " + payeeTransferResponse, this.getClass());
		return payeeTransferResponse;
	}

	public void validateTTTransferReq(String origin, String beneficiaryBankCountry, String currency) throws BusinessException {
		// If customer search using Australian SwiftBic Address,show them error message.
		if (("AUSTRALIA".equalsIgnoreCase(beneficiaryBankCountry) || "AU".equalsIgnoreCase(beneficiaryBankCountry))
				&& "AUD".equalsIgnoreCase(currency)) {
			throw new BusinessException(BusinessException.TT_AUD_TO_AUST_INVALID);
		}
	}
	
	protected boolean countryMatchFound(String countryCode) {
		/*
    	 * ttPurposeCodeDistinctCountry.contains(countryCode) returns false because ttPurposeCodeDistinctCountry has 'space' in it, 
    	 * hence looping. Will Change to a better soln  
    	 * */
		
		/*18E4 - Tech Debt -changed to countryCode*/
		List<String> ttPurposeCodeDistinctCountry = IBankParams.getDistinctCountryForTTPurpose();
		boolean countryExists = false;
		for(String str: ttPurposeCodeDistinctCountry) {
		    if(str.trim().contains(countryCode))
		    	countryExists = true;
		}
		return countryExists;
	}
	
	/*18E4 - Tech Debt -changed to countryCode*/
/*	protected String getCountryCodeTTPurposeCode(String countryName) {
		List<BICCountry> countryLst = (List<BICCountry>) IBankParams.getBICCountryList();
    	String countryCode = null;
		for(BICCountry country : countryLst) {
    		if(country.getCountryName().equals(countryName))
    		countryCode = country.getCountryCode(); 	
    	}
    	return countryCode;
	}*/
	
	protected boolean purposeCodeFound(List<TTPurposeCode> purposeCodes, String countryCode , String purposeCode) throws BusinessException{
		boolean purposeCodeFound = false;
		if(null!= countryCode && null!= purposeCodes ){
			for(TTPurposeCode purpose : purposeCodes){
				if(purpose.getPurposeCode().equals(purposeCode)){
					Logger.debug("Purposecode "+purposeCode+" found for country "+countryCode, this.getClass());
					purposeCodeFound = true ;
					break;
				}
			}
		}
		
		return purposeCodeFound;
	}
	
}
