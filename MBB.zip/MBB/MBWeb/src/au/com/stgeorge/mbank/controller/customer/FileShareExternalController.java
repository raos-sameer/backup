package au.com.stgeorge.mbank.controller.customer;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.AbstractController;
import au.com.stgeorge.framework.common.logging.Logger;
import au.com.stgeorge.ibank.businessobject.BusinessException;
import au.com.stgeorge.ibank.businessobject.FileshareService;
import au.com.stgeorge.ibank.businessobject.ProofOfStmtService;
import au.com.stgeorge.ibank.businessobject.ResourceException;
import au.com.stgeorge.ibank.businessobject.impl.FileshareServiceHelper;
import au.com.stgeorge.ibank.common.cache.IBankParams;
import au.com.stgeorge.ibank.valueobject.PDFStore;
import au.com.stgeorge.ibank.valueobject.SAMLStore;
import au.com.stgeorge.ibank.valueobject.database.CodesVO;
import au.com.stgeorge.ibank.valueobject.transfer.IBankCommonData;
import au.com.stgeorge.mbank.session.MobileSession;
import au.com.stgeorge.mbank.util.MBAppHelper;
import au.com.stgeorge.mbank.util.MBAppUtils;
import au.com.stgeorge.perflogger.PerformanceLogger;
import au.com.stgeorge.security.util.StringMethods;

/**
 * @author C50216
 * 
 */

@Controller
public class FileShareExternalController extends AbstractController
{
	private static final String FILESHARE = "fileshare";
	@Autowired
	private MBAppHelper mbAppHelper;
	
	@Autowired
	private PerformanceLogger perfLogger;

	@Autowired
	private ProofOfStmtService proofOfStmtService;
	
	@Autowired
	private FileshareService fileshareService;

	@Override
	protected ModelAndView handleRequestInternal(HttpServletRequest request, HttpServletResponse response) throws Exception
	{
		Logger.debug("FileShareSamlPostController - handleRequestInternal(). Request: " + request, this.getClass());	
		perfLogger.startAllLogs();
		String logName = MBAppUtils.getLogName(request);
		perfLogger.startLog(logName);
		String actionType = request.getParameter("actionType");		
		Logger.debug("FileShareSamlPostController - actionType**** " + actionType, this.getClass());	
		String token = request.getParameter("token");
		Logger.debug("FileShareSamlPostController - token**** " + token, this.getClass());	
		String brand = request.getParameter("brand");
		Logger.debug("FileShareSamlPostController - brand**** " + brand, this.getClass());	
		ModelAndView model = null;
		String origin = null;
		try
		{
			if ((FILESHARE.equalsIgnoreCase(actionType) && !StringMethods.isEmptyString(token) ))
			{
				SAMLStore samlStore = fileshareService.getSAMLToken(token, FileshareServiceHelper.FILESHARE);
				if(samlStore == null){
					throw new BusinessException(BusinessException.PDF_STATEMENT_NOT_FOUND);
				}
				String samlData = samlStore.getSamlData();						
				//Logger.debug("FileShareSamlPostController - saml response " + pdfStore.getPdfData(), this.getClass());	
			//	proofOfStmtService.deletePDFDocTokenDetails(token);	
				fileshareService.deleteSAMLTokenDetails(token, FileshareServiceHelper.FILESHARE);
				model = new ModelAndView(FILESHARE);
				
				if(brand.contains("Melbourne")) {
					origin="BOM";
				}else if (brand.contains("St.George")) {
					origin="STG";
				}else if(brand.contains("BankSA")) {
					origin="BSA";
				}
				Logger.debug("FileShareSamlPostController - origin**** " + origin, this.getClass());		
				IBankCommonData commonData=  new IBankCommonData();
				commonData.setOrigin(origin);
				CodesVO relayStateCode = IBankParams.getCodesData(IBankParams.getBaseOriginCode(commonData.getOrigin()), IBankParams.SAML_ENTITY_ID,IBankParams.FILESHARE_RELAY_STATE );
		      	String relayStateURL = relayStateCode.getMessage();
		      
		      	CodesVO entityIDCode = IBankParams.getCodesData(IBankParams.getBaseOriginCode(commonData.getOrigin()), IBankParams.SAML_ENTITY_ID,IBankParams.FILESHARE_ENTITY_ID );
		      	String entityID = entityIDCode.getMessage();
		     	
		      	StringBuilder urlBuilder = new StringBuilder();
		  		urlBuilder.append(relayStateURL);
		  		urlBuilder.append("?entityid=");
		  		urlBuilder.append(entityID);
		  		
		  		Logger.debug("FileShareSamlPostController - urlBuilder.toString() *********** " + urlBuilder.toString(), this.getClass());	
		  						
				model.addObject("targetUrl", "/mb/jsp/fileshare.jsp");
				model.addObject("samlHTTPPOSTBindingURL", fileshareService.getRecipientURL(commonData));
				model.addObject("SAMLResponse", fileshareService.deflateSAMLObject(samlData));
				model.addObject("RelayState", urlBuilder.toString());
				
				Logger.debug("FileShareSamlPostController - recepient********* " + fileshareService.getRecipientURL(commonData), this.getClass());	
				Logger.debug("FileShareSamlPostController -  samlresponse ********** " + fileshareService.deflateSAMLObject(samlData), this.getClass());					
			
				return model;
			}		

		} catch (BusinessException be)
		{
		
		} catch (ResourceException re)
		{
			
		} catch (Exception ex)
		{
			Logger.error("Error : " , ex , this.getClass());
		
		} finally
		{
			perfLogger.endLog(logName);
			perfLogger.endAllLogs();
		}	
		return model;
	}

	
}
