package au.com.stgeorge.mbank.model.common;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;

import au.com.stgeorge.mbank.util.JsonDateTimeSerializer;

public class AppParams
{
	
private  String origin;  
private String salesOfferSwitch;
private String closedAcctStmtSwitch;
private String manageStmtSwitch;
private String onboardingSwitch;
private String travelRetrieveQuoteSwitch;
private String obTileSwitch;
private String shareBsbAccNumSwitch;
private String androidBackButtonSwitch;
private String eCorrespondenceSwitch;
private String serviceBadgingSwitch;
private String nppInwardSwitch;
private String nppOutwardSwitch;
private String adobeTaggingSwitch;
//private String businessAccSoleDirSwitch;
private String unlockActivateDeltaInfoSwitch;
private String retentionSavingSavingsSwitch;
//private String creditCardClosureSwitch;
private String payIdRegistrationSwitch;
private String cardDisputeSwitch;
//19E1 CI - Removing increase transaction history CI item
//private String moreTranHistorySwitch;
private String showPayToPayIdIcon;

//19E2 Opitimisation
private String upcomingPaymentsSwitch;
private String manageEcorreStmtSwitch;
private String dashboardConnectSwitch; 

private String incomeVerificationSwitch;
private String appDynamicsMBSwitch;

//19E2 CPP Term Deposit Switches for Origination and Renewal
private String cppTDOpenSwitch;
private String cppTDRenewSwitch;	

//19E2 SavingsOnboarding switches 

//private String savingsOnboardingExistingSwitch;
//private String savingsOnboardingNewSwitch;	
private String activeAccountSwitch;

//19E3: NPP
private int nppPaymentStatusPollingCount;
private int nppPaymentStatusPollingInterval;
private int payIdRegStatusPollingInterval;

//19E3 CPP Manage Term Deposit Switch
private String manageTDSwitch;

//19E3- Direct debit transaction switch
private String recurringDDTSwitch;

//19E3 productContentSwitch  

private String productContentSwitch;

private String personalizationContentSwitch;

private int personalizationContentRefreshTime;

private String personalizationContentUrl;

private String personalizationCSSURL;

private String showInfoMsgForOsko;

//19e3 CPP TFN Switch
private String tfnSwitch;

//19E3 - 
private String targetURL;

//19E4 AEM Insertion Points
private String  aemNBACampaignSwitch;
private String medbSwitch;
private String medbSalCreditSwitch;

//19E4 Global Wallet switch
private String globalWalletSwitch;

//19E4- BCOP Msg switch
private String logonPayeesBillersAsyncSwitch;


//19E4 - Complete Freedom Route Switch 
private String completeFreedomRouteSwitch;

//19E4 - Incentive Saver Route Switch 
private String incentiveSaverRouteSwitch; 

// 20 E2 : Commenting out the switch for tech debt to do switch clean up
//private String accountDetailsRouteSwitch;

private String payToMobileServiceAndHelpEntry;

//20E4 -  ASIC Switch Change
private String asicSwitch;

private String homeLoanDigiSwitch;
private String bcopCompleteFreedomSwitch;
private String bcopPortfolioFixedLoanSwitch;

//20E1 Madison Service Menu Flag
private String showMadison;

//20E1 C!: Fix bottom menu icon switch
private String fixBottomMenuSwitch;

private String matrixSplashPagePhoneNo;

//20E1
private String aemAdminTemplateSwitch;
//20E1 GCC Transfer
private String globalWalletTransferSwitch;
//20E1 NPP PayId AddressBook Switch
private String nppPayIdAddressBookSwitch;

private String nppEndToEndIdSwitch;

private String updatePhoneNumberSwitch;

//20E2 CSH
private String showCSHTile;

private String transCategoryUpliftSwitch;  

private String lwcSwitch;

private String fileShareSwitch;

private String payeeLimitIncreaseSwitch;

private String mgrpSwitch;

//20E3
private String intlPaymentSwitch;

//20E3 Warranty
private String covidSupportHubSwitch;

//20E4 AppStoreUrl
private AppStoreURL appStoreUrl;

//20E4 - Madison - Wallet eligibility URL
private String walletEligibilityURL;

//20E4 - Madison - Add card to Wallet manually URL
private String addCardManuallyURL;

//20E4 Madison Service Menu Flag
private String showAddCardToWallet;

//20E4 LWC Google Maps API switch
private String showGoogleMapLWC;

//20E4 Biller History CI
private String showBillerHistory;

//20E4 Live Person Chat Status
private String secureChatActiveFlag;

//20E4 Smart Plan (Plan&Pay)
private String smartPlanSwitch;

//21E2 Acct to Index switch
private String acctToIndexValidationSwitch;

private String[] lpWebOobStartChatDisplayPages;

private String[] lpWebOobMinimizedStateDisplayPages;

private String[] lpWebFloatingIconDisplayPages;

private String[] lpNativeFloatingIconDisplayPages;

private String[] lpNativeStartChatDisplayPages;

//20E4: CSH CR
private String cshTilePresent;

private String googleMapApiKey;

private String ttRestrictHighRiskCtrySwitch;


private String updateContactDetailsSwitch;

private String managePreferencesSwitch;

private String cardLostStolenPhone;

private String qasUrl;
private String qasAction;
private String qasToken;

private String feeSimplificationSwitch;

private String gamblingBlockSwitch;

private String nppABNPayIdRegSwitch;
private String smartPlanFeeMsgSwitch;
private String cshHomeLoanSwitch;

	private String 	fileSharePingIDPSwitch;

public String getCshHomeLoanSwitch() {
	return cshHomeLoanSwitch;
}
public void setCshHomeLoanSwitch(String cshHomeLoanSwitch) {
	this.cshHomeLoanSwitch = cshHomeLoanSwitch;
}
public String getFeeSimplificationSwitch() {
	return feeSimplificationSwitch;
}
public void setFeeSimplificationSwitch(String feeSimplificationSwitch) {
	this.feeSimplificationSwitch = feeSimplificationSwitch;
}
public String getGamblingBlockSwitch() {
	return gamblingBlockSwitch;
}
public void setGamblingBlockSwitch(String gamblingBlockSwitch) {
	this.gamblingBlockSwitch = gamblingBlockSwitch;
}
public String getQasUrl() {
	return qasUrl;
}
public void setQasUrl(String qasUrl) {
	this.qasUrl = qasUrl;
}
public String getQasAction() {
	return qasAction;
}
public void setQasAction(String qasAction) {
	this.qasAction = qasAction;
}
public String getQasToken() {
	return qasToken;
}
public void setQasToken(String qasToken) {
	this.qasToken = qasToken;
}


//private String emailBounceBackSwitch;


//public String getEmailBounceBackSwitch() {
//	return emailBounceBackSwitch;
//}
//public void setEmailBounceBackSwitch(String emailBounceBackSwitch) {
//	this.emailBounceBackSwitch = emailBounceBackSwitch;
//}

public String getCardLostStolenPhone() {
	return cardLostStolenPhone;
}
public void setCardLostStolenPhone(String cardLostStolenPhone) {
	this.cardLostStolenPhone = cardLostStolenPhone;
}
public String getUpdateContactDetailsSwitch() {
	return updateContactDetailsSwitch;
}
public void setUpdateContactDetailsSwitch(String updateContactDetailsSwitch) {
	this.updateContactDetailsSwitch = updateContactDetailsSwitch;
}
public String getSecureChatActiveFlag() {
	return secureChatActiveFlag;
}
public void setSecureChatActiveFlag(String secureChatActiveFlag) {
	this.secureChatActiveFlag = secureChatActiveFlag;
}
public AppStoreURL getAppStoreUrl() {
	return appStoreUrl;
}
public void setAppStoreUrl(AppStoreURL appStoreUrl) {
	this.appStoreUrl = appStoreUrl;
}
public String getIntlPaymentSwitch() {
	return intlPaymentSwitch;
}
public void setIntlPaymentSwitch(String intlPaymentSwitch) {
	this.intlPaymentSwitch = intlPaymentSwitch;
}

private String unarrangedOverdraftSwitch;

private String bCopSwitch20E4;

private String simplifyConnectSwitch;

//20E4 lwc pendingTransaction
private String lwcPendingTransactionSwitch;


//Live Person chat
private String lpMessagingSwitch; 

private String showActivateCardAddToWallet;

//21E1 Card Auto Pay
private String cardAutoPaySwitch;

private String ascendaSwitch;

private String lpSiteId;

public String getLpSiteId() {
	return lpSiteId;
}
public void setLpSiteId(String lpSiteId) {
	this.lpSiteId = lpSiteId;
}
public String getSimplifyConnectSwitch() {
	return simplifyConnectSwitch;
}
public void setSimplifyConnectSwitch(String simplifyConnectSwitch) {
	this.simplifyConnectSwitch = simplifyConnectSwitch;
}
public String getUnarrangedOverdraftSwitch() {
	return unarrangedOverdraftSwitch;
}
public void setUnarrangedOverdraftSwitch(String unarrangedOverdraftSwitch) {
	this.unarrangedOverdraftSwitch = unarrangedOverdraftSwitch;
}
public String getbCopSwitch20E4() {
	return bCopSwitch20E4;
}
public void setbCopSwitch20E4(String bCopSwitch20E4) {
	this.bCopSwitch20E4 = bCopSwitch20E4;
}
public String getPayeeLimitIncreaseSwitch() {
	return payeeLimitIncreaseSwitch;
}
public void setPayeeLimitIncreaseSwitch(String payeeLimitIncreaseSwitch) {
	this.payeeLimitIncreaseSwitch = payeeLimitIncreaseSwitch;
}
public String getBcopPortfolioFixedLoanSwitch() {
	return bcopPortfolioFixedLoanSwitch;
}
public void setBcopPortfolioFixedLoanSwitch(String bcopPortfolioFixedLoanSwitch) {
	this.bcopPortfolioFixedLoanSwitch = bcopPortfolioFixedLoanSwitch;
}
public String getBcopCompleteFreedomSwitch() {
	return bcopCompleteFreedomSwitch;
}
public void setBcopCompleteFreedomSwitch(String bcopCompleteFreedomSwitch) {
	this.bcopCompleteFreedomSwitch = bcopCompleteFreedomSwitch;
}
public String getHomeLoanDigiSwitch() {
	return homeLoanDigiSwitch;
}
public void setHomeLoanDigiSwitch(String homeLoanDigiSwitch) {
	this.homeLoanDigiSwitch = homeLoanDigiSwitch;
}
/*public String getCreditCardClosureSwitch() {


public String getLogonPayeesBillersAsyncSwitch() {
	return logonPayeesBillersAsyncSwitch;
}
public void setLogonPayeesBillersAsyncSwitch(
		String logonPayeesBillersAsyncSwitch) {
	this.logonPayeesBillersAsyncSwitch = logonPayeesBillersAsyncSwitch;
}
public String getCreditCardClosureSwitch() {
	return creditCardClosureSwitch;
}
public void setCreditCardClosureSwitch(String creditCardClosureSwitch) {
	this.creditCardClosureSwitch = creditCardClosureSwitch;
}*/
public String getRetentionSavingSavingsSwitch() {
	return retentionSavingSavingsSwitch;
}
public void setRetentionSavingSavingsSwitch(String retentionSavingSavingsSwitch) {
	this.retentionSavingSavingsSwitch = retentionSavingSavingsSwitch;
}
/*public String getBusinessAccSoleDirSwitch() {
	return businessAccSoleDirSwitch;
}
public void setBusinessAccSoleDirSwitch(String businessAccSoleDirSwitch) {
	this.businessAccSoleDirSwitch = businessAccSoleDirSwitch;
}*/
public String geteCorrespondenceSwitch() {
	return eCorrespondenceSwitch;
}
public void seteCorrespondenceSwitch(String eCorrespondenceSwitch) {
	this.eCorrespondenceSwitch = eCorrespondenceSwitch;
}

public String getShareBsbAccNumSwitch() {
	return shareBsbAccNumSwitch;
}
public void setShareBsbAccNumSwitch(String shareBsbAccNumSwitch) {
	this.shareBsbAccNumSwitch = shareBsbAccNumSwitch;
}

  public String getManageStmtSwitch() {
	return manageStmtSwitch;
}
public void setManageStmtSwitch(String manageStmtSwitch) {
	this.manageStmtSwitch = manageStmtSwitch;
}
  public String getClosedAcctStmtSwitch() {
	return closedAcctStmtSwitch;
}
public void setClosedAcctStmtSwitch(String closedAcctStmtSwitch) {
	this.closedAcctStmtSwitch = closedAcctStmtSwitch;
}
  public String getSalesOfferSwitch() {
	return salesOfferSwitch;
}
public void setSalesOfferSwitch(String salesOfferSwitch) {
	this.salesOfferSwitch = salesOfferSwitch;
}

private String payeeEmailSwitch ;


public String getPayeeEmailSwitch() {
	return payeeEmailSwitch;
}
public void setPayeeEmailSwitch(String payeeEmailSwitch) {
	this.payeeEmailSwitch = payeeEmailSwitch;
}
public String getOrigin()
	{
		return origin;
	}
	public void setOrigin(String origin)
	{
		this.origin = origin;
	}
	
	@JsonSerialize(using = JsonDateTimeSerializer.class)
	public Date getSystemDate()
	{
		return systemDate;
	}
	public String getOriginName()
	{
		return originName;
	}
	public void setOriginName(String originName)
	{
		this.originName = originName;
	}
	public String getOriginPhone()
	{
		return originPhone;
	}
	public void setOriginPhone(String originPhone)
	{
		this.originPhone = originPhone;
	}
	public String getOriginIntPhone()
	{
		return originIntPhone;
	}
	public void setOriginIntPhone(String originIntPhone)
	{
		this.originIntPhone = originIntPhone;
	}
	public String getOriginHelpDeskPhone()
	{
		return originHelpDeskPhone;
	}
	public void setOriginHelpDeskPhone(String originHelpDeskPhone)
	{
		this.originHelpDeskPhone = originHelpDeskPhone;
	}
	public String getOriginTradingHours()
	{
		return originTradingHours;
	}
	public void setOriginTradingHours(String originTradingHours)
	{
		this.originTradingHours = originTradingHours;
	}
	public String getOriginURL()
	{
		return originURL;
	}
	public void setOriginURL(String originURL)
	{
		this.originURL = originURL;
	}
	public void setSystemDate(Date systemDate)
	{
		this.systemDate = systemDate;
	}
	private  Date systemDate;
	
	private String originName;
	
	private String originPhone;
	
	private String originIntPhone;
	
	private String originHelpDeskPhone;
	
	private String originTradingHours;
	
	private String originURL;
	private String keyboardAmountType;

	private String keyboardNumType;
	private String keyboardNumPattern;
	
	private String creditLimitIncreaseSwitch;
	
	
	private Integer cordovaReplInd;
	
	private Integer cardlessTokenInd;

	private String fileShareOAuthIDPSwitch;
	
	public String getKeyboardNumType()
	{
		return keyboardNumType;
	}
	public void setKeyboardNumType(String keyboardNumType)
	{
		this.keyboardNumType = keyboardNumType;
	}
	public String getKeyboardNumPattern()
	{
		return keyboardNumPattern;
	}
	public void setKeyboardNumPattern(String keyboardNumPattern)
	{
		this.keyboardNumPattern = keyboardNumPattern;
	}

	
	public String getKeyboardAmountType()
	{
		return keyboardAmountType;
	}
	public void setKeyboardAmountType(String keyboardAmountType)
	{
		this.keyboardAmountType = keyboardAmountType;
	}
	
	public String getCreditLimitIncreaseSwitch() {
		return creditLimitIncreaseSwitch;
	}
	public void setCreditLimitIncreaseSwitch(String creditLimitIncreaseSwitch) {
		this.creditLimitIncreaseSwitch = creditLimitIncreaseSwitch;
	}
	
	private String gccSwitch;

	public String getGccSwitch() {
		return gccSwitch;
	}
	public void setGccSwitch(String gccSwitch) {
		this.gccSwitch = gccSwitch;
	}	

	private String btsSwitch;
	
	private String btoSwitch;
	
	@JsonProperty("btSSwitch")
	public String getBtsSwitch() {
		return btsSwitch;
	}
	public void setBtsSwitch(String btsSwitch) {
		this.btsSwitch = btsSwitch;
	}
	@JsonProperty("btOSwitch")
	public String getBtoSwitch() {
		return btoSwitch;
	}
	public void setBtoSwitch(String btoSwitch) {
		this.btoSwitch = btoSwitch;
	}
	//19E4 Tech Debt Start:Switch Removal
	/*private String greenBirdSwitch;
	public String getGreenBirdSwitch() {
		return greenBirdSwitch;
	}
	public void setGreenBirdSwitch(String greenBirdSwitch) {
		this.greenBirdSwitch = greenBirdSwitch;
	}*/
	//19E4 Tech Debt End:Switch Removal
	private String fastFundingSwitch;
	public String getFastFundingSwitch() {
		return fastFundingSwitch;
	}
	public void setFastFundingSwitch(String fastFundingSwitch) {
		this.fastFundingSwitch = fastFundingSwitch;
	}
	
	public void setTapAndPayFlag(String tapAndPayFlag) {
		this.tapAndPayFlag = tapAndPayFlag;
	}
	public String getTapAndPayFlag() {
		return tapAndPayFlag;
	}
	private String tapAndPayFlag;
	
	
	private String insuranceSwitch;
	public String getInsuranceSwitch() {
		return insuranceSwitch;
	}
	public void setInsuranceSwitch(String insuranceSwitch) {
		this.insuranceSwitch = insuranceSwitch;
	}
	
	private String connectSwitch;
	public String getConnectSwitch() {
		return connectSwitch;
	}
	public void setConnectSwitch(String connectSwitch) {
		this.connectSwitch = connectSwitch;
	}
	private String notificationUptake;
	public String getNotificationUptake() {
		return notificationUptake;
	}
	public void setNotificationUptake(String notificationUptake) {
		this.notificationUptake = notificationUptake;
	}
	public Integer getCordovaReplInd() {
		return cordovaReplInd;
	}
	public void setCordovaReplInd(Integer cordovaReplInd) {
		this.cordovaReplInd = cordovaReplInd;
	}
	
	private String payToMobileSwitch;

	public String getPayToMobileSwitch() {
		return payToMobileSwitch;
	}
	public void setPayToMobileSwitch(String payToMobileSwitch) {
		this.payToMobileSwitch = payToMobileSwitch;
	}
	
	public Integer getCardlessTokenInd() {
		return cardlessTokenInd;
	}
	public void setCardlessTokenInd(Integer cardlessTokenInd) {
		this.cardlessTokenInd = cardlessTokenInd;
	}
	
	private String onlinePINSecuritySwitch;
	private String onlinePINActivationSwitch;


	public String getOnlinePINSecuritySwitch() {
		return onlinePINSecuritySwitch;
	}
	public void setOnlinePINSecuritySwitch(String onlinePINSecuritySwitch) {
		this.onlinePINSecuritySwitch = onlinePINSecuritySwitch;
	}
	public String getOnlinePINActivationSwitch() {
		return onlinePINActivationSwitch;
	}
	public void setOnlinePINActivationSwitch(String onlinePINActivationSwitch) {
		this.onlinePINActivationSwitch = onlinePINActivationSwitch;
	}

	private String expenseSplitterSwitch;
	
	public String getExpenseSplitterSwitch() {
		return expenseSplitterSwitch;
	}
	public void setExpenseSplitterSwitch(String expenseSplitterSwitch) {
		this.expenseSplitterSwitch = expenseSplitterSwitch;
	}
	
	private String insuranceSSOSwitch;

	public String getInsuranceSSOSwitch() {
		return insuranceSSOSwitch;
	}
	public void setInsuranceSSOSwitch(String insuranceSSOSwitch) {
		this.insuranceSSOSwitch = insuranceSSOSwitch;
	}
	
	
	private String motorInsuranceSSOSwitch;


	public String getMotorInsuranceSSOSwitch() {
		return motorInsuranceSSOSwitch;
	}
	public void setMotorInsuranceSSOSwitch(String motorInsuranceSSOSwitch) {
		this.motorInsuranceSSOSwitch = motorInsuranceSSOSwitch;
	}
	
	private String creditLimitDecreaseSwitch;


	public String getCreditLimitDecreaseSwitch() {
		return creditLimitDecreaseSwitch;
	}
	public void setCreditLimitDecreaseSwitch(String creditLimitDecreaseSwitch) {
		this.creditLimitDecreaseSwitch = creditLimitDecreaseSwitch;
	}
	public String getOnboardingSwitch() {
		return onboardingSwitch;
	}
	public void setOnboardingSwitch(String onboardingSwitch) {
		this.onboardingSwitch = onboardingSwitch;
	}

	
	public String getTravelRetrieveQuoteSwitch() {
		return travelRetrieveQuoteSwitch;
	}
	public void setTravelRetrieveQuoteSwitch(String travelRetrieveQuoteSwitch) {
		this.travelRetrieveQuoteSwitch = travelRetrieveQuoteSwitch;
	}
	//17E3 Transaction Categorisation
	@JsonInclude(Include.NON_NULL)
	private Integer tnxCategorisationSwitch;


	public Integer getTnxCategorisationSwitch() {
		return tnxCategorisationSwitch;
	}
	public void setTnxCategorisationSwitch(Integer tnxCategorisationSwitch) {
		this.tnxCategorisationSwitch = tnxCategorisationSwitch;
	}
	public String getObTileSwitch() {
		return obTileSwitch;
	}
	public void setObTileSwitch(String obTileSwitch) {
		this.obTileSwitch = obTileSwitch;
	}
	
	

	private String lockUnlockSwitch;


	public String getLockUnlockSwitch() {
		return lockUnlockSwitch;
	}
	public void setLockUnlockSwitch(String lockUnlockSwitch) {
		this.lockUnlockSwitch = lockUnlockSwitch;
	}
	
	private String homeLoanSwitch;

	private String madisonLCMSwitch;

	public String getHomeLoanSwitch() {
		return homeLoanSwitch;
	}
	public void setHomeLoanSwitch(String homeLoanSwitch) {
		this.homeLoanSwitch = homeLoanSwitch;
	}
	
	//17E4 DDA Transaction Categorisation
	@JsonInclude(Include.NON_NULL)
	private Integer ddaTnxCategorisationSwitch;


	public Integer getDdaTnxCategorisationSwitch() {
		return ddaTnxCategorisationSwitch;
	}
	public void setDdaTnxCategorisationSwitch(Integer ddaTnxCategorisationSwitch) {
		this.ddaTnxCategorisationSwitch = ddaTnxCategorisationSwitch;
	}
	//20E3 UI Switch Clean up
	/*public String getAndroidBackButtonSwitch() {
		return androidBackButtonSwitch;
	}
	public void setAndroidBackButtonSwitch(String androidBackButtonSwitch) {
		this.androidBackButtonSwitch = androidBackButtonSwitch;
	}*/
	public String getAdobeTaggingSwitch() {
		return adobeTaggingSwitch;
	}
	public void setAdobeTaggingSwitch(String adobeTaggingSwitch) {
		this.adobeTaggingSwitch = adobeTaggingSwitch;
	}
	public String getServiceBadgingSwitch() {
		return serviceBadgingSwitch;
	}
	public void setServiceBadgingSwitch(String serviceBadgingSwitch) {
		this.serviceBadgingSwitch = serviceBadgingSwitch;
	}
	public String getNppInwardSwitch() {
		return nppInwardSwitch;
	}
	public void setNppInwardSwitch(String nppInwardSwitch) {
		this.nppInwardSwitch = nppInwardSwitch;
	}	
	public String getNppOutwardSwitch() {
		return nppOutwardSwitch;
	}
	public void setNppOutwardSwitch(String nppOutwardSwitch) {
		this.nppOutwardSwitch = nppOutwardSwitch;
	}
	public String getUnlockActivateDeltaInfoSwitch() {
		return unlockActivateDeltaInfoSwitch;
	}
	public void setUnlockActivateDeltaInfoSwitch(
			String unlockActivateDeltaInfoSwitch) {
		this.unlockActivateDeltaInfoSwitch = unlockActivateDeltaInfoSwitch;
	}
	public String getCardDisputeSwitch() {
		return cardDisputeSwitch;
	}
	public void setCardDisputeSwitch(String cardDisputeSwitch) {
		this.cardDisputeSwitch = cardDisputeSwitch;
	}
	//19E1 CI - Removing increase transaction history CI item
	/*
	public String getMoreTranHistorySwitch() {
		return moreTranHistorySwitch;
	}
	public void setMoreTranHistorySwitch(String moreTranHistorySwitch) {
		this.moreTranHistorySwitch = moreTranHistorySwitch;
	}*/
	public String getShowPayToPayIdIcon() {
		return showPayToPayIdIcon;
	}
	public void setShowPayToPayIdIcon(String showPayToPayIdIcon) {
		this.showPayToPayIdIcon = showPayToPayIdIcon;
	}
	public String getPayIdRegistrationSwitch() {
		return payIdRegistrationSwitch;
	}
	public void setPayIdRegistrationSwitch(String payIdRegistrationSwitch) {
		this.payIdRegistrationSwitch = payIdRegistrationSwitch;
	}
	public String getIncomeVerificationSwitch() {
		return incomeVerificationSwitch;
	}
	public String getUpcomingPaymentsSwitch() {
		return upcomingPaymentsSwitch;
	}
	public void setUpcomingPaymentsSwitch(String upcomingPaymentsSwitch) {
		this.upcomingPaymentsSwitch = upcomingPaymentsSwitch;
	}
	public String getManageEcorreStmtSwitch() {
		return manageEcorreStmtSwitch;
	}
	public void setManageEcorreStmtSwitch(String manageEcorreStmtSwitch) {
		this.manageEcorreStmtSwitch = manageEcorreStmtSwitch;
	}
	public String getDashboardConnectSwitch() {
		return dashboardConnectSwitch;
	}
	public void setDashboardConnectSwitch(String dashboardConnectSwitch) {
		this.dashboardConnectSwitch = dashboardConnectSwitch;
	}
	public void setIncomeVerificationSwitch(String incomeVerificationSwitch) {
		this.incomeVerificationSwitch = incomeVerificationSwitch;
	}
	public String getCppTDOpenSwitch() {
		return cppTDOpenSwitch;
	}
	public void setCppTDOpenSwitch(String cppTDOpenSwitch) {
		this.cppTDOpenSwitch = cppTDOpenSwitch;
	}
	public String getCppTDRenewSwitch() {
		return cppTDRenewSwitch;
	}
	public void setCppTDRenewSwitch(String cppTDRenewSwitch) {
		this.cppTDRenewSwitch = cppTDRenewSwitch;
	}
	public String getAppDynamicsMBSwitch() {
	    return appDynamicsMBSwitch;
	}
	public void setAppDynamicsMBSwitch(String appDynamicsMBSwitch) {
	    this.appDynamicsMBSwitch = appDynamicsMBSwitch;
	}
	//19E4 Tech Debt Start:Switch Removal
	/*public String getSavingsOnboardingExistingSwitch() {
		return savingsOnboardingExistingSwitch;
	}
	public void setSavingsOnboardingExistingSwitch(
			String savingsOnboardingExistingSwitch) {
		this.savingsOnboardingExistingSwitch = savingsOnboardingExistingSwitch;
	}*/
/*	public String getSavingsOnboardingNewSwitch() {
		return savingsOnboardingNewSwitch;
	}
	public void setSavingsOnboardingNewSwitch(String savingsOnboardingNewSwitch) {
		this.savingsOnboardingNewSwitch = savingsOnboardingNewSwitch;
	}*/
	public int getNppPaymentStatusPollingCount() {
		return nppPaymentStatusPollingCount;
	}
	public void setNppPaymentStatusPollingCount(int nppPaymentStatusPollingCount) {
		this.nppPaymentStatusPollingCount = nppPaymentStatusPollingCount;
	}
	public int getNppPaymentStatusPollingInterval() {
		return nppPaymentStatusPollingInterval;
	}
	public void setNppPaymentStatusPollingInterval(
			int nppPaymentStatusPollingInterval) {
		this.nppPaymentStatusPollingInterval = nppPaymentStatusPollingInterval;
	}
	
	public int getPayIdRegStatusPollingInterval() {
		return payIdRegStatusPollingInterval;
	}
	public void setPayIdRegStatusPollingInterval(int payIdRegStatusPollingInterval) {
		this.payIdRegStatusPollingInterval = payIdRegStatusPollingInterval;
	}

	public String getManageTDSwitch() {
		return manageTDSwitch;
	}
	public void setManageTDSwitch(String manageTDSwitch) {
		this.manageTDSwitch = manageTDSwitch;
	}
	public String getRecurringDDTSwitch() {
		return recurringDDTSwitch;
	}
	public void setRecurringDDTSwitch(String recurringDDTSwitch) {
		this.recurringDDTSwitch = recurringDDTSwitch;
	}
	
	public String getPersonalizationContentSwitch() {
		return personalizationContentSwitch;
	}
	public void setPersonalizationContentSwitch(String personalizationContentSwitch) {
		this.personalizationContentSwitch = personalizationContentSwitch;
	}
	
	public int getPersonalizationContentRefreshTime() {
		return personalizationContentRefreshTime;
	}
	public void setPersonalizationContentRefreshTime(
			int personalizationContentRefreshTime) {
		this.personalizationContentRefreshTime = personalizationContentRefreshTime;
	}
	public String getPersonalizationContentUrl() {
		return personalizationContentUrl;
	}
	public void setPersonalizationContentUrl(String personalizationContentUrl) {
		this.personalizationContentUrl = personalizationContentUrl;
	}
	public String getActiveAccountSwitch() {
		return activeAccountSwitch;
	}
	public void setActiveAccountSwitch(String activeAccountSwitch) {
		this.activeAccountSwitch = activeAccountSwitch;
	}
	public String getShowInfoMsgForOsko() {
		return showInfoMsgForOsko;
	}
	public void setShowInfoMsgForOsko(String showInfoMsgForOsko) {
		this.showInfoMsgForOsko = showInfoMsgForOsko;
	}
	public String getProductContentSwitch() {
		return productContentSwitch;
	}
	public void setProductContentSwitch(String productContentSwitch) {
		this.productContentSwitch = productContentSwitch;
	}
	public String getTfnSwitch() {
		return tfnSwitch;
	}
	public void setTfnSwitch(String tfnSwitch) {
		this.tfnSwitch = tfnSwitch;
	}
	public String getPersonalizationCSSURL() {
		return personalizationCSSURL;
	}
	public void setPersonalizationCSSURL(String personalizationCSSURL) {
		this.personalizationCSSURL = personalizationCSSURL;
	}
	public String getTargetURL() {
		return targetURL;
	}
	public void setTargetURL(String targetURL) {
		this.targetURL = targetURL;
	}
	public String getAemNBACampaignSwitch() {
		return aemNBACampaignSwitch;
	}
	public void setAemNBACampaignSwitch(String aemNBACampaignSwitch) {
		this.aemNBACampaignSwitch = aemNBACampaignSwitch;
	}
	public String getMedbSwitch() {
		return medbSwitch;
	}
	public void setMedbSwitch(String medbSwitch) {
		this.medbSwitch = medbSwitch;
	}
	
	public String getMedbSalCreditSwitch() {
		return medbSalCreditSwitch;
	}
	public void setMedSalCreditSwitch(String medbSalCreditSwitch) {
		this.medbSalCreditSwitch = medbSalCreditSwitch;
	}	
	public String getGlobalWalletSwitch() {
		return globalWalletSwitch;
	}
	public void setGlobalWalletSwitch(String globalWalletSwitch) {
		this.globalWalletSwitch = globalWalletSwitch;
	}
	public String getAsicSwitch() {
		return asicSwitch;
	}
	public void setAsicSwitch(String asicSwitch) {
		this.asicSwitch = asicSwitch;
	}
	public String getLogonPayeesBillersAsyncSwitch() {
		return logonPayeesBillersAsyncSwitch;
	}
	public void setLogonPayeesBillersAsyncSwitch(
			String logonPayeesBillersAsyncSwitch) {
		this.logonPayeesBillersAsyncSwitch = logonPayeesBillersAsyncSwitch;
	}
	//20E3 Switch Cleanup
	/*public String getCompleteFreedomRouteSwitch() {
		return completeFreedomRouteSwitch;
	}
	public void setCompleteFreedomRouteSwitch(String completeFreedomRouteSwitch) {
		this.completeFreedomRouteSwitch = completeFreedomRouteSwitch;
	}*/
// 20 E2 : Commenting out the switch for tech debt to do switch clean up
	//	public String getAccountDetailsRouteSwitch() {
//		return accountDetailsRouteSwitch;
//	}
//	public void setAccountDetailsRouteSwitch(String accountDetailsRouteSwitch) {
//		this.accountDetailsRouteSwitch = accountDetailsRouteSwitch;
//	}
	public String getPayToMobileServiceAndHelpEntry() {
		return payToMobileServiceAndHelpEntry;
	}
	public void setPayToMobileServiceAndHelpEntry(String payToMobileServiceAndHelpEntry) {
		this.payToMobileServiceAndHelpEntry = payToMobileServiceAndHelpEntry;
	}
	//20E3 UI Switch cleanup
	/*public String getIncentiveSaverRouteSwitch() {
		return incentiveSaverRouteSwitch;
	}
	public void setIncentiveSaverRouteSwitch(String incentiveSaverRouteSwitch) {
		this.incentiveSaverRouteSwitch = incentiveSaverRouteSwitch;
	}*/

	public String getMatrixSplashPagePhoneNo() {
		return matrixSplashPagePhoneNo;
	}
	public void setMatrixSplashPagePhoneNo(String matrixSplashPagePhoneNo) {
		this.matrixSplashPagePhoneNo = matrixSplashPagePhoneNo;
	}
	public String getShowMadison() {
		return showMadison;
	}
	public void setShowMadison(String showMadison) {
		this.showMadison = showMadison;
	}
	public String getFixBottomMenuSwitch() {
		return fixBottomMenuSwitch;
	}
	public void setFixBottomMenuSwitch(String fixBottomMenuSwitch) {
		this.fixBottomMenuSwitch = fixBottomMenuSwitch;
	}
	public String getAemAdminTemplateSwitch() {
		return aemAdminTemplateSwitch;
	}
	public void setAemAdminTemplateSwitch(String aemAdminTemplateSwitch) {
		this.aemAdminTemplateSwitch = aemAdminTemplateSwitch;
	}
	public String getGlobalWalletTransferSwitch() {
		return globalWalletTransferSwitch;
	}
	public void setGlobalWalletTransferSwitch(String gwTransferSwitch) {
		this.globalWalletTransferSwitch = gwTransferSwitch;
	}
	public String getNppPayIdAddressBookSwitch() {
		return nppPayIdAddressBookSwitch;
	}
	public void setNppPayIdAddressBookSwitch(String nppPayIdAddressBookSwitch) {
		this.nppPayIdAddressBookSwitch = nppPayIdAddressBookSwitch;
	}
	public String getNppEndToEndIdSwitch() {
		return nppEndToEndIdSwitch;
	}
	public void setNppEndToEndIdSwitch(String nppEndToEndIdSwitch) {
		this.nppEndToEndIdSwitch = nppEndToEndIdSwitch;
	}
	public String getShowCSHTile() {
		return showCSHTile;
	}
	public void setShowCSHTile(String showCSHTile) {
		this.showCSHTile = showCSHTile;
	}
	public String getUpdatePhoneNumberSwitch() {
		return updatePhoneNumberSwitch;
	}
	public void setUpdatePhoneNumberSwitch(String updatePhoneNumberSwitch) {
		this.updatePhoneNumberSwitch = updatePhoneNumberSwitch;
	}
	public String getTransCategoryUpliftSwitch() {
		return transCategoryUpliftSwitch;
	}
	public void setTransCategoryUpliftSwitch(String transCategoryUpliftSwitch) {
		this.transCategoryUpliftSwitch = transCategoryUpliftSwitch;
	}
	public String getLwcSwitch() {
		return lwcSwitch;
	}
	public void setLwcSwitch(String lwcSwitch) {
		this.lwcSwitch = lwcSwitch;
	}
	
	
	
	public String getLwcPendingTransactionSwitch() {
		return lwcPendingTransactionSwitch;
	}
	public void setLwcPendingTransactionSwitch(String lwcPendingTransactionSwitch) {
		this.lwcPendingTransactionSwitch = lwcPendingTransactionSwitch;
	}
	public String getFileShareSwitch() {
		return fileShareSwitch;
	}
	
	public void setFileShareSwitch(String fileShareSwitch) {
		this.fileShareSwitch = fileShareSwitch;
	}
	/**
	 * @return the mgrpSwitch
	 */
	public String getMgrpSwitch() {
		return mgrpSwitch;
	}
	/**
	 * @param mgrpSwitch the mgrpSwitch to set
	 */
	public void setMgrpSwitch(String mgrpSwitch) {
		this.mgrpSwitch = mgrpSwitch;
	}
	public String getCovidSupportHubSwitch() {
		return covidSupportHubSwitch;
	}
	public void setCovidSupportHubSwitch(String covidSupportHubSwitch) {
		this.covidSupportHubSwitch = covidSupportHubSwitch;
	}
	
	public String getWalletEligibilityURL() {
		return walletEligibilityURL;
	}
	public void setWalletEligibilityURL(String walletEligibilityURL) {
		this.walletEligibilityURL = walletEligibilityURL;
	}
	public String getAddCardManuallyURL() {
		return addCardManuallyURL;
	}
	public void setAddCardManuallyURL(String addCardManuallyURL) {
		this.addCardManuallyURL = addCardManuallyURL;
	}
	public String getShowAddCardToWallet() {
		return showAddCardToWallet;
	}
	public void setShowAddCardToWallet(String showAddCardToWallet) {
		this.showAddCardToWallet = showAddCardToWallet;
	}
	public String getShowGoogleMapLWC() {
		return showGoogleMapLWC;
	}
	public void setShowGoogleMapLWC(String showGoogleMapLWC) {
		this.showGoogleMapLWC = showGoogleMapLWC;
	}
	public String getShowBillerHistory() {
		return showBillerHistory;
	}
	public void setShowBillerHistory(String showBillerHistory) {
		this.showBillerHistory = showBillerHistory;
	}
	public String getSmartPlanSwitch() {
		return smartPlanSwitch;
	}
	public void setSmartPlanSwitch(String smartPlanSwitch) {
		this.smartPlanSwitch = smartPlanSwitch;
	}

	public String getLpMessagingSwitch() {
		return lpMessagingSwitch;
	}
	public void setLpMessagingSwitch(String lpMessagingSwitch) {
		this.lpMessagingSwitch = lpMessagingSwitch;
	}
	public String getCshTilePresent() {
		return cshTilePresent;
	}
	public void setCshTilePresent(String cshTilePresent) {
		this.cshTilePresent = cshTilePresent;
	}
	public String getShowActivateCardAddToWallet() {
		return showActivateCardAddToWallet;
	}
	public void setShowActivateCardAddToWallet(String showActivateCardAddToWallet) {
		this.showActivateCardAddToWallet = showActivateCardAddToWallet;
	}
	
	public String[] getLpWebOobStartChatDisplayPages() {
		return lpWebOobStartChatDisplayPages;
	}
	public void setLpWebOobStartChatDisplayPages(String[] lpWebOobStartChatDisplayPages) {
		this.lpWebOobStartChatDisplayPages = lpWebOobStartChatDisplayPages;
	}
	public String[] getLpWebOobMinimizedStateDisplayPages() {
		return lpWebOobMinimizedStateDisplayPages;
	}
	public void setLpWebOobMinimizedStateDisplayPages(String[] lpWebOobMinimizedStateDisplayPages) {
		this.lpWebOobMinimizedStateDisplayPages = lpWebOobMinimizedStateDisplayPages;
	}
	public String[] getLpWebFloatingIconDisplayPages() {
		return lpWebFloatingIconDisplayPages;
	}
	public void setLpWebFloatingIconDisplayPages(String[] lpWebFloatingIconDisplayPages) {
		this.lpWebFloatingIconDisplayPages = lpWebFloatingIconDisplayPages;
	}
	public String[] getLpNativeFloatingIconDisplayPages() {
		return lpNativeFloatingIconDisplayPages;
	}
	public void setLpNativeFloatingIconDisplayPages(String[] lpNativeFloatingIconDisplayPages) {
		this.lpNativeFloatingIconDisplayPages = lpNativeFloatingIconDisplayPages;
	}
	public String[] getLpNativeStartChatDisplayPages() {
		return lpNativeStartChatDisplayPages;
	}
	public void setLpNativeStartChatDisplayPages(String[] lpNativeStartChatDisplayPages) {
		this.lpNativeStartChatDisplayPages = lpNativeStartChatDisplayPages;
	}

	public String getAscendaSwitch() {
		return ascendaSwitch;
	}
	public void setAscendaSwitch(String ascendaSwitch) {
		this.ascendaSwitch = ascendaSwitch;
	}
	public String getGoogleMapApiKey() {
		return googleMapApiKey;
	}
	public void setGoogleMapApiKey(String googleMapApiKey) {
		this.googleMapApiKey = googleMapApiKey;
	}
	public String getTtRestrictHighRiskCtrySwitch() {
		return ttRestrictHighRiskCtrySwitch;
	}
	public void setTtRestrictHighRiskCtrySwitch(String ttRestrictHighRiskCtrySwitch) {
		this.ttRestrictHighRiskCtrySwitch = ttRestrictHighRiskCtrySwitch;
	}

	public String getCardAutoPaySwitch() {
		return cardAutoPaySwitch;
	}
	public void setCardAutoPaySwitch(String cardAutoPaySwitch) {
		this.cardAutoPaySwitch = cardAutoPaySwitch;
	}
	public String getManagePreferencesSwitch() {
		return managePreferencesSwitch;
	}
	public void setManagePreferencesSwitch(String managePreferencesSwitch) {
		this.managePreferencesSwitch = managePreferencesSwitch;
	}
	public String getMadisonLCMSwitch() {
		return madisonLCMSwitch;
	}
	public void setMadisonLCMSwitch(String madisonLCMSwitch) {
		this.madisonLCMSwitch = madisonLCMSwitch;
	}
	public String getNppABNPayIdRegSwitch() {
		return nppABNPayIdRegSwitch;
	}
	public void setNppABNPayIdRegSwitch(String nppABNPayIdRegSwitch) {
		this.nppABNPayIdRegSwitch = nppABNPayIdRegSwitch;
	}
	public String getSmartPlanFeeMsgSwitch() {
		return smartPlanFeeMsgSwitch;
	}
	public void setSmartPlanFeeMsgSwitch(String smartPlanFeeMsgSwitch) {
		this.smartPlanFeeMsgSwitch = smartPlanFeeMsgSwitch;
	}
	public String getAcctToIndexValidationSwitch() {
		return acctToIndexValidationSwitch;
	}
	public void setAcctToIndexValidationSwitch(String acctToIndexValidationSwitch) {
		this.acctToIndexValidationSwitch = acctToIndexValidationSwitch;
	}

	public String getFileShareOAuthIDPSwitch() {
		return fileShareOAuthIDPSwitch;
	}

	public void setFileShareOAuthIDPSwitch(String fileShareOAuthIDPSwitch) {
		this.fileShareOAuthIDPSwitch = fileShareOAuthIDPSwitch;
	}
}
