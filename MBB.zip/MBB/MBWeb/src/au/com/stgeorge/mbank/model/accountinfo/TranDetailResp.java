/**
 * 
 */
package au.com.stgeorge.mbank.model.accountinfo;

import java.util.Date;

import au.com.stgeorge.mbank.util.JsonDateTimeSerializer;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;

/**
 * @author C50216
 *
 */
@JsonInclude(Include.NON_NULL)
public class TranDetailResp{
	
    private Date date;
    private String desc;
    private String desc2;
    private String amt;    
    private Boolean isDebit=false;
    private String tranCategory;
    private String tranCategoryId;
	private String tranSubCategory;
	private String iconName;
	private Integer searchFlag;
	private String searchString;
	private String pRPaymentId;
	private String nppTranType;
	private Boolean isDisputable;
	private String refNum;
	private String runningBalance;   
	private Date effectiveDate;
	private String lwcDesc;
	private Boolean isPayInstalment = false;
	
	// 20E4 Smart plan
	private Integer smartPlanStatus;
	private Integer smartPlanInstalmentLeft ;
	private Integer smartPlanOriginalPlanTerm;
	
	private String smartPlanTransactionAmount;
	private String smartPlanNextPaymentAmount;
	private Date smartPlanPaymentDueDate;
	private Date smartPlanPaidOutDate;
	    
	
	
    @JsonSerialize(using = JsonDateTimeSerializer.class)
	@JsonInclude(Include.NON_NULL)
	public Date getDate() {
		return date;
	}
	public void setDate(Date date) {
		this.date = date;
	}
	public String getDesc() {
		return desc;
	}
	public void setDesc(String desc) {
		this.desc = desc;
	}
	public String getDesc2() {
		return desc2;
	}
	public void setDesc2(String desc2) {
		this.desc2 = desc2;
	}
	public String getAmt() {
		return amt;
	}
	public void setAmt(String amt) {
		this.amt = amt;
	}
	public Boolean isDebit() {
		return isDebit;
	}
	public void setDebit(Boolean isDebit) {
		this.isDebit = isDebit;
	}
	public String getTranCategory() {
		return tranCategory;
	}
	public void setTranCategory(String tranCategory) {
		this.tranCategory = tranCategory;
	}
	public String getTranSubCategory() {
		return tranSubCategory;
	}
	public void setTranSubCategory(String tranSubCategory) {
		this.tranSubCategory = tranSubCategory;
	}
	public String getIconName() {
		return iconName;
	}
	public void setIconName(String iconName) {
		this.iconName = iconName;
	}
	public Integer getSearchFlag() {
		return searchFlag;
	}
	public void setSearchFlag(Integer searchFlag) {
		this.searchFlag = searchFlag;
	}
	public String getSearchString() {
		return searchString;
	}
	public void setSearchString(String searchString) {
		this.searchString = searchString;
	}
	public String getpRPaymentId() {
		return pRPaymentId;
	}
	public void setpRPaymentId(String pRPaymentId) {
		this.pRPaymentId = pRPaymentId;
	}
	public String getRunningBalance()
	{
		return runningBalance;
	}
	public void setRunningBalance(String runningBalance)
	{
		this.runningBalance = runningBalance;
	}
	public Boolean getIsDisputable() {
		return isDisputable;
	}
	public void setIsDisputable(Boolean isDisputable) {
		this.isDisputable = isDisputable;
	}
	public String getRefNum() {
		return refNum;
	}
	public void setRefNum(String refNum) {
		this.refNum = refNum;
	}
	public String getTranCategoryId() {
		return tranCategoryId;
	}
	public void setTranCategoryId(String tranCategoryId) {
		this.tranCategoryId = tranCategoryId;
	}
	public String getNppTranType() {
		return nppTranType;
	}
	public void setNppTranType(String nppTranType) {
		this.nppTranType = nppTranType;
	}
	
	public String getLwcDesc() {
		return lwcDesc;
	}
	public void setLwcDesc(String lwcDesc) {
		this.lwcDesc = lwcDesc;
	}
	@JsonSerialize(using = JsonDateTimeSerializer.class)
	public Date getEffectiveDate() {
		return effectiveDate;
	}

	public void setEffectiveDate(Date effectiveDate) {
		this.effectiveDate = effectiveDate;
	}
	public Boolean getIsPayInstalment() {
		return isPayInstalment;
	}
	public void setIsPayInstalment(Boolean isPayInstalment) {
		this.isPayInstalment = isPayInstalment;
	}
	public Integer getSmartPlanStatus() {
		return smartPlanStatus;
	}
	public void setSmartPlanStatus(Integer smartPlanStatus) {
		this.smartPlanStatus = smartPlanStatus;
	}
	public Integer getSmartPlanInstalmentLeft() {
		return smartPlanInstalmentLeft;
	}
	public void setSmartPlanInstalmentLeft(Integer smartPlanInstalmentLeft) {
		this.smartPlanInstalmentLeft = smartPlanInstalmentLeft;
	}
	public Integer getSmartPlanOriginalPlanTerm() {
		return smartPlanOriginalPlanTerm;
	}
	public void setSmartPlanOriginalPlanTerm(Integer smartPlanOriginalPlanTerm) {
		this.smartPlanOriginalPlanTerm = smartPlanOriginalPlanTerm;
	}
	public String getSmartPlanTransactionAmount() {
		return smartPlanTransactionAmount;
	}
	public void setSmartPlanTransactionAmount(String smartPlanTransactionAmount) {
		this.smartPlanTransactionAmount = smartPlanTransactionAmount;
	}
	public String getSmartPlanNextPaymentAmount() {
		return smartPlanNextPaymentAmount;
	}
	public void setSmartPlanNextPaymentAmount(String smartPlanNextPaymentAmount) {
		this.smartPlanNextPaymentAmount = smartPlanNextPaymentAmount;
	}
	
	@JsonSerialize(using = JsonDateTimeSerializer.class)
	public Date getSmartPlanPaymentDueDate() {
		return smartPlanPaymentDueDate;
	}
	public void setSmartPlanPaymentDueDate(Date smartPlanPaymentDueDate) {
		this.smartPlanPaymentDueDate = smartPlanPaymentDueDate;
	}
	
	@JsonSerialize(using = JsonDateTimeSerializer.class)
	public Date getSmartPlanPaidOutDate() {
		return smartPlanPaidOutDate;
	}
	public void setSmartPlanPaidOutDate(Date smartPlanPaidOutDate) {
		this.smartPlanPaidOutDate = smartPlanPaidOutDate;
	}
	
}
