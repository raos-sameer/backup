package au.com.stgeorge.mbank.controller.loanApplication;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import com.fasterxml.jackson.databind.ObjectMapper;
import au.com.stgeorge.framework.common.logging.Logger;
import au.com.stgeorge.ibank.businessobject.BusinessException;
import au.com.stgeorge.ibank.businessobject.ResourceException;
import au.com.stgeorge.ibank.businessobject.loanapplication.LoanApplicationService;
import au.com.stgeorge.ibank.common.cache.IBankParams;
import au.com.stgeorge.ibank.loanApplication.LoanApplicationDetail;
import au.com.stgeorge.ibank.valueobject.Customer;
import au.com.stgeorge.ibank.valueobject.EContractDetails;
import au.com.stgeorge.ibank.valueobject.NonFinTransactionDetails;
import au.com.stgeorge.ibank.valueobject.Statistic;
import au.com.stgeorge.ibank.valueobject.transfer.IBankCommonData;
import au.com.stgeorge.mbank.controller.IMBController;
import au.com.stgeorge.mbank.controller.SecureCodeHelper;
import au.com.stgeorge.mbank.model.common.IMBReq;
import au.com.stgeorge.mbank.model.common.IMBResp;
import au.com.stgeorge.mbank.model.common.ReqHeader;
import au.com.stgeorge.mbank.model.common.RespHeader;
import au.com.stgeorge.mbank.model.request.EmptyReq;
import au.com.stgeorge.mbank.model.request.SecureCodeReq;
import au.com.stgeorge.mbank.model.response.ErrorResp;
import au.com.stgeorge.mbank.session.MobileSession;
import au.com.stgeorge.mbank.session.MobileSessionImpl;
import au.com.stgeorge.mbank.util.MBAppHelper;
import au.com.stgeorge.mbank.util.MBAppUtils;
import au.com.stgeorge.mbank.util.MBAppValidator;
import au.com.stgeorge.mbank.util.ServiceConstants;
import au.com.stgeorge.perflogger.PerformanceLogger;

/**
 * @author c70714
 *
 */
@Controller
@RequestMapping("/eContract")
public class EContractApplicationController implements IMBController {

	@Autowired
	private EContractApplicationHelper eContractHelper;

	@Autowired
	private MBAppHelper mbAppHelper;
	
	@Autowired
	private MBAppValidator mbAppValidator;

	@Autowired
	private SecureCodeHelper secureCodeHelper;
	
	@Autowired
	private LoanApplicationService loanService;
	
	
	@RequestMapping(method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE, value = "reqSecureCode")
	@ResponseBody
	public IMBResp reqSecureCode(HttpServletRequest httpRequest, @RequestBody final SecureCodeReq request) {
		
		PerformanceLogger performanceLogger = new PerformanceLogger();
		performanceLogger.startAllLogs();
		String logName = MBAppUtils.getLogName(httpRequest);
		performanceLogger.startLog(logName);
		Logger.debug("EContractApplicationController - reqSecureCode(). Request: " + request, this.getClass());

		MobileSession mobileSession = null;
		IBankCommonData commonData = null;
		try {
			mobileSession = mbAppHelper.getMobileSession(httpRequest);
			commonData = new MBAppHelper().populateIBankCommonData(mobileSession, httpRequest);
			validateRequestHeader(request.getHeader(), httpRequest);
			ErrorResp errorResponse = validate(request, httpRequest);
			
			if (errorResponse.hasErrors()){
				return errorResponse;
			}
			
			if (ServiceConstants.PERSONAL_LOAN_2FA_TRAN_CODE != request.getTranType()) {
				return MBAppUtils.createInvalid2FATransactionTypeResponse(ServiceConstants.ECONTRACT_REQ_SECURE_CODE);
			}

			EContractDetails eContractDtls = new EContractDetails();
			eContractDtls.setProductActionType(IBankParams.PERSONAL_LOAN);
			
			return secureCodeHelper.reqSecureCode(commonData, mobileSession, null, eContractDtls, request,ServiceConstants.ECONTRACT_REQ_SECURE_CODE, httpRequest);
		} catch (ResourceException e) {
			Logger.error("ResourceException in EContractApplicationController - reqSecureCode() - [key: "+ e.getKey()+ "], GCIS: ["+ ((mobileSession != null && mobileSession.getCustomer() != null) ? mobileSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			mobileSession.removeSecureCodeDetails();
			return MBAppUtils.createErrorResp(IBankParams.getBaseOriginCode(mobileSession.getOrigin()),BusinessException.SYSTEM_UNAVILABLE,ServiceConstants.ECONTRACT_REQ_SECURE_CODE, httpRequest);
		} catch (Exception e) {
			Logger.error("Exception EContractApplicationController - reqSecureCode(): GCIS: [" + ((mobileSession != null && mobileSession.getCustomer() != null) ? mobileSession.getCustomer().getGcis() : "") + "]", e, this.getClass());
			mobileSession.removeSecureCodeDetails();
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(),BusinessException.GENERIC_ERROR,ServiceConstants.PAYIDREG_SECURE_CODE, httpRequest);
		} finally {
			performanceLogger.endLog(logName);
			performanceLogger.endAllLogs();
		}
	}	

	
	@RequestMapping(value="verifySecCodeEcontract", method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public IMBResp verifySecCodeEcontract(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, @RequestBody final SecureCodeReq req)
	{
		Logger.debug("In verifySecCodeEcontract ( EContractApplicationController )  for Customer " +  "  " + httpServletRequest.getContentType() + " "
				+ httpServletRequest.getRemoteAddr() + "  " + httpServletResponse.getCharacterEncoding() + httpServletResponse.getLocale() +
				" True IP >> " + httpServletRequest.getHeader(IBankParams.trueClientIP()), this.getClass());

		PerformanceLogger performanceLogger = new PerformanceLogger();
		performanceLogger.startAllLogs();
		String logName = MBAppUtils.getLogName(httpServletRequest);
		performanceLogger.startLog(logName);
		ObjectMapper mapper = new ObjectMapper();
		MobileSession mbSession = null;
		String arn = "";
		String desc = "";
		
		try
		{
			mbSession = mbAppHelper.getMobileSession(httpServletRequest);

			validateRequestHeader(req.getHeader(), httpServletRequest);

			ErrorResp errorResp = validate(req, httpServletRequest);
			if (errorResp != null && errorResp.getErrors() != null && errorResp.getErrors().size() > 0){
				return errorResp;
			}
			
			IBankCommonData ibankCommonData=mbAppHelper.populateIBankCommonData(mbSession,httpServletRequest);
			
			ErrorResp errorResponse = secureCodeHelper.verifySecureCode(ibankCommonData, mbSession, new NonFinTransactionDetails(){}, req, ServiceConstants.ECONTRACT_VERIFY_SECURE_CODE, httpServletRequest);
			if (errorResponse.hasErrors()){
				return errorResponse;
			}
			
			mbSession.setSecureCodeVerifiedTranName(ServiceConstants.ECONTRACT_VERIFY_SECURE_CODE);

			//if authenticated //
			Logger.info("Authenticated 2FA", this.getClass());
			if(mbSession.getLoanApplicationDetail()!=null){
				Logger.debug("mbSession getLoanApplicationDetail not null", getClass());
				arn = mbSession.getLoanApplicationDetail().getAppRefNum();
			}
			
			Logger.debug("arn from session is ::"+arn, getClass());
			desc="ARN:"+arn+"; RedirectTo: ACE Accept eContract"; 
			loanService.makeStatisticsLog(ibankCommonData,desc,Statistic.DIRECT_EXTERNAL_LINK);
			Logger.info("Statistics Log Created", this.getClass());
			
			IMBResp serviceResponse = eContractHelper.populateEcontractResp();
		
			Logger.info("verifySecCodeEcontract JSON Response :" + mapper.writeValueAsString(serviceResponse), this.getClass());
			RespHeader headerResp = populateResponseHeader(ServiceConstants.ECONTRACT_VERIFY_SECURE_CODE, mbSession);
			serviceResponse.setHeader(headerResp);
			
			return serviceResponse;
		} catch (BusinessException e) {
			Logger.error("Exception Inside verifySecCodeEcontract() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			IMBResp resp1 = MBAppUtils.createErrorResp(IBankParams.getBaseOriginCode(mbSession.getOrigin()), e, ServiceConstants.ECONTRACT_VERIFY_SECURE_CODE, httpServletRequest);
			return resp1;
		} catch (Exception e)
		{
			Logger.error("Exception Inside verifySecCodeEcontract() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			BusinessException exp = new BusinessException(BusinessException.SMPL_SYS_ERROR);
			IMBResp resp1 = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, ServiceConstants.ECONTRACT_VERIFY_SECURE_CODE, httpServletRequest);
			return resp1;
		} finally
		{
			performanceLogger.endLog(logName);
			performanceLogger.endAllLogs();
		}
	}
	
	
	@RequestMapping(value="performStatistic", method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public IMBResp performStatistic(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, @RequestBody final EmptyReq request)
	{
		Logger.debug("EContractApplicationController - performStatistic Request: " + request, this.getClass());

		PerformanceLogger performanceLogger = new PerformanceLogger();
		performanceLogger.startAllLogs();
		String logName = MBAppUtils.getLogName(httpServletRequest);
		performanceLogger.startLog(logName);
		MobileSession mbSession = null;
		String arn = "";
		String desc ="";
		
		try
		{
			mbSession = mbAppHelper.getMobileSession(httpServletRequest);
			validateRequestHeader(request.getHeader(), httpServletRequest);
			ErrorResp errorResp = validate(request, httpServletRequest);
			if (errorResp != null && errorResp.getErrors() != null && errorResp.getErrors().size() > 0){
				return errorResp;
			}
			
			IBankCommonData ibankCommonData=mbAppHelper.populateIBankCommonData(mbSession,httpServletRequest);
			if(mbSession.getLoanApplicationDetail()!=null){
				Logger.debug("mbSession getLoanApplicationDetail not null", getClass());
				arn = mbSession.getLoanApplicationDetail().getAppRefNum();
			}
			 Logger.debug("arn from session is ::"+arn, getClass());
			 //desc="ARN:"+arn+"; RedirectTo: ACE Accept eContract"; 
			 loanService.makeStatisticsLog(ibankCommonData,arn,Statistic.GHOST_TILE_TO_APPL);
			 Logger.info("Statistics Log Created", this.getClass());
			Logger.info("Statistics Log Created", this.getClass());
			IMBResp serviceResponse = eContractHelper.populatePerformStatisticResp();
			return serviceResponse;
		} catch (BusinessException e) {
			Logger.error("Exception Inside performStatistic() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			IMBResp resp1 = MBAppUtils.createErrorResp(IBankParams.getBaseOriginCode(mbSession.getOrigin()), e, ServiceConstants.ECONTRACT_VERIFY_SECURE_CODE, httpServletRequest);
			return resp1;
		} catch (Exception e)
		{
			Logger.error("Exception Inside performStatistic() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			BusinessException exp = new BusinessException(BusinessException.SMPL_SYS_ERROR);
			IMBResp resp1 = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, ServiceConstants.ECONTRACT_VERIFY_SECURE_CODE, httpServletRequest);
			return resp1;
		} finally
		{
			performanceLogger.endLog(logName);
			performanceLogger.endAllLogs();
		}
	}
	
	
	@PostMapping(value = "authenticate", headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public IMBResp is2FARequired(HttpServletRequest httpServletRequest,HttpServletResponse httpServletResponse,@RequestBody final EmptyReq req) { 

		PerformanceLogger performanceLogger = new PerformanceLogger();
		performanceLogger.startAllLogs();
		String logName = MBAppUtils.getLogName(httpServletRequest);
		performanceLogger.startLog(logName);
		
		ObjectMapper objectMapper = new ObjectMapper();					
		MobileSession mobileSession = new MobileSessionImpl();
		try{
			mobileSession.getSessionContext(httpServletRequest);
			validateRequestHeader(req.getHeader(), httpServletRequest);
			ErrorResp errorResp = validate(req, httpServletRequest);
			IMBResp serviceResponse = null;
			boolean authRequired = true;
			if (errorResp != null && errorResp.getErrors() != null && errorResp.getErrors().size() > 0)	{				
				return errorResp;				
			}else{								
				Customer customer = mobileSession.getCustomer();				
				IBankCommonData commonData=mbAppHelper.populateIBankCommonData(mobileSession,httpServletRequest);
				commonData.setCustomer(customer);
				
				LoanApplicationDetail loanAppDetail = loanService.getLoanApplicationDetails(commonData);
				authRequired = loanService.redirectToZoom2FASecurePage(commonData,loanAppDetail);
				
                RespHeader headerResp = populateResponseHeader(req.getHeader().getServiceName(), mobileSession);
                serviceResponse = eContractHelper.populate2FARequiredResponse(authRequired);
				serviceResponse.setHeader(headerResp);		
                
				Logger.debug("Authenticate response :" + objectMapper.writeValueAsString(serviceResponse), this.getClass());
				return serviceResponse;
			}				
		} catch (Exception e){
			Logger.error("Exception in EContractApplicationController GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.GENERIC_ERROR, ServiceConstants.ECONTRACT, httpServletRequest);
		} finally {
			performanceLogger.endLog(logName);
			performanceLogger.endAllLogs();
		}
	}
	
	@ExceptionHandler({org.springframework.http.converter.HttpMessageNotReadableException.class})
	@ResponseStatus(org.springframework.http.HttpStatus.OK)
	@ResponseBody
	public IMBResp resolveException() {		
		return MBAppUtils.createInvalidMessageBodyResponse(ServiceConstants.ECONTRACT);
	}
	
	public ErrorResp validate(IMBReq serviceRequest, HttpServletRequest request) {
		return  mbAppValidator.validate(serviceRequest, request);
	}
	
	public void validateRequestHeader(ReqHeader header, HttpServletRequest request) throws ResourceException
	{	
		mbAppValidator.validateRequestHeader(header,  request);	
	}
	
	public RespHeader populateResponseHeader(String ServiceName)
	{		
		return mbAppHelper.populateResponseHeader(ServiceName);
	}				
	
	public RespHeader populateResponseHeader(String serviceName, MobileSession mobSession )
	{
		return mbAppHelper.populateResponseHeader(serviceName, mobSession);
	}
	
}
