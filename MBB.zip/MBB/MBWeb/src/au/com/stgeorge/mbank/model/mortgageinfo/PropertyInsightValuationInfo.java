package au.com.stgeorge.mbank.model.mortgageinfo;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_NULL)
public class PropertyInsightValuationInfo {
	private String estimateHighValue;
	private String estimateLowValue;
	private Long numOfBedRooms;
	private Long numOfBathRooms;
	private Long numberOfCarSpaces;
	private String confidenceLevel;
	private String valuationDate;
	private String lastFetchedDate;

	public String getEstimateHighValue() {
		return estimateHighValue;
	}

	public void setEstimateHighValue(String estimateHighValue) {
		this.estimateHighValue = estimateHighValue;
	}

	public String getEstimateLowValue() {
		return estimateLowValue;
	}

	public void setEstimateLowValue(String estimateLowValue) {
		this.estimateLowValue = estimateLowValue;
	}

	public Long getNumOfBedRooms() {
		return numOfBedRooms;
	}

	public void setNumOfBedRooms(Long numOfBedRooms) {
		this.numOfBedRooms = numOfBedRooms;
	}

	public Long getNumOfBathRooms() {
		return numOfBathRooms;
	}

	public void setNumOfBathRooms(Long numOfBathRooms) {
		this.numOfBathRooms = numOfBathRooms;
	}

	public Long getNumberOfCarSpaces() {
		return numberOfCarSpaces;
	}

	public void setNumberOfCarSpaces(Long numberOfCarSpaces) {
		this.numberOfCarSpaces = numberOfCarSpaces;
	}

	public String getConfidenceLevel() {
		return confidenceLevel;
	}

	public void setConfidenceLevel(String confidenceLevel) {
		this.confidenceLevel = confidenceLevel;
	}

	public String getValuationDate() {
		return valuationDate;
	}

	public void setValuationDate(String valuationDate) {
		this.valuationDate = valuationDate;
	}

	public String getLastFetchedDate() {
		return lastFetchedDate;
	}

	public void setLastFetchedDate(String lastFetchedDate) {
		this.lastFetchedDate = lastFetchedDate;
	}

}
