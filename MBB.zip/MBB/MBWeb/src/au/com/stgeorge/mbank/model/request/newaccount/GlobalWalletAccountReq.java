package au.com.stgeorge.mbank.model.request.newaccount;

import javax.validation.constraints.NotNull;

import au.com.stgeorge.ibank.businessobject.BusinessException;
import au.com.stgeorge.mbank.model.common.IMBReq;
import au.com.stgeorge.mbank.model.common.ReqHeader;

public class GlobalWalletAccountReq implements IMBReq{

	private static final long serialVersionUID = -8619853234497299425L;
	
	private ReqHeader header;
	
	
	//TODO	
	@NotNull(message = "" + BusinessException.WSVC_INVALID_INPUT_PARAM)
	private Integer accountIndex;
	
	public Integer getAccountIndex() {
		return accountIndex;
	}	
	public void setAccountIndex(Integer accountIndex) {
		this.accountIndex = accountIndex;
	}
	
	public ReqHeader getHeader()
	{
		return header;
	}
	public void setHeader(ReqHeader header)
	{
		this.header = header;
	}
	
	public static long getSerialVersionUID() {
		return serialVersionUID;
	}
	
}
