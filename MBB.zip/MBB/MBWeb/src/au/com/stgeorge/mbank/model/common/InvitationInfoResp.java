package au.com.stgeorge.mbank.model.common;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_NULL)
public class InvitationInfoResp implements Serializable  {
	/**
	 * 
	 */
	private static final long serialVersionUID = -1292464319521330126L;
	/**
	 * 
	 */
	public String getAccountName() {
		return accountName;
	}
	public void setAccountName(String accountName) {
		this.accountName = accountName;
	}
	public String getDetail() {
		return detail;
	}
	public void setDetail(String detail) {
		this.detail = detail;
	}
	public String getUnlockText() {
		return unlockText;
	}
	public void setUnlockText(String unlockText) {
		this.unlockText = unlockText;
	}
	public String getProductType() {
		return productType;
	}
	public void setProductType(String productType) {
		this.productType = productType;
	}
	public String getCcAmount() {
		return ccAmount;
	}
	public void setCcAmount(String ccAmount) {
		this.ccAmount = ccAmount;
	}
	public String getPlAmount() {
		return plAmount;
	}
	public void setPlAmount(String plAmount) {
		this.plAmount = plAmount;
	}



	private String ccAmount;
	private String plAmount;
	private String accountName;
	private String detail;
	private String productType;
	private String unlockText;
	

	  @Override public String toString() {
		    StringBuilder result = new StringBuilder();
		    String NEW_LINE = System.getProperty("line.separator");

		    result.append(this.getClass().getName() + " Object {" + NEW_LINE);
		    result.append(" ccAmount: " + ccAmount + NEW_LINE);
		    result.append(" plAmount: " + plAmount + NEW_LINE);
		    result.append(" accountName: " + accountName + NEW_LINE );
		    result.append(" detail: " + detail + NEW_LINE);
		    //Note that Collections and Maps also override toString
		    result.append(" productType: " + productType + NEW_LINE);
		    result.append(" unlockText: " + unlockText + NEW_LINE);
//		    if(getHeader() != null){
//		    result.append(" clientApiVersion: " + getHeader().getClientApiVersion() + NEW_LINE);
//		    result.append(" nameId: " + getHeader().getNameId() + NEW_LINE);
//		    result.append(" serviceName: " + getHeader().getServiceName() + NEW_LINE);
//		    }
		    result.append("}");

		    return result.toString();
		  }
}
