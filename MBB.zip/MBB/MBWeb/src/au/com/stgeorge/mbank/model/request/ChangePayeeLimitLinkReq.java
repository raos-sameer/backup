package au.com.stgeorge.mbank.model.request;


import java.io.Serializable;

import javax.validation.constraints.Pattern;

import org.apache.commons.lang.builder.ReflectionToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;
import org.hibernate.validator.constraints.NotEmpty;

import au.com.stgeorge.ibank.businessobject.BusinessException;
import au.com.stgeorge.mbank.model.common.IMBReq;
import au.com.stgeorge.mbank.model.common.ReqHeader;


public class ChangePayeeLimitLinkReq implements IMBReq, Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	protected static final String STR_PATTERN = "^[a-zA-Z]*$";

	private ReqHeader header;

	@NotEmpty(message = "" + BusinessException.WSVC_INVALID_INPUT_PARAM)
	@Pattern(regexp = "^[0-9]+$", message = "" + BusinessException.WSVC_INVALID_INPUT_PARAM)
	private String index;
	
	@Pattern(regexp = STR_PATTERN, message = "{errors.source.invalid}")
	private String source;
	
	private boolean sourceSecurityWellBeingCheck;
    
	public boolean isSourceSecurityWellBeingCheck() {
		return sourceSecurityWellBeingCheck;
	}
	public void setSourceSecurityWellBeingCheck(boolean sourceSecurityWellBeingCheck) {
		this.sourceSecurityWellBeingCheck = sourceSecurityWellBeingCheck;
	}
	public String getIndex() {
		return index;
	}

	public ReqHeader getHeader() {
		return header;
	}

	public void setHeader(ReqHeader header) {
		this.header = header;
	}

	@Override
	public String toString() {
		return ReflectionToStringBuilder.toString(this, ToStringStyle.MULTI_LINE_STYLE);
	}

	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}

}
