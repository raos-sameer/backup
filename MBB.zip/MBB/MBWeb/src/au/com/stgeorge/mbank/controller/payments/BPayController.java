package au.com.stgeorge.mbank.controller.payments;

import java.util.Calendar;
import java.util.Date;
import java.util.List;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.builder.ReflectionToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;

import au.com.stgeorge.digitalsec.logger.DigitalSecLogger;
import au.com.stgeorge.digitalsec.logger.DigitalSecLogggerVO;
import au.com.stgeorge.framework.common.logging.Logger;
import au.com.stgeorge.framework.common.util.DateMethods;
import au.com.stgeorge.ibank.businessobject.BPayService;
import au.com.stgeorge.ibank.businessobject.BusinessException;
import au.com.stgeorge.ibank.businessobject.CustomerService;
import au.com.stgeorge.ibank.businessobject.DuplicateException;
import au.com.stgeorge.ibank.businessobject.HeartBeat;
import au.com.stgeorge.ibank.businessobject.IBankSecureService;
import au.com.stgeorge.ibank.businessobject.MemoryThrottlingService;
import au.com.stgeorge.ibank.businessobject.PaymentService;
import au.com.stgeorge.ibank.businessobject.ResourceException;
import au.com.stgeorge.ibank.common.cache.IBankParams;
import au.com.stgeorge.ibank.safi.businessobject.Safi2Service;
import au.com.stgeorge.ibank.safi.util.SafiConstants;
import au.com.stgeorge.ibank.safi.util.SafiUtil;
import au.com.stgeorge.ibank.safi.valueobject.SafiPayTranVO;
import au.com.stgeorge.ibank.service.valueobject.SafiRespVO;
import au.com.stgeorge.ibank.servicestation.businessobject.ServiceStation;
import au.com.stgeorge.ibank.servicestation.businessobject.ServiceStationImpl;
import au.com.stgeorge.ibank.servicestation.businessobject.valueobject.ServiceStationVO;
import au.com.stgeorge.ibank.servicestation.util.ServicetationConstants;
import au.com.stgeorge.ibank.util.CommonBusinessUtil;
import au.com.stgeorge.ibank.util.StringUtil;
import au.com.stgeorge.ibank.valueobject.Account;
import au.com.stgeorge.ibank.valueobject.BPayPayment;
import au.com.stgeorge.ibank.valueobject.Biller;
import au.com.stgeorge.ibank.valueobject.BillerMaster;
import au.com.stgeorge.ibank.valueobject.Customer;
import au.com.stgeorge.ibank.valueobject.PaymentDuplicateVO;
import au.com.stgeorge.ibank.valueobject.PaymentsLog;
import au.com.stgeorge.ibank.valueobject.PhoneNumber;
import au.com.stgeorge.ibank.valueobject.Receipt;
import au.com.stgeorge.ibank.valueobject.collection.LabelValueMap;
import au.com.stgeorge.ibank.valueobject.database.CodesVO;
import au.com.stgeorge.ibank.valueobject.database.OriginsVO;
import au.com.stgeorge.ibank.valueobject.transfer.IBankCommonData;
import au.com.stgeorge.mbank.controller.IMBController;
import au.com.stgeorge.mbank.controller.SafiWebHelper;
import au.com.stgeorge.mbank.controller.SecureCodeHelper;
import au.com.stgeorge.mbank.controller.customer.LogonHelper;
import au.com.stgeorge.mbank.model.common.IMBReq;
import au.com.stgeorge.mbank.model.common.IMBResp;
import au.com.stgeorge.mbank.model.common.ReqHeader;
import au.com.stgeorge.mbank.model.common.RespHeader;
import au.com.stgeorge.mbank.model.request.IndexReq;
import au.com.stgeorge.mbank.model.request.SecureCodeReq;
import au.com.stgeorge.mbank.model.request.payments.AddBillerReq;
import au.com.stgeorge.mbank.model.request.payments.BPayTransferReq;
import au.com.stgeorge.mbank.model.request.payments.BillerDetailsReq;
import au.com.stgeorge.mbank.model.request.payments.BPayReceiptsRequest;
import au.com.stgeorge.mbank.model.response.ErrorResp;
import au.com.stgeorge.mbank.model.response.payments.TransferResp;
import au.com.stgeorge.mbank.session.MobileSession;
import au.com.stgeorge.mbank.session.MobileSessionImpl;
import au.com.stgeorge.mbank.util.MBAppHelper;
import au.com.stgeorge.mbank.util.MBAppUtils;
import au.com.stgeorge.mbank.util.MBAppValidator;
import au.com.stgeorge.mbank.util.ServiceConstants;
import au.com.stgeorge.mobilebank.businessobject.BillerService;
import au.com.stgeorge.mobilebank.businessobject.MobileBankService;
import au.com.stgeorge.mobilebank.businessobject.TransactService;
import au.com.stgeorge.perflogger.PerformanceLogger;
import au.com.stgeorge.security.util.StringMethods;

/**
 * BPay Transfer service
 * 
 * @author C38854
 * 
 */
@Controller
@RequestMapping("/bpay")
public class BPayController implements IMBController {

	public static final String Y = "Y";
	public static final String N = "N";
	
	@Autowired
	private TransactService transactService;

	@Autowired
	private BPayHelper helper;

	@Autowired
	private SecureCodeHelper secureCodeHelper;

	@Autowired
	private MobileBankService mobileBankService;
	
	
	@Autowired
	private MBAppValidator mbAppValidator;
	
	@Autowired
	private MBAppHelper mbAppHelper;
	
	@Autowired
	private BillerService billerService;
	
    @Autowired
    private DigitalSecLogger digitalSecLogger;

    @Autowired
	private ServiceStation serviceStationService;
    
    @Autowired
   	private LogonHelper logonHelper;
    
    @Autowired
    private Safi2Service safi2Service;
    
	@Autowired
	private MemoryThrottlingService memoryThrottlingService;
	
	@Autowired
	private PayeeHelper payeeHelper;
	/**
	 * BPay transfer service operation
	 * 
	 * @param httpRequest
	 * @param request
	 * @return
	 */
	@RequestMapping(method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE, value = "transfer")
	@ResponseBody
	public IMBResp transfer(HttpServletRequest httpRequest,HttpServletResponse httpResponse, @RequestBody final BPayTransferReq request) {
		Logger.debug("BPayController - transfer(). Request: " + request, this.getClass());
		String logName = startPerformanceLog(httpRequest);
		MobileSession mobileSession = new MobileSessionImpl();
		BPayPayment payment = null;
		String validDecodedPrint = null;
		String devicePrint = null;
		try {
			mobileSession.getSessionContext(httpRequest);
			Customer customer = mobileSession.getCustomer();
			IBankCommonData commonData = new MBAppHelper().populateIBankCommonData(mobileSession, httpRequest);
			helper.populateBillerList(commonData, customer);
			
			validateRequestHeader(request.getHeader(), httpRequest);
			ErrorResp errorResponse = validate(request, httpRequest);
			if (errorResponse.hasErrors())
				return errorResponse;

			// Validation for account index to account number
			boolean isAcctToIndexValidationSwitchOn=IBankParams.isSwitchOn(IBankParams.ACCT_TO_INDEX_VALIDATION_SWITCH);
			if(isAcctToIndexValidationSwitchOn) {
				String fromAccountNumber=request.getFromAccountNumber();
				String fromAccountNumberMasked=request.getFromAccountNumberMasked();
							
				String toAccountNumber=request.getToBillerCode();
							
				boolean isValidAcctToIndex=mbAppHelper.isValidIndextoAcct(fromAccountNumber, fromAccountNumberMasked, request.getFromAccountIndex(), toAccountNumber, null, request.getToBillerIndex(), "BPAYTransfer", commonData);
							
				if(!isValidAcctToIndex) {
					//throw new business exception
					Logger.error("BPayController - transfer(). Index-Account MisMatch", this.getClass());
					throw new BusinessException(BusinessException.ACCOUNT_TO_INDEX_MISMATCH, "Account-Index mismatch");
				}
			}
			
			Account fromAccount = customer.getAccounts().get(request.getFromAccountIndex());

			Biller biller = customer.getBillers().get(request.getToBillerIndex());
			// remove leading zeros from biller code
			String billerCode = StringMethods.removeLeadingZero(biller.getCode().trim());

			BillerMaster billerDetails = mobileBankService.getBillerDetails(billerCode);
			helper.validateBPayTransferReq(request, billerDetails);
			payment = helper.populatePayment(fromAccount, customer, commonData, request, biller, billerDetails.getVariableCRN());
			
			
			// SBGEXP-3394 - SAFI switch, Throttle and Heartbeat check
			String baseOrigin = IBankParams.getBaseOriginCode(payment.getCommonData().getOrigin());
			boolean isSafiBPaySwitchOn = IBankParams.isSwitchOn(baseOrigin, IBankParams.SAFI_BPAY_SWITCH);
			Logger.info("SAFI : BPayController.transfer:: Safi Logon Switch Val: "+isSafiBPaySwitchOn, this.getClass());
			boolean isSafiServiceAvailable = false;
			
			if(isSafiBPaySwitchOn) {				
				isSafiServiceAvailable = HeartBeat.isApplicationAvailable(HeartBeat.SAFI2_SERVICE_APPLICATION);
				Logger.info("SAFI : BPayController.transfer:: SAFI2_SERVICE_APPLICATION STATUS: "+isSafiServiceAvailable,this.getClass());
			}

			if(isSafiServiceAvailable){

				boolean isThrottleAllowed = memoryThrottlingService.processThrottling(IBankParams.THROTTLE_CAT_PAYMENT, customer.getGcis(), mobileSession.getSessionID());
								
				if(isThrottleAllowed){
					//18E4: Safi 
					Logger.debug("SAFI : BPayController.transfer(): Device Print Received in BPay Transfer Request: " +request.getDevicePrint(), this.getClass()) ;
					validDecodedPrint = SafiUtil.validateDevicePrint(request.getDevicePrint());
					devicePrint = validDecodedPrint != null ? request.getDevicePrint():null;
					boolean isMobileApp = ((logonHelper.loadCordova(httpRequest)) == -1) ? false:true;
					SafiPayTranVO safiPayTranVO = SafiWebHelper.populateSafiPayTranVOForBPay(httpRequest, payment, commonData, devicePrint, mobileSession, isMobileApp);
					payment.setSafiPayTranVO(safiPayTranVO);
					//18E4: Safi
				}
			}
			// SBGEXP-3394 - SAFI switch, Throttle and Heartbeat check	
			
			mobileSession.setTransaction(payment);
			
			Boolean sendMail = helper.isValidSendMailFlag(request.getSendEmail());
			
			mobileSession.setSendPaymentEmail(sendMail);
			IMBResp bpayTransferResp = performTransfer(mobileSession, fromAccount, payment, ServiceConstants.BPAY_TRANSFER_SERVICE, commonData, httpRequest,httpResponse,false);
			
			createOrUpdatePMData2Cookie(httpRequest, payment.getSafiRespVO(), httpResponse);
			
			return bpayTransferResp;
			
		} catch (BusinessException e) {
			Logger.info("BusinessException in BPayController - transfer() - [key: " + e.getKey() + "], GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());
			
			if(e.getKey()==BusinessException.SAFI_PAYMENT_DENY_ERROR){
				Logger.info("BusinessException in BPayController - transfer() - Handling SAFI DENY ERROR", this.getClass());
				createOrUpdatePMData2Cookie(httpRequest, payment.getSafiRespVO(), httpResponse);
				OriginsVO myOriginVO = IBankParams.getOrigin(mobileSession.getOrigin());
				OriginsVO baseOrigin = IBankParams.getOrigin(myOriginVO.getBankName());
				String[] values = { baseOrigin.getBpayPhone() };
				IMBResp resp1 = MBAppUtils.createErrorResp(mobileSession.getOrigin(), e,values, ServiceConstants.BPAY_TRANSFER_SERVICE, httpRequest);
				return resp1;
			}else if (e.getKey() == BusinessException.ACCOUNT_TO_INDEX_MISMATCH){
				return MBAppUtils.createErrorResp("ALL", e.getKey(), ServiceConstants.BPAY_TRANSFER_SERVICE, httpRequest);
			}else {
				return MBAppUtils.createErrorResp(mobileSession.getOrigin(), e, ServiceConstants.BPAY_TRANSFER_SERVICE, httpRequest);
			}
		} catch (ResourceException e) {
			Logger.error("ResourceException in BPayController - transfer() - [key: " + e.getKey() + "], GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());
			mobileSession.removeTransaction();
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.SYSTEM_UNAVILABLE, ServiceConstants.BPAY_TRANSFER_SERVICE, httpRequest);
		} catch (Exception e) {
			Logger.error("Exception BPayController - transfer(): GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			mobileSession.removeTransaction();
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.GENERIC_ERROR, ServiceConstants.BPAY_TRANSFER_SERVICE, httpRequest);
		} finally {
			endPerformanceLog(logName);
		}

	}

	/**
	 * Request security code service operation
	 * 
	 * @param request
	 * @return
	 */
	@RequestMapping(method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE, value = "reqsecurecode")
	@ResponseBody
	public IMBResp reqSecureCode(HttpServletRequest httpRequest, @RequestBody final SecureCodeReq request) {
		Logger.debug("BPayController - reqSecureCode(). Request: " + request, this.getClass());
		String logName = startPerformanceLog(httpRequest);
		MobileSession mobileSession = new MobileSessionImpl();

		try {
			mobileSession.getSessionContext(httpRequest);
			mobileSession.removeDigitalSecLoggerMap();
			IBankCommonData commonData = new MBAppHelper().populateIBankCommonData(mobileSession, httpRequest);
			
			validateRequestHeader(request.getHeader(), httpRequest);
			ErrorResp errorResponse = validate(request, httpRequest);// validate json
			if (errorResponse.hasErrors())
				return errorResponse;

			if (ServiceConstants.BPAY_TRANSFER_2FA_TRAN_CODE != request.getTranType()
					&& ServiceConstants.ADD_BILLER_2FA_TRAN_CODE != request.getTranType()) {
				return MBAppUtils.createInvalid2FATransactionTypeResponse(ServiceConstants.BPAY_SECURE_CODE_SERVICE);
			}

			LabelValueMap digitalSecLoggerMap = new LabelValueMap(2);
			digitalSecLoggerMap.put(DigitalSecLogger.AUTHTYPE, request.getDeliveryMethod());
			PhoneNumber phoneNumber = CommonBusinessUtil.get2FAPhoneNumber(commonData, request.getPhone());
			digitalSecLoggerMap.put(DigitalSecLogger.AUTHPHONE, phoneNumber.getAreaCode()+phoneNumber.getPhoneNumber());
			mobileSession.setDigitalSecLoggerMap(digitalSecLoggerMap);
			
			return secureCodeHelper.reqSecureCode(commonData, mobileSession, mobileSession.getTransaction(), mobileSession.getBiller(), request,
					ServiceConstants.BPAY_SECURE_CODE_SERVICE, httpRequest);
		} catch (ResourceException e) {
			Logger.error("ResourceException in BPayController - reqSecureCode() - [key: " + e.getKey() + "], GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());
			mobileSession.removeSecureCodeDetails();
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.SYSTEM_UNAVILABLE, ServiceConstants.BPAY_SECURE_CODE_SERVICE, httpRequest);
		} catch (Exception e) {
			Logger.error("Exception BPayController - reqSecureCode(): GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			mobileSession.removeSecureCodeDetails();
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.GENERIC_ERROR, ServiceConstants.BPAY_SECURE_CODE_SERVICE, httpRequest);
		} finally {
			endPerformanceLog(logName);
		}

	}

	/**
	 * Secure transfer service operation
	 * 
	 * @param request
	 * @return
	 */
	@RequestMapping(method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE, value = "transfersecure")
	@ResponseBody
	public IMBResp transferSecure(HttpServletRequest httpRequest,HttpServletResponse httpResponse, @RequestBody final SecureCodeReq request) {
		Logger.debug("BPayController - transferSecure(). Request: " + request, this.getClass());
		String logName = startPerformanceLog(httpRequest);
		MobileSession mobileSession = new MobileSessionImpl();
		String safiAction = null;
		String optDeliveryMethod = null;
		String optPhoneUsed = null;
		boolean is2FADone = false;
		BPayPayment payment = null;
		IBankCommonData commonData = null;
		
		try {
			mobileSession.getSessionContext(httpRequest);
			commonData = new MBAppHelper().populateIBankCommonData(mobileSession, httpRequest);
			
			validateRequestHeader(request.getHeader(), httpRequest);
			ErrorResp errorResponse = validate(request, httpRequest);// validate json
			if (errorResponse.hasErrors())
				return errorResponse;

			if (ServiceConstants.BPAY_TRANSFER_2FA_TRAN_CODE != request.getTranType()) return MBAppUtils.createInvalid2FATransactionTypeResponse(ServiceConstants.BPAY_TRANSFER_SECURE_SERVICE);
			
			payment = (BPayPayment) mobileSession.getTransaction();
			
			String emailId = "";
			boolean isSendPaymentEmail = false;
			if(mobileSession.isSendPaymentEmail() != null && mobileSession.isSendPaymentEmail()){
				isSendPaymentEmail = true;
				emailId = payment.getCommonData().getCustomer().getContactDetail().getEmail();
			}
			String highSecurityBiller = IBankParams.isHighRiskBiller(payment.getToBiller().getCode()) ? Y : N;
			
			safiAction  =  payment != null && payment.getSafiRespVO() != null ? payment.getSafiRespVO().getSafiAction(): null ;
			
			errorResponse = secureCodeHelper.verifySecureCode(commonData, mobileSession, mobileSession.getTransaction(), request,
					ServiceConstants.BPAY_TRANSFER_SECURE_SERVICE, httpRequest);
			
			if (errorResponse.hasErrors()){
				
				DigitalSecLogggerVO digitalSecLoggerVO =new DigitalSecLogggerVO();
		        digitalSecLoggerVO.setTranName(DigitalSecLogger.BPAY_TRANSFER);
		        digitalSecLoggerVO.setStatus(DigitalSecLogger.FAILURE_2FA);
		        digitalSecLoggerVO.setCommonLogData(mbAppHelper.getCommonLogData(commonData));
				digitalSecLoggerVO.setUserAgent(commonData.getUserAgent());
				LabelValueMap digitalSecMap = mobileSession.getDigitalSecLoggerMap();
				if(payment.getScheduleDetails()==null)
				digitalSecLoggerVO.setValues(((BPayPayment)payment).toDigitalSecurityLog(false,digitalSecMap.get(DigitalSecLogger.AUTHTYPE),digitalSecMap.get(DigitalSecLogger.AUTHPHONE),isSendPaymentEmail, emailId,highSecurityBiller));
				else if(payment.getScheduleDetails() != null && ((payment.getScheduleDetails().getId()== null || "".equals(payment.getScheduleDetails().getId() ) )))
					digitalSecLoggerVO.setValues(((BPayPayment)payment).toSchLog(false,digitalSecMap.get(DigitalSecLogger.AUTHTYPE),digitalSecMap.get(DigitalSecLogger.AUTHPHONE),isSendPaymentEmail, emailId,highSecurityBiller));
				digitalSecLogger.log(digitalSecLoggerVO);
				
				//18E4: Safi Notify TODO: Add SafiSwitch check here
				if(errorResponse.getStatus() ==  ErrorResp.STATUS_2FA_SUSPENDED  && !(StringMethods.isEmptyString(safiAction)) && safiAction.equalsIgnoreCase(SafiConstants.SAFI_ACTION_CHALLENGE)){
					is2FADone = false;
					Logger.info("SAFI : BPayController - transferSecure(): Notify Call:START SafiAction :Challenge: STATUS_2FA_SUSPENDED",this.getClass());
					optDeliveryMethod = digitalSecMap.get(DigitalSecLogger.AUTHTYPE);
					optPhoneUsed = digitalSecMap.get(DigitalSecLogger.AUTHPHONE);
					notifyCallAndUpdateCookie(payment, httpRequest, httpResponse,commonData, mobileSession, is2FADone, false,optPhoneUsed,optDeliveryMethod);
					Logger.info("SAFI : BPayController - transferSecure(): Notify Call: END",this.getClass());
				}
				//18E4: Safi Notify
				
				return errorResponse;
			}

			//18E4: Safi changes
			is2FADone = true;
			
			//commented for SBGEXP-3873		
			// Date is set inside verifySecureCode method of SecureCodeHelper
			//mobileSession.setSafiLast2FASuccessTime(new Date());
			
			//18E4: Safi changes
			
			// do transfer
			payment.setOtp(mobileSession.getSecureCodeDetails().getOtp());

			Account fromAccount = MBAppHelper.getAccountbyAccountId(payment.getFromAccount(), mobileSession.getCustomer().getAccounts());
			
			LabelValueMap digitalSecMap = mobileSession.getDigitalSecLoggerMap();
			optDeliveryMethod = digitalSecMap != null ? digitalSecMap.get(DigitalSecLogger.AUTHTYPE):null;
			optPhoneUsed = digitalSecMap != null ? digitalSecMap.get(DigitalSecLogger.AUTHPHONE):null;
			
			return performTransfer(mobileSession, fromAccount, payment, ServiceConstants.BPAY_TRANSFER_SECURE_SERVICE, commonData, httpRequest,httpResponse,is2FADone);
		} catch (ResourceException e) {
			Logger.info("Exception - [key: " + e.getKey() + "], GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());
			mobileSession.removeTransaction();
			mobileSession.removeSecureCodeDetails();
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.SYSTEM_UNAVILABLE, ServiceConstants.BPAY_TRANSFER_SECURE_SERVICE, httpRequest);
		} catch (BusinessException e) {
			Logger.error("BusinessException BPayController - transferSecure(): GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			try {
				if(!(StringMethods.isEmptyString(safiAction)) && safiAction.equalsIgnoreCase(SafiConstants.SAFI_ACTION_CHALLENGE)){
					Logger.info("SAFI : BusinessException BPayController - transferSecure(): Notify Call:START SafiAction :Challenge:  2FA Status: "+is2FADone+"Payment Failed",this.getClass());
					notifyCallAndUpdateCookie(payment, httpRequest, httpResponse,commonData, mobileSession, is2FADone,false,optPhoneUsed,optDeliveryMethod);
					Logger.info("SAFI : BusinessException BPayController - transferSecure(): Notify Call: END",this.getClass());
				}
			} catch (BusinessException e1) {
				mobileSession.removeTransaction();
				mobileSession.removeSecureCodeDetails();
				return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.GENERIC_ERROR, ServiceConstants.BPAY_TRANSFER_SECURE_SERVICE, httpRequest);
			}
			mobileSession.removeTransaction();
			mobileSession.removeSecureCodeDetails();
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.GENERIC_ERROR, ServiceConstants.BPAY_TRANSFER_SECURE_SERVICE, httpRequest);
		} catch (Exception e) {
			Logger.error("Exception BPayController - reqSecureCode(): GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			mobileSession.removeTransaction();
			mobileSession.removeSecureCodeDetails();
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.GENERIC_ERROR, ServiceConstants.BPAY_TRANSFER_SECURE_SERVICE, httpRequest);
		} finally {
			endPerformanceLog(logName);
		}
	}

	private void notifyCallAndUpdateCookie( BPayPayment payment,HttpServletRequest httpServletRequest,HttpServletResponse httpServletResponse ,IBankCommonData commonData,MobileSession mobileSession,boolean status2FA,boolean isPaymentSuccess,String otpPhoneUsed,String otpDeliveryMethod) throws BusinessException{
		Logger.debug("SAFI : BPayController.notifyCallAndUpdateCookie():START", this.getClass());
		try{
			if(payment != null){
				SafiRespVO safiRespVO = payment.getSafiRespVO();
				if(status2FA){
					//populate the safiPayTranVO for notify call
					SafiWebHelper.populateSafiVOForNotifyBPay(httpServletRequest,payment, mobileSession, status2FA,isPaymentSuccess,otpPhoneUsed, otpDeliveryMethod);
					//SAFI Notify Call
					safiRespVO = safi2Service.notifySafiForBPay(commonData,payment.getSafiPayTranVO());
				}
				//create or update cookie and save
				createOrUpdatePMData2Cookie(httpServletRequest,safiRespVO , httpServletResponse);
			}
		}catch(Exception e){
			Logger.debug("SAFI : BPayController.notifyCallAndUpdateCookie(): exception during notify call", this.getClass());
		}
		Logger.debug("SAFI : BPayController.notifyCallAndUpdateCookie():END", this.getClass());
	}
	
	/**
	 * Add biller service operation
	 * 
	 * @param httpRequest
	 * @param request
	 * @return
	 */
	@RequestMapping(method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE, value = "add")
	@ResponseBody
	public IMBResp addBiller(HttpServletRequest httpRequest, @RequestBody final AddBillerReq request) {
		Logger.debug("BPayController - addBiller(). Request: " + request, this.getClass());
		String logName = startPerformanceLog(httpRequest);
		MobileSession mobileSession = new MobileSessionImpl();
        DigitalSecLogggerVO digitalSecLoggerVO =new DigitalSecLogggerVO();
        digitalSecLoggerVO.setTranName(DigitalSecLogger.ADD_BILLER);
        digitalSecLoggerVO.setStatus(DigitalSecLogger.SUCCESS);
		try {
			mobileSession.getSessionContext(httpRequest);
			IBankCommonData commonData = new MBAppHelper().populateIBankCommonData(mobileSession, httpRequest);
			digitalSecLoggerVO.setCommonLogData(mbAppHelper.getCommonLogData(commonData));
			digitalSecLoggerVO.setUserAgent(commonData.getUserAgent());
			
			validateRequestHeader(request.getHeader(), httpRequest);
			ErrorResp errorResponse = validate(request, httpRequest);// validate json
			if (errorResponse.hasErrors())
				return errorResponse;
			Logger.debug("addBiller :", this.getClass());
			helper.validateBillerReq(request, mobileSession.getCustomer().getBillers(), commonData);
			Biller biller = helper.populateBiller(request, commonData.getCustomer().getFullName());
			if (!is2FAExcempt(BPayService.findTrustedBiller(biller, commonData), mobileSession.getCustomer(), biller)) {
				mobileSession.setBiller(biller);
				return helper.populateSecureRequiredResponse(populateResponseHeader(ServiceConstants.ADD_BILLER_SERVICE, mobileSession), mobileSession.getCustomer(), mobileSession.getOrigin(), ServiceConstants.ADD_BILLER_SERVICE, httpRequest);
			} else {
				BPayService.addBiller(biller, commonData);
				Customer updatedCustomer = CustomerService.getCustomer(commonData);
				mobileSession.setCustomer(updatedCustomer);

				String highSecurityBiller = IBankParams.isHighRiskBiller(biller.getCode()) ? Y : N;
				digitalSecLoggerVO.setValues(biller.toDigitalSecurityLog(CommonBusinessUtil.get2FAExemptType(commonData.getCustomer()), null, false, highSecurityBiller));
				digitalSecLogger.log(digitalSecLoggerVO);
				return helper.populateAddBillerResp(populateResponseHeader(ServiceConstants.ADD_BILLER_SECURE_SERVICE, mobileSession), updatedCustomer.getBillers(),
						biller);
			}
		} catch (BusinessException e) {
			Logger.info("Exception - [key: " + e.getKey() + "], GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());
			digitalSecLoggerVO.setStatus(DigitalSecLogger.FAILURE);
			digitalSecLogger.log(digitalSecLoggerVO);
			if (e.getKey() == BusinessException.NO_INFORMATION) {
				return MBAppUtils.createErrorResp(mobileSession.getOrigin(), new BusinessException(BusinessException.BP_BILLER_EXISTS), ServiceConstants.ADD_BILLER_SERVICE, httpRequest);
			}
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), e, ServiceConstants.ADD_BILLER_SERVICE, httpRequest);
		} catch (ResourceException e) {
			Logger.info("Exception - [key: " + e.getKey() + "], GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());
			mobileSession.removeBiller();
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.SYSTEM_UNAVILABLE, ServiceConstants.ADD_BILLER_SERVICE, httpRequest);
		} catch (Exception e) {
			Logger.error("Exception BPayController - reqSecureCode(): GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			mobileSession.removeBiller();
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.GENERIC_ERROR, ServiceConstants.ADD_BILLER_SERVICE, httpRequest);
		} finally {
			endPerformanceLog(logName);
		}

	}

	/**
	 * Add Biller secure service operation
	 * 
	 * @param httpRequest
	 * @param request
	 * @return
	 */
	@RequestMapping(method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE, value = "addsecure")
	@ResponseBody
	public IMBResp addBillerSecure(HttpServletRequest httpRequest, @RequestBody final SecureCodeReq request) {
		Logger.debug("BPayController - addBillerSecure(). Request: " + request, this.getClass());
		String logName = startPerformanceLog(httpRequest);
		MobileSession mobileSession = new MobileSessionImpl();
        DigitalSecLogggerVO digitalSecLoggerVO =new DigitalSecLogggerVO();
        digitalSecLoggerVO.setTranName(DigitalSecLogger.ADD_BILLER);
        digitalSecLoggerVO.setStatus(DigitalSecLogger.SUCCESS);
        
		try {
			mobileSession.getSessionContext(httpRequest);
			IBankCommonData commonData = new MBAppHelper().populateIBankCommonData(mobileSession, httpRequest);
			digitalSecLoggerVO.setCommonLogData(mbAppHelper.getCommonLogData(commonData));
			digitalSecLoggerVO.setUserAgent(commonData.getUserAgent());
			
			validateRequestHeader(request.getHeader(), httpRequest);
			ErrorResp errorResponse = validate(request, httpRequest);// validate json
			if (errorResponse.hasErrors())
				return errorResponse;

			if (ServiceConstants.ADD_BILLER_2FA_TRAN_CODE != request.getTranType()) return MBAppUtils.createInvalid2FATransactionTypeResponse(ServiceConstants.PAYEE_SECURE_CODE_SERVICE);
			
			Biller biller = mobileSession.getBiller();
			
			String highSecurityBiller = IBankParams.isHighRiskBiller(biller.getCode()) ? Y : N;
			LabelValueMap digitalSecMap = mobileSession.getDigitalSecLoggerMap();
			digitalSecLoggerVO.setValues(biller.toDigitalSecurityLog(digitalSecMap.get(DigitalSecLogger.AUTHTYPE), digitalSecMap.get(DigitalSecLogger.AUTHPHONE), false, highSecurityBiller));
			errorResponse = secureCodeHelper.verifySecureCode(commonData, mobileSession, biller, request, ServiceConstants.ADD_BILLER_SECURE_SERVICE, httpRequest);
			if (errorResponse.hasErrors()){
				digitalSecLoggerVO.setStatus(DigitalSecLogger.FAILURE_2FA);
				digitalSecLogger.log(digitalSecLoggerVO);
				
				return errorResponse;
			}

			billerService.addBiller(biller, commonData);
			Customer updatedCustomer = CustomerService.getCustomer(commonData);
			mobileSession.setCustomer(updatedCustomer);
			digitalSecLogger.log(digitalSecLoggerVO);
			
			IMBResp response = helper.populateAddBillerResp(populateResponseHeader(ServiceConstants.ADD_BILLER_SECURE_SERVICE, mobileSession), updatedCustomer.getBillers(),
					biller);
			mobileSession.removeBiller();
			mobileSession.removeSecureCodeDetails();
			mobileSession.removeDigitalSecLoggerMap();
			
			return response;
		} catch (BusinessException e) {
			Logger.info("Exception - [key: " + e.getKey() + "], GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());
			digitalSecLoggerVO.setValues(""); //no values to be logged for failure
			digitalSecLoggerVO.setStatus(DigitalSecLogger.FAILURE);
			digitalSecLogger.log(digitalSecLoggerVO);
			if (e.getKey() == BusinessException.NO_INFORMATION) {
				return MBAppUtils.createErrorResp(mobileSession.getOrigin(), new BusinessException(BusinessException.BP_BILLER_EXISTS),
						ServiceConstants.ADD_BILLER_SECURE_SERVICE, httpRequest);
			}
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), e, ServiceConstants.ADD_BILLER_SECURE_SERVICE, httpRequest);
		} catch (ResourceException e) {
			Logger.info("Exception - [key: " + e.getKey() + "], GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());
			mobileSession.removeBiller();
			mobileSession.removeSecureCodeDetails();
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.SYSTEM_UNAVILABLE, ServiceConstants.ADD_BILLER_SECURE_SERVICE, httpRequest);
		} catch (Exception e) {
			Logger.error("Exception BPayController - reqSecureCode(): GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			mobileSession.removeBiller();
			mobileSession.removeSecureCodeDetails();
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.GENERIC_ERROR, ServiceConstants.ADD_BILLER_SECURE_SERVICE, httpRequest);
		} finally {
			endPerformanceLog(logName);
		}
	}
	
	
	/**
	 * Add Biller secure service operation
	 * 
	 * @param httpRequest
	 * @param request
	 * @return
	 */
	@RequestMapping(method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE, value = "delete")
	@ResponseBody
	public IMBResp deleteBiller(HttpServletRequest httpRequest, @RequestBody final IndexReq request) {
		Logger.debug("BPayController - deleteBiller(). Request: " + request, this.getClass());
		String logName = startPerformanceLog(httpRequest);
		MobileSession mobileSession = new MobileSessionImpl();
		try {
			mobileSession.getSessionContext(httpRequest);
			IBankCommonData commonData = new MBAppHelper().populateIBankCommonData(mobileSession, httpRequest);
			
			validateRequestHeader(request.getHeader(), httpRequest);
			ErrorResp errorResponse = validate(request, httpRequest);// validate json
			if (errorResponse.hasErrors())
				return errorResponse;
			billerService.deleteBiller(mobileSession.getCustomer().getBillers().get(Integer.parseInt(request.getIndex())), commonData);
			Customer updatedCustomer = CustomerService.getCustomer(commonData);
			mobileSession.setCustomer(updatedCustomer);
			return helper.populateDeleteBillerResp(populateResponseHeader(ServiceConstants.DELETE_BILLER_SERVICE, mobileSession), updatedCustomer.getBillers());
		} catch (BusinessException e) {
			Logger.info("BusinessException in processRequest", e, this.getClass());			
			if (BusinessException.ACCOUNT_DELETE_UNAVAILABLE == e.getKey()){
				return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.ACCOUNT_DELETE_UNAVAILABLE_BILLER, ServiceConstants.DELETE_BILLER_SERVICE, httpRequest);
			}
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), e, ServiceConstants.DELETE_BILLER_SERVICE, httpRequest);
		} catch (ResourceException e) {
			Logger.info("Exception - [key: " + e.getKey() + "], GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.SYSTEM_UNAVILABLE, ServiceConstants.DELETE_BILLER_SERVICE, httpRequest);
		} catch (Exception e) {
			Logger.error("Exception BPayController - reqSecureCode(): GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.GENERIC_ERROR, ServiceConstants.DELETE_BILLER_SERVICE, httpRequest);
		} finally {
			endPerformanceLog(logName);
		}
	}

	/**
	 * Get Biller Details service operation
	 * 
	 * @param httpRequest
	 * @param request
	 * @return
	 */
	@RequestMapping(method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE, value = "billerdetails")
	@ResponseBody
	public IMBResp getBillerDetails(HttpServletRequest httpRequest, @RequestBody final BillerDetailsReq request) {
		Logger.debug("BPayController - getBillerDetails(). Request: " + request, this.getClass());	
		String logName = startPerformanceLog(httpRequest);
		MobileSession mobileSession = new MobileSessionImpl();
		try {
			mobileSession.getSessionContext(httpRequest);
			validateRequestHeader(request.getHeader(), httpRequest);
			ErrorResp errorResponse = validate(request, httpRequest);// validate json
			if (errorResponse.hasErrors())
				return errorResponse;

			BillerMaster billerDetails = mobileBankService.getBillerDetails(request.getCode());
			if (billerDetails == null)
				return MBAppUtils.createErrorResp(mobileSession.getOrigin(), new BusinessException(BusinessException.BPAY_INVALID_BIILER_CODE),
						ServiceConstants.GET_BILLER_DETAILS_SERVICE, httpRequest);

			return helper.populateBillerDetailResponse(populateResponseHeader(ServiceConstants.GET_BILLER_DETAILS_SERVICE, mobileSession), billerDetails);
		} catch (BusinessException e) {
			Logger.info("Exception - [key: " + e.getKey() + "], GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), e, ServiceConstants.GET_BILLER_DETAILS_SERVICE, httpRequest);
		} catch (ResourceException e) {
			Logger.info("Exception - [key: " + e.getKey() + "], GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.SYSTEM_UNAVILABLE, ServiceConstants.GET_BILLER_DETAILS_SERVICE, httpRequest);
		} catch (Exception e) {
			Logger.error("Exception BPayController - reqSecureCode(): GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.GENERIC_ERROR, ServiceConstants.GET_BILLER_DETAILS_SERVICE, httpRequest);
		} finally {
			endPerformanceLog(logName);
		}

	}
	
	/**
	 * Get Biller Details service operation
	 * 
	 * @param httpRequest
	 * @param request
	 * @return
	 */
	@RequestMapping(method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE, value = "billerhistory")
	@ResponseBody
	public IMBResp getBillerPayeeHistory(HttpServletRequest httpRequest, @RequestBody final BPayReceiptsRequest request) {
		Logger.debug("BPayController - getBillerPayeeHistory(). Request: " + request, this.getClass());	
		String logName = startPerformanceLog(httpRequest);
		MobileSession mobileSession = new MobileSessionImpl();
		try {
			mobileSession.getSessionContext(httpRequest);
			validateRequestHeader(request.getHeader(), httpRequest);
			ErrorResp errorResponse = validate(request, httpRequest);// validate json
			if (errorResponse.hasErrors())
				return errorResponse;
			
			IBankCommonData commonData = new MBAppHelper().populateIBankCommonData(mobileSession, httpRequest);
			
			Customer customer = mobileSession.getCustomer();
			List<Biller> billers = customer.getBillers();
			Biller selectedBiller=null;
			
			if(billers!=null) {
			 selectedBiller=billers.get(request.getToBillerIndex());
			}
			else {
			  Logger.error("Biller is mobileSession is null", this.getClass());
			  return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.GENERIC_ERROR, ServiceConstants.BILLER_RECEIPTS_PAYEE_SERVICE, httpRequest);
			}
			
			String defaultViewDays;
			CodesVO myCodesVO = IBankParams.getCodesData(IBankParams.DEFAULT_ORIGIN, IBankParams.PARAMETER, IBankParams.CODE_THIRDPARTY_PAYMENT_HISTORY_DEFAULT_VIEW_DAYS);
			
			if (myCodesVO == null) {
				defaultViewDays = "365";
			} else {
				defaultViewDays = myCodesVO.getMessage();
			}
			
			Date toDate = DateMethods.getUtilDate();
			Date fromDate = DateMethods.relativeDate(toDate, -StringMethods.safeInt( defaultViewDays, 0));
			if (toDate != null) {
				Calendar toEndDateTime = Calendar.getInstance();
				toEndDateTime.setTime(toDate);
				toEndDateTime.set(Calendar.HOUR_OF_DAY, 23);
				toEndDateTime.set(Calendar.MINUTE, 59);
				toEndDateTime.set(Calendar.SECOND, 59);
				toEndDateTime.set(Calendar.MILLISECOND, 999);
				toDate = toEndDateTime.getTime();
			}
			
			Logger.info("BPayController - getBillerPayeeHistory() fromDate:::::: "+fromDate.toString() +",toDate:::::::: "+toDate.toString(), this.getClass());
			Logger.info("BPayController - getBillerPayeeHistory() selectedBiller Code:::: "+selectedBiller.getCode()+",Alias::::::: "+selectedBiller.getBillerAlias()+",Name::::: "+selectedBiller.getName(), this.getClass());
			int count=0;String selectedBillerAllias=null,selectedBillerName=null;
			if(billers!=null && billers.size()>0) {
				for(Biller biller:billers) {
					if(StringMethods.removeLeadingZero(selectedBiller.getCode()).equals(StringMethods.removeLeadingZero((biller.getCode())))) {
						count++;
						if(count>1) {
							selectedBillerName=biller.getName();
							selectedBillerAllias=null;
							break;
						}
						else {
							if(biller.getBillerAlias()!=null) {
								selectedBillerName=biller.getName();
								selectedBillerAllias=biller.getBillerAlias();
							}
						}
					}
				}
			}
			
			List<PaymentsLog> paymentLogList=PaymentService.getBPayPaymentHistoryMobile(commonData.getCustomer().getGcis(), fromDate, toDate, selectedBiller, commonData);
			
			if (paymentLogList.size() > 200) {
				paymentLogList = paymentLogList.subList(0, 200);
			}
			return payeeHelper.populateBPayReceiptsResp(populateResponseHeader(ServiceConstants.BILLER_RECEIPTS_PAYEE_SERVICE, mobileSession), paymentLogList, mobileSession.getCustomer().getAccounts(),selectedBillerName,selectedBillerAllias);

			
		
		} catch (BusinessException e) {
			Logger.info("Exception - [key: " + e.getKey() + "], GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), e, ServiceConstants.BILLER_RECEIPTS_PAYEE_SERVICE, httpRequest);
		} catch (ResourceException e) {
			Logger.info("Exception - [key: " + e.getKey() + "], GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.SYSTEM_UNAVILABLE, ServiceConstants.BILLER_RECEIPTS_PAYEE_SERVICE, httpRequest);
		} catch (Exception e) {
			Logger.error("Exception BPayController - reqSecureCode(): GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.GENERIC_ERROR, ServiceConstants.BILLER_RECEIPTS_PAYEE_SERVICE, httpRequest);
		} finally {
			endPerformanceLog(logName);
		}

	}


	private boolean is2FAExcempt(String trustedAcctInd, Customer customer, Biller selectedBiller) throws BusinessException {
		return !(!(trustedAcctInd.equalsIgnoreCase(IBankSecureService.TRUSTED_STATUS))//not trusted biller
		&& (selectedBiller.getVariableCRN() != 1)
				&& (!(IBankSecureService.isGlobalByPass()))//no bypass 
				&& (!(IBankSecureService.isCustomerExempt(customer.getIBankSecureDetails())))//not excempt customer
				&& IBankParams.isHighRiskBiller(selectedBiller.getCode())//high risk biller
		);
	}
	
	
	private IMBResp performTransfer(MobileSession mobileSession, Account fromAccount, BPayPayment payment, String caller, IBankCommonData commonData, HttpServletRequest httpRequest,HttpServletResponse httpResponse,boolean is2FADone)
			throws BusinessException {
		
		DigitalSecLogggerVO digitalSecLoggerVO =new DigitalSecLogggerVO();
		digitalSecLoggerVO.setTranName(DigitalSecLogger.BPAY_TRANSFER);
		digitalSecLoggerVO.setStatus(DigitalSecLogger.SUCCESS);
		digitalSecLoggerVO.setCommonLogData(mbAppHelper.getCommonLogData(commonData));
		digitalSecLoggerVO.setUserAgent(commonData.getUserAgent());
		String optDeliveryMethod = null;
	    String optPhoneUsed = null;
	    String safiAction = null;
		try {
			
			String emailId = "";
			boolean isSendPaymentEmail = false;
			if(mobileSession.isSendPaymentEmail() != null && mobileSession.isSendPaymentEmail()){
				isSendPaymentEmail = true;
				emailId = payment.getCommonData().getCustomer().getContactDetail().getEmail();
			}
			
			//18E4: Safi
			LabelValueMap digitalSecMap = mobileSession.getDigitalSecLoggerMap();
			optDeliveryMethod = digitalSecMap != null ? digitalSecMap.get(DigitalSecLogger.AUTHTYPE):null;
			optPhoneUsed = digitalSecMap != null ? digitalSecMap.get(DigitalSecLogger.AUTHPHONE):null;
			safiAction = payment != null && payment.getSafiRespVO() != null? payment.getSafiRespVO().getSafiAction(): null;
			//18E4: Safi
			
			Receipt receipt = pay(payment, mobileSession);
			
			//18E4: Safi
					
			if(!(StringMethods.isEmptyString(safiAction)) && safiAction.equalsIgnoreCase(SafiConstants.SAFI_ACTION_CHALLENGE)){
				Logger.info("SAFI : BPayController - performTransfer(): Notify Call:START SafiAction :Challenge:  2FA Status: "+is2FADone+"Payment Successful",this.getClass());
				notifyCallAndUpdateCookie(payment, httpRequest, httpResponse,commonData, mobileSession, is2FADone,true,optPhoneUsed,optDeliveryMethod);
				Logger.info("SAFI : BPayController - performTransfer(): Notify Call: END",this.getClass());
			}
			//18E4: Safi
			
			if (payment.getFavTranId() != null) {
				try {
					mobileBankService.updateFavouriteTransactionAmount(commonData, payment.getFavTranId(), payment.getAmount().doubleValue());
				} catch (Throwable e) {
					// do nothing
					Logger.info("Exception when updating favourite transaction - ", e, this.getClass());
				}
			}
			
			TransferResp response = helper.populateTransferResponse(populateResponseHeader(ServiceConstants.BPAY_TRANSFER_SERVICE, mobileSession), receipt, payment,
					mobileSession.getCustomer());
			
			response = helper.populateTeaserResponse(response, commonData,"BPAY Transfer Receipt");
			
			if(null!=response.getTeaserResp())
			{
				if(null!=response.getTeaserResp().getSalesOfferTeaserResp())
				{
					if(null==response.getTeaserResp().getSalesOfferTeaserResp().getIsBpayTfrReceipt())
					{
						// Getting the service station VO and Setting the service station response.
						long insertionPt = helper.getInsertionPointCode(ServicetationConstants.BPAY_TRANSFER_RECEIPT);
						ServiceStationVO servicestationVO=populateServiceMessage(insertionPt,ServiceStationImpl.CHANNEL_MOBILE, commonData);
						response = helper.populateServiceStationResponse(response,servicestationVO);
						
						if(null!=servicestationVO)
						{
							mobileSession.setServiceStationMessage(servicestationVO.getServiceStationMsg());
						}
					}
				}
			}
						
			String highSecurityBiller = IBankParams.isHighRiskBiller(payment.getToBiller().getCode()) ? Y : N;
			
			
	
			if(is2FADone){
				if (payment.getScheduleDetails() != null && ((payment.getScheduleDetails().getId()== null || "".equals(payment.getScheduleDetails().getId() ) ))) {
					digitalSecLoggerVO.setValues(((BPayPayment)payment).toSchLog(false,digitalSecMap.get(DigitalSecLogger.AUTHTYPE),digitalSecMap.get(DigitalSecLogger.AUTHPHONE),isSendPaymentEmail, emailId,highSecurityBiller));
					digitalSecLogger.log(digitalSecLoggerVO);
				}
				else if(payment.getScheduleDetails() == null){
				digitalSecLoggerVO.setValues(((BPayPayment)payment).toDigitalSecurityLog(false,digitalSecMap.get(DigitalSecLogger.AUTHTYPE),digitalSecMap.get(DigitalSecLogger.AUTHPHONE),isSendPaymentEmail, emailId,highSecurityBiller));
				digitalSecLogger.log(digitalSecLoggerVO);
				}
			} else {
				if (payment.getScheduleDetails() != null && ((payment.getScheduleDetails().getId()== null || "".equals(payment.getScheduleDetails().getId() ) ))) {
					digitalSecLoggerVO.setValues(((BPayPayment)payment).toSchLog(false,CommonBusinessUtil.get2FAExemptType(commonData.getCustomer()),null,isSendPaymentEmail, emailId,highSecurityBiller));
					digitalSecLogger.log(digitalSecLoggerVO);

				}
			 else if(payment.getScheduleDetails() == null){
				digitalSecLoggerVO.setValues(((BPayPayment)payment).toDigitalSecurityLog(false,CommonBusinessUtil.get2FAExemptType(commonData.getCustomer()),null,isSendPaymentEmail, emailId,highSecurityBiller));
				digitalSecLogger.log(digitalSecLoggerVO);
				}
			}
	
			mobileSession.removeDigitalSecLoggerMap();
			
			mobileSession.removeTransaction();
			mobileSession.removeSecureCodeDetails();
			Logger.debug("BPayController - performTransfer(). Response: " + response, this.getClass());
			return response;

		} catch (DuplicateException e) {
			Logger.info("DuplicateException in BPayController - transfer() - [key: " + e.getKey() + "], GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());
			if (e.getKey() == BusinessException.DUPLICATE_PAYMENT) {
				return helper.populateTransferResponse(populateResponseHeader(caller, mobileSession), (List<PaymentDuplicateVO>) ((DuplicateException) e)
						.getDuplicatePaymentList(), mobileSession.getCustomer().getAccounts());
			}
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), e, caller, httpRequest);
		} catch (BusinessException e) {
			Logger.info("BusinessException in BPayController - transfer() - [key: " + e.getKey() + "], GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());
			safiAction = payment != null && payment.getSafiRespVO() != null? payment.getSafiRespVO().getSafiAction(): null;
			
			if (e.getKey() == BusinessException.IBANK_SECURE_REQUIRED || e.getKey() == BusinessException.IBANK_SECURE_REG_REQUIRED) {
				
				if(!(StringMethods.isEmptyString(safiAction)) && safiAction.equalsIgnoreCase(SafiConstants.SAFI_ACTION_CHALLENGE)){
					Logger.info("SAFI : BusinessException BPayController - performTransfer():createOrUpdatePMData2Cookie: START SafiAction :Challenge",this.getClass());
					createOrUpdatePMData2Cookie(httpRequest, payment.getSafiRespVO(), httpResponse);
					Logger.info("SAFI : BusinessException BPayController - performTransfer():createOrUpdatePMData2Cookie: END",this.getClass());	
				}
				
				return helper.populateSecureRequiredResponse(populateResponseHeader(caller, mobileSession), mobileSession.getCustomer(), mobileSession.getOrigin(), caller, httpRequest);
				
			} else if(e.getKey() == BusinessException.SAFI_PAYMENT_NO_PHONE_EXIST
					|| e.getKey() == BusinessException.SAFI_PAYMENT_2FA_EXEMPT
					|| e.getKey() == BusinessException.SAFI_PAYMENT_2FA_GLOBAL_BYPASS) {
				
				Logger.info("SAFI : BusinessException BPayController - performTransfer():createOrUpdatePMData2Cookie: START SafiAction : "+e.getKey(), this.getClass());
				createOrUpdatePMData2Cookie(httpRequest, payment.getSafiRespVO(), httpResponse);
				Logger.info("SAFI : BusinessException BPayController - performTransfer():createOrUpdatePMData2Cookie: END", this.getClass());
				
				String[] values = getContactNumber(mobileSession);
				return MBAppUtils.createErrorResp(mobileSession.getOrigin(), e, values, ServiceConstants.BPAY_TRANSFER_SERVICE, httpRequest);
	
			} else {

				digitalSecLoggerVO.setStatus(DigitalSecLogger.FAILURE);
				digitalSecLogger.log(digitalSecLoggerVO);
				
				if(!(StringMethods.isEmptyString(safiAction)) && (safiAction.equalsIgnoreCase(SafiConstants.SAFI_ACTION_ALLOW) ||  safiAction.equalsIgnoreCase(SafiConstants.SAFI_ACTION_REVIEW))){
					Logger.info("SAFI : BusinessException BPayController - performTransfer(): createOrUpdatePMData2Cookie: START SafiAction :Allow/Review  Payment Failed:",this.getClass());
					createOrUpdatePMData2Cookie(httpRequest, payment.getSafiRespVO(), httpResponse);
					Logger.info("SAFI : BusinessException BPayController - performTransfer(): createOrUpdatePMData2Cookie: END",this.getClass());
				}
				
				if(!(StringMethods.isEmptyString(safiAction)) && safiAction.equalsIgnoreCase(SafiConstants.SAFI_ACTION_CHALLENGE)){
					Logger.info("SAFI : BusinessException BPayController - performTransfer(): Notify Call:START SafiAction :Challenge:  2FA Status: "+is2FADone+"Payment Failed: ",this.getClass());
					notifyCallAndUpdateCookie(payment, httpRequest, httpResponse,commonData, mobileSession, is2FADone,false,optPhoneUsed,optDeliveryMethod);
					Logger.info("SAFI : BusinessException BPayController - performTransfer(): Notify Call: END",this.getClass());
				}
				
				if (e.getKey() == BusinessException.SAFI_PAYMENT_DENY_ERROR) {
					throw e;
				}else if (e.getKey() == BusinessException.ACCOUNT_AMT_BELOW_MIN_REDRAW) {
					String minAmt = "";
					if (fromAccount != null && fromAccount.getLimits() != null) {
						minAmt = String.valueOf(fromAccount.getLimits().getMinimumRedrawAmount());
					}
					return MBAppUtils.createErrorResp(mobileSession.getOrigin(), e.getKey(), MBAppUtils.getMessage(mobileSession.getOrigin(), e.getKey(), new String[] { minAmt }), caller, httpRequest);
				} else if (e.getKey() == BusinessException.INVALID_CHAR_SET) {
					throw new BusinessException(BusinessException.INVALID_CHAR_SET, "Invalid Character");
				} else {
					return MBAppUtils.createErrorResp(mobileSession.getOrigin(), e.getKey(), MBAppUtils.getMessage(mobileSession.getOrigin(), e.getKey()), caller, httpRequest);
				}
			}
		}
	}

	private Receipt pay(BPayPayment payment, MobileSession mobileSession) throws BusinessException {
		Logger.debug("Payment object - " + ReflectionToStringBuilder.toString(payment, ToStringStyle.MULTI_LINE_STYLE), this.getClass());
		Receipt receipt = transactService.performTransfer(payment);
		Logger.debug("Receipt - " + ReflectionToStringBuilder.toString(receipt, ToStringStyle.MULTI_LINE_STYLE), this.getClass());
//		 throw new BusinessException(BusinessException.IBANK_SECURE_REQUIRED);
		Customer updatedCustomer = payment.getCommonData().getCustomer();
		mobileSession.setCustomer(updatedCustomer);
		// send email if needed
		if (mobileSession.isSendPaymentEmail() != null && mobileSession.isSendPaymentEmail()) {
			// if an email needs to be sent to customer
			Logger.debug("Sending email: ", this.getClass());
			transactService.sendBPayEmailReceipt(payment, receipt, MBAppHelper.getAccountbyAccountId(payment.getFromAccount(), updatedCustomer
					.getAccounts()), payment.getToBiller());
			mobileSession.removeSendPaymentEmail();
		}
		return receipt;
	}
	
	private void createOrUpdatePMData2Cookie(HttpServletRequest httpServletRequest,SafiRespVO safiRespVO,HttpServletResponse httpServletResponse){

		if(safiRespVO != null){
			Cookie pmdata2 = SafiWebHelper.readCookies(httpServletRequest);
			Logger.debug("SAFI : BPayController.createOrUpdatePMData2Cookie(): PMDATA2 cookie received.", this.getClass());
			//create or update cookie and save
			Cookie newCookie = SafiWebHelper.createOrUpdatePmdata2Cookie(httpServletRequest,pmdata2,safiRespVO.getDeviceToken());
			Logger.debug("SAFI : BPayController.createOrUpdatePMData2Cookie(): Setting PMDATA2 cookie in resp.", this.getClass());
			httpServletResponse.addCookie(newCookie);
			Logger.debug("SAFI : BPayController.createOrUpdatePMData2Cookie(): PMDATA2 cookie setting resp done.", this.getClass());
		}
	}

	public ErrorResp validate(IMBReq serviceRequest, HttpServletRequest request) {
		
		// 20E1 : Data masking for CRN : Start
		String serviceReqForMasking = ReflectionToStringBuilder.toString(serviceRequest);
		String serviceReqAfterMasking = maskValue(serviceReqForMasking,serviceRequest);
		Logger.info("Service request object - " + serviceReqAfterMasking, this.getClass());
		// 20E1 : Data masking for CRN : End
		return mbAppValidator.validate(serviceRequest, request);
	}

	/*
     * Method to mask crn value for AddBillerRea and custRef value for BPayTransferReq 
     * 
     */
	private String maskValue(String serviceResponseForMasking,IMBReq serviceRequest) {
		
		try {
			String[] srvReq = serviceResponseForMasking.split(",");

			for (int i = 0; i < srvReq.length; i++) {
				if (serviceRequest instanceof BPayTransferReq) {
					if ((!StringUtils.isEmpty(srvReq[i])) && srvReq[i].contains("custRefNum")) {
						int ind = srvReq[i].indexOf("custRefNum");
						String temp = srvReq[i].substring(ind + 11, srvReq[i].length());
						if ((!StringUtils.isEmpty(temp)) && temp.length() > 10) {
							srvReq[i] = "custRefNum:" + StringUtil.maskCrnValue(temp, "X");
						}
					}
				}
				if (serviceRequest instanceof AddBillerReq) {
					if ((!StringUtils.isEmpty(srvReq[i])) && srvReq[i].contains("crn")) {
						int ind = srvReq[i].indexOf("crn");
						String temp = srvReq[i].substring(ind + 4, srvReq[i].length());
						if ((!StringUtils.isEmpty(temp)) && temp.length() > 10) {
							srvReq[i] = "crn:" + StringUtil.maskCrnValue(temp, "X");
						}
					}
				}
			}
			String serviceReq = StringUtils.join(srvReq, ",");
			return serviceReq;
		} catch (Exception e) {
			Logger.info("Error while masking value in BpayController ", this.getClass());
			return serviceResponseForMasking;
		}
	}
	public void validateRequestHeader(ReqHeader headerReq, HttpServletRequest request) throws BusinessException {
		Logger.debug("Request header validation: " + ReflectionToStringBuilder.toString(headerReq, ToStringStyle.MULTI_LINE_STYLE), this.getClass());
		mbAppValidator.validateRequestHeader(headerReq, request);
	}

	public RespHeader populateResponseHeader(String serviceName, MobileSession mobSession) {
		return mbAppHelper.populateResponseHeader(serviceName, mobSession);
	}

	/**
	 * Response for invalid body request
	 * 
	 * @return
	 */
	@ExceptionHandler( { org.springframework.http.converter.HttpMessageNotReadableException.class })
	@ResponseStatus(org.springframework.http.HttpStatus.OK)
	@ResponseBody
	public IMBResp resolveException() {
		return MBAppUtils.createInvalidMessageBodyResponse(ServiceConstants.BPAY_TRANSFER_SERVICE);
	}
	
	@Autowired
	private PerformanceLogger perfLogger;
	
	private String startPerformanceLog(HttpServletRequest httpRequest){
		perfLogger.startAllLogs();
		String logName = MBAppUtils.getLogName(httpRequest);
		perfLogger.startLog(logName);
		return logName;
	}
	
	private void endPerformanceLog(String logName){
		perfLogger.endLog(logName);
		perfLogger.endAllLogs();
	}
	private ServiceStationVO populateServiceMessage(long insertionPoint,String channel, IBankCommonData commonData)
	{
		ServiceStationVO serviceStationAdminVo=null;
		try
		{
		 serviceStationAdminVo= serviceStationService.getServiceMessage(insertionPoint, ServiceStationImpl.CHANNEL_MOBILE, commonData);			
		}
		 catch(BusinessException ex){
			Logger.error("An error occurred while getting service station message for mobile accoutn details ", ex, this.getClass());
		}
		return serviceStationAdminVo;
	}

	private String[] getContactNumber(MobileSession mobileSession) {
		OriginsVO myOriginVO = IBankParams.getOrigin(mobileSession.getOrigin());
		OriginsVO baseOrigin = IBankParams.getOrigin(myOriginVO.getBankName());
		String[] values = { baseOrigin.getBpayPhone() };
		return values;
	}
	
	public static void main(String args[]) {
		Date toDate = DateMethods.getUtilDate();
		Date fromDate = DateMethods.relativeDate(toDate, -StringMethods.safeInt( "425", 0));
		System.out.println(toDate.toString()+","+fromDate.toString());
	}
}
