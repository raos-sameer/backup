package au.com.stgeorge.mbank.model.request.customer.ev;
import au.com.stgeorge.mbank.model.common.IMBReq;
import java.io.Serializable;
import au.com.stgeorge.mbank.model.common.ReqHeader;

public class ReIDVReq implements IMBReq, Serializable{
	
	private static final long serialVersionUID = -256469501889499119L;
	private EVInfo evInfo;
	private CRSInfo crsInfo;
	private ReIDVInfo reIDVInfo;
	private ReqHeader header;
	
	public EVInfo getEvInfo() {
		return evInfo;
	}
	public void setEvInfo(EVInfo evInfo) {
		this.evInfo = evInfo;
	}
	public CRSInfo getCrsInfo() {
		return crsInfo;
	}
	public void setCrsInfo(CRSInfo crsInfo) {
		this.crsInfo = crsInfo;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}	
	public ReqHeader getHeader() {
		return header;
	}
	public void setHeader(ReqHeader header) {
		this.header = header;
	}
	public ReIDVInfo getReIDVInfo() {
		return reIDVInfo;
	}
	public void setReIDVInfo(ReIDVInfo reIDVInfo) {
		this.reIDVInfo = reIDVInfo;
	}
}
