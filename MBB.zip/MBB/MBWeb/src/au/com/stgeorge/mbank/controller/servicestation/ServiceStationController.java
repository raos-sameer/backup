/**
 * 
 */
package au.com.stgeorge.mbank.controller.servicestation;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang.builder.ReflectionToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import au.com.stgeorge.framework.common.logging.Logger;
import au.com.stgeorge.ibank.businessobject.BusinessException;
import au.com.stgeorge.ibank.businessobject.ResourceException;
import au.com.stgeorge.ibank.servicestation.businessobject.ServiceStation;
import au.com.stgeorge.ibank.servicestation.businessobject.valueobject.ServiceStationMessage;
import au.com.stgeorge.ibank.valueobject.transfer.IBankCommonData;
import au.com.stgeorge.mbank.controller.IMBController;
import au.com.stgeorge.mbank.model.common.IMBReq;
import au.com.stgeorge.mbank.model.common.IMBResp;
import au.com.stgeorge.mbank.model.common.ReqHeader;
import au.com.stgeorge.mbank.model.common.RespHeader;
import au.com.stgeorge.mbank.model.request.EmptyReq;
import au.com.stgeorge.mbank.model.response.ErrorResp;
import au.com.stgeorge.mbank.session.MobileSession;
import au.com.stgeorge.mbank.util.MBAppHelper;
import au.com.stgeorge.mbank.util.MBAppUtils;
import au.com.stgeorge.mbank.util.MBAppValidator;
import au.com.stgeorge.mbank.util.ServiceConstants;
import au.com.stgeorge.perflogger.PerformanceLogger;

/**
 * @author C50216
 *
 */

@Controller
@RequestMapping("/servicestation")
public class ServiceStationController implements IMBController{
	
	
	@Autowired
	private PerformanceLogger perfLogger;
	
	@Autowired
	private MBAppHelper mbAppHelper;
	
	@Autowired
	private MBAppValidator mbAppValidator;
	
	@Autowired
	private ServiceStation serviceStationService;
	
	@Autowired
	private ServiceStationHelper helper;
	
	@RequestMapping(value = "read", method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public IMBResp readServiceMessage(HttpServletRequest httpServletRequest,@RequestBody final EmptyReq req){ 
				
		perfLogger.startAllLogs();
		String logName = MBAppUtils.getLogName(httpServletRequest);
		perfLogger.startLog(logName);		
		MobileSession mbSession = null;
		try{
			mbSession = mbAppHelper.getMobileSession(httpServletRequest);
			validateRequestHeader(req.getHeader(), httpServletRequest);
			ErrorResp errorResp = validate(req, httpServletRequest);
					
			if (errorResp != null && errorResp.getErrors() != null && errorResp.getErrors().size() > 0)
			{				
				return errorResp;
			}			
			IBankCommonData commonData=mbAppHelper.populateIBankCommonData(mbSession,httpServletRequest);
			ServiceStationMessage serviceMessage = mbSession.getServiceStationMessage();
			if(serviceMessage != null){
				mbSession.removeServiceStationMessage();
				serviceStationService.markDashboardServiceMsgRead(commonData, serviceMessage);				
			}
			return helper.populateSuccessResp(populateResponseHeader(ServiceConstants.SERVICE_STATION_SERVICE, mbSession ));
					
		}catch (BusinessException e)
		{
			Logger.info("BusinessException Inside processMsgList() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			BusinessException exp = new BusinessException(e.getKey());
			IMBResp resp1  = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, ServiceConstants.MSGCENTRE_LIST_SERVICE, httpServletRequest);
			return resp1;
		}catch (ResourceException e){
			Logger.error("ResourceException Inside processMsgList() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			ResourceException exp = new ResourceException(e.getKey());
			IMBResp resp1  = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, ServiceConstants.MSGCENTRE_LIST_SERVICE, httpServletRequest);
			return resp1;
		} catch (Exception e)
		{
			Logger.error("Exception Inside processMsgList() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			BusinessException exp = new BusinessException(BusinessException.GENERIC_ERROR);
			IMBResp resp1  = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, ServiceConstants.MSGCENTRE_LIST_SERVICE, httpServletRequest);
			return resp1;
		} finally
		{
			perfLogger.endLog(logName);
			perfLogger.endAllLogs();
		}	
						
	}
	
	@RequestMapping(value = "readacctdetail", method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public IMBResp readAccountDetailServiceMessage(HttpServletRequest httpServletRequest,@RequestBody final EmptyReq req){ 
				
		perfLogger.startAllLogs();
		String logName = MBAppUtils.getLogName(httpServletRequest);
		perfLogger.startLog(logName);		
		MobileSession mbSession = null;
		try{
			mbSession = mbAppHelper.getMobileSession(httpServletRequest);			
			validateRequestHeader(req.getHeader(), httpServletRequest);
			ErrorResp errorResp = validate(req, httpServletRequest);
					
			if (errorResp != null && errorResp.getErrors() != null && errorResp.getErrors().size() > 0)
			{				
				return errorResp;
			}			
			IBankCommonData commonData=mbAppHelper.populateIBankCommonData(mbSession,httpServletRequest);
			ServiceStationMessage serviceMessage = mbSession.getServiceStationAccountDetailMessage();
			if(serviceMessage != null){
				//mbSession.removeServiceStationAccountDetailsMessage();
				serviceStationService.markServiceMessageRead(commonData, serviceMessage);				
			}
			return helper.populateSuccessResp(populateResponseHeader(ServiceConstants.SERVICE_STATION_SERVICE, mbSession ));
					
		}catch (BusinessException e)
		{
			Logger.info("BusinessException Inside processMsgList() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			BusinessException exp = new BusinessException(e.getKey());
			IMBResp resp1  = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, ServiceConstants.MSGCENTRE_LIST_SERVICE, httpServletRequest);
			return resp1;
		}catch (ResourceException e){
			Logger.error("ResourceException Inside processMsgList() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			ResourceException exp = new ResourceException(e.getKey());
			IMBResp resp1  = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, ServiceConstants.MSGCENTRE_LIST_SERVICE, httpServletRequest);
			return resp1;
		} catch (Exception e)
		{
			Logger.error("Exception Inside processMsgList() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			BusinessException exp = new BusinessException(BusinessException.GENERIC_ERROR);
			IMBResp resp1  = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, ServiceConstants.MSGCENTRE_LIST_SERVICE, httpServletRequest);
			return resp1;
		} finally
		{
			perfLogger.endLog(logName);
			perfLogger.endAllLogs();
		}	
						
	}
	
	@RequestMapping(value = "readdashboard", method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public IMBResp readDashboardServiceMessage(HttpServletRequest httpServletRequest,@RequestBody final EmptyReq req)
	{ 				
		perfLogger.startAllLogs();
		String logName = MBAppUtils.getLogName(httpServletRequest);
		perfLogger.startLog(logName);		
		MobileSession mbSession = null;
		try{
			mbSession = mbAppHelper.getMobileSession(httpServletRequest);
			validateRequestHeader(req.getHeader(), httpServletRequest);
			ErrorResp errorResp = validate(req, httpServletRequest);
					
			if (errorResp != null && errorResp.getErrors() != null && errorResp.getErrors().size() > 0)
			{				
				return errorResp;
			}			
			IBankCommonData commonData=mbAppHelper.populateIBankCommonData(mbSession,httpServletRequest);
			ServiceStationMessage serviceMessage = mbSession.getServiceStationDashboardMessage();
			if(serviceMessage != null)
			{
				//mbSession.removeServiceStationMessage();
				serviceStationService.markDashboardServiceMsgRead(commonData, serviceMessage);				
			}
			return helper.populateSuccessResp(populateResponseHeader(ServiceConstants.SERVICE_STATION_SERVICE, mbSession ));
					
		}catch (BusinessException e)
		{
			Logger.info("BusinessException Inside processMsgList() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			BusinessException exp = new BusinessException(e.getKey());
			IMBResp resp1  = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, ServiceConstants.MSGCENTRE_LIST_SERVICE, httpServletRequest);
			return resp1;
		}catch (ResourceException e){
			Logger.error("ResourceException Inside processMsgList() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			ResourceException exp = new ResourceException(e.getKey());
			IMBResp resp1  = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, ServiceConstants.MSGCENTRE_LIST_SERVICE, httpServletRequest);
			return resp1;
		} catch (Exception e)
		{
			Logger.error("Exception Inside processMsgList() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			BusinessException exp = new BusinessException(BusinessException.GENERIC_ERROR);
			IMBResp resp1  = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, ServiceConstants.MSGCENTRE_LIST_SERVICE, httpServletRequest);
			return resp1;
		} finally
		{
			perfLogger.endLog(logName);
			perfLogger.endAllLogs();
		}	
						
	}
	
	@RequestMapping(value = "deletedashboard", method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public IMBResp deleteDashboardServiceMessage(HttpServletRequest httpServletRequest,@RequestBody final EmptyReq req){ 
				
		perfLogger.startAllLogs();
		String logName = MBAppUtils.getLogName(httpServletRequest);
		perfLogger.startLog(logName);		
		MobileSession mbSession = null;
		try{
			mbSession = mbAppHelper.getMobileSession(httpServletRequest);
			validateRequestHeader(req.getHeader(), httpServletRequest);
			ErrorResp errorResp = validate(req, httpServletRequest);
					
			if (errorResp != null && errorResp.getErrors() != null && errorResp.getErrors().size() > 0)
			{				
				return errorResp;
			}			
			IBankCommonData commonData=mbAppHelper.populateIBankCommonData(mbSession,httpServletRequest);
			ServiceStationMessage serviceMessage = mbSession.getServiceStationDashboardMessage();
			
			if(serviceMessage != null)
			{
				mbSession.removeServiceStationDashboardMessage();
				serviceStationService.closeServiceMessage(commonData, serviceMessage);				
			}
			return helper.populateSuccessResp(populateResponseHeader(ServiceConstants.SERVICE_STATION_SERVICE, mbSession ));
					
		}catch (BusinessException e)
		{
			Logger.info("BusinessException Inside processMsgList() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			BusinessException exp = new BusinessException(e.getKey());
			IMBResp resp1  = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, ServiceConstants.MSGCENTRE_LIST_SERVICE, httpServletRequest);
			return resp1;
		}catch (ResourceException e){
			Logger.error("ResourceException Inside processMsgList() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			ResourceException exp = new ResourceException(e.getKey());
			IMBResp resp1  = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, ServiceConstants.MSGCENTRE_LIST_SERVICE, httpServletRequest);
			return resp1;
		} catch (Exception e)
		{
			Logger.error("Exception Inside processMsgList() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			BusinessException exp = new BusinessException(BusinessException.GENERIC_ERROR);
			IMBResp resp1  = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, ServiceConstants.MSGCENTRE_LIST_SERVICE, httpServletRequest);
			return resp1;
		} finally
		{
			perfLogger.endLog(logName);
			perfLogger.endAllLogs();
		}
	}

	public ErrorResp validate(IMBReq serviceRequest, HttpServletRequest request) {
		Logger.info("Service request object - " + ReflectionToStringBuilder.toString(serviceRequest), this.getClass());
		return mbAppValidator.validate(serviceRequest, request);
	}

	public void validateRequestHeader(ReqHeader headerReq, HttpServletRequest request) throws BusinessException {
		Logger.debug("Request header validation: " + ReflectionToStringBuilder.toString(headerReq, ToStringStyle.MULTI_LINE_STYLE), this.getClass());
		mbAppValidator.validateRequestHeader(headerReq, request);
	}
	

	public RespHeader populateResponseHeader(String serviceName, MobileSession mobSession) {
		return mbAppHelper.populateResponseHeader(serviceName, mobSession);
	}
	
	@RequestMapping(value = "delete", method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public IMBResp deleteServiceMessage(HttpServletRequest httpServletRequest,@RequestBody final EmptyReq req){ 
				
		perfLogger.startAllLogs();
		String logName = MBAppUtils.getLogName(httpServletRequest);
		perfLogger.startLog(logName);		
		MobileSession mbSession = null;
		try{
			mbSession = mbAppHelper.getMobileSession(httpServletRequest);
			validateRequestHeader(req.getHeader(), httpServletRequest);
			ErrorResp errorResp = validate(req, httpServletRequest);
					
			if (errorResp != null && errorResp.getErrors() != null && errorResp.getErrors().size() > 0)
			{				
				return errorResp;
			}			
			IBankCommonData commonData=mbAppHelper.populateIBankCommonData(mbSession,httpServletRequest);
			ServiceStationMessage serviceMessage = mbSession.getServiceStationMessage();
			if(serviceMessage != null){
				mbSession.removeServiceStationMessage();
				serviceStationService.closeServiceMessage(commonData, serviceMessage);				
			}
			return helper.populateSuccessResp(populateResponseHeader(ServiceConstants.SERVICE_STATION_SERVICE, mbSession ));
					
		}catch (BusinessException e)
		{
			Logger.info("BusinessException Inside processMsgList() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			BusinessException exp = new BusinessException(e.getKey());
			IMBResp resp1  = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, ServiceConstants.MSGCENTRE_LIST_SERVICE, httpServletRequest);
			return resp1;
		}catch (ResourceException e){
			Logger.error("ResourceException Inside processMsgList() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			ResourceException exp = new ResourceException(e.getKey());
			IMBResp resp1  = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, ServiceConstants.MSGCENTRE_LIST_SERVICE, httpServletRequest);
			return resp1;
		} catch (Exception e)
		{
			Logger.error("Exception Inside processMsgList() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			BusinessException exp = new BusinessException(BusinessException.GENERIC_ERROR);
			IMBResp resp1  = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, ServiceConstants.MSGCENTRE_LIST_SERVICE, httpServletRequest);
			return resp1;
		} finally
		{
			perfLogger.endLog(logName);
			perfLogger.endAllLogs();
		}
	}
	
	@RequestMapping(value = "deleteacctdetail", method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public IMBResp deleteAccountDetailsServiceMessage(HttpServletRequest httpServletRequest,@RequestBody final EmptyReq req){ 
				
		perfLogger.startAllLogs();
		String logName = MBAppUtils.getLogName(httpServletRequest);
		perfLogger.startLog(logName);		
		MobileSession mbSession = null;
		try{
			mbSession = mbAppHelper.getMobileSession(httpServletRequest);
			validateRequestHeader(req.getHeader(), httpServletRequest);
			ErrorResp errorResp = validate(req, httpServletRequest);
					
			if (errorResp != null && errorResp.getErrors() != null && errorResp.getErrors().size() > 0)
			{				
				return errorResp;
			}			
			IBankCommonData commonData=mbAppHelper.populateIBankCommonData(mbSession,httpServletRequest);
			ServiceStationMessage serviceMessage = mbSession.getServiceStationAccountDetailMessage();
			if(serviceMessage != null){
				mbSession.removeServiceStationAccountDetailsMessage();
				serviceStationService.closeServiceMessage(commonData, serviceMessage);				
			}
			return helper.populateSuccessResp(populateResponseHeader(ServiceConstants.SERVICE_STATION_SERVICE, mbSession ));
					
		}catch (BusinessException e)
		{
			Logger.info("BusinessException Inside processMsgList() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			BusinessException exp = new BusinessException(e.getKey());
			IMBResp resp1  = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, ServiceConstants.MSGCENTRE_LIST_SERVICE, httpServletRequest);
			return resp1;
		}catch (ResourceException e){
			Logger.error("ResourceException Inside processMsgList() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			ResourceException exp = new ResourceException(e.getKey());
			IMBResp resp1  = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, ServiceConstants.MSGCENTRE_LIST_SERVICE, httpServletRequest);
			return resp1;
		} catch (Exception e)
		{
			Logger.error("Exception Inside processMsgList() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			BusinessException exp = new BusinessException(BusinessException.GENERIC_ERROR);
			IMBResp resp1  = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, ServiceConstants.MSGCENTRE_LIST_SERVICE, httpServletRequest);
			return resp1;
		} finally
		{
			perfLogger.endLog(logName);
			perfLogger.endAllLogs();
		}
	}
}
