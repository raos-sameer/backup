package au.com.stgeorge.mbank.model.mortgageinfo;

import java.io.Serializable;
import java.util.List;

import javax.validation.Valid;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_NULL)
public class ApplicationInfo implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = -2334701650351329205L;
	@Valid
	private LoanTypeInfo loanType;
	@Valid
	private List<ApplicantInfo> applicants;
	@Valid
	private List<AssetInfo> assets;
	@Valid
	private List<LiabilityInfo> liabilities;
	@Valid
	private List<ExpenseInfo> expenses;
	private List<PropertyInfo> properties;
	private DashboardInfo dashboard;

	private Boolean dashboardIntroInd;
	private Boolean isbackgroundCall;
	private Boolean validateRefinanceLoanAmount;
	
	private int index;

	private String customerModifiedOn;
	
	private String pageName;
	private String status;
	
	private Boolean inflightApp;
	
	private Boolean creditCheckRequired;
	private Integer lenderIndex;
	private LenderInfo lender;
	
	public Integer getLenderIndex() {
		return lenderIndex;
	}
	public void setLenderIndex(Integer lenderIndex) {
		this.lenderIndex = lenderIndex;
	}
	public LenderInfo getLender() {
		return lender;
	}

	public void setLender(LenderInfo lender) {
		this.lender = lender;
	}

	public DashboardInfo getDashboard() {
		return dashboard;
	}

	public Boolean getDashboardIntroInd() {
		return dashboardIntroInd;
	}

	public void setDashboardIntroInd(Boolean dashboardIntroInd) {
		this.dashboardIntroInd = dashboardIntroInd;
	}

	public void setDashboard(DashboardInfo dashboard) {
		this.dashboard = dashboard;
	}

	public LoanTypeInfo getLoanType() {
		return loanType;
	}

	public void setLoanType(LoanTypeInfo loanType) {
		this.loanType = loanType;
	}

	public List<ApplicantInfo> getApplicants() {
		return applicants;
	}

	public void setApplicants(List<ApplicantInfo> applicants) {
		this.applicants = applicants;
	}

	public List<AssetInfo> getAssets() {
		return assets;
	}

	public void setAssets(List<AssetInfo> assets) {
		this.assets = assets;
	}

	public List<LiabilityInfo> getLiabilities() {
		return liabilities;
	}

	public void setLiabilities(List<LiabilityInfo> liabilities) {
		this.liabilities = liabilities;
	}

	public List<ExpenseInfo> getExpenses() {
		return expenses;
	}

	public void setExpenses(List<ExpenseInfo> expenses) {
		this.expenses = expenses;
	}

	public List<PropertyInfo> getProperties() {
		return properties;
	}

	public void setProperties(List<PropertyInfo> properties) {
		this.properties = properties;
	}

	public Boolean getIsbackgroundCall() {
		return isbackgroundCall;
	}

	public void setIsbackgroundCall(Boolean isbackgroundCall) {
		this.isbackgroundCall = isbackgroundCall;
	}

	public Boolean getValidateRefinanceLoanAmount() {
		return validateRefinanceLoanAmount;
	}

	public void setValidateRefinanceLoanAmount(Boolean validateRefinanceLoanAmount) {
		this.validateRefinanceLoanAmount = validateRefinanceLoanAmount;
	}
	public int getIndex() {
		return index;
	}

	public void setIndex(int index) {
		this.index = index;
	}

	public String getCustomerModifiedOn() {
		return customerModifiedOn;
	}

	public void setCustomerModifiedOn(String customerModifiedOn) {
		this.customerModifiedOn = customerModifiedOn;
	}

	public String getPageName()
	{
		return pageName;
	}

	public void setPageName(String pageName)
	{
		this.pageName = pageName;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Boolean getInflightApp() {
		return inflightApp;
	}

	public void setInflightApp(Boolean inflightApp) {
		this.inflightApp = inflightApp;
	}

	public Boolean getCreditCheckRequired() {
		return creditCheckRequired;
	}

	public void setCreditCheckRequired(Boolean creditCheckRequired) {
		this.creditCheckRequired = creditCheckRequired;
	}
		
}
