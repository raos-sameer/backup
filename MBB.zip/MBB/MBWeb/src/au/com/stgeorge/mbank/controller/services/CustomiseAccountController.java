package au.com.stgeorge.mbank.controller.services;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang.builder.ReflectionToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import au.com.stgeorge.framework.common.logging.Logger;
import au.com.stgeorge.ibank.businessobject.BusinessException;
import au.com.stgeorge.ibank.businessobject.ResourceException;
import au.com.stgeorge.ibank.evcrs.businessobject.CRSService;
import au.com.stgeorge.ibank.valueobject.Account;
import au.com.stgeorge.ibank.valueobject.AccountAlias;
import au.com.stgeorge.ibank.valueobject.Customer;
import au.com.stgeorge.ibank.valueobject.transfer.IBankCommonData;
import au.com.stgeorge.mbank.controller.IMBController;
import au.com.stgeorge.mbank.controller.customer.LogonHelper;
import au.com.stgeorge.mbank.model.common.IMBReq;
import au.com.stgeorge.mbank.model.common.IMBResp;
import au.com.stgeorge.mbank.model.common.ReqHeader;
import au.com.stgeorge.mbank.model.common.RespHeader;
import au.com.stgeorge.mbank.model.request.services.CustomiseAccountReq;
import au.com.stgeorge.mbank.model.response.ErrorResp;
import au.com.stgeorge.mbank.model.response.services.CustomiseAccountResp;
import au.com.stgeorge.mbank.session.MobileSession;
import au.com.stgeorge.mbank.session.MobileSessionImpl;
import au.com.stgeorge.mbank.util.MBAppHelper;
import au.com.stgeorge.mbank.util.MBAppUtils;
import au.com.stgeorge.mbank.util.MBAppValidator;
import au.com.stgeorge.mbank.util.ServiceConstants;
import au.com.stgeorge.mobilebank.businessobject.MobileBankService;
import au.com.stgeorge.perflogger.PerformanceLogger;

/**
 * Customize account Service
 * 
 * @author C69934, C70723
 * 
 */
@Controller
@RequestMapping("/customiseaccount")
public class CustomiseAccountController implements IMBController {
	
	@Autowired
	private MBAppValidator mbAppValidator;
	
	@Autowired
	private MBAppHelper mbAppHelper;
	
	@Autowired
	private MobileBankService mobileBankService;
	
	@Autowired
	private CustomiseAccountHelper customiseAccountHelper;
	
	@Autowired
	private LogonHelper logonHelper;
	
	@Autowired
	private CRSService crsService;

	
	@RequestMapping(method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE, value="/renameandsort")
	@ResponseBody
	public IMBResp renameAndSort(HttpServletRequest httpRequest, @RequestBody final CustomiseAccountReq request) {
		Logger.info("CustomiseAccountController - renameAndSort(). Request: " + request, this.getClass());
		String logName = startPerformanceLog(httpRequest);
		MobileSession mobileSession = new MobileSessionImpl();
		List<AccountAlias> accountAliasList;

		try {
			mobileSession.getSessionContext(httpRequest);
			validateRequestHeader(request.getHeader(), httpRequest);
			ErrorResp errorResponse = validate(request, httpRequest);
			if (errorResponse.hasErrors())
				return errorResponse;

			IBankCommonData commonData = new MBAppHelper().populateIBankCommonData(mobileSession, httpRequest);
			accountAliasList= customiseAccountHelper.getAccountAliasListNomCheck(commonData,request);

			mobileBankService.customiseAccountPrefrence(commonData,accountAliasList);
			
			List<Account> accounts = commonData.getCustomer().getAccounts();

			//changing account index so that it is in sync with sortOrder
			int index = 0;
			for(Account account : accounts){
				int oldIndex = account.getIndex();
				account.setIndex(index);
				Logger.info("AccName="+account.getAlias()+"Acc#:"+account.getAccountId().getAccountNumber()+", oldIndex="+oldIndex+", newIndex="+index+",sortOrder="+account.getSortOrder(), this.getClass());
				index++;
			}
			
			mobileSession.setCustomer(commonData.getCustomer());
			IMBResp serviceResponse = populateCustomiseAccountResponse(commonData.getCustomer(),populateResponseHeader(ServiceConstants.CUSTOMISE_ACCOUNT_SERVICE, mobileSession),"SUCCESS");
			
			return serviceResponse;
			
		} catch (BusinessException e) {
			Logger.info("BusinessException in CustomiseAccountController - renameAndSort() - [key: " + e.getKey() + "] : GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), e, ServiceConstants.CUSTOMISE_ACCOUNT_SERVICE, httpRequest);
		} catch (ResourceException e) {
			Logger.error("ResourceException in CustomiseAccountController - renameAndSort() - [key: " + e.getKey() + "] : GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.SYSTEM_UNAVILABLE, ServiceConstants.CUSTOMISE_ACCOUNT_SERVICE, httpRequest);
		} catch (Exception e) {
			Logger.error("Exception CustomiseAccountController - renameAndSort(): GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.SYSTEM_UNAVILABLE,ServiceConstants.CUSTOMISE_ACCOUNT_SERVICE, httpRequest);
		} finally {
			endPerformanceLog(logName);
		}
	}

	
	private CustomiseAccountResp populateCustomiseAccountResponse(Customer customer, RespHeader header,String status) throws BusinessException{
		CustomiseAccountResp customiseAccountResp = new CustomiseAccountResp(header);

		ArrayList<au.com.stgeorge.mbank.model.common.AccountResp> accountList = logonHelper.populateAccountList(customer,null);
		customiseAccountResp.setAccounts(accountList);

		customiseAccountResp.setStatus(status);
		
		return customiseAccountResp;
	}
	
	
	
	@Override
	public void validateRequestHeader(ReqHeader headerReq,HttpServletRequest request) throws BusinessException {
		Logger.debug("Request header validation: " + ReflectionToStringBuilder.toString(headerReq, ToStringStyle.MULTI_LINE_STYLE), this.getClass());
		mbAppValidator.validateRequestHeader(headerReq, request);
	}

	@Override
	public ErrorResp validate(IMBReq serviceRequest,HttpServletRequest httpRequest) throws BusinessException {
		Logger.info("Service request object - " + ReflectionToStringBuilder.toString(serviceRequest), this.getClass());
		return mbAppValidator.validate(serviceRequest, httpRequest);
	}

	@Override
	public RespHeader populateResponseHeader(String serviceName,MobileSession mobileSession) {
		return mbAppHelper.populateResponseHeader(serviceName, mobileSession);
	}
	
	@Autowired
	private PerformanceLogger perfLogger;
	
	private String startPerformanceLog(HttpServletRequest httpRequest){
		perfLogger.startAllLogs();
		String logName = MBAppUtils.getLogName(httpRequest);
		perfLogger.startLog(logName);
		return logName;
	}
	
	private void endPerformanceLog(String logName){
		perfLogger.endLog(logName);
		perfLogger.endAllLogs();
	}

}
