package au.com.stgeorge.mbank.controller.loanApplication;

import au.com.stgeorge.ibank.businessobject.BusinessException;
import au.com.stgeorge.ibank.valueobject.homeloan.HomeLoanTileContentVO;
import au.com.stgeorge.mbank.model.response.homeloan.HomeLoanTileContentResp;

public class HomeLoanApplicationHelper 
{

	public void populateHomeLoanTileContentResp(HomeLoanTileContentResp resp, HomeLoanTileContentVO tileContentVO) throws BusinessException {
		resp.setHeading(tileContentVO.getProductGroup());
		resp.setProgressPercentage(tileContentVO.getProgressPercentage());
		resp.setProgressMessage(tileContentVO.getProgressMessage());
		resp.setApplicationId(tileContentVO.getApplicationId());
		resp.setPid(tileContentVO.getPid());
		resp.setDisableTile(tileContentVO.isDisableTile());
		resp.setNextActionMessage(tileContentVO.getNextActionMessage());
		resp.setTileExpired(false);
		resp.setApplicationCount(tileContentVO.getAppCount());
	}
	
}