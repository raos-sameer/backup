package au.com.stgeorge.mbank.model.common;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_NULL)
public class PayeeResp implements Serializable {

	private static final long serialVersionUID = 2493416265887979254L;
	private AccountKeyInfoResp payeeAccountKeyInfo;
	private String payerName;
	private String payeeEmail;
	private String payeeType;

	public AccountKeyInfoResp getPayeeAccountKeyInfo() {
		return payeeAccountKeyInfo;
	}

	public void setPayeeAccountKeyInfo(AccountKeyInfoResp payeeAccount) {
		this.payeeAccountKeyInfo = payeeAccount;
	}

	public String getPayerName() {
		return payerName;
	}

	public void setPayerName(String payerName) {
		this.payerName = payerName;
	}

	public String getPayeeEmail() {
		return payeeEmail;
	}

	public void setPayeeEmail(String payeeEmail) {
		this.payeeEmail = payeeEmail;
	}

	public String getPayeeType() {
		return payeeType;
	}

	public void setPayeeType(String payeeType) {
		this.payeeType = payeeType;
	}

}
