package au.com.stgeorge.mbank.model.request.customer;

import java.io.Serializable;

import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import au.com.stgeorge.ibank.businessobject.BusinessException;
import au.com.stgeorge.mbank.model.common.IMBReq;
import au.com.stgeorge.mbank.model.common.ReqHeader;

public class ReactivateReq implements IMBReq, Serializable{
	
	private static final long serialVersionUID = -8619853234497299428L;
	
	@Size(max = 16,message = ""+BusinessException.INVALID_USERID_PASSWORD)
	@Pattern(regexp="([0-9]+)",message = ""+BusinessException.INVALID_USERID_PASSWORD)
	private String accessNumber;
	
	private ReqHeader header;

	public ReqHeader getHeader()
	{
		return header;
	}
	public void setHeader(ReqHeader header)
	{
		this.header = header;
	}
	
	public String getAccessNumber() {
		return accessNumber;
	}
	public void setAccessNumber(String accessNumber) {
		this.accessNumber = accessNumber;
	}

}
