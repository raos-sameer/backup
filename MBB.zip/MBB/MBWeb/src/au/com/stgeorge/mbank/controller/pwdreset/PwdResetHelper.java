/**
 * 
 */
package au.com.stgeorge.mbank.controller.pwdreset;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Service;

import au.com.stgeorge.framework.common.logging.Logger;
import au.com.stgeorge.ibank.businessobject.BusinessException;
import au.com.stgeorge.ibank.common.cache.IBankParams;
import au.com.stgeorge.ibank.safi.util.SafiUtil;
import au.com.stgeorge.ibank.safi.valueobject.SafiDeviceInfo;
import au.com.stgeorge.ibank.safi.valueobject.SafiPwdResetVO;
import au.com.stgeorge.ibank.service.valueobject.SafiRespVO;
import au.com.stgeorge.ibank.util.DateUtils;
import au.com.stgeorge.ibank.valueobject.Customer;
import au.com.stgeorge.ibank.valueobject.pwdreset.PhoneNumber;
import au.com.stgeorge.ibank.valueobject.pwdreset.PwdResetCustomerDetails;
import au.com.stgeorge.ibank.valueobject.pwdreset.PwdSecureCodeDetails;
import au.com.stgeorge.ibank.valueobject.transfer.IBankCommonData;
import au.com.stgeorge.mbank.controller.SafiWebHelper;
import au.com.stgeorge.mbank.controller.customer.LogonHelper;
import au.com.stgeorge.mbank.model.common.ReqHeader;
import au.com.stgeorge.mbank.model.request.pwdreset.PwdResetReq;
import au.com.stgeorge.mbank.model.request.pwdreset.PwdSecNumResetReq;
import au.com.stgeorge.mbank.model.response.canretrieval.PhoneNumsResp;
import au.com.stgeorge.mbank.model.response.canretrieval.PhoneTypeEnum;
import au.com.stgeorge.mbank.model.response.canretrieval.SecureCodeInfoResp;
import au.com.stgeorge.mbank.session.MobileSession;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;

@Service
public class PwdResetHelper {

	public static final String OPEN_BRACKET = "("; 
	
	public static final String CLOSE_BRACKET = ")";
	
	public SecureCodeInfoResp populateSecureCodeResponse(PwdResetCustomerDetails pwdResetCustomerDetails) throws JsonParseException, JsonMappingException, IOException{
		SecureCodeInfoResp secureCodeInfoResp = new SecureCodeInfoResp();
		if(pwdResetCustomerDetails.getSecureCodeDetails() != null){			
			secureCodeInfoResp.setDeliveryPref(pwdResetCustomerDetails.getSecureCodeDetails().getDeliveryPref());
			secureCodeInfoResp.setPhonePref(pwdResetCustomerDetails.getSecureCodeDetails().getPhonePref());
			List<PhoneNumsResp> phoneNumsList = new ArrayList<PhoneNumsResp>();
			String hashedNumber = null;
			if(pwdResetCustomerDetails.getSecureCodeDetails().getHome() != null){
				PhoneNumsResp phoneNumsResp = new PhoneNumsResp();
				phoneNumsResp.setPhoneType(PhoneTypeEnum.HOME.toString());
				hashedNumber = OPEN_BRACKET + pwdResetCustomerDetails.getSecureCodeDetails().getHome().getAreaCode() + CLOSE_BRACKET + LogonHelper.maskPhoneNumber(pwdResetCustomerDetails.getSecureCodeDetails().getHome().getPhoneNumber());				
				phoneNumsResp.setPhoneNum(hashedNumber);
				phoneNumsList.add(phoneNumsResp);
			}
			if(pwdResetCustomerDetails.getSecureCodeDetails().getWork() != null){
				PhoneNumsResp phoneNumsResp = new PhoneNumsResp();
				phoneNumsResp.setPhoneType(PhoneTypeEnum.WORK.toString());
				hashedNumber = OPEN_BRACKET + pwdResetCustomerDetails.getSecureCodeDetails().getWork().getAreaCode() + CLOSE_BRACKET + LogonHelper.maskPhoneNumber(pwdResetCustomerDetails.getSecureCodeDetails().getWork().getPhoneNumber());
				phoneNumsResp.setPhoneNum(hashedNumber);
				phoneNumsList.add(phoneNumsResp);
			}
			if(pwdResetCustomerDetails.getSecureCodeDetails().getMobile() != null){
				PhoneNumsResp phoneNumsResp = new PhoneNumsResp();
				phoneNumsResp.setPhoneType(PhoneTypeEnum.MOBILE.toString());
				hashedNumber = LogonHelper.maskPhoneNumber(pwdResetCustomerDetails.getSecureCodeDetails().getMobile().getAreaCode()+pwdResetCustomerDetails.getSecureCodeDetails().getMobile().getPhoneNumber());
				phoneNumsResp.setPhoneNum(hashedNumber);
				phoneNumsList.add(phoneNumsResp);
			}
			if(phoneNumsList.size() > 0){
				secureCodeInfoResp.setPhoneNums(phoneNumsList);
			}			
		}
		return secureCodeInfoResp;
	}

	public Date validateDateOfBirth(String dateString) throws BusinessException{
		Date dob = null;
		Date currDate = new Date();
		SimpleDateFormat sdf = new SimpleDateFormat(DateUtils.ISO_8601_CALENDAR_DATE_FORMAT_PATTERN);
		sdf.setLenient(false);		
		try {
			dob = sdf.parse(dateString);
			if(dob.after(currDate)){
				throw new BusinessException(BusinessException.INVALID_DATE_OF_BIRTH);
			}
		} catch (ParseException e) {
			throw new BusinessException(BusinessException.INVALID_DATE_OF_BIRTH);
		}
		return dob;
	}
	
	public PwdResetCustomerDetails populatePwdResetCustomerDetails(IBankCommonData commondata) {
		//populate the PwdResetCustomerDetails from session
		PwdResetCustomerDetails pwdCustDetails = new PwdResetCustomerDetails();
		if(commondata!=null && commondata.getUser()!=null && commondata.getCustomer()!=null){
			pwdCustDetails.setCan(commondata.getUser().getUserId());
			pwdCustDetails.setGcisNumber(commondata.getUser().getGCISNumber());
			String cardIssueNum =(String)commondata.getUser().getAttribute(IBankParams.USEROBJ_CARDNUMBER);			
			if(cardIssueNum!=null && cardIssueNum.length() > 1){
				pwdCustDetails.setCardNumber(cardIssueNum.substring(0, cardIssueNum.length()-1));
				pwdCustDetails.setIssueNum(cardIssueNum.substring(cardIssueNum.length()-1, cardIssueNum.length()));
			}
			pwdCustDetails.setIpAddress(commondata.getIpAddress());			
			Customer cust =commondata.getCustomer();
		
			PwdSecureCodeDetails secureCodeDetails =new PwdSecureCodeDetails();
			if(cust.getContactDetail()!=null && cust.getContactDetail().getMobileNumber()!=null){
				PhoneNumber mobile =new PhoneNumber();
				mobile.setAreaCode(cust.getContactDetail().getMobileNumber().getAreaCode());
				mobile.setPhoneNumber(cust.getContactDetail().getMobileNumber().getPhoneNumber());
				secureCodeDetails.setMobile(mobile);
			}
			pwdCustDetails.setSecureCodeDetails(secureCodeDetails);
		}
		
		return pwdCustDetails;
	}
	
	
    

	public PwdResetCustomerDetails populatePwdResetDetails(PwdResetCustomerDetails pwdCustDetails,PwdSecNumResetReq request){
		pwdCustDetails.setPassword(request.getPassword());
		pwdCustDetails.setConfirmPassword(request.getConfirmPassword());
		pwdCustDetails.setSecurityNo(request.getSecNum());
		pwdCustDetails.setConfirmSecurityNo(request.getConfirmSecNum());
		return pwdCustDetails;
	}
	
	private static final String DEVICE_TYPE_TABLET = "TABLET";
	private static final String DEVICE_TYPE_MOBILE = "MOBILE";
	public String getGDWOrigin(ReqHeader req, String origin)
    {
          StringBuffer tempOrigin = new StringBuffer();
          if ( req.getDeviceType() != null && req.getDeviceType().toUpperCase().startsWith(DEVICE_TYPE_TABLET) )
          {
                tempOrigin.append(origin.substring(1));
          }
          else
          {
                tempOrigin.append(origin);
          }
          return tempOrigin.toString();
    }
	
	public SafiPwdResetVO populateSafiVO(HttpServletRequest httpRequest, MobileSession mobileSession, IBankCommonData commonData, PwdResetReq request, boolean isMobileApp, SafiDeviceInfo safiDeviceInfo) throws BusinessException {
		String validDecodedPrint;
		String devicePrint;
		Logger.debug("SAFI : populateSafiVO Device Print" +request.getDevicePrint(), this.getClass()) ;
		validDecodedPrint = SafiUtil.validateDevicePrint(request.getDevicePrint());
		devicePrint = validDecodedPrint != null ? request.getDevicePrint():null;
		
		SafiPwdResetVO safiVO = new SafiPwdResetVO();
		
		if(null == devicePrint && null != safiDeviceInfo && null != safiDeviceInfo.getValidDevicePrintJson()) {
			devicePrint = safiDeviceInfo.getValidDevicePrintJson();
			Logger.debug("SAFI : populateSafiVO :  Device Print from request was null so getting from cookie Pm_dp:" +devicePrint, this.getClass()) ;
		}
			
		Logger.debug("SAFI : populateSafiVO for PWD reset: validDecodedPrint: " +validDecodedPrint + " devicePrint: "+devicePrint+" isMobileApp: "+isMobileApp, this.getClass()) ;
			
		safiVO = SafiWebHelper.populateSafiVOForPwdReset(httpRequest, devicePrint, commonData, isMobileApp, safiVO, mobileSession, safiDeviceInfo);
		
		return safiVO;
	}
	
	public void handleSafiResponseinCookies(HttpServletRequest httpServletRequest,HttpServletResponse httpServletResponse, SafiRespVO safiRespVO){
		if(safiRespVO != null){
			Cookie pmdata2 = SafiWebHelper.readCookies(httpServletRequest);
			Cookie newCookie = SafiWebHelper.createOrUpdatePmdata2Cookie(httpServletRequest,pmdata2,safiRespVO.getDeviceToken());
			httpServletResponse.addCookie(newCookie);
		}
	}
	
	public long getDaysSinceLastLogonCredChanged(Date changePasswordDate) {
		try {
			if(changePasswordDate != null) {
				return ChronoUnit.DAYS.between(changePasswordDate.toInstant(), new Date().toInstant());
			}
		}
		catch(Exception e){
			Logger.warn("Error in getting Days since last Logon Cred changed data", e, this.getClass());
		}
		return 0;
	}
	
	public boolean isNoContactPhoneNumberAvailable(PwdResetCustomerDetails pwdResetCustomerDetails) {
		if(pwdResetCustomerDetails.getSecureCodeDetails() != null){	
			if(pwdResetCustomerDetails.getSecureCodeDetails().getHome() == null && 
				pwdResetCustomerDetails.getSecureCodeDetails().getWork() == null &&
				pwdResetCustomerDetails.getSecureCodeDetails().getMobile() == null){
				return true;
			}
		}else {
			return true;
		}
		return false;
	}
}
