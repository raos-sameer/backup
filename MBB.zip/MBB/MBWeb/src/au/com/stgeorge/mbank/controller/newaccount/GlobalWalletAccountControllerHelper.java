package au.com.stgeorge.mbank.controller.newaccount;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import au.com.stgeorge.framework.common.util.DateMethods;
import au.com.stgeorge.framework.common.util.StringMethods;
import au.com.stgeorge.ibank.businessobject.BusinessException;
import au.com.stgeorge.ibank.businessobject.globalWallet.GlobalWalletService;
import au.com.stgeorge.ibank.businessobject.globalWallet.GlobalWalletServiceHelper;
import au.com.stgeorge.ibank.businessobject.globalWallet.GlobalWalletUtil;
import au.com.stgeorge.ibank.businessobject.model.globalwallet.cardholderdetails.GetCardHolderAccountDetailsResp;
import au.com.stgeorge.ibank.util.DateUtils;
import au.com.stgeorge.ibank.util.ServiceHelper;
import au.com.stgeorge.ibank.util.StringUtil;
import au.com.stgeorge.ibank.valueobject.Account;
import au.com.stgeorge.ibank.valueobject.CardActivation;
import au.com.stgeorge.ibank.valueobject.Customer;
import au.com.stgeorge.ibank.valueobject.GCCAccount;
import au.com.stgeorge.ibank.valueobject.GlobalCardActivation;
import au.com.stgeorge.ibank.valueobject.PursePaymentLog;
import au.com.stgeorge.ibank.valueobject.globalWallet.GlobalWalletDetails;
import au.com.stgeorge.ibank.valueobject.globalWallet.GlobalWalletPurse;
import au.com.stgeorge.ibank.valueobject.globalWallet.GlobalWalletPursePayment;
import au.com.stgeorge.ibank.valueobject.globalWallet.GlobalWalletReceipt;
import au.com.stgeorge.ibank.valueobject.globalWallet.GlobalWalletTransaction;
import au.com.stgeorge.ibank.valueobject.globalWallet.GlobalWalletTransactionDetails;
import au.com.stgeorge.ibank.valueobject.transfer.IBankCommonData;
import au.com.stgeorge.mbank.model.request.newaccount.GlobalWalletPurseTransferReq;
import au.com.stgeorge.mbank.model.response.CurrenciesDebitedResp;
import au.com.stgeorge.mbank.model.response.GlobalWalletTransDetailsResp;
import au.com.stgeorge.mbank.model.response.GlobalWalletTransListingResp;
import au.com.stgeorge.mbank.model.response.GlobalWalletTransactionResp;
import au.com.stgeorge.mbank.model.response.accountinfo.GlobalWalletAccountInfoResp;
import au.com.stgeorge.mbank.model.response.accountinfo.GlobalWalletCardsForSetPinResp;
import au.com.stgeorge.mbank.model.response.accountinfo.GlobalWalletPurseTransferResp;
import au.com.stgeorge.mbank.model.response.accountinfo.GlobalWalletTransferReceiptResp;
import au.com.stgeorge.mbank.model.response.services.GlobalWalletActivationResp;
import au.com.stgeorge.mbank.session.MobileSession;
import au.com.stgeorge.mbank.util.MBAppHelper;
import au.com.stgeorge.mbank.util.MBAppUtils;

public class GlobalWalletAccountControllerHelper {
	
	private static final String SUCCESS = "Success";
		
	//private static NumberFormat numberFormat = new DecimalFormat("#,###,###,###.00");
	//private static NumberFormat numberFormatJPY = new DecimalFormat("#,###,###,###");
	//public static final String CURRENCY_CODE_JPY = "JPY";
	
	/*static {
		numberFormatJPY.setRoundingMode(RoundingMode.DOWN);
	}*/
	
	private MBAppHelper mbAppHelper;	
	
	public MBAppHelper getMbAppHelper() {
		return mbAppHelper;
	}

	public void setMbAppHelper(MBAppHelper mbAppHelper) {
		this.mbAppHelper = mbAppHelper;
	}
	
	public GlobalWalletPursePayment populateGlobalWalletPursePaymentVO(MobileSession mbSession, GlobalWalletPurseTransferReq globalWalletPurseTransferReq) throws BusinessException {
		GlobalWalletPursePayment globalWalletPursePaymentVO = new GlobalWalletPursePayment();

		int myAcctIndex = globalWalletPurseTransferReq.getAccountIndex();
		Customer customer=mbSession.getCustomer();			
		GCCAccount globalWalletAccount = (GCCAccount) mbAppHelper.getAccountFromCustomer(customer, myAcctIndex);
		
		HashMap<String, GlobalWalletPurse> gccExchangeRateQuotes = mbSession.getGccExchangeRateQuotes();
		GlobalWalletPurse globalWalletPurse = gccExchangeRateQuotes.get(globalWalletPurseTransferReq.getFromCurrencyCode().toUpperCase()+"|"+globalWalletPurseTransferReq.getToCurrencyCode());   
		String quoteId = null;
		Long forexId = null;
		if(globalWalletPurse != null) {
			quoteId = globalWalletPurse.getQuoteId();
			forexId = globalWalletPurse.getId();
		} 
		if(quoteId == null || forexId == null) {
			throw new BusinessException(BusinessException.GLOBAL_WALLET_PURSE_TRANSFER_SVC_UNAVAILABLE);
		}
		
		globalWalletPursePaymentVO.setDebitcurrencyCode(globalWalletPurseTransferReq.getFromCurrencyCode());
		globalWalletPursePaymentVO.setDebitAmount(new BigDecimal(globalWalletPurseTransferReq.getTransferAmt()));
		globalWalletPursePaymentVO.setCreditcurrencyCode(globalWalletPurseTransferReq.getToCurrencyCode());
		globalWalletPursePaymentVO.setCreditAmount(new BigDecimal(globalWalletPurseTransferReq.getExchangeAmt()));
		globalWalletPursePaymentVO.setQuoteId(quoteId);
		globalWalletPursePaymentVO.setExchangeRate(new BigDecimal(globalWalletPurseTransferReq.getExchangeRate()));
		
		globalWalletPursePaymentVO.setGcisNumber(customer.getGcis());
		globalWalletPursePaymentVO.setPayerName(customer.getFullName()); //TBC TODO
		globalWalletPursePaymentVO.setOrigin(mbSession.getOrigin()); //TBC TODO
		globalWalletPursePaymentVO.setBsbNumber(globalWalletAccount.getAccountId().getBsb());
		globalWalletPursePaymentVO.setAccountNumber(globalWalletAccount.getAccountId().getAccountNumber());
		globalWalletPursePaymentVO.setCard(globalWalletAccount.getCardNumber());
		globalWalletPursePaymentVO.setForexId(forexId);
		
		return globalWalletPursePaymentVO;
	}


	public GlobalWalletPurseTransferResp populateGlobalWalletPurseTransferResp(int index, GlobalWalletReceipt globalWalletReceipt, MobileSession mbSession) {
				
		GlobalWalletPurseTransferResp globalWalletPurseTransferResp = new GlobalWalletPurseTransferResp();
		
		GlobalWalletTransferReceiptResp receipt = new GlobalWalletTransferReceiptResp();
		receipt.setAccountIndex(index);
		
		PursePaymentLog pursePaymentLog = globalWalletReceipt.getPursePaymentLog();
		
		if(pursePaymentLog!=null) {
			receipt.setFromCurrencyCode(pursePaymentLog.getDebitcurrencyCode());
			receipt.setTransferAmt(String.valueOf(pursePaymentLog.getDebitAmount()));
			receipt.setToCurrencyCode(pursePaymentLog.getCreditcurrencyCode());
			receipt.setExchangeAmt(String.valueOf(pursePaymentLog.getCreditAmount()));
			receipt.setExchangeRate(String.valueOf(pursePaymentLog.getExchangeRate()));
		}
		
		if(!StringMethods.isEmptyString(globalWalletReceipt.getReceiptNumber()))
			receipt.setReceiptNumDisp(MBAppUtils.formatReceiptNumber(globalWalletReceipt.getReceiptNumber()));
		
		int status = -1;
        if(GlobalWalletReceipt.ResponseStausEnum.ACSC.getStatus().equalsIgnoreCase(globalWalletReceipt.getGrpStatus())){
        	status = GlobalWalletUtil.PAYMENTS_SUCCESSFUL;//PaymentsLog.PAYMENTSLOG_SUCCESSFUL_TRANSACTION;
        	if(!StringMethods.isEmptyString(mbSession.getPursePaymentsLogId())) {
        		mbSession.removePursePaymentsLogId();
        	}
        }
        else if(GlobalWalletReceipt.ResponseStausEnum.RJCT.getStatus().equalsIgnoreCase(globalWalletReceipt.getGrpStatus())){
        	status = GlobalWalletUtil.PAYMENTS_ERROR;//PaymentsLog.PAYMENTSLOG_ERROR_TRANSACTION;
        	if(!StringMethods.isEmptyString(mbSession.getPursePaymentsLogId())) {
        		mbSession.removePursePaymentsLogId();
        	}
        }
        else if(GlobalWalletReceipt.ResponseStausEnum.ACSP.getStatus().equalsIgnoreCase(globalWalletReceipt.getGrpStatus())){
        	status = GlobalWalletUtil.PROCESSING_RECEIPT_STATUS;
			mbSession.setPursePaymentsLogId(globalWalletReceipt.getPaymentLog().getId()+"");
			mbSession.setSelectedAccountIndex(String.valueOf(index));
        }

		receipt.setStatus(status);
		receipt.setTranDateTime(globalWalletReceipt.getTimestamp());
		
		globalWalletPurseTransferResp.setReceipt(receipt);
		return globalWalletPurseTransferResp;
	}

	
	/**
	 * This method will populate limit for the GCC Account details page.
	 * @param mbSession
	 * @return GCCAccountInfoResp
	 */
	public GlobalWalletAccountInfoResp populateGlobalWalletAcctLimitsResp(MobileSession mbSession, Account account, GlobalWalletDetails globalWalletDtls) {
		GlobalWalletAccountInfoResp response = new GlobalWalletAccountInfoResp();
		response.setAccountKey(mbAppHelper.getGlobalWalletAcctKeyInfoResp(account));																			
		response.setProductName(account.getAccountId().getProductName());
		response.setAccountLimit(globalWalletDtls.getAccountLimit());
		response.setAccountPerDayLimit(globalWalletDtls.getAccountPerDayLimit());
		response.setAccountPerAnnumLimit(globalWalletDtls.getAccountPerAnnumLimit());
		return response;
	}
	
	/**
	 * This method will populate transaction listing response for the Transactions tab.
	 * @param mbSession
	 * @return GlobalWalletTransListingResp
	 */
	public GlobalWalletTransListingResp populateGlobalWalletTransactionListingResp(MobileSession mbSession, Account account, GlobalWalletDetails globalWalletDtls) {
		GlobalWalletTransListingResp transListingResp = new GlobalWalletTransListingResp();
		
		//Set Pending Transactions in the Response
		List<GlobalWalletTransaction> pendingTransactions = globalWalletDtls.getPendingTransactions();
		List<GlobalWalletTransactionResp> pendingTransactionsResp = new ArrayList<GlobalWalletTransactionResp>();
		
		for (GlobalWalletTransaction pendingTransaction : pendingTransactions) {
			GlobalWalletTransactionResp globalWalletTransactionResp = new GlobalWalletTransactionResp(); 
			globalWalletTransactionResp.setAmount(pendingTransaction.getAmount());
			globalWalletTransactionResp.setCurrencyCode(pendingTransaction.getCurrencyCode());
			globalWalletTransactionResp.setDescription(pendingTransaction.getDescription());
			globalWalletTransactionResp.setReferenceNumber(pendingTransaction.getReferenceNumber());
			if(pendingTransaction.getSettlementDate()!=null && pendingTransaction.getSettlementDate().length()>=10) {
				globalWalletTransactionResp.setSettlementDate(pendingTransaction.getSettlementDate().substring(0, 10));
			}
			globalWalletTransactionResp.setTransactionCode(pendingTransaction.getTransactionCode());
			if(pendingTransaction.getTransactionDate()!=null && pendingTransaction.getTransactionDate().length()>=10) {
				globalWalletTransactionResp.setTransactionDate(pendingTransaction.getTransactionDate().substring(0, 10));
			}
			globalWalletTransactionResp.setTransactionSequenceNumber(pendingTransaction.getTransactionSequenceNumber());
			globalWalletTransactionResp.setTransactionType(pendingTransaction.getTransactionType());
			
			if(!StringMethods.isEmptyString(pendingTransaction.getAuthorizationDateTime())) {
				globalWalletTransactionResp.setAuthorizationDateTime(DateUtils.StringtoDateSoftConvert(pendingTransaction.getAuthorizationDateTime(), "yyyy-MM-dd'T'HH:mm:ss"));
			}
			
			pendingTransactionsResp.add(globalWalletTransactionResp);
		}
		transListingResp.setPendingTransactions(pendingTransactionsResp);
		
		//Set Posted Transactions in the Response
		List<GlobalWalletTransaction> postedTransactions = globalWalletDtls.getPostedTransactions();
		List<GlobalWalletTransactionResp> postedTransactionsResp = new ArrayList<GlobalWalletTransactionResp>();
		
		for (GlobalWalletTransaction postedTransaction : postedTransactions) {
			GlobalWalletTransactionResp globalWalletTransactionResp = new GlobalWalletTransactionResp(); 
			globalWalletTransactionResp.setAmount(postedTransaction.getAmount());
			globalWalletTransactionResp.setCurrencyCode(postedTransaction.getCurrencyCode());
			globalWalletTransactionResp.setDescription(postedTransaction.getDescription());
			globalWalletTransactionResp.setReferenceNumber(postedTransaction.getReferenceNumber());
			globalWalletTransactionResp.setSettlementDate(postedTransaction.getSettlementDate().substring(0,10));
			globalWalletTransactionResp.setTransactionCode(postedTransaction.getTransactionCode());
			if(postedTransaction.getTransactionDate()!=null && postedTransaction.getTransactionDate().length() >= 10) {
				globalWalletTransactionResp.setTransactionDate(postedTransaction.getTransactionDate().substring(0, 10));
			}
			globalWalletTransactionResp.setEffectiveDateTime(postedTransaction.getEffectiveDate());
			globalWalletTransactionResp.setCycleDateTime(postedTransaction.getCycleDateTime());

			globalWalletTransactionResp.setTransactionSequenceNumber(postedTransaction.getTransactionSequenceNumber());
			globalWalletTransactionResp.setTransactionType(postedTransaction.getTransactionType());
			postedTransactionsResp.add(globalWalletTransactionResp);
		}
		
		transListingResp.setPostedTransactions(postedTransactionsResp);
		transListingResp.setIsLoadMore(globalWalletDtls.getIsLoadMore());
		transListingResp.setPostedTransactionStartIndex(globalWalletDtls.getPostedTransactionStartIndex());
	
		return transListingResp;
	}
	
	/**
	 * This method will populate transaction details response for the Transactions page.
	 * @param mbSession
	 * @return GlobalWalletTransDetailsResp
	 */
	public GlobalWalletTransDetailsResp populateGlobalWalletTransactionDetailsResp(List<GlobalWalletTransactionDetails> globalWalletTransactionDetailsList, String currencyCode
			,String tranCode, String convertCurrencyDescription, boolean isWalletTransfer) {
		GlobalWalletTransDetailsResp transDetailsResp = new GlobalWalletTransDetailsResp();
		
		//Set Transaction Details in the Response
		transDetailsResp.setTransactionID(globalWalletTransactionDetailsList.get(0).getTransactionID());		
		
		transDetailsResp.setCurrencySupported(globalWalletTransactionDetailsList.get(0).getCurrencySupported());
		transDetailsResp.setDontRecognizeMsg(globalWalletTransactionDetailsList.get(0).getDontRecognizeMsg());
		
		transDetailsResp.setConvertCurrencyError(globalWalletTransactionDetailsList.get(0).getConvertCurrencyError());
		
		List<CurrenciesDebitedResp> currenciesDebitedRespList = new ArrayList<CurrenciesDebitedResp>();
		List<String> exchangeRatesRespList = new ArrayList<String>();
		
		//Only for purchase transactions
		if(tranCode.equalsIgnoreCase(GlobalWalletServiceHelper.TXN_CODE_PURCHASE_TRANSACTION) || tranCode.equalsIgnoreCase(GlobalWalletServiceHelper.TXN_CODE_PURCHASE_REVERSAL_TRANSACTION) ||
				tranCode.equalsIgnoreCase(GlobalWalletServiceHelper.TXN_CODE_ATM_WITHDRAWAL_TRANSACTION) || tranCode.equalsIgnoreCase(GlobalWalletServiceHelper.TXN_CODE_ATM_WITHDRAWAL_REVERSAL_TRANSACTION)) {
			if(globalWalletTransactionDetailsList.size()==1) {
				if(!globalWalletTransactionDetailsList.get(0).getCurreciesDebited().getCurrencyCode().equalsIgnoreCase(currencyCode)) {
					
					CurrenciesDebitedResp currenciesDebitedResp = new CurrenciesDebitedResp();
					currenciesDebitedResp.setAmount(globalWalletTransactionDetailsList.get(0).getCurreciesDebited().getAmount().toString());
					currenciesDebitedResp.setCurrencyCode(globalWalletTransactionDetailsList.get(0).getCurreciesDebited().getCurrencyCode());
					currenciesDebitedRespList.add(currenciesDebitedResp);
					exchangeRatesRespList.add(globalWalletTransactionDetailsList.get(0).getConversionRate());
				}
			}
			else {	
				for (GlobalWalletTransactionDetails globalWalletTransactionDetails : globalWalletTransactionDetailsList) {
					
					CurrenciesDebitedResp currenciesDebitedResp = new CurrenciesDebitedResp();
                    currenciesDebitedResp.setAmount(globalWalletTransactionDetails.getCurreciesDebited().getAmount().toString());
					currenciesDebitedResp.setCurrencyCode(globalWalletTransactionDetails.getCurreciesDebited().getCurrencyCode());
					currenciesDebitedRespList.add(currenciesDebitedResp);
					
					if(!globalWalletTransactionDetails.getCurreciesDebited().getCurrencyCode().equalsIgnoreCase(currencyCode)) {
						exchangeRatesRespList.add(globalWalletTransactionDetails.getConversionRate());						
					}
				}		
			}
		}
		
		//Only for convert currency transactions
		/*if((tranCode.equalsIgnoreCase(GlobalWalletServiceHelper.TXN_CODE_CREDIT_ADJUSTMENT) ||
		tranCode.equalsIgnoreCase(GlobalWalletServiceHelper.TXN_CODE_DEBIT_ADJUSTMENT)) && convertCurrencyDescription.startsWith("CONVERTED CURRENCY")) {	*/		
		if(isWalletTransfer) {	
			for (GlobalWalletTransactionDetails globalWalletTransactionDetails : globalWalletTransactionDetailsList) {
				
				exchangeRatesRespList.add(convertCurrencyDescription);
				
				CurrenciesDebitedResp currenciesDebitedFromResp = null;
				CurrenciesDebitedResp currenciesDebitedToResp = null;
				
				if(globalWalletTransactionDetails.getFrom()!=null) {				
					if(globalWalletTransactionDetails.getFrom().getAmount()!=null && globalWalletTransactionDetails.getFrom().getCurrencyCode()!=null) {
						currenciesDebitedFromResp = new CurrenciesDebitedResp();
                        currenciesDebitedFromResp.setAmount(globalWalletTransactionDetails.getFrom().getAmount().toString());
						currenciesDebitedFromResp.setCurrencyCode(globalWalletTransactionDetails.getFrom().getCurrencyCode());
					 }				
				}
				
				if(globalWalletTransactionDetails.getTo()!=null) {
					
					if(globalWalletTransactionDetails.getTo().getAmount()!=null && globalWalletTransactionDetails.getTo().getCurrencyCode()!=null) {
						currenciesDebitedToResp = new CurrenciesDebitedResp();
                        currenciesDebitedToResp.setAmount(globalWalletTransactionDetails.getTo().getAmount().toString());
						currenciesDebitedToResp.setCurrencyCode(globalWalletTransactionDetails.getTo().getCurrencyCode());
					}				
				}
				
				transDetailsResp.setFrom(currenciesDebitedFromResp);
				transDetailsResp.setTo(currenciesDebitedToResp);
			}			
		}
				
		transDetailsResp.setCurrenciesDebited(currenciesDebitedRespList);
		transDetailsResp.setExchangeRates(exchangeRatesRespList);
		
		return transDetailsResp;
	}
	
	/*private String getFormattedAmount(String currencyCode, BigDecimal amount){
		
		if(currencyCode.equalsIgnoreCase(CURRENCY_CODE_JPY)) {
			return numberFormatJPY.format(amount);
		}else {
			return numberFormat.format(amount);
		}
	}*/
	
	public GlobalWalletCardsForSetPinResp populateCardsForSetPinResp(GetCardHolderAccountDetailsResp cardHolderAccountDetailsResp , MobileSession mbSession){
		GlobalWalletCardsForSetPinResp resp = new GlobalWalletCardsForSetPinResp();
		
		List<GlobalWalletActivationResp> globalWalletActivationResp = new ArrayList<>();
		
		if(null != cardHolderAccountDetailsResp.getData() &&
				null != cardHolderAccountDetailsResp.getData().getCurrencyCards()){
						
			for(String card : cardHolderAccountDetailsResp.getData().getCurrencyCards()){
				GlobalWalletActivationResp gwaResp = new GlobalWalletActivationResp();
				gwaResp.setArrangementId(card);
				gwaResp.setArrangementIdSetPINDisplay(StringUtil.formatCCSAccountNumber(card));
				gwaResp.setArrangementIdDisplay(StringUtil.formatGlobaleWalletDisplayCardNumber(card));
				gwaResp.setActivationStatus(SUCCESS);
				
				globalWalletActivationResp.add(gwaResp);				
			}
			
			resp.setGlobalWalletActivationResp(globalWalletActivationResp);
			//TODO - remove hard coded name 			
			resp.setProductName("GlobalWallet");
				
			CardActivation cardActivation = new CardActivation();
			List<GlobalCardActivation> activatedCardRespList = new ArrayList<>();
			for (String cardNumber : cardHolderAccountDetailsResp.getData().getCurrencyCards()) {
				GlobalCardActivation globalCardActivation = new GlobalCardActivation();
				globalCardActivation.setArrangementId(cardNumber);
				activatedCardRespList.add(globalCardActivation);
			}
			cardActivation.setCardNumber(cardHolderAccountDetailsResp.getData().getCurrencyCards().get(0));
			cardActivation.setGlobalCardActivationList(activatedCardRespList);
			mbSession.setCardActivation(cardActivation);
		}
		
		return resp;
	}
	
	public CurrenciesDebitedResp getNonNetworkTxn(List<GlobalWalletTransactionDetails> globalWalletTransactionDetailsList, IBankCommonData commonData, String tranCode) {
		
        //Only For Non Network Transactions - 20E4
		GlobalWalletService globalWalletService = ServiceHelper.getBean("globalWalletService");
		CurrenciesDebitedResp nonNetworkTxn = null;
		if(globalWalletService.isNonNetworkTxn(commonData.getOrigin() , tranCode)) {
			if(globalWalletTransactionDetailsList !=null && globalWalletTransactionDetailsList.size() ==1 && globalWalletTransactionDetailsList.get(0).getCurreciesDebited() != null
					 &&  !"AUD".equalsIgnoreCase(globalWalletTransactionDetailsList.get(0).getCurreciesDebited().getCurrencyCode())) {
				GlobalWalletTransactionDetails txnDetail = globalWalletTransactionDetailsList.get(0);				
				nonNetworkTxn = new CurrenciesDebitedResp();				
				nonNetworkTxn.setCurrencyCode(txnDetail.getCurreciesDebited().getCurrencyCode());
				nonNetworkTxn.setAmount(txnDetail.getCurreciesDebited().getAmount().toString());
			}
			
		}
		
		return nonNetworkTxn;
	}
}
