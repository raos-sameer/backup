package au.com.stgeorge.mbank.model.loanApplication;

import java.util.List;

import au.com.stgeorge.mbank.model.common.ErrorInfo;
import au.com.stgeorge.mbank.model.common.IMBResp;
import au.com.stgeorge.mbank.model.common.RespHeader;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_NULL)
public class EContractResp implements IMBResp {

	/**
	 * 
	 */
	private static final long serialVersionUID = 5862837232014769214L;
	private RespHeader header;
	private Boolean isSuccess = false; 	
	private Boolean auth2FArequired = true;
	private List<ErrorInfo> error;
	
	public RespHeader getHeader() {
		return header;
	}
	public void setHeader(RespHeader header) {
		this.header = header;
	}
	public Boolean getIsSuccess() {
		return isSuccess;
	}
	public void setIsSuccess(Boolean isSuccess) {
		this.isSuccess = isSuccess;
	}
	public List<ErrorInfo> getError() {
		return error;
	}
	public void setError(List<ErrorInfo> error) {
		this.error = error;
	}
	public Boolean getAuth2FArequired() {
		return auth2FArequired;
	}
	public void setAuth2FArequired(Boolean auth2fArequired) {
		auth2FArequired = auth2fArequired;
	}
	
	
}
