package au.com.stgeorge.mbank.controller.payments;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.builder.ReflectionToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;

import com.fasterxml.jackson.databind.ObjectMapper;

import au.com.stgeorge.digitalsec.logger.DigitalSecLogger;
import au.com.stgeorge.digitalsec.logger.DigitalSecLogggerVO;
import au.com.stgeorge.framework.common.logging.Logger;
import au.com.stgeorge.framework.common.util.DateMethods;
import au.com.stgeorge.ibank.businessobject.BusinessException;
import au.com.stgeorge.ibank.businessobject.CustomerService;
import au.com.stgeorge.ibank.businessobject.DuplicateException;
import au.com.stgeorge.ibank.businessobject.IBankSecureService;
import au.com.stgeorge.ibank.businessobject.NPPCommonService;
import au.com.stgeorge.ibank.businessobject.NPPService;
import au.com.stgeorge.ibank.businessobject.PayeeLimitService;
import au.com.stgeorge.ibank.businessobject.PaymentService;
import au.com.stgeorge.ibank.businessobject.PrudentialLimitHelper;
import au.com.stgeorge.ibank.businessobject.ResourceException;
import au.com.stgeorge.ibank.businessobject.ThirdPartyTransferHelper;
import au.com.stgeorge.ibank.common.cache.IBankParams;
import au.com.stgeorge.ibank.common.cache.IBankRefershParams;
import au.com.stgeorge.ibank.npp.NPPParams;
import au.com.stgeorge.ibank.npp.NPPStatus;
import au.com.stgeorge.ibank.npp.PayIdPaymentSwitchParams;
import au.com.stgeorge.ibank.npp.dao.valueobject.NPPPayIdPayee;
import au.com.stgeorge.ibank.safi.util.SafiConstants;
import au.com.stgeorge.ibank.safi.util.SafiUtil;
import au.com.stgeorge.ibank.safi.valueobject.SafiForensicInfo;
import au.com.stgeorge.ibank.safi.valueobject.SafiPayIdDetails;
import au.com.stgeorge.ibank.safi.valueobject.SafiPayTranVO;
import au.com.stgeorge.ibank.service.valueobject.SafiRespVO;
import au.com.stgeorge.ibank.servicestation.businessobject.ServiceStation;
import au.com.stgeorge.ibank.servicestation.businessobject.ServiceStationImpl;
import au.com.stgeorge.ibank.servicestation.businessobject.valueobject.ServiceStationVO;
import au.com.stgeorge.ibank.servicestation.util.ServicetationConstants;
import au.com.stgeorge.ibank.util.CommonBusinessUtil;
import au.com.stgeorge.ibank.util.DateUtils;
import au.com.stgeorge.ibank.util.NPPUtil;
import au.com.stgeorge.ibank.util.StringUtil;
import au.com.stgeorge.ibank.valueobject.Account;
import au.com.stgeorge.ibank.valueobject.AccountFlags;
import au.com.stgeorge.ibank.valueobject.Customer;
import au.com.stgeorge.ibank.valueobject.NPPPayment;
import au.com.stgeorge.ibank.valueobject.PayIDResolution;
import au.com.stgeorge.ibank.valueobject.PaymentDuplicateVO;
import au.com.stgeorge.ibank.valueobject.PaymentsLog;
import au.com.stgeorge.ibank.valueobject.PhoneNumber;
import au.com.stgeorge.ibank.valueobject.Receipt;
import au.com.stgeorge.ibank.valueobject.SecureCodeDetails;
import au.com.stgeorge.ibank.valueobject.Statistic;
import au.com.stgeorge.ibank.valueobject.ThirdParty;
import au.com.stgeorge.ibank.valueobject.ThirdPartyPayment;
import au.com.stgeorge.ibank.valueobject.collection.LabelValueMap;
import au.com.stgeorge.ibank.valueobject.database.CodesVO;
import au.com.stgeorge.ibank.valueobject.database.OriginsVO;
import au.com.stgeorge.ibank.valueobject.database.PaymentsLogVO;
import au.com.stgeorge.ibank.valueobject.transfer.IBankCommonData;
import au.com.stgeorge.ibank.valueobject.transfer.NPPEnrichmentDetails;
import au.com.stgeorge.ibank.valueobject.transfer.NPPValidations;
import au.com.stgeorge.mbank.controller.IMBController;
import au.com.stgeorge.mbank.controller.SafiWebHelper;
import au.com.stgeorge.mbank.controller.SecureCodeHelper;
import au.com.stgeorge.mbank.controller.customer.LogonHelper;
import au.com.stgeorge.mbank.model.common.IMBReq;
import au.com.stgeorge.mbank.model.common.IMBResp;
import au.com.stgeorge.mbank.model.common.ReqHeader;
import au.com.stgeorge.mbank.model.common.RespHeader;
import au.com.stgeorge.mbank.model.payments.ResubmitPaymentResp;
import au.com.stgeorge.mbank.model.request.ChangePayeeLimitLinkReq;
import au.com.stgeorge.mbank.model.request.EmptyReq;
import au.com.stgeorge.mbank.model.request.IndexReq;
import au.com.stgeorge.mbank.model.request.SecureCodeReq;
import au.com.stgeorge.mbank.model.request.payments.AddPayeeReq;
import au.com.stgeorge.mbank.model.request.payments.NPPValidateEnrichmentReq;
import au.com.stgeorge.mbank.model.request.payments.NPPValidationsReq;
import au.com.stgeorge.mbank.model.request.payments.PayToPayIdLandingPageReq;
import au.com.stgeorge.mbank.model.request.payments.PayeeTransferReq;
import au.com.stgeorge.mbank.model.request.payments.PaymentLogStatusReq;
import au.com.stgeorge.mbank.model.request.payments.ResolvePayIdReq;
import au.com.stgeorge.mbank.model.response.ErrorResp;
import au.com.stgeorge.mbank.model.response.payments.NPPValidationsResp;
import au.com.stgeorge.mbank.model.response.payments.ResolvePayIdResp;
import au.com.stgeorge.mbank.model.response.payments.TransferResp;
import au.com.stgeorge.mbank.session.MobileSession;
import au.com.stgeorge.mbank.session.MobileSessionImpl;
import au.com.stgeorge.mbank.util.MBAppHelper;
import au.com.stgeorge.mbank.util.MBAppUtils;
import au.com.stgeorge.mbank.util.MBAppValidator;
import au.com.stgeorge.mbank.util.ServiceConstants;
import au.com.stgeorge.mobilebank.businessobject.MobileBankService;
import au.com.stgeorge.mobilebank.businessobject.PayeeService;
import au.com.stgeorge.mobilebank.businessobject.TransactService;
import au.com.stgeorge.perflogger.PerformanceLogger;
import au.com.stgeorge.security.util.StringMethods;
import javax.xml.datatype.XMLGregorianCalendar;
import java.text.SimpleDateFormat;
/**
 * Transfer to Payee controller
 * 
 * @author C38854
 */
/**
 * @author C86611
 *
 */
@Controller
@RequestMapping("/payee")
public class PayeeController implements IMBController {
	
	
	private static final int DE_DESC_MAXLENGTH = 24;

	private static final String NOTALLOW_CHAR_PAYER_NAME = "$ : _ + % * ? [ ] > ; = < } \\^ { | @ # ! ~ ` - \"";

	@Autowired
	private TransactService transactService;
	
	@Autowired
	private NPPService nppService;

	@Autowired
	private PayeeHelper payeeHelper;

	@Autowired
	private SecureCodeHelper secureCodeHelper;

	@Autowired
	private PayeeService payeeService;
	
	@Autowired
	private PayeeLimitService payeeLimitService;
	
	@Autowired
	private MobileBankService mobileBankService;
	
	@Autowired
	private MBAppValidator mbAppValidator;
	
	@Autowired
	private MBAppHelper mbAppHelper;
	
    @Autowired
    private DigitalSecLogger digitalSecLogger;

    @Autowired
   	private LogonHelper logonHelper;

    @Autowired
	private ServiceStation serviceStationService;
    
    @Autowired
	IBankRefershParams ibankRefreshParams;
    
    @Autowired
	private NPPCommonService nppCommonService;
    
    private SafiPayTranVO safiPaymentTransferVO;

    private static final String DE = "DE";
    private static final String OSKO = "osko";
    private static final String ONUS = "OnUs";
    private static final String REASON_2FA_SAFI = "SAFI";
	private static final String REASON_2FA_EHUB = "EHUB";
	private static final int NO_ERROR = 1;
	
    @RequestMapping(method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE, value = "validate")
	@ResponseBody
	public IMBResp  validate(HttpServletRequest httpRequest, @RequestBody final NPPValidationsReq request){
    	final String methodName = "PayeeController.validate():";
    	
    	Logger.debug("PayeeController - validate(). Request: " + request, this.getClass());
		String logName = startPerformanceLog(httpRequest);
		MobileSession mobileSession = new MobileSessionImpl();		
		
		NPPValidationsResp nppValidationsResp = null;	
		
		try {
			mobileSession.getSessionContext(httpRequest);	
			Customer customer = mobileSession.getCustomer();
			IBankCommonData commonData = new MBAppHelper().populateIBankCommonData(mobileSession, httpRequest);
			payeeHelper.populatePayees(commonData, customer);
			
			validateRequestHeader(request.getHeader(), httpRequest);
			
			//validate scheduled payment details
			if (request.getScheduleDetail() != null) { 
				payeeHelper.validateTransferSchedule(request.getScheduleDetail());	
			}
						
			NPPValidations nppValidationsVO = populateNPPValidationsVO(request, customer, commonData);
			
			// validate OnUs Transfer if switch is on.
			//String onUsSwitch = IBankParams.getCodesData(commonData.getOrigin(), IBankParams.CONFIGURATION_PROPERTIES,
					//IBankParams.ON_US_TRANSFER_NEW_SWTICH).getMessage();
			//
		/*	boolean isOnUsTransfer = false;
			
			if (onUsSwitch.equals("ON")) {
				isOnUsTransfer = nppService.isOnUsTransfer(nppValidationsVO);
			}
			*/
			
			NPPParams nppParams = ibankRefreshParams.getNPPParams(commonData.getOrigin(), mobileSession.getCustomer().getGcis());
			
			boolean isNppOutwardSwitch = nppParams.isNppOutwardSwitchON();
			
			boolean isOsko = false;
			String truncatedDescription = request.getDesc();
			String truncatedPayerName = request.getPayerName();	
            //call NPP validations if NPP switch is ON and not an OnUs transfer
			if(isNppOutwardSwitch) {
				try{
					//check NPP validity
					isOsko = nppService.validateForNPP(nppValidationsVO,commonData.getOrigin());	
					Logger.debug("On Continue btn Click - This is an OSKO transaction - "+isOsko+" Amt transfered is "+request.getAmt() 
					+ " Gcis NO: "+customer.getGcis(),getClass());
				}catch(BusinessException e) {
	                if(e.getKey() == BusinessException.NPP_ONUS_SERVICE_RETURNED_400 ) {
	                	isOsko = false;
	                }else {
	                	throw e;// this is to keep it consistent with earlier implementation as in MB, business exception was not getting caught but in IB it is
	                }
				}
			} else {
				Logger.debug("On Continue btn Click - NPP Switch is OFF  - This transaction will be processed using existing DE payment. Amt transfered is "+request.getAmt(),getClass());
			}
			//21E1 NPP Enrichment API call to get FLAN and other identifiers
			if(ibankRefreshParams.isNPPEnrichmentAPISwitchOn() && isOsko) {
				try{
					NPPEnrichmentDetails nppEnrichmentDetailsVO = payeeHelper.populateNPPEnrichmentDetailsVO(nppValidationsVO);
					nppEnrichmentDetailsVO = nppService.callPaymentEnrichmentAPI(nppEnrichmentDetailsVO, commonData);
					if(StringUtils.isEmpty(nppEnrichmentDetailsVO.getFlan())) {
						Logger.info("FLAN not received from WDP enrichment API. Payment not eligible for Osko", this.getClass());
						isOsko = false;
						mobileSession.removeNPPEnrichmentDetails();
					} else {
						//Set FLAN and otherdetails in session to be used in SVC501
						isOsko = true;
						mobileSession.setNPPEnrichmentDetails(nppEnrichmentDetailsVO);
					}
				}catch(BusinessException e) {
					Logger.error("Business Exception in calling Enrichment API. Payment not eligible for Osko", e, this.getClass());
					isOsko = false;
					mobileSession.removeNPPEnrichmentDetails();
				}
			}else {
				Logger.debug("isNPPEnrichmentAPISwitchOn is false or isOsko is false. Not calling enrichment API", this.getClass());
			}
			String accountNumOskoDisp = null;
			if(!isOsko) {
				//truncate description and payerName if its DE
				if(truncatedDescription!=null && truncatedDescription.length()>24) {
					truncatedDescription = truncatedDescription.substring(0, 24); 						
				}
				if(truncatedPayerName!=null && truncatedPayerName.length()>24) {
					truncatedPayerName = truncatedPayerName.substring(0, 24);
				}
			}else{
				ThirdParty thirdParty = customer.getThirdParties().get(request.getToPayeeIndex());
				if(thirdParty.getAccountNumOsko() == null)
				{
					thirdParty.setAccountNumOsko(nppService.getOskoAccountNumber(thirdParty));
				}
				accountNumOskoDisp = StringUtil.formatThirdPartyAccountNumber(thirdParty.getAccountNumOsko());
			}
		   if (isOsko) {
				mobileSession.setPaymentType(OSKO);
			} else {
				mobileSession.setPaymentType(DE);
			}
		    mobileSession.setResubmitPayment(Boolean.FALSE);
		    
			// -- 21E2 : Outward Transaction

			String payAmount = request.getAmt();
			String payDescription = request.getDesc();
			String payReference = request.getReference();

			Logger.info(methodName + "Amount: " + payAmount, this.getClass());
			Logger.info(methodName + "Desc: " + payDescription, this.getClass());
			Logger.info(methodName + "Reference: " + payReference, this.getClass());

			boolean isAbusiveOutwardSwitchON = IBankParams.isSwitchOn(IBankParams.ABUSIVE_OUTWARD_SWITCH);
			Logger.info(methodName + "isAbusiveOutwardSwitchON: " + isAbusiveOutwardSwitchON, this.getClass());

			if (isAbusiveOutwardSwitchON) {
				String paymentType = mobileSession.getPaymentType();
				Logger.info(methodName + "Payment Type: " + paymentType, this.getClass());

				if (paymentType != null && (OSKO.equals(paymentType) || DE.equals(paymentType))) {
					List<String> abusiveWordsDictionary = IBankParams.getAbusiveWordsDictionary();
					Logger.info(methodName + "abusiveWordsDictionary: " + abusiveWordsDictionary, this.getClass());

					if (abusiveWordsDictionary != null && !abusiveWordsDictionary.isEmpty()) {
						BusinessException bExc = null;
						int errorKeyId = 0;
						
						List<String> abusiveWordsDictionaryWithDot = IBankParams.getAbusiveWordsDictionaryWithDot();
						Logger.info(methodName + "abusiveWordsDictionaryWithDot: " + abusiveWordsDictionaryWithDot, this.getClass());

						boolean isDescriptionAbusive = IBankParams.isAbusiveWordPresent(payDescription, abusiveWordsDictionary, abusiveWordsDictionaryWithDot);
						boolean isReferenceAbusive = IBankParams.isAbusiveWordPresent(payReference, abusiveWordsDictionary, abusiveWordsDictionaryWithDot);

						if (isDescriptionAbusive)
							errorKeyId = BusinessException.ABUSIVE_WORD_IN_DESC;
						if (isReferenceAbusive)
							errorKeyId = BusinessException.ABUSIVE_WORD_IN_REFERENCE;
						if (isDescriptionAbusive && isReferenceAbusive)
							errorKeyId = BusinessException.ABUSIVE_WORD_IN_DESC_REFERENCE;
						if(isDescriptionAbusive || isReferenceAbusive) {
							NPPUtil.createAbusivewordStatisticsLog(commonData, payDescription, payReference,null,Statistic.ABUSIVE_OUTWARD_TRANSACTION);
							String fromAccNo = "";
							String fromBSB = "";
							String toBSB =nppValidationsVO.getToAccountBsb();
							String toAccNo = nppValidationsVO.getToAccountNumber();
							String transDate = getFormattedDate(null, new Date());
							if(null != nppValidationsVO.getFromAccount()) {
								if(null!= nppValidationsVO.getFromAccount().getAccountId()) {
									fromAccNo =  nppValidationsVO.getFromAccount().getAccountId().getAccountNumber();
									fromBSB =  nppValidationsVO.getFromAccount().getAccountId().getBsb();
								}
							}
							
							DigitalSecLogggerVO digitalSecAbuiveTransVO =new DigitalSecLogggerVO();
							digitalSecAbuiveTransVO.setTranName(DigitalSecLogger.REPORT_ABUSIVE_TRA_OUTWARD);
							digitalSecAbuiveTransVO.setCommonLogData(mbAppHelper.getCommonLogData(commonData));
							digitalSecAbuiveTransVO.setUserAgent(commonData.getUserAgent());
							digitalSecAbuiveTransVO.setValues(NPPUtil.getAbusiveTransDigitalSecurityLog(commonData, payDescription, payReference, 
									fromAccNo, fromBSB, toBSB, toAccNo, request.getAmt(), transDate, "", false));
							digitalSecLogger.log(digitalSecAbuiveTransVO);
						}
						if (errorKeyId != 0) {
							bExc = new BusinessException(errorKeyId);
							return MBAppUtils.createErrorResp(mobileSession.getOrigin(), bExc,
									ServiceConstants.VALIDATE_FOR_NPP_SERVICE, httpRequest);
						}
					}
				}
			}

			// -- 21E2 : Outward Transaction
		    
			//populate the response object
			nppValidationsResp = payeeHelper.populateNPPValidationsResponse(populateResponseHeader(ServiceConstants.VALIDATE_FOR_NPP_SERVICE, mobileSession),isOsko,truncatedDescription,truncatedPayerName);
			nppValidationsResp.setReference((payReference == null) ? "" : payReference);
			nppValidationsResp.setNppParticipantWarning(nppValidationsVO.isNppParticipantWarning());
			nppValidationsResp.setTurnNPPOutwardSwitchOff(!nppParams.isNppOutwardSwitchON());
			Logger.debug("TurnNPPOutwardSwitchOff:"+(!nppParams.isNppOutwardSwitchON()), getClass());
			nppValidationsResp.setTurnDisplayOskoMessageOn(nppParams.isDisplayOskoMessage());
			Logger.debug("TurnDisplayOskoMessageOn:"+nppParams.isDisplayOskoMessage(), getClass());
			
			if(isOsko){
				nppValidationsResp.setAccountNumOskoDisp(accountNumOskoDisp);
			}
		} catch (BusinessException e) {			
			Logger.error("BusinessException in PayeeController - validate() - [key: " + e.getKey() + "], GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), e, ServiceConstants.VALIDATE_FOR_NPP_SERVICE, httpRequest);			
		}		
		finally {
			endPerformanceLog(logName);
		}		
		return nppValidationsResp;		
    }
    
    /**
	 * Transfer to Payee service operation
	 * 
	 * @param httpRequest
	 * @param request
	 * @return
	 */
	@RequestMapping(method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE, value = "transfer")
	@ResponseBody
	public IMBResp transfer(HttpServletRequest httpRequest, HttpServletResponse httpServletResponse,@RequestBody final PayeeTransferReq request) {
		Logger.debug("PayeeController - transfer(). Request: " + request, this.getClass());
		String logName = startPerformanceLog(httpRequest);
		MobileSession mobileSession = new MobileSessionImpl(); 
		IBankCommonData commonData = null;
		ThirdPartyPayment payment = null;
		try {
			mobileSession.getSessionContext(httpRequest);
			mobileSession.removePayIDResolution();// remove PayIDResolution
			Customer customer = mobileSession.getCustomer();
			commonData = new MBAppHelper().populateIBankCommonData(mobileSession, httpRequest);
			validateRequestHeader(request.getHeader(), httpRequest);
			ErrorResp errorResponse = validate(request, httpRequest);// validate json
			if (errorResponse.hasErrors())
				return errorResponse;
			
			// Validation for account index to account number
			boolean isAcctToIndexValidationSwitchOn=IBankParams.isSwitchOn(IBankParams.ACCT_TO_INDEX_VALIDATION_SWITCH);
			if(isAcctToIndexValidationSwitchOn) {
				String fromAccountNumber=request.getFromAccountNumber();
				String fromAccountNumberMasked=request.getFromAccountNumberMasked();
				
				String toAccountNumber=request.getToAccountNumber();

				Logger.debug("PayeeController - transfer(). fromAccountNumber: " + fromAccountNumber, this.getClass());
				Logger.debug("PayeeController - transfer(). fromAccountNumberMasked: " + fromAccountNumberMasked, this.getClass());
				Logger.debug("PayeeController - transfer(). toAccountNumber: " + toAccountNumber, this.getClass());

				
				boolean isValidAcctToIndex=mbAppHelper.isValidIndextoAcct(fromAccountNumber, fromAccountNumberMasked, request.getFromAccountIndex(), toAccountNumber, null, request.getToPayeeIndex(), "PayeeTransfer", commonData);
				
				if(!isValidAcctToIndex) {
					//throw new business exception
					Logger.error("PayeeController - transfer(). Index-Account MisMatch", this.getClass());
					throw new BusinessException(BusinessException.ACCOUNT_TO_INDEX_MISMATCH, "Account-Index mismatch");
				}
			}		
			//Validate PayeeEmail. Payee Email can't be same as Payer's Email
			if(customer != null && customer.getContactDetail() != null && !StringUtils.isEmpty(customer.getContactDetail().getEmail()) && !StringUtils.isEmpty(request.getPayeeEmail())) {
				if(customer.getContactDetail().getEmail().toLowerCase().equals(request.getPayeeEmail().toLowerCase())) {
					throw new BusinessException(BusinessException.SHARE_RECEIPT_PAYEE_EMAIL_ADDRESS_CANNOT_BE_YOUR_OWN);
				}
			}

			
			if (request.getScheduleDetail() != null) payeeHelper.validateTransferSchedule(request.getScheduleDetail());
			
			Account fromAccount = customer.getAccounts().get(request.getFromAccountIndex());
           
			String paymentType = mobileSession.getPaymentType();
			
			if (null == mobileSession.getPaymentType()) {
				paymentType = "";
			}
			
			if(/*isNppOutwardSwitch &&*/ paymentType.equalsIgnoreCase(OSKO)) {
				Logger.debug("On Confirm btn Click - NPP Switch is ON, PaymentType is OSKO - Payment will be processed via 501",getClass());	
				payment = payeeHelper.populateNPPPayment(fromAccount, customer, commonData, request, mobileSession);
				//19E1: Safi
				populateSafiPayTranVO(httpRequest, request, mobileSession,	commonData, payment);
				//19E1: Safi 
				
			} else {
				Logger.debug("On Confirm btn Click - NPP Switch is OFF or PaymentType is not OSKO - Payment will be processed via existing DE.",getClass());	
				payment = payeeHelper.populatePayment(fromAccount, customer, commonData, request, mobileSession);		
			
				//18E4: Safi
				populateSafiPayTranVO(httpRequest, request, mobileSession,	commonData, payment);
				//18E4: Safi 
			}
			
			Boolean sendMail = payeeHelper.isValidSendMailFlag(request.getSendEmail());
			
			mobileSession.setSendPaymentEmail(sendMail);
            IMBResp resp = performTransfer(mobileSession, fromAccount, payment, ServiceConstants.PAYEE_TRANSFER_SERVICE, commonData, httpRequest,false);
            mobileSession.setTransaction(payment);
			return  resp;
			
		} catch (BusinessException e) {
			if (e.getKey() == BusinessException.ACCOUNT_TO_INDEX_MISMATCH){
				return MBAppUtils.createErrorResp("ALL", e.getKey(), ServiceConstants.PAYEE_TRANSFER_SERVICE, httpRequest);
			} else {
				Logger.info("BusinessException in PayeeController - transfer() - [key: " + e.getKey() + "], GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());
				return MBAppUtils.createErrorResp(mobileSession.getOrigin(), e, ServiceConstants.PAYEE_TRANSFER_SERVICE, httpRequest);
			}		
		} catch (ResourceException e) {
			Logger.error("ResourceException in PayeeController - transfer() - [key: " + e.getKey() + "], GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());
			mobileSession.removeNPPEnrichmentDetails();
			mobileSession.removeTransaction();
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.SYSTEM_UNAVILABLE, ServiceConstants.PAYEE_TRANSFER_SERVICE, httpRequest);
		} catch (Exception e) {
			Logger.error("Exception PayeeController - transfer(): GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			mobileSession.removeNPPEnrichmentDetails();
			mobileSession.removeTransaction();
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.GENERIC_ERROR, ServiceConstants.PAYEE_TRANSFER_SERVICE, httpRequest);
		} finally {
			//18E4 : SAFI changes for third party transfers
			handleSafiResponse(payment,httpRequest,httpServletResponse);
			//18E4 : SAFI changes for third party transfers ENDS
			endPerformanceLog(logName);
		}
	}

	private void populateSafiPayTranVO(HttpServletRequest httpRequest,
			final PayeeTransferReq request, MobileSession mobileSession,
			IBankCommonData commonData, ThirdPartyPayment payment) throws BusinessException {
		String validDecodedPrint;
		String devicePrint;
		if(ThirdPartyTransferHelper.isSafiCallAllowed(payment, mobileSession.getPaymentType()) &&
				payment != null && ThirdPartyTransferHelper.isSafiApplicableForAnalyze(payment)) {
			Logger.debug("SAFI : PayeeController.transfer(): Device Print Received in Payee Transfer Request: " +request.getDevicePrint(), this.getClass()) ;
			validDecodedPrint = SafiUtil.validateDevicePrint(request.getDevicePrint());
			devicePrint = validDecodedPrint != null ? request.getDevicePrint():null;
			
			if(null == devicePrint && null != mobileSession.getSafiLogonInfo() && null != mobileSession.getSafiLogonInfo().getDevicePrint()) {
				devicePrint = mobileSession.getSafiLogonInfo().getDevicePrint();
				Logger.debug("SAFI : PayeeController.transfer(): Device Print from request was null so getting from mobileSession.getSafiLogonInfo():" +devicePrint, this.getClass()) ;
			}
			
			boolean isMobileApp = ((logonHelper.loadCordova(httpRequest)) == -1) ? false:true;
			Logger.debug("SAFI : PayeeController.transfer(): validDecodedPrint: " +validDecodedPrint + " devicePrint: "+devicePrint+" isMobileApp: "+isMobileApp, this.getClass()) ;
			
			safiPaymentTransferVO = SafiWebHelper.populateSafiPayTranVOForThirdPartyPayment(httpRequest, payment, commonData,devicePrint,mobileSession,isMobileApp);
			payment.setSafiPayTranVO(safiPaymentTransferVO);
			payment.setSafiCall(SafiConstants.SAFI_CALL_ANALYZE);
			payment.setOnUsTransferCheckDone(true);
			if(safiPaymentTransferVO.getExecutionSpeed().equalsIgnoreCase(SafiConstants.REAL_TIME_EXECUTION_SPEED)) { 
				Logger.debug("SAFI : PayeeController.transfer():OnUsTransfer TRUE " , this.getClass()) ;
				payment.setOnUsTransfer(true);
			}
		}
	}
	
	private void populatePayIdSafiPayTranVO(HttpServletRequest httpRequest,
			final PayeeTransferReq request, MobileSession mobileSession,
			IBankCommonData commonData, ThirdPartyPayment payment) throws BusinessException {
		String validDecodedPrint;
		String devicePrint;
		if(PayeeHelper.isSafiCallAllowed(payment, mobileSession.getPaymentType()) &&
				payment != null && ThirdPartyTransferHelper.isSafiApplicableForAnalyze(payment)) {
			Logger.debug("SAFI : PayeeController.transfer(): Device Print Received in PayID Transfer Request: " +request.getDevicePrint(), this.getClass()) ;
			validDecodedPrint = SafiUtil.validateDevicePrint(request.getDevicePrint());
			devicePrint = validDecodedPrint != null ? request.getDevicePrint():null;
			
			if(null == devicePrint && null != mobileSession.getSafiLogonInfo() && null != mobileSession.getSafiLogonInfo().getDevicePrint()) {
				devicePrint = mobileSession.getSafiLogonInfo().getDevicePrint();
				Logger.debug("SAFI : PayeeController.transfer(): Device Print from request was null so getting from mobileSession.getSafiLogonInfo():" +devicePrint, this.getClass()) ;
			}
			
			boolean isMobileApp = ((logonHelper.loadCordova(httpRequest)) == -1) ? false:true;
			Logger.debug("SAFI : PayeeController.transfer(): validDecodedPrint: " +validDecodedPrint + " devicePrint: "+devicePrint+" isMobileApp: "+isMobileApp, this.getClass()) ;
			
			safiPaymentTransferVO = SafiWebHelper.populateSafiPayTranVOForPayIdPayment(httpRequest, payment, commonData,devicePrint,mobileSession,isMobileApp);
			payment.setSafiPayTranVO(safiPaymentTransferVO);
			payment.setSafiCall(SafiConstants.SAFI_CALL_ANALYZE);
			payment.setOnUsTransferCheckDone(true);
			if(safiPaymentTransferVO.getExecutionSpeed().equalsIgnoreCase(SafiConstants.REAL_TIME_EXECUTION_SPEED)) { 
				Logger.debug("SAFI : PayeeController.transfer():OnUsTransfer TRUE " , this.getClass()) ;
				payment.setOnUsTransfer(true);
			}
		}
	}
	
	private SafiPayTranVO populateSafiVOForPayIdResolution(HttpServletRequest httpRequest,
			final ResolvePayIdReq request, MobileSession mobileSession, IBankCommonData commonData, String payIdType,
			String payIdValue, long payIdResolutionCounter, int payeePayIDindex) throws BusinessException {

		SafiPayTranVO safiPayTranVO = null;

		if (NPPUtil.isSafiPayIdResolutionCallAllowed(commonData.getOrigin(), commonData.getCustomer().getGcis(),
				commonData.getSessionId())) {
			String validDecodedPrint = null;
			String devicePrint = null;

			Logger.debug(
					"SAFI : PayeeController.populateSafiVOForPayIdResolution(): Device Print Received in ResolvePayId Request: "
							+ request.getDevicePrint(),
					this.getClass());
			validDecodedPrint = SafiUtil.validateDevicePrint(request.getDevicePrint());
			devicePrint = validDecodedPrint != null ? request.getDevicePrint() : null;

			if (null == devicePrint && null != mobileSession.getSafiLogonInfo()
					&& null != mobileSession.getSafiLogonInfo().getDevicePrint()) {
				devicePrint = mobileSession.getSafiLogonInfo().getDevicePrint();
				validDecodedPrint = SafiUtil.validateDevicePrint(devicePrint);
				Logger.debug(
						"SAFI : PayeeController.populateSafiVOForPayIdResolution: Device Print getting from mobileSession.getSafiLogonInfo():"
								+ devicePrint,
						this.getClass());
			}

			boolean isMobileApp = ((logonHelper.loadCordova(httpRequest)) == -1) ? false : true;
			Logger.debug("SAFI : PayeeController.transfer(): validDecodedPrint: " + validDecodedPrint + " devicePrint: "
					+ devicePrint + " isMobileApp: " + isMobileApp, this.getClass());

			safiPayTranVO = SafiWebHelper.populateSafiPayIdResolutionVO(httpRequest, commonData, devicePrint,
					mobileSession, isMobileApp, payIdType, payIdValue, payeePayIDindex);
			safiPayTranVO.setPayIdResolutionCounter(payIdResolutionCounter);
		}
		return safiPayTranVO;
	}

	/**
	 * Request security code service operation
	 * 
	 * @param request
	 * @return
	 */
	@RequestMapping(method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE, value = "reqsecurecode")
	@ResponseBody
	public IMBResp reqSecureCode(HttpServletRequest httpRequest, HttpServletResponse httpResponse, @RequestBody final SecureCodeReq request) {
		Logger.debug("PayeeController - reqSecureCode(). Request: " + request, this.getClass());
		String logName = startPerformanceLog(httpRequest);
		MobileSession mobileSession = new MobileSessionImpl();

		try {
			mobileSession.getSessionContext(httpRequest);
			mobileSession.removeDigitalSecLoggerMap();
			IBankCommonData commonData = new MBAppHelper().populateIBankCommonData(mobileSession, httpRequest);
			ThirdPartyPayment payment = (ThirdPartyPayment) mobileSession.getTransaction();
			
			validateRequestHeader(request.getHeader(), httpRequest);
			ErrorResp errorResponse = validate(request, httpRequest);// validate json
			if (errorResponse.hasErrors())
				return errorResponse;
			
			if (ServiceConstants.PAYEE_TRANSFER_2FA_TRAN_CODE != request.getTranType() 
					&& ServiceConstants.ADD_PAYEE_2FA_TRAN_CODE != request.getTranType()
					&& ServiceConstants.INC_PAYEE_LIMIT_2FA_TRAN_CODE != request.getTranType()
					&& ServiceConstants.PAY_TO_PAYID_TRAN_CODE != request.getTranType()
					&& ServiceConstants.OSKO_TRANSFER_2FA_TRAN_CODE != request.getTranType()){
				return MBAppUtils.createInvalid2FATransactionTypeResponse(ServiceConstants.PAYEE_SECURE_CODE_SERVICE);
			}
			
			LabelValueMap digitalSecLoggerMap = new LabelValueMap(2);
			digitalSecLoggerMap.put(DigitalSecLogger.AUTHTYPE, request.getDeliveryMethod());
			PhoneNumber phoneNumber = CommonBusinessUtil.get2FAPhoneNumber(commonData, request.getPhone());
			digitalSecLoggerMap.put(DigitalSecLogger.AUTHPHONE, phoneNumber.getAreaCode()+phoneNumber.getPhoneNumber());
			mobileSession.setDigitalSecLoggerMap(digitalSecLoggerMap);
			IMBResp mbResponse = secureCodeHelper.reqSecureCode(commonData, mobileSession, mobileSession.getTransaction(), mobileSession.getPayee(), request, ServiceConstants.PAYEE_SECURE_CODE_SERVICE, httpRequest);
			
			if (mbResponse instanceof ErrorResp){
				ErrorResp errResponse = (ErrorResp)mbResponse;
				Logger.debug("PayeeController - transferSecure(): error status while requesting secure code : "+errResponse.getStatus(), this.getClass());
				
				//18E4: Safi Notify if customer account is suspended after unsuccessful 2FA attempts
				//This method is called while adding a new payee so no need to call SAFI notify by checking payment object value which will be null for add payee action
				if(errResponse.hasErrors() && errResponse.getStatus() ==  ErrorResp.STATUS_2FA_SUSPENDED && payment != null 
						&& null != payment.getSafiRespVO() && SafiConstants.SAFI_ACTION_CHALLENGE.equals(payment.getSafiRespVO().getSafiAction())) {
					notifyCallForSafi(httpRequest, httpResponse, mobileSession,	commonData, payment, digitalSecLoggerMap,false,false);
					String caller = DigitalSecLogger.TRANSFER_TO_PAYEE;
					if(request.getTranType()!=null && request.getTranType() == ServiceConstants.PAY_TO_PAYID_TRAN_CODE){
						caller = DigitalSecLogger.TRANSFER_TO_PAYID; 
					}
					saveDigitalSecureLog(httpRequest, mobileSession, commonData, payment, false /*is2FADone*/, false /*paymentSuccess*/, caller);
				}
				//18E4: Safi Notify
				
				return errResponse;
			}
			
			return mbResponse;
		} catch (ResourceException e) {
			Logger.error("ResourceException in PayeeController - reqSecureCode() - [key: " + e.getKey() + "], GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());
			mobileSession.removeSecureCodeDetails();
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.SYSTEM_UNAVILABLE, ServiceConstants.PAYEE_SECURE_CODE_SERVICE, httpRequest);
		} catch (Exception e) {
			Logger.error("Exception PayeeController - reqSecureCode(): GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "]", e, this.getClass());
			mobileSession.removeSecureCodeDetails();
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.GENERIC_ERROR, ServiceConstants.PAYEE_SECURE_CODE_SERVICE, httpRequest);
		} finally {
			endPerformanceLog(logName);
		}

	}
	
	/**
	 * Request security code service operation
	 * 
	 * @param request
	 * @return
	 */
	@RequestMapping(method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE, value = "reqsecurecoderesolvepayid")
	@ResponseBody
	public IMBResp reqSecureCodeResolvePayId(HttpServletRequest httpRequest, HttpServletResponse httpResponse, @RequestBody final SecureCodeReq request) {
		Logger.debug("PayeeController - reqSecureCodeResolvePayId(). Request: " + request, this.getClass());
		String logName = startPerformanceLog(httpRequest);
		MobileSession mobileSession = new MobileSessionImpl();

		try {
			mobileSession.getSessionContext(httpRequest);
			mobileSession.removeDigitalSecLoggerMap();
			IBankCommonData commonData = new MBAppHelper().populateIBankCommonData(mobileSession, httpRequest);
			
			
			
			
			//	TODO : remove below code after SMS/IVR is implemented for PayIdVerification
			/*NPPPayment payment = new NPPPayment();
			PayIdThirdParty payIdTp = new PayIdThirdParty();
			payIdTp.setPayID(mobileSession.getSafiPayTranVOForPayIdResolution().getSafiPayIdDetails().getPayIdUserValue());
			payIdTp.setPayIDType(mobileSession.getSafiPayTranVOForPayIdResolution().getSafiPayIdDetails().getPayIdTypeUserValue());
			payment.setToThirdParty(payIdTp);
			
			PayIDResolution payIdResolution = new PayIDResolution();
			payIdResolution.setPayIDTypeOrig(mobileSession.getSafiPayTranVOForPayIdResolution().getSafiPayIdDetails().getPayIdTypeUserValue());
			payment.setPayIDResultion(payIdResolution);
			
			payment.setAmount(new BigDecimal(10));
			request.setTranType(ServiceConstants.PAY_TO_PAYID_TRAN_CODE);*/
			//	TODO : remove above code after SMS/IVR is implemented for PayIdVerification
			
			
			
			
			validateRequestHeader(request.getHeader(), httpRequest);
			ErrorResp errorResponse = validate(request, httpRequest);// validate json
			if (errorResponse.hasErrors())
				return errorResponse;
			
			//	TODO : uncomment to send correct tran type for pay id resolution
			/*if (ServiceConstants.PAYIDRESOLUTION_TRAN_CODE != request.getTranType()) {
				return MBAppUtils.createInvalid2FATransactionTypeResponse(ServiceConstants.PAYEE_SECURE_CODE_SERVICE);
			}*/
			
			LabelValueMap digitalSecLoggerMap = new LabelValueMap(2);
			digitalSecLoggerMap.put(DigitalSecLogger.AUTHTYPE, request.getDeliveryMethod());
			PhoneNumber phoneNumber = CommonBusinessUtil.get2FAPhoneNumber(commonData, request.getPhone());
			digitalSecLoggerMap.put(DigitalSecLogger.AUTHPHONE, phoneNumber.getAreaCode()+phoneNumber.getPhoneNumber());
			mobileSession.setDigitalSecLoggerMap(digitalSecLoggerMap);
			IMBResp mbResponse = secureCodeHelper.reqSecureCode(commonData, mobileSession, null, mobileSession.getSafiPayTranVOForPayIdResolution().getSafiPayIdDetails(), request, ServiceConstants.PAYID_RESOLUTION_SECURE_SERVICE, httpRequest);
			
			if (mbResponse instanceof ErrorResp){
				ErrorResp errResponse = (ErrorResp)mbResponse;
				Logger.debug("PayeeController - reqSecureCodeResolvePayId(): error status while requesting secure code : "+errResponse.getStatus(), this.getClass());
				
				if(errResponse.hasErrors() && errResponse.getStatus() ==  ErrorResp.STATUS_2FA_SUSPENDED && mobileSession.getSafiPayTranVOForPayIdResolution() != null 
						&& null != mobileSession.getSafiPayTranVOForPayIdResolution().getSafiRespVO() && SafiConstants.SAFI_ACTION_CHALLENGE.equals(mobileSession.getSafiPayTranVOForPayIdResolution().getSafiRespVO().getSafiAction())) {
					notifyCallForSafiPayIdResolution(httpRequest, httpResponse, mobileSession, commonData, digitalSecLoggerMap, false);
					//log forensic for pay id resolution
					DigitalSecLogggerVO digitalSecurityLogVO = payeeHelper.initializeDigitalLogger(commonData,
							DigitalSecLogger.PAYID_LOOKUP, DigitalSecLogger.FAILURE, mbAppHelper.getCommonLogData(commonData));
					addPayIdResolutionFailureDigitialLogger(mobileSession.getSafiPayTranVOForPayIdResolution().getSafiPayIdDetails()
							.getPayIdUserValue(), mobileSession.getSafiPayTranVOForPayIdResolution().getSafiPayIdDetails().getPayIdTypeUserValue(),
							mobileSession.getCustomer(), digitalSecurityLogVO, digitalSecLoggerMap,
							BusinessException.PAY_TO_PAYID_RESOLUTION_ERROR);
					//TODO : saveDigitalSecureLog(httpRequest, mobileSession, commonData, payment, false /*is2FADone*/, false /*paymentSuccess*/, DigitalSecLogger.TRANSFER_TO_PAYID);
				}
				
				return errResponse;
			}
			
			return mbResponse;
		} catch (ResourceException e) {
			Logger.error("ResourceException in PayeeController - reqSecureCodeResolvePayId() - [key: " + e.getKey() + "], GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());
			mobileSession.removeSecureCodeDetails();
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.SYSTEM_UNAVILABLE, ServiceConstants.PAYEE_SECURE_CODE_SERVICE, httpRequest);
		} catch (Exception e) {
			Logger.error("Exception PayeeController - reqSecureCodeResolvePayId(): GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "]", e, this.getClass());
			mobileSession.removeSecureCodeDetails();
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.GENERIC_ERROR, ServiceConstants.PAYEE_SECURE_CODE_SERVICE, httpRequest);
		} finally {
			endPerformanceLog(logName);
		}
	}
	
	/**
	 * Make secure transfer service operation
	 * 
	 * @param request
	 * @return
	 */
	@RequestMapping(method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE, value = "resolvepayidsecure")
	@ResponseBody
	public IMBResp resolvePayIdSecure(HttpServletRequest httpRequest, HttpServletResponse httpResponse, @RequestBody final SecureCodeReq request) {
		Logger.debug("PayeeController - resolvePayIdSecure(). Request: " + request, this.getClass());
		String logName = startPerformanceLog(httpRequest);
		MobileSession mobileSession = new MobileSessionImpl();
		ObjectMapper mapper = new ObjectMapper();
		SafiPayIdDetails safiPayIdDetails = null;
		IMBResp resolvePayIdResp = null;
		DigitalSecLogggerVO digitalSecurityLogVO = null;
		LabelValueMap digitalSecMap  = null;

		try {
			mobileSession.getSessionContext(httpRequest);
			IBankCommonData commonData = new MBAppHelper().populateIBankCommonData(mobileSession, httpRequest);
			validateRequestHeader(request.getHeader(), httpRequest);
			ErrorResp errorResponse = validate(request, httpRequest);// validate json

			if (ServiceConstants.PAYIDRESOLUTION_TRAN_CODE != request.getTranType()) {   
				return MBAppUtils.createInvalid2FATransactionTypeResponse(ServiceConstants.PAYEE_SECURE_CODE_SERVICE);
			}
			
			digitalSecurityLogVO = payeeHelper.initializeDigitalLogger(commonData, DigitalSecLogger.PAYID_LOOKUP, DigitalSecLogger.SUCCESS, mbAppHelper.getCommonLogData(commonData));
			digitalSecMap = mobileSession.getDigitalSecLoggerMap();
			errorResponse = secureCodeHelper.verifySecureCode(commonData, mobileSession, mobileSession.getSafiPayTranVOForPayIdResolution().getSafiPayIdDetails(), request, ServiceConstants.PAYID_RESOLUTION_SECURE_SERVICE, httpRequest);
			safiPayIdDetails = mobileSession.getSafiPayTranVOForPayIdResolution().getSafiPayIdDetails();
			
			if (errorResponse.hasErrors()) {
				Logger.debug("Error in resolvePayIdSecure() after verifySecureCode", this.getClass());
				
				if ((errorResponse.getStatus() == ErrorResp.STATUS_2FA_SUSPENDED)) {
					// add forensic log for resolution paid not resolved
					addPayIdResolutionFailureDigitialLogger(safiPayIdDetails.getPayIdUserValue(), safiPayIdDetails.getPayIdTypeUserValue(),
							mobileSession.getCustomer(), digitalSecurityLogVO, digitalSecMap,
							BusinessException.PAY_TO_PAYID_RESOLUTION_ERROR);
					notifyCallForSafiPayIdResolution(httpRequest, httpResponse, mobileSession, commonData, digitalSecMap, false);
				}
				
				return errorResponse;
			}
			

			PayIdPaymentSwitchParams payIdPaymentSwitchParams = mobileSession.getPayIdPaymentSwitchParams();
			if(payIdPaymentSwitchParams != null && payIdPaymentSwitchParams.isAllowPayToPayIdPayment()) {
				notifyCallForSafiPayIdResolution(httpRequest, httpResponse, mobileSession, commonData, digitalSecMap, true);
				
				safiPayIdDetails = mobileSession.getSafiPayTranVOForPayIdResolution().getSafiPayIdDetails();
				
				if(safiPayIdDetails != null && safiPayIdDetails.getPayIdUserValue() != null && safiPayIdDetails.getPayIdTypeUserValue() != null) {
					String payID = safiPayIdDetails.getPayIdUserValue();
					String payIDType = safiPayIdDetails.getPayIdTypeUserValue();
		
					if(!StringMethods.isEmptyString(payID) && !StringMethods.isEmptyString(payIDType) && (payIDType.equalsIgnoreCase(NPPUtil.PAYID_TYPE_EMAIL) || payIDType.equalsIgnoreCase(NPPUtil.PAYID_TYPE_ORGID))) {
						payID = payID.trim().toLowerCase();
					}
		
					PayIDResolution payIDResolution = null;
					if(IBankParams.isPayIdResolutionServiceSwitchOn(commonData.getOrigin())) {
						 payIDResolution = nppService.resolvePayIdWDPService(commonData, payID, NPPUtil.getESBPayIdType(payIDType));
					}else {
						 payIDResolution = nppService.resolvePayId(commonData, payID, NPPUtil.getESBPayIdType(payIDType));
					}
					payIDResolution.setPayIDTypeOrig(payIDType);
					payIDResolution.setIs2FAdone(true);
					payIDResolution.setNewPayIDPayee(mobileSession.getSafiPayTranVOForPayIdResolution().isNewPayee());
					boolean isNameChanged = false;
					if(!payIDResolution.isNewPayIDPayee() && IBankParams.isNPPPayIdAddressBookSwitchON(commonData.getOrigin())) {
						NPPPayIdPayee selectedPayidPayee = payeeHelper.getPayIDPayee(payIDType, payID, mobileSession.getCustomer());
						if(!selectedPayidPayee.getPayIdName().equals(payIDResolution.getShortName())) {
							isNameChanged = true;
							payIDResolution.setNameChanged(true);
						}
					}
					
					// if PAYID is resolved then set it in session
					if(payIDResolution != null && payIDResolution.isPayIDResolutionStatus()){
						//add forensic log for resolution success
						addPayIdResolutionSuccessDigitialLogger(payIDResolution,payIDType, mobileSession.getCustomer(), digitalSecurityLogVO, digitalSecMap, isNameChanged);
						mobileSession.setPayIDResolution(payIDResolution);
					} else {
						throw new BusinessException(BusinessException.PAYID_NOT_RESOLVED, new String[]{payID});
					}
					
					//Populate response to send information to UI.
					resolvePayIdResp = payeeHelper.populateResolvePayIdResp(populateResponseHeader(ServiceConstants.PAYEE_TRANSFER_SERVICE, mobileSession),payIDResolution, payIDType,isNameChanged);
					((ResolvePayIdResp)resolvePayIdResp).setPayIdType(payIDType);
		
					Logger.info("PayeeController.resolvePayIdSecure(): JSON Response :" + mapper.writeValueAsString(resolvePayIdResp), this.getClass());
					
					mobileSession.removeSafiPayTranVOForPayIdResolution();
				} else {
					Logger.error("PayeeController - resolvePayIdSecure() Pay id type and value not found from mobileSession...", getClass());
					mobileSession.removeNPPEnrichmentDetails();
					mobileSession.removeTransaction();
					return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.GENERIC_ERROR, ServiceConstants.PAYEE_TRANSFER_SERVICE, httpRequest);
				}
				
			} else {
				throw new BusinessException(BusinessException.SYSTEM_UNAVILABLE);
			}

		} catch (BusinessException e) {
			Logger.info("BusinessException in PayeeController - resolvePayIdSecure() - [key: " + e.getKey() + "], GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());
			
			if (e.getKey() == BusinessException.PAYID_NOT_RESOLVED) {
				if (safiPayIdDetails != null) {
					// add forensic log for resolution paid not resolved
					addPayIdResolutionFailureDigitialLogger(safiPayIdDetails.getPayIdUserValue(), safiPayIdDetails.getPayIdTypeUserValue(),
							mobileSession.getCustomer(), digitalSecurityLogVO, digitalSecMap, BusinessException.PAYID_NOT_RESOLVED);
					if (safiPayIdDetails.getPayIdTypeUserValue() != null) {
						String[] values = { safiPayIdDetails.getPayIdUserValue().trim().toLowerCase() };
						ErrorResp errRsp = MBAppUtils.createErrorResp(mobileSession.getOrigin(), e, values,
								ServiceConstants.PAYEE_TRANSFER_SERVICE, httpRequest);
						int indexOf = errRsp.getErrors().get(0).getMessage().lastIndexOf(":");
						String errMsg = errRsp.getErrors().get(0).getMessage().substring(0, indexOf + 1)
								+ "<br>"
								+ errRsp.getErrors().get(0).getMessage()
										.substring(indexOf + 2, errRsp.getErrors().get(0).getMessage().length());
						errRsp.getErrors().get(0).setMessage(errMsg);
						return errRsp;
					}
				}
			} else {
				if (safiPayIdDetails != null && e.getKey() == BusinessException.PAY_TO_PAYID_RESOLUTION_ERROR) {
					// add forensic log for resolution paid not resolved
					addPayIdResolutionFailureDigitialLogger(safiPayIdDetails.getPayIdUserValue(), safiPayIdDetails.getPayIdTypeUserValue(),
							mobileSession.getCustomer(), digitalSecurityLogVO, digitalSecMap,
							BusinessException.PAY_TO_PAYID_RESOLUTION_ERROR);
				}
				return MBAppUtils.createErrorResp(mobileSession.getOrigin(), e.getKey(), ServiceConstants.PAYEE_TRANSFER_SECURE_SERVICE, httpRequest);
			}
		} catch (ResourceException e) {
			Logger.error("Exception PayeeController - resolvePayIdSecure(): GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "]", e, this.getClass());
			mobileSession.removeNPPEnrichmentDetails();
			mobileSession.removeTransaction();
			mobileSession.removeSecureCodeDetails();
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.SYSTEM_UNAVILABLE, ServiceConstants.PAYEE_TRANSFER_SECURE_SERVICE, httpRequest);
		} catch (Exception e) {
			Logger.error("Exception PayeeController - transferSecure(): GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "]", e, this.getClass());
			mobileSession.removeNPPEnrichmentDetails();
			mobileSession.removeTransaction();
			mobileSession.removeSecureCodeDetails();
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.GENERIC_ERROR, ServiceConstants.PAYEE_TRANSFER_SECURE_SERVICE, httpRequest);
		} finally {
			endPerformanceLog(logName);
		}
		
		return resolvePayIdResp;
	}

	private void notifyCallForSafi(HttpServletRequest httpRequest,
			HttpServletResponse httpResponse, MobileSession mobileSession,
			IBankCommonData commonData, ThirdPartyPayment payment,
			LabelValueMap digitalSecLoggerMap,boolean status2FA , boolean isPaymentSuccess)
			throws BusinessException {
		if (payment != null && mobileSession != null) {
			if (payment.getSafiRespVO() != null
					&& SafiConstants.SAFI_ACTION_CHALLENGE.equals(payment
							.getSafiRespVO().getSafiAction()) && ThirdPartyTransferHelper.isSafiApplicableForNotify(payment)) {
				Logger.info("SAFI : PayeeController - transferSecure(): Notify Call:START STATUS_2FA_SUSPENDED while requesting secure code",this.getClass());
				String devicePrint = mobileSession.getSafiLogonInfo() != null ? mobileSession
						.getSafiLogonInfo().getDevicePrint() : "";
				Logger.debug("reqSecureCode() suspended devicePrint from native app : " + devicePrint, this.getClass());
				payment.setSafiCall(SafiConstants.SAFI_CALL_NOTIFY);
				mobileSession.setTransaction(payment);
				notifyCallAndUpdateCookie(httpRequest, mobileSession, payment, httpRequest,
						httpResponse, commonData, digitalSecLoggerMap,
						status2FA /* status2FA */, isPaymentSuccess /* isPaymentSuccess */);
				Logger.info("SAFI : PayeeController - transferSecure(): Notify Call: END",this.getClass());
			}
		}
	}
	
	private void notifyCallForSafiPayIdResolution(HttpServletRequest httpRequest, HttpServletResponse httpResponse, MobileSession mobileSession, IBankCommonData commonData, 
			LabelValueMap digitalSecLoggerMap, boolean status2FA) throws BusinessException {
		
		if (mobileSession != null && mobileSession.getSafiPayTranVOForPayIdResolution() != null && mobileSession.getSafiPayTranVOForPayIdResolution().getSafiRespVO() != null
				&& SafiConstants.SAFI_ACTION_CHALLENGE.equals(mobileSession.getSafiPayTranVOForPayIdResolution().getSafiRespVO().getSafiAction())) {
			
			Logger.info("SAFI : PayeeController - reqSecureCodeResolvePayId(): Notify Call:START STATUS_2FA_SUSPENDED while requesting secure code",this.getClass());
			String devicePrint = mobileSession.getSafiLogonInfo() != null ? mobileSession.getSafiLogonInfo().getDevicePrint() : "";
			Logger.debug("reqSecureCodeResolvePayId() suspended devicePrint from native app : " + devicePrint, this.getClass());
			
			notifyCallAndUpdateCookiePayIdResolution(httpRequest, mobileSession, httpRequest, httpResponse, commonData, digitalSecLoggerMap, status2FA /* status2FA */);
			Logger.info("SAFI : PayeeController - reqSecureCodeResolvePayId(): Notify Call: END",this.getClass());
		}
	}
	
	/**
	 * Make secure transfer service operation
	 * 
	 * @param request
	 * @return
	 */
	@RequestMapping(method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE, value = "transfersecure")
	@ResponseBody
	public IMBResp transferSecure(HttpServletRequest httpRequest, HttpServletResponse httpResponse, @RequestBody final SecureCodeReq request) {
		Logger.debug("PayeeController - transferSecure(). Request: " + request, this.getClass());
		String logName = startPerformanceLog(httpRequest);
		MobileSession mobileSession = new MobileSessionImpl();
		String safiAction = null;

		try {
			mobileSession.getSessionContext(httpRequest);
			IBankCommonData commonData = new MBAppHelper().populateIBankCommonData(mobileSession, httpRequest);
			validateRequestHeader(request.getHeader(), httpRequest);
			ErrorResp errorResponse = validate(request, httpRequest);// validate json
			if (errorResponse.hasErrors())
				return errorResponse;

			if (ServiceConstants.PAYEE_TRANSFER_2FA_TRAN_CODE != request.getTranType() && 
					ServiceConstants.OSKO_TRANSFER_2FA_TRAN_CODE != request.getTranType()){   
				return MBAppUtils.createInvalid2FATransactionTypeResponse(ServiceConstants.PAYEE_SECURE_CODE_SERVICE);
			}
			
			ThirdPartyPayment payment = (ThirdPartyPayment) mobileSession.getTransaction();
			safiAction = payment.getSafiRespVO() != null && payment.getSafiRespVO().getSafiAction() != null ? payment.getSafiRespVO().getSafiAction(): null ;
			
			String reasonCode = "";
			if(payment instanceof NPPPayment) {
				reasonCode = ((NPPPayment)payment).getReasonCode();			
			}
			
			String paymentType = mobileSession.getPaymentType();
			if (null == mobileSession.getPaymentType()) {
				paymentType = "";
			}
			
			boolean isMobileApp = ((logonHelper.loadCordova(httpRequest)) == -1) ? false:true;
			
			LabelValueMap digitalSecMap = mobileSession.getDigitalSecLoggerMap();
			errorResponse = secureCodeHelper.verifySecureCode(commonData, mobileSession, mobileSession.getTransaction(), request, ServiceConstants.PAYEE_TRANSFER_SECURE_SERVICE, httpRequest);
			if (errorResponse.hasErrors()){
				Logger.debug("Error in transferSecure() after verifySecureCode with safiAction : "+safiAction, this.getClass());
				DigitalSecLogggerVO digitalSecLoggerVO = initializeDigitalLoggers(commonData);
				String devicePrint = mobileSession.getSafiLogonInfo()!= null ? mobileSession.getSafiLogonInfo().getDevicePrint() : "";
				if(payment.getScheduleDetails()==null) {
					SafiForensicInfo safiForensicInfo = populateSafiForensicInfoVO(payment.getSafiRespVO(), devicePrint);
					/*if(null != payment && payment instanceof NPPPayment && ((NPPPayment)payment).isDeRetry()) {
						digitalSecLoggerVO.setStatus(DigitalSecLogger.FAILURE);
						digitalSecLoggerVO.setValues(((ThirdPartyPayment)payment).toDigitalSecurityLogNPP(((ThirdPartyPayment)payment).toDigitalSecurityLog(false,digitalSecMap.get(DigitalSecLogger.AUTHTYPE),digitalSecMap.get(DigitalSecLogger.AUTHPHONE), mobileSession.getPayIDResolution()), "Osko", false  TODO : payment.isRetryDEConsent(),reasonCode, safiForensicInfo, isMobileApp, false is2FADone));
						digitalSecLogger.log(digitalSecLoggerVO);
						digitalSecLoggerVO.setStatus(DigitalSecLogger.SUCCESS);
						paymentType = "DE";
					}*/
					digitalSecLoggerVO.setValues(((ThirdPartyPayment)payment).toDigitalSecurityLogNPP(((ThirdPartyPayment)payment).toDigitalSecurityLog(false,digitalSecMap.get(DigitalSecLogger.AUTHTYPE),digitalSecMap.get(DigitalSecLogger.AUTHPHONE), mobileSession.getPayIDResolution(), null), paymentType.equalsIgnoreCase(OSKO) ? "Osko" : "DE", null, reasonCode,safiForensicInfo, isMobileApp, false /*is2FADone*/));
					
				} else if(payment.getScheduleDetails() != null && ((payment.getScheduleDetails().getId()== null || "".equals(payment.getScheduleDetails().getId() ) ))) {
					digitalSecLoggerVO.setValues(((ThirdPartyPayment)payment).toSchLog(false,digitalSecMap.get(DigitalSecLogger.AUTHTYPE),digitalSecMap.get(DigitalSecLogger.AUTHPHONE),mobileSession.getPayIDResolution()));
				}
				digitalSecLogger.log(digitalSecLoggerVO);
				
				//18E4: Safi Notify if SAFI response is challenge or customer account is suspended after unsuccessful 2FA attempts
				if((errorResponse.getStatus() ==  ErrorResp.STATUS_2FA_SUSPENDED )){
					notifyCallForSafi(httpRequest, httpResponse, mobileSession, commonData, payment, digitalSecMap,false, false);
				}
				
				//18E4: Safi Notify
				
				return errorResponse;
			}
			
			// do transfer
			payment.getToThirdParty().setTrusted(IBankSecureService.TRUSTED_NOW_STATUS);
			Logger.debug("transferSecure : changed to Trusted Now " + payment.getToThirdParty().getTrusted(), this.getClass());
			payment.setOtp(mobileSession.getSecureCodeDetails().getOtp());

			Account fromAccount = MBAppHelper.getAccountbyAccountId(payment.getFromAccount(), mobileSession.getCustomer().getAccounts());
			
			//	Before making transfer, remove value from safi call so that analyze call is not made again in ThirdPartyTransferTransaction
			//	If reason of 2FA is SAFI challenge response then call notify method
			//	If reason of 2FA is thrown EHUB then do not call notify method
			if(payment != null && null != payment.getReasonFor2FA() && REASON_2FA_SAFI.equalsIgnoreCase(payment.getReasonFor2FA())) {
				payment.setSafiCall(SafiConstants.SAFI_CALL_NOTIFY);		//	flag to indicate which SAFI action to call
			} else {
				payment.setSafiCall("");
			}
			mobileSession.setTransaction(payment);
			
			IMBResp transferResponse = performTransfer(mobileSession, fromAccount, payment, ServiceConstants.PAYEE_TRANSFER_SECURE_SERVICE, commonData, httpRequest,true);
			
			//18E4: Safi Notify Call when Payment is Successful
			boolean isPaymentSuccess = isPaymentSuccess(transferResponse);
			notifyCallForSafi(httpRequest, httpResponse, mobileSession, commonData, payment, digitalSecMap, true /*status2FA*/, isPaymentSuccess);
			//18E4: Safi Notify Call when Payment is Successful
			
			return transferResponse;
		} catch (ResourceException e) {
			Logger.error("Exception PayeeController - transferSecure(): GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "]", e, this.getClass());
			mobileSession.removeNPPEnrichmentDetails();
			mobileSession.removeTransaction();
			mobileSession.removeSecureCodeDetails();
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.SYSTEM_UNAVILABLE, ServiceConstants.PAYEE_TRANSFER_SECURE_SERVICE, httpRequest);
		} catch (Exception e) {
			Logger.error("Exception PayeeController - transferSecure(): GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "]", e, this.getClass());
			mobileSession.removeNPPEnrichmentDetails();
			mobileSession.removeTransaction();
			mobileSession.removeSecureCodeDetails();
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.GENERIC_ERROR, ServiceConstants.PAYEE_TRANSFER_SECURE_SERVICE, httpRequest);
		} finally {
			endPerformanceLog(logName);
		}

	}

	private boolean isPaymentSuccess(IMBResp transferResponse) {
		boolean isPaymentSuccess = true;
		if(transferResponse != null && transferResponse instanceof ErrorResp) {
			ErrorResp errResponse = (ErrorResp)transferResponse;
			if(errResponse.hasErrors()) {
				isPaymentSuccess = false;
			}
		}
		return isPaymentSuccess;
	}

	
	private DigitalSecLogggerVO initializeDigitalLoggers(
			IBankCommonData commonData) {
		DigitalSecLogggerVO digitalSecLoggerVO =new DigitalSecLogggerVO();
		digitalSecLoggerVO.setTranName(DigitalSecLogger.TRANSFER_TO_PAYEE);
		digitalSecLoggerVO.setStatus(DigitalSecLogger.FAILURE_2FA);
		digitalSecLoggerVO.setCommonLogData(mbAppHelper.getCommonLogData(commonData));
		digitalSecLoggerVO.setUserAgent(commonData.getUserAgent());
		return digitalSecLoggerVO;
	}

	@RequestMapping(method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE, value = "add")
	@ResponseBody
	public IMBResp addPayee(HttpServletRequest httpRequest, @RequestBody final AddPayeeReq request) {
		Logger.debug("PayeeController - addPayee(). Request: " + request, this.getClass());
		String logName = startPerformanceLog(httpRequest);
		MobileSession mobileSession = new MobileSessionImpl();
        DigitalSecLogggerVO digitalSecLoggerVO =new DigitalSecLogggerVO();
        digitalSecLoggerVO.setTranName(DigitalSecLogger.ADD_PAYEE);
        digitalSecLoggerVO.setStatus(DigitalSecLogger.SUCCESS);
		
		try {
			mobileSession.getSessionContext(httpRequest);
			IBankCommonData commonData = new MBAppHelper().populateIBankCommonData(mobileSession, httpRequest);
			digitalSecLoggerVO.setCommonLogData(mbAppHelper.getCommonLogData(commonData));
			digitalSecLoggerVO.setUserAgent(commonData.getUserAgent());
			
			validateRequestHeader(request.getHeader(), httpRequest);
			ErrorResp errorResponse = validate(request, httpRequest);// validate json
			if (errorResponse.hasErrors())
				return errorResponse;

			Logger.debug("addPayee :", this.getClass());
			ThirdParty thirdParty = payeeHelper.populateThirdParty(request, commonData.getCustomer().getFullName());


			digitalSecLoggerVO.setValues(thirdParty.toDigitalSecurityLog(get2FAExemptType(mobileSession.getCustomer()), null));
			//Changed place for validate payee request to add payee information in forensic logs
			payeeHelper.validatePayeeReq(request);

			// check for existing ThirdParty
			ThirdParty existingThirdParty = payeeService.getPayee(thirdParty, commonData);
			if (existingThirdParty != null && existingThirdParty.getBsb() != null && existingThirdParty.getNumber() != null)
				throw new BusinessException(BusinessException.EXISTING_THIRD_PARTY);

			Logger.debug("addPayee : trusted flag before " + thirdParty.getTrusted(), this.getClass());
			if (!is2FAExcemptAddPayee(mobileSession.getCustomer())) {
				thirdParty.setTrusted(IBankSecureService.TRUSTED_STATUS);
				mobileSession.setPayee(thirdParty);
				Logger.debug("addPayee : trusted flag not exempt after " + thirdParty.getTrusted(), this.getClass());
				return payeeHelper.populateSecureRequiredResponse(populateResponseHeader(ServiceConstants.ADD_PAYEE_SERVICE, mobileSession), mobileSession.getCustomer(), mobileSession.getOrigin(), ServiceConstants.ADD_PAYEE_SERVICE, httpRequest);
			} else {
				
				thirdParty.setTrusted(IBankSecureService.NOT_TRUSTED_STATUS);
				payeeService.addPayee(thirdParty, commonData);
				Customer updatedCustomer = CustomerService.getCustomer(commonData);
				mobileSession.setCustomer(updatedCustomer);
				
				digitalSecLogger.log(digitalSecLoggerVO);
				mobileSession.removeDigitalSecLoggerMap();
				
				IMBResp response = payeeHelper.populateAddPayeeResp(populateResponseHeader(ServiceConstants.ADD_PAYEE_SECURE_SERVICE, mobileSession), updatedCustomer.getThirdParties(), thirdParty);
				mobileSession.removePayee();
				Logger.debug("addPayee : trusted flag exempt after " + thirdParty.getTrusted(), this.getClass());
				return response;
			}
		} catch (BusinessException e) {
			if(e.getKey() != BusinessException.EXISTING_THIRD_PARTY){
				digitalSecLoggerVO.setStatus(DigitalSecLogger.FAILURE);
				digitalSecLogger.log(digitalSecLoggerVO);
			}
			Logger.info("BusinessException - [key: " + e.getKey() + "], GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), e, ServiceConstants.ADD_PAYEE_SERVICE, httpRequest);
		} 
		catch (ResourceException e) {
			Logger.info("ResourceException - [key: " + e.getKey() + "], GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());
			mobileSession.removePayee();
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.SYSTEM_UNAVILABLE, ServiceConstants.ADD_PAYEE_SERVICE, httpRequest);
		} catch (Exception e) {
			Logger.error("Exception PayeeController - addPayee(): GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "]", e, this.getClass());
			mobileSession.removePayee();
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.GENERIC_ERROR, ServiceConstants.ADD_PAYEE_SERVICE, httpRequest);
		} finally {
			endPerformanceLog(logName);
		}

	}
	
	/**
	 * Add Payee Secure
	 * 
	 * @param httpRequest
	 * @param request
	 * @return
	 */
	@RequestMapping(method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE, value = "addsecure")
	@ResponseBody
	public IMBResp addPayeeSecure(HttpServletRequest httpRequest, @RequestBody final SecureCodeReq request) {
		Logger.debug("PayeeController - addPayeeSecure(). Request: " + request, this.getClass());
		String logName = startPerformanceLog(httpRequest);
		MobileSession mobileSession = new MobileSessionImpl();
        DigitalSecLogggerVO digitalSecLoggerVO =new DigitalSecLogggerVO();
        digitalSecLoggerVO.setTranName(DigitalSecLogger.ADD_PAYEE);
        digitalSecLoggerVO.setStatus(DigitalSecLogger.SUCCESS);

		try {
			mobileSession.getSessionContext(httpRequest);
			IBankCommonData commonData = new MBAppHelper().populateIBankCommonData(mobileSession, httpRequest);
			digitalSecLoggerVO.setCommonLogData(mbAppHelper.getCommonLogData(commonData));
			digitalSecLoggerVO.setUserAgent(commonData.getUserAgent());
			
			validateRequestHeader(request.getHeader(), httpRequest);
			ErrorResp errorResponse = validate(request, httpRequest);// validate json
			if (errorResponse.hasErrors())
				return errorResponse;

			if (ServiceConstants.ADD_PAYEE_2FA_TRAN_CODE != request.getTranType()) return MBAppUtils.createInvalid2FATransactionTypeResponse(ServiceConstants.PAYEE_SECURE_CODE_SERVICE);
			

			ThirdParty payee = mobileSession.getPayee();
			LabelValueMap digitalSecMap = mobileSession.getDigitalSecLoggerMap();
			digitalSecLoggerVO.setValues(payee.toDigitalSecurityLog(digitalSecMap.get(DigitalSecLogger.AUTHTYPE), digitalSecMap.get(DigitalSecLogger.AUTHPHONE)));
			
			errorResponse = secureCodeHelper.verifySecureCode(commonData, mobileSession, payee, request, ServiceConstants.ADD_PAYEE_SECURE_SERVICE, httpRequest);
			if (errorResponse.hasErrors()){
				digitalSecLoggerVO.setStatus(DigitalSecLogger.FAILURE_2FA);
				digitalSecLogger.log(digitalSecLoggerVO);
				
				return errorResponse;
			}
			payeeService.addPayee(payee, commonData);
			Customer updatedCustomer = CustomerService.getCustomer(commonData);
			mobileSession.setCustomer(updatedCustomer);
			IMBResp response = payeeHelper.populateAddPayeeResp(populateResponseHeader(ServiceConstants.ADD_PAYEE_SECURE_SERVICE, mobileSession), updatedCustomer.getThirdParties(), payee);
			mobileSession.removePayee();
			mobileSession.removeSecureCodeDetails();
			mobileSession.removeDigitalSecLoggerMap();
			digitalSecLogger.log(digitalSecLoggerVO);
			return response;
		} catch (BusinessException e) {
			//digitalSecLoggerVO.setValues(""); //no values to be logged for failure
			digitalSecLoggerVO.setStatus(DigitalSecLogger.FAILURE);
			digitalSecLogger.log(digitalSecLoggerVO);
			Logger.info("Exception - [key: " + e.getKey() + "], GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), e, ServiceConstants.ADD_PAYEE_SECURE_SERVICE, httpRequest);
		} catch (ResourceException e) {
			Logger.info("Exception - [key: " + e.getKey() + "], GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());
			mobileSession.removePayee();
			mobileSession.removeSecureCodeDetails();
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.SYSTEM_UNAVILABLE, ServiceConstants.ADD_PAYEE_SECURE_SERVICE, httpRequest);
		} catch (Exception e) {
			Logger.error("Exception PayeeController - addPayeeSecure(): GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "]", e, this.getClass());
			mobileSession.removePayee();
			mobileSession.removeSecureCodeDetails();
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.GENERIC_ERROR, ServiceConstants.ADD_PAYEE_SECURE_SERVICE, httpRequest);
		} finally {
			endPerformanceLog(logName);
		}
	}
	
	/**
	 * Delete payee service operation
	 * 
	 * @param httpRequest
	 * @param request
	 * @return
	 */
	@RequestMapping(method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE, value = "delete")
	@ResponseBody
	public IMBResp deletePayee(HttpServletRequest httpRequest, @RequestBody final IndexReq request) {
		Logger.debug("PayeeController - deletePayee(). Request: " + request, this.getClass());
		String logName = startPerformanceLog(httpRequest);
		MobileSession mobileSession = new MobileSessionImpl();
        DigitalSecLogggerVO digitalSecLoggerVO =new DigitalSecLogggerVO();
        digitalSecLoggerVO.setTranName(DigitalSecLogger.DELETE_PAYEE);
        digitalSecLoggerVO.setStatus(DigitalSecLogger.SUCCESS);
        
		try {
			mobileSession.getSessionContext(httpRequest);
			Customer customer = mobileSession.getCustomer();
			IBankCommonData commonData = new MBAppHelper().populateIBankCommonData(mobileSession, httpRequest);

			validateRequestHeader(request.getHeader(), httpRequest);
			ErrorResp errorResponse = validate(request, httpRequest);// validate json
			if (errorResponse.hasErrors())
				return errorResponse;

			digitalSecLoggerVO.setCommonLogData(mbAppHelper.getCommonLogData(commonData));
			digitalSecLoggerVO.setUserAgent(commonData.getUserAgent());
			
			ThirdParty payee = customer.getThirdParties().get(Integer.parseInt(request.getIndex()));
			if (request.isSourceSecurityWellBeingCheck()) {
				payeeService.deletePayee(payee, commonData, ServiceConstants.SOURCE_SECURITY_WELLBEING);
			}
			else {
				payeeService.deletePayee(payee, commonData);
			}
			
			Customer updatedCustomer = CustomerService.getCustomer(commonData);
			mobileSession.setCustomer(updatedCustomer);

			digitalSecLoggerVO.setValues(payee.toDigitalSecurityLog(DigitalSecLogger.DELETE_PAYEE, null));
			digitalSecLogger.log(digitalSecLoggerVO);
			
			return payeeHelper.populateDeletePayeeResp(populateResponseHeader(ServiceConstants.DELETE_PAYEE_SERVICE, mobileSession), updatedCustomer.getThirdParties());
		} catch (BusinessException e) {
			digitalSecLoggerVO.setStatus(DigitalSecLogger.FAILURE);
			digitalSecLogger.log(digitalSecLoggerVO);
			Logger.info("Exception - [key: " + e.getKey() + "], GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());
			if (BusinessException.ACCOUNT_DELETE_UNAVAILABLE == e.getKey()){
				return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.ACCOUNT_DELETE_UNAVAILABLE_PAYEE, ServiceConstants.DELETE_BILLER_SERVICE, httpRequest);
			}
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), e, ServiceConstants.DELETE_PAYEE_SERVICE, httpRequest);
		} catch (ResourceException e) {
			Logger.info("Exception - [key: " + e.getKey() + "], GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.SYSTEM_UNAVILABLE, ServiceConstants.DELETE_PAYEE_SERVICE, httpRequest);
		} catch (Exception e) {
			Logger.error("Exception PayeeController - deletePayee(): GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "]", e, this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.GENERIC_ERROR, ServiceConstants.DELETE_PAYEE_SERVICE, httpRequest);
		} finally {
			endPerformanceLog(logName);
		}

	}
	
	
	/**
	 * Get payment receipts for payee service operation
	 * 
	 * @param httpRequest
	 * @param request
	 * @return
	 */
	@RequestMapping(method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE, value = "receipts")
	@ResponseBody
	public IMBResp getReceipts(HttpServletRequest httpRequest, @RequestBody final IndexReq request) {
		Logger.debug("PayeeController - getReceipts(). Request: " + request, this.getClass());
		String logName = startPerformanceLog(httpRequest);
		MobileSession mobileSession = new MobileSessionImpl();
		try {
			mobileSession.getSessionContext(httpRequest);
			IBankCommonData commonData = new MBAppHelper().populateIBankCommonData(mobileSession, httpRequest);
			
			validateRequestHeader(request.getHeader(), httpRequest);
			ErrorResp errorResponse = validate(request, httpRequest);// validate json
			if (errorResponse.hasErrors())
				return errorResponse;

			String defaultViewDays;
			CodesVO myCodesVO = IBankParams.getCodesData(IBankParams.DEFAULT_ORIGIN, IBankParams.PARAMETER, IBankParams.CODE_THIRDPARTY_PAYMENT_HISTORY_DEFAULT_VIEW_DAYS);
			if (myCodesVO == null) {
				defaultViewDays = "365";
			} else {
				defaultViewDays = myCodesVO.getMessage();
			}
			defaultViewDays = defaultViewDays + 60;
			Date toDate = DateMethods.getUtilDate();
			Date fromDate = DateMethods.relativeDate(toDate, -StringMethods.safeInt(defaultViewDays, 0));
			List<PaymentsLog> paymentLogList = PaymentService.getThirdPartyPaymentHistory(mobileSession.getCustomer().getGcis(), fromDate, toDate, CustomerService.getCustomer(commonData).getThirdParties().get(Integer.parseInt(request.getIndex())), commonData);
			if (paymentLogList.size() > 200) {
				paymentLogList = paymentLogList.subList(0, 200);
			}
			return payeeHelper.populatePayeeReceiptsResp(populateResponseHeader(ServiceConstants.RECEIPTS_PAYEE_SERVICE, mobileSession), paymentLogList, mobileSession.getCustomer().getAccounts());
		} catch (BusinessException e) {
			Logger.info("BusinessException in getReceipts()GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "]", e, this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), e, ServiceConstants.RECEIPTS_PAYEE_SERVICE, httpRequest);
		
		} catch (ResourceException e) {
			Logger.info("Exception - [key: " + e.getKey() + "], GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.SYSTEM_UNAVILABLE, ServiceConstants.RECEIPTS_PAYEE_SERVICE, httpRequest);
		} catch (Exception e) {
			Logger.error("Exception PayeeController - getReceipts(): ", e, this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.GENERIC_ERROR, ServiceConstants.RECEIPTS_PAYEE_SERVICE, httpRequest);
		} finally {
			endPerformanceLog(logName);
		}
	}
	
	/**
	 * Increase limit for payee service operation
	 * 
	 * @param httpRequest
	 * @param request
	 * @return
	 */
	@RequestMapping(method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE, value = "limit")
	@ResponseBody
	public IMBResp changePayeeLimit(HttpServletRequest httpRequest, @RequestBody final ChangePayeeLimitLinkReq request) {
		Logger.debug("PayeeController - changePayeeLimit(). Request: " + request, this.getClass());
		Logger.info("PayeeController - changePayeeLimit(). request.getIndex = " + request.getIndex(), this.getClass());
		
		String logName = startPerformanceLog(httpRequest);
		MobileSession mobileSession = new MobileSessionImpl();
		try {
			mobileSession.getSessionContext(httpRequest);
			IBankCommonData commonData = new MBAppHelper().populateIBankCommonData(mobileSession, httpRequest);
			
			validateRequestHeader(request.getHeader(), httpRequest);
			ErrorResp errorResponse = validate(request, httpRequest);// validate json
			if (errorResponse.hasErrors())
				return errorResponse;
			
			//setting source of Payee Limit Change link in mobile session
			String source = request.getSource();
			
			if (request.isSourceSecurityWellBeingCheck() ) {
				if (source == null) {
					source = ServiceConstants.SOURCE_SECURITY_WELLBEING;
				}
				else {
					source = source + ";" + ServiceConstants.SOURCE_SECURITY_WELLBEING;
				}
			}
			mobileSession.setSourceForPayeeLimitChange(source);
			ThirdParty payee = CustomerService.getCustomer(commonData).getThirdParties().get(Integer.parseInt(request.getIndex()));
			if (!IBankParams.isPayeeLimitIncreaseSwitchOn(commonData.getOrigin()) && "0".equalsIgnoreCase(payeeLimitService.getIncrasePayeLimitStatus(commonData, payee))) {
				return payeeHelper.populateIncreasePayeeLimitResp(populateResponseHeader(ServiceConstants.PAYEE_INCREASE_LIMIT_SERVICE, mobileSession), null, true);
			} else {
				mobileSession.setPayee(payee);
				return payeeHelper.populateChangePayeeLimitResponse(populateResponseHeader(ServiceConstants.PAYEE_INCREASE_LIMIT_SERVICE, mobileSession), payee, mobileSession.getCustomer(), mobileSession.getOrigin(), ServiceConstants.PAYEE_INCREASE_LIMIT_SERVICE, httpRequest);
			}
		} catch (BusinessException e) {
			Logger.info("Exception - [key: " + e.getKey() + "], GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), e, ServiceConstants.PAYEE_INCREASE_LIMIT_SERVICE, httpRequest);
		} catch (ResourceException e) {
			Logger.info("Exception - [key: " + e.getKey() + "], GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());
			mobileSession.removePayee();
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.SYSTEM_UNAVILABLE, ServiceConstants.PAYEE_INCREASE_LIMIT_SERVICE, httpRequest);
		} catch (Exception e) {
			Logger.error("Exception PayeeController - changePayeeLimit(): GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "]", e, this.getClass());
			mobileSession.removePayee();
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.GENERIC_ERROR, ServiceConstants.PAYEE_INCREASE_LIMIT_SERVICE, httpRequest);
		} finally {
			endPerformanceLog(logName);
		}
	}
	
	
	/**
	 * Increase limit for payee secure service operation
	 * 
	 * @param httpRequest
	 * @param request
	 * @return
	 */
	@RequestMapping(method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE, value = "limitsecure")
	@ResponseBody
	public IMBResp increasePayeeLimitSecure(HttpServletRequest httpRequest, @RequestBody final SecureCodeReq request) {
		Logger.debug("PayeeController - increasePayeeLimitSecure(). Request: " + request, this.getClass());
		String logName = startPerformanceLog(httpRequest);
		MobileSession mobileSession = new MobileSessionImpl();
		ThirdParty payee = null;
		PhoneNumber phone = null;
		SecureCodeDetails secureDetails=null;
		DigitalSecLogggerVO digitalSecLoggerVO = null;
		try {
			mobileSession.getSessionContext(httpRequest);
			IBankCommonData commonData = new MBAppHelper().populateIBankCommonData(mobileSession, httpRequest);
			secureDetails = mobileSession.getSecureCodeDetails();
			validateRequestHeader(request.getHeader(), httpRequest);
			ErrorResp errorResponse = validate(request, httpRequest);// validate json
			if (errorResponse.hasErrors())
				return errorResponse;	
			
			if (ServiceConstants.INC_PAYEE_LIMIT_2FA_TRAN_CODE != request.getTranType()) return MBAppUtils.createInvalid2FATransactionTypeResponse(ServiceConstants.PAYEE_SECURE_CODE_SERVICE);
			
			payee = mobileSession.getPayee();
			digitalSecLoggerVO = initializeDigitalLoggerIncreasePayeeLimit(commonData);
			
			phone = CommonBusinessUtil.get2FAPhoneNumber(commonData, secureDetails.getPhoneNumber());
			
			errorResponse = secureCodeHelper.verifySecureCode(commonData, mobileSession, payee, request, ServiceConstants.PAYEE_INCREASE_LIMIT_SECURE_SERVICE, httpRequest);
			if (errorResponse.hasErrors()) {
				//addPayeeDetailsAndLog(payee, digitalSecLoggerVO, DigitalSecLogger.FAILURE_2FA);
				addPayeeDetailsForIncreasePayeeLimitAndLog(payee, digitalSecLoggerVO, phone,secureDetails, DigitalSecLogger.FAILURE_2FA);
				return errorResponse;
			}
			IMBResp response = payeeHelper.populateIncreasePayeeLimitResp(populateResponseHeader(ServiceConstants.PAYEE_INCREASE_LIMIT_SERVICE, mobileSession),
					payeeService.processIncreasePayeeLimit(payee, commonData,mobileSession.getSourceForPayeeLimitChange()), false);
			//addPayeeDetailsAndLog(payee, digitalSecLoggerVO, DigitalSecLogger.SUCCESS);
			addPayeeDetailsForIncreasePayeeLimitAndLog(payee, digitalSecLoggerVO, phone, secureDetails, DigitalSecLogger.SUCCESS);

			mobileSession.removePayee();
			mobileSession.removeSecureCodeDetails();
			mobileSession.removeSource();
			return response;
		} catch (BusinessException e) {
			Logger.info("Exception - [key: " + e.getKey() + "], GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());
			//addPayeeDetailsAndLog(payee, digitalSecLoggerVO, DigitalSecLogger.FAILURE);
			addPayeeDetailsForIncreasePayeeLimitAndLog(payee, digitalSecLoggerVO, phone,secureDetails, DigitalSecLogger.FAILURE);
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), e, ServiceConstants.PAYEE_INCREASE_LIMIT_SECURE_SERVICE, httpRequest);
		} catch (ResourceException e) {
			Logger.info("Exception - [key: " + e.getKey() + "], GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());
			mobileSession.removePayee();
			mobileSession.removeSecureCodeDetails();
			//addPayeeDetailsAndLog(payee, digitalSecLoggerVO, DigitalSecLogger.FAILURE);
			addPayeeDetailsForIncreasePayeeLimitAndLog(payee, digitalSecLoggerVO,phone, secureDetails, DigitalSecLogger.FAILURE);
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.SYSTEM_UNAVILABLE, ServiceConstants.PAYEE_INCREASE_LIMIT_SECURE_SERVICE, httpRequest);
		} catch (Exception e) {
			mobileSession.removePayee();
			mobileSession.removeSecureCodeDetails();
			addPayeeDetailsAndLog(payee, digitalSecLoggerVO, DigitalSecLogger.FAILURE);
			addPayeeDetailsForIncreasePayeeLimitAndLog(payee, digitalSecLoggerVO,phone, secureDetails, DigitalSecLogger.FAILURE);
			Logger.error("Exception PayeeController - increasePayeeLimitSecure(): GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "]", e, this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.GENERIC_ERROR, ServiceConstants.PAYEE_INCREASE_LIMIT_SECURE_SERVICE, httpRequest);
		} finally {
			endPerformanceLog(logName);
		}
	}
	
	
	/**
	 * Decrease limit for payee
	 * 
	 * @param httpRequest
	 * @param request
	 * @return
	 */
	@RequestMapping(method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE, value = "decreaseLimit")
	@ResponseBody
	public IMBResp decreasePayeeLimit(HttpServletRequest httpRequest, @RequestBody final EmptyReq request) {
		Logger.debug("PayeeController - increasePayeeLimitSecure(). Request: " + request, this.getClass());
		String logName = startPerformanceLog(httpRequest);
		MobileSession mobileSession = new MobileSessionImpl();
		try {
			mobileSession.getSessionContext(httpRequest);
			IBankCommonData commonData = new MBAppHelper().populateIBankCommonData(mobileSession, httpRequest);
			
			validateRequestHeader(request.getHeader(), httpRequest);
			ErrorResp errorResponse = validate(request, httpRequest);// validate json
			if (errorResponse.hasErrors())
				return errorResponse;
			
			ThirdParty payee = mobileSession.getPayee();
			
			IMBResp response = payeeHelper.populateDeccreasePayeeLimitResp(populateResponseHeader(ServiceConstants.PAYEE_DECREASE_LIMIT_SERVICE, mobileSession),
					payeeService.processDecreasePayeeLimit(payee, commonData, mobileSession.getSourceForPayeeLimitChange()));
			
			DigitalSecLogggerVO digitalSecLoggerVO = initializeDigitalLoggerDeccreasePayeeLimit(commonData);
			addPayeeDetailsAndLog(payee, digitalSecLoggerVO, DigitalSecLogger.SUCCESS);
			
			mobileSession.removePayee();
			mobileSession.removeSecureCodeDetails();
			mobileSession.removeSource();
			return response;
		} catch (BusinessException e) {
			Logger.info("Exception - [key: " + e.getKey() + "], GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), e, ServiceConstants.PAYEE_DECREASE_LIMIT_SERVICE, httpRequest);
		} catch (ResourceException e) {
			Logger.info("Exception - [key: " + e.getKey() + "], GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());
			mobileSession.removePayee();
			mobileSession.removeSecureCodeDetails();
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.SYSTEM_UNAVILABLE, ServiceConstants.PAYEE_DECREASE_LIMIT_SERVICE, httpRequest);
		} catch (Exception e) {
			mobileSession.removePayee();
			mobileSession.removeSecureCodeDetails();
			Logger.error("Exception PayeeController - increasePayeeLimitSecure(): GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "]", e, this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.GENERIC_ERROR, ServiceConstants.PAYEE_DECREASE_LIMIT_SERVICE, httpRequest);
		} finally {
			endPerformanceLog(logName);
		}
	}

	private void addPayeeDetailsAndLog(ThirdParty payee, DigitalSecLogggerVO digitalSecLoggerVO, String status) {
		StringBuffer sb = new StringBuffer();
		sb.append(DigitalSecLogger.PAYEE_NAME).append(DigitalSecLogger.DELIMITER_COLON).append(payee.getName());
		sb.append(DigitalSecLogger.DELIMITER_COMMA).append(DigitalSecLogger.PAYEE_ACT_NUM).append(DigitalSecLogger.DELIMITER_COLON).append(payee.getAccountNumOsko());
		sb.append(DigitalSecLogger.DELIMITER_COMMA).append(DigitalSecLogger.PAYEE_BSB).append(DigitalSecLogger.DELIMITER_COLON).append(payee.getBsb());
		sb.append(DigitalSecLogger.DELIMITER_COMMA).append(DigitalSecLogger.PAYEE_EMAIL).append(DigitalSecLogger.DELIMITER_COLON).append(payee.getEmailPayee());
		digitalSecLoggerVO.setStatus(status);
		digitalSecLoggerVO.setValues(sb.toString());
		digitalSecLogger.log(digitalSecLoggerVO);
	}
	
	
	/**
	 * Response for invalid body request 
	 * 
	 * @return
	 */
	@ExceptionHandler({org.springframework.http.converter.HttpMessageNotReadableException.class})
	@ResponseStatus(org.springframework.http.HttpStatus.OK)
	@ResponseBody
	public IMBResp resolveException() {
		return MBAppUtils.createInvalidMessageBodyResponse(ServiceConstants.PAYEE_TRANSFER_SERVICE);
	}

	@SuppressWarnings("unchecked")
	private IMBResp performTransfer(MobileSession mobileSession, Account fromAccount, ThirdPartyPayment payment, String caller, IBankCommonData commonData, HttpServletRequest httpRequest,boolean is2FADone)
			throws BusinessException, Exception {
		
		DigitalSecLogggerVO digitalSecLoggerVO =new DigitalSecLogggerVO();
		if(caller!=null && 
				(caller.equalsIgnoreCase(ServiceConstants.PAYID_TRANSFER_SERVICE) || 
						caller.equalsIgnoreCase(ServiceConstants.PAYID_TRANSFER_SECURE_SERVICE))){
			digitalSecLoggerVO.setTranName(DigitalSecLogger.TRANSFER_TO_PAYID);
		}else{
			digitalSecLoggerVO.setTranName(DigitalSecLogger.TRANSFER_TO_PAYEE);
		}
			
        digitalSecLoggerVO.setStatus(DigitalSecLogger.SUCCESS);
		digitalSecLoggerVO.setCommonLogData(mbAppHelper.getCommonLogData(commonData));
		digitalSecLoggerVO.setUserAgent(commonData.getUserAgent());
		
		//	devicePrint will be available in case of native app only and will be passed to forensic log
		String devicePrint = mobileSession.getSafiLogonInfo()!= null ? mobileSession.getSafiLogonInfo().getDevicePrint() : "";
		Logger.debug("performTransfer() devicePrint from native app : "+devicePrint, this.getClass());
		
		try {
			Receipt receipt = null;
			String paymentType = mobileSession.getPaymentType();
			
			if (null == mobileSession.getPaymentType()) {
				paymentType = "";
			}
			receipt = pay(payment, mobileSession);
			mobileSession.setResubmitPayment(Boolean.FALSE);
			if (payment.getFavTranId() != null) {
				try {
					mobileBankService.updateFavouriteTransactionAmount(commonData, payment.getFavTranId(), payment.getAmount().doubleValue());
				} catch (Throwable e) {
					// do nothing
					Logger.info("Exception when updating favourite transaction - GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "]", e, this.getClass());
				}
			}
			
			TransferResp response = payeeHelper
					.populateTransferResponse(populateResponseHeader(ServiceConstants.PAYEE_TRANSFER_SERVICE, mobileSession), receipt, payment, mobileSession.getCustomer());
			
			response = payeeHelper.populateDescriptionPayer(mobileSession, response, receipt, commonData);
			
			// to populate payid payee in the response
			if (payeeHelper.isPayIDPayment(payment) && IBankParams.isNPPPayIdAddressBookSwitchON(commonData.getOrigin())) { //set the PayIdPayees in resp incase AddressBook Switch is ON
				payeeHelper.populatePayIdPayeeResp(receipt, response, commonData);
			}
			
			//	setting On us flag to show relevant message to customer on receipt page
			if(response != null && null != mobileSession.getPaymentType() && mobileSession.getPaymentType().equalsIgnoreCase(ONUS) || (null != payment && payment.isOnUsTransfer())) {
				response.getReceipt().setOnUsTransfer(true);
			} else {
				response.getReceipt().setOnUsTransfer(false);
			}
			
			response = payeeHelper.populateTeaserResponse(response, commonData,"Pay Anyone Receipt");
			if(null!=response.getTeaserResp())
			{
				if(null!=response.getTeaserResp().getSalesOfferTeaserResp())
				{
					if(null==response.getTeaserResp().getSalesOfferTeaserResp().getIsPayeeTfrReceipt())
					{
						// Getting the service station VO and Setting the service station response.
						long insertionPt = payeeHelper.getInsertionPointCode(ServicetationConstants.PAY_ANYONE_RECEIPT);
						ServiceStationVO servicestationVO=populateServiceMessage(insertionPt,ServiceStationImpl.CHANNEL_MOBILE, commonData);
						response = payeeHelper.populateServiceStationResponse(response,servicestationVO);
						
						if(null!=servicestationVO)
						{
						   mobileSession.setServiceStationMessage(servicestationVO.getServiceStationMsg());	
						}
					}
				}	
			}
			
			LabelValueMap digitalSecMap = mobileSession.getDigitalSecLoggerMap();
			String reasonCode = "";
			String digitalSecValues = null;
			if(payment instanceof NPPPayment) {
				reasonCode = ((NPPPayment)payment).getReasonCode();	
				if(null != receipt && null != receipt.getPaymentLog() && NPPStatus.isFailure(receipt.getPaymentLog().getStatus())) {
					digitalSecLoggerVO.setStatus(DigitalSecLogger.FAILURE);
				}
			}
			
			boolean isMobileApp = ((logonHelper.loadCordova(httpRequest)) == -1) ? false:true;
			SafiForensicInfo safiForensicInfo = populateSafiForensicInfoVO(payment.getSafiRespVO(), devicePrint);
			if(is2FADone){				
				if (payment.getScheduleDetails() != null && ((payment.getScheduleDetails().getId()== null || "".equals(payment.getScheduleDetails().getId() ) ))) {
					digitalSecLoggerVO.setValues(((ThirdPartyPayment)payment).toSchLog(false,digitalSecMap.get(DigitalSecLogger.AUTHTYPE),digitalSecMap.get(DigitalSecLogger.AUTHPHONE),mobileSession.getPayIDResolution()));
					digitalSecLogger.log(digitalSecLoggerVO);
				}
				else if(payment.getScheduleDetails() == null){
					digitalSecValues = ((ThirdPartyPayment)payment).toDigitalSecurityLog(false,digitalSecMap.get(DigitalSecLogger.AUTHTYPE),digitalSecMap.get(DigitalSecLogger.AUTHPHONE), mobileSession.getPayIDResolution(), receipt);
				}
			}
			else {
				if (payment.getScheduleDetails() != null && ((payment.getScheduleDetails().getId()== null || "".equals(payment.getScheduleDetails().getId() ) ))) {
					digitalSecLoggerVO.setValues(((ThirdPartyPayment)payment).toSchLog(false,CommonBusinessUtil.get2FAExemptType(commonData.getCustomer()),null, mobileSession.getPayIDResolution()));
					digitalSecLogger.log(digitalSecLoggerVO);

				}
				else if(payment.getScheduleDetails() == null){
					digitalSecValues = ((ThirdPartyPayment)payment).toDigitalSecurityLog(false,CommonBusinessUtil.get2FAExemptType(commonData.getCustomer()),null, mobileSession.getPayIDResolution(),receipt);
				}
			}
			if(payment.getScheduleDetails() == null ) {
				/*if(null != payment && payment instanceof NPPPayment && ((NPPPayment)payment).isDeRetry()) {
					digitalSecLoggerVO.setStatus(DigitalSecLogger.FAILURE);
					digitalSecLoggerVO.setValues(((ThirdPartyPayment)payment).toDigitalSecurityLogNPP(digitalSecValues, "Osko", false  TODO : payment.isRetryDEConsent(),reasonCode, safiForensicInfo, isMobileApp, is2FADone));
					digitalSecLogger.log(digitalSecLoggerVO);
					digitalSecLoggerVO.setStatus(DigitalSecLogger.SUCCESS);
					paymentType = "DE";
				}*/
				digitalSecLoggerVO.setValues(((ThirdPartyPayment)payment).toDigitalSecurityLogNPP(digitalSecValues, paymentType.equalsIgnoreCase(OSKO) ? "Osko" : "DE", null, reasonCode, safiForensicInfo, isMobileApp, is2FADone));
				digitalSecLogger.log(digitalSecLoggerVO);
			}
			
			mobileSession.removeDigitalSecLoggerMap();
			mobileSession.removeNPPEnrichmentDetails();
			mobileSession.removeTransaction();
			mobileSession.removeSecureCodeDetails();
			Logger.debug("PayeeController - performTransfer(). Response: " + response, this.getClass());
			
			return response;
		} catch (DuplicateException e) {
			Logger.info("DuplicateException in PayeeController - transfer() - [key: " + e.getKey() + "], GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());
			if (e.getKey() == BusinessException.DUPLICATE_PAYMENT) {
				return payeeHelper.populateTransferResponse(populateResponseHeader(caller, mobileSession), (List<PaymentDuplicateVO>) ((DuplicateException) e)
						.getDuplicatePaymentList(), mobileSession.getCustomer().getAccounts());
			}
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), e, caller, httpRequest);
		} catch (BusinessException e) {
			Logger.info("BusinessException in PayeeController - transfer() - [key: " + e.getKey() + "], GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());

			if (e.getKey() == BusinessException.IBANK_SECURE_REQUIRED) {
				//	Call SAFI notify call only when it gives challenge response in analyze call
				//	In case SAFI gives allow response and EHUB throws a 2FA challenge then do not make SAFI notify call
				setReasonFor2FA(payment);
				
				return payeeHelper.populateSecureRequiredResponse(populateResponseHeader(caller, mobileSession), mobileSession.getCustomer(), mobileSession.getOrigin(), caller, httpRequest);
			
			} else if(e.getKey() == BusinessException.SAFI_PAYMENT_NO_PHONE_EXIST
					|| e.getKey() == BusinessException.SAFI_PAYMENT_2FA_EXEMPT
					|| e.getKey() == BusinessException.SAFI_PAYMENT_2FA_GLOBAL_BYPASS) {
				
				String[] values = getContactNumber(mobileSession);
				return MBAppUtils.createErrorResp(mobileSession.getOrigin(), e,values, ServiceConstants.PAYEE_TRANSFER_SERVICE, httpRequest);
				
			} else {
				saveDigitalSecureLog(httpRequest, mobileSession, commonData, payment, is2FADone /*is2FADone*/, false /*paymentSuccess*/, caller);

				if (e.getKey() == BusinessException.ACCOUNT_AMT_BELOW_MIN_REDRAW) {
					String minAmt = "";
					if (fromAccount != null && fromAccount.getLimits() != null) {
						minAmt = String.valueOf(fromAccount.getLimits().getMinimumRedrawAmount());
					}
					return MBAppUtils.createErrorResp(mobileSession.getOrigin(), e.getKey(), MBAppUtils.getMessage(mobileSession.getOrigin(), e.getKey(), new String[] { minAmt }), caller, httpRequest);

				} else if (e.getKey() == BusinessException.PAYER_NAME_INVALID) {
					return MBAppUtils.createErrorResp(mobileSession.getOrigin(), e.getKey(), MBAppUtils.getMessage(mobileSession.getOrigin(), e.getKey(), new String[] { NOTALLOW_CHAR_PAYER_NAME }), caller, httpRequest);
				} else if (e.getKey() == BusinessException.INVALID_CHAR_SET) {
					throw new BusinessException(BusinessException.INVALID_CHAR_SET, "Invalid Character");
				} else if(e.getKey()==BusinessException.SAFI_PAYMENT_DENY_ERROR){
					
					String[] values = getContactNumber(mobileSession);
					IMBResp resp1 = MBAppUtils.createErrorResp(mobileSession.getOrigin(), e,values, ServiceConstants.PAYEE_TRANSFER_SERVICE, httpRequest);
					return resp1;
				} 
				else if (e.getKey() == BusinessException.EXCEED_DAILY_LIMIT) {
					BusinessException businessException;
					String[] errorParams = new String[1];
					if(PrudentialLimitHelper.isAsgardNominatedAccount(payment)){
						errorParams[0] = PrudentialLimitHelper.ECASH_BANK_SETUP_EXCEPTION_PARAM;						
					}
					else if(payment.getToThirdParty().getBankSetup()) {
						errorParams[0] = PrudentialLimitHelper.BANK_SETUP_EXCEPTION_PARAM;						
					}
					else {
						errorParams[0] = PrudentialLimitHelper.CUST_SETUP_CUMULATIVE_EXCEPTION_PARAM;						
					}
					businessException = new BusinessException(BusinessException.DB_ACCT_EXCEEDS_DAILY_LIMIT,errorParams);
					return MBAppUtils.createErrorResp(mobileSession.getOrigin(), businessException, businessException.getValues(),caller, httpRequest);
				} else if (e.getKey() == BusinessException.CUST_SETUP_ACCT_EXCEEDS_DAILY_LIMIT) {
					//This is separate error code itroduced for PayId payment.
					if (payeeHelper.isPayIDPayment(payment)) {
						e = new BusinessException(BusinessException.PAYID_TXN_AMOUNT_EXCEEDS_DAILY_LIMIT);
					}
					return MBAppUtils.createErrorResp(mobileSession.getOrigin(), e, e.getValues(),caller, httpRequest);
				} else {					
					return MBAppUtils.createErrorResp(mobileSession.getOrigin(), e, e.getValues(),caller, httpRequest);
				}
			}
		} catch (ResourceException e) {
			saveDigitalSecureLog(httpRequest, mobileSession, commonData, payment,  is2FADone /*is2FADone*/, false /*paymentSuccess*/, caller);
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), e, caller, httpRequest);
		}
	}
	
	/**
	 * This method will be called when user clicks on PayID icon.
	 * A call to WDP arrangement API will be made and if user is a registered PayID then populate PayID type list.
	 * @param ResolvePayIdReq
	 * @return ResolvePayIdResp
	 */
	@RequestMapping(method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE, value = "payIdTypeList")
	@ResponseBody
	public IMBResp getPayIdTypeList(HttpServletRequest httpRequest, HttpServletResponse httpServletResponse,@RequestBody final PayToPayIdLandingPageReq request) {
		String logName = startPerformanceLog(httpRequest);
		MobileSession mobileSession = new MobileSessionImpl();
		IBankCommonData commonData = null;
		ObjectMapper mapper = new ObjectMapper();
		
		try {
			Logger.debug("PayeeController.getPayIdTypeList().JSON Request: " + mapper.writeValueAsString(request), this.getClass());
			
			mobileSession.getSessionContext(httpRequest);
			commonData = new MBAppHelper().populateIBankCommonData(mobileSession, httpRequest);
			validateRequestHeader(request.getHeader(), httpRequest);
			// validate json
			ErrorResp errorResponse = validate(request, httpRequest);
			if (errorResponse.hasErrors())
				return errorResponse;
			
			//	First removing PayIdPaymentSwitchParams from session
			mobileSession.removePayIdPaymentSwitchParams();
			
			PayIdPaymentSwitchParams payIdPaymentSwitchParams = ibankRefreshParams.getPayIdPaymentSwitchParams(commonData.getOrigin(), commonData.getUser().getGCISNumber());
			mobileSession.setPayIdPaymentSwitchParams(payIdPaymentSwitchParams);
			
			Logger.debug("AllowPayToPayIdPayment in PayeeController.getPayIdTypeList():" + payIdPaymentSwitchParams.isAllowPayToPayIdPayment(), this.getClass());
			Logger.debug("ShowPayToPayIdIcon in PayeeController.getPayIdTypeList():" + payIdPaymentSwitchParams.isShowPayToPayIdIcon(), this.getClass());
			
			if(payIdPaymentSwitchParams.isAllowPayToPayIdPayment()) {
				// if PAYID is registered then populate the pay id types list and populate response to send information to UI. 
				IMBResp payIdLandingPageResp = payeeHelper.populatePayIdLandingPageResp(populateResponseHeader(ServiceConstants.PAYEE_TRANSFER_SERVICE, mobileSession), commonData, payIdPaymentSwitchParams);
				
				Logger.info("PayeeController.getPayIdTypeList(): JSON Response :" + mapper.writeValueAsString(payIdLandingPageResp), this.getClass());
				return payIdLandingPageResp;
			}else{
				/*19E1:As per email from Houghton,Karl, In case of PAYID Switch off scenario, send Error message as 
				 "Payments to PayID are currently not available. Please try again later." */

				throw new BusinessException(BusinessException.PAY_TO_PAYID_SWITCH_OFF);
			}
			
		} catch (BusinessException e) {
			Logger.info("BusinessException in PayeeController - getPayIdTypeList() - [key: " + e.getKey() + "], GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), e, ServiceConstants.PAYEE_TRANSFER_SERVICE, httpRequest);
		} catch (ResourceException e) {
			Logger.error("ResourceException in PayeeController - getPayIdTypeList() - [key: " + e.getKey() + "], GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());
			mobileSession.removeNPPEnrichmentDetails();
			mobileSession.removeTransaction();
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.SYSTEM_UNAVILABLE, ServiceConstants.PAYEE_TRANSFER_SERVICE, httpRequest);
		} catch (Exception e) {
			Logger.error("Exception PayeeController - getPayIdTypeList(): GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			mobileSession.removeNPPEnrichmentDetails();
			mobileSession.removeTransaction();
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.GENERIC_ERROR, ServiceConstants.PAYEE_TRANSFER_SERVICE, httpRequest);
		} finally {
			endPerformanceLog(logName);
		}
	}

	/**
	 * This method calls WDP PayId Resolution API to resolve the PAYID based on type of PAYID entered by Customer.
	 * Valid PayID Type Values: CONSMOB,BUSMOB,BUSPH,EMAIL,AUABN,PHALIAS,ORGID
	 * PayID Type: Can not be NULL 
	 * PayID Value : Can not be NULL
	 * @param ResolvePayIdReq
	 * @return ResolvePayIdResp
	 */
	@RequestMapping(method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE, value = "resolvepayid")
	@ResponseBody
	public IMBResp resolvePayId(HttpServletRequest httpRequest, HttpServletResponse httpServletResponse,@RequestBody final ResolvePayIdReq request) {
		String logName = startPerformanceLog(httpRequest);
		MobileSession mobileSession = new MobileSessionImpl(); 
		IBankCommonData commonData = null;
		ObjectMapper mapper = new ObjectMapper();
		SafiPayTranVO safiPayTranVOForResolution = null;
		DigitalSecLogggerVO digitalSecurityLogVO = null;
		
		try {
			Logger.debug("PayeeController - resolvePayId().JSON Request: " + mapper.writeValueAsString(request), this.getClass());

			mobileSession.getSessionContext(httpRequest);
			// check eligible accounts for payID payment and throw business exception if the customer doesn't have one
			if (!isPayIdPaymentAllowed(mobileSession.getCustomer())){
				throw new BusinessException(BusinessException.PAYID_PAYMENT_DENY_ERROR);
			}
			commonData = new MBAppHelper().populateIBankCommonData(mobileSession, httpRequest);
			validateRequestHeader(request.getHeader(), httpRequest);
			//initialize DigitalSecLogggerVO
			digitalSecurityLogVO = payeeHelper.initializeDigitalLogger(commonData, DigitalSecLogger.PAYID_LOOKUP, DigitalSecLogger.SUCCESS, mbAppHelper.getCommonLogData(commonData));
			// validate json
			ErrorResp errorResponse = validate(request, httpRequest);
			if (errorResponse.hasErrors()){
				return errorResponse;
			}
			
			PayIdPaymentSwitchParams payIdPaymentSwitchParams = mobileSession.getPayIdPaymentSwitchParams();
			if(null == payIdPaymentSwitchParams) {
				payIdPaymentSwitchParams = ibankRefreshParams.getPayIdPaymentSwitchParams(commonData.getOrigin(), commonData.getUser().getGCISNumber());
				mobileSession.setPayIdPaymentSwitchParams(payIdPaymentSwitchParams);
			}
			if(payIdPaymentSwitchParams != null && payIdPaymentSwitchParams.isAllowPayToPayIdPayment()) {
				String payID = request.getPayIdValue();
				String payIDType = request.getPayIdType();
				int payeePayIDindex = request.getPayIdIndex();
				//Existing PayId from Address Book
				NPPPayIdPayee selectedPayIdPayee = null;
				if( IBankParams.isNPPPayIdAddressBookSwitchON(commonData.getOrigin())) {//PayID AddressBook Switch ON then get from the addressBook
					if(request.getPayIdIndex() != -1 ) {
						Customer customer = mobileSession.getCustomer();
						if(null != customer) {
							List<NPPPayIdPayee> payIdPayees = customer.getNppPayIdPayees();
							if(null != payIdPayees && payIdPayees.size() != 0 ) {
								selectedPayIdPayee = payIdPayees.get(request.getPayIdIndex());
								payID = selectedPayIdPayee.getPayId();
								payIDType = selectedPayIdPayee.getPayIdType();
							}
						}
						 
					}else { //Duplicate check for new  PayID Payee 
						NPPPayIdPayee payIdpayee = payeeHelper.getPayIDPayee(payIDType, payID, mobileSession.getCustomer());
						if(null != payIdpayee) {
							throw new BusinessException(BusinessException.PAYID_EXISTS);
						}
							
					}
				}
			
				if(!StringMethods.isEmptyString(payID) && !StringMethods.isEmptyString(payIDType) && (payIDType.equalsIgnoreCase(NPPUtil.PAYID_TYPE_EMAIL) || payIDType.equalsIgnoreCase(NPPUtil.PAYID_TYPE_ORGID))) {
					payID = payID.trim().toLowerCase();
				}

				NPPUtil.validatePayID(payID, payIDType);
				
				//increase PayID resolution counter
				long payIdResolutionCounter = nppService.getPayIdResolutionCounter(commonData);
				//	SAFI for PayID resolution call
				safiPayTranVOForResolution = populateSafiVOForPayIdResolution(httpRequest, request, mobileSession, commonData, payIDType, payID, payIdResolutionCounter, payeePayIDindex);
				nppService.callSAFIAnalyzeForPayIdResolution(safiPayTranVOForResolution, commonData);
				// If SAFI switch is off or SAFI is not available and PayID
				// resolution counter threshold reached then deny payment
				if (safiPayTranVOForResolution == null || safiPayTranVOForResolution.getSafiRespVO() == null) {
					if (NPPUtil.isPayIdResolutionMaxThresholdReached(commonData.getUser().getGCISNumber(), payIdResolutionCounter)) {
						throw new BusinessException(BusinessException.SAFI_PAYMENT_DENY_ERROR);
					}
				}
				// Call WDP Resolution API to resolve PAYID
				PayIDResolution payIDResolution = null;
				if(IBankParams.isPayIdResolutionServiceSwitchOn(commonData.getOrigin())) {
					 payIDResolution = nppService.resolvePayIdWDPService(commonData, payID, NPPUtil.getESBPayIdType(payIDType));
				}else {
					 payIDResolution = nppService.resolvePayId(commonData, payID, NPPUtil.getESBPayIdType(payIDType));
				}
				
				payIDResolution.setPayIDTypeOrig(payIDType);
				Logger.debug("Resolve PayiD payeePayIDindex " + payeePayIDindex , this.getClass());
				if (payeePayIDindex == -1) {
					payIDResolution.setNewPayIDPayee(true);
					
				}
				Logger.debug("Resolve PayiD payIDResolution.getNewPayIDPayee " + payIDResolution.isNewPayIDPayee() , this.getClass());
				// if PAYID is resolved then set it in session
				boolean isNameChanged = false;
				if(payIDResolution != null && payIDResolution.isPayIDResolutionStatus()){
					if(null != selectedPayIdPayee && !payIDResolution.isNewPayIDPayee() && !payIDResolution.getShortName().equals(selectedPayIdPayee.getPayIdName()) ) {
						isNameChanged = true;
						payIDResolution.setNameChanged(true);
					}
					mobileSession.setPayIDResolution(payIDResolution);
					//add forensic log for success
					addPayIdResolutionSuccessDigitialLogger(payIDResolution, payIDType, mobileSession.getCustomer(), digitalSecurityLogVO, null, isNameChanged);
				}
				else{
					throw new BusinessException(BusinessException.PAYID_NOT_RESOLVED, new String[]{payID});
				}

				//Populate response to send information to UI.
				IMBResp resolvePayIdResp = payeeHelper.populateResolvePayIdResp(populateResponseHeader(ServiceConstants.PAYEE_TRANSFER_SERVICE, mobileSession),payIDResolution, payIDType,isNameChanged);

				Logger.info("PayeeController.resolvePayId(): JSON Response :" + mapper.writeValueAsString(resolvePayIdResp), this.getClass());
						
				return  resolvePayIdResp;
				
			} else {
				throw new BusinessException(BusinessException.SYSTEM_UNAVILABLE);
		   }
		} catch (BusinessException e) {
			Logger.info("BusinessException in PayeeController - resolvePayId() - [key: " + e.getKey() + "], GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());
			if(e.getKey() == BusinessException.PAYID_PAYMENT_DENY_ERROR) {
				// add forensic log for failure
				return MBAppUtils.createErrorResp(mobileSession.getOrigin(), e, getContactNumber(mobileSession), ServiceConstants.PAYEE_TRANSFER_SERVICE, httpRequest);
			} 
			else if(e.getKey()==BusinessException.PAYID_NOT_RESOLVED){
				//add forensic log for failure
				addPayIdResolutionFailureDigitialLogger(request.getPayIdValue(), request.getPayIdType(), mobileSession.getCustomer(), digitalSecurityLogVO, null, BusinessException.PAYID_NOT_RESOLVED);
				
				String[] values = {request.getPayIdValue().trim().toLowerCase()};
				ErrorResp errRsp = MBAppUtils.createErrorResp(mobileSession.getOrigin(), e,values,ServiceConstants.PAYEE_TRANSFER_SERVICE, httpRequest);
				int indexOf = errRsp.getErrors().get(0).getMessage().lastIndexOf(":");
				String errMsg = errRsp.getErrors().get(0).getMessage().substring(0, indexOf+1) + "<br>" +errRsp.getErrors().get(0).getMessage().substring(indexOf+2, errRsp.getErrors().get(0).getMessage().length());
				errRsp.getErrors().get(0).setMessage(errMsg);
				return errRsp;
				
			} else if(e.getKey() == BusinessException.SAFI_PAYMENT_DENY_ERROR) {
				// add forensic log for failure
				addPayIdResolutionFailureDigitialLogger(request.getPayIdValue(), request.getPayIdType(),
						mobileSession.getCustomer(), digitalSecurityLogVO, null, BusinessException.PAY_TO_PAYID_RESOLUTION_ERROR);
				return MBAppUtils.createErrorResp(mobileSession.getOrigin(), e, getContactNumber(mobileSession), ServiceConstants.PAYEE_TRANSFER_SERVICE, httpRequest);
				
			} else if (e.getKey() == BusinessException.IBANK_SECURE_REQUIRED) {
				return payeeHelper.populateSecureRequiredResponse(populateResponseHeader(ServiceConstants.PAYEE_TRANSFER_SERVICE, mobileSession), mobileSession.getCustomer(), mobileSession.getOrigin(), ServiceConstants.PAYEE_TRANSFER_SERVICE, httpRequest);
			
			} else if(e.getKey() == BusinessException.SAFI_PAYMENT_NO_PHONE_EXIST
					|| e.getKey() == BusinessException.SAFI_PAYMENT_2FA_EXEMPT
					|| e.getKey() == BusinessException.SAFI_PAYMENT_2FA_GLOBAL_BYPASS) {
				
				String[] values = getContactNumber(mobileSession);
				// add forensic log for failure
				addPayIdResolutionFailureDigitialLogger(request.getPayIdValue(), request.getPayIdType(),
						mobileSession.getCustomer(), digitalSecurityLogVO, null, BusinessException.PAY_TO_PAYID_RESOLUTION_ERROR);
				return MBAppUtils.createErrorResp(mobileSession.getOrigin(), e,values, ServiceConstants.PAYEE_TRANSFER_SERVICE, httpRequest);
				
			}else if(e.getKey()==BusinessException.PAYID_EXISTS) {
				Logger.error("BusinessException in PayeeController - resolvePayId() duplicate payId - [key: " + e.getKey() + "], GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());
				return MBAppUtils.createErrorResp(mobileSession.getOrigin(), e,ServiceConstants.PAYEE_TRANSFER_SERVICE, httpRequest);
			}else {
				if (e.getKey()==BusinessException.PAY_TO_PAYID_RESOLUTION_ERROR){
					addPayIdResolutionFailureDigitialLogger(request.getPayIdValue(), request.getPayIdType(),
							mobileSession.getCustomer(), digitalSecurityLogVO, null, BusinessException.PAY_TO_PAYID_RESOLUTION_ERROR);
				}
				return MBAppUtils.createErrorResp(mobileSession.getOrigin(), e,ServiceConstants.PAYEE_TRANSFER_SERVICE, httpRequest);
			}
		} catch (ResourceException e) {
			Logger.error("ResourceException in PayeeController - resolvePayId() - [key: " + e.getKey() + "], GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());
			mobileSession.removeNPPEnrichmentDetails();
			mobileSession.removeTransaction();
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.SYSTEM_UNAVILABLE, ServiceConstants.PAYEE_TRANSFER_SERVICE, httpRequest);
		} catch (Exception e) {
			Logger.error("Exception PayeeController - resolvePayId(): GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			mobileSession.removeNPPEnrichmentDetails();
			mobileSession.removeTransaction();
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.GENERIC_ERROR, ServiceConstants.PAYEE_TRANSFER_SERVICE, httpRequest);
		} finally {
			endPerformanceLog(logName);
			
			if(safiPayTranVOForResolution != null) {
				handleSafiResponseForPayIdResolution(safiPayTranVOForResolution.getSafiRespVO(), httpRequest, httpServletResponse);
				
				if(safiPayTranVOForResolution.getSafiRespVO() != null) {
					mobileSession.setSafiPayTranVOForPayIdResolution(safiPayTranVOForResolution);
				}
			}
		}
	}

	/**
	 * This method checks the eligible accounts for payID payment and if the
	 * customer doesn't have one return false.
	 * 
	 * @param customer
	 * @return
	 */
	private boolean isPayIdPaymentAllowed(Customer customer) {
		if (customer.getAccounts() != null) {
			for (Account account : customer.getAccounts()) {
				if ((Account.DDA.equalsIgnoreCase(account.getAccountId().getApplicationId())
						|| Account.CHS.equalsIgnoreCase(account.getAccountId().getApplicationId()))
						&& account.getAllowFlags().contains(AccountFlags.ALLOW_WITHDRAWAL)) {
					return true;
				}
			}
		}
		return false;
	}
	
	/**
	 * Transfer to PayID operation
	 * 
	 * @param httpRequest
	 * @param request
	 * @return
	 */
	@RequestMapping(method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE, value = "transferpayid")
	@ResponseBody
	public IMBResp transferToPayID(HttpServletRequest httpRequest, HttpServletResponse httpServletResponse,@RequestBody final PayeeTransferReq request) {
		Logger.debug("PayeeController - transferToPayId(). Request: " + request, this.getClass());
		String logName = startPerformanceLog(httpRequest);
		MobileSession mobileSession = new MobileSessionImpl(); 
		IBankCommonData commonData = null;
		ThirdPartyPayment payment = null;
		
		try {
			mobileSession.getSessionContext(httpRequest);
			Customer customer = mobileSession.getCustomer();
			commonData = new MBAppHelper().populateIBankCommonData(mobileSession, httpRequest);
			payeeHelper.populatePayIdPayees(commonData, customer);
			validateRequestHeader(request.getHeader(), httpRequest);
			ErrorResp errorResponse = validate(request, httpRequest);// validate json
			if (errorResponse.hasErrors())
				return errorResponse;

			PayIdPaymentSwitchParams payIdPaymentSwitchParams = mobileSession.getPayIdPaymentSwitchParams();
			if(payIdPaymentSwitchParams != null && payIdPaymentSwitchParams.isAllowPayToPayIdPayment()) {
				PayIDResolution payIDResolution = mobileSession.getPayIDResolution();

				if(payIDResolution != null && payIDResolution.isPayIDResolutionStatus()){

					NPPValidations nppValidationsVO = populateNPPValidationsVO(request, customer, commonData, payIDResolution);
					nppService.validatePayIDTransferEligibility(nppValidationsVO);
				}

				Account fromAccount = customer.getAccounts().get(request.getFromAccountIndex());

				mobileSession.setPaymentType(OSKO);

				Logger.debug("PayeeController - transferToPayId(): PaymentType is PAYID - Payment will be processed via 501",getClass());	
				payment = payeeHelper.populateNPPPayment(fromAccount, customer, commonData, request, mobileSession);
				
				//Change this code once PayID address book gets implemented
				Logger.debug("payIDResolution.isNewPayIDPayee() "+ payIDResolution.isNewPayIDPayee(), this.getClass());
				if(payIDResolution.isNewPayIDPayee()) {
					payment.setNewThirdParty(true);
				} else {
					payment.setNewThirdParty(false);
				}
				
				//Safi Call for Pay to PayId 19E2
				populatePayIdSafiPayTranVO(httpRequest, request, mobileSession, commonData, payment);
				
				Boolean sendMail = payeeHelper.isValidSendMailFlag(request.getSendEmail());

				mobileSession.setSendPaymentEmail(sendMail);
				IMBResp resp = performTransfer(mobileSession, fromAccount, payment, ServiceConstants.PAYID_TRANSFER_SERVICE, commonData, httpRequest,false);
				mobileSession.setTransaction(payment);
				return  resp;
				
			} else {
				throw new BusinessException(BusinessException.SYSTEM_UNAVILABLE);
			}

		} catch (BusinessException e) {
			Logger.info("BusinessException in PayeeController - transferToPayId() - [key: " + e.getKey() + "], GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), e, ServiceConstants.PAYID_TRANSFER_SERVICE, httpRequest);
		} catch (ResourceException e) {
			Logger.error("ResourceException in PayeeController - transferToPayId() - [key: " + e.getKey() + "], GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());
			mobileSession.removeNPPEnrichmentDetails();
			mobileSession.removeTransaction();
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.SYSTEM_UNAVILABLE, ServiceConstants.PAYID_TRANSFER_SERVICE, httpRequest);
		} catch (Exception e) {
			Logger.error("Exception PayeeController - transferToPayId(): GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			mobileSession.removeNPPEnrichmentDetails();
			mobileSession.removeTransaction();
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.GENERIC_ERROR, ServiceConstants.PAYID_TRANSFER_SERVICE, httpRequest);
		} finally {
			handleSafiResponse(payment,httpRequest,httpServletResponse);
			endPerformanceLog(logName);
		}
	}
	
	/**
	 * Make secure transfer service operation
	 * 
	 * @param request
	 * @return
	 */
	@RequestMapping(method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE, value = "transferpayidsecure")
	@ResponseBody
	public IMBResp transferToPayIDSecure(HttpServletRequest httpRequest, HttpServletResponse httpResponse, @RequestBody final SecureCodeReq request) {
		Logger.debug("PayeeController - transferpayidsecure(). Request: " + request, this.getClass());
		String logName = startPerformanceLog(httpRequest);
		MobileSession mobileSession = new MobileSessionImpl();
		String safiAction = null;
		IMBResp transferResponse;

		try {
			mobileSession.getSessionContext(httpRequest);
			IBankCommonData commonData = new MBAppHelper().populateIBankCommonData(mobileSession, httpRequest);
			validateRequestHeader(request.getHeader(), httpRequest);
			ErrorResp errorResponse = validate(request, httpRequest);// validate json
			if (errorResponse.hasErrors())
				return errorResponse;

			if (ServiceConstants.PAY_TO_PAYID_TRAN_CODE != request.getTranType()) return MBAppUtils.createInvalid2FATransactionTypeResponse(ServiceConstants.PAYID_SECURE_CODE_SERVICE);
			
			PayIdPaymentSwitchParams payIdPaymentSwitchParams = mobileSession.getPayIdPaymentSwitchParams();
			if(payIdPaymentSwitchParams != null && payIdPaymentSwitchParams.isAllowPayToPayIdPayment()) {
				ThirdPartyPayment payment = (ThirdPartyPayment) mobileSession.getTransaction();
				safiAction = payment.getSafiRespVO() != null && payment.getSafiRespVO().getSafiAction() != null ? payment.getSafiRespVO().getSafiAction(): null ;
				
				String reasonCode = "";
				if(payment instanceof NPPPayment) {
					reasonCode = ((NPPPayment)payment).getReasonCode();			
				}
				
				String paymentType = mobileSession.getPaymentType();
				if (null == mobileSession.getPaymentType()) {
					paymentType = "";
				}
				
				boolean isMobileApp = ((logonHelper.loadCordova(httpRequest)) == -1) ? false:true;
				
				LabelValueMap digitalSecMap = mobileSession.getDigitalSecLoggerMap();
				errorResponse = secureCodeHelper.verifySecureCode(commonData, mobileSession, mobileSession.getTransaction(), request, ServiceConstants.PAYID_TRANSFER_SECURE_SERVICE, httpRequest);
				if (errorResponse.hasErrors()){
					Logger.debug("Error in transferpayidsecure() after verifySecureCode with safiAction : "+safiAction, this.getClass());
					DigitalSecLogggerVO digitalSecLoggerVO = initializeDigitalLoggers(commonData);
					String devicePrint = mobileSession.getSafiLogonInfo()!= null ? mobileSession.getSafiLogonInfo().getDevicePrint() : "";
					if(payment.getScheduleDetails()==null) {
						SafiForensicInfo safiForensicInfo = populateSafiForensicInfoVO(payment.getSafiRespVO(), devicePrint);
						/*if(null != payment && payment instanceof NPPPayment && ((NPPPayment)payment).isDeRetry()) {
							digitalSecLoggerVO.setStatus(DigitalSecLogger.FAILURE);
							digitalSecLoggerVO.setValues(((ThirdPartyPayment)payment).toDigitalSecurityLogNPP(((ThirdPartyPayment)payment).toDigitalSecurityLog(false,digitalSecMap.get(DigitalSecLogger.AUTHTYPE),digitalSecMap.get(DigitalSecLogger.AUTHPHONE), mobileSession.getPayIDResolution()), "Osko", false  TODO : payment.isRetryDEConsent(),reasonCode, safiForensicInfo, isMobileApp, false is2FADone));
							digitalSecLogger.log(digitalSecLoggerVO);
							digitalSecLoggerVO.setStatus(DigitalSecLogger.SUCCESS);
							paymentType = "DE";
						}*/
						digitalSecLoggerVO.setValues(((ThirdPartyPayment)payment).toDigitalSecurityLogNPP(((ThirdPartyPayment)payment).toDigitalSecurityLog(false,digitalSecMap.get(DigitalSecLogger.AUTHTYPE),digitalSecMap.get(DigitalSecLogger.AUTHPHONE), mobileSession.getPayIDResolution(), null), paymentType.equalsIgnoreCase(OSKO) ? "Osko" : "DE", null, reasonCode,safiForensicInfo, isMobileApp, false /*is2FADone*/));
						
					} else if(payment.getScheduleDetails() != null && ((payment.getScheduleDetails().getId()== null || "".equals(payment.getScheduleDetails().getId() ) ))) {
						digitalSecLoggerVO.setValues(((ThirdPartyPayment)payment).toSchLog(false,digitalSecMap.get(DigitalSecLogger.AUTHTYPE),digitalSecMap.get(DigitalSecLogger.AUTHPHONE),mobileSession.getPayIDResolution()));
					}
					digitalSecLogger.log(digitalSecLoggerVO);
					
					//19E2: Safi Notify if SAFI response is challenge or customer account is suspended after unsuccessful 2FA attempts
					if((errorResponse.getStatus() ==  ErrorResp.STATUS_2FA_SUSPENDED )){
						notifyCallForSafi(httpRequest, httpResponse, mobileSession, commonData, payment, digitalSecMap,false, false);
					}
					
					//19E2: Safi Notify
					
					return errorResponse;
				}
				
				// do transfer
				payment.getToThirdParty().setTrusted(IBankSecureService.TRUSTED_NOW_STATUS);
				Logger.debug("transferpayidsecure : changed to Trusted Now " + payment.getToThirdParty().getTrusted(), this.getClass());
				payment.setOtp(mobileSession.getSecureCodeDetails().getOtp());
	
				Account fromAccount = MBAppHelper.getAccountbyAccountId(payment.getFromAccount(), mobileSession.getCustomer().getAccounts());
				
				//	Before making transfer, remove value from safi call so that analyze call is not made again in ThirdPartyTransferTransaction
				//	If reason of 2FA is SAFI challenge response then call notify method
				//	If reason of 2FA is thrown EHUB then do not call notify method
				if(payment != null && null != payment.getReasonFor2FA() && REASON_2FA_SAFI.equalsIgnoreCase(payment.getReasonFor2FA())) {
					payment.setSafiCall(SafiConstants.SAFI_CALL_NOTIFY);		//	flag to indicate which SAFI action to call
				} else {
					payment.setSafiCall("");
				}
				mobileSession.setTransaction(payment);
				
				transferResponse = performTransfer(mobileSession, fromAccount, payment, ServiceConstants.PAYID_TRANSFER_SECURE_SERVICE, commonData, httpRequest,true);
				
				//18E4: Safi Notify Call when Payment is Successful
				boolean isPaymentSuccess = isPaymentSuccess(transferResponse);
				notifyCallForSafi(httpRequest, httpResponse, mobileSession, commonData, payment, digitalSecMap, true /*status2FA*/, isPaymentSuccess);
				//18E4: Safi Notify Call when Payment is Successful
				
			} else {
				throw new BusinessException(BusinessException.SYSTEM_UNAVILABLE);
			}
			
			return transferResponse;
		} catch (ResourceException e) {
			Logger.error("Exception PayeeController - transferpayidsecure(): GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "]", e, this.getClass());
			mobileSession.removeNPPEnrichmentDetails();
			mobileSession.removeTransaction();
			mobileSession.removeSecureCodeDetails();
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.SYSTEM_UNAVILABLE, ServiceConstants.PAYID_TRANSFER_SECURE_SERVICE, httpRequest);
		} catch (Exception e) {
			Logger.error("Exception PayeeController - transferpayidsecure(): GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "]", e, this.getClass());
			mobileSession.removeNPPEnrichmentDetails();
			mobileSession.removeTransaction();
			mobileSession.removeSecureCodeDetails();
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.GENERIC_ERROR, ServiceConstants.PAYID_TRANSFER_SECURE_SERVICE, httpRequest);
		} finally {
			endPerformanceLog(logName);
		}

	}
	
	
	/**
	 * Validate BIC for Payee
	 * @param httpRequest
	 * @param request
	 * @return
	 */
	@RequestMapping(method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE, value = "validateBic")
	@ResponseBody
	public IMBResp validateBicAndPaymentEnrichment(HttpServletRequest httpRequest, @RequestBody final NPPValidateEnrichmentReq request) {
		final String methodName = "PayeeController.validateBicAndPaymentEnrichment():";
		
		Logger.debug("PayeeController - validateBicAndPaymentEnrichment Request: " + request, this.getClass());
		String logName = startPerformanceLog(httpRequest);
		MobileSession mobileSession = new MobileSessionImpl();
		IBankCommonData commonData = null;
		boolean isBicActive=false;
		
		try {
			mobileSession.getSessionContext(httpRequest);
			commonData = new MBAppHelper().populateIBankCommonData(mobileSession, httpRequest);
				
			validateRequestHeader(request.getHeader(), httpRequest);
			
			// -- 21E2 : Abusive Transaction

			String payAmount = request.getAmt();
			String payDescription = request.getDesc();
			String payReference = request.getReference();

			Logger.info(methodName + "Amount: " + payAmount, this.getClass());
			Logger.info(methodName + "Desc: " + payDescription, this.getClass());
			Logger.info(methodName + "Reference: " + payReference, this.getClass());

			boolean isAbusiveOutwardSwitchON = IBankParams.isSwitchOn(IBankParams.ABUSIVE_OUTWARD_SWITCH);
			Logger.info(methodName + "isAbusiveOutwardSwitchON: " + isAbusiveOutwardSwitchON, this.getClass());

			if (isAbusiveOutwardSwitchON) {

				List<String> abusiveWordsDictionary = IBankParams.getAbusiveWordsDictionary();
				Logger.info(methodName + "abusiveWordsDictionary: " + abusiveWordsDictionary, this.getClass());

				if (abusiveWordsDictionary != null && !abusiveWordsDictionary.isEmpty()) {
					BusinessException bExc = null;
					int errorKeyId = 0;
					
					List<String> abusiveWordsDictionaryWithDot = IBankParams.getAbusiveWordsDictionaryWithDot();
					Logger.info(methodName + "abusiveWordsDictionaryWithDot: " + abusiveWordsDictionaryWithDot, this.getClass());

					boolean isDescriptionAbusive = IBankParams.isAbusiveWordPresent(payDescription, abusiveWordsDictionary, abusiveWordsDictionaryWithDot);
					boolean isReferenceAbusive = IBankParams.isAbusiveWordPresent(payReference, abusiveWordsDictionary, abusiveWordsDictionaryWithDot);

					if (isDescriptionAbusive)
						errorKeyId = BusinessException.ABUSIVE_WORD_IN_DESC;
					if (isReferenceAbusive)
						errorKeyId = BusinessException.ABUSIVE_WORD_IN_REFERENCE;
					if (isDescriptionAbusive && isReferenceAbusive) {
						errorKeyId = BusinessException.ABUSIVE_WORD_IN_DESC_REFERENCE;
					}
					if(isDescriptionAbusive || isReferenceAbusive) {
						NPPUtil.createAbusivewordStatisticsLog(commonData, payDescription, payReference,null,Statistic.ABUSIVE_OUTWARD_TRANSACTION);
						Customer customerTmp = mobileSession.getCustomer();
						String fromAcctNo="";
						String fromBsb="";						
						if(null!=customerTmp) {
							Account fromAccount = customerTmp.getAccounts().get(request.getFromAccountIndex());
							if(null!=fromAccount) {
								if(null!=fromAccount.getAccountId()) {
									fromAcctNo = fromAccount.getAccountId().getAccountNumber();
									fromBsb = fromAccount.getAccountId().getBsb();
								}
							}
						}
						String transDate = getFormattedDate(null, new Date());
						DigitalSecLogggerVO digitalSecAbuiveTransVO =new DigitalSecLogggerVO();
						digitalSecAbuiveTransVO.setTranName(DigitalSecLogger.REPORT_ABUSIVE_TRA_OUTWARD);
						digitalSecAbuiveTransVO.setCommonLogData(mbAppHelper.getCommonLogData(commonData));
						digitalSecAbuiveTransVO.setUserAgent(commonData.getUserAgent());
						digitalSecAbuiveTransVO.setValues(NPPUtil.getAbusiveTransDigitalSecurityLog(commonData, payDescription, payReference, 
								fromAcctNo, fromBsb, "", "", payAmount, transDate, "", false));
						digitalSecLogger.log(digitalSecAbuiveTransVO);

					}
					if (errorKeyId != 0) {
						bExc = new BusinessException(errorKeyId);
						return MBAppUtils.createErrorResp(mobileSession.getOrigin(), bExc,
								ServiceConstants.PAYEE_VALIDATE_BIC_SERVICE, httpRequest);
					}
				}
			}

			// -- 21E2 : Abusive Transaction
			
			ErrorResp errorResponse = validate(request, httpRequest);// validate json
			if (errorResponse.hasErrors())
				return errorResponse;
			PayIDResolution payIDResolution = mobileSession.getPayIDResolution();
				if(payIDResolution != null && payIDResolution.isPayIDResolutionStatus()){
					if(payIDResolution.getIssuer()!=null){
							isBicActive=nppService.validateBic(payIDResolution);
						}
					}
			
			//21E1 - Enrichment Call just before showing review page during payid MB flow
			if(ibankRefreshParams.isNPPEnrichmentAPISwitchOn()) {
				try{
					Customer customer = mobileSession.getCustomer();
					NPPEnrichmentDetails nppEnrichmentDetailsVO = new NPPEnrichmentDetails();
					nppEnrichmentDetailsVO.setFromAccount(customer.getAccounts().get(request.getFromAccountIndex()));
					nppEnrichmentDetailsVO = nppService.callPaymentEnrichmentAPI(nppEnrichmentDetailsVO, commonData);
					if(StringUtils.isEmpty(nppEnrichmentDetailsVO.getFlan())) {
						Logger.info("FLAN not received from WDP enrichment API. Payid payment cannot proceed since FLAN is missing", this.getClass());
						mobileSession.removeNPPEnrichmentDetails();
						throw new BusinessException(BusinessException.NPP_ENRICHMEMT_API_ERROR, "FLAN Missing");
					} else {
						//Set FLAN and otherdetails in session to be used in SVC501
						mobileSession.setNPPEnrichmentDetails(nppEnrichmentDetailsVO);
					}
				}catch(BusinessException e) {
					Logger.error("Business Exception in calling Enrichment API. Payment not eligible for Osko", e, this.getClass());
					mobileSession.removeNPPEnrichmentDetails();
					throw e; 
				}
			}else {
				Logger.debug("isNPPEnrichmentAPISwitchOn is false. Not calling enrichment API", this.getClass());
			}
			Logger.debug("PayeeController - populating responsee", this.getClass());
			IMBResp response = payeeHelper.populateValidateBicResp(populateResponseHeader(ServiceConstants.PAYEE_VALIDATE_BIC_SERVICE, mobileSession),isBicActive);
			return response;
			} 
		  catch (BusinessException e) {
			  Logger.info("BusinessException in PayeeController - validateBicAndPaymentEnrichment() - [key: " + e.getKey() + "], GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());
			  if(e.getKey() == BusinessException.NPP_ENRICHMEMT_API_ERROR) {
				String errorParams[] = getPhoneNumber(commonData);
				ErrorResp resp = MBAppUtils.createErrorResp(mobileSession.getOrigin(), e, errorParams, ServiceConstants.NPP_ENRICHMEMT_API_ERROR, httpRequest);	
				return resp;
			}
			  return MBAppUtils.createErrorResp(mobileSession.getOrigin(), e, ServiceConstants.PAYEE_VALIDATE_BIC_SERVICE, httpRequest);
				} 
		  catch (ResourceException e) {
			  Logger.info("Exception in validateBicAndPaymentEnrichment() - [key: " + e.getKey() + "], GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());
			  return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.SYSTEM_UNAVILABLE, ServiceConstants.PAYEE_VALIDATE_BIC_SERVICE, httpRequest);
		  		} 
		  catch (Exception e) {
			  Logger.error("Exception in PayeeController - validateBicAndPaymentEnrichment(): GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "]", e, this.getClass());
			  return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.GENERIC_ERROR, ServiceConstants.PAYEE_VALIDATE_BIC_SERVICE, httpRequest);
		  		} 
		  finally {
			  endPerformanceLog(logName);
		  	}
	}
	
	private String[] getContactNumber(MobileSession mobileSession) {
		OriginsVO myOriginVO = IBankParams.getOrigin(mobileSession.getOrigin());
		OriginsVO baseOrigin = IBankParams.getOrigin(myOriginVO.getBankName());
		String[] values = { baseOrigin.getBpayPhone() };
		return values;
	}

	private void setReasonFor2FA(ThirdPartyPayment payment) {
		if(null != payment.getSafiRespVO() && null != payment.getSafiRespVO().getSafiAction() && SafiConstants.SAFI_ACTION_CHALLENGE.equalsIgnoreCase(payment.getSafiRespVO().getSafiAction())) {
			payment.setReasonFor2FA(REASON_2FA_SAFI);
			Logger.debug("performTransfer() SAFI responded with 2FA challenge so setting 2FA reason as SAFI.", this.getClass());
		} else {
			payment.setReasonFor2FA(REASON_2FA_EHUB);
			Logger.debug("performTransfer() EHUB threw 2FA challenge so setting 2FA reason as EHUB.", this.getClass());
		}	
	}

	private boolean is2FAExcemptAddPayee(Customer customer) throws BusinessException {
		return IBankSecureService.isGlobalByPass() || IBankSecureService.isCustomerExempt(customer.getIBankSecureDetails());
	}
	
	
	private String get2FAExemptType(Customer customer) throws BusinessException {
		if( IBankSecureService.isGlobalByPass() ){
			return DigitalSecLogger.BYPASS;
		} else if (IBankSecureService.isCustomerExempt(customer.getIBankSecureDetails())){
			return DigitalSecLogger.EXEMPTED;
		} else {
			return DigitalSecLogger.BLANK_CHAR;
		}
	}
	
	private Receipt pay(ThirdPartyPayment payment, MobileSession mobileSession) throws BusinessException {
		Logger.debug("Payment object - " + ReflectionToStringBuilder.toString(payment, ToStringStyle.MULTI_LINE_STYLE), this.getClass());
		Receipt receipt = transactService.performTransfer(payment);
		Logger.debug("Receipt - " + ReflectionToStringBuilder.toString(receipt, ToStringStyle.MULTI_LINE_STYLE), this.getClass());
		// throw new BusinessException(BusinessException.IBANK_SECURE_REQUIRED);
		Customer updatedCustomer = payment.getCommonData().getCustomer();
		mobileSession.setCustomer(updatedCustomer);
		// send email if needed
		if ( (null == mobileSession.getPaymentType() || DE.equalsIgnoreCase(mobileSession.getPaymentType())) 
				&& mobileSession.isSendPaymentEmail() != null && mobileSession.isSendPaymentEmail()) {
			// if an email needs to be sent to customer
			Logger.debug("Sending email: ", this.getClass());
			transactService.sendPayerEmailReceipt(payment, receipt, MBAppHelper.getAccountbyAccountId(payment.getFromAccount(), updatedCustomer
					.getAccounts()), payment.getToThirdParty());
			mobileSession.removeSendPaymentEmail();
		}
		return receipt;
	}
	
	public ErrorResp validate(IMBReq serviceRequest, HttpServletRequest request) {
		Logger.info("Service request object - " + ReflectionToStringBuilder.toString(serviceRequest), this.getClass());
		return mbAppValidator.validate(serviceRequest, request);
	}

	public RespHeader populateResponseHeader(String serviceName, MobileSession mobSession) {
		return mbAppHelper.populateResponseHeader(serviceName, mobSession);
	}
	
	public void validateRequestHeader(ReqHeader headerReq, HttpServletRequest request) throws BusinessException {
		Logger.debug("Request header validation: " + ReflectionToStringBuilder.toString(headerReq, ToStringStyle.MULTI_LINE_STYLE), this.getClass());
		new MBAppValidator().validateRequestHeader(headerReq, request);
	}
	
	@Autowired
	private PerformanceLogger perfLogger;
	
	private String startPerformanceLog(HttpServletRequest httpRequest){
		perfLogger.startAllLogs();
		String logName = MBAppUtils.getLogName(httpRequest);
		perfLogger.startLog(logName);
		return logName;
	}
	
	private void endPerformanceLog(String logName){
		perfLogger.endLog(logName);
		perfLogger.endAllLogs();
	}
	
	private ServiceStationVO populateServiceMessage(long insertionPoint,String channel, IBankCommonData commonData)
	{
		ServiceStationVO serviceStationAdminVo=null;
		try
		{
		 serviceStationAdminVo= serviceStationService.getServiceMessage(insertionPoint, ServiceStationImpl.CHANNEL_MOBILE, commonData);			
		}
		 catch(BusinessException ex){
			Logger.error("An error occurred while getting service station message for mobile accoutn details", ex, this.getClass());
		}
		return serviceStationAdminVo; 
	}
	
	/**
	 * @param request
	 * @param customer
	 * @param commonData
	 * @return
	 * @throws BusinessException
	 */
	private NPPValidations populateNPPValidationsVO(NPPValidationsReq request,Customer customer,IBankCommonData commonData) throws BusinessException {
		NPPValidations nppValidationsVO = new NPPValidations();
		nppValidationsVO.setAmount(new BigDecimal(request.getAmt()));
		nppValidationsVO.setFromAccount(customer.getAccounts().get(request.getFromAccountIndex()));
		nppValidationsVO.setToAccountBsb(customer.getThirdParties().get(request.getToPayeeIndex()).getBsb());
		ThirdParty thirdParty = customer.getThirdParties().get(request.getToPayeeIndex());
		if(thirdParty != null && thirdParty.getAccountNumOsko() != null)
		{
			nppValidationsVO.setToAccountNumber(thirdParty.getAccountNumOsko());
		}
		else{
			nppValidationsVO.setToAccountNumber(nppService.getOskoAccountNumber(thirdParty));
		}
		nppValidationsVO.setBankSetup(customer.getThirdParties().get(request.getToPayeeIndex()).getBankSetup());
		nppValidationsVO.setFirstPaymentDate(customer.getThirdParties().get(request.getToPayeeIndex()).getFirstPaymentDate());
		if (request.getScheduleDetail()!=null && request.getScheduleDetail().getFirstPayDate() != null && !"".equals(request.getScheduleDetail().getFirstPayDate())) {
			Date firstPayDate = DateUtils.StringtoDate(request.getScheduleDetail().getFirstPayDate(), DateUtils.ISO_8601_CALENDAR_DATE_FORMAT_PATTERN);
			nppValidationsVO.setFirstPayDate(firstPayDate);
		}
		nppValidationsVO.setCommonData(commonData);
		return nppValidationsVO;
	}
	
	private NPPValidations populateNPPValidationsVO(PayeeTransferReq request,Customer customer,IBankCommonData commonData,PayIDResolution payIDResolution) throws BusinessException {
		NPPValidations nppValidationsVO = new NPPValidations();
		nppValidationsVO.setAmount(new BigDecimal(request.getAmt()));
		nppValidationsVO.setFromAccount(customer.getAccounts().get(request.getFromAccountIndex()));
		nppValidationsVO.setToAccountBsb(payIDResolution.getIssuer());
		nppValidationsVO.setToAccountNumber(payIDResolution.getAccountNumber());
		nppValidationsVO.setBankSetup(false);
		nppValidationsVO.setCommonData(commonData);
		nppValidationsVO.setSchemeName(payIDResolution.getSchemeName());
		return nppValidationsVO;
	}
	
	private void createOrUpdatePMData2Cookie(HttpServletRequest httpServletRequest,SafiRespVO safiRespVO,HttpServletResponse httpServletResponse){
		
		if(safiRespVO != null){
			Logger.debug("SAFI : PayeeController Read cookie ", this.getClass());
			Cookie pmdata2 = SafiWebHelper.readCookies(httpServletRequest);
			Logger.debug("SAFI : PayeeController.createOrUpdatePMData2Cookie(): PMDATA2 cookie received : "+ pmdata2, this.getClass());
			//create or update cookie and save
			Cookie newCookie = SafiWebHelper.createOrUpdatePmdata2Cookie(httpServletRequest,pmdata2,safiRespVO.getDeviceToken());
			Logger.debug("SAFI : PayeeController.createOrUpdatePMData2Cookie(): Setting PMDATA2 cookie in resp : "+ newCookie.getValue(), this.getClass());
			httpServletResponse.addCookie(newCookie);
			Logger.debug("SAFI : PayeeController.createOrUpdatePMData2Cookie(): PMDATA2 cookie setting resp done: "+ newCookie.getValue(), this.getClass());
		}
	}

	private void handleSafiResponse(ThirdPartyPayment tpPayment,HttpServletRequest httpRequest,HttpServletResponse httpServletResponse) {
		if(tpPayment != null && ThirdPartyTransferHelper.isSafiApplicableForAnalyze(tpPayment) && 
			    tpPayment.getSafiCall() != null && tpPayment.getSafiCall().equalsIgnoreCase(SafiConstants.SAFI_CALL_ANALYZE)) {
			if(tpPayment != null && tpPayment.getSafiRespVO() != null) {
				SafiRespVO safiRespVO = tpPayment.getSafiRespVO();
				Logger.debug("SAFI : PayeeController.handleSafiResponse: safiRespVO not NULL. Updating PMData2 Cookie.",this.getClass());
				createOrUpdatePMData2Cookie(httpRequest,safiRespVO, httpServletResponse);			
			}
		}
	}
	
	private void handleSafiResponseForPayIdResolution(SafiRespVO safiRespVO, HttpServletRequest httpRequest, HttpServletResponse httpServletResponse) {
		if(safiRespVO != null) {
			Logger.debug("SAFI : PayeeController.handleSafiResponseForPayIdResolution: safiRespVO not NULL. Updating PMData2 Cookie.",this.getClass());
			createOrUpdatePMData2Cookie(httpRequest,safiRespVO, httpServletResponse);
		}
	}

	private void notifyCallAndUpdateCookie(HttpServletRequest httpRequest, MobileSession mobileSession, ThirdPartyPayment payment,HttpServletRequest httpServletRequest,HttpServletResponse httpServletResponse ,IBankCommonData commonData,LabelValueMap digitalSecMap,boolean status2FA,boolean isPaymentSuccess) throws BusinessException{
		Logger.debug("SAFI : PayeeController.notifyCallAndUpdateCookie():START", this.getClass());
		if(payment != null){
			//populate the safiPayTranVO for notify call
			SafiWebHelper.populateSafiVOForNotifyThirdPartyPayment(httpRequest, mobileSession, payment, digitalSecMap, status2FA,isPaymentSuccess);
			
			//If Osko payment is going via DE retry then change execution speed before making SAFI notify call
			/*if(SafiConstants.OSKO.equalsIgnoreCase(mobileSession.getPaymentType())) {
				NPPPayment nppPayment = (NPPPayment)payment;
				Logger.debug("nppPayment.isDeRetry() : "+nppPayment.isDeRetry(), this.getClass());
				if(nppPayment.isDeRetry()) {
					if(nppPayment.getSafiPayTranVO() != null){
						nppPayment.getSafiPayTranVO().setPayeeType(SafiConstants.PAY_ANYONE_PAYEE_TYPE);
					}
					Logger.debug("Passing OVER_NIGHT_EXECUTION_SPEED in safi notify...", getClass());
				}
			} */
					
			//SAFI Notify Call
			SafiRespVO safiRespVO = payeeService.notifyCallForThirdPartyTransfer(commonData,payment.getSafiPayTranVO());
			//create or update cookie and save
			createOrUpdatePMData2Cookie(httpServletRequest,safiRespVO , httpServletResponse);
		}
		Logger.debug("SAFI : PayeeController.notifyCallAndUpdateCookie():END", this.getClass());
	}
	
	private void notifyCallAndUpdateCookiePayIdResolution(HttpServletRequest httpRequest, MobileSession mobileSession, HttpServletRequest httpServletRequest,HttpServletResponse httpServletResponse,
			IBankCommonData commonData,LabelValueMap digitalSecMap,boolean status2FA) throws BusinessException {
		
		Logger.debug("SAFI : PayeeController.notifyCallAndUpdateCookiePayIdResolution():START", this.getClass());
		if(mobileSession.getSafiPayTranVOForPayIdResolution() != null) {
			SafiWebHelper.populateSafiVOForNotifyPayIdResolution(httpRequest, mobileSession, digitalSecMap, status2FA);
			
			//SAFI Notify Call
			SafiRespVO safiRespVO = payeeService.notifyCallForPayIdResolution(commonData, mobileSession.getSafiPayTranVOForPayIdResolution());
			
			//create or update cookie and save
			createOrUpdatePMData2Cookie(httpServletRequest, safiRespVO, httpServletResponse);
		}
		Logger.debug("SAFI : PayeeController.notifyCallAndUpdateCookiePayIdResolution():END", this.getClass());
	}
	
	//	This method saves payment and SAFI response details in digital secure log
	private void saveDigitalSecureLog(HttpServletRequest httpRequest, MobileSession mobileSession, IBankCommonData commonData, ThirdPartyPayment payment, boolean is2FADone, boolean paymentSuccess, String caller) throws BusinessException {
		DigitalSecLogggerVO digitalSecLoggerVO = new DigitalSecLogggerVO();
		
		if(caller!=null && 
				(caller.equalsIgnoreCase(ServiceConstants.PAYID_TRANSFER_SERVICE) || 
						caller.equalsIgnoreCase(ServiceConstants.PAYID_TRANSFER_SECURE_SERVICE))){
			digitalSecLoggerVO.setTranName(DigitalSecLogger.TRANSFER_TO_PAYID);
		}else{
			digitalSecLoggerVO.setTranName(DigitalSecLogger.TRANSFER_TO_PAYEE);
		}
		
		digitalSecLoggerVO.setCommonLogData(mbAppHelper.getCommonLogData(commonData));
		digitalSecLoggerVO.setUserAgent(commonData.getUserAgent());
		if(paymentSuccess) {
			digitalSecLoggerVO.setStatus(DigitalSecLogger.SUCCESS);
		} else {
			digitalSecLoggerVO.setStatus(DigitalSecLogger.FAILURE);
		}
		
		LabelValueMap digitalSecMap = mobileSession.getDigitalSecLoggerMap();
		String reasonCode = "";
		if(payment instanceof NPPPayment) {
			reasonCode = ((NPPPayment)payment).getReasonCode();			
		}
		
		String paymentType = mobileSession.getPaymentType();
		if (null == mobileSession.getPaymentType()) {
			paymentType = "";
		}
		String devicePrint =  mobileSession.getSafiLogonInfo()!= null ? mobileSession.getSafiLogonInfo().getDevicePrint() : "";
		
		boolean isMobileApp = ((logonHelper.loadCordova(httpRequest)) == -1) ? false:true;
		SafiForensicInfo safiForensicInfo = populateSafiForensicInfoVO(payment.getSafiRespVO(), devicePrint);
		String digiSecValues = null;
		if(is2FADone){
			digiSecValues = ((ThirdPartyPayment)payment).toDigitalSecurityLog(false,digitalSecMap.get(DigitalSecLogger.AUTHTYPE),digitalSecMap.get(DigitalSecLogger.AUTHPHONE), mobileSession.getPayIDResolution(), null);
		} else {
			digiSecValues = ((ThirdPartyPayment)payment).toDigitalSecurityLog(false,CommonBusinessUtil.get2FAExemptType(commonData.getCustomer()),null, mobileSession.getPayIDResolution(), null);
		}
		/*if(null != payment && payment instanceof NPPPayment && ((NPPPayment)payment).isDeRetry()) {
			digitalSecLoggerVO.setStatus(DigitalSecLogger.FAILURE);
			digitalSecLoggerVO.setValues(((ThirdPartyPayment)payment).toDigitalSecurityLogNPP(digiSecValues, paymentType.equalsIgnoreCase(OSKO) ? "Osko" : "DE", false  TODO : payment.isRetryDEConsent(),reasonCode, safiForensicInfo, isMobileApp, is2FADone));
			digitalSecLogger.log(digitalSecLoggerVO);
			digitalSecLoggerVO.setStatus(DigitalSecLogger.SUCCESS);
			paymentType = "DE";
		}*/
		digitalSecLoggerVO.setValues(((ThirdPartyPayment)payment).toDigitalSecurityLogNPP(digiSecValues, paymentType.equalsIgnoreCase(OSKO) ? "Osko" : "DE", null, reasonCode, safiForensicInfo, isMobileApp, is2FADone));
		digitalSecLogger.log(digitalSecLoggerVO);
		
		mobileSession.removeDigitalSecLoggerMap();
	}
	
	private SafiForensicInfo populateSafiForensicInfoVO(SafiRespVO safiRespVO, String devicePrint) {
		SafiForensicInfo safiForensicInfo = null;
		if(safiRespVO != null) {
			safiForensicInfo = new SafiForensicInfo();
			
			safiForensicInfo.setSafiAction(safiRespVO.getSafiAction());
			safiForensicInfo.setSafiClientTransactionId(safiRespVO.getSafiClientTransactionId());
			safiForensicInfo.setSafiRiskScore(safiRespVO.getSafiRiskScore() != null ? safiRespVO.getSafiRiskScore().toString() : "");
			safiForensicInfo.setSafiRuleName(safiRespVO.getSafiRuleName());
			safiForensicInfo.setSafiSdkDevicePrint(devicePrint);
		}
		return safiForensicInfo;
	}
	
	
	/*
	 * Method to be invoked at every 2 seconds to check paymentsLog table to fetch status of the transaction (SBGEXP-5719)
	 * 
	 * 
	 */
	@RequestMapping(method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE, value = "nppPaymentStatus")
	@ResponseBody
	public IMBResp getNPPPaymentLogStatus(HttpServletRequest httpRequest, @RequestBody final PaymentLogStatusReq request) throws Exception {
		
		Logger.debug("PayeeController - getNPPPaymentLogStatus(). Request: " + request + "PaymentLogID : " + request.getPaymentsLogID(), this.getClass());
		String logName = startPerformanceLog(httpRequest);
		TransferResp response = null;
		MobileSession mobileSession = new MobileSessionImpl(); 
		try {
			mobileSession.getSessionContext(httpRequest);	
			validateRequestHeader(request.getHeader(), httpRequest);
			ErrorResp errorResponse = validate(request, httpRequest);// validate json
			if (errorResponse.hasErrors())
				return errorResponse;
			PaymentsLogVO paymentsLogVO = nppService.getPaymentsLog(request.getPaymentsLogID());
			Logger.debug("Response from nppService : " + paymentsLogVO, this.getClass());
			Account fromAccount = null;
			if(NPPStatus.isSuccess(paymentsLogVO.getStatus())) {
				IBankCommonData commonData = new MBAppHelper().populateIBankCommonData(mobileSession, httpRequest);
				Customer customer = mobileSession.getCustomer();
				String fromAccountNumber = paymentsLogVO.getAccountNumberFrom();
				String fromBsb = paymentsLogVO.getBsbNumberFrom();
				for(Account account : customer.getAccounts()){
					if(account.getAccountId().getAccountNumber().equals(fromAccountNumber)
							&& account.getAccountId().getBsb().equals(fromBsb)){
						fromAccount = account;
					}
				}
				BigDecimal redrawFee = ThirdPartyTransferHelper.getRedrawFeeForLoanAccount(fromAccount);
				transactService.adjustBalance(commonData,fromAccount,null,paymentsLogVO.getAmount(),redrawFee);
			}
			response = payeeHelper
					.populatePaymentLogStatusResp(populateResponseHeader(ServiceConstants.VALIDATE_FOR_NPP_SERVICE, mobileSession),paymentsLogVO,fromAccount);
			
		} catch (BusinessException e) {
			Logger.info("BusinessException in PayeeController - getNPPPaymentLogStatus() - [key: " + e.getKey() + "], GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), e, ServiceConstants.PAYEE_TRANSFER_SERVICE, httpRequest);
		} catch (ResourceException e) {
			Logger.error("ResourceException in PayeeController - getNPPPaymentLogStatus() - [key: " + e.getKey() + "], GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());
			mobileSession.removeNPPEnrichmentDetails();
			mobileSession.removeTransaction();
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.SYSTEM_UNAVILABLE, ServiceConstants.PAYEE_TRANSFER_SERVICE, httpRequest);
		} catch (Exception e) {
			Logger.error("Exception PayeeController - getNPPPaymentLogStatus(): GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			mobileSession.removeNPPEnrichmentDetails();
			mobileSession.removeTransaction();
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.GENERIC_ERROR, ServiceConstants.PAYEE_TRANSFER_SERVICE, httpRequest);
		}
		finally {
			endPerformanceLog(logName);
		}	
		return response;
	}
	
	/**
	 * Method for fetching the Payment Details from the PaymentsLog Id 
	 * 
	 */
	@RequestMapping(method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE, value = "getPaymentInfo")
	@ResponseBody
	public IMBResp getPaymentDetailsForRebmit(HttpServletRequest httpRequest, @RequestBody final PaymentLogStatusReq request) throws Exception {
		Logger.debug("PayeeController - getPaymentDetailsForRebmit(). Request: " + request, this.getClass());
		String logName = startPerformanceLog(httpRequest);
		IMBResp resubmitResponse= null;
		MobileSession mobileSession = new MobileSessionImpl(); 
		try {
			mobileSession.getSessionContext(httpRequest);	
			validateRequestHeader(request.getHeader(), httpRequest);
			ErrorResp errorResponse = validate(request, httpRequest);// validate json
			if (errorResponse.hasErrors())
				return errorResponse;
			mobileSession.setPaymentType(DE);
			mobileSession.setResubmitPayment(Boolean.TRUE);
			PaymentsLogVO paymentsLogVO = nppService.getPaymentsLog(request.getPaymentsLogID());
			resubmitResponse = populatePaymentresponse(paymentsLogVO,mobileSession,populateResponseHeader(ServiceConstants.PAYMENT_RESUBMIT_INFO_SERVICE, mobileSession));
			
			
		} catch (BusinessException e) {
			Logger.info("BusinessException in PayeeController - getPaymentDetailsForRebmit() - [key: " + e.getKey() + "], GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), e, ServiceConstants.PAYEE_TRANSFER_SERVICE, httpRequest);
		} catch (ResourceException e) {
			Logger.error("ResourceException in PayeeController - getPaymentDetailsForRebmit() - [key: " + e.getKey() + "], GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());
			mobileSession.removeNPPEnrichmentDetails();
			mobileSession.removeTransaction();
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.SYSTEM_UNAVILABLE, ServiceConstants.PAYEE_TRANSFER_SERVICE, httpRequest);
		} catch (Exception e) {
			Logger.error("Exception PayeeController - getPaymentDetailsForRebmit(): GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			mobileSession.removeNPPEnrichmentDetails();
			mobileSession.removeTransaction();
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.GENERIC_ERROR, ServiceConstants.PAYEE_TRANSFER_SERVICE, httpRequest);
		}
		finally {
			endPerformanceLog(logName);
		}	
		return resubmitResponse;
	}

	private IMBResp populatePaymentresponse(PaymentsLogVO paymentsLogVO, MobileSession mobileSession, RespHeader respHeader) {

		ResubmitPaymentResp resubmitPaymentResp = new ResubmitPaymentResp(respHeader);
		resubmitPaymentResp.setAmount(String.valueOf(paymentsLogVO.getAmount()));
		
		//AccountId fromAccountID = new AccountId();
		//fromAccountID.setAccountNumber(paymentsLogVO.getAccountNumberFrom() );
		//fromAccountID.setApplicationId(Account.DDA);
		
		//int fromAccountIndex = mbAppHelper.getAccountIndexByAccountId(mobileSession.getCustomer().getAccounts(),fromAccountID);
		
		if (mobileSession != null && mobileSession.getCustomer().getAccounts() != null) {
			for (int i = 0; i < mobileSession.getCustomer().getAccounts().size(); i++) {
				Account account = mobileSession.getCustomer().getAccounts().get(i);

				if (account.getAccountId().getBsb().equals(paymentsLogVO.getBsbNumberFrom())
						&& account.getAccountId().getAccountNumber().equals(paymentsLogVO.getAccountNumberFrom())) {
					resubmitPaymentResp.setFromAccountIndex(mobileSession.getCustomer().getAccounts().get(i).getIndex());
					break;
				}
			}
		}
		//resubmitPaymentResp.setFromAccountIndex(fromAccountIndex);
		
		int toAccIndex = -1;
		
	/*	if ( favTran.isEmailNotifFlag() )
		{
			favTranResp.setSendEmail(true);
		}*/
		if(null != paymentsLogVO.getPayerName() && paymentsLogVO.getPayerName().length() > DE_DESC_MAXLENGTH) {
			resubmitPaymentResp.setPayerName(paymentsLogVO.getPayerName().substring(0, DE_DESC_MAXLENGTH));
		} else {
			resubmitPaymentResp.setPayerName(paymentsLogVO.getPayerName());
		}


		toAccIndex = mbAppHelper.getThirdPartyIndexFromCustomer(mobileSession.getCustomer(), paymentsLogVO.getBsbNumberTo(), paymentsLogVO.getAccountNumberTo());
		
		resubmitPaymentResp.setToItemIndex(toAccIndex);
		if ( toAccIndex >= 0)
		{
			ThirdParty thirdParty = mbAppHelper.getThirdPartyFromCustomer(mobileSession.getCustomer(), toAccIndex);
			if ( thirdParty != null )
			{
				resubmitPaymentResp.setPayerName( "");
				if(null != thirdParty.getPayerName() && thirdParty.getPayerName().length() > DE_DESC_MAXLENGTH) {
					resubmitPaymentResp.setPayerName( thirdParty.getPayerName().substring(0, DE_DESC_MAXLENGTH));
				} else {
					resubmitPaymentResp.setPayerName(thirdParty.getPayerName());
				}  
			}
			else
			{
				resubmitPaymentResp.setSendEmail(false);
			}
		}
		resubmitPaymentResp.setTranType("1");
		
		if(null != paymentsLogVO.getReferenceNumber() && paymentsLogVO.getReferenceNumber().length() > DE_DESC_MAXLENGTH) {
			resubmitPaymentResp.setDesc(paymentsLogVO.getReferenceNumber().substring(0, DE_DESC_MAXLENGTH));
		}else{
			resubmitPaymentResp.setDesc(paymentsLogVO.getReferenceNumber());
		}
		return resubmitPaymentResp;
	}
	
	@RequestMapping(method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE, value = "getPayeesAndBillers")
	@ResponseBody
	public IMBResp getPayeesAndBillers(HttpServletRequest httpRequest, HttpServletResponse httpServletResponse,@RequestBody final EmptyReq request) {
		Logger.debug("PayeeController - getPayeesAndBillers(). Request: " + request, this.getClass());
		String logName = startPerformanceLog(httpRequest);
		MobileSession mobileSession = new MobileSessionImpl(); 
		IBankCommonData commonData = null;
		IMBResp resp = null;
		try {
			mobileSession.getSessionContext(httpRequest);
			commonData = new MBAppHelper().populateIBankCommonData(mobileSession, httpRequest);
			validateRequestHeader(request.getHeader(), httpRequest);
			ErrorResp errorResponse = validate(request, httpRequest);
			if (errorResponse.hasErrors())
				return errorResponse;

			Customer customer = mobileSession.getCustomer();
			resp = payeeHelper.populateAllTypePayeesList(commonData, customer);
			RespHeader headerResp = mbAppHelper.populateResponseHeader(ServiceConstants.PAYEE_TRANSFER_SERVICE, mobileSession);
			resp.setHeader(headerResp);
			return  resp;
			
		} catch (BusinessException e) {
			Logger.info("BusinessException in PayeeController - getPayeesAndBillers() - [key: " + e.getKey() + "], GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), e, ServiceConstants.PAYEE_TRANSFER_SERVICE, httpRequest);
		} catch (ResourceException e) {
			Logger.error("ResourceException in PayeeController - getPayeesAndBillers() - [key: " + e.getKey() + "], GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.SYSTEM_UNAVILABLE, ServiceConstants.PAYEE_TRANSFER_SERVICE, httpRequest);
		} catch (Exception e) {
			Logger.error("Exception PayeeController - getPayeesAndBillers(): GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.GENERIC_ERROR, ServiceConstants.PAYEE_TRANSFER_SERVICE, httpRequest);
		} finally {
			endPerformanceLog(logName);
		}
	}
	
	@RequestMapping(method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE, value = "getPayeesAndBillersAsync")
	@ResponseBody
	public IMBResp getPayeesAndBillersAsync(HttpServletRequest httpRequest, HttpServletResponse httpServletResponse,@RequestBody final EmptyReq request) {
		Logger.debug("PayeeController - getPayeesAndBillersAsync(). Request: " + request, this.getClass());
		String logName = startPerformanceLog(httpRequest);
		MobileSession mobileSession = new MobileSessionImpl(); 
		IBankCommonData commonData = null;
		IMBResp resp = null;
		try {
			perfLogger.startLog("getPayeesAndBillersAsync");
			mobileSession.getSessionContext(httpRequest);
			commonData = new MBAppHelper().populateIBankCommonData(mobileSession, httpRequest);
			//bypassing nameID validation for Async Calls
			//validateRequestHeader(request.getHeader(), httpRequest);
			ErrorResp errorResponse = validateAsync(request, httpRequest);
			if (errorResponse.hasErrors())
				return errorResponse;

			resp = payeeHelper.populateAllTypePayeesListAsync(commonData, mobileSession);
			
			RespHeader headerResp = mbAppHelper.populateAsyncResponseHeader(ServiceConstants.PAYEE_TRANSFER_SERVICE, mobileSession);
			resp.setHeader(headerResp);
			return  resp;
			
		} catch (BusinessException e) {
			Logger.info("BusinessException in PayeeController - getPayeesAndBillersAsync() - [key: " + e.getKey() + "], GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());
			return MBAppUtils.createErrorRespAsync(mobileSession.getOrigin(), e, ServiceConstants.PAYEE_TRANSFER_SERVICE, httpRequest);
		} catch (ResourceException e) {
			Logger.error("ResourceException in PayeeController - getPayeesAndBillersAsync() - [key: " + e.getKey() + "], GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());
			return MBAppUtils.createErrorRespAsync(mobileSession.getOrigin(), new ResourceException(BusinessException.SYSTEM_UNAVILABLE), ServiceConstants.PAYEE_TRANSFER_SERVICE, httpRequest);
		} catch (Exception e) {
			Logger.error("Exception PayeeController - getPayeesAndBillersAsync(): GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			return MBAppUtils.createErrorRespAsync(mobileSession.getOrigin(), new BusinessException(BusinessException.GENERIC_ERROR), ServiceConstants.PAYEE_TRANSFER_SERVICE, httpRequest);
		} finally {
			perfLogger.endLog("getPayeesAndBillersAsync");
			endPerformanceLog(logName);
		}
	}
	
	/**
	 * Delete payee service operation
	 * 
	 * @param httpRequest
	 * @param request
	 * @return
	 */
	@RequestMapping(method = RequestMethod.POST, headers = "content-type=application/json", produces = MediaType.APPLICATION_JSON_VALUE, value = "deletepayidpayee")
	@ResponseBody
	public IMBResp deletePayIdPayee(HttpServletRequest httpRequest, @RequestBody final IndexReq request) {
		Logger.debug("PayeeController - deletePayIdPayee(). Request: " + request, this.getClass());
		String logName = startPerformanceLog(httpRequest);
		MobileSession mobileSession  = new MobileSessionImpl();
		DigitalSecLogggerVO digitalSecLoggerVO = new DigitalSecLogggerVO();
		digitalSecLoggerVO.setTranName(DigitalSecLogger.DELETE_PAYID_PAYEE);
		digitalSecLoggerVO.setStatus(DigitalSecLogger.SUCCESS);
		//PayID Address Book Switch
		try {
			mobileSession.getSessionContext(httpRequest);
			IBankCommonData commonData = new MBAppHelper().populateIBankCommonData(mobileSession, httpRequest);
			Customer customer = mobileSession.getCustomer();
			if(IBankParams.isNPPPayIdAddressBookSwitchON(commonData.getOrigin())) {
				validateRequestHeader(request.getHeader(), httpRequest);
				ErrorResp errorResponse = validate(request, httpRequest);// validate json
				if (errorResponse.hasErrors())
					return errorResponse;

			digitalSecLoggerVO.setCommonLogData(mbAppHelper.getCommonLogData(commonData));
			digitalSecLoggerVO.setUserAgent(commonData.getUserAgent());
			NPPPayIdPayee payIdPayee = customer.getNppPayIdPayees().get(Integer.parseInt(request.getIndex()));
			digitalSecLoggerVO.setValues(NPPUtil.getPayIdDeleteDigitalSecurityLog(payIdPayee));
			nppCommonService.deletePayIdPayee(payIdPayee, commonData);
			
			//	add a statistics log entry for delete pay id event
			Logger.debug("Pay id type for Statistics log delete event:"+payIdPayee.getPayIdType(), getClass());
			NPPUtil.createPayIdPayeeStatisticsLog(commonData, false /*addPayIdEvent*/, NPPUtil.getPayIdTypeForGDW(payIdPayee.getPayIdType()));
			
			//get the updated customer object and set it in session
			Customer updatedCustomer = CustomerService.getCustomer(commonData);
			mobileSession.setCustomer(updatedCustomer);
			digitalSecLogger.log(digitalSecLoggerVO);
			return payeeHelper.populateDeletePayIdPayeeResp(
					populateResponseHeader(ServiceConstants.DELETE_PAYID_PAYEE_SERVICE, mobileSession),
					updatedCustomer.getNppPayIdPayees());
			
			}
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.GENERIC_ERROR,
					ServiceConstants.DELETE_PAYID_PAYEE_SERVICE, httpRequest);

		} catch (BusinessException e) {
			digitalSecLoggerVO.setStatus(DigitalSecLogger.FAILURE);
			digitalSecLogger.log(digitalSecLoggerVO);
			Logger.info("Exception - [key: " + e.getKey() + "], GCIS: ["
					+ ((mobileSession != null && mobileSession.getCustomer() != null)
							? mobileSession.getCustomer().getGcis()
							: "")
					+ "] :", e, this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), e, ServiceConstants.DELETE_PAYID_PAYEE_SERVICE,
					httpRequest);
		} catch (ResourceException e) {
			Logger.info("Exception - [key: " + e.getKey() + "], GCIS: ["
					+ ((mobileSession != null && mobileSession.getCustomer() != null)
							? mobileSession.getCustomer().getGcis()
							: "")
					+ "] :", e, this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.SYSTEM_UNAVILABLE,
					ServiceConstants.DELETE_PAYID_PAYEE_SERVICE, httpRequest);
		} catch (Exception e) {
			digitalSecLoggerVO.setStatus(DigitalSecLogger.FAILURE);
			digitalSecLogger.log(digitalSecLoggerVO);
			Logger.error("Exception PayeeController - deletePayee(): GCIS: ["
					+ ((mobileSession != null && mobileSession.getCustomer() != null)
							? mobileSession.getCustomer().getGcis()
							: "")
					+ "]", e, this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.GENERIC_ERROR,
					ServiceConstants.DELETE_PAYID_PAYEE_SERVICE, httpRequest);
		} finally {
			endPerformanceLog(logName);
		}
	}
	/**
	 * @param payIDResolution
	 *            - PayIDResolution
	 * @param payIDType
	 *            - String
	 * @param customer
	 *            - Customer
	 * @param digitalSecurityLogVO
	 *            - DigitalSecLogggerVO
	 * @param digitalSecLoggerMap
	 *            - LabelValueMap
	 * @param errorCode
	 *            - int
	 * @throws BusinessException
	 */
	private void addPayIdResolutionDigitialSecurityLogger(PayIDResolution payIDResolution, String payIDType,
			Customer customer, DigitalSecLogggerVO digitalSecurityLogVO, LabelValueMap digitalSecLoggerMap,
			int errorCode, boolean isNameChanged) {
		try {
			String authType = CommonBusinessUtil.get2FAExemptType(customer);
			String phone = null;
			if (DigitalSecLogger.BLANK_CHAR.equals(authType)) {
				if (null != digitalSecLoggerMap) {
					authType = digitalSecLoggerMap.get(DigitalSecLogger.AUTHTYPE);
					phone = digitalSecLoggerMap.get(DigitalSecLogger.AUTHPHONE);
				}
			}
			digitalSecurityLogVO.setValues(NPPUtil.getPayIdResolutionDigitalSecurityLog(payIDResolution, payIDType,
					authType, phone, errorCode, isNameChanged));
			digitalSecLogger.log(digitalSecurityLogVO);
		} catch (Exception e) {
			Logger.error("Exception in forensic log in Pay to PayID", e, this.getClass());
		}
	}
	
	/**
	 * @param payIDResolution
	 * @param payIdType
	 * @param customer
	 * @param digitalSecurityLogVO
	 * @param digitalSecurityLoggerMap
	 */
	public void addPayIdResolutionSuccessDigitialLogger(PayIDResolution payIDResolution, String payIdType, Customer customer,
			DigitalSecLogggerVO digitalSecurityLogVO, LabelValueMap digitalSecurityLoggerMap, boolean isNameChanged) {
		addPayIdResolutionDigitialSecurityLogger(payIDResolution, payIdType, customer,
				digitalSecurityLogVO, digitalSecurityLoggerMap, NO_ERROR, isNameChanged);
	}
	/**
	 * @param payToPayIdModel
	 * @param customer
	 * @param digitalSecurityLogVO
	 * @param digitalSecLoggerMap
	 * @param errorCode
	 */
	public void addPayIdResolutionFailureDigitialLogger(String payIDValue, String payIdType, Customer customer,
			DigitalSecLogggerVO digitalSecurityLogVO, LabelValueMap digitalSecLoggerMap, int errorCode) {
		PayIDResolution payIDResolution = new PayIDResolution();
		payIDResolution.setPayIDValue(payIDValue);
		digitalSecurityLogVO.setStatus(DigitalSecLogger.FAILURE);
		addPayIdResolutionDigitialSecurityLogger(payIDResolution, payIdType, customer,
				digitalSecurityLogVO, digitalSecLoggerMap, errorCode, false);
	}
	
	private DigitalSecLogggerVO initializeDigitalLoggerIncreasePayeeLimit(IBankCommonData commonData) {
		DigitalSecLogggerVO digitalSecLoggerVO =new DigitalSecLogggerVO();
		digitalSecLoggerVO.setTranName(DigitalSecLogger.INCREASE_PAYEE_LIMIT_REQUEST);
		digitalSecLoggerVO.setCommonLogData(mbAppHelper.getCommonLogData(commonData));
		digitalSecLoggerVO.setUserAgent(commonData.getUserAgent());
		return digitalSecLoggerVO;
	}
	
	private DigitalSecLogggerVO initializeDigitalLoggerDeccreasePayeeLimit(IBankCommonData commonData) {
		DigitalSecLogggerVO digitalSecLoggerVO =new DigitalSecLogggerVO();
		digitalSecLoggerVO.setTranName(DigitalSecLogger.DECREASE_PAYEE_LIMIT);
		digitalSecLoggerVO.setStatus(DigitalSecLogger.DECREASE_PAYEE_LIMIT_STATUS);
		digitalSecLoggerVO.setCommonLogData(mbAppHelper.getCommonLogData(commonData));
		digitalSecLoggerVO.setUserAgent(commonData.getUserAgent());
		return digitalSecLoggerVO;
	}
	
	/**
	 * SBGEXP-8092 - Fix issue of name id getting generated for async error response
	 *  
	 * @param serviceRequest
	 * @param httpRequest
	 * @return ErrorResp
	 * @throws BusinessException
	 */	
	public ErrorResp validateAsync(IMBReq serviceRequest, HttpServletRequest httpRequest) throws BusinessException {
		return  mbAppValidator.validateAsync(serviceRequest, httpRequest);
	}

	private String[] getPhoneNumber(IBankCommonData commonData) {
		OriginsVO myOriginVO = IBankParams.getOrigin(IBankParams.getBaseOriginCode(commonData.getOrigin()));
		OriginsVO baseOrigin = IBankParams.getOrigin(myOriginVO.getBankName());
		String[] errorParams = {baseOrigin.getPhone()};
		return errorParams;
	}
	
		private void addPayeeDetailsForIncreasePayeeLimitAndLog(ThirdParty payee, DigitalSecLogggerVO digitalSecLoggerVO,
			PhoneNumber phone , SecureCodeDetails secureCodeDetails, String status) {
		StringBuffer sb = new StringBuffer();
			
		sb.append(DigitalSecLogger.FA_MESSAGE_TYPE).append(DigitalSecLogger.DELIMITER_COLON).append(secureCodeDetails.getDeliveryMethod());
		sb.append(DigitalSecLogger.DELIMITER_COMMA).append(DigitalSecLogger.FA_PHONE_NUMBER).append(DigitalSecLogger.DELIMITER_COLON).append(phone.getDisplayPhoneNumber());
		sb.append(DigitalSecLogger.DELIMITER_COMMA).append(DigitalSecLogger.PAYEE_NAME).append(DigitalSecLogger.DELIMITER_COLON).append(payee.getName());
		sb.append(DigitalSecLogger.DELIMITER_COMMA).append(DigitalSecLogger.PAYEE_ACT_NUM).append(DigitalSecLogger.DELIMITER_COLON).append(payee.getAccountNumOsko());
		sb.append(DigitalSecLogger.DELIMITER_COMMA).append(DigitalSecLogger.PAYEE_BSB).append(DigitalSecLogger.DELIMITER_COLON).append(payee.getBsb());
		sb.append(DigitalSecLogger.DELIMITER_COMMA).append(DigitalSecLogger.PAYEE_EMAIL).append(DigitalSecLogger.DELIMITER_COLON).append(payee.getEmailPayee());
		digitalSecLoggerVO.setStatus(status);
		digitalSecLoggerVO.setValues(sb.toString());
		digitalSecLogger.log(digitalSecLoggerVO);
	}
		
		private String getFormattedDate(XMLGregorianCalendar obj, Date paymentDate) {
			String formattedDate = "";
			SimpleDateFormat dateFormate = new SimpleDateFormat("YYYY-MM-dd HH:mm:ss:SSS");
			if (null != obj) {
				formattedDate = dateFormate.format(obj.toGregorianCalendar().getTime());
			}else{
				formattedDate = dateFormate.format(paymentDate);
			}
			return formattedDate;
		}
	
}
