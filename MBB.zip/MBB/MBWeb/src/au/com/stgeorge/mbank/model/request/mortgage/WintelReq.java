package au.com.stgeorge.mbank.model.request.mortgage;

import java.io.Serializable;

import au.com.stgeorge.mbank.model.common.IMBReq;
import au.com.stgeorge.mbank.model.common.ReqHeader;

public class WintelReq implements IMBReq, Serializable {

	private static final long serialVersionUID = 5202245552218156634L;

	private ReqHeader header;
	
	private String logData;
	

	public ReqHeader getHeader() {
		return header;
	}

	public void setHeader(ReqHeader header) {
		this.header = header;
	}

	public String getLogData() {
		return logData;
	}

	public void setLogData(String logData) {
		this.logData = logData;
	}




}
