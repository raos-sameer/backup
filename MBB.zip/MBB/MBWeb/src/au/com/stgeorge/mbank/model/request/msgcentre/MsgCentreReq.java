/**
 * 
 */
package au.com.stgeorge.mbank.model.request.msgcentre;

import javax.validation.constraints.NotNull;

import au.com.stgeorge.ibank.businessobject.BusinessException;
import au.com.stgeorge.mbank.model.common.IMBReq;
import au.com.stgeorge.mbank.model.common.ReqHeader;

/**
 * @author C50216
 *
 */
public class MsgCentreReq implements IMBReq{
	
	private static final long serialVersionUID = -7062454840133308919L;	
	
	private ReqHeader header;
	private String type;

	@NotNull(message = "" + BusinessException.WSVC_INVALID_INPUT_PARAM)
	private Long customerMsgId;
	
	public ReqHeader getHeader()
	{
		return header;
	}
	public void setHeader(ReqHeader header)
	{
		this.header = header;
	}	
	public Long getCustomerMsgId() {
		return customerMsgId;
	}
	public void setCustomerMsgId(Long customerMsgId) {
		this.customerMsgId = customerMsgId;
	}
	public static long getSerialVersionUID() {
		return serialVersionUID;
	}
	public String getType() {
        return type;
	}
	public void setType(String type) {
		this.type = type;
	}	
}
