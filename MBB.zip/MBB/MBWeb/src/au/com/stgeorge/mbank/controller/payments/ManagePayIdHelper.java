package au.com.stgeorge.mbank.controller.payments;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import au.com.stgeorge.framework.common.logging.Logger;
import au.com.stgeorge.framework.common.util.StringMethods;
import au.com.stgeorge.ibank.businessobject.IBankSecureService;
import au.com.stgeorge.ibank.common.cache.IBankParams;
import au.com.stgeorge.ibank.common.cache.IBankRefershParams;
import au.com.stgeorge.ibank.service.businessobject.ManagePayIdService;
import au.com.stgeorge.ibank.util.NPPUtil;
import au.com.stgeorge.ibank.util.StringUtil;
import au.com.stgeorge.ibank.valueobject.Account;
import au.com.stgeorge.ibank.valueobject.ManageExistingPayIdDetails;
import au.com.stgeorge.ibank.valueobject.ManagePayIdAliasDetails;
import au.com.stgeorge.ibank.valueobject.ManagePayIdDetails;
import au.com.stgeorge.ibank.valueobject.PayIdAvailabilityDetails;
import au.com.stgeorge.ibank.valueobject.PayIdDetails;
import au.com.stgeorge.ibank.valueobject.PayIdStatusDetails;
import au.com.stgeorge.ibank.valueobject.RegisterPayIdDetails;
import au.com.stgeorge.ibank.valueobject.database.CodesVO;
import au.com.stgeorge.ibank.valueobject.transfer.IBankCommonData;
import au.com.stgeorge.mbank.model.common.AccountKeyInfoResp;
import au.com.stgeorge.mbank.model.response.payments.CreatePayIdResp;
import au.com.stgeorge.mbank.model.response.payments.ExistingPayIDDetails;
import au.com.stgeorge.mbank.model.response.payments.ManagePayIdResp;
import au.com.stgeorge.mbank.model.response.payments.PayIDSelectionOptions;
import au.com.stgeorge.mbank.model.response.payments.PayIdAccountList;
import au.com.stgeorge.mbank.model.response.payments.PayIdAvailabilityResp;
import au.com.stgeorge.mbank.model.response.payments.PayIdListingResp;
import au.com.stgeorge.mbank.model.response.payments.PayIdRegStatusResp;
import au.com.stgeorge.mbank.model.response.payments.PayIdResp;
import au.com.stgeorge.mbank.util.MBAppHelper;

/**
 * @author c72660
 *
 */
@Service
public class ManagePayIdHelper {
	
	public static final String REGISTRATION_PAYID_STATUS = "Completed";
	
	private static final String AUS_COUNTRY_CODE = "+61-";
	
	@Autowired
	private ManagePayIdService managePayIdService;
	
	@Autowired
	private IBankRefershParams ibankRefreshParams;
	
	public ManagePayIdResp populateManagePayIdResp(){
		ManagePayIdResp managePayIdResp = new ManagePayIdResp();
		managePayIdResp.setIsSuccess(true);
		return managePayIdResp;
	}

	public PayIdResp populateGetPayIdResp(IBankCommonData iBankCommonData, ManagePayIdDetails payIdDtls, MBAppHelper mbAppHelper, String selectedPayIdType) {
			PayIdResp payIdResp = new PayIdResp();
			if(ibankRefreshParams.isNppABNPayIdRegSwitchOn() && null == selectedPayIdType && !payIdDtls.isUpdateFlow() && null != payIdDtls.getPayIdAliasesDetails() && payIdDtls.getPayIdAliasesDetails().size() > 1) {
				Logger.debug("Redirecting to PayId selection page", this.getClass());
				payIdResp.setShowPayIdSelectionPage(true);
				payIdResp.setPayIdSelectionOptions(populatePayIdTypeList(iBankCommonData.getOrigin(), null));
			}
			else {
	            payIdResp.setIsUpdateFlow(payIdDtls.isUpdateFlow());
	            payIdResp.setPayIdStatusCode(payIdDtls.getPayIdStatusCode());
	            payIdResp.setPayIdStatus(payIdDtls.getPayIdStatus());
	            payIdResp.setPayIdStatusDef(payIdDtls.getPayIdStatusDef());
	            payIdResp.setPayIdRegAcctIndex(payIdDtls.getPayIdRegAcctIndex());
	            payIdResp.setShowUpdateBtn(payIdDtls.isShowUpdateBtn());
	            payIdResp.setPayIdAccEligible(payIdDtls.isPayIdAccEligible());
	            payIdResp.setWarningMsgForPayIdAddition(payIdDtls.getWarningMsgForPayIdAddition());
	            if(payIdDtls.isUpdateFlow() || !NPPUtil.AUBN.equals(payIdDtls.getSelectedPayIdType())) {
	            	payIdResp.setPayIdAccountList(getPayeeAccountList(payIdDtls.getEligibleAccountList(),mbAppHelper, null));
	            }
	            else {
	            	payIdResp.setPayIdAccountList(getPayeeAccountList(payIdDtls.getEligibleAbnAccountList(),mbAppHelper, null));
	            }
				
				if (iBankCommonData.getCustomer().getContactDetail() != null) {
					payIdResp.setPayIdNumber(StringUtil.maskPayID(iBankCommonData.getCustomer().getContactDetail().getMobileNumber().getAreaCode()+
																	iBankCommonData.getCustomer().getContactDetail().getMobileNumber().getPhoneNumber()));
				} else {
					payIdResp.setPayIdNumber("");
				}
				if(ibankRefreshParams.isNppABNPayIdRegSwitchOn() && !payIdDtls.isUpdateFlow()) {
					if ( (null == selectedPayIdType && null != payIdDtls.getPayIdAliasesDetails() && payIdDtls.getPayIdAliasesDetails().size() == 1 && payIdDtls.getPayIdAliasesDetails().containsKey(NPPUtil.AUBN))  
							|| (null != selectedPayIdType && NPPUtil.AUBN.equals(selectedPayIdType)) ){
						payIdResp.setPayIdName(payIdDtls.getPayIdShortName());
						payIdResp.setPayIdNumber(StringUtil.formatABN(payIdDtls.getPayIdAliasesDetails().get(NPPUtil.AUBN).getPaymentAliasId()));
						payIdResp.setPayIdType(NPPUtil.PAYID_TYPE_ABNACN);
					}else {
						payIdResp.setPayIdType(NPPUtil.PAYID_TYPE_CONSMOB);
						payIdResp.setPayIdName(StringMethods.changeToTitleCase(iBankCommonData.getCustomer().getDisplayName()));
					}
				}else {
					payIdResp.setPayIdType(NPPUtil.PAYID_TYPE_CONSMOB);
					payIdResp.setPayIdName(StringMethods.changeToTitleCase(iBankCommonData.getCustomer().getDisplayName()));
				}
			}
		return payIdResp;
	}
	
	public CreatePayIdResp populatePayIdCreationResp(RegisterPayIdDetails registerPayIdDetails, IBankCommonData iBankCommonData,MBAppHelper mbAppHelper, Integer accInx, PayIdDetails payIdDetails) {
		CreatePayIdResp createPayIdResp =populatePayIdDestAccount(iBankCommonData.getCustomer().getAccounts().get(accInx), mbAppHelper);
		
		if(ibankRefreshParams.isNppABNPayIdRegSwitchOn() && NPPUtil.PAYID_TYPE_ABNACN.equals(payIdDetails.getPayIdType())) {
			createPayIdResp.setPayIdNumber(StringUtil.formatABN(payIdDetails.getPayIdNumber()));
			createPayIdResp.setPayIdName(payIdDetails.getPayIdName());
		} else if(ibankRefreshParams.isNppABNPayIdRegSwitchOn() && NPPUtil.PAYID_TYPE_CONSMOB.equals(payIdDetails.getPayIdType())) {
			createPayIdResp.setPayIdNumber(payIdDetails.getPayIdMobileNumber());
			createPayIdResp.setPayIdName(payIdDetails.getPayIdName());
		} else {
			createPayIdResp.setPayIdNumber(managePayIdService.formatPayIdMobileNumber(StringUtil.formatPhoneNumber(
					iBankCommonData.getCustomer().getContactDetail().getMobileNumber(), IBankSecureService.PHONE_TYPE_MOBILE, false), false));
			
			createPayIdResp.setPayIdName(StringMethods.changeToTitleCase(iBankCommonData.getCustomer().getDisplayName()));
		}
		if(IBankParams.PAYID_UCM_SUB_CODE_REGD.equals(registerPayIdDetails.getRegStatusCode()) &&
				IBankParams.PAYID_UCM_CODE_ADDR_WBC_0000.equals(registerPayIdDetails.getUpdateResultCode())){
			createPayIdResp.setRegPayIdStatusCode(IBankParams.PAYID_REG_STATUS_UI_SUCCESS);
			createPayIdResp.setRegPayIdStatus(registerPayIdDetails.getRegStatus());
		}else{
			createPayIdResp.setRegPayIdStatusCode(IBankParams.PAYID_REG_STATUS_UI_PROCESSING);
			createPayIdResp.setRegPayIdStatus(registerPayIdDetails.getRegStatus());
		}
		
		createPayIdResp.setRegPayIdStatusDesc(registerPayIdDetails.getStatusDescription());
		createPayIdResp.setShowUpdateBtn(registerPayIdDetails.isShowUpdateBtn());
		createPayIdResp.setPayIdRegIdentifier(registerPayIdDetails.getPayIdRegIdentifier());
		createPayIdResp.setPayIdType(payIdDetails.getPayIdType());
		return createPayIdResp;
	}
	

	public PayIdRegStatusResp populatePayIdRegStatusResp(IBankCommonData iBankCommonData, PayIdStatusDetails payIdStatusDtls, MBAppHelper mbAppHelper) {
		PayIdRegStatusResp payIdRegStatusResp = new PayIdRegStatusResp();
		payIdRegStatusResp.setRegPayIdStatus(payIdStatusDtls.getPayIdStatus());
		payIdRegStatusResp.setRegPayIdStatusCode(payIdStatusDtls.getPayIdStatusCode());
		payIdRegStatusResp.setRegPayIdStatusDesc(payIdStatusDtls.getPayIdStatusDes());
		return payIdRegStatusResp;
	}
	
	
	public PayIdAvailabilityResp populatePayIdAvailabilityResp(PayIdAvailabilityDetails payIdAvailabilityDtls) {
		    
				PayIdAvailabilityResp payIdAvailabilityResp =new PayIdAvailabilityResp();
				payIdAvailabilityResp.setPayIdAvailable(payIdAvailabilityDtls.isPayIdAvailabilityStatus());
				payIdAvailabilityResp.setInstitutionName(payIdAvailabilityDtls.getInstitutionName());
				payIdAvailabilityResp.setCustBrandSilo(payIdAvailabilityDtls.getCustomerBrandSilo());
			    
		return payIdAvailabilityResp;
	}
	
   private List<PayIdAccountList> getPayeeAccountList(Collection<Account> accounts, MBAppHelper mbAppHelper, ManageExistingPayIdDetails existingPayidDetails){
		
	    List<PayIdAccountList> payIdAccountList =null;
		PayIdAccountList payIdAccountResp=null ;
		if(accounts != null && accounts.size() > 0){
			payIdAccountList = new ArrayList<PayIdAccountList>();
			Iterator<Account> it = accounts.iterator();			
			while(it.hasNext()){
				
				payIdAccountResp =new PayIdAccountList();
				Account acct = it.next();
				payIdAccountResp.setAccountIndex(acct.getIndex());
				AccountKeyInfoResp keyInfo = mbAppHelper.getAcctKeyInfoResp(acct);
				payIdAccountResp.setAccountName(acct.getAlias());
				payIdAccountResp.setBsb(acct.getAccountId().getBsb());
				payIdAccountResp.setAccountNumber(acct.getAccountId().getFormattedAccountNumber());
				payIdAccountResp.setBsbDisp(keyInfo.getBsbDisp());
				payIdAccountResp.setAccountNumberDisp(keyInfo.getAccountNumDisp());
				if(acct.getErrorCode() == 0){
					if(!acct.isAccountTermDeposit() || acct.getAccountId().getSubProductCode().equals("80")){
						payIdAccountResp.setAvailBalance(acct.getAvailableBalance());	
					}else{
						payIdAccountResp.setAvailBalance(null);
					}
				}
				if(null != existingPayidDetails && acct.getIndex() == existingPayidDetails.getPayIdRegAcctIndex()) {
					payIdAccountResp.setPayIdRegAcct(true);
				} else {
					payIdAccountResp.setPayIdRegAcct(false);
				}
				payIdAccountList.add(payIdAccountResp);				
			}
		}
		return payIdAccountList;
	}
   
   private CreatePayIdResp populatePayIdDestAccount(Account account, MBAppHelper mbAppHelper){
		
	   CreatePayIdResp createPayIdResp=null ;
		if(account != null){
			     createPayIdResp =new CreatePayIdResp();
			     
				 createPayIdResp.setAccountIndex(account.getIndex());
				 createPayIdResp.setAccountName(account.getAlias());
				 createPayIdResp.setBsb(account.getAccountId().getBsb());
				 createPayIdResp.setAccountNumber(account.getAccountId().getAccountNumber());
				 AccountKeyInfoResp keyInfo = mbAppHelper.getAcctKeyInfoResp(account);
				 createPayIdResp.setBsbDisp(keyInfo.getBsbDisp());
				 createPayIdResp.setAccountNumberDisp(keyInfo.getAccountNumDisp());
				}
		return createPayIdResp;
	}
   
   
   public String formatPayIdMobileNumber(String number) {
		String formattedNumber = number.replaceAll(" ", "").trim();
		// Remove leading 0 for Mobile Number
		if (number.trim().startsWith("0")) {
			formattedNumber = formattedNumber.substring(1);
		}
		formattedNumber = AUS_COUNTRY_CODE + formattedNumber;
		return formattedNumber;
	}
   
   public List<PayIDSelectionOptions> populatePayIdTypeList(String origin, List<String> excludePayIdTypes) {
		List<CodesVO> payIdTypeCodes = (List<CodesVO>)(IBankParams.getCodesDataList(origin, "ManagePayIdTypes"));
		
		List<PayIDSelectionOptions> payIdTypeList = new ArrayList<PayIDSelectionOptions>(payIdTypeCodes.size());
		for(int i=0;i<payIdTypeCodes.size();i++) {
			payIdTypeList.add(i, null);
		}
		
		Iterator<CodesVO> iterator = payIdTypeCodes.iterator();
		
		while (iterator.hasNext()) {
			CodesVO codesVO = (CodesVO)iterator.next();
			String payIdType = codesVO.getCode().substring(2);
			int position = Integer.parseInt(codesVO.getCode().substring(0,1));
			if(excludePayIdTypes == null || (excludePayIdTypes != null && !excludePayIdTypes.contains(payIdType) ) ) {
				PayIDSelectionOptions option = new PayIDSelectionOptions();
				option.setPayIdType(payIdType);
				option.setPayIdDisplayName(codesVO.getMessage());
				payIdTypeList.set(position-1, option);
			}
		}
		//Filtering null elements from above list
		payIdTypeList = payIdTypeList.stream()
        		.filter(x -> x != null)
        		.collect(Collectors.toList());
		
		return payIdTypeList;
	}
	
   public PayIdListingResp populateListingPagePayIdResp(IBankCommonData iBankCommonData, ManagePayIdDetails payIdDtls, MBAppHelper mbAppHelper) {
	   PayIdListingResp payIdResp = new PayIdListingResp();
		
	   payIdResp.setShowPayIdListingPage(payIdDtls.isUpdateFlow());
	   payIdResp.setExistingPayIds(new ArrayList<ExistingPayIDDetails>());
	   payIdDtls.getActivePayIdDetailsMap().forEach((payIdType, existingPayIdDetails) -> {
		    ExistingPayIDDetails existPayIdResp = new ExistingPayIDDetails();
		    existPayIdResp.setIsUpdateFlow(existingPayIdDetails.isUpdateFlow());
		    existPayIdResp.setPayIdStatusCode(existingPayIdDetails.getPayIdStatusCode());
		    existPayIdResp.setPayIdStatus(existingPayIdDetails.getPayIdStatus());
		    existPayIdResp.setPayIdStatusDef(existingPayIdDetails.getPayIdStatusDef());
		    existPayIdResp.setPayIdRegAcctIndex(existingPayIdDetails.getPayIdRegAcctIndex());
		    existPayIdResp.setShowUpdateBtn(existingPayIdDetails.isShowUpdateBtn());
		    existPayIdResp.setIsPayIdAccEligible(true);//TODO: need to correct this hardcoding. This information needs call to WDP to determine if acc is still eligible for ABN payids. need to check with Ada/Jay
		    
       		if(NPPUtil.AUBN.equals(payIdType.getValue())) {
       			existPayIdResp.setPayIdType(NPPUtil.PAYID_TYPE_ABNACN);
       			existPayIdResp.setPayIdNumber(StringUtil.formatABN(existingPayIdDetails.getPayIdNumber()));
       			existPayIdResp.setCurrentLinkedAcct(getCurrentLinkedAccount(iBankCommonData.getCustomer().getAccounts(), mbAppHelper, existingPayIdDetails.getPayIdRegAcctIndex()));
			} else {
				existPayIdResp.setPayIdType(NPPUtil.PAYID_TYPE_CONSMOB);
				existPayIdResp.setPayIdNumber(StringUtil.maskPayID(existingPayIdDetails.getPayIdNumber()));
				existPayIdResp.setCurrentLinkedAcct(getCurrentLinkedAccount(payIdDtls.getEligibleAccountList(), mbAppHelper, existingPayIdDetails.getPayIdRegAcctIndex()));
			}
       		existPayIdResp.setPayIdName(existingPayIdDetails.getPayIdName());
       		payIdResp.getExistingPayIds().add(existPayIdResp);
	   });
       		
	   payIdResp.setShowAddNewPayIdBtn(managePayIdService.showAddPayIdButton(payIdDtls));
	   
	   List<String> excludePayIdTypes = filterExistingPayIdTypes(payIdDtls);
	   
	   payIdResp.setPayIdSelectionOptions(populatePayIdTypeList(iBankCommonData.getOrigin(), excludePayIdTypes));
	   return payIdResp;
	}
   
   private PayIdAccountList getCurrentLinkedAccount(Collection<Account> accounts, MBAppHelper mbAppHelper, int selectedAcctIndex){
		PayIdAccountList payIdAccountResp=null ;
		if(accounts != null && accounts.size() > 0){
			Iterator<Account> it = accounts.iterator();			
			while(it.hasNext()){
				Account acct = it.next();
				if(selectedAcctIndex == acct.getIndex()) {
					payIdAccountResp =new PayIdAccountList();
					payIdAccountResp.setAccountIndex(acct.getIndex());
					AccountKeyInfoResp keyInfo = mbAppHelper.getAcctKeyInfoResp(acct);
					payIdAccountResp.setAccountName(acct.getAlias());
					payIdAccountResp.setBsb(acct.getAccountId().getBsb());
					payIdAccountResp.setAccountNumber(acct.getAccountId().getFormattedAccountNumber());
					payIdAccountResp.setBsbDisp(keyInfo.getBsbDisp());
					payIdAccountResp.setAccountNumberDisp(keyInfo.getAccountNumDisp());
					return payIdAccountResp;
				}
			}
		}
		return payIdAccountResp;
	}
   
   public List<String> filterExistingPayIdTypes( ManagePayIdDetails payIdDtls) {
	   List<String> excludePayIds = payIdDtls.getActivePayIdDetailsMap().entrySet().stream()
               .map(x -> x.getKey().getValue())
               .collect(Collectors.toList());
	   return excludePayIds;
   }
   
   
   public PayIdResp populateChangeLinkedAcctResp(IBankCommonData iBankCommonData, ManagePayIdDetails payIdDtls, MBAppHelper mbAppHelper, String selectedPayIdType) {
		PayIdResp payIdResp = new PayIdResp();
		   payIdResp.setIsUpdateFlow(payIdDtls.isUpdateFlow());
		   payIdResp.setWarningMsgForPayIdAddition(payIdDtls.getWarningMsgForPayIdAddition());
           if(!NPPUtil.AUBN.equals(selectedPayIdType)) {
        	    payIdResp.setPayIdType(NPPUtil.PAYID_TYPE_CONSMOB);
        	    payIdResp.setPayIdAccountList(getPayeeAccountList(payIdDtls.getEligibleAccountList(),mbAppHelper, payIdDtls.getActivePayIdDetailsMap().get(ManageExistingPayIdDetails.PayIdTypeEnum.valueOf(selectedPayIdType))));
           } else {
        	   payIdResp.setPayIdType(NPPUtil.PAYID_TYPE_ABNACN);
           	   payIdResp.setPayIdAccountList(getPayeeAccountList(payIdDtls.getEligibleAbnAccountList(),mbAppHelper, payIdDtls.getActivePayIdDetailsMap().get(ManageExistingPayIdDetails.PayIdTypeEnum.valueOf(selectedPayIdType))));
           }
        return payIdResp;
   }
   
}
