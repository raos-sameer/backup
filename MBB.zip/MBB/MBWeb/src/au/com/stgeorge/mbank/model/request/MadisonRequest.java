package au.com.stgeorge.mbank.model.request;

import au.com.stgeorge.mbank.model.common.IMBReq;
import au.com.stgeorge.mbank.model.common.ReqHeader;

public class MadisonRequest implements IMBReq{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -3209035438234606905L;
	private ReqHeader header;
	private String madisonGDWAction;
	private String source;
	private boolean allowLogout;
	
	
	public boolean isAllowLogout() {
		return allowLogout;
	}

	public void setAllowLogout(boolean allowLogout) {
		this.allowLogout = allowLogout;
	}

	public String getMadisonGDWAction() {
		return madisonGDWAction;
	}

	public void setMadisonGDWAction(String madisonGDWAction) {
		this.madisonGDWAction = madisonGDWAction;
	}

	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}

	public ReqHeader getHeader() {
		return header;
	}

	public void setHeader(ReqHeader header) {
		this.header = header;
	}


}
