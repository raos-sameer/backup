/**
 * 
 */
package au.com.stgeorge.mbank.model.accountinfo;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
/**
 * @author C50216
 *
 */

@JsonInclude(Include.NON_NULL)
public class TDAFlexiDetailResp {

	private String originalFundAmt;
	private String remainFundAmt;
	
	public String getOriginalFundAmt() {
		return originalFundAmt;
	}
	public void setOriginalFundAmt(String originalFundAmt) {
		this.originalFundAmt = originalFundAmt;
	}
	public String getRemainFundAmt() {
		return remainFundAmt;
	}
	public void setRemainFundAmt(String remainFundAmt) {
		this.remainFundAmt = remainFundAmt;
	}
	
	
	
}
