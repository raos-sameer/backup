package au.com.stgeorge.mbank.model.common;

import java.io.Serializable;

import au.com.stgeorge.framework.common.util.StringMethods;
import au.com.stgeorge.ibank.common.cache.IBankParams;
import au.com.stgeorge.ibank.util.StringUtil;
import au.com.stgeorge.ibank.valueobject.Account;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_NULL)
public class AccountKeyInfoResp implements Serializable {
	private static final long serialVersionUID = -2499114819421876862L;
	private int accountIndex;
	private String accountType;
	private int bsb;
	private String accountNum;
	private String accountName;
	private String formattedBsb;
	private String accountNumOsko;	

	public int getAccountIndex() {
		return accountIndex;
	}

	public void setAccountIndex(int accountIndexs) {
		this.accountIndex = accountIndexs;
	}

	public String getAccountType() {
		return accountType;
	}

	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}

	@JsonInclude(Include.NON_DEFAULT)
	public int getBsb() {
		return bsb;
	}

	public void setBsb(int bsb) {
		this.bsb = bsb;
	}

	public String getAccountNum() {
		return accountNum;
	}

	public void setAccountNum(String accountNum) {
		this.accountNum = accountNum;
	}

	public String getAccountName() {
		return accountName;
	}

	public void setAccountName(String accountName) {
		this.accountName = accountName;
	}

	public String getFormattedBsb() {
		return formattedBsb;
	}

	public void setFormattedBsb(String formattedBsb) {
		this.formattedBsb = formattedBsb;
	}

	public String getAccountNumOsko() {
		return accountNumOsko;
	}

	public void setAccountNumOsko(String accountNumOsko) {
		this.accountNumOsko = accountNumOsko;
	}
	public String getAccountNumDisp() {
		String applicationId = accountType;
		if (applicationId == null) {
			return StringUtil.formatDDAAccountNumber(accountNum);
			// return accountNumber;
		} else if (Account.LIS.equals(applicationId) || Account.NOM.equals(applicationId)) {
			// return StringUtil.formatLISAccountNumber(accountNumber);
			return StringUtil.formatCompassAccountNumber(accountNum);
		} else if (Account.CRA.equals(applicationId)) {
			
			if(IBankParams.isSwitchOn(IBankParams.CARD_NUM_MASK_SWITCH))
				return StringUtil.formatCardNumber(accountNum);
			else
				return StringUtil.formatCCSAccountNumber(accountNum);
			// return accountNumber;
		} else {
			// This is commented in 10R3 for correcting the account number formatting
			// if (accountNumber.length() == 10){
			if (Account.CDA.equals(applicationId)) {
				return StringUtil.formatCDAAccountNumber(accountNum);
			}
			// }
			return StringUtil.formatDDAAccountNumber(accountNum);
			// return accountNumber;
		}

	}

	public String getBsbDisp() {
		if (bsb > 0) {
			String tempBsb = StringUtil.padLeadingString(String.valueOf(bsb), 6, '0');
			return StringUtil.formatBSBNumber(tempBsb);
		} else
			return null;

	}
	
	public String getAccountNumOskoDisp() {		
		if(accountNumOsko != null && !StringMethods.isEmptyString(accountNumOsko)){
			return StringUtil.formatThirdPartyAccountNumber(accountNumOsko);		
		}else
			return null;
	}
}
