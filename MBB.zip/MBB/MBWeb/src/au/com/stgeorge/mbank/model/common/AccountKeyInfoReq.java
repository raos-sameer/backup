package au.com.stgeorge.mbank.model.common;

import java.io.Serializable;

import javax.validation.constraints.Pattern;

import org.apache.commons.lang.builder.ReflectionToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;
import org.hibernate.validator.constraints.NotEmpty;
import org.hibernate.validator.constraints.Length;

import au.com.stgeorge.ibank.businessobject.BusinessException;
import au.com.stgeorge.mbank.util.ServiceConstants;

public class AccountKeyInfoReq implements Serializable {
	private static final long serialVersionUID = -4735038678628838163L;
	private static final String BLOCK_CHARS_PATTERN = "^[0-9A-Za-z',. &/\\-]*$";
	private static final String ACC_NUM = "^(([0-9])+){1,9}$";

	@NotEmpty(message = "" + BusinessException.ACCOUNT_NO_THIRD_PARTY_BSB)
	@Length(min = ServiceConstants.BSB_LENGTH, max = ServiceConstants.BSB_LENGTH, message = "" + BusinessException.ACCOUNT_INVALID_BSB)
	@Pattern(regexp = "[\\d]{6}", message = "" + BusinessException.ACCOUNT_INVALID_BSB)
	private String bsb;

	@NotEmpty(message = "" + BusinessException.ACCOUNT_NO_THIRD_PARTY_ACCT)
	@Pattern(regexp = ACC_NUM, message = "{errors.invalid.tpaccountlength}")
	private String accountNum;

	@NotEmpty(message = "" + BusinessException.ACCOUNT_NO_THIRD_PARTY_NAME)
	@Length(max = ServiceConstants.THIRDPARTY_MAX_NAME_LEN, message = "{errors.accountName.maxlength}")
	@Pattern(regexp = BLOCK_CHARS_PATTERN, message = "{errors.accountName.blockchar}")
	private String accountName;

	public String getAccountNum() {
		return accountNum;
	}

	public String getAccountName() {
		return accountName;
	}

	public String getBsb() {
		return bsb;
	}
	
	@Override
	public String toString() {
		return ReflectionToStringBuilder.toString(this, ToStringStyle.MULTI_LINE_STYLE);
	}

}
