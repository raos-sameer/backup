package au.com.stgeorge.mbank.controller;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.AbstractController;

import au.com.stgeorge.framework.common.logging.Logger;
import au.com.stgeorge.ibank.businessobject.BusinessException;
import au.com.stgeorge.ibank.businessobject.ContentManagementService;
import au.com.stgeorge.ibank.businessobject.SystemInformation;
import au.com.stgeorge.ibank.common.cache.IBankParams;
import au.com.stgeorge.ibank.common.cache.IBankRefershParams;
import au.com.stgeorge.ibank.common.cache.IBankRefreshParamsImpl;
import au.com.stgeorge.ibank.util.CommonBusinessUtil;
import au.com.stgeorge.ibank.util.ServiceHelper;
import au.com.stgeorge.ibank.util.StringUtil;
import au.com.stgeorge.ibank.valueobject.database.CodesVO;
import au.com.stgeorge.ibank.valueobject.database.OriginsVO;
import au.com.stgeorge.mbank.controller.customer.CookieLogonBean;
import au.com.stgeorge.mbank.controller.customer.LogonHelper;
import au.com.stgeorge.mbank.util.MBAppUtils;
import au.com.stgeorge.perflogger.PerformanceLogger;
import au.com.stgeorge.security.util.StringMethods;
import au.com.stgeorge.mbank.util.GDPRWebHelper;

public class MainController extends AbstractController
{

	private static volatile int numberOfRequests = 0;
	public static final String REQ_ACTION_STR = "action";
	private static final String REQ_IGNORE_SEC_FLAG =  "SIMPLE-LOGON" ;
	private static final String REQ_NORMAL_LOGON = "NORMAL";
	private static final String REQ_DASHBOARD = "DASHBOARD";   // Used by Native App logon My accounts
	private static final String REQ_ACTIVATION_LOGON = "ACTIVATION";
	private static final String REQ_PWD_RESET = "PWDRESET";
	public static final String CHAT = "chat/";
	public static final String MAIN_VIEW = "Index";
	private static final String ERROR_VIEW = "404";
	public static final String REQ_LOAD_CORDOVA = "LoadCordova";
	public static final String PWD_RESET_URL = "PwdResetURL";
	public static final String HELP_DESK_NO = "HelpDeskNo";

	public static final String NUM_KEYBOARD_TYPE = "NumKeyBoardType";
	public static final String NUM_KEYBOARD_PATTERN_TYPE = "NumKeyBoardTypePattern";
	
	public static final String SYS_VERSION = "SysVersion";
	public static final String ORIGIN_NAME = "OriginName";
	
	
	public static final String PRELOAD_VALUE = "PreLoadParam";
	public static final String WEB_CONTEXT = "WebContext";
	
	public static final String REQ_ACTION_TYPE = "ActionType";  // Used By GCC and BT Now...
	public static final String APPLY_GCC ="applyGCC";
	public static final String SERVICE_MENU ="serviceMenu";
	public static final String APPLY_BT ="applyBT";
	public static final String BT_SUPER_SEARCH ="btSuperSearch";
	public static final String CHANGE_CARD_PIN ="changeCardPIN";
	public static final String REQ_ALLOWS_APPACTION_POST = "AppActionPost";
	public static final String CAN_RETRIEVAL_URL = "CANRetrievalURL";
	public static final String PWD_URL = "PwdURL";
	public static final String GDW_ACTION_CONNECT = "PHLNK";
	public static final String GDW_ACTION_MB = "MBLNK";
	public static final String REQ_ACTION_SOURCE = "ActionSource";
	public static final String REQ_ACTION_ID = "ActionId";  //
	public static final String ONBOARDING_STATUS ="Onboardingstatus";
	public static final String GET_CASH_INDICATOR = "getcashind";
	public static final String ONLINE_REG_SWITCH = "OnlineRegSwitch";
	public static final String TAGGING_SWITCH = "TaggingSwitch";
	public static final String ANDROID_BACK_BTN = "androidback";
	private static final String ACTION_TYPE_OPEN_ACCT = "openAcct";
	private static final String CUST_TYPE = "custType";
	private static final String PROD_TYPE = "product";
	private static final String CUST_TYPE_SOLE_TRADER = "soleTrader";
	private static final String CUST_TYPE_SOLE_DIRECTOR = "soleDirector";
	private static final String PROD_TYPE_FREEDOM_BUSINESS = "freedomBusiness";
	private static final String PROD_TYPE_SAVING_BUSINESS = "savingBusiness";
	private static final String ACTION_TYPE_SOLE_FREEDOM_BUSINESS = "busFreedomSol";
	private static final String ACTION_TYPE_SOLE_SAVING_BUSINESS = "busSaverSol";
	private static final String ACTION_TYPE_SOLE_DIR_FREEDOM_BUSINESS = "busFreedomSolDir";
	private static final String ACTION_TYPE_SOLE_DIR_SAVING_BUSINESS = "busSaverSolDir";
	public static final String ECONTRACT_DEEPLINK ="sPlsecpage";
	public static final String CONTENT_ID = "ContentId";
	public static final String LEAD_ID = "leadId";
	private static final String BLOCK_CHARS = "^[0-9A-Za-z',. &/\\-_]*$";
	
	public static final String AEM_DIGEST = "aemDigester";
	public static final String DEMO = "isDemo";
	public static final String TT_ID = "tid";
	public static final String P_ID = "pid";
	public static final String CAMPAIGN_CODE = "campaignCode";
	public static final String LOCATION_ID = "locationId";
	public static final String FIX_BOTTOM_MENU_SWITCH = "FixMenuIconSwitch";
	
	//20E4 Live Person switch
	public static final String LP_MESSAGING_SWITCH = "lpMessagingSwitch";
	public static final String LP_NATIVE_OLD_APP_SWITCH="lpNativeOldApp";
	
	public static final String F_ID = "fid";
	public static final String C_ID = "cid";
	
	//20E2 - CSH tile deeplink action
	private static final String HOME_LOAN_APP_TRACKER ="homeLoanAppTracker";
	
	//20E3 - CSH  prepareonline 
	private static final String CSH_PREPARE_ONLINE ="prepareOnline";
	public static final String PURPOSE = "purpose";
	public static final String OPPORTUNITY_ID = "oid";
	public static final String LENDER_ID = "lid";
	public static final String HMAC = "a";
	public static final String STAGE = "stage";
	public static final String JOINT = "jnt";
	public static final String SID = "sid";
	public static final String CTX = "ctx";
	
	
	
	@Override
	protected ModelAndView handleRequestInternal(HttpServletRequest request, HttpServletResponse response) throws Exception
	{
		//PerformanceLogger performanceLogger = new PerformanceLogger();
		//performanceLogger.startAllLogs();
		//String logName = MBAppUtils.getLogName(request);
		//performanceLogger.startLog(logName);
		
		ModelAndView model = null;
		String origin = null;
		String numKeyType = null;
		String numKeyTypePattern = null;
		try
		{
			numberOfRequests ++;
			logonHelper.setWebReadyCookie(request, response , "0" );
			
			boolean isDemo = logonHelper.isDemo();
			
			if ( isDemo )
			{
				origin = logonHelper.resolveDemoOrigin( request);	
				HttpSession httpSession = request.getSession();
				Logger.info(" Demo Details "+ origin  + " httpSession.isNew() "+ httpSession.isNew() + " httpSession ID :"+ httpSession.getId() , this.getClass());
				if ( ! httpSession.isNew() )
				{
					Object originObj = request.getParameter("origin");
					if ( originObj != null  )
					{
						if ( origin.trim().length() == 3 )
							origin = "M"+(String) originObj; 
					} 
					else if  ( httpSession.getAttribute(LogonHelper.ORIGIN) != null )
					{
						origin = (String) httpSession.getAttribute(LogonHelper.ORIGIN);
					}
					
					if ( StringMethods.isEmptyString(origin ) )
					{
						origin = "MSTG";
					}
					httpSession.invalidate();
					httpSession = request.getSession();
					Logger.info(" Demo Details ( New ) "+ origin  + " httpSession.isNew() "+ httpSession.isNew() + " httpSession ID :"+ httpSession.getId() , this.getClass());
				}
				httpSession.setAttribute(LogonHelper.ORIGIN, origin);
				
				String aemContentDigest = StringMethods.safeString(request.getParameter(ContentManagementService.AEM_DIGEST), "");
				
				Logger.info(" aemContentDigest :  "+ aemContentDigest , this.getClass());
				request.setAttribute(MainController.AEM_DIGEST, aemContentDigest);
				request.setAttribute(MainController.DEMO, "true");

				
			}
			else
			{
				origin = logonHelper.resolveOrigin(request);
			}

			request.setAttribute(MainController.WEB_CONTEXT, logonHelper.getMBWebResourceContext());
			
			if ( StringMethods.isEmptyString(origin) )
			{
				origin = "MSTG";
				request.setAttribute(LogonHelper.ORIGIN, origin);
				Logger.info("Unable to resolve the origin  Request Details. URL : "+ request.getRequestURL() + " IP :" + request.getRemoteAddr() + " Number Of Requests : "+ numberOfRequests +
						" True IP >> " + request.getHeader(IBankParams.trueClientIP()), this.getClass());
				model = new ModelAndView(ERROR_VIEW);
			}
			else
			{
				request.setAttribute(LogonHelper.ORIGIN, origin);
				request.setAttribute(PRELOAD_VALUE, 2);  // Complete
				
				numKeyType =  logonHelper.getNumKeyBoardType(request);
				numKeyTypePattern =  logonHelper.getNumKeyBoardPattern(request);
				request.setAttribute(NUM_KEYBOARD_TYPE, numKeyType);
				request.setAttribute(NUM_KEYBOARD_PATTERN_TYPE, numKeyTypePattern);
				if ( this.systemInformation == null )
				{
					Logger.info("************ Loading systemInformation *************** "+ request.getRequestURL()   , this.getClass());
					this.systemInformation = getSystemInformationDtls();
				}
				request.setAttribute(SYS_VERSION, this.systemInformation.getMB3PackageVersion());
				OriginsVO originVO = IBankParams.getOrigin(origin);
				request.setAttribute(ORIGIN_NAME, originVO.getName());
			//	
				String pwdResetUrl = IBankParams.getCodesData( originVO.getBankName(),IBankParams.EXTERNAL_LINKS,  PWD_URL).getMessage();	
				request.setAttribute(PWD_RESET_URL, pwdResetUrl);
				
				String canRetrievalUrl = IBankParams.getCodesData( originVO.getBankName(),IBankParams.EXTERNAL_LINKS,  CAN_RETRIEVAL_URL).getMessage();
				request.setAttribute(CAN_RETRIEVAL_URL, canRetrievalUrl);
				
				request.setAttribute(HELP_DESK_NO, originVO.getPhone());
				
				String onlineRegSwitch = "ON";
				CodesVO codesVO = IBankParams.getCodesData(origin,	IBankParams.CONFIGURATION_PROPERTIES, IBankParams.ONLINE_REG_SWITCH);
				if ( codesVO != null  && "OFF".equalsIgnoreCase(codesVO.getMessage())){
					onlineRegSwitch = "OFF";
				}
				request.setAttribute(ONLINE_REG_SWITCH, onlineRegSwitch);
				String taggingSwitch = "ON";
				codesVO = IBankParams.getCodesData(origin,	IBankParams.CONFIGURATION_PROPERTIES, TAGGING_SWITCH);
				if ( (codesVO == null) || codesVO != null  && "OFF".equalsIgnoreCase(codesVO.getMessage())){
					taggingSwitch = "OFF";
				}
				request.setAttribute(TAGGING_SWITCH, taggingSwitch);
				String fixBottomMenuSwitchVal = "ON";
				codesVO = IBankParams.getCodesData(origin,	IBankParams.CONFIGURATION_PROPERTIES, FIX_BOTTOM_MENU_SWITCH);
				if ( (codesVO == null) || codesVO != null  && "OFF".equalsIgnoreCase(codesVO.getMessage())){
					fixBottomMenuSwitchVal = "OFF";
				}
				request.setAttribute(FIX_BOTTOM_MENU_SWITCH, fixBottomMenuSwitchVal);
				
				String lpMessagingSwitch = "OFF";
				String baseOrigin = IBankParams.getBaseOriginCode(origin);
				codesVO = IBankParams.getCodesData(baseOrigin,	IBankParams.CONFIGURATION_PROPERTIES, IBankParams.LP_MESSAGING_SWITCH);
				if ( (codesVO == null) || codesVO != null  && "ON".equalsIgnoreCase(codesVO.getMessage())){
					lpMessagingSwitch = "ON";
				}
				request.setAttribute(LP_MESSAGING_SWITCH, lpMessagingSwitch);
				
				Cookie appVersionCookie = CommonBusinessUtil.getCookie(request, IBankParams.APP_VER_COOKIE);
				Boolean isLpOldAppVersion = !CommonBusinessUtil.cookieContainsValue(appVersionCookie, CHAT);
				if(isLpOldAppVersion) {
					request.setAttribute(LP_NATIVE_OLD_APP_SWITCH, IBankParams.ON);
				}else {
					request.setAttribute(LP_NATIVE_OLD_APP_SWITCH, IBankParams.OFF);
				}
								
				
				request.setAttribute(ANDROID_BACK_BTN, "ON");
				
				String campaignCode = (String) request.getParameter(CAMPAIGN_CODE);		
				if (!StringMethods.isEmptyString(campaignCode)) {
					request.setAttribute(CAMPAIGN_CODE, campaignCode);
				}	
				
				model = new ModelAndView(MAIN_VIEW);
				Logger.info(originVO.toXml() + " \nInside Main Controller  Request Details. URL : "+ request.getRequestURL() + " IP :" + request.getRemoteAddr() + " Number Of Requests : "+ numberOfRequests +
						" True IP >> " + request.getHeader(IBankParams.trueClientIP()), this.getClass());
				findPageToBeDsiaplyed(request, response, origin);
				gdprWebHelper.gdpr(origin, request, response);
			}
			return model;
		}
		catch ( Exception e)
		{
			origin = "MSTG";
			request.setAttribute(LogonHelper.ORIGIN, origin);
			model = new ModelAndView(ERROR_VIEW);
			Logger.error("Error in Main Controller " , e, this.getClass());
			return model;
		}
		finally
		{
			IBankRefershParams iBankRefreshParams =  (IBankRefershParams)ServiceHelper.getBean("ibankRefreshParams");
			boolean logonSpeedSwitch = iBankRefreshParams.isNativeLogonSpeedSwitch(origin);
			String nativeSwitchVal = "false";
			if (logonSpeedSwitch) {
				nativeSwitchVal = "true";
			}
			request.setAttribute(IBankRefreshParamsImpl.NATIVE_LOGON_SPEED_SWITCH, nativeSwitchVal);
			numberOfRequests--;
			//performanceLogger.endLog(logName);
			//performanceLogger.endAllLogs();
		}
	}

	private void findPageToBeDsiaplyed(HttpServletRequest request, HttpServletResponse response, String origin) throws BusinessException
	{
		CookieLogonBean cookieBean = logonHelper.populateCookieLogonBean(request);
		
		if ( cookieBean != null )
		Logger.info(" Screen Type " +cookieBean.isIgnoreSec() , this.getClass());

		if (request.getRequestURL().toString().endsWith(REQ_ACTIVATION_LOGON.toLowerCase()))
		{
			request.setAttribute(REQ_ACTION_STR, REQ_ACTIVATION_LOGON);
			request.setAttribute(REQ_IGNORE_SEC_FLAG,  IBankParams.NO);
		} else if(request.getRequestURL().toString().endsWith(REQ_PWD_RESET.toLowerCase()))
		{   
			request.setAttribute(REQ_ACTION_STR,REQ_PWD_RESET);
	     	request.setAttribute(REQ_IGNORE_SEC_FLAG,  IBankParams.NO);	
		}else if (cookieBean == null || logonHelper.isDemo())
		{
			request.setAttribute(REQ_ACTION_STR, REQ_NORMAL_LOGON);
			request.setAttribute(REQ_IGNORE_SEC_FLAG, IBankParams.NO);
		} else
		{
			if (cookieBean.isIgnoreSec())
			{
				request.setAttribute(REQ_ACTION_STR, REQ_IGNORE_SEC_FLAG);
				request.setAttribute(REQ_IGNORE_SEC_FLAG, IBankParams.YES);
			} else
			// if (!cookieBean.isIgnoreSec())
			{
				request.setAttribute(REQ_ACTION_STR, REQ_NORMAL_LOGON);
				request.setAttribute(REQ_IGNORE_SEC_FLAG, IBankParams.NO);
			}
			/*
			 * { request.setAttribute(REQ_ACTION_STR, "simple");
			 * request.setAttribute(REQ_IGNORE_SEC_FLAG, "Y"); }
			 */
		}
		String actionId = request.getParameter(REQ_ACTION_ID);
		if (!StringMethods.isEmptyString(actionId)) {
			request.setAttribute( MainController.REQ_ACTION_ID ,actionId);
		}
		String actionType = request.getParameter(REQ_ACTION_TYPE);
		
			if(!isValidActionType(actionType)){
				Logger.info("Invalid Character in Action Type " + actionType,  this.getClass());
				throw new BusinessException(BusinessException.INVALID_CHAR_SET, "Invalid Character");
			}
			
		IBankRefershParams ibankRefreshParams = (IBankRefershParams) ServiceHelper.getBean("ibankRefreshParams");
			
		if ( ! StringMethods.isEmptyString(actionType) && APPLY_GCC.equalsIgnoreCase(actionType) ){
			request.setAttribute( MainController.REQ_ACTION_TYPE ,APPLY_GCC );
		}else if ( ! StringMethods.isEmptyString(actionType) && SERVICE_MENU.equalsIgnoreCase(actionType) ){
			request.setAttribute( MainController.REQ_ACTION_TYPE, SERVICE_MENU );
		}else if ( ! StringMethods.isEmptyString(actionType) && APPLY_BT.equalsIgnoreCase(actionType) ){
			request.setAttribute( MainController.REQ_ACTION_TYPE, APPLY_BT );
		}else if ( ! StringMethods.isEmptyString(actionType) && BT_SUPER_SEARCH.equalsIgnoreCase(actionType) ){
			request.setAttribute( MainController.REQ_ACTION_TYPE, BT_SUPER_SEARCH );
		}else if ( ! StringMethods.isEmptyString(actionType) && CHANGE_CARD_PIN.equalsIgnoreCase(actionType) ){
			request.setAttribute( MainController.REQ_ACTION_TYPE, CHANGE_CARD_PIN );
		}else if(!StringMethods.isEmptyString(actionType) 
				&& MainController.ONBOARDING_STATUS.equalsIgnoreCase(actionType) 
						&& !IBankParams.isOnboardingSwitchON()){
			request.removeAttribute(MainController.REQ_ACTION_TYPE);
		}else if(!StringMethods.isEmptyString(actionType) 
				&& MainController.ECONTRACT_DEEPLINK.equalsIgnoreCase(actionType) 
				&& !ibankRefreshParams.isEContractSwitchOn(origin)){
			request.removeAttribute(MainController.REQ_ACTION_TYPE);
		}else if (ACTION_TYPE_OPEN_ACCT.equalsIgnoreCase(actionType)){
			String custType = request.getParameter(CUST_TYPE);
			String productType = request.getParameter(PROD_TYPE);
			if(CUST_TYPE_SOLE_TRADER.equalsIgnoreCase(custType) && (PROD_TYPE_FREEDOM_BUSINESS.equals(productType) || PROD_TYPE_SAVING_BUSINESS.equals(productType)))
			{
				request.setAttribute( MainController.REQ_ACTION_TYPE, PROD_TYPE_FREEDOM_BUSINESS.equals(productType) ? ACTION_TYPE_SOLE_FREEDOM_BUSINESS:ACTION_TYPE_SOLE_SAVING_BUSINESS );
			}
			else if(CUST_TYPE_SOLE_DIRECTOR.equalsIgnoreCase(custType) && (PROD_TYPE_FREEDOM_BUSINESS.equals(productType) || PROD_TYPE_SAVING_BUSINESS.equals(productType)))
			{
				request.setAttribute( MainController.REQ_ACTION_TYPE, PROD_TYPE_FREEDOM_BUSINESS.equals(productType) ? ACTION_TYPE_SOLE_DIR_FREEDOM_BUSINESS:ACTION_TYPE_SOLE_DIR_SAVING_BUSINESS );
			}
			else{
				request.setAttribute( MainController.REQ_ACTION_TYPE ,actionType);
			}
		}else if(!StringMethods.isEmptyString(actionType) && HOME_LOAN_APP_TRACKER.equalsIgnoreCase(actionType) ) {
			
			// 20E2 - CSH app tracker - set the action only when  CSH display tile switch is ON
			if(IBankParams.isSwitchOn(IBankParams.getBaseOriginCode(origin), IBankParams.CSH_DISPLAY_TILE_SWITCH)) {
				request.setAttribute( MainController.REQ_ACTION_TYPE ,actionType);			
				
				//Set fid in the session if its present in request
				if(null != request.getParameter(F_ID) && !StringUtil.isRogueInputData(request.getParameter(F_ID))) {					
					request.setAttribute(F_ID, (String)request.getParameter(F_ID));					
				}
				
				if(null != request.getParameter(C_ID) && !StringUtil.isRogueInputData(request.getParameter(C_ID))) {					
					request.setAttribute(C_ID, (String)request.getParameter(C_ID));					
				}		
			}
		}
		
		else if(!StringMethods.isEmptyString(actionType) && CSH_PREPARE_ONLINE.equalsIgnoreCase(actionType) ) {
			
				//TODO add switch or not need to check			
				request.setAttribute( MainController.REQ_ACTION_TYPE ,actionType);		
		
				if(null != request.getParameter(PURPOSE) && !StringUtil.isRogueInputData(request.getParameter(PURPOSE))) {					
					request.setAttribute(PURPOSE, (String)request.getParameter(PURPOSE));					
				}
				if(null != request.getParameter(OPPORTUNITY_ID) && !StringUtil.isRogueInputData(request.getParameter(OPPORTUNITY_ID))) {					
					request.setAttribute(OPPORTUNITY_ID, (String)request.getParameter(OPPORTUNITY_ID));					
				}				
				if(null != request.getParameter(LENDER_ID) && !StringUtil.isRogueInputData(request.getParameter(LENDER_ID))) {					
					request.setAttribute(LENDER_ID, (String)request.getParameter(LENDER_ID));					
				}
				if(null != request.getParameter(HMAC) && !StringUtil.isRogueInputData(request.getParameter(HMAC))) {					
					request.setAttribute(HMAC, (String)request.getParameter(HMAC));					
				}
				
				if(null != request.getParameter(STAGE) && !StringUtil.isRogueInputData(request.getParameter(STAGE))) {					
					request.setAttribute(STAGE, (String)request.getParameter(STAGE));					
				}
				if(null != request.getParameter(JOINT) && !StringUtil.isRogueInputData(request.getParameter(JOINT))) {					
					request.setAttribute(JOINT, (String)request.getParameter(JOINT));					
				}
				if(null != request.getParameter(SID) && !StringUtil.isRogueInputData(request.getParameter(SID))) {					
					request.setAttribute(SID, (String)request.getParameter(SID));					
				}
				if(null != request.getParameter(CTX) && !StringUtil.isRogueInputData(request.getParameter(CTX))) {					
					request.setAttribute(CTX, (String)request.getParameter(CTX));					
				}
			

		}
		else {
			request.setAttribute( MainController.REQ_ACTION_TYPE ,actionType);
		}
		int loadCordova = logonHelper.loadCordova(request);
		request.setAttribute(REQ_LOAD_CORDOVA, String.valueOf(loadCordova));
		
//		int allowsPost = logonHelper.allowsPostWhenNative(request);
//		request.setAttribute(REQ_ALLOWS_APPACTION_POST, String.valueOf(allowsPost));

	}
	
	private boolean isValidActionType(String actionType){

		if(StringMethods.isEmptyString(actionType)){
			return true;
		}
		
		String pattern = BLOCK_CHARS;
		Pattern r = Pattern.compile(pattern);

		Matcher m = r.matcher(actionType);
		if (m.find()) {
			return true;
		} 
		return false;
	}
	

	private SystemInformation getSystemInformationDtls()
	{
		SystemInformation systemInformation = (SystemInformation) ServiceHelper.getBean("systemInformation");
		return systemInformation;

	}
	
	@Autowired
	private LogonHelper logonHelper;
	
	@Autowired
	private SystemInformation systemInformation;
	
	@Autowired
	private GDPRWebHelper gdprWebHelper;
	

}