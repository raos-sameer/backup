package au.com.stgeorge.mbank.controller.services;

import java.util.Collection;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import au.com.stgeorge.framework.common.logging.Logger;
import au.com.stgeorge.ibank.businessobject.AccountFilter;
import au.com.stgeorge.ibank.businessobject.BusinessException;
import au.com.stgeorge.ibank.businessobject.acctsvc.AccountService;
import au.com.stgeorge.ibank.valueobject.Account;
import au.com.stgeorge.ibank.valueobject.TermDepositAccount;
import au.com.stgeorge.ibank.valueobject.transfer.IBankCommonData;
import au.com.stgeorge.ibank.valueobject.transfer.TermDepositInterestInstruction;
import au.com.stgeorge.mbank.controller.IMBController;
import au.com.stgeorge.mbank.model.common.IMBReq;
import au.com.stgeorge.mbank.model.common.IMBResp;
import au.com.stgeorge.mbank.model.common.ReqHeader;
import au.com.stgeorge.mbank.model.common.RespHeader;
import au.com.stgeorge.mbank.model.request.services.ManagedTDDetailsReq;
import au.com.stgeorge.mbank.model.request.services.ManagedTDUpdateDetailsReq;
import au.com.stgeorge.mbank.model.response.ErrorResp;
import au.com.stgeorge.mbank.session.MobileSession;
import au.com.stgeorge.mbank.util.MBAppHelper;
import au.com.stgeorge.mbank.util.MBAppUtils;
import au.com.stgeorge.mbank.util.MBAppValidator;
import au.com.stgeorge.mbank.util.ServiceConstants;
import au.com.stgeorge.mobilebank.businessobject.TermDepositService;
import au.com.stgeorge.perflogger.PerformanceLogger;

/**
 * 
 * Controller for Managed TD flow.
 *
 */

@Controller
@RequestMapping("/manageTd")
public class ManageTermDepositController implements IMBController {

	@Autowired
	private MBAppHelper mbAppHelper;
	
	@Autowired
	private TermDepositService termDepositService;
	
	@Autowired
	private ManageTermDepositHelper mtdHelper;
	
	@Autowired
	private MBAppValidator mbAppValidator;
	
	@Autowired
	private AccountService acctSvc;
	
	/**
	 * This method will be called when customer clicks on the ManageTD link from the services menu.<br>
	 * It takes customer to the first page of the Manage TD flow.<br>
	 * 
	 * @param httpServletRequest
	 * @param httpServletResponse
	 * @param request
	 * @return IMBResp
	 */
	@RequestMapping(value="getDetails", method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public IMBResp getDetails(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, @RequestBody final ManagedTDDetailsReq request) {
		
		Logger.debug("MTD: getDetails :: START", this.getClass());

		PerformanceLogger performanceLogger = new PerformanceLogger();		
		String logName = MBAppUtils.getLogName(httpServletRequest);
		
		performanceLogger.startAllLogs();
		performanceLogger.startLog(logName);		
		
		MobileSession mbSession =  null;

		try
		{			
			mbSession = mbAppHelper.getMobileSession(httpServletRequest);		
			
			validateRequestHeader( request.getHeader(), httpServletRequest );
				
			ErrorResp errorResp = validate(request, httpServletRequest);
			
			if (errorResp != null && errorResp.getErrors() != null && errorResp.getErrors().size() > 0)
				return errorResp;
								
			IBankCommonData commonData = mbAppHelper.populateIBankCommonData(mbSession, httpServletRequest);			
			
			//Fetch the selected TD account
			Account selectedAccount = mbAppHelper.getAccountFromCustomer(mbSession.getCustomer(), request.getAccountIndex());		
			
			//Fetch the TD account details - this will make a WMQI call
			TermDepositAccount tdaAccount = (TermDepositAccount)termDepositService.getTDAAccount(selectedAccount.getAccountId(), commonData);
			
			//Fetch the pay interest to account list
			Collection<Account> paidToInterestAccountsList = AccountFilter.getTermDepositPaidToInterestAccounts(mbSession.getCustomer().getAccounts());	
			
			//Construct the response
			IMBResp serviceResponse =  mtdHelper.getManagedTDDetailsResp(tdaAccount, paidToInterestAccountsList, mbSession.getCustomer());
			
			//Populate the response header
			RespHeader headerResp = populateResponseHeader(ServiceConstants.MANAGE_TD_SERVICE, mbSession);
	        serviceResponse.setHeader(headerResp);       
				        	
			return serviceResponse;
			
		} catch (BusinessException e) {
			Logger.error("MTD : BusinessException Inside getDetails() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			IMBResp resp1 = MBAppUtils.createErrorResp(mbSession.getOrigin(), e, ServiceConstants.MANAGE_TD_SERVICE, httpServletRequest);
			return resp1;
		} catch (Exception e) {	
			Logger.error("MTD : Exception Inside getDetails() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			BusinessException exp = new BusinessException(BusinessException.SYSTEM_UNAVILABLE);
			IMBResp resp1 = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, ServiceConstants.MANAGE_TD_SERVICE, httpServletRequest);
			return resp1;
		} finally {
			performanceLogger.endLog(logName);
			performanceLogger.endAllLogs();
			
			Logger.debug("MTD: getDetails :: END", this.getClass());
		}
	}
	
	/**
	 * This method will be called when customer changes the Payment instructions and clicks on Confirm button on Confirmation screen. <br><br>
	 * 
	 * @param httpServletRequest
	 * @param httpServletResponse
	 * @param tdRenewRequest
	 * @return IMBResp
	 */
	@RequestMapping(value="updateDetails", method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public IMBResp updateDetails(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, @RequestBody final ManagedTDUpdateDetailsReq request) {
		
		Logger.debug("MTD: updateDetails :: START", this.getClass());

		PerformanceLogger performanceLogger = new PerformanceLogger();		
		String logName = MBAppUtils.getLogName(httpServletRequest);
		
		performanceLogger.startAllLogs();
		performanceLogger.startLog(logName);		
		
		MobileSession mbSession =  null;

		try
		{			
			mbSession = mbAppHelper.getMobileSession(httpServletRequest);		
			
			validateRequestHeader( request.getHeader(), httpServletRequest );
				
			ErrorResp errorResp = validate(request, httpServletRequest);
			
			if (errorResp != null && errorResp.getErrors() != null && errorResp.getErrors().size() > 0)
				return errorResp;
								
			IBankCommonData commonData = mbAppHelper.populateIBankCommonData(mbSession, httpServletRequest);
			
			//Fetch the selected TD account
			Account selectedAccount = mbAppHelper.getAccountFromCustomer(mbSession.getCustomer(), request.getTermDepositProductIndex());		
			
			//Fetch the TD account details - this will make a WMQI call
			TermDepositAccount tdaAccount = (TermDepositAccount)termDepositService.getTDAAccount(selectedAccount.getAccountId(), commonData);
			
			//Fetch the pay interest to account list
			Collection<Account> paidToInterestAccountsList = AccountFilter.getTermDepositPaidToInterestAccounts(mbSession.getCustomer().getAccounts());	
			
			TermDepositInterestInstruction transfer = mtdHelper.getTDInterestInstruction(tdaAccount, commonData, paidToInterestAccountsList, request.getIntrPayToAcctIndex(), request.getIntrPayInst());
			 
			acctSvc.updateFinancialInstruction(transfer);
						
			//Construct the response
			IMBResp serviceResponse = mtdHelper.getManagedTDUpdateResp(mbSession.getCustomer());
			
			//Populate the response header
			RespHeader headerResp = populateResponseHeader(ServiceConstants.MANAGE_TD_SERVICE, mbSession);
	        serviceResponse.setHeader(headerResp);       
				        	
			return serviceResponse;
			
		} catch (BusinessException e) {
			Logger.error("MTD : BusinessException Inside updateDetails() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			IMBResp resp1 = MBAppUtils.createErrorResp(mbSession.getOrigin(), e, ServiceConstants.MANAGE_TD_SERVICE, httpServletRequest);
			return resp1;
		} catch (Exception e) {	
			Logger.error("MTD : Exception Inside updateDetails() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			BusinessException exp = new BusinessException(BusinessException.SYSTEM_UNAVILABLE);
			IMBResp resp1 = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, ServiceConstants.MANAGE_TD_SERVICE, httpServletRequest);
			return resp1;
		} finally {
			performanceLogger.endLog(logName);
			performanceLogger.endAllLogs();
			
			Logger.debug("MTD: updateDetails :: END", this.getClass());
		}
	}
	
	@Override
	public void validateRequestHeader(ReqHeader headerReq, HttpServletRequest request) throws BusinessException {
		mbAppValidator.validateRequestHeader(headerReq,  request);		
	}

	@Override
	public ErrorResp validate(IMBReq serviceRequest, HttpServletRequest httpRequest) throws BusinessException {
		return  mbAppValidator.validate(serviceRequest, httpRequest);
	}

	@Override
	public RespHeader populateResponseHeader(String serviceName, MobileSession mobileSession) {
		return mbAppHelper.populateResponseHeader(serviceName, mobileSession);
	}

}
