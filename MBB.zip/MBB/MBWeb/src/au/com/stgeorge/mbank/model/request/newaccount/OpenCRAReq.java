package au.com.stgeorge.mbank.model.request.newaccount;

import java.io.Serializable;

import au.com.stgeorge.ibank.valueobject.transfer.NewDDAAccount;
import au.com.stgeorge.mbank.model.common.IMBReq;
import au.com.stgeorge.mbank.model.common.ProductReq;
import au.com.stgeorge.mbank.model.common.ReqHeader;

public class OpenCRAReq implements IMBReq, Serializable
{

	private static final long serialVersionUID = -2564695018894992233L;

	private ReqHeader header;

	private ProductReq product;

	public ProductReq getProduct()
	{
		return product;
	}

	public void setProduct(ProductReq product)
	{
		this.product = product;
	}

	public ReqHeader getHeader()
	{
		return header;
	}

	public void setHeader(ReqHeader header)
	{
		this.header = header;
	}

	public static long getSerialVersionUID()
	{
		return serialVersionUID;
	}

}
