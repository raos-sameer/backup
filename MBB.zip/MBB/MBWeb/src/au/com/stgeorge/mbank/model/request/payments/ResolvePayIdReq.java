package au.com.stgeorge.mbank.model.request.payments;

import javax.validation.constraints.NotNull;
import org.apache.commons.lang.builder.ReflectionToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;
import au.com.stgeorge.mbank.model.common.IMBReq;
import au.com.stgeorge.mbank.model.common.ReqHeader;

/**
 * Resolve PayId request
 * 
 */
public class ResolvePayIdReq implements IMBReq  {

	private static final long serialVersionUID = -1644947830163325463L;

	private ReqHeader header;
	
	@NotNull(message =  "{errors.payIdType.required}")
	private String payIdType;
	
	@NotNull(message =  "{errors.payIdValue.required}")
	private String payIdValue;
		
	private String devicePrint;	
	
	private int payIdIndex;

	public String getPayIdType() {
		return payIdType;
	}

	public void setPayIdType(String payIdType) {
		this.payIdType = payIdType;
	}

	public String getPayIdValue() {
		return payIdValue;
	}

	public void setPayIdValue(String payIdValue) {
		this.payIdValue = payIdValue;
	}

	public String getDevicePrint() {
		return devicePrint;
	}

	public void setDevicePrint(String devicePrint) {
		this.devicePrint = devicePrint;
	}

	@Override
	public String toString() {
		return ReflectionToStringBuilder.toString(this, ToStringStyle.MULTI_LINE_STYLE);
	}

	@Override
	public ReqHeader getHeader() {
		return header;
	}

	@Override
	public void setHeader(ReqHeader header) {
		this.header = header;
	}

	public int getPayIdIndex() {
		return payIdIndex;
	}

	public void setPayIdIndex(int payIdIndex) {
		this.payIdIndex = payIdIndex;
	}

	
}
