package au.com.stgeorge.mbank.model.request.newaccount;

import java.io.Serializable;
import java.util.List;

import au.com.stgeorge.mbank.model.common.IMBReq;
import au.com.stgeorge.mbank.model.common.ReqHeader;

public class ProductContentReq implements IMBReq, Serializable {

	private static final long serialVersionUID = -2993255178579970136L;
	private ReqHeader header;	
	private String pageURL;
	private List<ProductContentCPCReq> productContentCPCReq;
	
	@Override
	public ReqHeader getHeader() {
		return header;
	}

	@Override
	public void setHeader(ReqHeader header) {
		this.header = header;
	}

	public String getPageURL() {
		return pageURL;
	}

	public void setPageURL(String pageURL) {
		this.pageURL = pageURL;
	}

	public List<ProductContentCPCReq> getProductContentCPCReq() {
		return productContentCPCReq;
	}

	public void setProductContentCPCReq(
			List<ProductContentCPCReq> productContentCPCReq) {
		this.productContentCPCReq = productContentCPCReq;
	}

}
