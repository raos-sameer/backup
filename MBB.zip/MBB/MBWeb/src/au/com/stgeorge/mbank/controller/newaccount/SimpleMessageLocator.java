package au.com.stgeorge.mbank.controller.newaccount;

import java.io.InputStream;
import javax.xml.bind.Unmarshaller;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import org.w3c.dom.Document;

public class SimpleMessageLocator
{
	private Unmarshaller unmarshaller;
	private String simpleMsgXMLConfig;

	public String getSimpleMsgXMLConfig()
	{
		return simpleMsgXMLConfig;
	}




	public void setSimpleMsgXMLConfig(String simpleMsgXMLConfig)
	{
		this.simpleMsgXMLConfig = simpleMsgXMLConfig;
	}




	public Unmarshaller getUnmarshaller() {
  	return unmarshaller;
  }





	private SimpleMessageStructure messageStructure;

	



	public SimpleMessageStructure getMessageStructure() {
		return messageStructure;
	}




	public void setMessageStructure(SimpleMessageStructure messageStructure) {
		this.messageStructure = messageStructure;
	}




	public void initStructures() throws Exception
	{
		
		InputStream newAccountsIs = null;


		try
		{
			ClassLoader classLoader = getClass().getClassLoader();						
			newAccountsIs = classLoader.getResourceAsStream(simpleMsgXMLConfig);			
			DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();	
			//set below to avoid security defects
			dbf.setFeature("http://xml.org/sax/features/external-general-entities", false);
			dbf.setFeature("http://xml.org/sax/features/external-parameter-entities", false);
			dbf.setXIncludeAware(false);
		    dbf.setExpandEntityReferences(false);
		    dbf.setFeature("http://javax.xml.XMLConstants/feature/secure-processing", true);
		    
			DocumentBuilder db = dbf.newDocumentBuilder();
			Document document = db.parse(newAccountsIs);
			messageStructure = (SimpleMessageStructure) unmarshaller.unmarshal(document);			
			
		} finally
		{
		
			
			if (newAccountsIs != null)
			{
				newAccountsIs.close();
			}
		
		}
	}






	public void setUnmarshaller(Unmarshaller unmarshaller) {
		this.unmarshaller = unmarshaller;
	}

	

}
