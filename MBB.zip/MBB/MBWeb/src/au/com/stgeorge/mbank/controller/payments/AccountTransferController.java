package au.com.stgeorge.mbank.controller.payments;

import java.util.Arrays;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang.builder.ReflectionToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;

import au.com.stgeorge.digitalsec.logger.DigitalSecLogger;
import au.com.stgeorge.framework.common.logging.Logger;
import au.com.stgeorge.ibank.businessobject.BusinessException;
import au.com.stgeorge.ibank.businessobject.GCCService;
import au.com.stgeorge.ibank.businessobject.ResourceException;
import au.com.stgeorge.ibank.businessobject.acctsvc.AccountService;
import au.com.stgeorge.ibank.businessobject.globalWallet.ForexRateService;
import au.com.stgeorge.ibank.businessobject.globalWallet.GlobalWalletPaymentService;
import au.com.stgeorge.ibank.businessobject.globalWallet.GlobalWalletUtil;
import au.com.stgeorge.ibank.common.cache.IBankParams;
import au.com.stgeorge.ibank.servicestation.businessobject.ServiceStation;
import au.com.stgeorge.ibank.valueobject.Account;
import au.com.stgeorge.ibank.valueobject.CreditCardAccount;
import au.com.stgeorge.ibank.valueobject.Customer;
import au.com.stgeorge.ibank.valueobject.LoanAccount;
import au.com.stgeorge.ibank.valueobject.PaymentsLog;
import au.com.stgeorge.ibank.valueobject.Receipt;
import au.com.stgeorge.ibank.valueobject.database.CodesVO;
import au.com.stgeorge.ibank.valueobject.transfer.IBankCommonData;
import au.com.stgeorge.mbank.controller.IMBController;
import au.com.stgeorge.mbank.model.common.IMBReq;
import au.com.stgeorge.mbank.model.common.IMBResp;
import au.com.stgeorge.mbank.model.common.ReqHeader;
import au.com.stgeorge.mbank.model.common.RespHeader;
import au.com.stgeorge.mbank.model.request.EmptyReq;
import au.com.stgeorge.mbank.model.request.IndexReq;
import au.com.stgeorge.mbank.model.request.payments.AcctTransferReq;
import au.com.stgeorge.mbank.model.response.ErrorResp;
import au.com.stgeorge.mbank.model.response.payments.TransferResp;
import au.com.stgeorge.mbank.session.MobileSession;
import au.com.stgeorge.mbank.session.MobileSessionImpl;
import au.com.stgeorge.mbank.util.MBAppConstants;
import au.com.stgeorge.mbank.util.MBAppHelper;
import au.com.stgeorge.mbank.util.MBAppUtils;
import au.com.stgeorge.mbank.util.MBAppValidator;
import au.com.stgeorge.mbank.util.ServiceConstants;
import au.com.stgeorge.mobilebank.businessobject.MobileBankService;
import au.com.stgeorge.mobilebank.businessobject.TransactService;
import au.com.stgeorge.perflogger.PerformanceLogger;
import au.com.stgeorge.security.util.StringMethods;

/**
 * Account to account transfer service
 * 
 * @author C38854
 * 
 */
@Controller
@RequestMapping("/accounts")
public class AccountTransferController implements IMBController {

	private static final String TERM_DEPOSIT_CODE = "TermDeposit";
	public static final String TDA_BRANCHKEY = "000";
	public static final String BILLER_CODE = "BillerCode";
	public static final String STG = "STG";
	public static final String BSA = "BSA";
	
	@Autowired
	private TransactService transactService;

	@Autowired
	private AccountTransferHelper helper;

	@Autowired
	private MobileBankService mobileBankService;
	
	@Autowired
	private AccountService acctSvc;
	
	@Autowired
	private PerformanceLogger perfLogger;
		
	@Autowired
	private MBAppValidator mbAppValidator;
	
	@Autowired
	private MBAppHelper mbAppHelper;

	@Autowired
	private GCCService gccService;

    @Autowired
    private DigitalSecLogger digitalSecLogger;
    
	@Autowired
	private ServiceStation serviceStationService;
    

	@Autowired
	private GlobalWalletPaymentService globalWalletPaymentService;

	/**
	 * Account to account service operation
	 * 
	 * @param httpRequest
	 * @param request
	 * @return
	 */
	@RequestMapping(method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE, value = "transfer")
	@ResponseBody
	public IMBResp transfer(HttpServletRequest httpRequest, @RequestBody final AcctTransferReq request) {
		Logger.debug("AccountTransferController - transfer(). Request: " + request, this.getClass());
		String logName = startPerformanceLog(httpRequest);
		MobileSession mobileSession = new MobileSessionImpl();

		try {
			mobileSession.getSessionContext(httpRequest);
			Customer customer = mobileSession.getCustomer();
			IBankCommonData commonData = new MBAppHelper().populateIBankCommonData(mobileSession, httpRequest);

			validateRequestHeader(request.getHeader(), httpRequest);
			ErrorResp errorResponse = validate(request, httpRequest);
			if (errorResponse.hasErrors()) {
				return errorResponse;
			}
			
			// Validation for account index to account number
			
			boolean isAcctToIndexValidationSwitchOn=IBankParams.isSwitchOn(IBankParams.ACCT_TO_INDEX_VALIDATION_SWITCH);
			if(isAcctToIndexValidationSwitchOn) {
				String fromAccountNumber=request.getFromAccountNumber();
				String fromAccountNumberMasked=request.getFromAccountNumberMasked();
				
				String toAccountNumber=request.getToAccountNumber();
				String toAccountNumberMasked=request.getToAccountNumberMasked();
				
				boolean isValidAcctToIndex=mbAppHelper.isValidIndextoAcct(fromAccountNumber, fromAccountNumberMasked, request.getFromAccountIndex(), toAccountNumber, toAccountNumberMasked, request.getToAccountIndex(), "AccountTransfer", commonData);
				
				if(!isValidAcctToIndex) {
					//throw new business exception
					Logger.error("AccountTransferController - transfer(). Index-Account MisMatch", this.getClass());
					throw new BusinessException(BusinessException.ACCOUNT_TO_INDEX_MISMATCH, "Account-Index mismatch");
				}
			}
		
			helper.validateTransferReq(request);

			Account fromAcct;
			Account toAcct;
			
			// external nominated acct to DRA transfer
			if (request.getFromAccountIndex() == -1) {
				fromAcct = mobileBankService.getNominatedAccount(customer.getAccounts().get(request.getToAccountIndex()), commonData);
			} else {
				fromAcct = customer.getAccounts().get(request.getFromAccountIndex());
			}
			// DRA to external nominated account transfer
			if (request.getToAccountIndex() == -1) {
				toAcct = mobileBankService.getNominatedAccount(customer.getAccounts().get(request.getFromAccountIndex()), commonData);
			} else {
				toAcct = customer.getAccounts().get(request.getToAccountIndex());
			}
							
			return helper.performTransfer(mobileSession, fromAcct, toAcct, commonData, request, httpRequest, mbAppHelper, gccService, transactService, serviceStationService, digitalSecLogger, request.getScheduleDetail() != null, ServiceConstants.ACCOUNT_TRANSFER_SERVICE);
		} catch (BusinessException e) {			
			Logger.info("BusinessException in AccountTransferController - transfer() - [key: " + e.getKey() + "] : GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());
			if (e.getKey() == BusinessException.GCC_ESB_TECH_ERROR) {
				IBankCommonData commonData = new MBAppHelper().populateIBankCommonData(mobileSession, httpRequest);
				String[] phoneNumbers = helper.getGCCPhoneNumber(commonData.getOrigin());
				return MBAppUtils.createErrorResp(mobileSession.getOrigin(), e, phoneNumbers, ServiceConstants.ACCOUNT_TRANSFER_SERVICE, httpRequest);
			} else if (e.getKey() == BusinessException.EXCEED_DAILY_LIMIT){
				return MBAppUtils.createErrorResp("ALL", e.getKey(), ServiceConstants.ACCOUNT_TRANSFER_SERVICE, httpRequest);
			} else if (e.getKey() == BusinessException.ACCOUNT_TO_INDEX_MISMATCH){
				return MBAppUtils.createErrorResp("ALL", e.getKey(), ServiceConstants.ACCOUNT_TRANSFER_SERVICE, httpRequest);
			} else {				
				return MBAppUtils.createErrorResp(mobileSession.getOrigin(), e, ServiceConstants.ACCOUNT_TRANSFER_SERVICE, httpRequest);
			}
		} catch (ResourceException e) {
			Logger.error("ResourceException in AccountTransferController - transfer() - [key: " + e.getKey() + "] : GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.SYSTEM_UNAVILABLE, ServiceConstants.ACCOUNT_TRANSFER_SERVICE, httpRequest);
		} catch (Exception e) {
			Logger.error("Exception AccountTransferController - transfer(): GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.GENERIC_ERROR, ServiceConstants.ACCOUNT_TRANSFER_SERVICE, httpRequest);
		} finally {
			endPerformanceLog(logName);
		}
	}

	/**
	 * Get CC Details service operation
	 * 
	 * @param httpRequest
	 * @param request
	 * @return
	 */
	@RequestMapping(method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE, value = "ccdetails")
	@ResponseBody
	public IMBResp getCCDetails(HttpServletRequest httpRequest, @RequestBody final IndexReq request) {
		Logger.debug("AccountTransferController - getCCDetails(). Request: " + request, this.getClass());
		String logName = startPerformanceLog(httpRequest);
		MobileSession mobileSession = new MobileSessionImpl();

		try {
			mobileSession.getSessionContext(httpRequest);
			IBankCommonData commonData = new MBAppHelper().populateIBankCommonData(mobileSession, httpRequest);
			
			validateRequestHeader(request.getHeader(), httpRequest);
			mobileSession.getSessionContext(httpRequest);
			commonData.setCustomer(mobileSession.getCustomer());
			ErrorResp errorResponse = validate(request, httpRequest);// validate json
			if (errorResponse.hasErrors())
				return errorResponse;
			Account selectedAccount = mobileSession.getCustomer().getAccounts().get(Integer.parseInt(request.getIndex()));
			return helper.populateCCDetailResponse(populateResponseHeader(ServiceConstants.GET_CC_DETAILS_SERVICE, mobileSession),
					(CreditCardAccount) mobileBankService.getAccount(selectedAccount.getAccountId(), commonData));
		} catch (BusinessException e) {
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), e, ServiceConstants.GET_CC_DETAILS_SERVICE, httpRequest);
		} catch (ResourceException e) {
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.SYSTEM_UNAVILABLE, ServiceConstants.GET_CC_DETAILS_SERVICE, httpRequest);
		} catch (Exception e) {
			Logger.error("Exception PayeeController - reqSecureCode() : GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), ResourceException.MOBILE_NON_FINANCIAL_FATAL_ERR, ServiceConstants.GET_CC_DETAILS_SERVICE, httpRequest);
		} finally {
			endPerformanceLog(logName);
		}
	}
	
	/**
	 * TDA Funding service operation
	 * 
	 * @param httpRequest
	 * @param request
	 * @return
	 */
	@RequestMapping(method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE, value = "tdafundingdetail")
	@ResponseBody
	public IMBResp fundTDA(HttpServletRequest httpRequest, @RequestBody final IndexReq request) {
		Logger.debug("AccountTransferController - fundTDA(). Request: " + request, this.getClass());
		String logName = startPerformanceLog(httpRequest);
		MobileSession mobileSession = new MobileSessionImpl();

		try {
			mobileSession.getSessionContext(httpRequest);
			IBankCommonData commonData = new MBAppHelper().populateIBankCommonData(mobileSession, httpRequest);
			
			validateRequestHeader(request.getHeader(), httpRequest);
			mobileSession.getSessionContext(httpRequest);
			commonData.setCustomer(mobileSession.getCustomer());
			ErrorResp errorResponse = validate(request, httpRequest);// validate json
			if (errorResponse.hasErrors())
				return errorResponse;
			Account selectedAccount = mobileSession.getCustomer().getAccounts().get(Integer.parseInt(request.getIndex()));
			
			CodesVO codesVo = new CodesVO();
			String billerCodeOrigin = "";
			if (selectedAccount != null && !StringMethods.isEmptyString(selectedAccount.getBrand())) {
				billerCodeOrigin = selectedAccount.getBrand();
			} else {
				if (selectedAccount != null) {
					String branchKey = selectedAccount.getAccountId().getBranchKey();
					if (TDA_BRANCHKEY.equals(branchKey)) {
						billerCodeOrigin = STG;
					} else {
						billerCodeOrigin = BSA;
					}
				} else {
					Logger.warn("Account is NULL in getBillerCodeForTDA.Cannot get BillerCode.", this.getClass());
				}
			}
			
			String origin = null; 
			if (billerCodeOrigin.contains("BOM")) {
				billerCodeOrigin = "Bank of Melbourne";
				origin = MBAppConstants.ORIGIN_MBOM;
			} else if (billerCodeOrigin.contains("BSA")) {
				billerCodeOrigin = "BankSA";
				origin = MBAppConstants.ORIGIN_MBSA;
			} else {
				billerCodeOrigin = "St.George";
				origin = MBAppConstants.ORIGIN_MSTG;
			}
			
			codesVo = IBankParams.getCodesData(origin, TERM_DEPOSIT_CODE, BILLER_CODE);
			String termDepBillerCode = "";
			if (codesVo.getMessage() != null) termDepBillerCode = codesVo.getMessage();
			
			return helper.populateTDAFundingDetailResponse(populateResponseHeader(ServiceConstants.FUND_TDA_SERVICE, mobileSession),
					billerCodeOrigin, termDepBillerCode);
			
			
		} catch (BusinessException e) {
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), e, ServiceConstants.FUND_TDA_SERVICE, httpRequest);
		} catch (ResourceException e) {
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.SYSTEM_UNAVILABLE, ServiceConstants.FUND_TDA_SERVICE, httpRequest);
		} catch (Exception e) {
			Logger.error("Exception PayeeController - reqSecureCode(): GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), ResourceException.MOBILE_NON_FINANCIAL_FATAL_ERR, ServiceConstants.FUND_TDA_SERVICE, httpRequest);
		} finally {
			endPerformanceLog(logName);
		}

	}
	
	/**
	 * Get List Redraw Fee service operation
	 * 
	 * @param httpRequest
	 * @param request
	 * @return
	 */
	@RequestMapping(method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE, value = "lisredrawfee")
	@ResponseBody
	public IMBResp getLisRedrawFee(HttpServletRequest httpRequest, @RequestBody final IndexReq request) {
		Logger.debug("AccountTransferController - getLisRedrawFee(). Request: " + request, this.getClass());
		String logName = startPerformanceLog(httpRequest);
		MobileSession mobileSession = new MobileSessionImpl();

		try {
			mobileSession.getSessionContext(httpRequest);
			IBankCommonData commonData = new MBAppHelper().populateIBankCommonData(mobileSession, httpRequest);

			validateRequestHeader(request.getHeader(), httpRequest);
			mobileSession.getSessionContext(httpRequest);
			commonData.setCustomer(mobileSession.getCustomer());
			ErrorResp errorResponse = validate(request, httpRequest);// validate json
			if (errorResponse.hasErrors())
				return errorResponse;
			Account selectedAccount = mobileSession.getCustomer().getAccounts().get(Integer.parseInt(request.getIndex()));
			LoanAccount loanAccount = helper.getLoanAccountById(selectedAccount.getAccountId(), commonData);
			// String redrawMsg = MBAppUtils.getMessage(mobileSession.getOrigin(), BusinessException.ACCOUNT_REDRAW_FEE_IS_CHARGED,
			// new String[] { IBankParams.getOrigin(commonData.getOrigin()).getTradingHours() });
			return helper.populateRedrawFeeResponse(populateResponseHeader(ServiceConstants.GET_REDRAW_FEE_SERVICE, mobileSession), loanAccount.getRedrawFee()
					.toString());
		} catch (BusinessException e) {
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), e, ServiceConstants.GET_REDRAW_FEE_SERVICE, httpRequest);
		} catch (ResourceException e) {
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.SYSTEM_UNAVILABLE, ServiceConstants.GET_REDRAW_FEE_SERVICE, httpRequest);
		} catch (Exception e) {
			Logger.error("Exception PayeeController - reqSecureCode(): GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), ResourceException.MOBILE_NON_FINANCIAL_FATAL_ERR, ServiceConstants.GET_REDRAW_FEE_SERVICE, httpRequest);
		} finally {
			endPerformanceLog(logName);
		}
	}
	
	/**
	 * Get List Redraw Message service operation
	 * 
	 * @param httpRequest
	 * @param request
	 * @return
	 */
	@RequestMapping(method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE, value = "lisredrawmsg")
	@ResponseBody
	public IMBResp getLisRedrawMessage(HttpServletRequest httpRequest, @RequestBody final IndexReq request) {
		Logger.debug("AccountTransferController - getLisRedrawMessage(). Request: " + request, this.getClass());
		String logName = startPerformanceLog(httpRequest);
		MobileSession mobileSession = new MobileSessionImpl();

		try {
			mobileSession.getSessionContext(httpRequest);
			IBankCommonData commonData = new MBAppHelper().populateIBankCommonData(mobileSession, httpRequest);

			validateRequestHeader(request.getHeader(), httpRequest);
			mobileSession.getSessionContext(httpRequest);
			commonData.setCustomer(mobileSession.getCustomer());
			ErrorResp errorResponse = validate(request, httpRequest);// validate json
			if (errorResponse.hasErrors())
				return errorResponse;
			Account selectedAccount = mobileSession.getCustomer().getAccounts().get(Integer.parseInt(request.getIndex()));
			LoanAccount loanAccount = helper.getLoanAccountById(selectedAccount.getAccountId(), commonData);
			String response = "",bcopResponse = "";
			if (loanAccount != null && loanAccount.getProdScheme() != null && loanAccount.getProdNum() != null) {
				String subProduct = loanAccount.getProdScheme() + loanAccount.getProdNum();
				String loanMsg = acctSvc.checkLoanSubProduct(subProduct);
				if (StringMethods.isValidString(loanMsg)) {
					response = loanMsg;
				}
			}
			//Need to add the response only for residential loan accounts (having group code 2000) and ProdScheme as F (Fixed home loans)
			boolean isFixedResidentialLoan = "2000".equals(selectedAccount.getAccountId().getGroupCode()) && loanAccount != null && loanAccount.getProdScheme() != null && loanAccount.getProdScheme().equalsIgnoreCase("F");
			if(isFixedResidentialLoan){
				CodesVO codesVo = IBankParams.getCodesData(IBankParams.BRAND_ORIGIN, IBankParams.TRANSFER_CATEGORY, IBankParams.BCOP_FIXEDLOAN_MSG_CODE);
				if(codesVo != null && codesVo.getMessage() != null){
					bcopResponse = codesVo.getMessage();
				}
			}
			return helper.populateRedrawMessageResponse(populateResponseHeader(ServiceConstants.GET_REDRAW_MSG_SERVICE, mobileSession), response, bcopResponse);
		} catch (BusinessException e) {
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), e, ServiceConstants.GET_REDRAW_MSG_SERVICE, httpRequest);
		} catch (ResourceException e) {
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.SYSTEM_UNAVILABLE, ServiceConstants.GET_REDRAW_MSG_SERVICE,httpRequest);
		} catch (Exception e) {
			Logger.error("Exception PayeeController - reqSecureCode(): GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), ResourceException.MOBILE_NON_FINANCIAL_FATAL_ERR, ServiceConstants.GET_REDRAW_MSG_SERVICE, httpRequest);
		} finally {
			endPerformanceLog(logName);
		}
	}
	
	@RequestMapping(method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE, value = "ddaredrawmsg")
	@ResponseBody
	public IMBResp getDDARedrawMessage(HttpServletRequest httpRequest, @RequestBody final IndexReq request) {
		Logger.debug("AccountTransferController - getDDARedrawMessage(). Request: " + request, this.getClass());
		String logName = startPerformanceLog(httpRequest);
		MobileSession mobileSession = new MobileSessionImpl();

		try {
			mobileSession.getSessionContext(httpRequest);
			IBankCommonData commonData = new MBAppHelper().populateIBankCommonData(mobileSession, httpRequest);

			validateRequestHeader(request.getHeader(), httpRequest);
			mobileSession.getSessionContext(httpRequest);
			commonData.setCustomer(mobileSession.getCustomer());
			ErrorResp errorResponse = validate(request, httpRequest);// validate json
			if (errorResponse.hasErrors())
				return errorResponse;
			
			Account selectedAccount = mobileSession.getCustomer().getAccounts().get(Integer.parseInt(request.getIndex()));
			String loanMsg = "";
			if(IBankParams.isBcopPorfolioFixedLoanSwitchON()){
				if(selectedAccount.getAccountId() != null && selectedAccount.getAccountId().getSubProductCode() != null){
					CodesVO codesVo = IBankParams.getCodesData(IBankParams.BRAND_ORIGIN,IBankParams.TRANSFER_CATEGORY, IBankParams.BCOP_PORTFOLIO_FIXED_LOAN_SUBPRODCODE);
					List<String> eligibleCodes = Arrays.asList(codesVo.getMessage().split(","));
					if (eligibleCodes != null){						
						if(eligibleCodes.contains(selectedAccount.getAccountId().getSubProductCode())){
							CodesVO codesVo1 = IBankParams.getCodesData(IBankParams.BRAND_ORIGIN, IBankParams.TRANSFER_CATEGORY, IBankParams.BCOP_PORTFOLIO_FIXED_LOAN_MSG);
							loanMsg = codesVo1.getMessage();
						}
					}
				}
			}
			return helper.populateDDAMessageResponse(populateResponseHeader(ServiceConstants.GET_DDA_MSG_SERVICE, mobileSession), loanMsg);
		} catch (BusinessException e) {
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), e, ServiceConstants.GET_DDA_MSG_SERVICE, httpRequest);
		} catch (ResourceException e) {
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.SYSTEM_UNAVILABLE, ServiceConstants.GET_DDA_MSG_SERVICE,httpRequest);
		} catch (Exception e) {
			Logger.error("Exception PayeeController - reqSecureCode(): GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), ResourceException.MOBILE_NON_FINANCIAL_FATAL_ERR, ServiceConstants.GET_DDA_MSG_SERVICE, httpRequest);
		} finally {
			endPerformanceLog(logName);
		}
	}
	
	@RequestMapping(method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE, value = "walletReceiptStatus")
	@ResponseBody
	public IMBResp getWWWPaymentLogStatus(HttpServletRequest httpRequest, @RequestBody final EmptyReq request) throws Exception {
		
		//Logger.debug("PayeeController - getWWWPaymentLogStatus(). Request: " + request + "PaymentLogID : " + request.getPaymentsLogID(), this.getClass());
		Logger.debug("PayeeController - getWWWPaymentLogStatus(). Request: " + request , this.getClass());
		String logName = startPerformanceLog(httpRequest);
		TransferResp response = null;
		MobileSession mobileSession = new MobileSessionImpl(); 
		try {
			mobileSession.getSessionContext(httpRequest);	
			validateRequestHeader(request.getHeader(), httpRequest);
			ErrorResp errorResponse = validate(request, httpRequest);// validate json
			if (errorResponse.hasErrors())
				return errorResponse;

			String acctIndexStr = mobileSession.getSelectedAccountIndex();//If load, it will be fromAcctIndex.//If unload, it will be toAcctIndex. 
			Logger.info("PayeeController - walletReceiptStatus(). : SelectedAccountIndex in session :"+acctIndexStr , this.getClass());
			if(acctIndexStr == null){
				Logger.error("PayeeController - walletReceiptStatus(). : SelectedAccountIndex is null in session ." , this.getClass());
				throw new BusinessException(BusinessException.SYSTEM_UNAVILABLE, "PayeeController - walletReceiptStatus(). : SelectedAccountIndex is null in session .");
			}
			
			int acctIndex = Integer.parseInt(acctIndexStr);
			
			
			String paymentsLogIdStr = mobileSession.getPaymentsLogId();
			Logger.info("PayeeController - walletReceiptStatus(). : paymentsLogId in session :"+paymentsLogIdStr , this.getClass());
			if(paymentsLogIdStr == null){
				Logger.error("PayeeController - walletReceiptStatus(). : paymentsLogId is null in session ." , this.getClass());
				throw new BusinessException(BusinessException.SYSTEM_UNAVILABLE, "PayeeController - walletReceiptStatus(). : paymentsLogId is null in session .");
			}
			
			int paymentsLogId = Integer.parseInt(paymentsLogIdStr);
			IBankCommonData commonData = new MBAppHelper().populateIBankCommonData(mobileSession, httpRequest);
			Receipt receipt = globalWalletPaymentService.getPaymentsLogStatus(paymentsLogId, acctIndex, commonData);

			if(receipt != null && receipt.getPaymentLog() != null){
				response = helper
						.populateWWWPaymentLogStatusResp(populateResponseHeader(ServiceConstants.GLOBAL_WALLET_PAYMENTS_LOG_STATUS_SERVICE, mobileSession),receipt.getPaymentLog(),commonData);
			}
			else{
				Logger.error("PayeeController - walletReceiptStatus(). : paymentsLog is null from db for  paymentsLogId : "+paymentsLogId , this.getClass());
				throw new BusinessException(BusinessException.SYSTEM_UNAVILABLE, "PayeeController - walletReceiptStatus(). : paymentsLog is null from db for  paymentsLogId : "+paymentsLogId );

			}

			
			if(receipt != null && receipt.getPaymentLog() != null && GlobalWalletUtil.isSuccess(receipt.getPaymentLog().getStatus())){
				

				Customer customer = mobileSession.getCustomer();
				String xRefType = receipt.getPaymentLog().getXrefType();

				if(xRefType.equalsIgnoreCase(PaymentsLog.TYPE_TRANSFER_WWW_LOAD)){
					Account fromAccount = commonData.getCustomer().getAccounts().get(acctIndex);	

					if (fromAccount != null) {
						// adjustBalance is done in getPaymentsLogStatus method
						
						if(fromAccount.getAvailableBalance() != null)
							response.getReceipt().setFromAccountAvailBalance(fromAccount.getAvailableBalance().toString());
						if(fromAccount.getBalanceDisplay() != null)
							response.getReceipt().setFromAccountBalance(fromAccount.getBalanceDisplay().toString());
						
					}
					
					
				}
				if(xRefType.equalsIgnoreCase(PaymentsLog.TYPE_TRANSFER_WWW_UNLOAD)){
				
					Account toAccount = commonData.getCustomer().getAccounts().get(acctIndex);
					if (toAccount != null) {
						// adjustBalance is done in getPaymentsLogStatus method
										
						if (toAccount.getAvailableBalance() != null) {
							response.getReceipt().setToAccountAvailBalance(String.valueOf(toAccount.getAvailableBalance()));
						}
						
						if (toAccount.getBalanceDisplay() != null) {
							response.getReceipt().setToAccountBalance(String.valueOf(toAccount.getBalanceDisplay()));
						}
						
					}

				}
			}

			
			//Removing PaymentsLogId from session 
			if(response.getReceipt().getStatus() == GlobalWalletUtil.PAYMENTS_SUCCESSFUL
					|| response.getReceipt().getStatus() == GlobalWalletUtil.PAYMENTS_ERROR){
				Logger.info("response.getReceipt().getStatus()  : " + response.getReceipt().getStatus() + ": So removing PaymentsLogId from session.", getClass());
				mobileSession.removePaymentsLogId();
			}

			
		} catch (BusinessException e) {
			Logger.info("BusinessException in PayeeController - getWWWPaymentLogStatus() - [key: " + e.getKey() + "], GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), e, ServiceConstants.GLOBAL_WALLET_PAYMENTS_LOG_STATUS_SERVICE, httpRequest);
		} catch (ResourceException e) {
			Logger.error("ResourceException in PayeeController - getWWWPaymentLogStatus() - [key: " + e.getKey() + "], GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());
			mobileSession.removeTransaction();
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.SYSTEM_UNAVILABLE, ServiceConstants.GLOBAL_WALLET_PAYMENTS_LOG_STATUS_SERVICE, httpRequest);
		} catch (Exception e) {
			Logger.error("Exception PayeeController - getWWWPaymentLogStatus(): GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			mobileSession.removeTransaction();
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.GENERIC_ERROR, ServiceConstants.GLOBAL_WALLET_PAYMENTS_LOG_STATUS_SERVICE, httpRequest);
		}
		finally {
			endPerformanceLog(logName);
		}	
		return response;
	}


	public ErrorResp validate(IMBReq serviceRequest, HttpServletRequest request) {
		Logger.info("Service request object - " + ReflectionToStringBuilder.toString(serviceRequest), this.getClass());
		return mbAppValidator.validate(serviceRequest, request);
	}

	public void validateRequestHeader(ReqHeader headerReq, HttpServletRequest request) throws BusinessException {
		Logger.debug("Request header validation: " + ReflectionToStringBuilder.toString(headerReq, ToStringStyle.MULTI_LINE_STYLE), this.getClass());
		 mbAppValidator.validateRequestHeader(headerReq, request);
	}

	/**
	 * Response for invalid body request
	 * 
	 * @return
	 */
	@ExceptionHandler( { org.springframework.http.converter.HttpMessageNotReadableException.class })
	@ResponseStatus(org.springframework.http.HttpStatus.OK)
	@ResponseBody
	public IMBResp resolveException() {
		return MBAppUtils.createInvalidMessageBodyResponse(ServiceConstants.ACCOUNT_TRANSFER_SERVICE);
	}
	
	public RespHeader populateResponseHeader(String serviceName, MobileSession mobSession) {
		return helper.populateResponseHeader(serviceName, mobSession, mbAppHelper);
	}
	
	private String startPerformanceLog(HttpServletRequest httpRequest){
		perfLogger.startAllLogs();
		String logName = MBAppUtils.getLogName(httpRequest);
		perfLogger.startLog(logName);
		return logName;
	}
	
	private void endPerformanceLog(String logName){
		perfLogger.endLog(logName);
		perfLogger.endAllLogs();
	}
}
