package au.com.stgeorge.mbank.model.request.expensesplitter;

import java.io.Serializable;
import java.util.List;

import au.com.stgeorge.mbank.model.common.IMBReq;
import au.com.stgeorge.mbank.model.common.ReqHeader;

public class ExpenseSplitterContactListReq implements Serializable,IMBReq{
  
	private static final long serialVersionUID = -3785031820176986767L;
	private ReqHeader header;
	private List<ContactReq> contactList;

	public ReqHeader getHeader() {
		return header;
	}
	public void setHeader(ReqHeader header) {
		this.header = header;
	}
	public List<ContactReq> getContactList() {
		return contactList;
	}
	public void setContactList(List<ContactReq> contactList) {
		this.contactList = contactList;
	}

}
