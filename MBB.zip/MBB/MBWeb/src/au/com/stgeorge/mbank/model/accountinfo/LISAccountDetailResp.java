package au.com.stgeorge.mbank.model.accountinfo;

import java.util.Date;

import au.com.stgeorge.ibank.util.StringUtil;
import au.com.stgeorge.mbank.util.JsonDateSerializer;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;

@JsonInclude(Include.NON_NULL)
public class LISAccountDetailResp{

	private String interestRateType;
	private String repaymentType;
	private String payAdvanceAmt;
	private String nextPaymentAmt;
	private Date nextPaymentDate;
	private String dueAmt;
	private String repaymentAccount;	
	private String lastPaymentAmt;
	private Date lastPaymentDate;
	private String paymentCycleDisp;	
	private String availRedrawAmt;
	private String arrearsAmt;
	private String remainTermDisp;
	private String forecastTermDisp;	
	private HomeLoanIncreaseResp homeLoanIncreaseResp;
	private InterestAmtDetailResp interestCharged;
	private String indicativeRepaymentFlag;
	private String investmentInd;
	private String intOnlyMatDate;

    public String getIntOnlyMatDate() {
  	return intOnlyMatDate;
    }

    public void setIntOnlyMatDate(String intOnlyMatDate) {
  	this.intOnlyMatDate = intOnlyMatDate;
    } 
	
	public String getIndicativeRepaymentFlag() {
		return indicativeRepaymentFlag;
	}
	public void setIndicativeRepaymentFlag(String indicativeRepaymentFlag) {
		this.indicativeRepaymentFlag = indicativeRepaymentFlag;
	}
	public String getInterestRateType() {
		return interestRateType;
	}
	public void setInterestRateType(String interestRateType) {
		this.interestRateType = interestRateType;
	}
	public String getRepaymentType() {
		return repaymentType;
	}
	public void setRepaymentType(String repaymentType) {
		this.repaymentType = repaymentType;
	}
	public InterestAmtDetailResp getInterestCharged() {
		return interestCharged;
	}
	public void setInterestCharged(InterestAmtDetailResp interestCharged) {
		this.interestCharged = interestCharged;
	}
	public String getRemainTermDisp() {
		return remainTermDisp;
	}
	public void setRemainTermDisp(String remainTermDisp) {
		this.remainTermDisp = remainTermDisp;
	}
	public String getForecastTermDisp() {
		return forecastTermDisp;
	}
	public void setForecastTermDisp(String forecastTermDisp) {
		this.forecastTermDisp = forecastTermDisp;
	}	
	public String getPaymentCycleDisp() {
		return paymentCycleDisp;
	}
	public void setPaymentCycleDisp(String paymentCycleDisp) {
		this.paymentCycleDisp = paymentCycleDisp;
	}
	
	public String getPayAdvanceAmt() {
		return payAdvanceAmt;
	}
	public void setPayAdvanceAmt(String payAdvanceAmt) {
		this.payAdvanceAmt = payAdvanceAmt;
	}
	
	@JsonSerialize(using = JsonDateSerializer.class)
	@JsonInclude(Include.NON_NULL)
	public Date getNextPaymentDate() {
		return nextPaymentDate;
	}
	public void setNextPaymentDate(Date nextPaymentDate) {
		this.nextPaymentDate = nextPaymentDate;
	}
	public String getDueAmt() {
		return dueAmt;
	}
	public void setDueAmt(String dueAmt) {
		this.dueAmt = dueAmt;
	}	
	public String getLastPaymentAmt() {
		return lastPaymentAmt;
	}
	public void setLastPaymentAmt(String lastPaymentAmt) {
		this.lastPaymentAmt = lastPaymentAmt;
	}	
	@JsonSerialize(using = JsonDateSerializer.class)
	@JsonInclude(Include.NON_NULL)
	public Date getLastPaymentDate() {
		return lastPaymentDate;
	}
	public void setLastPaymentDate(Date lastPaymentDate) {
		this.lastPaymentDate = lastPaymentDate;
	}	
	public String getAvailRedrawAmt() {
		return availRedrawAmt;
	}
	public void setAvailRedrawAmt(String availRedrawAmt) {
		this.availRedrawAmt = availRedrawAmt;
	}
	public String getArrearsAmt() {
		return arrearsAmt;
	}
	public void setArrearsAmt(String arrearsAmt) {
		this.arrearsAmt = arrearsAmt;
	}	
	public String getNextPaymentAmt() {
		return nextPaymentAmt;
	}
	public void setNextPaymentAmt(String nextPaymentAmt) {
		this.nextPaymentAmt = nextPaymentAmt;
	}			
	
	public void setRepaymentAccount(String repaymentAccount) {
		this.repaymentAccount = repaymentAccount;
	}
	
	public String getrepaymentAccountDisp()
	{
		if(repaymentAccount !=null)
			return StringUtil.formatDDAAccountNumber(repaymentAccount);
		else 
			return null;
	}
	public HomeLoanIncreaseResp getHomeLoanIncrease() {
		return homeLoanIncreaseResp;
	}
	public void setHomeLoanIncreaseLinkResp(HomeLoanIncreaseResp homeLoanIncreaseResp) {
		this.homeLoanIncreaseResp = homeLoanIncreaseResp;
	}
	public String getInvestmentInd() {
		return investmentInd;
	}
	public void setInvestmentInd(String investmentInd) {
		this.investmentInd = investmentInd;
	}
	
	
	
}
