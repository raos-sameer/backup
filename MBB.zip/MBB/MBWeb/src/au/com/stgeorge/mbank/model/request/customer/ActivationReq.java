package au.com.stgeorge.mbank.model.request.customer;

import java.io.Serializable;

import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.Length;

import au.com.stgeorge.ibank.businessobject.BusinessException;
import au.com.stgeorge.mbank.model.common.IMBReq;
import au.com.stgeorge.mbank.model.common.ReqHeader;

public class ActivationReq implements IMBReq, Serializable{
	
	private static final long serialVersionUID = -256469501889499119L;

	@Size(max = 16,message = ""+BusinessException.SMPL_INV_INP_PARAMS)
	@Pattern(regexp="([0-9]+)",message = ""+BusinessException.SMPL_INV_INP_PARAMS)
	private String accessNumber;

	@Size(min=4, max = 6, message = "{error.customer.credential.invalid}" )
   @Pattern(regexp = "([0-9]+)", message = "{error.customer.credential.invalid}")
	private String newSecNum;
  
	@Size(min=6, max = 16,  message = "{error.customer.credential.invalid}" )
	@Pattern(regexp="([a-zA-Z0-9]+)",  message = "{error.customer.credential.invalid}")
	private String newPassword;

	@Size(min=6, max = 16, message = ""+BusinessException.SMPL_INV_INP_PARAMS)
	@Pattern(regexp="([a-zA-Z0-9]+)",message = ""+BusinessException.SMPL_INV_INP_PARAMS)
	private String password;
	
	@Length(max = 50, message = ""+BusinessException.WSVC_INVALID_INPUT_PARAM)
	@Email(message = ""+BusinessException.SMPL_INV_INP_PARAMS)
	private String newEmail;
	
	
	public String getNewEmail() {
		return newEmail;
	}
	public void setNewEmail(String newEmail) {
		this.newEmail = newEmail;
	}
	public String getPassword()
	{
		return password;
	}
	public void setPassword(String password)
	{
		this.password = password;
	}
	public String getNewSecNum()
	{
		return newSecNum;
	}
	public void setNewSecNum(String newSecNum)
	{
		this.newSecNum = newSecNum;
	}

    public String getNewPassword()
	{
		return newPassword;
	}
	public void setNewPassword(String newPassword)
	{
		this.newPassword = newPassword;
	}

	private ReqHeader header;

	public String getAccessNumber() {
		return accessNumber;
	}
	public void setAccessNumber(String accessNumber) {
		this.accessNumber = accessNumber;
	}

	public ReqHeader getHeader()
	{
		return header;
	}
	public void setHeader(ReqHeader header)
	{
		this.header = header;
	}

	public static long getSerialVersionUID() {
		return serialVersionUID;
	}
}
