/**
 * 
 */
package au.com.stgeorge.mbank.controller.accountinfo;

import java.math.BigDecimal;
import java.net.URLEncoder;
import java.text.MessageFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collection;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import au.com.stgeorge.framework.common.logging.Logger;
import au.com.stgeorge.framework.common.util.DateMethods;
import au.com.stgeorge.framework.common.util.StringMethods;
import au.com.stgeorge.ibank.AbusiveTransactionVO;
import au.com.stgeorge.ibank.businessobject.BusinessException;
import au.com.stgeorge.ibank.businessobject.CardDisputeService;
import au.com.stgeorge.ibank.businessobject.HomeLoanService;
import au.com.stgeorge.ibank.businessobject.MerchantTransactionInfo;
import au.com.stgeorge.ibank.businessobject.MerchantTransactionInfoService;
import au.com.stgeorge.ibank.businessobject.ResourceException;
import au.com.stgeorge.ibank.businessobject.SmartPlansService;
import au.com.stgeorge.ibank.businessobject.StatisticsService;
import au.com.stgeorge.ibank.businessobject.assembler.CustomerVOAssembler;
import au.com.stgeorge.ibank.businessobject.assembler.LoanAccountAssembler;
import au.com.stgeorge.ibank.cardispute.vo.DebitCardTranCodeInfo;
import au.com.stgeorge.ibank.common.cache.IBankParams;
import au.com.stgeorge.ibank.common.cache.IBankRefershParams;
import au.com.stgeorge.ibank.common.log.IBankLog;
import au.com.stgeorge.ibank.dao.ReportTransactionDao;
import au.com.stgeorge.ibank.evcrs.businessobject.valueobject.NPPTransactionDetail;
import au.com.stgeorge.ibank.npp.NPPReturnEnum;
import au.com.stgeorge.ibank.servicestation.businessobject.valueobject.ServiceStationVO;
import au.com.stgeorge.ibank.servicestation.util.ServicetationConstants;
import au.com.stgeorge.ibank.util.DateUtils;
import au.com.stgeorge.ibank.util.StringUtil;
import au.com.stgeorge.ibank.valueobject.Account;
import au.com.stgeorge.ibank.valueobject.AccountId;
import au.com.stgeorge.ibank.valueobject.AccountingTransactionHistory;
import au.com.stgeorge.ibank.valueobject.AddonPolicyHolderOptionsVO;
import au.com.stgeorge.ibank.valueobject.AddonPolicyOptionsVO;
import au.com.stgeorge.ibank.valueobject.BusinessLoanAccount;
import au.com.stgeorge.ibank.valueobject.ChequeAccount;
import au.com.stgeorge.ibank.valueobject.CoverageVO;
import au.com.stgeorge.ibank.valueobject.CreditCardAccount;
import au.com.stgeorge.ibank.valueobject.Customer;
import au.com.stgeorge.ibank.valueobject.CustomerTypes;
import au.com.stgeorge.ibank.valueobject.DdaAccount;
import au.com.stgeorge.ibank.valueobject.DirectAccount;
import au.com.stgeorge.ibank.valueobject.GCCAccount;
import au.com.stgeorge.ibank.valueobject.HomeLoanAccount;
import au.com.stgeorge.ibank.valueobject.InsuranceAccount;
import au.com.stgeorge.ibank.valueobject.IntRateDetailsVO;
import au.com.stgeorge.ibank.valueobject.InterestTierVO;
import au.com.stgeorge.ibank.valueobject.LabelAmountVO;
import au.com.stgeorge.ibank.valueobject.LabelValueVO;
import au.com.stgeorge.ibank.valueobject.LoanAccount;
import au.com.stgeorge.ibank.valueobject.OutstandingAuthorisations;
import au.com.stgeorge.ibank.valueobject.PersonalLoanAccount;
import au.com.stgeorge.ibank.valueobject.RunningBalanceTransactionInfo;
import au.com.stgeorge.ibank.valueobject.Statistic;
import au.com.stgeorge.ibank.valueobject.TermDepositAccount;
import au.com.stgeorge.ibank.valueobject.TransactionHistory;
import au.com.stgeorge.ibank.valueobject.TransactionHistoryCrossLink;
import au.com.stgeorge.ibank.valueobject.TransactionInfo;
import au.com.stgeorge.ibank.valueobject.TravelInsuranceAccount;
import au.com.stgeorge.ibank.valueobject.database.CodesVO;
import au.com.stgeorge.ibank.valueobject.database.OriginsVO;
import au.com.stgeorge.ibank.valueobject.globalWallet.GlobalWalletCard;
import au.com.stgeorge.ibank.valueobject.globalWallet.GlobalWalletDetails;
import au.com.stgeorge.ibank.valueobject.globalWallet.GlobalWalletPurse;
import au.com.stgeorge.ibank.valueobject.transfer.IBankCommonData;
import au.com.stgeorge.mbank.model.accountinfo.AccountDetailResp;
import au.com.stgeorge.mbank.model.accountinfo.AdditionalPolicyHolderInfo;
import au.com.stgeorge.mbank.model.accountinfo.AdditionalPolicyInfo;
import au.com.stgeorge.mbank.model.accountinfo.CRAAccountDetailResp;
import au.com.stgeorge.mbank.model.accountinfo.CarInfo;
import au.com.stgeorge.mbank.model.accountinfo.CardAuthResp;
import au.com.stgeorge.mbank.model.accountinfo.CoverageInfo;
import au.com.stgeorge.mbank.model.accountinfo.DDAAccountDetailResp;
import au.com.stgeorge.mbank.model.accountinfo.GCCAccountDetailResp;
import au.com.stgeorge.mbank.model.accountinfo.HomeLoanIncreaseLinkResp;
import au.com.stgeorge.mbank.model.accountinfo.HomeLoanIncreaseResp;
import au.com.stgeorge.mbank.model.accountinfo.InsuranceAccountDetailResp;
import au.com.stgeorge.mbank.model.accountinfo.InterestAmtDetailResp;
import au.com.stgeorge.mbank.model.accountinfo.InterestRateDetailResp;
import au.com.stgeorge.mbank.model.accountinfo.InterestRateTierDetailResp;
import au.com.stgeorge.mbank.model.accountinfo.LISAccountDetailResp;
import au.com.stgeorge.mbank.model.accountinfo.OfferDetailResp;
import au.com.stgeorge.mbank.model.accountinfo.OverdraftDetailResp;
import au.com.stgeorge.mbank.model.accountinfo.RewardDetailResp;
import au.com.stgeorge.mbank.model.accountinfo.SumInsuredInfo;
import au.com.stgeorge.mbank.model.accountinfo.TDAAccountDetailResp;
import au.com.stgeorge.mbank.model.accountinfo.TDAFlexiDetailResp;
import au.com.stgeorge.mbank.model.accountinfo.TranDetailResp;
import au.com.stgeorge.mbank.model.accountinfo.TranHistoryResp;
import au.com.stgeorge.mbank.model.accountinfo.TravelInsuranceAccountDetailsResp;
import au.com.stgeorge.mbank.model.common.AccountKeyInfoResp;
import au.com.stgeorge.mbank.model.common.AddressResp;
import au.com.stgeorge.mbank.model.common.IMBResp;
import au.com.stgeorge.mbank.model.common.KeyValueResp;
import au.com.stgeorge.mbank.model.common.RespHeader;
import au.com.stgeorge.mbank.model.request.accountinfo.AccountInfoReq;
import au.com.stgeorge.mbank.model.request.accountinfo.AdvanceSearchReq;
import au.com.stgeorge.mbank.model.response.ErrorResp;
import au.com.stgeorge.mbank.model.response.TransCrosSellServiceResp;
import au.com.stgeorge.mbank.model.response.TransactionDetailResp;
import au.com.stgeorge.mbank.model.response.TransactionNppDetailsResp;
import au.com.stgeorge.mbank.model.response.accountinfo.AccountInfoResp;
import au.com.stgeorge.mbank.model.response.accountinfo.GlobalWalletAccountInfoResp;
import au.com.stgeorge.mbank.model.response.accountinfo.GlobalWalletCardResp;
import au.com.stgeorge.mbank.model.response.accountinfo.GlobalWalletPurseResp;
import au.com.stgeorge.mbank.model.response.lwc.MerchantAddress;
import au.com.stgeorge.mbank.model.response.lwc.MerchantContactDetails;
import au.com.stgeorge.mbank.model.response.lwc.MerchantDetailsResp;
import au.com.stgeorge.mbank.model.response.servicestation.ServiceStationResp;
import au.com.stgeorge.mbank.session.MobileSession;
import au.com.stgeorge.mbank.util.MBAppConstants;
import au.com.stgeorge.mbank.util.MBAppHelper;

/**
 * @author C50216
 *
 */
@Service
public class AccountInfoHelper {

	private static final String CRUISE_PACK = "CRUIS";

	private static final String SNOW_PACK_L = "SNOWL";
	private static final String SNOW_PACK_D = "SNOWD";
	
	private static final String SL_ACTION_EXTSER = "EXTSER";
	private static final String SL_ACTION_SAEXT = "SAEXT";
	private static final String SL_DESC_TOP = "TOP";
	private static final String SL_DESC_BOTTOM = "BOTTOM";
	private static final String SL_DESC = "Description:{0}|from date:{1}|to date:{2}|from amount:{3}|to amount:{4}";
	private static final String LWC_IDENTIFIER = "LWCDetailsDisplayed";
	private static final String SEPARATOR = "|";
	private static final int ENTRY_POINT_0 = 0;
	private static final int ENTRY_POINT_1 = 1;
	private static final int ENTRY_POINT_2 = 2;
	private static final long RETURN_PAYMENT_MICR_CODE = 77;
	private static final long NPP_SCT_RETURN_PAYMENT_TRAN_CODE = 11601;//NPP SCT- Credit Return
	private static final long NPP_OSKO_RETURN_PAYMENT_TRAN_CODE = 11603;//NPP OSKO- Credit Return
	private static final String OSKO_DEPOSIT = "osko deposit";
	
	@Autowired
	private MBAppHelper mbAppHelper;
	
	@Autowired
	HomeLoanService hliAccountsService;
	
	@Autowired
	CardDisputeService cardDisputeService;

	@Autowired
	MerchantTransactionInfoService merchantTransactionInfoService; 
	
	@Autowired
	SmartPlansService smartPlanService;
	
	@Autowired
	private IBankRefershParams ibankRefreshParams;
	
	@Autowired
	private ReportTransactionDao reportTransactionDAO;
	
	private static final String BUSINESS_ACCESS_SAVER_PROD_CODE = "3610";
	private static final String CURRENCY_DETAIL="CurrencyDetail";
	
	//19E1 CI - Removing increase transaction history CI item
	//19E1 Release Fix Passing TransactionHistory object from session to remove reference to session object
	protected IMBResp populateResp(MobileSession mbSession , TransactionHistory tranHistorySession,Account acct, Collection cardAuths,StringBuffer[] cardAuthtotAmt, TransactionHistory trxnHist, ServiceStationResp serviceStationResp, boolean categorisationFlag, boolean isCategorisationAvailableForTranHistory,IBankCommonData commonData) throws ResourceException, BusinessException {
		return populateResp(mbSession,tranHistorySession,acct,cardAuths,cardAuthtotAmt,trxnHist,serviceStationResp,categorisationFlag,isCategorisationAvailableForTranHistory, false,commonData);
	}
	//19E1 CI - Removing increase transaction history CI item
	//19E1 Release Fix Passing TransactionHistory object from session to remove reference to session object
	protected IMBResp populateResp(MobileSession mbSession, TransactionHistory tranHistorySession ,Account acct, Collection cardAuths,StringBuffer[] cardAuthtotAmt, TransactionHistory trxnHist, ServiceStationResp serviceStationResp, boolean categorisationFlag, boolean isCategorisationAvailableForTranHistory,boolean isRespCameFromExtendHist, IBankCommonData commonData) throws ResourceException, BusinessException {		
		AccountInfoResp acctDtlResponse = new AccountInfoResp();

		if(acct != null){			
			AccountDetailResp mbAcctDet = populateAcctDetailResp(mbSession.getCustomer(), acct, mbSession.getOrigin());			
			if(categorisationFlag){
				mbAcctDet.setAllowTnxCategorisation(true);
			}
			acctDtlResponse.setAccountDetail(mbAcctDet);	
			
			if (Account.AHI.equalsIgnoreCase(acct.getAccountId().getApplicationId()) || Account.AMI.equalsIgnoreCase(acct.getAccountId().getApplicationId())  || Account.ATI.equalsIgnoreCase(acct.getAccountId().getApplicationId())){
				mbSession.setPolicyAppId(acct.getAccountId().getApplicationId());
				mbSession.setPolicySubProdCode(acct.getAccountId().getSubProductCode());
			}
		}				
		if ( (Account.CREDIT_CARD.equalsIgnoreCase(acct.getAccountId().getEhubProductCode())
				|| Account.SAVING_ACCOUNT.equalsIgnoreCase(acct.getAccountId().getEhubProductCode())
				|| Account.CHEQUE_ACCOUNT.equalsIgnoreCase(acct.getAccountId().getEhubProductCode())
				)
				&& !acct.getAccountId().isSenseSavingAccount() 
				&& !MBAppHelper.isHISAAccount(acct.getAccountId().getSubProductCode())){
						
			CardAuthResp cardAuth = new CardAuthResp();			
			
			if(cardAuths != null){			
				BigDecimal totalAmount = new BigDecimal(0);
				cardAuth.setAuthList(getCardAuthResp(cardAuths,acct.getAccountId().getApplicationId()));			
				if(Account.CREDIT_CARD.equalsIgnoreCase(acct.getAccountId().getEhubProductCode()))
					totalAmount = new BigDecimal(Double.parseDouble(cardAuthtotAmt[0].toString()));
				else				
					totalAmount = getCardAuthTotalAmount(cardAuths);							
				
				cardAuth.setTotAmt(StringUtil.formatBigDecimal(totalAmount.multiply(new BigDecimal(-1))));

			}
						
			acctDtlResponse.setCardAuth(cardAuth);			
		}
		
		
		Calendar toDateCalendar = Calendar.getInstance();
		//19E1 CI - Removing increase transaction history CI item
		//toDateCalendar.add(Calendar.DAY_OF_MONTH, -Integer.parseInt(histPeriod));
		toDateCalendar.add(Calendar.DAY_OF_MONTH, -30);
		
		boolean isGoogleSearchAllowed = false;
		
		if(acct.isApplicationIdCra() || acct.isApplicationIdDda()){
		//if(mbAcctDet.getAllowTnxCrossSell()){
			isGoogleSearchAllowed = true;
		}
		
		// 20E4 Smart plan Customer account eligibility check
		boolean isAccountEligibleForSmartPlans = mbSession.getIsAccountEligibleForSmartPlan() != null ? mbSession.getIsAccountEligibleForSmartPlan() : false;
		boolean isAccEligibleForPurchaseSmartPlans = mbSession.getIsAccountEligibleForPurchaseSmartPlan() != null ? mbSession.getIsAccountEligibleForPurchaseSmartPlan() : false;
	
		if(isRespCameFromExtendHist){
			//19E1 Release Fix Passing TransactionHistory object from session to remove reference to session object
			populateAcctHistoryResp(tranHistorySession, acctDtlResponse, trxnHist, toDateCalendar, isCategorisationAvailableForTranHistory, isGoogleSearchAllowed,isRespCameFromExtendHist,commonData, acct.getAccountId().getApplicationId(), isAccountEligibleForSmartPlans, isAccEligibleForPurchaseSmartPlans);
		}else{
			populateAcctHistoryResp(acctDtlResponse, trxnHist, toDateCalendar, isCategorisationAvailableForTranHistory, isGoogleSearchAllowed,commonData, acct.getAccountId().getApplicationId(), isAccountEligibleForSmartPlans, isAccEligibleForPurchaseSmartPlans);
		}
		
		if(serviceStationResp != null){
			acctDtlResponse.setServiceStation(serviceStationResp);
		}
	
		return acctDtlResponse;

	}	
	
	protected void populateAcctHistoryResp(AccountInfoResp resp,TransactionHistory trxnHist,IBankCommonData commonData, boolean isAccountEligibleForSmartPlans, boolean isAccEligibleForPurchaseSmartPlans){
		populateAcctHistoryResp(resp,trxnHist,null, false, false,commonData, null, isAccountEligibleForSmartPlans, isAccEligibleForPurchaseSmartPlans);
	
	}
	
	protected void populateAcctHistoryResp(AccountInfoResp resp,TransactionHistory trxnHist, Calendar toDate, boolean isCategorisationAvailableForTranHistory, boolean isGoogleSearchAllowed, IBankCommonData commonData, String accountType,boolean isAccountEligibleForSmartPlans, boolean isAccEligibleForPurchaseSmartPlans){
		populateAcctHistoryResp(null,resp,trxnHist,toDate,isCategorisationAvailableForTranHistory,isGoogleSearchAllowed,false,commonData, accountType, isAccountEligibleForSmartPlans, isAccEligibleForPurchaseSmartPlans);
	}
	
	
	//19E1 Release Fix Passing TransactionHistory object from session to remove reference to session object
	protected void populateAcctHistoryResp(TransactionHistory tranHistorySession, AccountInfoResp resp,TransactionHistory trxnHist, Calendar toDate, boolean isCategorisationAvailableForTranHistory, boolean isGoogleSearchAllowed, boolean isRespCameFromExtendHist, IBankCommonData commonData, String accountType, boolean isAccountEligibleForSmartPlans, boolean isAccEligibleForPurchaseSmartPlans){
		TranHistoryResp histResp = null;
		int maxTransactions = Integer.parseInt(IBankParams.getExtendTranHistMaxTransaction(commonData.getOrigin()));
		if(toDate != null){
			histResp = new TranHistoryResp();
			histResp.setToDate(String.valueOf(toDate.getTimeInMillis()));
		}
		if(trxnHist != null){
			if(histResp == null){
				histResp = new TranHistoryResp();
			}
			 
			histResp.setTranList(getTrxnHistoryResp(commonData.getOrigin(), commonData.getCustomer().getGcis(), accountType,trxnHist, isCategorisationAvailableForTranHistory, isGoogleSearchAllowed, isAccountEligibleForSmartPlans, isAccEligibleForPurchaseSmartPlans));
			
			if(trxnHist.getTotalCount() != null && trxnHist.getTotalCount() > maxTransactions){
				Logger.debug("DB count is more than "+maxTransactions+" | DB count :: "+trxnHist.getTotalCount(),this.getClass());
				histResp.setHasMoreTran(true);
			}
			
			if(isRespCameFromExtendHist){
				//19E1 Release Fix Passing TransactionHistory object from session to remove reference to session object
				if(tranHistorySession!=null && tranHistorySession.getTransactions()!=null){
					if(tranHistorySession.getTransactions().size() == maxTransactions){
						Logger.debug("mbSession transactions size | max reached | return true ::"+tranHistorySession.getTransactions().size(), this.getClass());
						histResp.setMaxTransactionsReached(true);
					}else{
						Logger.debug("mbSession transactions size |max not reached | return false ::"+tranHistorySession.getTransactions().size(), this.getClass());
						histResp.setMaxTransactionsReached(false);
					}
				}
			}else{
				Logger.debug("Switch is off | Setting MaxTransactionsReached as false | isRespCameFromExtendHist value ::"+isRespCameFromExtendHist, this.getClass());
				histResp.setMaxTransactionsReached(false);
				
				if(("Y").equalsIgnoreCase(trxnHist.getMoreToCome())){
					histResp.setHasMoreTran(true);					
				}
			}
			
			
			histResp.setNoMoreRecordsStored(trxnHist.getLessThanMinDate());
			histResp.setOpenDate(trxnHist.getOpenDate());
			histResp.setClosingDate(trxnHist.getClosingDate());
			histResp.setOpeningBalance(trxnHist.getOpeningBalance());
			histResp.setClosingBalance(trxnHist.getClosingBalance());
		}
		resp.setTranHistory(histResp);			
	}
	
	private AccountDetailResp populateAcctDetailResp(Customer customer, Account acct, String origin) {
		
		
		AccountDetailResp acctDtl = new AccountDetailResp();		 
		AccountKeyInfoResp keyInfo = null;
		Map<String,String> map = new HashMap<String,String>();
		String interestRate = null;
		String productName = null;	
		Boolean isCardLinked = false;
		
		if(Account.SAVING_ACCOUNT.equalsIgnoreCase(acct.getAccountId().getEhubProductCode())){
									
			DdaAccount ddaAcct = (DdaAccount)acct;			
			DDAAccountDetailResp mbDDADtl = getSAVAcctResp(origin,customer,ddaAcct,map);
								
			mbDDADtl.setGetCashEligible(checkGetCashEligibility(acct));			
			acctDtl.setDdaDetail(mbDDADtl);
			
			keyInfo = mbAppHelper.getAcctKeyInfoResp(ddaAcct);																			
			productName = ddaAcct.getAccountId().getProductName();
			interestRate = map.get("interestRate");
			
			mbDDADtl.setHomeLoanIncreaseResp(getHomeLoanIncreaseLink(ddaAcct.getDispLoanIncreaseLink()));
			//17E2 Service Interaction and Cross Sell -- Used to check whether DDA account is linked to card or not
			if(ddaAcct.getAtmAccessInd() != null && ddaAcct.getAtmAccessInd().equalsIgnoreCase("Y")){
			isCardLinked = true;
			}
		}
		else if(Account.DRAGON_DIRECT.equalsIgnoreCase(acct.getAccountId().getEhubProductCode())){
									
			DirectAccount draAcct = (DirectAccount)acct;			
			DDAAccountDetailResp mbDDADtl = getDRAAcctResp(customer,draAcct,map);
			mbDDADtl.setGetCashEligible(checkGetCashEligibility(acct));
			acctDtl.setDdaDetail(mbDDADtl);						
			keyInfo = mbAppHelper.getAcctKeyInfoResp(draAcct);																		
			productName = draAcct.getAccountId().getProductName();
			interestRate = map.get("interestRate");
									
		}
		else if(Account.CHEQUE_ACCOUNT.equalsIgnoreCase(acct.getAccountId().getEhubProductCode())){
																	
			ChequeAccount chqAcct = (ChequeAccount)acct;			
			DDAAccountDetailResp mbDDADtl = getCHQAcctResp(origin,chqAcct,map);
			mbDDADtl.setGetCashEligible(checkGetCashEligibility(acct));
			acctDtl.setDdaDetail(mbDDADtl);
			
			keyInfo = mbAppHelper.getAcctKeyInfoResp(chqAcct);																			
			productName = chqAcct.getAccountId().getProductName();																					
			interestRate = map.get("interestRate");
			
			mbDDADtl.setHomeLoanIncreaseResp(getHomeLoanIncreaseLink(chqAcct.getDispLoanIncreaseLink()));
			//17E2 Service Interaction and Cross Sell -- Used to check whether DDA account is linked to card or not
			if(chqAcct.getAtmAccessInd() != null && chqAcct.getAtmAccessInd().equalsIgnoreCase("Y")){
				isCardLinked = true;
				}
			
		}
		else if(Account.CREDIT_CARD.equalsIgnoreCase(acct.getAccountId().getEhubProductCode())){
										
			CreditCardAccount craAcct = (CreditCardAccount)acct;
			CRAAccountDetailResp mbCraDtl = getCRAAcctResp(craAcct,customer);
			acctDtl.setCraDetail(mbCraDtl);
			
			interestRate = craAcct.getInterestRate().toString();
			
			keyInfo = mbAppHelper.getAcctKeyInfoResp(craAcct);
			
			productName = craAcct.getAccountId().getProductName();


			Logger.debug("AccountInfoHelper populateAcctDetailResp():::::: accountNumber"+craAcct.getAccountId().getAccountNumber()+" ,CRA Acct allwPointsBalDisplay:::"+craAcct.isAllowPointsBalDisplay()+" ,CRA Points Bal::::"+craAcct.getPointBal()+",Rewards Date::::"+craAcct.getRewardAsAtDate(),this.getClass());
				if ( Boolean.TRUE.equals(IBankParams.getSwitch(IBankParams.DEFAULT_ORIGIN,IBankParams.MGRP_SWITCH )) && mbCraDtl.getRewardDetail()!=null ) {
					acctDtl.setShowRewards(true);
					
					acctDtl.setRewardsPoints(String.valueOf(mbCraDtl.getRewardDetail().getPointBalance()));
				}
			
			//17E2 Service Interaction and Cross Sell -- CRA account always has a card
			isCardLinked = true;
			 
		}else if(Account.LOAN_ACCOUNT.equalsIgnoreCase(acct.getAccountId().getEhubProductCode())){
											
			LoanAccount lisAcct = (LoanAccount)acct;
			LISAccountDetailResp mbLisDtl = getLISAcctResp(lisAcct,customer);			
			acctDtl.setLisDetail(mbLisDtl);
			
			interestRate = lisAcct.getInterestRate().toString();
			
			keyInfo = mbAppHelper.getAcctKeyInfoResp(lisAcct);
			
			productName = lisAcct.getAccountId().getProductName();
						
			mbLisDtl.setHomeLoanIncreaseLinkResp(getHomeLoanIncreaseLink(lisAcct.getDispLoanIncreaseLink()));
			
		}else if(Account.TERM_DEPOSIT.equalsIgnoreCase(acct.getAccountId().getEhubProductCode())){
						
			TermDepositAccount tdaAcct = (TermDepositAccount)acct;
			TDAAccountDetailResp mbTdaDtl = getTDAAcctResp(tdaAcct,customer);	
			acctDtl.setTdaDetail(mbTdaDtl);
			
			interestRate = tdaAcct.getInterestRate().toString();
			
			keyInfo = mbAppHelper.getAcctKeyInfoResp(tdaAcct);
			
			productName = tdaAcct.getAccountId().getProductName();
			
		}else if(Account.GCC.equalsIgnoreCase(acct.getAccountId().getApplicationId())){
									
			GCCAccount gccAcct = (GCCAccount)acct;			
			GCCAccountDetailResp mbGccDtl = getGCCcctResp(gccAcct);
			
			CodesVO codesVO = IBankParams.getCodesData(origin,	IBankParams.CONFIGURATION_PROPERTIES, "GCCFundingSwitch");
			mbGccDtl.setAllowFunding( isGCCFundingSwitchON(origin));
			
			OriginsVO myOriginVO  = IBankParams.getOrigin(origin);
			OriginsVO baseOrigin  = IBankParams.getOrigin(myOriginVO.getBankName());

			
			CodesVO appStoreCodesVO = IBankParams.getCodesData(baseOrigin.getBankName(),	"GCCDetails", "AppleStoreURL");
			CodesVO googleCodesVO = IBankParams.getCodesData(baseOrigin.getBankName(),	"GCCDetails", "GooglePlayURL");

			try
			{
				mbGccDtl.setItunesUrl( URLEncoder.encode( appStoreCodesVO.getMessage() ,"UTF-8" ) );
				mbGccDtl.setGoogleUrl( URLEncoder.encode( googleCodesVO.getMessage() ,"UTF-8" ) );
			}
			catch (Exception e)
			{
				Logger.error("Unable to encode " + appStoreCodesVO.getMessage(), e, this.getClass());
			}

			
			keyInfo = mbAppHelper.getAcctKeyInfoResp(gccAcct);																			
			productName = gccAcct.getAccountId().getProductName();
			acctDtl.setGccDetail(mbGccDtl);
//			mbDDADtl.setHomeLoanIncreaseResp(getHomeLoanIncreaseLink(ddaAcct.getDispLoanIncreaseLink()));
		}else if (Account.AHI.equalsIgnoreCase(acct.getAccountId().getApplicationId()) || Account.AMI.equalsIgnoreCase(acct.getAccountId().getApplicationId()))
		{
			InsuranceAccount insAcct = (InsuranceAccount) acct;
			InsuranceAccountDetailResp insActDtlsResp = getInsuranceAccDtlsResp(insAcct, origin);
			
			acctDtl.setInsDetail(insActDtlsResp);
			keyInfo = mbAppHelper.getAcctKeyInfoResp(insAcct);																			
			productName = insAcct.getAccountId().getProductName();
		}else if (Account.ATI.equalsIgnoreCase(acct.getAccountId().getApplicationId()))
		{
			TravelInsuranceAccount insAcct = (TravelInsuranceAccount) acct;
			TravelInsuranceAccountDetailsResp travelInsActDtlsResp = getInsuranceAccDtlsResp(insAcct, origin);
			
			acctDtl.setAtiDetail(travelInsActDtlsResp);
			keyInfo = mbAppHelper.getAcctKeyInfoResp(insAcct);																			
			productName = insAcct.getAccountId().getProductName();
		}
		
		acctDtl.setAccountKey(keyInfo);
		acctDtl.setProductName(productName);
		acctDtl.setInterestRate(interestRate);
		acctDtl.setBalance(acct.getBalanceDisplay().toString());
		if((!acct.isApplicationIdCda()||acct.getAccountId().getSubProductCode().equals("80")) && ! (Account.AHI.equalsIgnoreCase(acct.getAccountId().getApplicationId()) || Account.AMI.equalsIgnoreCase(acct.getAccountId().getApplicationId())  || Account.ATI.equalsIgnoreCase(acct.getAccountId().getApplicationId())))
		{
		acctDtl.setAvailBalance(acct.getAvailableBalance().toString());
		}
		else
		{
		acctDtl.setAvailBalance(null);
		}
		//17E2 Service Interaction and Cross Sell -- Start
			CodesVO excludedSubProd = null;
			if(Account.DDA.equalsIgnoreCase(acct.getAccountId().getApplicationId())){
				acctDtl.setAllowTnxCrossSell(true);
				acctDtl.setCardLinked(isCardLinked);
				excludedSubProd = IBankParams.getCodesData(IBankParams.DEFAULT_ORIGIN,IBankParams.TRANSACTION_CROSS_LINK, IBankParams.EXCLUDED_SUBPRODUCTS_DDA);
			}else if(Account.CRA.equalsIgnoreCase(acct.getAccountId().getApplicationId())){
				acctDtl.setAllowTnxCrossSell(true);
				acctDtl.setCardLinked(isCardLinked);
				excludedSubProd = IBankParams.getCodesData(IBankParams.DEFAULT_ORIGIN,IBankParams.TRANSACTION_CROSS_LINK, IBankParams.EXCLUDED_SUBPRODUCTS_CRA);
			}
			CodesVO codesVo = IBankParams.getCodesData(IBankParams.DEFAULT_ORIGIN, IBankParams.CONFIGURATION_PROPERTIES, IBankParams.OPTIMIZATION_TRAN_DETAILS);
			String optimizationSwitch = IBankParams.OFF;
			if(null != codesVo) 
				optimizationSwitch = codesVo.getMessage();
			if(IBankParams.OFF.equals(optimizationSwitch)) {
					
				Logger.info("Excluded Subproduct code " + acct.getAccountId().getSubProductCode(), this.getClass());
				if(excludedSubProd != null && !StringMethods.isEmptyString(excludedSubProd.getMessage())){
					String[] excludedSubProducts = excludedSubProd.getMessage().split(",");				
					if(excludedSubProducts != null && excludedSubProducts.length > 0)
	                { 
						List<String> excludedSubProductList = Arrays.asList(excludedSubProducts);
	                      if(excludedSubProductList.contains(acct.getAccountId().getSubProductCode()))
	                      {
	                    	  acctDtl.setAllowTnxCrossSell(false);
	                      }
	                }
				}
			}
		//acctDtl.setIsCardLinked(isCardLinked);
		//17E2 Service Interaction and Cross Sell -- End
			
			//17E4 Share BSB Account Number
			String ehubProductCode = acct.getAccountId().getEhubProductCode();
			if(Account.LIS.equalsIgnoreCase(ehubProductCode) 
					|| Account.CREDIT_CARD.equalsIgnoreCase(ehubProductCode) 
					|| Account.TERM_DEPOSIT.equalsIgnoreCase(ehubProductCode) 
					|| Account.BT.equalsIgnoreCase(ehubProductCode) 
					|| Account.AHI.equalsIgnoreCase(ehubProductCode)
					|| Account.AMI.equalsIgnoreCase(ehubProductCode)
					|| Account.ATI.equalsIgnoreCase(ehubProductCode)
					|| Account.GCC.equalsIgnoreCase(ehubProductCode)){
				acctDtl.setShareAllowed(false);
			}else{
				acctDtl.setShareAllowed(true);
			}
			
			if(IBankParams.isExtendTranHistSwitchOn(origin,acct.getAccountId().getApplicationId(),customer.getGcis())){
				Logger.debug(" returning true for isExtendTranHistSwitchOn with origin "+ origin +" acctType" + acct.getAccountId().getApplicationId(), IBankParams.class);
				acctDtl.setAdvanceSearchSwitch(true);
			}
			else{
				Logger.debug(" returning false for isExtendTranHistSwitchOn with origin "+ origin +" acctType" + acct.getAccountId().getApplicationId(), IBankParams.class);
				acctDtl.setAdvanceSearchSwitch(false);
			}	

			return acctDtl;
		
	}
	
	private InsuranceAccountDetailResp getInsuranceAccDtlsResp(InsuranceAccount insuranceAcct, String origin) {
		InsuranceAccountDetailResp insAcctDtlsResp = new InsuranceAccountDetailResp();
		
		insAcctDtlsResp.setPolicyNumber(insuranceAcct.getAccountId().getAccountNumber());
		
		if(insuranceAcct.getPremiumAmount()!=null){
			insAcctDtlsResp.setPremiumAmt(insuranceAcct.getPremiumAmount().toString());
		}
		//19E4 Tech Debt Start:Switch Removal
		/*CodesVO codesResults = IBankParams.getCodesData(IBankParams.DEFAULT_ORIGIN,IBankParams.CONFIGURATION_PROPERTIES, IBankParams.INSURANCE_POLICY_V2_SWITCH);
		if(codesResults != null && IBankParams.OFF.equalsIgnoreCase(codesResults.getMessage())){*/
		/*if(insuranceAcct.getPremiumAmountType()!=null){
			insAcctDtlsResp.setPremiumType(insuranceAcct.getPremiumAmountType().toLowerCase());
		}*/
		//insAcctDtlsResp.setAdditionalInfo(false);
		
		
		/*if (IBankParams.HOME_CONTENTS_INSURANCE.equalsIgnoreCase(insuranceAcct.getAccountId().getSubProductCode()))
		{
			CodesVO codesResult = IBankParams.getCodesData(IBankParams.getBaseOriginCode(origin),IBankParams.EXTERNAL_LINKS, IBankParams.INSURANCE+"|"+insuranceAcct.getAccountId().getApplicationId()+"|"+insuranceAcct.getAccountId().getSubProductCode()+"|"+IBankParams.CLAIM_INSURANCE);
			insAcctDtlsResp.setClaimUrl(codesResult.getMessage());
		}*/
		/*}*/
	/*	else{*/
			if(insuranceAcct.getPremiumAmountType()!=null){
				insAcctDtlsResp.setPremiumType(insuranceAcct.getPremiumAmountType());
			}
			insAcctDtlsResp.setAdditionalInfo(true);
			insAcctDtlsResp.setStartDate(insuranceAcct.getStartDate().toString());
			
			CodesVO codesResult = IBankParams.getCodesData(IBankParams.getBaseOriginCode(origin),IBankParams.EXTERNAL_LINKS, IBankParams.INSURANCE+"|"+insuranceAcct.getAccountId().getApplicationId()+"|"+insuranceAcct.getAccountId().getSubProductCode()+"|"+IBankParams.CLAIM_INSURANCE);
			if(codesResult != null){
			insAcctDtlsResp.setClaimUrl(codesResult.getMessage());
			}
		/*}*/
			//19E4 Tech Debt End:Switch Removal
		insAcctDtlsResp.setExpiryDate(insuranceAcct.getExpiryDate().toString());
	
		/*if (IBankParams.HOME_CONTENTS_INSURANCE.equalsIgnoreCase(insuranceAcct.getAccountId().getSubProductCode()))
		{
			CodesVO codesResult = IBankParams.getCodesData(IBankParams.getBaseOriginCode(origin),IBankParams.EXTERNAL_LINKS, IBankParams.INSURANCE+"|"+insuranceAcct.getAccountId().getApplicationId()+"|"+insuranceAcct.getAccountId().getSubProductCode()+"|"+IBankParams.CLAIM_INSURANCE);
			insAcctDtlsResp.setClaimUrl(codesResult.getMessage());
		}*/
	
		CodesVO codesResultPDS = IBankParams.getCodesData(IBankParams.getBaseOriginCode(origin),IBankParams.EXTERNAL_LINKS, IBankParams.INSURANCE+"|"+insuranceAcct.getAccountId().getApplicationId()+"|"+insuranceAcct.getAccountId().getSubProductCode());
		if(codesResultPDS != null)
			insAcctDtlsResp.setProductUrl(codesResultPDS.getMessage());
		
		List<CoverageInfo> coverageList = new ArrayList<CoverageInfo>(insuranceAcct.getCoverageList().size());
		for(CoverageVO eachCoverageVo:insuranceAcct.getCoverageList())
		{
			CoverageInfo coverageInfo = new CoverageInfo();
			coverageInfo.setCoverageName(eachCoverageVo.getCoverName());
			coverageInfo.setInsType(eachCoverageVo.getInsuranceType());
			
			if(eachCoverageVo.getRiskAddress() != null){
				AddressResp riskAddress = new AddressResp();
				riskAddress.setLine1(eachCoverageVo.getRiskAddress().getLine1());
				riskAddress.setLine2(eachCoverageVo.getRiskAddress().getLine2());
				coverageInfo.setRiskAddress(riskAddress);
			}
			
			if(eachCoverageVo.getSumInsuredList() != null && eachCoverageVo.getSumInsuredList().size() > 0){
				List<SumInsuredInfo> sumInsuredList = new ArrayList<SumInsuredInfo>(eachCoverageVo.getSumInsuredList().size());
				for(LabelAmountVO eachSumInsured:eachCoverageVo.getSumInsuredList())
				{
					SumInsuredInfo sumInsuredInfo = new SumInsuredInfo();
					sumInsuredInfo.setComponentType(eachSumInsured.getLabel());
					
					if(eachSumInsured.getAmount() != null){
						sumInsuredInfo.setComponentAmt(eachSumInsured.getAmount().toString());
					}else{
						sumInsuredInfo.setComponentAmt("");
					}
					
					sumInsuredList.add(sumInsuredInfo);
				}
			coverageInfo.setInsuredList(sumInsuredList);
			}
			
			if(eachCoverageVo.getAmtInsuredList() != null && eachCoverageVo.getAmtInsuredList().size() > 0){
				List<SumInsuredInfo> sumInsuredList = new ArrayList<SumInsuredInfo>(eachCoverageVo.getAmtInsuredList().size());
				for(LabelValueVO eachSumInsured:eachCoverageVo.getAmtInsuredList())
				{
					SumInsuredInfo sumInsuredInfo = new SumInsuredInfo();
					sumInsuredInfo.setComponentType(eachSumInsured.getLabel());
					
					if(eachSumInsured.getValue() != null){
						sumInsuredInfo.setComponentAmt(eachSumInsured.getValue());
					}else{
						sumInsuredInfo.setComponentAmt("");
					}
					
					sumInsuredList.add(sumInsuredInfo);
				}
			coverageInfo.setInsuredList(sumInsuredList);
			}
			
			
			if(eachCoverageVo.getCarDetailsVO() != null){
				CarInfo carInfo = new CarInfo();
				carInfo.setMake(eachCoverageVo.getCarDetailsVO().getMake());
				carInfo.setModel(eachCoverageVo.getCarDetailsVO().getModel());
				carInfo.setRegoId(eachCoverageVo.getCarDetailsVO().getRego());	
				coverageInfo.setCarDetails(carInfo);			
			}
			
			coverageList.add(coverageInfo);
		}
		insAcctDtlsResp.setCoverageList(coverageList);
		return insAcctDtlsResp;
	}
	
	private TravelInsuranceAccountDetailsResp getInsuranceAccDtlsResp(TravelInsuranceAccount insuranceAcct, String origin) {
		TravelInsuranceAccountDetailsResp insAcctDtlsResp = new TravelInsuranceAccountDetailsResp();
		
		insAcctDtlsResp.setPolicyNumber(insuranceAcct.getAccountId().getAccountNumber());
		insAcctDtlsResp.setExpiryDate(insuranceAcct.getExpiryDate().toString());
		insAcctDtlsResp.setStartDate(insuranceAcct.getStartDate().toString());
		insAcctDtlsResp.setPremiumAmt(insuranceAcct.getPremiumAmount().toString());
		insAcctDtlsResp.setCoverType(insuranceAcct.getCoverType());
		insAcctDtlsResp.setCoverageName(insuranceAcct.getRiskCover());
		insAcctDtlsResp.setCoveredArea(insuranceAcct.getCoveredAreaList());
		insAcctDtlsResp.setPolicyHolders(insuranceAcct.getPolicyHoldersList());
		if(insuranceAcct.getDependentsList()!= null && !insuranceAcct.getDependentsList().isEmpty())
			insAcctDtlsResp.setDependants(insuranceAcct.getDependentsList());
		CodesVO codesResult = IBankParams.getCodesData(IBankParams.getBaseOriginCode(origin),IBankParams.EXTERNAL_LINKS, IBankParams.INSURANCE+"|"+insuranceAcct.getAccountId().getApplicationId()+"|"+IBankParams.CLAIM_INSURANCE);
		if(codesResult != null)
			insAcctDtlsResp.setClaimUrl(codesResult.getMessage());	
	
		CodesVO codesResultPDS = IBankParams.getCodesData(IBankParams.getBaseOriginCode(origin),IBankParams.EXTERNAL_LINKS, IBankParams.INSURANCE+"|"+insuranceAcct.getAccountId().getApplicationId());
		if(codesResultPDS != null)
			insAcctDtlsResp.setProductUrl(codesResultPDS.getMessage());
		if(insuranceAcct.getAdditionalPolicyOptionsList() != null && !insuranceAcct.getAdditionalPolicyOptionsList().isEmpty()){
			List<AdditionalPolicyInfo> additionalPolicyInfoList = new ArrayList<AdditionalPolicyInfo>(insuranceAcct.getAdditionalPolicyOptionsList().size());
			for(AddonPolicyOptionsVO addonOption : insuranceAcct.getAdditionalPolicyOptionsList()){
				AdditionalPolicyInfo additionalPolicyInfo = new AdditionalPolicyInfo();
				additionalPolicyInfo.setComponentType(addonOption.getAddonDescription());
				
				if(!SNOW_PACK_L.equalsIgnoreCase(addonOption.getAddonType()) && !SNOW_PACK_D.equalsIgnoreCase(addonOption.getAddonType()) && !CRUISE_PACK.equalsIgnoreCase(addonOption.getAddonType()))
					additionalPolicyInfo.setComponentAmt(addonOption.getAddonAmount().toString());
				
				additionalPolicyInfoList.add(additionalPolicyInfo);
			}
			insAcctDtlsResp.setAdditionalPolicyOptions(additionalPolicyInfoList);
		}
		
		if(insuranceAcct.getAdditionalPolicyHolderOptionsList() != null && !insuranceAcct.getAdditionalPolicyHolderOptionsList().isEmpty()){
			List<AdditionalPolicyHolderInfo> additionalPolicyHolderInfoList = new ArrayList<AdditionalPolicyHolderInfo>(insuranceAcct.getAdditionalPolicyHolderOptionsList().size());
			for (AddonPolicyHolderOptionsVO addonPolicyHolderOptionsVO : insuranceAcct.getAdditionalPolicyHolderOptionsList()) {
				AdditionalPolicyHolderInfo additionalPolicyHolderInfo = new AdditionalPolicyHolderInfo();
				List<AdditionalPolicyInfo> increasedItems = new ArrayList<AdditionalPolicyInfo>();
				additionalPolicyHolderInfo.setHolderName(addonPolicyHolderOptionsVO.getHolderName());
				
				if(addonPolicyHolderOptionsVO.getIncreasedLimits() != null){
					for (AddonPolicyOptionsVO addonPolicyOptionsVO : addonPolicyHolderOptionsVO.getIncreasedLimits()) {
						AdditionalPolicyInfo additionalPolicyInfo = new AdditionalPolicyInfo();
						additionalPolicyInfo.setComponentType(addonPolicyOptionsVO.getAddonDescription());
						additionalPolicyInfo.setComponentAmt(addonPolicyOptionsVO.getAddonAmount().toString());
						increasedItems.add(additionalPolicyInfo);
					}
					additionalPolicyHolderInfo.setIncreasedLimits(increasedItems);
				}
				if(additionalPolicyHolderInfo.getIncreasedLimits() != null && additionalPolicyHolderInfo.getIncreasedLimits().size()>0)
					additionalPolicyHolderInfoList.add(additionalPolicyHolderInfo);
			}
			
			if(additionalPolicyHolderInfoList != null && !additionalPolicyHolderInfoList.isEmpty()){
				insAcctDtlsResp.setAdditionalPolicyHolderOptions(additionalPolicyHolderInfoList);
			}
		}
		return insAcctDtlsResp;
	}

	private HomeLoanIncreaseResp getHomeLoanIncreaseLink(String eligibilityFlag) {
		if (IBankParams.isHomeLoanIncreaseSwitchOn() && ("X".equals(eligibilityFlag) || "Y".equals(eligibilityFlag))) {
				HomeLoanIncreaseResp homeLoanIncreaseLinkResp = new HomeLoanIncreaseResp();
				homeLoanIncreaseLinkResp.setAppDestination("OAFCLAS");
				return homeLoanIncreaseLinkResp;
		}
		return null;
	}
		
	private DDAAccountDetailResp getSAVAcctResp(String origin, Customer customer,DdaAccount ddaAcct,Map<String,String> map) {
		
		DDAAccountDetailResp acctDtl = new DDAAccountDetailResp();												
		
		CodesVO codeItem=IBankParams.getCodesData(IBankParams.BRAND_ORIGIN, IBankParams.PARAMETER,IBankParams.MIN_INT_RATE_DISPLAY);		
		BigDecimal minInterestRate=new BigDecimal(0);		
		if (codeItem != null) {
			minInterestRate = new BigDecimal(codeItem.getMessage());
		}		
				
		if (!IBankParams.isAccountInterestRateDetlsReq(ddaAcct.getAccountId().getSubProductCode())){
				
			if(!MBAppConstants.RATE_TYPE_SPLIT.equalsIgnoreCase(ddaAcct.getRateInd())) {			
				BigDecimal currentIntRate = ddaAcct.getCurrentIntRate();
				if (currentIntRate != null && (currentIntRate.compareTo(minInterestRate) >= 0)) {				
					if (MBAppConstants.RATE_TYPE_BAL.equalsIgnoreCase(ddaAcct.getRateInd()))
						acctDtl.setStandardInterestRate(currentIntRate.toString());						
					else
						map.put("interestRate",currentIntRate.toString());						
				}								
			}
			if (MBAppConstants.RATE_TYPE_BONUS.equalsIgnoreCase(ddaAcct.getRateInd())) {
				BigDecimal bonusRate = ddaAcct.getBonusRate();			
				if (bonusRate != null && (bonusRate.compareTo(minInterestRate) >= 0)) {
					acctDtl.setBonusRate(bonusRate.toString());					
				}
			}
		}else
			acctDtl.setInterestRateDetail(getInterestRateDetail(origin,ddaAcct));
							
		if (ddaAcct.getAccountId().isSenseAccount()){ 
			if (ddaAcct.getSenseLinkAcctKey()!=null && ddaAcct.getSenseLinkAcctKey().length()>0){						
				
				AccountKeyInfoResp keyInfo = new AccountKeyInfoResp();
				keyInfo.setAccountNum(ddaAcct.getSenseLinkAcctKey());
				keyInfo.setBsb(Integer.parseInt(ddaAcct.getSenseLinkBranchKey()));
				keyInfo.setAccountType(Account.DDA);				
				
				acctDtl.setLinkedAccount(keyInfo);						
			}			
		}		
		if (ddaAcct.getAccountId().isSenseSavingAccount()){
			acctDtl.setSavingsTargetAmt(ddaAcct.getTargetBal().toString());				
		}
		
		if(ddaAcct.isOverDraftAllowed()){
			
			OverdraftDetailResp overDraftDet = new OverdraftDetailResp();
			overDraftDet.setLimitAmt(ddaAcct.getOverDraftLimit().toString());
			overDraftDet.setRate(ddaAcct.getOverDraftRate().toString());
			
			acctDtl.setOverdraft(overDraftDet);
			
		}
							
		acctDtl.setInterestCharged(getInterestAmtDetail(ddaAcct.getIntChargedLastYear(),ddaAcct.getIntChargedThisYear()));
		acctDtl.setInterestEarned(getInterestAmtDetail(ddaAcct.getInterestLastYear(),ddaAcct.getInterestThisYear()));
																						
		return acctDtl;
		
	}	

	private DDAAccountDetailResp getDRAAcctResp(Customer customer,DirectAccount draAcct,Map<String,String> map) {
			
		
		
		DDAAccountDetailResp acctDtl = new DDAAccountDetailResp();
		MBAppHelper mbAppHelper = new MBAppHelper();
								
		CodesVO codeItem=IBankParams.getCodesData(IBankParams.BRAND_ORIGIN, IBankParams.PARAMETER,IBankParams.MIN_INT_RATE_DISPLAY);
		BigDecimal minInterestRate=new BigDecimal(0);		
		if (codeItem != null) {
			minInterestRate = new BigDecimal(codeItem.getMessage());
		}						
		
		if (!MBAppConstants.RATE_TYPE_SPLIT.equalsIgnoreCase(draAcct.getRateInd())) {			
			BigDecimal currentIntRate = draAcct.getCurrentIntRate();
			if (currentIntRate != null && (currentIntRate.compareTo(minInterestRate) >= 0)) {				
				if (MBAppConstants.RATE_TYPE_BAL.equalsIgnoreCase(draAcct.getRateInd()))
					acctDtl.setStandardInterestRate(currentIntRate.toString());						
				else
					map.put("interestRate",currentIntRate.toString());						
			}					
		}
						
		if (MBAppConstants.RATE_TYPE_BONUS.equalsIgnoreCase(draAcct.getRateInd())) {
			BigDecimal bonusRate = draAcct.getBonusRate();		
			if (bonusRate != null && (bonusRate.compareTo(minInterestRate) >= 0)) {
				acctDtl.setBonusRate(bonusRate.toString());					
			}
		}
				
		if(!draAcct.getNominatedAccountNumber().equalsIgnoreCase("")){
			
			AccountKeyInfoResp keyInfo = new AccountKeyInfoResp();
			
			au.com.stgeorge.ibank.valueobject.AccountId acctId = new au.com.stgeorge.ibank.valueobject.AccountId();
			acctId.setAccountNumber(draAcct.getNominatedAccountNumber().replace(" ", ""));
			acctId.setApplicationId(draAcct.getAccountId().getApplicationId());
			
			Account nominatedAcct = mbAppHelper.getAccountbyAccountId(acctId, customer.getAccounts());
			if(nominatedAcct != null)
				keyInfo = mbAppHelper.getAcctKeyInfoResp(nominatedAcct);
			else{										
				keyInfo.setAccountNum(draAcct.getNominatedAccountNumber().replace(" ", ""));
				keyInfo.setBsb(Integer.parseInt(draAcct.getNominatedAccountBsb().replace("-", "")));
				keyInfo.setAccountType(draAcct.getNominatedAcct().getEhubProductCode());
			}			
			acctDtl.setLinkedAccount(keyInfo);
		}
								
		acctDtl.setInterestEarned(getInterestAmtDetail(draAcct.getInterestLastYear(),draAcct.getInterestThisYear()));
			
		
		return acctDtl;
		
	}
	
	private DDAAccountDetailResp getCHQAcctResp(String origin, ChequeAccount chqAcct,Map<String,String> map){
		
		DDAAccountDetailResp acctDtl = new DDAAccountDetailResp();		
								
		CodesVO codeItem=IBankParams.getCodesData(IBankParams.BRAND_ORIGIN, IBankParams.PARAMETER,IBankParams.MIN_INT_RATE_DISPLAY);
		BigDecimal minInterestRate=new BigDecimal(0);		
		if (codeItem != null) {
			minInterestRate = new BigDecimal(codeItem.getMessage());
		}		
				
		if (!IBankParams.isAccountInterestRateDetlsReq(chqAcct.getAccountId().getSubProductCode())){
			if(!MBAppConstants.RATE_TYPE_SPLIT.equalsIgnoreCase(chqAcct.getRateInd())) {
				BigDecimal currentIntRate = chqAcct.getCurrentIntRate();
				if (currentIntRate != null && (currentIntRate.compareTo(minInterestRate) >= 0)) {
					if (MBAppConstants.RATE_TYPE_BAL.equalsIgnoreCase(chqAcct.getRateInd()))
						acctDtl.setStandardInterestRate(currentIntRate.toString());						
					else
						map.put("interestRate",currentIntRate.toString());						
				}					
			}			
			if(MBAppConstants.RATE_TYPE_BONUS.equalsIgnoreCase(chqAcct.getRateInd())) {
				BigDecimal bonusRate = chqAcct.getBonusRate();			
				if (bonusRate != null && (bonusRate.compareTo(minInterestRate) >= 0)) {
					acctDtl.setBonusRate(bonusRate.toString());					
				}
			}
		}else
			acctDtl.setInterestRateDetail(getInterestRateDetail(origin,chqAcct));
			
		if(chqAcct.isOverDraftAllowed()){
			
			OverdraftDetailResp overDraftDet = new OverdraftDetailResp();
			overDraftDet.setLimitAmt(chqAcct.getOverDraftLimit().toString());
			overDraftDet.setRate(chqAcct.getOverDraftRate().toString());
			
			acctDtl.setOverdraft(overDraftDet);
			
		}
							
		acctDtl.setInterestCharged(getInterestAmtDetail(chqAcct.getIntChargedLastYear(),chqAcct.getIntChargedThisYear()));							
		acctDtl.setInterestEarned(getInterestAmtDetail(chqAcct.getInterestLastYear(),chqAcct.getInterestThisYear()));
		
		return acctDtl;
		
	}
		
	private CRAAccountDetailResp getCRAAcctResp(CreditCardAccount craAcct,Customer customer) {
		
		CRAAccountDetailResp mbCraDtl = new CRAAccountDetailResp();			
		
		if("Y".equalsIgnoreCase(customer.getPreference().getCliConsentInd()))
			mbCraDtl.setHasClientConsent(true);
		
		//handleCredCardLimit
		if (
				IBankParams.isCreditLimitIncreaseSwitchOn() && 
				((customer.getCustomerTypes().contains(CustomerTypes.TYPE_GHS) 
				&& CustomerVOAssembler.PERSONAL_CUSTOMER.equalsIgnoreCase(customer.getCustTypeInd()))
			|| (customer.getCustomerTypes().contains(CustomerTypes.TYPE_CHS_GHS)
				&& CustomerVOAssembler.PERSONAL_CUSTOMER.equalsIgnoreCase(customer.getCustTypeInd()) 
				&& CustomerTypes.TYPE_GHS.equalsIgnoreCase(customer.getPrimaryProfile()))))
		{
			if (CreditCardAccount.GOTO_IBNK_SOL_TRIAD.equalsIgnoreCase(craAcct.getAllowCrLimitInc()) || CreditCardAccount.GOTO_ACE_SOL_TRIAD.equalsIgnoreCase(craAcct.getAllowCrLimitInc()))
			{											
				
				OfferDetailResp offerDtl = new OfferDetailResp();
				offerDtl.setOfferAmt(craAcct.getOfferLimit().toString());
				
				BigDecimal minIncreaseAmt = new BigDecimal((IBankParams.getCodesData(IBankParams.BRAND_ORIGIN, IBankParams.CREDIT_CARD_CONFIG,
						IBankParams.CC_MIN_CREDITLIMITINC)).getMessage());				
				offerDtl.setMinIncreaseAmt(minIncreaseAmt.toString());
				
				mbCraDtl.setOfferDetail(offerDtl);				
			}
		}		
		mbCraDtl.setCreditLimitAmt(craAcct.getCreditLimit().toString());
		mbCraDtl.setNextPaymentDate(craAcct.getNextPaymentDate());		
		mbCraDtl.setPayNowAmt(craAcct.getPayNowAmount().toString());
		
		if(craAcct.getStmtBalAmountDisplay()!=null && craAcct.getStmtBalAmountDisplay().compareTo(new BigDecimal(0)) != 0)
			mbCraDtl.setStmtBalanceAmt(craAcct.getStmtBalAmountDisplay().toString());
		
		mbCraDtl.setLastStmtDate(craAcct.getLastStatementDate());	
		
		if(craAcct.getLastPaymentAmount()!=null && craAcct.getLastPaymentAmount().compareTo(new BigDecimal(0)) != 0)
			mbCraDtl.setLastPaymentAmt(craAcct.getLastPaymentAmount().toString());
		
		mbCraDtl.setLastPaymentDate(craAcct.getLastPaymentDate());
		
		if (craAcct.getCashAdvanceRate() != null)
			mbCraDtl.setCashAdvanceRate(craAcct.getCashAdvanceRate().toString());
		else
			mbCraDtl.setCashAdvanceRate(craAcct.getCashIntRateInd().toString());
		
		mbCraDtl.setAvailCredit(craAcct.getAvailableCredit().toString());
		
		if (craAcct.isAllowAccountOwner() && craAcct.isAllowPointsBalDisplay()){
			RewardDetailResp rewardDtl = new RewardDetailResp();
			rewardDtl.setRewardAsAtDate(craAcct.getRewardAsAtDate());
			try {
				rewardDtl.setPointBalance(Integer.parseInt(craAcct.getPointBal()));			
			}catch(NumberFormatException e){
				rewardDtl.setPointBalance(0);
			}
			mbCraDtl.setRewardDetail(rewardDtl);
		}
		
		
		
		
		if ( craAcct.getCreditCardAdditionalInfo() != null && "Y".equalsIgnoreCase(craAcct.getCreditCardAdditionalInfo().getRequiredActivationStatus() ) )
			mbCraDtl.setNeedsActivation(true);
		
		if (IBankParams.YES.equals(craAcct.getCreditCardAdditionalInfo().getProductTransferStatus())){
			
			au.com.stgeorge.ibank.valueobject.AccountId acctId = new au.com.stgeorge.ibank.valueobject.AccountId();
			acctId.setAccountNumber(craAcct.getCreditCardAdditionalInfo().getReplacementAcctNum());
			acctId.setApplicationId(craAcct.getAccountId().getApplicationId());
			
			mbCraDtl.setReplacementAccountIndex(mbAppHelper.getAccountIndexByAccountId(customer.getAccounts(),acctId));
			mbCraDtl.setIsTransferred(true);
		}
		mbCraDtl.setAllowCreditLimitDec(craAcct.isAllowCrLimitDec());
		
		return mbCraDtl;
		
	}	
	
	private LISAccountDetailResp getLISAcctResp(LoanAccount lisAcct,Customer customer){
		
		LISAccountDetailResp mbLisDtl = new LISAccountDetailResp();					
		String nextPaymentAmount = null;
				
		if(lisAcct instanceof HomeLoanAccount){
			HomeLoanAccount hmlAcct = (HomeLoanAccount)lisAcct;
			if(hmlAcct.getNextPaymentAmount()!=null && hmlAcct.getNextPaymentAmount().compareTo(new BigDecimal(0)) != 0){
				nextPaymentAmount = hmlAcct.getNextPaymentAmount().toString();
			}
			if(lisAcct.getIntOnlyMatDate()!=null){
				mbLisDtl.setIntOnlyMatDate(DateMethods.formatDate("yyyy-MM-dd", lisAcct.getIntOnlyMatDate()));
			}
			
		}else if(lisAcct instanceof PersonalLoanAccount){
			PersonalLoanAccount pelAcct = (PersonalLoanAccount)lisAcct;
			if(pelAcct.getRepayment()!=null && pelAcct.getRepayment().compareTo(new BigDecimal(0)) != 0)
				nextPaymentAmount = pelAcct.getRepayment().toString();			
			
		}else if(lisAcct instanceof BusinessLoanAccount){
			BusinessLoanAccount bulAcct = (BusinessLoanAccount)lisAcct;
			if(bulAcct.getNextPaymentAmount()!=null && bulAcct.getNextPaymentAmount().compareTo(new BigDecimal(0)) != 0)
				nextPaymentAmount = bulAcct.getNextPaymentAmount().toString();						
		}
		
		if(!"9".equalsIgnoreCase(lisAcct.getLoanStatus())){
			BigDecimal arrearsBalance=lisAcct.getArrearsBalance();
			if (arrearsBalance != null && arrearsBalance.signum() < 0 && "3".equalsIgnoreCase(lisAcct.getLoanStatus())){
				mbLisDtl.setPayAdvanceAmt(lisAcct.getAbsPrePaymentAmount().toString());				
			}
			else if("11".equalsIgnoreCase(lisAcct.getLoanStatus())){				
					mbLisDtl.setNextPaymentAmt(nextPaymentAmount);
			}
			else{
				//if(!(lisAcct instanceof PersonalLoanAccount))// as per Ibank
				mbLisDtl.setNextPaymentAmt(nextPaymentAmount);
				
				if(lisAcct.getLoanAdditionalInfo()!=null){
					
					mbLisDtl.setNextPaymentDate(lisAcct.getLoanAdditionalInfo().getNextPaymentDate());
					
					if(lisAcct.getLoanAdditionalInfo().getLastPaymentDate()!=null){
						mbLisDtl.setLastPaymentDate(lisAcct.getLoanAdditionalInfo().getLastPaymentDate());
						
						if(lisAcct.getLoanAdditionalInfo().getLastPaymentAmountDisplay()!=null && lisAcct.getLoanAdditionalInfo().getLastPaymentAmountDisplay().compareTo(new BigDecimal(0)) != 0)
							mbLisDtl.setLastPaymentAmt(lisAcct.getLoanAdditionalInfo().getLastPaymentAmountDisplay().toString());
					}
					
					if(lisAcct.getPaymentCycle()!=null && lisAcct.getPaymentCycle().length() > 0)
						mbLisDtl.setPaymentCycleDisp(getPaymentCycle(lisAcct.getPaymentCycle().charAt(lisAcct.getPaymentCycle().length()-1)));
					
				}
				
				if(lisAcct.getOutstandingTransfer()!=null && lisAcct.getOutstandingTransfer().compareTo(new BigDecimal(0)) !=0 )
					mbLisDtl.setDueAmt(lisAcct.getOutstandingTransfer().toString());
				
				if ((LoanAccountAssembler.SAVINGS_TRF).equalsIgnoreCase(lisAcct.getPaymentMethod()))					
						mbLisDtl.setRepaymentAccount(lisAcct.getNominatedAccount());
				
				if(arrearsBalance!=null && arrearsBalance.compareTo(new BigDecimal(0))< 0){	
					mbLisDtl.setPayAdvanceAmt(lisAcct.getAbsPrePaymentAmount().toString());
					
					if (lisAcct.getAvailRedrawAmt() != null && lisAcct.getAvailRedrawAmt().compareTo(new BigDecimal(0))> 0)
						mbLisDtl.setAvailRedrawAmt(lisAcct.getAvailRedrawAmt().toString());
				}
				
				if(arrearsBalance!=null && arrearsBalance.compareTo(new BigDecimal(0)) >=0)
					mbLisDtl.setArrearsAmt(arrearsBalance.toString());			
			}			   															
			mbLisDtl.setInterestCharged(getInterestAmtDetail(lisAcct.getIntChargedLastYear(),lisAcct.getIntChargedThisYear()));											
		}		
		mbLisDtl.setRemainTermDisp(lisAcct.getProjTerm());
		
		mbLisDtl.setInterestRateType(lisAcct.getIntRateType());
		//16E4 Added new Loan Category
		if(!StringMethods.isEmptyString(lisAcct.getInvestmentInd())){
			mbLisDtl.setInvestmentInd(lisAcct.getInvestmentInd());
		}
		
		mbLisDtl.setRepaymentType(lisAcct.getRePaymentType());
		
		if(!StringMethods.isEmptyString(lisAcct.getRePaymentType())&&lisAcct.getRePaymentType().trim().equalsIgnoreCase("Interest Only"))
				mbLisDtl.setIndicativeRepaymentFlag(IBankParams.YES);
				
		if(lisAcct.getForeCastTerm()!=null && ! ("0 months".equalsIgnoreCase(lisAcct.getForeCastTerm())) )
			mbLisDtl.setForecastTermDisp(lisAcct.getForeCastTerm());
			
		return mbLisDtl;	
	}

	private TDAAccountDetailResp getTDAAcctResp(TermDepositAccount tdaAcct,Customer customer){
		
		TDAAccountDetailResp mbTdaDtl = new TDAAccountDetailResp(); 
		
		mbTdaDtl.setMaturityDate(tdaAcct.getMaturityDate());
		
		if(tdaAcct.getTermDepositAdditionalInfo()!=null){
			
			if(tdaAcct.getTermDepositAdditionalInfo().getInterestAmount()!=null 
					&& tdaAcct.getTermDepositAdditionalInfo().getInterestAmount().compareTo(new BigDecimal(0)) != 0){
					
				mbTdaDtl.setInterestAmt(tdaAcct.getTermDepositAdditionalInfo().getInterestAmount().toString());
			}
			
			mbTdaDtl.setNextInterestDate(tdaAcct.getTermDepositAdditionalInfo().getNextInterestDate());
			
		}
		if(tdaAcct.getAccountId() != null
				&& tdaAcct.getAccountId().getSubProductCode().equals(IBankParams.getCodesData(IBankParams.BRAND_ORIGIN, "TermDepositSubProd","4").getMessage())){
			
			if(tdaAcct.getTermDepositAdditionalInfo()!=null){
				
				TDAFlexiDetailResp TDFlexiDtl = new TDAFlexiDetailResp();
								
				TDFlexiDtl.setOriginalFundAmt(tdaAcct.getTermDepositAdditionalInfo().getWDrawableAmount().toString());
				TDFlexiDtl.setRemainFundAmt(tdaAcct.getTermDepositAdditionalInfo().getRemainingAmount().toString());
				
				mbTdaDtl.setTdaFlexiDetail(TDFlexiDtl);
			}
			
		}
		
		if(tdaAcct.getInterestInstruction()!=null && tdaAcct.getInterestInstruction().getInterestFreq()!=null && tdaAcct.getInterestInstruction().getInterestInstruction()!=null){
			String interestInstr=getFreqPaymentWording(tdaAcct.getInterestInstruction().getInterestFreq().charAt(1))+ " "+getFreqPaymentWording(tdaAcct.getInterestInstruction().getInterestInstruction().charAt(1));
			mbTdaDtl.setInstruction(interestInstr);
		}		
		
		mbTdaDtl.setInterestEarned(getInterestAmtDetail(tdaAcct.getInterestLastYear(),tdaAcct.getInterestThisYear()));
		
		return mbTdaDtl;
	}
	
	private List<TranDetailResp> getCardAuthResp(Collection authorisations,String accountType){
		List<TranDetailResp> authlist = null;
		
		TranDetailResp cardAuth;
		if(authorisations != null && authorisations.size() > 0 ){
			
			authlist = new ArrayList<TranDetailResp>();						
			Iterator it = authorisations.iterator();			
			while(it.hasNext()){				
				OutstandingAuthorisations auth = (OutstandingAuthorisations)it.next();
				cardAuth = new TranDetailResp();
				
				if (StringMethods.isValidString(auth.getDescription()))
					cardAuth.setDesc(auth.getDescription());
				
				if(auth.getRequestTime() == null)
					cardAuth.setDate(auth.getRequestDate());
				else 
				{
					Date datetime = mbAppHelper.getDateTime(auth.getRequestDate(),auth.getRequestTime());
					cardAuth.setDate(datetime);
				}
				String amtValue = "";
				BigDecimal amount=auth.getAmount();//for DDA account cardAuth transactions
				//auth.getCrAmt() & auth.getDrAmt() used for CreditCard transactions
				
				if (amount !=null){
					cardAuth.setDebit(true);
					if (amount.signum() == -1) {
						//cardAuth.setDebit(true);
						BigDecimal negatedAmt = amount.negate();
						amtValue=negatedAmt.toString();
					}
					else{
						amtValue=amount.toString();
					}
				}else if(auth.getCrAmt() != null && auth.getCrAmt().compareTo(new BigDecimal(0)) != 0){
					amtValue=auth.getCrAmt().toString();					
				}else if(auth.getDrAmt()!=null && auth.getDrAmt().compareTo(new BigDecimal(0)) != 0){
					amtValue=auth.getDrAmt().toString();
					cardAuth.setDebit(true);
				}
								
				cardAuth.setAmt(amtValue);
				//Todo to be replaced with new lwc switch
				//if(IBankParams.isLWCSwitchON()) {
				String lwcDesc = null;
				String pendingDesc = merchantTransactionInfoService.populateLWCForOutstandingTranDesc(auth,accountType);
				Logger.debug("pendingDesc from Service: "+pendingDesc, this.getClass());
				if(pendingDesc != null) {
					pendingDesc = pendingDesc.trim();
					String[] pendingDescArray = StringUtils.split(pendingDesc);
					if(StringUtils.isNumeric(pendingDescArray[0])) {
						lwcDesc = pendingDesc.substring(pendingDescArray[0].length()).trim();
					}
					else {
						lwcDesc = pendingDesc;
					}
				}		
				cardAuth.setLwcDesc(lwcDesc);
				//}
				authlist.add(cardAuth);				
			}			
			Collections.reverse(authlist);
		}		
		return authlist;
	}
	
	private List<TranDetailResp> getTrxnHistoryResp(String origin, String gcisNumber, String accountType, TransactionHistory trxnHist, boolean isCategorisationAvailableForTranHistory, boolean isGoogleSearchAllowed, boolean isAccountEligibleForSmartPlans, boolean isAccEligibleForPurchaseSmartPlans){
		List<TranDetailResp> trxnHistList = null; 
		
		TranDetailResp tranDet;
		if(trxnHist != null && trxnHist.getTransactions().size() > 0 ){
			trxnHistList = new ArrayList<TranDetailResp>();
			ArrayList list=(ArrayList)trxnHist.getTransactions();
			Iterator it = list.iterator();
			List<DebitCardTranCodeInfo> debitCardTranCodes = null;//List<String> creditCardTrancCodes = null;
			List<Long> creditCardTrancCodes = null;
			if(IBankParams.isCardDisputeSwitchON(origin)){
				debitCardTranCodes = cardDisputeService.getDebitCardTranCodes();
				creditCardTrancCodes = cardDisputeService.getCreditCardLongTranCodes();
			}
			Calendar cal = Calendar.getInstance();
			cal.setTime(new Date());
			cal.add(Calendar.DATE, -151);
			Date disputeFromDate = cal.getTime();
			
			Calendar cal2 = Calendar.getInstance();
			cal2.setTime(new Date());
			cal2.add(Calendar.DATE, -1);
			Date disputeToDate = cal2.getTime();
			
			boolean smartPlanSwitch = ibankRefreshParams.isSmartPlanSwitchON(IBankParams.DEFAULT_ORIGIN, gcisNumber);
			
			while(it.hasNext()){
				tranDet = new TranDetailResp();
				TransactionInfo eachTransactionInfo=(TransactionInfo)it.next();
				tranDet.setDate(eachTransactionInfo.getDate());
				
				if(StringMethods.isValidString(eachTransactionInfo.getDescription1()))					
					tranDet.setDesc(eachTransactionInfo.getDescription1());				
	
				if(StringMethods.isValidString(eachTransactionInfo.getDescription2()))
					tranDet.setDesc2(eachTransactionInfo.getDescription2());
				
				//17E3 Transaction Categorisation : updating tranHistory with Category, SubCategory and iconName.
				if(isCategorisationAvailableForTranHistory){
					tranDet.setIconName(eachTransactionInfo.getIconName());
					tranDet.setTranCategory(eachTransactionInfo.getTranCategory());
					tranDet.setTranCategoryId(eachTransactionInfo.getTranCategoryId());
					tranDet.setTranSubCategory(eachTransactionInfo.getTranSubCategory());
				}
				
				//17E4 Google Search.
				if(isGoogleSearchAllowed){
					tranDet.setSearchFlag(eachTransactionInfo.getSearchFlag());
					tranDet.setSearchString(eachTransactionInfo.getSearchString());
				}
				
				String amtValue = "";
				BigDecimal amount=eachTransactionInfo.getAmount();
				if (amount !=null){
					if (amount.signum() == -1) {
						tranDet.setDebit(true);
						BigDecimal negatedAmt = amount.negate();
						amtValue=negatedAmt.toString();
					}
					else{
						amtValue=amount.toString();
					}
				}
				tranDet.setAmt(amtValue);	

				tranDet.setpRPaymentId(eachTransactionInfo.getpRPaymentId());
				
				String nppTranType = NPPReturnEnum.getNppTranType(eachTransactionInfo.getBranchTranCode(),eachTransactionInfo.getMicrCode(),eachTransactionInfo.getUserID());
				tranDet.setNppTranType(nppTranType);
				
				tranDet.setEffectiveDate(eachTransactionInfo.getEffectiveDate());
				
				if (  eachTransactionInfo instanceof RunningBalanceTransactionInfo  )
				{
					RunningBalanceTransactionInfo tempTran = ( RunningBalanceTransactionInfo)  eachTransactionInfo;
					//Logger.debug("Running Balance :" + tempTran.getBalance() , this.getClass());
				  if(Account.LIS.equals(accountType)) 
				  {
				  	tranDet.setRunningBalance(tempTran.getBalanceNegated().toString());
				  }
				  else
				  {
				  	tranDet.setRunningBalance(tempTran.getBalance().toString());
				  }
				}
				
				String type;
				if(Account.DDA.equals(accountType)){
					type="debit";
				}
				else{
					type="credit";
				}
				if(IBankParams.isCardDisputeSwitchON(origin)){
					tranDet.setIsDisputable
					(
				new Boolean(cardDisputeService.isCardDisputeTransaction(eachTransactionInfo,
						disputeFromDate,disputeToDate,type,creditCardTrancCodes,debitCardTranCodes)));
					tranDet.setRefNum(eachTransactionInfo.getRefNum());
				}
				else{
					tranDet.setIsDisputable(false);
				}
				
				if(smartPlanSwitch) {
					// 20E4 - Smart Plan - Payment installment eligibility check for transaction
					if(eachTransactionInfo.getSmartPlanStatus() != null) {
						if(eachTransactionInfo.getSmartPlanStatus() == 1) {
							// Active Smart plan
							tranDet.setSmartPlanStatus(eachTransactionInfo.getSmartPlanStatus());
							tranDet.setSmartPlanInstalmentLeft(eachTransactionInfo.getSmartPlanInstalmentLeft());
							tranDet.setSmartPlanOriginalPlanTerm(eachTransactionInfo.getSmartPlanOriginalPlanTerm());
						}else {
							tranDet.setSmartPlanStatus(eachTransactionInfo.getSmartPlanStatus());
						}
						tranDet.setIsPayInstalment(false);
						
						// Setting properties for SP Transaction details page.
						if(eachTransactionInfo.getSmartPlanTransactionAmount() != null) {
							tranDet.setSmartPlanTransactionAmount(eachTransactionInfo.getSmartPlanTransactionAmount().toString());
						}
						if(eachTransactionInfo.getSmartPlanNextPaymentAmount() != null) {
							tranDet.setSmartPlanNextPaymentAmount(eachTransactionInfo.getSmartPlanNextPaymentAmount().toString());
						}
						tranDet.setSmartPlanPaymentDueDate(eachTransactionInfo.getSmartPlanPaymentDueDate());
						tranDet.setSmartPlanPaidOutDate(eachTransactionInfo.getSmartPlanPaidOutDate());
					}
					else if(isAccountEligibleForSmartPlans && isAccEligibleForPurchaseSmartPlans) {
						try {
							tranDet.setIsPayInstalment(smartPlanService.isTransactionEligible(eachTransactionInfo));
						} catch (BusinessException e) {
							Logger.error("Error in Transaction Eligibility Check."+e,this.getClass());
							tranDet.setIsPayInstalment(false);
						}
					}else{
						Logger.info("Transaction eligiblity check not performed.", this.getClass());
						tranDet.setIsPayInstalment(false);
					}
				}
				
				if(IBankParams.isLWCSwitchON()) {
					tranDet.setLwcDesc(merchantTransactionInfoService.populateLWCTranDesc(eachTransactionInfo, accountType));
				}
				
				trxnHistList.add(tranDet);
			}
		}
		
		return trxnHistList;
	}
	
	
	public boolean isReportInappropriateEligible(NPPTransactionDetail nppTranDetail) {
		try {
			Logger.debug("ReferenceId()" + nppTranDetail.getReferenceId() + "desc " + 
					nppTranDetail.getDescription(), getClass());
			Logger.debug("Effective date" + nppTranDetail.getEffectiveDate() ,getClass());
			if (IBankParams.isSwitchOn(IBankParams.ABUSIVE_INWARD_SWITCH) ) {
				Date transactionDate = new SimpleDateFormat("dd/MM/yyyy")
						.parse(nppTranDetail.getEffectiveDate());
				Date currentDate = new Date();
				long diff = currentDate.getTime() - transactionDate.getTime();

				long days = TimeUnit.DAYS.convert(diff, TimeUnit.MILLISECONDS);
				Logger.info("no of days since transaction::" + days ,
						getClass());
				int abusiveTrxnRestrictDays = IBankParams.getAbusiveTrxnDays();
				
				if (days <= abusiveTrxnRestrictDays && (!StringMethods.isEmptyString(nppTranDetail.getDescription())
						|| !StringMethods.isEmptyString(nppTranDetail.getReferenceId()))) {
 					return true;
				}
			}
		} catch (Exception ex) {
			Logger.error("Exception in checkReportAbusiveTranEligibility", ex, getClass());
		}
		return false;
	}
	
	
	private BigDecimal getCardAuthTotalAmount(Collection authorisations){
		BigDecimal total = new BigDecimal(0);
		if (authorisations == null)
			return total;
		Iterator it = authorisations.iterator();
		while(it.hasNext()){
			OutstandingAuthorisations auth = (OutstandingAuthorisations)it.next();
			if(auth.getAmount()!=null)
				total = total.add(auth.getAmount());
		}
		return total;
	}	
	
	private InterestAmtDetailResp getInterestAmtDetail(BigDecimal lastYearAmt, BigDecimal thisYearAmt){
		
		InterestAmtDetailResp intAmtDtl = null; 
		
		if(lastYearAmt == null)
			lastYearAmt = new BigDecimal(0);
				
		if(thisYearAmt == null)
			thisYearAmt = new BigDecimal(0);
							
		if (lastYearAmt.compareTo(new BigDecimal(0)) != 0 || thisYearAmt.compareTo(new BigDecimal(0)) != 0){
			
			intAmtDtl = new InterestAmtDetailResp();
			intAmtDtl.setLastYearAmt(lastYearAmt.toString());
			intAmtDtl.setThisYearAmt(thisYearAmt.toString());
		}
		return intAmtDtl;
	}
	
	private static String getPaymentCycle(char input){
		String payCycle="";
		switch(input){
			case 'F':
				payCycle="Fortnightly";
				break;		
			case 'T':
				payCycle="Fortnightly";
				break;			
			case 'M':
				payCycle="Monthly";
				break;	
			case 'Q':
				payCycle="Quarterly";
				break;		
			case 'W':
				payCycle="Weekly";
				break;	
			case 'X':
				payCycle="Weekly";
				break;	
			default:
				payCycle="Others";						
		}
		return payCycle;
	}
	
	private String getFreqPaymentWording(char input){
		String freqPaymentWording="";
		switch(input){
			case 'T':
				freqPaymentWording="to instructed account";
				break;
			case 'O':
				freqPaymentWording="to cheque";
				break;
			case 'A':
				freqPaymentWording="roll over at new interest rate";
				break;				
			case '0':
				freqPaymentWording="at maturity";
				break;	
			case '4':
				freqPaymentWording="every 28 days";
				break;		
			case 'S':
				freqPaymentWording="Every 6 months";
				break;	
			case 'Y':
				freqPaymentWording="Annually";
				break;
			case 'M':
				freqPaymentWording="Monthly";
				break;
			default:
				freqPaymentWording="Not Specified";							
		}		
		return freqPaymentWording;
	}
	
	private InterestRateDetailResp getInterestRateDetail(String origin, DdaAccount account){
		InterestRateDetailResp rateDetail = new InterestRateDetailResp();
		
		// if interest rate not available due to system issue
		if (account.getIntRateDetailsVO() == null && DdaAccount.INTRATE_RATE_NOT_AVAILABLE == account.getInterestRateAvail()) {
			String error = IBankParams.getErrorMessage(IBankParams.DEFAULT_ORIGIN, IBankParams.INTEREST_RATE_ERROR_MSG);
			rateDetail.setErrorDesc(error);
			return rateDetail;
		}
		
		IntRateDetailsVO intRateDetailsVO = account.getIntRateDetailsVO();
		rateDetail.setIsAdditionalDetail(true);
		rateDetail.setBaseRate(intRateDetailsVO.getInterestRate().toString());
		
		if(intRateDetailsVO.isCampignExists()){
			
			rateDetail.setBonusRateType(intRateDetailsVO.getCampignType());//FULL,PARTIAL
			
			if(intRateDetailsVO.getCampignRate() != null)
				rateDetail.setBonusRate(intRateDetailsVO.getCampignRate().toString());
			
			rateDetail.setBonusExpiryDate(intRateDetailsVO.getCampignExpDate());
			
			if(intRateDetailsVO.getInterestRateWithBonus() != null)
				rateDetail.setTotalRate(intRateDetailsVO.getInterestRateWithBonus().toString());					
		}		
		
		//hiding link if its override rate or Zero rate without campaign without expiry
		if ((IntRateDetailsVO.CALC_INRATEIND_OVER
				.equalsIgnoreCase(intRateDetailsVO.getCalRateTypeInd()) || (intRateDetailsVO.isRequesteZeroIntRate()))
				&& intRateDetailsVO.getExpDate() == null) {
		
			Logger.info("#Hiding show details link either over ride rate or zero interest rate withour expiry date:"+account.getAccountId().getAccountKey() , this.getClass());
			rateDetail.setIsAdditionalDetail(false);
			return rateDetail;
		}
		
		//hiding link if flat rate without campaign and  without expiry
		if ( IntRateDetailsVO.INTRATETYPE_FLAT.equalsIgnoreCase(intRateDetailsVO.getInterestRateType()) &&
				!(intRateDetailsVO.isCampignExists()) && intRateDetailsVO.getExpDate() == null) {
			
			Logger.info("#Hiding show details link, flat rate without campign withour expiry date:"+account.getAccountId().getAccountKey() , this.getClass());
			rateDetail.setIsAdditionalDetail(false);
			return rateDetail;
		}
						
		rateDetail.setBaseRateType(intRateDetailsVO.getCalRateTypeInd());//BASE,DISC,OVER
		rateDetail.setBaseExpiryDate(intRateDetailsVO.getExpDate());
		
		if(intRateDetailsVO.getInterestTiers() != null){
			rateDetail.setTierType(intRateDetailsVO.getInterestRateType());//SP,TR,FL
			rateDetail.setTierDetail(getInterestTierInfo(intRateDetailsVO));
		}
					
		String tempURLSubprodCode = "";
		if ( BUSINESS_ACCESS_SAVER_PROD_CODE.equalsIgnoreCase(account.getAccountId().getSubProductCode() ) )
		{
			tempURLSubprodCode = "-"+ account.getAccountId().getSubProductCode();
		}
		
		CodesVO codesVO = IBankParams.getCodesData(origin,
				IBankParams.EXTERNAL_LINKS,
				IBankParams.INTEREST_RATE_DETAILS_LINK + tempURLSubprodCode);
		
		rateDetail.setExternalLink(codesVO.getMessage());
		
	
		return rateDetail;
	}
	
	private List<InterestRateTierDetailResp> getInterestTierInfo(IntRateDetailsVO intRateDetailsVO){
		List<InterestRateTierDetailResp> tierList = null;
		
		List<InterestTierVO> interestTiers = intRateDetailsVO.getInterestTiers();
		
		if(interestTiers!=null && interestTiers.size() > 0){
			tierList = new ArrayList<InterestRateTierDetailResp>();
			Iterator<InterestTierVO> iterator = interestTiers.iterator();
			boolean firstTier = true;
			boolean lastTier = false;
			
			while (iterator.hasNext()) {
				InterestTierVO interestTierVO = iterator.next();
				InterestRateTierDetailResp tierDetail = new InterestRateTierDetailResp();
				lastTier = !iterator.hasNext();
				if (IntRateDetailsVO.INTRATETYPE_SPLIT.equalsIgnoreCase(intRateDetailsVO.getInterestRateType())) {
					if (lastTier) {
						tierDetail.setMinAmt(interestTierVO.getStarValue().toString());					
					} else {
						tierDetail.setMinAmt(interestTierVO.getStarValue().toString());
						tierDetail.setMaxAmt(interestTierVO.getEndValue().toString());
					}
					tierDetail.setRate(interestTierVO.getInterestRate().toString());
					
				} else if (IntRateDetailsVO.INTRATETYPE_TIERED.equalsIgnoreCase(intRateDetailsVO.getInterestRateType())) {
					if (lastTier) {
						tierDetail.setMinAmt(interestTierVO.getStarValue().toString());
						tierDetail.setRate(interestTierVO.getInterestRate().toString());
					}
					else {
						if (firstTier) {
							tierDetail.setMaxAmt(interestTierVO.getEndValue().toString());					
							tierDetail.setRate(interestTierVO.getInterestRate().toString());
							firstTier = false;
						} else {
							tierDetail.setMinAmt(interestTierVO.getStarValue().toString());
							tierDetail.setMaxAmt(interestTierVO.getEndValue().toString());
						}
						tierDetail.setRate(interestTierVO.getInterestRate().toString());
					}
				}
				tierList.add(tierDetail);
			}				
		}
		return tierList;		
	}

	public IMBResp populateHLIResponse(RespHeader header, String destination, String link, boolean isExisting) {
		HomeLoanIncreaseLinkResp response = new HomeLoanIncreaseLinkResp(header);
		response.setLinkURL(link);
		response.setAppDestination(destination);
		response.setIsExisting(isExisting);
		Logger.info("Response: " + response, this.getClass());
		return response;
	}
	
	private boolean checkGetCashEligibility(Account acct){
		CodesVO codeItem=IBankParams.getCodesData(IBankParams.BRAND_ORIGIN, IBankParams.PARAMETER,IBankParams.GET_CASH_ELIGIBLE_PRODUCTS);
		
		if(codeItem != null){
			if(codeItem.getMessage().indexOf(";"+acct.getAccountId().getSubProductCode()+";") >= 0)
				return true;
		}
		
		return false;
	}
	
	private GCCAccountDetailResp getGCCcctResp(GCCAccount gccAcct)
	{
		GCCAccountDetailResp gccAccountDetailResp = new GCCAccountDetailResp();
		
		List<LabelValueVO> cards = gccAcct.getCardDetails();
		if ( cards != null && cards.size() > 0 )
		{
			ArrayList <KeyValueResp> cardResp = new ArrayList <KeyValueResp> ();
			for ( LabelValueVO card : cards  )
			{
				KeyValueResp keyValueResp = new KeyValueResp();
				keyValueResp.setId(card.getLabel());
				keyValueResp.setName(card.getValue());
				cardResp.add(keyValueResp);
			}
			gccAccountDetailResp.setCards(cardResp);
		}

		List<LabelValueVO> wallets = gccAcct.getWalletBalances();

		if (  wallets != null &&  wallets.size() > 0 )
		{
			ArrayList <KeyValueResp> walletResp = new ArrayList <KeyValueResp> ();
			for ( LabelValueVO wallet :  wallets  )
			{
				KeyValueResp keyValueResp = new KeyValueResp();
				CodesVO codesVO = IBankParams.getCodesData(IBankParams.BRAND_ORIGIN,CURRENCY_DETAIL, wallet.getLabel());
				keyValueResp.setId(codesVO.getMessage());
				keyValueResp.setName(wallet.getLabel()+ ":" +wallet.getValue());
				walletResp.add(keyValueResp);
			}
			gccAccountDetailResp.setBalances(walletResp);
		}

		gccAccountDetailResp.setStatus(gccAcct.getStatus());
		return gccAccountDetailResp;
	}
	
	
	public static boolean isGCCFundingSwitchON(String origin)
	{
		CodesVO codesVO = IBankParams.getCodesData(origin,	IBankParams.CONFIGURATION_PROPERTIES, "GCCFundingSwitch");
		if ( codesVO == null  )
			return false;
		
		if ( IBankParams.ON.equalsIgnoreCase( codesVO.getMessage()) )
			return true;
		
		return false;
		
	}
	
	public long getInsertionPointCode(String insertionPointString){
		List<CodesVO> CodesVOList = (List<CodesVO>) IBankParams.getCodesDataList(IBankParams.DEFAULT_ORIGIN, ServicetationConstants.CD_CATEGORY_SERVICETATION_INSERTION_PT);
		long insertionPointValue = 0;
		for(CodesVO codesVO : CodesVOList){
			if(codesVO.getMessage().trim().equalsIgnoreCase(insertionPointString)){
				if(StringMethods.isValidString(codesVO.getCode())){
					insertionPointValue = Long.parseLong(codesVO.getCode());
					break;
				}
			}
		}
		if(insertionPointValue == 0){
			Logger.warn("NO match found in RELEASECODES table for the insertion point "+insertionPointString, this.getClass());
		}
		return insertionPointValue;
	}
	
	
	public ServiceStationResp populateServiceStationResp(ServiceStationVO serviceStationVO){
		ServiceStationResp resp = null;		
		
		if(null!=serviceStationVO)
		{
			resp=new ServiceStationResp();
			if(null!=serviceStationVO.getContent())
			{
			   resp.setContent(serviceStationVO.getContent());
			}			
			if(null!=serviceStationVO.getServiceStationMsg())
			{
				resp.setInsertionPointValue(new Long(serviceStationVO.getServiceStationMsg().getInsertionPointValue()).toString());	
			}
			if(null!=serviceStationVO.getSubject())
			{
			   resp.setSubject(serviceStationVO.getSubject());
			}
			if(null!=serviceStationVO.getServiceStationMsg().getFunctionLink())
			{
			   resp.setFunctionLink(serviceStationVO.getServiceStationMsg().getFunctionLink());
			}
			if(null!=serviceStationVO.getServiceStationMsg().getMessageAction())
			{
			   resp.setMessageAction(serviceStationVO.getServiceStationMsg().getMessageAction());
			}
			if(null!=serviceStationVO.getServiceStationMsg())
			{
				resp.setMsgID(new Long(serviceStationVO.getServiceStationMsg().getMsgID()).toString());	
			}
		}		
		return resp;
	}
	
	//17E2 Service Interaction and Cross Sell
	/**
	 * @param transactionHistoryCrossLink
	 * @return
	 */
	public TransCrosSellServiceResp getTranCrossSellResp(TransactionHistoryCrossLink transactionHistoryCrossLink, ServiceStationResp serviceStationResp ){
		if (null != transactionHistoryCrossLink) {
			TransCrosSellServiceResp resp = new TransCrosSellServiceResp();
			resp.setSubject(transactionHistoryCrossLink.getTitleTxt());
			resp.setContent(transactionHistoryCrossLink.getDetailsTxt());
			resp.setButtonText(transactionHistoryCrossLink.getButtonTxt());
			resp.setFunctionLink(transactionHistoryCrossLink.getActionUrl());

			if (serviceStationResp != null)
				resp.setServiceStation(serviceStationResp);

			return resp;
		}
		return null;
	}
	
	/**
	 * This method is to validate the advanced search object coming in the acccount info request
	 * @param req
	 * @throws BusinessException
	 */
	public void validateAdvancedSearch(AccountInfoReq req) throws BusinessException {
		
		Date fromDate = null;
		Date toDate = null;
		
		if(!StringMethods.isEmptyString(req.getAdvanceSearch().getFromDate())){
			try{
				fromDate = DateUtils.StringtoDate(req.getAdvanceSearch().getFromDate(), DateUtils.EN_AU_DATE_FORMAT_PATTERN);
			}
			catch(BusinessException be){
				Logger.error("1 error",this.getClass());
				throw new BusinessException(BusinessException.WSVC_INVALID_INPUT_PARAM);
			}
		}
		else{
			Logger.error("2 error",this.getClass());
			throw new BusinessException(BusinessException.WSVC_INVALID_INPUT_PARAM);
		}

		if(!StringMethods.isEmptyString(req.getAdvanceSearch().getToDate())){
			try{
				toDate = DateUtils.StringtoDate(req.getAdvanceSearch().getToDate(), DateUtils.EN_AU_DATE_FORMAT_PATTERN);
			}
			catch(BusinessException be){
				Logger.error("3 error",this.getClass());
				throw new BusinessException(BusinessException.WSVC_INVALID_INPUT_PARAM);
			}
			
			if (toDate.before(fromDate)) {
				Logger.error("4 error",this.getClass());
				throw new BusinessException(BusinessException.WSVC_INVALID_INPUT_PARAM);
			}
			
			Date currentDate = new Date();
			
			//to date >current date
			if(currentDate.before(toDate)){
				Logger.error("5 error",this.getClass());
				throw new BusinessException(BusinessException.WSVC_INVALID_INPUT_PARAM);
			}

			Calendar calendar = Calendar.getInstance();
			calendar.setTime(fromDate);
			calendar.add(Calendar.MONTH, 12);
			Date tempFromdate = calendar.getTime();
			
			//to - from not > 12 months
			 if (tempFromdate.before(toDate)){ 
				 Logger.error("6 error",this.getClass());
				 throw new BusinessException(BusinessException.WSVC_INVALID_INPUT_PARAM);	
			 }
		}
		else{
			Logger.error("7 error",this.getClass());
			throw new BusinessException(BusinessException.WSVC_INVALID_INPUT_PARAM);
		}
	}
	
	public TransactionHistory updateExtendTranHistInSession(MobileSession mbSession ,TransactionHistory sessionTranHist ,TransactionHistory trxnHist, String period){
		
		//TransactionHistory history = mbSession.getTransactionHistory();
		
		if (sessionTranHist == null) {
			sessionTranHist = new AccountingTransactionHistory();
			sessionTranHist.setTransactions(new ArrayList<TransactionInfo>());
		} else if (sessionTranHist.getTransactions() == null){
			sessionTranHist.setTransactions(new ArrayList<TransactionInfo>());
		}
		
		if (trxnHist == null) {
			trxnHist = new AccountingTransactionHistory();
			trxnHist.setTransactions(new ArrayList<TransactionInfo>());
		} else if (trxnHist.getTransactions() == null){
			trxnHist.setTransactions(new ArrayList<TransactionInfo>());
		}
		
		if (!"30".equals(period)){
			sessionTranHist.getTransactions().addAll(sessionTranHist.getTransactions().size(), trxnHist.getTransactions());
			mbSession.setTransactionHistory(sessionTranHist);
			
			Logger.debug("Inside updateExtendTranHistInSession not 30 | mbSession transaction size in session"+mbSession.getTransactionHistory().getTransactions().size() ,this.getClass());
			return sessionTranHist;
			
		}else{
			
			Logger.debug("Inside updateExtendTranHistInSession 30 | mbSession transaction size in session" ,this.getClass());
			mbSession.setTransactionHistory(trxnHist);
			return trxnHist;
		}
	}
	
	public int calculateNumberOfTranReqd(MobileSession mbSession, int maxTransactions){
		
		int numberOfTranReqd = 0;
		TransactionHistory historyFromSession = mbSession.getTransactionHistory();
		if(historyFromSession != null && historyFromSession.getTransactions()!=null){
			int sizeOfListInSession = historyFromSession.getTransactions().size();

			Logger.debug("getting number of transactions from session | sizeOfListInSession ::"+sizeOfListInSession,this.getClass());
			
			if(sizeOfListInSession <= maxTransactions){
				numberOfTranReqd = maxTransactions - sizeOfListInSession;
				Logger.debug("calculating number of transactions required numberOfTranReqd ::"+numberOfTranReqd,this.getClass());
			}
		}

		return numberOfTranReqd;
	}
	
	/**
	 * @param req
	 * @return
	 */
	public boolean isAdvancedSearch(AccountInfoReq req){
		if(req.getHistoryPeriod()!=null && req.getAdvanceSearch()!=null){
			return true;
		}
		return false;
	}
	
	private void createGDWEntry(IBankCommonData commonData, String action, String desc, AccountId accountId){
		try {
			Statistic s = new Statistic();
			s.setAction(action);
			s.setGcisNumber(commonData.getUser().getGCISNumber());
			s.setOriginBank(commonData.getOrigin());
			s.setIpAddress(commonData.getIpAddress());
			s.setGDWOriginBank(commonData.getGdwOrigin());
			s.setSessionId(commonData.getSessionId());
			s.setDescription(desc);
			s.setAccountNumberFrom(accountId.getAccountNumber());
			s.setAccountTypeFrom(accountId.getEhubProductCode());
			s.setApplIdFrom(accountId.getApplicationId());
			s.setProdCodeFrom(accountId.getSubProductCode());
			StatisticsService.logStatistic(s);
		} catch (Exception e) {
			Logger.error(" Failed Statistic log for Advanced Tran Hist Action :"+action, this.getClass());
		}
	}
	
	private String createDescForGDW(String desc, String fromDate, String toDate, String fromAmt, String toAmt){
		String[] strArr = {desc, fromDate, toDate, fromAmt,toAmt};
		return MessageFormat.format(SL_DESC, (Object[])strArr);
	}
	
	public void createGDWEntryForAdvancedSearch(AdvanceSearchReq advSearchReq, IBankCommonData commonData, AccountId acctId){
		
		String desc = null;
		String action = null;
		
		desc = createDescForGDW(advSearchReq.getDescription(),advSearchReq.getFromDate(), advSearchReq.getToDate(), advSearchReq.getFromAmount(), advSearchReq.getToAmount());
		action = SL_ACTION_EXTSER;
		
		createGDWEntry(commonData, action, desc, acctId);

		if(advSearchReq.getEntryPoint() != ENTRY_POINT_0){
			action = SL_ACTION_SAEXT;
			if(advSearchReq.getEntryPoint() == ENTRY_POINT_1){
				desc = SL_DESC_TOP;
			}else if(advSearchReq.getEntryPoint() == ENTRY_POINT_2){
				desc = SL_DESC_BOTTOM;
			}
			createGDWEntry(commonData, action, desc, acctId);
		}
	}

	/**
	 * Npp Inward payment population
	 * @param nppInwardPaymentDetails
	 * @param resp 
	 * @param crossSellDtls 
	 * @return transactionNppDetailsResp
	 */
	public TransactionDetailResp populateTransactionDetailsResp(NPPTransactionDetail nppTransactionDetail,
			ServiceStationResp resp, MerchantTransactionInfo lwcDetails, ErrorResp errorResp,
			boolean showAbusiveLinkIntraDay, String gcisNo, String accountNo, String trxnRefNo) {
		final String methodName = "AccountInfoHelper.populateTransactionDetailsResp():";
		Logger.info(methodName, this.getClass());

		int abusiveTrxnRestrictDay = IBankParams.getAbusiveTrxnRptRestrictInDays();
		long abusiveTrxnRestrictDays = abusiveTrxnRestrictDay;
		Logger.info(methodName + "abusiveTrxnRestrictDays:" + abusiveTrxnRestrictDays, this.getClass());

		//boolean isAbTrxnReported = false;
		boolean abusiveTrxnSuccessMessageToBeDisplay = false;
		
		Date abusiveTrxnReportedOn_ = reportTransactionDAO.isAbusiveTrxnReported(gcisNo, accountNo, trxnRefNo);
		Logger.info(methodName + "abusiveTrxnReportedOn_:" + abusiveTrxnReportedOn_, this.getClass());
		
		if(abusiveTrxnReportedOn_ != null) {
			//isAbTrxnReported = true;
			nppTransactionDetail.setShowReportAbusiveLink(false);
			
			Date currentDate = new Date();
			Logger.info(methodName + "currentDate:" + currentDate, this.getClass());

			long abusiveTrxnRptDiff_ = currentDate.getTime() - abusiveTrxnReportedOn_.getTime();
			Logger.info(methodName + "abusiveTrxnRptDiff_:" + abusiveTrxnRptDiff_, this.getClass());
			
			//long abusiveTrxnDiffDays_ = TimeUnit.DAYS.convert(abusiveTrxnRptDiff_, TimeUnit.MILLISECONDS);
			//Logger.info(methodName + "abusiveTrxnDiffDays_:" + abusiveTrxnDiffDays_, getClass());
			
			long abusiveTrxnRestrictDaysMs = abusiveTrxnRestrictDays * 24 * 60 * 60 * 1000 ;
			Logger.info(methodName + "abusiveTrxnRestrictDaysMs:" + abusiveTrxnRestrictDaysMs, this.getClass());

			if (abusiveTrxnRptDiff_ <= abusiveTrxnRestrictDaysMs) {
				abusiveTrxnSuccessMessageToBeDisplay = true;
			}
		}
		
		//Logger.info(methodName + "isAbTrxnReported:" + isAbTrxnReported, this.getClass());
		Logger.info(methodName + "abusiveTrxnSuccessMessageToBeDisplay:" + abusiveTrxnSuccessMessageToBeDisplay, this.getClass());

		TransactionDetailResp tranDetailsResp = new TransactionDetailResp();
		tranDetailsResp.setReportInappropriateIntraDayTran(showAbusiveLinkIntraDay);
		tranDetailsResp.setTransactionNppDetailsResp(populateNPPTransactionDetail(nppTransactionDetail, errorResp, abusiveTrxnSuccessMessageToBeDisplay));

		if (resp != null) {
			tranDetailsResp.setServiceStation(resp);
		}

		if (IBankParams.isLWCSwitchON() && lwcDetails != null) {
			populateLWCResp(lwcDetails, tranDetailsResp);
		}

		return tranDetailsResp;
	}
	
	private void populateLWCResp(MerchantTransactionInfo lwcDetails, TransactionDetailResp tranDetailsResp) {
		
		MerchantDetailsResp merchantDetailsResp = new MerchantDetailsResp();
		
		if(IBankParams.isLWCMerchantLogoSwitchON()) {
			merchantDetailsResp.setMerchantLogo(lwcDetails.getMerchantLogo());
		}
		
		merchantDetailsResp.setLwcUrl(lwcDetails.getLwcUrl());
		merchantDetailsResp.setLwcMessageUrl(lwcDetails.getLwcMessageUrl());
		merchantDetailsResp.setMerchantName(lwcDetails.getMerchantName());
		
		MerchantAddress merchantAddress = new MerchantAddress();
		merchantAddress.setSingleLineAddress(lwcDetails.getSingleLineAddress());
		merchantAddress.setLatitude(lwcDetails.getLatitude());
		merchantAddress.setLongitude(lwcDetails.getLongitude());
		merchantAddress.setMapable(lwcDetails.isMapable());
		merchantAddress.setLatLonPrecision(lwcDetails.getLatLonPrecision());
		
		MerchantContactDetails merchantContacts = new MerchantContactDetails();
		merchantContacts.setWebsiteUrl(lwcDetails.getWebsiteUrl());
		merchantContacts.setWebsiteDisplayValue(lwcDetails.getWebsiteDisplayValue());
		merchantContacts.setContactNumber(lwcDetails.getContactNumber());
		merchantContacts.setEmail(lwcDetails.getEmail());
		
		merchantDetailsResp.setAddress(merchantAddress);
		merchantDetailsResp.setContacts(merchantContacts);
		
		if (tranDetailsResp != null) {
			tranDetailsResp.setLwcDetailsResp(merchantDetailsResp);
		}
	}
	
	/**
	 * @param nppTransactionDetail
	 * @param errorResp
	 * @return
	 */
	private TransactionNppDetailsResp populateNPPTransactionDetail(NPPTransactionDetail nppTransactionDetail, 
			ErrorResp errorResp, boolean abusiveTrxnSuccessMessageToBeDisplay) {
		TransactionNppDetailsResp response = null;
		if (errorResp != null && errorResp.hasErrors()) {
			response = new TransactionNppDetailsResp();
			response.setErrorResp(errorResp);
		} else if(nppTransactionDetail != null) {
			response = new TransactionNppDetailsResp();
			
			//21E2
			//response.setAbusiveTrxnReported(isAbTrxnReported);
			response.setAbusiveTrxnSuccessMessageToBeDisplay(abusiveTrxnSuccessMessageToBeDisplay);
			
			response.setDepositNumber(nppTransactionDetail.getDepositNumber());
			response.setReferenceId(nppTransactionDetail.getReferenceId());
			response.setDescription(nppTransactionDetail.getDescription());
			response.setOsko(nppTransactionDetail.isOsko());
			response.setDisplayName(nppTransactionDetail.getDiplayName());
			response.setWithdrawalNumber(nppTransactionDetail.getWithdrawalNumber());
			response.setOriginAmount(nppTransactionDetail.getOriginAmount());
			response.setOriginDate(nppTransactionDetail.getOriginDate());
			response.setEffectiveDate(nppTransactionDetail.getEffectiveDate());
			response.setPayeeAccountNumber(nppTransactionDetail.getPayeeAccountNumber());
			response.setPayId(nppTransactionDetail.getPayId());
			response.setPayIdName(nppTransactionDetail.getPayIdName());
			response.setReportInappropriateTran(nppTransactionDetail.isShowReportAbusiveLink());
			if (!StringMethods.isEmptyString(nppTransactionDetail
					.getNppTranType())
					&& nppTransactionDetail.getNppTranType().equalsIgnoreCase(
							"REV")) {
				response.setShowDeepLink(nppTransactionDetail.isSoftfail());
				if (nppTransactionDetail.isSoftfail()) {
					response.setDescription(nppTransactionDetail
							.getDescription().replace("{0}", ""));
				}
			}
		}
		return response;
	}
	
	/**
	 * @param nppTransactionDetails
	 * @return
	 */
	public boolean isValidNPPTransactionDetails(NPPTransactionDetail nppTransactionDetails, String nppTranType, boolean isDebit) {
		if (null == nppTransactionDetails
				|| (StringMethods.isEmptyString(nppTransactionDetails.getReferenceId())
						&& StringMethods.isEmptyString(nppTransactionDetails.getDescription())
						&& StringMethods.isEmptyString(nppTransactionDetails.getDiplayName())
						&& StringMethods.isEmptyString(nppTransactionDetails.getOriginDate())
						&& StringMethods.isEmptyString(nppTransactionDetails.getPayeeAccountNumber())
						&& StringMethods.isEmptyString(nppTransactionDetails.getEffectiveDate()))) {
			return false;
		}
		
		if(nppTranType.equalsIgnoreCase("ORG") && isDebit && StringMethods.isEmptyString(nppTransactionDetails.getWithdrawalNumber())){
			return false;
		}
		
		if(nppTranType.equalsIgnoreCase("ORG") && !isDebit && StringMethods.isEmptyString(nppTransactionDetails.getDepositNumber())){
			return false;
		}
		
		if((nppTranType.equalsIgnoreCase("RET") || nppTranType.equalsIgnoreCase("REV")) && StringMethods.isEmptyString(nppTransactionDetails.getWithdrawalNumber()) && StringMethods.isEmptyString(nppTransactionDetails.getDepositNumber())){
			return false;
		}
		
		if(nppTranType.equalsIgnoreCase("RET") && !isDebit && StringMethods.isEmptyString(nppTransactionDetails.getOriginAmount())){
			return false;
		}
		return true;
	}
	public void logStatistic(Account account, IBankCommonData commonData, String action, MerchantTransactionInfo lwcResp)
		 	throws BusinessException, ResourceException
		 	{
				try
			 	{
					Logger.info(" TxnDetails gdw entry: start " , this.getClass());
					
					Statistic s = new Statistic();
					StringBuffer sb = new StringBuffer();
					if(account !=null && account.getAccountId() != null) {
						sb.append(account.getAccountId().getAccountNumber() + SEPARATOR + account.getAccountId().getApplicationId());
						if(lwcResp!=null) {
							sb.append(SEPARATOR+LWC_IDENTIFIER);
						}
						s.setDescription(sb.toString());
					}
			 		s.setAction(action);
			 		s.setGcisNumber(commonData.getUser().getGCISNumber());
			 		s.setOriginBank(commonData.getOrigin());
			 		s.setGDWOriginBank(commonData.getGdwOrigin());
			 		s.setIpAddress(commonData.getIpAddress());
			 		s.setSessionId(commonData.getSessionId());
			 		StatisticsService.logStatistic(s);
			 		Logger.info(" TxnDetails gdw entry: end " , this.getClass());
			 	}
			     catch (Throwable t)
			 	{
			 	   // do nothing as this is not a part of the transaction
			    		IBankLog.logERR("Failed to create a statistic entry for TxnDetails.", t, this.getClass());
			  	}   
		 	}//End of logStatistic
	
	
	/**
	 * This method will populate Purse and card details for the GCC Account details page.
	 * 
	 * @param mbSession
	 * @return GCCAccountInfoResp
	 */
	public GlobalWalletAccountInfoResp populateGlobalWalletAcctDetailsResp(MobileSession mbSession, GCCAccount globalWalletaccount, GlobalWalletDetails globalWalletDtls) {
		
		GlobalWalletAccountInfoResp response = new GlobalWalletAccountInfoResp();
		
		response.setAccountKey(mbAppHelper.getGlobalWalletAcctKeyInfoResp(globalWalletaccount));																			
		response.setProductName(globalWalletaccount.getAccountId().getProductName());
		
		List<GlobalWalletCardResp> cards = new ArrayList<>();
		List<GlobalWalletPurseResp> purses = new ArrayList<>();
		
		for (GlobalWalletPurse purse : globalWalletDtls.getPurses()) {
			GlobalWalletPurseResp purseResp = new GlobalWalletPurseResp();
			
			purseResp.setCurrencyCode(purse.getCurrencyCode());
			purseResp.setDescription(purse.getCurrencyDescription());
			purseResp.setAvailBalance(purse.getAvailableBal());
			purseResp.setBalance(purse.getCurrentBal());
			
			purses.add(purseResp);
		}
		
		if(globalWalletDtls.getCards()!=null && globalWalletDtls.getCards().size()>0){
			for (GlobalWalletCard card : globalWalletDtls.getCards()) {
				GlobalWalletCardResp cardResp = new GlobalWalletCardResp();
				
				cardResp.setCard(card.getCardNumber());
				cardResp.setCardDisplay(StringUtil.formatCompassAccountNumber(card.getCardNumber()));
				cardResp.setStatus(card.getStatus());
				
				cards.add(cardResp);
			}
			response.setCards(cards);
			globalWalletaccount.setCardNumber(cards.get(0).getCard());
		}else{
			response.setCardListError(IBankParams.getErrorMessage(IBankParams.DEFAULT_ORIGIN, Integer.toString(BusinessException.GLOBAL_WALLET_CARD_LIST_API_ERROR)));
		}
		// 20E1 Added LastTransactionDate details in the response
		response.setLastTransactionDate(globalWalletDtls.getLastTransactionDate());
		response.setTransHistoryMonthConfig(globalWalletDtls.getTransHistoryDefaultMonth());
		response.setIsLastTransDateBeyond(globalWalletDtls.getIsLastTransDateBeyond());
		response.setIsLastTransactionDateAvailable(globalWalletDtls.getIsLastTransactionDateAvailable());
		//TODO Add the TransactionHistoryBeyondMessage
		
		String baseOrigin = IBankParams.getBaseOriginCode(mbSession.getOrigin());
		String gccCustomerCare = IBankParams.getGCCMasterCardCustomerCare(baseOrigin);
		String gccCustomerCareOverseas = IBankParams.getGCCMasterCardCustomerCareOverseas(baseOrigin);
		String[] errorParams = { globalWalletDtls.getTransHistoryDefaultMonth(),
				gccCustomerCare, gccCustomerCareOverseas };
		String message = IBankParams
				.getErrorMessage(
						baseOrigin,
						String
								.valueOf(BusinessException.GLOBAL_WALLET_TRANS_HISTORY_BEYOND));
		if (errorParams != null) {
			message = MessageFormat
					.format(message, (Object[])errorParams);
		}
		response.setTransHistoryBeyondMessage(message);		
		response.setPurses(purses);
		response.setShowCardActivationTile(globalWalletDtls.getShowCardActivationTile());
		
		//Set No Transactions Found message
		String[] msgParams = { globalWalletDtls.getTransHistoryDefaultMonth(), gccCustomerCare, gccCustomerCareOverseas };
		String noTransactionsFoundMessage = IBankParams.getErrorMessage(baseOrigin,String.valueOf(BusinessException.GLOBAL_WALLET_TRANS_HISTORY_NOT_FOUND));
		if (msgParams != null && !StringUtils.isEmpty(noTransactionsFoundMessage)) {
			noTransactionsFoundMessage = MessageFormat.format(noTransactionsFoundMessage, (Object[])msgParams);
			response.setNoTransactionsFoundMessage(noTransactionsFoundMessage);
		}
		
		return response;
	}
	
	public void refreshAccountList(int myAcctIndex, MobileSession mbSession) throws Exception{
		Logger.info(" GlobalWallet refreshAccountList: start " , this.getClass());
		Customer customer=mbSession.getCustomer();			
		List<Account> accountList = customer.getAccounts();
		List<Account> newAccountList = new ArrayList<Account>();
		int acctListLen = customer.getAccounts().size();
		Logger.info("GlobalWallet refreshAccountList: existing accounts size  " + acctListLen, this.getClass());
		int index = 0;
		for (int i = 0; i < acctListLen; i++) {
			if (myAcctIndex != i) {
				Account account = accountList.get(i);
				int oldIndex = account.getIndex();
				account.setIndex(index);
				Logger.info("AccName="+account.getAlias()+"Acc#:"+account.getAccountId().getAccountNumber()+", oldIndex="+oldIndex+", newIndex="+index, this.getClass());
				newAccountList.add(account);
				index++;
			}
		}
		/*//changing account index
		int index = 0;
		for(Account account : newAccountList){
			int oldIndex = account.getIndex();
			account.setIndex(index);
			Logger.info("AccName="+account.getAlias()+"Acc#:"+account.getAccountId().getAccountNumber()+", oldIndex="+oldIndex+", newIndex="+index, this.getClass());
			index++;
		}*/
		Logger.info("GlobalWallet refreshAccountList: after deleting the closed GCC accounts size  " + newAccountList.size(), this.getClass());
		customer.setAccounts(newAccountList);
		mbSession.setCustomer(customer);
		Logger.info("GlobalWallet refreshAccountList: end " , this.getClass());
	}
	
	public boolean isReportIntraDayTrans(String transDesc ,String transDate) {
		try {
			Logger.debug("Tran Desc()" + transDesc, getClass());
			Logger.debug("Tran date" + transDate ,getClass());
		
			if (IBankParams.isSwitchOn(IBankParams.ABUSIVE_INWARD_SWITCH) ) {
				int abusiveTrxnDays = IBankParams.getAbusiveTrxnDays();
				Date transactionDate = new SimpleDateFormat("dd/MM/yyyy")
						.parse(transDate);
				Date currentDate = new Date();
				long diff = currentDate.getTime() - transactionDate.getTime();

				long days = TimeUnit.DAYS.convert(diff, TimeUnit.MILLISECONDS);
				Logger.info("no of days since transaction::" + days ,
						getClass());
				
				if(transDesc.toLowerCase().contains(OSKO_DEPOSIT) && days <= abusiveTrxnDays)
				{
					return true;
				}
				
			}
		} catch (Exception ex) {
			Logger.error("Exception in isReportIntraDayTrans", ex, getClass());
		}
		return false;
	}
	
	public AbusiveTransactionVO populateAbusiveTransVO(NPPTransactionDetail nppTranDetail,String acctNo,String bsb,String prPaymentId) {
		AbusiveTransactionVO  abusiveTransVO = new AbusiveTransactionVO();	
		try {
			Logger.debug("AccountInfoHelper populateAbusiveTransVO Unformatted BIC:::"+nppTranDetail.getUnformattedBic(), this.getClass());
			Logger.debug("AccountInfoHelper populateAbusiveTransVO Credit Status Transaction Id BIC:::"+nppTranDetail.getCreditStatusTransId(), this.getClass());
			abusiveTransVO.setDescription(nppTranDetail.getDescription());
			abusiveTransVO.setTranDate(nppTranDetail.getEffectiveDate());
			//abusiveTransVO.setFromAccountNumner(acctNo);
			//abusiveTransVO.setFromBSB(bsb);
			abusiveTransVO.setAbusiveDepositNumber(nppTranDetail.getDepositNumber());
			//abusiveTransVO.setAbusiveReferenceNumber(nppTranDetail.getReferenceId());	
			abusiveTransVO.setAbusiveReferenceNumber(prPaymentId);
			abusiveTransVO.setAmount(nppTranDetail.getAmtForAbusiveTran());
			abusiveTransVO.setTransactionId(nppTranDetail.getUnformattedBic());
			abusiveTransVO.setCreditStatusTransId(nppTranDetail.getCreditStatusTransId());
			abusiveTransVO.setAbusiveDepositNumber(nppTranDetail.getDepositNumber());
			abusiveTransVO.setAbusiveAccountNumber(acctNo);
			abusiveTransVO.setPayeeBSB(bsb);
			if(nppTranDetail.getUnformattedBic() != null) {
				abusiveTransVO.setBic(nppTranDetail.getUnformattedBic().substring(0,11));
				Logger.debug("AccountInfoHelper populateAbusiveTransVO BIC:::"+abusiveTransVO.getBic(), this.getClass());
			}
			abusiveTransVO.setPaymentId(prPaymentId);
			abusiveTransVO.setDescription(nppTranDetail.getDescription());
			/*if(!StringMethods.isEmptyString(nppTranDetail.getPayeeAccountNumber())) {
				if(nppTranDetail.getPayeeAccountNumber().length()>6) {
					abusiveTransVO.setFromBSB(nppTranDetail.getPayeeAccountNumber().substring(0, 6));
					abusiveTransVO.setFromAccountNumner(nppTranDetail.getPayeeAccountNumber().substring(6,nppTranDetail.getPayeeAccountNumber().length()));
				}
			}*/
			if(!StringMethods.isEmptyString(nppTranDetail.getFromAcctDetForAbusiveTrans())) {
				if(nppTranDetail.getFromAcctDetForAbusiveTrans().length()>6) {
					abusiveTransVO.setFromBSB(nppTranDetail.getFromAcctDetForAbusiveTrans().substring(0, 6));
					abusiveTransVO.setFromAccountNumner(nppTranDetail.getFromAcctDetForAbusiveTrans().substring(6,nppTranDetail.getFromAcctDetForAbusiveTrans().length()));
				}
			}
			abusiveTransVO.setReference(nppTranDetail.getReferenceId());
		} catch (Exception ex) {
			Logger.error("Exception in populateAbusiveTransVO", ex, getClass());
		}
		return abusiveTransVO;
	}
}