package au.com.stgeorge.mbank.controller;

import java.util.Calendar;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.AbstractController;

import au.com.stgeorge.framework.common.logging.Logger;
import au.com.stgeorge.framework.common.util.StringMethods;
import au.com.stgeorge.ibank.businessobject.BusinessException;
import au.com.stgeorge.ibank.businessobject.SystemInformation;
import au.com.stgeorge.ibank.businessobject.loanapplication.LoanApplicationService;
import au.com.stgeorge.ibank.businessobject.onlinereg.OnlineRegistrationService;
import au.com.stgeorge.ibank.common.cache.IBankParams;
import au.com.stgeorge.ibank.onlinereg.valueobject.OnlineRegReqLogVO;
import au.com.stgeorge.ibank.util.ServiceHelper;
import au.com.stgeorge.ibank.valueobject.database.CodesVO;
import au.com.stgeorge.ibank.valueobject.database.OriginsVO;
import au.com.stgeorge.mbank.controller.customer.LogonHelper;
import au.com.stgeorge.mbank.controller.loanApplication.LoanApplicationHelper;
import au.com.stgeorge.mbank.controller.onlinereg.OnlineRegHelper;
import au.com.stgeorge.mbank.util.GDPRWebHelper;
import au.com.stgeorge.mbank.util.MBAppHelper;
import au.com.stgeorge.mbank.util.MBAppUtils;
import au.com.stgeorge.perflogger.PerformanceLogger;

public class OnlineRegMainController extends AbstractController {

    public static final String PAGE_NAME = "OnlineReg";
    private static final String ERROR_VIEW = "404";
    private static volatile int numberOfRequests = 0;

    public static final String NUM_KEYBOARD_TYPE = "NumKeyBoardType";
    public static final String NUM_KEYBOARD_PATTERN_TYPE = "NumKeyBoardTypePattern";
    public static final String SYS_VERSION = "SysVersion";
    public static final String ORIGIN_NAME = "OriginName";
    public static final String HELP_DESK_NO = "HelpDeskNo";
    public static final String DATA_ROLE = "DataRole";
    public static final String DATA_ROLE_VALUES = "DataRoleValues";
    public static final String DATA_CUSTOMER_NAME = "DataCustomerName";
    public static final String DATA_BRAND_NAME = "DataBrandName";
    public static final String ACTION_TYPE = "actionType";
    public static final String DATA_SERVICES_AVAILABILITY = "ServicesAvailability";
    public static final Integer MIN_AGE = 13;
    public static final Integer MAX_AGE_YEAR = 1900;
    public static final String PRIVACY_URL = "PrivacyUrl";
    public static final String TnC_URL = "TnCUrl";
    public static final String DATA_YEARS = "DataYears";
    public static final String ERROR = "Error";
    public static final String ONLINE_REG_REQ_TOKEN = "OnlineRegReqToken";
    public static final String BLANK = "";
    public static final String WEB_CONTEXT = "WebContext";
    public static final String REQ_LOAD_CORDOVA = "LoadCordova";
    public static final String ORIGIN_PHONE = "originPhone";
    public static final String ORIGIN_HELPDESK_PHONE = "originHelpDeskPhone";
    public static final String STR_SECRET_KEYMAP= "secretKey";
    public static final String STR_PASSWORD_KEYMAP = "passwordMap";
    public static final String STR_SECNUM_KEYMAP = "securityNumMap";
    public static final String STR_ENCRYPTION_SWITCH = "isEncryptionOn";
	public static final String STR_NAME_ID = "nameId";
	public static final String NEW_APPL = "NewApplication";
	public static final String CUSTTYPE_EXISTING = "existingCustomer";
	public static final String CUSTTYPE_NEW = "newCustomer";
	private static final String SOURCE = "source";
	public static final String COMPASS_DATA = "CompassData";
	public static final String TAGGING_SWITCH = "TaggingSwitch";
	
    @Autowired
    private OnlineRegistrationService onlineRegistrationService;

    @Autowired
    private OnlineRegHelper onlineRegHelper;
    
    @Autowired
    private LoanApplicationHelper loanApplicationHelper;
    
    @Autowired
    private LoanApplicationService loanApplicationService;
    
    @Override
    protected ModelAndView handleRequestInternal(HttpServletRequest request, HttpServletResponse response) throws Exception {

	PerformanceLogger performanceLogger = new PerformanceLogger();
	performanceLogger.startAllLogs();
	String logName = MBAppUtils.getLogName(request);
	performanceLogger.startLog(logName);

	ModelAndView model = null;
	String origin = null;
	String originOld = null;
	String numKeyType = null;
	String numKeyTypePattern = null;
	String dataRole = null;
	String gcisNumber=null;
	//19E1 - Income Verification to get application reference number
	String applRefNumber=null;
	String[] decryptedData = new String[2];
	boolean fromACE = false;

	try {

	    numberOfRequests++;
	    origin = LogonHelper.resolveOrigin(request);
	    
	    if (StringMethods.isEmptyString(origin)) {
		origin = "MBOM";
		request.setAttribute(LogonHelper.ORIGIN, origin);
		Logger.info(
			"Unable to resolve the origin for Online Registration Request Details. URL : " + request.getRequestURL() + " IP :"
				+ request.getRemoteAddr() + " Number Of Requests : " + numberOfRequests + 
				" True IP >> " + request.getHeader(IBankParams.trueClientIP()), this.getClass());
		model = new ModelAndView(ERROR_VIEW);
	    } else {
	    	
			String taggingSwitch = "ON";
			CodesVO codesVO = IBankParams.getCodesData(origin,	IBankParams.CONFIGURATION_PROPERTIES, TAGGING_SWITCH);
			if ( (codesVO == null) || codesVO != null  && "OFF".equalsIgnoreCase(codesVO.getMessage())){
				taggingSwitch = "OFF";
			}
			request.setAttribute(TAGGING_SWITCH, taggingSwitch);
	    	
			request.setAttribute(LogonHelper.ORIGIN, origin);
			numKeyType = logonHelper.getNumKeyBoardType(request);
			numKeyTypePattern = logonHelper.getNumKeyBoardPattern(request);
			request.setAttribute(NUM_KEYBOARD_TYPE, numKeyType);
			request.setAttribute(NUM_KEYBOARD_PATTERN_TYPE, numKeyTypePattern);
	
			//dataRole = request.getParameter(ACTION_TYPE);
			Logger.info("The value for data role is  " + dataRole, this.getClass());
			
			request.setAttribute(DATA_YEARS, getYearRange());
	
			if (this.systemInformation == null) {
			    Logger.info("************ Loading systemInformation for OnlineReg*************** " + request.getRequestURL(), this.getClass());
			    this.systemInformation = getSystemInformationDtls();
			}
			request.setAttribute(WEB_CONTEXT, PAGE_NAME.toLowerCase());
			int loadCordova = logonHelper.loadCordova(request);
			request.setAttribute(REQ_LOAD_CORDOVA, String.valueOf(loadCordova));
	
			request.setAttribute(SYS_VERSION, this.systemInformation.getMB3PackageVersion());
			OriginsVO originVO = IBankParams.getOrigin(origin);
			request.setAttribute(ORIGIN_NAME, originVO.getName());
			request.setAttribute(ORIGIN_HELPDESK_PHONE, originVO.getPhone());
			
			OriginsVO baseOrigin  = IBankParams.getOrigin(originVO.getBankName());
			request.setAttribute(ORIGIN_PHONE, baseOrigin.getPhone());
			
			request.setAttribute(PRIVACY_URL, getCodeValue(origin, IBankParams.PRIVACY_URL));
			request.setAttribute(TnC_URL, getCodeValue(origin, IBankParams.TnC_URL));
	
			OnlineRegReqLogVO onlineRegReqLogVO = new OnlineRegReqLogVO();
			onlineRegReqLogVO.setOrigin(origin);
			onlineRegReqLogVO.setIPAddress(MBAppHelper.resolveIPAddress(request, origin));
			onlineRegReqLogVO.setUserAgent(request.getHeader("User-Agent"));
	
			String source=(String)request.getParameter(SOURCE);
			if(null!=source && source.equalsIgnoreCase("ACE")){
				fromACE=true;
			}
			String throttleResp = "";
			if(fromACE){
				 throttleResp = onlineRegistrationService.checkThrottling(onlineRegReqLogVO,"ACE");
			}else{
				 throttleResp = onlineRegistrationService.checkThrottling(onlineRegReqLogVO,null);
			}
			Logger.debug("throttleResp=" + throttleResp, this.getClass());
			if (throttleResp.equals(OnlineRegistrationService.THROTTLE_ERROR)) {
			    request.setAttribute(ERROR, getErrorMessage(origin));
			    request.setAttribute(ONLINE_REG_REQ_TOKEN, BLANK);
			    
			} else {
			    request.setAttribute(ERROR, BLANK);
			    request.setAttribute(ONLINE_REG_REQ_TOKEN, throttleResp);
			}
			onlineRegReqLogVO.setRegReqToken(throttleResp);
			
			// Changes for eFinance : 18E2

			
			
			if(fromACE){
				if(!IBankParams.isSwitchOn(IBankParams.EFINANCE_SWITCH)){
					Logger.info("efinance switch is off", this.getClass());
				    request.setAttribute(DATA_SERVICES_AVAILABILITY, "OFF");
				}else{
					String token=(String)request.getParameter(COMPASS_DATA);
					Logger.debug("CompassData from ACE is>> " + token, this.getClass());
					if(!StringMethods.isEmptyString(token))
					{
						//19E1 - Income Verification changed method signature to get application reference number
						decryptedData = loanApplicationService.verifyJWTParams(token);
						gcisNumber = decryptedData[0];
						applRefNumber = decryptedData[1];
						
						if(!StringMethods.isEmptyString(gcisNumber)) {
							StringMethods.removeLeadingZero(gcisNumber);
						}
						else {
							//throw error for no gcis in token
							Logger.info("No GCIS in JWT Token: ERROR: ",this.getClass());
							throw new BusinessException(BusinessException.ONLINE_REG_GENERIC_ERROR, "Error checking token - No GCIS");
						}
						if(IBankParams.isSwitchOn(IBankParams.IV_SWITCH)) {
							if(!StringMethods.isEmptyString(applRefNumber)) {
								StringMethods.removeLeadingZero(applRefNumber);
							}
							else {
								//throw error for no applRefNumber in token
								Logger.info("No ApplRefNumber in JWT Token: ERROR: ",this.getClass());
								throw new BusinessException(BusinessException.ONLINE_REG_GENERIC_ERROR, "Error checking token - No ApplRefNumber");
							}
						}
					}
					else
					{
						Logger.info("OnlineReg.processOnlineRegistration(): ERROR: ",this.getClass());
						throw new BusinessException(BusinessException.ONLINE_REG_GENERIC_ERROR, "Error checking token");
					}					
					request.setAttribute(DATA_SERVICES_AVAILABILITY, "ON");
					request.setAttribute(DATA_ROLE, NEW_APPL);
					request.setAttribute(DATA_ROLE_VALUES, CUSTTYPE_NEW);// Hardcoding to new customer will need to be plugged in after customer check and jwt decryption 
					request.setAttribute(DATA_BRAND_NAME, originVO.getName());
					String customerName = "";
					try
						{
							onlineRegReqLogVO.setGcisNumber(gcisNumber);
							onlineRegReqLogVO.setSourceApplRefNum(applRefNumber);
							customerName = loanApplicationHelper.populateNewApplicationCustomer(request, response, onlineRegReqLogVO);
							if(!StringMethods.isEmptyString(customerName)){
								request.setAttribute(DATA_ROLE_VALUES, CUSTTYPE_EXISTING);
								request.setAttribute(DATA_CUSTOMER_NAME, customerName);
							}
						}
						catch (BusinessException e) 
						{
						    Logger.info("BusinessException in Online Reg Main Controller() - [key: " + e.getKey() + "]", e, this.getClass());
						    request.setAttribute(DATA_SERVICES_AVAILABILITY, "OFF");						   
						    
						}
						catch(Exception ex){
							
							request.setAttribute(DATA_SERVICES_AVAILABILITY, "OFF");							
						}
				}
			}
			gdprWebHelper.gdpr(origin, request, response);
			onlineRegHelper.populateKeyMaps(request, origin);
			Logger.debug("Loading Online Registration page... " + request.getRequestURL() + " IP :" + request.getRemoteAddr() + " True IP >> " + request.getHeader(IBankParams.trueClientIP()), this.getClass());
			model = new ModelAndView(PAGE_NAME);
	    }
	    return model;
	}

	catch (Exception e) {
	    origin = "MSTG";
	    request.setAttribute(LogonHelper.ORIGIN, origin);
	    model = new ModelAndView(ERROR_VIEW);
	    Logger.error("Error in Main Controller ", e, this.getClass());
	    return model;
	} finally {
	    numberOfRequests--;
	    performanceLogger.endLog(logName);
	    performanceLogger.endAllLogs();
	}

    }

    private String getErrorMessage(String origin) {
	OriginsVO myOriginVO = IBankParams.getOrigin(origin);
	OriginsVO baseOrigin = IBankParams.getOrigin(myOriginVO.getBankName());
	String[] values = { baseOrigin.getBpayPhone() };
	String errorMessage = MBAppUtils.getMessage(origin, BusinessException.ONLINE_REG_GENERIC_ERROR, values);
	return errorMessage;
    }

    private String getCodeValue(String origin, String code) {
	CodesVO myCodesVO = IBankParams.getCodesData(origin, IBankParams.ONLINE_REG, code);
	if (myCodesVO != null) {
	    return myCodesVO.getMessage();
	} else {
	    return "";
	}
    }

    private String getYearRange() {
	CodesVO myCodesVO = IBankParams.getCodesData(IBankParams.DEFAULT_ORIGIN, IBankParams.ONLINE_REG, IBankParams.MIN_BIRTH_YEAR);
	int minBirthYear = MIN_AGE;
	if (myCodesVO != null) {
	    try {
		minBirthYear = Integer.parseInt(myCodesVO.getMessage());
	    } catch (NumberFormatException nfe) {
		Logger.error("error while parsing minBirthYear:" + myCodesVO.getMessage(), this.getClass());
	    }
	}

	int birthyear = Calendar.getInstance().get(Calendar.YEAR) - minBirthYear;
	StringBuffer yearRange = new StringBuffer();

	for (int i = birthyear; i >= MAX_AGE_YEAR; i--) {
	    if (yearRange.length() > 0) {
		yearRange.append(",");
	    }
	    yearRange.append(i);
	}

	return yearRange.toString();
    }

    private SystemInformation getSystemInformationDtls() {
	SystemInformation systemInformation = (SystemInformation) ServiceHelper.getBean("systemInformation");
	return systemInformation;

    }

    @Autowired
    private LogonHelper logonHelper;

    @Autowired
	private GDPRWebHelper gdprWebHelper;

    @Autowired
    private SystemInformation systemInformation;

}
