package au.com.stgeorge.mbank.model.request.expensesplitter;



import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.Length;
import org.hibernate.validator.constraints.NotEmpty;

import au.com.stgeorge.ibank.businessobject.BusinessException;
import au.com.stgeorge.mbank.model.common.IMBReq;
import au.com.stgeorge.mbank.model.common.ReqHeader;



public class ExpenseGroupReq implements IMBReq{


	/**
	 * 
	 */
	private static final long serialVersionUID = -1595739441271019483L;
	protected static final String AMT_PATTERN = "^[0-9]*\\.{0,1}(\\d{1,2}){0,1}$";
	protected static final String BLOCK_CHARS_PATTERN = "^[0-9A-Za-z',. &/\\-]*$";
	protected static final String MASK_NUMBERS = "^[0-9]+$";
	
	private ReqHeader header;

	public ReqHeader getHeader() {
		return header;
	}

	public void setHeader(ReqHeader header) {
		this.header = header;
	}

	private boolean settled;
	
	@NotEmpty(message = "{errors.can.required}")
	@Pattern(regexp = BLOCK_CHARS_PATTERN, message = "{errors.desc.blockchar}")
	@Length(max = 24, message = "{errors.desc.maxlength}")
	private String expenseGrpName;
	
	@Length(max = 14, message = "{errors.amt.maxlength}")
	@Pattern(regexp = AMT_PATTERN, message = "{errors.amt.blockchar}")
	private String amtPaid;
	
	@Length(max = 14, message = "{errors.amt.maxlength}")
	@Pattern(regexp = AMT_PATTERN, message = "{errors.amt.blockchar}")
	private String totalAmt;
	
	@Length(max = 14, message = "{errors.amt.maxlength}")
	@Pattern(regexp = AMT_PATTERN, message = "{errors.amt.blockchar}")
	private String amtDue;
	
	@Length(max = 14, message = "{errors.amt.maxlength}")
	@Pattern(regexp = AMT_PATTERN, message = "{errors.amt.blockchar}")
	private String amtPaidNow;

	@Pattern(regexp = MASK_NUMBERS, message = "" + BusinessException.WSVC_INVALID_INPUT_PARAM)
	private String expGrpID;

	public String getExpenseGrpName() {
		return expenseGrpName;
	}

	public void setExpenseGrpName(String expenseGrpName) {
		this.expenseGrpName = expenseGrpName;
	}

	public String getAmtPaid() {
		return amtPaid;
	}

	public void setAmtPaid(String amtPaid) {
		this.amtPaid = amtPaid;
	}

	public String getTotalAmt() {
		return totalAmt;
	}

	public void setTotalAmt(String totalAmt) {
		this.totalAmt = totalAmt;
	}

	public String getAmtDue() {
		return amtDue;
	}

	public void setAmtDue(String amtDue) {
		this.amtDue = amtDue;
	}

	public String getExpGrpID() {
		return expGrpID;
	}

	public void setExpGrpID(String expGrpID) {
		this.expGrpID = expGrpID;
	}

	public String getAmtPaidNow() {
		return amtPaidNow;
	}

	public void setAmtPaidNow(String amtPaidNow) {
		this.amtPaidNow = amtPaidNow;
	}

	public boolean isSettled() {
		return settled;
	}

	public void setSettled(boolean settled) {
		this.settled = settled;
	}
	
	

	
	
}
