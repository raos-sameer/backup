package au.com.stgeorge.mbank.controller.customer;

import static au.com.stgeorge.ibank.common.cache.IBankParams.YES;

import java.math.BigDecimal;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collection;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import au.com.stgeorge.digitalsec.logger.DigitalSecLogger;
import au.com.stgeorge.digitalsec.logger.DigitalSecLogggerVO;
import au.com.stgeorge.framework.common.configuration.Configuration;
import au.com.stgeorge.framework.common.configuration.Configurator;
import au.com.stgeorge.framework.common.logging.Logger;
import au.com.stgeorge.framework.common.model.User;
import au.com.stgeorge.framework.common.util.StringMethods;
import au.com.stgeorge.ibank.businessobject.AccountFilter;
import au.com.stgeorge.ibank.businessobject.BusinessException;
import au.com.stgeorge.ibank.businessobject.CardAutoPayService;
import au.com.stgeorge.ibank.businessobject.ContactDetailsValidationServiceImpl;
import au.com.stgeorge.ibank.businessobject.CustomerMaintenanceService;
import au.com.stgeorge.ibank.businessobject.DonationsService;
import au.com.stgeorge.ibank.businessobject.FastFundingService;
import au.com.stgeorge.ibank.businessobject.FixedHomeLoanService;
import au.com.stgeorge.ibank.businessobject.ForceChangePwdService;
import au.com.stgeorge.ibank.businessobject.IBankSecureService;
import au.com.stgeorge.ibank.businessobject.IBankSecurityService;
import au.com.stgeorge.ibank.businessobject.PreferencesService;
import au.com.stgeorge.ibank.businessobject.ResourceException;
import au.com.stgeorge.ibank.businessobject.SimpleDigestService;
import au.com.stgeorge.ibank.businessobject.SmartPlansService;
import au.com.stgeorge.ibank.businessobject.ThirdPartyTransferHelper;
import au.com.stgeorge.ibank.businessobject.assembler.CustomerVOAssembler;
import au.com.stgeorge.ibank.businessobject.categorisation.CategorisationService;
import au.com.stgeorge.ibank.businessobject.globalWallet.GlobalWalletService;
import au.com.stgeorge.ibank.businessobject.impl.CPCServiceImpl;
import au.com.stgeorge.ibank.businessobject.loanapplication.LoanApplicationService;
import au.com.stgeorge.ibank.businessobject.mortgage.MortgageDataService;
import au.com.stgeorge.ibank.businessobject.mortgage.MortgageService;
import au.com.stgeorge.ibank.businessobject.recurringedirectdebits.RecurringDirectDebitsService;
import au.com.stgeorge.ibank.common.cache.CodesCache;
import au.com.stgeorge.ibank.common.cache.IBankParams;
import au.com.stgeorge.ibank.common.cache.IBankRefershParams;
import au.com.stgeorge.ibank.common.log.IBankLog;
import au.com.stgeorge.ibank.dao.CpclistDao;
import au.com.stgeorge.ibank.evcrs.businessobject.EVService;
import au.com.stgeorge.ibank.evcrs.businessobject.valueobject.EVInfo;
import au.com.stgeorge.ibank.loanApplication.LoanApplicationDetail;
import au.com.stgeorge.ibank.loanApplication.util.LoanAppConstants;
import au.com.stgeorge.ibank.loanApplication.util.LoanAppUtil;
import au.com.stgeorge.ibank.loanApplication.util.LoanProdTypeEnum;
import au.com.stgeorge.ibank.messagecentre.valueobject.MessageSearch;
import au.com.stgeorge.ibank.mortgage.util.MortgageUtil;
import au.com.stgeorge.ibank.npp.NPPParams;
import au.com.stgeorge.ibank.npp.PayIdPaymentSwitchParams;
import au.com.stgeorge.ibank.safi.util.SafiConstants;
import au.com.stgeorge.ibank.safi.valueobject.SafiForensicInfo;
import au.com.stgeorge.ibank.service.businessobject.QuickZoneService;
import au.com.stgeorge.ibank.servicestation.businessobject.valueobject.ServiceStationVO;
import au.com.stgeorge.ibank.servicestation.util.ServicetationConstants;
import au.com.stgeorge.ibank.session.SessionConstants;
import au.com.stgeorge.ibank.util.CommonBusinessUtil;
import au.com.stgeorge.ibank.util.ServiceHelper;
import au.com.stgeorge.ibank.util.StringUtil;
import au.com.stgeorge.ibank.valueobject.Account;
import au.com.stgeorge.ibank.valueobject.AccountFlags;
import au.com.stgeorge.ibank.valueobject.Address;
import au.com.stgeorge.ibank.valueobject.AutoApplyRetentionInfo;
import au.com.stgeorge.ibank.valueobject.BTSuperSearchTile;
import au.com.stgeorge.ibank.valueobject.ContactDetail;
import au.com.stgeorge.ibank.valueobject.Cpclist;
import au.com.stgeorge.ibank.valueobject.CreditCardAccount;
import au.com.stgeorge.ibank.valueobject.Customer;
import au.com.stgeorge.ibank.valueobject.CustomerTypes;
import au.com.stgeorge.ibank.valueobject.FavTran;
import au.com.stgeorge.ibank.valueobject.ForceChangePwd;
import au.com.stgeorge.ibank.valueobject.GCCAccount;
import au.com.stgeorge.ibank.valueobject.GCCAccount.GCCAccountStatusEnum;
import au.com.stgeorge.ibank.valueobject.MsgCentreInfo;
import au.com.stgeorge.ibank.valueobject.PaymentsLog;
import au.com.stgeorge.ibank.valueobject.Preference;
import au.com.stgeorge.ibank.valueobject.TermDepositAdditionalInfo;
import au.com.stgeorge.ibank.valueobject.UserAgentVO;
import au.com.stgeorge.ibank.valueobject.database.CodesVO;
import au.com.stgeorge.ibank.valueobject.database.FixedHomeLoanOffer;
import au.com.stgeorge.ibank.valueobject.database.OriginsVO;
import au.com.stgeorge.ibank.valueobject.mortgage.Application;
import au.com.stgeorge.ibank.valueobject.mortgage.DashBoard;
import au.com.stgeorge.ibank.valueobject.transfer.IBankCommonData;
import au.com.stgeorge.mbank.controller.offers.SalesOfferHelper;
import au.com.stgeorge.mbank.controller.onboarding.OBTileHelper;
import au.com.stgeorge.mbank.controller.services.LostCardHelper;
import au.com.stgeorge.mbank.model.common.AccountControlResp;
import au.com.stgeorge.mbank.model.common.AccountKeyInfoResp;
import au.com.stgeorge.mbank.model.common.AccountResp;
import au.com.stgeorge.mbank.model.common.AppParams;
import au.com.stgeorge.mbank.model.common.AppStoreURL;
import au.com.stgeorge.mbank.model.common.BTSuperSearchResp;
import au.com.stgeorge.mbank.model.common.ContactInfoResp;
import au.com.stgeorge.mbank.model.common.CustomerControlResp;
import au.com.stgeorge.mbank.model.common.CustomerResp;
import au.com.stgeorge.mbank.model.common.FavTranResp;
import au.com.stgeorge.mbank.model.common.GhostTileResp;
import au.com.stgeorge.mbank.model.common.IMBResp;
import au.com.stgeorge.mbank.model.common.OnboardingTileResp;
import au.com.stgeorge.mbank.model.common.PhoneInfoResp;
import au.com.stgeorge.mbank.model.common.ReqHeader;
import au.com.stgeorge.mbank.model.common.RespHeader;
import au.com.stgeorge.mbank.model.common.SecureCodeInfoResp;
import au.com.stgeorge.mbank.model.request.customer.LogonReq;
import au.com.stgeorge.mbank.model.response.ExternalLogonResp;
import au.com.stgeorge.mbank.model.response.customer.LastTranDetailResp;
import au.com.stgeorge.mbank.model.response.customer.LockedCardInfoResp;
import au.com.stgeorge.mbank.model.response.customer.LogonResp;
import au.com.stgeorge.mbank.model.response.customer.MarketPreferenceResp;
import au.com.stgeorge.mbank.model.response.servicestation.ServiceStationResp;
import au.com.stgeorge.mbank.session.GenericSessionFactory;
import au.com.stgeorge.mbank.session.IGenericSession;
import au.com.stgeorge.mbank.session.MobileSession;
import au.com.stgeorge.mbank.session.MobileSessionImpl;
import au.com.stgeorge.mbank.util.MBAppConstants;
import au.com.stgeorge.mbank.util.MBAppHelper;
import au.com.stgeorge.mbank.util.MBAppUtils;
import au.com.stgeorge.mbank.util.OriginResolver;
import au.com.stgeorge.mbank.util.ServiceConstants;
import au.com.stgeorge.mobilebank.businessobject.CardService;
import au.com.stgeorge.mobilebank.businessobject.MobileBankService;
//import au.com.stgeorge.ibank.ev.util.EVStatus;
import au.com.stgeorge.tranhistory.service.TranHistorySmartPlanService;
import au.com.stgeorge.tranhistory.valueobject.SmartPlanDashboardInfo;

/**
 * @author C03121
 * 
 *         To change the template for this generated type comment go to
 *         Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class LogonHelper
{
	private static final char DOT_CHAR = '.';
	public static final String MBSA = "MBSA";
	public static final String MBOM = "MBOM";
	public static final String MSTG = "MSTG";
	public static final String ORIGIN = "origin";
	public static final String BROWSER_NAME = "browserName";
	public static final String SESSION_COOKIE_NAME = "MBAppCookie";
	public static final String SECURITYENCRYPTER_BEAN = "ibankSecurityService";
	public static final String MOBILE_TNC_COOKIE = "MobileTnCCookie";
	public static final String MOBILE_TERMS_COOKIE = "MobileTerms";
	
	
	public static final String SMS_RESET_STATUS = "SMSRESET";
	
	
	public static final String APP_VER_COOKIE = "AppVersion";
	public static final String DEVICE_ANDROID = "ANDROID";//to support older app
	public static final String DEVICE_ANDROID_MOBBANK = "AND-MOBBANK";//added in 16E1
	public static final String DEVICE_IOS_MOBBANK = "IOS-MOBBANK";
	public static final String APPACTION_POST = "_POST";
	public static final String TAPNPAY_COOKIE = "tapAndPayCookie";
	public static final String TAPNPAY_SPLASHPAGE_COOKIE = "tapNPaySplashPageCookieNew";
	public static final String TAPNPAY_SPLASHPAGE_COOKIE_OLD = "tapNPaySplashPageCookie";
	
	public static final String MOGO_APP_VERSION_COOKIE = "MOGO";//To support Onboarding tile for Mogo SDK installed devices only.
	public static final String CONNECT_APP_VER_COOKIE = "CONNECT";
	
	public static final String ONBOARDING_COOKIE = "_onboarding";
	
	public static final String SHARE_BSB_ACC_NUM_COOKIE = "share";
	public static final String ECORRESPONDENCE_COOKIE = "postpdf";
	
	public static final double ANDROID_BACKBTN_APPVERSION =  7.0;
	public static final double IOS_CSHSAFIOLD_APPVERSION =  9.29;
	public static final String LOGGEDON_STATE_FORCE_RESETPWD = "1";
	public static final String LOGGEDON_STATE_FORCE_RESETPWD_SECNUM = "2";
	public static final String LOGGEDON_STATE_FORCE_PWDCHANGE = "3";
	public static final String LOGGEDON_STATE_FORCE_PWDCHANGE_2FA = "4";
	public static final String LOGGEDON_STATE_FORCE_PWDCHANGE_2FA_EXEMPT = "5";
	public static final String AUTO_INIT_RESET_PWD_SECNUM = "6";	
	public static final String LOGGEDON_STATE_ONLINE_REGISTRATION = "7";
	public static final String LOGGEDON_STATE_ONLINE_REGISTRATION_2FA = "8";
	public static final String LOGGEDON_STATE_COMPLETE = "9";
	public static final String LOGGEDON_STATE_CRS_HARD_PROMPT = "10";
	public static final String LOGGEDON_STATE_ECORRESPONDENCE_PROMPT = "11";
	public static final String LOGGEDON_STATE_SAFI_CHALLENGE = "12";
	
	/*public static final String LOGGEDON_STATE_SAVINGS_ONBOARDING_PROMPT = "13";
	public static final String LOGGEDON_STATE_P2M_DECOMMISSION_PROMPT = "14";*/
	
	public static final String LOGON_ACTION_MORTGAGE_PRIMARY = "primary";
	public static final String LOGON_ACTION_MORTGAGE_SECONDARY = "secondary";
	
	private static final String TAP_N_PAY = "tapAndPay";
	private static final String CUST_INFO = "customerinfo";
	private static final String SALES_OFFER_HELPER_BEAN = "salesOfferHelper";
	private static final String CPCLIST_BEAN = "cpcListDao";
	
	private static final String APPVERSION_COOKIE_DOC_UPLOAD = "_docupload";
	
	public static final String NPP_OUTWARD_PILOT_LIST = "NPPOutwardPilotList";
	
	public static final String MADISON_PILOT = "MadisonPilot";
	public static final String MADISON_IN_APP_PROV_PILOT = "MadisonInAppProvPilot";
	
	
	private String androidAmtField;

	private SimpleDigestService simpleDigestService;

	private FastFundingService fastFundingService;
	
	public static final String SPRING_INSURANCE_SERVICE_BEAN  ="insuranceService";
	public static final String SPRING_EVSERVICE_BEAN  ="evService";
	private static final String SMPL_DEVICE_ID ="DeviceID";
	
	public static final String ORIGIN_TABLET_PREFIX = "T";
	
	private CategorisationService categorisationService;
	
	private OBTileHelper obTileHelper;
	
	private LoanApplicationService loanApplService;
	
	private MortgageService mortgageService;
	
	private CodesCache codesCache;
	
	private RecurringDirectDebitsService recurringDirectDebits;
	
	private DonationsService donationsService;
	
	private IBankRefershParams ibankRefreshParams;
	
	private CPCServiceImpl cpcService;
	
	private FixedHomeLoanService fixedHomeLoanService;
	
	private GlobalWalletService globalWalletService;
	
	private TranHistorySmartPlanService tranHistorySmartPlanService;
	
	private String googleMapApiKey;
	
	private CardAutoPayService cardAutoPayService;
	
	private ContactDetailsValidationServiceImpl qasService;
	
	private SmartPlansService smartPlansService;
	
	

	public SmartPlansService getSmartPlansService() {
		return smartPlansService;
	}

	public void setSmartPlansService(SmartPlansService smartPlansService) {
		this.smartPlansService = smartPlansService;
	}

	public ContactDetailsValidationServiceImpl getQasService() {
		return qasService;
	}

	public void setQasService(ContactDetailsValidationServiceImpl qasService) {
		this.qasService = qasService;
	}

	public LoanApplicationService getLoanApplService() {
		return loanApplService;
	}

	public void setLoanApplService(LoanApplicationService loanApplService) {
		this.loanApplService = loanApplService;
	}
		

	public MortgageService getMortgageService() {
		return mortgageService;
	}

	public void setMortgageService(MortgageService mortgageService) {
		this.mortgageService = mortgageService;
	}

	public FixedHomeLoanService getFixedHomeLoanService() {
		return fixedHomeLoanService;
	}

	public void setFixedHomeLoanService(FixedHomeLoanService fixedHomeLoanService) {
		this.fixedHomeLoanService = fixedHomeLoanService;
	}

	public GlobalWalletService getGlobalWalletService() {
		return globalWalletService;
	}

	public void setGlobalWalletService(GlobalWalletService globalWalletService) {
		this.globalWalletService = globalWalletService;
	}

	public TranHistorySmartPlanService getTranHistorySmartPlanService() {
		return tranHistorySmartPlanService;
	}

	public void setTranHistorySmartPlanService(TranHistorySmartPlanService tranHistorySmartPlanService) {
		this.tranHistorySmartPlanService = tranHistorySmartPlanService;
	}
	
	public CardAutoPayService getCardAutoPayService() {
		return cardAutoPayService;
	}

	public void setCardAutoPayService(CardAutoPayService cardAutoPayService) {
		this.cardAutoPayService = cardAutoPayService;
	}




	public static final String SERVICE_BADGE_COOKIE = "serviceBadgeCookie";
	public static final String SERVICE_BADGE_COOKIE_VERSION = "1";
	
	public FastFundingService getFastFundingService() {
  	return fastFundingService;
  }

	public void setFastFundingService(FastFundingService fastFundingService) {
  	this.fastFundingService = fastFundingService;
  }

	
	public OBTileHelper getObTileHelper() {
		return obTileHelper;
	}

	public void setObTileHelper(OBTileHelper obTileHelper) {
		this.obTileHelper = obTileHelper;
	}

	public String getAndroidAmtField()
	{
		return androidAmtField;
	}

	public void setAndroidAmtField(String androidAmtField)
	{
		this.androidAmtField = androidAmtField;
	}

	
	public SimpleDigestService getSimpleDigestService()
	{
		return simpleDigestService;
	}

	public void setSimpleDigestService(SimpleDigestService simpleDigestService)
	{
		this.simpleDigestService = simpleDigestService;
	}
	
	public RecurringDirectDebitsService getRecurringDirectDebits() {
		return recurringDirectDebits;
	}

	public void setRecurringDirectDebits(RecurringDirectDebitsService recurringDirectDebits) {
		this.recurringDirectDebits = recurringDirectDebits;
	}

	public DonationsService getDonationsService() {
		return donationsService;
	}

	public void setDonationsService(DonationsService donationsService) {
		this.donationsService = donationsService;
	}

	public CategorisationService getCategorisationService() {
		return categorisationService;
	}

	public void setCategorisationService(
			CategorisationService categorisationService) {
		this.categorisationService = categorisationService;
	}
	
	public IBankRefershParams getIbankRefreshParams() {
		return ibankRefreshParams;
	}

	public void setIbankRefreshParams(IBankRefershParams ibankRefreshParams) {
		this.ibankRefreshParams = ibankRefreshParams;
	}

	public IGenericSession createCompassSession(User myUser, String origin, String browser, HttpServletRequest httpServletRequest) throws BusinessException
	{
		return createCompassSession(myUser, origin, browser, httpServletRequest, "");
	}
	
	
	public IGenericSession createCompassSession(User myUser, String origin, String browser, HttpServletRequest httpServletRequest, String prefix) throws BusinessException
	{

		try
		{
			String sessionId = new MBAppHelper().generatetSessionID();
			sessionId = prefix + sessionId;
			IGenericSession gSession =  null;
			if ( isDBSession() )
			{
				gSession = GenericSessionFactory.getInstance(sessionId);
			}
			else
			{
				 gSession = GenericSessionFactory.getInstance(httpServletRequest);
			}
			

			gSession.setUser(myUser);

			gSession.setAttribute(ORIGIN, origin);
			gSession.setAttribute(BROWSER_NAME, browser);

			Logger.debug(" User CAN : " + myUser.getUserId() + ",GCIS Number : " + myUser.getGCISNumber() + ",Card : "
					+ myUser.getAttribute(IBankParams.USEROBJ_CARDNUMBER) + ",LastAccess : " + myUser.getAttribute(IBankParams.USEROBJ_LASTACESSBY)
					+ ",MustChangePwd " + myUser.isStatusMustChangePassword() + ",TT Access " + myUser.getAttribute(IBankParams.USEROBJ_TT_ACCESS) + ",Origin "
					+ myUser.getAttribute(IBankParams.USEROBJ_BRAND) + ",Lim Attr : " + myUser.getAttribute(IBankParams.USEROBJ_LIM) + ",Session ID : "
					+ gSession.getId(), this.getClass());

			return gSession;
		} catch (Exception e)
		{

			IBankLog.logTRC(" Unable to create the Session " + myUser.getUserId() + " " + myUser.getAttribute(IBankParams.USEROBJ_CARDNUMBER), e,
					LogonHelper.class);
			throw new BusinessException(BusinessException.SYSTEM_UNAVILABLE, " Unable to create the Session " + myUser.getUserId() + " "
					+ myUser.getAttribute(IBankParams.USEROBJ_CARDNUMBER));
		}
	}

	public static final String SPRING_ORIGIN_RESOLVER_BEAN = "originResolver";

	public static  String resolveOrigin(HttpServletRequest request)
	{
		OriginResolver originResolver = (OriginResolver) ServiceHelper.getBean(SPRING_ORIGIN_RESOLVER_BEAN);
		String tempOrigin = originResolver.resolveOrigin(request);
		Logger.info("Origin resolved to : " + tempOrigin, LogonHelper.class);
		return tempOrigin;
	}

/*	public static String resolveOrigin(HttpServletRequest httpServletRequest)
	{
		return resolveSimpOrigin(httpServletRequest);
	} */

//	public  IMBResp populateResponse(Customer customer, User user,int unreadMsgCount, HttpServletRequest request, HttpServletResponse response, boolean mustChangePwd) throws BusinessException
//	{
//		return populateResponse(customer, user, unreadMsgCount, request, response, mustChangePwd,null);
//	}
	

	public  IMBResp populateResponse(Customer customer, User user,int unreadMsgCount, HttpServletRequest request, HttpServletResponse response, boolean mustChangePwd) throws BusinessException
	{
		return populateResponse( customer,  user, unreadMsgCount,  request,  response,  mustChangePwd, null, null) ;
	}
	
	public  IMBResp populateResponse(Customer customer, User user,int unreadMsgCount, HttpServletRequest request, HttpServletResponse response, boolean mustChangePwd, ServiceStationVO servicestationVO, AutoApplyRetentionInfo autoApply) throws BusinessException
	{
		LogonResp logonResponse = new LogonResp();
		MobileSession mobileSession = new MobileSessionImpl();
		mobileSession.getSessionContext(request);		

		
		String origin =  getOrigin( mobileSession,  request ) ;
		Logger.debug("Logon Helper : origin -"+origin, this.getClass());
		
//		logonResponse.setApiVersion(ServiceConstants.API_VERSION);
		au.com.stgeorge.mbank.model.common.CustomerResp mbCustomer = new au.com.stgeorge.mbank.model.common.CustomerResp();
		mbCustomer.setTitle(customer.getTitle());
		mbCustomer.setFirstName(customer.getFirstName());
		mbCustomer.setMiddleName(customer.getMiddleName());
		mbCustomer.setLastName(customer.getLastName());
		mbCustomer.setFullName(customer.getFullName());
		
		mbCustomer.setHasDDAAccount(isTransactionAccountPresent(customer.getAccounts()));
//		mbCustomer.setSystemDate( new Date() );
//		mbCustomer.setLastLogonDateTime(customer.getPreference().getLastLogonDate());
		// mbCustomer.setLastName(customer.getFullName());

		LastTranDetailResp lastTranDetailResp =  populateLastTranDetailResp(customer.getPreference().getLastLogonDate(),  user);
		
		MarketPreferenceResp marketPreferenceResp = populateMarketPreferenceResp(customer);
	
/*		PaymentsLog payLog = getLastTransactionDetails(user);
		if (payLog != null)
		{
			
			mbCustomer.setLastTranDateTime(payLog.getDate());
			mbCustomer.setLastTranType(getLastTransactionType(payLog));
			mbCustomer.setLastTranAmount(String.valueOf(payLog.getAmount()));
		}  */
		
		if ( lastTranDetailResp != null )
		{
			mbCustomer.setLastTranDetail(lastTranDetailResp);
		}
		mbCustomer.setMarketPreference(marketPreferenceResp);
		
		mbCustomer.setBillers(MBAppHelper.populateBillerList(customer.getBillers()));

		mbCustomer.setContactInfo(populateContact(customer.getContactDetail()));

		mbCustomer.setPayees(MBAppHelper.populatePayees(customer.getThirdParties()));
		
		mbCustomer.setSecureCodeInfo(populateSecureCodeInfo(customer));		
		boolean isLockedCard = isTempBlockedCard(customer.getGcis(),origin);
		
		if  (isLockedCard)
		{
			LockedCardInfoResp lockedCardInfoResp = new LockedCardInfoResp();
			CodesVO codeItem=IBankParams.getCodesData(origin , IBankParams.CONST_LOCK_UNLOCK,IBankParams.LOCK_UNLOCK_TILE_TXT);
			if ( codeItem != null && ! StringMethods.isEmptyString(codeItem.getMessage()))
			{
				lockedCardInfoResp.setLockText(codeItem.getMessage());
			}
			
			mbCustomer.setLockedCardInfoResp(lockedCardInfoResp);
		}
		else
		{
		
			if ( customer.getPreference().isDisplayELeadsSplashPage() )
			{
				mbCustomer.setInvitationInfoResp(MBAppHelper.populateInvitation(customer));
				//My Invitation for sales
				SalesOfferHelper salesOfferHelper = (SalesOfferHelper) ServiceHelper.getBean(SALES_OFFER_HELPER_BEAN);		
				mbCustomer.setSalesOfferTeaserResp(salesOfferHelper.populateTeaserResp(customer));//MyInvitation
			}
			
			// adding the service station message to session and  logon response
			if(null!=mbCustomer.getSalesOfferTeaserResp())
			{
				if(null==mbCustomer.getSalesOfferTeaserResp().getIsDashboard())
				{
					if(null!=servicestationVO)
					{			
						mobileSession.setServiceStationDashboardMessage(servicestationVO.getServiceStationMsg());
						mbCustomer.setServiceStation(populateServiceStationResp(servicestationVO));
					}
				}
			}
		}
		
		 int previousHomeLoanStatus=-1;
         if(IBankParams.isHomeLoanDigiSwitchON()){
              if(customer.getPreference()!=null){
            	  previousHomeLoanStatus=customer.getPreference().getFixedHomeLoanStatus();
              }
         }

		
		
		ArrayList<au.com.stgeorge.mbank.model.common.AccountResp> accountList = populateAccountList(customer,autoApply);
		mbCustomer.setAccounts(accountList);
		
		  if(IBankParams.isHomeLoanDigiSwitchON()){
              if(customer.getPreference()!=null){
            	  if(previousHomeLoanStatus!=-1 && previousHomeLoanStatus != customer.getPreference().getFixedHomeLoanStatus()){
                	  mobileSession.setCustomer(customer);
                  }
              }
          }
		
		
		
		if(IBankParams.isHomeLoanDigiSwitchON() && accountList != null){
			for (au.com.stgeorge.mbank.model.common.AccountResp actResp : accountList){
				if(actResp.isNewHomeLoanDigiOffer()){ 
					unreadMsgCount ++;
				}
			}
		}
		if(customer.getObTileVO() != null){
			mbCustomer.setOnboardingTileResp(populateOnboardingTileResp(customer));
		}else if(customer.getBtSuperSearchTile() != null){
			mbCustomer.setBtSuperSearchResp(populateBTSuperSearchResp(customer));
		}
		/*
		 * TODO Review changes for fastfunding code cleanup
		 * else{
			FastFundingResp ffr = populateFastFundingResp(customer);
			if(ffr != null )
				mbCustomer.setFastFundingResp(ffr);
		}*/
		
		boolean spashPageReqd = false;
		String encryptedUserid = getEncryptedUserID(user.getUserId());
		Logger.debug("Tap n Pay Switch: "+isTapAndPayEligibile(request), this.getClass());
		
		
		CodesVO codeItem=codesCache.getCodes(IBankParams.BRAND_ORIGIN, IBankParams.CONFIGURATION_PROPERTIES,IBankParams.TapAndPayDecomissionSwitch);
		Logger.debug("Tap n Pay Decomission Switch: "+codeItem.getMessage(), this.getClass());
		
		
		
		
		if(IBankParams.ON.equalsIgnoreCase(codeItem.getMessage())){ 
			
			if(isAndroidMobBankDeviceInAppVer(request) && !isSplashPageCookieFound(request, response, encryptedUserid, "1.0") && !isOnboardingFlow(mobileSession)){ // checks if splash page needs to be shown
				spashPageReqd = true;
				 setSplashPageCookie(request, response, encryptedUserid, "1.0"); // set the cookie
			}
		}
 
        //To not show first time help during App Logon --start
		boolean firstTimeCookie=false;
		Cookie cookie = getCookie(request, APP_VER_COOKIE);
		
		logAppversionCookie( mobileSession ,  cookie );

        if(cookie!=null && !(StringMethods.isEmptyString(cookie.getValue()))){
              //coming from native app
              firstTimeCookie = true;
        }
        else{
              //coming from msite OR browser
        	  Cookie oldCookie = null;
        	  boolean isOldCookieDelete = false;
    		  oldCookie = isFirstTimeHelpCookieExists(request, MOBILE_DEVICE_FIRST_TIME_COOKIE);
    		  if(oldCookie!=null)
    		  {
    			  isOldCookieDelete=deleteOldCookies(request,response,MOBILE_DEVICE_FIRST_TIME_COOKIE);
    				if(isOldCookieDelete){
    					Logger.info(" Existing Old domain Cookie Name:"
    							+ MOBILE_DEVICE_FIRST_TIME_COOKIE
    							+ ", isOldCookieDelete :" + isOldCookieDelete, this.getClass());
    				}
    				else{
    					Logger.debug("Existing Old domain Cookie Name: "
    							+ MOBILE_DEVICE_FIRST_TIME_COOKIE
    							+ "isOldCookieDelete :" + isOldCookieDelete, this.getClass());
    				}
    			  firstTimeCookie=true;
    		  }else if(isFirstTimeCookieExists(request)){
    			  firstTimeCookie=true;
    		  }
             
              setFirstTimeHelpCookie(request, response) ;                
        }

	  //To not show first time help during App Logon --end
        EVService evService = (EVService) ServiceHelper.getBean(SPRING_EVSERVICE_BEAN);
		int evStatus=(int)evService.getEVTileStatus(customer);
		customer.setEvStatus(evStatus);
		
		
		
		CustomerControlResp customerControl = populateCustomerControlResp(origin, mobileSession, cookie, user, customer , firstTimeCookie, spashPageReqd);

		handleGetCashFlag(request, customerControl);
		
		mbCustomer.setCustomerControl(customerControl);
		
		mbCustomer.setUnreadMsgCount(unreadMsgCount);
		if(customer.getInvitation() != null)
			mbCustomer.setUnreadOfferCount(customer.getInvitation().getOfferCount());
		
			
		
		FavTranResp mostFavTran = populateMostFavTranResp( customer );
		if ( mostFavTran != null )
			mbCustomer.setMostFavTran(mostFavTran);
			
		//19E1: setting the eligible from account indexes for Savings Habit
		for (Account account : customer.getSavingsHabitFromAcctsList()) {
			mbCustomer.getSavingsHabitFromAccts().add(account.getIndex());
		}
				
		logonResponse.setCustomer(mbCustomer);
		
		AppParams appParams = populateAppParams(request, customer);
		
		
		//To hide the Get Active on your account functionality if there is no eligible transaction account
		/*
		 * TODO Review changes for fast funding code changes
		 * if(appParams.getFastFundingSwitch().equalsIgnoreCase("ON")){
			List<Account> ffAccountList  = AccountFilter.filterGetActiveOnYourAccount(customer.getAccounts());
			if(ffAccountList.size() >0)
			{
				appParams.setFastFundingSwitch("ON");
			}
			else{
				appParams.setFastFundingSwitch("OFF");
			}
		}*/
		//17E3 Transaction Categorisation
		Integer categSwitchValue = categorisationService.getTnxCategorisationSwitchFlag(appParams.getOrigin(), user.getGCISNumber(), true);
			appParams.setTnxCategorisationSwitch(categSwitchValue);
		
		//17E4 DDA Transaction Categorisation
		Integer DDAcategSwitchValue = categorisationService.getSwitchFlag(appParams.getOrigin(), user.getGCISNumber(), CategorisationService.DDA_CATEGORISATION_SWITCH);
			appParams.setDdaTnxCategorisationSwitch(DDAcategSwitchValue);
		
		logonResponse.setAppParams(appParams);
		logonResponse.setChangePwdReqd(mustChangePwd);
		
		String encryptedCookieUserid = getEncryptedUserID(user.getUserId());
		addNewTnCCookie(request, response,encryptedCookieUserid,"1.0");
		
		Boolean smsRest = (Boolean) user.getAttribute(SMS_RESET_STATUS);
		if ( smsRest != null && smsRest.booleanValue())
		{
			logonResponse.setChangePwdAndSecNumReqd(smsRest.booleanValue());
		}
		
		//18E2 - Service Menu Badging Validation
		boolean isCookieFound = isServiceBadgingCookieExists(request, response,encryptedCookieUserid);
		if (!isCookieFound )
		{
			Logger.info("Service Badging Cookie not found for " + user.getUserId() ,this.getClass());
			logonResponse.setServiceBadgingRequired(true);
		}
		else
		{
			Logger.info("Service Badging Cookie found for " + user.getUserId() ,this.getClass());
			logonResponse.setServiceBadgingRequired(false);
		}
		//to disable service badge
		//logonResponse.setServiceBadgingRequired(false);
		
		return logonResponse;

	}
	
	public  IMBResp populateExternalLogonResponse(User user, HttpServletRequest request, HttpServletResponse response) throws BusinessException
	{
		ExternalLogonResp logonResponse = new ExternalLogonResp();
		logonResponse.setSuccess("Y");
		return logonResponse;
	}


	private void handleGetCashFlag(HttpServletRequest request, CustomerControlResp customerControl) throws BusinessException {
		MobileSession mobileSession = new MobileSessionImpl();
		mobileSession.getSessionContext(request);		
		
		if (customerControl.isAllowGetCash()){
			CodesVO codeItem=IBankParams.getCodesData(IBankParams.BRAND_ORIGIN, IBankParams.CONFIGURATION_PROPERTIES,IBankParams.GET_CASH_SWITCH);
			//0,1,9 9 FOR BROWSER
			Logger.debug("switch in codes table : " + codeItem.getMessage(), LogonHelper.class);
			// GetCashSwitch = 9, ignore flag sent by native app. 
			if (codeItem != null && "9".equals(codeItem.getMessage())){
				return;
			}
			
			Logger.debug("allowGetCash in session : " + mobileSession.getGetCashAllowFlag() , LogonHelper.class);
//			if (!("1".equals(mobileSession.getGetCashAllowFlag()))){
//				customerControl.setAllowGetCash(false);
//			}
			
			Logger.debug("allowGetCash in controll : " + customerControl.isAllowGetCash() , LogonHelper.class);
			
		}
	}

	public  ContactInfoResp populateContact(ContactDetail contactDetail)
	{
		ContactInfoResp mbContact = new ContactInfoResp();

/*		ArrayList<au.com.stgeorge.mbank.model.common.AddressResp> addresses = new ArrayList<au.com.stgeorge.mbank.model.common.AddressResp>();
		if (contactDetail.getMailingAddress() != null)
			addresses.add(populateAddress(contactDetail.getMailingAddress(), "MAIL"));

		if (contactDetail.getResidentialAddress() != null)
			addresses.add(populateAddress(contactDetail.getResidentialAddress(), "RES"));
*/
		
		ArrayList<au.com.stgeorge.mbank.model.common.PhoneInfoResp> phones = new ArrayList<au.com.stgeorge.mbank.model.common.PhoneInfoResp>();
		
		PhoneInfoResp phoneInfo = null;
		if ( contactDetail.getMobileNumber() != null )
		{
			phoneInfo = new PhoneInfoResp();
			phoneInfo.setPhoneType( "MOBILE" );
//			phoneInfo.setPhoneNum(maskPhoneNumber(contactDetail.getMobileNumber().getDisplayPhoneNumber() ));
			if ( StringMethods.isEmptyString(contactDetail.getMobileNumber().getPhoneNumber() ) )
			{
				phoneInfo.setPhoneNum("");
			}
			else
			{
				phoneInfo.setPhoneNum(maskPhoneNumber(contactDetail.getMobileNumber().getAreaCode() + contactDetail.getMobileNumber().getPhoneNumber()));
			}
			phones.add(phoneInfo);
		}

		if ( contactDetail.getHomeNumber() != null )
		{
			phoneInfo = new PhoneInfoResp();
			phoneInfo.setPhoneType( "HOME" );
//			phoneInfo.setPhoneNum( maskPhoneNumber(contactDetail.getHomeNumber().getDisplayPhoneNumber() ));
			if ( StringMethods.isEmptyString(contactDetail.getHomeNumber().getPhoneNumber()) )
			{
				phoneInfo.setPhoneNum("" );
			}
			else
			{
				phoneInfo.setPhoneNum("(" + contactDetail.getHomeNumber().getAreaCode() + ") "
						+ maskPhoneNumber(contactDetail.getHomeNumber().getPhoneNumber()));
			}
			phones.add(phoneInfo);
		}

		if ( contactDetail.getWorkNumber() != null )
		{
			phoneInfo = new PhoneInfoResp();
			phoneInfo.setPhoneType( "WORK" );
//			phoneInfo.setPhoneNum( maskPhoneNumber(( contactDetail.getWorkNumber().getDisplayPhoneNumber() )));
			if ( StringMethods.isEmptyString(contactDetail.getWorkNumber().getPhoneNumber()) )
			{
				phoneInfo.setPhoneNum("");
			}
			else
			{
				phoneInfo.setPhoneNum("(" + contactDetail.getWorkNumber().getAreaCode() + ") "
						+ maskPhoneNumber(contactDetail.getWorkNumber().getPhoneNumber()));
			}
			
			phones.add(phoneInfo);
		}
		
		if ( phones.size() > 0 )
		{
			mbContact.setPhones(phones);
//			return mbContact;
		}
//		if (addresses.size() > 0)
	//	{
		//	mbContact.setAddresses(addresses);
	//		return mbContact;
		//}

		mbContact.setEmailAddress(contactDetail.getEmail() );
		return mbContact;
	}

	private  au.com.stgeorge.mbank.model.common.AddressResp populateAddress(Address address, String type)
	{
		au.com.stgeorge.mbank.model.common.AddressResp mbAddress = new au.com.stgeorge.mbank.model.common.AddressResp();
		if (address != null)
		{
			mbAddress.setAddrType(type);
			mbAddress.setCountryName(address.getCountryName());
			mbAddress.setLine1(address.getLine1());
			mbAddress.setLine2(address.getLine3());
			mbAddress.setLine3(address.getLine3());

			mbAddress.setPostCode(address.getPostZipcode());
			mbAddress.setState(address.getState());
			mbAddress.setSuburb(address.getSuburb());
		}
		return mbAddress;

	}

	
	public  ArrayList<au.com.stgeorge.mbank.model.common.AccountResp> populateAccountList(Customer customer, AutoApplyRetentionInfo autoApplyRetentionInfo)
	{
		ArrayList<au.com.stgeorge.mbank.model.common.AccountResp> mbAccountList = new ArrayList<au.com.stgeorge.mbank.model.common.AccountResp>();

		List<Account> accountList = customer.getAccounts();
		String accountNumberFromMessage="",branchkey="",custMsgId="";
		List<String> cashAdvWarEligibleCodesMsgs = null;
		boolean isAutoApplyApplicable=false;
		List<String> bcopEligibleCodesMsgs = null;
		Map<String, SmartPlanDashboardInfo> spDashboardDetails = null;
		
		if(autoApplyRetentionInfo!=null &&  autoApplyRetentionInfo.getAccountNumber()!=null && autoApplyRetentionInfo.getAccountNumber().length()==16){
			accountNumberFromMessage = autoApplyRetentionInfo.getAccountNumber();
			//branchkey = accountNumber.substring(3,6);
			accountNumberFromMessage = accountNumberFromMessage.substring(3,16);
			//accountNumber = StringMethods.removeLeadingZero(accountNumber);
			custMsgId = String.valueOf(autoApplyRetentionInfo.getCustMsgId());
			isAutoApplyApplicable =true;
			
		}
		
		
		
		//19E3 - CashAdvance Fee warning checkbox show eligible sub product codes (only for CRA Accounts)
		CodesVO codeItem=IBankParams.getCodesData(IBankParams.DEFAULT_ORIGIN , IBankParams.CASH_ADBVANCE_WARNING_CATEGORY,IBankParams.ELIGIBLE_SUBPRODCODE);
		if ( codeItem != null && ! StringMethods.isEmptyString(codeItem.getMessage())){
			cashAdvWarEligibleCodesMsgs = Arrays.asList(codeItem.getMessage().split(","));
		}
		
		//19E4 - BCOP Transfer from Gold cash mangement and investment savings account(only for DDA accounts)
		codeItem=IBankParams.getCodesData(IBankParams.DEFAULT_ORIGIN , IBankParams.GOLD_INVESTMENT_WARNING_CATEGORY,IBankParams.ELIGIBLE_SUBPRODCODE);
		if ( codeItem != null && ! StringMethods.isEmptyString(codeItem.getMessage())){
			bcopEligibleCodesMsgs = Arrays.asList(codeItem.getMessage().split(","));
		}

		
		Map<String,FixedHomeLoanOffer> map =null;SimpleDateFormat homeLoanDateFormat = new SimpleDateFormat("dd MMM yyyy");
		if(IBankParams.isHomeLoanDigiSwitchON()){
			try{
				map=fixedHomeLoanService.getHomeLoanEligiblilityDetails(customer);
			}
			catch(Exception e){
				Logger.error("Exception found in fixed home Loan ",e,this.getClass());
			}
			}
		
		//2oE4 - Smart Plans for dashboard display
		if(ibankRefreshParams.isSmartPlanSwitchON(IBankParams.DEFAULT_ORIGIN, customer.getGcis()) && accountList != null) {
			List<String> craAccountNumber = new ArrayList<String>();
			for (Account account : accountList){
				if (Account.CRA.equalsIgnoreCase(account.getAccountId().getApplicationId())) {
					try {
						if(smartPlansService.isCustomerPrimaryCardHolder(account)) {
							craAccountNumber.add(account.getAccountId().getAccountNumber());
						}
					} catch (BusinessException e) {
						Logger.error("Exception found in Smart Plan dashboard section ",e,this.getClass());
					}
				}
			}
			if(craAccountNumber.size() > 0) {
				//Query Smart Plan details table to get the list of active plans and Total Rem Amt
				spDashboardDetails = tranHistorySmartPlanService.getActionPlanDashboardInfo(craAccountNumber);
			}
		}
		
		
		if(accountList != null){
		for (Account account : accountList)
		{
			String accountNumber="";int no_paddding_zeros=0;
			
			
			
			ArrayList<Integer> linkedIndexes = null; 
			au.com.stgeorge.mbank.model.common.AccountResp mbAccount = new au.com.stgeorge.mbank.model.common.AccountResp();
			if(account.getErrorCode() == 0){
				if(!account.isAccountTermDeposit()||account.getAccountId().getSubProductCode().equals("80"))
				{
					mbAccount.setAvailBalance(account.getAvailableBalance());		
				}
				else
				{
					mbAccount.setAvailBalance(null);
				}
				
				mbAccount.setBalance(account.getBalanceDisplay());
			}else
				mbAccount.setIsSystemAvail(false);
			
			
			//18E1 Added Changes for Overseas Transfer to send Fee
			BigDecimal audFee = null;
			BigDecimal nonAudFee = null;
			try {
				audFee = MBAppUtils.getUpdatedFee(IBankParams.DEFAULT_ORIGIN, account, MBAppUtils.CURRENCY_CODE_AUD);
				nonAudFee = MBAppUtils.getUpdatedFee(IBankParams.DEFAULT_ORIGIN, account, MBAppUtils.CURRENCY_CODE_NONAUD);
			} catch (ResourceException | BusinessException e1) {
				
			} 
			mbAccount.setAudFee(audFee);
			mbAccount.setNonAudFee(nonAudFee);
			
			
			// mbAccount.setCraInProductTransfer(account.getcr)
			// mbAccount.setCraNeedsActivation(account.getAccountId().is)
			// mbAccount.setLoanRedrawFee( account.getLoanAdditionalInfo().get)
			// mbAccount.setNominatedAccount(getMBAccountKeyInfo(account, true));
			// mbAccount.setTdaInInitialDeposittdaInInitGrace(account.is)

			AccountControlResp mbAccountControl = getMBAccountControl(account, accountList);
			mbAccount.setAccountControl(mbAccountControl);

			AccountKeyInfoResp accountKeyInfo = getMBAccountKeyInfo(account, false);
			mbAccount.setAccountKeyInfo(accountKeyInfo);
			mbAccount.setIsIncentiveSaver(String.valueOf(IBankParams.INCENTIVE_SAVER_ACCOUNT).equals(account.getAccountId().getGroupCode()));
			
			//20E1 - GCC - LOAD/UNLOAD
			//SBGEXP-7560 : GCC Payments - MB - Load/Unload
			
/*			if (  Account.GCC.equalsIgnoreCase( account.getAccountId().getApplicationId() ) )
			{
				if( Account.SUB_PROD_CODE_WWW.equalsIgnoreCase(account.getAccountId().getSubProductCode())){
					mbAccount.setIsGCCMasterCard(true);
				}
				
			}  */

			if (Account.GWC.equalsIgnoreCase(account.getAccountId().getApplicationId()))
			{
				//mbAccount.setIsGCCMasterCard(true);
				mbAccountList.add(mbAccount);
				continue;
			}
			else if (Account.GCC.equalsIgnoreCase(account.getAccountId().getApplicationId()))
			{
				mbAccountList.add(mbAccount);
				
				GCCAccount revaccount = (GCCAccount)account;
				Logger.info("GCC Account Transition status "+revaccount.getStatus()+" for gcis "+customer.getGcis(), this.getClass());
				if(customer.getPreference().isDisplayELeadsSplashPage() && IBankParams.isSwitchOn( IBankParams.GCC_TRANSITION_SWITCH) &&  !String.valueOf(GCCAccountStatusEnum.TRANSITIONED.getGCCAccountStatus()).equalsIgnoreCase(revaccount.getStatus()) ) {
					mbAccount.setTransitionFlag(GCCAccount.SHOW_GCC_TRANSITION_BANNER);//show the banner as transition not done
				}else {
					mbAccount.setTransitionFlag(GCCAccount.HIDE_GCC_TRANSITION_BANNER);//hide the banner as transition is done
				}
				
				continue;
			}
			else if ("DRA".equalsIgnoreCase(account.getAccountId().getEhubProductCode()))
			{
				linkedIndexes = getNOMLinkedAccountIndex(account, accountList);
				mbAccount.setDirectSaver(true);
			}
			else  if (account.getAccountId().isSenseSavingAccount())
			{
				linkedIndexes =  getLinkedSenseEveryDayAccountIndex(account, accountList);
				mbAccount.setSenseSavings(true);
				
			}
			else if (account.getAccountId().isSenseEverydayAccount())
			{
				linkedIndexes = getLinkedSennseSavingAccountIndex(account, accountList);
				mbAccount.setSenseEveryday(true);
				
			}
			else if ("NOM".equalsIgnoreCase(account.getAccountId().getApplicationId()))
			{
				linkedIndexes = getLinkedAccoutsIndexesForExtNOM(account, accountList);
				mbAccount.setNOMAccount(true);
			}
			
			mbAccount.setIsHISAAccount(MBAppHelper.isHISAAccount(account.getAccountId().getSubProductCode()));
			
			mbAccount.setLinkedIndexes(linkedIndexes);
			
			if( account.isAccountTermDeposit() )
			{
				mbAccount = handleTermDepositFlags(account, mbAccount);
			}

			if( account.isAccountCreditCard() )
			{
				mbAccount = handleCRAActivationStatus(account, mbAccount );
			}
			
			
			if ( customer.isAllowMakeInitialFunding() && account.isUnfunded() )
			{
				if ( ! Account.BT.equalsIgnoreCase( account.getAccountId().getApplicationId() ) )
					mbAccount.setMakeInitialFunding(true);
			}
			if ("CRA".equalsIgnoreCase(account.getAccountId().getApplicationId()))
			{
					if ( "Y".equalsIgnoreCase(account.getCreditCardAdditionalInfo().getProductTransferStatus() ) )
					{
						mbAccount.setCraInProductTransfer(true);
						mbAccount.setReplaceAcctNum(account.getCreditCardAdditionalInfo().getReplacementAcctNum());
					}
					mbAccount.setCcClosureTile(populateCCClosureTile(account));
					mbAccount.setShowCashAdvChk(isSubProdCodeEligible(cashAdvWarEligibleCodesMsgs, account));
			}

			if(isAutoApplyApplicable && Account.DDA.equalsIgnoreCase(  account.getAccountId().getApplicationId())){
				if(account.getAccountId().getAccountNumber().length()<13){
				
					no_paddding_zeros = 13-account.getAccountId().getAccountNumber().length();
					accountNumber = StringMethods.pad(no_paddding_zeros,'0')+( account.getAccountId().getAccountNumber());
					
				}
				else{
					accountNumber = account.getAccountId().getAccountNumber();
					//accountNumber2 = StringMethods.removeLeadingZero(accountNumber2.substring(accountNumber2.length()-10,accountNumber2.length()) );
				
				}
				if(accountNumberFromMessage.equals(accountNumber)){
					
					Logger.info("populateAccountList::: GCIS==="+customer.getGcis() +",accountNumber from Message[Appfield1]==="+autoApplyRetentionInfo.getAccountNumber()+",account Number from dashboard==="+ account.getAccountId().getAccountNumber(), this.getClass());
					mbAccount.setAutoApplyRetentionInd(true);
					mbAccount.setCustMsgId(custMsgId);
					
				}
			}
			//19E4 - CashAdvance Fee warning for Transfer from Gold cash mangement and investment savings account
			if(Account.DDA.equalsIgnoreCase(  account.getAccountId().getApplicationId())){
				mbAccount.setShowBcopGoldInvestMsg(isSubProdCodeEligible(bcopEligibleCodesMsgs, account));
				mbAccount.setGoldCashInvestmentFees(IBankParams.getGoldCashInvestmentFees());
			}
			
			if(IBankParams.isHomeLoanDigiSwitchON() &&  Account.LIS.equalsIgnoreCase(  account.getAccountId().getApplicationId())){
				if(map!=null){
					FixedHomeLoanOffer offer = map.get(account.getAccountId().getAccountNumber());
					if(offer!=null){
						mbAccount.setHomeLoanDigiMaturityDate(homeLoanDateFormat.format(offer.getFixedRateMaturityDate()));
						mbAccount.setHomeLoanDigiOfferFlag(offer.getOfferStatus());
	  					if(offer.getFixedHomeLoanCustomerStatus() == null || "N".equals(offer.getFixedHomeLoanCustomerStatus())){
	  						MessageSearch msgSrc = fixedHomeLoanService.sendTemplate3Msg(customer.getGcis(), offer);
	  						//This is to update the count of unread messages.
	  						if (msgSrc != null){
	  							mbAccount.setNewHomeLoanDigiOffer(true);
	  						}else{
	  							mbAccount.setNewHomeLoanDigiOffer(false);
	  						}
	  					}
					}
				}
			}
			
			if(AccountFilter.isMadisonLCMSwitchOn(customer.getGcis())) {
				
				if ("CRA".equalsIgnoreCase(account.getAccountId().getApplicationId())){
					mbAccount.setIsSBlockCard(populateSBlockCard(account));
					mbAccount.setIsReplacementCard(populateReplacementCard(account));
					mbAccount.setIsTempReplacementCard(populateTempReplacementCard(account));
					
					CreditCardAccount crAcc =(CreditCardAccount) account;
						
				    if("S".equalsIgnoreCase(crAcc.getBlockCode())) {
							mbAccount.setBalance(null);
							mbAccount.setAvailBalance(null);
					}
					if(mbAccountControl!=null && "J".equalsIgnoreCase(crAcc.getBlockCode()) && !("Q".equalsIgnoreCase(crAcc.getAccountId().getAcctStatus()))) {
							mbAccountControl.setAllowViewEstmt(true);
					}
					
				}	
			}
	
			//2oE4 - Smart Plans for dashboard display
			if(ibankRefreshParams.isSmartPlanSwitchON(IBankParams.DEFAULT_ORIGIN, customer.getGcis()) && spDashboardDetails != null && spDashboardDetails.get(account.getAccountId().getAccountNumber()) != null) {
				SmartPlanDashboardInfo spDetails = spDashboardDetails.get(account.getAccountId().getAccountNumber());
				mbAccount.setSmartPlanActivePlans(spDetails.getActivePlanCount());
				mbAccount.setSmartPlanTotalRemAmt(spDetails.getTotalRemAmt().negate());
			}
			mbAccountList.add(mbAccount);
			
		}
		
		PayIdPaymentSwitchParams payIdPaymentSwitchParams = ibankRefreshParams.getPayIdPaymentSwitchParams(IBankParams.DEFAULT_ORIGIN, customer.getGcis());
		if(payIdPaymentSwitchParams.isShowPayToPayIdIcon()) {
			//19E1: Added changes for FROM ACCOUNT NPP ELIGIBILITY
			setFromAccountNPPEligibility(accountList, mbAccountList);
		}
		
		}
		return mbAccountList;
	}

	public  AccountKeyInfoResp getMBAccountKeyInfo(Account account, boolean nominated)
	{
		AccountKeyInfoResp accountKeyInfo = new AccountKeyInfoResp();
				
//		if (Account.GCC.equalsIgnoreCase( account.getAccountId().getApplicationId() ) && Account.SUB_PROD_CODE_WWW.equalsIgnoreCase(account.getAccountId().getSubProductCode()))

		if (Account.GWC.equalsIgnoreCase( account.getAccountId().getApplicationId() ))
			accountKeyInfo.setAccountNum(account.getAccountId().getAccountNumber());
		
		else if ( !  Account.GCC.equalsIgnoreCase( account.getAccountId().getApplicationId() ) )
			accountKeyInfo.setAccountNum(account.getAccountId().getAccountNumber());
		
		accountKeyInfo.setAccountType(account.getAccountId().getApplicationId());
		if (account.getAccountId().getBsb() != null && account.getAccountId().getBsb().length() > 3)
		{
			accountKeyInfo.setBsb(Integer.parseInt(account.getAccountId().getBsb()));
		}

		if (!nominated)
		{
			accountKeyInfo.setAccountIndex(account.getIndex());
			accountKeyInfo.setAccountName(account.getAlias());
		}

		return accountKeyInfo;
	}

	public  AccountControlResp getMBAccountControl(Account account,  List<Account> toAccts)
	{
		AccountControlResp mbAccountControl = new AccountControlResp();
		if (  Account.GCC.equalsIgnoreCase( account.getAccountId().getApplicationId() ) )
		{
			mbAccountControl.setAllowDeposit(account.getAllowFlags().contains(AccountFlags.ALLOW_DEPOSIT));
		}
		else if ( ! Account.BT.equalsIgnoreCase( account.getAccountId().getApplicationId() ) )
		{
			mbAccountControl.setAllowBpay(account.getAllowFlags().contains(AccountFlags.ALLOW_BPAY_BILL_PAYMENT));	
			// mbAccountControl.setAllowCashAdv(account.isa)
			mbAccountControl.setAllowDeposit(account.getAllowFlags().contains(AccountFlags.ALLOW_DEPOSIT));
			mbAccountControl.setAllowSMS(account.getAllowFlags().contains(AccountFlags.ALLOW_SMS));
			mbAccountControl.setAllowTP(account.getAllowFlags().contains(AccountFlags.ALLOW_THIRDPARTY));
			mbAccountControl.setAllowTT(account.getAllowFlags().contains(AccountFlags.ALLOW_TT_ORDER));
			// mbAccountControl.setAllowViewDetails(
			// account.getAllowFlags().contains(AccountFlags.ALLOW_) );
			mbAccountControl.setAllowViewEstmt(account.getAllowFlags().contains(AccountFlags.ALLOW_VIEW_STATEMENT));
			mbAccountControl.setAllowWithdrawal(account.getAllowFlags().contains(AccountFlags.ALLOW_WITHDRAWAL));
			mbAccountControl.setAllowTDAFunding(account.getAllowFlags().contains(AccountFlags.ALLOW_OPEN_ACCT_FUND_FROM));
			mbAccountControl.setAllowPayToCreditCard(account.getAllowFlags().contains(AccountFlags.ALLOW_CREDIT_CARD_TRANSFER_FROM));
			if(ibankRefreshParams.isAutoPaySwitchOn() && Account.CRA.equals(account.getAccountId().getApplicationId())){
				try {
					mbAccountControl.setAllowAutoPay(cardAutoPayService.isCardAutoPayEligible(account));
				} catch (BusinessException e) {
					Logger.error("getMBAccountControl: Error while checking eligibility for Card Auto Pay"+e, LogonHelper.class);
					mbAccountControl.setAllowAutoPay(false);
				}
			}else {
				Logger.info("getMBAccountControl: AUTO_PAY_SWITCH is OFF or Not a credit card account", LogonHelper.class);
				mbAccountControl.setAllowAutoPay(false);
			}
			
		}
		
		//20E1 - GCC - LOAD/UNLOAD
		//SBGEXP-7560 : GCC Payments - MB - Load/Unload
		if (  Account.GWC.equalsIgnoreCase( account.getAccountId().getApplicationId() ) )
		{
//			if( Account.SUB_PROD_CODE_WWW.equalsIgnoreCase(account.getAccountId().getSubProductCode())){
				mbAccountControl.setAllowDeposit(account.getAllowFlags().contains(AccountFlags.ALLOW_DEPOSIT));
				mbAccountControl.setAllowWithdrawal(account.getAllowFlags().contains(AccountFlags.ALLOW_WITHDRAWAL));
				
				//--using default origin as discussed
				if(globalWalletService.isEstatementsAvailableForActiveGlobalWalletAccount(IBankParams.DEFAULT_ORIGIN)) {
					mbAccountControl.setAllowViewEstmt(true);
				}
	//		}
			
		}
		return mbAccountControl;

	}
	public static final String SPRING_MOBILE_SERVICE_BEAN  ="mobileBankService";
	public  PaymentsLog getLastTransactionDetails(User user)
	{
		try
		{

			MobileBankService mobileBankService = (MobileBankService) ServiceHelper.getBean(SPRING_MOBILE_SERVICE_BEAN);
			
			PaymentsLog paylog = mobileBankService.getLastTransactionDetails(user);
			return paylog;
		} catch (Exception e)
		{
			Logger.info("getLastTransactionDetails: No Last Transaction for Customer : " + user.getGCISNumber(), e, LogonHelper.class);
			return null;
		}
	}

	public static final String XREFTYPE_ORIGIN = "ALL";
	public static final String XREFTYPE_CATEGORY = "XrefType";
	private static final String CHAT = "chat/";

	public  String getLastTransactionType(PaymentsLog payLog)
	{

		String lastTransType = null;
		if (payLog != null)
		{
			CodesVO codesVoObj = IBankParams.getCodesData(XREFTYPE_ORIGIN, XREFTYPE_CATEGORY, payLog.getXrefType());
			lastTransType = codesVoObj.getMessage();
		} else
			lastTransType = "";
		return lastTransType;
	}

	
	public  SecureCodeInfoResp populateSecureCodeInfo(Customer customer )
	{
		SecureCodeInfoResp secureCodeInfo = null;
		if(customer.getIBankSecureDetails() != null){
			secureCodeInfo = new SecureCodeInfoResp();
			String delPref = customer.getIBankSecureDetails().getDeliveryPref();
			secureCodeInfo.setDeliveryPref(delPref);
			String phonePref = customer.getIBankSecureDetails().getPhonePref();
			secureCodeInfo.setPhonePref(phonePref);
			secureCodeInfo.setExempt(isCustomerSecCodeExempted(customer));
		}
		return secureCodeInfo;
	}

	
	private  FavTranResp populateMostFavTranResp(Customer customer ) 
	{
		try
		{
			MobileBankService mobileBankService = (MobileBankService) ServiceHelper.getBean(SPRING_MOBILE_SERVICE_BEAN);
			FavTran favTran = mobileBankService.getMostFavouriteTransaction(customer.getGcis());
			if ( favTran != null )
			{
				FavTranResp favTranResp = new FavTranResp();
				favTranResp.setAliasName(favTran.getAliasName());
				favTranResp.setAmount(String.valueOf(favTran.getAmount()));
				favTranResp.setFavouriteFlag(favTran.isFavouriteFlag());
				favTranResp.setTranIndex(favTran.getId().intValue());
				return favTranResp;
			}
			return null;
			
		}
		catch ( Exception  e)
		{
			Logger.info("Unable to get most fav tran .. " , e, this.getClass());
			return null;
		}

	}

	
	
	public  String isCustomerSecCodeExempted(Customer customer)  
	{
		try
		{
			if (  IBankSecureService.isGlobalByPass() ||  IBankSecureService.isCustomerExempt(customer.getIBankSecureDetails()) )
			{
				return "Y"; 
			}
			else
			{
				return "N";
			}
		}
		catch (Exception e)
		{
			return "N";
		}
			 

	}

	
	private CustomerControlResp populateCustomerControlResp(String origin, MobileSession mobileSession, Cookie cookie, User  user, Customer customer, boolean firstTimeCookie, boolean splashPageReqd ) throws BusinessException
	{
		//String origin1 = mobileSession.getOrigin();
		CustomerControlResp customerControl = new CustomerControlResp();
		
		if( (cookie!=null && !(StringMethods.isEmptyString(cookie.getValue()))) && !(mobileSession.getGDWOrigin() != null && mobileSession.getGDWOrigin().startsWith(ORIGIN_TABLET_PREFIX))){
		    //coming from native app
			customerControl.setAllowExpenseSplitter(true);
		}
		else{
		    //coming from msite OR browser
			customerControl.setAllowExpenseSplitter(false);
		}		
		// Checking to show direct debits
		boolean showDirectDebits=recurringDirectDebits.showDirectDebitsLink(origin, customer);
		if(showDirectDebits){
			customerControl.setShowDirectDebits(true);
		}else{
			customerControl.setShowDirectDebits(false);
		}
		
		// Checking to show donations
		if( (cookie!=null && !(StringMethods.isEmptyString(cookie.getValue())))){
		    //coming from native app
			String originCode = mobileSession.getGDWOrigin() != null ? mobileSession.getGDWOrigin() : origin;
			customerControl.setShowDonations(donationsService.showDonationsLink(originCode,customer));
		}
		else{
		    //coming from msite OR browser
			customerControl.setShowDonations(false);
		}	
				
		customerControl.setFirstTimeHelp(true);
		customerControl.setAllowInitialFunding(customer.isAllowMakeInitialFunding());
		customerControl.setFirstTimeHelp( ! firstTimeCookie);
		customerControl.setSplashPage(splashPageReqd);
		if ( IBankParams.YES.equalsIgnoreCase((String) user.getAttribute(IBankParams.USEROBJ_TT_ACCESS)) )
		{
			customerControl.setTTReg(true);	
		}
		else
		{
			customerControl.setTTReg(false);
		}
		
		if(customer.getCustomerTypes().contains(CustomerTypes.TYPE_GHS)){
			if(CustomerVOAssembler.PERSONAL_CUSTOMER.equalsIgnoreCase(customer.getCustTypeInd())){
				Logger.debug("getAllowGetCash in personal customer : " , LogonHelper.class);
				customerControl.setAllowAccountOpening( true );				
				customerControl.setAllowGetCash(true);
				customerControl.setAllowCardActivation(true);
				customerControl.setAllowTFNCapture(true);
//				customerControl.setAllowSMS(true);
				//18E1: Added for CRS Ongoing Maintenance.
				Logger.info("allowCRSOngoing check: Origin is : "+origin, LogonHelper.class);
				customerControl.setAllowCRSOngoing(true);
				customerControl.setAllowECorrespondence(true);
			}
			else if(IBankParams.isSwitchOn(IBankParams.CRS_BUSINESS_SWITCH)){
				Logger.info("CRS Business switch on : Open for Business Customers:" , LogonHelper.class);
				customerControl.setAllowCRSOngoing(true);
			}
			else{
				customerControl.setAllowAccountOpening( false );
				customerControl.setAllowGetCash(false);
				customerControl.setAllowCardActivation(false);
//				customerControl.setAllowSMS(true);
			}
		}else if(customer.getCustomerTypes().contains(CustomerTypes.TYPE_CHS)){
			customerControl.setAllowAccountOpening( false );
			customerControl.setAllowGetCash(false);
			customerControl.setAllowCardActivation(false);
			
			if(CustomerVOAssembler.PERSONAL_CUSTOMER.equalsIgnoreCase(customer.getCustTypeInd()) || (IBankParams.isSwitchOn(IBankParams.CRS_BUSINESS_SWITCH))){
				Logger.info("CRS Business switch on OR personal customer" , LogonHelper.class);
				customerControl.setAllowCRSOngoing(true);
			}
			
		}else if(customer.getCustomerTypes().contains(CustomerTypes.TYPE_CHS_GHS)){
			if(CustomerTypes.TYPE_GHS.equalsIgnoreCase(customer.getPrimaryProfile()) || CustomerVOAssembler.PERSONAL_CUSTOMER.equalsIgnoreCase(customer.getCustTypeInd())){
				Logger.debug("getAllowGetCash in combined customer : " , LogonHelper.class);
				customerControl.setAllowAccountOpening( true );
				customerControl.setAllowGetCash(true);
				customerControl.setAllowCardActivation(true);
//				customerControl.setAllowSMS(true);
			}
			else{
				customerControl.setAllowAccountOpening( false );
				customerControl.setAllowGetCash(false);
				customerControl.setAllowCardActivation(false);
//				customerControl.setAllowSMS(false);
			}
			
			//Production fix Business customer are not allowed for account opening : 
			if(CustomerTypes.TYPE_GHS.equalsIgnoreCase(customer.getPrimaryProfile()) && !CustomerVOAssembler.PERSONAL_CUSTOMER.equalsIgnoreCase(customer.getCustTypeInd())){
				customerControl.setAllowAccountOpening( false );// same flag is being used for My Invitation for sales
			}
			
			//18E1: Added for CRS Ongoing Maintenance.
			if(CustomerVOAssembler.PERSONAL_CUSTOMER.equalsIgnoreCase(customer.getCustTypeInd()) || (IBankParams.isSwitchOn(IBankParams.CRS_BUSINESS_SWITCH))){
				Logger.info("CRS Business switch on OR personal customer" , LogonHelper.class);

				customerControl.setAllowCRSOngoing(true);
			}
			//18E1: Added for ECorrespondence.
			if(CustomerTypes.TYPE_GHS.equalsIgnoreCase(customer.getPrimaryProfile()) && CustomerVOAssembler.PERSONAL_CUSTOMER.equalsIgnoreCase(customer.getCustTypeInd())){
				customerControl.setAllowECorrespondence(true);
			}
			
		}
		
		if (customer.getCustomerTypes().contains(CustomerTypes.TYPE_GHS))
		{
			customerControl.setAllowSMS(true);
			customerControl.setAllowChangeCardPIN(true);
			customerControl.setAllowBusinessAccOpening(true);
		} else if (customer.getCustomerTypes().contains(CustomerTypes.TYPE_CHS_GHS))
		{
			if (CustomerTypes.TYPE_GHS.equalsIgnoreCase(customer.getPrimaryProfile()))
			{
				customerControl.setAllowSMS(true);
				customerControl.setAllowChangeCardPIN(true);
				customerControl.setAllowBusinessAccOpening(true);
			} else
			{
				customerControl.setAllowSMS(false);
				customerControl.setAllowChangeCardPIN(true);
				customerControl.setAllowBusinessAccOpening(false);
			}
		} else
		{
			customerControl.setAllowSMS(false);
			customerControl.setAllowChangeCardPIN(false);
			customerControl.setAllowBusinessAccOpening(false);
		}
		
		if(IBankParams.isSwitchOn(IBankParams.ONLINE_SECURITY_CHECK_SWITCH)) {
			customerControl.setShowOnlineSecurityCheck(true);
		}else {
			customerControl.setShowOnlineSecurityCheck(false);
		}
		//To hide the Credit Limit decrease functionality if there is no eligible credit cards.
		if(IBankParams.isCreditLimitDecreaseSwitchON()){
			if(hasEligibleAcctsForCreditLimitDecrease(customer.getAccounts()))
			{
				customerControl.setAllowCreditLimitDec(true);
			}
		}
		
		customerControl.setAllowOffer(customer.getPreference().isDisplayELeadsSplashPage());		

		customerControl.setEvStatus(String.valueOf(customer.getEvStatus()));
		

		//17E4 : Native Redesign
		if(mobileSession != null && mobileSession.getCustNameRequested() != null ){
			Logger.debug("/LogonHelper :: populateCustomerControlResp():: CUST_NAME_populateCustomerControlResp ::"+ mobileSession.getCustNameRequested(), this.getClass());	
			if(isCookieContainsCustInfo(cookie)== 0 && mobileSession.getCustNameRequested() == true){
				
					Logger.debug("/LogonHelper :: populateCustomerControlResp():: SEND NATIVE FIRST NAME ::"+ customerControl.isSendNativeFirstName(), this.getClass());
				if(null!= customer){
					Logger.debug("/LogonHelper :: populateCustomerControlResp():: FIRST NAME ::"+ customer.getFirstName()+":: LAST NAME :: "+customer.getLastName(), this.getClass());
				}
				
				if(null != customer && !StringMethods.isEmptyString(customer.getFirstName())){
					 customerControl.setSendNativeFirstName(true);
					 String nameToSendInUI = StringUtil.toCamelCaseString(customer.getFirstName().toLowerCase());
					Logger.debug("/LogonHelper :: populateCustomerControlResp(): First Name Disp" + nameToSendInUI, LogonHelper.class);
					customerControl.setFirstNameDisp(nameToSendInUI);
				}
			}
		}
		Logger.debug("getAllowGetCash in term of eligibility : " + customerControl.isAllowGetCash(), LogonHelper.class);
		Logger.info("allowCRSOngoing Flag:" + "GCIS Number: " + customer.getGcis() + customerControl.isAllowCRSOngoing(), LogonHelper.class);

		return customerControl;
	}
	

	public AppParams populateAppParams(HttpServletRequest request, Customer customer)
	{
		AppParams appParams = new AppParams();
		AppStoreURL appStore = new AppStoreURL();
		String origin = null;
		if ( isDemo() )
		{
			origin = (String) request.getAttribute(LogonHelper.ORIGIN);
		}
		else
		{
			origin = resolveOrigin(request);
		}
		
		if ( origin == null )
		{
			origin = "MSTG";
		}
		appParams.setOrigin(origin);
		appParams.setSystemDate(new Date());
		OriginsVO myOriginVO  = IBankParams.getOrigin(origin);
		if (  myOriginVO != null  )
		{
			appParams.setOriginHelpDeskPhone(myOriginVO.getPhone() );
			appParams.setOriginIntPhone(myOriginVO.getIntPhone());
			appParams.setOriginName(myOriginVO.getName());

			OriginsVO baseOrigin  = IBankParams.getOrigin(myOriginVO.getBankName());
			
			appParams.setOriginPhone(baseOrigin.getPhone());
			appParams.setOriginTradingHours( myOriginVO.getTradingHours() );
			appParams.setOriginURL(myOriginVO.getUrl());
			
			
			if (!StringMethods.isEmptyString(getAndroidAmtField()) && isAndroid(request)) {
				
				if(isAndroidPixel(request))
				{
					Logger.debug("Inside Google Pixel :", LogonHelper.class);
					appParams.setKeyboardAmountType("number");
				}
				else
				{
					appParams.setKeyboardAmountType(getAndroidAmtField());
				}	
			}
			else
			{
				appParams.setKeyboardAmountType("number");
			}
		}
		
		// Setting App Store URLs for Android and IOS device.
		CodesVO androidVO = IBankParams.getCodesData(IBankParams.getBaseOriginCode(origin), IBankParams.APP_STORE_URL, "Android");
		if(androidVO == null) {
			appStore.setAndroidUrl("");
		}else {
			appStore.setAndroidUrl(androidVO.getMessage().trim());
		}
		
		CodesVO iosVO = IBankParams.getCodesData(IBankParams.getBaseOriginCode(origin), IBankParams.APP_STORE_URL, "IOS");
		if(iosVO == null) {
			appStore.setIosUrl("");
		}else {
			appStore.setIosUrl(iosVO.getMessage().trim());
		}
		appParams.setAppStoreUrl(appStore);
		
	//	String numKeyType =  getNumKeyBoardType(request);
		
		appParams.setKeyboardNumPattern( getNumKeyBoardPattern(request) );
		appParams.setKeyboardNumType(getNumKeyBoardType(request));
		appParams.setCreditLimitIncreaseSwitch((IBankParams.isCreditLimitIncreaseSwitchOn()) ? "ON" : "OFF");

		appParams.setAdobeTaggingSwitch((IBankParams.isAdobeTaggingSwitchSwitchOn(origin)) ? "ON" : "OFF");

		CodesVO codesVO = IBankParams.getCodesData(origin,	IBankParams.CONFIGURATION_PROPERTIES, "GCCSwitch");
		if ( codesVO == null  )
			appParams.setGccSwitch("ON");
		else
			appParams.setGccSwitch((codesVO.getMessage().trim()).toUpperCase()) ;
		//19E4 Tech Debt Start:Switch Removal
		/*CodesVO greenBirdCodesVO = IBankParams.getCodesData(origin,	IBankParams.CONFIGURATION_PROPERTIES, "GreenBirdSwitch");
		if ( greenBirdCodesVO == null  )
			appParams.setGreenBirdSwitch("ON");
		else
			appParams.setGreenBirdSwitch((greenBirdCodesVO.getMessage().trim()).toUpperCase()) ;*/
		//19E4 Tech Debt End:Switch Removal
		//BT - 16E1
		CodesVO serviceBTVO = IBankParams.getCodesData(origin,	IBankParams.CONFIGURATION_PROPERTIES, "BTSSwitch");
		CodesVO originationBTVO = IBankParams.getCodesData(origin,	IBankParams.CONFIGURATION_PROPERTIES, "BTOSwitch");
		if ( serviceBTVO == null  )
			appParams.setBtsSwitch("ON");
		else
			appParams.setBtsSwitch((serviceBTVO.getMessage().trim()).toUpperCase());
		
		if ( originationBTVO == null  )
			appParams.setBtoSwitch("ON");
		else
			appParams.setBtoSwitch((originationBTVO.getMessage().trim()).toUpperCase());
			
		int isNativeApp = loadCordova(request);
		if((isNativeApp == 1 || isNativeApp == 2))//update switch only if its native app
		{
			// if OFF from database explicitly then OFF even if native app says true
			appParams.setBtsSwitch(
					(allowsPostWhenNative(request) == 0 && "ON".equalsIgnoreCase(appParams.getBtsSwitch())) ? 
							"ON": "OFF"); 
			appParams.setBtoSwitch(
					(allowsPostWhenNative(request) == 0 && "ON".equalsIgnoreCase(appParams.getBtoSwitch())) ? 
							"ON": "OFF");
		}
		
		//appParams.setBtoSwitch("OFF");
		//BT - 16E1	
		
			
		//Onboarding Tile switch 
		/*
		* TODO Review changes for fast funding cleanup
		//boolean isMogoAvailable = isMogoSDKInstalled(request);//To support Onboarding tile for Mogo SDK installed devices only.
		 * boolean showFastFudning =IBankParams.isFastFundingSwitchON(origin);
		if(showFastFudning && isMogoAvailable){
			Logger.debug("Switch for showing Get Active on your account tile in mobile banking ",  this.getClass());
			appParams.setFastFundingSwitch("ON");
		}
		else{
			appParams.setFastFundingSwitch("OFF");
		}*/
		//TAp n Pay icon for eligible devices
		/*if(IBankParams.isTapAndPayDecomissionSwitch()){
			appParams.setTapAndPayFlag("OFF"); 
		}
		else{*/
			appParams.setTapAndPayFlag((isTapAndPayEligibile(request) == 0) ?	"ON": "OFF");
		//}
		 
		boolean medbFeatureSwitch = IBankParams.isBrandSwitchOn(origin, IBankParams.MEDB_FEATURE_SWITCH);
		
		if(medbFeatureSwitch) {
             appParams.setActiveAccountSwitch(IBankParams.ON);
         }else {
                 boolean isMogoAvailable = isMogoSDKInstalled(request);
                                             
                 boolean isEligible = isActiveAccountPresent(customer.getAccounts());
                                             
                 if(isMogoAvailable && isEligible){
                      appParams.setActiveAccountSwitch(IBankParams.ON);
                 }
                 else{
                      appParams.setActiveAccountSwitch(IBankParams.OFF);
                 }
        } 
		
		boolean fixBottomMenuSwitch = IBankParams.isBrandSwitchOn(origin, IBankParams.CI_MENU_ICON_SWITCH);
		if(fixBottomMenuSwitch) {
			appParams.setFixBottomMenuSwitch(IBankParams.ON);
		}else {
			appParams.setFixBottomMenuSwitch(IBankParams.OFF);
		}		
		String madisonSwitch = IBankParams.getBrandSwitchVal(origin, IBankParams.MADISON_SWITCH) ;
		if(madisonSwitch.equalsIgnoreCase("1")) {			
			boolean isMadisonEligible=checkMadisonServiceMenuEligibility(request);
			if(isMadisonEligible) {
				appParams.setShowMadison(IBankParams.ON);
			}else {
				appParams.setShowMadison(IBankParams.OFF);
			}
		}else if(madisonSwitch.equalsIgnoreCase("2")) {
			boolean isPilot=ibankRefreshParams.isPilotCustomer(customer.getGcis(),MADISON_PILOT);
			if(isPilot) {
				boolean isMadisonEligible=checkMadisonServiceMenuEligibility(request);
				if(isMadisonEligible) {
					appParams.setShowMadison(IBankParams.ON);
				}else {
					appParams.setShowMadison(IBankParams.OFF);
				}
			}else {
				appParams.setShowMadison(IBankParams.OFF);
			}
		}else {
			appParams.setShowMadison(IBankParams.OFF);
		}
		CodesVO cometCodesVO = IBankParams.getCodesData(origin,	IBankParams.CONFIGURATION_PROPERTIES, "CometSwitch");
		if ( cometCodesVO == null  )
			appParams.setInsuranceSwitch("ON");
		else
			appParams.setInsuranceSwitch((cometCodesVO.getMessage().trim()).toUpperCase()) ;
		
		appParams.setConnectSwitch(isConnectSwitchOn(request));
		
		if(isOnboardingPresentInCookie(request) && IBankParams.isOnboardingSwitchON()){
			appParams.setOnboardingSwitch(IBankParams.ON);
		}else{
			appParams.setOnboardingSwitch(IBankParams.OFF);
		}
		
		appParams.setNotificationUptake(IBankParams.ON);
		
		if (isCordovaSupported( request )){
			appParams.setCordovaReplInd(1);
		}else{
			appParams.setCordovaReplInd( 0 );
		}

		if(IBankParams.isMyInvitationSwitchON(origin))
			appParams.setSalesOfferSwitch(IBankParams.ON);
		else
			appParams.setSalesOfferSwitch(IBankParams.OFF);
		
		
		/*CodesVO payToMobileCodesVO = IBankParams.getCodesData(origin,	IBankParams.CONFIGURATION_PROPERTIES, "payToMobileSwitch");
		if ( payToMobileCodesVO == null  )
			appParams.setPayToMobileSwitch("ON");
		else
			appParams.setPayToMobileSwitch((payToMobileCodesVO.getMessage().trim()).toUpperCase()) ;*/
		
		//if PayId registration switch is ALLON or PILOTON, turn Off paytoMobile
		if(IBankParams.isPayToMobileSwitchOn(origin)){
			appParams.setPayToMobileSwitch(IBankParams.ON);
		}else{
			appParams.setPayToMobileSwitch(IBankParams.OFF);
		}
		
		if(ibankRefreshParams.getPayIdRegistrationSwitchParams(origin, customer.getGcis()).isShowPayToMobileAccount()
				&& IBankParams.isPayToMobileSwitchOn(origin)){
			appParams.setPayToMobileServiceAndHelpEntry(IBankParams.ON);
		}else{
			appParams.setPayToMobileServiceAndHelpEntry(IBankParams.OFF);
		}
		
		if (isCardlessTokenSupported( request )){
			appParams.setCardlessTokenInd(1);
		}else{
			appParams.setCardlessTokenInd(0);
		}
		
		boolean onlinePinSecuritySwitch =IBankParams.isOnlinePinSecuritySwitchON(origin);
		if(onlinePinSecuritySwitch){
			appParams.setOnlinePINSecuritySwitch(IBankParams.ON);
		}
		else {
			appParams.setOnlinePINSecuritySwitch(IBankParams.OFF);
		}
		
		boolean onlinePinActivationSwitch =IBankParams.isOnlinePinActivationSwitchON(origin);
		if(onlinePinActivationSwitch){
			appParams.setOnlinePINActivationSwitch(IBankParams.ON);
		}
		else {
			appParams.setOnlinePINActivationSwitch(IBankParams.OFF);
		}

		if(IBankParams.isExpenseSplitterSwitchON(origin)){
			appParams.setExpenseSplitterSwitch(IBankParams.ON);
		}
		else{
			appParams.setExpenseSplitterSwitch(IBankParams.OFF);
		}

		if(IBankParams.isInsuranceSSOSwitchON()){
			appParams.setInsuranceSSOSwitch(IBankParams.ON);
		}
		else{
			appParams.setInsuranceSSOSwitch(IBankParams.OFF);
		}

		if(IBankParams.isClosedAccountSwitchOn(origin)){
			appParams.setClosedAcctStmtSwitch(IBankParams.ON);
		}else{
			appParams.setClosedAcctStmtSwitch(IBankParams.OFF);
		}
		
		if(IBankParams.isManageStatementsSwitchOn(origin)){
			appParams.setManageStmtSwitch(IBankParams.ON);
		}else{
			appParams.setManageStmtSwitch(IBankParams.OFF);
		}
		
		
		if(IBankParams.isMotorInsuranceSSOSwitchON()){
			appParams.setMotorInsuranceSSOSwitch(IBankParams.ON);
		}
		else{
			appParams.setMotorInsuranceSSOSwitch(IBankParams.OFF);
		}
		
		if(IBankParams.isCreditLimitDecreaseSwitchON()){
			appParams.setCreditLimitDecreaseSwitch(IBankParams.ON);
		}
		else{
			appParams.setCreditLimitDecreaseSwitch(IBankParams.OFF);
		}
		
		if(IBankParams.isTravelRetrieveQuoteSwitchON()){
			appParams.setTravelRetrieveQuoteSwitch(IBankParams.ON);
		}else{
			appParams.setTravelRetrieveQuoteSwitch(IBankParams.OFF);
		}
		
		if(IBankParams.isOBTileSwitchON(origin)){
			appParams.setObTileSwitch(IBankParams.ON);
		}else{
			appParams.setObTileSwitch(IBankParams.OFF);
		}
		
		if(IBankParams.isSwitchOn(origin, IBankParams.LOCK_UNLOCK_SWITCH)){
			appParams.setLockUnlockSwitch(IBankParams.ON);
		}
		else{
			appParams.setLockUnlockSwitch(IBankParams.OFF);
		}
		
		if(IBankParams.isSwitchOn(origin, IBankParams.HOME_LOAN_SWITCH)){
			appParams.setHomeLoanSwitch(IBankParams.ON);
		}
		else{
			appParams.setHomeLoanSwitch(IBankParams.OFF);
		}
		
		//21E1 Card Auto Pay switch
		if(ibankRefreshParams.isAutoPaySwitchOn()) {
			appParams.setCardAutoPaySwitch(IBankParams.ON);
		}else {
			appParams.setCardAutoPaySwitch(IBankParams.OFF);
		}
		
		if(isShareBsbAccNumSupported(request)){
			appParams.setShareBsbAccNumSwitch(IBankParams.ON);
		}
		else{
			appParams.setShareBsbAccNumSwitch(IBankParams.OFF);
		}
		//20E3 UI Switch Cleanup
		/*if(isAndroidBackBtnSupported(request) && IBankParams.isSwitchOn(IBankParams.ANDROID_BACKBUTTON_SWITCH)){
			appParams.setAndroidBackButtonSwitch(IBankParams.ON);
		}
		else{
			appParams.setAndroidBackButtonSwitch(IBankParams.OFF);
		}*/	
		if(CommonBusinessUtil.isECorrespondenceSupported(request)){
			appParams.seteCorrespondenceSwitch(IBankParams.ON);
		}
		else{
			appParams.seteCorrespondenceSwitch(IBankParams.OFF);
		}
		
		if(IBankParams.isSwitchOn(IBankParams.SERVICE_BADGING_SWITCH)) {
			appParams.setServiceBadgingSwitch(IBankParams.ON);	
		}
		else {
			appParams.setServiceBadgingSwitch(IBankParams.OFF);
		}
		
		String madisonInAppProvSwitch = IBankParams.getBrandSwitchVal(origin, IBankParams.MADISON_IN_APP_PROVISIONING_SWITCH) ;
		boolean madisonCardActivationSwitch = IBankParams.isSwitchOn(IBankParams.MADISON_IN_APP_CARD_ACTIVATION_SWITCH);
		Logger.debug("In App Prov switch val>>"+madisonInAppProvSwitch, this.getClass());
		
		if(("1").equalsIgnoreCase(madisonInAppProvSwitch)) {	
			Logger.debug("In App Prov switch val inside 1>>", this.getClass());
			boolean isMadisonEligible=checkMadisonServiceMenuEligibility(request);
			if(isMadisonEligible) {
				appParams.setShowAddCardToWallet(IBankParams.ON);
				if(madisonCardActivationSwitch) {
					appParams.setShowActivateCardAddToWallet(IBankParams.ON);
				}
			}else {
				appParams.setShowAddCardToWallet(IBankParams.OFF);
				appParams.setShowActivateCardAddToWallet(IBankParams.OFF);
			}
		}else if(("2").equalsIgnoreCase(madisonInAppProvSwitch)) {
			boolean isPilot=ibankRefreshParams.isPilotCustomer(customer.getGcis(),MADISON_IN_APP_PROV_PILOT);
			if(isPilot) {
				boolean isMadisonEligible=checkMadisonServiceMenuEligibility(request);
				if(isMadisonEligible) {
					appParams.setShowAddCardToWallet(IBankParams.ON);
					if(madisonCardActivationSwitch) {
						appParams.setShowActivateCardAddToWallet(IBankParams.ON);
					}
				}else {
					appParams.setShowAddCardToWallet(IBankParams.OFF);
					appParams.setShowActivateCardAddToWallet(IBankParams.OFF);
				}
			}else {
				appParams.setShowAddCardToWallet(IBankParams.OFF);
				appParams.setShowActivateCardAddToWallet(IBankParams.OFF);
			}
		}else {
			appParams.setShowAddCardToWallet(IBankParams.OFF);
			appParams.setShowActivateCardAddToWallet(IBankParams.OFF);
		}
		/*if(IBankParams.isSwitchOn(IBankParams.MADISON_IN_APP_PROVISIONING_SWITCH)) {
			boolean isMadisonEligible=checkMadisonServiceMenuEligibility(request);
			if (isMadisonEligible) {
				appParams.setShowAddCardToWallet(IBankParams.ON);	
			}else {
				appParams.setShowAddCardToWallet(IBankParams.OFF);	
			}			
		}
		else {
			appParams.setShowAddCardToWallet(IBankParams.OFF);
		}*/
		
		if(IBankParams.isSwitchOn(IBankParams.LWC_GOOGLE_MAPS_SWITCH)) {
			appParams.setShowGoogleMapLWC(IBankParams.ON);
		}
		else {
			appParams.setShowGoogleMapLWC(IBankParams.OFF);
		}
		if(IBankParams.isSwitchOn(IBankParams.CI_BILLER_HISTORY_SWITCH)) {
			appParams.setShowBillerHistory(IBankParams.ON);
		}
		else {
			appParams.setShowBillerHistory(IBankParams.OFF);
		}

		if(customer != null) {
			if(ibankRefreshParams.isNPPInwardSwitchON(origin, customer.getGcis())) {
				appParams.setNppInwardSwitch(IBankParams.ON);
			} else {
				appParams.setNppInwardSwitch(IBankParams.OFF);
			}
			Logger.debug("appParams NppInwardSwitch : "+appParams.getNppInwardSwitch(), getClass());
		
			NPPParams nppParams = ibankRefreshParams.getNPPParams(origin, customer.getGcis());
			
			if(nppParams.isNppOutwardSwitchON()) {
				appParams.setNppOutwardSwitch(IBankParams.ON);
			}
			else{
				appParams.setNppOutwardSwitch(IBankParams.OFF);
			}
			Logger.debug("appParams NppOutwardSwitch : "+appParams.getNppOutwardSwitch(), getClass());
			
			if(nppParams.isDisplayOskoMessage()) {
				appParams.setShowInfoMsgForOsko(IBankParams.ON);
			}else{
				appParams.setShowInfoMsgForOsko(IBankParams.OFF);
			}
			Logger.debug("appParams ShowInfoMsgForOsko : "+appParams.getShowInfoMsgForOsko(), getClass());
		}
		//19E4 Tech Debt Start:Switch Removal
		/*if(IBankParams.isBusinessAccSoleDirSwitchON()){
			appParams.setBusinessAccSoleDirSwitch(IBankParams.ON);
		}
		else{
			appParams.setBusinessAccSoleDirSwitch(IBankParams.OFF);
		}*/
		//19E4 Tech Debt End:Switch Removal
		//19E4 Tech Debt Start:Switch Removal
		/*if(IBankParams.isUnlockActivateDeltaInfoSwitchON()){
			appParams.setUnlockActivateDeltaInfoSwitch(IBankParams.ON);
		}
		else{
			appParams.setUnlockActivateDeltaInfoSwitch(IBankParams.OFF);
		}*/
		//19E4 Tech Debt End:Switch Removal
		//19E4 Tech Debt Start:Switch Removal
		/*if(IBankParams.isRetentionSavingSavingsSwitchON()){
			appParams.setRetentionSavingSavingsSwitch(IBankParams.ON);
		}
		else{
			appParams.setRetentionSavingSavingsSwitch(IBankParams.OFF);
		}*/
		//19E4 Tech Debt End:Switch Removal
		//19E4 Tech Debt Start:Switch Removal
		/*if(IBankParams.isCCClosureSwitchON()){
			appParams.setCreditCardClosureSwitch(IBankParams.ON);
		}
		else{
			appParams.setCreditCardClosureSwitch(IBankParams.OFF);
		}
		*/
		//19E4 Tech Debt End:Switch Removal
		if(customer!=null){
			if(ibankRefreshParams.getPayIdRegistrationSwitchParams(origin, customer.getGcis()).isShowPayIdRegistrationMenu()){
	            appParams.setPayIdRegistrationSwitch(IBankParams.ON);
	        }
	        else{
	            appParams.setPayIdRegistrationSwitch(IBankParams.OFF);
	        }	
		}
		
		if(IBankParams.isCardDisputeSwitchON(origin)){
			appParams.setCardDisputeSwitch(IBankParams.ON);
		}
		else{
			appParams.setCardDisputeSwitch(IBankParams.OFF);
		}

		if(IBankParams.isSmartPlanFeeMsgSwitchOn()){
			appParams.setSmartPlanFeeMsgSwitch(IBankParams.ON);
		}
		else{
			appParams.setSmartPlanFeeMsgSwitch(IBankParams.OFF);
		}

		//19E1 CI - Removing increase transaction history CI item
		/*
		if(IBankParams.isExtendTranHistSwitchOn(origin,Account.DDA,null) && IBankParams.isExtendTranHistSwitchOn(origin,Account.CRA,null)){
			if (!IBankParams.isSwitchOn(origin, IBankParams.MORE_TRAN_HISTORY_SWITCH)){
				appParams.setMoreTranHistorySwitch(IBankParams.OFF);
			}else{
				appParams.setMoreTranHistorySwitch(IBankParams.ON);
			}
		}else{
			appParams.setMoreTranHistorySwitch(IBankParams.OFF);
		}
		*/
		
		if(customer != null) {
			PayIdPaymentSwitchParams payIdPaymentSwitchParams = ibankRefreshParams.getPayIdPaymentSwitchParams(origin, customer.getGcis());
			if(payIdPaymentSwitchParams.isShowPayToPayIdIcon()) {
				appParams.setShowPayToPayIdIcon(IBankParams.ON);
			} else {
				appParams.setShowPayToPayIdIcon(IBankParams.OFF);
			}
		}
		
		if(IBankParams.isSwitchOn(origin, IBankParams.IV_SWITCH)) {
			appParams.setIncomeVerificationSwitch(IBankParams.ON);
		}
		else {
			appParams.setIncomeVerificationSwitch(IBankParams.OFF);
		}
		
		//19E2 CPP Term Deposit Switches for Origination and Renewal
		if(IBankParams.isSwitchOn(origin, IBankParams.CPP_TD_OPEN_SWITCH))
			appParams.setCppTDOpenSwitch(IBankParams.ON);		
		else 
			appParams.setCppTDOpenSwitch(IBankParams.OFF);
		
		
		if(IBankParams.isSwitchOn(origin, IBankParams.CPP_TD_RENEW_SWITCH))
			appParams.setCppTDRenewSwitch(IBankParams.ON);		
		else 
			appParams.setCppTDRenewSwitch(IBankParams.OFF);
		
		//19E2 Optimisation 
		if(IBankParams.isSwitchOn(origin, IBankParams.UPCOMING_PAYMENTS_SWITCH))
			appParams.setUpcomingPaymentsSwitch(IBankParams.ON);		
		else 
			appParams.setUpcomingPaymentsSwitch(IBankParams.OFF);
		
		if(IBankParams.isSwitchOn(origin, IBankParams.MANAGE_ECORRESTMT_SWITCH))
			appParams.setManageEcorreStmtSwitch(IBankParams.ON);		
		else 
			appParams.setManageEcorreStmtSwitch(IBankParams.OFF);
		
		if(IBankParams.isSwitchOn(origin, IBankParams.DASHBOARD_CONNECT_SWITCH))
			appParams.setDashboardConnectSwitch(IBankParams.ON);		
		else 
			appParams.setDashboardConnectSwitch(IBankParams.OFF);
		
		//19E2 AppDynamics
		if(IBankParams.isSwitchOn(IBankParams.APP_DYNAMICS_MB_SWITCH)){
			appParams.setAppDynamicsMBSwitch(IBankParams.ON);
		}
		else{
			appParams.setAppDynamicsMBSwitch(IBankParams.OFF);
		}
		
		//19E2 SavingsOnboarding Existing Account Switch
		//19E4 Tech Debt Start:Switch Removal
		/*if(IBankParams.isSwitchOn(IBankParams.SAVINGS_HABIT_SWITCH_EXISTING)){
			appParams.setSavingsOnboardingExistingSwitch(IBankParams.ON);
		}else{
			appParams.setSavingsOnboardingExistingSwitch(IBankParams.OFF);
		}*/
		//19E4 Tech Debt End:Switch Removal
		//19E2 SavingsOnboarding New Account Switch
		//19E4 Tech Debt Start:Switch Removal
		/*if(IBankParams.isSwitchOn(IBankParams.SAVINGS_HABIT_SWITCH_NEW)){
			appParams.setSavingsOnboardingNewSwitch(IBankParams.ON);
		}else{
			appParams.setSavingsOnboardingNewSwitch(IBankParams.OFF);
		}*/
		//19E4 Tech Debt End:Switch Removal
		
		if(IBankParams.isSwitchOn(origin, IBankParams.MANAGE_TD_SWITCH))
			appParams.setManageTDSwitch(IBankParams.ON);		
		else 
			appParams.setManageTDSwitch(IBankParams.OFF);
		
		
		//19E3 TFNSWITCH ON
		if(IBankParams.isSwitchOn(origin, IBankParams.TFN_SWITCH))
			 appParams.setTfnSwitch(IBankParams.ON);		
		else 
			 appParams.setTfnSwitch(IBankParams.OFF);
		
		
		// 19E3 changes for polling
		appParams.setNppPaymentStatusPollingCount(IBankParams.getNPPPaymentStatusPollingCount());
		appParams.setNppPaymentStatusPollingInterval(IBankParams.getNPPPaymentStatusPollingInterval());
		appParams.setPayIdRegStatusPollingInterval(IBankParams.getPayIdRegStatusPollingInterval());
		
		//19E3- Direct debit transaction switch
		if(IBankParams.isRecurringDirectDebitTransactionSwitchON(origin))
			appParams.setRecurringDDTSwitch(IBankParams.ON);		
		else 
			appParams.setRecurringDDTSwitch(IBankParams.OFF);		
		
		//19E4 AEM Personalization/AEMNba Switch 
		//boolean aemCampaignSwitch = IBankParams.isBrandSwitchOn(origin, IBankParams.AEM_NBA_CAMPAIGN_SWITCH) ;
		boolean aemCampaignSwitch =ibankRefreshParams.isAemCampaignSwitch(origin, IBankParams.AEM_NBA_CAMPAIGN_SWITCH);
		if(aemCampaignSwitch) {
			appParams.setAemNBACampaignSwitch(IBankParams.ON);	
		}else{
			appParams.setAemNBACampaignSwitch(IBankParams.OFF);	
		}
		
		//19E4 MEDB
		boolean medbSwitch = ibankRefreshParams.isMEDBImportPayeesSwitchOn(origin, IBankParams.MEDB_SWITCH);
		if(medbSwitch){
			appParams.setMedbSwitch(IBankParams.ON);	
		}else{
			appParams.setMedbSwitch(IBankParams.OFF);	
		}
		
		boolean medbSalCreditSwitch = ibankRefreshParams.isMEDBSalaryCreditSwitchOn(origin, IBankParams.MEDB_SALCREDIT_SWITCH);
		if(medbSalCreditSwitch){
			appParams.setMedSalCreditSwitch(IBankParams.ON);	
		}else{
			appParams.setMedSalCreditSwitch(IBankParams.OFF);	
		}
	//	boolean personalizationSwitch = IBankParams.isBrandSwitchOn(origin, IBankParams.PERSONALIZATION_CONTENT_SWITCH) ;
		boolean personalizationSwitch = ibankRefreshParams.isAemCampaignSwitch(origin, IBankParams.PERSONALIZATION_CONTENT_SWITCH) ;
		if(personalizationSwitch){						
			appParams.setPersonalizationContentSwitch(IBankParams.ON);	
		}else{
			appParams.setPersonalizationContentSwitch(IBankParams.OFF);	
		}
		if(aemCampaignSwitch || personalizationSwitch){
			CodesVO codesVo = IBankParams.getCodesVO(origin, IBankParams.CATEGORY_PERSONALIZATION_CONTENT, IBankParams.PERSONALIZATION_CONTENT_URL);
			if(codesVo != null){
				appParams.setPersonalizationContentUrl(codesVo.getMessage());
			}
			codesVo = IBankParams.getCodesVO(origin, IBankParams.CATEGORY_PERSONALIZATION_CONTENT, IBankParams.PERSONALIZATION_CONTENT_REFRESH_TIME);
			try{
				if(codesVo != null && StringMethods.isNumber(codesVo.getMessage())){
					appParams.setPersonalizationContentRefreshTime(Integer.parseInt(codesVo.getMessage()));
				}
			}
			catch(Exception e){
				IBankLog.logEOTFail("unable to get PersonalizationContentRefreshTime",LogonHelper.class);			
			}
			
			codesVo = IBankParams.getCodesVO(origin, IBankParams.CATEGORY_PERSONALIZATION_CONTENT, IBankParams.PERSONALIZATION_CSS_URL);
			if(codesVo != null){
				appParams.setPersonalizationCSSURL(codesVo.getMessage());
			}		
		}		
		
		//19E3 ProductContentSwitch
		if(IBankParams.isSwitchOn(origin, IBankParams.PRODUCT_CONTENT_SWITCH)){
			appParams.setProductContentSwitch(IBankParams.ON);
		}else{
			appParams.setProductContentSwitch(IBankParams.OFF);
		}
		
		//19E4 Worldwide Wallet / Global Wallet / GCC switch
		if(globalWalletService.isGlobalWalletSwitchOn(customer.getGcis()))
			appParams.setGlobalWalletSwitch(IBankParams.ON);
		else
			appParams.setGlobalWalletSwitch(IBankParams.OFF);
		
		//19E3 - CPP IB-MB flow
		appParams.setTargetURL(createTargetUrl(request)+IBankParams.getCPPTargetURL());
		
					
		if(IBankParams.isLogonPayeesBillersAsyncSwitchON(origin))
			appParams.setLogonPayeesBillersAsyncSwitch(IBankParams.ON);		
		else 
			appParams.setLogonPayeesBillersAsyncSwitch(IBankParams.OFF);
		
		//19E4 Worldwide Wallet / Global Wallet / GCC switch
		//20E3 Switch Cleanup 
		/*if(IBankParams.isSwitchOn(origin, IBankParams.COMPLETE_FREEDOM_ROUTE_SWITCH))
			appParams.setCompleteFreedomRouteSwitch(IBankParams.ON);
		else
			appParams.setCompleteFreedomRouteSwitch(IBankParams.OFF);*/
		//19E4 Incentive Saver Route switch
		//20E3 Switch Clean up
		/*if(IBankParams.isSwitchOn(origin, IBankParams.INCENTIVE_SAVER_ROUTE_SWITCH)){
			appParams.setIncentiveSaverRouteSwitch(IBankParams.ON);
		}else{
			appParams.setIncentiveSaverRouteSwitch(IBankParams.OFF);
		}*/
		
		//	19E4 Account details tabs switch
		//20E2 -- Commenting the switch check for account details route switch as a part of tech debt to do switch clean up
	/*	if(IBankParams.isAccountDetailsRouteSwitchOn(origin, IBankParams.ACCOUNT_DETAILS_ROUTE_SWITCH)) {
			appParams.setAccountDetailsRouteSwitch(IBankParams.ON);
		} else {
			appParams.setAccountDetailsRouteSwitch(IBankParams.OFF);
		}*/
		//20E4 Asic swith change
		if(IBankParams.isASICSwitchON())
			appParams.setAsicSwitch(IBankParams.ON);		
		else 
			appParams.setAsicSwitch(IBankParams.OFF);
				
		if(IBankParams.isHomeLoanDigiSwitchON())
			appParams.setHomeLoanDigiSwitch(IBankParams.ON);
		else
			appParams.setHomeLoanDigiSwitch(IBankParams.OFF);
		
		if(IBankParams.isSwitchOn(IBankParams.BCOPP_COMPLETE_FREEDOM_SWITCH))
			appParams.setBcopCompleteFreedomSwitch(IBankParams.ON);		
		else 
			appParams.setBcopCompleteFreedomSwitch(IBankParams.OFF);
		
		if(IBankParams.isBcopPorfolioFixedLoanSwitchON())
			appParams.setBcopPortfolioFixedLoanSwitch(IBankParams.ON);		
		else 
			appParams.setBcopPortfolioFixedLoanSwitch(IBankParams.OFF);
		
		if(IBankParams.isSwitchOn(IBankParams.AEM_ADMIN_TEMPLATE_SWITCH)){
			appParams.setAemAdminTemplateSwitch(IBankParams.ON);
		}else{
			appParams.setAemAdminTemplateSwitch(IBankParams.OFF);
		}
		if(IBankParams.isSwitchOn(origin, IBankParams.GLOBAL_WALLET_TRANSFER_SWITCH)){
			appParams.setGlobalWalletTransferSwitch(IBankParams.ON);
		}else{
			appParams.setGlobalWalletTransferSwitch(IBankParams.OFF);
		}
		if(IBankParams.isSwitchOn(IBankParams.TRANS_CATEGORY_UPLIFT))
			appParams.setTransCategoryUpliftSwitch(IBankParams.ON);		
		else 
			appParams.setTransCategoryUpliftSwitch(IBankParams.OFF);
		CodesVO phoneNoCodesVO = IBankParams.getCodesData(origin, IBankParams.MATRIX_SPLASH_PAGE_PARAMS,IBankParams.PHONE);
		if ( phoneNoCodesVO != null && ! StringMethods.isEmptyString(phoneNoCodesVO.getMessage() ) ) {
			appParams.setMatrixSplashPagePhoneNo(phoneNoCodesVO.getMessage());
		}
		//appParams.setMatrixSplashPagePhoneNo(IBankParams.getCodesData(origin, IBankParams.MATRIX_SPLASH_PAGE_PARAMS,IBankParams.PHONE).getMessage());		

		
		if(IBankParams.isPayeeEmailSwitchOn(origin)){
			appParams.setPayeeEmailSwitch(IBankParams.ON);
		}else{
			appParams.setPayeeEmailSwitch(IBankParams.OFF);
		}if(IBankParams.isNPPPayIdAddressBookSwitchON(origin)){
			appParams.setNppPayIdAddressBookSwitch(IBankParams.ON);
		}else {
			appParams.setNppPayIdAddressBookSwitch(IBankParams.OFF);
		}
		
		if(IBankParams.isNPPEndToEndIdSwitchON(origin)){
			appParams.setNppEndToEndIdSwitch(IBankParams.ON);
		} else {
			appParams.setNppEndToEndIdSwitch(IBankParams.OFF);
		}

		// 20E2- CSH - set CSH show tile flag 
		// If switch is on check CCPL Loan Indicator value
		if(IBankParams.isSwitchOn(IBankParams.getBaseOriginCode(origin), IBankParams.CSH_DISPLAY_TILE_SWITCH)) {
			appParams.setShowCSHTile(IBankParams.ON);			
			
			int cshIndicator = LoanAppUtil.getCSHTileIndicator(customer.getPreference().getCcPLLoanInd());
			
			if(cshIndicator == LoanAppConstants.PRF_CCLOANIND_CSH ||
					cshIndicator == LoanAppConstants.PRF_CCLOANIND_EFINANCE ||	
					cshIndicator == LoanAppConstants.PRF_CCLOANIND_HOMELOAN ||
					cshIndicator == LoanAppConstants.PRF_CCLOANIND_EFINANCE_HOMELOAN_BOTH) {
				appParams.setCshTilePresent(IBankParams.YES);
			} else {
				appParams.setCshTilePresent(IBankParams.NO);
			}
		} else {
			appParams.setShowCSHTile(IBankParams.OFF);
		}
		
		int updatePhoneNumberSwitch = ibankRefreshParams.getUpdatePhoneNumberSwitch();
		if(updatePhoneNumberSwitch != 0) {
			if(updatePhoneNumberSwitch==2){
				appParams.setUpdatePhoneNumberSwitch(IBankParams.ON);
			}else {
				Cookie cookie = getCookie(request, APP_VER_COOKIE);
				if (cookie != null && !StringMethods.isEmptyString(cookie.getValue())) {
					appParams.setUpdatePhoneNumberSwitch(IBankParams.ON);
				}else {
					appParams.setUpdatePhoneNumberSwitch(IBankParams.OFF);
				}
			}
		}else {
			appParams.setUpdatePhoneNumberSwitch(IBankParams.OFF);
		}
		
		if(IBankParams.isLWCSwitchON()) {
			appParams.setLwcSwitch(IBankParams.ON);
		}else {
			appParams.setLwcSwitch(IBankParams.OFF);
		}

		if(IBankParams.isLWCPendingtransSwitchON()) {
			appParams.setLwcPendingTransactionSwitch(IBankParams.ON);
		}else {
			appParams.setLwcPendingTransactionSwitch(IBankParams.OFF);
		}
		
		 if(IBankParams.isSwitchOn(IBankParams.FILESHARE_SWITCH))
				appParams.setFileShareSwitch(IBankParams.ON);
			else
				appParams.setFileShareSwitch(IBankParams.OFF);
		 
		 if(IBankParams.isPayeeLimitIncreaseSwitchOn(origin)) {
			 appParams.setPayeeLimitIncreaseSwitch(IBankParams.ON);
		 }else {
			 appParams.setPayeeLimitIncreaseSwitch(IBankParams.OFF);
		 }
		 
		 if(Boolean.TRUE.equals(IBankParams.getSwitch(IBankParams.DEFAULT_ORIGIN,IBankParams.MGRP_SWITCH))) {
			 appParams.setMgrpSwitch(IBankParams.ON);
		 }else {
			 appParams.setMgrpSwitch(IBankParams.OFF);
		 }
		 
		 boolean intlPaymentFeeSwitch =ibankRefreshParams.isIntlPaymentFeeSwitchOn();
		 if(intlPaymentFeeSwitch) {
				appParams.setIntlPaymentSwitch(IBankParams.ON);
			}else {
				appParams.setIntlPaymentSwitch(IBankParams.OFF);
			}
		// 20E3 warranty - Covid Support Hub Tile in Compass 
				 if(IBankParams.isCOVIDSupportHubSwitchON()) {
					appParams.setCovidSupportHubSwitch(IBankParams.ON);
				 }else {
					appParams.setCovidSupportHubSwitch(IBankParams.OFF);
				 }

        if ( IBankParams.isSwitchOn(IBankParams.SIMPLIFY_CONNECT_SWITCH) ) {
			appParams.setSimplifyConnectSwitch(IBankParams.ON);
		}
		else {
			appParams.setSimplifyConnectSwitch(IBankParams.OFF);
		} 		 
        
        //set walletEligibilityURL
        CodesVO walletEligibilityURL = IBankParams.getCodesVO(IBankParams.getBaseOriginCode(origin), IBankParams.MADISON_CATEGORY, IBankParams.MADISON_WALLET_ELIGIBILITY_URL);
    	if(null != walletEligibilityURL) {
    		appParams.setWalletEligibilityURL(walletEligibilityURL.getMessage());
    	}
		
    	//set addCardManuallyURL
    	CodesVO addCardManuallyURL = IBankParams.getCodesVO(IBankParams.getBaseOriginCode(origin), IBankParams.MADISON_CATEGORY, IBankParams.MADISON_ADD_TO_WALLET_MANUALLY_URL);
    	
    	if(null != addCardManuallyURL) {
    		appParams.setAddCardManuallyURL(addCardManuallyURL.getMessage());
    	}
    	
    	if(ibankRefreshParams.isUnarrangedOverdraftSwitchOn()) {
			appParams.setUnarrangedOverdraftSwitch(IBankParams.ON);
		}else {
			appParams.setUnarrangedOverdraftSwitch(IBankParams.OFF);
		}
    	
    	if(ibankRefreshParams.is20E4BcopSwitchOn()) {
			appParams.setbCopSwitch20E4(IBankParams.ON);
		}else {
			appParams.setbCopSwitch20E4(IBankParams.OFF);
		}
    	
		if (null != customer && null != customer.getPreference()) {
			int value = customer.getPreference().getSecureChatStatus();
			appParams.setSecureChatActiveFlag(IBankParams.OFF);
			if (value == 1) {
				appParams.setSecureChatActiveFlag(IBankParams.ON);
			}
			if ( IBankParams.isSwitchOn(IBankParams.getBaseOriginCode(origin),IBankParams.LP_MESSAGING_SWITCH) ) {
				appParams.setLpMessagingSwitch(IBankParams.ON);
			}
			else {
				appParams.setLpMessagingSwitch(IBankParams.OFF);
			} 
    	}
		
		if ( ibankRefreshParams.isSmartPlanSwitchON(IBankParams.DEFAULT_ORIGIN, customer.getGcis()) ) {
			appParams.setSmartPlanSwitch(IBankParams.ON);
		}
		else {
			appParams.setSmartPlanSwitch(IBankParams.OFF);
		} 
		
		
		if(ibankRefreshParams.isAscendaSwitchON())
				appParams.setAscendaSwitch(IBankParams.ON);
			else
				appParams.setAscendaSwitch(IBankParams.OFF);
		
		if ( IBankParams.isSwitchOn(IBankParams.UPD_CONTACT_DETAILS_SWITCH) ) {
			appParams.setUpdateContactDetailsSwitch(IBankParams.ON);
		}
		else {
			appParams.setUpdateContactDetailsSwitch(IBankParams.OFF);
		} 
		
		if ( IBankParams.isSwitchOn(IBankParams.FEE_SIMPLIFICATION_SWITCH) ) {
			appParams.setFeeSimplificationSwitch(IBankParams.ON);
		}
		else {
			appParams.setFeeSimplificationSwitch(IBankParams.OFF);
		} 
		
		if ( IBankParams.isSwitchOn(IBankParams.GAMBLING_SWITCH) ) {
			appParams.setGamblingBlockSwitch(IBankParams.ON);
		}
		else {
			appParams.setGamblingBlockSwitch(IBankParams.OFF);
		} 
		
//		if ( IBankParams.isSwitchOn(IBankParams.EMAIL_BOUNCE_BACK_SWITCH) ) {
//			appParams.setEmailBounceBackSwitch(IBankParams.ON);
//		}
//		else {
//			appParams.setEmailBounceBackSwitch(IBankParams.OFF);
//		} 
//		Google Maps Key population
		
		Logger.info("@2375:googleMapApiKey:"+googleMapApiKey, this.getClass());
		appParams.setGoogleMapApiKey(IBankParams.getIBankCertPassword(googleMapApiKey));//i5MB:Uncomment
		
		if(ibankRefreshParams.isTTRestrictHighRiskCountriesSwitchOn()) {
			appParams.setTtRestrictHighRiskCtrySwitch(IBankParams.ON);
		}else {
			appParams.setTtRestrictHighRiskCtrySwitch(IBankParams.OFF);
		}
		
		appParams.setLpWebOobStartChatDisplayPages(
				IBankParams.getLivePersonChatPageConfig(origin, IBankParams.LP_WEB_START_CHAT_DISPLAY_PAGES));
		appParams.setLpWebOobMinimizedStateDisplayPages(
				IBankParams.getLivePersonChatPageConfig(origin, IBankParams.LP_WEB_MIN_STATE_DISPLAY_PAGES));
		appParams.setLpWebFloatingIconDisplayPages(
				IBankParams.getLivePersonChatPageConfig(origin, IBankParams.LP_WEB_FLOAT_ICON_DISPLAY_PAGES));
		appParams.setLpNativeFloatingIconDisplayPages(
				IBankParams.getLivePersonChatPageConfig(origin, IBankParams.LP_NATIVE_FLOAT_ICON_DISPLAY_PAGES));
		appParams.setLpNativeStartChatDisplayPages(
				IBankParams.getLivePersonChatPageConfig(origin, IBankParams.LP_NATIVE_START_CHAT_DISPLAY_PAGES));

		appParams.setLpSiteId(IBankParams.getLpSiteId(origin));
		
		if(IBankParams.isSwitchOn(IBankParams.MANAGE_PREFERENCES_SWITCH)) {
			appParams.setManagePreferencesSwitch(IBankParams.ON);
		}else{
			appParams.setManagePreferencesSwitch(IBankParams.OFF);
		}

		if(AccountFilter.isMadisonLCMSwitchOn(customer.getGcis())) {
			appParams.setMadisonLCMSwitch(IBankParams.ON);
		}else {
			appParams.setMadisonLCMSwitch(IBankParams.OFF);
		}
		
		appParams.setCardLostStolenPhone(IBankParams.getLostStolenCardHelpDeskPhoneNumber(origin));

		appParams.setQasUrl(qasService.getQasUrl());
		appParams.setQasToken(qasService.getQasToken());
		appParams.setQasAction(qasService.getQasAction());
		
		if(ibankRefreshParams.isNppABNPayIdRegSwitchOn()) {
			appParams.setNppABNPayIdRegSwitch(IBankParams.ON);
		}else {
			appParams.setNppABNPayIdRegSwitch(IBankParams.OFF);
		}
		
		//21E2 Account to Index validation switch
		if ( IBankParams.isSwitchOn(IBankParams.ACCT_TO_INDEX_VALIDATION_SWITCH) ) {
			appParams.setAcctToIndexValidationSwitch(IBankParams.ON);
		}
		else {
			appParams.setAcctToIndexValidationSwitch(IBankParams.OFF);

		} 
		if(ibankRefreshParams.isMBCshHomeLoanSwitchOn(IBankParams.getBaseOriginCode(origin))) {
			appParams.setCshHomeLoanSwitch(IBankParams.ON);
		}
		else {
			appParams.setCshHomeLoanSwitch(IBankParams.OFF);
		}


		if ( IBankParams.isSwitchOn(IBankParams.ACCT_TO_INDEX_VALIDATION_SWITCH) ) {
			appParams.setAcctToIndexValidationSwitch(IBankParams.ON);
		}
		else {
			appParams.setAcctToIndexValidationSwitch(IBankParams.OFF);
		}

		if ( IBankParams.isSwitchOn(IBankParams.ACCT_TO_INDEX_VALIDATION_SWITCH) ) {
			appParams.setAcctToIndexValidationSwitch(IBankParams.ON);
		}
		else {
			appParams.setAcctToIndexValidationSwitch(IBankParams.OFF);
		}

		if ( IBankParams.isSwitchOn(IBankParams.DEFAULT_ORIGIN,IBankParams.FILESHARE_PING_IDP_SWITCH) ) {
			appParams.setFileShareOAuthIDPSwitch(IBankParams.ON);
		}
		else {
			appParams.setFileShareOAuthIDPSwitch(IBankParams.OFF);
		}

		return appParams;
	}
	
	
	private ArrayList<Integer> getNOMLinkedAccountIndex(Account selAccount, List<Account> toAccts) 
	// For DRA  account getting Nominated Account.
	{
		int linkIndex = -1;
		String nomAccountKey = null;
		if ("DRA".equalsIgnoreCase(selAccount.getAccountId().getEhubProductCode()))
		{
			if (selAccount.getNominatedAcct() != null)
			{
				nomAccountKey = selAccount.getNominatedAcct().getAccountKey();
				if (StringMethods.isValidString(nomAccountKey))
				{
					nomAccountKey = nomAccountKey.replaceAll(" ", "");
					nomAccountKey = StringMethods.removeLeadingZero(nomAccountKey);
				}
			}
			if (toAccts != null)
			{
				for (int j = 0; j < toAccts.size(); j++)
				{
					Account nomAcct = (Account) toAccts.get(j);
					String nomToAcctKey = nomAcct.getAccountId().getAccountKey();
					Logger.debug("nomAcct " + nomAcct + " nomToAcctKey ", this.getClass());
					if(null != nomAcct.getAccountId() && null != nomAcct.getAccountId().getApplicationId()  && !"ZIP".equals(nomAcct.getAccountId().getApplicationId())) {
						nomToAcctKey = nomToAcctKey.replaceAll(" ", "");
						nomToAcctKey = StringMethods.removeLeadingZero(nomToAcctKey);
						if ((nomToAcctKey.equalsIgnoreCase(nomAccountKey)))
						{
							linkIndex = nomAcct.getIndex();
							break;
						}
					}
				}
			}
		}
		ArrayList<Integer> indexes = new ArrayList<Integer>();
		indexes.add(linkIndex); 
		return indexes;
	}

	private ArrayList<Integer> getLinkedSenseEveryDayAccountIndex(Account selAccount, List<Account> toAccts) 
	// Gettting Sense Saving account Index for Sense EveryDay
	{
		int linkIndex = -1;
		if (selAccount.getAccountId().isSenseSavingAccount())
		{
			String linkedAcct = "";
			if (selAccount.getSenseLinkAcctKey() != null)
			{
				linkedAcct = selAccount.getSenseLinkAcctKey().trim();
			}
			if (toAccts != null)
			{
				for (int j = 0; j < toAccts.size(); j++)
				{
					Account sneAcct = (Account) toAccts.get(j);
					if(null != sneAcct.getAccountId()  &&null != sneAcct.getAccountId().getAccountKey())
						if ((sneAcct.getAccountId().getAccountKey().equalsIgnoreCase(linkedAcct)))
						{
							linkIndex = sneAcct.getIndex();
							break;
						}
				}
			}
		}
		ArrayList<Integer> indexes = new ArrayList<Integer>();
		indexes.add(linkIndex); 
		return indexes;
	}

	private ArrayList<Integer> getLinkedSennseSavingAccountIndex(Account selAccount, List<Account> toAccts)
	//Gettting Sense EveryDay account Index for Sense Saving
	{
		int linkIndex = -1;
		if (selAccount.getAccountId().isSenseEverydayAccount())
		{
			String linkedAcct = "";
			if (selAccount.getSenseLinkAcctKey() != null)
			{
				linkedAcct = selAccount.getSenseLinkAcctKey().trim();
			}

			if (toAccts != null)
			{
				boolean snsAcctFound = false;
				for (int j = 0; j < toAccts.size(); j++)
				{
					Account snsAcct = (Account) toAccts.get(j);
					if(null != snsAcct.getAccountId() && null != snsAcct.getAccountId().getAccountKey())
						if ((snsAcct.getAccountId().getAccountKey().equalsIgnoreCase(linkedAcct)))
						{
							linkIndex = snsAcct.getIndex();
							break;
						}
				}
			}
		}
		ArrayList<Integer> indexes = new ArrayList<Integer>();
		indexes.add(linkIndex); 
		return indexes;
	}

	private ArrayList<Integer> getLinkedAccoutsIndexesForExtNOM(Account selAccount, List<Account> toAccts)
	//Getting 
	{
		int linkIndex = -1;
		String nomAccountKey = null;
		String nomAcctKeys = "";
		ArrayList<Integer> indexes = new ArrayList<Integer>();
		if ("NOM".equalsIgnoreCase(selAccount.getAccountId().getApplicationId()))
		{
			nomAccountKey = selAccount.getAccountId().getAccountKey();
			if (StringMethods.isValidString(nomAccountKey))
			{
				nomAccountKey = nomAccountKey.replaceAll(" ", "");
				nomAccountKey = StringMethods.removeLeadingZero(nomAccountKey);
			}
			if (toAccts != null)
			{
				for (int j = 0; j < toAccts.size(); j++)
				{
					String draNomKey = "";
					Account draAcct = (Account) toAccts.get(j);
					if (draAcct.getNominatedAcct() != null && null != draAcct.getNominatedAcct().getAccountKey())
					{
						draNomKey = draAcct.getNominatedAcct().getAccountKey();
						draNomKey = draNomKey.replaceAll(" ", "");
						draNomKey = StringMethods.removeLeadingZero(draNomKey);
					}
					if ((draNomKey.equalsIgnoreCase(nomAccountKey)) && !Account.NOM.equalsIgnoreCase(draAcct.getAccountId().getApplicationId()))
					{
						linkIndex = draAcct.getIndex();
						indexes.add(linkIndex);
					}
				}
			}
			
			if ( indexes.size() < 1 )
			{
				indexes.add(linkIndex);  // -1 gets added
			}
		}
		return indexes;
	}
	
	public static String maskPhoneNumber(String phoneNumber)
	{
		String phoneNo = "";
		if (!StringMethods.isEmptyString(phoneNumber))
		{
			int len = phoneNumber.length();
			if (len > 4)
			{
				for (int i = 0; i < len - 4; i++)
				{
					phoneNo = phoneNo + "#";
				}
				phoneNo = phoneNo + phoneNumber.substring(len - 4);
			}
		}

		return phoneNo;

	}


	public static final String MOBILE_ENCRYTED_COOKIE = "MBSetCookie";
	public static final String MOBILE_ENCRYTED_SL_COOKIE = "MBSLToken";
//	public static final String MOBILE_SMPL_ENCRYTED_COOKIE = "MBankCookie";
	public static final String MOBILE_DEVICE_FIRST_TIME_COOKIE = "MBFirstTimeHelpCookie";
	public static final String MOBILE_DEVICE_FIRST_COOKIE = "MBFirstTimeHelp";

	public static final String MOBILE_DEVICE_WEB_READY = "WebReady";
	public static final String MOBILE_DEVICE_PMDATA2_COOKIE = "PMData2";
	
	public boolean isPMData2CookieExists(HttpServletRequest request) throws ResourceException
	{
		
		Cookie cookie = getCookie(request,MOBILE_DEVICE_PMDATA2_COOKIE);
		if(cookie != null){
			Logger.info("LaraCroft: Cookie " + cookie.getName() + " found in the request. Value : " + cookie.getValue() , this.getClass());
			return true;
		}else{
			return false;
		}
		//return ( cookie != null ) ; 
	}
	
	public boolean isFirstTimeCookieExists(HttpServletRequest request) throws ResourceException
	{
		Cookie cookie = getCookie(request,MOBILE_DEVICE_FIRST_COOKIE);
		return ( cookie != null ) ; 
	}
	
	public Cookie isFirstTimeHelpCookieExists(HttpServletRequest request, String oldCookieName) throws ResourceException
	{
		Cookie cookie = getCookie(request,oldCookieName);
		return cookie ; 
	}
	
	public Cookie getCookie(HttpServletRequest request, String cookieName) throws ResourceException
	{

		Cookie[] cookies = request.getCookies();
		Cookie cookie = null;
		if (cookies != null)
		{
			for (int i = 0; i < cookies.length; i++)
			{
		//		Logger.info("Cookie Name" + cookies[i].getName() + " found in the request. Value : " + cookie.getValue() , this.getClass());
				if (cookies[i].getName().equals(cookieName))
				{
						cookie = cookies[i]; 
						Logger.info("Cookie " + cookieName + " found in the request. Value : " + cookie.getValue() , this.getClass());
					  break;
				}
			}
		}
		return cookie;
	}

	
	public void setFirstTimeHelpCookie(HttpServletRequest request, HttpServletResponse response ) throws ResourceException
	{
		Cookie cookie = getCookie(request,MOBILE_DEVICE_FIRST_COOKIE);
		String domain = getFullDomainName(request);
		String value = null; 
		if ( cookie == null )
			value = String.valueOf(new Date().getTime()) ;
		else
			value = cookie.getValue();
		setCookie(MOBILE_DEVICE_FIRST_COOKIE,value, domain, cookie, response, true);
		
			 
	}
//delete oldDomain cookie if exist
	public boolean deleteOldCookies(HttpServletRequest request,
			HttpServletResponse response, String oldCookieName) {
		Cookie oldCookie = null;
		boolean isOldCookieDelete = false;
		String oldDomain = getDomainName(request);
		oldCookie = isFirstTimeHelpCookieExists(request, oldCookieName);
		if (oldCookie != null) {
			oldCookie.setMaxAge(0);
			oldCookie.setDomain(oldDomain);
			if (oldDomain.equals(STG_DOMAIN)) {
				oldCookie.setDomain(oldDomain);
			} else if (oldDomain.equals(BSA_DOMAIN)) {
				oldCookie.setDomain(oldDomain);
			} else if (oldDomain.equals(BOM_DOMAIN)) {
				oldCookie.setDomain(oldDomain);
			}

			response.addCookie(oldCookie);
			isOldCookieDelete = true;
		}
		return isOldCookieDelete;
	}
  	
	public boolean updateMBCookie(HttpServletRequest request,
			HttpServletResponse response) {
		Cookie oldCookie = null;
		String encryptCookVal=null;
		boolean isOldCookieDelete = false;
		String oldDomain = getDomainName(request);
		String newDomain=getFullDomainName(request);
		oldCookie = isFirstTimeHelpCookieExists(request, MOBILE_ENCRYTED_COOKIE);
		if (oldCookie != null) {
			oldCookie.setMaxAge(0);
			oldCookie.setDomain(oldDomain);
			if (oldDomain.equals(STG_DOMAIN)) {
				oldCookie.setDomain(oldDomain);
			} else if (oldDomain.equals(BSA_DOMAIN)) {
				oldCookie.setDomain(oldDomain);
			} else if (oldDomain.equals(BOM_DOMAIN)) {
				oldCookie.setDomain(oldDomain);
			}
			encryptCookVal = oldCookie.getValue();
			response.addCookie(oldCookie);
			
			setCookie(MOBILE_ENCRYTED_SL_COOKIE, encryptCookVal, newDomain, null, response, true);
			isOldCookieDelete = true;
		}
		return isOldCookieDelete;
	}


	public void setEncryptedCANCookie(String can, HttpServletRequest request, HttpServletResponse response) throws ResourceException
	{
		createRemoveCANCookie(can, request, response, true);
	}

	public void removeEncryptedCANCookie(HttpServletRequest request, HttpServletResponse response) throws ResourceException
	{
		// createRemoveCANCookie("","","", request, response, false);
		createRemoveCANCookie("", request, response, false);
	}

	
	public String[] getCANAndSecFlagFromCookie(HttpServletRequest request) throws ResourceException
	{

		Cookie[] cookies = request.getCookies();
		String decryptedCookVal = null;
		String[] temp = null;
		if (cookies != null)
		{
			for (int i = 0; i < cookies.length; i++)
			{
				if (cookies[i].getName().equals(MOBILE_ENCRYTED_SL_COOKIE) || cookies[i].getName().equals(MOBILE_ENCRYTED_COOKIE))
				{
					decryptedCookVal = getDecryptedValue(cookies[i].getValue());
					temp = decryptedCookVal.split(";");

					if (temp.length == 3)
					{
						Logger.info("Encrypted CAN from cookie : " + temp[0] + ";Access Number : " + temp[1] + "; Security flag : " + temp[2], this.getClass());
					} else
					{
						Logger.info("Cookie has incorrect no of parameters", this.getClass());
					}

					return temp;
				}
			}
		}
		Logger.info("Cookie not found in the request", this.getClass());
		return null;
	}

	private void createRemoveCANCookie(String can, HttpServletRequest request, HttpServletResponse response, boolean create) throws ResourceException
	{

		Cookie[] cookies = request.getCookies();
		boolean isCookieExists = false;
		boolean isOldCookieDelete=false;
		String encryptCookVal = null;

		//response.setContentType("text/html");
		String domain = getFullDomainName(request);

		if (cookies != null)
		{
			for (int i = 0; i < cookies.length; i++)
			{
				isOldCookieDelete=deleteOldCookies(request,response,MOBILE_ENCRYTED_COOKIE);
				Logger.debug("createRemoveCANCookie " + cookies[i].getName() + " " + cookies[i].getValue(), this.getClass());
				if(isOldCookieDelete){
					Logger.debug("Inside isOldCookieDelete", this.getClass());
					isCookieExists = true;
					Logger.info(" Existing Old domain Cookie Name:"
							+ MOBILE_ENCRYTED_COOKIE
							+ ", isOldCookieDelete :" + isOldCookieDelete, this.getClass());
				}
				else{
					Logger.debug("Existing Old domain Cookie Name: "
							+ MOBILE_ENCRYTED_COOKIE
							+ "isOldCookieDelete :" + isOldCookieDelete, this.getClass());
				}
				if (cookies[i].getName().equals(MOBILE_ENCRYTED_SL_COOKIE))
				{
					// To do expire MOBILE_ENCRYTED_SL_COOKIE
					isCookieExists = true;
					if (cookies[i].getName().equals(MOBILE_ENCRYTED_SL_COOKIE) && ! create )
					{
						cookies[i].setMaxAge(0);
						setCookie(MOBILE_ENCRYTED_SL_COOKIE, encryptCookVal, domain, cookies[i], response, false);
					} 
					
/*					else if (!StringMethods.isEmptyString(can))
					{
						Logger.info("Adding Encrypted CAN cookie 11111111111111111111 ", this.getClass());
						encryptCookVal = getEncryptedCAN(can);
						cookies[i].setValue(encryptCookVal);
						response.addCookie(cookies[i]);
					} else
					{
						Logger.info("Adding Encrypted CAN cookie 11111111111111111222 ", this.getClass());
						encryptCookVal = "";
						cookies[i].setValue(encryptCookVal);
						response.addCookie(cookies[i]);
					}  */

				}
			}
		}

		if ( create)
		{
			Logger.info("Adding Encrypted CAN cookie ", this.getClass());
			encryptCookVal = getEncryptedCAN(can);
			setCookie(MOBILE_ENCRYTED_SL_COOKIE, encryptCookVal, domain, null, response, create);
			
			
		}

		Logger.info("Cookie information stored : " + encryptCookVal, this.getClass());
	}

	private void setCookie(String name, String value, String domain, Cookie cookie, HttpServletResponse response, boolean create)
	{
		if (cookie == null)
		{
			// System.out.println("The value of name is :" + name + " :value is :" +
			// value);
			cookie = new Cookie(name, value);
		}
		cookie.setValue(value);

		if (create)
			cookie.setMaxAge(3 * 30 * 24 * 60 * 60); // 3 moths / 30 days...
		else
			cookie.setMaxAge(0);

		cookie.setSecure(true);
		
		if ( ! StringMethods.isEmptyString(domain ) )
			cookie.setDomain(domain);
		response.addCookie(cookie);

	}

	private String getEncryptedCAN(String can)
	{
		return simpleDigestService.encryptData(can);
	}

	public String getDecryptedValue(String encryptedValue)
	{
		try
		{
			return simpleDigestService.decryptData(encryptedValue);
		} catch (ResourceException e)
		{
			// returning null to show registration page
			return null;
		}

	}

	private String getDomainName(HttpServletRequest request)
	{
		try
		{
			int index = request.getServerName().indexOf('.');
			String domain = request.getServerName().substring(index, request.getServerName().length());
			return domain;
		} catch (Exception e)
		{
			return "";
		}

	}
	
	private String getFullDomainName(HttpServletRequest request)
	{
		try
		{
		    String domain = request.getServerName();
			return domain;
		} catch (Exception e)
		{
			return "";
		}

	}

	public CookieLogonBean populateCookieLogonBean( HttpServletRequest request) throws ResourceException
	{

		Cookie[] cookies = request.getCookies();
		CookieLogonBean cookieBean = null;
		String decryptedCookVal = null;
		String[] temp = null;
		if (cookies != null)
		{
			for (int i = 0; i < cookies.length; i++)
			{
				
/*				if ((cookies[i].getName().equals(MOBILE_SMPL_ENCRYTED_COOKIE)) )
				{
					decryptedCookVal = getDecryptedValue(cookies[i].getValue());
					if(!StringMethods.isEmptyString(decryptedCookVal))
					{
						Logger.info("Encrypted CAN from cookie : " + decryptedCookVal, this.getClass());
					}
					else
					{
						Logger.info("Cookie has incorrect value",this.getClass());
					}
				    cookieBean = new CookieLogonBean();
				    if(decryptedCookVal.length() > 8){
				    	String accessNumber = decryptedCookVal.substring(0, (decryptedCookVal.length() - 1));
				    	String issueNum = decryptedCookVal.substring(decryptedCookVal.length() -1, decryptedCookVal.length());
				    	cookieBean.setAccessNumber(accessNumber);
				    	cookieBean.setIssueNumber(issueNum);
				    }
				    else{
				    	cookieBean.setAccessNumber(decryptedCookVal);
				    }
				    cookieBean.setIgnoreSec(true);
					return cookieBean;
					
				}else 
				*/
				Logger.info("Cookie cookies[i].getName() "+ cookies[i].getName(), this.getClass());

				if (cookies[i].getName().equals(MOBILE_ENCRYTED_SL_COOKIE) || cookies[i].getName().equals(MOBILE_ENCRYTED_COOKIE))
				{      
						decryptedCookVal = getDecryptedValue(cookies[i].getValue());
					   							
						 temp = decryptedCookVal.split(";");
							
						 if(temp.length == 1)
						{
							Logger.info("Encrypted CAN from old cookie : " + temp[0] + ";Issue Number : " + temp[0] + "; Security flag : " + temp[0], this.getClass());
						}
						else
						{
							Logger.info("Cookie has incorrect no of parameters" + temp.length,this.getClass());
						}
					    cookieBean = new CookieLogonBean();
					    String accessNumber = temp[0];
					    if(accessNumber.length() > 8){
					    	cookieBean.setAccessNumber(accessNumber);
//					    	cookieBean.setIssueNumber(temp[1]);
					    }
					    else{
					    	cookieBean.setAccessNumber(accessNumber);
					    }
//					    cookieBean.setIgnoreSec("Y".equalsIgnoreCase(temp[2])); //ignore Security Number = "Y"
					    cookieBean.setIgnoreSec(true); //ignore Security Number = "Y"
						return cookieBean;
					}
			}
		}
		Logger.info("Cookie not found in the request", this.getClass());
		return null;
	}
	
	private static final String MB_DEMO_URL = "mbDemoURL";
	
	private MarketPreferenceResp populateMarketPreferenceResp(Customer customer) {
		
		MarketPreferenceResp marketPreferenceResp = new MarketPreferenceResp();
		if (customer.isGHSCustomer()|| (customer.isCHSGHSCustomer() && CustomerTypes.TYPE_GHS.equals(customer.getPrimaryProfile()))) {
			marketPreferenceResp.setContactForGeneralMarketing(customer.getPreference().getContactForGeneralMarketing());
			marketPreferenceResp.setContactForTelephoneMarketing(customer.getPreference().getContactForTelephoneMarketing());
			marketPreferenceResp.setContactForElectronicMarketing(customer.getPreference().getContactForElectronicMarketing());
		}
		marketPreferenceResp.setReceiveOfferViaInternetMobileBanking(customer.getPreference().isDisplayELeadsSplashPage());
		return marketPreferenceResp;
	}
	
	private LastTranDetailResp populateLastTranDetailResp(Date lastLogonDate, User user)
	{
		LastTranDetailResp lastTranDetailResp = null;
		if ( lastLogonDate != null)
		{
			if ( lastTranDetailResp == null )
				lastTranDetailResp = new LastTranDetailResp();

			lastTranDetailResp.setLastLogonDateTime(lastLogonDate);
		}
		PaymentsLog payLog = getLastTransactionDetails(user);
		if (payLog != null)
		{
			if ( lastTranDetailResp == null )
				lastTranDetailResp = new LastTranDetailResp();
			
			lastTranDetailResp.setLastTranDateTime(payLog.getDate());
			lastTranDetailResp.setLastTranTypeDisp(getLastTransactionType(payLog));
			lastTranDetailResp.setLastTranAmt(String.valueOf(payLog.getAmount()));
		}
		return lastTranDetailResp;
	}


	public int loadCordova(HttpServletRequest request)
	{
		Cookie cookie = getCookie(request, APP_VER_COOKIE);
	  	if ( cookie != null && ! StringMethods.isEmptyString(cookie.getValue()))
	  	{
	  		String tempStr = cookie.getValue();
		  	Logger.info("Cookie value .. ####" +tempStr , this.getClass());
			  	if (tempStr.indexOf("_contactLookup") >= 0)
			  	{
			  		return 3;
			  	}
		  	  if ( tempStr.toUpperCase().indexOf(DEVICE_ANDROID) >= 0 
		  			  || tempStr.toUpperCase().indexOf(DEVICE_ANDROID_MOBBANK) >= 0 )
		  	  {
		  	  	return 2;  // Android
		  	  }
		  	  else
		  	  {
		  	  	return 1; // IOS
		  	  }
	  	}
	  	return -1; // Not detected
	}
	public boolean isMogoSDKInstalled(HttpServletRequest request)
	{
		Cookie cookie = getCookie(request, APP_VER_COOKIE);
		if ( cookie != null && ! StringMethods.isEmptyString(cookie.getValue()))
	  	{
			String tempStr = cookie.getValue();
	  		Logger.debug("App version Cookie value .. " +tempStr , this.getClass());
		  	  if ( tempStr.toUpperCase().indexOf(MOGO_APP_VERSION_COOKIE) >= 0)
		  	  {
		  	  	return true;  // MOGO sdk is installed
		  	  }
		  	  else
		  	  {
		  	  	return false; // MOGO sdk is not installed
		  	  }
	  	}
	  	return true; // No app is used..through browser
	}
	
	private boolean isActiveAccountPresent(List<Account> accountList){
		List<Account> custAccounts = AccountFilter.filterGetActiveOnYourAccount(accountList);
		if(custAccounts!=null && custAccounts.size() > 0){
			Logger.info("Returning true from isActiveAccountPresent", this.getClass());
			return true;
		}
		Logger.info("Returning false from isActiveAccountPresent", this.getClass());
		return false;
	}
	
	private int allowsPostWhenNative(HttpServletRequest request)
	{
		Cookie cookie = getCookie(request, APP_VER_COOKIE);
	  	if ( cookie != null && ! StringMethods.isEmptyString(cookie.getValue()))
	  	{
	  		String tempStr = cookie.getValue();
		  	Logger.debug("Cookie value .. " +tempStr , this.getClass());
	  	  if ( tempStr.toUpperCase().indexOf(APPACTION_POST) >= 0 )
	  	  {
	  	  	return 0;  // allows post when native
	  	  }
	  	  else
	  	  {
	  	  	return 1; // doesn't allow
	  	  }
	  	}
	  	return -1; // Not detected
		
	}
	
	
	private AccountResp handleTermDepositFlags(Account item, AccountResp mbAccountResp) {
		AccountResp accountResp = mbAccountResp;
		TermDepositAdditionalInfo addtInfo = item.getTermDepositAdditionalInfo();
		if (!"CHS".equals(item.getAccountId().getApplicationId())
		    && addtInfo != null && YES.equals(addtInfo.getGraceInd())) {
			
			
			Logger.debug("Team Dep .. isTdaInitialDeposit " + addtInfo.isTdaInitialDeposit() + " isTdaRenewal "+ addtInfo.isTdaRenewal() , this.getClass());
			if (addtInfo.isTdaInitialDeposit()) {
					accountResp.setTdaInInitGrace(true);
			} else if (addtInfo.isTdaRenewal()) {
					accountResp.setTdaInRenewGrace(true);
			}	
		}
		
		if(item.getAccountId().getSubProductCode().equals("80")){
			accountResp.setTdaIsFlexiDeposit(true);
		}
		return accountResp;
	}
	
	
	private AccountResp handleCRAActivationStatus(Account acct,  AccountResp mbAccountResp) {
		AccountResp accountResp = mbAccountResp;
		
	 CreditCardAccount crAccount = (CreditCardAccount) acct;
	 
   if(("C".equals(crAccount.getBlockCode()) || acct.isBlocked())  ) {
  	 	boolean isBlocked =  checkCardBlocked(null, acct.getAccountId().getAccountNumber());
  	  if ( isBlocked )
  	  	accountResp.setCraOnHold(Boolean.TRUE);
   }

		if ( acct.getCreditCardAdditionalInfo() != null )
		{
			if (IBankParams.YES.equals(acct.getCreditCardAdditionalInfo().getReplCardProdTransfer()) ||
					IBankParams.YES.equals(acct.getCreditCardAdditionalInfo().getRequiredActivationStatus()))
			{
				accountResp.setCraNeedsActivation(true);
			}
		}
		

		return accountResp;
	}

	
	public String getEncryptedUserID(String userID) throws ResourceException {
		try {
			IBankSecurityService iBankSecurityService = (IBankSecurityService) ServiceHelper
					.getBean(SECURITYENCRYPTER_BEAN);
			String uniqueId = iBankSecurityService.encrypt(userID);
			return uniqueId;
		} catch (Exception e) {
			IBankLog.logERR("Unable to Craete UniqueID. User ID : " + userID,
					e, this.getClass());
			throw new ResourceException(ResourceException.SYSTEM_ERROR,
					"Unable to Craete UniqueID");
		}
	}

	public String getDeccryptedUserID(String encryptedUserID)
			throws ResourceException {
		try {
			IBankSecurityService iBankSecurityService = (IBankSecurityService) ServiceHelper
					.getBean(SECURITYENCRYPTER_BEAN);
			String strText = iBankSecurityService.decrypt(encryptedUserID);
			return strText;
		} catch (Exception e) {
			IBankLog.logERR("Unable to Decrypt :" + encryptedUserID, e, this
					.getClass());
			throw new ResourceException(ResourceException.SYSTEM_ERROR,
					"Unable to Decrypt :" + encryptedUserID);
		}
	}

	
  private static final String BSA_DOMAIN =".banksa.com.au"; 
  private static final String STG_DOMAIN = ".stgeorge.com.au";
  private static final String BOM_DOMAIN=".bankofmelbourne.com.au";

	
	public boolean isMobileTnCCookieExists(HttpServletRequest request,HttpServletResponse response,String encryptedUserID,String version){
		boolean  isCookieFound = false;
		//response.setContentType("text/html");
		boolean isOldCookieDelete=false;
		Cookie[] cookies = request.getCookies();
		if (cookies != null) {
			for (int i = 0; i < cookies.length; i++) {
				if (cookies[i].getName().equals(MOBILE_TNC_COOKIE)) {
					isOldCookieDelete=deleteOldCookies(request,response,MOBILE_TNC_COOKIE);
					if(isOldCookieDelete){
						Logger.info(" Existing Old domain Cookie Name:"
								+ MOBILE_TNC_COOKIE
								+ ", isOldCookieDelete :" + isOldCookieDelete, this.getClass());
					}
					else{
						Logger.debug("Existing Old domain Cookie Name: "
								+ MOBILE_TNC_COOKIE
								+ "isOldCookieDelete :" + isOldCookieDelete, this.getClass());
					}
					String oldCookieValue=cookies[i].getValue();
					String[] values=oldCookieValue.split(":");
					if (encryptedUserID.equals(values[0]) && version.equals(values[1])) {
					isCookieFound = true;
					}
					break;
				}
				if (cookies[i].getName().equals(
						MOBILE_TERMS_COOKIE)) {
					String oldCookieValue = cookies[i].getValue();
					Logger.info("Terms and Condition Existing Cookies " + oldCookieValue  ,this.getClass());
					String[] values = oldCookieValue.split(":");
					Logger.info("values array " + values  ,this.getClass());
					if (encryptedUserID.equals(values[0]) && version.equals(values[1])) {
						cookies[i].setValue(encryptedUserID);
						cookies[i].setMaxAge(640 * 24 * 60 * 60);
						cookies[i].setSecure(true);
						String serverName = request.getServerName();
						if (StringMethods.isValidString(serverName)) {
							if (serverName.endsWith(STG_DOMAIN)) {
								//cookies[i].setDomain(STG_DOMAIN);
								cookies[i].setDomain(serverName);
							} else if (serverName.endsWith(BSA_DOMAIN)) {
								//cookies[i].setDomain(BSA_DOMAIN);
								cookies[i].setDomain(serverName);	
							} else if (serverName.endsWith(BOM_DOMAIN)) {
								//cookies[i].setDomain(BOM_DOMAIN);
								cookies[i].setDomain(serverName);
							}
//							else -- for testing from local device
//								cookies[i].setDomain("."+serverName);
						}
						//response.addCookie(cookies[i]);
						Logger.debug("Using  Existing Cookie "
								+ MOBILE_TERMS_COOKIE
								+ "Value :" + encryptedUserID, this.getClass());
						isCookieFound = true;
						
//						response.setHeader("Set-Cookie", 
	//							MOBILE_TERMS_COOKIE + "=" + encryptedUserID + ":" + version + "; max-age ="+ cookies[i].getMaxAge() +";Secure;HttpOnly;Domain="+cookies[i].getDomain());

						break;
					}
				}
			}
		}

		return isCookieFound;
	}

	
	public void addNewTnCCookie(HttpServletRequest request,HttpServletResponse response,String encryptedUserID,String version){
		Cookie cookie = new Cookie(MOBILE_TERMS_COOKIE,
				encryptedUserID + ":" + version);
		cookie.setMaxAge(640 * 24 * 60 * 60);
		cookie.setSecure(true);
		
		String serverName = request.getServerName();
		String domain = STG_DOMAIN;
		int maxage = 640 * 24 * 60 * 60;
		if (StringMethods.isValidString(serverName)) {
			if (serverName.endsWith(STG_DOMAIN)) {
				//cookie.setDomain(stgeorgeDomain);
				//domain = STG_DOMAIN;
				domain = serverName;
			} else if (serverName.endsWith(BSA_DOMAIN)) {
				//cookie.setDomain(banksaDomain);
				//domain = BSA_DOMAIN;
				domain = serverName;
			} else if(serverName.endsWith(BOM_DOMAIN)){
				//domain = BOM_DOMAIN;
				domain = serverName;
			}
//			else -- for testing from local device
//				domain = "." + serverName;
		}		
				
/*		if(domain != null)
			response.setHeader("Set-Cookie", 
				MOBILE_TERMS_COOKIE + "=" + encryptedUserID + ":" + version + "; max-age ="+ maxage +";Secure;HttpOnly;Domain="+domain);
		else
			response.setHeader("Set-Cookie", 
					MOBILE_TERMS_COOKIE + "=" + encryptedUserID + ":" + version + "; max-age ="+ maxage +";Secure;HttpOnly");
		Logger.debug("Adding new Cookie " + MOBILE_TERMS_COOKIE
				+ " Value :" + encryptedUserID, this.getClass());  */
		
		cookie.setSecure(true);
		cookie.setDomain(domain);
		if(null != cookie)
			Logger.debug("T & C Cookie added " + cookie.getValue(), this.getClass());
		response.addCookie(cookie);
		

	}

	
	public static final String DEVICE_TYPE_TABLET = "TABLET";
	public static final String DEVICE_TYPE_MOBILE = "MOBILE";
	

	public String getGDWOrigin(ReqHeader req, String origin)
	{
		StringBuffer tempOrigin = new StringBuffer();
		if ( req.getDeviceType() != null && req.getDeviceType().toUpperCase().startsWith(DEVICE_TYPE_TABLET) )
		{
			tempOrigin.append("T");
			tempOrigin.append(origin.substring(1));
		}
		else
		{
			tempOrigin.append(origin);
		}
		return tempOrigin.toString();
	}
	
	
	public boolean isAndroid(HttpServletRequest request) {
		String userAgent = request.getHeader("User-Agent").toLowerCase();
		if (userAgent.indexOf("android") >= 0)
			return true;
		else
			return false;
	}
	
	public boolean isAndroidPixel(HttpServletRequest request) {
		String userAgent = request.getHeader("User-Agent").toLowerCase();
		if (userAgent.indexOf("pixel") >= 0)
			return true;
		else
			return false;
	}
	
	public String getNumKeyBoardType(HttpServletRequest request)
	{
		String type = null;
		if (isIPhone(request) || isAndroidS4(request))
			// request.setAttribute("usePattern","Y");
			type = "text";
		else
			// request.setAttribute("usePattern","N");
			type = "number";
		return type;
	}

	
	public String getNumKeyBoardPattern(HttpServletRequest request)
	{
		String type = null;
		if (isIPhone(request) || isAndroidS4(request))
		{
			// request.setAttribute("usePattern","Y");
			type = "[0-9]*";
		}
		else
		{
			// request.setAttribute("usePattern","N");
			type = " ";
		}
		return type;
	}
	public String getKeyboardAmountType(HttpServletRequest request)
	{
		if (!StringMethods.isEmptyString(getAndroidAmtField()) && isAndroid(request)) {
			
			if(isAndroidPixel(request))
			{
				Logger.debug("Inside Google Pixel :", LogonHelper.class);
				return "number";
			}
			else
			{
				return getAndroidAmtField();
			}	
		}
		else
		{
			return "number";
		}
	}
	
	public boolean isAndroidS4(HttpServletRequest request) {
		String userAgent = request.getHeader("User-Agent").toLowerCase();
		String pattern = "(.*)(android 4\\.2)(.*)";
		// Create a Pattern object
	    Pattern r = Pattern.compile(pattern);
	    Matcher m = r.matcher(userAgent);
	    if(m.find()){
	    	return true;
	    } else {
	    	return false;
	    }
	}
	
	public boolean isIPhone(HttpServletRequest request) {
		String userAgent = request.getHeader("User-Agent").toLowerCase();
		Logger.info(" User Agent  : "+ userAgent, this.getClass());
		if (userAgent.indexOf("iphone") >= 0 || userAgent.indexOf("ipod") >= 0 || userAgent.indexOf("ipad") >= 0)
			return true;

		return false;

	}	

	public  IMBResp populateCustomeCredentialChange(Customer customer, User user, HttpServletRequest request, HttpServletResponse response)
	{
		LogonResp logonResponse = new LogonResp();
		CustomerResp mbCustomer = new CustomerResp();
	//	mbCustomer.setContactInfo(populateContact(customer.getContactDetail()));
		//mbCustomer.setSecureCodeInfo(populateSecureCodeInfo(customer));
		
		AppParams appParams = populateAppParams(request, customer);
		logonResponse.setAppParams(appParams);
		logonResponse.setChangePwdReqd(user.isStatusMustChangePassword());
		
		String encryptedCookieUserid = getEncryptedUserID(user.getUserId());
		addNewTnCCookie(request, response,encryptedCookieUserid,"1.0");
		
		Boolean smsRest = (Boolean) user.getAttribute(SMS_RESET_STATUS);
		if ( smsRest != null && smsRest.booleanValue())
		{
			logonResponse.setChangePwdAndSecNumReqd(smsRest.booleanValue());
		}
		logonResponse.setCustomer(mbCustomer);
		return logonResponse;
	}

	public void setWebReadyCookie(HttpServletRequest request, HttpServletResponse response, String value ) throws ResourceException
	{
		Cookie cookie = getCookie(request,MOBILE_DEVICE_WEB_READY);
		String domain = null; //  getDomainName(request);  Not setting domain as suggested by MAD Team 
		setCookie(MOBILE_DEVICE_WEB_READY,value, domain, cookie, response, true);
		 
	}


	public static boolean isDemo()
	{
		
	  CodesVO code = IBankParams.getCodesData(IBankParams.BRAND_ORIGIN, IBankParams.CONFIGURATION_PROPERTIES, MB_DEMO_URL);
	  
	  if ( code != null && ! StringMethods.isEmptyString(code.getMessage() ) )
	  {
	  	return true;
	  }
	  else
	  {
	  	return false;
	  }

	}

	
	private boolean isDBSession()
	{
		
	  Configuration myConfig = Configurator.getConfiguration(SessionConstants.CONFIG_SESSION_FILE);
	  String sessionFromProp = myConfig.getConfig(SessionConstants.CONFIG_SESSTIONTYPE);
	  return ! SessionConstants.CONFIG_HTTPSESSION_SESSION.equals(sessionFromProp);
	}

	private static  String webContext = null;

	public String getMBWebResourceContext()
	{
		if ( this.webContext != null )
			return this.webContext;
		if (StringMethods.isEmptyString(this.webContext))
		{
			if (isDemo())
			{
				this.webContext = "mb3demo";
			}
			else
			{
				this.webContext = "mb3";
			}
		}
		Logger.info("WebContext used is " + this.webContext, this.getClass());
		return this.webContext;
	}
	
	public String resolveDemoOrigin( HttpServletRequest request )
	{
		Object originObj = request.getParameter("origin");

		String origin = "MSTG";
		if ( originObj != null )
		{
			origin = (String) originObj; 
		}
	
		if ( origin.endsWith( CustomerMaintenanceService.BSA_BRAND ) )
			origin = "MBSA";
		else if ( origin.endsWith( CustomerMaintenanceService.BOM_BRAND ) )
			origin = "MBOM";
		else 
			origin = "MSTG";

		return 	origin;
		
	}	 

	
  private boolean checkCardBlocked(String gcisNumber, String cardNum)
	{
		try
		{
			
			CardService cardService = (CardService)ServiceHelper.getBean("mobileCardService");
			Collection colList = cardService.findTempBlockedLockedCards(gcisNumber, cardNum);
			
			
			if (colList != null && colList.size() > 0)
			{
				return true;
			}
		} catch (ResourceException e)
		{
			IBankLog.logTRC("ResourceException Occured in checkCardBlocked:" + e, LostCardHelper.class);
		} catch (BusinessException e)
		{
			IBankLog.logTRC("BusinessException Occured in checkCardBlocked:" + e, LostCardHelper.class);
		}
		return false;
	}
  
  private boolean hasEligibleAcctsForCreditLimitDecrease(List<Account> accountList)
	{
	  boolean hasEligibleCard = false;
		try
		{
			CardService cardService = (CardService)ServiceHelper.getBean("mobileCardService");
			hasEligibleCard = cardService.hasEligibleAcctsForCreditLimitDecrease(accountList);
			
		} catch (Exception e)
		{
			IBankLog.logTRC("Exception Occured in hasEligibleAcctsForCreditLimitDecrease:" + e, LogonHelper.class);
		} 
		return hasEligibleCard;
	}
  
 /* 
  * TODO Review changes for fastfunding code cleanup
  * public FastFundingResp populateFastFundingResp(Customer customer)
	{
		FastFundingResp resp =null;
		
		if (customer.getFastFundingTile() == null){
			return resp;
		}
		
		//find  ACCOUNT INDEX
		Iterator<Account> iterator = customer.getAccounts().iterator();
		int i = -1;
		boolean found = false;
		while (iterator.hasNext() && !found) {
			i++;
			Account anAccount = iterator.next();
			if (anAccount.getAccountId().getAccountNumber().equals(customer.getFastFundingTile().getAccountNumber()) &&
				anAccount.getAccountId().getBsb().equals(customer.getFastFundingTile().getBSBNumber())){
				found = true;
			}
		}
		
		if(!found){
			resp= new FastFundingResp();
			resp.setProductName(customer.getFastFundingTile().getProductName());
			resp.setAccountNumber(customer.getFastFundingTile().getAccountNumber());
			resp.setbSBNumber(customer.getFastFundingTile().getBSBNumber());
			resp.setSalAccountNumber(customer.getFastFundingTile().getSalAccountNumber());
			resp.setSalBSBNumber(customer.getFastFundingTile().getSalBSBNumber());
			resp.setSwitching(customer.getFastFundingTile().getSwitching());
			resp.setSalCredit(customer.getFastFundingTile().getSalCredit());
			resp.setTileStatus(customer.getFastFundingTile().getTileStatus());
			resp.setFunding(customer.getFastFundingTile().getFunding());			
			resp.setAccountIndex(0);
		}else{
			resp= new FastFundingResp();
			resp.setProductName(customer.getFastFundingTile().getProductName());
			resp.setAccountNumber(customer.getFastFundingTile().getAccountNumber());
			resp.setbSBNumber(customer.getFastFundingTile().getBSBNumber());
			resp.setSalAccountNumber(customer.getFastFundingTile().getSalAccountNumber());
			resp.setSalBSBNumber(customer.getFastFundingTile().getSalBSBNumber());
			resp.setSwitching(customer.getFastFundingTile().getSwitching());
			resp.setSalCredit(customer.getFastFundingTile().getSalCredit());
			resp.setTileStatus(customer.getFastFundingTile().getTileStatus());
			resp.setFunding(customer.getFastFundingTile().getFunding());	
			resp.setAccountIndex(i);
		}
		
		return resp;
	}*/
  
  	private int isTapAndPayEligibile(HttpServletRequest request)
	{
  	//	CodesVO codeItem=IBankParams.getCodesData(IBankParams.BRAND_ORIGIN, IBankParams.CONFIGURATION_PROPERTIES,IBankParams.TAPNPAY_SWITCH);
  		
  		CodesVO codeItem=codesCache.getCodes(IBankParams.BRAND_ORIGIN, IBankParams.CONFIGURATION_PROPERTIES,IBankParams.TAPNPAY_SWITCH);
  		if ( codeItem != null )
  			Logger.debug("isTapAndPayEligibile . Switch " + codeItem.getMessage() +  "  " + codeItem.toXml(), this.getClass());

  		
  		
		if(codeItem != null && IBankParams.ON.equalsIgnoreCase(codeItem.getMessage())){
			Cookie cookie = getCookie(request, APP_VER_COOKIE);
	  	Logger.debug("Cookie : " + cookie , this.getClass());

		  	if ( cookie != null && ! StringMethods.isEmptyString(cookie.getValue()))
		  	{
		  		String tempStr = cookie.getValue();
			  	Logger.debug("App Ver Cookie value .. " +tempStr , this.getClass());
		  	  if ( tempStr.indexOf(TAP_N_PAY) >= 0 )
		  	  {
		  	  	return 0;  // phone is Tap and Pay eligible
		  	  }
		  	  else
		  	  {
		  	  	return 1; // do not show the icon
		  	  }
		  	}
		  	return -1; // Not detected
		}else{
			return 1; //DO not show the icon
		}
  		
		
		
	}
  	
  	private int isCookieContainsCustInfo(Cookie cookie)
	{  					
			Logger.debug("Cookie : " + cookie , this.getClass());
		  	if ( cookie != null && ! StringMethods.isEmptyString(cookie.getValue()))
		  	{
		  		String tempStr = cookie.getValue();
			  	Logger.debug("App Ver Cookie value CUST_INFO.. " +tempStr , this.getClass());
		  	  if (tempStr.indexOf(CUST_INFO) >= 0 )
		  	  {
		  	  	return 0;  
		  	  }
		  	  else
		  	  {
		  	  	return 1; 
		  	  }
		  	}
		  	return -1; 
		
	}
  	
  	public boolean isSplashPageCookieFound(HttpServletRequest request,HttpServletResponse response,String encryptedUserID,String version){
	
  		Logger.info("Starting to search for splash page cookie",this.getClass());
  		boolean  isCookieFound = false;
		//response.setContentType("text/html");
		Cookie[] cookies = request.getCookies();
		
		CodesVO codesVo = codesCache.getCodes(IBankParams.DEFAULT_ORIGIN, IBankParams.CONFIGURATION_PROPERTIES, IBankParams.TapAndPayDecomissionSwitch);
		
		boolean googleTapAndPaySwitch=false;
		if(codesVo != null && !IBankParams.ON.equalsIgnoreCase(codesVo.getMessage())){
			googleTapAndPaySwitch = false;
		}else{
			googleTapAndPaySwitch = true;
		}

			
		
		if(googleTapAndPaySwitch){
				if (cookies != null) {
					for (int i = 0; i < cookies.length; i++) {
						
						
						
						if (cookies[i].getName().equals(TAPNPAY_SPLASHPAGE_COOKIE)) {
							Logger.info("Splash Page Cookie Fpund",this.getClass());
							String oldCookieValue = cookies[i].getValue();
							String[] values = oldCookieValue.split(":");
							if (encryptedUserID.equals(values[0])
									&& version.equals(values[1])) {
								cookies[i].setValue(encryptedUserID);
								cookies[i].setMaxAge(640 * 24 * 60 * 60);
								cookies[i].setSecure(true);   
								String serverName = request.getServerName();  
								if (StringMethods.isValidString(serverName)) {
									if (serverName.endsWith(STG_DOMAIN)) {
										cookies[i].setDomain(STG_DOMAIN);
									} else if (serverName.endsWith(BSA_DOMAIN)) {
										cookies[i].setDomain(BSA_DOMAIN);
									} else if (serverName.endsWith(BOM_DOMAIN)) {
										cookies[i].setDomain(BOM_DOMAIN);
									}
									
									
								}
								isCookieFound = true;
								setSplashPageCookie(request,response,encryptedUserID,version);
								Logger.info("Splash Page Cookie Fpund and user is not same",this.getClass());
								break;  
							}
						}
						else if(cookies[i].getName().equals(TAPNPAY_SPLASHPAGE_COOKIE_OLD)){
							Logger.debug("deleting old tap and pay cookie"+cookies[i].getName(), this.getClass());
							deleteOldCookies(request, response, TAPNPAY_SPLASHPAGE_COOKIE_OLD);
							/*cookies[i].setMaxAge(0);
							String oldDomain = getDomainName(request);
							cookies[i].setDomain(oldDomain);
							response.addCookie(cookies[i]);*/
						}
						
						
						
					}
				
			}
		}
		else{
			if (cookies != null) {
				for (int i = 0; i < cookies.length; i++) {
					
					
					
					if (cookies[i].getName().equals(TAPNPAY_SPLASHPAGE_COOKIE_OLD)) {
						Logger.info("Splash Page Cookie Fpund",this.getClass());
						String oldCookieValue = cookies[i].getValue();
						String[] values = oldCookieValue.split(":");
						if (encryptedUserID.equals(values[0])
								&& version.equals(values[1])) {
							cookies[i].setValue(encryptedUserID);
							cookies[i].setMaxAge(640 * 24 * 60 * 60);
							cookies[i].setSecure(true);   
							String serverName = request.getServerName();  
							if (StringMethods.isValidString(serverName)) {
								if (serverName.endsWith(STG_DOMAIN)) {
									cookies[i].setDomain(STG_DOMAIN);
								} else if (serverName.endsWith(BSA_DOMAIN)) {
									cookies[i].setDomain(BSA_DOMAIN);
								} else if (serverName.endsWith(BOM_DOMAIN)) {
									cookies[i].setDomain(BOM_DOMAIN);
								}
								
								
							}
							isCookieFound = true;
							setSplashPageCookie(request,response,encryptedUserID,version);
							Logger.info("Splash Page Cookie Fpund and user is not same",this.getClass());
							break;  
						}
					}
					
					
					
				}
			
		}
		}
		
		
			Logger.info("End search for splash page cookie "+isCookieFound,this.getClass());

			return isCookieFound;
 	}

  	public void setSplashPageCookie(HttpServletRequest request,HttpServletResponse response,String encryptedUserID,String version ) throws ResourceException
	{
  		//if (isTapAndPayEligibile(request) == 0) {
			Cookie cookie = new Cookie(TAPNPAY_SPLASHPAGE_COOKIE,
					encryptedUserID + ":" + version);
			cookie.setMaxAge(640 * 24 * 60 * 60);
			cookie.setSecure(true);
			
			String serverName = request.getServerName();
			String domain = "";
			if (StringMethods.isValidString(serverName)) {
				if (serverName.endsWith(STG_DOMAIN)) {
					// cookie.setDomain(stgeorgeDomain);
					domain = STG_DOMAIN;
				} else if (serverName.endsWith(BSA_DOMAIN)) {
					// cookie.setDomain(banksaDomain);
					domain = BSA_DOMAIN;
				} else if (serverName.endsWith(BOM_DOMAIN)) {
					domain = BOM_DOMAIN;
				}
				
				
				
			}

			cookie.setDomain(domain);
			response.addCookie(cookie);
	//	}
		
	}

	public String isConnectSwitchOn(HttpServletRequest request)
	{
		Cookie cookie = getCookie(request, APP_VER_COOKIE);
		if ( cookie != null && ! StringMethods.isEmptyString(cookie.getValue()))
	  	{
			String tempStr = cookie.getValue();
	  		Logger.debug("App version Cookie value .. " +tempStr , this.getClass());
		  	  if ( tempStr.toUpperCase().indexOf(CONNECT_APP_VER_COOKIE) >= 0)
		  	  {
		  	  	return "ON";  // Connect swtiched on
		  	  }
		  	  else
		  	  {
		  	  	return "OFF"; // Connect switched off
		  	  }
	  	}
	  	return "OFF"; // No app is used..through browser
	}
	
	public boolean isOnboardingPresentInCookie(HttpServletRequest request)
	{
		Cookie cookie = getCookie(request, APP_VER_COOKIE);
		if ( cookie != null && ! StringMethods.isEmptyString(cookie.getValue())){
			String tempStr = cookie.getValue();
	  		Logger.debug("App version Cookie value .. " +tempStr , this.getClass());
	  		
		  	if (tempStr.indexOf(ONBOARDING_COOKIE) >= 0){
		  	  	return true; 
		  	}
		  	else{
		  	  	return false;
		  	}
	  	}
	  	return false; 
	}
	
	/***
	 * For Share BSB and Account Number Check if "Share" attribute is present or not
	 * @param request
	 * @return
	 */
	public boolean isShareBsbAccNumSupported(HttpServletRequest request)
	{
		boolean isShareBsbAccNumSupported = false;
		Cookie cookie = getCookie(request, APP_VER_COOKIE);
		if ( cookie != null && ! StringMethods.isEmptyString(cookie.getValue())){
			String tempStr = cookie.getValue();
			Logger.debug("Share BSB App version Cookie value .. " +tempStr , this.getClass());
			if (tempStr.indexOf(SHARE_BSB_ACC_NUM_COOKIE) >= 0){
				isShareBsbAccNumSupported = true; 
				Logger.debug("Share Attribute is Present. Returning true.", this.getClass());
			}
		}
		return isShareBsbAccNumSupported; 
	}
	
	
	public boolean isECorrespondenceSupported(HttpServletRequest request)
	{
		boolean isECorrespondenceSupported = false;
		Cookie cookie = getCookie(request, APP_VER_COOKIE);
		if ( cookie != null && ! StringMethods.isEmptyString(cookie.getValue())){
			String tempStr = cookie.getValue();
			Logger.info("ECorrespondence App version Cookie value .. " +tempStr , this.getClass());
			if (tempStr.indexOf(ECORRESPONDENCE_COOKIE) >= 0){
				isECorrespondenceSupported = true; 
				Logger.info("PostPdf Attribute is Present. Returning true.", this.getClass());
			}
		}
		return isECorrespondenceSupported; 
	}
	
	
	/***
	 * For android back button to check if the App is 7.0 or above
	 * @param request
	 * @return
	 */
	public boolean isAndroidBackBtnSupported(HttpServletRequest request)
	{
		boolean isAndroidBackBtnSupported = false;

		//20E1GCC - SBGEXP-7954
		String globalWalletSwitch = null;
		CodesVO codesVo = IBankParams.getCodesData(IBankParams.DEFAULT, IBankParams.CONFIGURATION_PROPERTIES, IBankParams.GLOBAL_WALLET_SWITCH);
		if(codesVo != null && null != codesVo.getMessage())
			globalWalletSwitch = codesVo.getMessage();
		
		if (isFeatureSupportedByNative(request, DEVICE_ANDROID) || isFeatureSupportedByNative(request, DEVICE_ANDROID_MOBBANK)) {
			

			Cookie cookie = getCookie(request, APP_VER_COOKIE);
			String tempStr = cookie.getValue();
			Logger.debug("Android App version Cookie value .. " +tempStr , this.getClass());
			String appVersion=StringUtils.substringBetween(tempStr,"/","(");
			try{
				if (appVersion != null && (Double.parseDouble(appVersion)>=ANDROID_BACKBTN_APPVERSION)){
					isAndroidBackBtnSupported = true; 
					Logger.debug("App later than 7.0", this.getClass());
				}
			}
			catch (NumberFormatException e) {
				Logger.debug("Appversion not supported", this.getClass());
			}
		}else if(IBankParams.isSwitchOn(IBankParams.COMPLETE_FREEDOM_ROUTE_SWITCH) ||
					IBankParams.isSwitchOn(IBankParams.INCENTIVE_SAVER_ROUTE_SWITCH) ||
					(null != globalWalletSwitch && (globalWalletSwitch.equals(IBankParams.ON) || globalWalletSwitch.equals(IBankParams.PILOT)))){
			isAndroidBackBtnSupported = true;
			Logger.debug("Ios app and any one of Complete Freedom route or Account Details Route or Incentive Saver Route Switch or Global Wallet switch is on", this.getClass());
		} 
		return isAndroidBackBtnSupported; 
	}
	
	/***
	 * For iOS old version to check if the iOS App is 9.28 or blow
	 * @param request
	 * @return
	 */
	public boolean isIOSOldVersion(HttpServletRequest request) {
		
		boolean isCSHSafiOldiOSAppVersion = false;

		//21E1CSHSAFI 
		Cookie cookie = getCookie(request, APP_VER_COOKIE);
		String tempStr = cookie.getValue();
		Logger.info("iOS App version Cookie value .. " +tempStr , this.getClass());
		String appVersion=StringUtils.substringBetween(tempStr,"/","(");
		try{
			if (appVersion != null && (Double.parseDouble(appVersion)<=IOS_CSHSAFIOLD_APPVERSION)){
				isCSHSafiOldiOSAppVersion = true; 
				Logger.info("App lesse than 9.28", this.getClass());
			}
		}
		catch (NumberFormatException e) {
			Logger.info("Appversion not supported", this.getClass());
		}
		return isCSHSafiOldiOSAppVersion;
	}
	
	public void createSafiCookieWithDifferentDomain(HttpServletRequest request, HttpServletResponse response, String origin) {
		Cookie pmDPCookie = getCookie(request, SafiConstants.MOBILE_PM_DP_COOKIE);
		Cookie dsPrmCookie =  getCookie(request, SafiConstants.MOBILE_DS_PRM_COOKIE);
		if(null != pmDPCookie) {
			Logger.info("Found pm_dp Cookie " + pmDPCookie.getValue(), LogonHelper.class);
			setDomainAndAddCompassCookie(origin, request, response, SafiConstants.MOBILE_PM_DP_COOKIE, pmDPCookie.getValue());
		}
		if(null != dsPrmCookie) {
			Logger.info("Found ds_prm Cookie " + dsPrmCookie.getValue(), LogonHelper.class);
			setDomainAndAddCompassCookie(origin, request, response, SafiConstants.MOBILE_DS_PRM_COOKIE, dsPrmCookie.getValue());
		}
	}
	
	public boolean isFeatureSupportedByNative(HttpServletRequest request, String featureName) {
		Cookie cookie = getCookie(request, APP_VER_COOKIE);
		if (cookie != null && !StringMethods.isEmptyString(cookie.getValue())) {
			String tempStr = cookie.getValue();
			if (tempStr.indexOf(featureName) >= 0 || tempStr.toUpperCase().indexOf(featureName) >= 0)
				return true;
		}
		return false;
	}


	public boolean isCordovaSupported(HttpServletRequest request) {
		Cookie cookie = getCookie(request, APP_VER_COOKIE);
		if (cookie != null && !StringMethods.isEmptyString(cookie.getValue())) {
			String tempStr = cookie.getValue();
			if (tempStr.indexOf("_contactLookup") >= 0)
				return true;
		}
		return false;
	}	

	public boolean isCardlessTokenSupported(HttpServletRequest request) {
		Cookie cookie = getCookie(request, APP_VER_COOKIE);
		if (cookie != null && !StringMethods.isEmptyString(cookie.getValue())) {
			String tempStr = cookie.getValue();
			if (tempStr.indexOf("_cardlesstoken") >= 0)
				return true;
		}
		return false;
	}
	
	public BTSuperSearchResp populateBTSuperSearchResp(Customer customer) {
		BTSuperSearchResp resp =null;
		
		BTSuperSearchTile btSuperSearchTile = customer.getBtSuperSearchTile();
		if (btSuperSearchTile == null){
			return resp;
		} else {
			resp = new BTSuperSearchResp();
			resp.setAccountIndex(btSuperSearchTile.getAccountIndex());
			resp.setCombine(btSuperSearchTile.getCombineSuper());
			resp.setNotify(btSuperSearchTile.getNotifyEmployer());
			resp.setCustomise(btSuperSearchTile.getCustomiseInsurance());
			resp.setMinimiseTile(btSuperSearchTile.isMinimizeTile());
			return resp;
		}
			
	}
	
	private boolean isOnboardingFlow(MobileSession mobileSession){
		
		if(mobileSession.getOnboardingVO()!=null){
			Logger.debug("Onboarding Ticket : " + mobileSession.getOnboardingVO().getTicket(), this.getClass());
		}
		
		return mobileSession.getOnboardingVO() != null && !StringMethods.isEmptyString(mobileSession.getOnboardingVO().getTicket());
	}
	
	public long getInsertionPointCode(String insertionPointString){
		List<CodesVO> CodesVOList = (List<CodesVO>) IBankParams.getCodesDataList(IBankParams.DEFAULT_ORIGIN, ServicetationConstants.CD_CATEGORY_SERVICETATION_INSERTION_PT);
		long insertionPointValue = 0;
		for(CodesVO codesVO : CodesVOList){
			if(codesVO.getMessage().trim().equalsIgnoreCase(insertionPointString)){
				if(StringMethods.isValidString(codesVO.getCode())){
					insertionPointValue = Long.parseLong(codesVO.getCode());
					break;
				}
			}
		}
		if(insertionPointValue == 0){
			Logger.warn("NO match found in RELEASECODES table for the insertion point "+insertionPointString, this.getClass());
		}
		return insertionPointValue;
	}
	
	public ServiceStationResp populateServiceStationResp(ServiceStationVO serviceStationVO)
	{
		ServiceStationResp resp = null;
		if(null!=serviceStationVO)
		{
			resp=new ServiceStationResp();
			if(null!=serviceStationVO.getContent())
			{
			   resp.setContent(serviceStationVO.getContent());
			}			
			if(null!=serviceStationVO.getServiceStationMsg())
			{
				resp.setInsertionPointValue(new Long(serviceStationVO.getServiceStationMsg().getInsertionPointValue()).toString());	
			}
			if(null!=serviceStationVO.getSubject())
			{
			   resp.setSubject(serviceStationVO.getSubject());
			}
			if(null!=serviceStationVO.getServiceStationMsg().getFunctionLink())
			{
			   resp.setFunctionLink(serviceStationVO.getServiceStationMsg().getFunctionLink());
			}
			if(null!=serviceStationVO.getServiceStationMsg().getMessageAction())
			{
			   resp.setMessageAction(serviceStationVO.getServiceStationMsg().getMessageAction());
			}
			if(null!=serviceStationVO.getServiceStationMsg())
			{
				resp.setMsgID(new Long(serviceStationVO.getServiceStationMsg().getMsgID()).toString());	
			}
		}		
		return resp;
	}
	
	public OnboardingTileResp populateOnboardingTileResp(Customer customer){
		OnboardingTileResp resp = new OnboardingTileResp();
		
		Iterator<Account> iterator = customer.getAccounts().iterator();
		int i = -1;
		while (iterator.hasNext()){
			i++;
			Account anAccount = iterator.next();
			if (anAccount.getAccountId().getAccountNumber().equals(customer.getObTileVO().getAccountNumber()) && anAccount.getAccountId().getBsb().equals(customer.getObTileVO().getBsbNumber())){
				resp.setAccountIndex(i);
				break;
			}
		}
		
		resp.setAccountNumber(customer.getObTileVO().getAccountNumber());
		resp.setProductName(customer.getObTileVO().getProductName());
		resp.setViewStatus(customer.getObTileVO().getViewStatus());
		resp.setTileStatus(customer.getObTileVO().getStatus());
		resp.setObSegments(obTileHelper.populateOBSegmentResp(customer.getObTileVO().getSelectedSegmentList(), resp.getObSegments()));
		return resp;
	}
	
	public boolean isTempBlockedCard(String gcisNum, String origin)
	{
		
		if( ! IBankParams.isSwitchOn(origin, IBankParams.LOCK_UNLOCK_SWITCH))
		{
			return false;
		}  
		
		au.com.stgeorge.ibank.businessobject.CardService cardService = (au.com.stgeorge.ibank.businessobject.CardService)ServiceHelper.getBean("cardService");
		return cardService.checkTempBlockedCards(gcisNum);
		
	}
	
	public String getOrigin(MobileSession mobileSession, HttpServletRequest httpServletRequest )
	{
		String origin = mobileSession.getOrigin() ;
		if (StringMethods.isEmptyString(origin))
		{
			origin = resolveOrigin(httpServletRequest);
		}
		if ( StringMethods.isEmptyString( origin ) )
		{
			origin = "MSTG";
		}
		return origin;
	}
	
	private void logAppversionCookie(MobileSession mobileSession , Cookie cookie )
	{
		try
		{
			String sessDeviceId =  mobileSession.getDeviceID();
			UserAgentVO userAgentVO = mobileSession.getUserAgentWS();
			StringBuffer strBuf = new StringBuffer(APP_VER_COOKIE);
			if ( cookie == null   )
			{
				if ( mobileSession.getCustomer() != null )
				 strBuf.append(" NOT SET. for Gcis : " + mobileSession.getCustomer().getGcis());
				
				strBuf.append(" ( AppVersion Cookie Not set )Device ID : " +sessDeviceId );
				if ( userAgentVO != null )
					strBuf.append(" User Agent :  " +userAgentVO.toCSV());
				Logger.info(strBuf , this.getClass());
			}
			else
			{
				if ( mobileSession.getCustomer() != null )
					strBuf.append(" Gcis : " + mobileSession.getCustomer().getGcis());
				
				strBuf.append(" Device ID : " +sessDeviceId );
				strBuf.append(" Cookie : " +cookie.getValue() );
		
				if ( userAgentVO != null )
					strBuf.append(" User Agent :  " +userAgentVO.toCSV());
				Logger.info(strBuf , this.getClass());
			}
		}
		catch ( Exception e)
		{
			Logger.error( " error in logAppversionCookie ", e,  this.getClass());
		}
	}	
	
	public String toDigitalSecurityLog(LogonReq req,String deviceID){
	    StringBuffer sb = new StringBuffer();
	    try
	    {
	    	 sb.append(DigitalSecLogger.MOBILE_DEVICE_ID)
	    	    .append(DigitalSecLogger.DELIMITER_COLON)
	    	    .append(deviceID)
		    	.append(DigitalSecLogger.DELIMITER_COMMA)
		    	.append(DigitalSecLogger.ENTERED_CAN)
	    	    .append(DigitalSecLogger.DELIMITER_COLON);
	    	    if(null!=req.getAccessNumber())
	    	       sb.append("True");
	    	    else
	    	    	sb.append("False");
		    sb.append(DigitalSecLogger.DELIMITER_COMMA)
		    	.append(DigitalSecLogger.ENTERED_PASSWORD)
	    	    .append(DigitalSecLogger.DELIMITER_COLON);
	    	    if(null!=req.getPassword())
	    	    	sb.append("True");
	    	    else
	    	    	sb.append("False");
		    sb.append(DigitalSecLogger.DELIMITER_COMMA)
		    	.append(DigitalSecLogger.ENTERED_SECURITY_NUMBER)
	    	    .append(DigitalSecLogger.DELIMITER_COLON);
	    	    if(null!=req.getSecurityNumber())    	    	
	    	    	sb.append("True");
	    	    else
	    	    	sb.append("False");
		      sb.append(DigitalSecLogger.DELIMITER_COMMA)
	    	    .append(DigitalSecLogger.ENTERED_FINGERPRINT)
	    	    .append(DigitalSecLogger.DELIMITER_COLON)
	    	    .append("False");
		}	    		         
	    catch (Exception e) 
	    {
	    	Logger.debug("EVINFO(): Exception while creating data for Fraud Logging::", EVInfo.class);
		}	    
	    return sb.toString();
	}
	
	public String getCommonLogData(LogonReq req,IBankCommonData ibankCommonData, String accessNumber) {

		StringBuffer logBuffer = new StringBuffer();
		String can=null;
		String gcisNumber=null;
		try {
			logBuffer.append(DigitalSecLogger.SESSION_ID)
					.append(DigitalSecLogger.DELIMITER_COLON)
					.append(ibankCommonData.getSessionId())
					.append(DigitalSecLogger.DELIMITER_COMMA);
			
			if(null!=ibankCommonData.getUser())
			{
				can = ibankCommonData.getUser().getUserId();
				if (ibankCommonData.getUser().getUserId() != null) {
					can = can.replaceAll(DigitalSecLogger.USERID_ALLOWED_SP_CHARS,
							DigitalSecLogger.BLANK_CHAR);
				}
				gcisNumber=ibankCommonData.getUser().getGCISNumber();
			}
			else
			{
				if(null!=accessNumber)// saved can wrong credential scenario
				{
					can=accessNumber;
				}
				else
				{
					can=req!= null? req.getAccessNumber():"";
				}				
				gcisNumber="";
			}

			logBuffer.append(DigitalSecLogger.CAN)
					.append(DigitalSecLogger.DELIMITER_COLON).append(can)
					.append(DigitalSecLogger.DELIMITER_COMMA)
					.append(DigitalSecLogger.GCIS_NUMBER)
					.append(DigitalSecLogger.DELIMITER_COLON)
					.append(gcisNumber)
					.append(DigitalSecLogger.DELIMITER_COMMA)
					.append(DigitalSecLogger.ORIGIN)
					.append(DigitalSecLogger.DELIMITER_COLON)
					.append(ibankCommonData.getOrigin())
					.append(DigitalSecLogger.DELIMITER_COMMA)
					.append(DigitalSecLogger.IP_ADDRESS)
					.append(DigitalSecLogger.DELIMITER_COLON)
					.append(ibankCommonData.getIpAddress());
			
			
			
		} catch (Exception e) {
			// consume error, so that main feature is not impacted
		}
		return logBuffer.toString();
	}
	
	public String getExpiryDateForCRSPrompt(int noOfDays){
		
		Logger.info( "Inside getExpiryDateForCRSPrompt:>> "+noOfDays,  this.getClass());
		noOfDays=noOfDays-1;
		Logger.info( "Inside getExpiryDateForCRSPrompt: after>> "+noOfDays,  this.getClass());
		Date expiryPeriod=null;
		String expiryPeriodstr="";
        DateFormat dateFormat = new SimpleDateFormat("dd MMM yyyy");                                                                                                                  
       
        Calendar calExp = Calendar.getInstance();
		calExp.set(Calendar.HOUR_OF_DAY,0);
		calExp.set(Calendar.MINUTE,0);
		calExp.set(Calendar.SECOND,0);
		calExp.clear(Calendar.MILLISECOND);                
		calExp.add(Calendar.DATE, noOfDays);
		expiryPeriod = calExp.getTime();
		expiryPeriodstr=dateFormat.format(expiryPeriod);
		Logger.info( "Inside getExpiryDateForCRSPrompt: Return value:>> "+expiryPeriodstr,  this.getClass());
		return expiryPeriodstr;
	}
	
	public String convertExpiryDateForCRSPrompt(Date expiryDate){
		String expiryPeriodstr="";
        DateFormat dateFormat = new SimpleDateFormat("dd MMM yyyy");                                                                                                                  
		expiryPeriodstr=dateFormat.format(expiryDate);
		return expiryPeriodstr;
	}
	
	public void setServiceBadgeCookie(HttpServletRequest request, HttpServletResponse response,String userId) throws ResourceException, BusinessException
	{
		try {
			Cookie cookie = getCookie(request,SERVICE_BADGE_COOKIE);
			String domain = getDomainName(request);
			CodesVO codeItem=IBankParams.getCodesData(IBankParams.DEFAULT_ORIGIN, IBankParams.SERVICE_BADGING_COOKIE,IBankParams.SERVICE_BADGING_VERSION);
			Integer cookieVersion = Integer.parseInt(codeItem.getMessage());
			String cookieValue = userId +":" + cookieVersion ;
			setCookie(SERVICE_BADGE_COOKIE,cookieValue, domain, cookie, response, true);
		}
		catch( Exception e) {
			Logger.error("Error in setting service badge cookie", this.getClass());
			throw new BusinessException(10000000);
		}
		
	}
	
	
	public boolean isServiceBadgingCookieExists(HttpServletRequest request, HttpServletResponse response,String encryptedUserID) {
		boolean isCookieFound = false;
		//response.setContentType("text/html");
		Cookie[] cookies = request.getCookies();
		if (cookies != null) {
			for (int i = 0; i < cookies.length; i++) {
				String oldCookieValue = cookies[i].getValue();
				if(oldCookieValue == null) {
					return false;
				}
				String[] values = oldCookieValue.split(":");
				if (values != null && (values.length > 0 && encryptedUserID.equals(values[0])) && (values.length > 1 && SERVICE_BADGE_COOKIE_VERSION.equals(values[1]))){
						isCookieFound = true;
					}
				}
			}
		return isCookieFound;
	} 
	
	public LoanApplicationDetail populateLoanApplicationDetail(IBankCommonData ibankCommonData, IMBResp serviceResponse ){
		try{
			Logger.debug("Inside populateLoanApplicationDetail",  this.getClass());
			List<GhostTileResp> ghostTileList=new ArrayList<GhostTileResp>();
			GhostTileResp ghostTileResp = new GhostTileResp();
		 	LoanApplicationDetail loanAppDetail = loanApplService.getLoanApplicationDetails(ibankCommonData);
		 	DateFormat dateFormat = new SimpleDateFormat("dd MMM yyyy"); 
		 	IBankRefershParams ibankRefreshParams = (IBankRefershParams) ServiceHelper.getBean("ibankRefreshParams");
			if(loanAppDetail != null){
				Logger.info("Loan Application details for ghost tile:" + loanAppDetail.getSourceApplRefNum(), getClass());
			//	if(checkEligibilityForZoomTile(loanAppDetail, ibankCommonData)){
					if(null!=loanAppDetail.getApplExpDate())
				 	{
			 			if(null!=loanAppDetail.getNextStepInd() && 
			 					(loanAppDetail.getNextStepInd().longValue()==LoanAppConstants.NEXT_STEP_INDICATOR_7 
			 						|| loanAppDetail.getNextStepInd().longValue()==LoanAppConstants.NEXT_STEP_INDICATOR_8)
			 								|| checkLVSwitchAndNextStep(loanAppDetail) 
			 									|| loanApplService.checkZoomEligibility(loanAppDetail) || loanApplService.isEContractAccepted(loanAppDetail))
			 			{
			 				ghostTileResp.setExpiryDate(null);
			 		    }
			 			else{
			 				ghostTileResp.setExpiryDate(dateFormat.format((loanAppDetail.getApplExpDate())));
			 			}
				 	}
	
				 	ghostTileResp.setTileType(LoanAppConstants.TILE_TYPE_EFINANCE);
				 
				 		if(null!= loanAppDetail.getProductType()){
							Logger.debug("product Type : "+loanAppDetail.getProductType(),this.getClass());
							ghostTileResp.setProductType(LoanProdTypeEnum.valueOf(loanAppDetail.getProductType()).getProductName());
						}
	
						
					 	if(null!=loanAppDetail.getSourceApplStatus() && loanAppDetail.getSourceApplStatus().equalsIgnoreCase(LoanAppConstants.SOURCE_APPL_INCOMPLETE_STATUS)){
					 		ghostTileResp.setTileStatusDesc(LoanAppConstants.INCOMPLETE_STATUS);
					 		ghostTileResp.setIncompleteAppl(true);
					 	}else{
					 		ghostTileResp.setTileStatusDesc(getEFinanceTileStatusDesc(String.valueOf(loanAppDetail.getNextStepInd())));
					 		ghostTileResp.setIncompleteAppl(false);
					 		// Added for IV - 19E1
					 		if((IBankParams.isSwitchOn(IBankParams.IV_SWITCH) && 
					 				null!=loanAppDetail.getNextStepInd() && (loanAppDetail.getNextStepInd() == 1 || loanAppDetail.getNextStepInd()==2))){
			                	ghostTileResp.setTileStatusDesc(getEFinanceTileStatusDesc(loanAppDetail)); 
			                }
					 		if(ibankRefreshParams.isLVSwitchOn()){
					 			if(!StringMethods.isEmptyString(loanAppDetail.getLvRequired()) && loanAppDetail.getLvRequired().equalsIgnoreCase("Y")){
					 				ghostTileResp.setTileStatusDesc(getLVGhostTileDesc(loanAppDetail)); 
					 			}
					 		}
					 		
					 		//Added for ZOOM
					 		if(loanApplService.checkZoomEligibility(loanAppDetail)){
					 			ghostTileResp.setTileStatusDetails(LoanAppConstants.EFINANCE_TILE_STATUS_ECONTRACT);
					 			ghostTileResp.setTileType(LoanAppConstants.TILE_TYPE_ECONTRACT);
			                }
					 		
					 		
					 		if(ibankRefreshParams.isEContractSwitchOn(ibankCommonData.getOrigin()) && loanApplService.isEContractAccepted(loanAppDetail)){
					 			ghostTileResp.setTileStatusDesc(LoanAppConstants.TILE_STATUS_ECONTRACT_ACCEPTED);
					 			ghostTileResp.setTileType(LoanAppConstants.TILE_TYPE_ECONTRACT_ACCEPTED);
			                }
					 	}
					 	ghostTileList.add(ghostTileResp);	 	
					 	if(((LogonResp) serviceResponse).getCustomer() != null && null!= ghostTileResp){
							Logger.debug("Setting the Ghost tile response in LogonResp::", this.getClass());
							((LogonResp) serviceResponse).getCustomer().setGhostTiles(ghostTileList);
						}
				}
		// 	}
			return loanAppDetail;
		}
		catch(Exception ex){
			Logger.error("Eception caught while populating loan application details.", ex, this.getClass());
		    return null;
		}		
	}
	
	private boolean checkLVSwitchAndNextStep(LoanApplicationDetail loanAppStatusDetails){
		IBankRefershParams ibankRefreshParams = (IBankRefershParams) ServiceHelper.getBean("ibankRefreshParams");
        if(ibankRefreshParams.isLVSwitchOn() && (loanAppStatusDetails.getNextStepInd()!=null && loanAppStatusDetails.getNextStepInd().longValue()==LoanAppConstants.NEXT_STEP_INDICATOR_12)){
            return true;
        }
        return false;
    }
	
	public void populateHomeLoanGhostTile(IBankCommonData ibankCommonData, IMBResp serviceResponse ){
		try{
			Logger.debug("Inside populateHomeLoanGhostTile",  this.getClass());
			List<GhostTileResp> ghostTileList=null;
			DashBoard dashboard=null;
			int count=0;
			List<Application> appList=null;
			ghostTileList=((LogonResp)serviceResponse).getCustomer().getGhostTiles();
			if(ghostTileList==null){
				ghostTileList=new ArrayList<GhostTileResp>();
				((LogonResp) serviceResponse).getCustomer().setGhostTiles(ghostTileList);
			}
	
			GhostTileResp ghostTile = null;
		 	appList = mortgageService.getLoanDetailsForGhostTile(ibankCommonData.getCustomer().getGcis());
		 	
		 	if(appList.size()>1){
		 		ghostTile = new GhostTileResp();
		 		ghostTile.setTileType(LoanAppConstants.TILE_TYPE_MORTGAGE_MULTIPLE);
		 		ghostTile.setProductType(LoanAppConstants.HOMELOAN_LOAN_PRODUCT_TYPE);
		 		ghostTile.setTileStatusDesc(LoanAppConstants.HOMELOAN_LOAN_TILE_STATUS_MULTIPLE_APP_DESC);
		 		ghostTile.setTileStatusDetails(LoanAppConstants.HOMELOAN_LOAN_TILE_STATUS_DETAILS_MULTIPLE_APPLICATIONS);
		 	}
		 	else if(appList.size()==1){
		 		ghostTile = new GhostTileResp();
		 		ghostTile.setTileType(LoanAppConstants.TILE_TYPE_MORTGAGE);
		 		ghostTile.setProductType(LoanAppConstants.HOMELOAN_LOAN_PRODUCT_TYPE);
		 		Application application=appList.get(0);
		 		if(null!=application){
		 			dashboard=application.getDashboard();
		 			if(dashboard.isPersonalDetailsStatusInd()){
		 				count++;
		 			}
		 			if(dashboard.isLoanTypeStatusInd()){
		 				count++;
		 			}
		 			if(dashboard.isAssetStatusInd()){
		 				count++;
		 			}
		 			if(dashboard.isIncomeStatusInd()){
		 				count++;
		 			}
		 			if(dashboard.isLiabilityStatusInd()){
		 				count++;
		 			}
		 			if(dashboard.isExpenseStatusInd()){
		 				count++;
		 			}
	 				if(null!=application.getLoanType() && application.getLoanType().getLoanType().equalsIgnoreCase(LoanAppConstants.HOMELOAN_LOAN_TYPE_NEW_PROPERTY)){
	 					ghostTile.setTileStatusDesc(LoanAppConstants.HOMELOAN_LOAN_TILE_STATUS_DESC_PURCHASE);
	 				}
	 				if(null!=application.getLoanType() && application.getLoanType().getLoanType().equalsIgnoreCase(LoanAppConstants.HOMELOAN_LOAN_TYPE_REFINANCE)){
	 					ghostTile.setTileStatusDesc(LoanAppConstants.HOMELOAN_LOAN_TILE_STATUS_DESC_REFINANCE);
	 				}

		 			if(count <6){
		 				ghostTile.setTileStatusDetails(LoanAppConstants.HOMELOAN_LOAN_TILE_STATUS_DETAILS);
		 			}
		 			if(count==6){
		 				ghostTile.setTileStatusDetails(LoanAppConstants.HOMELOAN_LOAN_TILE_STATUS_DETAILS_READY_TO_SUBMIT);
		 			}
		 		}
		 	}
		 	if(null!=ghostTile){
		 		ghostTileList.add(ghostTile);
		 	}
		 	else
		 	{
		 		ghostTile = populateDMPostSubmitTile(ibankCommonData);
		 		if ( ghostTile != null )
		 		{
		 			ghostTileList.add(ghostTile);
		 		}
		 	}
		 	
		  if(((LogonResp) serviceResponse).getCustomer() != null && null!= ghostTile){
					Logger.debug("Setting the Home Loan Ghost tile response in LogonResp::", this.getClass());
					((LogonResp) serviceResponse).getCustomer().setGhostTiles(ghostTileList);	
				}
		}
		catch(Exception ex){
			Logger.error("Exception caught while populating home loan application details.", ex, this.getClass());
		}		
	}
	
	private String getEFinanceTileStatusDesc(String tileStatusCode)
	{			
		String eFinanceTileStatusDesc=null;
		List<CodesVO> codesVOList = (List<CodesVO>)IBankParams.getCodesDataList(IBankParams.EFINANCE_NEXT_STEP_HEADER);
		for(CodesVO codeVO : codesVOList){		
			if(null != codeVO && null != codeVO.getCode()){
				if(codeVO.getCode().contains(tileStatusCode)){
					eFinanceTileStatusDesc=codeVO.getMessage();
				}
			}
		}				
		return eFinanceTileStatusDesc;
	}
	
	// Added for IV - 19E1
	private  String getEFinanceTileStatusDesc(LoanApplicationDetail loanApplicationDetail) {
			String eFinanceTileStatusDesc=null;
			CodesVO codesVO = null;
			if(null!=loanApplicationDetail.getNextStepInd() && loanApplicationDetail.getNextStepInd()==1) { 
					if(loanApplicationDetail.getProductType().equals(LoanProdTypeEnum.CRA.getProductCode()) ||
							loanApplicationDetail.getProductType().equals(LoanProdTypeEnum.OVD.getProductCode()) ||
							loanApplicationDetail.getProductType().equals(LoanProdTypeEnum.GSL.getProductCode())){
					codesVO = IBankParams.getCodesData(IBankParams.DEFAULT_ORIGIN, IBankParams.EFINANCE_NEXT_STEP_HEADER, String.valueOf(LoanAppConstants.NEXT_STEP_HEADER_VERIFY_YOUR_INCOME));
					
				 } 
				 else if (loanApplicationDetail.getProductType().equals(LoanProdTypeEnum.PLA.getProductCode())){
						codesVO = IBankParams.getCodesData(IBankParams.DEFAULT_ORIGIN, IBankParams.EFINANCE_NEXT_STEP_HEADER, String.valueOf(LoanAppConstants.NEXT_STEP_HEADER_VERIFY_YOUR_INFORMATION));						
				}
			}
			else if(null!=loanApplicationDetail.getNextStepInd() && loanApplicationDetail.getNextStepInd()==2) {
				if (loanApplicationDetail.getProductType().equals(LoanProdTypeEnum.PLA.getProductCode())){
					codesVO = IBankParams.getCodesData(IBankParams.DEFAULT_ORIGIN, IBankParams.EFINANCE_NEXT_STEP_HEADER, String.valueOf(LoanAppConstants.NEXT_STEP_HEADER_RECEIVED_VERIFICATION_DOCUMENTS));						
				}
				else if(loanApplicationDetail.getProductType().equals(LoanProdTypeEnum.CRA.getProductCode()) ||
						loanApplicationDetail.getProductType().equals(LoanProdTypeEnum.OVD.getProductCode()) ||
						loanApplicationDetail.getProductType().equals(LoanProdTypeEnum.GSL.getProductCode())){
				codesVO = IBankParams.getCodesData(IBankParams.DEFAULT_ORIGIN, IBankParams.EFINANCE_NEXT_STEP_HEADER, String.valueOf(loanApplicationDetail.getNextStepInd()));
				} 
			}				
			
			if (codesVO != null){
				eFinanceTileStatusDesc=codesVO.getMessage();
			}
		return eFinanceTileStatusDesc;	
	}
	
	// Added for LV - 19E4// LVReqd = Y
		private  String getLVGhostTileDesc(LoanApplicationDetail loanApplicationDetail) {
				String ghostTileDesc=null;
				CodesVO codesVO = null;
				
				String code = String.valueOf(loanApplicationDetail.getNextStepInd());
				
				if(null!=loanApplicationDetail.getNextStepInd() && 
						(loanApplicationDetail.getNextStepInd()==1 || 
							loanApplicationDetail.getNextStepInd()==10 || 
								loanApplicationDetail.getNextStepInd()==12)){
					code = code+"LV";
				}
				
				codesVO = IBankParams.getCodesData(IBankParams.DEFAULT_ORIGIN, IBankParams.EFINANCE_NEXT_STEP_HEADER, code);
				if (codesVO != null){
					ghostTileDesc=codesVO.getMessage();
				}
				return ghostTileDesc;	
			}
	
	public static boolean isSafiLogonSwitchOn(String origin) throws BusinessException{

		return IBankParams.isSwitchOn(origin, IBankParams.SAFI_LOGON_SWITCH);
	}
	
	// Added for SBGEXP-3394 - SAFI switch, Throttle and Heartbeat check
	public static boolean isSafiTTSwitchOn(String origin) throws BusinessException{

		return IBankParams.isSwitchOn(origin, IBankParams.SAFI_TELEGRAPHIC_TRANSFER_SWITCH);
	}
	
	// Added for SBGEXP-3394 - SAFI switch, Throttle and Heartbeat check
	public static boolean isSafiBPaySwitchOn(String origin) throws BusinessException{

		return IBankParams.isSwitchOn(origin, IBankParams.SAFI_BPAY_SWITCH);
	}	
	
	// Added SafiThirdPartyPayment  - SAFI switch, Throttle and Heartbeat check
	public static boolean isSafiTPSwitchOn(String origin) throws BusinessException{
		return IBankParams.isSwitchOn(origin, IBankParams.SAFI_THIRD_PARTY_TRANSFER_SWITCH);
	}
	
	/**
	 * isNativeJSInterfaceSwitchON
	 * This switch is used to control the inclusion of NativeJSInterface for native app
	 * @return
	 * @throws BusinessException
	 */
	public static boolean isNativeJSInterfaceSwitchON() throws BusinessException{
		return IBankParams.isNativeJSInterfaceSwitchON();
	}
	
	  //18E4 : Safi changes - forensic logs
		public String toDigitalSecuritySafiLog(SafiForensicInfo safiForensicInfo){
			
			StringBuffer sb = new StringBuffer();
		    try
	        {
		    	if(null!= safiForensicInfo){
		    		if(null!= safiForensicInfo.getSafiSdkDevicePrint()){
		    			sb.append(DigitalSecLogger.SAFI_SDK_DEVICE_PRINT)
		    			.append(DigitalSecLogger.DELIMITER_COLON).append(safiForensicInfo.getSafiSdkDevicePrint()).append(DigitalSecLogger.DELIMITER_COMMA);
		    		}					
					sb.append(DigitalSecLogger.SAFI_RULE_NAME).append(DigitalSecLogger.DELIMITER_COLON)
					.append(DigitalSecLogger.DOUBLE_QUOTE).append(safiForensicInfo.getSafiRuleName()).append(DigitalSecLogger.DOUBLE_QUOTE)
					.append(DigitalSecLogger.DELIMITER_COMMA).append(DigitalSecLogger.SAFI_RISK_SCORE)
					.append(DigitalSecLogger.DELIMITER_COLON).append(safiForensicInfo.getSafiRiskScore());
		    	}
	           
	        }                          
	        catch (Exception e) 
	        {
	          Logger.debug("Logon Helper(): Exception while creating data for Fraud Logging::", LogonHelper.class);
	        }         
	        return sb.toString();
		}
		
		
		public boolean  isAndroidMobBankDeviceInAppVer(HttpServletRequest request){
		
				
				
				Cookie cookie = getCookie(request, APP_VER_COOKIE);
	  	Logger.debug("Cookie : " + cookie , this.getClass());
	  	
		  	if ( cookie != null && ! StringMethods.isEmptyString(cookie.getValue()))
		  	{
		  		String tempStr = cookie.getValue();
			  	Logger.debug("App Ver Cookie value .. " +tempStr , this.getClass());
		  	  if ( tempStr.toUpperCase().indexOf(DEVICE_ANDROID_MOBBANK) >= 0 )
		  	  {
		  	  	return true;  // phone is Android 
		  	  }
		  	  else
		  	  {
		  	  	return false; // phone is not Android 
		  	  }
		  	}
		  	return false; // phone is not Android 
				
				
				
				
		}
	
		private Boolean populateCCClosureTile (Account account){
			CreditCardAccount ccAccount = (CreditCardAccount) account;
		if ("Z".equalsIgnoreCase(ccAccount.getBlockCode()) || (!IBankParams.isDisplayOBlockCreditCardSwitchOn()
				&& "O".equalsIgnoreCase(ccAccount.getBlockCode()))) {
			if (ccAccount.getCreditLimit().compareTo(ccAccount.getAvailableBalance()) > 0) {
				return true;
			}
		}
			return false;
		}
		
		private Boolean isTransactionAccountPresent(List<Account> accounts){
			if(accounts!=null && accounts.size()>0){
				for (Account account : accounts) {
					if(Account.DDA.equalsIgnoreCase(account.getAccountId().getApplicationId())){
						return true;
					}
				}
			}
			return false;
		}
		private Boolean populateSBlockCard (Account account){
			CreditCardAccount ccAccount = (CreditCardAccount) account;
			if(ccAccount.getBlockCode()!=null){
				if("S".equalsIgnoreCase(ccAccount.getBlockCode())){
						return true;										
	            }
			}
			return false;
		}
		
		private Boolean populateTempReplacementCard (Account account){
			CreditCardAccount ccAccount = (CreditCardAccount) account;
			if(ccAccount.getBlockCode()!=null){
				if("J".equalsIgnoreCase(ccAccount.getBlockCode()) && ("Q".equalsIgnoreCase(ccAccount.getAccountId().getAcctStatus()))){ 
						return true;										
	            }
			}
			return false;
		}
		
		private Boolean populateReplacementCard (Account account){
			CreditCardAccount ccAccount = (CreditCardAccount) account;
			if(ccAccount.getBlockCode()!=null){
				if("J".equalsIgnoreCase(ccAccount.getBlockCode()) && !("Q".equalsIgnoreCase(ccAccount.getAccountId().getAcctStatus()))){
						return true;										
	            }
			}
			return false;
		}
		
		
		/*
		 * 19E4 Changes : This method invokes CPCServiceImpl to fetch the NPP eligible NPP accounts for pay to pay ID flow
		 * 
		 */
		private void setFromAccountNPPEligibility(final List<Account> fromAccountList,final List<au.com.stgeorge.mbank.model.common.AccountResp> mbAccountList){
			
			Logger.debug("LogonHelper.setFromAccountNPPEligibility(): Start", this.getClass());
			
			//check from account eligibility from CPC list
			boolean isNPPEligibleFromAccount = false;
			CpclistDao cpclistDao = null;
			List<Cpclist> cpcList = null;

			try{
				List<Account> fromAcctList = new ArrayList<Account>();
				cpcService = (CPCServiceImpl) ServiceHelper.getBean("cpcService");
				fromAcctList = cpcService.getFromAccountNPPEligibility(fromAccountList);
				
				Iterator<Account> fromAcctIterator = fromAcctList.iterator();
				Iterator<au.com.stgeorge.mbank.model.common.AccountResp> mbAcctIterator = mbAccountList.iterator();
				
				while(fromAcctIterator.hasNext() && mbAcctIterator.hasNext()){
					Account fromAccount = fromAcctIterator.next();
					au.com.stgeorge.mbank.model.common.AccountResp mbAccount = mbAcctIterator.next();
					
					if(fromAccount.isNppOutwardAllowed() && mbAccount.getAccountControl().isAllowTP()){
						mbAccount.getAccountControl().setAllowPayID(ThirdPartyTransferHelper.validateCHSAccountEligibility(fromAccount));
					}
				}
			}catch(Exception ex){
				Logger.error("LogonHelper.setFromAccountNPPEligibility(): exception while fetching CPC List from Database: "+isNPPEligibleFromAccount, this.getClass());
			}

			Logger.debug("LogonHelper.setFromAccountNPPEligibility(): End", this.getClass());
		}
		
		
 		private GhostTileResp populateDMPostSubmitTile(IBankCommonData ibankCommonData)
 		{

 			try
 			{
				MortgageDataService mortgageDataService = (MortgageDataService) ServiceHelper.getBean("mortgageDataService");
				Logger.info("Getting PostSubmit DM Tile for GCIS " + ibankCommonData.getCustomer().getGcis() , this.getClass());
		    String stat = mortgageDataService.getApplicationStatusForTile(ibankCommonData);
	
		    if ( StringMethods.isEmptyString(stat))
		    {
		    	return null;
		    }
		    
	 			GhostTileResp ghostTile = new GhostTileResp();
				ghostTile.setTileType(LoanAppConstants.TILE_TYPE_MORTGAGE);
		 		ghostTile.setProductType(LoanAppConstants.HOMELOAN_LOAN_PRODUCT_TYPE);
		 		
		 		
		    if (  MortgageUtil.DOC_UPLOAD.equalsIgnoreCase( stat ))
		    {
			 		ghostTile.setTileStatusDesc(LoanAppConstants.HOMELOAN_LOAN_TILE_STATUS_DESC_PURCHASE_SUBMITTED);
			 		ghostTile.setTileStatusDetails(LoanAppConstants.HOMELOAN_LOAN_TILE_STATUS_DETAILS_SUBMITTED);
			 		return ghostTile;
		    }
		    else 	if (  MortgageUtil.REFI_DOC_UPLOAD.equalsIgnoreCase( stat ))
		    {
			 		ghostTile.setTileStatusDesc(LoanAppConstants.HOMELOAN_LOAN_TILE_STATUS_DESC_REFINANCE_SUBMITTED);
			 		ghostTile.setTileStatusDetails(LoanAppConstants.HOMELOAN_LOAN_TILE_STATUS_DETAILS_SUBMITTED);
			 		return ghostTile;
		    }
		    else 	if (  MortgageUtil.MULTI_DOC_UPLOAD.equalsIgnoreCase( stat ))
		    {
			 		ghostTile.setTileStatusDesc(LoanAppConstants.HOMELOAN_LOAN_TILE_STATUS_DESC_ALL_SUBMITTED);
			 		ghostTile.setTileStatusDetails(LoanAppConstants.HOMELOAN_LOAN_TILE_STATUS_DETAILS_SUBMITTED);
			 		return ghostTile;
		    }

 			}
 			catch ( Exception e)
 			{
 				Logger.error("Error in populateDMPostSubmitTile(, clazz) ", e, this.getClass() );
 			}
			return null;

 		}

 		public boolean isDocUploadAllowed(HttpServletRequest httpRequest){
 			boolean isAllowed = false;
 			Cookie cookie = getCookie(httpRequest, APP_VER_COOKIE);
 			if(cookie == null){//Not Native App
 				isAllowed = true;
 			}else if(cookie != null && StringMethods.isValidString(cookie.getValue()) && (cookie.getValue().indexOf(APPVERSION_COOKIE_DOC_UPLOAD) >=0)){
 				isAllowed = true;
 			}
 			Logger.info("isDocUploadAllowed "+isAllowed, this.getClass());
 			return isAllowed;
 		}

		public CodesCache getCodesCache() {
			return codesCache;
		}

		public void setCodesCache(CodesCache codesCache) {
			this.codesCache = codesCache;
		}
	
	public static boolean isAppDynamicsDMSwitchOn(String origin){
	    return IBankParams.isSwitchOn(origin, IBankParams.APP_DYNAMICS_DM_SWITCH);
	}
	public static boolean isAppDynamicsMBSwitchOn(String origin){
	    return IBankParams.isSwitchOn(origin, IBankParams.APP_DYNAMICS_MB_SWITCH);
	}
	public static String getAppDAdrumKey(String origin){
	    return IBankParams.getCodesData(origin, IBankParams.APP_DYNAMICS_CATEGORY, IBankParams.APP_DYNAMICS_ADRUM_KEY).getMessage();
	}
	public static String getAdrumHttpEndPoint(String origin){
	    return IBankParams.getCodesData(origin, IBankParams.APP_DYNAMICS_CATEGORY, IBankParams.APP_DYNAMICS_HTTP_END_POINT).getMessage();
	}
	public static String getAdrumHttpsEndPoint(String origin){
	    return IBankParams.getCodesData(origin, IBankParams.APP_DYNAMICS_CATEGORY, IBankParams.APP_DYNAMICS_HTTPS_END_POINT).getMessage();
	}
	
	public IGenericSession createCompassSession(HttpServletRequest httpServletRequest, String sessionId, boolean isLite) throws BusinessException
	{

		try
		{
			//String sessionId = new MBAppHelper().generatetSessionID();
			//sessionId = prefix + sessionId;
			IGenericSession gSession =  null;
			if ( isDBSession() )
			{
				gSession = GenericSessionFactory.getInstance(sessionId ,isLite);
				
			}
			else
			{
				 gSession = GenericSessionFactory.getInstance(httpServletRequest);
			}
			

			//gSession.setUser(myUser);

			//gSession.setAttribute(ORIGIN, origin);
			//gSession.setAttribute(BROWSER_NAME, browser);

			/*Logger.debug(" User CAN : " + myUser.getUserId() + ",GCIS Number : " + myUser.getGCISNumber() + ",Card : "
					+ myUser.getAttribute(IBankParams.USEROBJ_CARDNUMBER) + ",LastAccess : " + myUser.getAttribute(IBankParams.USEROBJ_LASTACESSBY)
					+ ",MustChangePwd " + myUser.isStatusMustChangePassword() + ",TT Access " + myUser.getAttribute(IBankParams.USEROBJ_TT_ACCESS) + ",Origin "
					+ myUser.getAttribute(IBankParams.USEROBJ_BRAND) + ",Lim Attr : " + myUser.getAttribute(IBankParams.USEROBJ_LIM) + ",Session ID : "
					+ gSession.getId(), this.getClass());*/

			return gSession;
		} catch (Exception e)
		{

			IBankLog.logTRC(" Unable to create the Session ", e,
					LogonHelper.class);
			throw new BusinessException(BusinessException.SYSTEM_UNAVILABLE, " Unable to create the Session " );
		}
	}
	
	public static void logNativeJsSwitchInterface(boolean isNativeJSInterfaceSwitchON){
		Logger.debug("Inside logNativeJsSwitchInterface : Value of isNativeJSInterfaceSwitchON ::"+ isNativeJSInterfaceSwitchON, LogonHelper.class);
	}
	//19E3 - CashAdvance Fee warning checkbox show eligible sub product codes (only for CRA Accounts)
	//19E4 - BCOP Transfer from Gold cash mangement and investment savings account (only for DDA Accounts)
	private boolean isSubProdCodeEligible(List<String> eligibleSubProdCodeList, Account account){
		if (eligibleSubProdCodeList != null && account.getAccountId() != null && account.getAccountId().getSubProductCode() != null && 
				eligibleSubProdCodeList.contains(account.getAccountId().getSubProductCode())){
			return true;
		}
		return false;
	}
	
	private String createTargetUrl(HttpServletRequest httpServletRequest){
		String menuUrl = "";		
		menuUrl = menuUrl.concat(httpServletRequest.getScheme()).concat("://").concat(httpServletRequest.getHeader("Host")).concat("/ibank/");				
		return menuUrl;
	}

	
	/**
	 * @param  HttpServletRequest request
	 * @return true : eligible for Madison splash page
	 *         false: not eligible for Madison splash page
	 * @throws BusinessException 
	 * @throws ResourceException 
	 */
	public boolean checkMadisonSplashEligibility(HttpServletRequest request) throws ResourceException, BusinessException{
		
		boolean madisonSplashEligible = false;
		if(null!=request) {
			String userAgent = request.getHeader("User-Agent").toLowerCase();
			Cookie cookie = getCookie(request, APP_VER_COOKIE);	
			if( (cookie!=null && !(StringMethods.isEmptyString(cookie.getValue())))){
				if(null!=userAgent) {
					if(StringUtils.containsIgnoreCase(userAgent, "ios") || StringUtils.containsIgnoreCase(userAgent, "iphone")){
						madisonSplashEligible = true;
					}
				}
			}
		}
		return madisonSplashEligible;
	}
					
					
	
	/**
	 * @param  HttpServletRequest request, Customer customer
	 * @return true : eligible for Madison link to be shown in service menu
	 *         false: not eligible for Madison link to be shown in service menu
	 * @throws BusinessException 
	 * @throws ResourceException 
	 */
	public boolean checkMadisonServiceMenuEligibility(HttpServletRequest request) {
			if(null!=request) {
				String userAgent = request.getHeader("User-Agent").toLowerCase();
				Logger.debug("In App Prov:user agent>>"+userAgent, this.getClass());
				Cookie cookie = getCookie(request, APP_VER_COOKIE);		
				Logger.debug("In App Prov:cookie>>"+cookie, this.getClass());
				
				if(null!=cookie) {
					Logger.debug("In App Prov:cookie val>>"+cookie.getValue(), this.getClass());
				}				
				if( (cookie!=null && !(StringMethods.isEmptyString(cookie.getValue())))){
					if(null!=userAgent) {
						if(StringUtils.containsIgnoreCase(userAgent, "ios") || StringUtils.containsIgnoreCase(userAgent, "iphone")){
							return true;
						}else {
							return false;
						}
					}else {
						return false;
					}
				}
				else {
					return false;
			   }
			}else {
				return false;
		}
	}
	
	public String getAppLink(String origin){
		String appLink = "";		
		CodesVO codeItem=IBankParams.getCodesData(origin, IBankParams.MADISON_CATEGORY,IBankParams.MADISON_APP_LINK);		
		
		if(null!=codeItem) {
			appLink=codeItem.getMessage();
		}
		return appLink;
	}
	
	public String getLearnMoreLink(String origin){
		String learnMoreLink = "";		
		CodesVO codeItem=IBankParams.getCodesData(origin, IBankParams.MADISON_CATEGORY,IBankParams.MADISON_LEARN_MORE_LINK);		
		
		if(null!=codeItem) {
			learnMoreLink=codeItem.getMessage();
		}
		return learnMoreLink;
	}
	
	public boolean isMadisonEligible(String userAgent, Cookie cookie) throws ResourceException
	{
		if( (cookie!=null && !(StringMethods.isEmptyString(cookie.getValue())))){
			if(null!=userAgent) {
				if(StringUtils.containsIgnoreCase(userAgent, "ios") || StringUtils.containsIgnoreCase(userAgent, "iphone")){
					return true;
				}else {
					return false;
				}
			}else {
				return false;
			}
		}
		else {
			return false;
	   }
	}
	

	/**
	 * Added for 20E2 CSH - SBGEXP-8227
	 * 
	 * This method will populate GhostTileResp for CSH
	 * 
	 * @param ibankCommonData
	 * @param serviceResponse
	 * @return LoanApplicationDetail - for CSH tile
	 */
	public void populateCSHApplicationDetail(IBankCommonData ibankCommonData, IMBResp serviceResponse ){		
		try{
			
			//CSH display tile switch - when OFF, do not populate CSH ghost tile for CSH.
			if(!IBankParams.isSwitchOn(IBankParams.getBaseOriginCode(ibankCommonData.getOrigin()), IBankParams.CSH_DISPLAY_TILE_SWITCH)) 
				return;
			
			
			Logger.debug("CSH : populateCSHApplicationDetail",  this.getClass());
			
			List<GhostTileResp> ghostTileList=new ArrayList<GhostTileResp>();
			GhostTileResp ghostTileResp = new GhostTileResp();
			
			//fetch the list of ghost tile from logon response.
			if(null != ((LogonResp) serviceResponse).getCustomer().getGhostTiles())
				ghostTileList = ((LogonResp) serviceResponse).getCustomer().getGhostTiles();
			
			//Populate the ghostTileResp
		 	ghostTileResp.setTileType(LoanAppConstants.TILE_TYPE_CSH);			 
		 	ghostTileList.add(ghostTileResp);
			 	
		 	if(((LogonResp) serviceResponse).getCustomer() != null && null!= ghostTileResp){
				Logger.debug("CSH : populateCSHApplicationDetail : Setting the CSH Ghost tile response in LogonResp::", this.getClass());
				((LogonResp) serviceResponse).getCustomer().setGhostTiles(ghostTileList);
			}
		 	
		} catch(Exception ex){
			Logger.error("CSH : populateCSHApplicationDetail : Exception caught while populating CSH application details.", ex, this.getClass());
		}		
	}
	
	public Map<String, Object> getConnectSession(String sessionID){
		QuickZoneService serv = ServiceHelper.getBean("quickZoneService");
		Map<String, Object> resp = serv.getConnectSession(sessionID);
		return resp;
	}
	
	public UserAgentVO getUserAgentFromSession(Map<String, Object> resp) {
		return (UserAgentVO)resp.get(MobileSessionImpl.USER_AGENT_OBLECT);
	}
	
	public String getDeviceIDFromSession(Map<String, Object> resp) {
		return (String)resp.get(MobileSessionImpl.DEVICE_ID);
	}
	
	public User getUserFromSession(Map<String, Object> resp) {
		return (User)resp.get(MobileSessionImpl.USER_OBLECT);
	}
	
	public void deleteConnectSession(String sessionID){
		QuickZoneService serv = ServiceHelper.getBean("quickZoneService");
		serv.deleteConnectSession(sessionID);
		
	}
	
	public IGenericSession createMBSession(HttpServletRequest request, User user, String origin, String sessDeviceId, LogonHelper logonHelper) throws BusinessException{
		//1-read WSServiceSession and Validate Session
		
		//String gdwOrigin  = logonHelper.getGDWOrigin( request.getHeader(),  origin);
		
		//4-Create MB Session ID
		IGenericSession genericSession = logonHelper.createCompassSession(user, origin, "WebSrv", request);
		
		genericSession.setAttribute(MobileSessionImpl.USER_OBLECT, user);
		genericSession.setAttribute(MobileSessionImpl.ORIGIN_OBLECT, origin);
		
		//GDW Origin - mbAppLogon will set right one (TSTG,MSTG)
		genericSession.setAttribute(MobileSessionImpl.GDW_ORIGIN, origin);
		genericSession.setAttribute(SMPL_DEVICE_ID, sessDeviceId);
		
		return genericSession;

	}

	Customer getCustomerInSession( MobileSession mobileSession, IBankCommonData ibankCommonData, final String callingMethodName) throws BusinessException {
		Customer customer = mobileSession.getCustomer();
		if(customer ==  null){
			Logger.info(callingMethodName +" Customer from Session is NULL: Calling 360" , this.getClass());
			customer = getCustomer(ibankCommonData, callingMethodName,false);
		}
		if(null!=customer)
		{
		  ibankCommonData.setCustomer(customer);
		}
		mobileSession.setCustomer(customer);
		return customer;
	}

	LogonResp populateAutoInitLogonResp( HttpServletRequest httpServletRequest, ObjectMapper mapper, Customer customer, final String callingMethodName) throws JsonProcessingException {
		LogonResp logonResp = new LogonResp();
		logonResp.setAutoInitPwdSecNumChng(true);
		logonResp.setChangePwdReqd(false);
		logonResp.setChangePwdAndSecNumReqd(false);
		logonResp.setTermsAcceptanceReqd(true);
		String maskedEmailAddress = getMaskedCustomerEmailAddress(customer);
		logonResp.setEmailAddress(maskedEmailAddress == null ? "" : maskedEmailAddress);
		Logger.debug("***AutoInitStatus  ECorrespondence Check: ", this.getClass());
		//E-correspondence Check Box for the consent capture
		if(CommonBusinessUtil.isECorrespondenceSupported(httpServletRequest)){
			if(customer.isCustomerOfTypeGHS()&& CustomerVOAssembler.PERSONAL_CUSTOMER.equalsIgnoreCase(customer.getCustTypeInd()))
			{
				logonResp.seteCorConsentCaptureRequired(true);
			}
		}
		Logger.debug("***AutoInitStatus inside " + callingMethodName + " 2: ", this.getClass());
		AppParams appParams = populateAppParams(httpServletRequest, customer);
		Logger.debug("***AutoInitStatus inside " + callingMethodName + " 3: ", this.getClass());
		logonResp.setAppParams(appParams);
		Logger.debug("***AutoInitStatus inside " + callingMethodName + " 4: ", this.getClass());
		MobileSession dummySession = null;
		RespHeader headerResp = populateResponseHeader(ServiceConstants.LOGON_RESPONSE, dummySession);
		logonResp.setHeader(headerResp);
		Logger.debug("***AutoInitStatus " + callingMethodName + " JSON for Auto INIT Response :" + mapper.writeValueAsString(logonResp), this.getClass());
		return logonResp;
	}

	public ForceChangePwd setForceChangedPwdInSession( MobileSession mobileSession, IBankCommonData ibankCommonData) throws BusinessException {
		ForceChangePwd forceVO = mobileSession.getForceChangePwd();
		
		if (forceVO == null){
			ForceChangePwdService forceService;
			Logger.debug("logon:: forceChangePwdStatus: null", this.getClass());
			forceService = ServiceHelper.getBean(ServiceConstants.FORCE_PWD_CHANGE);
			forceVO = forceService.getStatus(ibankCommonData);
			mobileSession.setForceChangePwd(forceVO);
		}
		return forceVO;
	}

	public IMBResp populateSafiResponse(IMBResp serviceResponse, Customer customer) {
		((LogonResp) serviceResponse).setCustomer(null);
		((LogonResp) serviceResponse).setShowSafiChallenge(true);
		((LogonResp) serviceResponse).setContactInfo(populateContact(customer.getContactDetail()));
		((LogonResp) serviceResponse).setSecureCodeInfo(populateSecureCodeInfo(customer));
		return serviceResponse;
	}

	public void populateGhostTileResponse(IMBResp serviceResponse, MobileSession mobileSession, IBankCommonData ibankCommonData, Customer customer) {
		int cshIndicator = LoanAppUtil.getCSHTileIndicator(customer.getPreference().getCcPLLoanInd());
		
		//20E4 - Warranty - fetch cshIndicator from db2 if prepareOnline customer
		Logger.info("populateGhostTileResponse : mobileSession.getIsPrepareOnlineRedirect() :: "+mobileSession.getIsPrepareOnlineRedirect(), this.getClass());
		  
		//20E4 Warranty - CSH - Back to Compass from Juipter scenario
		//Refresh customer preferences when its a prepareOnline User, returned from Jupiter
		//21E2WR: Refresh customer preferences when its a csh apply online, returned from Jupiter
		if((null != mobileSession.getIsPrepareOnlineRedirect() && mobileSession.getIsPrepareOnlineRedirect()) ||  (null != mobileSession.getIsCshApplyOnlineRedirect() && mobileSession.getIsCshApplyOnlineRedirect())) {
			
			Preference myPreference = null;
			try {
				myPreference = PreferencesService.getPreferenceForMobileBank(ibankCommonData.getUser());
			} catch (Exception e) {
				Logger.warn("populateGhostTileResponse : Exception while fetching preference: "+e, this.getClass());
			} 
			
			if(null != myPreference) {
				cshIndicator = LoanAppUtil.getCSHTileIndicator(myPreference.getCcPLLoanInd());
			}
			
			Logger.info("populateGhostTileResponse : PrepareOnline user - Refresh customer preferences, cshIndicator : "+cshIndicator, this.getClass());
		}
		
		if(customer.getPreference() != null){
			if(customer.getPreference().getCcPLLoanInd() == LoanAppConstants.PRF_CCLOANIND_EFINANCE || customer.getPreference().getCcPLLoanInd() == LoanAppConstants.PRF_CCLOANIND_EFINANCE_HOMELOAN_BOTH
					|| cshIndicator == LoanAppConstants.PRF_CCLOANIND_EFINANCE
					|| cshIndicator == LoanAppConstants.PRF_CCLOANIND_EFINANCE_HOMELOAN_BOTH){						
				LoanApplicationDetail loanAppDetail = populateLoanApplicationDetail(ibankCommonData,serviceResponse);
				mobileSession.setLoanApplicationDetail(loanAppDetail);
			}
								
			//20E2-CSH -SBGEXP-8227 - populate the details for CSH tile
			if(cshIndicator == LoanAppConstants.PRF_CCLOANIND_CSH ||
					cshIndicator == LoanAppConstants.PRF_CCLOANIND_EFINANCE ||	
					cshIndicator == LoanAppConstants.PRF_CCLOANIND_HOMELOAN ||
					cshIndicator == LoanAppConstants.PRF_CCLOANIND_EFINANCE_HOMELOAN_BOTH) {
				Logger.debug("CSH : Populate CSH Tile - mbAppLogon. ", this.getClass());
				populateCSHApplicationDetail(ibankCommonData,serviceResponse);						 
			}
			
			//20E2-CSH -SBGEXP-8227 - added two conditions to check CSH/Efinance/Homeloan combination
			if(customer.getPreference().getCcPLLoanInd() == LoanAppConstants.PRF_CCLOANIND_HOMELOAN || customer.getPreference().getCcPLLoanInd() == LoanAppConstants.PRF_CCLOANIND_EFINANCE_HOMELOAN_BOTH
					|| cshIndicator == LoanAppConstants.PRF_CCLOANIND_HOMELOAN
					|| cshIndicator == LoanAppConstants.PRF_CCLOANIND_EFINANCE_HOMELOAN_BOTH){
				populateHomeLoanGhostTile(ibankCommonData, serviceResponse);
			}
		}
	}

	public String safiActionFromSession( MobileSession mobileSession, Customer customer, final String callingMethodName) {
		String safiAction =  mobileSession.getSafiLogonInfo()!= null ?mobileSession.getSafiLogonInfo().getSafiAction():null;
		Logger.debug("SAFI : SafiAction from Session: "+safiAction+"GCISNumber: " + customer.getGcis() + " from method " + callingMethodName , this.getClass());
		return safiAction;
	}

	public DigitalSecLogggerVO initializeDigiLoggerSafiAppLogon(MobileSession mobileSession, IBankCommonData ibankCommonData) {
		DigitalSecLogggerVO digitalSecLoggerVO = new DigitalSecLogggerVO();
		SafiForensicInfo safiForensicInfo = new SafiForensicInfo();
		safiForensicInfo.setSafiRiskScore(mobileSession.getSafiLogonInfo()!= null ? mobileSession.getSafiLogonInfo().getSafiRiskScore() :"");
		safiForensicInfo.setSafiRuleName(mobileSession.getSafiLogonInfo()!= null ? mobileSession.getSafiLogonInfo().getSafiRuleName() :"");
		safiForensicInfo.setSafiSdkDevicePrint(mobileSession.getSafiLogonInfo()!= null ? mobileSession.getSafiLogonInfo().getDevicePrint() : "");
		digitalSecLoggerVO.setTranName(DigitalSecLogger.SAFI_APP_LOGON);
		digitalSecLoggerVO.setValues(toDigitalSecuritySafiLog(safiForensicInfo));
		digitalSecLoggerVO.setCommonLogData(getCommonLogData(null,ibankCommonData,null));
		digitalSecLoggerVO.setUserAgent(ibankCommonData.getUserAgent());
		return digitalSecLoggerVO;
	}

	boolean isSafiDeny(String safiAction) {
		return !StringMethods.isEmptyString(safiAction) && safiAction.equalsIgnoreCase(SafiConstants.SAFI_ACTION_DENY);
	}

	boolean isSafiChallenge(String safiAction) {
		return !StringMethods.isEmptyString(safiAction) && safiAction.equalsIgnoreCase(SafiConstants.SAFI_ACTION_CHALLENGE);
	}

	MessageSearch setSplashPageInfoInSession(MobileSession mobileSession, List<MessageSearch> splashPageInfo) {
		MessageSearch messageSearch = null;
		if(splashPageInfo != null && !splashPageInfo.isEmpty()){
			
			if(splashPageInfo.size() > 0) {
				messageSearch = splashPageInfo.get(0);
				mobileSession.setSplashInfoMsg(messageSearch);
			}
		}
		return messageSearch;
	}

	AutoApplyRetentionInfo setDigiRetentionInfoInSession( MobileSession mobileSession, MsgCentreInfo messageCentreInfo) {
		List<AutoApplyRetentionInfo> digiRetInfoList = messageCentreInfo.getApplyRetentionInfo();
		
		//setAutoApplyRetentioninSession(mobileSession,  digiRetInfoList);
		AutoApplyRetentionInfo autoApplyRetentionInfo = null;
		if(digiRetInfoList!=null && digiRetInfoList.size()>0  ){
		
			try{
				 autoApplyRetentionInfo = digiRetInfoList.get(0);
			
				 Logger.debug("Auto Apply retention info message seen: "+autoApplyRetentionInfo.getAccountNumber(), this.getClass());
				 
				 mobileSession.setAutoApplyRetentionInfo(autoApplyRetentionInfo);
				}
				catch(Exception e){
					Logger.warn("LogonController:mbAppLogon() autoApplyRetentionInfo is null", this.getClass());
				}
			
			
		}
		return autoApplyRetentionInfo;
	}

	public Customer getCustomer(IBankCommonData commonData, String statistic, boolean isLogonFlow) throws BusinessException,
			ResourceException
	{
	//	IBankCommonData commonData = populateIBankCommonData(sessionId,user , origin, ipAddress);
		MobileBankService mobileBankService = (MobileBankService) ServiceHelper.getBean(MBAppConstants.SPRING_MOBILE_SERVICE_BEAN);
		Customer customer = mobileBankService.getCustomer(commonData, statistic, isLogonFlow);
		return customer;
	}

	
	String getMaskedCustomerEmailAddress(Customer customer) {
		String masked = null;
		if(null!=customer.getContactDetail() && null!=customer.getContactDetail().getEmail()) {
			String email_unmasked=customer.getContactDetail().getEmail();
			masked = email_unmasked.replaceAll("(?<=.{2}).(?=[^@]*?.{2}@)", "*");
		}
		return masked;
	}
	
	private RespHeader populateResponseHeader(String serviceName, MobileSession mobileSession )
	{
		MBAppHelper mbAppHelper = new MBAppHelper();
		return mbAppHelper.populateResponseHeader(serviceName, mobileSession);
		
	}

	void populateGhostTile(LogonUtilController logonUtilController, IGenericSession genericSession, IBankCommonData ibankCommonData, Customer customer, IMBResp serviceResponse) {
		int cshIndicator = LoanAppUtil.getCSHTileIndicator(customer.getPreference().getCcPLLoanInd());
		
		if(customer.getPreference() != null){
			if(customer.getPreference().getCcPLLoanInd() == LoanAppConstants.PRF_CCLOANIND_EFINANCE || customer.getPreference().getCcPLLoanInd() == LoanAppConstants.PRF_CCLOANIND_EFINANCE_HOMELOAN_BOTH
					|| cshIndicator == LoanAppConstants.PRF_CCLOANIND_EFINANCE
					|| cshIndicator == LoanAppConstants.PRF_CCLOANIND_EFINANCE_HOMELOAN_BOTH){						
				LoanApplicationDetail loanAppDetail = populateLoanApplicationDetail(ibankCommonData,serviceResponse);
				Logger.debug("populateLoanApplicationDetail 1", logonUtilController.getClass());
				genericSession.setAttribute("LoanApplDetail", loanAppDetail); 
			}
			
			//20E2-CSH -SBGEXP-8227 - populate the details for CSH tile
			if(cshIndicator == LoanAppConstants.PRF_CCLOANIND_CSH ||
					cshIndicator == LoanAppConstants.PRF_CCLOANIND_EFINANCE ||	
					cshIndicator == LoanAppConstants.PRF_CCLOANIND_HOMELOAN ||
					cshIndicator == LoanAppConstants.PRF_CCLOANIND_EFINANCE_HOMELOAN_BOTH) {
				Logger.debug("CSH : Populate CSH Tile - processLogon. ", logonUtilController.getClass());
				populateCSHApplicationDetail(ibankCommonData,serviceResponse);						 
			}
			
			//20E2-CSH -SBGEXP-8227 - added two conditions to check CSH/Efinance/Homeloan combination
			if(customer.getPreference().getCcPLLoanInd() == LoanAppConstants.PRF_CCLOANIND_HOMELOAN || customer.getPreference().getCcPLLoanInd() == LoanAppConstants.PRF_CCLOANIND_EFINANCE_HOMELOAN_BOTH
					|| cshIndicator == LoanAppConstants.PRF_CCLOANIND_HOMELOAN
					|| cshIndicator == LoanAppConstants.PRF_CCLOANIND_EFINANCE_HOMELOAN_BOTH){
				populateHomeLoanGhostTile(ibankCommonData, serviceResponse);
			}
		}
	}

	void populateGhostTileResponse(LogonUtilController logonUtilController, MobileSession mobileSession, IBankCommonData ibankCommonData, Customer customer, IMBResp serviceResponse) {
		int cshIndicator = LoanAppUtil.getCSHTileIndicator(customer.getPreference().getCcPLLoanInd());
		
		if(customer.getPreference() != null){
			if(customer.getPreference().getCcPLLoanInd() == LoanAppConstants.PRF_CCLOANIND_EFINANCE || customer.getPreference().getCcPLLoanInd() == LoanAppConstants.PRF_CCLOANIND_EFINANCE_HOMELOAN_BOTH
					|| cshIndicator == LoanAppConstants.PRF_CCLOANIND_EFINANCE
					|| cshIndicator == LoanAppConstants.PRF_CCLOANIND_EFINANCE_HOMELOAN_BOTH){						
				LoanApplicationDetail loanAppDetail = populateLoanApplicationDetail(ibankCommonData,serviceResponse);
				mobileSession.setLoanApplicationDetail(loanAppDetail);
			}
			
			//20E2-CSH -SBGEXP-8227 - populate the details for CSH tile
			if(cshIndicator == LoanAppConstants.PRF_CCLOANIND_CSH ||
					cshIndicator == LoanAppConstants.PRF_CCLOANIND_EFINANCE ||	
					cshIndicator == LoanAppConstants.PRF_CCLOANIND_HOMELOAN ||
					cshIndicator == LoanAppConstants.PRF_CCLOANIND_EFINANCE_HOMELOAN_BOTH) {
				Logger.debug("CSH : Populate CSH Tile - loadCustomer. ", logonUtilController.getClass());
				populateCSHApplicationDetail(ibankCommonData,serviceResponse);						 
			}
			
			//20E2-CSH -SBGEXP-8227 - added two conditions to check CSH/Efinance/Homeloan combination
			if(customer.getPreference().getCcPLLoanInd() == LoanAppConstants.PRF_CCLOANIND_HOMELOAN || customer.getPreference().getCcPLLoanInd() == LoanAppConstants.PRF_CCLOANIND_EFINANCE_HOMELOAN_BOTH
					|| cshIndicator == LoanAppConstants.PRF_CCLOANIND_HOMELOAN
					|| cshIndicator == LoanAppConstants.PRF_CCLOANIND_EFINANCE_HOMELOAN_BOTH){
				populateHomeLoanGhostTile(ibankCommonData, serviceResponse);
			}
		}
	}

	public static String getOrigin( HttpServletRequest httpServletRequest, boolean isDemo, String callingMethodName) {
		String origin;
		if (isDemo)
		 {
		       origin = (String) httpServletRequest.getSession().getAttribute(LogonHelper.ORIGIN);
		       Logger.debug("Demo Origin is : " + httpServletRequest.getSession().getAttribute("origin"), LogonHelper.class);
		 }
		 else
		 {
		       origin = LogonHelper.resolveOrigin(httpServletRequest);
		       Logger.debug("LogonController " + callingMethodName + " : Origin :"+origin, LogonHelper.class);
		 }
		return origin;
	}
	
	public static  void printMobileTermsAndTandCCookieValue(HttpServletRequest request) {
		Cookie[] cookies = request.getCookies();
		if (cookies != null) {
			for (int i = 0; i < cookies.length; i++) {
				if (cookies[i].getName().equals(MOBILE_TNC_COOKIE)) {
					
						Logger.info(" Cookie Name:" + MOBILE_TNC_COOKIE + 	cookies[i].getValue() , LogonHelper.class);
				}
				if (cookies[i].getName().equals(MOBILE_TERMS_COOKIE)) {
					String oldCookieValue = cookies[i].getValue();
					Logger.info("Terms and Condition Existing Cookies " + oldCookieValue  ,LogonHelper.class);
					}
				}
			}
	}
	
	//Following method returns the OS type of Native App
	//i.e. 2 for Android and 1 for iOS. -1 when cookie not found (this should happen in case of msite)
	//It uses App_Ver_Cookie to determine this check.
	public int getAppOsType(HttpServletRequest request){
		Cookie cookie = getCookie(request, APP_VER_COOKIE);
		if ( cookie != null && ! StringMethods.isEmptyString(cookie.getValue())){
	  		String tempStr = cookie.getValue();
		  	Logger.info("App Ver Cookie value in getAppOsType .. " +tempStr , this.getClass());
		  	if ( tempStr.toUpperCase().indexOf(DEVICE_ANDROID) >= 0 
		  			  || tempStr.toUpperCase().indexOf(DEVICE_ANDROID_MOBBANK) >= 0 ){
		  		Logger.info("App Ver Cookie is Android .. " +tempStr , this.getClass());
		  	  	return 2;  // Android
		  	}else if ( tempStr.toUpperCase().indexOf(DEVICE_IOS_MOBBANK) >= 0 ) {
		  		Logger.info("App Ver Cookie is iOS .. " +tempStr , this.getClass());
		  	  	return 1; // IOS
		  	}else {
		  		Logger.info("App Ver Cookie is unknown .. " +tempStr , this.getClass());
		  		return -1; // unknown APP
		  	}
		}
		return -1; // not an App 
	}
	
	/**
	 * addCompassAppTypeCookie() is used to add the CompassAppType cookie in session.
	 * 
	 * @param origin
	 * @param request
	 * @param response
	 */
	public void setDomainAndAddCompassCookie(String origin, HttpServletRequest request, HttpServletResponse response, String name, String value) {
		String domainName = request.getServerName();
		if(domainName.contains(".")){
			domainName = domainName.substring(domainName.indexOf("."));
		}		
		if(! StringMethods.isEmptyString(domainName)){
			response.addHeader("Set-Cookie", name + "=" + value + "; path=/" + "; domain="+domainName);
		}
		else{
			response.addHeader("Set-Cookie", name + "=" + value + "; path=/");
		}

		Logger.info(" Added "+ name + " = "+ value, this.getClass());
	}

	

	public String getGoogleMapApiKey() {
		return googleMapApiKey;
	}

	public void setGoogleMapApiKey(String googleMapApiKey) {
		this.googleMapApiKey = googleMapApiKey;
	}
	
}