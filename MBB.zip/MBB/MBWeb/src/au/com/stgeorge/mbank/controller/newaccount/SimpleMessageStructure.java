package au.com.stgeorge.mbank.controller.newaccount;


import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement; 
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "SimpleMessageStructure")
@XmlAccessorType(XmlAccessType.FIELD)
public class SimpleMessageStructure {	
	
	@XmlElement(name="MsgCategory")
    private List<MsgCategory> msgCategories;

	public List<MsgCategory> getMsgCategories() {
  	return msgCategories;
  }

	public void setMsgCategories(List<MsgCategory> msgCategories) {
  	this.msgCategories = msgCategories;
  }
}


