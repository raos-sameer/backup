/**
 * 
 */
package au.com.stgeorge.mbank.controller.services;

import java.math.BigDecimal;
import java.net.URLEncoder;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;

import au.com.stgeorge.framework.common.logging.Logger;
import au.com.stgeorge.ibank.businessobject.BusinessException;
import au.com.stgeorge.ibank.businessobject.CustomerService;
import au.com.stgeorge.ibank.businessobject.ResourceException;
import au.com.stgeorge.ibank.common.cache.IBankParams;
import au.com.stgeorge.ibank.valueobject.CreditCardAccount;
import au.com.stgeorge.ibank.valueobject.Customer;
import au.com.stgeorge.ibank.valueobject.ExternalLinkVO;
import au.com.stgeorge.ibank.valueobject.Preference;
import au.com.stgeorge.ibank.valueobject.transfer.IBankCommonData;
import au.com.stgeorge.mbank.controller.IMBController;
import au.com.stgeorge.mbank.model.common.IMBReq;
import au.com.stgeorge.mbank.model.common.IMBResp;
import au.com.stgeorge.mbank.model.common.ReqHeader;
import au.com.stgeorge.mbank.model.common.RespHeader;
import au.com.stgeorge.mbank.model.request.EmptyReq;
import au.com.stgeorge.mbank.model.request.services.CLIReq;
import au.com.stgeorge.mbank.model.request.services.IncreaseCreditLimitReq;
import au.com.stgeorge.mbank.model.response.ErrorResp;
import au.com.stgeorge.mbank.model.response.services.ApplyHigherCreditLimitResp;
import au.com.stgeorge.mbank.model.response.services.IncreaseCreditLimitResp;
import au.com.stgeorge.mbank.session.MobileSession;
import au.com.stgeorge.mbank.util.FraudLogger;
import au.com.stgeorge.mbank.util.MBAppHelper;
import au.com.stgeorge.mbank.util.MBAppUtils;
import au.com.stgeorge.mbank.util.MBAppValidator;
import au.com.stgeorge.mbank.util.ServiceConstants;
import au.com.stgeorge.mobilebank.businessobject.CardService;
import au.com.stgeorge.mobilebank.businessobject.ExternalLinkService;
import au.com.stgeorge.mobilebank.businessobject.impl.ExternalLinkServiceImpl;
import au.com.stgeorge.perflogger.PerformanceLogger;

import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * @author C50216
 *
 */
@Controller
@RequestMapping("/creditlimit")
public class IncreaseCreditLimitController implements IMBController{

	private FraudLogger fraudLogger;
			
	@Autowired
	private MBAppHelper mbAppHelper;
	
	@Autowired
	private IncreaseCreditLimitHelper incCredLimitHelper;
	
	@Autowired
	private MBAppValidator mbAppValidator;
				
	@Autowired
	private PerformanceLogger perfLogger;
	
	@Autowired
	private CardService mobileCardService;
	
	@Autowired
	private ExternalLinkService externalLinkService;
	
	@RequestMapping(value= "consent" , method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public IMBResp processConsent(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, 
			@RequestBody final EmptyReq req){
		
		ObjectMapper objectMapper = new ObjectMapper();							
		perfLogger.startAllLogs();
		String logName = MBAppUtils.getLogName(httpServletRequest);
		perfLogger.startLog(logName);
		
		fraudLogger = new FraudLogger();
		MobileSession mbSession = null;
		try{	
			
			mbSession = mbAppHelper.getMobileSession(httpServletRequest);															
			Logger.info("Inc credit limit consent JSON Request :" + objectMapper.writeValueAsString(req), this.getClass());
			validateRequestHeader(req.getHeader(), httpServletRequest);
			ErrorResp errorResp = validate(req, httpServletRequest);
			if (errorResp != null && errorResp.getErrors() != null && errorResp.getErrors().size() > 0)
			{				
				//fraudLogger.logInvalidInput();
				return errorResp;
			}
												
			Customer customer=mbSession.getCustomer();			
			IBankCommonData commonData=mbAppHelper.populateIBankCommonData(mbSession,httpServletRequest);
			Preference preference = customer.getPreference();
			preference.setCliConsentInd("Y");
			mobileCardService.updateCLIConsent(commonData, preference);
			customer.getPreference().setCliConsentInd("Y");
			mbSession.setCustomer(customer);			
			
			//IMBResp serviceResponse = incCredLimitHelper.populateResp();
			IncreaseCreditLimitResp serviceResponse = new IncreaseCreditLimitResp(); 						
			RespHeader headerResp = populateResponseHeader(ServiceConstants.INCREASE_CREDIT_LIMIT_CONSENT_SERVICE, mbSession);
			serviceResponse.setHeader(headerResp);
			serviceResponse.setIsSuccess(true);
			
			Logger.info("Inc credit limit Consent JSON Response :" + objectMapper.writeValueAsString(serviceResponse), this.getClass());
			
			return serviceResponse;		
		}catch (BusinessException e)
		{			
			Logger.info("BusinessException Inside processConsent() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());			
			BusinessException exp = new BusinessException(e.getKey());
			IMBResp resp1  = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, ServiceConstants.INCREASE_CREDIT_LIMIT_CONSENT_SERVICE, httpServletRequest);
			return resp1;
		}catch (ResourceException e) {
			Logger.error("ResourceException Inside processConsent() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			ResourceException exp = new ResourceException(e.getKey());
			IMBResp resp1  = MBAppUtils.createErrorResp(mbSession.getOrigin(), BusinessException.SYSTEM_UNAVILABLE, ServiceConstants.INCREASE_CREDIT_LIMIT_CONSENT_SERVICE, httpServletRequest);
			return resp1;
		}catch (Exception e)
		{
			Logger.error("Exception Inside processConsent() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			BusinessException exp = new BusinessException(BusinessException.GENERIC_ERROR);
			IMBResp resp1  = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, ServiceConstants.INCREASE_CREDIT_LIMIT_CONSENT_SERVICE, httpServletRequest);
			return resp1;
		} finally
		{
			perfLogger.endLog(logName);
			perfLogger.endAllLogs();
		}
		
	}
	
	@RequestMapping(value= "info" , method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public IMBResp processInfo(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, 
			@RequestBody final IncreaseCreditLimitReq req){
		
		ObjectMapper objectMapper = new ObjectMapper();				
		perfLogger.startAllLogs();
		String logName = MBAppUtils.getLogName(httpServletRequest);
		perfLogger.startLog(logName);
		
		fraudLogger = new FraudLogger();
		MobileSession mbSession = null;
		try{	
			mbSession = mbAppHelper.getMobileSession(httpServletRequest);	
			Logger.info("Inc credit limit info JSON Request :" + objectMapper.writeValueAsString(req), this.getClass());
			validateRequestHeader(req.getHeader(), httpServletRequest);
			ErrorResp errorResp = validate(req, httpServletRequest);
			if (errorResp != null && errorResp.getErrors() != null && errorResp.getErrors().size() > 0)
			{				
				//fraudLogger.logInvalidInput();
				return errorResp;
			}
			
			if (!IBankParams.isCreditLimitIncreaseSwitchOn()) throw new BusinessException(BusinessException.GENERIC_ERROR);
			
			Customer customer=mbSession.getCustomer();
			
			CreditCardAccount acct = (CreditCardAccount)mbAppHelper.getAccountFromCustomer(customer, req.getAccountIndex());
								
			acct.setRequestedCreditLimit(new BigDecimal(Double.parseDouble(req.getNewLimit())));
			//acct.setOfferLimit(new BigDecimal(Double.parseDouble(req.getOfferLimit())));						
			mobileCardService.validateDetails(acct);
							
			IMBResp serviceResponse = incCredLimitHelper.populateInfoResp(acct,req.getNewLimit()); 
								
			RespHeader headerResp = populateResponseHeader(ServiceConstants.INCREASE_CREDIT_LIMIT_SERVICE, mbSession);
			serviceResponse.setHeader(headerResp);
			
			Logger.info("Inc credit limit Info JSON Response :" + objectMapper.writeValueAsString(serviceResponse), this.getClass());
			
			return serviceResponse;		
		}catch (BusinessException e)
		{			
			Logger.info("BusinessException Inside processInfo() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			IMBResp resp1 = null;
			BusinessException exp = new BusinessException(e.getKey());
			if(BusinessException.CR_LIMIT_LESS_MIN_INC == e.getKey()){
				String minInc = (IBankParams.getCodesData(IBankParams.DEFAULT_ORIGIN,
						IBankParams.CREDIT_CARD_CONFIG,
						IBankParams.CC_MIN_CREDITLIMITINC)).getMessage();
				String[] values = {minInc};				
				resp1  = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, values, ServiceConstants.INCREASE_CREDIT_LIMIT_SERVICE, httpServletRequest);
			}				
			else				
				resp1  = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, ServiceConstants.INCREASE_CREDIT_LIMIT_SERVICE, httpServletRequest);
			
			return resp1;
		}catch (ResourceException e) {
			Logger.error("ResourceException Inside processInfo() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			ResourceException exp = new ResourceException(e.getKey());
			IMBResp resp1  = MBAppUtils.createErrorResp(mbSession.getOrigin(), BusinessException.SYSTEM_UNAVILABLE, ServiceConstants.INCREASE_CREDIT_LIMIT_SERVICE, httpServletRequest);
			return resp1;
		}catch (Exception e)
		{
			Logger.error("Exception Inside processInfo() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			BusinessException exp = new BusinessException(BusinessException.GENERIC_ERROR);
			IMBResp resp1  = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, ServiceConstants.INCREASE_CREDIT_LIMIT_SERVICE, httpServletRequest);
			return resp1;
		} finally
		{
			perfLogger.endLog(logName);
			perfLogger.endAllLogs();
		}
		
	}
	
	@RequestMapping(value= "increase" , method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public IMBResp processIncreaseLimit(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, 
			@RequestBody final IncreaseCreditLimitReq req){
		
		ObjectMapper objectMapper = new ObjectMapper();				
		perfLogger.startAllLogs();
		String logName = MBAppUtils.getLogName(httpServletRequest);
		perfLogger.startLog(logName);
		
		fraudLogger = new FraudLogger();
		MobileSession mbSession = null;
		try{	
			mbSession = mbAppHelper.getMobileSession(httpServletRequest);	
			Logger.info("Inc credit limit increase JSON Request :" + objectMapper.writeValueAsString(req), this.getClass());
			validateRequestHeader(req.getHeader(), httpServletRequest);
			ErrorResp errorResp = validate(req, httpServletRequest);
			if (errorResp != null && errorResp.getErrors() != null && errorResp.getErrors().size() > 0)
			{				
				//fraudLogger.logInvalidInput();
				return errorResp;
			}
																													
			Customer customer=mbSession.getCustomer();			
			IBankCommonData commonData=mbAppHelper.populateIBankCommonData(mbSession,httpServletRequest);
			CreditCardAccount acct = (CreditCardAccount)mbAppHelper.getAccountFromCustomer(customer, req.getAccountIndex());
			acct.setRequestedCreditLimit(new BigDecimal(Double.parseDouble(req.getNewLimit())));
			//acct.setOfferLimit(new BigDecimal(Double.parseDouble(req.getOfferLimit())));						
			mobileCardService.validateDetails(acct);
						
			mobileCardService.updateCreditLimit(mbSession.getUser().getGCISNumber(),acct,commonData);
			//IMBResp serviceResponse = incCredLimitHelper.populateInfoResp(acct,req);
			
			IncreaseCreditLimitResp serviceResponse = new IncreaseCreditLimitResp(); 								
			RespHeader headerResp = populateResponseHeader(ServiceConstants.INCREASE_CREDIT_LIMIT_INFO_SERVICE, mbSession);
			serviceResponse.setHeader(headerResp);
			serviceResponse.setIsSuccess(true);
			
			Logger.info("Inc credit limit increase JSON Response :" + objectMapper.writeValueAsString(serviceResponse), this.getClass());
			
			return serviceResponse;		
		}catch (BusinessException e)
		{			
			Logger.info("BusinessException Inside processIncreaseLimit() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			IMBResp resp1 = null;
			BusinessException exp = new BusinessException(e.getKey());
			if(BusinessException.CR_LIMIT_LESS_MIN_INC == e.getKey()){
				String minInc = (IBankParams.getCodesData(IBankParams.DEFAULT_ORIGIN,
						IBankParams.CREDIT_CARD_CONFIG,
						IBankParams.CC_MIN_CREDITLIMITINC)).getMessage();
				String[] values = {minInc};				
				resp1  = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, values, ServiceConstants.INCREASE_CREDIT_LIMIT_INFO_SERVICE, httpServletRequest);
			}				
			else				
				resp1  = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, ServiceConstants.INCREASE_CREDIT_LIMIT_INFO_SERVICE, httpServletRequest);
			
			return resp1;
		}catch (ResourceException e) {
			Logger.error("ResourceException Inside processIncreaseLimit() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			ResourceException exp = new ResourceException(e.getKey());
			IMBResp resp1  = MBAppUtils.createErrorResp(mbSession.getOrigin(), BusinessException.SYSTEM_UNAVILABLE, ServiceConstants.INCREASE_CREDIT_LIMIT_INFO_SERVICE, httpServletRequest);
			return resp1;
		}catch (Exception e)
		{
			Logger.error("Exception Inside processIncreaseLimit() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			BusinessException exp = new BusinessException(BusinessException.GENERIC_ERROR);
			IMBResp resp1  = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, ServiceConstants.INCREASE_CREDIT_LIMIT_INFO_SERVICE, httpServletRequest);
			return resp1;
		} finally
		{
			perfLogger.endLog(logName);
			perfLogger.endAllLogs();
		}
		
	}
	
	@RequestMapping(value = "getUrl", method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public IMBResp getCCIncreaseURL(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse,
			@RequestBody final CLIReq request) {
		
		
		 ObjectMapper objectMapper = new ObjectMapper();
		perfLogger.startAllLogs();
		String logName = MBAppUtils.getLogName(httpServletRequest);
		perfLogger.startLog(logName);

		MobileSession mbSession = null;
		try {
			mbSession = mbAppHelper.getMobileSession(httpServletRequest);
			 Logger.info("Apply higher credit limit JSON Request :" + objectMapper.writeValueAsString(request), this.getClass());
			 validateRequestHeader(request.getHeader(), httpServletRequest);
			ErrorResp errorResp = validate(request, httpServletRequest);
			if (errorResp != null && errorResp.getErrors() != null && errorResp.getErrors().size() > 0) {
				return errorResp;
			}
			IBankCommonData commonData = mbAppHelper.populateIBankCommonData(mbSession, httpServletRequest);
			
			if (!IBankParams.isCreditLimitIncreaseSwitchOn()) throw new BusinessException(BusinessException.GENERIC_ERROR);
			
			String accountNumber = (request.getAccountIndex() != null) ? mbSession.getCustomer().getAccounts().get(request.getAccountIndex())
					.getAccountId().getAccountNumber() : null;
//			String accountNumber = mbSession.getIncreaseCCLimitAccountNumber();
			
			ExternalLinkVO externalLinkVO = externalLinkService.getExternalURLVO(commonData, true, ExternalLinkServiceImpl.ACE_INCR_CREDIT_LIMIT, null, accountNumber);
			StringBuffer url = new StringBuffer(externalLinkVO.getUrl());
			if(!CustomerService.isJWTSwitchON()){
			url.append("&data=" + URLEncoder.encode(externalLinkVO.getUnSignedData(), "UTF-8"));
			url.append("&sign=" + URLEncoder.encode(externalLinkVO.getSignedData(), "UTF-8"));
			}
			else{
				url.append("&ACEdata="+ externalLinkVO.getUnSignedData());	
			}
			Logger.info(" External URL " + url, this.getClass());
			ApplyHigherCreditLimitResp craLimitResp = new ApplyHigherCreditLimitResp();
			craLimitResp.setUrl(url.toString());
			RespHeader headerResp = populateResponseHeader(request.getHeader().getServiceName(), mbSession);
			craLimitResp.setHeader(headerResp);

			return craLimitResp;
		} catch (Exception e) {
			Logger.error("Exception Inside getURL() of increaseCredit Limit for Customer GCIS: ["
					+ ((mbSession != null && mbSession.getCustomer() != null) ? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			BusinessException exp = new BusinessException(BusinessException.SYSTEM_UNAVILABLE);
			IMBResp resp1 = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, ServiceConstants.APPLY_HIGHER_CREDIT_LIMIT_SERVICE,
					httpServletRequest);
			return resp1;
		} finally {
//			if (mbSession != null)
//				mbSession.invalidateSession();

			perfLogger.endLog(logName);
			perfLogger.endAllLogs();
		}

	}
	
	
	@RequestMapping(value = "getUrlTriad", method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public IMBResp getCCIncreaseURLTRIAD(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse,
			@RequestBody final CLIReq request) {
		ObjectMapper objectMapper = new ObjectMapper();
		perfLogger.startAllLogs();
		String logName = MBAppUtils.getLogName(httpServletRequest);
		perfLogger.startLog(logName);

		MobileSession mbSession = null;
		try {
			mbSession = mbAppHelper.getMobileSession(httpServletRequest);
			Logger.info("Apply higher credit limit JSON Request :" + objectMapper.writeValueAsString(request), this.getClass());
			validateRequestHeader(request.getHeader(), httpServletRequest);
			ErrorResp errorResp = validate(request, httpServletRequest);
			if (errorResp != null && errorResp.getErrors() != null && errorResp.getErrors().size() > 0) {
				return errorResp;
			}
			IBankCommonData commonData = mbAppHelper.populateIBankCommonData(mbSession, httpServletRequest);
			
			if (request.getAccountIndex() == null || !IBankParams.isCreditLimitIncreaseSwitchOn())
				throw new BusinessException(BusinessException.GENERIC_ERROR);
			String accountNumber = mbSession.getCustomer().getAccounts().get(request.getAccountIndex()).getAccountId().getAccountNumber();
//			String accountNumber = mbSession.getIncreaseCCLimitAccountNumber();
			
			//validate
			ExternalLinkVO externalLinkVO = externalLinkService.getExternalURLVO(commonData, true, ExternalLinkServiceImpl.ACE_TRIAD_URL, null, accountNumber);
			StringBuffer url = new StringBuffer(externalLinkVO.getUrl());
			url.append("&data=" + URLEncoder.encode(externalLinkVO.getUnSignedData(), "UTF-8"));
			url.append("&sign=" + URLEncoder.encode(externalLinkVO.getSignedData(), "UTF-8"));
			Logger.info(" External URL " + url, this.getClass());
			ApplyHigherCreditLimitResp craLimitResp = new ApplyHigherCreditLimitResp();
			craLimitResp.setUrl(url.toString());
			RespHeader headerResp = populateResponseHeader(request.getHeader().getServiceName(), mbSession);
			craLimitResp.setHeader(headerResp);

			return craLimitResp;
		} catch (BusinessException e) {
			Logger.info("BusinessException - [key: " + e.getKey() + "], GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());
			return MBAppUtils.createErrorResp(mbSession.getOrigin(), e, ServiceConstants.APPLY_HIGHER_CREDIT_LIMIT_SERVICE, httpServletRequest);
		} catch (Exception e) {
			Logger.error("Exception Inside getURL() of increaseCredit Limit for Customer GCIS: ["
					+ ((mbSession != null && mbSession.getCustomer() != null) ? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			BusinessException exp = new BusinessException(BusinessException.SYSTEM_UNAVILABLE);
			IMBResp resp1 = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, ServiceConstants.APPLY_HIGHER_CREDIT_LIMIT_SERVICE,
					httpServletRequest);
			return resp1;
		} finally {
//			if (mbSession != null)
//				mbSession.invalidateSession();

			perfLogger.endLog(logName);
			perfLogger.endAllLogs();
		}

	}
	
	/**
	 * Response for invalid body request 
	 * 
	 * @return
	 */
	@ExceptionHandler({org.springframework.http.converter.HttpMessageNotReadableException.class})
	@ResponseStatus(org.springframework.http.HttpStatus.OK)
	@ResponseBody
	public IMBResp resolveException() {		
		return MBAppUtils.createInvalidMessageBodyResponse(ServiceConstants.INCREASE_CREDIT_LIMIT_SERVICE);
	}
	
	public ErrorResp validate(IMBReq serviceRequest, HttpServletRequest request) {
		return mbAppValidator.validate(serviceRequest, request);
	}
	
	public void validateRequestHeader(ReqHeader header, HttpServletRequest request) throws ResourceException
	{	
		mbAppValidator.validateRequestHeader(header,  request);	
	}
	
	public RespHeader populateResponseHeader(String serviceName, MobileSession mobSession )
	{
		return mbAppHelper.populateResponseHeader(serviceName, mobSession);
	}

	
}
