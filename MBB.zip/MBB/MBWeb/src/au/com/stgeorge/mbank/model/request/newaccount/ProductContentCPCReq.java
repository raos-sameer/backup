package au.com.stgeorge.mbank.model.request.newaccount;

import java.io.Serializable;

public class ProductContentCPCReq implements Serializable {

	private static final long serialVersionUID = -2993255178579970136L;
	
	private String subProductCode;
	private String appId;
	public String getSubProductCode() {
		return subProductCode;
	}
	public void setSubProductCode(String subProductCode) {
		this.subProductCode = subProductCode;
	}
	public String getAppId() {
		return appId;
	}
	public void setAppId(String appId) {
		this.appId = appId;
	}
	
}
