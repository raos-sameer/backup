package au.com.stgeorge.mbank.model.request;

import au.com.stgeorge.mbank.model.common.IMBReq;
import au.com.stgeorge.mbank.model.common.ReqHeader;

public class AscendaReq implements IMBReq{

	private static final long serialVersionUID = 1L;

	private ReqHeader header;
	private int accountIndex;
	private String launchPoint;

	public ReqHeader getHeader() {
		return header;
	}

	public void setHeader(ReqHeader header) {
		this.header = header;
	}
	public int getAccountIndex() {
		return accountIndex;
	}

	public void setAccountIndex(int accountIndex) {
		this.accountIndex = accountIndex;
	}

	public String getLaunchPoint() {
		return launchPoint;
	}

	public void setLaunchPoint(String launchPoint) {
		this.launchPoint = launchPoint;
	}
	
	

}
