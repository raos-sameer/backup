/**
 * 
 */
package au.com.stgeorge.mbank.controller.customer;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import au.com.stgeorge.digitalsec.logger.DigitalSecLogger;
import au.com.stgeorge.digitalsec.logger.DigitalSecLogggerVO;
import au.com.stgeorge.framework.common.logging.Logger;
import au.com.stgeorge.framework.common.util.StringMethods;
import au.com.stgeorge.ibank.businessobject.BusinessException;
import au.com.stgeorge.ibank.businessobject.IBankSecureService;
import au.com.stgeorge.ibank.businessobject.ResourceException;
import au.com.stgeorge.ibank.common.cache.IBankParams;
import au.com.stgeorge.ibank.evcrs.businessobject.CRSService;
import au.com.stgeorge.ibank.evcrs.businessobject.valueobject.CRSInfo;
import au.com.stgeorge.ibank.evcrs.businessobject.valueobject.EVForeignCountryDetail;
import au.com.stgeorge.ibank.evcrs.businessobject.valueobject.TaxResidency;
import au.com.stgeorge.ibank.messagecentre.valueobject.MessageSearch;
import au.com.stgeorge.ibank.util.CommonBusinessUtil;
import au.com.stgeorge.ibank.valueobject.Customer;
import au.com.stgeorge.ibank.valueobject.NonFinTransactionDetails;
import au.com.stgeorge.ibank.valueobject.PhoneNumber;
import au.com.stgeorge.ibank.valueobject.collection.LabelValueMap;
import au.com.stgeorge.ibank.valueobject.database.OriginsVO;
import au.com.stgeorge.ibank.valueobject.transfer.IBankCommonData;
import au.com.stgeorge.mbank.controller.IMBController;
import au.com.stgeorge.mbank.controller.SecureCodeHelper;
import au.com.stgeorge.mbank.controller.customer.ev.CRSHelper;
import au.com.stgeorge.mbank.model.common.IMBReq;
import au.com.stgeorge.mbank.model.common.IMBResp;
import au.com.stgeorge.mbank.model.common.ReqHeader;
import au.com.stgeorge.mbank.model.common.RespHeader;
import au.com.stgeorge.mbank.model.request.EmptyReq;
import au.com.stgeorge.mbank.model.request.SecureCodeReq;
import au.com.stgeorge.mbank.model.request.customer.CRSMaintenanceReq;
import au.com.stgeorge.mbank.model.response.ErrorResp;
import au.com.stgeorge.mbank.model.response.SuccessResp;
import au.com.stgeorge.mbank.model.response.customer.CRSMaintenanceResp;
import au.com.stgeorge.mbank.session.MobileSession;
import au.com.stgeorge.mbank.session.MobileSessionImpl;
import au.com.stgeorge.mbank.util.MBAppHelper;
import au.com.stgeorge.mbank.util.MBAppUtils;
import au.com.stgeorge.mbank.util.MBAppValidator;
import au.com.stgeorge.mbank.util.ServiceConstants;
import au.com.stgeorge.perflogger.PerformanceLogger;

import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * @author c70656
 *
 */

@Controller
@RequestMapping("/crsmaintenance")
public class CRSMaintenanceController implements IMBController{

	@Autowired
	private MBAppValidator mbAppValidator;

	@Autowired
	private MBAppHelper mbAppHelper;
	
	@Autowired
    private PerformanceLogger perfLogger;
	
	@Autowired
    private CRSService crsService;
	
	@Autowired
    private CRSHelper crsHelper;
	
	@Autowired
	private SecureCodeHelper secureCodeHelper;
	
	@Autowired
	private DigitalSecLogger digitalSecLogger;
	
	@RequestMapping(value="getdata", method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public IMBResp getData(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse,
			@RequestBody final EmptyReq req){

		String logName = startPerformanceLog(httpServletRequest);
		ObjectMapper mapper = new ObjectMapper();
		MobileSession mbSession = null;
		try {
			
			mbSession = mbAppHelper.getMobileSession(httpServletRequest);		
			IBankCommonData commonData = new MBAppHelper().populateIBankCommonData(mbSession, httpServletRequest);
			Logger.info("CRSMaintenanceController.getData JSON Request :" + mapper.writeValueAsString(req), this.getClass());
			validateRequestHeader( req.getHeader(), httpServletRequest );

			ErrorResp errorResp = validate(req, httpServletRequest);
			if (errorResp != null && errorResp.getErrors() != null && errorResp.getErrors().size() > 0)
			{
				return errorResp;
			}
			
			Customer customer = commonData.getCustomer();

			Logger.info("CRSMaintenanceController.getData(): Calling crsService.getCrsInfo()", this.getClass());
			CRSInfo crsInfoVO = crsService.getCrsInfo(commonData);
			au.com.stgeorge.mbank.model.request.customer.ev.CRSInfo crsInfoObj = new au.com.stgeorge.mbank.model.request.customer.ev.CRSInfo();
			Logger.info("CRSMaintenanceController.getData(): Populate Response.", this.getClass());
			CRSMaintenanceResp serviceResponse = populateGetCRSInfoResponse(crsInfoVO,crsInfoObj ,customer.getCustTypeInd());
			if(serviceResponse.isExemptedCustomer()){
				mbSession.setSecureCodeVerifiedTranName(ServiceConstants.CRS_MAINTENANCE);
			}
			//Setting customer type if business customer			
			serviceResponse.setCustTypeInd(customer.getCustTypeInd());
			
			//X customer Fix 
			if(null!= crsInfoVO){
				mbSession.setCrsRegistrationNumber(crsInfoVO.getRegistrationNumber());
				Logger.debug("In getData :: flag value ::"+crsInfoVO.getRegistrationNumber(), this.getClass());
			}
			

			RespHeader headerResp = populateResponseHeader(ServiceConstants.CRS_MAINTENANCE, mbSession);
		    serviceResponse.setHeader(headerResp);
		    Logger.info("CRSMaintenanceController.getData JSON Response :" + mapper.writeValueAsString(serviceResponse), this.getClass());
			return serviceResponse;

		} catch (BusinessException e) {
			BusinessException exp = new BusinessException(e.getKey());
			IMBResp resp1 = MBAppUtils.createErrorResp(mbSession.getOrigin() , exp, ServiceConstants.CRS_MAINTENANCE, httpServletRequest);
			return resp1;
		} catch (ResourceException e) {
			return MBAppUtils.createErrorResp(mbSession.getOrigin(), BusinessException.SYSTEM_UNAVILABLE, ServiceConstants.CRS_MAINTENANCE, httpServletRequest);
		}catch (Exception e) {	
			IMBResp resp1 = MBAppUtils.createErrorResp(mbSession.getOrigin(),BusinessException.GENERIC_ERROR, ServiceConstants.CRS_MAINTENANCE, httpServletRequest);
			return resp1;
		} finally {
		    endPerformanceLog(logName);
		}
	    
		
	}
	
	
	
	@RequestMapping(value="save", method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public IMBResp save(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, @RequestBody final CRSMaintenanceReq req){

		String logName = startPerformanceLog(httpServletRequest);
		ObjectMapper mapper = new ObjectMapper();
		MobileSession mbSession = null;
		List<EVForeignCountryDetail> evForeignCountryDtls=new ArrayList<EVForeignCountryDetail>();
		DigitalSecLogggerVO digitalSecLoggerVO = new DigitalSecLogggerVO();
		digitalSecLoggerVO.setTranName(DigitalSecLogger.CRS_MAINTENANCE);
		digitalSecLoggerVO.setAction(DigitalSecLogger.CRS_MAINTENANCE_ACTION_ADD);
		boolean isForeignTaxResident = false;
		try {
			
			mbSession = mbAppHelper.getMobileSession(httpServletRequest);		
			IBankCommonData commonData = new MBAppHelper().populateIBankCommonData(mbSession, httpServletRequest);
			Logger.info("CRSMaintenanceController.save JSON Request :" + mapper.writeValueAsString(req), this.getClass());
			validateRequestHeader( req.getHeader(), httpServletRequest );

			evForeignCountryDtls=IBankParams.getForeignTINDetails();
			crsHelper.validateCRSData(req.getCrsInfo(), evForeignCountryDtls);
			ErrorResp errorResp = validate(req, httpServletRequest);
			if (errorResp != null && errorResp.getErrors() != null && errorResp.getErrors().size() > 0)
			{
				return errorResp;
			}

			
			CRSInfo crsInfoVo = crsHelper.populateCRSInfoVo(req.getCrsInfo(), evForeignCountryDtls);
			isForeignTaxResident = crsInfoVo.isForeignTaxResident();
			digitalSecLoggerVO.setCommonLogData(mbAppHelper.getCommonLogData(commonData));
		    digitalSecLoggerVO.setUserAgent(commonData.getUserAgent());
		    digitalSecLoggerVO.setValues(crsInfoVo.toDigitalSecurityLog(null, null,DigitalSecLogger.COUNTRY,DigitalSecLogger.TIN));
		    
			Logger.info("CRSMaintenanceController.save(): Calling crsService.updateCRSInfo()", this.getClass());
			//crsService.updateCRSInfo(commonData, crsInfoVo, null);
			//X customer fix
			String crsRegistrationNumber = mbSession.getCrsRegistrationNumber();
			Logger.debug("In CRSMaintenanceController .. crsMaintenanceSave( ) : flag value ::"+crsRegistrationNumber, this.getClass());
			crsInfoVo.setRegistrationNumber(crsRegistrationNumber);
			
			if(StringMethods.isValidString(crsRegistrationNumber) && crsRegistrationNumber.equalsIgnoreCase("X")){
				Logger.debug("Calling getCustomerTaxInfo()", this.getClass());
				au.com.stgeorge.ibank.evcrs.businessobject.valueobject.CRSInfo oldCrsInfoVO = crsService.getCrsInfo(commonData);
				crsService.updateCRSInfo(commonData,crsInfoVo,null,oldCrsInfoVO);
			}else{
				Logger.debug("In CRSMaintenanceController .. crsMaintenanceSave( ) : Non X ", this.getClass());
				crsService.updateCRSInfo(commonData,crsInfoVo,null);
			}

			Logger.info("CRSMaintenanceController.save(): Populate Response.", this.getClass());
			
			if(isForeignTaxResident){
				digitalSecLoggerVO.setStatus(DigitalSecLogger.SUCCESS);
				digitalSecLogger.log(digitalSecLoggerVO);
			}
			// going to delete crs HArd Prompt message  from DB & remove from session
			Logger.info("CRSMaintenanceController.save(): Calling crsService.updateMsgDeleteStatus() & Removing from session...", this.getClass());
			MessageSearch messageSearch=mbSession.getSplashInfoMsg();
			crsService.updateMsgDeleteStatus(messageSearch,commonData);
			mbSession.removeSplashInfoMsg();
		    
			//TODO populate resp
			CRSMaintenanceResp serviceResponse = null;
			CRSInfo crsInfoVO = crsService.getCrsInfo(commonData);
			au.com.stgeorge.mbank.model.request.customer.ev.CRSInfo crsInfoObj = new au.com.stgeorge.mbank.model.request.customer.ev.CRSInfo();
			serviceResponse = populateGetCRSInfoResponse(crsInfoVO,crsInfoObj);
			serviceResponse.setStatus("SUCCESS");
			RespHeader headerResp = populateResponseHeader(ServiceConstants.CRS_MAINTENANCE, mbSession);
		    serviceResponse.setHeader(headerResp);
		    Logger.info("CRSMaintenanceController.save JSON Response :" + mapper.writeValueAsString(serviceResponse), this.getClass());
			return serviceResponse;

		} catch (BusinessException e) {
			if(isForeignTaxResident){
				digitalSecLoggerVO.setStatus(DigitalSecLogger.FAILURE);
				digitalSecLogger.log(digitalSecLoggerVO);
			}
			BusinessException exp = new BusinessException(e.getKey());
			IMBResp resp1 = MBAppUtils.createErrorResp(mbSession.getOrigin() , exp, ServiceConstants.CRS_MAINTENANCE, httpServletRequest);
			return resp1;
		} catch (ResourceException e) {
			return MBAppUtils.createErrorResp(mbSession.getOrigin(), BusinessException.SYSTEM_UNAVILABLE, ServiceConstants.CRS_MAINTENANCE, httpServletRequest);
		}catch (Exception e) {	
			IMBResp resp1 = MBAppUtils.createErrorResp(mbSession.getOrigin(),BusinessException.GENERIC_ERROR, ServiceConstants.CRS_MAINTENANCE, httpServletRequest);
			return resp1;
		} finally {
		    endPerformanceLog(logName);
		}
	    
		
	}
	
	 @RequestMapping(method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE, value = "reqsecurecode")
		@ResponseBody
		public IMBResp reqSecureCode(HttpServletRequest httpRequest, @RequestBody final SecureCodeReq request) {
			Logger.debug("CRSMaintenanceController - reqSecureCode(). Request: " + request, this.getClass());
			String logName = startPerformanceLog(httpRequest);
			MobileSession mobileSession = null;
			IBankCommonData commonData = null;
			PhoneNumber phoneNumber = null;
			try {
				mobileSession = mbAppHelper.getMobileSession(httpRequest);	
				mobileSession.getSessionContext(httpRequest);
				commonData = new MBAppHelper().populateIBankCommonData(mobileSession, httpRequest);
				mobileSession.removeDigitalSecLoggerMap();
				
				validateRequestHeader(request.getHeader(), httpRequest);
				ErrorResp errorResponse = validate(request, httpRequest);// validate json
				if (errorResponse.hasErrors())
					return errorResponse;
				
				if (ServiceConstants.CRS_MAINTENANCE_TRAN_CODE != request.getTranType()){
					return MBAppUtils.createInvalid2FATransactionTypeResponse(ServiceConstants.CRS_MAINTENANCE);
				}
				
				LabelValueMap digitalSecLoggerMap = new LabelValueMap();
				digitalSecLoggerMap.put(DigitalSecLogger.AUTHTYPE, request.getDeliveryMethod());
				phoneNumber = CommonBusinessUtil.get2FAPhoneNumber(commonData, request.getPhone());
				digitalSecLoggerMap.put(DigitalSecLogger.AUTHPHONE, phoneNumber.getAreaCode()+phoneNumber.getPhoneNumber());
				mobileSession.setDigitalSecLoggerMap(digitalSecLoggerMap);
				
				return secureCodeHelper.reqSecureCode(commonData, mobileSession, null, new NonFinTransactionDetails() {}, request, ServiceConstants.CRS_MAINTENANCE, httpRequest);
				
			} catch (ResourceException e) {
				Logger.error("ResourceException in CRSMaintenanceController - reqSecureCode() - [key: " + e.getKey() + "], GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());
				mobileSession.removeSecureCodeDetails();
				return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.SYSTEM_UNAVILABLE, ServiceConstants.CRS_MAINTENANCE, httpRequest);
			}
			catch (Exception e) {
				Logger.error("Exception CRSMaintenanceController - reqSecureCode(): GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "]", e, this.getClass());
				mobileSession.removeSecureCodeDetails();
				return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.GENERIC_ERROR, ServiceConstants.CRS_MAINTENANCE, httpRequest);
			} finally {
				endPerformanceLog(logName);
			}

		}	
	  
	 @RequestMapping(value="check2fastatus", method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE)
	 @ResponseBody
	 public IMBResp check2FAStatus(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse,
			 @RequestBody final EmptyReq req){

		 String logName = startPerformanceLog(httpServletRequest);
		 ObjectMapper mapper = new ObjectMapper();
		 MobileSession mbSession = null;
		 String origin = null;
		 try {
			 origin = mbAppHelper.getOrigin(httpServletRequest);
			 mbSession = mbAppHelper.getMobileSession(httpServletRequest);		
			 Logger.info("CRSMaintenanceController.check2FAStatus JSON Request :" + mapper.writeValueAsString(req), this.getClass());

			 validateRequestHeader( req.getHeader(), httpServletRequest );

			 ErrorResp errorResp = validate(req, httpServletRequest);
			 if (errorResp != null && errorResp.getErrors() != null && errorResp.getErrors().size() > 0)
			 {
				 return errorResp;
			 }
			 
			 Customer customer = mbSession.getCustomer();
			 
			 if (IBankParams.isGlobalByPass() || IBankSecureService.isCustomerExempt(customer.getIBankSecureDetails())) {
				 Logger.info("CRSMaintenanceController.check2FAStatus(): The 2FA is global security bypassed. Throwing an error", this.getClass());
				 throw new BusinessException(BusinessException.CRS_MAINTENANCE_FATAL_ERROR);
			 }

			 SuccessResp successResp = new SuccessResp();
			 successResp.setIsSuccess(true);
			 RespHeader headerResp = populateResponseHeader(ServiceConstants.CRS_MAINTENANCE, mbSession);
			 successResp.setHeader(headerResp);
			 Logger.info("CRSMaintenanceController.check2FAStatus JSON Response :" + mapper.writeValueAsString(successResp), this.getClass());
			 return successResp;

		 } catch (BusinessException e) {

			 Logger.info("BusinessException in CRSMaintenanceController.check2FAStatus - [key: " + e.getKey() + "]", e, this.getClass());
			 if (e.getKey() == BusinessException.CRS_MAINTENANCE_FATAL_ERROR) {
				 OriginsVO myOriginVO = IBankParams.getOrigin(origin);
				 String[] values = { myOriginVO.getPhone(),myOriginVO.getIntPhone() };
				 ErrorResp errorResp = MBAppUtils.createErrorResp(origin, e, values, ServiceConstants.CRS_MAINTENANCE, httpServletRequest);
				 errorResp.setStatus(ErrorResp.GLOBAL_BYPASS);
				 
				 return errorResp;
			 }

			 BusinessException exp = new BusinessException(e.getKey());
			 IMBResp resp1 = MBAppUtils.createErrorResp(mbSession.getOrigin() , exp, ServiceConstants.CRS_MAINTENANCE, httpServletRequest);
			 return resp1;

		 } catch (ResourceException e) {
			 return MBAppUtils.createErrorResp(mbSession.getOrigin(), BusinessException.SYSTEM_UNAVILABLE, ServiceConstants.CRS_MAINTENANCE, httpServletRequest);
		 }catch (Exception e) {	
			 IMBResp resp1 = MBAppUtils.createErrorResp(mbSession.getOrigin(),BusinessException.GENERIC_ERROR, ServiceConstants.CRS_MAINTENANCE, httpServletRequest);
			 return resp1;
		 } finally {
			 endPerformanceLog(logName);
		 }

	 }

	 
	@Override
	public void validateRequestHeader(ReqHeader headerReq,
			HttpServletRequest request) throws BusinessException {
		mbAppValidator.validateRequestHeader(headerReq,  request);
		
	}

	@Override
	public ErrorResp validate(IMBReq serviceRequest,
			HttpServletRequest httpRequest) throws BusinessException {
		return mbAppValidator.validate(serviceRequest, httpRequest);
	}

	@Override
	public RespHeader populateResponseHeader(String serviceName,
			MobileSession mobileSession) {
		return mbAppHelper.populateResponseHeader(serviceName,mobileSession);
	}
	
	
	private String startPerformanceLog(HttpServletRequest httpRequest) {
		perfLogger.startAllLogs();
		String logName = MBAppUtils.getLogName(httpRequest);
		perfLogger.startLog(logName);
		return logName;
    }

    private void endPerformanceLog(String logName) {
		perfLogger.endLog(logName);
		perfLogger.endAllLogs();
    }
    
    
    //TODO temp change, will be removed
    private CRSMaintenanceResp populateGetCRSInfoResponse(au.com.stgeorge.ibank.evcrs.businessobject.valueobject.CRSInfo crsInfoVO, au.com.stgeorge.mbank.model.request.customer.ev.CRSInfo crsInfoObj,String... custTypeInd){

		//Populate Response
		CRSMaintenanceResp response = new CRSMaintenanceResp();
		if(crsInfoVO != null && !("X".equalsIgnoreCase(crsInfoVO.getRegistrationNumber()))){
			Logger.info("crsInfoVO not null and RegistrationNumber is Y or N", this.getClass());
			crsHelper.populateCRSInfo(crsInfoVO, crsInfoObj);
			response.setCrsInfoAvailable(true);
		}else{
			
			if(crsInfoVO != null && ("X".equalsIgnoreCase(crsInfoVO.getRegistrationNumber()))){
				Logger.info("crsInfoVO not null and ResgistrationNumber is X ", this.getClass());
				response.setExemptedCustomer(true);
			}
			Logger.info("crsInfoVO null", this.getClass());
			response.setCrsInfoAvailable(false);
			populateCRSUIInformation(crsInfoObj ,custTypeInd);
			response.setCountries(crsHelper.getCountryList());
		}
		
		response.setCrsInfo(crsInfoObj);
		return response;
	}
	
    private CRSMaintenanceResp populateGetCRSInfoUpdateResponse(au.com.stgeorge.ibank.evcrs.businessobject.valueobject.CRSInfo crsInfoVO, au.com.stgeorge.mbank.model.request.customer.ev.CRSInfo crsInfoObj, String... custTypeInd){
    	//Populate Response
    	CRSMaintenanceResp response = new CRSMaintenanceResp();
    	if(crsInfoVO != null){
    		crsHelper.populateCRSInfoForUpdate(crsInfoVO, crsInfoObj);
    		response.setCrsInfoAvailable(true);
    		populateCRSUIInformation(crsInfoObj , custTypeInd);
    		response.setCountries(crsHelper.getCountryList());
    		response.setCrsInfo(crsInfoObj);
    	}
    	return response;
    }
    
	private void populateCRSUIInformation(au.com.stgeorge.mbank.model.request.customer.ev.CRSInfo crsInfoObj ,String... custTypeInd) {
		List<String> mandatoryReasonList = crsHelper.getMandatoryReasonList(custTypeInd);
		crsInfoObj.setMandatoryTINReasons(mandatoryReasonList);
		Logger.info("crsInfoVO getMandatoryReasonList=" + mandatoryReasonList, this.getClass());
		List<String> optionalReasonList = crsHelper.getOptionalReasonList(custTypeInd);
		crsInfoObj.setOptionalTINReasons(optionalReasonList);
		Logger.info("crsInfoVO getOptionalReasonList="+optionalReasonList, this.getClass());
		List<EVForeignCountryDetail> evForeignCountryDtls=IBankParams.getForeignTINDetails();
		Logger.info("crsInfoVO evForeignCountryDtls="+evForeignCountryDtls, this.getClass());
		crsInfoObj.setEvForeignCountryResp(crsHelper.getForeignCountriesAndTINRegex(evForeignCountryDtls));
		Logger.info("crsInfoVO getEvForeignCountryResp="+crsInfoObj.getEvForeignCountryResp(), this.getClass());
	}



	@RequestMapping(method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE, value = "verifysecurecode")
	@ResponseBody
	public IMBResp verifySecureCode(HttpServletRequest httpRequest, @RequestBody final SecureCodeReq request) {
		Logger.debug("CRSMaintenanceController - verifySecureCode(). Request: " + request, this.getClass());
		String logName = startPerformanceLog(httpRequest);
		MobileSession mobileSession = new MobileSessionImpl();
		ObjectMapper mapper = new ObjectMapper();
		try {
			mobileSession.getSessionContext(httpRequest);
			IBankCommonData commonData = new MBAppHelper().populateIBankCommonData(mobileSession, httpRequest);
			
			//Setting customer type if business customer
			Customer customer = commonData.getCustomer();
			
			validateRequestHeader(request.getHeader(), httpRequest);
			ErrorResp errorResponse = validate(request, httpRequest);// validate json
			if (errorResponse.hasErrors())
				return errorResponse;
			if (ServiceConstants.CRS_MAINTENANCE_TRAN_CODE != request.getTranType()){
				return MBAppUtils.createInvalid2FATransactionTypeResponse(ServiceConstants.CRS_MAINTENANCE);
			}
			errorResponse = secureCodeHelper.verifySecureCode(commonData, mobileSession, new NonFinTransactionDetails() {},
											request, ServiceConstants.CRS_MAINTENANCE, httpRequest);
			if (errorResponse.hasErrors()) {
			    return errorResponse;
			} else{
				Logger.info("CRSMaintenanceController.verifySecureCode: Calling crsService.getCrsInfo()", this.getClass());
				CRSInfo crsInfoVO = crsService.getCrsInfo(commonData);
				au.com.stgeorge.mbank.model.request.customer.ev.CRSInfo crsInfoObj = new au.com.stgeorge.mbank.model.request.customer.ev.CRSInfo();
				Logger.info("CRSMaintenanceController.verifySecureCode(): Populate Response.", this.getClass());
				CRSMaintenanceResp serviceResponse = populateGetCRSInfoUpdateResponse(crsInfoVO, crsInfoObj,customer.getCustTypeInd());
			    Logger.debug("CRSMaintenanceController.verifySecureCode() JSON Response :" + mapper.writeValueAsString(serviceResponse), this.getClass());
			    serviceResponse.setCustTypeInd(customer.getCustTypeInd());
				//set a value in session if 2fa verification is successful. This will be used to validate CRS update without 2FA check
				RespHeader headerResp = populateResponseHeader(ServiceConstants.CRS_MAINTENANCE, mobileSession);
			    serviceResponse.setHeader(headerResp);
				mobileSession.setSecureCodeVerifiedTranName(ServiceConstants.CRS_MAINTENANCE);
				return serviceResponse;
			}
			
		} catch (ResourceException e) {
			Logger.error("Exception CRSMaintenanceController - verifySecureCode(): GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "]", e, this.getClass());
			mobileSession.removeSecureCodeDetails();
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.SYSTEM_UNAVILABLE, ServiceConstants.CRS_MAINTENANCE, httpRequest);
		} 
		catch (Exception e) {
			Logger.error("Exception CRSMaintenanceController - verifySecureCode(): GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "]", e, this.getClass());
			mobileSession.removeSecureCodeDetails();
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.GENERIC_ERROR, ServiceConstants.CRS_MAINTENANCE, httpRequest);
		} finally {
			endPerformanceLog(logName);
		}

	}	
	
	@RequestMapping(value="update", method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public IMBResp update(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, @RequestBody final CRSMaintenanceReq req){

		String logName = startPerformanceLog(httpServletRequest);
		ObjectMapper mapper = new ObjectMapper();
		MobileSession mbSession = null;
		List<EVForeignCountryDetail> evForeignCountryDtls=new ArrayList<EVForeignCountryDetail>();
		DigitalSecLogggerVO digitalSecLoggerVO = new DigitalSecLogggerVO();
		digitalSecLoggerVO.setTranName(DigitalSecLogger.CRS_MAINTENANCE);
		digitalSecLoggerVO.setAction(DigitalSecLogger.CRS_MAINTENANCE_ACTION_UPDATE);
		
		try {
			
			mbSession = mbAppHelper.getMobileSession(httpServletRequest);		
			IBankCommonData commonData = new MBAppHelper().populateIBankCommonData(mbSession, httpServletRequest);
			Logger.info("CRSMaintenanceController.update JSON Request :" + mapper.writeValueAsString(req), this.getClass());
			validateRequestHeader( req.getHeader(), httpServletRequest );

			evForeignCountryDtls=IBankParams.getForeignTINDetails();
			crsHelper.validateCRSData(req.getCrsInfo(), evForeignCountryDtls);
			ErrorResp errorResp = validate(req, httpServletRequest);
			
			Customer customer = commonData.getCustomer();
			
			if (errorResp != null && errorResp.getErrors() != null && errorResp.getErrors().size() > 0)
			{
				Logger.info("CRSMaintenanceController.update JSON ERROR Response Return :" + mapper.writeValueAsString(errorResp), this.getClass());
				return errorResp;
			}

			if ( ! ServiceConstants.CRS_MAINTENANCE.equalsIgnoreCase(mbSession.getSecureCodeVerifiedTranName()) )
			{
				Logger.error("CRSMaintenanceController.update(): Secure not verified. Session Sec Code Vale : "+ mbSession.getSecureCodeVerifiedTranName(), this.getClass());
				throw new ResourceException(ResourceException.SYSTEM_ERROR, "CRSMaintenanceController.update(): Secure not verified. Session Sec Code Vale : "+ mbSession.getSecureCodeVerifiedTranName());
			}
			
			CRSInfo crsInfoModel = crsHelper.populateCRSInfoVo(req.getCrsInfo(), evForeignCountryDtls);
			
			digitalSecLoggerVO.setCommonLogData(mbAppHelper.getCommonLogData(commonData));
		    digitalSecLoggerVO.setUserAgent(commonData.getUserAgent());
		    LabelValueMap digitalSecMap = mbSession.getDigitalSecLoggerMap();

		    Logger.info("CRSMaintenanceController.update(): Calling crsService.updateCRSInfo()", this.getClass());
			//TODO: Call New UPDATE CALL instead of this call 
			boolean success = compareAndgenerateCRSInfoUpdate(commonData, crsInfoModel,digitalSecLoggerVO,digitalSecMap);
			Logger.info("CRSMaintenanceController.update(): Populate Response.", this.getClass());
			
			//TODO populate resp
		
		    
			CRSMaintenanceResp serviceResponse = null;
			
			if(success){
				Logger.info("CRSMaintenanceController.update(): Update is Successful : Calling crsService.getCrsInfo()", this.getClass());
				
				CRSInfo crsInfoVO = crsService.getCrsInfo(commonData);
				au.com.stgeorge.mbank.model.request.customer.ev.CRSInfo crsInfoObj = new au.com.stgeorge.mbank.model.request.customer.ev.CRSInfo();
				serviceResponse = populateGetCRSInfoResponse(crsInfoVO,crsInfoObj);
				serviceResponse.setCustTypeInd(customer.getCustTypeInd());
				RespHeader headerResp = populateResponseHeader(ServiceConstants.CRS_MAINTENANCE, mbSession);
			    serviceResponse.setHeader(headerResp);
				serviceResponse.setStatus("SUCCESS");
				Logger.info("CRSMaintenanceController.update JSON Response :" + mapper.writeValueAsString(serviceResponse), this.getClass());
				digitalSecLoggerVO.setStatus(DigitalSecLogger.SUCCESS);
			    digitalSecLogger.log(digitalSecLoggerVO);
			}
		    
			return serviceResponse;

		} catch (BusinessException e) {
			digitalSecLoggerVO.setStatus(DigitalSecLogger.FAILURE);
			digitalSecLogger.log(digitalSecLoggerVO);
			BusinessException exp = new BusinessException(e.getKey());
			IMBResp resp1 = MBAppUtils.createErrorResp(mbSession.getOrigin() , exp, ServiceConstants.CRS_MAINTENANCE, httpServletRequest);
			return resp1;
		} catch (ResourceException e) {
			return MBAppUtils.createErrorResp(mbSession.getOrigin(), BusinessException.SYSTEM_UNAVILABLE, ServiceConstants.CRS_MAINTENANCE, httpServletRequest);
		}catch (Exception e) {	
			IMBResp resp1 = MBAppUtils.createErrorResp(mbSession.getOrigin(),BusinessException.GENERIC_ERROR, ServiceConstants.CRS_MAINTENANCE, httpServletRequest);
			return resp1;
		} finally {
			mbSession.removeDigitalSecLoggerMap();
		    endPerformanceLog(logName);
		}
		
	}
	
	private boolean compareAndgenerateCRSInfoUpdate(IBankCommonData commonData, au.com.stgeorge.ibank.evcrs.businessobject.valueobject.CRSInfo crsModel,DigitalSecLogggerVO digitalSecLoggerVO,LabelValueMap digitalSecMap) throws ResourceException, BusinessException {
		//Individual individualOldData = crsService.getCustomerTaxInfo(commonData);
		au.com.stgeorge.ibank.evcrs.businessobject.valueobject.CRSInfo oldCrsInfoVO = crsService.getCrsInfo(commonData);
		boolean success=false;
		String authType = null;
		String authPhone = null;
		
		if(null != digitalSecMap){
			authType = digitalSecMap.get(DigitalSecLogger.AUTHTYPE);
			authPhone = digitalSecMap.get(DigitalSecLogger.AUTHPHONE);
		}
		
		digitalSecLoggerVO.setValues(oldCrsInfoVO.toDigitalSecurityLog(authType,authPhone,
		DigitalSecLogger.FROM_COUNTRY,DigitalSecLogger.FROM_TIN) + crsModel.toDigitalSecurityLog(null,null,
		DigitalSecLogger.TO_COUNTRY,DigitalSecLogger.TO_TIN));
		
		/*
		 * Yes to No and No to Yes
		 * */
		if((oldCrsInfoVO.isForeignTaxResident() && !crsModel.isForeignTaxResident()) || (!oldCrsInfoVO.isForeignTaxResident() && crsModel.isForeignTaxResident())) {
			crsService.updateCRSInfo(commonData,crsModel,null,oldCrsInfoVO);
			success = true;
		}
		/*
		 * No to No
		 * */
		else if(!oldCrsInfoVO.isForeignTaxResident() && !crsModel.isForeignTaxResident()) {
			crsService.updateCRSInfo(commonData,crsModel,null,oldCrsInfoVO);
			return true;
		}
		/*
		 * All other scenarios
		 * */
		else if(oldCrsInfoVO.isForeignTaxResident() && crsModel.isForeignTaxResident()) {
			
			List<TaxResidency> crsInfoVOList = oldCrsInfoVO.getTaxResidencyList();
			List<TaxResidency> crsModelList = crsModel.getTaxResidencyList();
			List<TaxResidency> crsInfoVOListCopy = null,crsModelListCopy = null;
			
			au.com.stgeorge.ibank.evcrs.businessobject.valueobject.CRSInfo oldUpdatedCrsInfoVO = oldCrsInfoVO;
			
			if(!(crsInfoVOList.containsAll(crsModelList) && crsModelList.containsAll(crsInfoVOList))) {
				crsInfoVOListCopy = new ArrayList<TaxResidency>();
				crsModelListCopy = new ArrayList<TaxResidency>();
				crsInfoVOListCopy.addAll(crsInfoVOList);
				crsModelListCopy.addAll(crsModelList);
								
				for(int i=crsInfoVOList.size()-1;i>=0;i--) {
					if(crsModelList.contains(crsInfoVOList.get(i))) {
						crsInfoVOListCopy.remove(i);
						crsModelListCopy.remove(crsModelList.indexOf(crsInfoVOList.get(i)));
					}
				}

				Logger.info("Old Tax Residency List: "+crsInfoVOListCopy,getClass());
				Logger.info("New Tax Residency List: "+crsModelListCopy,getClass());

				oldCrsInfoVO.setTaxResidencyList(crsInfoVOListCopy);
				crsModel.setTaxResidencyList(crsModelListCopy);
			}
			else {
				oldCrsInfoVO.setTaxResidencyList(crsInfoVOList);
				crsModel.setTaxResidencyList(crsModelList);		
			}
			
			crsService.updateCRSInfo(commonData,crsModel,null,oldCrsInfoVO,oldUpdatedCrsInfoVO);
			success = true;
		}
		return success;
	}	
	
    
}
