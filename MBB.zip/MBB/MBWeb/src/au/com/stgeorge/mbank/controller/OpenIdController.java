package au.com.stgeorge.mbank.controller;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.AbstractController;

import com.fasterxml.jackson.databind.ObjectMapper;

import au.com.stgeorge.framework.common.logging.Logger;
import au.com.stgeorge.framework.common.util.DateMethods;
import au.com.stgeorge.ibank.businessobject.BusinessException;
import au.com.stgeorge.ibank.businessobject.ContextHandoverService;
import au.com.stgeorge.ibank.businessobject.ResourceException;
import au.com.stgeorge.ibank.businessobject.SystemInformation;
import au.com.stgeorge.ibank.businessobject.globalWallet.GlobalWalletService;
import au.com.stgeorge.ibank.businessobject.loanapplication.LoanApplicationServiceImpl;
import au.com.stgeorge.ibank.common.cache.IBankParams;
import au.com.stgeorge.ibank.util.ServiceHelper;
import au.com.stgeorge.ibank.util.StringUtil;
import au.com.stgeorge.ibank.valueobject.Customer;
import au.com.stgeorge.ibank.valueobject.database.CodesVO;
import au.com.stgeorge.ibank.valueobject.database.GlobalWallet;
import au.com.stgeorge.ibank.valueobject.database.OriginsVO;
import au.com.stgeorge.ibank.valueobject.globalWallet.GCCContextHandOverVO;
import au.com.stgeorge.ibank.valueobject.transfer.IBankCommonData;
import au.com.stgeorge.mbank.controller.customer.CookieLogonBean;
import au.com.stgeorge.mbank.controller.customer.LogonHelper;
import au.com.stgeorge.mbank.session.MobileSession;
import au.com.stgeorge.mbank.util.MBAppConstants;
import au.com.stgeorge.mbank.util.MBAppHelper;
import au.com.stgeorge.mobilebank.businessobject.MobileBankService;
import au.com.stgeorge.mobilebank.businessobject.impl.MobileBankServiceImpl;
import au.com.stgeorge.security.util.StringMethods;
import au.com.stgeorge.framework.common.util.DateMethods;

public class OpenIdController extends AbstractController
{

	private static volatile int numberOfRequests = 0;
	public static final String REQ_ACTION_STR = "action";
	private static final String REQ_IGNORE_SEC_FLAG =  "SIMPLE-LOGON" ;
	//private static final String REQ_NORMAL_LOGON = "NORMAL";
	private static final String REQ_DASHBOARD = "DASHBOARD";   // Used by Native App logon My accounts
	//private static final String REQ_ACTIVATION_LOGON = "ACTIVATION";
	//private static final String REQ_PWD_RESET = "PWDRESET";
	public static final String MAIN_VIEW = "Index";
	private static final String ERROR_VIEW = "404";
	private static final String SESSION_EXPIRY_VIEW = "sessionExpiryPage";
	public static final String REQ_LOAD_CORDOVA = "LoadCordova";
	public static final String PWD_RESET_URL = "PwdResetURL";
	public static final String HELP_DESK_NO = "HelpDeskNo";

	public static final String NUM_KEYBOARD_TYPE = "NumKeyBoardType";
	public static final String NUM_KEYBOARD_PATTERN_TYPE = "NumKeyBoardTypePattern";
	
	public static final String SYS_VERSION = "SysVersion";
	public static final String ORIGIN_NAME = "OriginName";
	
	public static final String PRELOAD_VALUE = "PreLoadParam";
	public static final String WEB_CONTEXT = "WebContext";
	
	public static final String REQ_ACTION_TYPE = "ActionType";  // Used By GCC and BT Now...
	/*public static final String APPLY_GCC ="applyGCC";
	public static final String SERVICE_MENU ="serviceMenu";
	public static final String APPLY_BT ="applyBT";
	public static final String BT_SUPER_SEARCH ="btSuperSearch";
	public static final String CHANGE_CARD_PIN ="changeCardPIN";
	public static final String REQ_ALLOWS_APPACTION_POST = "AppActionPost";*/
	public static final String CAN_RETRIEVAL_URL = "CANRetrievalURL";
	public static final String PWD_URL = "PwdURL";
	public static final String GDW_ACTION_CONNECT = "PHLNK";
/*	public static final String GDW_ACTION_MB = "MBLNK";
	public static final String REQ_ACTION_SOURCE = "ActionSource";
	public static final String REQ_ACTION_ID = "ActionId";  //
	public static final String ONBOARDING_STATUS ="Onboardingstatus";
	public static final String GET_CASH_INDICATOR = "getcashind";
*/	public static final String ONLINE_REG_SWITCH = "OnlineRegSwitch";
	public static final String ANDROID_BACK_BTN = "androidback";
	/*private static final String ACTION_TYPE_OPEN_ACCT = "openAcct";
	private static final String CUST_TYPE = "custType";
	private static final String PROD_TYPE = "product";
	private static final String CUST_TYPE_SOLE_TRADER = "soleTrader";
	private static final String CUST_TYPE_SOLE_DIRECTOR = "soleDirector";
	private static final String PROD_TYPE_FREEDOM_BUSINESS = "freedomBusiness";
	private static final String PROD_TYPE_SAVING_BUSINESS = "savingBusiness";
	private static final String ACTION_TYPE_SOLE_FREEDOM_BUSINESS = "busFreedomSol";
	private static final String ACTION_TYPE_SOLE_SAVING_BUSINESS = "busSaverSol";
	private static final String ACTION_TYPE_SOLE_DIR_FREEDOM_BUSINESS = "busFreedomSolDir";
	private static final String ACTION_TYPE_SOLE_DIR_SAVING_BUSINESS = "busSaverSolDir";
	
	public static final String CONTENT_ID = "ContentId";
	*/	
	private static final String BLOCK_CHARS = "^[0-9A-Za-z',. &/\\-_]*$";
	
	public static final String GCC_REQ_ACTION_STR = "gccAction";
	
	public static final String FIX_BOTTOM_MENU_SWITCH = "FixMenuIconSwitch";
	public static final String SESSION_EXPIRED = "sessionexpired";
	
	@Autowired
	private GlobalWalletService globalWalletService;
	
	@Autowired
	private LoanApplicationServiceImpl loanApplService;
	
	@Autowired
	private MBAppHelper mbAppHelper;
	
	@Autowired
	private ContextHandoverService contextHandoverService;
	
	//private static final String CONTEXT_HANDOVER_REF_ID_VALID_CHAR_SET = "^[0-9A-Za-z'\\-_,. &/]*$";
	
	
	/*public static final String AEM_DIGEST = "aemDigester";
	public static final String DEMO = "isDemo";
*/
	@Override
	protected ModelAndView handleRequestInternal(HttpServletRequest request, HttpServletResponse response) throws Exception
	{
		//PerformanceLogger performanceLogger = new PerformanceLogger();
		//performanceLogger.startAllLogs();
		//String logName = MBAppUtils.getLogName(request);
		//performanceLogger.startLog(logName);
		
		ModelAndView model = null;
		String origin = null;
		String numKeyType = null;
		String numKeyTypePattern = null;
		MobileSession mbSession =  null;
		try
		{
			numberOfRequests ++;
			logonHelper.setWebReadyCookie(request, response , "0" );
			
			//boolean isDemo = logonHelper.isDemo();
			
			/*if ( isDemo )
			{
				origin = logonHelper.resolveDemoOrigin( request);	
				HttpSession httpSession = request.getSession();
				Logger.info(" Demo Details "+ origin  + " httpSession.isNew() "+ httpSession.isNew() + " httpSession ID :"+ httpSession.getId() , this.getClass());
				if ( ! httpSession.isNew() )
				{
					Object originObj = request.getParameter("origin");
					if ( originObj != null  )
					{
						if ( origin.trim().length() == 3 )
							origin = "M"+(String) originObj; 
					} 
					else if  ( httpSession.getAttribute(LogonHelper.ORIGIN) != null )
					{
						origin = (String) httpSession.getAttribute(LogonHelper.ORIGIN);
					}
					
					if ( StringMethods.isEmptyString(origin ) )
					{
						origin = "MSTG";
					}
					httpSession.invalidate();
					httpSession = request.getSession();
					Logger.info(" Demo Details ( New ) "+ origin  + " httpSession.isNew() "+ httpSession.isNew() + " httpSession ID :"+ httpSession.getId() , this.getClass());
				}
				httpSession.setAttribute(LogonHelper.ORIGIN, origin);
				
				String aemContentDigest = StringMethods.safeString(request.getParameter(ContentManagementService.AEM_DIGEST), "");
				
				Logger.info(" aemContentDigest :  "+ aemContentDigest , this.getClass());
				//request.setAttribute(DeeplinkController.AEM_DIGEST, aemContentDigest);
				//request.setAttribute(DeeplinkController.DEMO, "true");

				
			}
			else
			{*/
				origin = logonHelper.resolveOrigin(request);
			//}

			request.setAttribute(OpenIdController.WEB_CONTEXT, logonHelper.getMBWebResourceContext());
			
			if ( StringMethods.isEmptyString(origin) )
			{
				origin = "MSTG";
				request.setAttribute(LogonHelper.ORIGIN, origin);
				Logger.info("Unable to resolve the origin  Request Details. URL : "+ request.getRequestURL() + " IP :" + request.getRemoteAddr() + " Number Of Requests : "+ numberOfRequests +
						" True IP >> " + request.getHeader(IBankParams.trueClientIP()), this.getClass());
				model = new ModelAndView(ERROR_VIEW);
			}
			else
			{
				request.setAttribute(LogonHelper.ORIGIN, origin);
				request.setAttribute(PRELOAD_VALUE, 2);  // Complete
				
				numKeyType =  logonHelper.getNumKeyBoardType(request);
				numKeyTypePattern =  logonHelper.getNumKeyBoardPattern(request);
				request.setAttribute(NUM_KEYBOARD_TYPE, numKeyType);
				request.setAttribute(NUM_KEYBOARD_PATTERN_TYPE, numKeyTypePattern);
				if ( this.systemInformation == null )
				{
					Logger.info("************ Loading systemInformation *************** "+ request.getRequestURL()   , this.getClass());
					this.systemInformation = getSystemInformationDtls();
				}
				request.setAttribute(SYS_VERSION, this.systemInformation.getMB3PackageVersion());
				OriginsVO originVO = IBankParams.getOrigin(origin);
				request.setAttribute(ORIGIN_NAME, originVO.getName());
			//	
				String pwdResetUrl = IBankParams.getCodesData( originVO.getBankName(),IBankParams.EXTERNAL_LINKS,  PWD_URL).getMessage();	
				request.setAttribute(PWD_RESET_URL, pwdResetUrl);
				
				String canRetrievalUrl = IBankParams.getCodesData( originVO.getBankName(),IBankParams.EXTERNAL_LINKS,  CAN_RETRIEVAL_URL).getMessage();
				request.setAttribute(CAN_RETRIEVAL_URL, canRetrievalUrl);
				
				request.setAttribute(HELP_DESK_NO, originVO.getPhone());
				
				

				
				String onlineRegSwitch = "ON";
				CodesVO codesVO = IBankParams.getCodesData(origin,	IBankParams.CONFIGURATION_PROPERTIES, IBankParams.ONLINE_REG_SWITCH);
				if ( codesVO != null  && "OFF".equalsIgnoreCase(codesVO.getMessage())){
					onlineRegSwitch = "OFF";
				}
				request.setAttribute(ONLINE_REG_SWITCH, onlineRegSwitch);
				
				String fixBottomMenuSwitchVal = "ON";
				codesVO = IBankParams.getCodesData(origin,	IBankParams.CONFIGURATION_PROPERTIES, FIX_BOTTOM_MENU_SWITCH);
				if ( (codesVO == null) || codesVO != null  && "OFF".equalsIgnoreCase(codesVO.getMessage())){
					fixBottomMenuSwitchVal = "OFF";
				}
				request.setAttribute(FIX_BOTTOM_MENU_SWITCH, fixBottomMenuSwitchVal);
				
				request.setAttribute(ANDROID_BACK_BTN, "ON");
				
				model = new ModelAndView(MAIN_VIEW);
				Logger.info(originVO.toXml() + " \nInside OpenId Controller  Request Details. URL : "+ request.getRequestURL() + " IP :" + request.getRemoteAddr() + " Number Of Requests : "+ numberOfRequests +
						" True IP >> " + request.getHeader(IBankParams.trueClientIP()), this.getClass());

				String actionType = request.getParameter(REQ_ACTION_TYPE);
				
				if(!isValidActionType(actionType)){
					Logger.info("Invalid Character in Action Type " + actionType,  this.getClass());
					throw new BusinessException(BusinessException.INVALID_CHAR_SET, "Invalid Character");
				}
				
				if(! StringMethods.isEmptyString(actionType) && SESSION_EXPIRED.equalsIgnoreCase(actionType) ){
					Logger.info("actionType : "+actionType + ". Redirecting to UI for session expiry page.", this.getClass());
					model = new ModelAndView(SESSION_EXPIRY_VIEW);
					return model;
				}
				
				mbSession = mbAppHelper.getMobileSession(request);
				IBankCommonData commonData = mbAppHelper.populateIBankCommonData(mbSession, request);
				findPageToBeDisplayed(request, response, origin, mbSession, commonData);
				

			}
			return model;
		}
		catch ( Exception e)
		{
			origin = "MSTG";
			request.setAttribute(LogonHelper.ORIGIN, origin);
			model = new ModelAndView(ERROR_VIEW);
			Logger.error("Error in Main Controller " , e, this.getClass());
			return model;
		}
		finally
		{
			numberOfRequests--;
			//performanceLogger.endLog(logName);
			//performanceLogger.endAllLogs();
		}
	}

	private void findPageToBeDisplayed(HttpServletRequest request, HttpServletResponse response, String origin, MobileSession mbSession, IBankCommonData commonData) throws ResourceException, Exception
	{
		CookieLogonBean cookieBean = logonHelper.populateCookieLogonBean(request);
		
		if ( cookieBean != null )
		Logger.info(" Screen Type " +cookieBean.isIgnoreSec() , this.getClass());

		/*if (request.getRequestURL().toString().endsWith(REQ_ACTIVATION_LOGON.toLowerCase()))
		{
			request.setAttribute(REQ_ACTION_STR, REQ_ACTIVATION_LOGON);
			request.setAttribute(REQ_IGNORE_SEC_FLAG,  IBankParams.NO);
		} else if(request.getRequestURL().toString().endsWith(REQ_PWD_RESET.toLowerCase()))
		{   
			request.setAttribute(REQ_ACTION_STR,REQ_PWD_RESET);
	     	request.setAttribute(REQ_IGNORE_SEC_FLAG,  IBankParams.NO);	
		}else if (cookieBean == null || logonHelper.isDemo())
		{
			request.setAttribute(REQ_ACTION_STR, REQ_NORMAL_LOGON);
			request.setAttribute(REQ_IGNORE_SEC_FLAG, IBankParams.NO);
		} else
		{
			if (cookieBean.isIgnoreSec())
			{
				request.setAttribute(REQ_ACTION_STR, REQ_IGNORE_SEC_FLAG);
				request.setAttribute(REQ_IGNORE_SEC_FLAG, IBankParams.YES);
			} else
			// if (!cookieBean.isIgnoreSec())
			{
				request.setAttribute(REQ_ACTION_STR, REQ_NORMAL_LOGON);
				request.setAttribute(REQ_IGNORE_SEC_FLAG, IBankParams.NO);
			}
			/*
			 * { request.setAttribute(REQ_ACTION_STR, "simple");
			 * request.setAttribute(REQ_IGNORE_SEC_FLAG, "Y"); }
			 */
		//}
		
		//TODO for REQ_IGNORE_SEC_FLAG
		
		String actionType = request.getParameter(REQ_ACTION_TYPE);
		
		if(!isValidActionType(actionType)){
			Logger.info("Invalid Character in Action Type " + actionType,  this.getClass());
			throw new BusinessException(BusinessException.INVALID_CHAR_SET, "Invalid Character");
		}
		
		//if(IBankParams.isSwitchOn(origin, IBankParams.GCC_MASTER_CARD_SWITCH)){
		Logger.debug("findPageToBeDisplayed actionType" + actionType,  this.getClass());
		Logger.debug("findPageToBeDisplayed gcis" + commonData.getCustomer().getGcis(),  this.getClass());
		if(IBankParams.isGCCMasterCardOriginationSwitchOn(commonData.getOrigin(), commonData.getCustomer().getGcis())) {
			if(! StringMethods.isEmptyString(actionType) && (IBankParams.GLOBAL_WALLET_PIN_BRANCH_PACK.equalsIgnoreCase(actionType) || IBankParams.GCC_ORIGINATION_SUCCESS.equalsIgnoreCase(actionType))){
				
				try{
					String referenceId = request.getParameter("referenceId");
					Logger.debug("referenceId : " + referenceId,  this.getClass());
					if(IBankParams.GLOBAL_WALLET_PIN_BRANCH_PACK.equalsIgnoreCase(actionType) && !StringMethods.isEmptyString(referenceId)
							&& StringUtil.isValidData(referenceId, ContextHandoverService.CONTEXT_HANDOVER_REF_ID_VALID_CHAR_SET) ){
						GCCContextHandOverVO contextHandOverVO = contextHandoverService.getGCCContextHandOverData(commonData, referenceId);
						//TODO print return object
						//ObjectMapper objectMapper = new ObjectMapper();	
						//TODO info or debug
						if(contextHandOverVO != null){
							
							//Logger.info("contextHandOverVO :" + objectMapper.writeValueAsString(contextHandOverVO), this.getClass());
							Logger.debug("contextHandOverVO.getCardHolderId :" + contextHandOverVO.getCardHolderId(), this.getClass());
							Logger.debug("contextHandOverVO.getCardNumber :" + contextHandOverVO.getCardNumber(), this.getClass());
							Logger.debug("contextHandOverVO.getAdditionalCardNumber :" + contextHandOverVO.getAdditionalCardNumber(), this.getClass());
							Logger.debug("contextHandOverVO.safiLast2FASuccessTime :" + contextHandOverVO.getSafiLast2FASuccessTime(), this.getClass());
							
							if(!StringMethods.isEmptyString(contextHandOverVO.getSafiLast2FASuccessTime())  && !StringMethods.isEmptyString(contextHandOverVO.getSafiStatus() )) {
								Date safiLast2FASuccessTime = DateMethods.getUtilDateTime(contextHandOverVO.getSafiLast2FASuccessTime(), "yyyy-MM-dd HH:mm:ss.SSS");
								if(safiLast2FASuccessTime!=null) {
									mbSession.setSafiLast2FASuccessTime(safiLast2FASuccessTime);
	
									//20E4 -- WWW -- For storing actionType coming from WDPUI, which is used for bypassing the 2FA in setpin flow
									//Only if it is from branch pack and safiLast2FASuccessTime has some value 
									if(IBankParams.GLOBAL_WALLET_PIN_BRANCH_PACK.equalsIgnoreCase(actionType)  && ContextHandoverService.SAFI_STATUS_CHECK_PERFORMED.equalsIgnoreCase(contextHandOverVO.getSafiStatus()) ) {
										Logger.info("findPageToBeDisplayed() : it is from branch pack and safiLast2FASuccessTime has some value : bypass the 2FA in setpin flow", this.getClass());
										mbSession.setActionType(actionType);
									}
									
								}

							}
							
						}
						

					}
				}
				catch ( Exception e)
				{
					Logger.error("Error in calling getHandoverData " , e, this.getClass());
				}
				
				
				
				//Get InitiatedGlobalWalletCardId from session
				Long requestId = mbSession.getInitiatedGlobalWalletId();
				
				if(requestId!=null){
					List<GlobalWallet> initiatedGlobalWalletList = new ArrayList<>();
					
					//Call service to get account from API and update DB
					GlobalWallet initiatedGlobalWallet = new GlobalWallet();
					initiatedGlobalWallet.setRequestId(requestId);				
					initiatedGlobalWalletList.add(initiatedGlobalWallet);
					
					boolean isAccountUpdated = globalWalletService.updateOpenedGlobalWalletInfo(initiatedGlobalWalletList, null, commonData, actionType);
					
					if(isAccountUpdated) {
						mbSession.removeCustomer();//this is set to null so as UI will make refersh Customer call
					
						//getCustomer
						MobileBankService mobileBankService = (MobileBankService) ServiceHelper.getBean(MBAppConstants.SPRING_MOBILE_SERVICE_BEAN);
						commonData.setCustomer(null);
						
						Customer customer = mobileBankService.getCustomer(commonData, MobileBankServiceImpl.SIMPLIFIED_LOGON);
						mbSession.setCustomer(customer);
					}
					
					if(IBankParams.GCC_ORIGINATION_SUCCESS.equalsIgnoreCase(actionType)) {
						//Remove InitiatedGlobalWalletCardId  from session
						mbSession.removeInitiatedGlobalWalletId();
					}
					//redirect to Set Pin page
					request.setAttribute(REQ_ACTION_TYPE, actionType);
				}			
			}
		}
		if(!StringMethods.isEmptyString(actionType) && (IBankParams.ECONTRACT_ACE.equalsIgnoreCase(actionType))){
			mbSession.removeCustomer();
			//Logger.debug("user "+commonData.getUser().getGCISNumber(),this.getClass());
			MobileBankService mobileBankService = (MobileBankService) ServiceHelper.getBean(MBAppConstants.SPRING_MOBILE_SERVICE_BEAN);
			commonData.setCustomer(null);
			Customer customer = mobileBankService.getCustomer(commonData, MobileBankServiceImpl.SIMPLIFIED_LOGON);
			mbSession.setCustomer(customer);
		}
			
		/*if ( ! StringMethods.isEmptyString(actionType) && APPLY_GCC.equalsIgnoreCase(actionType) ){
			request.setAttribute( DeeplinkController.REQ_ACTION_TYPE ,APPLY_GCC );
		}else if ( ! StringMethods.isEmptyString(actionType) && SERVICE_MENU.equalsIgnoreCase(actionType) ){
			request.setAttribute( DeeplinkController.REQ_ACTION_TYPE, SERVICE_MENU );
		}else if ( ! StringMethods.isEmptyString(actionType) && APPLY_BT.equalsIgnoreCase(actionType) ){
			request.setAttribute( DeeplinkController.REQ_ACTION_TYPE, APPLY_BT );
		}else if ( ! StringMethods.isEmptyString(actionType) && BT_SUPER_SEARCH.equalsIgnoreCase(actionType) ){
			request.setAttribute( DeeplinkController.REQ_ACTION_TYPE, BT_SUPER_SEARCH );
		}else if ( ! StringMethods.isEmptyString(actionType) && CHANGE_CARD_PIN.equalsIgnoreCase(actionType) ){
			request.setAttribute( DeeplinkController.REQ_ACTION_TYPE, CHANGE_CARD_PIN );
		}else if(!StringMethods.isEmptyString(actionType) 
				&& DeeplinkController.ONBOARDING_STATUS.equalsIgnoreCase(actionType) 
						&& !IBankParams.isOnboardingSwitchON()){
			request.removeAttribute(DeeplinkController.REQ_ACTION_TYPE);
		}else if (ACTION_TYPE_OPEN_ACCT.equalsIgnoreCase(actionType)){
			String custType = request.getParameter(CUST_TYPE);
			String productType = request.getParameter(PROD_TYPE);
			if(CUST_TYPE_SOLE_TRADER.equalsIgnoreCase(custType) && (PROD_TYPE_FREEDOM_BUSINESS.equals(productType) || PROD_TYPE_SAVING_BUSINESS.equals(productType)))
			{
				request.setAttribute( DeeplinkController.REQ_ACTION_TYPE, PROD_TYPE_FREEDOM_BUSINESS.equals(productType) ? ACTION_TYPE_SOLE_FREEDOM_BUSINESS:ACTION_TYPE_SOLE_SAVING_BUSINESS );
			}
			else if(CUST_TYPE_SOLE_DIRECTOR.equalsIgnoreCase(custType) && (PROD_TYPE_FREEDOM_BUSINESS.equals(productType) || PROD_TYPE_SAVING_BUSINESS.equals(productType)))
			{
				request.setAttribute( DeeplinkController.REQ_ACTION_TYPE, PROD_TYPE_FREEDOM_BUSINESS.equals(productType) ? ACTION_TYPE_SOLE_DIR_FREEDOM_BUSINESS:ACTION_TYPE_SOLE_DIR_SAVING_BUSINESS );
			}
			else{
				request.setAttribute( DeeplinkController.REQ_ACTION_TYPE ,actionType);
			}
		}else {
			request.setAttribute( DeeplinkController.REQ_ACTION_TYPE ,actionType);
		}*/

		int loadCordova = logonHelper.loadCordova(request);
		request.setAttribute(REQ_LOAD_CORDOVA, String.valueOf(loadCordova));
		
//		int allowsPost = logonHelper.allowsPostWhenNative(request);
//		request.setAttribute(REQ_ALLOWS_APPACTION_POST, String.valueOf(allowsPost));

		request.setAttribute(REQ_ACTION_STR, REQ_DASHBOARD);
		
		if ( ! StringMethods.isEmptyString(actionType)){
			request.setAttribute( OpenIdController.REQ_ACTION_TYPE ,actionType );
		}
		
		//TODO
		request.setAttribute(REQ_IGNORE_SEC_FLAG, IBankParams.NO);

//TODO any chanhges for origin..
		
		
	}
	
	private boolean isValidActionType(String actionType){

		if(StringMethods.isEmptyString(actionType)){
			return true;
		}
		
		String pattern = BLOCK_CHARS;
		Pattern r = Pattern.compile(pattern);

		Matcher m = r.matcher(actionType);
		if (m.find()) {
			return true;
		} 
		return false;
	}
	

	private SystemInformation getSystemInformationDtls()
	{
		SystemInformation systemInformation = (SystemInformation) ServiceHelper.getBean("systemInformation");
		return systemInformation;

	}
	
	@Autowired
	private LogonHelper logonHelper;
	
	@Autowired
	private SystemInformation systemInformation;
	

}