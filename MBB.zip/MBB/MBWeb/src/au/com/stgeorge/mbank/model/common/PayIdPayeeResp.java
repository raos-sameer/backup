package au.com.stgeorge.mbank.model.common;

public class PayIdPayeeResp {
	
	private int payIDIndex;
    private String payIDName;
    private String payID;
    private String payIDDisp;
    private String payIDType;
    private String payIDLimitType;
    private String payerName;
    private String payeeEmail;
	
	public int getPayIDIndex() {
		return payIDIndex;
	}
	public void setPayIDIndex(int payIDIndex) {
		this.payIDIndex = payIDIndex;
	}
	public String getPayerName() {
		return payerName;
	}
	public void setPayerName(String payerName) {
		this.payerName = payerName;
	}
	public String getPayeeEmail() {
		return payeeEmail;
	}
	public void setPayeeEmail(String payeeEmail) {
		this.payeeEmail = payeeEmail;
	}
	public String getPayIDName() {
		return payIDName;
	}
	public void setPayIDName(String payIDName) {
		this.payIDName = payIDName;
	}
	public String getPayID() {
		return payID;
	}
	public void setPayID(String payID) {
		this.payID = payID;
	}
	public String getPayIDDisp() {
		return payIDDisp;
	}
	public void setPayIDDisp(String payIDDisp) {
		this.payIDDisp = payIDDisp;
	}
	public String getPayIDType() {
		return payIDType;
	}
	public void setPayIDType(String payIDType) {
		this.payIDType = payIDType;
	}
	public String getPayIDLimitType() {
		return payIDLimitType;
	}
	public void setPayIDLimitType(String payIDLimitType) {
		this.payIDLimitType = payIDLimitType;
	}


}
