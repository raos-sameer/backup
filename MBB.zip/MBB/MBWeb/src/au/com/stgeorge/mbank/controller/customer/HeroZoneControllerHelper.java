package au.com.stgeorge.mbank.controller.customer;

import au.com.stgeorge.mbank.model.response.customer.HeroZoneResp;


public class HeroZoneControllerHelper
{

	public HeroZoneResp getFavTranListResponse()
	{
		return null;
	}
	
	public HeroZoneResp getFavTranAddResponse()
	{
		return null;
	}
	
	public HeroZoneResp getFavTranUpdateResponse()
	{
		return null;
	}
	
	public HeroZoneResp getFavTranDeleteResponse()
	{
		return null;
	}
	
}
