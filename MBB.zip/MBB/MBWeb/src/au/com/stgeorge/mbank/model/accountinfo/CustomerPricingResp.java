package au.com.stgeorge.mbank.model.accountinfo;

import java.util.List;
import au.com.stgeorge.mbank.model.common.ErrorInfo;
import au.com.stgeorge.mbank.model.common.IMBResp;
import au.com.stgeorge.mbank.model.common.RespHeader;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_NULL)
public class CustomerPricingResp implements IMBResp{

	private static final long serialVersionUID = 7117551735147104954L;
	
	private RespHeader header;
    private List<ErrorInfo> error;
    private String bonusRate;
    private String bonusTerm;
    private Boolean offerAccepted;    
    private AccountDetailResp accountDetailResp;
    
	public RespHeader getHeader() {
		return header;
	}
	public void setHeader(RespHeader header) {
		this.header = header;
	}
	public List<ErrorInfo> getError() {
		return error;
	}
	public void setError(List<ErrorInfo> error) {
		this.error = error;
	}
	public String getBonusRate() {
		return bonusRate;
	}
	public void setBonusRate(String bonusRate) {
		this.bonusRate = bonusRate;
	}
	public String getBonusTerm() {
		return bonusTerm;
	}
	public void setBonusTerm(String bonusTerm) {
		this.bonusTerm = bonusTerm;
	}	
	public Boolean getOfferAccepted() {
		return offerAccepted;
	}
	public void setOfferAccepted(Boolean offerAccepted) {
		this.offerAccepted = offerAccepted;
	}	
	public AccountDetailResp getAccountDetailResp() {
		return accountDetailResp;
	}
	public void setAccountDetailResp(AccountDetailResp accountDetailResp) {
		this.accountDetailResp = accountDetailResp;
	}		
}
