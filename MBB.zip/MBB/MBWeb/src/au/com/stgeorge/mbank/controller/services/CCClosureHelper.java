package au.com.stgeorge.mbank.controller.services;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import au.com.stgeorge.framework.common.logging.Logger;
import au.com.stgeorge.framework.common.util.DateMethods;
import au.com.stgeorge.framework.common.util.StringMethods;
import au.com.stgeorge.ibank.common.cache.IBankParams;
import au.com.stgeorge.ibank.service.valueobject.CCClosureReqVO;
import au.com.stgeorge.ibank.valueobject.ContactDetail;
import au.com.stgeorge.ibank.valueobject.PhoneNumber;
import au.com.stgeorge.ibank.valueobject.transfer.IBankCommonData;
import au.com.stgeorge.ibank.valueobject.wdp.CCClosurePreparationData;
import au.com.stgeorge.ibank.valueobject.wdp.EligibleCard;
import au.com.stgeorge.ibank.valueobject.wdp.PayoutQuoteData;
import au.com.stgeorge.mbank.model.common.ErrorInfo;
import au.com.stgeorge.mbank.model.request.services.CCClosurePayoutReq;
import au.com.stgeorge.mbank.model.request.services.CCClosureReq;
import au.com.stgeorge.mbank.model.response.ErrorResp;
import au.com.stgeorge.mbank.model.response.services.CCClosureEligibleCardsResp;
import au.com.stgeorge.mbank.model.response.services.CCClosurePayoutDataResp;
import au.com.stgeorge.mbank.model.response.services.CCClosureResp;
import au.com.stgeorge.mbank.model.response.services.EligibleCardResp;
import au.com.stgeorge.mbank.session.MobileSession;
import au.com.stgeorge.mbank.util.MBAppHelper;
import au.com.stgeorge.mbank.util.MBAppUtils;

@Service
public class CCClosureHelper {

	private static final String DATE_FORMAT = "dd MMM yyyy";
	@Autowired
	private MBAppHelper mbAppHelper;
	
	protected CCClosureEligibleCardsResp populateCCClosureEligibleCardsResp (CCClosurePreparationData ccClosurePreparationData, String baseOrigin){
		
		CCClosureEligibleCardsResp resp = new CCClosureEligibleCardsResp();
		List<EligibleCardResp> eligibleCards = new ArrayList<>(); 
		
		for (EligibleCard eligibleCard : ccClosurePreparationData.getAccounts()) {
			EligibleCardResp eligibleCardResp = new EligibleCardResp();
			eligibleCardResp.setAccountNumber(eligibleCard.getAccountNumber());
			eligibleCardResp.setAccountNumDisp(eligibleCard.getAccountNumDisp());
			eligibleCardResp.setAvailableBalance(eligibleCard.getAvailableBalance());
			eligibleCardResp.setCurrentBalance(eligibleCard.getCurrentBalance());
			eligibleCardResp.setAccountName(eligibleCard.getAccountName());
			eligibleCards.add(eligibleCardResp);
		}
		
		resp.setCcClosureReasonList(IBankParams.getCCClosureReasonList());
		resp.setFaqUrl(IBankParams.getCCClosureFaqUrl(baseOrigin));
		
		resp.setEligibleCards(eligibleCards);
		return resp;			
	}
	
	protected CCClosurePayoutDataResp populatePayoutDataResp (PayoutQuoteData payoutData){
		
		CCClosurePayoutDataResp resp = new CCClosurePayoutDataResp(); 
		
		resp.setIsPositiveAmount(payoutData.getIsPositiveAmount());
		if("N".equalsIgnoreCase(payoutData.getIsPositiveAmount())){
			resp.setPayoutAmount(new BigDecimal(payoutData.getPayoutAmount()).negate().toString());
		}else{
			resp.setPayoutAmount(payoutData.getPayoutAmount());
		}
		resp.setPayoutDate(DateMethods.formatDate(DATE_FORMAT , payoutData.getPayoutDate()));
		resp.setJointAccount(payoutData.isJointAccount());
		resp.setLastAccount(payoutData.isLastAccount());
		
		return resp;			
	}

	protected CCClosureResp populateClosureResp (IBankCommonData commonData, boolean isTransactionAccountPresent, String billerCode){
		
		CCClosureResp resp = new CCClosureResp(); 
		
		resp.setBillerCode(billerCode);
		resp.setHasTransactionAccount(isTransactionAccountPresent);
		resp.setHasEmail(!StringMethods.isEmptyString(commonData.getCustomer().getContactDetail().getEmail()));
		resp.setIsSuccess(true);
		
		return resp;			
	}
	
	protected ErrorResp validatePayoutReq (CCClosurePayoutReq req, MobileSession mbSession) {
		ErrorResp errorResp = new ErrorResp(null);
		boolean isErrorExists = false;
		
		errorResp.setErrors(new ArrayList<ErrorInfo>());
		
		if("008".equalsIgnoreCase(req.getReasonCode()) && StringMethods.isEmptyString(req.getOtherDescription())){
			ErrorInfo error = new ErrorInfo();
			error.setCode(""); // TODO Add error code
			error.setMessage(""); //TODO Get error message
			errorResp.getErrors().add(error);
			isErrorExists = true;
		}
		
		if ( isErrorExists ){
			errorResp.setHeader(new MBAppHelper().populateResponseHeader(mbSession.getOrigin(), mbSession));
		}
		
		Logger.info("Error response populated: " + errorResp, MBAppUtils.class);
	
		return errorResp;
	}
	
	public static boolean isPhoneNumberAvailable(ContactDetail contactDetail){

		 boolean isPhoneExists = true;
		 
		 if(contactDetail != null){
			 PhoneNumber homePhone = contactDetail.getHomeNumber();
			 PhoneNumber workPhone = contactDetail.getWorkNumber();
			 PhoneNumber mobilePhone = contactDetail.getMobileNumber();

			 if(!(homePhone != null && !StringMethods.isEmptyString(homePhone.getAreaCode()) && !StringMethods.isEmptyString(homePhone.getPhoneNumber())) &&
					 !(workPhone != null && !StringMethods.isEmptyString(workPhone.getAreaCode()) && !StringMethods.isEmptyString(workPhone.getPhoneNumber())) &&
					 !(mobilePhone != null && !StringMethods.isEmptyString(mobilePhone.getAreaCode()) && !StringMethods.isEmptyString(mobilePhone.getPhoneNumber()))){
				 isPhoneExists = false;
			 }
		 } 
		 
		 return isPhoneExists;
	 }
	
	protected CCClosureReqVO populateClosureReqVO (CCClosureReq ccClosureReq){
		
		CCClosureReqVO ccClosureReqVO = new CCClosureReqVO(); 
		
		ccClosureReqVO.setAccountIndex(ccClosureReq.getAccountIndex());
		ccClosureReqVO.setAccountNum(ccClosureReq.getAccountNum());
		ccClosureReqVO.setBsb(ccClosureReq.getBsb());
		ccClosureReqVO.setDonationIndicator(ccClosureReq.getDonationIndicator());
		
		return ccClosureReqVO;			
	}
}
