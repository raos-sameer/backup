package au.com.stgeorge.mbank.controller.statements;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import au.com.stgeorge.framework.common.util.DateMethods;
import au.com.stgeorge.ibank.businessobject.BusinessException;
import au.com.stgeorge.ibank.businessobject.acctsvc.AccountService;
import au.com.stgeorge.ibank.common.cache.IBankParams;
import au.com.stgeorge.ibank.messagecentre.valueobject.TokenDetails;
import au.com.stgeorge.ibank.util.DateUtils;
import au.com.stgeorge.ibank.util.ServiceHelper;
import au.com.stgeorge.ibank.valueobject.Account;
import au.com.stgeorge.ibank.valueobject.AcctStatement;
import au.com.stgeorge.ibank.valueobject.CreditCardAccount;
import au.com.stgeorge.ibank.valueobject.transfer.IBankCommonData;
import au.com.stgeorge.mbank.model.common.IMBResp;
import au.com.stgeorge.mbank.model.response.statements.ClosedAccountListResp;
import au.com.stgeorge.mbank.model.response.statements.EStmtInfoResp;
import au.com.stgeorge.mbank.model.statements.ClosedAccountKeyInfoResp;
import au.com.stgeorge.mbank.model.statements.EStmtDetailResp;

/**
 * @author C50216
 *
 */

public class EStmtHelper {
	
	
	private static final String INVALID_LOW_BLOCK_CODE = "S";
	
	protected boolean validateDateRange(Date fromDate, Date toDate) throws BusinessException, Exception{
		
		boolean validate = true;
		
		if(fromDate != null &&  toDate != null){			
			
			Calendar minFromDate = Calendar.getInstance();
			minFromDate.setTime(fromDate);
			minFromDate.set(Calendar.YEAR,2000);
			minFromDate.set(Calendar.MONTH,0);
			minFromDate.set(Calendar.DAY_OF_MONTH,1);
			removeTimeFromDate(minFromDate);
			
			Calendar dateFrom = Calendar.getInstance();
			dateFrom.setTime(fromDate);
			removeTimeFromDate(dateFrom);
			
			Calendar dateTo = Calendar.getInstance();
			dateTo.setTime(toDate);
			removeTimeFromDate(dateTo);
						
			Calendar today = Calendar.getInstance();
			removeTimeFromDate(today);
			
			if(minFromDate.after(dateFrom)
					|| dateFrom.after(today)
					|| dateTo.after(today) 
					|| dateFrom.after(dateTo))
				validate = false;
				
		}else
			validate = false;
		
		return validate;		
	}
	
	protected IMBResp populateStmtListResp(List<TokenDetails> tokenList){
		
		EStmtInfoResp resp = new EStmtInfoResp();
		EStmtDetailResp detail = null;
	
		List<EStmtDetailResp> detailList = null;
		
		if (tokenList != null && tokenList.size() > 0) {
			Iterator<TokenDetails> it = tokenList.iterator();			
			detailList = new ArrayList<EStmtDetailResp>();
			
			while(it.hasNext()){
				TokenDetails tokenDtl = it.next(); 
				detail = new EStmtDetailResp();
				detail.setToken(tokenDtl.getToken());
				//TokenDetails table  StmtId & StmtEndDate is not null
				if(!tokenDtl.getStmtId().equalsIgnoreCase(""))
					detail.setDate(tokenDtl.getStmtEndDate());
				
				detailList.add(detail);				
			}
			
			resp.setStmtList(detailList);
		}
		
		return resp;
	}
	
	private void removeTimeFromDate(Calendar cal){
		
		cal.set(Calendar.HOUR_OF_DAY, 0);
		cal.set(Calendar.MINUTE,0);
		cal.set(Calendar.SECOND,0);
		cal.set(Calendar.MILLISECOND,0);		
		
	}	
	
	protected ClosedAccountListResp populateClosedAccountListResp(List<Account> closedAccountsList){
		
		ClosedAccountListResp resp = new ClosedAccountListResp();
		ClosedAccountKeyInfoResp cAccountInfoResp = null;
		List<ClosedAccountKeyInfoResp> respAccountInfoList = null;
		
		if(closedAccountsList != null && closedAccountsList.size() > 0){
			respAccountInfoList = new ArrayList<ClosedAccountKeyInfoResp>();

			for(Account closedAccount:closedAccountsList){
				cAccountInfoResp = new  ClosedAccountKeyInfoResp();
				cAccountInfoResp.setAccountIndex(closedAccount.getIndex());
				cAccountInfoResp.setCloseDate(closedAccount.getCloseDate());
				
				if(closedAccount.getOpenDate() != null){
					cAccountInfoResp.setOpenDate(closedAccount.getOpenDate());
				}else{
					Calendar cal = Calendar.getInstance();
					cal.setTime(closedAccount.getCloseDate());
					cal.add(Calendar.MONTH, -6); // to get previous year add -1
					cAccountInfoResp.setOpenDate(cal.getTime());
				}
				
				cAccountInfoResp.setAccountNum(closedAccount.getAccountId().getAccountNumber());
				cAccountInfoResp.setAccountName(closedAccount.getAlias());
				cAccountInfoResp.setAccountType(closedAccount.getAccountId().getApplicationId());
				respAccountInfoList.add(cAccountInfoResp);
			}
		}
		
		resp.setAccountList(respAccountInfoList);
		
		return resp;
	}
	
	/**
	 * This method will filter the estatement from Statement List for Closed Credit Card Accounts 
	 * having Block Code 'U' or 'V' and LowerBlock Code 'S'.
	 * @param account
	 * @param stmtList
	 * @param commonData
	 * @return
	 */
	protected List<AcctStatement> getFilteredClosedCCStmtList(Account account, List<AcctStatement> stmtList,IBankCommonData commonData)throws BusinessException{
		
		CreditCardAccount craAccount = null;
		String blockCode = null;
		String lowBlockCode = null;
		List<String>invalidBlockCodes = null;
		Date changedDate = null;
		Date stmtToDate = null;
		List<AcctStatement> filteredStmtList = null;
		AccountService acctSvc = null;
		
		craAccount = (CreditCardAccount) account;
		
		if(craAccount != null && stmtList != null){

			invalidBlockCodes = IBankParams.getClosedCCAcctInvalidBlockCodes(commonData.getOrigin());
			blockCode = craAccount.getBlockCode();
			if(blockCode!= null && !("".equalsIgnoreCase(blockCode)) && invalidBlockCodes.contains(blockCode)){

				acctSvc = (AccountService) ServiceHelper.getBean("acctSvc");
				craAccount = (CreditCardAccount)acctSvc.getClosedCreditCardAccount(account.getAccountId(), commonData);

				lowBlockCode = craAccount.getLowBlockCode() != null ? craAccount.getLowBlockCode().getCode():null;

				if(lowBlockCode != null && !("".equalsIgnoreCase(lowBlockCode)) && INVALID_LOW_BLOCK_CODE.equalsIgnoreCase(lowBlockCode)){
					changedDate = DateUtils.getUtilDateFromXMLDateTime(craAccount.getLowBlockCode().getChgDate(), null);
				}
				
				if(changedDate != null){

					filteredStmtList = new ArrayList<AcctStatement>();
					for(AcctStatement stmt : stmtList){
						stmtToDate = stmt.getDateTo();
						if(stmtToDate != null && stmtToDate.before(changedDate)){
							filteredStmtList.add(stmt);
						}
					}
					return filteredStmtList;
				}
				
			}
		}
		
		return stmtList;
		
	}
	
	public List<TokenDetails> filterGWCAccountStatementList(List<TokenDetails> sessionTokenList , Date formStartDate, Date formEndDate) throws BusinessException {
			
			
			List<TokenDetails> filteredTokenDetailList = new ArrayList<>();
			
			Calendar formStartDateCal = Calendar.getInstance();
			formStartDateCal.setTime(formStartDate);
			formStartDateCal.set(Calendar.DAY_OF_MONTH, 1);
			formStartDate = formStartDateCal.getTime();
			
			Calendar formEndDateCal = Calendar.getInstance();
			formEndDateCal.setTime(formEndDate);
			formEndDateCal.set(Calendar.DAY_OF_MONTH, formEndDateCal.getActualMaximum(Calendar.DAY_OF_MONTH));
			formEndDate = formEndDateCal.getTime();
			
			for(TokenDetails tokenDetail : sessionTokenList) {
				
				/*Calendar stmtStartDateCal = Calendar.getInstance();
				Date stmtStartDate = tokenDetail.getCreatedOn();
				stmtStartDateCal.setTime(stmtStartDate);
				stmtStartDateCal.set(Calendar.DAY_OF_MONTH, 1);
				stmtStartDate = stmtStartDateCal.getTime();*/
				
				//Calendar stmtEndDateCal = Calendar.getInstance();
				Date stmtEndDate = tokenDetail.getStmtEndDate();
				//stmtEndDateCal.setTime(stmtEndDate);
				//stmtEndDateCal.set(Calendar.DAY_OF_MONTH, stmtEndDateCal.getActualMaximum(Calendar.DAY_OF_MONTH));
				//stmtEndDate = stmtEndDateCal.getTime();
				
				if(formStartDate.getTime() <= stmtEndDate.getTime() && formEndDate.getTime() >= stmtEndDate.getTime() ) {
					filteredTokenDetailList.add(tokenDetail);
				}
			}
			
			if(filteredTokenDetailList.isEmpty()) {
				throw new BusinessException(BusinessException.PDF_STATEMENT_NOT_FOUND);
			}
			
			return filteredTokenDetailList;
		}
	}
