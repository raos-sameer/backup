package au.com.stgeorge.mbank.model.common;

import org.apache.commons.lang.builder.ReflectionToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

/**
 * Payee receipts response
 * 
 * @author C38854
 *
 */
@JsonInclude(Include.NON_NULL)
public class BTSearchStatusResp implements IMBResp {

	private static final long serialVersionUID = -7569983049344317260L;

	private RespHeader header;

	private boolean btSearchDone;

	
	public RespHeader getHeader() {
		return header;
	}


	public void setHeader(RespHeader header) {
		this.header = header;
	}


	public boolean isBtSearchDone() {
		return btSearchDone;
	}


	public void setBtSearchDone(boolean btSearchDone) {
		this.btSearchDone = btSearchDone;
	}


	@Override
	public String toString() {
		return ReflectionToStringBuilder.toString(this, ToStringStyle.MULTI_LINE_STYLE);
	}

}
