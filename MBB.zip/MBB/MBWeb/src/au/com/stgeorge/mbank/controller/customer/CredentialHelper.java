package au.com.stgeorge.mbank.controller.customer;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import au.com.stgeorge.framework.common.logging.Logger;
import au.com.stgeorge.framework.common.model.User;
import au.com.stgeorge.framework.common.util.StringMethods;
import au.com.stgeorge.ibank.businessobject.BusinessException;
import au.com.stgeorge.ibank.businessobject.IBankSecureService;
import au.com.stgeorge.ibank.common.cache.IBankParams;
import au.com.stgeorge.ibank.common.log.IBankLog;
import au.com.stgeorge.ibank.servicestation.businessobject.valueobject.ServiceStationVO;
import au.com.stgeorge.ibank.servicestation.util.ServicetationConstants;
import au.com.stgeorge.ibank.util.ServiceHelper;
import au.com.stgeorge.ibank.valueobject.Account;
import au.com.stgeorge.ibank.valueobject.AccountFlags;
import au.com.stgeorge.ibank.valueobject.Address;
import au.com.stgeorge.ibank.valueobject.Biller;
import au.com.stgeorge.ibank.valueobject.ContactDetail;
import au.com.stgeorge.ibank.valueobject.Customer;
import au.com.stgeorge.ibank.valueobject.PaymentsLog;
import au.com.stgeorge.ibank.valueobject.ThirdParty;
import au.com.stgeorge.ibank.valueobject.database.CodesVO;
import au.com.stgeorge.mbank.model.common.AccountControlResp;
import au.com.stgeorge.mbank.model.common.AccountKeyInfoResp;
import au.com.stgeorge.mbank.model.common.ContactInfoResp;
import au.com.stgeorge.mbank.model.common.RespHeader;
import au.com.stgeorge.mbank.model.common.IMBResp;
import au.com.stgeorge.mbank.model.common.PayeeResp;
import au.com.stgeorge.mbank.model.common.PhoneInfoResp;
import au.com.stgeorge.mbank.model.common.SecureCodeInfoResp;
import au.com.stgeorge.mbank.model.response.customer.CredentialResp;
import au.com.stgeorge.mbank.model.response.customer.LogonResp;
import au.com.stgeorge.mbank.model.response.servicestation.ServiceStationResp;
import au.com.stgeorge.mbank.session.GenericSessionFactory;
import au.com.stgeorge.mbank.session.IGenericSession;
import au.com.stgeorge.mbank.util.MBAppHelper;
import au.com.stgeorge.mbank.util.OriginResolver;
import au.com.stgeorge.mobilebank.businessobject.MobileBankService;

/**
 * @author C03121
 * 
 *         To change the template for this generated type comment go to
 *         Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class CredentialHelper
{
	public long getInsertionPointCode(String insertionPointString){
		List<CodesVO> CodesVOList = (List<CodesVO>) IBankParams.getCodesDataList(IBankParams.DEFAULT_ORIGIN, ServicetationConstants.CD_CATEGORY_SERVICETATION_INSERTION_PT);
		long insertionPointValue = 0;
		for(CodesVO codesVO : CodesVOList){
			if(codesVO.getMessage().trim().equalsIgnoreCase(insertionPointString)){
				if(StringMethods.isValidString(codesVO.getCode())){
					insertionPointValue = Long.parseLong(codesVO.getCode());
					break;
				}
			}
		}
		if(insertionPointValue == 0){
			Logger.warn("NO match found in RELEASECODES table for the insertion point "+insertionPointString, this.getClass());
		}
		return insertionPointValue;
	}
	public static IMBResp populateResponse()
	{		
		return populateResponse(null);
	}
	
	public static IMBResp populateResponse(ServiceStationVO serviceStationVO)
	{
		CredentialResp credentialResp = new CredentialResp();
		credentialResp.setSuccess(true);
		if(null!=serviceStationVO)
		{
			credentialResp.setServiceStation(populateServiceStationResp(serviceStationVO));
		}			
		return credentialResp;
	}
	
	public static ServiceStationResp populateServiceStationResp(ServiceStationVO serviceStationVO){
		ServiceStationResp resp = null;		
		
		if(null!=serviceStationVO)
		{
			resp=new ServiceStationResp();
			if(null!=serviceStationVO.getContent())
			{
			   resp.setContent(serviceStationVO.getContent());
			}			
			if(null!=serviceStationVO.getServiceStationMsg())
			{
				resp.setInsertionPointValue(new Long(serviceStationVO.getServiceStationMsg().getInsertionPointValue()).toString());	
			}
			if(null!=serviceStationVO.getSubject())
			{
			   resp.setSubject(serviceStationVO.getSubject());
			}
			if(null!=serviceStationVO.getServiceStationMsg().getFunctionLink())
			{
			   resp.setFunctionLink(serviceStationVO.getServiceStationMsg().getFunctionLink());
			}
			if(null!=serviceStationVO.getServiceStationMsg().getMessageAction())
			{
			   resp.setMessageAction(serviceStationVO.getServiceStationMsg().getMessageAction());
			}
			if(null!=serviceStationVO.getServiceStationMsg())
			{
				resp.setMsgID(new Long(serviceStationVO.getServiceStationMsg().getMsgID()).toString());	
			}
		}		
		return resp;
	}
}
