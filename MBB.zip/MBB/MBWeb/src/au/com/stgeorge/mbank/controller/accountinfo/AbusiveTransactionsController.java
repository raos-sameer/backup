package au.com.stgeorge.mbank.controller.accountinfo;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.fasterxml.jackson.databind.ObjectMapper;

import au.com.stgeorge.framework.common.logging.Logger;
import au.com.stgeorge.ibank.AbusiveTransactionVO;
import au.com.stgeorge.ibank.businessobject.AbusiveTransactionsService;
import au.com.stgeorge.ibank.businessobject.BusinessException;
import au.com.stgeorge.ibank.util.NPPUtil;
import au.com.stgeorge.ibank.valueobject.Account;
import au.com.stgeorge.ibank.valueobject.Customer;
import au.com.stgeorge.ibank.valueobject.Statistic;
import au.com.stgeorge.ibank.valueobject.transfer.IBankCommonData;
import au.com.stgeorge.mbank.controller.IMBController;
import au.com.stgeorge.mbank.model.common.IMBReq;
import au.com.stgeorge.mbank.model.common.IMBResp;
import au.com.stgeorge.mbank.model.common.ReqHeader;
import au.com.stgeorge.mbank.model.common.RespHeader;
import au.com.stgeorge.mbank.model.request.AbusiveTrxnReportRequest;
import au.com.stgeorge.mbank.model.response.AbusiveTrxnReportResponse;
import au.com.stgeorge.mbank.model.response.ErrorResp;
import au.com.stgeorge.mbank.session.MobileSession;
import au.com.stgeorge.mbank.util.MBAppHelper;
import au.com.stgeorge.mbank.util.MBAppUtils;
import au.com.stgeorge.mbank.util.MBAppValidator;
import au.com.stgeorge.mbank.util.ServiceConstants;
import au.com.stgeorge.perflogger.PerformanceLogger;

import au.com.stgeorge.digitalsec.logger.DigitalSecLogger;
import au.com.stgeorge.digitalsec.logger.DigitalSecLogggerVO;

@Controller
@RequestMapping("/abusiveTransaction")
public class AbusiveTransactionsController implements IMBController {

	@Autowired
	private MBAppHelper mbAppHelper;

	@Autowired
	private MBAppValidator mbAppValidator;

	@Autowired
	private PerformanceLogger perfLogger;

	@Autowired
	AbusiveTransactionsService abusiveTransactionsService;

	
	@Autowired
	private DigitalSecLogger digitalSecLogger;
	
	
	@Override
	public RespHeader populateResponseHeader(String serviceName, MobileSession mobileSession) {
		return mbAppHelper.populateResponseHeader(serviceName, mobileSession);
	}
	

	@RequestMapping(value = "report", method = RequestMethod.POST, headers = "content-type=application/json", produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public IMBResp reportAbusiveTransaction(HttpServletRequest httpServletRequest,
			HttpServletResponse httpServletResponse,
			@RequestBody final AbusiveTrxnReportRequest abusiveTrxnReportRequest) {
		final String methodName = "AbusiveTransactionsController.reportAbusiveTransaction():";

		Logger.info(methodName, this.getClass());

		MobileSession mbSession = null;
		String serviceName = ServiceConstants.REPORT_ABUSIVE_TRANSACTION;
		int errorKeyId = 0;
		int successRepopnseCode = 11004007;
		AbusiveTrxnReportResponse abusiveTrxnReportResponse = null;
		ObjectMapper objectMapper = new ObjectMapper();
		String logName = MBAppUtils.getLogName(httpServletRequest);

		perfLogger.startAllLogs();
		perfLogger.startLog(logName);
		
		DigitalSecLogggerVO digiSecLogvOForAbusiveTrans = new DigitalSecLogggerVO();
		try {
			mbSession = mbAppHelper.getMobileSession(httpServletRequest);
			AbusiveTransactionVO abusiveTransDet = mbSession.getAbusiveTransactionDetails();
			IBankCommonData commonData = mbAppHelper.populateIBankCommonData(mbSession, httpServletRequest);
			
			Logger.info(methodName + "Request Payload:" + objectMapper.writeValueAsString(abusiveTrxnReportRequest),
					this.getClass());

			validateRequestHeader(abusiveTrxnReportRequest.getHeader(), httpServletRequest);

			
			Customer customer = commonData.getCustomer();
			
			int accountIndex_ = abusiveTrxnReportRequest.getAccountIndex();
			Logger.info(methodName + "accountIndex_: " + accountIndex_, this.getClass());

			Account selectedAccount_ = mbAppHelper.getAccountFromCustomer(customer, accountIndex_);

			String accountNo_ = null;

			try {
				accountNo_ = selectedAccount_.getAccountId().getAccountNumber();
				Logger.info(methodName + "accountNo: " + accountNo_, this.getClass());
			} catch (Exception tExc) {
				Logger.error(methodName + "Exception caught while getting account number", tExc, this.getClass());
			}
					
			Logger.info(methodName + "getAbusiveDepositNumber() from session: " + abusiveTransDet.getAbusiveDepositNumber(), this.getClass());
			Logger.info(methodName + "getAbusiveAccountNumber() from session: " + abusiveTransDet.getAbusiveAccountNumber()+"::"+abusiveTransDet.getPayeeBSB(), this.getClass());

			abusiveTransDet.setAbusiveAccountNumber(accountNo_);
			
			/*AbusiveTransactionVO abusiveTransactionVO = new AbusiveTransactionVO();
			abusiveTransactionVO.setAbusiveDepositNumber(abusiveTrxnReportRequest.getDepositNumber());
			abusiveTransactionVO.setAbusiveAccountNumber(accountNo_);
			abusiveTransactionVO.setDescription(abusiveTrxnReportRequest.getTrxnDescription());
			abusiveTransactionVO.setAbusiveReferenceNumber(abusiveTrxnReportRequest.getTrxnRefNumber());*/

			abusiveTransactionsService.reportInappropriateTransaction(commonData, abusiveTransDet);
			abusiveTransactionsService.persistAbusiveTransaction(commonData, abusiveTransDet);
			NPPUtil.createAbusivewordStatisticsLog(commonData, abusiveTransDet.getDescription(),
					abusiveTransDet.getReference(), abusiveTransDet.getAbusiveDepositNumber(),Statistic.ABUSIVE_INWARD_TRANSACTION);
			digiSecLogvOForAbusiveTrans.setUserAgent(commonData.getUserAgent());
			digiSecLogvOForAbusiveTrans.setCommonLogData(mbAppHelper.getCommonLogData(commonData));
			digiSecLogvOForAbusiveTrans.setTranName(DigitalSecLogger.REPORT_ABUSIVE_TRA_INWARD);
			digiSecLogvOForAbusiveTrans.setValues(NPPUtil.getAbusiveTransDigitalSecurityLog(commonData, abusiveTransDet.getDescription(), abusiveTransDet.getReference(),abusiveTransDet.getFromAccountNumner(),
					abusiveTransDet.getFromBSB(),abusiveTransDet.getPayeeBSB(),abusiveTransDet.getAbusiveAccountNumber(),abusiveTransDet.getAmount(),abusiveTransDet.getTranDate(),abusiveTransDet.getAbusiveDepositNumber(),true));
			digitalSecLogger.log(digiSecLogvOForAbusiveTrans);
		} catch (BusinessException bExc_) {
			errorKeyId = bExc_.getKey();
		} catch (Exception exc) {
			Logger.error(methodName + "Exception caught: ", exc, this.getClass());
			errorKeyId = BusinessException.SYSTEM_UNAVILABLE;
		} finally {
			perfLogger.endLog(logName);
			perfLogger.endAllLogs();
		}
			
		if (errorKeyId != 0) {
			Logger.info(methodName + "errorKeyId:" + errorKeyId, this.getClass());
			BusinessException bExc = new BusinessException(errorKeyId);
			digiSecLogvOForAbusiveTrans.setStatus("Failure");
			return MBAppUtils.createErrorResp(mbSession.getOrigin(), bExc, serviceName, httpServletRequest);
		} else {
			RespHeader responseHeader = populateResponseHeader(serviceName, mbSession);
			abusiveTrxnReportResponse = new AbusiveTrxnReportResponse();
			abusiveTrxnReportResponse.setHeader(responseHeader);
			abusiveTrxnReportResponse.setSuccess(true);
			// abusiveTrxnReportResponse.setMessage(MBAppUtils.getMessage(mbSession.getOrigin(),
			// successRepopnseCode));
		}
		
		return abusiveTrxnReportResponse;
	}

	@Override
	public ErrorResp validate(IMBReq serviceRequest, HttpServletRequest httpRequest) throws BusinessException {
		return mbAppValidator.validate(serviceRequest, httpRequest);
	}

	@Override
	public void validateRequestHeader(ReqHeader headerReq, HttpServletRequest request) throws BusinessException {
		mbAppValidator.validateRequestHeader(headerReq, request);
	}
}