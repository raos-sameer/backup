package au.com.stgeorge.mbank.controller.accountinfo;

import java.io.IOException;
import java.util.UUID;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import au.com.stgeorge.framework.common.logging.Logger;
import au.com.stgeorge.ibank.businessobject.BusinessException;
import au.com.stgeorge.ibank.businessobject.ResourceException;
import au.com.stgeorge.ibank.businessobject.wdp.WDPServiceHelper;
import au.com.stgeorge.ibank.cpp.businessobject.CustomerPricingService;
import au.com.stgeorge.ibank.cpp.util.CustomerPricingConstants;
import au.com.stgeorge.ibank.cpp.valueobjects.CustomerPricingDetails;
import au.com.stgeorge.ibank.valueobject.Account;
import au.com.stgeorge.ibank.valueobject.transfer.IBankCommonData;
import au.com.stgeorge.mbank.model.accountinfo.CustomerPricingResp;
import au.com.stgeorge.mbank.model.common.IMBResp;
import au.com.stgeorge.mbank.session.MobileSession;
import au.com.stgeorge.mbank.util.MBAppHelper;
import au.com.stgeorge.mbank.util.MBAppUtils;
import au.com.stgeorge.mbank.util.ServiceConstants;
import au.com.stgeorge.mobilebank.businessobject.MobileBankService;
import au.com.stgeorge.perflogger.PerformanceLogger;


@Controller
@RequestMapping("/cpp")
public class CustomerPricingController {

	@Autowired
	private PerformanceLogger perfLogger;

	@Autowired
	private MBAppHelper mbAppHelper;
	
	@Autowired
	private CustomerPricingService customerPricingService;
	
	@Autowired
	private CustomerPricingHelper customerPricingHelper;
	
	@Autowired
	private MobileBankService mobileBankService;
	
	@RequestMapping(value="getOfferDetails", method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public IMBResp getOfferDetails(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse){

		Logger.debug("CPP : getOfferDetails - START. ", this.getClass());
		
		CustomerPricingDetails customerPricingDetails = null;
		MobileSession mbSession = null;
		IBankCommonData commonData=null;		
		String offerId = null;
		CustomerPricingResp serviceResponse = new CustomerPricingResp();
		String logName = MBAppUtils.getLogName(httpServletRequest);
		
		try{			
			perfLogger.startLog(logName);
			
			mbSession = mbAppHelper.getMobileSession(httpServletRequest);	
			commonData = mbAppHelper.populateIBankCommonData(mbSession, httpServletRequest);			
	
			Account selectedAcct = mbSession.getSelectedAccount();
			
			if(null != selectedAcct){
				offerId = ""+selectedAcct.getPreCalOfferDetails().getOfferId();
			}
			
			UUID appCorrelationId = WDPServiceHelper.generateAppCorrelationId();
			customerPricingDetails  = customerPricingService.getOfferDetails(offerId, commonData, selectedAcct, appCorrelationId);
			selectedAcct.getPreCalOfferDetails().setCustomerPricingDetails(customerPricingDetails);
			
			// Add the firstTimeCheck entry in DB			
			 if(selectedAcct.getPreCalOfferDetails().getFirstTimeCheck()!= null && selectedAcct.getPreCalOfferDetails().getFirstTimeCheck().equals(Boolean.TRUE))
				 customerPricingService.updateFirstTimeCheck(commonData, selectedAcct, Boolean.FALSE);			 
			 
			serviceResponse = customerPricingHelper.populateResp(customerPricingDetails);
			serviceResponse.setHeader(mbAppHelper.populateResponseHeader(ServiceConstants.CUSTOMER_PRICING_SERVICE, mbSession));
			
		}catch (BusinessException e){			
			Logger.error("CPP : getOfferDetails :: BusinessException : GCIS ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "]", e, this.getClass());
			IMBResp resp  = MBAppUtils.createErrorResp(mbSession.getOrigin(), e, ServiceConstants.CUSTOMER_PRICING_SERVICE, httpServletRequest);
			return resp;			
		}catch (ResourceException e) {
			Logger.error("CPP : getOfferDetails :: ResourceException : GCIS ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "]", e, this.getClass());
			IMBResp resp  = MBAppUtils.createErrorResp(mbSession.getOrigin(), BusinessException.SYSTEM_UNAVILABLE, ServiceConstants.CUSTOMER_PRICING_SERVICE, httpServletRequest);
			return resp;
		}catch (Exception e) {			
			Logger.error("CPP : getOfferDetails :: Exception : GCIS ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "]", e, this.getClass());
			IMBResp resp  = MBAppUtils.createErrorResp(mbSession.getOrigin(), BusinessException.SYSTEM_UNAVILABLE, ServiceConstants.CUSTOMER_PRICING_SERVICE, httpServletRequest);
			return resp;
		}finally{
			perfLogger.endLog(logName);
		}

		Logger.debug("CPP : getOfferDetails - END. ", this.getClass());

		return serviceResponse;
	}

	@RequestMapping(value="processOffer", method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE)	
	@ResponseBody
	public IMBResp processOffer(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse) throws ResourceException, BusinessException {
		
		Logger.debug("CPP : processOffer - START", this.getClass());		
		MobileSession mbSession = null;
		IBankCommonData commonData=null;		
		CustomerPricingResp serviceResponse = new CustomerPricingResp();		
		String logName = MBAppUtils.getLogName(httpServletRequest);
		
		try {
			perfLogger.startLog(logName);
			
			mbSession = mbAppHelper.getMobileSession(httpServletRequest);	
			commonData = mbAppHelper.populateIBankCommonData(mbSession, httpServletRequest);
			
			Account selectedAcct = mbSession.getSelectedAccount();
			CustomerPricingDetails customerPricingDetails = selectedAcct.getPreCalOfferDetails().getCustomerPricingDetails();
			UUID appCorrelationId = WDPServiceHelper.generateAppCorrelationId();
			String status = customerPricingService.processOffer(selectedAcct, appCorrelationId, commonData);
			Logger.debug("CPP : Status of Offer Acceptance :"+ status, this.getClass());
			
			if(CustomerPricingConstants.OFFER_ACCEPTANCE_SUCCESS.equalsIgnoreCase(status)){
				selectedAcct.getPreCalOfferDetails().setOfferAcceped(true);	
				
				//Populate response with CPP Offer Details
				serviceResponse = customerPricingHelper.populateResp(customerPricingDetails);
				
				//Call AcctDetInq to get the new rates				 
				Account acctDetail = mobileBankService.getAccountDetails(selectedAcct.getAccountId(), commonData);
				
				//Populate response with Account Details				
				serviceResponse.setAccountDetailResp(customerPricingHelper.populateAcctDetailResp(mbSession.getCustomer(), acctDetail, mbSession.getOrigin()));
				
				serviceResponse.setOfferAccepted(true);
				serviceResponse.setHeader(mbAppHelper.populateResponseHeader(ServiceConstants.CUSTOMER_PRICING_SERVICE, mbSession));
				
				//Update the firstTimeCheck entry OfferStatus flag to Y
				 if(selectedAcct.getPreCalOfferDetails().getFirstTimeCheck()!= null && selectedAcct.getPreCalOfferDetails().getFirstTimeCheck().equals(Boolean.TRUE))
					 customerPricingService.updateFirstTimeCheck(commonData, selectedAcct, Boolean.TRUE);	
			}			
		}		
		catch (BusinessException be) {				
			Logger.error("CPP : processOffer :: BusinessException : GCIS ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "]", be, this.getClass());
			IMBResp resp  = MBAppUtils.createErrorResp(mbSession.getOrigin(), be, ServiceConstants.CUSTOMER_PRICING_SERVICE, httpServletRequest);
			return resp;
		}catch (ResourceException re) {			
			Logger.error("CPP : processOffer :: ResourceException: " + re.getKey() + " Message : "+ re.getMessage(), re, this.getClass());				
			IMBResp resp  = MBAppUtils.createErrorResp(mbSession.getOrigin(), re, ServiceConstants.CUSTOMER_PRICING_SERVICE, httpServletRequest);
			return resp;
		}catch(IOException ie){
			Logger.error("CPP : processOffer :: IOException: " + ie, this.getClass());	
			IMBResp resp  = MBAppUtils.createErrorResp(mbSession.getOrigin(), BusinessException.SYSTEM_UNAVILABLE, ServiceConstants.CUSTOMER_PRICING_SERVICE, httpServletRequest);
			return resp;
		}catch(Exception e){			
			Logger.error("CPP : processOffer :: Exception : GCIS ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "]", e, this.getClass());
			IMBResp resp  = MBAppUtils.createErrorResp(mbSession.getOrigin(), BusinessException.SYSTEM_UNAVILABLE, ServiceConstants.CUSTOMER_PRICING_SERVICE, httpServletRequest);
			return resp;
		}
		Logger.debug("CPP : processOffer - END", this.getClass());
		return serviceResponse;
	}
}
