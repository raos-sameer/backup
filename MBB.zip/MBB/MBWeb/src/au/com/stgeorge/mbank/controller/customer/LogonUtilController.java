package au.com.stgeorge.mbank.controller.customer;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.UUID;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.SerializationUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import au.com.stgeorge.digitalsec.logger.DigitalSecLogger;
import au.com.stgeorge.digitalsec.logger.DigitalSecLogggerVO;
import au.com.stgeorge.framework.common.logging.Logger;
import au.com.stgeorge.framework.common.model.User;
import au.com.stgeorge.framework.common.util.StringMethods;
import au.com.stgeorge.ibank.businessobject.BusinessException;
import au.com.stgeorge.ibank.businessobject.CustomerDemographicService;
import au.com.stgeorge.ibank.businessobject.CustomerService;
import au.com.stgeorge.ibank.businessobject.ForceChangePwdService;
import au.com.stgeorge.ibank.businessobject.HeartBeat;
import au.com.stgeorge.ibank.businessobject.IBankSecureService;
import au.com.stgeorge.ibank.businessobject.MemoryThrottlingService;
import au.com.stgeorge.ibank.businessobject.PRMUpdateService;
import au.com.stgeorge.ibank.businessobject.ReactivateOnlineService;
import au.com.stgeorge.ibank.businessobject.ReactivateOnlineServiceImpl;
import au.com.stgeorge.ibank.businessobject.ResourceException;
import au.com.stgeorge.ibank.businessobject.assembler.CustomerVOAssembler;
import au.com.stgeorge.ibank.businessobject.impl.ForceChangePwdServiceImpl;
import au.com.stgeorge.ibank.common.cache.IBankParams;
import au.com.stgeorge.ibank.common.cache.IBankRefershParams;
import au.com.stgeorge.ibank.common.cache.IBankRefreshParamsImpl.NativeLogonSwitch;
import au.com.stgeorge.ibank.evcrs.businessobject.CRSService;
import au.com.stgeorge.ibank.evcrs.businessobject.valueobject.CRSInfo;
import au.com.stgeorge.ibank.loanApplication.LoanApplicationDetail;
import au.com.stgeorge.ibank.loanApplication.util.LoanAppConstants;
import au.com.stgeorge.ibank.loanApplication.util.LoanAppUtil;
import au.com.stgeorge.ibank.messagecentre.util.MessageCentreConstants;
import au.com.stgeorge.ibank.messagecentre.valueobject.CustomerMessage;
import au.com.stgeorge.ibank.messagecentre.valueobject.MessageSearch;
import au.com.stgeorge.ibank.npp.PayIdRegistrationSwitchParams;
import au.com.stgeorge.ibank.safi.businessobject.Safi2Service;
import au.com.stgeorge.ibank.safi.util.SafiConstants;
import au.com.stgeorge.ibank.safi.util.SafiUtil;
import au.com.stgeorge.ibank.safi.valueobject.SafiForensicInfo;
import au.com.stgeorge.ibank.safi.valueobject.SafiLogonInfo;
import au.com.stgeorge.ibank.safi.valueobject.SafiPrmInfo;
import au.com.stgeorge.ibank.safi.valueobject.SafiReactivateOnlineVO;
import au.com.stgeorge.ibank.safi.valueobject.SafiRsaDevicePrintInfo;
import au.com.stgeorge.ibank.service.businessobject.OnboardingService;
import au.com.stgeorge.ibank.service.businessobject.TPSThrottlingService;
import au.com.stgeorge.ibank.service.valueobject.OnboardingStep;
import au.com.stgeorge.ibank.service.valueobject.OnboardingVO;
import au.com.stgeorge.ibank.service.valueobject.SafiRespVO;
import au.com.stgeorge.ibank.service.valueobject.SafiVO;
import au.com.stgeorge.ibank.servicestation.businessobject.ServiceStation;
import au.com.stgeorge.ibank.servicestation.businessobject.ServiceStationImpl;
import au.com.stgeorge.ibank.servicestation.businessobject.valueobject.ServiceStationVO;
import au.com.stgeorge.ibank.servicestation.util.ServicetationConstants;
import au.com.stgeorge.ibank.util.CommonBusinessUtil;
import au.com.stgeorge.ibank.util.ServiceHelper;
import au.com.stgeorge.ibank.util.StringUtil;
import au.com.stgeorge.ibank.valueobject.Account;
import au.com.stgeorge.ibank.valueobject.AutoApplyRetentionInfo;
import au.com.stgeorge.ibank.valueobject.Customer;
import au.com.stgeorge.ibank.valueobject.ForceChangePwd;
import au.com.stgeorge.ibank.valueobject.MsgCentreInfo;
import au.com.stgeorge.ibank.valueobject.Statistic;
import au.com.stgeorge.ibank.valueobject.database.CodesVO;
import au.com.stgeorge.ibank.valueobject.database.OriginsVO;
import au.com.stgeorge.ibank.valueobject.transfer.AuthenticationData;
import au.com.stgeorge.ibank.valueobject.transfer.IBankCommonData;
import au.com.stgeorge.mbank.controller.IMBController;
import au.com.stgeorge.mbank.controller.MainController;
import au.com.stgeorge.mbank.controller.SafiWebHelper;
import au.com.stgeorge.mbank.model.common.AppParams;
import au.com.stgeorge.mbank.model.common.CustomerResp;
import au.com.stgeorge.mbank.model.common.GhostTileResp;
import au.com.stgeorge.mbank.model.common.IMBReq;
import au.com.stgeorge.mbank.model.common.IMBResp;
import au.com.stgeorge.mbank.model.common.ReqHeader;
import au.com.stgeorge.mbank.model.common.RespHeader;
import au.com.stgeorge.mbank.model.common.SplashPageResp;
import au.com.stgeorge.mbank.model.request.EmptyReq;
import au.com.stgeorge.mbank.model.request.customer.CustomerAppReq;
import au.com.stgeorge.mbank.model.request.customer.LogonReq;
import au.com.stgeorge.mbank.model.request.mortgage.ApplicationReq;
import au.com.stgeorge.mbank.model.response.CanNumResp;
import au.com.stgeorge.mbank.model.response.EmptyResp;
import au.com.stgeorge.mbank.model.response.ErrorResp;
import au.com.stgeorge.mbank.model.response.SuccessResp;
import au.com.stgeorge.mbank.model.response.customer.LogonResp;
import au.com.stgeorge.mbank.session.GenericSessionFactory;
import au.com.stgeorge.mbank.session.IGenericSession;
import au.com.stgeorge.mbank.session.MobileSession;
import au.com.stgeorge.mbank.session.MobileSessionImpl;
import au.com.stgeorge.mbank.useragent.UserAgentParser;
import au.com.stgeorge.mbank.util.FraudLogger;
import au.com.stgeorge.mbank.util.MBAppConstants;
import au.com.stgeorge.mbank.util.MBAppHelper;
import au.com.stgeorge.mbank.util.MBAppLogger;
import au.com.stgeorge.mbank.util.MBAppUtils;
import au.com.stgeorge.mbank.util.MBAppValidator;
import au.com.stgeorge.mbank.util.ServiceConstants;
import au.com.stgeorge.mobilebank.businessobject.EStatementsService;
import au.com.stgeorge.mobilebank.businessobject.EmailBounceBackService;
import au.com.stgeorge.mobilebank.businessobject.MobileBankService;
import au.com.stgeorge.mobilebank.businessobject.MobileMsgCntrService;
import au.com.stgeorge.mobilebank.businessobject.PayMobService;
import au.com.stgeorge.mobilebank.businessobject.SavingsOnboardingService;
import au.com.stgeorge.perflogger.PerformanceLogger;
import au.com.stgeorge.ibank.businessobject.model.customerDemographic.EmailAddress;
import au.com.stgeorge.ibank.businessobject.model.customerDemographic.GetCustomerResp;

@Controller
@RequestMapping(method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE)
public class LogonUtilController implements IMBController
{
	private static final String USER_AGENT = "User-Agent";
	private static final String E_COR_SPLASH_TYPE = "eCor";
	private static final String CRS_SPLASH_TYPE = "CRS";
	private static final String ESTMT_SPLASH_TYPE = "estmtSplash";
	private static final String OB_STATUS_ELIGIBLE = "ELIGIBLE";
	private static final String OB_STEP_ESTMT = "estmt";
	private static final String OB_STEP_PUSH = "push";
	private static final String OB_STEP_QZ = "qz";
	private static final String OB_STEP_SL = "sl";
	private static final String OB_STEPNAME_E_STATEMENTS = "eStatements";
	private static final String OB_STEPNAME_NOTIFICATIONS = "Notifications";
	private static final String OB_STEPNAME_QUICK_ZONE = "Quick Zone";
	private static final String OB_STEPNAME_SIMPLIFIED_SIGN_IN = "Simple sign in";
	private static final String COMPASS_CHANNEL = "IBNK";
	public static final String SMS_RESET_STATUS = "SMSRESET";
	private FraudLogger fraudLogger;
	private static final String SAVINGS_ONBOARDING_SPLASH_TYPE = "savings";
	private static final String P2M_DECOMMISSION_SPLASH_TYPE = "P2MDecommission";
	private static final String PAYID_REGISTRATION_SPLASH_TYPE = "PayIDRegistration";
	private static final String MADISON_SPLASH_TYPE = "Madison";
	private static final String CUTSOMER_OBJ = "CustomerObj";
	private static final String LITE = "LITE";
	private static final String SMPL_DEVICE_ID ="DeviceID";

	//19E3 CPP TD IB-MB
	public static final String STATE = "DesktopMobileState";
	
	@Autowired
	private EmailBounceBackService emailBounceBackService;
	
	//21E1
	public static final String EMAIL_BOUNCE_BACK_SPLASH_TYPE = "emailBounceBack";
	
	//19E4 Matrix Migration
	public static final String FORCED_MATRIX_MIGRATION_SPLASH_TYPE = "forcedMatrixMigration";
	public static final String EXPIRY_MATRIX_MIGRATION_SPLASH_TYPE = "expiryMatrixMigration";
	
	//20E4 Email Update splash page type
	public static final String EMAIL_UPDATE_SPLASH_TYPE = "EmailUpdate";
		
	//20E1 Madison Pilot
	private static final String MADISON_PILOT = "MadisonPilot";
	private static final String CONNECT_SESSION_ID = "ConnectSessionID";
	
	@Autowired
	private MobileMsgCntrService msgCntrService;
	
	@Autowired
	private CustomerDemographicService custDemoGraPro;
	
	@Autowired
	private TPSThrottlingService tpsThrottlingService;
	
	@Autowired
	private OnboardingService onboardingService;
	
	@Autowired
	private ServiceStation serviceStationService;
	
	@Autowired
	private DigitalSecLogger digitalSecurityLogger;
	
	@Autowired
	private Safi2Service safi2Service;
	
	@Autowired
	private CRSService crsService;

	@Autowired
	private MemoryThrottlingService memoryThrottlingService;
		
	@Autowired
	private SavingsOnboardingService savingsOnboardingService;
	
	@Autowired
	private EStatementsService mobileEStatementsService;
		
	@Autowired
	private PayMobService payToMobileService; 
	
	private boolean isEBBRequired(IBankCommonData commonData) {
final String methodName = "LogonUtilController.isEBBRequired():";

boolean isEBBSplashRequired = false;

try {
	UUID appCorrelationId = UUID.randomUUID();

	GetCustomerResp customerDemographicResponse = custDemoGraPro.getCustomerDemoGraphicProfile(commonData,
			appCorrelationId);

	if (customerDemographicResponse != null) {
		au.com.stgeorge.ibank.businessobject.model.customerDemographic.Customer demographicCustomer = customerDemographicResponse
				.getData();

		if (demographicCustomer != null) {
			List<EmailAddress> emailAddresses_ = demographicCustomer.getEmailAddresses();

			for (EmailAddress emailAddress_ : emailAddresses_) {
				Logger.debug(
						methodName + "Priority Level: " + ((emailAddress_.getPriorityLevel() == null) ? "Null"
								: emailAddress_.getPriorityLevel()),
						this.getClass());

				if (emailAddress_.getPriorityLevel() != null
						&& "primary".equalsIgnoreCase(emailAddress_.getPriorityLevel())) {

					if (emailAddress_.getValidityStatus() != null
							&& emailAddress_.getValidityStatus().getCode() != null) {
						String validityStatusCode_ = emailAddress_.getValidityStatus().getCode();
						Logger.debug(methodName + "validityStatusCode_: " + validityStatusCode_,
								this.getClass());

						if ("C".equalsIgnoreCase(validityStatusCode_)) {}
						else {
							isEBBSplashRequired = true;
						}
					}
					break;
				}
			}
		}
	} else {
		Logger.debug(methodName + "Response is NUll", this.getClass());
	}
} catch (Exception excD) {
	Logger.error(methodName + "Error caught while invoking demographic API: ", excD, this.getClass());
}
return isEBBSplashRequired;
}
	
	@RequestMapping("/logon")
	@ResponseBody
	public IMBResp processLogon(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse,@RequestBody final LogonReq req)
	{
		Logger.debug("In processLogon ( LogonAction ** /v1/logon )  for Customer" + req.getAccessNumber() + "  " + httpServletRequest.getContentType() + " "+ httpServletRequest.getRemoteAddr() + "  " + httpServletResponse.getCharacterEncoding() + httpServletResponse.getLocale() + " True IP >> " + httpServletRequest.getHeader(IBankParams.trueClientIP()) , this.getClass());
		LogonHelper.printMobileTermsAndTandCCookieValue(httpServletRequest);
		final String METHOD_NAME = "processLogon";
		fraudLogger = new FraudLogger();
		perfLogger.startAllLogs();
		String logName = MBAppUtils.getLogName(httpServletRequest);
		perfLogger.startLog(logName);
		String origin = null;
		AuthenticationData authenticationData = new AuthenticationData();
		DigitalSecLogggerVO digitalSecLoggerVO = new DigitalSecLogggerVO();
		List populateSplashPageResult = null;
		
		boolean isDemo = LogonHelper.isDemo();
		origin = LogonHelper.getOrigin(httpServletRequest, isDemo, METHOD_NAME);

		String gdwOrigin  = logonHelper.getGDWOrigin( req.getHeader(),  origin);
		
		httpServletRequest.setAttribute(LogonHelper.ORIGIN, origin);

		ObjectMapper mapper = new ObjectMapper();
		int unreadMsgCount = -1;
		IGenericSession genericSession = null ;
		User user = null;
		IBankCommonData ibankCommonData=null;
		Customer customer=null;

		String sessId=null;
		boolean reactivateOnline = false;
		boolean safiChallenge = false;
		try
		{ 
			ErrorResp errorResp = validate(req, httpServletRequest);
			if (errorResp != null && errorResp.getErrors() != null && errorResp.getErrors().size() > 0)
			{
				return errorResp;
			}

			String userAgent = httpServletRequest.getHeader(USER_AGENT);
			Logger.debug("Simplified Logon origin" + origin + ": User-Agent :" + userAgent, this.getClass());

			ibankCommonData = populateIBankCommonData(null, null, origin, MBAppHelper.resolveIPAddress(httpServletRequest, origin), userAgent);
			if (isDemo)
			{
			   checkDemoSecurityKey( req.getPassword());	
			}
		
			
			authenticationData = populateAuthenticationData(req, gdwOrigin, MBAppHelper.resolveIPAddress(httpServletRequest, origin));
			authenticationData.setCompassChannel(COMPASS_CHANNEL);
			user = authenticate(authenticationData, false);
			if(user != null) {
				user.setActionType(req.getActionType());
			}
			genericSession = logonHelper.createCompassSession(user, origin, MBAppConstants.WEB_SRV, httpServletRequest);
			sessId = genericSession.getId();
			
			Logger.debug("Reactivate: reactivateOnline " + reactivateOnline+" CAN : "+user.getUserId()+" Logon Type "+user.getAttribute( IBankParams.LOGON_TYPE), this.getClass());
			//20E4 - COVID19 OTP - on three unsuccessful login attempts user is allowed to login using OTP - Begin
			if ( user != null && user.getAttribute(IBankParams.LOGON_TYPE) != null &&  IBankParams.LogonTypeEnum.OTP == user.getAttribute( IBankParams.LOGON_TYPE)  )
			{
				reactivateOnline = true;
				Logger.info("Reactivate:  reactivateOnline " + reactivateOnline+" CAN : "+user.getUserId(), this.getClass());
			}
			//20E4 - COVID19 OTP - on three unsuccessful login attempts user is allowed to login using OTP - End

			perfLogger.setPrefix("GCIS:" + user.getGCISNumber() + ";SESSIONID:" + sessId + ";BRAND:" + origin +";");
			Logger.info("***User-Agent: " + userAgent.toLowerCase() + "***SessionId: " + sessId, this.getClass());

			httpServletResponse.setHeader("Set-Cookie", MBAppConstants.SMPL_SESS_CONSTANT + "=" + genericSession.getId()   + "; HttpOnly ; Secure ; path=/   " );
			//TODO
			//httpServletResponse.setHeader("Set-Cookie", MBAppConstants.SMPL_SESS_CONSTANT + "=" + sessId   + "; HttpOnly ; path=/   " ); 
			
			ibankCommonData = populateIBankCommonData(sessId, user, origin, MBAppHelper.resolveIPAddress(httpServletRequest, origin), userAgent, gdwOrigin);
						
			user.setAttribute(IBankParams.USEROBJ_BRAND,origin );
			// Forensic Logs			
			if(!reactivateOnline) { //Normal logon flow
				logDigitalLoggerLogonSuccess(req, digitalSecLoggerVO, ibankCommonData);
			}
			
			LogonHelper.printMobileTermsAndTandCCookieValue(httpServletRequest);
			//18E4 throw error if the session is DM session
			MBAppHelper.validateMBSessionId(sessId);
			boolean isLogonFlow = false;
			if(IBankParams.isLogonPayeesBillersAsyncSwitchON(origin))
				isLogonFlow = true;
			
			if(reactivateOnline) { //20E4 - COVID19 OTP login
				String actionType = null;
				if(httpServletRequest.getAttribute(MainController.REQ_ACTION_TYPE) != null) {
					actionType = (String) httpServletRequest.getAttribute(MainController.REQ_ACTION_TYPE);
				}
				Logger.info("Reactivate : LogonUtilController:processLogon(): actionType:"+actionType+",....CAN: "+user.getUserId(), this.getClass());
				
				ReactivateOnlineService reactivateOnlineService = (ReactivateOnlineService)ServiceHelper.getBean("reactivateOnlineService");
				customer = reactivateOnlineService.getCustomerDetails(user, authenticationData.getOrigin());
				ibankCommonData.setCustomer(customer);
				genericSession.setAttribute(MobileSessionImpl.LAUNCHED_APP,ReactivateOnlineService.SESSION_REACTIVATE);
				Logger.info("Reactivate : Got Customer. CAN : "+user.getUserId(), this.getClass());
			} else { //Normal flow
				customer = getCustomer(ibankCommonData, null, isLogonFlow);
			}
			
			setCustomerAndOriginInSession(origin, genericSession, customer, gdwOrigin);
			if(!reactivateOnline) { //Normal logon flow
				setSecurityLogs(httpServletRequest, authenticationData, genericSession, user,false);
			}
			LogonHelper.printMobileTermsAndTandCCookieValue(httpServletRequest);
			
			String safiAction = null;
			if(reactivateOnline) { 
				//20E4 - COVID19 OTP - SAFI analyse call
				safiAction = processReactivateRequest(httpServletRequest, genericSession, req, ibankCommonData, genericSession) ;
				Logger.info("Reactivate: SAFI call done. CAN : "+user.getUserId()+" Safi response action "+safiAction, this.getClass());
				if(!StringMethods.isEmptyString(safiAction) && SafiConstants.SAFI_ACTION_CHALLENGE.equalsIgnoreCase(safiAction)) {
					safiChallenge = true;
				}

			} else { //Normal safi analyse
				safiAction = safiCallWithPRMAndDiggitalLogger(httpServletRequest, httpServletResponse, req,
						METHOD_NAME, origin, authenticationData, digitalSecLoggerVO, genericSession, user, ibankCommonData,
						customer, sessId);
			}
				
			LogonHelper.printMobileTermsAndTandCCookieValue(httpServletRequest);
			
			if(!StringMethods.isEmptyString(safiAction) && safiAction.equalsIgnoreCase(SafiConstants.SAFI_ACTION_DENY)){
				throw new BusinessException(BusinessException.SAFI_LOGON_DENY_ERROR);
			}
						
			ForceChangePwdService forceService = ServiceHelper.getBean(ServiceConstants.FORCE_PWD_CHANGE);
			ForceChangePwd forceVO = forceService.getStatus(ibankCommonData);
			genericSession.setForceChangePwd(forceVO);
			String forceStatus = forceService.getStatusFromVO(ibankCommonData, forceVO);
			
			
//			appHelper.makeStatisticsLog(authenticationData, user, httpServletRequest);
			
			mbAppHelper.addTrackingIdCookie(customer.getPreference().getTrackingId(), IBankParams.getBaseOriginCode(ibankCommonData.getOrigin()), httpServletRequest, httpServletResponse);
			MBAppHelper.addWebAnalyticsCookis(IBankParams.getBaseOriginCode(ibankCommonData.getOrigin()), httpServletRequest, httpServletResponse);

			//safiAction will be populated only if Safi is called else null always.
			validateDifferentCookie(httpServletRequest, httpServletResponse, req, user,safiAction);
		
			validatetermsAndCondCookie( genericSession.getUser().getUserId(),  httpServletRequest,  httpServletResponse);//i5MB:Uncomment
			
			boolean mustChangePwd = user.isStatusMustChangePassword();
			Boolean smsRest = null;
			
			if (user.isStatusMustChangePassword()){
				genericSession.setLoggedonState(LogonHelper.LOGGEDON_STATE_FORCE_RESETPWD);
			}else{
				smsRest = (Boolean) user.getAttribute(SMS_RESET_STATUS);
				if ( smsRest != null && smsRest.booleanValue()){
					genericSession.setLoggedonState(LogonHelper.LOGGEDON_STATE_FORCE_RESETPWD_SECNUM);
				}
			}
			
			// call service to get ServiceAdminVo
			long insertionPt = logonHelper.getInsertionPointCode(ServicetationConstants.DASHBOARD);
			ServiceStationVO servicestationVO=populateServiceMessage(insertionPt,ServiceStationImpl.CHANNEL_MOBILE, ibankCommonData);
			if(null!=servicestationVO)
			{
				genericSession.setAttribute(MobileSessionImpl.SERVICE_STATION_DASHBOARD_MESSAGE, servicestationVO.getServiceStationMsg());
			}
			
//			Splash page update MsgCount
			Logger.debug("Processing splashPageInfo", this.getClass());
			boolean isECorrespondenceSupported = CommonBusinessUtil.isECorrespondenceSupported(httpServletRequest);
			MsgCentreInfo	msgCentreInfo	   = processMsgCentre(origin,customer.getGcis(),isECorrespondenceSupported);
			
			List<MessageSearch>  splashPageInfo = msgCentreInfo.getSplashPageInfo();  
			
			MessageSearch messageSearch = setSplashmsgInfoInSession(genericSession,  splashPageInfo);
			
			AutoApplyRetentionInfo autoApplyRetentionInfo = setAutoApplyRetentionInfoInSession(genericSession,
					msgCentreInfo);
			
			unreadMsgCount = msgCentreInfo.getUnreadMessageCount();
			Logger.debug("splashPageInfo - unreadMsgCount: "+unreadMsgCount, this.getClass());
			IMBResp serviceResponse = logonHelper.populateResponse(customer, user, unreadMsgCount, httpServletRequest, httpServletResponse, mustChangePwd,servicestationVO,autoApplyRetentionInfo);
			
			if( isPwdChangeSafiChallenge(user, customer, safiAction, smsRest)){

				Logger.debug("SAFI : LogonUtilController:processLogon(): Setting LoggedOnState - SafiChallenge: SafiAction: "+safiAction+" GCISNumber: "+customer.getGcis(), this.getClass());
				((LogonResp) serviceResponse).setCustomer(null);
				((LogonResp) serviceResponse).setShowSafiChallenge(true);
				((LogonResp) serviceResponse).setContactInfo(logonHelper.populateContact(customer.getContactDetail()));
				((LogonResp) serviceResponse).setSecureCodeInfo(logonHelper.populateSecureCodeInfo(customer));
				genericSession.setLoggedonState(LogonHelper.LOGGEDON_STATE_SAFI_CHALLENGE);

			}if(! isPwdChangeSafiChallenge(user, customer, safiAction, smsRest)){
				//Populate the ghost tile Response
				//20E2-CSH -SBGEXP-8227 - added two conditions to check CSH/Efinance/Homeloan combination				
				logonHelper.populateGhostTile(this, genericSession, ibankCommonData, customer, serviceResponse);
			MobileSession mobileSession = new MobileSessionImpl();
			mobileSession.setSession(genericSession);		
//			Populate the SplashPage Response
			populateSplashPageResponse(httpServletRequest, origin, mobileSession, ibankCommonData, customer, mustChangePwd, smsRest, 
					isECorrespondenceSupported, splashPageInfo, messageSearch, serviceResponse);
			if (!((LogonResp) serviceResponse).isChangePwdAndSecNumReqd() && !((LogonResp) serviceResponse).isChangePwdReqd() && !((LogonResp) serviceResponse).isShowSafiChallenge()){
				Logger.debug("forceChangePwd gcis: " + customer.getGcis() + " status = " + forceStatus, LogonUtilController.class);
				setLoggedStatus(genericSession, forceStatus, customer);
				((LogonResp) serviceResponse).setForceChangePwdStatus(forceStatus);
				((LogonResp) serviceResponse).setRemSkipCount(forceService.getRemSkipCount(forceVO, forceStatus, origin));					
			}				
			}
			genericSession.setAttribute(MobileSessionImpl.CUSTOMER_OBLECT, customer);

			//20E4 - COVID 19 OTP - reactivate online - Begin
			if(reactivateOnline) {
				if(safiChallenge) {
					((LogonResp) serviceResponse).setContactInfo(logonHelper.populateContact(customer.getContactDetail()));
					((LogonResp) serviceResponse).setSecureCodeInfo(logonHelper.populateSecureCodeInfo(customer));
					((LogonResp) serviceResponse).setReactivateOnline(true);
					((LogonResp) serviceResponse).setShowSafiChallenge(true);
					((LogonResp) serviceResponse).setCustomer(null);
					genericSession.setLoggedonState(LogonHelper.LOGGEDON_STATE_SAFI_CHALLENGE);
					
					Logger.info("Reactivate : Forwarding to 2FA screen. CAN : "+user.getUserId(), this.getClass());
				} else {
					//TODO TBC show error 
					Logger.warn("Inside processLogon() - safiChallenge is FALSE for COVID19 OTP Reactivate Online Flow, returning an error.", this.getClass());
					BusinessException exp = new BusinessException(BusinessException.SMPL_SYS_ERROR);
					IMBResp resp1 = MBAppUtils.createErrorResp(origin, exp, MBAppConstants.SMPL_LOGON_RESP_NAME, httpServletRequest);
					return resp1;
				}
			}  //20E4 - COVID 19 OTP - reactivate online - End
			
			Logger.info("Simplified Logon /logon JSON Response :" + mapper.writeValueAsString(serviceResponse), this.getClass());
			MobileSession dummySession = null;
			RespHeader headerResp = populateResponseHeader(ServiceConstants.LOGON_RESPONSE, dummySession );
			setSecurityUniqueId( genericSession, headerResp);
			serviceResponse.setHeader(headerResp);			
			
			return serviceResponse;

		} catch (BusinessException e)
		{
			Logger.info("Exception Inside processLogon() for Customer 1. " + e.getKey(), this.getClass());
			if ( e.getKey() == (BusinessException.COOKIES_NOT_FOUND) )
			{
				LogonResp logonResp = new LogonResp();
				logonResp.setTermsAcceptanceReqd(true);
				
				if (user.isStatusMustChangePassword()){
					logonResp.setChangePwdReqd( user.isStatusMustChangePassword());
					genericSession.setLoggedonState(LogonHelper.LOGGEDON_STATE_FORCE_RESETPWD);
				}
				
				Boolean smsRest = (Boolean) user.getAttribute(LogonHelper.SMS_RESET_STATUS);
				if ( smsRest != null && smsRest.booleanValue())
				{
					logonResp.setChangePwdAndSecNumReqd(smsRest.booleanValue());
					genericSession.setLoggedonState(LogonHelper.LOGGEDON_STATE_FORCE_RESETPWD_SECNUM);
					
				}
				AppParams appParams = logonHelper.populateAppParams(httpServletRequest, customer);
				logonResp.setAppParams(appParams);
				String autoInitSts=(String)user.getAttribute(IBankParams.REG_STATUS);
				
				if(!StringMethods.isEmptyString(autoInitSts) && autoInitSts.equalsIgnoreCase(IBankParams.AUTO_INIT_ADMIN)){
					logonResp.setAutoInitPwdSecNumChng(true);
					//logonResp.setFirstName(customer.getFirstName());
					if(null!=customer.getContactDetail() && null!=customer.getContactDetail().getEmail()){
						String email_unmasked=customer.getContactDetail().getEmail();
						String masked = email_unmasked.replaceAll("(?<=.{2}).(?=[^@]*?.{2}@)", "*");
						logonResp.setEmailAddress(masked);
					}
					else
					{
						logonResp.setEmailAddress("");
					}
					genericSession.setLoggedonState(LogonHelper.AUTO_INIT_RESET_PWD_SECNUM);
					Logger.debug("***AutoInitStatus  ECorrespondence Check: ", this.getClass());
					//E-correspondence Check Box for the consent capture
					if(CommonBusinessUtil.isECorrespondenceSupported(httpServletRequest)){
						if(customer.isCustomerOfTypeGHS()&& CustomerVOAssembler.PERSONAL_CUSTOMER.equalsIgnoreCase(customer.getCustTypeInd()))
						{
							logonResp.seteCorConsentCaptureRequired(true);
						}
					}
					
				}
				MobileSession dummySession = null;
				RespHeader headerResp = populateResponseHeader(ServiceConstants.LOGON_RESPONSE, dummySession);
				setSecurityUniqueId( genericSession, headerResp);

				logonResp.setHeader(headerResp);
				
				//20E4 - COVID19 OTP - Reactivate Online - Begin
				if(reactivateOnline) {
					if(safiChallenge) {
						logonResp.setContactInfo(logonHelper.populateContact(customer.getContactDetail()));
						logonResp.setSecureCodeInfo(logonHelper.populateSecureCodeInfo(customer));
						logonResp.setReactivateOnline(true);
						logonResp.setShowSafiChallenge(true);
						logonResp.setTermsAcceptanceReqd(false);
						logonResp.setCustomer(null);
						genericSession.setLoggedonState(LogonHelper.LOGGEDON_STATE_SAFI_CHALLENGE);
					} else {
						//TODO TBC show error
						Logger.warn("Inside processLogon() - safiChallenge is FALSE for COVID19 OTP Reactivate Online Flow, returning an error.", this.getClass());
						BusinessException exp = new BusinessException(BusinessException.SMPL_SYS_ERROR);
						IMBResp resp1 = MBAppUtils.createErrorResp(origin, exp, MBAppConstants.SMPL_LOGON_RESP_NAME, httpServletRequest);
						return resp1;
					}
				}
				//20E4 - COVID19 OTP - Reactivate Online - End
				
				return logonResp;
			}
			else if(BusinessException.NO_ACCOUNTS_AVAILABLE==e.getKey() 
					|| BusinessException.NO_ACTIVE_ACCOUNTS==e.getKey()){
				Logger.error("No accounts avail for customer " + origin ,e, this.getClass());				
				IMBResp resp1 = MBAppUtils.createErrorResp(origin, BusinessException.NO_ACTIVE_ACCOUNTS , MBAppConstants.SMPL_LOGON_RESP_NAME, httpServletRequest);
				return resp1;
			}
			else if(e.getKey()==BusinessException.INVALID_CHAR_SET)
			{
				IMBResp resp1 = MBAppUtils.createErrorResp(origin, e, MBAppConstants.SMPL_LOGON_RESP_NAME, httpServletRequest);
				return resp1;
			}else if(e.getKey()==BusinessException.SAFI_LOGON_DENY_ERROR)
			{
				digitalSecLoggerVO.setStatus(DigitalSecLogger.SAFI_DENY_STATUS);
				digitalSecurityLogger.log(digitalSecLoggerVO);
				
				OriginsVO myOriginVO = IBankParams.getOrigin(origin);
			    OriginsVO baseOrigin = IBankParams.getOrigin(myOriginVO.getBankName());
			    String[] values = { baseOrigin.getBpayPhone() };
			    IMBResp resp1 = MBAppUtils.createErrorResp(origin, e,values, MBAppConstants.SMPL_LOGON_RESP_NAME, httpServletRequest);
				return resp1;
			}else if(e.getKey()==BusinessException.IBANK_SECURE_NO_PHONE_EXIST){
				
				digitalSecLoggerVO.setStatus(DigitalSecLogger.SAFI_CHALLENGE_STATUS);
				digitalSecurityLogger.log(digitalSecLoggerVO);
				
				IMBResp resp1 = MBAppUtils.createErrorResp(origin, e, MBAppConstants.SMPL_LOGON_RESP_NAME, httpServletRequest);
				return resp1;
			}//19E4 Tech Debt Start:Switch Removal
			else if(/*IBankParams.isPasswordReset19E1SwitchON() &&*/ e.getKey()==BusinessException.ACCOUNT_LOCKED){
				BusinessException exp = new BusinessException(BusinessException.USER_LOCKED_RESET_PASSWORD);
				IMBResp resp1 = MBAppUtils.createErrorResp(origin, exp, MBAppConstants.SMPL_LOGON_RESP_NAME, httpServletRequest);
				return resp1;
			}
			digitalSecLoggerVO.setStatus(DigitalSecLogger.FAILURE);
			initializeLogonDigitalLogger(req, digitalSecLoggerVO,null, ibankCommonData,DigitalSecLogger.APP_LOGON);
			digitalSecurityLogger.log(digitalSecLoggerVO);
			IMBResp resp1 = MBAppUtils.createErrorResp(origin, e, MBAppConstants.SMPL_LOGON_RESP_NAME, httpServletRequest);
			return resp1;
		} catch (Exception e)
		{
			Logger.warn("Exception Inside processLogon() for Customer 2.  ", e, this.getClass());
			BusinessException exp = new BusinessException(BusinessException.SMPL_SYS_ERROR);
			IMBResp resp1 = MBAppUtils.createErrorResp(origin, exp, MBAppConstants.SMPL_LOGON_RESP_NAME, httpServletRequest);
			return resp1;
		} finally
		{
			
			if ( reactivateOnline &&  safiChallenge &&  genericSession != null  )
			{
				genericSession.updateSession();
				MBAppLogger.logUserAgent(httpServletRequest, genericSession.getUser().getGCISNumber(), sessId, origin);	
				Logger.warn("Updating session for Reactivate.  ", this.getClass());
			}
			else if ( ! reactivateOnline &&  genericSession != null ){
				genericSession.updateSession();
				MBAppLogger.logUserAgent(httpServletRequest, genericSession.getUser().getGCISNumber(), sessId, origin);	
			}
			perfLogger.endLog(logName);
			perfLogger.endAllLogs();
		}

	}

	
	
	private void populateSplashPageResponse(HttpServletRequest httpServletRequest, String origin,
			MobileSession mobileSession, IBankCommonData ibankCommonData, Customer customer, boolean mustChangePwd,
			Boolean smsRest, boolean isECorrespondenceSupported, List<MessageSearch> splashPageInfo,
			MessageSearch messageSearch, IMBResp serviceResponse) throws BusinessException {
		List populateSplashPageResult;
		MsgCentreInfo msgCentreInfo;
		Logger.debug("Before populate splashPageInfo", this.getClass());
		if(isSpashPageInfoPresent(splashPageInfo)){
			
			boolean isSplashPageAdded = false;
			if(MessageCentreConstants.PAYTOMOBILE_DECOMMISSION.equals(messageSearch.getMessageAction())){
				if(checkPayToMobileSplashEligibility(messageSearch, ibankCommonData)){
					isSplashPageAdded = true;
					msgCntrService.updateCustomerMessage(messageSearch,ibankCommonData.getCustomer().getGcis(), true);
					populateNPPSplashResp(serviceResponse, ibankCommonData.getOrigin(),P2M_DECOMMISSION_SPLASH_TYPE);
				}else{
					msgCntrService.updateCustomerMessage(messageSearch,ibankCommonData.getCustomer().getGcis(), false);
					msgCentreInfo = msgCntrService.getMobLogonMsgs(customer.getGcis());
					splashPageInfo= msgCentreInfo.getSplashPageInfo();
					messageSearch = setSpashpageInfoInSession(mobileSession, splashPageInfo, messageSearch);
				}
			}
			
			if(!isSplashPageAdded){
				if(MessageCentreConstants.PAYID_REGISTRATION.equals(messageSearch.getMessageAction())){
					if(checkPayIDRegSplashEligibility(messageSearch, ibankCommonData)){
						isSplashPageAdded = true;
						msgCntrService.updateCustomerMessage(messageSearch,ibankCommonData.getCustomer().getGcis(), true);
						populateNPPSplashResp(serviceResponse, ibankCommonData.getOrigin(),PAYID_REGISTRATION_SPLASH_TYPE);
					}else{
						msgCntrService.updateCustomerMessage(messageSearch,ibankCommonData.getCustomer().getGcis(), false);
						msgCentreInfo = msgCntrService.getMobLogonMsgs(customer.getGcis());
						splashPageInfo= msgCentreInfo.getSplashPageInfo();
						messageSearch = setSpashpageInfoInSession(mobileSession, splashPageInfo, messageSearch);
					}
				}
			}
			
			if(!isSplashPageAdded){
				if(MessageCentreConstants.MADISON_SPLASH.equals(messageSearch.getMessageAction())){
					perfLogger.startLog("SPLASH_Madison");
					String MADISON_SWITCH = IBankParams.getBrandSwitchVal(ibankCommonData.getOrigin().trim(), IBankParams.MADISON_SWITCH) ;
					boolean isPilot = false;
					Logger.debug("Madison Switch Value: "+MADISON_SWITCH, this.getClass());
					if(MADISON_SWITCH.equalsIgnoreCase("2")){
						IBankRefershParams iBankRefreshParams =  (IBankRefershParams)ServiceHelper.getBean("ibankRefreshParams");
						isPilot=iBankRefreshParams.isPilotCustomer(ibankCommonData.getCustomer().getGcis(),MADISON_PILOT);
					}
					if(isPilot || MADISON_SWITCH.equalsIgnoreCase("1")) {
						if(logonHelper.checkMadisonSplashEligibility(httpServletRequest)){
							isSplashPageAdded = true;
							msgCntrService.updateCustomerMessage(messageSearch,ibankCommonData.getCustomer().getGcis(), true);
							String learnMoreLink=logonHelper.getLearnMoreLink(origin);
							String appLink=logonHelper.getAppLink(origin);
							populateMadisonSplashResp(serviceResponse, ibankCommonData.getOrigin(),MADISON_SPLASH_TYPE, learnMoreLink, appLink);
						}
						else {
							msgCentreInfo = msgCntrService.getMobLogonMsgs(customer.getGcis());
							splashPageInfo= msgCentreInfo.getSplashPageInfo();
							messageSearch = setSpashpageInfoInSession(mobileSession, splashPageInfo, messageSearch);
						}
					}
					perfLogger.endLog("SPLASH_Madison");
				}
			}				
			
			if(!isSplashPageAdded){
				if(MessageCentreConstants.MATRIX_FORCE_MIGRATION_MSG_ACTION.equals(messageSearch.getMessageAction())){
					isSplashPageAdded = true;
					populateSplashPageResp(serviceResponse, hasMatrixSplashPageMaxCountReached(messageSearch, IBankParams.getMaxMatrixMigSplashSkipCount()), FORCED_MATRIX_MIGRATION_SPLASH_TYPE);
				}
			}
			
			// 21E1 Email bounce back
						if (!isSplashPageAdded) {
							if (MessageCentreConstants.EMAIL_BOUNCE_BACK_MSG_ACTION.equals(messageSearch.getMessageAction())) {
								boolean isEBBSwitchON = IBankParams.isSwitchOn(IBankParams.EMAIL_BOUNCE_BACK_SWITCH);
								Logger.debug("LogonUtilController:654:isEBBSwitchON: " + isEBBSwitchON, this.getClass());

								if (isEBBSwitchON) {
									boolean isEBBSplashRequired = isEBBRequired(ibankCommonData);
									Logger.debug("LogonUtilController:707:isEBBSplashRequired: " + isEBBSplashRequired,
											this.getClass());

									if (isEBBSplashRequired) {									
										emailBounceBackService.addStatisticLog(messageSearch, ibankCommonData, "showEmailBounceBackSplash",
												"");
										isSplashPageAdded = true;
										populateEBBSplashPageResp(serviceResponse,
												hasEBBSplashPageMaxCountReached(messageSearch, IBankParams.getMaxEBBSkipCount()),
												EMAIL_BOUNCE_BACK_SPLASH_TYPE, messageSearch.getCustMessageExpiry(),
												messageSearch.getAppField2());
									}
								}
							}
						}
						// End
			
			if(!isSplashPageAdded){
				if(MessageCentreConstants.EMAIL_UPDATION_MSG_ACTION.equals(messageSearch.getMessageAction())){
					isSplashPageAdded = true;
					populateSplashPageResp(serviceResponse, hasEmailUpdateSplashPageMaxCountReached(messageSearch,IBankParams.getMaxEmailUpdateSplashSkipCount()), EMAIL_UPDATE_SPLASH_TYPE);
				}
			}
			
			if(!isSplashPageAdded){
				if(MessageCentreConstants.SPLASH_OB_ESTATEMENT.equals(messageSearch.getMessageAction()) && null!=customer.getContactDetail() && null!=customer.getContactDetail().getEmail()){
					isSplashPageAdded = true;
					if(mobileEStatementsService.isEligibleForEstmtOnboarding(customer, ibankCommonData))
						populateSplashPageResp(serviceResponse, hasSplashPageMaxCountReached(messageSearch, IBankParams.getMaxEstatementSplashSkipCount()), ESTMT_SPLASH_TYPE);
					else
					    mobileEStatementsService.deleteMessage(messageSearch, ibankCommonData);;
				}
			}
			
			if(!isSplashPageAdded  && isSpashPageInfoPresent(splashPageInfo)){
				if(MessageCentreConstants.SPLASH_ACTION_ECORRESPONDENCE.equals(messageSearch.getMessageAction())) {
					if(populateECorrespondenceSplashResp(serviceResponse))
						mobileSession.setLoggedonState(LogonHelper.LOGGEDON_STATE_ECORRESPONDENCE_PROMPT);
					//TODO check if the onBoardingVo has to be set null after testing
				}else {
					populateSplashPageResult=populateSplashPage(splashPageInfo, origin, customer, ibankCommonData, serviceResponse);
					if(null!= populateSplashPageResult){
						boolean crsSplash = (boolean) populateSplashPageResult.get(0);
						Logger.debug("After populateSplashPage : crsSlpash :"+crsSplash , this.getClass());
						if(crsSplash){
							if(populateSplashPageResult.size() > 1){
								//genericSession.setAttribute(MobileSessionImpl.CRS_REGISTRATION_NUMBER, (String)populateSplashPageResult.get(1));
								mobileSession.setCrsRegistrationNumber((String)populateSplashPageResult.get(1));
								Logger.debug("In LogonUtilController :: CRS Flag "+(String)populateSplashPageResult.get(1), this.getClass());
							}							
							if(isCrsHardPrompt3(splashPageInfo)){
								boolean isSmsReset = smsRest != null ? smsRest.booleanValue() : false ;
								if(!mustChangePwd || !isSmsReset){
									Logger.debug("This is hard prompt three ..Setting logged on state..", this.getClass());
									mobileSession.setLoggedonState(LogonHelper.LOGGEDON_STATE_CRS_HARD_PROMPT);
								}
								
							}
						}
					} else {
						
						// NOTE: Never remove this condition from code because it is populating splash page response for Savings habit in this method
						// TODO Refactor the code to make it more readable
						if (showSavingsOnBoardingSplashPage(ibankCommonData, customer, messageSearch, serviceResponse)) {
							Logger.debug("Splash page response populated for Savings Onboarding", this.getClass());
						}
					}
				}
			}
			
		}
		else if(setEcorrespondenceSplashPage(customer,serviceResponse, "processLogon",isECorrespondenceSupported)) {
			mobileSession.setLoggedonState(LogonHelper.LOGGEDON_STATE_ECORRESPONDENCE_PROMPT);
			//TODO check if the onBoardingVo has to be set null after testing
		}
	}

	/**
	 * <p>Create JSON response for email bounce back splash page with expiry date.</p>
	 * @param serviceResponse
	 * @param hasSplashPageMaxCountReached
	 * @param splashPageType
	 * @param expiryDate
	 */
	private void populateEBBSplashPageResp(IMBResp serviceResponse, boolean hasSplashPageMaxCountReached,
			String splashPageType, Date expiryDate, String emailAddress) {
		DateFormat dateFormatExpr = new SimpleDateFormat("dd MMM yyyy");

		SplashPageResp splashPageResp = new SplashPageResp();
		splashPageResp.setSplashType(splashPageType);
		splashPageResp.setExpiryDate((expiryDate == null) ? "" : dateFormatExpr.format(expiryDate));
		splashPageResp.setSplashPageMaxCountReached(hasSplashPageMaxCountReached);
		splashPageResp.setCustomerEmail(emailAddress);

		Logger.debug("populateSplashPageResp():@728:splashPageType: " + splashPageType
				+ " | hasSplashPageMaxCountReached: " + hasSplashPageMaxCountReached + "| Expiry Date: "
				+ splashPageResp.getExpiryDate() + " | emailAddress: " + emailAddress, this.getClass());

		setCustomerSplashPageResp(serviceResponse, splashPageResp);
	}
	
	private boolean hasEBBSplashPageMaxCountReached(MessageSearch messageSearch, int maxAllowedCount) {
		int lastUpdatedCount = 0;
		if (null != messageSearch && messageSearch.getAppField1() != null) {
			lastUpdatedCount = Integer.parseInt(messageSearch.getAppField1());
		}
		return maxAllowedCount <= lastUpdatedCount;
	}

	private MessageSearch setSpashpageInfoInSession(MobileSession mobileSession, List<MessageSearch> splashPageInfo,
			MessageSearch messageSearch) {
		if(splashPageInfo.size() > 0 && splashPageInfo.get(0) != null) {
			messageSearch = splashPageInfo.get(0);
			//genericSession.setAttribute(MobileSessionImpl.SPLASH_MESSAGE_INFO, messageSearch);
			mobileSession.setSplashInfoMsg(messageSearch);
		}
		return messageSearch;
	}

	private boolean isSpashPageInfoPresent(List<MessageSearch> splashPageInfo) {
		return splashPageInfo != null && splashPageInfo.size() > 0 && splashPageInfo.get(0) != null;
	}

	private MessageSearch setSplashmsgInfoInSession(IGenericSession genericSession, List<MessageSearch> splashPageInfo) {
		MessageSearch messageSearch = null;
		if(splashPageInfo != null && !splashPageInfo.isEmpty()){
			if(splashPageInfo.size() > 0) {
				messageSearch =splashPageInfo.get(0); 
				genericSession.setAttribute(MobileSessionImpl.SPLASH_MESSAGE_INFO, messageSearch);
				
			}
		}
		return messageSearch;
	}

	private AutoApplyRetentionInfo setAutoApplyRetentionInfoInSession(IGenericSession genericSession,
			MsgCentreInfo msgCentreInfo) {
		List<AutoApplyRetentionInfo> digiRetInfoList=		msgCentreInfo.getApplyRetentionInfo();
		AutoApplyRetentionInfo autoApplyRetentionInfo =null;
		if(digiRetInfoList!= null && digiRetInfoList.size()>0 ){
			try{
			 autoApplyRetentionInfo = digiRetInfoList.get(0);
		
			 Logger.debug("Auto Apply retention info message seen: "+autoApplyRetentionInfo.getAccountNumber(), this.getClass());
			 
			genericSession.setAttribute(MobileSessionImpl.AUTO_APPLY_RETENTION_SESSION, autoApplyRetentionInfo);
			}
			catch(Exception e){
				Logger.warn("LogonUtilController:processLogon() autoApplyRetentionInfo is null", this.getClass());
			}
		}
		return autoApplyRetentionInfo;
	}

	private boolean isPwdChangeSafiChallenge(User user, Customer customer, String safiAction, Boolean smsRest) {
		return !(smsRest != null && smsRest.booleanValue()) && !(user.isStatusMustChangePassword()) && (!StringMethods.isEmptyString(safiAction)) && (safiAction.equalsIgnoreCase(SafiConstants.SAFI_ACTION_CHALLENGE)) && (!hasSecureCodeConstraints(customer));
	}
	
	@RequestMapping("/getCustApp")
	@ResponseBody
	public IMBResp getCustomerApp(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse,@RequestBody final CustomerAppReq req) throws BusinessException
	{
		final String METHOD_NAME = "getCustomerApp";
		IGenericSession genericSession = null;
		perfLogger.startAllLogs();
		String logName = MBAppUtils.getLogName(httpServletRequest);
		perfLogger.startLog(logName);		
		String sessDeviceId = null; 
		String origin = LogonHelper.resolveOrigin(httpServletRequest);
		IBankRefershParams iBankRefreshParams =  (IBankRefershParams)ServiceHelper.getBean("ibankRefreshParams");
		boolean logonSpeedSwitch = iBankRefreshParams.isNativeLogonSpeedSwitch(origin);
		RespHeader headerResp = null;
		if(!logonSpeedSwitch) {
			Logger.error("NativeLogonSpeedSwitch is OFF for brand " + origin ,this.getClass());
			IMBResp resp1 = MBAppUtils.createErrorResp(origin, BusinessException.GENERIC_ERROR, "getCustApp", httpServletRequest);
			return resp1;
		}
		NativeLogonSwitch logonSwitch = iBankRefreshParams.getNativeLogonSwitch(origin);
		if (req.getSessionId()!=null){
			genericSession = GenericSessionFactory.getInstance(req.getSessionId());
			
			Logger.debug("getCustomerApp - getting session :"+genericSession , this.getClass());
			
			if ( genericSession.getAttribute(SMPL_DEVICE_ID) != null )
			{
				sessDeviceId = (String) genericSession.getAttribute(SMPL_DEVICE_ID);
				Logger.info("getCustomerApp DeviceID " + sessDeviceId, this.getClass());
			}				
		}else{
			//CONNECT NOT SUPPORTED!!!!!!!!!!!!!!!!
			Logger.error("SESSION ID IS NULL" ,this.getClass());
			throw new BusinessException(BusinessException.SESSION_EXPIRED,"Device ID do not match , Session Device ID :" + sessDeviceId + ", Request Device ID : " + req.getDeviceId());			
		}
		if(!req.getDeviceId().equalsIgnoreCase(sessDeviceId)){
			Logger.error("Device ID do not match , Session Device ID :" + sessDeviceId + ", Request Device ID : " + req.getDeviceId() ,this.getClass());
			IMBResp resp1 = MBAppUtils.createErrorResp(origin, BusinessException.SESSION_EXPIRED, "getCustApp", httpServletRequest);
			return resp1;
		}  
		String userAgent = httpServletRequest.getHeader(USER_AGENT);
		Logger.info("***User-Agent: " + userAgent.toLowerCase() + "***SessionId: " + genericSession.getId(), this.getClass());
		httpServletResponse.setHeader("Set-Cookie", MBAppConstants.SMPL_SESS_CONSTANT + "=" + genericSession.getId()   + "; HttpOnly ;secure;  path=/   " );
		//httpServletResponse.setHeader("Set-Cookie", MBAppConstants.SMPL_SESS_CONSTANT + "=" + genericSession.getId()   + "; HttpOnly ;  path=/   " );
		Logger.info("Native Logon Switch ---- " + logonSwitch.getSwitchStatus(), this.getClass());
		if (NativeLogonSwitch.ALLON.equals(logonSwitch)) {
			SuccessResp successResp = new SuccessResp();
			MobileSession dummySession = null;
			headerResp = populateResponseHeader(req.getHeader().getServiceName(), dummySession);
			successResp.setHeader(headerResp);
			successResp.setIsSuccess(true);	
			return successResp;
		}else {
			MobileSession mobileSession = new MobileSessionImpl();
			mobileSession.setSession(genericSession);
			Logger.debug("Inside getCustmerApp::" , this.getClass());
			ObjectMapper mapper = new ObjectMapper();
			httpServletRequest.setAttribute(LogonHelper.ORIGIN, origin);
			String gdwOrigin = logonHelper.getGDWOrigin(req.getHeader(), origin);
			MBAppHelper mbAppHelper = new MBAppHelper();
			String onboardingQZSession = null;
			int unreadMsgCount = 0;
			IMBResp serviceResponse = null;
			User user = null;
			OnboardingVO oldOnboarding = null;
			Customer customer = null;
			try
			{
				logonHelper.setWebReadyCookie(httpServletRequest, httpServletResponse , "1" );
				user = mobileSession.getUser();
				
				MBAppLogger.logUserAgent(httpServletRequest, mobileSession);
				MBAppLogger.logAppVersionCookie(httpServletRequest, mobileSession);			
				mobileSession.setGDWOrigin(gdwOrigin);
				
				// Populating IBankCommonData
				IBankCommonData ibankCommonData = populateIBankCommonData(mobileSession.getSessionID(), mobileSession.getUser(), origin, MBAppHelper.resolveIPAddress(httpServletRequest, origin), userAgent, gdwOrigin);
				mobileSession.getUser().setAttribute(IBankParams.USEROBJ_BRAND, origin);
				mobileSession.setOrigin(origin);
				
				//18E4 throw error if the session is DM session
				MBAppHelper.validateMBSessionId(mobileSession.getSessionID());
				
				customer = logonHelper.getCustomerInSession( mobileSession, ibankCommonData,METHOD_NAME);
					
				String safiAction = logonHelper.safiActionFromSession(mobileSession, customer, METHOD_NAME);
				
				DigitalSecLogggerVO digitalSecLoggerVO = logonHelper.initializeDigiLoggerSafiAppLogon(mobileSession, ibankCommonData); 
				
				if(logonHelper.isSafiDeny(safiAction)){
					Logger.warn("SAFI : getCustmerApp:SafiAction from Session: "+safiAction+"GCISNumber: "+customer.getGcis(), this.getClass());
					throw new BusinessException(BusinessException.SAFI_LOGON_DENY_ERROR);
				}
				//Throw Ecxeption if SafiChallenge and No Phone Number
				safiChallengeWithoutPhoneNumber(customer, safiAction, digitalSecLoggerVO, METHOD_NAME);
				
				// 17E4 changes for staff assisted rego
				String autoInitStatus=(String)user.getAttribute(IBankParams.REG_STATUS);
				if(isAutoInitAdmin(autoInitStatus)){
					Logger.debug("***AutoInitStatus inside getCustmerApp 1: ", this.getClass());
					LogonResp logonResp = logonHelper.populateAutoInitLogonResp( httpServletRequest, mapper, customer, METHOD_NAME);
					mobileSession.setLoggedonState(LogonHelper.AUTO_INIT_RESET_PWD_SECNUM);
					return logonResp;					 
				}
						
				OnboardingVO onboardingVO = mobileSession.getOnboardingVO();
				
				ForceChangePwd forceVO = logonHelper.setForceChangedPwdInSession( mobileSession, ibankCommonData);
				ForceChangePwdService forceService = ServiceHelper.getBean(ServiceConstants.FORCE_PWD_CHANGE);			
				if (forceService.isCustomerTarget(forceVO)){
					setLoggedStatus(mobileSession, ForceChangePwdServiceImpl.FORCE_PWD_TARGETED, customer);
					onboardingVO = null;
				}
				//TODO Check if the Tracking Id Cookie, AnalyticsCookie and T&C Cookie can be kept independent of the onboarding process 
				onboardingVO = checkSafiConstraintChallenge(safiAction, customer, onboardingVO, METHOD_NAME);
				if(onboardingVO != null && onboardingVO.getTicket() != null)
				{
					boolean isAndroid = logonHelper.isAndroid(httpServletRequest);
					oldOnboarding = setOnBoardingSteps(onboardingQZSession, user, mobileSession, ibankCommonData, customer,
							onboardingVO, isAndroid);
					
					if(! ("SPIKETC".equalsIgnoreCase(onboardingVO.getTicket()) || "SPIKEAPP".equalsIgnoreCase(onboardingVO.getTicket())) ) {
						mbAppHelper.addTrackingIdCookie(customer.getPreference().getTrackingId(), IBankParams.getBaseOriginCode(ibankCommonData.getOrigin()), httpServletRequest, httpServletResponse);
						MBAppHelper.addWebAnalyticsCookis(IBankParams.getBaseOriginCode(ibankCommonData.getOrigin()), httpServletRequest, httpServletResponse);
						validatetermsAndCondCookie(mobileSession.getUser().getUserId(), httpServletRequest, httpServletResponse);
					}
				}
				else{
					mbAppHelper.addTrackingIdCookie(customer.getPreference().getTrackingId(), IBankParams.getBaseOriginCode(ibankCommonData.getOrigin()), httpServletRequest, httpServletResponse);
					//bypass TnC cookie check if coming via OnlineRegistration flow
					if(mobileSession.getOnlineRegistrationDetails() == null){					
						validatetermsAndCondCookie(mobileSession.getUser().getUserId(), httpServletRequest, httpServletResponse);
					}
				}

				
				Boolean smsRest = (Boolean) user.getAttribute(SMS_RESET_STATUS);
				Logger.info("***smsRest getCustmerApp : " +smsRest, this.getClass());
				
				if (user.isStatusMustChangePassword() || smsRest.booleanValue())
				{
					Logger.info("***smsRest True : " +smsRest, this.getClass());
					
					if (user.isStatusMustChangePassword()){
						mobileSession.setLoggedonState(LogonHelper.LOGGEDON_STATE_FORCE_RESETPWD);
					}else{
						mobileSession.setLoggedonState(LogonHelper.LOGGEDON_STATE_FORCE_RESETPWD_SECNUM);
					}
					
					serviceResponse = logonHelper.populateCustomeCredentialChange(customer, mobileSession.getUser(), httpServletRequest, httpServletResponse);
					Logger.debug("User Requested for change of password | In this case no need to set Onboarding Object", LogonUtilController.class);
				}
				else if(logonHelper.isSafiChallenge(safiAction) && !hasSecureCodeConstraints(customer)){
						Logger.debug("SAFI : LogonUtilController:getCustmerApp(): Setting LoggedOnState - SafiChallenge: SafiAction: "+safiAction+" GCISNumber: "+customer.getGcis(), this.getClass());
						serviceResponse = logonHelper.populateResponse(customer, mobileSession.getUser(), unreadMsgCount, httpServletRequest, httpServletResponse, user.isStatusMustChangePassword());
						serviceResponse = logonHelper.populateSafiResponse(serviceResponse, customer);
						mobileSession.setLoggedonState(LogonHelper.LOGGEDON_STATE_SAFI_CHALLENGE);
				}else
				{
					Logger.info("***smsRest False : " +smsRest, this.getClass());
					boolean isECorrespondenceSupported = CommonBusinessUtil.isECorrespondenceSupported(httpServletRequest);
					MsgCentreInfo messageCentreInfo= processMsgCentre(origin,customer.getGcis(),isECorrespondenceSupported);
					List<MessageSearch> splashPageInfo= messageCentreInfo.getSplashPageInfo();
					unreadMsgCount = messageCentreInfo.getUnreadMessageCount();
					Logger.debug("splashPageInfo - unreadMsgCount: "+unreadMsgCount, this.getClass());
					
					MessageSearch messageSearch = logonHelper.setSplashPageInfoInSession(mobileSession, splashPageInfo);		
					AutoApplyRetentionInfo autoApplyRetentionInfo = logonHelper.setDigiRetentionInfoInSession(mobileSession,messageCentreInfo);
					// call service to get ServiceAdminVo
					ServiceStationVO servicestationVO = setDashBoardServiceStationMsgInSession(mobileSession,ibankCommonData);
					
					serviceResponse = logonHelper.populateResponse(customer, mobileSession.getUser(), unreadMsgCount, httpServletRequest, httpServletResponse, user.isStatusMustChangePassword(),servicestationVO,autoApplyRetentionInfo);
					
					//Populate the ghost tile Response
					//20E2-CSH -SBGEXP-8227 - added two conditions to check CSH/Efinance/Homeloan combination
					logonHelper.populateGhostTileResponse(serviceResponse, mobileSession, ibankCommonData, customer);
					boolean mustChangePwd = user.isStatusMustChangePassword();
//					Populate the SplashPage Response
					populateSplashPageResponse(httpServletRequest, gdwOrigin, mobileSession, ibankCommonData, customer, mustChangePwd, smsRest, isECorrespondenceSupported, splashPageInfo, messageSearch, serviceResponse);
					String encryptedCookieUserid = logonHelper.getEncryptedUserID(mobileSession.getUser().getUserId());
					logonHelper.addNewTnCCookie(httpServletRequest, httpServletResponse, encryptedCookieUserid, "1.0");
					((LogonResp) serviceResponse).setTermsAcceptanceReqd(false);
					((LogonResp) serviceResponse).setOnboarding(oldOnboarding);
					
					//if (!hasSecureCodeConstraints(customer)){
					forceService = ServiceHelper.getBean(ServiceConstants.FORCE_PWD_CHANGE);
					
					String forceStatus = forceService.getStatusFromVO(ibankCommonData, forceVO);
					Logger.debug("forceChangePwd gcis: " + customer.getGcis() + " status = " + forceStatus, LogonUtilController.class);
					setLoggedStatus(mobileSession, forceStatus, customer);
					((LogonResp) serviceResponse).setForceChangePwdStatus(forceStatus);
					((LogonResp) serviceResponse).setRemSkipCount(forceService.getRemSkipCount(forceVO, forceStatus, origin));
					
					Logger.debug("Setting OnBoarding Object only if changePassword false", LogonUtilController.class);
				}
				
				// 20E1 : Data masking for account num : Start
				String serviceResponseForMasking = mapper.writeValueAsString(serviceResponse);
				String serviceResponseAfterMasking = maskAccountNumValue(serviceResponseForMasking);
				Logger.info("Simplified Logon /getCustmerApp normal JSON Response :" + serviceResponseAfterMasking,
						this.getClass());
				// 20E1 : Data masking for account num : End
				headerResp = populateResponseHeader(ServiceConstants.LOGON_RESPONSE, mobileSession);
				
				//setting the name id in response after loggin from native app
				setSecurityUniqueId(mbAppHelper, mobileSession, headerResp);
				
				serviceResponse.setHeader(headerResp);
				
				//17E4 : Native Redesign
				Logger.debug("/getCustmerApp :: getCustmerApp():: CUST_NAME_REQUESTED ::"+mobileSession.getCustNameRequested(), this.getClass());
				return serviceResponse;
			} catch (BusinessException e){
				Logger.info("Exception Inside processLogon() for Customer 1. " + e.getKey(), this.getClass());
				if (e.getKey() == (BusinessException.COOKIES_NOT_FOUND)){
					LogonResp logonResp = new LogonResp();
					logonResp.setTermsAcceptanceReqd(true);
					logonResp.setChangePwdReqd(user.isStatusMustChangePassword());
					Boolean smsRest = (Boolean) user.getAttribute(LogonHelper.SMS_RESET_STATUS);
						if (smsRest != null && smsRest.booleanValue()){
							logonResp.setChangePwdAndSecNumReqd(smsRest.booleanValue());
						}
					AppParams appParams = logonHelper.populateAppParams(httpServletRequest, customer);
					logonResp.setAppParams(appParams);
					headerResp = populateResponseHeader(ServiceConstants.LOGON_RESPONSE, genericSession);				
					
					//setting the name id in response after loggin from native app
					setSecurityUniqueId(mbAppHelper, genericSession, headerResp);
					
					logonResp.setHeader(headerResp);
					
					Logger.debug("Value of change password required"+logonResp.isChangePwdReqd(), LogonUtilController.class);
					Logger.debug("Value of change password and security number required"+logonResp.isChangePwdAndSecNumReqd(), LogonUtilController.class);
						if(!logonResp.isChangePwdReqd() && !logonResp.isChangePwdAndSecNumReqd()  ){
							Logger.debug("Setting the Onboarding object in response", LogonUtilController.class);
							logonResp.setOnboarding(oldOnboarding);
						}
					try {
						Logger.info("Business exception, Simplified Logon /mbAppLogon JSON Response :" + mapper.writeValueAsString(logonResp), this.getClass());
					} catch (Exception e1) {
						Logger.debug("Simplified Logon /mbAppLogon JSON Response : + mapper.writeValueAsString(logonResp)", this.getClass());
					}
					genericSession.updateSession();
					return logonResp;
				} else if (BusinessException.NO_ACCOUNTS_AVAILABLE == e.getKey() || BusinessException.NO_ACTIVE_ACCOUNTS == e.getKey()){
					Logger.error("No accounts avail for customer " + origin, e, this.getClass());
					IMBResp resp1 = MBAppUtils.createErrorResp(origin, BusinessException.NO_ACTIVE_ACCOUNTS , MBAppConstants.SMPL_LOGON_RESP_NAME, httpServletRequest);
					return resp1;
				} else if (e.getKey() == BusinessException.INVALID_CHAR_SET){
					IMBResp resp1 = MBAppUtils.createErrorResp(origin, e, MBAppConstants.SMPL_LOGON_RESP_NAME, httpServletRequest);
					return resp1;
				}else if (e.getKey() == BusinessException.SAFI_LOGON_DENY_ERROR){
					OriginsVO myOriginVO = IBankParams.getOrigin(origin);
				    OriginsVO baseOrigin = IBankParams.getOrigin(myOriginVO.getBankName());
				    String[] values = { baseOrigin.getBpayPhone() };
					IMBResp resp1 = MBAppUtils.createErrorResp(origin, e, values, MBAppConstants.SMPL_LOGON_RESP_NAME, httpServletRequest);
					return resp1;
				}//19E4 Tech Debt Start:Switch Removal
				else if(/*IBankParams.isPasswordReset19E1SwitchON() &&*/ e.getKey()==BusinessException.ACCOUNT_LOCKED){
					BusinessException exp = new BusinessException(BusinessException.USER_LOCKED_RESET_PASSWORD);
					IMBResp resp1 = MBAppUtils.createErrorResp(origin, exp, MBAppConstants.SMPL_LOGON_RESP_NAME, httpServletRequest);
					return resp1;
				}
				IMBResp resp1 = MBAppUtils.createErrorResp(origin, e, MBAppConstants.SMPL_LOGON_RESP_NAME, httpServletRequest);
				return resp1;
			} catch (Exception e){
				Logger.error("Exception Inside processLogon() for Customer 2.  ", e, this.getClass());
				BusinessException exp = new BusinessException(BusinessException.SYSTEM_UNAVILABLE);
				IMBResp resp1 = MBAppUtils.createErrorResp(origin, exp, MBAppConstants.SMPL_LOGON_RESP_NAME, httpServletRequest);
				return resp1;
			} finally{
				
				perfLogger.endLog(logName);
				perfLogger.endAllLogs();
			}
		}
	}
	
	@RequestMapping("/mbAppLogon")
	@ResponseBody
	public IMBResp mbAppLogonV1(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, @RequestBody final LogonReq req)
	{
		Logger.debug("Inside mbAppLogonV1::" , this.getClass());
		final String METHOD_NAME = "mbAppLogon";
		ObjectMapper mapper = new ObjectMapper();
		String origin = LogonHelper.resolveOrigin(httpServletRequest);
		httpServletRequest.setAttribute(LogonHelper.ORIGIN, origin);
		String gdwOrigin = logonHelper.getGDWOrigin(req.getHeader(), origin);
		String logName = MBAppUtils.getLogName(httpServletRequest);
		perfLogger.startAllLogs();
		perfLogger.startLog(logName);

		MBAppHelper mbAppHelper = new MBAppHelper();
		String onboardingQZSession = null;
		int unreadMsgCount = 0;
		IMBResp serviceResponse = null;
		User user = null;
		MobileSession mobileSession = null;
		OnboardingVO oldOnboarding = null;
		String deviceID=null;
		List populateSplashPageResult = null;
		try
		{
			mobileSession = mbAppHelper.getMobileSession(httpServletRequest);

			// String device ID:
			if(null!=mobileSession){
				deviceID=mobileSession.getDeviceID();
			}			
			Logger.debug("Device ID from session is ::" + deviceID, this.getClass());		
			logonHelper.setWebReadyCookie(httpServletRequest, httpServletResponse , "1" );

			user = mobileSession.getUser();
			if(user != null) {
				user.setActionType(req.getActionType());
			}
			String userAgent = httpServletRequest.getHeader(USER_AGENT);
			Logger.debug("mbAppLogonV1 origin" + origin + ": User-Agent :" + userAgent, this.getClass());
			
			MBAppLogger.logUserAgent(httpServletRequest, mobileSession);
			MBAppLogger.logAppVersionCookie(httpServletRequest, mobileSession);			
			mobileSession.setGDWOrigin(gdwOrigin);
			
			// Populating IBankCommonData
			IBankCommonData ibankCommonData = populateIBankCommonData(mobileSession.getSessionID(), mobileSession.getUser(), origin, MBAppHelper.resolveIPAddress(httpServletRequest, origin), userAgent, gdwOrigin);
			mobileSession.getUser().setAttribute(IBankParams.USEROBJ_BRAND, origin);
			mobileSession.setOrigin(origin);
			
			//18E4 throw error if the session is DM session
			MBAppHelper.validateMBSessionId(mobileSession.getSessionID());
			
			Customer customer = logonHelper.getCustomerInSession( mobileSession, ibankCommonData,METHOD_NAME);
			String safiAction = logonHelper.safiActionFromSession(mobileSession, customer, METHOD_NAME);
			
			DigitalSecLogggerVO digitalSecLoggerVO = logonHelper.initializeDigiLoggerSafiAppLogon(mobileSession, ibankCommonData); 
			
			if(logonHelper.isSafiDeny(safiAction)){
				Logger.warn("SAFI : mbAppLogon:SafiAction from Session: "+safiAction+"GCISNumber: "+customer.getGcis(), this.getClass());
				throw new BusinessException(BusinessException.SAFI_LOGON_DENY_ERROR);
			}
			//Throw Ecxeption if SafiChallenge and No Phone Number
			safiChallengeWithoutPhoneNumber(customer, safiAction, digitalSecLoggerVO, METHOD_NAME);
			
			// 17E4 changes for staff assisted rego
			String autoInitStatus=(String)user.getAttribute(IBankParams.REG_STATUS);
			if(isAutoInitAdmin(autoInitStatus)){
				Logger.info("***AutoInitStatus inside mbAppLogon 1: ", this.getClass());
				LogonResp logonResp = logonHelper.populateAutoInitLogonResp( httpServletRequest, mapper, customer, METHOD_NAME);
				mobileSession.setLoggedonState(LogonHelper.AUTO_INIT_RESET_PWD_SECNUM);
				return logonResp;					 
			}
					
			OnboardingVO onboardingVO = mobileSession.getOnboardingVO();
			
			ForceChangePwd forceVO = logonHelper.setForceChangedPwdInSession( mobileSession, ibankCommonData);
			ForceChangePwdService forceService = ServiceHelper.getBean(ServiceConstants.FORCE_PWD_CHANGE);			
			if (forceService.isCustomerTarget(forceVO)){
				setLoggedStatus(mobileSession, ForceChangePwdServiceImpl.FORCE_PWD_TARGETED, customer);
				onboardingVO = null;
			}
			//TODO Check if the Tracking Id Cookie, AnalyticsCookie and T&C Cookie can be kept independent of the onboarding process 
			onboardingVO = checkSafiConstraintChallenge(safiAction, customer, onboardingVO, METHOD_NAME);
			if(onboardingVO != null && onboardingVO.getTicket() != null)
			{
				boolean isAndroid = logonHelper.isAndroid(httpServletRequest);
				oldOnboarding = setOnBoardingSteps(onboardingQZSession, user, mobileSession, ibankCommonData, customer,
						onboardingVO, isAndroid);
				
				if(! ("SPIKETC".equalsIgnoreCase(onboardingVO.getTicket()) || "SPIKEAPP".equalsIgnoreCase(onboardingVO.getTicket())) ) {
					mbAppHelper.addTrackingIdCookie(customer.getPreference().getTrackingId(), IBankParams.getBaseOriginCode(ibankCommonData.getOrigin()), httpServletRequest, httpServletResponse);
					MBAppHelper.addWebAnalyticsCookis(IBankParams.getBaseOriginCode(ibankCommonData.getOrigin()), httpServletRequest, httpServletResponse);
					validatetermsAndCondCookie(mobileSession.getUser().getUserId(), httpServletRequest, httpServletResponse);
				}
			}
			else{
				mbAppHelper.addTrackingIdCookie(customer.getPreference().getTrackingId(), IBankParams.getBaseOriginCode(ibankCommonData.getOrigin()), httpServletRequest, httpServletResponse);
				//bypass TnC cookie check if coming via OnlineRegistration flow
				if(mobileSession.getOnlineRegistrationDetails() == null){					
					validatetermsAndCondCookie(mobileSession.getUser().getUserId(), httpServletRequest, httpServletResponse);
				}
			}

			
			Boolean smsRest = (Boolean) user.getAttribute(SMS_RESET_STATUS);
			Logger.info("***smsRest mbAppLogon : " +smsRest, this.getClass());
			
			if (user.isStatusMustChangePassword() || smsRest.booleanValue())
			{
				Logger.info("***smsRest True : " +smsRest, this.getClass());
				
				if (user.isStatusMustChangePassword()){
					mobileSession.setLoggedonState(LogonHelper.LOGGEDON_STATE_FORCE_RESETPWD);
				}else{
					mobileSession.setLoggedonState(LogonHelper.LOGGEDON_STATE_FORCE_RESETPWD_SECNUM);
				}
				
				serviceResponse = logonHelper.populateCustomeCredentialChange(customer, mobileSession.getUser(), httpServletRequest, httpServletResponse);
				Logger.debug("User Requested for change of password | In this case no need to set Onboarding Object", LogonUtilController.class);
			}
			else if(logonHelper.isSafiChallenge(safiAction) && !hasSecureCodeConstraints(customer)){
					Logger.debug("SAFI : LogonUtilController:mbAppLogon(): Setting LoggedOnState - SafiChallenge: SafiAction: "+safiAction+" GCISNumber: "+customer.getGcis(), this.getClass());
					serviceResponse = logonHelper.populateResponse(customer, mobileSession.getUser(), unreadMsgCount, httpServletRequest, httpServletResponse, user.isStatusMustChangePassword());
					serviceResponse = logonHelper.populateSafiResponse(serviceResponse, customer);
					mobileSession.setLoggedonState(LogonHelper.LOGGEDON_STATE_SAFI_CHALLENGE);
			}else
			{
				Logger.info("***smsRest False : " +smsRest, this.getClass());
				boolean isECorrespondenceSupported = CommonBusinessUtil.isECorrespondenceSupported(httpServletRequest);
				MsgCentreInfo messageCentreInfo= processMsgCentre(origin,customer.getGcis(),isECorrespondenceSupported);
				List<MessageSearch> splashPageInfo= messageCentreInfo.getSplashPageInfo();
				unreadMsgCount = messageCentreInfo.getUnreadMessageCount();
				Logger.debug("splashPageInfo - unreadMsgCount: "+unreadMsgCount, this.getClass());
				
				MessageSearch messageSearch = logonHelper.setSplashPageInfoInSession(mobileSession, splashPageInfo);		
				AutoApplyRetentionInfo autoApplyRetentionInfo = logonHelper.setDigiRetentionInfoInSession(mobileSession,messageCentreInfo);
				// call service to get ServiceAdminVo
				ServiceStationVO servicestationVO = setDashBoardServiceStationMsgInSession(mobileSession,ibankCommonData);
				
				serviceResponse = logonHelper.populateResponse(customer, mobileSession.getUser(), unreadMsgCount, httpServletRequest, httpServletResponse, user.isStatusMustChangePassword(),servicestationVO,autoApplyRetentionInfo);
				
				//Populate the ghost tile Response
				//20E2-CSH -SBGEXP-8227 - added two conditions to check CSH/Efinance/Homeloan combination
				logonHelper.populateGhostTileResponse(serviceResponse, mobileSession, ibankCommonData, customer);
				boolean mustChangePwd = user.isStatusMustChangePassword();
//				Populate the SplashPage Response
				populateSplashPageResponse(httpServletRequest, gdwOrigin, mobileSession, ibankCommonData, customer, mustChangePwd, smsRest, isECorrespondenceSupported, splashPageInfo, messageSearch, serviceResponse);
				String encryptedCookieUserid = logonHelper.getEncryptedUserID(mobileSession.getUser().getUserId());
				logonHelper.addNewTnCCookie(httpServletRequest, httpServletResponse, encryptedCookieUserid, "1.0");
				((LogonResp) serviceResponse).setTermsAcceptanceReqd(false);
				((LogonResp) serviceResponse).setOnboarding(oldOnboarding);
				
				//if (!hasSecureCodeConstraints(customer)){
				forceService = ServiceHelper.getBean(ServiceConstants.FORCE_PWD_CHANGE);
				
				String forceStatus = forceService.getStatusFromVO(ibankCommonData, forceVO);
				Logger.debug("forceChangePwd gcis: " + customer.getGcis() + " status = " + forceStatus, LogonUtilController.class);
				setLoggedStatus(mobileSession, forceStatus, customer);
				((LogonResp) serviceResponse).setForceChangePwdStatus(forceStatus);
				((LogonResp) serviceResponse).setRemSkipCount(forceService.getRemSkipCount(forceVO, forceStatus, origin));
				
				Logger.debug("Setting OnBoarding Object only if changePassword false", LogonUtilController.class);
			}
			
			if(customer != null && customer.isNoAccOrNoActAccounts()) {
				Logger.info("NO ACCOUNTS or NO ACTIVE Accounts for GCIS: "+customer.getGcis(), this.getClass());
				boolean cshTileExists = false;
				if(((LogonResp) serviceResponse).getCustomer() != null &&  ((LogonResp) serviceResponse).getCustomer().getGhostTiles() != null && ((LogonResp) serviceResponse).getCustomer().getGhostTiles().size() > 0) {
					for(GhostTileResp ghostTile : ((LogonResp) serviceResponse).getCustomer().getGhostTiles()) {
						if(LoanAppConstants.TILE_TYPE_CSH.equalsIgnoreCase(ghostTile.getTileType())) {
							cshTileExists = true;
							break;
						}
					}
				}
				if(IBankParams.PREPARE_ONLINE.equalsIgnoreCase(req.getActionType()) || cshTileExists) {
//					do nothing
				}
				else {
					Logger.error("Not a Prepare Online Deeplink or CSH Tiles present. So, throwing NO Accounts error: "+customer.getGcis(), this.getClass());
					throw new BusinessException(BusinessException.NO_ACCOUNTS_AVAILABLE);
				}
			}
			
			// 20E1 : Data masking for account num : Start
			String serviceResponseForMasking = mapper.writeValueAsString(serviceResponse);
			String serviceResponseAfterMasking = maskAccountNumValue(serviceResponseForMasking);
			Logger.info("Simplified Logon /mbAppLogon normal JSON Response :" + serviceResponseAfterMasking,
					this.getClass());
			// 20E1 : Data masking for account num : End
			RespHeader headerResp = populateResponseHeader(ServiceConstants.LOGON_RESPONSE, mobileSession);
			
			//setting the name id in response after loggin from native app
			setSecurityUniqueId(mbAppHelper, mobileSession, headerResp);
			
			serviceResponse.setHeader(headerResp);
			
			//17E4 : Native Redesign
			Logger.debug("/mbAppLogon :: mbAppLogon():: CUST_NAME_REQUESTED ::"+mobileSession.getCustNameRequested(), this.getClass());
			return serviceResponse;
		} catch (BusinessException e){
			Logger.info("Exception Inside processLogon() for Customer 1. " + e.getKey(), this.getClass());
			if (e.getKey() == (BusinessException.COOKIES_NOT_FOUND)){
				LogonResp logonResp = new LogonResp();
				logonResp.setTermsAcceptanceReqd(true);
				logonResp.setChangePwdReqd(user.isStatusMustChangePassword());
				Boolean smsRest = (Boolean) user.getAttribute(LogonHelper.SMS_RESET_STATUS);
					if (smsRest != null && smsRest.booleanValue()){
						logonResp.setChangePwdAndSecNumReqd(smsRest.booleanValue());
					}
				AppParams appParams = logonHelper.populateAppParams(httpServletRequest, mobileSession.getCustomer());
				logonResp.setAppParams(appParams);
				RespHeader headerResp = populateResponseHeader(ServiceConstants.LOGON_RESPONSE, mobileSession);				
				
				//setting the name id in response after loggin from native app
				setSecurityUniqueId(mbAppHelper, mobileSession, headerResp);
				
				logonResp.setHeader(headerResp);
				
				Logger.debug("Value of change password required"+logonResp.isChangePwdReqd(), LogonUtilController.class);
				Logger.debug("Value of change password and security number required"+logonResp.isChangePwdAndSecNumReqd(), LogonUtilController.class);
					if(!logonResp.isChangePwdReqd() && !logonResp.isChangePwdAndSecNumReqd()  ){
						Logger.debug("Setting the Onboarding object in response", LogonUtilController.class);
						logonResp.setOnboarding(oldOnboarding);
					}
				try {
					Logger.info("Business exception, Simplified Logon /mbAppLogon JSON Response :" + mapper.writeValueAsString(logonResp), this.getClass());
				} catch (Exception e1) {
					Logger.debug("Simplified Logon /mbAppLogon JSON Response : + mapper.writeValueAsString(logonResp)", this.getClass());
				}
				return logonResp;
			} else if (BusinessException.NO_ACCOUNTS_AVAILABLE == e.getKey() || BusinessException.NO_ACTIVE_ACCOUNTS == e.getKey()){
				Logger.error("No accounts avail for customer " + origin, e, this.getClass());
				IMBResp resp1 = MBAppUtils.createErrorResp(origin, BusinessException.NO_ACTIVE_ACCOUNTS , MBAppConstants.SMPL_LOGON_RESP_NAME, httpServletRequest);
				return resp1;
			} else if (e.getKey() == BusinessException.INVALID_CHAR_SET){
				IMBResp resp1 = MBAppUtils.createErrorResp(origin, e, MBAppConstants.SMPL_LOGON_RESP_NAME, httpServletRequest);
				return resp1;
			}else if (e.getKey() == BusinessException.SAFI_LOGON_DENY_ERROR){
				OriginsVO myOriginVO = IBankParams.getOrigin(origin);
			    OriginsVO baseOrigin = IBankParams.getOrigin(myOriginVO.getBankName());
			    String[] values = { baseOrigin.getBpayPhone() };
				IMBResp resp1 = MBAppUtils.createErrorResp(origin, e, values, MBAppConstants.SMPL_LOGON_RESP_NAME, httpServletRequest);
				return resp1;
			}//19E4 Tech Debt Start:Switch Removal
			else if(/*IBankParams.isPasswordReset19E1SwitchON() &&*/ e.getKey()==BusinessException.ACCOUNT_LOCKED){
				BusinessException exp = new BusinessException(BusinessException.USER_LOCKED_RESET_PASSWORD);
				IMBResp resp1 = MBAppUtils.createErrorResp(origin, exp, MBAppConstants.SMPL_LOGON_RESP_NAME, httpServletRequest);
				return resp1;
			}
			IMBResp resp1 = MBAppUtils.createErrorResp(origin, e, MBAppConstants.SMPL_LOGON_RESP_NAME, httpServletRequest);
			return resp1;
		} catch (Exception e){
			Logger.error("Exception Inside processLogon() for Customer 2.  ", e, this.getClass());
			BusinessException exp = new BusinessException(BusinessException.SYSTEM_UNAVILABLE);
			IMBResp resp1 = MBAppUtils.createErrorResp(origin, exp, MBAppConstants.SMPL_LOGON_RESP_NAME, httpServletRequest);
			return resp1;
		} finally{
			
			perfLogger.endLog(logName);
			perfLogger.endAllLogs();
		}
	}
	
	@RequestMapping("/getCustomer")
	@ResponseBody
	public IMBResp smplGetCustomer(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, @RequestBody final LogonReq req)
	{

		fraudLogger = new FraudLogger();
		perfLogger.startAllLogs();
		String logName = MBAppUtils.getLogName(httpServletRequest);
		perfLogger.startLog(logName);
		UserAgentParser bean = (UserAgentParser) ServiceHelper.getBean(ServiceConstants.USER_AGENT_PARSER);
		
		// LogonResponse resp = new LogonResponse();
		ObjectMapper mapper = new ObjectMapper();
		int unreadMsgCount = -1;
		String origin = LogonHelper.resolveOrigin(httpServletRequest);
		httpServletRequest.setAttribute(LogonHelper.ORIGIN, origin);
		MobileSession mobileSession =  null;
		String deviceID=null;
		Customer customer = null;
		List populateSplashPageResult = null;
		final String METHOD_NAME ="smplGetCustomer";
		
		try
		{
			String userAgent = httpServletRequest.getHeader(USER_AGENT);
			Logger.debug("Simplified Logon origin" + origin + ": User-Agent :" + userAgent, this.getClass());
			// Populating IBankCommonData
			IBankCommonData ibankCommonData = populateIBankCommonData(null, null, origin, MBAppHelper.resolveIPAddress(httpServletRequest, origin), userAgent);
			au.com.stgeorge.mbank.useragent.UserAgentVO userAgentVO = bean.parseUserAgentString(userAgent);
			MBAppHelper mbAppHelper = new MBAppHelper();
			mobileSession = mbAppHelper.getMobileSession(httpServletRequest);
			if(null!=mobileSession){
				deviceID=mobileSession.getDeviceID();
			}
			
			isCustomerOTPAuthVerified(mobileSession);
			
			Logger.debug("Device ID in session in smplGetCustomer::" + deviceID, this.getClass());
			if ( StringMethods.isEmptyString(mobileSession.getGDWOrigin()) )
			{
				String gdwOrigin  = logonHelper.getGDWOrigin( req.getHeader(),  origin);
				mobileSession.setGDWOrigin(gdwOrigin);
			}
			ibankCommonData.setUser(mobileSession.getUser());
			ibankCommonData.setSessionId(mobileSession.getSessionID());

			if ( ! "Y".equalsIgnoreCase(req.getTcViewed()) )
			{
				Logger.debug("@1358:::", this.getClass());
				validatetermsAndCondCookie( mobileSession.getUser().getUserId(),  httpServletRequest,  httpServletResponse);
			}

			mobileSession.getUser().setAttribute(IBankParams.USEROBJ_BRAND,origin );
			
			ibankCommonData.setGdwOrigin(mobileSession.getGDWOrigin());
			
			customer = mobileSession.getCustomer();
			
			//18E4 throw error if the session is DM session
			MBAppHelper.validateMBSessionId(mobileSession.getSessionID());
			
			if ( customer == null )
			{
				customer = getCustomer( ibankCommonData, null);
			}
			
			if(null!=customer)
			{
		 	  ibankCommonData.setCustomer(customer);
			}

//			Splash page update MsgCount
			Logger.debug("Processing splashPageInfo", this.getClass());
			boolean isECorrespondenceSupported = CommonBusinessUtil.isECorrespondenceSupported(httpServletRequest);
			//List<Object> splashPageInfo= processMsgCentre(origin,customer.getGcis(),isECorrespondenceSupported);
			MsgCentreInfo msgCentreInfo=			processMsgCentre(origin,customer.getGcis(),isECorrespondenceSupported);
			List<MessageSearch> splashPageInfo = msgCentreInfo.getSplashPageInfo();
			MessageSearch messageSearch = null;
			if(splashPageInfo != null && !splashPageInfo.isEmpty()){
				unreadMsgCount =msgCentreInfo.getUnreadMessageCount();
				Logger.debug("splashPageInfo - unreadMsgCount: "+unreadMsgCount, this.getClass());
				if(splashPageInfo.size() > 0){
					messageSearch = splashPageInfo.get(0);
					mobileSession.setSplashInfoMsg(messageSearch);
				}
			}
			
			List<AutoApplyRetentionInfo>  digiRetInfoList= 			msgCentreInfo.getApplyRetentionInfo();
			AutoApplyRetentionInfo autoApplyRetentionInfo =null;
			
			
			if(digiRetInfoList!= null && digiRetInfoList.size()>0 ){
				try{
				 autoApplyRetentionInfo = digiRetInfoList.get(0);
			
				 Logger.debug("Auto Apply retention info message seen: "+autoApplyRetentionInfo.getAccountNumber(), this.getClass());
				 
				 mobileSession.setAutoApplyRetentionInfo( autoApplyRetentionInfo); 
				}
				catch(Exception e){
					Logger.warn("LogonUtilController:smplGetCustomer() autoApplyRetentionInfo is null", this.getClass());
				}
			}

			// call service to get ServiceAdminVo
			long insertionPt = logonHelper.getInsertionPointCode(ServicetationConstants.DASHBOARD);
			ServiceStationVO servicestationVO=populateServiceMessage(insertionPt,ServiceStationImpl.CHANNEL_MOBILE, ibankCommonData);		
			if(null!=servicestationVO)
			{
				mobileSession.setServiceStationDashboardMessage(servicestationVO.getServiceStationMsg());
			}
			
			IMBResp serviceResponse = logonHelper.populateResponse(customer, mobileSession.getUser(), unreadMsgCount, httpServletRequest, httpServletResponse, false,servicestationVO,autoApplyRetentionInfo);
			
			//Populate the ghost tile Response
			//20E2-CSH -SBGEXP-8227 - added two conditions to check CSH/Efinance/Homeloan combination
			logonHelper.populateGhostTileResponse(this, mobileSession, ibankCommonData, customer, serviceResponse);
//			Populate the SplashPage Response
			boolean mustChangePwd = mobileSession.getUser().isStatusMustChangePassword();
			Boolean smsRest = (Boolean) mobileSession.getUser().getAttribute(SMS_RESET_STATUS);
			Logger.debug("Before populate splashPageInfo 1430", this.getClass());
			populateSplashPageResponse(httpServletRequest, origin, mobileSession, ibankCommonData, customer, mustChangePwd, smsRest, isECorrespondenceSupported, splashPageInfo, messageSearch, serviceResponse);
			
			String encryptedCookieUserid = logonHelper.getEncryptedUserID(mobileSession.getUser().getUserId());
			logonHelper.addNewTnCCookie(httpServletRequest, httpServletResponse,encryptedCookieUserid,"1.0");
			
			((LogonResp) serviceResponse ).setTermsAcceptanceReqd(false);
			
			//if (!hasSecureCodeConstraints(customer)){
			String safiAction =  mobileSession.getSafiLogonInfo()!= null ?mobileSession.getSafiLogonInfo().getSafiAction():null;
			populateForcePasswordResp(origin, mobileSession, customer, ibankCommonData,	serviceResponse);
									
			mobileSession.setCustomer(customer);
			
			// 17E4 changes for staff assisted rego
			String autoInitStatus=(String)mobileSession.getUser().getAttribute(IBankParams.REG_STATUS);				
			Logger.debug("***AutoInitStatus  smplGetCustomer: " +autoInitStatus, this.getClass());
			Boolean smsRest1 = (Boolean) mobileSession.getUser().getAttribute(LogonHelper.SMS_RESET_STATUS);
			Logger.debug("***AutoInitStatus smsRest1 smplGetCustomer: " +smsRest1, this.getClass());
			
			if(isAutoInitAdmin(autoInitStatus)){
				LogonResp logonResp =  logonHelper.populateAutoInitLogonResp(httpServletRequest, mapper, customer, METHOD_NAME);
				mobileSession.setLoggedonState(LogonHelper.AUTO_INIT_RESET_PWD_SECNUM);
				return logonResp;
			}	
			
			if(!StringMethods.isEmptyString(safiAction) && safiAction.equalsIgnoreCase(SafiConstants.SAFI_ACTION_CHALLENGE) && !hasSecureCodeConstraints(customer)){
				Logger.debug("SAFI : LogonUtilController:smplGetCustomer(): Setting LoggedOnState - SafiChallenge: SafiAction: "+safiAction+" GCISNumber: "+customer.getGcis(), this.getClass());
				logonHelper.populateSafiResponse(serviceResponse, customer);
				mobileSession.setLoggedonState(LogonHelper.LOGGEDON_STATE_SAFI_CHALLENGE);
			}
			
			Logger.info("Simplified Logon /getCustomer JSON Response :" + mapper.writeValueAsString(serviceResponse), this.getClass());
			RespHeader headerResp = populateResponseHeader(ServiceConstants.LOGON_RESPONSE, mobileSession);
			serviceResponse.setHeader(headerResp);
			
			//17E4 : Native Redesign
			Logger.debug("/getCustomer :: smplGetCustomer():: CUST_NAME_REQUESTED ::"+ mobileSession.getCustNameRequested(), this.getClass());
			
			return serviceResponse;

		} catch (BusinessException e)
		{
			Logger.error("Exception Inside processLogon() for Customer 3.  " + e.getKey(), this.getClass());
			if ( e.getKey() == (BusinessException.COOKIES_NOT_FOUND) )
			{
				LogonResp logonResp = new LogonResp();
				logonResp.setTermsAcceptanceReqd(true);
				RespHeader headerResp = populateResponseHeader(ServiceConstants.LOGON_RESPONSE, mobileSession);
				logonResp.setHeader(headerResp);
				return logonResp;
			}
			IMBResp resp1 = MBAppUtils.createErrorResp(origin, e, MBAppConstants.SMPL_LOGON_RESP_NAME, httpServletRequest);
			return resp1;
		} catch (Exception e)
		{
			Logger.error("Exception Inside processLogon() for Customer 4. ", e, this.getClass());
			BusinessException exp = new BusinessException(BusinessException.SMPL_SYS_ERROR);
			IMBResp resp1 = MBAppUtils.createErrorResp(origin, exp, MBAppConstants.SMPL_LOGON_RESP_NAME, httpServletRequest);
			return resp1;
		} finally
		{
			
			perfLogger.endLog(logName);
			perfLogger.endAllLogs();
		}

	}

	private void populateForcePasswordResp(String origin, MobileSession mobileSession, Customer customer,
			IBankCommonData ibankCommonData, IMBResp serviceResponse) throws BusinessException {
		ForceChangePwd forceVO = mobileSession.getForceChangePwd();
		ForceChangePwdService forceService = (ForceChangePwdService)ServiceHelper.getBean(ServiceConstants.FORCE_PWD_CHANGE);
		
		if (forceVO == null){
			forceVO = forceService.getStatus(ibankCommonData);
			mobileSession.setForceChangePwd(forceVO);
		}
		
		String force = forceVO==null?"":forceVO.getStatus();
		Logger.debug("logon getCustomer:: forceChangePwdStatus: " + force, this.getClass());

		String forcePWDStatus = forceService.getStatusFromVO(ibankCommonData, forceVO);
		
		String safiAction =  mobileSession.getSafiLogonInfo()!= null ?mobileSession.getSafiLogonInfo().getSafiAction():null;
		Logger.debug("SAFI : SafiAction: smplGetCustomer: "+safiAction+"GCISNumber: "+ibankCommonData.getCustomer().getGcis(), this.getClass());
		
		if(!StringMethods.isEmptyString(safiAction) && (safiAction.equalsIgnoreCase(SafiConstants.SAFI_ACTION_ALLOW) || safiAction.equalsIgnoreCase(SafiConstants.SAFI_ACTION_REVIEW))){
			 setLoggedStatus(mobileSession, forcePWDStatus, customer);
			((LogonResp) serviceResponse).setForceChangePwdStatus(forcePWDStatus);
			((LogonResp) serviceResponse).setRemSkipCount(forceService.getRemSkipCount(forceVO, forcePWDStatus, origin));
		}
		
	}

	@RequestMapping("/simpleLogon")
	@ResponseBody
	public IMBResp processSavedCAN(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse,
			@RequestBody final LogonReq req)
	{
		Logger.debug("In processLogon ( LogonAction )  for Customer " + req.getAccessNumber() + "  " + httpServletRequest.getContentType() + " "
				+ httpServletRequest.getRemoteAddr() + "  " + httpServletResponse.getCharacterEncoding() + httpServletResponse.getLocale() +
				" True IP >> " + httpServletRequest.getHeader(IBankParams.trueClientIP()), this.getClass());
		final String METHOD_NAME = "processSavedCAN";
		fraudLogger = new FraudLogger();
		perfLogger.startAllLogs();
		String logName = MBAppUtils.getLogName(httpServletRequest);
		perfLogger.startLog(logName);
		UserAgentParser bean = (UserAgentParser) ServiceHelper.getBean(ServiceConstants.USER_AGENT_PARSER);
		ObjectMapper mapper = new ObjectMapper();
		int unreadMsgCount = -1;
		
		String origin = LogonHelper.resolveOrigin(httpServletRequest);
		httpServletRequest.setAttribute(LogonHelper.ORIGIN, origin);
		String gdwOrigin  = logonHelper.getGDWOrigin( req.getHeader(),  origin);
		DigitalSecLogggerVO digitalSecLoggerVO = new DigitalSecLogggerVO();
		IGenericSession genericSession = null;
		IBankCommonData ibankCommonData=null;
		String accNumber=null;
		List populateSplashPageResult = null;
		SafiForensicInfo safiForensicInfo = null;
		String sessId = null;
		Customer customer=null;
		boolean reactivateOnline = false;
		boolean safiChallenge = false;
		try
		{ 

			String userAgent = httpServletRequest.getHeader(USER_AGENT);
			Logger.debug("Simplified Logon origin" + origin + ": User-Agent :" + userAgent, this.getClass());
			ibankCommonData = populateIBankCommonData(null, null, origin, MBAppHelper.resolveIPAddress(httpServletRequest, origin), userAgent);
			CookieLogonBean cookieLogonBean = logonHelper.populateCookieLogonBean(  httpServletRequest );
			AuthenticationData authenticationData = populateAuthenticationData(req, gdwOrigin, MBAppHelper.resolveIPAddress(httpServletRequest, origin));
			authenticationData.setUserId(cookieLogonBean.getAccessNumber());
			authenticationData.setIssueNumber(cookieLogonBean.getIssueNumber());
			accNumber=cookieLogonBean.getAccessNumber();
			Logger.debug("Simplified Logon error can number:>>" + req.getAccessNumber(), this.getClass());
			User user = authenticate(authenticationData, true);
			
			
			if (isUserMustChangePassword(user) ){
				logonHelper.removeEncryptedCANCookie(httpServletRequest, httpServletResponse);
				LogonResp logonResp = new LogonResp();
				logonResp.setChangePwdReqd(true);
				logonResp.setChangePwdAndSecNumReqd(true);
				MobileSession dummySession = null;
				RespHeader headerResp = populateResponseHeader(ServiceConstants.LOGON_RESPONSE, dummySession);
				logonResp.setHeader(headerResp);
				return logonResp;
			}else{
				boolean isOldCookieDelete= logonHelper.updateMBCookie(httpServletRequest, httpServletResponse);
				if(isOldCookieDelete){
					Logger.info(" Simple Logon Existing Old domain Cookie Name:"
							+ LogonHelper.MOBILE_ENCRYTED_COOKIE
							+ ", isOldCookieDelete :" + isOldCookieDelete, this.getClass());
				}
			}


			
			genericSession = logonHelper.createCompassSession(user, origin, MBAppConstants.WEB_SRV, httpServletRequest);
			sessId = genericSession.getId();
			
			Logger.debug("Reactivate: reactivateOnline " + reactivateOnline+" CAN : "+user.getUserId()+" Logon Type "+user.getAttribute( IBankParams.LOGON_TYPE), this.getClass());
			//20E4 - COVID19 OTP - on three unsuccessful login attempts user is allowed to login using OTP - Begin
			if ( user != null && user.getAttribute(IBankParams.LOGON_TYPE) != null &&  IBankParams.LogonTypeEnum.OTP == user.getAttribute( IBankParams.LOGON_TYPE)  )
			{
				reactivateOnline = true;
				Logger.info("Reactivate:  reactivateOnline " + reactivateOnline+" CAN : "+user.getUserId(), this.getClass());
			}
			//20E4 - COVID19 OTP - on three unsuccessful login attempts user is allowed to login using OTP - End

			
			perfLogger.setPrefix("GCIS:" + user.getGCISNumber() + ";SESSIONID:" + sessId + ";BRAND:" + origin +";");
			Logger.info("***User-Agent: " + userAgent.toLowerCase() + "***SessionId: " + sessId, this.getClass());
			httpServletResponse.setHeader("Set-Cookie", MBAppConstants.SMPL_SESS_CONSTANT + "=" + genericSession.getId()   + "; Secure; HttpOnly; path=/" );
			//httpServletResponse.setHeader("Set-Cookie", MBAppConstants.SMPL_SESS_CONSTANT + "=" + sessId   + "; HttpOnly ; path=/   " ); 
			
			authenticationData.setSessionId(sessId);
			
			ibankCommonData = populateIBankCommonData(sessId, user, origin, MBAppHelper.resolveIPAddress(httpServletRequest,origin), userAgent, gdwOrigin);
			
			//18E4 thow error if the session is DM session
			MBAppHelper.validateMBSessionId(sessId);
			
			if(reactivateOnline) { //20E4 - COVID19 OTP login
				ReactivateOnlineService reactivateOnlineService = (ReactivateOnlineService)ServiceHelper.getBean("reactivateOnlineService");
				customer = reactivateOnlineService.getCustomerDetails(user, authenticationData.getOrigin());
				genericSession.setAttribute(MobileSessionImpl.SESSION_LOCK,ReactivateOnlineService.SESSION_REACTIVATE);
				Logger.info("Reactivate : Got Customer. CAN : "+user.getUserId(), this.getClass());
			} else { //Normal flow
				customer = getCustomer(ibankCommonData, Statistic.LOGON_MB_ONLY_PASSWORD);
			}
			ibankCommonData.setCustomer(customer);
			user.setAttribute(IBankParams.USEROBJ_BRAND,origin );
			setCustomerAndOriginInSession(origin, genericSession, customer, gdwOrigin);
			
			/*Safi changes for remember me*/
			String safiAction = null;
			if(reactivateOnline) { 
				//20E4 - COVID19 OTP - SAFI analyse call
				safiAction = processReactivateRequest(httpServletRequest, genericSession, req, ibankCommonData, genericSession);
				Logger.info("Reactivate: SAFI call done. CAN : "+user.getUserId()+" Safi response action "+safiAction, this.getClass());
				if(!StringMethods.isEmptyString(safiAction) && SafiConstants.SAFI_ACTION_CHALLENGE.equalsIgnoreCase(safiAction)) {
					safiChallenge = true;
				}
			} else { //Normal logon SAFI flow
				setSecurityLogs(httpServletRequest, authenticationData, genericSession, user, req.isSaveCan());
				safiAction =  safiCallWithPRMAndDiggitalLogger(httpServletRequest, httpServletResponse, req, METHOD_NAME, gdwOrigin, authenticationData, digitalSecLoggerVO, genericSession, user, ibankCommonData, customer, sessId);
			}


			ForceChangePwdService forceService = ServiceHelper.getBean(ServiceConstants.FORCE_PWD_CHANGE);
			ForceChangePwd forceVO = forceService.getStatus(ibankCommonData);
			genericSession.setForceChangePwd(forceVO);
			String forceStatus = forceService.getStatusFromVO(ibankCommonData, forceVO);
			setLoggedStatus(genericSession, forceStatus, customer);
			
		
			
//			appHelper.makeStatisticsLog(authenticationData, user, httpServletRequest);
			
			Logger.debug("Processing splashPageInfo", this.getClass());
			boolean isECorrespondenceSupported = CommonBusinessUtil.isECorrespondenceSupported(httpServletRequest);
			MsgCentreInfo messageCentreInfo=processMsgCentre(origin,customer.getGcis(),isECorrespondenceSupported);
			List<MessageSearch> splashPageInfo = messageCentreInfo.getSplashPageInfo();
			
			List<AutoApplyRetentionInfo> digiRetInfoList = messageCentreInfo.getApplyRetentionInfo();
			
			MessageSearch messageSearch = null;
			if(splashPageInfo != null && !splashPageInfo.isEmpty()){
				unreadMsgCount = messageCentreInfo.getUnreadMessageCount();
				Logger.debug("splashPageInfo - unreadMsgCount: "+unreadMsgCount, this.getClass());
				if(splashPageInfo.size() > 0) {
					messageSearch = (MessageSearch)splashPageInfo.get(0);
					genericSession.setAttribute(MobileSessionImpl.SPLASH_MESSAGE_INFO, messageSearch);
				}
			}
			AutoApplyRetentionInfo autoApplyRetentionInfo =null;
			if(digiRetInfoList!=null && digiRetInfoList.size()>0  ){
				try{
				 autoApplyRetentionInfo = digiRetInfoList.get(0);
				 genericSession.setAttribute(MobileSessionImpl.AUTO_APPLY_RETENTION_SESSION, autoApplyRetentionInfo);
				}
				catch(Exception e){
					Logger.warn("LogonUtilController:processSavedCAN() autoApplyRetentionInfo is null", this.getClass());
				}
			}
			
			
			
			
			// call service to get ServiceAdminVo
			long insertionPt = logonHelper.getInsertionPointCode(ServicetationConstants.DASHBOARD);
			ServiceStationVO servicestationVO=populateServiceMessage(insertionPt,ServiceStationImpl.CHANNEL_MOBILE, ibankCommonData);
			if(null!=servicestationVO)
			{
				genericSession.setAttribute(MobileSessionImpl.SERVICE_STATION_DASHBOARD_MESSAGE, servicestationVO.getServiceStationMsg());
			}
			
			boolean isOldCookieDelete=logonHelper.deleteOldCookies(httpServletRequest,httpServletResponse,LogonHelper.MOBILE_TNC_COOKIE);
			if(isOldCookieDelete){
				Logger.info(" Existing Old domain Cookie Name:"
						+ LogonHelper.MOBILE_TNC_COOKIE
						+ ", isOldCookieDelete :" + isOldCookieDelete, this.getClass());
			}
			else{
				Logger.debug("Existing Old domain Cookie Name: "
						+ LogonHelper.MOBILE_TNC_COOKIE
						+ "isOldCookieDelete :" + isOldCookieDelete, this.getClass());
			}
			IMBResp serviceResponse = logonHelper.populateResponse(customer, user, unreadMsgCount, httpServletRequest, httpServletResponse, false,servicestationVO,autoApplyRetentionInfo);
			
			
			//20E4 - COVID 19 OTP - reactivate online - Begin
			if(reactivateOnline) {
				if(safiChallenge) {
					((LogonResp) serviceResponse).setContactInfo(logonHelper.populateContact(customer.getContactDetail()));
					((LogonResp) serviceResponse).setSecureCodeInfo(logonHelper.populateSecureCodeInfo(customer));
					((LogonResp) serviceResponse).setReactivateOnline(true);
					((LogonResp) serviceResponse).setShowSafiChallenge(true);
					((LogonResp) serviceResponse).setCustomer(null);
					genericSession.setLoggedonState(LogonHelper.LOGGEDON_STATE_SAFI_CHALLENGE);
					Logger.info("Reactivate : Forwarding to 2FA screen. CAN : "+user.getUserId(), this.getClass());
				} else {
					//TODO TBC show error 
					Logger.warn("Inside processLogon() - safiChallenge is FALSE for COVID19 OTP Reactivate Online Flow, returning an error.", this.getClass());
					BusinessException exp = new BusinessException(BusinessException.SMPL_SYS_ERROR);
					IMBResp resp1 = MBAppUtils.createErrorResp(origin, exp, MBAppConstants.SMPL_LOGON_RESP_NAME, httpServletRequest);
					return resp1;
				}
			}  //20E4 - COVID 19 OTP - reactivate online - End
			else { //Normal logon flow
				if(StringMethods.isValidString(safiAction) && SafiConstants.SAFI_ACTION_CHALLENGE.equalsIgnoreCase(safiAction) && (!hasSecureCodeConstraints(customer))){
					Logger.debug("SAFI : LogonUtilController:processSavedCAN: Setting LoggedOnState - SafiChallenge: SafiAction: "+safiAction+" GCISNumber: "+customer.getGcis(), this.getClass());
					((LogonResp) serviceResponse).setCustomer(null);
					((LogonResp) serviceResponse).setShowSafiChallenge(true);
					((LogonResp) serviceResponse).setContactInfo(logonHelper.populateContact(customer.getContactDetail()));
					((LogonResp) serviceResponse).setSecureCodeInfo(logonHelper.populateSecureCodeInfo(customer));
					genericSession.setLoggedonState(LogonHelper.LOGGEDON_STATE_SAFI_CHALLENGE);
				}else{
					//Populate the ghost tile Response
					//20E2-CSH -SBGEXP-8227 - added two conditions to check CSH/Efinance/Homeloan combination
					
					logonHelper.populateGhostTile(this, genericSession, ibankCommonData, customer, serviceResponse);
				}
			}

			
			MobileSession mobileSession = new MobileSessionImpl();
			mobileSession.setSession(genericSession);
//			Populate the SplashPage Response
			Logger.debug("Before populate splashPageInfo", this.getClass());
			boolean mustChangePwd = mobileSession.getUser().isStatusMustChangePassword();
			Boolean smsRest = (Boolean) mobileSession.getUser().getAttribute(SMS_RESET_STATUS);
			populateSplashPageResponse(httpServletRequest, gdwOrigin, mobileSession, ibankCommonData, customer, mustChangePwd, smsRest, isECorrespondenceSupported, splashPageInfo, messageSearch, serviceResponse);
			//if (!hasSecureCodeConstraints(customer)){
				Logger.debug("forceChangePwd gcis: " + customer.getGcis() + " status = " + forceStatus, LogonUtilController.class);
				((LogonResp) serviceResponse).setForceChangePwdStatus(forceStatus);
				((LogonResp) serviceResponse).setRemSkipCount(forceService.getRemSkipCount(forceVO, forceStatus, origin));
			//}
			
//			genericSession.updateSession();
			logDigitalLoggerLogonSuccess(req, digitalSecLoggerVO, ibankCommonData);
			
			if(!StringMethods.isEmptyString(safiAction) && safiAction.equalsIgnoreCase(SafiConstants.SAFI_ACTION_DENY)){
				throw new BusinessException(BusinessException.SAFI_LOGON_DENY_ERROR);
			}
			
			mbAppHelper.addTrackingIdCookie(customer.getPreference().getTrackingId(), IBankParams.getBaseOriginCode(ibankCommonData.getOrigin()), httpServletRequest, httpServletResponse);
			MBAppHelper.addWebAnalyticsCookis(IBankParams.getBaseOriginCode(ibankCommonData.getOrigin()), httpServletRequest, httpServletResponse);

			Logger.info("Simplified Logon /simpleLogon JSON Response :" + mapper.writeValueAsString(serviceResponse), this.getClass());
			MobileSession dummySession = null;
			RespHeader headerResp = populateResponseHeader(ServiceConstants.LOGON_RESPONSE, dummySession);
			
			setSecurityUniqueId(genericSession, headerResp);
			
			serviceResponse.setHeader(headerResp);
//			validateDifferentCookie(httpServletRequest, httpServletResponse, req, user);
			
			return serviceResponse;

		} catch (BusinessException e)
		{
			Logger.info("Exception Inside processLogon() for Customer 5. " + e.getKey() + "#", this.getClass());
			if ( e.getKey() == (BusinessException.COOKIES_NOT_FOUND) )
			{
				LogonResp logonResp = new LogonResp();
				logonResp.setTermsAcceptanceReqd(true);
				MobileSession dummySession = null;
				RespHeader headerResp = populateResponseHeader(ServiceConstants.LOGON_RESPONSE, dummySession);
				logonResp.setHeader(headerResp);
				
				//20E4 - COVID 19 OTP - reactivate online - Begin
				if(reactivateOnline) {
					if(safiChallenge) {
						logonResp.setContactInfo(logonHelper.populateContact(customer.getContactDetail()));
						logonResp.setSecureCodeInfo(logonHelper.populateSecureCodeInfo(customer));
						logonResp.setReactivateOnline(true);
						logonResp.setShowSafiChallenge(true);
						logonResp.setCustomer(null);
						genericSession.setLoggedonState(LogonHelper.LOGGEDON_STATE_SAFI_CHALLENGE);
					} else {
						//TODO TBC show error 
						Logger.warn("Inside processLogon() - safiChallenge is FALSE for COVID19 OTP Reactivate Online Flow, returning an error.", this.getClass());
						BusinessException exp = new BusinessException(BusinessException.SMPL_SYS_ERROR);
						IMBResp resp1 = MBAppUtils.createErrorResp(origin, exp, MBAppConstants.SMPL_LOGON_RESP_NAME, httpServletRequest);
						return resp1;
					}
				}  //20E4 - COVID 19 OTP - reactivate online - End

				return logonResp;
			}else if(e.getKey()==BusinessException.SAFI_LOGON_DENY_ERROR){
				
				digitalSecLoggerVO.setStatus(DigitalSecLogger.SAFI_DENY_STATUS);
				digitalSecLoggerVO.setTranName(DigitalSecLogger.SAFI_APP_LOGON);
				digitalSecLoggerVO.setValues(logonHelper.toDigitalSecuritySafiLog(safiForensicInfo));
				digitalSecLoggerVO.setCommonLogData(logonHelper.getCommonLogData(req,ibankCommonData,accNumber));
				digitalSecLoggerVO.setUserAgent(ibankCommonData.getUserAgent());
				digitalSecurityLogger.log(digitalSecLoggerVO);
				
				OriginsVO myOriginVO = IBankParams.getOrigin(origin);
			    OriginsVO baseOrigin = IBankParams.getOrigin(myOriginVO.getBankName());
			    String[] values = { baseOrigin.getBpayPhone() };
			    IMBResp resp1 = MBAppUtils.createErrorResp(origin, e,values, MBAppConstants.SMPL_LOGON_RESP_NAME, httpServletRequest);
				return resp1;
			}else if(e.getKey()==BusinessException.IBANK_SECURE_NO_PHONE_EXIST){
				
				digitalSecLoggerVO.setStatus(DigitalSecLogger.SAFI_CHALLENGE_STATUS);
				digitalSecLoggerVO.setTranName(DigitalSecLogger.SAFI_APP_LOGON);
				digitalSecLoggerVO.setValues(logonHelper.toDigitalSecuritySafiLog(safiForensicInfo));
				digitalSecLoggerVO.setCommonLogData(logonHelper.getCommonLogData(req,ibankCommonData,accNumber));
				digitalSecLoggerVO.setUserAgent(ibankCommonData.getUserAgent());
				digitalSecurityLogger.log(digitalSecLoggerVO);
				
				IMBResp resp1 = MBAppUtils.createErrorResp(origin, e, MBAppConstants.SMPL_LOGON_RESP_NAME, httpServletRequest);
				return resp1;
			}//19E4 Tech Debt Start:Switch Removal
			else if(/*IBankParams.isPasswordReset19E1SwitchON() && */e.getKey()==BusinessException.ACCOUNT_LOCKED){
				BusinessException exp = new BusinessException(BusinessException.USER_LOCKED_RESET_PASSWORD);
				IMBResp resp1 = MBAppUtils.createErrorResp(origin, exp, MBAppConstants.SMPL_LOGON_RESP_NAME, httpServletRequest);
				return resp1;
			}
			digitalSecLoggerVO.setStatus(DigitalSecLogger.FAILURE);
			digitalSecLoggerVO.setTranName(DigitalSecLogger.APP_LOGON);
			digitalSecLoggerVO.setValues(logonHelper.toDigitalSecurityLog(req,""));
			digitalSecLoggerVO.setCommonLogData(logonHelper.getCommonLogData(req,ibankCommonData,accNumber));
			digitalSecLoggerVO.setUserAgent(ibankCommonData.getUserAgent());
			digitalSecurityLogger.log(digitalSecLoggerVO);
			IMBResp resp1 = MBAppUtils.createErrorResp(origin, e, MBAppConstants.SMPL_LOGON_RESP_NAME, httpServletRequest);
			return resp1;
		} catch (Exception e)
		{
			Logger.error("Exception Inside processLogon() for Customer 6. ", e, this.getClass());
			BusinessException exp = new BusinessException(BusinessException.SMPL_SYS_ERROR);
			IMBResp resp1 = MBAppUtils.createErrorResp(origin, exp, MBAppConstants.SMPL_LOGON_RESP_NAME, httpServletRequest);
			return resp1;
		} finally
		{
			
			if ( reactivateOnline &&  safiChallenge &&  genericSession != null  )
			{
				genericSession.updateSession();
				MBAppLogger.logUserAgent(httpServletRequest, genericSession.getUser().getGCISNumber(), sessId, origin);	
				Logger.warn("Updating session for Reactivate.  ", this.getClass());
			}
			else if ( ! reactivateOnline &&  genericSession != null ){
				genericSession.updateSession();
				MBAppLogger.logUserAgent(httpServletRequest, genericSession.getUser().getGCISNumber(), sessId, origin);
			}

			perfLogger.endLog(logName);
			perfLogger.endAllLogs();
		}

	}
	
	@RequestMapping("/getLiteCustomer")
	@ResponseBody
	public IMBResp getCustomerLite(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, @RequestBody final LogonReq req)
	{
		System.out.println("In getLiteCustomer LogonUtilController START");
		final String METHOD_NAME = "getCustomerLite" ;
        Logger.debug("In getLiteCustomer ( LogonAction )  for Customer " + req.getAccessNumber() + "  " + httpServletRequest.getContentType() + " "+ httpServletRequest.getRemoteAddr() + "  " + httpServletResponse.getCharacterEncoding() + httpServletResponse.getLocale() + " True IP >> " + httpServletRequest.getHeader(IBankParams.trueClientIP()) , this.getClass());
        fraudLogger = new FraudLogger();
        perfLogger.startAllLogs();
        String logName = MBAppUtils.getLogName(httpServletRequest);
        perfLogger.startLog(logName);
        String origin = null;
        IGenericSession genericSession = null ;

        String gdwOrigin  = logonHelper.getGDWOrigin( req.getHeader(),  origin);
        Logger.debug("LogonUtilController - getLiteCustomer : gdwOrigin :"+gdwOrigin, this.getClass());
              
		try {
			User user = null;
			origin = checkDemoSecurityKey(httpServletRequest, req,METHOD_NAME);
			httpServletRequest.setAttribute(LogonHelper.ORIGIN, origin);
			
			MobileSession mbSession = mbAppHelper.getMobileSession(httpServletRequest);

			setStateInMobileSession(mbSession, METHOD_NAME);

			String userAgent = httpServletRequest.getHeader(USER_AGENT);
			Logger.debug("LogonUtilController - getLiteCustomer - Logon origin : " + origin + " : User-Agent :" + userAgent,
					this.getClass());

			String ipAddress = MBAppHelper.resolveIPAddress(httpServletRequest, origin);

			String sessionId = null;
			
			AuthenticationData authenticationData = new AuthenticationData();
			
			sessionId = getSessionIdFromCompassCookie(httpServletRequest, sessionId);

 			if (null != sessionId) {
				genericSession = logonHelper.createCompassSession(httpServletRequest, sessionId, true);

				setSessionAttributes(origin, genericSession);

				user = setUserOrigin(origin, genericSession);

			} else {
				authenticationData = populateAuthenticationData(req, gdwOrigin,
						ipAddress);
				authenticationData.setCompassChannel(COMPASS_CHANNEL);
				user = authenticate(authenticationData, false);


				if ( user != null && user.getAttribute(IBankParams.LOGON_TYPE) != null &&  IBankParams.LogonTypeEnum.OTP == user.getAttribute( IBankParams.LOGON_TYPE)  )
				{
					Logger.debug( " CAN : "+user.getUserId()+" Logon Type "+user.getAttribute( IBankParams.LOGON_TYPE), this.getClass());
					throw new BusinessException(BusinessException.INVALID_USERID_PASSWORD);
				}

				genericSession = logonHelper.createCompassSession(user, origin, MBAppConstants.WEB_SRV,
						httpServletRequest);

			}

			perfLogger.setPrefix(
					"GCIS:" + user.getGCISNumber() + ";SESSIONID:" + genericSession.getId() + ";BRAND:" + origin + ";");
			Logger.info("***User-Agent: " + userAgent.toLowerCase() + "***SessionId: " + genericSession.getId(),
					this.getClass());
			String sesId = genericSession.getId();
			IBankCommonData ibankCommonData = populateIBankCommonData(sesId, user, origin, ipAddress , userAgent , gdwOrigin);

			Customer customer = getCustomerLite(ibankCommonData, genericSession);

			setCustomerAndOriginInSession(origin, genericSession, customer, gdwOrigin);

			setSecurityLogs(httpServletRequest, authenticationData, genericSession, user, false);

			mbAppHelper.addTrackingIdAndWebAnalyticCookie(httpServletRequest, httpServletResponse, ibankCommonData,
					customer);

			validateDifferentCookie(httpServletRequest, httpServletResponse, req, user, null);
			IMBResp serviceResponse = populateCustomerLiterResponse(httpServletRequest, httpServletResponse,
					genericSession, user, customer);

			return serviceResponse;

		}catch (Exception e)
        {
              Logger.warn("Exception Inside processLogon() for Customer 2.  ", e, this.getClass());
              BusinessException exp = new BusinessException(BusinessException.SMPL_SYS_ERROR);
              IMBResp resp1 = MBAppUtils.createErrorResp(origin, exp, MBAppConstants.SMPL_LOGON_RESP_NAME, httpServletRequest);
              return resp1;
        } finally
        {
              
              if ( genericSession != null ){
                    genericSession.updateSession(true);
                    MBAppLogger.logUserAgent(httpServletRequest, genericSession.getUser().getGCISNumber(), genericSession.getId(), origin);      
              }
              perfLogger.endLog(logName);
              perfLogger.endAllLogs();
        }

	}
	
	@RequestMapping("/loadCustomer")
	@ResponseBody
	public IMBResp loadCustomer(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, @RequestBody final LogonReq req)
	{
		System.out.println("In loadCustomer LogonUtilController START");
        Logger.debug("In loadCustomer ( LogonAction )  for Customer " + req.getAccessNumber() + "  " + httpServletRequest.getContentType() + " "+ httpServletRequest.getRemoteAddr() + "  " + httpServletResponse.getCharacterEncoding() + httpServletResponse.getLocale() + " True IP >> " + httpServletRequest.getHeader(IBankParams.trueClientIP()) , this.getClass());
        final String MEHTOD_NAME = "loadCustomer";
        fraudLogger = new FraudLogger();
        perfLogger.startAllLogs();        
        String logName = MBAppUtils.getLogName(httpServletRequest);
        perfLogger.startLog(logName);
        
        String origin = null;
        ObjectMapper mapper = new ObjectMapper();
        int unreadMsgCount = -1;
        User user = null;
        
        MobileSession mobileSession = null;
       
        boolean isDemo = LogonHelper.isDemo();
        origin = LogonHelper.getOrigin(httpServletRequest, isDemo, MEHTOD_NAME);
        
        httpServletRequest.setAttribute(LogonHelper.ORIGIN, origin);

        String gdwOrigin  = logonHelper.getGDWOrigin( req.getHeader(),  origin);
        Logger.debug("LogonUtilController - loadCustomer : gdwOrigin :"+gdwOrigin, this.getClass());
              
        try { 
			mobileSession = mbAppHelper.getMobileSession(httpServletRequest);
			
			user = mobileSession.getUser();
			String userAgent = httpServletRequest.getHeader(USER_AGENT);
			
			MBAppLogger.logUserAgent(httpServletRequest, mobileSession);
			MBAppLogger.logAppVersionCookie(httpServletRequest, mobileSession);
			
			mobileSession.getUser().setAttribute(IBankParams.USEROBJ_BRAND, origin);
			// Populating IBankCommonData
			IBankCommonData ibankCommonData = populateIBankCommonData(mobileSession.getSessionID(), user, origin, MBAppHelper.resolveIPAddress(httpServletRequest, origin), userAgent, gdwOrigin);
			Customer customer = getCustomer(mobileSession, ibankCommonData);
			
			mobileSession.setCustomer(customer);
			mobileSession.setOrigin(origin);
			
			//19E3 Warranty Fix - Defect # 2792 - Adding Ghosttile one back is clicked from ProductsPages -Start
			// call service to get ServiceAdminVo
			IMBResp serviceResponse = populateServiceStationDetailsInResponse(httpServletRequest, httpServletResponse,
					unreadMsgCount, user, mobileSession, ibankCommonData, customer);
			
			//Populate the ghost tile Response
			//20E2-CSH -SBGEXP-8227 - added two conditions to check CSH/Efinance/Homeloan combination			
			logonHelper.populateGhostTileResponse(this, mobileSession, ibankCommonData, customer, serviceResponse);
			//19E3 Warranty Fix - Defect # 2792 - Adding Ghosttile one back is clicked from ProductsPages -End				
            
			// 20E1 : Data masking for CRN : Start
			String serviceResponseForMasking = mapper.writeValueAsString(serviceResponse);
			String serviceResponseAfterMasking = maskValue(serviceResponseForMasking);
			
			Logger.info("loadCustomer JSON Response : " + serviceResponseAfterMasking, this.getClass());
			// 20E1 : Data masking for CRN : End
			MobileSession dummySession = null;
	        RespHeader headerResp = populateResponseHeader(ServiceConstants.LOGON_RESPONSE, dummySession);
	        setSecurityUniqueId(mbAppHelper, mobileSession, headerResp);			
			
	        //20E4 Live Person Chat
	        Logger.debug("lpMessagingSwitch " + httpServletRequest.getAttribute( MainController.LP_MESSAGING_SWITCH) , this.getClass());
	        String lpMessagingSwitch = "OFF";
			CodesVO codesVO = IBankParams.getCodesData(IBankParams.getBaseOriginCode(origin),	IBankParams.CONFIGURATION_PROPERTIES, IBankParams.LP_MESSAGING_SWITCH);
			if ( (codesVO == null) || codesVO != null  && "ON".equalsIgnoreCase(codesVO.getMessage())){
				lpMessagingSwitch = "ON";
			}
			httpServletRequest.setAttribute(MainController.LP_MESSAGING_SWITCH, lpMessagingSwitch);	
			Cookie appVersionCookie = CommonBusinessUtil.getCookie(httpServletRequest, IBankParams.APP_VER_COOKIE);
			Boolean isLpOldAppVersion = !CommonBusinessUtil.cookieContainsValue(appVersionCookie, MainController.CHAT);
			if(isLpOldAppVersion) {
				httpServletRequest.setAttribute(MainController.LP_NATIVE_OLD_APP_SWITCH, IBankParams.ON);
			}else {
				httpServletRequest.setAttribute(MainController.LP_NATIVE_OLD_APP_SWITCH, IBankParams.OFF);
			}
			
	        serviceResponse.setHeader(headerResp);                

	        return serviceResponse;
        } catch (Exception e) {
        	Logger.warn("Exception Inside loadCustomer().  ", e, this.getClass());
        	BusinessException exp = new BusinessException(BusinessException.SMPL_SYS_ERROR);
        	IMBResp resp1 = MBAppUtils.createErrorResp(origin, exp, MBAppConstants.SMPL_LOGON_RESP_NAME, httpServletRequest);
        	return resp1;
        } finally {
        	perfLogger.endLog(logName);
        	perfLogger.endAllLogs();
        }
	}

	private String safiCallWithPRMAndDiggitalLogger(HttpServletRequest httpServletRequest,
			HttpServletResponse httpServletResponse, final LogonReq req, final String METHOD_NAME, String origin,
			AuthenticationData authenticationData, DigitalSecLogggerVO digitalSecLoggerVO,
			IGenericSession genericSession, User user, IBankCommonData ibankCommonData, Customer customer,
			String sessId) throws BusinessException {
		String safiAction = null;
		
		
		
		boolean isSafiServiceAvailable = isSafiLogonServiceAvailable(origin, METHOD_NAME);
		SafiPrmInfo safiPrmVo = null;	
		String devicePrint = null;
		String validDecodedPrint = null;
		if (isSafiServiceAvailable) {

			boolean isThrottleAllowed = memoryThrottlingService.processThrottling(IBankParams.THROTTLE_CAT_LOGON,
					genericSession.getUser().getGCISNumber(), sessId);
			SafiForensicInfo safiForensicInfo = null;
			
			if (isThrottleAllowed) {

				// SBGEXP-3465 :: New Throttle Service for Logon
				Logger.debug("SAFI : LogonUtilController." + METHOD_NAME + ":: Throttle Allowed", this.getClass());

				/* 18E3 : Safi changes */
				Logger.debug("SAFI : LogonUtilController." + METHOD_NAME + ": Device Print Received in Logon Request: "
						+ req.getDevicePrint(), this.getClass());
				validDecodedPrint = SafiUtil.validateDevicePrint(req.getDevicePrint());
				devicePrint = validDecodedPrint != null ? req.getDevicePrint() : null;
				SafiVO safiVO = new SafiVO();
				SafiWebHelper.populateSafiVO(httpServletRequest, devicePrint, ibankCommonData, false, safiVO,
						SafiConstants.DEFAULT_TIME_LAST2FA_SUCCESS);

				if(req.isSaveCan())
					safiVO.setAuthType(SafiConstants.SIMPLIFIED_AUTH);
				else
					safiVO.setAuthType(SafiConstants.FULL_AUTH);

				SafiRespVO safiRespVO = safi2Service.analyzeSafiForLogon(ibankCommonData, safiVO);
				
				if (null != safiRespVO) {
					safiAction = safiRespVO.getSafiAction();
					SafiLogonInfo safiLogonInfo = new SafiLogonInfo();
					safiLogonInfo.setSafiAction(safiAction);
					genericSession.setAttribute(MobileSessionImpl.SAFI_LOGON_INFO, safiLogonInfo);
					Logger.debug("SAFI : LogonUtilController." + METHOD_NAME + ": SafiAction: " + safiAction
							+ " GCISNumber: " + customer.getGcis(), this.getClass());
					boolean hasSecureCodeConstraints = hasSecureCodeConstraints(customer);

					if (!StringMethods.isEmptyString(safiAction)&& safiAction.equalsIgnoreCase(SafiConstants.SAFI_ACTION_CHALLENGE)	&& hasSecureCodeConstraints) {
						Logger.warn("SAFI : LogonUtilController." + METHOD_NAME + ": SafiAction : " + safiAction + "hasSecureCodeConstraints: " + hasSecureCodeConstraints, this.getClass());
					}
					
					Cookie pmdata2 = SafiWebHelper.readCookies(httpServletRequest);
					Logger.debug("SAFI : LogonUtilController." + METHOD_NAME + ": PMDATA2 cookie received : " + pmdata2,this.getClass());
					// create or update cookie and save
					Cookie newCookie = SafiWebHelper.createOrUpdatePmdata2Cookie(httpServletRequest, pmdata2,
							safiRespVO.getDeviceToken());
					Logger.debug("SAFI : LogonUtilController." + METHOD_NAME + ": Setting PMDATA2 cookie in resp : "
							+ newCookie.getValue(), this.getClass());
					httpServletResponse.addCookie(newCookie);

					if (SafiConstants.SAFI_ACTION_CHALLENGE.equalsIgnoreCase(safiAction) && !hasSecureCodeConstraints(customer)) {

						boolean phoneNumAvailable = SafiWebHelper.isPhoneNumberAvailable(customer.getContactDetail());
						if (!phoneNumAvailable) {
							Logger.warn("SAFI : LogonUtilController:" + METHOD_NAME	+ ": Phone Number not available....Exception" + "GCISNumber: "+ customer.getGcis(), this.getClass());
							throw new BusinessException(BusinessException.IBANK_SECURE_NO_PHONE_EXIST);
						}
						safiLogonInfo = setSafiLogonInfo(safiRespVO, safiAction, devicePrint);

						genericSession.setAttribute(MobileSessionImpl.SAFI_LOGON_INFO, safiLogonInfo);
					}

					// 18E4 : Safi - for forensic logs
					Logger.debug("SAFI : Populating Safi forensic info", this.getClass());
					safiForensicInfo = setSafiForensicLogInfo(safiRespVO, safiAction);

				}

				/* Safi PRM changes */
				SafiRsaDevicePrintInfo safiRsaDevicePrintVo = SafiUtil.populateSafiRsaDevicePrintVo(validDecodedPrint);
				safiPrmVo = SafiUtil.populateSafiPrmVO(safiRespVO, safiRsaDevicePrintVo, null, null);

				if (null != safiPrmVo && StringMethods.isEmptyString(devicePrint)) {
					safiPrmVo.setIsValidRsaDevicePrint(Boolean.FALSE);
				}

			}
			//18E4 : Safi forensic logging
			initializeLogonDigitalLogger(req, digitalSecLoggerVO, safiForensicInfo, ibankCommonData,DigitalSecLogger.SAFI_APP_LOGON);
			logSafiDigitalLoggerSafiLogonSuccess(digitalSecLoggerVO,  safiAction);

		}
		/*18E3 : Safi changes*/	
		
		
		Logger.debug("Sending PRM information", this.getClass());
		sendLogonPRMMessage(authenticationData, ibankCommonData, user, IBankParams.PRM_LOGON_SUCCESS, safiPrmVo);
		return safiAction;
	}

	private void logSafiDigitalLoggerSafiLogonSuccess( DigitalSecLogggerVO digitalSecLoggerVO, String safiAction) {
		if(StringMethods.isValidString(safiAction) && !(SafiConstants.SAFI_ACTION_CHALLENGE.equalsIgnoreCase(safiAction) ||SafiConstants.SAFI_ACTION_DENY.equalsIgnoreCase(safiAction)  )){
			Logger.debug("SAFI : Populating Safi forensic info", this.getClass());	
		    digitalSecLoggerVO.setStatus(DigitalSecLogger.SUCCESS);
			digitalSecurityLogger.log(digitalSecLoggerVO); 
		
		}
	}

	private void initializeLogonDigitalLogger(final LogonReq req, DigitalSecLogggerVO digitalSecLoggerVO,
			SafiForensicInfo safiForensicInfo, IBankCommonData ibankCommonData, final String tranName) {
		digitalSecLoggerVO.setTranName(tranName);
		if(null == safiForensicInfo) {
			digitalSecLoggerVO.setValues(logonHelper.toDigitalSecurityLog(req,""));
		} else {
			digitalSecLoggerVO.setValues(logonHelper.toDigitalSecuritySafiLog(safiForensicInfo));
		}
		digitalSecLoggerVO.setCommonLogData(logonHelper.getCommonLogData(req,ibankCommonData,null));
		digitalSecLoggerVO.setUserAgent(ibankCommonData.getUserAgent());
	}

	private SafiForensicInfo setSafiForensicLogInfo(SafiRespVO safiRespVO, String safiAction) {
		SafiForensicInfo safiForensicInfo;
		safiForensicInfo = new SafiForensicInfo();
		safiForensicInfo.setSafiRiskScore(
				safiRespVO.getSafiRiskScore() != null ? safiRespVO.getSafiRiskScore().toString()
						: null);
		safiForensicInfo.setSafiRuleName(safiRespVO.getSafiRuleName());
		safiForensicInfo.setSafiAction(safiAction);
		return safiForensicInfo;
	}

	private SafiLogonInfo setSafiLogonInfo(SafiRespVO safiRespVO, String safiAction, String devicePrint) {
		SafiLogonInfo safiLogonInfo;
		safiLogonInfo = new SafiLogonInfo();
		safiLogonInfo.setSafiAction(safiAction);
		safiLogonInfo.setDevicePrint(devicePrint);
		safiLogonInfo.setDeviceToken(safiRespVO.getDeviceToken());
		safiLogonInfo.setSafiChallengeEventRefId(safiRespVO.getSafiChallengeEventRefId());
		safiLogonInfo.setSafiSessionId(safiRespVO.getSafiSessionId());

		// 18E4 : Safi forensic logging
		safiLogonInfo.setSafiRuleName(safiRespVO.getSafiRuleName());
		safiLogonInfo.setSafiRiskScore(
				safiRespVO.getSafiRiskScore() != null ? safiRespVO.getSafiRiskScore().toString()
						: null);
		return safiLogonInfo;
	}

	private boolean isSafiLogonServiceAvailable(String origin, final String callingMethodName) {
		String baseOrigin = IBankParams.getBaseOriginCode(origin);
		boolean isSafiLogonSwitchOn = IBankParams.isSwitchOn(baseOrigin,IBankParams.SAFI_LOGON_SWITCH);
		Logger.debug("SAFI : LogonUtilController. " + callingMethodName + ":: Safi Logon Switch Val: "+isSafiLogonSwitchOn, this.getClass());
		boolean isSafiServiceAvailable = false;
		
		if(isSafiLogonSwitchOn){
			isSafiServiceAvailable = HeartBeat.isApplicationAvailable(HeartBeat.SAFI2_SERVICE_APPLICATION);
			Logger.debug("SAFI : LogonUtilController." + callingMethodName + ":: SAFI2_SERVICE_APPLICATION STATUS: "+isSafiServiceAvailable,this.getClass());
		}
		return isSafiServiceAvailable;
	}

	private void logDigitalLoggerLogonSuccess(final LogonReq req, DigitalSecLogggerVO digitalSecLoggerVO,
			IBankCommonData ibankCommonData) {
		digitalSecLoggerVO.setStatus(DigitalSecLogger.SUCCESS);
		digitalSecLoggerVO.setTranName(DigitalSecLogger.APP_LOGON);
		digitalSecLoggerVO.setValues(logonHelper.toDigitalSecurityLog(req,""));
		digitalSecLoggerVO.setCommonLogData(logonHelper.getCommonLogData(req,ibankCommonData,null));
		digitalSecLoggerVO.setUserAgent(ibankCommonData.getUserAgent());
		digitalSecurityLogger.log(digitalSecLoggerVO);
	}
	
	

	private IMBResp handleMessageSplash(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, MobileSession mobileSession, String origin, Customer customer, IBankCommonData ibankCommonData,	User user, OnboardingVO oldOnboarding) throws BusinessException {
		IBankRefershParams iBankRefreshParams;
		IMBResp serviceResponse;
		List populateSplashPageResult = null;
		boolean isECorrespondenceSupported = CommonBusinessUtil.isECorrespondenceSupported(httpServletRequest);
		MsgCentreInfo messageCentreInfo= processMsgCentre(origin,customer.getGcis(),isECorrespondenceSupported);
		List<MessageSearch> splashPageInfo= messageCentreInfo.getSplashPageInfo();
		MessageSearch messageSearch = null;
		int unreadMsgCount =0;
		if(splashPageInfo != null && !splashPageInfo.isEmpty()){
		//	unreadMsgCount = (Integer)splashPageInfo.get(0);
			unreadMsgCount = messageCentreInfo.getUnreadMessageCount();
			Logger.debug("splashPageInfo - unreadMsgCount: "+unreadMsgCount, this.getClass());
			if(splashPageInfo.size() > 0) {
				messageSearch = splashPageInfo.get(0);
				//mobileSession.setSplashInfoMsg(messageSearch);
				mobileSession.setSplashInfoMsg(messageSearch);
			}
		}
		
		
		List<AutoApplyRetentionInfo> digiRetInfoList = messageCentreInfo.getApplyRetentionInfo();
		
		//setAutoApplyRetentioninSession(mobileSession,  digiRetInfoList);
		AutoApplyRetentionInfo autoApplyRetentionInfo = null;
		if(digiRetInfoList!=null && digiRetInfoList.size()>0  ){
		
			try{
				 autoApplyRetentionInfo = digiRetInfoList.get(0);
			
				 Logger.debug("Auto Apply retention info message seen: "+autoApplyRetentionInfo.getAccountNumber(), this.getClass());
				 
				 //mobileSession.setAutoApplyRetentionInfo(autoApplyRetentionInfo);
				 mobileSession.setAutoApplyRetentionInfo(autoApplyRetentionInfo);
				}
				catch(Exception e){
					Logger.warn("LogonUtilController:mbAppLogon() autoApplyRetentionInfo is null", this.getClass());
				}
			
			
		}
		
		// call service to get ServiceAdminVo
		long insertionPt = logonHelper.getInsertionPointCode(ServicetationConstants.DASHBOARD);
		ServiceStationVO servicestationVO=populateServiceMessage(insertionPt,ServiceStationImpl.CHANNEL_MOBILE, ibankCommonData);
		if(null!=servicestationVO)
		{
			//mobileSession.setServiceStationDashboardMessage(servicestationVO.getServiceStationMsg());
			mobileSession.setServiceStationDashboardMessage(servicestationVO.getServiceStationMsg());
		}
		
		serviceResponse = logonHelper.populateResponse(customer, user, unreadMsgCount, httpServletRequest, httpServletResponse, user.isStatusMustChangePassword(),servicestationVO,autoApplyRetentionInfo);
		
		//Populate the ghost tile Response
		//20E2-CSH -SBGEXP-8227 - added two conditions to check CSH/Efinance/Homeloan combination
		int cshIndicator = LoanAppUtil.getCSHTileIndicator(customer.getPreference().getCcPLLoanInd());
		
		if(customer.getPreference() != null){
			if(customer.getPreference().getCcPLLoanInd() == LoanAppConstants.PRF_CCLOANIND_EFINANCE || customer.getPreference().getCcPLLoanInd() == LoanAppConstants.PRF_CCLOANIND_EFINANCE_HOMELOAN_BOTH
					|| cshIndicator == LoanAppConstants.PRF_CCLOANIND_EFINANCE
					|| cshIndicator == LoanAppConstants.PRF_CCLOANIND_EFINANCE_HOMELOAN_BOTH){						
				LoanApplicationDetail loanAppDetail = logonHelper.populateLoanApplicationDetail(ibankCommonData,serviceResponse);
				//mobileSession.setLoanApplicationDetail(loanAppDetail);
				mobileSession.setLoanApplicationDetail(loanAppDetail);
			}
								
			//20E2-CSH -SBGEXP-8227 - populate the details for CSH tile
			if(cshIndicator == LoanAppConstants.PRF_CCLOANIND_CSH ||
					cshIndicator == LoanAppConstants.PRF_CCLOANIND_EFINANCE ||	
					cshIndicator == LoanAppConstants.PRF_CCLOANIND_HOMELOAN ||
					cshIndicator == LoanAppConstants.PRF_CCLOANIND_EFINANCE_HOMELOAN_BOTH) {
				Logger.debug("CSH : Populate CSH Tile - mbAppLogon. ", getClass());
				logonHelper.populateCSHApplicationDetail(ibankCommonData,serviceResponse);						 
			}
			
			//20E2-CSH -SBGEXP-8227 - added two conditions to check CSH/Efinance/Homeloan combination
			if(customer.getPreference().getCcPLLoanInd() == LoanAppConstants.PRF_CCLOANIND_HOMELOAN || customer.getPreference().getCcPLLoanInd() == LoanAppConstants.PRF_CCLOANIND_EFINANCE_HOMELOAN_BOTH
					|| cshIndicator == LoanAppConstants.PRF_CCLOANIND_HOMELOAN
					|| cshIndicator == LoanAppConstants.PRF_CCLOANIND_EFINANCE_HOMELOAN_BOTH){
				logonHelper.populateHomeLoanGhostTile(ibankCommonData, serviceResponse);
			}
		}
		
//				Populate the SplashPage Response
		Logger.debug("Before populate splashPageInfo", this.getClass());
		if(isSpashPageInfoPresent(splashPageInfo)){
			
			int splashFlag = 0;
			if(MessageCentreConstants.PAYTOMOBILE_DECOMMISSION.equals(messageSearch.getMessageAction())){
				if(checkPayToMobileSplashEligibility(messageSearch, ibankCommonData)){
					splashFlag = 1;
					msgCntrService.updateCustomerMessage(messageSearch,ibankCommonData.getCustomer().getGcis(), true);
					populateNPPSplashResp(serviceResponse, ibankCommonData.getOrigin(),P2M_DECOMMISSION_SPLASH_TYPE);
				}else{
					msgCntrService.updateCustomerMessage(messageSearch,ibankCommonData.getCustomer().getGcis(), false);
					messageCentreInfo = msgCntrService.getMobLogonMsgs(customer.getGcis());
					splashPageInfo= messageCentreInfo.getSplashPageInfo();
					if(splashPageInfo.size() > 0 && splashPageInfo.get(0) != null) {
						messageSearch = splashPageInfo.get(0);
						//mobileSession.setSplashInfoMsg(messageSearch);
						mobileSession.setSplashInfoMsg(messageSearch);
					}
				}
			}
			
			if(splashFlag == 0){
				if(MessageCentreConstants.PAYID_REGISTRATION.equals(messageSearch.getMessageAction())){
					if(checkPayIDRegSplashEligibility(messageSearch, ibankCommonData)){
						splashFlag = 1;
						msgCntrService.updateCustomerMessage(messageSearch,ibankCommonData.getCustomer().getGcis(), true);
						populateNPPSplashResp(serviceResponse, ibankCommonData.getOrigin(),PAYID_REGISTRATION_SPLASH_TYPE);
					}else{
						msgCntrService.updateCustomerMessage(messageSearch,ibankCommonData.getCustomer().getGcis(), false);
						messageCentreInfo = msgCntrService.getMobLogonMsgs(customer.getGcis());
						splashPageInfo= messageCentreInfo.getSplashPageInfo();
						if(splashPageInfo.size() > 0 && splashPageInfo.get(0) != null) {
							messageSearch = splashPageInfo.get(0);
							//mobileSession.setSplashInfoMsg(messageSearch);
							mobileSession.setSplashInfoMsg(messageSearch);
							
						}
					}
				}
			}
			
			if(splashFlag == 0){
				if(MessageCentreConstants.MADISON_SPLASH.equals(messageSearch.getMessageAction())){
					perfLogger.startLog("SPLASH_Madison");
					String MADISON_SWITCH = IBankParams.getBrandSwitchVal(ibankCommonData.getOrigin().trim(), IBankParams.MADISON_SWITCH) ;
					boolean isPilot = false;
					Logger.debug("Madison Switch Value: "+MADISON_SWITCH, this.getClass());
					if(MADISON_SWITCH.equalsIgnoreCase("2")){
						iBankRefreshParams =  (IBankRefershParams)ServiceHelper.getBean("ibankRefreshParams");
						isPilot=iBankRefreshParams.isPilotCustomer(ibankCommonData.getCustomer().getGcis(),MADISON_PILOT);
					}
					if(isPilot || MADISON_SWITCH.equalsIgnoreCase("1")) {
						if(logonHelper.checkMadisonSplashEligibility(httpServletRequest)){
							splashFlag = 1;
							msgCntrService.updateCustomerMessage(messageSearch,ibankCommonData.getCustomer().getGcis(), true);
							String learnMoreLink=logonHelper.getLearnMoreLink(origin);
							String appLink=logonHelper.getAppLink(origin);
							populateMadisonSplashResp(serviceResponse, ibankCommonData.getOrigin(),MADISON_SPLASH_TYPE, learnMoreLink, appLink);
						}
						else {
							messageCentreInfo = msgCntrService.getMobLogonMsgs(customer.getGcis());
							splashPageInfo= messageCentreInfo.getSplashPageInfo();
							if(splashPageInfo.size() > 0 && splashPageInfo.get(0) != null) {
								messageSearch = splashPageInfo.get(0);
								//mobileSession.setSplashInfoMsg(messageSearch);
								mobileSession.setSplashInfoMsg(messageSearch);
							}
						}
					}
					perfLogger.endLog("SPLASH_Madison");
				}
			}
								
			if(splashFlag == 0){
				if(MessageCentreConstants.MATRIX_FORCE_MIGRATION_MSG_ACTION.equals(messageSearch.getMessageAction())){
					splashFlag = 1;
					populateSplashPageResp(serviceResponse, hasMatrixSplashPageMaxCountReached(messageSearch, IBankParams.getMaxMatrixMigSplashSkipCount()), FORCED_MATRIX_MIGRATION_SPLASH_TYPE);
				}
			}
			
			if(splashFlag == 0){
				if(MessageCentreConstants.EMAIL_UPDATION_MSG_ACTION.equals(messageSearch.getMessageAction())){
					splashFlag = 1;
					populateSplashPageResp(serviceResponse, hasEmailUpdateSplashPageMaxCountReached(messageSearch, IBankParams.getMaxEmailUpdateSplashSkipCount()), EMAIL_UPDATE_SPLASH_TYPE);
				}
			}
			
			if(splashFlag == 0){
				if(MessageCentreConstants.SPLASH_OB_ESTATEMENT.equals(messageSearch.getMessageAction()) && null!=customer.getContactDetail() && null!=customer.getContactDetail().getEmail()){
					splashFlag = 1;
					if(mobileEStatementsService.isEligibleForEstmtOnboarding(customer, ibankCommonData))
						populateSplashPageResp(serviceResponse, hasSplashPageMaxCountReached(messageSearch, IBankParams.getMaxEstatementSplashSkipCount()), ESTMT_SPLASH_TYPE);
					else
					    mobileEStatementsService.deleteMessage(messageSearch, ibankCommonData);;
				}
			}
			if(splashFlag == 0 && splashPageInfo != null && splashPageInfo.size() > 0 && splashPageInfo.get(0) != null){
				if(MessageCentreConstants.SPLASH_ACTION_ECORRESPONDENCE.equals(messageSearch.getMessageAction())) {
					if(populateECorrespondenceSplashResp(serviceResponse))
						mobileSession.setLoggedonState(LogonHelper.LOGGEDON_STATE_ECORRESPONDENCE_PROMPT);
					//TODO check if the onBoardingVo has to be set null after testing
				}else {
					
					populateSplashPageResult=populateSplashPage(splashPageInfo, origin, customer, ibankCommonData, serviceResponse);
					if(null!= populateSplashPageResult){
						boolean crsSplash = (boolean) populateSplashPageResult.get(0);
						Logger.debug("After populateSplashPage : crsSlpash :"+crsSplash , this.getClass());
						if(crsSplash){
							if(populateSplashPageResult.size() > 1){
								//mobileSession.setCrsRegistrationNumber((String)populateSplashPageResult.get(1));
								mobileSession.setCrsRegistrationNumber((String)populateSplashPageResult.get(1));
								Logger.debug("In LogonUtilController :: CRS Flag "+(String)populateSplashPageResult.get(1), this.getClass());
							}
							
							if(isCrsHardPrompt3(splashPageInfo)){
								Boolean smsRest = (Boolean) user.getAttribute(LogonHelper.SMS_RESET_STATUS);
								boolean isSmsReset = smsRest != null ? smsRest.booleanValue() : false ;
								boolean mustChangePwd = user.isStatusMustChangePassword();
								if(!mustChangePwd || !isSmsReset){
									Logger.debug("This is hard prompt three ..Setting logged on state..", this.getClass());
									mobileSession.setLoggedonState(LogonHelper.LOGGEDON_STATE_CRS_HARD_PROMPT);
								}									
							}
						}
					} else {
						
						// NOTE: Never remove this condition from code because it is populating splash page response for Savings habit in this method
						// TODO Refactor the code to make it more readable
						if (showSavingsOnBoardingSplashPage(ibankCommonData, customer, messageSearch, serviceResponse)) {
							Logger.debug("Splash page response populated for Savings Onboarding", this.getClass());
							//mobileSession.setLoggedonState(LogonHelper.LOGGEDON_STATE_SAVINGS_ONBOARDING_PROMPT);
						}
					}
				}
			}
		
		}
		else if(setEcorrespondenceSplashPage(customer,serviceResponse,"mbAppLogon",isECorrespondenceSupported)){
			mobileSession.setLoggedonState(LogonHelper.LOGGEDON_STATE_ECORRESPONDENCE_PROMPT);
			//TODO check if the onBoardingVo has to be set null after testing
		}
		
		String encryptedCookieUserid = logonHelper.getEncryptedUserID(user.getUserId());
		logonHelper.addNewTnCCookie(httpServletRequest, httpServletResponse, encryptedCookieUserid, "1.0");
		((LogonResp) serviceResponse).setTermsAcceptanceReqd(false);
		((LogonResp) serviceResponse).setOnboarding(oldOnboarding);
		
		ForceChangePwdService forceService = ServiceHelper.getBean(ServiceConstants.FORCE_PWD_CHANGE);
		ForceChangePwd forceVO = mobileSession.getForceChangePwd();
		String forceStatus = forceService.getStatusFromVO(ibankCommonData, forceVO);
		Logger.debug("forceChangePwd gcis: " + customer.getGcis() + " status = " + forceStatus, LogonUtilController.class);
		setLoggedStatus(mobileSession, forceStatus, customer);
		((LogonResp) serviceResponse).setForceChangePwdStatus(forceStatus);
		((LogonResp) serviceResponse).setRemSkipCount(forceService.getRemSkipCount(forceVO, forceStatus, origin));
		
		Logger.debug("Setting OnBoarding Object only if changePassword false", LogonUtilController.class);
		return serviceResponse;
	}

	private IMBResp handleSafiChallenge(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse,	MobileSession mobileSession, String safiAction, Customer customer, User user) throws BusinessException {
		IMBResp serviceResponse = null;
		if(!StringMethods.isEmptyString(safiAction) && safiAction.equalsIgnoreCase(SafiConstants.SAFI_ACTION_CHALLENGE) && !hasSecureCodeConstraints(customer)){
				Logger.debug("SAFI : LogonUtilController:mbAppLogon(): Setting LoggedOnState - SafiChallenge: SafiAction: "+safiAction+" GCISNumber: "+customer.getGcis(), this.getClass());
				serviceResponse = logonHelper.populateResponse(customer, user, 0, httpServletRequest, httpServletResponse, user.isStatusMustChangePassword());
				((LogonResp) serviceResponse).setCustomer(null);
				((LogonResp) serviceResponse).setShowSafiChallenge(true);
				((LogonResp) serviceResponse).setContactInfo(logonHelper.populateContact(customer.getContactDetail()));
				((LogonResp) serviceResponse).setSecureCodeInfo(logonHelper.populateSecureCodeInfo(customer));
				mobileSession.setLoggedonState(LogonHelper.LOGGEDON_STATE_SAFI_CHALLENGE);
		}
		return serviceResponse;
	}

	private IMBResp handleSMSReset(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, MobileSession mobileSession, Customer customer, User user) {
		IMBResp serviceResponse;
		Boolean smsRest = (Boolean) user.getAttribute(SMS_RESET_STATUS);
		Logger.info("***smsRest mbAppLogon : " +smsRest, this.getClass());
		
		if (user.isStatusMustChangePassword() || smsRest.booleanValue())
		{
			Logger.info("***smsRest True : " +smsRest, this.getClass());
			
			if (user.isStatusMustChangePassword()){
				mobileSession.setLoggedonState(LogonHelper.LOGGEDON_STATE_FORCE_RESETPWD);
			}else{
				mobileSession.setLoggedonState(LogonHelper.LOGGEDON_STATE_FORCE_RESETPWD_SECNUM);
			}
			
			serviceResponse = logonHelper.populateCustomeCredentialChange(customer, user, httpServletRequest, httpServletResponse);
			Logger.debug("User Requested for change of password | In this case no need to set Onboarding Object", LogonUtilController.class);
			return serviceResponse;
		}
		return null;
	}

	private void handleTrackingIdTerms(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, Customer customer, User user, IBankCommonData ibankCommonData, MobileSession mobileSession) throws BusinessException {
		mbAppHelper.addTrackingIdCookie(customer.getPreference().getTrackingId(), IBankParams.getBaseOriginCode(ibankCommonData.getOrigin()), httpServletRequest, httpServletResponse);
		//bypass TnC cookie check if coming via OnlineRegistration flow
		if(mobileSession.getOnlineRegistrationDetails() == null){	
			validatetermsAndCondCookie(user.getUserId(), httpServletRequest, httpServletResponse);
		}
	}

	private OnboardingVO checkSafiConstraintChallenge(String safiAction, Customer customer, OnboardingVO onboardingVO, final String callingMethodName) {
		if(!StringMethods.isEmptyString(safiAction) && safiAction.equalsIgnoreCase(SafiConstants.SAFI_ACTION_CHALLENGE)){
			boolean hasSecureCodeConstraints = hasSecureCodeConstraints(customer);
			if(hasSecureCodeConstraints){
				Logger.debug("LogonUtilController. " +callingMethodName + " : Safi Action : "+safiAction+"hasSecureCodeConstraints: "+hasSecureCodeConstraints,this.getClass());
			}else{
				onboardingVO = null;
				Logger.debug(callingMethodName +" :: SafiAction - Challenge, Skipping OnBoarding", this.getClass());
			}
		}
		return onboardingVO;
	}

	private void handleOnboarding(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, MobileSession mobileSession, Customer customer, IBankCommonData ibankCommonData, User user, OnboardingVO oldOnboarding) throws BusinessException {
		String qzStatus = null;
		String onboardingQZSession = null;
		String pushStatus = null;
		boolean processEstatements = false;
		String eStmtStatus = null;
		
		//oldOnboarding = (OnboardingVO)ReflectionUtil.clone(onboardingVO);
		OnboardingVO onboardingVO = mobileSession.getOnboardingVO();
		oldOnboarding = (OnboardingVO)SerializationUtils.clone(onboardingVO);
		
		Logger.info("Eligibility service calls starts.", LogonUtilController.class);
		perfLogger.startLog("Onboarding_Eligibility");
		try	{
			perfLogger.startLog("QZ_Eligibility");
			qzStatus = onboardingService.getQuickZoneEligibilityStatus(customer,user);
			if(qzStatus.equalsIgnoreCase(OB_STATUS_ELIGIBLE)) {
				onboardingQZSession = onboardingService.getQuickZoneSessionForEligibleCustomer(user);
			}
			oldOnboarding.setStep(new OnboardingStep(OB_STEP_QZ,OB_STEPNAME_QUICK_ZONE, true,qzStatus, onboardingQZSession));
			perfLogger.endLog("QZ_Eligibility");
		}catch(BusinessException e){
			Logger.info("BusinessException in QuickZone Eligibility service.", LogonUtilController.class);
		}catch(Exception e){
			Logger.error("Exception caught while checking Eligibility for QuickZone : ", e, LogonUtilController.class);
		}
		
		try	{
			perfLogger.startLog("Push_Eligibility");
			pushStatus = onboardingService.getPushNotificationEligibilityStatus(customer);
			boolean isAndroid = logonHelper.isAndroid(httpServletRequest);
			oldOnboarding.setStep(new OnboardingStep(OB_STEP_PUSH,OB_STEPNAME_NOTIFICATIONS, !isAndroid,pushStatus));
			perfLogger.endLog("Push_Eligibility");
		}catch(BusinessException e){
			Logger.info("BusinessException in Push Notification Eligibility service.", LogonUtilController.class);
		}catch(Exception e){
			Logger.error("Exception caught while checking Eligibility for Push Notification : ", e, LogonUtilController.class);
		}
		
		if(customer.isCustomerOfTypeGHS() && customer.hasEmail()){
			try	{
				processEstatements = tpsThrottlingService.processRequest();
				if(processEstatements){
					perfLogger.startLog("ESTMT_Eligibility");
					eStmtStatus = onboardingService.getEStatemsntEligibilityStatus(customer, ibankCommonData);
					oldOnboarding.setStep(new OnboardingStep(OB_STEP_ESTMT,OB_STEPNAME_E_STATEMENTS,false,eStmtStatus));
					perfLogger.endLog("ESTMT_Eligibility");
				}
			}catch(BusinessException e){
				Logger.info("BusinessException in EStatement Eligibility service.", LogonUtilController.class);
			}catch(Exception e){
				Logger.error("Exception caught while checking Eligibility for EStatement : ", e, LogonUtilController.class);
			}
		}	
		Logger.info("Eligibility service calls ends.", LogonUtilController.class);
		mobileSession.setOnboardingVO(onboardingVO);
		mbAppHelper.addTrackingIdAndWebAnalyticCookie(httpServletRequest, httpServletResponse, ibankCommonData, customer);
		perfLogger.endLog("Onboarding_Eligibility");
		validatetermsAndCondCookie(user.getUserId(), httpServletRequest, httpServletResponse);
		
	}

	private void handleForceChangePwd(MobileSession mobSession, Customer customer, IBankCommonData ibankCommonData) throws BusinessException {
		
		ForceChangePwd forceVO =  mobSession.getForceChangePwd();	
		
		ForceChangePwdService forceService = null;
		if (forceVO == null){
			Logger.debug("logon:: forceChangePwdStatus: nulllllllll", this.getClass());
			forceService = ServiceHelper.getBean(ServiceConstants.FORCE_PWD_CHANGE);
			forceVO = forceService.getStatus(ibankCommonData);
			mobSession.setForceChangePwd(forceVO);
		}

		
		forceService = ServiceHelper.getBean(ServiceConstants.FORCE_PWD_CHANGE);			
		if (forceService.isCustomerTarget(forceVO)){
			setLoggedStatus(mobSession, ForceChangePwdServiceImpl.FORCE_PWD_TARGETED, customer);
			mobSession.setOnboardingVO(null);
		}
	}

	private LogonResp handleAutoInit(HttpServletRequest httpServletRequest, MobileSession mobileSession, Customer customer, String autoInitStatus)  {
		Logger.debug("***AutoInitStatus mbAppLogon : " +autoInitStatus, this.getClass());
		if(!StringMethods.isEmptyString(autoInitStatus) && autoInitStatus.equalsIgnoreCase(IBankParams.AUTO_INIT_ADMIN)){
			Logger.debug("***AutoInitStatus inside mbAppLogon 1: ", this.getClass());
			LogonResp logonResp = new LogonResp();
			logonResp.setAutoInitPwdSecNumChng(true);
			logonResp.setChangePwdReqd(false);
			logonResp.setChangePwdAndSecNumReqd(false);
			logonResp.setTermsAcceptanceReqd(true);
			//logonResp.setFirstName(customer.getFirstName());
			if(null!=customer.getContactDetail() && null!=customer.getContactDetail().getEmail()){
				String email_unmasked=customer.getContactDetail().getEmail();
				String masked = email_unmasked.replaceAll("(?<=.{2}).(?=[^@]*?.{2}@)", "*");
				logonResp.setEmailAddress(masked);
			}
			else
			{
				logonResp.setEmailAddress("");
			}
			Logger.debug("***AutoInitStatus  ECorrespondence Check: ", this.getClass());
			//E-correspondence Check Box for the consent capture
			if(CommonBusinessUtil.isECorrespondenceSupported(httpServletRequest)){
				if(customer.isCustomerOfTypeGHS()&& CustomerVOAssembler.PERSONAL_CUSTOMER.equalsIgnoreCase(customer.getCustTypeInd()))
				{
					logonResp.seteCorConsentCaptureRequired(true);
				}
			}
			
			Logger.debug("***AutoInitStatus inside mbAppLogon 2: ", this.getClass());
			mobileSession.setLoggedonState(LogonHelper.AUTO_INIT_RESET_PWD_SECNUM);
			AppParams appParams = logonHelper.populateAppParams(httpServletRequest, customer);
			Logger.debug("***AutoInitStatus inside mbAppLogon 3: ", this.getClass());
			logonResp.setAppParams(appParams);
			Logger.debug("***AutoInitStatus inside mbAppLogon 4: ", this.getClass());
			MobileSession dummySession = null;
			RespHeader headerResp = populateResponseHeader(ServiceConstants.LOGON_RESPONSE, dummySession);
			logonResp.setHeader(headerResp);
			return logonResp;					 
		}else {
			return null;
		}
		
	}

	private void handleSafiDigitalLogger(HttpServletRequest httpServletRequest, SafiLogonInfo safiLogonInfo,
			Customer customer, IBankCommonData ibankCommonData) throws BusinessException {
		String safiAction =  safiLogonInfo != null ?safiLogonInfo.getSafiAction():null;
		Logger.debug("SAFI : getCustApp:SafiAction from Session: "+safiAction, this.getClass());
		
		if(!StringMethods.isEmptyString(safiAction) && safiAction.equalsIgnoreCase(SafiConstants.SAFI_ACTION_DENY)){
			Logger.warn("SAFI : mbAppLogon:SafiAction from Session: "+safiAction+"GCISNumber: "+customer.getGcis(), this.getClass());
			throw new BusinessException(BusinessException.SAFI_LOGON_DENY_ERROR);
		}
		
		if(!StringMethods.isEmptyString(safiAction) && safiAction.equalsIgnoreCase(SafiConstants.SAFI_ACTION_CHALLENGE) && !hasSecureCodeConstraints(customer)){
			boolean phoneNumAvailable = SafiWebHelper.isPhoneNumberAvailable(customer.getContactDetail());
			if(!phoneNumAvailable){
				Logger.debug("SAFI : LogonUtilController:mbAppLogon(): Phone Number not available....Exception"+"GCISNumber: "+customer.getGcis(), this.getClass());
				//18E4 - Safi Forensic logging
				DigitalSecLogggerVO digitalSecLoggerVO = new DigitalSecLogggerVO();
				SafiForensicInfo safiForensicInfo = new SafiForensicInfo();
				boolean isMobileApp = ((logonHelper.loadCordova(httpServletRequest)) == -1) ? false:true;
				safiForensicInfo.setSafiRiskScore(safiLogonInfo!= null ? safiLogonInfo.getSafiRiskScore() :"");
				safiForensicInfo.setSafiRuleName(safiLogonInfo!= null ? safiLogonInfo.getSafiRuleName() :"");
				safiForensicInfo.setSafiSdkDevicePrint(safiLogonInfo!= null ? safiLogonInfo.getDevicePrint() : "");
				
				digitalSecLoggerVO.setStatus(DigitalSecLogger.FAILURE);
				digitalSecLoggerVO.setTranName(DigitalSecLogger.SAFI_APP_LOGON);
				digitalSecLoggerVO.setValues(logonHelper.toDigitalSecuritySafiLog(safiForensicInfo));
				digitalSecLoggerVO.setCommonLogData(logonHelper.getCommonLogData(null,ibankCommonData,null));
				digitalSecLoggerVO.setUserAgent(ibankCommonData.getUserAgent());
				digitalSecurityLogger.log(digitalSecLoggerVO);
				throw new BusinessException(BusinessException.IBANK_SECURE_NO_PHONE_EXIST);
			}
		}
	}

	
	private boolean showSavingsOnBoardingSplashPage(IBankCommonData ibankCommonData, Customer customer, MessageSearch messageSearch, IMBResp serviceResponse) throws BusinessException {
		if (MessageCentreConstants.SPLASH_ACTION_SAVINGS_ONBOARDING_EXISTING.equals(messageSearch.getMessageAction()) &&
			!isSavingsOnboardingSplashPageSkipped(messageSearch, IBankParams.getMaxSavingsOnboardingExistingSkipCount())) {
			return showSavingsOnBoardingExistingSplashPage(ibankCommonData, customer, messageSearch, serviceResponse);
		} else if (MessageCentreConstants.SPLASH_ACTION_SAVINGS_ONBOARDING_NEW.equals(messageSearch.getMessageAction()) &&
				   savingsOnboardingService.isDDAAvailable() && 
				   !isSavingsOnboardingSplashPageSkipped(messageSearch, IBankParams.getMaxSavingsOnboardingNewSkipCount())) {
			return showSavingsOnBoardingNewSplashPage(ibankCommonData, customer,	messageSearch, serviceResponse);	
		}
		
		return false;
	}

	private boolean showSavingsOnBoardingNewSplashPage(IBankCommonData ibankCommonData, Customer customer, MessageSearch messageSearch, IMBResp serviceResponse) throws BusinessException {
/*		if(IBankParams.isSwitchOn( IBankParams.SAVINGS_HABIT_SWITCH_NEW)){*/
			if (customer != null && customer.getSavingsHabitFromAcctsList() == null || customer.getSavingsHabitFromAcctsList().isEmpty()) {
				//do not display the splash page in case there is not from account and delete the message
				savingsOnboardingService.deleteMessage(messageSearch, ibankCommonData);	
				return false;
			} else {
				//TODO:check switch
				populateSavingsOnboardingSplashResp(serviceResponse, messageSearch, null);
				return true;
			}
		/*}else{
			return false;
		}*/
			
	}

	private boolean showSavingsOnBoardingExistingSplashPage(IBankCommonData ibankCommonData, Customer customer, MessageSearch messageSearch, IMBResp serviceResponse) throws BusinessException {
		//19E4 Tech Debt Start:Switch Removal
		/*	if(IBankParams.isSwitchOn(IBankParams.SAVINGS_HABIT_SWITCH_EXISTING)){*/
			List<Account> toAccounts = savingsOnboardingService.getSavingsOnboardingToAcounts(customer, ibankCommonData.getOrigin());
			
			//do not display the splash page in case there is not from or no to account and delete the message
			if (customer != null && customer.getSavingsHabitFromAcctsList() == null || 
				customer.getSavingsHabitFromAcctsList().isEmpty() ||
				toAccounts == null || toAccounts.isEmpty()) {
				savingsOnboardingService.deleteMessage(messageSearch, ibankCommonData);	
				return false;
			} else {
				populateSavingsOnboardingSplashResp(serviceResponse, messageSearch, toAccounts);			
				return true;
			}
		/*}else{
			return false;
		}	*/
			//19E4 Tech Debt End:Switch Removal
	}
	
	
	
	

	private boolean setEcorrespondenceSplashPage(Customer customer ,IMBResp serviceResponse ,String fromPlace,boolean isEcorrespondenceSupported) {
		Logger.debug("Inside set Ecorrespondence Splah page for customer "+ customer.getGcis() + " from " + fromPlace , this.getClass() );
		if(isEcorrespondenceSupported){
			//Splash page for eCorrespondence consent capture
			if(customer.isCustomerOfTypeGHS() && CustomerVOAssembler.PERSONAL_CUSTOMER.equals(customer.getCustTypeInd()) &&
					(!customer.getPreference().iseCorConsent()) && customer.getAccounts() != null && customer.getAccounts().size() > 0){
				boolean ecorSplashPresent = populateECorrespondenceSplashResp(serviceResponse);
				Logger.debug("set Ecorrespondence Splah page for customer "+ customer.getGcis() + " returning "  +ecorSplashPresent + " from " + fromPlace , this.getClass() );
				return ecorSplashPresent;
			}
			Logger.debug("set Ecorrespondence Splah page for customer "+ customer.getGcis() + " returning false" + " from " + fromPlace , this.getClass() );
		}
		return false;
	}
	
	private void populateSavingsOnboardingSplashResp(IMBResp serviceResponse, MessageSearch messageSearch, List<Account> toAccounts) {
		if (null != messageSearch) {
			SplashPageResp splashPageResp = new SplashPageResp();
			splashPageResp.setSplashType(SAVINGS_ONBOARDING_SPLASH_TYPE);
			if (serviceResponse != null && serviceResponse instanceof LogonResp && ((LogonResp) serviceResponse).getCustomer() != null) {
				CustomerResp customer = ((LogonResp) serviceResponse).getCustomer();
				customer.setSplashPage(splashPageResp);
				
				if (toAccounts != null) {
					for (Account account : toAccounts) {
						customer.getSavingsHabitToAccts().add(account.getIndex());
					}
				}
			}
		}	
	}
	private boolean hasSplashPageMaxCountReached(MessageSearch messageSearch, int maxAllowedCount) {
		if (null!= messageSearch) {
			int lastUpdatedCount = 0;
			if (messageSearch.getAppField1() != null) {
				lastUpdatedCount = Integer.parseInt(messageSearch.getAppField1());
			}
			return maxAllowedCount <= lastUpdatedCount;
		}	
		return false;
	}

	private boolean hasMatrixSplashPageMaxCountReached(MessageSearch messageSearch, int maxAllowedCount) {
		int lastUpdatedCount = 0;
		if (null!= messageSearch && messageSearch.getAppField1() != null) {
			lastUpdatedCount = Integer.parseInt(messageSearch.getAppField1());
		}
		return maxAllowedCount <= (lastUpdatedCount + 1);
	}
	
	private boolean hasEmailUpdateSplashPageMaxCountReached(MessageSearch messageSearch, int maxAllowedCount) {
		int lastUpdatedCount = 0;
		if (null!= messageSearch && messageSearch.getAppField1() != null) {
			lastUpdatedCount = Integer.parseInt(messageSearch.getAppField1());
		}
		return maxAllowedCount <= (lastUpdatedCount + 1);
	}
	
	private boolean isSavingsOnboardingSplashPageSkipped(MessageSearch messageSearch, int maxAllowedCount) {
		if (null!= messageSearch) {
			int lastUpdatedCount = 0;
			if (messageSearch.getAppField1() != null) {
				lastUpdatedCount = Integer.parseInt(messageSearch.getAppField1());
			}
			
			if (maxAllowedCount > lastUpdatedCount){				
				return false;
			} else {
				return true;
			}			
		}	
		
		return false;
	}
	
	private boolean populateECorrespondenceSplashResp(IMBResp serviceResponse) {
		SplashPageResp splashPageResp = new SplashPageResp();
		splashPageResp.setSplashType(E_COR_SPLASH_TYPE);
		return setCustomerSplashPageResp(serviceResponse, splashPageResp);
	}
	
	private void populateSplashPageResp(IMBResp serviceResponse, boolean hasSplashPageMaxCountReached, String splashPageType) {
		SplashPageResp splashPageResp = new SplashPageResp();
		splashPageResp.setSplashType(splashPageType);
		splashPageResp.setSplashPageMaxCountReached(hasSplashPageMaxCountReached);
		setCustomerSplashPageResp(serviceResponse, splashPageResp);
	}

	private AuthenticationData populateAuthenticationData(LogonReq req, String origin, String ipAddress)
	{
		AuthenticationData authenticationData = new AuthenticationData();
		authenticationData.setUserId(req.getAccessNumber());
		authenticationData.setIssueNumber(req.getIssueNumber());
		authenticationData.setPassword(req.getPassword());
		authenticationData.setSecurityNumber(req.getSecurityNumber());
		authenticationData.setOrigin(origin);
		authenticationData.setIpAddress(ipAddress);
		return authenticationData;
	}
	
	private ServiceStationVO populateServiceMessage(long insertionPoint,String channel, IBankCommonData commonData)
	{
		ServiceStationVO serviceStationAdminVo=null;
		try
		{
		 serviceStationAdminVo= serviceStationService.getServiceMessage(insertionPoint, ServiceStationImpl.CHANNEL_MOBILE, commonData);			
		}
		 catch(BusinessException ex){
			Logger.warn("An error occurred while getting service station message for mobile accoutn details", ex, this.getClass());
		}
		return serviceStationAdminVo;
	}

	public User authenticate(AuthenticationData authenticationData, boolean skipSecNum) throws BusinessException, ResourceException
	{
		MobileBankService mobileBankService = (MobileBankService) ServiceHelper.getBean(MBAppConstants.SPRING_MOBILE_SERVICE_BEAN);
		User myUser = null;
		if ( skipSecNum )
			myUser = mobileBankService.authenticateSkipSecurityNumber(authenticationData);
		else
			myUser = mobileBankService.authenticate(authenticationData);
		return myUser;
	}

	public Customer getCustomer(IBankCommonData commonData , String statistic) throws BusinessException,ResourceException	{
			return getCustomer(commonData , statistic, false);
	}

	public Customer getCustomer(IBankCommonData commonData , String statistic, boolean isLogonFlow) throws BusinessException,
			ResourceException
	{
	//	IBankCommonData commonData = populateIBankCommonData(sessionId,user , origin, ipAddress);
		MobileBankService mobileBankService = (MobileBankService) ServiceHelper.getBean(MBAppConstants.SPRING_MOBILE_SERVICE_BEAN);
		Customer customer = mobileBankService.getCustomer(commonData, statistic, isLogonFlow);
		return customer;
	}


	
	private IBankCommonData populateIBankCommonData(String sessionId, User user, String origin, String ipAddress ,String userAgent)
	{
		IBankCommonData commonData = new IBankCommonData();
		commonData.setUser(user);
		commonData.setOrigin(origin);
		commonData.setIpAddress(ipAddress);
		commonData.setSessionId(sessionId);
		commonData.setUserAgent(userAgent);
		return commonData;
	}



	
	public void sendLogonPRMMessage(AuthenticationData authData, IBankCommonData commonData, User myUser, String desc,SafiPrmInfo... safiPrmVo)
	{
		Logger.debug("sendLogonPRMMessage - start " + myUser + ":" + authData + ":" + commonData, LogonUtilController.class);
		Logger.debug("myUser:: " + myUser, LogonUtilController.class);
		PRMUpdateService prmService = (PRMUpdateService) ServiceHelper.getBean("prmServiceBean");
		prmService.sendPRMLogon(authData, commonData, myUser, desc,safiPrmVo);

		Logger.debug("sendLogonPRMMessage - end", LogonUtilController.class);
	}

	public String replaceString(String userAgent)
	{
		String data = userAgent;
		data = data.replaceAll("&", "&amp;");
		data = data.replaceAll("<", "&lt;");
		data = data.replaceAll(">", "&gt;");
		data = data.replaceAll("'", "&apos;");
		data = data.replaceAll("\"", "&quot;");
		return data;
	}


	
	public ErrorResp validate(IMBReq serviceRequest, HttpServletRequest request) {
		return mbAppValidator.validate(serviceRequest, request);
	}
	
	public void validateRequestHeader(ReqHeader header, HttpServletRequest request) throws ResourceException
	{
		// Nothing to do in case of logon as Session is not created. Session is
		// created after only successful logon
		mbAppValidator.validateRequestHeader(header,  request);

	}


	public RespHeader populateResponseHeader(String serviceName, MobileSession mobileSession )
	{
		MBAppHelper mbAppHelper = new MBAppHelper();
		return mbAppHelper.populateResponseHeader(serviceName, mobileSession);
		
	}
	
	public RespHeader populateResponseHeader(String serviceName, IGenericSession genericSession )
	{
		MBAppHelper mbAppHelper = new MBAppHelper();
		return mbAppHelper.populateResponseHeader(serviceName, genericSession);
		
	}	

	/*private void validateDifferentCookie(HttpServletRequest request, HttpServletResponse response, final LogonReq req, User user)
	{
		
		
		if ( user == null && StringMethods.isEmptyString(user.getGCISNumber()))
		{
			return ;
		}
		if (req.isSaveCan()){
			
			Logger.debug("req.isSaveCan(): $$$$ "+ "user :" + user, this.getClass());
		
			String accessNum = req.getAccessNumber();
			String issueNum = req.getIssueNumber();
			if ( StringMethods.isEmptyString(accessNum ) && StringMethods.isEmptyString(issueNum) )
			{
				accessNum = accessNum + issueNum; 
			}
			logonHelper.setEncryptedCANCookie(req.getAccessNumber(),request,response);
		}
		else if(logonBean.getSaveCan().equals("true") && logonBean.getIgnoreSecNum().equals("false")){
			if(accessNumber.length() > 8){
				//To do for card number < 16 digits pad with zeros
				if(accessNumber.length() < 16){
					accessNumber = mobileHelper.padLeadingChars(accessNumber, 16, '0');
				}
				mobileHelper.setEncryptedCANCookie(accessNumber+issueNum,request,response);
			}
			else{
				//To do for CAN < 8 digits pad with zeros
				if(accessNumber.length() < 8){
					accessNumber = mobileHelper.padLeadingChars(accessNumber, 8, '0');
				}
				mobileHelper.setEncryptedCANCookie(accessNumber,request,response);	
			}
		} 
		else if( ! req.isSaveCan()){
			logonHelper.removeEncryptedCANCookie(request, response);
		}
		//End

	}*/
	
	
	
	private void validateDifferentCookie(HttpServletRequest request, HttpServletResponse response, final LogonReq req, User user ,String safiAction)
	{
		
		
		if ( user == null && StringMethods.isEmptyString(user.getGCISNumber()))
		{
			return ;
		}
		if (req.isSaveCan()){
			//safiAction will be populated only if Safi is called else null always.
			if(!StringMethods.isEmptyString(safiAction) && (safiAction.equalsIgnoreCase(SafiConstants.SAFI_ACTION_CHALLENGE) || safiAction.equalsIgnoreCase(SafiConstants.SAFI_ACTION_DENY))){
				//do nothing
			}else{
				Logger.debug("req.isSaveCan(): $$$$ "+ "user :" + user, this.getClass());
				
				String accessNum = req.getAccessNumber();
				String issueNum = req.getIssueNumber();
				if ( StringMethods.isEmptyString(accessNum ) && StringMethods.isEmptyString(issueNum) )
				{
					accessNum = accessNum + issueNum; 
				}
				logonHelper.setEncryptedCANCookie(req.getAccessNumber(),request,response);
			}
						
		}
		else if( ! req.isSaveCan()){
			logonHelper.removeEncryptedCANCookie(request, response);
		}
		//End

	}
	

	private void validatetermsAndCondCookie(String userID, HttpServletRequest request, HttpServletResponse response) throws BusinessException
	{
		String encryptedCookieUserid = logonHelper.getEncryptedUserID(userID);
		boolean isCookieFound = logonHelper.isMobileTnCCookieExists(request, response,encryptedCookieUserid,"1.0");
		Logger.debug("@3036:isCookieFound: "+ isCookieFound,this.getClass());
		
		if ( !isCookieFound )
		{
			Logger.info("T & C Not displayed for " + userID ,this.getClass());
//			logonHelper.addNewTnCCookie(request, response,encryptedCookieUserid,"1.0");
			throw new BusinessException(BusinessException.COOKIES_NOT_FOUND, "T & C Not displayed for " + userID);
		}
		else
		{
			logonHelper.addNewTnCCookie(request, response,encryptedCookieUserid,"1.0");

		}
	}


	private boolean isUserMustChangePassword(User myUser){
		boolean retValue=false;
		String mustChangePassword=(String)myUser.getAttribute(User.MUSTCHANGEPASSWORD);
		Boolean isSMSReset = (Boolean)myUser.getAttribute(SMS_RESET_STATUS);

		if(StringMethods.isValidString(mustChangePassword) && mustChangePassword.equalsIgnoreCase("Y") || Boolean.TRUE.equals(isSMSReset) ){
			retValue=true;
		}
		return retValue;
	}

	//Create new branded messages for customer & return an unread count
	private MsgCentreInfo processMsgCentre(String origin, String gcisNum,boolean isECorrespondenceSupported) throws BusinessException, ResourceException{
			OriginsVO originVO= IBankParams.getOrigin(origin);
			msgCntrService.addBrandCustMsg(originVO.getBankName(),gcisNum);
			return msgCntrService.getCustomerMessageInfo(gcisNum,isECorrespondenceSupported, origin);				
		
	}
	
	
	private void setSecurityUniqueId (IGenericSession genericSession , RespHeader headerResp )
	{
		String newNameId = mbAppHelper.getSecurityUniqueID();
		headerResp.setNameId(newNameId);
		genericSession.setAttribute(MobileSessionImpl.SECURITY_UNIQUE_ID, newNameId);
	}
	
	private void setSecurityUniqueId(MBAppHelper mbAppHelper, MobileSession mobileSession, RespHeader headerResp) {
		String newNameId = mbAppHelper.getSecurityUniqueID();
		headerResp.setNameId(newNameId);
		mobileSession.setSecurityUniqueID(newNameId);
	}
	
	private void setSecurityUniqueId(MBAppHelper mbAppHelper, IGenericSession genericSession, RespHeader headerResp) {
		String newNameId = mbAppHelper.getSecurityUniqueID();
		headerResp.setNameId(newNameId);
		//mobileSession.setSecurityUniqueID(newNameId);
		genericSession.setAttribute(MobileSessionImpl.SECURITY_UNIQUE_ID, newNameId);
	}	
	
	
	private static final String MB_DEMO_SECURITY_KEY = "mbDemoSecurityKey";

	public void checkDemoSecurityKey(String securityKey) throws ResourceException, BusinessException{

		CodesVO code = IBankParams.getCodesData(IBankParams.BRAND_ORIGIN, IBankParams.CONFIGURATION_PROPERTIES, MB_DEMO_SECURITY_KEY);
		if (code == null){
			Logger.error("checkDemoSecurityKey: MB_DEMO_SECURITY_KEY is missing from DB" , this.getClass());
			throw new ResourceException(ResourceException.SYSTEM_ERROR,"MB_DEMO_SECURITY_KEY is missing from DB");
		}else{
			if(!securityKey.equals(code.getMessage())){
				throw new BusinessException(BusinessException.INVALID_USERID_PASSWORD);
			}

		}

	}
	
	private boolean hasSecureCodeConstraints(Customer customer) {
		
		boolean resp = false;
		
		try{
			if(IBankParams.isGlobalByPass()){
				resp = true;
			}else if (IBankSecureService.isCustomerExempt(customer.getIBankSecureDetails())){
				resp = true;
			}
		}catch (Exception e){
			resp = false;
			Logger.warn("Error Logon hasSecureCodeConstraints: " + customer.getGcis(), this.getClass());			
		}
		
		return resp;
	}
	
	private void setLoggedStatus (IGenericSession session, String status, Customer customer){
		if (ForceChangePwdServiceImpl.FORCE_PWD_SHOW_SKIP.equalsIgnoreCase(status) || ForceChangePwdServiceImpl.FORCE_PWD_TARGETED.equalsIgnoreCase(status)){
			if (!hasSecureCodeConstraints(customer)){
				session.setLoggedonState(LogonHelper.LOGGEDON_STATE_FORCE_PWDCHANGE);
			}else{
				session.setLoggedonState(LogonHelper.LOGGEDON_STATE_FORCE_PWDCHANGE_2FA_EXEMPT);
			}
		}
	}

	private void setLoggedStatus (MobileSession session, String status, Customer customer){
		
		if (ForceChangePwdServiceImpl.FORCE_PWD_SHOW_SKIP.equalsIgnoreCase(status) || ForceChangePwdServiceImpl.FORCE_PWD_TARGETED.equalsIgnoreCase(status)){
			if (!hasSecureCodeConstraints(customer)){
				session.setLoggedonState(LogonHelper.LOGGEDON_STATE_FORCE_PWDCHANGE);
			}else{
				session.setLoggedonState(LogonHelper.LOGGEDON_STATE_FORCE_PWDCHANGE_2FA_EXEMPT);
			}
		}
	}	
	private String getHardPrompt(String msgActionType ){		
		String hardPromptType =  "";
		switch(msgActionType){
		case "C1":
			hardPromptType = "H1";		   
			return hardPromptType;
		case "C2":
			hardPromptType = "H2";	
			return hardPromptType;
		case "C3":
			hardPromptType = "H3";	
			return hardPromptType;
		default:
			return hardPromptType;
		}
	}
	
//	Populate the SplashPage Response
	public List populateSplashPage(List<MessageSearch > splashPageInfo, String origin, Customer customer, IBankCommonData ibankCommonData, IMBResp serviceResponse ) throws au.com.stgeorge.framework.common.exception.ResourceException, BusinessException{
		Logger.debug("Inside populateSplashPage, GCIS: "+customer.getGcis(), this.getClass());
		SplashPageResp splashPageResp = null;
		MessageSearch messageSearch = splashPageInfo.get(0);
		CRSInfo crsInfo = null;
		boolean showSplash=false;
		List populateSplashPageResult = null;
		boolean showHardPrompt3=false;
		
		//switch check for CRS Hard prompt
		if(IBankParams.isSwitchOn(IBankParams.CRS_PRODUCT_READY_SWITCH)){			
			if(MessageSearch.messageActionCRSList.contains(messageSearch.getMessageAction())){
				populateSplashPageResult = new ArrayList();
//				Call 258
				try{				
					Logger.debug("populateSplashPage CRS Update  ",  this.getClass());
					crsInfo = crsService.getCrsInfo(ibankCommonData);	
					CustomerMessage customerMessage = new CustomerMessage();
					customerMessage.setId(messageSearch.getCustMsgID());
					customerMessage.setMsgID(messageSearch.getMsgID());
					customerMessage.setModifiedBy(ibankCommonData.getCustomer().getGcis());
					customerMessage.setAppField1(messageSearch.getAppField1());
					customerMessage.setGcisNumber(ibankCommonData.getCustomer().getGcis());
					customerMessage.setExpiryDate(messageSearch.getCustMessageExpiry());
					Logger.debug("258 response & crsInfo  : "+crsInfo, this.getClass());
					if(crsInfo != null && !"X".equalsIgnoreCase(crsInfo.getRegistrationNumber())){
						Logger.debug("Inside populateSplashPage : ",this.getClass());
						crsService.updateMsgDeleteStatus(messageSearch,ibankCommonData);
					}
					else{
						if(MessageCentreConstants.SPLASH_ACTION_CRS_HARD_PROMPT_3.equalsIgnoreCase(messageSearch.getMessageAction())){
							Logger.debug("Hard prompt 3",this.getClass());
							showHardPrompt3 = true;
							if(messageSearch.getXrefId() == null){
								Logger.debug("Inside XrefID NULL::>>", this.getClass());
								crsService.updateCRSPromptDetails(ibankCommonData, customerMessage, messageSearch.getMessageAction());
								showSplash=true;
								((LogonResp) serviceResponse).setCustomer(null);
								((LogonResp) serviceResponse).setFirstName(customer.getFirstName());
							}
						}
						else{
							Logger.debug("HP2 or Hp1", this.getClass());
							splashPageResp = new SplashPageResp();
							String hardPromptType = getHardPrompt(messageSearch.getMessageAction());
							splashPageResp.setSplashType(CRS_SPLASH_TYPE); // TODO Remove Hardcode
							splashPageResp.setPromptType(hardPromptType);
							/*if(MessageCentreConstants.SPLASH_ACTION_CRS_HARD_PROMPT_1.equalsIgnoreCase(messageSearch.getMessageAction())){
								Logger.debug("Inside HP1",  this.getClass());
								if(messageSearch.getCustMessageExpiry() != null){
									splashPageResp.setExpiryDate(logonHelper.convertExpiryDateForCRSPrompt(messageSearch.getCustMessageExpiry()));
								}else{
									splashPageResp.setExpiryDate(logonHelper.getExpiryDateForCRSPrompt(messageSearch.getAppField1()!=null?Integer.valueOf(messageSearch.getAppField1()).intValue():0));
						    	}
							}else{*/
								
						//	}
							Date expiryDate = customerMessage.getExpiryDate();
							Logger.debug("ExpiryDate in customer message is "+expiryDate,getClass());
							Logger.debug("XrefID::>>"+messageSearch.getXrefId(), this.getClass());
							if(messageSearch.getXrefId() == null){
								Logger.debug("Inside XrefID NULL::>>", this.getClass());
								splashPageResp.setShowCRSAsTile(false);
								expiryDate  = crsService.updateCRSPromptDetails(ibankCommonData, customerMessage, messageSearch.getMessageAction());
								Logger.debug("ExpiryDate returned from service is "+expiryDate,getClass());
								showSplash=true;
							}
							else{
								Logger.debug("Inside XrefID NOT NULL::>>", this.getClass());
								splashPageResp.setShowCRSAsTile(true);
							}
							Logger.debug("Inside HP2 or HP3",  this.getClass());
							splashPageResp.setExpiryDate(logonHelper.convertExpiryDateForCRSPrompt(expiryDate));
						}
															
					}
				} catch(BusinessException e){
					Logger.warn("Business Exception:" + e.getKey() + " Mesage : "+ e.getMessage(), e, this.getClass());
					//saveError(getServletRequest(), e.getKey());		
					splashPageResp = null;		
				}						
				if(serviceResponse != null && serviceResponse instanceof LogonResp){				
					if(null!=customer){
						Logger.debug("Setting customer type ::"+customer.getCustTypeInd(), this.getClass());
						((LogonResp) serviceResponse).setCustTypeInd(customer.getCustTypeInd());
					}
					if(((LogonResp) serviceResponse).getCustomer() != null && null!= splashPageResp){
						Logger.debug("Setting the SplashPageResp in LogonResp", this.getClass());
						((LogonResp) serviceResponse).getCustomer().setSplashPage(splashPageResp);
						
					}else if(null == splashPageResp && showHardPrompt3){
						Logger.debug("Setting showHardPrompt as true b'cuz its HP3", this.getClass());
						((LogonResp) serviceResponse).setShowHardPrompt(showHardPrompt3);
					}
				}
				populateSplashPageResult.add(showSplash);
			}
			
			
			if(null!= crsInfo){
				populateSplashPageResult.add(crsInfo.getRegistrationNumber());
				Logger.debug("In populateSplashPage :: flag value ::"+crsInfo.getRegistrationNumber(), this.getClass());
			}	
		}else{
			Logger.debug("CRS Hard Prompt Switch is OFF :: Kindly do not populate splash resp", this.getClass());
		}				
		return populateSplashPageResult;
	}
	
	public boolean isCrsHardPrompt3(List<MessageSearch > splashPageInfo){
		Logger.debug("Inside isCrsHardPrompt3", this.getClass());
		boolean isCrsHardPrompt3=false;
		if(splashPageInfo.size() > 0){
			
			MessageSearch messageSearch = splashPageInfo.get(0);			
			if(MessageCentreConstants.SPLASH_ACTION_CRS_HARD_PROMPT_3.equalsIgnoreCase(messageSearch.getMessageAction())){
				isCrsHardPrompt3 = true;
			}			
		}
		
		return isCrsHardPrompt3;
	}
	
	/**
	 * @param messageSearch
	 * @return true : eligible for P2M decommission splash page
	 *        false : not eligible for P2M decommission splash page
	 * @throws BusinessException 
	 * @throws ResourceException 
	 */
	private boolean checkPayToMobileSplashEligibility(MessageSearch messageSearch, IBankCommonData ibankCommonData) throws ResourceException, BusinessException{
		if (payToMobileService.getAliasDetail(ibankCommonData) != null) {
			//Customer is registered for Pay To Mobile
			Logger.debug("***Customer is registered for Pay to Mobile***", this.getClass());
			return true;
		}
		return false;
		//return true;
	}
	
	private boolean checkPayIDRegSplashEligibility(MessageSearch messageSearch, IBankCommonData ibankCommonData) throws ResourceException, BusinessException{
		IBankRefershParams iBankRefreshParams =  (IBankRefershParams)ServiceHelper.getBean("ibankRefreshParams");
		PayIdRegistrationSwitchParams payIdRegSwitchParams = iBankRefreshParams.getPayIdRegistrationSwitchParams(ibankCommonData.getOrigin(), ibankCommonData.getCustomer().getGcis());
		if(payIdRegSwitchParams.isShowPayIdRegistrationMenu() && !payIdRegSwitchParams.isShowPayIdOutageMessage()){
			//It means PayID feature is available for the user. Show the Payid reg splash
			if(CustomerService.isCustomerIDVed(ibankCommonData.getCustomer())){
				Logger.debug("***PayID Switch is ON and Customer is IDVed***", this.getClass());
				return true;
			}
		}
		return false;
	}
	
	
	private boolean populateNPPSplashResp(IMBResp serviceResponse, String origin, String splashType) {
		SplashPageResp splashPageResp = new SplashPageResp();
		splashPageResp.setSplashType(splashType);
		return setCustomerSplashPageResp(serviceResponse, splashPageResp);
	}

	private boolean setCustomerSplashPageResp(IMBResp serviceResponse, SplashPageResp splashPageResp) {
		if(serviceResponse != null && serviceResponse instanceof LogonResp && ((LogonResp) serviceResponse).getCustomer() != null){
			CustomerResp customer = ((LogonResp) serviceResponse).getCustomer();
			customer.setSplashPage(splashPageResp);
			return true;
		}
		return false;
	}

/*	private String getStatusDesc(long nextStepInd)
    {   
		  String statusDesc = null;
          String nextStpInd=String.valueOf(nextStepInd);                    
          switch(nextStpInd){
          case "1":
        	  statusDesc = LoanAppConstants.VERIFY_INCOME_STATUS;
        	  break;
          case "2":
        	  statusDesc = LoanAppConstants.VERIFY_INCOME_STATUS;
        	  break;
          case "3":
        	  statusDesc = LoanAppConstants.VERIFY_INCOME_STATUS;
                break;
          case "4":
        	  statusDesc = LoanAppConstants.SIGN_YOUR_CONTRACT_STATUS;
                break;
          case "5":
        	  statusDesc = LoanAppConstants.SIGN_YOUR_CONTRACT_STATUS;;
                break; 
          case "6":
        	  statusDesc = LoanAppConstants.SIGN_YOUR_CONTRACT_STATUS;;
                break; 
          }
          return statusDesc;
    }*/
	
	@Autowired
	private LogonHelper logonHelper;
	
	@Autowired
	private MBAppHelper mbAppHelper;
	
	@Autowired
	private ActivationHelper activationHelper;

	
	@Autowired
	private MBAppValidator mbAppValidator;
	
	@Autowired
	private PerformanceLogger perfLogger;
	
	

	private IMBResp populateCustomerLiterResponse(HttpServletRequest httpServletRequest,
			HttpServletResponse httpServletResponse, IGenericSession genericSession, User user, Customer customer)
			throws BusinessException, JsonProcessingException {
		int unreadMsgCount = -1;
		IMBResp serviceResponse = logonHelper.populateResponse(customer, user, unreadMsgCount, httpServletRequest,
				httpServletResponse, false, null, null);

		genericSession.setAttribute(MobileSessionImpl.CUSTOMER_OBLECT, customer);

		genericSession.setAttribute(STATE, MBAppConstants.STATE_MOBILE, true);
		ObjectMapper mapper = new ObjectMapper();
		Logger.info("getCustomerLite Logon /logon JSON Response :" + mapper.writeValueAsString(serviceResponse),
				this.getClass());
		MobileSession dummySession = null;
		RespHeader headerResp = populateResponseHeader(ServiceConstants.LOGON_RESPONSE, dummySession);
		setSecurityUniqueId(genericSession, headerResp);
		serviceResponse.setHeader(headerResp);
		return serviceResponse;
	}

	private String getSessionIdFromCompassCookie(HttpServletRequest httpServletRequest, String sessionId) {
		Cookie sessCookie = logonHelper.getCookie(httpServletRequest, MBAppConstants.COMPASS_COOKIE);
		if (null != sessCookie) {
			sessionId = sessCookie.getValue();
			Logger.debug("LogonUtilController - getLiteCustomer: Session id from IB :" + sessionId, this.getClass());
		}
		return sessionId;
	}

	private void setCustomerAndOriginInSession(String origin, IGenericSession genericSession, Customer customer,
			String gdwOrigin) {
		  genericSession.setAttribute(MobileSessionImpl.CUSTOMER_OBLECT, customer);
		  genericSession.setAttribute(MobileSessionImpl.ORIGIN_OBLECT, origin);
		  genericSession.setAttribute(MobileSessionImpl.GDW_ORIGIN, gdwOrigin);
	}

	private IBankCommonData populateIBankCommonData(String sessionId, User user,String origin,String ipAddress ,String userAgent , String gdwOrigin) {
		
		IBankCommonData commonData = new IBankCommonData();
		commonData.setUser(user);
		commonData.setOrigin(origin);
		commonData.setIpAddress(ipAddress);
		commonData.setSessionId(sessionId);
		commonData.setUserAgent(userAgent);
		commonData.setGdwOrigin(gdwOrigin);
		
		return commonData;
	}

	private void setSecurityLogs(HttpServletRequest httpServletRequest, AuthenticationData authenticationData,
		  IGenericSession genericSession, User user, boolean isSavedCan) {
		  MBAppHelper appHelper = new MBAppHelper();
		  authenticationData.setSessionId(genericSession.getId());
		  authenticationData.setUserAgent(replaceString(httpServletRequest.getHeader("user-agent")));
		  authenticationData.setRefWebsite(httpServletRequest.getHeader("referer"));
		  if(isSavedCan) {
			  appHelper.addSecurityLogSkipSecNum(user, authenticationData);
		  }else {
			  appHelper.addSecurityLog(user, authenticationData);
		  }
	}

	private Customer getCustomerLite(IBankCommonData ibankCommonData,IGenericSession genericSession) throws BusinessException {
		Customer customer = (Customer) genericSession.getAttribute(CUTSOMER_OBJ);
		if(null == customer) {
			  Logger.info(" getLiteCustomer: customer object could not be retrieved from genericSession. ", this.getClass());
			  customer = getCustomer(ibankCommonData, LITE);
		  }
		return customer;
	}

	private User setUserOrigin(String origin, IGenericSession genericSession) {
		User user;
		user = genericSession.getUser();
		  if(null!= user){
			  Logger.debug("LogonUtilController: getLiteCustomer - setting origin in User", this.getClass());
			  user.setAttribute(IBankParams.USEROBJ_BRAND, origin);
		  }
		return user;
	}

	private void setSessionAttributes(String origin, IGenericSession genericSession) {
		genericSession.setAttribute(LogonHelper.ORIGIN, origin);
		  genericSession.setAttribute(LogonHelper.BROWSER_NAME, MBAppConstants.WEB_SRV);
		  genericSession.setAttribute(LITE, true);
	}

	// Check the value of State attribute i.e. DesktopMobileState
	// It should be 1 otherwise throw an exception
	// If value is 1, set it as 2
	private String setStateInMobileSession(MobileSession mbSession, String loggingMethodName) throws BusinessException {
		StringBuffer logMsg = new StringBuffer("LogonUtilControllerV1 - ").append(loggingMethodName);
		 String mbLiteState = null;
		if(null != mbSession){        		    		  
			  if(null != mbSession.getState()){
				  mbLiteState = mbSession.getState();
				  Logger.debug(logMsg.append("mbLiteState ::  ").append(mbLiteState).toString(), this.getClass());
			  } 
			          		  
			  if(null == mbLiteState){
				  Logger.error(logMsg.append("mbLiteState ::  ").append("is NULL ").toString(), this.getClass());
				  throw new BusinessException(BusinessException.SYSTEM_UNAVILABLE);
			  }
			  
		  }else{
			  Logger.debug(logMsg.append(" mbSession is null. ").toString(), this.getClass());
		  }
		
		  if(null != mbLiteState) {
			  if(mbLiteState.equals(MBAppConstants.STATE_GOING_TO_MOBILE)){
				  mbSession.setState(MBAppConstants.STATE_MOBILE);
				  Logger.debug(logMsg.append("mbLiteState ::  ").append(" changed to 2:: ").toString(), this.getClass());
			  }
			  else {
				  Logger.error(logMsg.append(" :: Invalid state. ").toString(), this.getClass());
				  throw new BusinessException(BusinessException.SYSTEM_UNAVILABLE);
			  }
		  }
		  return mbLiteState;
	}

	private String checkDemoSecurityKey(HttpServletRequest httpServletRequest, final LogonReq req, final String callingMethodName)
			throws BusinessException {
		String origin;
		boolean isDemo = LogonHelper.isDemo();
		 origin = LogonHelper.getOrigin(httpServletRequest, isDemo,callingMethodName);
		 if (isDemo)
		 {
		    checkDemoSecurityKey( req.getPassword());    
		 }
		return origin;
	}

	

	private IMBResp populateServiceStationDetailsInResponse(HttpServletRequest httpServletRequest,
			HttpServletResponse httpServletResponse, int unreadMsgCount, User user, MobileSession mobileSession,
			IBankCommonData ibankCommonData, Customer customer) throws BusinessException {
		long insertionPt = logonHelper.getInsertionPointCode(ServicetationConstants.DASHBOARD);
		ServiceStationVO servicestationVO=populateServiceMessage(insertionPt,ServiceStationImpl.CHANNEL_MOBILE, ibankCommonData);		
		if(null!=servicestationVO)
		{
			mobileSession.setServiceStationDashboardMessage(servicestationVO.getServiceStationMsg());
		}
		//19E4 Fix: Service station tile not showing when user navigates back from products
		IMBResp serviceResponse = logonHelper.populateResponse(customer, user, unreadMsgCount, httpServletRequest, httpServletResponse, false,servicestationVO,null);
		//19E4 Fix End: Service station tile not showing when user navigates back from products
		((LogonResp) serviceResponse).setChangePwdAndSecNumReqd(false);
		((LogonResp) serviceResponse).setChangePwdReqd(false);
		((LogonResp) serviceResponse).setAutoInitPwdSecNumChng(false);
		return serviceResponse;
	}

	private Customer getCustomer(MobileSession mobileSession, IBankCommonData ibankCommonData)
			throws BusinessException {
		Customer customer = mobileSession.getCustomer();
					
		if (customer ==  null) {
			Logger.info("***loadCustomer Customer from Session is NULL: Calling 360" , this.getClass());
			customer = getCustomer(ibankCommonData, "mbAppLogon");
		}
		
		if (null != customer) {
		  ibankCommonData.setCustomer(customer);
		}
		return customer;
	}
	
	private boolean populateMadisonSplashResp(IMBResp serviceResponse, String origin, String splashType, String learnMoreLink, String appLink) {
		SplashPageResp splashPageResp = new SplashPageResp();
		splashPageResp.setSplashType(splashType);
		splashPageResp.setLearnMoreLink(learnMoreLink);
		splashPageResp.setAppLink(appLink);
		return setCustomerSplashPageResp(serviceResponse, splashPageResp);
	}
	private static String replaceDigits(String text, String maskChar) {
        StringBuffer buffer = new StringBuffer(text.length());
        Pattern pattern = Pattern.compile("\\d");
        Matcher matcher = pattern.matcher(text);
        while (matcher.find()) {
            matcher.appendReplacement(buffer, maskChar);
        }
        return buffer.toString();
    }
	/*
     * Method to mask crn value in the schedule response
     * 
     */
	private String maskValue(String serviceResponseForMasking) {
		try {

			String[] srvResp = serviceResponseForMasking.split(",");

			for (int i = 0; i < srvResp.length; i++) {

				if ((!StringUtils.isEmpty(srvResp[i])) && srvResp[i].contains("\"crn\"")) {
					int ind = srvResp[i].indexOf("\"crn\"");
					int lastIndex = srvResp[i].lastIndexOf("\"");
					String tempMask = srvResp[i].substring(ind + 7, lastIndex);
					if ((!StringUtils.isEmpty(tempMask)) && tempMask.length() > 10) {
						srvResp[i] = "\"crn\":" + "\"" + StringUtil.maskCrnValue(tempMask, "X") + "\"";
					}
				}
			}
			String serviceResponseAfterMasking = StringUtils.join(srvResp, ",");
			return serviceResponseAfterMasking;
		} catch (Exception e) {
			Logger.info("Error while masking CRN value ", this.getClass());
			return serviceResponseForMasking;
		}

	}
	/*
     * Method to mask crn value in the schedule response
     * 
     */
	private String maskAccountNumValue(String serviceResponseForMasking) {
		perfLogger.startLog("maskAccountNumValue");
		try {
			String[] srvResp = serviceResponseForMasking.split(",");

			for (int i = 0; i < srvResp.length; i++) {

				if ((!StringUtils.isEmpty(srvResp[i])) && srvResp[i].contains("\"accountType\":\"CRA\"")) {
					int actNumIndex = i + 1;
					int actNumDispIndex = i + 3;

					if ((!StringUtils.isEmpty(srvResp[actNumIndex]))) {

						String srvRespMask = srvResp[actNumIndex].substring(14, srvResp[actNumIndex].length() - 1);
						int lengthStr = srvRespMask.length();
						if (lengthStr == 16) {
							String tempStringMasking = replaceDigits(srvRespMask.substring(4, lengthStr - 4), "x");

							srvResp[actNumIndex] = "\"accountNum\":" + "\"" + srvRespMask.substring(0, 4)
									+ tempStringMasking + srvRespMask.substring(lengthStr - 4) + "\"";
						}
					}
					if ((!StringUtils.isEmpty(srvResp[actNumDispIndex]))) {
						String srvRespMask = srvResp[actNumDispIndex].substring(18, srvResp[actNumDispIndex].length() - 3);
						int lengthStr = srvRespMask.length();
						if (lengthStr == 19) {
							String tempStringMasking = replaceDigits(srvRespMask.substring(4, lengthStr - 5), "x");

							srvResp[actNumDispIndex] = "\"accountNumDisp\":" + "\"" + srvRespMask.substring(0, 5)
									+ tempStringMasking + srvRespMask.substring(lengthStr - 5) + "\"";
						}
					}
				}
			}
			String serviceResponseAfterMasking = StringUtils.join(srvResp, ",");
			return serviceResponseAfterMasking;
		} catch (Exception e) {
			Logger.info("Error while masking accountNum value ", this.getClass());
			return serviceResponseForMasking;
		} finally{
			perfLogger.endLog("maskAccountNumValue");
		}

	}
	
	private void safiChallengeWithoutPhoneNumber(Customer customer, String safiAction,	DigitalSecLogggerVO digitalSecLoggerVO, final String callingMethodName) throws BusinessException {
		if(logonHelper.isSafiChallenge(safiAction) && !hasSecureCodeConstraints(customer)){
			boolean phoneNumAvailable = SafiWebHelper.isPhoneNumberAvailable(customer.getContactDetail());
			if(!phoneNumAvailable){
				Logger.debug("SAFI : LogonUtilController: " + callingMethodName + ": Phone Number not available....Exception "+" GCISNumber: "+customer.getGcis(), this.getClass());
				logDigiLogFailure(digitalSecLoggerVO);
				throw new BusinessException(BusinessException.IBANK_SECURE_NO_PHONE_EXIST);
			}
		}
	}
	
	private void logDigiLogFailure(DigitalSecLogggerVO digitalSecLoggerVO) {
		digitalSecLoggerVO.setStatus(DigitalSecLogger.FAILURE);
		digitalSecurityLogger.log(digitalSecLoggerVO);
	}
	private OnboardingVO setOnBoardingSteps(String onboardingQZSession, User user, MobileSession mobileSession,
			IBankCommonData ibankCommonData, Customer customer, OnboardingVO onboardingVO, boolean isAndroid)
			throws BusinessException {
		OnboardingVO oldOnboarding;
		oldOnboarding = (OnboardingVO)SerializationUtils.clone(onboardingVO);
		if("SPIKETC".equalsIgnoreCase(onboardingVO.getTicket()))
		{
			Logger.info("T & C Not displayed for " + mobileSession.getUser().getUserId() ,this.getClass());
			mobileSession.setOnboardingVO(null);
			setOnOnboardingSteps(oldOnboarding);

			throw new BusinessException(BusinessException.COOKIES_NOT_FOUND, "T & C Not displayed for " + mobileSession.getUser().getUserId());
		}else if("SPIKEAPP".equalsIgnoreCase(onboardingVO.getTicket()))
		{
			setOnOnboardingSteps(oldOnboarding);
		} else {
			// Call Eligibiliy services here
			Logger.info("Eligibility service calls starts.", LogonUtilController.class);
			
			setOnBoardingEligibiltySteps(isAndroid, onboardingQZSession, user, oldOnboarding,ibankCommonData, customer);
			mobileSession.setOnboardingVO(onboardingVO);
		}
		return oldOnboarding;
	}

	private void setOnBoardingEligibiltySteps(boolean isAndroid, String onboardingQZSession,
			User user, OnboardingVO oldOnboarding, IBankCommonData ibankCommonData, Customer customer) {
		perfLogger.startLog("Onboarding_Eligibility");
		setOnBoardingQuickZoneEligibility(onboardingQZSession, user, oldOnboarding, customer);
		setOnBoardingPushEligibility(isAndroid, oldOnboarding, customer);
		setOnBoardingEstatementEligibility(oldOnboarding, ibankCommonData, customer);	
		Logger.info("Eligibility service calls ends.", LogonUtilController.class);
		perfLogger.endLog("Onboarding_Eligibility");
	}

	private void setOnBoardingEstatementEligibility(OnboardingVO oldOnboarding, IBankCommonData ibankCommonData,
			Customer customer) {
		boolean processEstatements;
		String eStmtStatus;
		if(customer.isCustomerOfTypeGHS() && customer.hasEmail()){
			try	{
				processEstatements = tpsThrottlingService.processRequest();
				if(processEstatements){
					perfLogger.startLog("ESTMT_Eligibility");
					eStmtStatus = onboardingService.getEStatemsntEligibilityStatus(customer, ibankCommonData);
					oldOnboarding.setStep(new OnboardingStep(OB_STEP_ESTMT,OB_STEPNAME_E_STATEMENTS,false,eStmtStatus));
					perfLogger.endLog("ESTMT_Eligibility");
				}
			}catch(BusinessException e){
				Logger.info("BusinessException in EStatement Eligibility service.", LogonUtilController.class);
			}catch(Exception e){
				Logger.error("Exception caught while checking Eligibility for EStatement : ", e, LogonUtilController.class);
			}
		}
	}

	private void setOnBoardingPushEligibility(boolean isAndroid, OnboardingVO oldOnboarding,
			Customer customer) {
		String pushStatus;
		try	{
			perfLogger.startLog("Push_Eligibility");
			pushStatus = onboardingService.getPushNotificationEligibilityStatus(customer);
			oldOnboarding.setStep(new OnboardingStep(OB_STEP_PUSH,OB_STEPNAME_NOTIFICATIONS, !isAndroid,pushStatus));
			perfLogger.endLog("Push_Eligibility");
		}catch(BusinessException e){
			Logger.info("BusinessException in Push Notification Eligibility service.", LogonUtilController.class);
		}catch(Exception e){
			Logger.error("Exception caught while checking Eligibility for Push Notification : ", e, LogonUtilController.class);
		}
	}

	private void setOnBoardingQuickZoneEligibility(String onboardingQZSession, User user, OnboardingVO oldOnboarding,
			Customer customer) {
		String qzStatus;
		try	{
			perfLogger.startLog("QZ_Eligibility");
			qzStatus = onboardingService.getQuickZoneEligibilityStatus(customer,user);
			if(qzStatus.equalsIgnoreCase(OB_STATUS_ELIGIBLE)) {
				onboardingQZSession = onboardingService.getQuickZoneSessionForEligibleCustomer(user);
			}
			oldOnboarding.setStep(new OnboardingStep(OB_STEP_QZ,OB_STEPNAME_QUICK_ZONE, true,qzStatus, onboardingQZSession));
			perfLogger.endLog("QZ_Eligibility");
		}catch(BusinessException e){
			Logger.info("BusinessException in QuickZone Eligibility service.", LogonUtilController.class);
		}catch(Exception e){
			Logger.error("Exception caught while checking Eligibility for QuickZone : ", e, LogonUtilController.class);
		}
	}

	private void setOnOnboardingSteps(OnboardingVO oldOnboarding) {
		oldOnboarding.setStep(new OnboardingStep(OB_STEP_SL,OB_STEPNAME_SIMPLIFIED_SIGN_IN, true, OB_STATUS_ELIGIBLE));
		oldOnboarding.setStep(new OnboardingStep(OB_STEP_QZ, OB_STEPNAME_QUICK_ZONE, true,OB_STATUS_ELIGIBLE,"session"));
		oldOnboarding.setStep(new OnboardingStep(OB_STEP_PUSH,OB_STEPNAME_NOTIFICATIONS, true,OB_STATUS_ELIGIBLE) );
		oldOnboarding.setStep(new OnboardingStep(OB_STEP_ESTMT,OB_STEPNAME_E_STATEMENTS,true,"INELIGIBLE") );
	}

	String getMaskedCustomerEmailAddress(Customer customer) {
		String masked = null;
		if(null!=customer.getContactDetail() && null!=customer.getContactDetail().getEmail()) {
			String email_unmasked=customer.getContactDetail().getEmail();
			masked = email_unmasked.replaceAll("(?<=.{2}).(?=[^@]*?.{2}@)", "*");
		}
		return masked;
	}

	private boolean isAutoInitAdmin(String autoInitStatus) {
		return !StringMethods.isEmptyString(autoInitStatus) && autoInitStatus.equalsIgnoreCase(IBankParams.AUTO_INIT_ADMIN);
	}

	private ServiceStationVO setDashBoardServiceStationMsgInSession(MobileSession mobileSession,
			IBankCommonData ibankCommonData) {
		long insertionPt = logonHelper.getInsertionPointCode(ServicetationConstants.DASHBOARD);
		ServiceStationVO servicestationVO=populateServiceMessage(insertionPt,ServiceStationImpl.CHANNEL_MOBILE, ibankCommonData);
		if(null!=servicestationVO)
		{
			mobileSession.setServiceStationDashboardMessage(servicestationVO.getServiceStationMsg());
		}
		return servicestationVO;
	}
	
	private String processReactivateRequest(HttpServletRequest httpServletRequest, IGenericSession genericSession, LogonReq req, IBankCommonData commonData, IGenericSession ibankSession) throws BusinessException
	{
		try
		{
			//Get devicePrint
			String validDecodedPrint = SafiUtil.validateDevicePrint(req.getDevicePrint());
			String devicePrint = validDecodedPrint != null ? req.getDevicePrint() : null;

			//Check for deep link actionType and throw error
			String actionType = null;
			if(httpServletRequest.getAttribute(MainController.REQ_ACTION_TYPE) != null) {
				actionType = (String) httpServletRequest.getAttribute(MainController.REQ_ACTION_TYPE);
			}
			//String actionType = req.getActionType();
			Logger.info("LogonController:processReactivateRequest(): actionType:"+actionType+",....GCISNumber: "+commonData.getCustomer().getGcis(), this.getClass());
			if(!StringUtils.isEmpty(actionType)) {
				Logger.warn("LogonController:processReactivateRequest(): Deeplink request identified with actionType:"+actionType+",....GCISNumber: "+commonData.getCustomer().getGcis(), this.getClass());
				throw new BusinessException(BusinessException.INVALID_USERID_PASSWORD);
			}
			
			//Validate phone number
			boolean phoneNumAvailable = SafiWebHelper.isPhoneNumberAvailable(commonData.getCustomer().getContactDetail());
			if(!phoneNumAvailable){
				Logger.warn("LogonController:processReactivateRequest(): Phone Number not available....GCISNumber: "+commonData.getCustomer().getGcis(), this.getClass());
				throw new BusinessException(BusinessException.INVALID_USERID_PASSWORD);
			}
			
			boolean hasSecureCodeConstraints =hasSecureCodeConstraints(commonData.getCustomer()); 
			if ( !  hasSecureCodeConstraints )
			{
				//Call SAFI Analyse
				Safi2Service safi2Service = ServiceHelper.getBean("safi2Service");
				SafiReactivateOnlineVO safiReactivateOnlineVO = SafiWebHelper.populateSafiReactivateOnlineVO(httpServletRequest , devicePrint, commonData, false);
				SafiRespVO safiRespVO = safi2Service.analyzeSafiForReactivateOnline(commonData, safiReactivateOnlineVO);
				Logger.debug("LogonController:processReactivateRequest():  1.Safi data - devicePrint:"+devicePrint, this.getClass());

				String safiAction = null;
				if(safiRespVO != null) {
					safiAction = safiRespVO.getSafiAction();
					SafiLogonInfo safiLogonInfo = setSafiLogonInfo(safiRespVO, safiAction, devicePrint);
					genericSession.setAttribute(MobileSessionImpl.SAFI_LOGON_INFO, safiLogonInfo);
					Logger.debug("LogonController:processReactivateRequest(): . safiLogonInfo is set to session -  safiLogonInfo:"+safiLogonInfo, this.getClass());
				}
				Logger.info("SAFI : LogonAction - processReactivateRequest(): Safi response : "+safiAction+"hasSecureCodeConstraints: "+hasSecureCodeConstraints,this.getClass());

				/*
				if(safiRespVO == null || safiAction == null || !SafiConstants.SAFI_ACTION_CHALLENGE.equals(safiAction)) { //TODO ADDED FOR TESTING - TO BE REMOVED - BEGIN
					safiAction = SafiConstants.SAFI_ACTION_CHALLENGE;
					Logger.info("SAFI : LogonAction - processReactivateRequest(): ***** HARD CODED FOR TESTING ******* Safi response : "+safiAction+"hasSecureCodeConstraints: "+hasSecureCodeConstraints,this.getClass());
				} //TODO ADDED FOR TESTING - TO BE REMOVED - END 
				*/
				
				//Add Forensic log for SAFI call
				String safiStatus = DigitalSecLogger.FAILURE;
				SafiForensicInfo safiForensicInfo = null;
				if(!StringMethods.isEmptyString(safiAction) && safiRespVO != null) {
					Logger.debug("SAFI : Populating safiForensicInfo for Reactivate Online Flow", this.getClass());
					safiStatus = DigitalSecLogger.SUCCESS;
					safiForensicInfo= new SafiForensicInfo();
					safiForensicInfo.setSafiRiskScore(safiRespVO.getSafiRiskScore() != null ? safiRespVO.getSafiRiskScore().toString():null);
					safiForensicInfo.setSafiRuleName(safiRespVO.getSafiRuleName());
					safiForensicInfo.setSafiAction(safiAction);
				}
				Logger.debug("SAFI : Populating Safi digitalSecLoggerVO for Reactivate Online Flow", this.getClass());
				DigitalSecLogggerVO digitalSecLoggerVO = new DigitalSecLogggerVO();
				digitalSecLoggerVO.setStatus(safiStatus);
				digitalSecLoggerVO.setTranName(DigitalSecLogger.SAFI_TRAN_NAME_LOGON_OTP_ANALYSE);
				digitalSecLoggerVO.setValues(logonHelper.toDigitalSecuritySafiLog(safiForensicInfo));
				digitalSecLoggerVO.setCommonLogData(logonHelper.getCommonLogData(req,commonData,null));
				digitalSecLoggerVO.setUserAgent(commonData.getUserAgent());
				digitalSecurityLogger.log(digitalSecLoggerVO); 

				//Return SAFI response if it is a CHALLENGE outcome
				if(!StringMethods.isEmptyString(safiAction) && SafiConstants.SAFI_ACTION_CHALLENGE.equalsIgnoreCase(safiAction)) {
					return safiAction;
				}
			}
			else
			{
				Logger.info(" LogonAction - processReactivateRequest(): hasSecureCodeConstraints: "+hasSecureCodeConstraints,this.getClass());
			}
		}
		catch ( Exception e)
		{
			Logger.warn("Error in processReactivateRequest ",  e , this.getClass());
		}
		try
		{
			ibankSession.setAttribute(MobileSessionImpl.CUSTOMER_OBLECT, null);
			ibankSession.setUser(null);
			commonData.setCustomer(null);
	//		ibankSession.invalidate();
		}
		catch ( Exception e)
		{
			Logger.warn("Error in invalidate session ",  e , this.getClass());
		}
		
		
		throw new BusinessException ( BusinessException.INVALID_USERID_PASSWORD, "Reactivate failed" );
		
	}
	
  public static boolean isCustomerOTPAuthVerified(MobileSession mobileSession) throws BusinessException
  {
  
        if ( !  ReactivateOnlineServiceImpl.isCustomerReactivateSwitchOn(mobileSession.getOrigin()) )
	    {
	    	return true;
	    }
        
	    User user = mobileSession.getUser();
	    
	    if ( user.getAttribute(  IBankParams.CUSTOMER_AUTHENTICATED_FLAG  ) !=null )
	    {
		    if ( IBankParams.NO.equalsIgnoreCase( (String) user.getAttribute(  IBankParams.CUSTOMER_AUTHENTICATED_FLAG  )))
		    {
		    	Logger.error("OTP NOT Verified. OTP flag for Customer "+ user.getUserId() + "  is "+ (String) user.getAttribute(  IBankParams.CUSTOMER_AUTHENTICATED_FLAG  ), LogonUtilController.class);
		    	mobileSession.invalidateSession();
		    	throw new BusinessException(BusinessException.SYSTEM_UNAVILABLE,"OTP Verified flag for Customer "+ user.getUserId() + "  is  "+ (String) user.getAttribute(  IBankParams.CUSTOMER_AUTHENTICATED_FLAG  ) );
		    }
	    }

	    return true;
  }
  
  @RequestMapping("/keepsessionalive")
  @ResponseBody
  public IMBResp keepsessionalive(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, @RequestBody final EmptyReq request)
	{
		try
		{
			Logger.debug("/keepsessionalive request - " + request, this.getClass() );
			mbAppValidator.validateRequestHeader(request.getHeader(), httpServletRequest);
			MBAppHelper appHelper = new MBAppHelper();
			MobileSession mobileSession = appHelper.getMobileSession(httpServletRequest);
			Logger.debug("Keep Session Alive. Name ID " + mobileSession.getSecurityUniqueID() + " Prev :"+ mobileSession.getSecurityUniqueIDPrevious() , this.getClass());
			httpServletResponse.setHeader("Connection", "close");
			
			IMBResp response = new EmptyResp();
			response.setHeader(mbAppHelper.populateResponseHeader("keepsessionalive", mobileSession));

			return  response;
		}
		catch ( Exception e)
		{
			Logger.error("keepsessionalive failed "   , e, this.getClass());
			return  null;
		}
	}	
  
  
  	@RequestMapping("/getCAN")
	@ResponseBody
	public IMBResp getCAN(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, @RequestBody final ApplicationReq request){
		MobileSession mobileSession = null;
		String accessNumber = " ";
		try{
			mbAppValidator.validateRequestHeader(request.getHeader(), httpServletRequest);
			mobileSession = mbAppHelper.getMobileSession(httpServletRequest);
			String  origin = mobileSession.getOrigin();
			Logger.info("origin for show access number : " + origin,  this.getClass());
			//19E4 Tech Debt Start:Switch Removal
			/*boolean showAccessNumberSwitch = true;
			CodesVO codesVo = IBankParams.getCodesData(origin, IBankParams.CONFIGURATION_PROPERTIES, IBankParams.SHOW_ACCESS_NUMBER_SWTICH);
			if(codesVo != null){
				showAccessNumberSwitch = IBankParams.ON.equalsIgnoreCase(codesVo.getMessage()) ? true: false;
			}
			if(showAccessNumberSwitch){*/
				accessNumber = mobileSession.getUser().getUserId();
				if(!StringMethods.isEmptyString(accessNumber)){
					accessNumber = accessNumber.replaceFirst("^0+(?!$)", "");
					accessNumber =   accessNumber.replaceFirst("(\\d+)(\\d{4})", "$1 $2");
				}
			/*}
			else{
				Logger.info("show access number switch is off : ",  this.getClass());
			}*/
				//19E4 Tech Debt End:Switch Removal
		}
		catch(Exception e){
			Logger.error("Error getting accessNumber : ", e, this.getClass());
		}
		CanNumResp canNumResp = new CanNumResp();
		RespHeader headerResp = populateResponseHeader(ServiceConstants.CAN_NUM_RESPONSE, mobileSession);
		canNumResp.setHeader(headerResp);
		canNumResp.setCanNum(accessNumber);
		
		return canNumResp;
	}
}
