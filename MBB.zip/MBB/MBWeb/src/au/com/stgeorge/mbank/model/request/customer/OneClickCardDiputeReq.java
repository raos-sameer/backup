package au.com.stgeorge.mbank.model.request.customer;

import java.io.Serializable;
import au.com.stgeorge.ibank.valueobject.TransactionInfo;
import au.com.stgeorge.mbank.model.common.IMBReq;
import au.com.stgeorge.mbank.model.common.ReqHeader;

public class OneClickCardDiputeReq implements IMBReq, Serializable {

   
  private static final long serialVersionUID = -256469501889499119L;
  
  
  private String  accountNumber;
  private String  bsb;
  private String amount;
  private String tranDesc1;
  private String transID;
  private String channel;
  private String cardType;
  private String disputeSource;
  private String transDate;
  private String tranDesc2;
  
  
public String getTranDesc2() {
	return tranDesc2;
}
public void setTranDesc2(String tranDesc2) {
	this.tranDesc2 = tranDesc2;
}
public String getAccountNumber() {
 	return accountNumber;
 }
 public void setAccountNumber(String accountNumber) {
 	this.accountNumber = accountNumber;
 }
 public String getBsb() {
 	return bsb;
 }
 public void setBsb(String bsb) {
 	this.bsb = bsb;
 }
 public String getAmount() {
 	return amount;
 }
 public void setAmount(String amount) {
 	this.amount = amount;
 }
 public String getTranDesc1() {
 	return tranDesc1;
 }
 public void setTranDesc1(String tranDesc1) {
 	this.tranDesc1 = tranDesc1;
 }
 public String getTransID() {
 	return transID;
 }
 public void setTransID(String transID) {
 	this.transID = transID;
 }
 public String getChannel() {
 	return channel;
 }
 public void setChannel(String channel) {
 	this.channel = channel;
 }
 public String getCardType() {
 	return cardType;
 }
 public void setCardType(String cardType) {
 	this.cardType = cardType;
 }
 public static long getSerialversionuid() {
 	return serialVersionUID;
 }

  private ReqHeader header;

  public ReqHeader getHeader() {
    return header;
  }
  public void setHeader(ReqHeader header) {
    this.header = header;
  }
  public String getDisputeSource() {
 	return disputeSource;
 }
 public void setDisputeSource(String disputeSource) {
 	this.disputeSource = disputeSource;
 }
public String getTransDate() {
	return transDate;
}
public void setTransDate(String transDate) {
	this.transDate = transDate;
}
 
 
 
}
