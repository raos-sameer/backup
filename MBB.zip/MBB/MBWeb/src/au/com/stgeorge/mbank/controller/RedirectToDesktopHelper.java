package au.com.stgeorge.mbank.controller;

import au.com.stgeorge.mbank.model.common.IMBResp;
import au.com.stgeorge.mbank.model.response.services.RedirectDeskResp;

/**
 * 
 * Helper class for RedirectToDesktopController
 *
 */
public class RedirectToDesktopHelper {

	public IMBResp populateResponse(String targetURL){
		
		RedirectDeskResp response = new RedirectDeskResp();
		response.setTargetURL(targetURL);
		
		return response;
	}
}
