package au.com.stgeorge.mbank.model.common;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
@JsonInclude(Include.NON_NULL)
public class SplashPageResp implements Serializable
{

	/**
	 * 
	 */
	private static final long serialVersionUID = 2741909902369994504L;
	private String splashType;
	private boolean showCRSAsTile;
	private String promptType;
	private String expiryDate;
	private String url;// for P2mDecommission FAQs
	private boolean splashPageMaxCountReached; // skip flag
	private String learnMoreLink;
	private String appLink;
	
	private String customerEmail;
	
	public String getCustomerEmail() {
		return customerEmail;
	}

	public void setCustomerEmail(String customerEmail) {
		this.customerEmail = customerEmail;
	}
	
	public String getSplashType() {
		return splashType;
	}
	public void setSplashType(String splashType) {
		this.splashType = splashType;
	}
	public String getPromptType() {
		return promptType;
	}
	public void setPromptType(String promptType) {
		this.promptType = promptType;
	}

	public String getExpiryDate() {
		return expiryDate;
	}
	public void setExpiryDate(String expiryDate) {
		this.expiryDate = expiryDate;
	}
	public boolean isShowCRSAsTile() {
		return showCRSAsTile;
	}
	public void setShowCRSAsTile(boolean showCRSAsTile) {
		this.showCRSAsTile = showCRSAsTile;
	}
	public String getUrl() {
		return url;
	}
	public void setUrl(String url) {
		this.url = url;
	}
	public boolean isSplashPageMaxCountReached() {
	    return splashPageMaxCountReached;
	}
	public void setSplashPageMaxCountReached(boolean splashPageMaxCountReached) {
	    this.splashPageMaxCountReached = splashPageMaxCountReached;
	}
	public String getLearnMoreLink() {
		return learnMoreLink;
	}
	public void setLearnMoreLink(String learnMoreLink) {
		this.learnMoreLink = learnMoreLink;
	}
	public String getAppLink() {
		return appLink;
	}
	public void setAppLink(String appLink) {
		this.appLink = appLink;
	}
	
}
