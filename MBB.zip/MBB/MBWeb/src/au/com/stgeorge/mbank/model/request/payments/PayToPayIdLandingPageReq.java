package au.com.stgeorge.mbank.model.request.payments;

import au.com.stgeorge.mbank.model.common.IMBReq;
import au.com.stgeorge.mbank.model.common.ReqHeader;

/**
 * @author C82050 
 */
public class PayToPayIdLandingPageReq implements IMBReq {

	private static final long serialVersionUID = -666671547650453403L;
	private ReqHeader header;
	
	@Override
	public ReqHeader getHeader() {
		return header;
	}
	
	@Override
	public void setHeader(ReqHeader header) {
		this.header = header;
	}
}