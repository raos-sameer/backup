package au.com.stgeorge.mbank.controller.customer.ev;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.builder.ReflectionToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import au.com.stgeorge.framework.common.logging.Logger;
import au.com.stgeorge.ibank.businessobject.BusinessException;
import au.com.stgeorge.ibank.businessobject.ResourceException;
import au.com.stgeorge.ibank.common.cache.IBankParams;
import au.com.stgeorge.ibank.evcrs.businessobject.EVService;
import au.com.stgeorge.ibank.evcrs.businessobject.valueobject.EVCRSDetail;
import au.com.stgeorge.ibank.evcrs.businessobject.valueobject.EVCustDetails;
import au.com.stgeorge.ibank.evcrs.businessobject.valueobject.EVForeignCountryDetail;
import au.com.stgeorge.ibank.evcrs.dao.valueobject.EVDetail;
import au.com.stgeorge.ibank.evcrs.util.EVConstants;
import au.com.stgeorge.ibank.evcrs.util.EVStatusEnum;
import au.com.stgeorge.ibank.valueobject.Customer;
import au.com.stgeorge.ibank.valueobject.database.CodesVO;
import au.com.stgeorge.ibank.valueobject.transfer.IBankCommonData;
import au.com.stgeorge.mbank.controller.IMBController;
import au.com.stgeorge.mbank.model.common.IMBReq;
import au.com.stgeorge.mbank.model.common.IMBResp;
import au.com.stgeorge.mbank.model.common.ReqHeader;
import au.com.stgeorge.mbank.model.common.RespHeader;
import au.com.stgeorge.mbank.model.request.EmptyReq;
import au.com.stgeorge.mbank.model.request.customer.ev.EVReq;
import au.com.stgeorge.mbank.model.request.customer.ev.ReIDVReq;
import au.com.stgeorge.mbank.model.response.ErrorResp;
import au.com.stgeorge.mbank.model.response.SuccessResp;
import au.com.stgeorge.mbank.session.MobileSession;
import au.com.stgeorge.mbank.util.MBAppHelper;
import au.com.stgeorge.mbank.util.MBAppUtils;
import au.com.stgeorge.mbank.util.MBAppValidator;
import au.com.stgeorge.mbank.util.ServiceConstants;
import au.com.stgeorge.perflogger.PerformanceLogger;

import com.fasterxml.jackson.databind.ObjectMapper;
@Controller
@RequestMapping("/ev")
public class EVController implements IMBController{

	@Autowired
	private MBAppHelper mbAppHelper;
	
	@Autowired
	private MBAppValidator mbAppValidator;

	@Autowired
	private EVService evService;
	
	@Autowired
	private EVHelper evhelper;
	
	@RequestMapping(value="evDetails", method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public IMBResp getEVDetails (HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse,@RequestBody final EmptyReq req)
	{
		Logger.debug("Inside getEVDetails", this.getClass());
		PerformanceLogger performanceLogger = new PerformanceLogger();
		performanceLogger.startAllLogs();
		String logName = MBAppUtils.getLogName(httpServletRequest);
		performanceLogger.startLog(logName);
		ObjectMapper mapper = new ObjectMapper();
		MobileSession mbSession = null;
		EVCRSDetail crsDetail=new EVCRSDetail();
		List<EVForeignCountryDetail> evForeignCountryDtls=null;
		try
		{
			mbSession = mbAppHelper.getMobileSession(httpServletRequest);		
			Logger.info("getEVDetails JSON Request :" + mapper.writeValueAsString(req), this.getClass());
			validateRequestHeader( req.getHeader(), httpServletRequest );
			
			ErrorResp errorResp = validate(req, httpServletRequest);
			if (errorResp != null && errorResp.getErrors() != null && errorResp.getErrors().size() > 0)
			{
				return errorResp;
			}			
			IBankCommonData ibankCommonData=mbAppHelper.populateIBankCommonData(mbSession,httpServletRequest);	
			
			crsDetail = evService.getCustomerInfo(ibankCommonData);
						
			if(null!=crsDetail){
				if(!crsDetail.isCrsInfoProvided()){
					evForeignCountryDtls=new ArrayList<EVForeignCountryDetail>();
					//evForeignCountryDtls=evService.getForeignCountriesAndTINRegex();
					evForeignCountryDtls=IBankParams.getForeignTINDetails();
				}
			  Logger.debug("Inside getEVDetails::::>", this.getClass());
			  EVCustDetails evCustDetails=new EVCustDetails();					
			  evCustDetails.setCrsInfoRequired(!crsDetail.isCrsInfoProvided());
			  Logger.debug("Before setting in session::::>", this.getClass());
			  mbSession.setEvCustDetails(evCustDetails);
			  Logger.debug("After setting in session::::>", this.getClass());
			}
			IMBResp serviceResponse = evhelper.populateResponse(crsDetail,mbSession,evForeignCountryDtls,ibankCommonData);			
			Logger.info("getEVDetails JSON Response :" + mapper.writeValueAsString(serviceResponse), this.getClass());
			RespHeader headerResp = populateResponseHeader(req.getHeader().getServiceName(), mbSession );
			serviceResponse.setHeader(headerResp);			
			return serviceResponse;
		}
		catch (BusinessException e){
			Logger.info("BusinessException in getEVDetails - [key: " + e.getKey() + "] : GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());
			return MBAppUtils.createErrorResp(mbSession.getOrigin(), e, ServiceConstants.EV_SERVICE, httpServletRequest);
		} 
		catch (ResourceException e){
			Logger.error("ResourceException in getEVDetails- [key: " + e.getKey() + "] : GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());
			return MBAppUtils.createErrorResp(mbSession.getOrigin(), BusinessException.SYSTEM_UNAVILABLE, ServiceConstants.EV_SERVICE, httpServletRequest);
		}
		catch (Exception e){
			Logger.error("Exception in getEVDetails: GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			return MBAppUtils.createErrorResp(mbSession.getOrigin(), BusinessException.SYSTEM_UNAVILABLE, ServiceConstants.EV_SERVICE, httpServletRequest);
		} 
		finally
		{
			performanceLogger.endLog(logName);
			performanceLogger.endAllLogs();
		}
	}
	
	@RequestMapping(value="submitEVDetails", method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public IMBResp submitEVDetails(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse,@RequestBody final EVReq req)
	{
		Logger.debug("Inside submitEVDetails", this.getClass());
		PerformanceLogger performanceLogger = new PerformanceLogger();
		performanceLogger.startAllLogs();
		String logName = MBAppUtils.getLogName(httpServletRequest);
		performanceLogger.startLog(logName);
		MobileSession mbSession = null;
		List<String> responseList=null;
		EVCRSDetail evCRSDetail=new EVCRSDetail();
		List<EVForeignCountryDetail> evForeignCountryDtls=new ArrayList<EVForeignCountryDetail>();
		CRSHelper crsHelper=new CRSHelper();
		au.com.stgeorge.ibank.evcrs.businessobject.valueobject.CRSInfo crsInfoVo=null;
		try
		{
			mbSession = mbAppHelper.getMobileSession(httpServletRequest);
			IBankCommonData ibankCommonData=mbAppHelper.populateIBankCommonData(mbSession,httpServletRequest);
			Customer customer=ibankCommonData.getCustomer();
			validateRequestHeader( req.getHeader(), httpServletRequest );
			
			//evForeignCountryDtls=evService.getForeignCountriesAndTINRegex();
			evForeignCountryDtls=IBankParams.getForeignTINDetails();
			String correlationId = mbSession.getEVThreatMatrixSessionID();
			
			evhelper.validateEVReq(req,evForeignCountryDtls);
			ErrorResp errorResp = validate(req, httpServletRequest);
			if (errorResp != null && errorResp.getErrors() != null && errorResp.getErrors().size() > 0)
			{
				return errorResp;
			}
			
			//get Individual from session
			EVCustDetails evCustDetails = mbSession.getEvCustDetails();
			Logger.debug("EVCustDetails ::>::"+evCustDetails, this.getClass());
			//populate evInfo and CRSInfoVO in valueObj
			au.com.stgeorge.ibank.evcrs.businessobject.valueobject.EVInfo evInfoVo = EVHelper.populateEvInfoVo(req);
			evInfoVo.setCorrelationId(correlationId);
			
			if(null!=evCustDetails){
				Logger.debug("evCustDetails from session not null::::>", this.getClass());
				if(evCustDetails.isCrsInfoRequired()){
					Logger.debug("Going to call populateCRSInfoVo", this.getClass());
					crsInfoVo=crsHelper.populateCRSInfoVo(req.getCrsInfo(),evForeignCountryDtls);
				}
			}
		
			evCRSDetail.setEvInfo(evInfoVo);
			evCRSDetail.setCrsInfo(crsInfoVo);
			if(null!=evCustDetails){
				Logger.debug("evCustDetails from session not null 2::::>", this.getClass());
				evCRSDetail.setCrsInfoProvided(evCustDetails.isCrsInfoRequired());
			}				
			//calling 437 service 
			try{
				responseList = evService.updateCRSAndEVInfo(ibankCommonData,evCRSDetail,evCustDetails);
				IMBResp serviceResponse = evhelper.populateValidateEVResponse(responseList);
				
				if(null!=responseList.get(0) && responseList.get(0).equalsIgnoreCase("ACCEPT"))
				{
				   customer.setEvStatus(EVStatusEnum.VERIFIED.getEVStatus());
				}
				else if(null!=responseList.get(0) && responseList.get(0).equalsIgnoreCase("REJECT"))
				{			
				  if(null!=responseList.get(1) && responseList.get(1).indexOf(EVConstants.EV_MAX_REACHED) != -1)
				  {
					customer.setEvStatus(EVStatusEnum.MAX_ATTEMPT_REACHED.getEVStatus());
				  }
				  else
				  {
					customer.setEvStatus(EVStatusEnum.NOT_VERIFIED.getEVStatus());
					// for not triggering subsequent CRS service calls ,in case of 1st 2nd attempt
					evCustDetails.setCrsInfoRequired(false);
					mbSession.setEvCustDetails(evCustDetails); 
				  }
				}
				RespHeader headerResp = populateResponseHeader(req.getHeader().getServiceName(), mbSession );
				serviceResponse.setHeader(headerResp);			
				return serviceResponse;
			}
			catch(BusinessException ex){
				Logger.info("BusinessException in updateCRSAndEVInfo - [key: " + ex.getKey() + "] : GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", ex,this.getClass());
				return EVHelper.createErrorResp(mbSession, ex ,ServiceConstants.EV_SERVICE, httpServletRequest);
			}			
		}
		catch (BusinessException e){
			Logger.info("BusinessException in checkCRSInfo - [key: " + e.getKey() + "] : GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());
			return MBAppUtils.createErrorResp(mbSession.getOrigin(), e, ServiceConstants.EV_SERVICE, httpServletRequest);
		} 
		catch (ResourceException e){
			Logger.error("ResourceException in checkCRSInfo- [key: " + e.getKey() + "] : GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());
			return MBAppUtils.createErrorResp(mbSession.getOrigin(), BusinessException.SYSTEM_UNAVILABLE, ServiceConstants.EV_SERVICE, httpServletRequest);
		}
		catch (Exception e){
			Logger.error("Exception in checkCRSInfo: GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			return MBAppUtils.createErrorResp(mbSession.getOrigin(), ResourceException.MOBILE_NON_FINANCIAL_FATAL_ERR, ServiceConstants.EV_SERVICE, httpServletRequest);
		} 
		finally
		{
			performanceLogger.endLog(logName);
			performanceLogger.endAllLogs();
		}
	}
	
	@RequestMapping(value="submitReIDVDetails", method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public IMBResp submitReIDVDetails(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse,@RequestBody final ReIDVReq req)
	{
		Logger.debug("Inside submitReIDVDetails", this.getClass());
		PerformanceLogger performanceLogger = new PerformanceLogger();
		performanceLogger.startAllLogs();
		String logName = MBAppUtils.getLogName(httpServletRequest);
		CRSHelper crsHelper=new CRSHelper();
		performanceLogger.startLog(logName);
		MobileSession mbSession = null;
		EVCRSDetail evCRSDetail=new EVCRSDetail();
		au.com.stgeorge.ibank.evcrs.businessobject.valueobject.CustInfo custInfoVO=null;
		au.com.stgeorge.ibank.evcrs.businessobject.valueobject.EVInfo evInfoVo=null;
		au.com.stgeorge.ibank.evcrs.businessobject.valueobject.CRSInfo crsInfoVo=null;
		List<EVForeignCountryDetail> evForeignCountryDtls=new ArrayList<EVForeignCountryDetail>();		
		try
		{
			mbSession = mbAppHelper.getMobileSession(httpServletRequest);
			IBankCommonData ibankCommonData=mbAppHelper.populateIBankCommonData(mbSession,httpServletRequest);
			validateRequestHeader( req.getHeader(), httpServletRequest );
			evForeignCountryDtls=IBankParams.getForeignTINDetails();
			String correlationId = mbSession.getEVThreatMatrixSessionID();
			evhelper.validateReIDVReq(req,evForeignCountryDtls);
			ErrorResp errorResp = validate(req, httpServletRequest);
			if (errorResp != null && errorResp.getErrors() != null && errorResp.getErrors().size() > 0)
			{
				return errorResp;
			}
			
			evInfoVo = EVHelper.populateEvInfoVo_ReIDV(req); 
			crsInfoVo=crsHelper.populateCRSInfoVo(req.getCrsInfo(),evForeignCountryDtls);
			custInfoVO=EVHelper.populateCustInfo(req);
			evInfoVo.setCorrelationId(correlationId);
			evCRSDetail.setEvInfo(evInfoVo);
			evCRSDetail.setCrsInfo(crsInfoVo);
			evCRSDetail.setCustInfo(custInfoVO);			
			evCRSDetail.setMessageId(correlationId);
			evCRSDetail.setCrsInfoProvided(true);
			
			String origin = mbSession.getOrigin();
			if ((origin.equalsIgnoreCase("MBSGD"))||(origin.equalsIgnoreCase("MBSA"))|| (origin.equalsIgnoreCase("MPSA"))) 
			{
               evCRSDetail.setClientRefId("BSA_Everyday Banking_Complete Freedom");
            }
			else if(origin.equalsIgnoreCase("MBOM")|| origin.equalsIgnoreCase("MBOMG"))
			{
               evCRSDetail.setClientRefId("BOM_Everyday Banking_Complete Freedom");
            }                 
            else
            {
               evCRSDetail.setClientRefId("SGB_Everyday Banking_Complete Freedom");
            }
			
			try{
				evService.updateCRSAndEVInfoReIDV(ibankCommonData,evCRSDetail);				
				SuccessResp successResp = new SuccessResp();																			
				RespHeader headerResp = populateResponseHeader(req.getHeader().getServiceName(), mbSession );
				successResp.setHeader(headerResp);
				successResp.setIsSuccess(true);	
				return successResp;
			}
			catch(BusinessException ex){
				return MBAppUtils.createErrorResp(mbSession.getOrigin(), ex, ServiceConstants.EV_SERVICE, httpServletRequest);
			}			
		}
		catch (BusinessException e){
			Logger.info("BusinessException in submitReIDVDetails - [key: " + e.getKey() + "] : GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());
			return MBAppUtils.createErrorResp(mbSession.getOrigin(), e, ServiceConstants.EV_SERVICE, httpServletRequest);
		} 
		catch (ResourceException e){
			Logger.error("ResourceException in submitReIDVDetails- [key: " + e.getKey() + "] : GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());
			return MBAppUtils.createErrorResp(mbSession.getOrigin(), BusinessException.SYSTEM_UNAVILABLE, ServiceConstants.EV_SERVICE, httpServletRequest);
		}
		catch (Exception e){
			Logger.error("Exception in submitReIDVDetails: GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			return MBAppUtils.createErrorResp(mbSession.getOrigin(), ResourceException.MOBILE_NON_FINANCIAL_FATAL_ERR, ServiceConstants.EV_SERVICE, httpServletRequest);
		} 
		finally
		{
			performanceLogger.endLog(logName);
			performanceLogger.endAllLogs();
		}
	}
	
	public ErrorResp validate(IMBReq serviceRequest, HttpServletRequest request) {
		Logger.info("Service request object - " + ReflectionToStringBuilder.toString(serviceRequest), this.getClass());
		return mbAppValidator.validate(serviceRequest, request);
	}

	public void validateRequestHeader(ReqHeader headerReq, HttpServletRequest request) throws BusinessException {
		Logger.debug("Request header validation: " + ReflectionToStringBuilder.toString(headerReq, ToStringStyle.MULTI_LINE_STYLE), this.getClass());
		mbAppValidator.validateRequestHeader(headerReq, request);
	}
	

	public RespHeader populateResponseHeader(String serviceName, MobileSession mobSession) {
		return mbAppHelper.populateResponseHeader(serviceName, mobSession);
	}
	
	@RequestMapping(value="reIDVDetails", method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public IMBResp getReIDVDetails (HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse,@RequestBody final EmptyReq req)
	{
		Logger.debug("Inside getReIDVDetails", this.getClass());
		IMBResp serviceResponse=null;
		PerformanceLogger performanceLogger = new PerformanceLogger();
		performanceLogger.startAllLogs();
		String logName = MBAppUtils.getLogName(httpServletRequest);
		performanceLogger.startLog(logName);
		ObjectMapper mapper = new ObjectMapper();
		MobileSession mbSession = null;
		EVCRSDetail crsDetail=new EVCRSDetail();
		List<EVForeignCountryDetail> evForeignCountryDtls=null;
		EVDetail evDetail=null;
		boolean isReIDVEligible=false;
		try
		{
			mbSession = mbAppHelper.getMobileSession(httpServletRequest);
			
			if(mbSession.getOrigin().equalsIgnoreCase("MASG") || mbSession.getOrigin().equalsIgnoreCase("MASGD") || mbSession.getOrigin().equalsIgnoreCase("ASG")){
				throw new BusinessException(BusinessException.ASG_REIDV_ERROR);
			}
			
            boolean reIdvCompleted = false;
            if ( mbSession.getEvCustDetails() == null && evService.isReIdvSwitchON(mbSession.getOrigin()) )
            {
            	isReIDVEligible=true;
            }
            else
            {
            	isReIDVEligible=mbSession.getEvCustDetails().getReIDVMsg();
            }
                        
			Logger.info("getReIDVDetails JSON Request :" + mapper.writeValueAsString(req), this.getClass());
			validateRequestHeader( req.getHeader(), httpServletRequest );
			
			ErrorResp errorResp = validate(req, httpServletRequest);
			if (errorResp != null && errorResp.getErrors() != null && errorResp.getErrors().size() > 0)
			{
				return errorResp;
			}			
			IBankCommonData ibankCommonData=mbAppHelper.populateIBankCommonData(mbSession,httpServletRequest);				
			try
			{
				evDetail =  evService.getEvDetails(ibankCommonData.getCustomer().getGcis());
			}
			 catch (EmptyResultDataAccessException e) 
			 {
				Logger.debug("NO data found for customer:"+ibankCommonData.getCustomer().getGcis() +" Re IDV. Continue with the flow.", this.getClass()); 
			 }
                
			 if(isReIDVEligible)
			 {
				 int attemptCount =  getReIDVMaxAttemptCount( IBankParams.DEFAULT);
				 if(null!=evDetail && null != evDetail.getIdvType() && evDetail.getIdvType().equalsIgnoreCase(EVConstants.EV_ReIDV_TYPE) && null != evDetail.getEvAttemptCount() && evDetail.getEvAttemptCount() >= attemptCount)
		          {
		              reIdvCompleted = true;
		              serviceResponse=evhelper.populateReIDVDoneResponse(reIdvCompleted);
		              Logger.info("getReIDVDetails JSON incase ReIDV is already Response :" + mapper.writeValueAsString(serviceResponse), this.getClass());              			
		          }
		         else
		          {
		              reIdvCompleted = false;
		              evForeignCountryDtls=IBankParams.getForeignTINDetails();				
		              Logger.debug("Inside getReIDVDetails::::>", this.getClass());
		              EVCustDetails evCustDetails=new EVCustDetails();					
		              evCustDetails.setCrsInfoRequired(!crsDetail.isCrsInfoProvided());
		              Logger.debug("Before setting in session::::>", this.getClass());
		              mbSession.setEvCustDetails(evCustDetails);
		              Logger.debug("After setting in session::::>", this.getClass());
		              serviceResponse = evhelper.populateReIDVResponse(crsDetail,mbSession,evForeignCountryDtls,reIdvCompleted,ibankCommonData);			
				      Logger.info("getReIDVDetails JSON Response :" + mapper.writeValueAsString(serviceResponse), this.getClass());
		          }
					
			      RespHeader headerResp = populateResponseHeader(req.getHeader().getServiceName(), mbSession );
	              serviceResponse.setHeader(headerResp);
	              mbSession.removeEVCustDetailsFromSession();
			 }
			 
			 else
			 {
				 Logger.error("ReIdv- No Reidv Message Exists - BusinessException: ", this.getClass());
				 throw new BusinessException(BusinessException.SYSTEM_UNAVILABLE);
			 }
		}
		catch (BusinessException e){
			Logger.info("BusinessException in getReIDVDetails - [key: " + e.getKey() + "] : GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());
			return MBAppUtils.createErrorResp(mbSession.getOrigin(), e, ServiceConstants.EV_SERVICE, httpServletRequest);
		} 
		catch (ResourceException e){
			Logger.error("ResourceException in getReIDVDetails- [key: " + e.getKey() + "] : GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());
			return MBAppUtils.createErrorResp(mbSession.getOrigin(), BusinessException.SYSTEM_UNAVILABLE, ServiceConstants.EV_SERVICE, httpServletRequest);
		}
		catch (Exception e){
			Logger.error("Exception in getReIDVDetails: GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			return MBAppUtils.createErrorResp(mbSession.getOrigin(), BusinessException.SYSTEM_UNAVILABLE, ServiceConstants.EV_SERVICE, httpServletRequest);
		} 
		finally
		{
			performanceLogger.endLog(logName);
			performanceLogger.endAllLogs();
		}
        return serviceResponse;
	}
	
	public int getReIDVMaxAttemptCount(String origin)
	{
		int tempCount = 3;
		try{
			CodesVO codesVo = IBankParams.getCodesData(origin, IBankParams.CONFIGURATION_PROPERTIES, "ReIDVMaxAttemptCount");
			if ( codesVo != null)
			{
				tempCount = Integer.parseInt(codesVo.getMessage());
			}
		}catch (Exception e){
			Logger.error("Error in getReIDVMaxAttemptCount ", e, this.getClass());
		}
		return tempCount;
	}
}
