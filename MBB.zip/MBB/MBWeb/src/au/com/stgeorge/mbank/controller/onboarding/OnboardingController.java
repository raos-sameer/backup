package au.com.stgeorge.mbank.controller.onboarding;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import au.com.stgeorge.framework.common.logging.Logger;
import au.com.stgeorge.framework.common.model.User;
import au.com.stgeorge.ibank.businessobject.BusinessException;
import au.com.stgeorge.ibank.service.businessobject.OnboardingService;
import au.com.stgeorge.ibank.service.valueobject.OnboardingStep;
import au.com.stgeorge.ibank.service.valueobject.OnboardingVO;
import au.com.stgeorge.ibank.valueobject.Customer;
import au.com.stgeorge.ibank.valueobject.transfer.IBankCommonData;
import au.com.stgeorge.mbank.controller.IMBController;
import au.com.stgeorge.mbank.controller.customer.LogonHelper;
import au.com.stgeorge.mbank.model.common.IMBReq;
import au.com.stgeorge.mbank.model.common.IMBResp;
import au.com.stgeorge.mbank.model.common.ReqHeader;
import au.com.stgeorge.mbank.model.common.RespHeader;
import au.com.stgeorge.mbank.model.request.EmptyReq;
import au.com.stgeorge.mbank.model.request.onboarding.OnboardingStatisticRequest;
import au.com.stgeorge.mbank.model.response.ErrorResp;
import au.com.stgeorge.mbank.model.response.SuccessResp;
import au.com.stgeorge.mbank.model.response.onboarding.OnboardingResp;
import au.com.stgeorge.mbank.session.MobileSession;
import au.com.stgeorge.mbank.util.MBAppHelper;
import au.com.stgeorge.mbank.util.MBAppUtils;
import au.com.stgeorge.mbank.util.ServiceConstants;
import au.com.stgeorge.perflogger.PerformanceLogger;

import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

@Controller
@RequestMapping("/onboarding")
public class OnboardingController implements IMBController
{
	private static final String OB_STEP_ESTMT = "estmt";
	private static final String OB_STEP_PUSH = "push";
	private static final String OB_STEP_QZ = "qz";
	private static final String OB_STEPNAME_E_STATEMENTS = "eStatements";
	private static final String OB_STEPNAME_NOTIFICATIONS = "Notifications";
	private static final String OB_STEPNAME_QUICK_ZONE = "Quick Zone";
	private static final String MBLNK = "MBLNK";
	private static final String POPULAR_FEATURES = "Popular features";

	private static final String OB_SAVE_EXIT = "SAVE_EXIT";
	private static final String OB_SUMMARY = "SUMMARY";
	private static final String OB_ALL_SET = "ALL_SET";
	private static final String SAVE_EXIT_GDW_ACTION = "EXSET";
	private static final String SUMMARY_GDW_ACTION = "OBSUMM";
	private static final String ALL_SET_GDW_ACTION = "OBALL";
	
	
	private static final Map<String, String> screenTypeToGDWAction;
	
	static{
		screenTypeToGDWAction = new HashMap<>();
		screenTypeToGDWAction.put(OB_SAVE_EXIT, SAVE_EXIT_GDW_ACTION);
		screenTypeToGDWAction.put(OB_SUMMARY, SUMMARY_GDW_ACTION);
		screenTypeToGDWAction.put(OB_ALL_SET, ALL_SET_GDW_ACTION);
	}
	
	
	@Autowired
	private LogonHelper logonHelper;
	
	@Autowired
	private OnboardingHelper helper;
	
	@Autowired
	private OnboardingService onboardingService;
	
	
	/**
	 * End point for getting the Onboarding object as a response from Shelf menu popular features in MB
	 * @param httpServletRequest
	 * @param httpServletResponse
	 * @param req
	 * @return
	 */
	
	@RequestMapping(method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE, value = "popularFeatures")
	@ResponseBody
	public IMBResp getPopularFeatures(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, @RequestBody final EmptyReq req)
	{
		ObjectMapper mapper = new ObjectMapper();

		String origin = logonHelper.resolveOrigin(httpServletRequest);
		httpServletRequest.setAttribute(LogonHelper.ORIGIN, origin);
		
		String logName = MBAppUtils.getLogName(httpServletRequest);
		MBAppHelper mbAppHelper = new MBAppHelper();
		
		User user = null;
		MobileSession mobileSession = null;
		OnboardingVO oldOnboarding;
		
		try
		{
			mobileSession = mbAppHelper.getMobileSession(httpServletRequest);
			user = mobileSession.getUser();
			
			Customer customer = mobileSession.getCustomer();
			
			IBankCommonData commonData = populateIBankCommonData(httpServletRequest, user, mobileSession);	
			
			oldOnboarding = getResponseOnboardingVO(customer, commonData, user, httpServletRequest, httpServletResponse, mobileSession);
			
			OnboardingHelper.addStatisticsLog(commonData, MBLNK, POPULAR_FEATURES);
			
			OnboardingResp onboardingResponse = new OnboardingResp();
			onboardingResponse.setOnboarding(oldOnboarding);
			
			RespHeader headerResp = populateResponseHeader(ServiceConstants.POPULAR_FEATURES_RESPONSE, mobileSession);
			onboardingResponse.setHeader(headerResp);
			
			Logger.info("Shelf Menu /popularFeatures JSON Response :" + mapper.writeValueAsString(onboardingResponse), this.getClass());
			return onboardingResponse;
			
		} catch (BusinessException e)
		{
			Logger.error("Exception Inside popularFeatures | Shelf Menu : BusinessException " + e.getKey(), e, this.getClass());
			IMBResp resp = MBAppUtils.createErrorResp(origin, e, ServiceConstants.POPULAR_FEATURES_RESPONSE, httpServletRequest);
			return resp;
		} catch (Exception e)
		{
			Logger.error("Exception Inside popularFeatures | Shelf Menu : Exception ", e, this.getClass());
			BusinessException exp = new BusinessException(BusinessException.SYSTEM_UNAVILABLE);
			IMBResp resp = MBAppUtils.createErrorResp(origin, exp, ServiceConstants.POPULAR_FEATURES_RESPONSE, httpServletRequest);
			return resp;
		} finally
		{
			perfLogger.endLog(logName);
			perfLogger.endAllLogs();
		}
	}

	private IBankCommonData populateIBankCommonData(HttpServletRequest httpServletRequest,	User user, MobileSession mobileSession) {
		IBankCommonData commonData = new IBankCommonData();
		commonData.setUser(user);
		commonData.setOrigin(mobileSession.getOrigin());
		commonData.setGdwOrigin(mobileSession.getGDWOrigin());
		commonData.setIpAddress(MBAppHelper.resolveIPAddress(httpServletRequest, mobileSession.getOrigin()));
		commonData.setSessionId(mobileSession.getSessionID());
		commonData.setCustomer(mobileSession.getCustomer());
		if ( ! OnboardingHelper.isValidIPAddress ( commonData.getIpAddress() ) )
		{
			Logger.info("Invalid IP Address : " + commonData.getIpAddress() ,MBAppHelper.class);
			commonData.setIpAddress("0.0.0.0");
		}
		String userAgent = httpServletRequest.getHeader("User-Agent");		
		commonData.setUserAgent(userAgent);
		return commonData;
	}
	
	@RequestMapping(method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE, value = "statistics")
	@ResponseBody
	public IMBResp addStatisticsLog(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, @RequestBody final OnboardingStatisticRequest req)
	{
		ObjectMapper mapper = new ObjectMapper();

		String origin = logonHelper.resolveOrigin(httpServletRequest);
		
		String logName = MBAppUtils.getLogName(httpServletRequest);
		MBAppHelper mbAppHelper = new MBAppHelper();
		User user = null;
		MobileSession mobileSession = null;
		
		try{
			
			mobileSession = mbAppHelper.getMobileSession(httpServletRequest);
			user = mobileSession.getUser();
			
			IBankCommonData commonData = new IBankCommonData();
			
			commonData.setUser(user);
			commonData.setOrigin(helper.getGdwOrigin(origin));
			commonData.setIpAddress(MBAppHelper.resolveIPAddress(httpServletRequest, origin));
			commonData.setSessionId(mobileSession.getSessionID());
			
			OnboardingHelper.addStatisticsLog(commonData, screenTypeToGDWAction.get(req.getAction_type()), req.getDesc());
			
			RespHeader headerResp = mbAppHelper.populateResponseHeader(ServiceConstants.ONBOARDING_STAT_RESPONSE, mobileSession);
			SuccessResp successResp = new SuccessResp();
			successResp.setHeader(headerResp);
			successResp.setIsSuccess(true);
			
			Logger.info("addStatisticsLog | for Onboarding Screens | JSON Response :" + mapper.writeValueAsString(successResp), this.getClass());
			
			return successResp;
			
		}catch (Exception e){
			
			Logger.error("Exception inside addStatisticsLog for action type | "+screenTypeToGDWAction.get(req.getAction_type())+" : Exception ", e, this.getClass());
			RespHeader headerResp = mbAppHelper.populateResponseHeader(ServiceConstants.ONBOARDING_STAT_RESPONSE, mobileSession);
			return getSuccessResponse(headerResp);
			
		} finally{
			perfLogger.endLog(logName);
			perfLogger.endAllLogs();
		}
	}
	
	
	private SuccessResp getSuccessResponse(RespHeader headerResp){
		SuccessResp successResp = new SuccessResp();
		successResp.setHeader(headerResp);
		successResp.setIsSuccess(true);
		return successResp;
	}
	
	/**
	 * @param customer
	 * @param user
	 * @param request
	 * @param response
	 * @param mobileSession
	 * @param origin
	 * @return
	 * @throws BusinessException
	 * @throws JsonGenerationException
	 * @throws JsonMappingException
	 * @throws IOException
	 */
	public OnboardingVO getResponseOnboardingVO(Customer customer, IBankCommonData ibankCommonData, User user, HttpServletRequest request, HttpServletResponse response, MobileSession mobileSession) throws BusinessException
	{
		//String slStatus = null;
		String qzStatus = null;
		String pushStatus = null;
		String eStmtStatus = null;
		String popularFeaturesQZSession = null;

		OnboardingVO oldOnboarding = new OnboardingVO();
			
		try {
			qzStatus = onboardingService.getQuickZoneEligibilityStatus(customer,user);
			if(qzStatus.equalsIgnoreCase("ELIGIBLE")) {
				popularFeaturesQZSession = onboardingService.getQuickZoneSessionForEligibleCustomer(user);
			}
			oldOnboarding.setStep(new OnboardingStep(OB_STEP_QZ,OB_STEPNAME_QUICK_ZONE, true,qzStatus, popularFeaturesQZSession));
		
			pushStatus = onboardingService.getPushNotificationEligibilityStatus(customer);
			boolean isAndroid = logonHelper.isAndroid(request);
			oldOnboarding.setStep(new OnboardingStep(OB_STEP_PUSH,OB_STEPNAME_NOTIFICATIONS, !isAndroid,pushStatus));
			
			eStmtStatus = onboardingService.getEStatemsntEligibilityStatus(customer,ibankCommonData);
			oldOnboarding.setStep(new OnboardingStep(OB_STEP_ESTMT,OB_STEPNAME_E_STATEMENTS,false,eStmtStatus));
		} catch (Exception e) {
			Logger.debug("Exception in one of the eligibility services : ",e, this.getClass());
		}
		//mobileSession.setOnboardingVO(onboardingVO);
			
		
		return oldOnboarding;
	}
	
	@Autowired
	private PerformanceLogger perfLogger;

	@Override
	public ErrorResp validate(IMBReq serviceRequest,HttpServletRequest httpRequest) throws BusinessException {
		return null;
	}
	
	public RespHeader populateResponseHeader(String serviceName, MobileSession mobSession )
	{
		RespHeader headerResp = new RespHeader();
		headerResp.setClientApiVersion(ServiceConstants.API_VERSION);
		headerResp.setServiceName(serviceName);
		Logger.info(" populateResponseHeader serviceName  " + serviceName, this.getClass());
		return headerResp;
	}

	@Override
	public void validateRequestHeader(ReqHeader headerReq,HttpServletRequest request) throws BusinessException {}
}
