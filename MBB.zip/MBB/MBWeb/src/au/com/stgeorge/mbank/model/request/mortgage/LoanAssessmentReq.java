package au.com.stgeorge.mbank.model.request.mortgage;

import au.com.stgeorge.mbank.model.common.IMBReq;
import au.com.stgeorge.mbank.model.common.ReqHeader;

public class LoanAssessmentReq implements IMBReq {
	private ReqHeader header;
	private Long applicationNum;
	private String requestType;


	public Long getApplicationNum() {
		return applicationNum;
	}

	public void setApplicationNum(Long applicationNum) {
		this.applicationNum = applicationNum;
	}

	public String getRequestType() {
		return requestType;
	}

	public void setRequestType(String requestType) {
		this.requestType = requestType;
	}

	public ReqHeader getHeader() {
		return header;
	}

	public void setHeader(ReqHeader header) {
		this.header = header;
	}
}