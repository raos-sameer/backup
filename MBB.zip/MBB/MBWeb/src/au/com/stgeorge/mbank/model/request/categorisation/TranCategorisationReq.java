package au.com.stgeorge.mbank.model.request.categorisation;


import javax.validation.constraints.NotNull;

import au.com.stgeorge.ibank.businessobject.BusinessException;
import au.com.stgeorge.mbank.model.common.IMBReq;
import au.com.stgeorge.mbank.model.common.ReqHeader;

public class TranCategorisationReq implements IMBReq{

	private static final long serialVersionUID = -8619853234497299425L;
	
	private ReqHeader header;
	
	@NotNull(message = "" + BusinessException.WSVC_INVALID_INPUT_PARAM)
	private Integer accountIndex;
	
	private Integer month;
	
	private Boolean monthDataReq;
	
	private String categoryName;
	
	private Boolean isDebit;
	 
	public Integer getAccountIndex() {
		return accountIndex;
	}	
	public void setAccountIndex(Integer accountIndex) {
		this.accountIndex = accountIndex;
	}	
	public ReqHeader getHeader()
	{
		return header;
	}
	public void setHeader(ReqHeader header)
	{
		this.header = header;
	}				  
	public Integer getMonth() {
		return month;
	}
	public void setMonth(Integer month) {
		this.month = month;
	}
	
	public Boolean isMonthDataReq() {
		return monthDataReq;
	}
	public void setMonthDataReq(Boolean monthDataReq) {
		this.monthDataReq = monthDataReq;
	}
	
	
	public String getCategoryName() {
		return categoryName;
	}
	public void setCategoryName(String categoryName) {
		this.categoryName = categoryName;
	}
	public static long getSerialVersionUID() {
		return serialVersionUID;
	}
	
	public Boolean isDebit() {
		return isDebit;
	}
	public void setDebit(Boolean isDebit) {
		this.isDebit = isDebit;
	}

}
