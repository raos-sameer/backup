package au.com.stgeorge.mbank.model.payments;

import au.com.stgeorge.mbank.model.common.IMBResp;
import au.com.stgeorge.mbank.model.common.RespHeader;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_NULL)
public class ResubmitPaymentResp implements IMBResp {

	private static final long serialVersionUID = 6229701793111337154L;
	private RespHeader header;
	private String amount;
	private int fromAccountIndex;
	private int toItemIndex;
	private String desc;
	private String tranType;
	private String payerName;
	private boolean sendEmail;

	public ResubmitPaymentResp(RespHeader header) {
		this.header = header;
	}
	
	public String getAmount() {
		return amount;
	}

	public void setAmount(String amount) {
		this.amount = amount;
	}

	public int getFromAccountIndex() {
		return fromAccountIndex;
	}

	public void setFromAccountIndex(int fromAccountIndex) {
		this.fromAccountIndex = fromAccountIndex;
	}

	public int getToItemIndex() {
		return toItemIndex;
	}

	public void setToItemIndex(int toItemIndex) {
		this.toItemIndex = toItemIndex;
	}

	public String getDesc() {
		return desc;
	}

	public void setDesc(String desc) {
		this.desc = desc;
	}

	public String getTranType() {
		return tranType;
	}

	public void setTranType(String tranType) {
		this.tranType = tranType;
	}

	public String getPayerName() {
		return payerName;
	}

	public void setPayerName(String payerName) {
		this.payerName = payerName;
	}

	public boolean getSendEmail() {
		return sendEmail;
	}

	public void setSendEmail(boolean sendEmail) {
		this.sendEmail = sendEmail;
	}


	@Override
	public RespHeader getHeader() {
		return header;
	}

	@Override
	public void setHeader(RespHeader header) {
		this.header = header;
	}
}
