package au.com.stgeorge.mbank.model.request;

import java.io.Serializable;

import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.NotEmpty;

import au.com.stgeorge.ibank.businessobject.BusinessException;
import au.com.stgeorge.mbank.model.common.IMBReq;
import au.com.stgeorge.mbank.model.common.ReqHeader;

public class CustomerRegReq implements IMBReq, Serializable{

	private static final long serialVersionUID = -3083693566338430411L;

	private ReqHeader header;
	
	@NotEmpty(message = "{errors.password.required}")
	@Size(min = 6,max = 12,message = ""+BusinessException.INVALID_CURRENT_PWD_SEC_NUM)
	@Pattern(regexp="([a-zA-Z0-9]+)",message = ""+BusinessException.INVALID_CURRENT_PWD_SEC_NUM)
	private String password;
	
	@NotEmpty(message = "{errors.secNum.required}")
    @Size(min = 4,max = 6,message = ""+BusinessException.INVALID_CURRENT_PWD_SEC_NUM)
	@Pattern(regexp="([0-9]+)",message = ""+BusinessException.INVALID_CURRENT_PWD_SEC_NUM)
	private String secNum;
    
	@Size(max = 50,message = ""+BusinessException.INVALID_CURRENT_PWD_SEC_NUM)
	@Email(message = "{errors.email.invalid}")
	private String email;

	private Boolean eStatementSubscribe;
	
	private Boolean eCorrespondenceConsent;
	
	private String nameId;
	
	private String pwdEncswitch;

	private boolean originMb;
	
	

	public ReqHeader getHeader() {
		return header;
	}

	public void setHeader(ReqHeader header) {
		this.header = header;
	}

	public String getPwdEncswitch() {
		return pwdEncswitch;
	}

	public void setPwdEncswitch(String pwdEncswitch) {
		this.pwdEncswitch = pwdEncswitch;
	}
	
	public String getNameId() {
		return nameId;
	}

	public void setNameId(String nameId) {
		this.nameId = nameId;
	}
	
	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getSecNum() {
		return secNum;
	}

	public void setSecNum(String secNum) {
		this.secNum = secNum;
	}


	public String getEmail() {
		return email;
	}
	
	public void setEmail(String email) {
		this.email = email;
	}

	public Boolean geteStatementSubscribe() {
		return eStatementSubscribe;
	}

	public void seteStatementSubscribe(Boolean eStatementSubscribe) {
		this.eStatementSubscribe = eStatementSubscribe;
	}

	public Boolean geteCorrespondenceConsent() {
		return eCorrespondenceConsent;
	}

	public void seteCorrespondenceConsent(Boolean eCorrespondenceConsent) {
		this.eCorrespondenceConsent = eCorrespondenceConsent;
	}
	
	public boolean isOriginMb() {
		return originMb;
	}

	public void setOriginMb(boolean originMb) {
		this.originMb = originMb;
	}

}
