package au.com.stgeorge.mbank.controller;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.AbstractController;

import au.com.stgeorge.framework.common.logging.Logger;
import au.com.stgeorge.framework.common.model.User;
import au.com.stgeorge.ibank.businessobject.BusinessException;
import au.com.stgeorge.ibank.businessobject.SystemInformation;
import au.com.stgeorge.ibank.common.cache.IBankParams;
import au.com.stgeorge.ibank.util.ServiceHelper;
import au.com.stgeorge.ibank.util.StringUtil;
import au.com.stgeorge.ibank.valueobject.database.OriginsVO;
import au.com.stgeorge.mbank.controller.customer.CookieLogonBean;
import au.com.stgeorge.mbank.controller.customer.LogonHelper;
import au.com.stgeorge.mbank.session.IGenericSession;
import au.com.stgeorge.security.util.StringMethods;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

public class MainLiteController extends AbstractController {
	
	private static volatile int numberOfRequests = 0;
	public static final String REQ_ACTION_STR = "action";
	private static final String ERROR_VIEW = "404";
	public static final String WEB_CONTEXT = "WebContext";
	public static final String SYS_VERSION = "SysVersion";
	public static final String ORIGIN_NAME = "OriginName";
	public static final String HELP_DESK_NO = "HelpDeskNo";
	private static final String REQ_IGNORE_SEC_FLAG =  "SIMPLE-LOGON" ;
	public static final String REQ_ACTION_TYPE = "ActionType"; 
	
	private static final String BLOCK_CHARS = "^[0-9A-Za-z',. &/\\-_]*$";
	
	private static final String REQ_LITE = "LITE";
	public static final String ORIGIN = "origin";
	public static final String BROWSER_NAME = "browserName";
	public static final String MAIN_LITE_VIEW = "indexLite";
	public static final String ORIGIN_LITE = "OriginLite";
	public static final String USER_NAME = "USERNAME";
	public static final String LAST_LOGON_DATE = "LastLogonDate";
	public static final String CURRENT_LOGIN_DATE = "currentLoginDate";
	public static final String MESSAGE_COUNT = "messageCount";
	private static final SimpleDateFormat DATE_FORMAT = new SimpleDateFormat("EEE dd MMM yyyy 'at' HH:mm");
	public static final String MENU_ITEM_SELECTED = "selectedMenuItem";
	
	private static final String IBANKCOOKIE = "CompassCookie";
	private static final String IBANK_CONTEXT = "/ibank/";
	public static final String MENU_URL = "MenuUrl";
	public static final String DATA_IB_ACTIVATION = "data-ib-activation";
	  
	private static final String CUST_DISPLAY_NAME = "CustDispalyName";
	private static final String OTHER_PARAMS = "otherParams";
	
	public static final String CONTACTURL = "originContactUrl";
	public static final String FAQURL = "originFaqUrl";
	public static final String ABN = "originABN";
	
	private static final String REDIRECT_TYPE ="redirectType";
	private static final String LITE ="lite";
	
	private static final String UNREAD_MSG_COUNT ="unreadMsgCount";
	public static final String ALLOWED_CHAR = "^[0-9A-Za-z',: {}]*$";
	public static final String ALLOWED_CHAR_UNREAD_COUNT = "^[0-9]*$";
	public static final String INVALID_INUT_REGEX = "(--|drop\\s+table|delete|\\.\\.(/|\\\\)|<.+>)";
	
	public static final String IBANK_LOGON_DATE = "CurrentLoginTime";
	public static final String DATA_IB_TIMESPENT = "data-ib-timespent";
	
	static ObjectMapper mapper = new ObjectMapper();
	
	@Autowired
	private LogonHelper logonHelper;
		
	@Autowired
	private SystemInformation systemInformation;
	

	@Override
	protected ModelAndView handleRequestInternal(HttpServletRequest request, HttpServletResponse response) throws Exception
	{
		Logger.debug("MainLiteController: handleRequestInternal", this.getClass());
		ModelAndView model = null;
		String origin = null;
		String redirectType = null;
		try
		{
			numberOfRequests ++;
			logonHelper.setWebReadyCookie(request, response , "0" );
			
			origin = logonHelper.resolveOrigin(request);
			String originLite = null;
			if(!StringMethods.isEmptyString(origin) )
			{
				//TODO : get it from releasecodes ?
				
				switch(origin){
					case "MSTG" : originLite = "DSTG";
						break;
					case "MBOM" : originLite = "DBOM";
						break;
					case "MBSA" : originLite = "DBSA";
						break;
				}
				request.setAttribute(ORIGIN_LITE, originLite);
			}
				
			request.setAttribute(MainLiteController.WEB_CONTEXT, logonHelper.getMBWebResourceContext());
			
			if ( StringMethods.isEmptyString(origin) )
			{
				origin = "MSTG";
				request.setAttribute(LogonHelper.ORIGIN, origin);
				Logger.info("MainLiteController : Unable to resolve the origin  Request Details. URL : "+ request.getRequestURL() + " IP :" + request.getRemoteAddr() + " Number Of Requests : "+ numberOfRequests +
						" True IP >> " + request.getHeader(IBankParams.trueClientIP()), this.getClass());
				model = new ModelAndView(ERROR_VIEW);
			}
			else
			{
				
				model = new ModelAndView(MAIN_LITE_VIEW);
				
				request.setAttribute(LogonHelper.ORIGIN, origin);
				Logger.debug("MainLiteController : Origin :"+origin, this.getClass());
				Logger.debug("MainLiteController : OriginLite :"+originLite, this.getClass());
				
				if ( this.systemInformation == null )
				{
					Logger.info("************ Loading systemInformation *************** "+ request.getRequestURL()   , this.getClass());
					this.systemInformation = getSystemInformationDtls();
				}
				request.setAttribute(SYS_VERSION, this.systemInformation.getMB3PackageVersion());
				
				OriginsVO originVO = IBankParams.getOrigin(origin);
				request.setAttribute(ORIGIN_NAME, originVO.getName());
				
				request.setAttribute(HELP_DESK_NO, originVO.getPhone());
				
				
				
				Logger.info(originVO.toXml() + " \nInside Main Lite Controller  Request Details. URL : "+ request.getRequestURL() + " IP :" + request.getRemoteAddr() + " Number Of Requests : "+ numberOfRequests +
						" True IP >> " + request.getHeader(IBankParams.trueClientIP()), this.getClass());
				
				CookieLogonBean cookieBean = logonHelper.populateCookieLogonBean(request);
				
				if ( cookieBean != null )
				Logger.info(" MainLiteController : Screen Type " +cookieBean.isIgnoreSec() , this.getClass());
				
				request.setAttribute(REQ_ACTION_STR,REQ_LITE);
		     	request.setAttribute(REQ_IGNORE_SEC_FLAG,  IBankParams.NO);	
				
				String actionType = request.getParameter(REQ_ACTION_TYPE);
				
				if(!isValidActionType(actionType)){
					Logger.info("MainLiteController : Invalid Character in Action Type " + actionType,  this.getClass());
					throw new BusinessException(BusinessException.INVALID_CHAR_SET, "Invalid Character");
				}else {
					Logger.info("MainLiteController : Action Type " + actionType,  this.getClass());
					request.setAttribute( MainLiteController.REQ_ACTION_TYPE ,actionType);
				}
				
				//unread msg count
				String msgUnreadCount = request.getParameter(UNREAD_MSG_COUNT);
				Logger.debug("MainLiteController - msgUnreadCount :"+msgUnreadCount , this.getClass());
				if(isValidUnreadCount(msgUnreadCount)){
					request.setAttribute( MainLiteController.MESSAGE_COUNT,msgUnreadCount);
				}else{
					throw new BusinessException(BusinessException.INVALID_CHAR_SET, "Invalid Character");
				}
				
				//getting session ID from IB cookie
				Cookie ibankCookie = readCookies(request);
				String sessionId = ibankCookie.getValue();
				//String sessionId = "94FFB45F3632318754804619BE982143";
				Logger.debug("MainLiteController : Session id from IB :"+sessionId, this.getClass());
				IGenericSession genericSession = logonHelper.createCompassSession(request,sessionId,true);
				genericSession.setAttribute(ORIGIN, origin);
				genericSession.setAttribute(BROWSER_NAME, "WebSrv");
				genericSession.setAttribute(REQ_LITE, true);
				
				User user = genericSession.getUser();
				String custName = (String) user.getAttribute(CUST_DISPLAY_NAME);
				request.setAttribute(MainLiteController.USER_NAME ,custName);	
				
				Object lastLogonObj  = user.getAttribute(LAST_LOGON_DATE);
				if ( lastLogonObj != null  )
				{
					Date lastLogonDate  = (Date)lastLogonObj;
					String formattedLastLoginDate = DATE_FORMAT.format(lastLogonDate).toString();
					request.setAttribute( MainLiteController.LAST_LOGON_DATE ,formattedLastLoginDate);
				}
				
				String formattedCurrentDate = DATE_FORMAT.format( new Date() ).toString();
				request.setAttribute( MainLiteController.CURRENT_LOGIN_DATE ,formattedCurrentDate);			
				
				//selected Menu
				String menuIndex = (String) user.getAttribute(MainLiteController.MENU_ITEM_SELECTED);
				Logger.debug("MainLiteController - selectedMenu:"+menuIndex, this.getClass());
				request.setAttribute( MainLiteController.MENU_ITEM_SELECTED ,menuIndex);
				
				String menuUrl = createMenuUrl(request);
				request.setAttribute(MainLiteController.MENU_URL, menuUrl);
				
				String otherParams = request.getParameter(OTHER_PARAMS);
				
				Logger.info("MainLiteController : otherParams :: "+otherParams, this.getClass());
				
				//gold customer
				String sessionOrigin = (String) user.getAttribute(ORIGIN);
				boolean isGoldCustomer = false;
				Logger.debug("MainLiteController - origin from Session :"+sessionOrigin, this.getClass());
				if("STGD".equalsIgnoreCase(sessionOrigin) || "BOMG".equalsIgnoreCase(sessionOrigin) || "BSGD".equalsIgnoreCase(sessionOrigin)){
					isGoldCustomer = true;
				}
				
				if(isGoldCustomer){
					Map<String, Object> otherParamsMap = null;
					if(null != otherParams && !otherParams.isEmpty()){
						if(isValidOtherParams(otherParams)){
							otherParamsMap = mapper.readValue(otherParams, new TypeReference<Map<String, Object>>() {});
						}else
							throw new BusinessException(BusinessException.INVALID_CHAR_SET, "Invalid Character");
						
					}else{
						otherParamsMap = new HashMap<>();
					}
					
					otherParamsMap.put("isGoldCustomer", Boolean.TRUE);
					String desktopActivationData = mapper.writeValueAsString(otherParamsMap);
					request.setAttribute(MainLiteController.DATA_IB_ACTIVATION, desktopActivationData);
					
				}else if(null != otherParams && !otherParams.isEmpty()){
					if(isValidOtherParams(otherParams)){
						request.setAttribute(MainLiteController.DATA_IB_ACTIVATION, otherParams);
					}else
						throw new BusinessException(BusinessException.INVALID_CHAR_SET, "Invalid Character");					
				}else {
					request.setAttribute(MainLiteController.DATA_IB_ACTIVATION, "");
				}
				
														
				redirectType = request.getParameter(REDIRECT_TYPE);
				
				Logger.info("MainLiteController : redirectType :: "+redirectType, this.getClass());
				
				if(null == redirectType || !redirectType.equals(LITE))
					throw new BusinessException(BusinessException.SYSTEM_UNAVILABLE);
				
				//for footer
				String originFooter = null;
				
				switch(origin){
					case "MSTG" : originFooter = "STG";
						break;
					case "MBOM" : originFooter = "BOM";
						break;
					case "MBSA" : originFooter = "BSA";
						break;
				}
				
				Logger.debug("MainLiteController : originFooter :"+originFooter, this.getClass());
				
				OriginsVO originDesktopVO = IBankParams.getOrigin(originFooter != null ? originFooter:origin);
				
				String contactURL = originDesktopVO.getContactUrl();
				String faqURL = originDesktopVO.getFaqUrl();
				String copyRight = originDesktopVO.getAbn();
				
				request.setAttribute(MainLiteController.CONTACTURL, contactURL);
				request.setAttribute(MainLiteController.FAQURL, faqURL);
				request.setAttribute(MainLiteController.ABN, copyRight);
				
				//time spent on IBank for session expiry
				Object ibankLoginTime  = genericSession.getAttribute(IBANK_LOGON_DATE);
				if (null!= ibankLoginTime)
				{
					Date ibankLogonDate  = (Date)ibankLoginTime;
					//Difference between current time and ibank logon date in milliseconds
					long ibTimeSpent = new Date().getTime() - ibankLogonDate.getTime();
					Logger.debug("MainLiteController - Time spent in Ibank in milliseconds :"+ibTimeSpent, this.getClass());
					request.setAttribute(MainLiteController.DATA_IB_TIMESPENT, ibTimeSpent);
				}
				
			}
			return model;
		}
		catch ( Exception e)
		{
			origin = "MSTG";
			request.setAttribute(LogonHelper.ORIGIN, origin);
			model = new ModelAndView(ERROR_VIEW);
			Logger.error("Error in Main Controller " , e, this.getClass());
			return model;
		}
		finally
		{
			numberOfRequests--;
		}
	}

	
	private boolean isValidActionType(String actionType){

		if(StringMethods.isEmptyString(actionType)){
			return true;
		}
		
		String pattern = BLOCK_CHARS;
		Pattern r = Pattern.compile(pattern);

		Matcher m = r.matcher(actionType);
		if (m.find()) {
			return true;
		} 
		return false;
	}
	

	private SystemInformation getSystemInformationDtls()
	{
		SystemInformation systemInformation = (SystemInformation) ServiceHelper.getBean("systemInformation");
		return systemInformation;

	}
	
	private Cookie readCookies(HttpServletRequest request){
		Cookie[] cookies = request.getCookies();
		Cookie compAssCookiePresent = null ;
		
		if (cookies != null) {			
			for (Cookie c : cookies) {
				Logger.debug("MainLiteController - Cookies - "+c.getName()+" : "+c.getValue(), this.getClass());
				if (c.getName().equalsIgnoreCase(IBANKCOOKIE)) {
					Logger.info("CompassCookie is recieved from browser at logon : Name ::"+c.getName(), this.getClass());
					compAssCookiePresent = c;
					break;
				}					
			}

		}else{
			Logger.info("No cookies found in Main lite controller", this.getClass());
		}
		return compAssCookiePresent;
	}
	
	private String createMenuUrl(HttpServletRequest httpServletRequest){
		String menuUrl = "";		
		menuUrl = menuUrl.concat(httpServletRequest.getScheme()).concat("://").concat(httpServletRequest.getHeader("Host")).concat(IBANK_CONTEXT);				
		return menuUrl;
	}

	private boolean isValidOtherParams(String otherParams){
		boolean isValid = false;
		try{
			String replaceStr = otherParams.replaceAll("\"", "'");
			Logger.debug("MainLiteController : isValidOtherParams :"+replaceStr, this.getClass());
	
			/*if(!StringUtil.isRogueInputData(otherParams)){
				isValid = true;
			}*/
			
			if(StringUtil.isValidData(replaceStr, ALLOWED_CHAR)){
				isValid = true;
			}
			
		}catch(Exception e){
			Logger.warn("MainLiteController : isValidOtherParams -something is wrong", this.getClass());
		}		
		return isValid;
	}
	
	private boolean isValidUnreadCount(String unreadCount){
		boolean isValid = false;
		try{
			if(StringUtil.isValidData(unreadCount, ALLOWED_CHAR_UNREAD_COUNT)){
				isValid = true;
			}						
		}catch(Exception e){
			Logger.warn("MainLiteController : isValidUnreadCount -something is wrong", this.getClass());
		}		
		return isValid;
	}
	

}
