package au.com.stgeorge.mbank.controller.businessaccount;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import au.com.stgeorge.framework.common.util.StringMethods;
import au.com.stgeorge.ibank.businessobject.BusinessException;
import au.com.stgeorge.ibank.businessobject.ResourceException;
import au.com.stgeorge.ibank.common.cache.IBankParams;
import au.com.stgeorge.ibank.service.valueobject.BusinessAccountDetails;
import au.com.stgeorge.ibank.service.valueobject.DeltaInformationCapturedVO;
import au.com.stgeorge.ibank.valueobject.Address;
import au.com.stgeorge.ibank.valueobject.ContactDetail;
import au.com.stgeorge.ibank.valueobject.LabelValueVO;
import au.com.stgeorge.ibank.valueobject.ThreatMatrix;
import au.com.stgeorge.mbank.model.common.AddressResp;
import au.com.stgeorge.mbank.model.common.ErrorInfo;
import au.com.stgeorge.mbank.model.common.IMBResp;
import au.com.stgeorge.mbank.model.request.customer.ev.CRSInfo;
import au.com.stgeorge.mbank.model.response.businessaccount.ACNDetailsResp;
import au.com.stgeorge.mbank.model.response.businessaccount.BusinessAccountResp;

public class BusinessAccountHelper
{
	public BusinessAccountResp populateResponse(ContactDetail contactDetail,Boolean activate,Boolean crossSell, String abn, List<LabelValueVO> tradingNames, String crsStatus, CRSInfo crsInfo, ThreatMatrix threatMatrix, String sessionThreatMatrixSessionID,DeltaInformationCapturedVO deltaInformationCapturedVO) throws BusinessException 
	{
		BusinessAccountResp businessAccountResp = new BusinessAccountResp();
		populateAddressResp(contactDetail, businessAccountResp);
		businessAccountResp.setActivate(activate);
		businessAccountResp.setCrossSell(crossSell);
		businessAccountResp.setEmail(contactDetail.getEmail());
		businessAccountResp.setAbn(abn);
		if(!StringMethods.isEmptyString(abn))
		{
			businessAccountResp.setTradingNames(tradingNames);
		}
		businessAccountResp.setForeignTaxResident(crsStatus);
		businessAccountResp.setCrsInfo(crsInfo);
		businessAccountResp.setStates(getStateList());
		
		if(threatMatrix != null){
			businessAccountResp = populateThreatMatrixInfo(businessAccountResp, threatMatrix, sessionThreatMatrixSessionID);
		}
		populateDeltaInfo(deltaInformationCapturedVO, businessAccountResp);
		businessAccountResp.setQasUrl(IBankParams.getAddressTypeaheadURL(IBankParams.DEFAULT_ORIGIN));
		return businessAccountResp;
	}

	/**
	 * @param deltaInformationCapturedVO
	 * @param businessAccountResp
	 */
	private void populateDeltaInfo(
			DeltaInformationCapturedVO deltaInformationCapturedVO,
			BusinessAccountResp businessAccountResp) {
		if(deltaInformationCapturedVO!=null)
		{
			businessAccountResp.setSofCaptured(deltaInformationCapturedVO.isSofCaptured());
			businessAccountResp.setSowCaptured(deltaInformationCapturedVO.isSowCaptured());
			businessAccountResp.setEmpTypeCaptured(deltaInformationCapturedVO.isEmpTypeCaptured());
			businessAccountResp.setOccupationCodeCaptured(deltaInformationCapturedVO.isOccupationCodeCaptured());
			businessAccountResp.setPobrCaptured(deltaInformationCapturedVO.isPobrCaptured());
			//businessAccountResp.setAlternateNameCaptured(deltaInformationCapturedVO.isAlternateNameCaptured());
			
			if(!deltaInformationCapturedVO.isSofCaptured())
			{
				businessAccountResp.setSourceOfFundsList(IBankParams.getTraderSourceOfFundsList());
			}
			if(!deltaInformationCapturedVO.isSowCaptured())
			{
				businessAccountResp.setSourceOfWealthList(IBankParams.getTraderSourceOfWealthList());
			}
			if(!deltaInformationCapturedVO.isOccupationCodeCaptured()){
				businessAccountResp.setOccupationCodeList(IBankParams.getCustOccupationList());
			}
			if(!deltaInformationCapturedVO.isEmpTypeCaptured()){
				businessAccountResp.setEmployerTypeList(IBankParams.getCustEmployeeCodeList());
			}
		}
	}

	private void populateAddressResp(ContactDetail contactDetail,
			BusinessAccountResp businessAccountResp) {
		if (contactDetail != null)
		{
			if(contactDetail.getMailingAddress() != null)
			{
				businessAccountResp.setAddress(populateAddress(contactDetail.getMailingAddress(), "MAIL"));
			}
			else if(contactDetail.getResidentialAddress() != null)
			{
				businessAccountResp.setAddress(populateAddress(contactDetail.getResidentialAddress(), "RES"));
			}			
		}
	}
	
	public BusinessAccountResp populateResponseSolDir(Boolean activate, List<BusinessAccountDetails> businessAcctDtlsList, ContactDetail contactDetail, String crsStatus, CRSInfo crsInfo, ThreatMatrix threatMatrix, String sessionThreatMatrixSessionID, String extUrl) throws ResourceException, BusinessException{
		BusinessAccountResp businessAccountResp = new BusinessAccountResp();
		
		businessAccountResp.setActivate(activate);
		populateAddressResp(contactDetail, businessAccountResp);
		businessAccountResp.setEmail(contactDetail.getEmail());
		
		if(activate && businessAcctDtlsList.size()>0){
			List<ACNDetailsResp> acnDtslList = new ArrayList<ACNDetailsResp>();
			
			for(BusinessAccountDetails businessAcctDtls : businessAcctDtlsList){
				ACNDetailsResp acnDtls = new ACNDetailsResp();
				acnDtls.setAcn(businessAcctDtls.getAcn());
				acnDtls.setAcnName(businessAcctDtls.getAcnName());
				acnDtslList.add(acnDtls);
			}
			
			businessAccountResp.setAcnList(acnDtslList);
		}
		
		businessAccountResp.setForeignTaxResident(crsStatus);
		businessAccountResp.setCrsInfo(crsInfo);
		businessAccountResp.setStates(getStateList());
		businessAccountResp.setSourceOfFundsList(IBankParams.getSourceOfFundsList());
		businessAccountResp.setSourceOfWealthList(IBankParams.getSourceOfWealthList());
		businessAccountResp.setExternalUrl(extUrl);
		
		if(threatMatrix != null){
			businessAccountResp = populateThreatMatrixInfo(businessAccountResp, threatMatrix, sessionThreatMatrixSessionID);
		}
		
		
		businessAccountResp.setQasUrl(IBankParams.getAddressTypeaheadURL(IBankParams.DEFAULT_ORIGIN));
		
		return businessAccountResp;
	}
	private ArrayList<String> getStateList()
	{
		ArrayList<String> stateList = (ArrayList<String>) IBankParams.getStates();
		return stateList;
	}
	
	private AddressResp populateAddress(Address address, String type)
	{
		AddressResp mbAddress = new AddressResp();
		if (address != null)
		{
			mbAddress.setAddrType(type);
			mbAddress.setCountryName(address.getCountryName());
			mbAddress.setLine1(address.getLine1());
			mbAddress.setLine2(address.getLine2());
			mbAddress.setLine3(address.getLine3());

			mbAddress.setPostCode(address.getPostZipcode());
			mbAddress.setState(address.getState());
			mbAddress.setSuburb(address.getSuburb());
		}
		return mbAddress;

	}
	
	
	public BusinessAccountResp populateResponse(List<LabelValueVO> tradingNames)
	{
		BusinessAccountResp businessAccountResp = new BusinessAccountResp();
		businessAccountResp.setTradingNames(tradingNames);
		return businessAccountResp;
	}
	
	public IMBResp populateIndustryTypeResponse(List<LabelValueVO> industryTypes)
	{
		BusinessAccountResp businessAccountResp = new BusinessAccountResp();
		businessAccountResp.setIndustryTypeList(industryTypes);
		return businessAccountResp;
	}
	
	public IMBResp populateOccupationTypeResponse(List<LabelValueVO> occupationTypes)
	{
		BusinessAccountResp businessAccountResp = new BusinessAccountResp();
		businessAccountResp.setOccupationCodeList(occupationTypes);
		return businessAccountResp;
	}
	
	public List<LabelValueVO> populateBusinessNames(List<String> tradingNames){
		List<LabelValueVO> businessNames = new ArrayList<LabelValueVO>();
		for(int i=0; i<tradingNames.size(); i++){
			businessNames.add(new LabelValueVO(tradingNames.get(i), (i+1)+""));
		}
		return businessNames;
	}
	
	public BusinessAccountResp populateThreatMatrixInfo(BusinessAccountResp businessAccountResp, ThreatMatrix threatMatrix, String sessionThreatMatrixSessionID)
	{
		if(null!=businessAccountResp){
			
			businessAccountResp.setSessionId(threatMatrix.getTrackingID());
			businessAccountResp.setOrgId(threatMatrix.getOrgID());
			businessAccountResp.setPageId(threatMatrix.getPageID());
			businessAccountResp.setThreatMatrixURL(threatMatrix.getThreatMatrixURL());
			
			if(sessionThreatMatrixSessionID == null){
				businessAccountResp.setThreatMatrixReqd(true);
			}
			else{
				businessAccountResp.setThreatMatrixReqd(false);
			}
		}	
		return businessAccountResp;
	}
	
	public IMBResp populateResponse(String url)
	{
		BusinessAccountResp businessAccountResp = new BusinessAccountResp();
		businessAccountResp.setExternalUrl(url);
		return businessAccountResp;
	}
	
	public List<ErrorInfo> getErrorList(String header, String message) {
		List<ErrorInfo> errorList = new ArrayList<ErrorInfo>();
		ErrorInfo eachError = new ErrorInfo();
		eachError.setCode(header);
		eachError.setMessage(header);
		errorList.add(eachError);
		return errorList;
	}
	
	public String getHardStopMsgHeader(Integer key)
	{
		return hardStoperrorCodeLabelMap.get(key);
	}
	private static Map<Integer,String> hardStoperrorCodeLabelMap = new HashMap<Integer,String>() {
        {
              put(BusinessException.BUS_ACCOUNT_TIME_OUT,"We are sorry."); 
              put(BusinessException.BUS_ACCOUNT_TRDING_FAILED,"Thank you."); 
              put(BusinessException.BUS_ACCOUNT_IP_TO_IP_FAILED,"Thank you.");               
              put(BusinessException.BUS_ACCOUNT_OPEN_PRIMARY_FAILED_BFA,"Thank you."); 
              put(BusinessException.BUS_ACCOUNT_OPEN_SECONDRY_FAILED_BSA,"Thank you.");  
              put(BusinessException.BUSINESS_ACCOUNT_RECEIVED_REQUEST_WILL_PROCESS,"We are sorry.");
              put(BusinessException.BUS_ACCOUNT_ABN_FUZZY_MATCH_TO_CUTOMER_NAME_FAILED,"Thank you.");
              put(BusinessException.BUS_ACCOUNT_SPLIT_ADDRESS,"We are sorry.");
              put(BusinessException.BUS_ACCOUNT_VERIFY_BLACK_LISTED_IPS_FAILED,"We are sorry.");
              put(BusinessException.BUS_ACCOUNT_OPEN_POLLING_TIME_OUT,"Thank you."); 
              put(BusinessException.BUS_ACCOUNT_IDV_FAILED,"Thank you.");
              put(BusinessException.BUSINESS_ACCOUNT_CUSTOMER_REIDVED,"12000302");
        }
  };
  
  private static Map<Integer,String> errorCodeLabelMap = new HashMap<Integer,String>() {
      {
    	  put(BusinessException.BUS_ACCOUNT_ORG_IDV_FAILED,"Thank you.");
    	  put(BusinessException.BUSINESS_ACCOUNTS_CREATED,"Thank you."); 
      }
  };

	public String getErrorMsgHeader(Integer key)
	{
		return errorCodeLabelMap.get(key);
	}
    
}
