package au.com.stgeorge.mbank.model.request.payments;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

import org.apache.commons.lang.builder.ReflectionToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;

import au.com.stgeorge.mbank.model.common.IMBReq;
import au.com.stgeorge.mbank.model.common.ReqHeader;

public class BPayReceiptsRequest implements IMBReq {
	private static final long serialVersionUID = 2022242446298729854L;

	// @Valid TODO
	private ReqHeader header;

	@NotNull(message = "Please select a biller")
	private Integer toBillerIndex;

	public Integer getToBillerIndex() {
		return toBillerIndex;
	}
	
	public void setToBillerIndex(Integer toBillerIndex) {
		this.toBillerIndex=toBillerIndex;
	}

	public ReqHeader getHeader() {
		return header;
	}

	public void setHeader(ReqHeader header) {
		this.header = header;
	}

	@Override
	public String toString() {
		return ReflectionToStringBuilder.toString(this, ToStringStyle.MULTI_LINE_STYLE);
	}
}
