package au.com.stgeorge.mbank.controller.offers;

import java.text.SimpleDateFormat;

import org.springframework.stereotype.Service;

import au.com.stgeorge.ibank.common.cache.IBankParams;
import au.com.stgeorge.ibank.service.valueobject.OfferDetails;
import au.com.stgeorge.mbank.model.response.offers.RetentionResp;

@Service
public class RetentionHelper {
	public RetentionResp populateRetentionEligibilityResp(OfferDetails savingSavingsOfferDetails){
		RetentionResp retentionResp = new RetentionResp();
		retentionResp.setEligible(savingSavingsOfferDetails.isEligibleForSavingSavingsOffer());
		if(savingSavingsOfferDetails.isEligibleForSavingSavingsOffer()){
			retentionResp.setStdInterestRate(savingSavingsOfferDetails.getStdInterestRate().toString());
			retentionResp.setPeriod(savingSavingsOfferDetails.getPeriod());
			retentionResp.setAddInterestRate(savingSavingsOfferDetails.getAddInterestRate().toString());
			retentionResp.setRetentionFeedbackReasonList(IBankParams.getRetentionSurveyReasonList());
		}
		return retentionResp;
	}
	
	public String getTotalInterestRate(String stdIntRate, String addIntRate){
		return Integer.toString(Integer.parseInt(stdIntRate)+Integer.parseInt(addIntRate));
	}
	
	public RetentionResp populateRetentionAcceptResp(OfferDetails savingSavingsOfferDetails){
		RetentionResp retentionResp = new RetentionResp();
		
		SimpleDateFormat sdf = new SimpleDateFormat("dd MMM yyyy");
		retentionResp.setStdInterestRate(savingSavingsOfferDetails.getStdInterestRate().toString());
		retentionResp.setPeriod(savingSavingsOfferDetails.getPeriod());
		retentionResp.setAddInterestRate(savingSavingsOfferDetails.getAddInterestRate().toString());
		retentionResp.setTotalInterestRate(savingSavingsOfferDetails.getTotalInterestRate().toString());
		retentionResp.setExpiryDate(sdf.format(savingSavingsOfferDetails.getExpiryDate()));
			
		return retentionResp;
	}
	
	public RetentionResp populateAcceptOfferResp(OfferDetails acceptOfferDetails){
		
		RetentionResp retentionResp = new RetentionResp();
		
		SimpleDateFormat sdf = new SimpleDateFormat("MMMM yyyy");
		SimpleDateFormat sdfcb = new SimpleDateFormat("dd MMM yyyy");
		
		if(OfferDetails.isCashbackOffer(acceptOfferDetails.getOfferType())){
			retentionResp.setAmountCB(acceptOfferDetails.getAmountCB());
			retentionResp.setMinTransactionsCB(acceptOfferDetails.getMinTransactionsCB());
			retentionResp.setMinDepositAmountCB(acceptOfferDetails.getMinDepositAmountCB());
			retentionResp.setPeriodCB(acceptOfferDetails.getPeriodCB());
			retentionResp.setExpiryDate(sdfcb.format(acceptOfferDetails.getExpiryDate()));
		}
		
		if(OfferDetails.isFeeWaiverOffer(acceptOfferDetails.getOfferType())){
			retentionResp.setMonthlyServiceFeeFW(acceptOfferDetails.getMonthlyServiceFeeFW());
			retentionResp.setAmountFW(acceptOfferDetails.getAmountFW());
			retentionResp.setPeriodFW(acceptOfferDetails.getPeriodFW());
			retentionResp.setExpiryDate(sdf.format(acceptOfferDetails.getExpiryDate()));
		}
		
	    retentionResp.setAccountNumber(acceptOfferDetails.getAccountNumber());
	    retentionResp.setBsbNumber(acceptOfferDetails.getBsbNumber());
	    retentionResp.setProductName(acceptOfferDetails.getProductName());
	    
	    return retentionResp;
	}
	
}
