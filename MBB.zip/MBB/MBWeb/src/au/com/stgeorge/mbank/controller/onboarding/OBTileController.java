package au.com.stgeorge.mbank.controller.onboarding;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import au.com.stgeorge.framework.common.logging.Logger;
import au.com.stgeorge.ibank.businessobject.BusinessException;
import au.com.stgeorge.ibank.businessobject.ResourceException;
import au.com.stgeorge.ibank.common.cache.IBankParams;
import au.com.stgeorge.ibank.onboarding.businessobject.OBTileService;
import au.com.stgeorge.ibank.util.ServiceHelper;
import au.com.stgeorge.ibank.valueobject.transfer.IBankCommonData;
import au.com.stgeorge.mbank.controller.IMBController;
import au.com.stgeorge.mbank.model.common.IMBReq;
import au.com.stgeorge.mbank.model.common.IMBResp;
import au.com.stgeorge.mbank.model.common.ReqHeader;
import au.com.stgeorge.mbank.model.common.RespHeader;
import au.com.stgeorge.mbank.model.request.EmptyReq;
import au.com.stgeorge.mbank.model.request.onboarding.FeatureReq;
import au.com.stgeorge.mbank.model.request.onboarding.SaveSegmentRequest;
import au.com.stgeorge.mbank.model.response.ErrorResp;
import au.com.stgeorge.mbank.model.response.SuccessResp;
import au.com.stgeorge.mbank.model.response.onboarding.OBFeatureListResp;
import au.com.stgeorge.mbank.model.response.onboarding.OBSegmentListResp;
import au.com.stgeorge.mbank.session.MobileSession;
import au.com.stgeorge.mbank.util.MBAppHelper;
import au.com.stgeorge.mbank.util.MBAppUtils;
import au.com.stgeorge.mbank.util.MBAppValidator;
import au.com.stgeorge.mbank.util.ServiceConstants;
import au.com.stgeorge.perflogger.PerformanceLogger;

import com.fasterxml.jackson.databind.ObjectMapper;

@Controller
@RequestMapping("/obtile")
public class OBTileController implements IMBController
{

	@Autowired
	private PerformanceLogger perfLogger;
	@Autowired
	private MBAppHelper mbAppHelper;
	
	@Autowired
	private MBAppValidator mbAppValidator;
	
	@Autowired
	private OBTileHelper obTileHelper;

	/**
	 * End point for getting the OBtileSuccessResp object as a response from OBTile Not Right Now button in MB
	 * @param httpServletRequest
	 * @param httpServletResponse
	 * @param req
	 * @return successResp
	 * @throws IOException
	 */
	@RequestMapping(value= "minimise" , method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public IMBResp updateMinimiseTile(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, @RequestBody final EmptyReq req)
	{				
				
		ObjectMapper objectMapper = new ObjectMapper();							
		perfLogger.startAllLogs();
		String logName = MBAppUtils.getLogName(httpServletRequest);
		perfLogger.startLog(logName);		
		MobileSession mbSession = null;		
		try{	
			
			mbSession = mbAppHelper.getMobileSession(httpServletRequest);												
			Logger.info("OBTileController.updateMinimiseTile Request :" + objectMapper.writeValueAsString(req), this.getClass());
			
			validateRequestHeader(req.getHeader(), httpServletRequest);
			
			IBankCommonData commonData=mbAppHelper.populateIBankCommonData(mbSession, httpServletRequest);
			OBTileService oBTileService = (OBTileService)ServiceHelper.getBean("obTileService");
			commonData.setGdwOrigin(commonData.getOrigin());
			oBTileService.updateOBViewStatus(commonData, "MIN");

			RespHeader headerResp = populateResponseHeader("obTileMinimisedResponse", mbSession);
			SuccessResp successResp = new SuccessResp();
			successResp.setHeader(headerResp);
			successResp.setIsSuccess(true);
			
			Logger.info("updateMinimiseTile | for Onboarding Screens | JSON Response :" + objectMapper.writeValueAsString(successResp), this.getClass());
			
			return successResp;
			
		}catch (BusinessException e)
		{
			Logger.error("Exception inside updateMinimiseTile", e, this.getClass());
			BusinessException exp = new BusinessException(BusinessException.SYSTEM_UNAVILABLE);
			IMBResp resp1  = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, ServiceConstants.MINIMISE_OBTILE_SERVICE, httpServletRequest);
			return resp1;
		} catch (ResourceException e) {
			Logger.error("Exception inside updateMinimiseTile", e, this.getClass());
			BusinessException exp = new BusinessException(BusinessException.SYSTEM_UNAVILABLE);
			IMBResp resp1  = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, ServiceConstants.MINIMISE_OBTILE_SERVICE, httpServletRequest);
			return resp1;
		}catch (Exception e)
		{
			Logger.error("Exception inside updateMinimiseTile", e, this.getClass());
			BusinessException exp = new BusinessException(BusinessException.SYSTEM_UNAVILABLE);
			IMBResp resp1  = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, ServiceConstants.MINIMISE_OBTILE_SERVICE, httpServletRequest);
			return resp1;
		} finally
		{
			perfLogger.endLog(logName);
			perfLogger.endAllLogs();
		}	
	}
	
	
	@RequestMapping(value= "getsegments" , method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public IMBResp getSegmentList(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, @RequestBody final EmptyReq req)
	{				
				
		ObjectMapper objectMapper = new ObjectMapper();							
		perfLogger.startAllLogs();
		String logName = MBAppUtils.getLogName(httpServletRequest);
		perfLogger.startLog(logName);		
		MobileSession mbSession = null;		
		try{	
			
			mbSession = mbAppHelper.getMobileSession(httpServletRequest);												
			Logger.info("OBTileController.getSegmentList Request :" + objectMapper.writeValueAsString(req), this.getClass());						
			
			validateRequestHeader(req.getHeader(), httpServletRequest);
			
			IBankCommonData commonData= mbAppHelper.populateIBankCommonData(mbSession, httpServletRequest);
			commonData.setGdwOrigin(commonData.getOrigin());
			OBTileService oBTileService = (OBTileService)ServiceHelper.getBean("obTileService");

			RespHeader headerResp = populateResponseHeader("obTileGetSegmentListResponse", mbSession);
			OBSegmentListResp obSegmentListResp = new OBSegmentListResp();
			obSegmentListResp.setHeader(headerResp);
			
			obTileHelper.populateOBSegmentResp(oBTileService.getSegmentList(commonData) ,obSegmentListResp);
			oBTileService.addActivityLogForTileClick(commonData);
			Logger.info("getsegments | for Onboarding Screens | JSON Response :" + objectMapper.writeValueAsString(obSegmentListResp), this.getClass());
			
			return obSegmentListResp;
			
		}catch (BusinessException e)
		{
			Logger.error("Exception inside getSegmentList", e, this.getClass());
			BusinessException exp = new BusinessException(BusinessException.SYSTEM_UNAVILABLE);
			IMBResp resp1  = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, ServiceConstants.OBTILE_GETSEGMENTS_SERVICE, httpServletRequest);
			return resp1;
		} catch (ResourceException e) {
			Logger.error("Exception inside getSegmentList", e, this.getClass());
			BusinessException exp = new BusinessException(BusinessException.SYSTEM_UNAVILABLE);
			IMBResp resp1  = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, ServiceConstants.OBTILE_GETSEGMENTS_SERVICE, httpServletRequest);
			return resp1;
		}catch (Exception e)
		{
			Logger.error("Exception inside getSegmentList", e, this.getClass());
			BusinessException exp = new BusinessException(BusinessException.SYSTEM_UNAVILABLE);
			IMBResp resp1  = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, ServiceConstants.OBTILE_GETSEGMENTS_SERVICE, httpServletRequest);
			return resp1;
		} finally
		{
			perfLogger.endLog(logName);
			perfLogger.endAllLogs();
		}	
	}
	
	
	@RequestMapping(value= "savesegments" , method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public IMBResp saveSegments(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, @RequestBody final SaveSegmentRequest req)
	{
		ObjectMapper objectMapper = new ObjectMapper();							
		perfLogger.startAllLogs();
		String logName = MBAppUtils.getLogName(httpServletRequest);
		perfLogger.startLog(logName);		
		MobileSession mbSession = null;		
		try{	
			
			mbSession = mbAppHelper.getMobileSession(httpServletRequest);												
			Logger.info("OBTileController.savesegments Request :" + objectMapper.writeValueAsString(req), this.getClass());
			
			validateRequestHeader(req.getHeader(), httpServletRequest);
			ErrorResp errorResp = validate(req, httpServletRequest);
			if (errorResp != null && errorResp.getErrors() != null && errorResp.getErrors().size() > 0)
			{									
				return errorResp;
			}								
			
			IBankCommonData commonData=mbAppHelper.populateIBankCommonData(mbSession, httpServletRequest);
			OBTileService oBTileService = (OBTileService)ServiceHelper.getBean("obTileService");
			commonData.setGdwOrigin(commonData.getOrigin());
			oBTileService.saveSegmentsAndFeatures(commonData, req.getSegments());
			RespHeader headerResp = populateResponseHeader("obTileSaveSegmentResponse", mbSession);
			
			OBFeatureListResp obFeatureListResp = new OBFeatureListResp();
			obFeatureListResp.setHeader(headerResp);
			
			obTileHelper.populateOBFeatureResp(oBTileService.prepareTileFeatureList(commonData, commonData.getCustomer(), commonData.getCustomer().getObTileVO()) ,obFeatureListResp, IBankParams.getBaseOriginCode(commonData.getOrigin()));
			
			Logger.info("saveSegments | for Onboarding Screens | JSON Response :" + objectMapper.writeValueAsString(obFeatureListResp), this.getClass());
			
			return obFeatureListResp;
			
		}catch (BusinessException e)
		{
			Logger.error("Exception inside saveSegments", e, this.getClass());
			BusinessException exp = new BusinessException(BusinessException.SYSTEM_UNAVILABLE);
			IMBResp resp1  = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, ServiceConstants.OBTILE_SAVESEGMENTS_SERVICE, httpServletRequest);
			return resp1;
		} catch (ResourceException e) {
			Logger.error("Exception inside saveSegments", e, this.getClass());
			BusinessException exp = new BusinessException(BusinessException.SYSTEM_UNAVILABLE);
			IMBResp resp1  = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, ServiceConstants.OBTILE_SAVESEGMENTS_SERVICE, httpServletRequest);
			return resp1;
		}catch (Exception e)
		{
			Logger.error("Exception inside saveSegments", e, this.getClass());
			BusinessException exp = new BusinessException(BusinessException.SYSTEM_UNAVILABLE);
			IMBResp resp1  = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, ServiceConstants.OBTILE_SAVESEGMENTS_SERVICE, httpServletRequest);
			return resp1;
		} finally
		{
			perfLogger.endLog(logName);
			perfLogger.endAllLogs();
		}	
	}
	
	
	@RequestMapping(value= "getfeatures" , method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public IMBResp getFeatureList(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, @RequestBody final EmptyReq req)
	{				
				
		ObjectMapper objectMapper = new ObjectMapper();							
		perfLogger.startAllLogs();
		String logName = MBAppUtils.getLogName(httpServletRequest);
		perfLogger.startLog(logName);		
		MobileSession mbSession = null;		
		try{	
			
			mbSession = mbAppHelper.getMobileSession(httpServletRequest);												
			Logger.info("OBTileController.getFeatureList Request :" + objectMapper.writeValueAsString(req), this.getClass());						
			
			validateRequestHeader(req.getHeader(), httpServletRequest);
			IBankCommonData commonData= mbAppHelper.populateIBankCommonData(mbSession, httpServletRequest);
			commonData.setGdwOrigin(commonData.getOrigin());
			OBTileService oBTileService = (OBTileService)ServiceHelper.getBean("obTileService");
			
			RespHeader headerResp = populateResponseHeader("obTileGetFeatureListResponse", mbSession);
			OBFeatureListResp obFeatureListResp = new OBFeatureListResp();
			obFeatureListResp.setHeader(headerResp);
			
			obTileHelper.populateOBFeatureResp(oBTileService.prepareTileFeatureList(commonData, commonData.getCustomer(), commonData.getCustomer().getObTileVO()),obFeatureListResp, IBankParams.getBaseOriginCode(commonData.getOrigin()));
			oBTileService.addActivityLogForTileClick(commonData);
			Logger.info("getfeatures | for Onboarding Screens | JSON Response :" + objectMapper.writeValueAsString(obFeatureListResp), this.getClass());
			
			return obFeatureListResp;
			
		}catch (BusinessException e)
		{
			Logger.error("Exception inside getFeatureList", e, this.getClass());
			BusinessException exp = new BusinessException(BusinessException.SYSTEM_UNAVILABLE);
			IMBResp resp1  = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, ServiceConstants.OBTILE_GETFEATURES_SERVICE, httpServletRequest);
			return resp1;
		} catch (ResourceException e) {
			Logger.error("Exception inside getFeatureList", e, this.getClass());
			BusinessException exp = new BusinessException(BusinessException.SYSTEM_UNAVILABLE);
			IMBResp resp1  = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, ServiceConstants.OBTILE_GETFEATURES_SERVICE, httpServletRequest);
			return resp1;
		}catch (Exception e)
		{
			Logger.error("Exception inside getFeatureList", e, this.getClass());
			BusinessException exp = new BusinessException(BusinessException.SYSTEM_UNAVILABLE);
			IMBResp resp1  = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, ServiceConstants.OBTILE_GETFEATURES_SERVICE, httpServletRequest);
			return resp1;
		} finally
		{
			perfLogger.endLog(logName);
			perfLogger.endAllLogs();
		}	
	}
	
	
	@RequestMapping(value= "updatefeaturestatus" , method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public IMBResp updateFeatureStatus(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, @RequestBody final FeatureReq req)
	{				
				
		ObjectMapper objectMapper = new ObjectMapper();							
		perfLogger.startAllLogs();
		String logName = MBAppUtils.getLogName(httpServletRequest);
		perfLogger.startLog(logName);		
		MobileSession mbSession = null;		
		try{	
			
			mbSession = mbAppHelper.getMobileSession(httpServletRequest);												
			Logger.info("OBTileController.updatefeaturestatus Request :" + objectMapper.writeValueAsString(req), this.getClass());
			
			validateRequestHeader(req.getHeader(), httpServletRequest);
			ErrorResp errorResp = validate(req, httpServletRequest);
			if (errorResp != null && errorResp.getErrors() != null && errorResp.getErrors().size() > 0)
			{									
				return errorResp;
			}								
			
			IBankCommonData commonData=mbAppHelper.populateIBankCommonData(mbSession, httpServletRequest);
			OBTileService oBTileService = (OBTileService)ServiceHelper.getBean("obTileService");
			
			commonData.setGdwOrigin(commonData.getOrigin());
			
			oBTileService.updateFeatureStatusOnclick(commonData,commonData.getCustomer().getObTileVO(), req.getFeatureID());
			
			RespHeader headerResp = populateResponseHeader("obTileUpdateFeatureStatusResponse", mbSession);
			SuccessResp successResp = new SuccessResp();
			successResp.setHeader(headerResp);
			successResp.setIsSuccess(true);
			
			Logger.info("updatefeaturestatus | for Onboarding Screens | JSON Response :" + objectMapper.writeValueAsString(successResp), this.getClass());
			
			return successResp;
			
		}catch (BusinessException e)
		{
			Logger.error("Exception inside updatefeaturestatus", e, this.getClass());
			BusinessException exp = new BusinessException(BusinessException.SYSTEM_UNAVILABLE);
			IMBResp resp1  = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, ServiceConstants.OBTILE_UPDATE_FEATURE_STATUS, httpServletRequest);
			return resp1;
		} catch (ResourceException e) {
			Logger.error("Exception inside updatefeaturestatus", e, this.getClass());
			BusinessException exp = new BusinessException(BusinessException.SYSTEM_UNAVILABLE);
			IMBResp resp1  = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, ServiceConstants.OBTILE_UPDATE_FEATURE_STATUS, httpServletRequest);
			return resp1;
		}catch (Exception e)
		{
			Logger.error("Exception inside updatefeaturestatus", e, this.getClass());
			BusinessException exp = new BusinessException(BusinessException.SYSTEM_UNAVILABLE);
			IMBResp resp1  = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, ServiceConstants.OBTILE_UPDATE_FEATURE_STATUS, httpServletRequest);
			return resp1;
		} finally
		{
			perfLogger.endLog(logName);
			perfLogger.endAllLogs();
		}	
	}
	
	@RequestMapping(value= "activitylog" , method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    public IMBResp addActivityLog(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, @RequestBody final FeatureReq req)
    {                       
                      
          ObjectMapper objectMapper = new ObjectMapper();                                     
          perfLogger.startAllLogs();
          String logName = MBAppUtils.getLogName(httpServletRequest);
          perfLogger.startLog(logName);       
          MobileSession mbSession = null;           
          try{  
                
                mbSession = mbAppHelper.getMobileSession(httpServletRequest);                                                                       
                Logger.info("OBTileController.addActivityLog Request :" + objectMapper.writeValueAsString(req), this.getClass());
                
                validateRequestHeader(req.getHeader(), httpServletRequest);
                ErrorResp errorResp = validate(req, httpServletRequest);
                if (errorResp != null && errorResp.getErrors() != null && errorResp.getErrors().size() > 0)
                {                                                     
                      return errorResp;
                }                                               
                
                IBankCommonData commonData=mbAppHelper.populateIBankCommonData(mbSession, httpServletRequest);
                OBTileService oBTileService = (OBTileService)ServiceHelper.getBean("obTileService");
                
                commonData.setGdwOrigin(commonData.getOrigin());
                
                oBTileService.addActivityLog(commonData, req.getFeatureID());
                
                
                RespHeader headerResp = populateResponseHeader("addActivityLog", mbSession);
                SuccessResp successResp = new SuccessResp();
                successResp.setHeader(headerResp);
                successResp.setIsSuccess(true);
                
                
                Logger.info("addActivityLog | JSON Response :" + objectMapper.writeValueAsString(successResp), this.getClass());
                
                return successResp;
                
          }catch (BusinessException e)
          {
                Logger.error("Exception inside addActivityLog", e, this.getClass());
                BusinessException exp = new BusinessException(BusinessException.SYSTEM_UNAVILABLE);
                IMBResp resp1  = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, ServiceConstants.OBTILE_ACTIVITYLOG_FEATURE_CLICK, httpServletRequest);
                return resp1;
          } catch (ResourceException e) {
                Logger.error("Exception inside addActivityLog", e, this.getClass());
                BusinessException exp = new BusinessException(BusinessException.SYSTEM_UNAVILABLE);
                IMBResp resp1  = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, ServiceConstants.OBTILE_ACTIVITYLOG_FEATURE_CLICK, httpServletRequest);
                return resp1;
          }catch (Exception e)
          {
                Logger.error("Exception inside addActivityLog", e, this.getClass());
                BusinessException exp = new BusinessException(BusinessException.SYSTEM_UNAVILABLE);
                IMBResp resp1  = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, ServiceConstants.OBTILE_ACTIVITYLOG_FEATURE_CLICK, httpServletRequest);
                return resp1;
          } finally
          {
                perfLogger.endLog(logName);
                perfLogger.endAllLogs();
          }     
    }

	
	@Override
	public void validateRequestHeader(ReqHeader headerReq,HttpServletRequest request) throws BusinessException {
		
		mbAppValidator.validateRequestHeader(headerReq, request);
		
	}
	@Override
	public ErrorResp validate(IMBReq serviceRequest,
			HttpServletRequest httpRequest) throws BusinessException {
		// TODO Auto-generated method stub
		 return mbAppValidator.validate(serviceRequest, httpRequest);
	}
	
	public RespHeader populateResponseHeader(String serviceName, MobileSession mobSession )
	{
		return mbAppHelper.populateResponseHeader(serviceName, mobSession);
	}
	
}
