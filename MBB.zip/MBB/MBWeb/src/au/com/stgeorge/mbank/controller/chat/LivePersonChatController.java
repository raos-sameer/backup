package au.com.stgeorge.mbank.controller.chat;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;

import com.fasterxml.jackson.databind.ObjectMapper;

import au.com.stgeorge.digitalsec.logger.DigitalSecLogger;
import au.com.stgeorge.digitalsec.logger.DigitalSecLogggerVO;
import au.com.stgeorge.framework.common.logging.Logger;
import au.com.stgeorge.ibank.businessobject.BusinessException;
import au.com.stgeorge.ibank.businessobject.LivePersionChatServiceImpl;
import au.com.stgeorge.ibank.businessobject.LivePersonChatService;
import au.com.stgeorge.ibank.businessobject.PreferencesService;
import au.com.stgeorge.ibank.businessobject.ResourceException;
import au.com.stgeorge.ibank.common.cache.IBankParams;
import au.com.stgeorge.ibank.valueobject.LivePersonChat;
import au.com.stgeorge.ibank.valueobject.SecureMessagingConfig;
import au.com.stgeorge.ibank.valueobject.SecureMessagingConfigVO;
import au.com.stgeorge.ibank.valueobject.mortgage.MortgageSessionInfo;
import au.com.stgeorge.ibank.valueobject.transfer.IBankCommonData;
import au.com.stgeorge.mbank.controller.IMBController;
import au.com.stgeorge.mbank.controller.customer.LogonHelper;
import au.com.stgeorge.mbank.model.common.IMBReq;
import au.com.stgeorge.mbank.model.common.IMBResp;
import au.com.stgeorge.mbank.model.common.ReqHeader;
import au.com.stgeorge.mbank.model.common.RespHeader;
import au.com.stgeorge.mbank.model.request.EmptyReq;
import au.com.stgeorge.mbank.model.chat.request.LivePersonChatReq;
import au.com.stgeorge.mbank.model.request.mortgage.MortgageChatSessionResp;
import au.com.stgeorge.mbank.model.response.ErrorResp;
import au.com.stgeorge.mbank.model.response.SuccessResp;
import au.com.stgeorge.mbank.model.response.chat.SecureMessagingConfigResponse;
import au.com.stgeorge.mbank.model.response.chat.SecureMessagingConfiguration;
import au.com.stgeorge.mbank.model.response.mortgage.ChatTokenResp;
import au.com.stgeorge.mbank.session.MobileSession;
import au.com.stgeorge.mbank.session.MobileSessionImpl;
import au.com.stgeorge.mbank.util.MBAppHelper;
import au.com.stgeorge.mbank.util.MBAppUtils;
import au.com.stgeorge.mbank.util.MBAppValidator;
import au.com.stgeorge.mbank.util.ServiceConstants;
import au.com.stgeorge.perflogger.PerformanceLogger;

@Controller
@RequestMapping("/livepersonchat")
public class LivePersonChatController implements IMBController {
	
	@Autowired
	private MBAppValidator mbAppValidator;

	@Autowired
	private MBAppHelper mbAppHelper;

	@Autowired
	private PerformanceLogger perfLogger;

	@Autowired
	private LivePersonChatService livePersonChatService;
	
	@Autowired
	private LogonHelper logonHelper;
	
	@Autowired
	private DigitalSecLogger digitalSecLogger;
	
	private static final String GDW_DESCRIPTION_DM = "DM";
	private static final String GDW_DESCRIPTION_MOBILE = "Mobile";
	private static final String GDW_DESCRIPTION_NATIVE = "Native";
	
	@Override
	public void validateRequestHeader(ReqHeader header, HttpServletRequest request) throws BusinessException {
		mbAppValidator.validateRequestHeader(header, request);
	}

	@Override
	public ErrorResp validate(IMBReq request, HttpServletRequest httpRequest) throws BusinessException {
		return mbAppValidator.validate(request, httpRequest);
	}

	public void validateDigitalMortgageRequestHeader(ReqHeader header, HttpServletRequest request)
			throws ResourceException, BusinessException {
		mbAppValidator.validateDigitalMortgageRequestHeader(header, request);
	}

	@Override
	public RespHeader populateResponseHeader(String serviceName, MobileSession mobSession) {
		return mbAppHelper.populateResponseHeader(serviceName, mobSession);
	}

	@RequestMapping(method = RequestMethod.POST, headers = "content-type=application/json", produces = MediaType.APPLICATION_JSON_VALUE, value = "getLPSessionID")
	@ResponseBody
	public IMBResp getLivePersonSessionId(HttpServletRequest httpRequest, @RequestBody final EmptyReq request) {
		Logger.debug("LivePersonChatController - get(). Request: " + request, this.getClass());
		String logName = startPerformanceLog(httpRequest);
		MobileSession mobileSession = new MobileSessionImpl();

		try {
			mobileSession = mbAppHelper.getMobileSession(httpRequest);
			validateDigitalMortgageRequestHeader(request.getHeader(), httpRequest);
			ErrorResp errorResponse = mbAppValidator.validateAsync(request, httpRequest);
			if (errorResponse.hasErrors())
				return errorResponse;
			
			// prepare live person chat object

			String sessionID = livePersonChatService
					.createLivePersonChatSession(prepareLivePersonChat(httpRequest, mobileSession));

			// mobileSession.invalidateSession();
			
			RespHeader header = mbAppHelper.populateAsyncResponseHeader(ServiceConstants.LIVEPERSONCHAT_SERVICE, mobileSession);
			IMBResp serviceResponse = populateChatSessionResponse(header, sessionID);

			return serviceResponse;

		} catch (BusinessException e) {
			Logger.info("BusinessException in LivePersonChatController - check() - [key: " + e.getKey()
					+ "] : GCIS: ["
					+ ((mobileSession != null && mobileSession.getCustomer() != null)
							? mobileSession.getCustomer().getGcis()
							: "")
					+ "] :", e, this.getClass());
			if (e.getKey() == BusinessException.MORTGAGE_SESSION_SHARING_ERROR) {
				Logger.error(
						"Session is sharing among multiple tabs or browsers and multiple applications are trying to update using the same session......",
						this.getClass());
				return MBAppUtils.createErrorResp(mobileSession.getOrigin(),
						BusinessException.MORTGAGE_SESSION_SHARING_ERROR,
						ServiceConstants.LIVEPERSONCHAT_SERVICE, httpRequest);
			} else {
				return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.SYSTEM_UNAVILABLE,
						ServiceConstants.LIVEPERSONCHAT_SERVICE, httpRequest);
			}
		} catch (ResourceException e) {
			Logger.error("ResourceException in LivePersonChatController - check() - [key: " + e.getKey()
					+ "] : GCIS: ["
					+ ((mobileSession != null && mobileSession.getCustomer() != null)
							? mobileSession.getCustomer().getGcis()
							: "")
					+ "] :", e, this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.SYSTEM_UNAVILABLE,
					ServiceConstants.LIVEPERSONCHAT_SERVICE, httpRequest);
		} catch (Exception e) {
			Logger.error("Exception LivePersonChatController - check(): GCIS: ["
					+ ((mobileSession != null && mobileSession.getCustomer() != null)
							? mobileSession.getCustomer().getGcis()
							: "")
					+ "] :", e, this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(),
					ResourceException.MOBILE_NON_FINANCIAL_FATAL_ERR, ServiceConstants.LIVEPERSONCHAT_SERVICE,
					httpRequest);
		} finally {
			endPerformanceLog(logName);
		}
	}

	@RequestMapping(method = RequestMethod.POST, headers = "content-type=application/json", produces = MediaType.APPLICATION_JSON_VALUE, value = "initRefreshLivePersonChatToken")
	@ResponseBody
	public IMBResp initRefreshLivePersonChatToken(HttpServletRequest httpRequest, @RequestBody final EmptyReq request) {
		Logger.debug("MortgageLivePersonChatController - initRefreshLivePersonChatToken(). Request: " + request,
				this.getClass());

		String logName = startPerformanceLog(httpRequest);
		MobileSession mobileSession = null;

		try {
			mobileSession = mbAppHelper.getMobileSession(httpRequest);
			// validateRequestHeader(request.getHeader(), httpRequest);
			// Added to solve the issue of Session sharing among multiple tabs or browsers
			// and multiple applications are trying to update using the same session.
			//validateDigitalMortgageRequestHeader(request.getHeader(), httpRequest);
			ErrorResp errorResponse = mbAppValidator.validateAsync(request, httpRequest);
			if (errorResponse.hasErrors()) {
				return errorResponse;
			}

			// Get LoanType Ref Data
			String token = livePersonChatService
					.getCreateRefreshJWTForLivePersonChat(prepareLivePersonChat(httpRequest, mobileSession),mobileSession.getOrigin());
			
			ChatTokenResp chatTokenResp = new ChatTokenResp();
			chatTokenResp.setJwtToken(token);

			// mortgageService.makeChatStatsEntry(mortgageCommonData, "Chat Initiated",
			// MortgageUtil.GWDStatatisticActionsEnum.ChatInit.getValue());

			RespHeader headerResp = mbAppHelper.populateAsyncResponseHeader(ServiceConstants.LIVEPERSONCHAT_SERVICE, mobileSession);
			chatTokenResp.setHeader(headerResp);
			ObjectMapper mapper = new ObjectMapper();

			Logger.debug("MortgageLivePersonChatController - initRefreshLivePersonChatToken() JSON Response :"
					+ mapper.writeValueAsString(chatTokenResp), this.getClass());

			return chatTokenResp;
		} catch (BusinessException e) {
			Logger.error("BusinessException - initRefreshLivePersonChatToken():", e, this.getClass());

			if (e.getKey() == BusinessException.MORTGAGE_SESSION_SHARING_ERROR) {
				Logger.error(
						"Session is sharing among multiple tabs or browsers and multiple applications are trying to update using the same session......",
						this.getClass());
				return MBAppUtils.createErrorRespAsync(mobileSession.getOrigin(), BusinessException.MORTGAGE_SESSION_SHARING_ERROR, "", ServiceConstants.LIVEPERSONCHAT_SERVICE, httpRequest);
			} else {
				return MBAppUtils.createErrorRespAsync(mobileSession.getOrigin(), BusinessException.SYSTEM_UNAVILABLE, "System Unavailable",
						ServiceConstants.LIVEPERSONCHAT_SERVICE, httpRequest);
			}
		} catch (Exception e) {
			Logger.error("Exception in MortgageLivePersonChatController - initRefreshLivePersonChatToken(): ", e,
					this.getClass());
			return MBAppUtils.createErrorRespAsync(mobileSession.getOrigin(), BusinessException.SYSTEM_UNAVILABLE,"System Unavailable",
					ServiceConstants.LIVEPERSONCHAT_SERVICE, httpRequest);
		} finally {
			endPerformanceLog(logName);
		}
	}
	
	@RequestMapping(method = RequestMethod.POST, headers = "content-type=application/json", produces = MediaType.APPLICATION_JSON_VALUE, value = "sendChatEvent")
	@ResponseBody
	public IMBResp sendChatEvent(HttpServletRequest httpRequest,
			@RequestBody final LivePersonChatReq request) throws BusinessException {
		Logger.debug("LivePersonChatController - sendChatEvent(). Request: Event Type: "
				+ request.getEventType(), this.getClass());

		String logName = startPerformanceLog(httpRequest);
		MobileSession mobileSession = null;
		int status = 0;
		try {
			mobileSession = mbAppHelper.getMobileSession(httpRequest);
			ErrorResp errorResponse = mbAppValidator.validateAsync(request, httpRequest);
			if (errorResponse.hasErrors()) {
				return errorResponse;
			}			
			if(request.getEventType() != null) {
				status = request.getEventType();
			}
								
			LivePersonChat livePersonChat = prepareLivePersonChat(httpRequest, mobileSession);
			livePersonChat.setStatus(status);
			//21E1 code
			livePersonChatService.updateLivePersonChatStatus(livePersonChat);
			//process chat event - make update preference table/GDW for chat events/forensic log entry based on eventType.
			//processChatEvent(livePersonChat, request);
			//save the chat status in session
			if(null == mobileSession.getMortgageSessionInfo()) {
				mobileSession.getCustomer().getPreference().setSecureChatStatus(status);
			}
			RespHeader headerResp = mbAppHelper.populateAsyncResponseHeader(ServiceConstants.LIVEPERSONCHAT_SERVICE, mobileSession);
			SuccessResp response = new SuccessResp();
			response.setHeader(headerResp);
			response.setIsSuccess(true);
			return response;
		} catch (Exception e) {
			Logger.error("Exception in LivePersonChatController - sendChatEvent(): GCIS: ["
					+ ((mobileSession != null && mobileSession.getCustomer() != null)
							? mobileSession.getCustomer().getGcis()
							: "")
					+ "]", e, this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.GENERIC_ERROR,
					ServiceConstants.LIVEPERSONCHAT_SERVICE, httpRequest);
		} finally {
			endPerformanceLog(logName);
		}
	}
	
/*
 * This methods is used for process different secure chat events.
 * Event Type:
 * 	1 - chat start 
 *  0 - chat end 
 *  2 - resume 
 *  3 - agent change
 *  It will do following based on eventType.
 * - update preference table
 * - forensic
 * - gdw
 */
private void processChatEvent(LivePersonChat livePersonChat,LivePersonChatReq request) throws Exception {
		
	Logger.debug("LivePersonChatController - processChatEvent(): Start: Event Type: "
			+ request.getEventType(), this.getClass());
	
		DigitalSecLogggerVO digitalSecLoggerVO = new DigitalSecLogggerVO();
		digitalSecLoggerVO.setCommonLogData(mbAppHelper.getCommonLogData(livePersonChat.getCommonData()));
		digitalSecLoggerVO.setUserAgent(livePersonChat.getCommonData().getUserAgent());
		digitalSecLoggerVO.setStatus(DigitalSecLogger.SUCCESS);

		int currentChatStatus = 0;
		StringBuffer logBuffer = null;
		
		
		if(request.getEventType() != null) {
			
			currentChatStatus = request.getEventType();
			String gdwDescription = livePersonChat.getGdwDescription()+DigitalSecLogger.DELIMITER_SEMI_COLON+request.getPageName();
			
			switch(currentChatStatus) {
			
			case LivePersionChatServiceImpl.CHAT_START:
				//update preference table
				livePersonChatService.updateLivePersonChatStatus(livePersonChat);
				//GDW entry for start chat event
				livePersonChatService.gdwEntryLivePersonChatStatus(livePersonChat.getCommonData(),currentChatStatus, gdwDescription);
				//Forensic log entry 
				logBuffer = new StringBuffer();
				logBuffer.append(DigitalSecLogger.CAMPAIGN_ID).append(DigitalSecLogger.DELIMITER_COLON).append(request.getCampaignId()).append(DigitalSecLogger.DELIMITER_COMMA);
				logBuffer.append(DigitalSecLogger.VISITOR_ID).append(DigitalSecLogger.DELIMITER_COLON).append(request.getVisitorId()).append(DigitalSecLogger.DELIMITER_COMMA);
				logBuffer.append(DigitalSecLogger.PAGE_NAME).append(DigitalSecLogger.DELIMITER_COLON).append(request.getPageName());
				digitalSecLoggerVO.setValues(logBuffer.toString());
				digitalSecLoggerVO.setTranName(LivePersionChatServiceImpl.TRAN_NAME_CHAT_START);
				digitalSecLogger.log(digitalSecLoggerVO);
				
				break;

			case LivePersionChatServiceImpl.CHAT_END : 
				//update preference table
				livePersonChatService.updateLivePersonChatStatus(livePersonChat);
				//GDW entry end chat event
				livePersonChatService.gdwEntryLivePersonChatStatus(livePersonChat.getCommonData(),currentChatStatus, gdwDescription);
				//Forensic log entry
				logBuffer = new StringBuffer();
				logBuffer.append(DigitalSecLogger.PAGE_NAME).append(DigitalSecLogger.DELIMITER_COLON).append(request.getPageName());
				digitalSecLoggerVO.setValues(logBuffer.toString());
				digitalSecLoggerVO.setTranName(LivePersionChatServiceImpl.TRAN_NAME_CHAT_END);
				digitalSecLogger.log(digitalSecLoggerVO);
				break;
			
			case LivePersionChatServiceImpl.CHAT_RESUME:
				livePersonChat.setStatus(LivePersionChatServiceImpl.CHAT_START);
				//update preference table
				livePersonChatService.updateLivePersonChatStatus(livePersonChat);
				//GDW entry resume chat event
				livePersonChatService.gdwEntryLivePersonChatStatus(livePersonChat.getCommonData(),currentChatStatus, gdwDescription);
				break;
				
			case LivePersionChatServiceImpl.AGENT_CHANGE :
				//Forensic log entry for Agent change event
				logBuffer = new StringBuffer();
				logBuffer.append(DigitalSecLogger.AGENT_ID).append(DigitalSecLogger.DELIMITER_COLON).append(request.getAgentId()).append(DigitalSecLogger.DELIMITER_COMMA);
				logBuffer.append(DigitalSecLogger.AGENT_NAME).append(DigitalSecLogger.DELIMITER_COLON).append(request.getAgentName()).append(DigitalSecLogger.DELIMITER_COMMA);
				logBuffer.append(DigitalSecLogger.PAGE_NAME).append(DigitalSecLogger.DELIMITER_COLON).append(request.getPageName());
				digitalSecLoggerVO.setValues(logBuffer.toString());
				digitalSecLoggerVO.setTranName(LivePersionChatServiceImpl.TRAN_NAME_AGENT_CHANGE);
				digitalSecLogger.log(digitalSecLoggerVO);
				
				break;
			}
			
		}
		
		Logger.debug("LivePersonChatController - processChatEvent(): End", this.getClass());
		
	}
	
	@RequestMapping(method = RequestMethod.POST, headers = "content-type=application/json", produces = MediaType.APPLICATION_JSON_VALUE, value = "getConfig")
	@ResponseBody
	public IMBResp getConfig(HttpServletRequest httpRequest, @RequestBody final EmptyReq request) throws BusinessException {
		Logger.debug("Start LivePersonChatController - getConfig(). Request: " + request, this.getClass());
		String logName = startPerformanceLog(httpRequest);
		MobileSession mobileSession = null;
		try {
			mobileSession = mbAppHelper.getMobileSession(httpRequest);
			ErrorResp errorResponse = mbAppValidator.validateAsync(request, httpRequest);
			if (errorResponse.hasErrors()) {
				return errorResponse;
			}
			String originCode = IBankParams.getBaseOriginCode(mobileSession.getOrigin());
			String channelType = LivePersionChatServiceImpl.MOBILE;
			boolean isMobileApp = ((logonHelper.loadCordova(httpRequest)) == -1) ? false : true;
			if (isMobileApp) {
				channelType = LivePersionChatServiceImpl.NATIVE;
			}
			
			List<SecureMessagingConfigVO> configList = livePersonChatService.getLivePersonMessagingConfig(originCode, channelType);
			
			RespHeader headerResp = mbAppHelper.populateAsyncResponseHeader(ServiceConstants.LIVEPERSONCHAT_SERVICE, mobileSession);
			SecureMessagingConfigResponse response = prepareSecureMessagingConfigResponse(configList);
			response.setHeader(headerResp);
			return response;

		} catch (Exception e) {
			Logger.error("Exception in MortgageLivePersonChatController - getConfig(): ", e, this.getClass());
			return MBAppUtils.createErrorRespAsync(mobileSession.getOrigin(), BusinessException.SYSTEM_UNAVILABLE, "System Unavailable",
					ServiceConstants.LIVEPERSONCHAT_SERVICE, httpRequest);
		} finally {
			Logger.debug("End LivePersonChatController - getConfig(). Request: " + request, this.getClass());
			endPerformanceLog(logName);
		}
	}

	private SecureMessagingConfigResponse prepareSecureMessagingConfigResponse(List<SecureMessagingConfigVO> configList) {
		Logger.debug("Start prepareSecureMessagingConfigResponse(). config list size : " + configList.size(), this.getClass());
		SecureMessagingConfigResponse response = new SecureMessagingConfigResponse();
		List<SecureMessagingConfiguration> configurationList = new ArrayList();
		for (SecureMessagingConfigVO secureMessagingConfig : configList) {
			SecureMessagingConfiguration config = new SecureMessagingConfiguration();
			config.setAllowNewChat(secureMessagingConfig.isAllowNewChat());
			config.setAllowResumeChat(secureMessagingConfig.isAllowResumeChat());
			config.setShowFloatingIcon(secureMessagingConfig.isShowFloatingIcon());
			config.setCampaignSectionTag(secureMessagingConfig.getCampaignSectionTag());
			config.setPageName(secureMessagingConfig.getPageName());
			configurationList.add(config);
		}
		response.setSecureMessagingConfig(configurationList);
		Logger.debug("End prepareSecureMessagingConfigResponse(). Response config list size: " + response.getSecureMessagingConfig().size(),
				this.getClass());
		return response;
	}
	
	private LivePersonChat prepareLivePersonChat(HttpServletRequest httpRequest, MobileSession mobileSession) {
		LivePersonChat livePersonChat = new LivePersonChat();
		livePersonChat.setSessionID(mobileSession.getSessionID());
		if (null != mobileSession.getDeviceID()) {
			livePersonChat.setDeviceID(mobileSession.getDeviceID());
		}
		if (null == mobileSession.getMortgageSessionInfo()) {
			Logger.debug("LivePersonChatController - prepareLivePersonChat() IBMB Channel", this.getClass());
			livePersonChat.setIBMBChannel(true);
			IBankCommonData commonData = mbAppHelper.populateIBankCommonData(mobileSession, httpRequest);
			Logger.debug("IBankCommonData customer" + commonData.getCustomer() , this.getClass());
			commonData.setOrigin(mobileSession.getOrigin());
			livePersonChat.setCommonData(commonData);
			boolean isMobileApp = ((logonHelper.loadCordova(httpRequest)) == -1) ? false:true;
			if(isMobileApp) {
				livePersonChat.setGdwDescription(GDW_DESCRIPTION_NATIVE); 
			}else {
				livePersonChat.setGdwDescription(GDW_DESCRIPTION_MOBILE); 
			}
			
		} else {
			Logger.debug("LivePersonChatController - prepareLivePersonChat() Morgage Session" + mobileSession.getMortgageSessionInfo(), this.getClass());
			MortgageSessionInfo mortgageSession = mobileSession.getMortgageSessionInfo();
			livePersonChat.setMortgageSession(mortgageSession);
			IBankCommonData commonData = mbAppHelper.populateIBankCommonData(mobileSession, httpRequest);
			Logger.debug("LivePersonChatController - commonData User " + commonData.getUser() , this.getClass());
			commonData.setOrigin(mobileSession.getOrigin());
			livePersonChat.setCommonData(commonData);	
			livePersonChat.setGdwDescription(GDW_DESCRIPTION_DM);
		}
		return livePersonChat;
	}

	/**
	 * Response for invalid body request
	 * 
	 * @return
	 */
	@ExceptionHandler({ org.springframework.http.converter.HttpMessageNotReadableException.class })
	@ResponseStatus(org.springframework.http.HttpStatus.OK)
	@ResponseBody
	public IMBResp resolveException() {
		return MBAppUtils.createInvalidMessageBodyResponse(ServiceConstants.MORTGAGE_CHAT_SESSION_SERVICE);
	}

	private MortgageChatSessionResp populateChatSessionResponse(RespHeader header, String sessionID)
			throws BusinessException {
		MortgageChatSessionResp response = new MortgageChatSessionResp(header);
		response.setSessionID(sessionID.replace(LivePersionChatServiceImpl.PREFIX_TOKEN_SESSION, ""));
		return response;
	}

	private String startPerformanceLog(HttpServletRequest httpRequest) {
		perfLogger.startAllLogs();
		String logName = MBAppUtils.getLogName(httpRequest);
		perfLogger.startLog(logName);
		return logName;
	}

	private void endPerformanceLog(String logName) {
		perfLogger.endLog(logName);
		perfLogger.endAllLogs();
	}
}
