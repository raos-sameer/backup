package au.com.stgeorge.mbank.controller.offers;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.fasterxml.jackson.databind.ObjectMapper;

import au.com.stgeorge.framework.common.logging.Logger;
import au.com.stgeorge.ibank.businessobject.BusinessException;
import au.com.stgeorge.ibank.businessobject.OfferService;
import au.com.stgeorge.ibank.businessobject.ResourceException;
import au.com.stgeorge.ibank.common.cache.IBankParams;
import au.com.stgeorge.ibank.service.valueobject.OfferDetails;
import au.com.stgeorge.ibank.valueobject.Invitation;
import au.com.stgeorge.ibank.valueobject.OffersSearchVO;
import au.com.stgeorge.ibank.valueobject.database.OriginsVO;
import au.com.stgeorge.ibank.valueobject.transfer.IBankCommonData;
import au.com.stgeorge.mbank.controller.IMBController;
import au.com.stgeorge.mbank.model.common.IMBReq;
import au.com.stgeorge.mbank.model.common.IMBResp;
import au.com.stgeorge.mbank.model.common.ReqHeader;
import au.com.stgeorge.mbank.model.common.RespHeader;
import au.com.stgeorge.mbank.model.request.offers.AemOfferDetailsReq;
import au.com.stgeorge.mbank.model.request.offers.SalesOfferReq;
import au.com.stgeorge.mbank.model.response.ErrorResp;
import au.com.stgeorge.mbank.session.MobileSession;
import au.com.stgeorge.mbank.util.MBAppHelper;
import au.com.stgeorge.mbank.util.MBAppUtils;
import au.com.stgeorge.mbank.util.MBAppValidator;
import au.com.stgeorge.mbank.util.ServiceConstants;
import au.com.stgeorge.perflogger.PerformanceLogger;

@Controller
@RequestMapping("/aemoffer")
public class AemOfferController implements IMBController{

	@Autowired
	private MBAppHelper mbAppHelper;
	
	@Autowired
	private MBAppValidator mbAppValidator;
	
	@Autowired
	private SalesOfferHelper salesOfferHelper;
	
	@Autowired
	private OfferService offerService;
	
	@Autowired
	private PerformanceLogger perfLogger;
	
	@Autowired
	private AemOfferHelper aemOfferHelper;
	
	@RequestMapping(value= "details" , method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public IMBResp getAemOfferDetails(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse,
			@RequestBody final AemOfferDetailsReq req)
	{				
				
		ObjectMapper objectMapper = new ObjectMapper();								
		perfLogger.startAllLogs();
		String logName = MBAppUtils.getLogName(httpServletRequest);
		perfLogger.startLog(logName);
				
		MobileSession mbSession = null;
		try{	
			
			mbSession = mbAppHelper.getMobileSession(httpServletRequest);		
			Logger.info("getAemOfferDetails JSON Request :" + objectMapper.writeValueAsString(req), this.getClass());
			//Bypassing name id check as this is an async call
			//validateRequestHeader(req.getHeader(), httpServletRequest);
			ErrorResp errorResp = validateAsync(req, httpServletRequest);
			if (errorResp != null && errorResp.getErrors() != null && errorResp.getErrors().size() > 0){
				return errorResp;
			}			
																																	
			IBankCommonData commonData=mbAppHelper.populateIBankCommonData(mbSession,httpServletRequest);
			
			OffersSearchVO offersSearchVO = null;
			
			//Applied switch check for AEM campaign look up
			if(IBankParams.isBrandSwitchOn(commonData.getOrigin(), IBankParams.AEM_NBA_CAMPAIGN_SWITCH)){
				offersSearchVO = offerService.getOfferDetailsByCampaignID(commonData, req.getCampaignCode().trim(),IBankParams.isSwitchOn(IBankParams.AEM_ADMIN_TEMPLATE_SWITCH));				
			}else{
				throw new BusinessException(BusinessException.OFFER_DETAILS_NOT_FOUND);
			} 
							
			IMBResp serviceResponse = salesOfferHelper.populateAemOfferDetailsResp(offersSearchVO,commonData);
									
			RespHeader headerResp = mbAppHelper.populateAsyncResponseHeader(ServiceConstants.AEM_OFFER_DETAIL_SERVICE, mbSession);
			serviceResponse.setHeader(headerResp);
			
			Logger.info("getAemOfferDetails JSON Response :" + objectMapper.writeValueAsString(serviceResponse), this.getClass());
			
			return serviceResponse;		
		}catch (BusinessException e){
			BusinessException exp = null;
			Logger.info("BusinessException Inside getAemOfferDetails() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "]", e, this.getClass());		
			exp = new BusinessException(e.getKey());
			IMBResp resp1  = MBAppUtils.createErrorRespAsync(mbSession.getOrigin() ,exp, ServiceConstants.AEM_OFFER_DETAIL_SERVICE, httpServletRequest);
			return resp1;
		}catch (ResourceException e){
			Logger.error("ResourceException Inside getAemOfferDetails() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "]", e, this.getClass());			
			ResourceException exp = new ResourceException(BusinessException.SYSTEM_UNAVILABLE);
			IMBResp resp1  = MBAppUtils.createErrorRespAsync(mbSession.getOrigin(), exp, ServiceConstants.AEM_OFFER_DETAIL_SERVICE, httpServletRequest);
			return resp1;
		}catch (Exception e){			
			Logger.error("Exception Inside getAemOfferDetails() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "]", e, this.getClass());
			BusinessException exp = new BusinessException(BusinessException.SYSTEM_UNAVILABLE);
			IMBResp resp1  = MBAppUtils.createErrorRespAsync(mbSession.getOrigin(), exp, ServiceConstants.AEM_OFFER_DETAIL_SERVICE, httpServletRequest);
			return resp1;
		} finally{
			perfLogger.endLog(logName);
			perfLogger.endAllLogs();
		}				
	}
	
	@RequestMapping(value = "validateretention", method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public IMBResp validateRetention(HttpServletRequest httpServletRequest,HttpServletResponse httpServletResponse,	@RequestBody final SalesOfferReq req) { 
				
		ObjectMapper objectMapper = new ObjectMapper();										
		
		perfLogger.startAllLogs();
		String logName = MBAppUtils.getLogName(httpServletRequest);
		perfLogger.startLog(logName);					

		MobileSession mbSession = null;
		Invitation invitation = null;
		
		try{			
			mbSession = mbAppHelper.getMobileSession(httpServletRequest);
			Logger.info("validateRetention :: Message Content JSON Request :" + objectMapper.writeValueAsString(req), this.getClass());
			ErrorResp errorResp = validate(req, httpServletRequest);
					
			if (errorResp != null && errorResp.getErrors() != null && errorResp.getErrors().size() > 0)
			{				
				return errorResp;
				
			} else {					
				IBankCommonData commonData=mbAppHelper.populateIBankCommonData(mbSession,httpServletRequest);
				
				invitation = offerService.getOfferAemRetention(commonData, req.getLeadId());
				if(invitation.isOfferApplied())
					throw new BusinessException(BusinessException.RETENTION_CUSTOM_ERROR);
				else
					mbSession.setRetentionCampaignLead(req.getLeadId().trim());
				
				OfferDetails offerDetails = new OfferDetails();
				if(invitation.getOfferEndDate()!=null){
					offerDetails.setExpiryDate(invitation.getOfferEndDate());
				}
				
				mbSession.setOfferDetails(offerDetails);
			}
			Logger.debug("Lead id in session : "+ mbSession.getRetentionCampaignLead(),this.getClass());
			IMBResp serviceResponse = aemOfferHelper.populateAemRetentionResponse(invitation);
			
			RespHeader headerResp = populateResponseHeader(ServiceConstants.AEM_OFFER_DETAIL_SERVICE, mbSession);
			serviceResponse.setHeader(headerResp);
			
			Logger.info("validateRetention :: JSON Response :" + objectMapper.writeValueAsString(serviceResponse), this.getClass());

			return serviceResponse;	
							
		}catch (BusinessException e)
		{
			Logger.info("BusinessException Inside validateRetention() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			BusinessException exp = new BusinessException(e.getKey());
			
			IMBResp resp1 = null;
			if(e.getKey() == BusinessException.MYINVITATION_INVALID_OFFER)
			{
				OriginsVO myOriginVO  = IBankParams.getOrigin(mbSession.getOrigin());
				OriginsVO baseOrigin  = IBankParams.getOrigin(myOriginVO.getBankName());
				String[] values = {baseOrigin.getPhone()};	
				resp1  = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, values, ServiceConstants.OFFER_DETAIL_SERVICE, httpServletRequest);
			}
			else if(BusinessException.RETENTION_CUSTOM_ERROR == e.getKey() || BusinessException.RETENTION_SAVINGS_ACCEPT_FAILED == e.getKey()){
				OriginsVO myOriginVO  = IBankParams.getOrigin(mbSession.getOrigin());
				OriginsVO baseOrigin  = IBankParams.getOrigin(myOriginVO.getBankName());
				String[] values = {baseOrigin.getPhone()};	
				resp1  = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp,values,ServiceConstants.OFFER_DETAIL_SERVICE, httpServletRequest);
	    	}
			else{				
				resp1  = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, ServiceConstants.OFFER_DETAIL_SERVICE, httpServletRequest);
			}
			
			return resp1;
						
		} catch (ResourceException e) {
			Logger.error("ResourceException Inside validateRetention() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			ResourceException exp = new ResourceException(e.getKey());
			IMBResp resp1  = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, ServiceConstants.OFFER_DETAIL_SERVICE, httpServletRequest);
			return resp1;
		} catch (Exception e) {
			Logger.error("Exception Inside validateRetention() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			BusinessException exp = new BusinessException(BusinessException.GENERIC_ERROR);
			IMBResp resp1  = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, ServiceConstants.OFFER_DETAIL_SERVICE, httpServletRequest);			
			return resp1;			
		} finally {
			perfLogger.endLog(logName);
			perfLogger.endAllLogs();
		}						
	}	
	
	
	@Override
	public void validateRequestHeader(ReqHeader headerReq,
			HttpServletRequest request) throws BusinessException {
		mbAppValidator.validateRequestHeader(headerReq,  request);
	}

	@Override
	public ErrorResp validate(IMBReq serviceRequest,
			HttpServletRequest httpRequest) throws BusinessException {
		return  mbAppValidator.validate(serviceRequest, httpRequest);
	}
	
	public ErrorResp validateAsync(IMBReq serviceRequest,
			HttpServletRequest httpRequest) throws BusinessException {
		return  mbAppValidator.validateAsync(serviceRequest, httpRequest);
	}

	@Override
	public RespHeader populateResponseHeader(String serviceName,
			MobileSession mobileSession) {
		return mbAppHelper.populateResponseHeader(serviceName,mobileSession);
	}
}
