package au.com.stgeorge.mbank.model.request.payments;

import javax.validation.Valid;

import org.apache.commons.lang.builder.ReflectionToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;
import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.Length;

import au.com.stgeorge.mbank.model.common.AccountKeyInfoReq;
import au.com.stgeorge.mbank.model.common.IMBReq;
import au.com.stgeorge.mbank.model.common.ReqHeader;

/**
 * Add Payee Request
 * 
 * @author C38854
 * 
 */
public class AddPayeeReq implements IMBReq {

	private static final long serialVersionUID = 3180492891887099677L;

//	@Valid TODO
	private ReqHeader header;

	@Valid
	private AccountKeyInfoReq payeeAccountKeyInfo;

	@Length(max = 50, message = "{errors.payeeEmail.maxlength}")
	@Email(message = "{errors.email.invalid}")
	private String payeeEmail;

	public ReqHeader getHeader() {
		return header;
	}

	public void setHeader(ReqHeader header) {
		this.header = header;
	}

	public String getPayeeEmail() {
		return payeeEmail;
	}

	public AccountKeyInfoReq getPayeeAccountKeyInfo() {
		return payeeAccountKeyInfo;
	}

	@Override
	public String toString() {
		return ReflectionToStringBuilder.toString(this, ToStringStyle.MULTI_LINE_STYLE);
	}

}
