package au.com.stgeorge.mbank.controller.customer;

import java.math.BigDecimal;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import au.com.stgeorge.framework.common.logging.Logger;
import au.com.stgeorge.framework.common.util.StringMethods;
import au.com.stgeorge.ibank.businessobject.BusinessException;
import au.com.stgeorge.ibank.businessobject.HeartBeat;
import au.com.stgeorge.ibank.businessobject.ResourceException;
import au.com.stgeorge.ibank.businessobject.StatisticsService;
import au.com.stgeorge.ibank.common.cache.IBankParams;
import au.com.stgeorge.ibank.common.cache.IBankRefershParams;
import au.com.stgeorge.ibank.common.log.IBankLog;
import au.com.stgeorge.ibank.safi.valueobject.SafiDeviceInfo;
import au.com.stgeorge.ibank.valueobject.Account;
import au.com.stgeorge.ibank.valueobject.Statistic;
import au.com.stgeorge.ibank.valueobject.ThirdParty;
import au.com.stgeorge.ibank.valueobject.transfer.IBankCommonData;
import au.com.stgeorge.mbank.model.response.customer.OnlineSecurityCheckResp;
import au.com.stgeorge.mobilebank.businessobject.EStatementsService;

@Service
public class OnlineSecurityCheckHelper {

	@Autowired
	private EStatementsService mobileEStatementService;
	
	@Autowired
	private IBankRefershParams ibankRefreshParams;
	
	private static final String OSC_LATEST_APP_VERSION_ANDRIOD = "LatestAppVersionAndriod";
	private static final String OSC_LATEST_APP_VERSION_IOS = "LatestAppVersionIOS";
	
	public boolean isEmailMissing(IBankCommonData commonData) {
		if(commonData.getCustomer().getContactDetail() == null || StringMethods.isEmptyString(commonData.getCustomer().getContactDetail().getEmail())) {
			return true;
		}		
		return false;
	}


	public String getUpperLimitPayeeCount(IBankCommonData commonData) {
		String upperLimitPayeeCount="0";
		try {
		
		int upperLimitCount = 0;
		List<ThirdParty> payeeList = commonData.getCustomer().getThirdParties();
		for(ThirdParty payee : payeeList) {
			if(payee.getBankSetup()){
				upperLimitCount ++;
			}
		}
		upperLimitPayeeCount=Integer.toString(upperLimitCount);
		}
		catch(Exception e)
		{
			return "error";
		}
		return upperLimitPayeeCount;
	}
	
	public String getEstmtEligibleCount(IBankCommonData commonData) {
		String accountListSize="0";
		try {
			List<Account> accountList = mobileEStatementService.getMobileSuppressableAccountsList(commonData, commonData.getCustomer());
			accountListSize=Integer.toString(accountList.size());
			return accountListSize;
		}		
		catch (BusinessException e) {
			if((e.getKey()==BusinessException.ESTMT_SERVICE_UNAVILABLE)){
			    return "error";
			}else {
				return "0";
			}
		}
		catch(Exception e)
		{
			return "error";
		}
		
	}
	
	public String latestAppVersionInstalled(SafiDeviceInfo devicePermsInfo, String origin, int appType) {
		try {
			 
		String installedAppVersion = devicePermsInfo != null? devicePermsInfo.getAppVersion():null;
		if (StringMethods.isEmptyString(installedAppVersion)) {
			Logger.info("Installed App version not found via cookies. Returning default false for isLatestAppVersionInstalled", this.getClass());
			return "error";
		}
		installedAppVersion = installedAppVersion.trim();
		String osCode = (appType == 2) ? OSC_LATEST_APP_VERSION_ANDRIOD : OSC_LATEST_APP_VERSION_IOS;
		String latestAppVersion = ibankRefreshParams.getLatestAppVersion(IBankParams.getBaseOriginCode(origin), osCode );
		
		Logger.info("Installed App Version :"+ installedAppVersion +": Latest App Version :"+latestAppVersion+":", this.getClass());
		if (compareAppVersion(extractAppVersion(installedAppVersion), latestAppVersion) >= 0 ) {
			Logger.debug("Installed version greater or equal to current version in DB. Returning true", this.getClass());
			return "true";
		}
		}
		catch (Exception e) {
			Logger.error("Error in checking for latest version of App installed ", e, this.getClass());
			return "error";
		}
		return "false";
	}
	
	public void addStatisticsLog(IBankCommonData commonData, String desc){
		Statistic s = new Statistic();	
		
		s.setAction(Statistic.ONLINE_SECURITY_CHECK_NEW_PAGE);
		s.setGcisNumber(commonData.getUser().getGCISNumber());		
		s.setOriginBank(commonData.getOrigin());	
		s.setDescription(desc);
		s.setIpAddress(commonData.getIpAddress());
		s.setSessionId(commonData.getSessionId());	
		
		try{
			StatisticsService.logStatistic(s);
		}
		catch (Throwable t) {
			IBankLog.logWRN("Failed to create a statistic entry for Online Security check New Menu click ", t, this.getClass());
		}		
	}
	
	public String getGDWDescription(OnlineSecurityCheckResp resp, boolean isMobileApp, int appType) {
		StringBuilder str = new StringBuilder();
		int getEstmtEligibleCount =0;
		int getUpperLimitPayeeCount=0;
		if(! resp.getEstmtEligibleCount().equalsIgnoreCase("error")) {
			 getEstmtEligibleCount=Integer.parseInt(resp.getEstmtEligibleCount());
		}
		if(! resp.getUpperLimitPayeeCount().equalsIgnoreCase("error")) {
		 getUpperLimitPayeeCount=Integer.parseInt(resp.getUpperLimitPayeeCount());
		}
		str.append("ContactDetails:").append(resp.isEmailIdMissing()?"NoEmail":"EmailPresent").append(";");
		if(resp.getEstmtEligibleCount().equalsIgnoreCase("error")){
			str.append("eStatements:").append("Unavailable").append(";");
		}else{
			str.append("eStatements:").append((getEstmtEligibleCount >0) ? resp.getEstmtEligibleCount()+"EligibleAccounts":"Enabled").append(";");
		}
		if(resp.getUpperLimitPayeeCount().equalsIgnoreCase("error")){
			str.append("Payees:").append("Unavailable").append(";");
		}else{
			str.append("Payees:").append((getUpperLimitPayeeCount >0) ? resp.getUpperLimitPayeeCount()+"UpperLimit":"NoUpperLimit").append(";");
		}
		
		if(isMobileApp) {
			if(resp.getLatestAppVersionStatus().equalsIgnoreCase("error")){
				str.append("AppVersion:").append("Unavailable").append(";");
			}else{
				str.append("AppVersion:").append(resp.getLatestAppVersionStatus().equalsIgnoreCase("true")?"UptoDate":"UpdateAvailable").append(";");
			}
			if(resp.getLocationServiceStatus().equalsIgnoreCase("error")){
				str.append("Locations:").append("Unavailable").append(";");
			}else{
				str.append("Locations:").append(resp.getLocationServiceStatus().equalsIgnoreCase("true")?"ON":"OFF").append(";");
			}
			if(resp.getPhoneServiceStatus().equalsIgnoreCase("error")){
				str.append("Telephone:").append(appType == 1?"IOS":"Unavailable").append(";");
			}else{
				str.append("Telephone:").append(appType == 1?"IOS":(resp.getPhoneServiceStatus().equalsIgnoreCase("true")?"ON":"OFF")).append(";");
			}				
			
		}
		return str.toString();
	}
	
	//App version from ds_prm is of type Android-MobBank-BOM.8.2
	//Using the below method to get the last numeric version number for comparison with what's present in releasecodes
	//For the above string this method will return 8.2
	private String extractAppVersion(String version) {
		String ver = version.substring(version.indexOf(".")+1);
		String[] verNos = ver.split("\\.");
		if(verNos.length > 2) {
			return verNos[0] + "." +verNos[1];
		}
		return ver;
	}
	
	/*
	 * returns 1 if version 1 > version 2
	 * returns 0 if version 1 == version 2
	 * returns -1 if version 1 < version 2
	 */
//	private int compareAppVersion(String version1, String version2) {
//        String[] ver1Parts = version1.split("\\.");
//        String[] ver2Parts = version2.split("\\.");
//        int length = Math.max(ver1Parts.length, ver2Parts.length);
//        for(int i = 0; i < length; i++) {
//            int ver1Part = i < ver1Parts.length ?
//                Integer.parseInt(ver1Parts[i]) : 0;
//            int ver2Part = i < ver2Parts.length ?
//                Integer.parseInt(ver2Parts[i]) : 0;
//            if(ver1Part < ver2Part)
//                return -1;
//            if(ver1Part > ver2Part)
//                return 1;
//        }
//        return 0;
//    }
	
	private int compareAppVersion(String version1, String version2) {
		BigDecimal ver1 = new BigDecimal(version1);
		BigDecimal ver2 = new BigDecimal(version2);
		return ver1.compareTo(ver2);
	}
}
