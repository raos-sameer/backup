package au.com.stgeorge.mbank.model.request.mortgage;

import java.io.Serializable;

import javax.validation.Valid;

import au.com.stgeorge.mbank.model.common.IMBReq;
import au.com.stgeorge.mbank.model.common.ReqHeader;
import au.com.stgeorge.mbank.model.mortgageinfo.ApplicationInfo;
import au.com.stgeorge.mbank.model.request.customer.LogonReq;

public class MortgageLogonReq implements IMBReq, Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = -2334701650351329205L;
	private ReqHeader header;
	
	@Valid
	private ApplicationInfo app;
	
	@Valid
	private LogonReq logonReq;
	
	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public ReqHeader getHeader() {
		return header;
	}

	public void setHeader(ReqHeader header) {
		this.header = header;
	}

	public LogonReq getLogonReq() {
		return logonReq;
	}

	public void setLogonReq(LogonReq logonReq) {
		this.logonReq = logonReq;
	}

	public ApplicationInfo getApplicationInfo() {
		return app;
	}
	public void setApp(ApplicationInfo app) {
		this.app = app;
	}
}
