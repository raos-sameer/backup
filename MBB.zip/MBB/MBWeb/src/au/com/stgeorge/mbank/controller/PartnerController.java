package au.com.stgeorge.mbank.controller;

import java.util.Date;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.builder.ReflectionToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import au.com.stgeorge.framework.common.logging.Logger;
import au.com.stgeorge.framework.common.util.StringMethods;
import au.com.stgeorge.ibank.businessobject.BusinessException;
import au.com.stgeorge.ibank.businessobject.ResourceException;
import au.com.stgeorge.ibank.businessobject.impl.OIDCServiceImpl;
import au.com.stgeorge.ibank.common.cache.IBankParams;
import au.com.stgeorge.ibank.valueobject.IDPSSODetails;
import au.com.stgeorge.ibank.valueobject.transfer.IBankCommonData;
import au.com.stgeorge.mbank.model.common.IMBReq;
import au.com.stgeorge.mbank.model.common.IMBResp;
import au.com.stgeorge.mbank.model.common.ReqHeader;
import au.com.stgeorge.mbank.model.common.RespHeader;
import au.com.stgeorge.mbank.model.request.PartnerVendorRequest;
import au.com.stgeorge.mbank.model.response.ErrorResp;
import au.com.stgeorge.mbank.model.response.SuccessResp;
import au.com.stgeorge.mbank.session.MobileSession;
import au.com.stgeorge.mbank.util.MBAppHelper;
import au.com.stgeorge.mbank.util.MBAppUtils;
import au.com.stgeorge.mbank.util.MBAppValidator;
import au.com.stgeorge.mbank.util.ServiceConstants;

@Controller
@RequestMapping("/partner")
public class PartnerController implements IMBController{
	
	@Autowired
	private MBAppHelper mbAppHelper;
	
	@Autowired
	private MBAppValidator mbAppValidator;
    
    private static final String SRV_TOKEN_TYPE = "OIDCToken"; 
    
    @RequestMapping(value="launchVendor", method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public IMBResp launchVendor(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, @RequestBody final PartnerVendorRequest request) throws BusinessException
    {
		Logger.debug("START : launchVendor", this.getClass());
		MobileSession mbSession =  null;
		String app=null;
		mbSession = mbAppHelper.getMobileSession(httpServletRequest);
		try {
			validateRequestHeader(request.getHeader(), httpServletRequest);
			ErrorResp errorResponse = validate(request, httpServletRequest);
			if (errorResponse.hasErrors())
			{
				return errorResponse;
			}
			
			if(null!=request) {
				app=request.getAppName();
			}
			
			
			IBankCommonData commonData = mbAppHelper.populateIBankCommonData(mbSession, httpServletRequest);
			String baseOrigin = IBankParams.getBaseOriginCode(commonData.getOrigin());
				String cookieName = "IBVrfyTk";
				String cookieValue = "";							
				//Create cookie to know which application(IB or MB) has launched Vendor
				OIDCServiceImpl oidcService  = new OIDCServiceImpl();
				IDPSSODetails idpSSODetails = new IDPSSODetails();
				idpSSODetails.setCreationTime(new Date() );
				idpSSODetails.setCustomerType("P");
				idpSSODetails.setGcisNumber( commonData.getUser().getGCISNumber());
				idpSSODetails.setSessionId(mbSession.getSessionID());
				idpSSODetails.setTokenType(SRV_TOKEN_TYPE);
				
				Logger.info("About to get Token : "+app, this.getClass());

				cookieValue = oidcService.getServiceTokenId(idpSSODetails, commonData, SRV_TOKEN_TYPE, true);

				Logger.info("Got Token for vendor launch: "+ cookieValue , this.getClass());

				mbSession.setidpSSODetails(idpSSODetails);

				Logger.info("Update Session Got Token : "+ cookieValue + "Sess Id " + idpSSODetails.getSessionId() , this.getClass());

				addCompassAppTypeCookie(baseOrigin, httpServletRequest, httpServletResponse, cookieName, "MB:"+cookieValue);

				//Adding LaunchedApp = app in session
				//mbSession.setLaunchedApp(app);				
				//returning success response
				Logger.info("Returning success response : ", this.getClass());
				RespHeader headerResp = populateResponseHeader(ServiceConstants.EXTERNAL_VENDOR, mbSession);			
				SuccessResp successResp = new SuccessResp();
				successResp.setHeader(headerResp);
				successResp.setIsSuccess(true);
				Logger.info("Returning success response : complete ", this.getClass());
				return successResp;
		}

		catch (ResourceException e) {
			Logger.error("ResourceException in IdpController - launchVendor - [key: " + e.getKey() + "] : GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());
			return MBAppUtils.createErrorResp(mbSession.getOrigin(), BusinessException.SYSTEM_UNAVILABLE, ServiceConstants.EXTERNAL_VENDOR, httpServletRequest);
		} catch (Exception e) {
			Logger.error("Exception IdpController - launchVendor: GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			return MBAppUtils.createErrorResp(mbSession.getOrigin(), ResourceException.MOBILE_NON_FINANCIAL_FATAL_ERR, ServiceConstants.EXTERNAL_VENDOR, httpServletRequest);
		}    
    }
	public RespHeader populateResponseHeader(String serviceName, MobileSession mobSession) {
		return mbAppHelper.populateResponseHeader(serviceName, mobSession);
	}
	
	public void validateRequestHeader(ReqHeader headerReq, HttpServletRequest request) throws BusinessException {
		Logger.debug("Request header validation: " + ReflectionToStringBuilder.toString(headerReq, ToStringStyle.MULTI_LINE_STYLE), this.getClass());
		new MBAppValidator().validateRequestHeader(headerReq, request);
	}
	
	
	public void addCompassAppTypeCookie(String origin, HttpServletRequest request, HttpServletResponse response, String name, String value) {
		String domainName = request.getServerName();
		if(domainName.contains(".")){
			domainName = domainName.substring(domainName.indexOf("."));
		}		
		if(! StringMethods.isEmptyString(domainName)){
			response.addHeader("Set-Cookie", name + "=" + value + "; path=/" + "; domain="+domainName);
		}
		else{
			response.addHeader("Set-Cookie", name + "=" + value + "; path=/");
		}

		Logger.info(" Added "+ name + " = "+ value, this.getClass());
	}


	public ErrorResp validate(IMBReq serviceRequest, HttpServletRequest request) {
		Logger.info("Service request object - " + ReflectionToStringBuilder.toString(serviceRequest), this.getClass());
		return mbAppValidator.validate(serviceRequest, request);
	}
	

}
