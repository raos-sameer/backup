package au.com.stgeorge.mbank.controller;

import java.util.UUID;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.builder.ReflectionToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import au.com.stgeorge.digitalsec.logger.DigitalSecLogger;
import au.com.stgeorge.digitalsec.logger.DigitalSecLogggerVO;
import au.com.stgeorge.framework.common.logging.Logger;
import au.com.stgeorge.framework.common.util.StringMethods;
import au.com.stgeorge.ibank.businessobject.BusinessException;
import au.com.stgeorge.ibank.businessobject.HeartBeat;
import au.com.stgeorge.ibank.businessobject.IBankSecureService;
import au.com.stgeorge.ibank.businessobject.MadisonExceptionMapHelper;
import au.com.stgeorge.ibank.businessobject.MadisonService;
import au.com.stgeorge.ibank.businessobject.MadisonServiceImpl;
import au.com.stgeorge.ibank.businessobject.MemoryThrottlingService;
import au.com.stgeorge.ibank.businessobject.PRMUpdateService;
import au.com.stgeorge.ibank.businessobject.ResourceException;
import au.com.stgeorge.ibank.businessobject.SafiDigiSecLoggerService;
import au.com.stgeorge.ibank.common.cache.IBankParams;
import au.com.stgeorge.ibank.safi.util.SafiConstants;
import au.com.stgeorge.ibank.safi.valueobject.SafiMadisonVO;
import au.com.stgeorge.ibank.service.valueobject.SafiRespVO;
import au.com.stgeorge.ibank.util.ServiceHelper;
import au.com.stgeorge.ibank.valueobject.Customer;
import au.com.stgeorge.ibank.valueobject.database.OriginsVO;
import au.com.stgeorge.ibank.valueobject.madison.Cards;
import au.com.stgeorge.ibank.valueobject.madison.MadisonCardsVO;
import au.com.stgeorge.ibank.valueobject.transfer.IBankCommonData;
import au.com.stgeorge.mbank.controller.customer.LogonHelper;
import au.com.stgeorge.mbank.model.common.IMBReq;
import au.com.stgeorge.mbank.model.common.IMBResp;
import au.com.stgeorge.mbank.model.common.ReqHeader;
import au.com.stgeorge.mbank.model.common.RespHeader;
import au.com.stgeorge.mbank.model.request.AddToWalletRequest;
import au.com.stgeorge.mbank.model.request.EmptyReq;
import au.com.stgeorge.mbank.model.request.MadisonEligibilityCardsRequest;
import au.com.stgeorge.mbank.model.request.MadisonRequest;
import au.com.stgeorge.mbank.model.request.MadisonSuccessGDWRequest;
import au.com.stgeorge.mbank.model.request.SecureCodeReq;
import au.com.stgeorge.mbank.model.response.AddToWalletResponse;
import au.com.stgeorge.mbank.model.response.ErrorResp;
import au.com.stgeorge.mbank.model.response.MadisonInAppProvisionResp;
import au.com.stgeorge.mbank.model.response.MadisonResponse;
import au.com.stgeorge.mbank.model.response.SuccessResp;
import au.com.stgeorge.mbank.session.MobileSession;
import au.com.stgeorge.mbank.session.MobileSessionImpl;
import au.com.stgeorge.mbank.util.MBAppConstants;
import au.com.stgeorge.mbank.util.MBAppHelper;
import au.com.stgeorge.mbank.util.MBAppUtils;
import au.com.stgeorge.mbank.util.MBAppValidator;
import au.com.stgeorge.mbank.util.ServiceConstants;
import au.com.stgeorge.perflogger.PerformanceLogger;

/**
 * Madison controller
 * 
 */
@Controller
@RequestMapping("/madison")
public class MadisonController implements IMBController {
	
	@Autowired
	private MBAppValidator mbAppValidator;
	
	@Autowired
	private MBAppHelper mbAppHelper;
    
    @Autowired
	private PerformanceLogger perfLogger;
    
    @Autowired
    private MadisonService madisonService;
    
    @Autowired
   	private LogonHelper logonHelper;
    
    @Autowired
    private MadisonHelper madisonHelper;
    
	@Autowired
	private SecureCodeHelper secureCodeHelper;
	
	ObjectMapper mapper = new ObjectMapper();
	
	@Autowired
	private SafiDigiSecLoggerService safiDigiSecLoggerService;
	
	
	
	@Autowired
	private MemoryThrottlingService memoryThrottlingService;
    
	@RequestMapping(method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE, value = "checkEligibility")
	@ResponseBody
	public IMBResp getEligibityForServicesMenu(HttpServletRequest httpRequest, @RequestBody final EmptyReq request) {
		Logger.debug("MadisonController - getEligibityForServicesMenu. Request: " + request, this.getClass());
		String logName = startPerformanceLog(httpRequest);
		MobileSession mobileSession = new MobileSessionImpl();
		MadisonResponse resp = null;
		boolean isEligible=false;
		String learnMoreLink=null;
		String appLink=null;
		try {
			mobileSession.getSessionContext(httpRequest);
			validateRequestHeader(request.getHeader(), httpRequest);
			ErrorResp errorResponse = validate(request, httpRequest);
			if (errorResponse.hasErrors())
			{
				return errorResponse;
			}
			
			IBankCommonData commonData = mbAppHelper.populateIBankCommonData(mobileSession, httpRequest);
			
			String MADISON_SWITCH = IBankParams.getBrandSwitchVal(commonData.getOrigin().trim(), IBankParams.MADISON_SWITCH) ;
			
			if(MADISON_SWITCH.equalsIgnoreCase("1")) {
					isEligible=true;
					learnMoreLink=logonHelper.getLearnMoreLink(commonData.getOrigin().trim());
					appLink=logonHelper.getAppLink(commonData.getOrigin().trim());
			}else if(MADISON_SWITCH.equalsIgnoreCase("2")) {
				boolean isPilot=madisonService.isPilotCustomer(commonData);
				if(isPilot) {
					isEligible=true;
					learnMoreLink=logonHelper.getLearnMoreLink(commonData.getOrigin().trim());
					appLink=logonHelper.getAppLink(commonData.getOrigin().trim());
				}
			}	
			resp = populateMadisonResponse(populateResponseHeader(ServiceConstants.MADISON, mobileSession),isEligible, learnMoreLink, appLink);			
			return resp;
			
		} catch (BusinessException e) {
			Logger.error("BusinessException in MadisonController - getEligibityForServicesMenu - [key: " + e.getKey() + "] : GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), e, ServiceConstants.MADISON, httpRequest);
		} catch (ResourceException e) {
			Logger.error("ResourceException in MadisonController - getEligibityForServicesMenu - [key: " + e.getKey() + "] : GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.SYSTEM_UNAVILABLE, ServiceConstants.MADISON, httpRequest);
		} catch (Exception e) {
			Logger.error("Exception MadisonController - getEligibityForServicesMenu: GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), ResourceException.MOBILE_NON_FINANCIAL_FATAL_ERR, ServiceConstants.MADISON, httpRequest);
		} finally {
			endPerformanceLog(logName);
		}
	}
	
	@RequestMapping(method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE, value = "getEligibleCards")
	@ResponseBody
	public IMBResp getEligibleCards(HttpServletRequest httpRequest, @RequestBody final MadisonEligibilityCardsRequest request)   {
		UUID appCorrelationID = UUID.randomUUID();
		String logName = startPerformanceLog(httpRequest);
		MobileSession mobileSession = new MobileSessionImpl();
		MadisonInAppProvisionResp resp = null;
		MadisonCardsVO madisonCardsVO = null;
		try {
			mobileSession.getSessionContext(httpRequest);
			Logger.info(appCorrelationID + " MadisonController - getEligibleCards. Request: " + mapper.writeValueAsString(request) +" GCIS: "+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : ""), this.getClass());

			validateRequestHeader(request.getHeader(), httpRequest);
			ErrorResp errorResponse = validate(request, httpRequest);
			if (errorResponse.hasErrors()) {
				Logger.error(appCorrelationID + " Validation error in MadisonController - getEligibleCards. Request: " +" GCIS: "+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : ""), this.getClass());
				return errorResponse;
			}
			
			IBankCommonData commonData = mbAppHelper.populateIBankCommonData(mobileSession, httpRequest);
			
			String activatedCard=null;
			
			
			if(null!=request.getEntryPoint()) {
				if(  !MadisonServiceImpl.CARD_ACTIVATION.equals(request.getEntryPoint())) {
					madisonService.addStatLogsForMadisonInApp(commonData, request.getEntryPoint(), null, null,null);
					mobileSession.setMadisonInAppEntryPoint(request.getEntryPoint());
					
				}
				else {
					if(IBankParams.isSwitchOn(IBankParams.MADISON_IN_APP_CARD_ACTIVATION_SWITCH) && mobileSession.getCardActivation()!=null && mobileSession.getCardActivation().getCardNumber()!=null) {
						activatedCard=mobileSession.getCardActivation().getCardNumber();
						Logger.info("MadisonController - getEligibleCards activated card from card activation flow:::: "+activatedCard, this.getClass());
					}
				}
				
			}
			
			madisonCardsVO = madisonService.getEligibleCardsToAddAppleWallet(appCorrelationID, commonData,activatedCard);
		
			if(madisonCardsVO!=null && activatedCard!=null) {
				if(madisonCardsVO.getCards()!=null && madisonCardsVO.getCards().size()>0 && madisonCardsVO.getCards().get(0)!=null && madisonCardsVO.getCards().get(0).getCardProductName()!=null) {
					mobileSession.setMadisonInAppProductName(madisonCardsVO.getCards().get(0).getCardProductName());
				}
			
			}
			
			
			//set the cards in session
			mobileSession.setMadisonCards(madisonCardsVO);
			
			resp = madisonHelper.populateMadisonInAppProvisionResponse(appCorrelationID, commonData, populateResponseHeader(ServiceConstants.MADISON, mobileSession), madisonCardsVO);	
			if(madisonCardsVO != null && resp != null) {
				String apSessionId = madisonService.saveMadisonCardListInSession(appCorrelationID, commonData, madisonCardsVO);
				resp.setApSessionId(apSessionId);
			}
			Logger.info(appCorrelationID + " MadisonController - getEligibleCards. Response: " + mapper.writeValueAsString(resp) +" GCIS: "+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : ""), this.getClass());
			return resp;
			
		} catch (BusinessException e) {
			Logger.error(appCorrelationID + " BusinessException in MadisonController - getEligibleCards - [key: " + e.getKey() + "] : GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());
			
			if(e.getKey() == MadisonExceptionMapHelper.CARD_ELIGIBILITY_MAX_CARD_LIMIT_REACHED) {
				resp = new MadisonInAppProvisionResp(populateResponseHeader(ServiceConstants.MADISON, mobileSession));
				resp.setMaxCardsExceed(true);
				return resp;
			}
			
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), e, ServiceConstants.MADISON, httpRequest);
		} catch (ResourceException e) {
			Logger.error(appCorrelationID + " ResourceException in MadisonController - getEligibleCards - [key: " + e.getKey() + "] : GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.SYSTEM_UNAVILABLE, ServiceConstants.MADISON, httpRequest);
		} catch (Exception e) {
			Logger.error(appCorrelationID + " Exception MadisonController - getEligibleCards: GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), ResourceException.MOBILE_NON_FINANCIAL_FATAL_ERR, ServiceConstants.MADISON, httpRequest);
		} finally {
			endPerformanceLog(logName);
		}
	}
	
	@RequestMapping(method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE, value = "performStatsLogging")
	@ResponseBody
	public IMBResp performStatsLogging(HttpServletRequest httpRequest,HttpServletResponse httpServletResponse, @RequestBody final MadisonRequest request) {
		Logger.debug("MadisonController - performStatsLogging. Request: " + request, this.getClass());
		String logName = startPerformanceLog(httpRequest);
		MobileSession mobileSession = new MobileSessionImpl();
		try {
			mobileSession.getSessionContext(httpRequest);
			validateRequestHeader(request.getHeader(), httpRequest);
			ErrorResp errorResponse = validate(request, httpRequest);
			if (errorResponse.hasErrors())
			{
				return errorResponse;
			}
			
			IBankCommonData commonData = mbAppHelper.populateIBankCommonData(mobileSession, httpRequest);
			madisonService.addStatLogsForMadison(commonData, request.getMadisonGDWAction(), request.getSource());
			
			if(request.isAllowLogout()) {
				mbAppHelper.addAuthCookie(IBankParams.getBaseOriginCode(commonData.getOrigin()), httpRequest, httpServletResponse, true);
				mobileSession.invalidateSession();
			}
			
			SuccessResp successResp = new SuccessResp();																			
			RespHeader headerResp = populateResponseHeader(request.getHeader().getServiceName(), mobileSession);
			successResp.setHeader(headerResp);
			successResp.setIsSuccess(true);	
			return successResp;
			
		} catch (BusinessException e) {

			Logger.error("BusinessException in MadisonController - performStatsLogging - [key: " + e.getKey() + "] : GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), e, ServiceConstants.MADISON, httpRequest);
		} catch (ResourceException e) {
			Logger.error("ResourceException in MadisonController - performStatsLogging - [key: " + e.getKey() + "] : GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.SYSTEM_UNAVILABLE, ServiceConstants.MADISON, httpRequest);
		} catch (Exception e) {
			Logger.error("Exception MadisonController - performStatsLogging: GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), ResourceException.MOBILE_NON_FINANCIAL_FATAL_ERR, ServiceConstants.MADISON, httpRequest);
		} finally {
			endPerformanceLog(logName);
		}
	}
	
	@PostMapping(path="addToWallet2fa", headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public IMBResp addToWallet2FA(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, @RequestBody final AddToWalletRequest req)
	{
		PerformanceLogger performanceLogger = new PerformanceLogger();
		performanceLogger.startAllLogs();
		
		String logName = MBAppUtils.getLogName(httpServletRequest);
		performanceLogger.startLog(logName);
		
		String origin = null;
		MobileSession mbSession = null;
		String cardNumber="";ObjectMapper mapper = new ObjectMapper();
		try
		{
			mbSession = mbAppHelper.getMobileSession(httpServletRequest);
			validateRequestHeader( req.getHeader(), httpServletRequest );
			origin = mbSession.getOrigin();

			ErrorResp errorResp = validate(req, httpServletRequest);
			if (errorResp != null && errorResp.getErrors() != null && errorResp.getErrors().size() > 0)
			{
				return errorResp;
			}
			
			AddToWalletResponse response = new AddToWalletResponse();
			response.setHeader(this.populateResponseHeader(ServiceConstants.MADISON, mbSession));
			Customer customer=mbSession.getCustomer();
						
			IBankCommonData ibankCommonData=mbAppHelper.populateIBankCommonData(mbSession,httpServletRequest);
		
			MadisonCardsVO madisonCardsVO = mbSession.getMadisonCards();String productName="";
			if(null != madisonCardsVO && null != madisonCardsVO.getCards()) {
				Cards card = madisonCardsVO.getCards().get(Integer.valueOf(req.getCardIndex()));
				
				if(null !=card && null != card.getCardNumber()) {
					cardNumber=card.getCardNumber();
					productName=card.getCardProductName();
					mbSession.setMadisonInAppCardNumber(card.getCardNumber());
					Logger.info("MadisonController addToWallet2FA selected card number::::: "+card.getCardNumber()+",product name:::::: "+productName, this.getClass());
				}
				else {
					Logger.error(" Madison Card not found in madisonCardsVO - MadisonController - populateSafiVO : GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", this.getClass());
					throw new BusinessException(BusinessException.SYSTEM_UNAVILABLE);
				}
					
			} else {
				Logger.error(" madisonCardsVO not found in session - MadisonController - addToWallet2FA : GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", this.getClass());
				throw new BusinessException(BusinessException.SYSTEM_UNAVILABLE);
			}
		
			
			
			madisonService.addStatLogsForMadisonInApp(ibankCommonData, MadisonServiceImpl.ADD_TO_APPLE_WALLET,mbSession.getMadisonInAppEntryPoint(),cardNumber,productName);
			
			if(mbSession.getSafiRequestVO()!=null) {
				mbSession.removeSafiRequestVO();
			}
			
			boolean isSafiMadisonSwitchOn = IBankParams.isSwitchOn(IBankParams.DEFAULT_ORIGIN, IBankParams.SAFI_MADISON_SWITCH);
			Logger.debug("SAFI : madison switch Value: "+isSafiMadisonSwitchOn, this.getClass());
			boolean isSafiServiceAvailable = false;

			if(isSafiMadisonSwitchOn){
				isSafiServiceAvailable = HeartBeat.isApplicationAvailable(HeartBeat.SAFI2_SERVICE_APPLICATION);
				
				Logger.info("SAFI : madison2FA :: SAFI2_SERVICE_APPLICATION STATUS: "+isSafiServiceAvailable, this.getClass());
			}
			
			if(isSafiServiceAvailable){
				
				boolean	isThrottleAllowed = memoryThrottlingService.processThrottling(IBankParams.THROTTLE_CAT_MADISON, customer.getGcis(), mbSession.getSessionID());
								
				if(isThrottleAllowed){
 					 response = (AddToWalletResponse) callSafiAnalyse(mapper,httpServletRequest, httpServletResponse, mbSession, ibankCommonData, req,response,cardNumber);
					
					return response;
				
				}else {
					response.setSecureCodeReqd(false);
					return response;
				}
			}else {			
				int errorID=0;boolean errorFlag=false;String status;
				if (madisonHelper.getRegisteredPhoneNumberCount(ibankCommonData.getCustomer().getContactDetail()) == 0) {
					errorID=(BusinessException.SAFI_MADISON_NO_PHONE_EXIST);
					status="Failure_SAFIOFFHOST";
					errorFlag=true;
				} else if (IBankSecureService.isCustomerExempt(ibankCommonData.getCustomer().getIBankSecureDetails())) {
					errorID=(BusinessException.SAFI_MADISON_2FA_EXEMPT);
					status="Failure_SAFIOFFHOST";
					errorFlag=true;
				} else if (IBankParams.isGlobalByPass()) {
					errorID=(BusinessException.SAFI_MADISON_2FA_GLOBAL_BYPASS);
					status="Failure_SAFIOFFHOST";
					errorFlag=true;
				}else {
					status="Pending2FA_SAFIOffhost";
				}
				String errorMessage = madisonService.getForensicLogErrorMessage(errorID);
				DigitalSecLogggerVO digitalSecLogggerVO = safiDigiSecLoggerService.initializeDigitalLogger(ibankCommonData, DigitalSecLogger.APPLEPAY_SETUP, status);
				safiDigiSecLoggerService.logDigiSecForSAFISwitchOFFMadisonInApp(digitalSecLogggerVO, ibankCommonData,errorMessage,cardNumber);

				
				if(errorFlag) {
					throw new BusinessException(errorID);
				}
				response.setSecureCodeReqd(true);
				
				return response;
			}
			
		
			
		} catch (BusinessException e)
		{
		//	digitalSecurityLogVO.setStatus(DigitalSecLogger.FAILURE);
		//	digitalSecurityLogger.log(digitalSecurityLogVO);
			
			IMBResp resp1 = null;
			Logger.error("Exception Inside madison2fa for Customer "+ e.getKey(), e, this.getClass());
			
			if(e.getKey()==BusinessException.SAFI_MADISON_2FA_DENY ||
					e.getKey()==BusinessException.SAFI_MADISON_2FA_EXEMPT ||
					e.getKey()==BusinessException.SAFI_MADISON_NO_PHONE_EXIST ||
					e.getKey()==BusinessException.SAFI_MADISON_2FA_GLOBAL_BYPASS){
				
				Logger.debug("BusinessException in madison2fa - DENY/Exempt/No Phone ERROR", this.getClass());
				OriginsVO myOriginVO = IBankParams.getOrigin(mbSession.getOrigin());
				OriginsVO baseOrigin = IBankParams.getOrigin(myOriginVO.getBankName());
				String[] values = null;
				
				if(e.getKey()==BusinessException.SAFI_MADISON_2FA_DENY)
					values = new String[] { baseOrigin.getBpayPhone()};
				else if(e.getKey() == BusinessException.SAFI_MADISON_2FA_GLOBAL_BYPASS)
					values = new String[] {baseOrigin.getName()};
				else
					values = new String[] {baseOrigin.getPhone()};
				
				IMBResp resp = MBAppUtils.createErrorResp(IBankParams.getBaseOriginCode(mbSession.getOrigin()), e,values, ServiceConstants.MADISON, httpServletRequest);
				return resp;
			}
			
			
			if (e.getValues() != null) {
				resp1 = MBAppUtils.createErrorResp(origin , e, e.getValues(), MBAppConstants.MADISON, httpServletRequest);
			} else if ( e.getKey() == 9898) { //  HOST ERROR TRANSACTION ROLLBACK 
				BusinessException exp = new BusinessException(BusinessException.GENERIC_ERROR);
				resp1 = MBAppUtils.createErrorResp(origin, exp, MBAppConstants.MADISON, httpServletRequest);
			} else{
				resp1 = MBAppUtils.createErrorResp(origin, e, MBAppConstants.MADISON, httpServletRequest);
			}
			return resp1;
			
		} catch (Exception e)
		{
			Logger.error("Exception Inside madison2fa() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			BusinessException exp = new BusinessException(BusinessException.GENERIC_ERROR);
			IMBResp resp1 = MBAppUtils.createErrorResp(origin, exp, MBAppConstants.MADISON, httpServletRequest);
			return resp1;
		} finally
		{
			performanceLogger.endLog(logName);
			performanceLogger.endAllLogs();
		}
	}
	

	@RequestMapping(value="reqsecurecode", method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public IMBResp reqSecureCode(HttpServletRequest httpRequest, HttpServletResponse httpServletResponse,@RequestBody final SecureCodeReq request)
	{
		Logger.debug("In reqSecCode for Customer " +  "  " + httpRequest.getContentType() + " "
				+ httpRequest.getRemoteAddr() + "  " + httpServletResponse.getCharacterEncoding() + httpServletResponse.getLocale() +
				" True IP >> " + httpRequest.getHeader(IBankParams.trueClientIP()), this.getClass());

		PerformanceLogger performanceLogger = new PerformanceLogger();
	//	fraudLogger = new FraudLogger();
		performanceLogger.startAllLogs();
		String logName = MBAppUtils.getLogName(httpRequest);
		performanceLogger.startLog(logName);
		MobileSession mbSession = null;
		try {
			mbSession = mbAppHelper.getMobileSession(httpRequest);
			validateRequestHeader( request.getHeader(), httpRequest );
			
			ErrorResp errorResponse = validate(request, httpRequest);
			if (errorResponse.hasErrors())
				return errorResponse;
			
			
			//check SafiMadisonVO exists in session.
			SafiMadisonVO safiVO = null;
			String safiAction = null;
			
			//check if this me
			if(null != mbSession.getSafiRequestVO() && mbSession.getSafiRequestVO() instanceof SafiMadisonVO) {
				
				Logger.debug("SAFI VO available in session. ", this.getClass());
				
				safiVO = (SafiMadisonVO) mbSession.getSafiRequestVO();
				
				if(null != safiVO.getSafiRespVO())
					safiAction = safiVO.getSafiRespVO().getSafiAction();
			} 
			
			IBankCommonData commonData=mbAppHelper.populateIBankCommonData(mbSession,httpRequest);
			
			IMBResp response = secureCodeHelper.reqSecureCode(commonData, mbSession, mbSession.getTransaction(), request, IBankSecureService.MADISON, httpRequest);
			
			//In case of error log the errors
			if(response instanceof ErrorResp){			
				errorResponse = (ErrorResp) response;
				if (errorResponse.hasErrors()){
					
					//SAFI notify call in case 2FA_SUSPENDED and SAFI_ACTION is a CHALLENGE
					if(errorResponse.getStatus() ==  ErrorResp.STATUS_2FA_SUSPENDED  && !(StringMethods.isEmptyString(safiAction)) && safiAction.equalsIgnoreCase(SafiConstants.SAFI_ACTION_CHALLENGE)){
						Logger.debug("SAFI : reqSecureCode(): Notify Call:START : SafiAction :Challenge: STATUS_2FA_SUSPENDED",this.getClass());
						callSafiNotify(httpRequest, httpServletResponse, false, commonData,mbSession);
						Logger.debug("SAFI : reqSecureCode(): Notify Call:END : SafiAction :Challenge: STATUS_2FA_SUSPENDED",this.getClass());
					}
					
					return errorResponse;
				}
			}
			
			
			return response;
		}
		catch (BusinessException e)
		{
			Logger.error("Exception Inside reqsecurecode() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			IMBResp resp1 = MBAppUtils.createErrorResp(mbSession.getOrigin(), e, MBAppConstants.MADISON, httpRequest);
			return resp1;
		} catch (Exception e)
		{
			Logger.error("Exception Inside reqsecurecode() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			BusinessException exp = new BusinessException(BusinessException.SMPL_SYS_ERROR);
			IMBResp resp1 = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, MBAppConstants.MADISON, httpRequest);
			return resp1;
		} finally
		{
			performanceLogger.endLog(logName);
			performanceLogger.endAllLogs();
		}
	}

	@RequestMapping(value="verifyseccode", method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public IMBResp verifySecCode(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, @RequestBody final SecureCodeReq req)
	{
		Logger.debug("In verifySecCode ( MadisonInAppController )  for Customer " +  "  " + httpServletRequest.getContentType() + " "
				+ httpServletRequest.getRemoteAddr() + "  " + httpServletResponse.getCharacterEncoding() + httpServletResponse.getLocale() +
				" True IP >> " + httpServletRequest.getHeader(IBankParams.trueClientIP()), this.getClass());

		PerformanceLogger performanceLogger = new PerformanceLogger();
		//fraudLogger = new FraudLogger();
		performanceLogger.startAllLogs();
		String logName = MBAppUtils.getLogName(httpServletRequest);
		performanceLogger.startLog(logName);
		ObjectMapper mapper = new ObjectMapper();
		
		MobileSession mbSession = null;
		String sdkDevicePrint=null,selectedCardNumber=null;
		boolean safiFlow=false, safiNotify = false, callPRM = true;
		DigitalSecLogggerVO digitalSecurityLogVO = null;IBankCommonData ibankCommonData=null;
		try
		{
			mbSession = mbAppHelper.getMobileSession(httpServletRequest);

			validateRequestHeader( req.getHeader(), httpServletRequest );

			ErrorResp errorResp = validate(req, httpServletRequest);
			if (errorResp != null && errorResp.getErrors() != null && errorResp.getErrors().size() > 0)
			{
				return errorResp;
			}
			
			
			
			SafiMadisonVO safiVO = null;
			String safiAction = null;
			
			//check SafiMadisonVO exists in session.
			if(null != mbSession.getSafiRequestVO() && mbSession.getSafiRequestVO() instanceof SafiMadisonVO ) {
				
				Logger.debug("SAFI VO available in session. ", this.getClass());
				
				safiVO = (SafiMadisonVO) mbSession.getSafiRequestVO();
				safiFlow=true;
				if(null != safiVO.getSafiRespVO()) {
					safiAction = safiVO.getSafiRespVO().getSafiAction();
					if(safiAction!=null) {
						safiNotify=true;
						callPRM=false;
					}
				}
			}
			
			 ibankCommonData=mbAppHelper.populateIBankCommonData(mbSession,httpServletRequest);
			
			 
			 
			String tranName= DigitalSecLogger.APPLEPAY_SETUP;
			digitalSecurityLogVO = safiDigiSecLoggerService.initializeDigitalLogger(ibankCommonData,tranName, DigitalSecLogger.SUCCESS);
		
			ErrorResp errorResponse = secureCodeHelper.verifySecureCode(ibankCommonData, mbSession, mbSession.getTransaction(), req, IBankSecureService.MADISON, httpServletRequest);
			if(safiAction!=null) {
				sdkDevicePrint = populateSDKDevicePrint(mapper, mbSession);
			}
			selectedCardNumber=mbSession.getMadisonInAppCardNumber();
			
			if (errorResponse.hasErrors()){
				if(safiFlow) {
					safiDigiSecLoggerService.logDigiSecForSafi2FAMadisonInApp(digitalSecurityLogVO, ibankCommonData, sdkDevicePrint,null,selectedCardNumber, false, false,false);
				}
				else {
					safiDigiSecLoggerService.logDigiSecForSafi2FASAFIOFFMadisonInApp(digitalSecurityLogVO, ibankCommonData, "",	selectedCardNumber,false, false);
				}
				
				//SAFI notify call in case 2FA_SUSPENDED and SAFI_ACTION is a CHALLENGE
				if(errorResponse.getStatus() ==  ErrorResp.STATUS_2FA_SUSPENDED  && !(StringMethods.isEmptyString(safiAction)) && safiAction.equalsIgnoreCase(SafiConstants.SAFI_ACTION_CHALLENGE)){
					Logger.debug("SAFI : verifySecCode(): Notify Call:START : SafiAction :Challenge: STATUS_2FA_SUSPENDED",this.getClass());
					callSafiNotify(httpServletRequest, httpServletResponse, false, ibankCommonData,mbSession);
					Logger.debug("SAFI : verifySecCode(): Notify Call:END : SafiAction :Challenge: STATUS_2FA_SUSPENDED",this.getClass());
				}
				
				return errorResponse;
			}else {
				
				if(safiFlow) {
					if(safiNotify) {
						callSafiNotify(httpServletRequest, httpServletResponse, true, ibankCommonData,mbSession);
					}
					safiDigiSecLoggerService.logDigiSecForSafi2FAMadisonInApp(digitalSecurityLogVO, ibankCommonData, sdkDevicePrint,null,selectedCardNumber, true, false,false);
				}
				else {
					safiDigiSecLoggerService.logDigiSecForSafi2FASAFIOFFMadisonInApp(digitalSecurityLogVO, ibankCommonData, null,selectedCardNumber,true, false);
				}
				
				if(callPRM) {
					//PRM call for SAFI off host scenario					
					PRMUpdateService prmServiceBean = (PRMUpdateService) ServiceHelper.getBean("prmServiceBean");
					prmServiceBean.sendPrmMadison(ibankCommonData, madisonService.populateDeviceRiskDetails(null, ibankCommonData));
				}
				
			}
			
			if(mbSession.getMadisonInAppCardNumber()!=null) {
				mbSession.removeMadisonInAppCardNumber();
			}
			mbSession.setSecureCodeVerifiedTranName(ServiceConstants.MADISON);
			
			
			AddToWalletResponse serviceResponse = new AddToWalletResponse();
			serviceResponse.setSuccess(true);
			
										
			RespHeader headerResp = populateResponseHeader(ServiceConstants.MADISON, mbSession);
			serviceResponse.setHeader(headerResp);
			return serviceResponse;
		} catch (BusinessException e)
		{
			Logger.error("Exception Inside verifySecCode() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			if (safiFlow) {
				safiDigiSecLoggerService.logDigiSecForSafi2FAMadisonInApp(digitalSecurityLogVO, ibankCommonData, sdkDevicePrint,null, selectedCardNumber,true, false,false);
			} else {
				safiDigiSecLoggerService.logDigiSecForSafi2FASAFIOFFMadisonInApp(digitalSecurityLogVO, ibankCommonData, "",selectedCardNumber, true,false);
			}
			IMBResp resp1 = MBAppUtils.createErrorResp( mbSession.getOrigin(), e, MBAppConstants.MADISON, httpServletRequest);
			return resp1;
		} catch (Exception e)
		{
			Logger.error("Exception Inside verifySecCode() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			if (safiFlow) {
				safiDigiSecLoggerService.logDigiSecForSafi2FAMadisonInApp(digitalSecurityLogVO, ibankCommonData, sdkDevicePrint, "",selectedCardNumber,true, false,false);
			} else {
				safiDigiSecLoggerService.logDigiSecForSafi2FASAFIOFFMadisonInApp(digitalSecurityLogVO, ibankCommonData, "",selectedCardNumber, true,false);
			}
			BusinessException exp = new BusinessException(BusinessException.SMPL_SYS_ERROR);
			IMBResp resp1 = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, MBAppConstants.MADISON, httpServletRequest);
			return resp1;
		} finally
		{
			performanceLogger.endLog(logName);
			performanceLogger.endAllLogs();
		}
	}	

	private IMBResp callSafiAnalyse(ObjectMapper mapper,HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, MobileSession mobileSession, IBankCommonData commonData,AddToWalletRequest request,AddToWalletResponse response,String cardNumber) throws ResourceException, BusinessException {
			
		SafiMadisonVO safiVO = new SafiMadisonVO(); 
		
		try {
			safiVO = madisonHelper.populateSafiVO(httpServletRequest, mobileSession, commonData, request,cardNumber);
			String sdkDevicePrint = null;
			sdkDevicePrint = populateSDKDevicePrint(mapper, mobileSession);

			madisonService.safiAnalyzeForMadison(commonData, safiVO,sdkDevicePrint);
			
			
			if(null != safiVO && null != safiVO.getSafiRespVO() && null != safiVO.getSafiRespVO().getSafiAction()) {
				if(SafiConstants.SAFI_ACTION_ALLOW.equalsIgnoreCase(safiVO.getSafiRespVO().getSafiAction()) || SafiConstants.SAFI_ACTION_REVIEW.equalsIgnoreCase(safiVO.getSafiRespVO().getSafiAction()))
					response.setSecureCodeReqd(false);
			}
			
		} catch(BusinessException be){
		
			//Only in case of Challenge - set setSecureCodeReqd to TRUE
			//Otherwise throw exception
			if (be.getKey() == BusinessException.IBANK_SECURE_REQUIRED) {
				response.setSecureCodeReqd(true);
			} else{
				throw be;
			}
			
		}finally{			
			mobileSession.setSafiRequestVO(safiVO);
			madisonHelper.handleSafiResponseinCookies(httpServletRequest ,httpServletResponse, safiVO.getSafiRespVO());
		}
		
	   		return response;
		}



	private void callSafiNotify(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, boolean status2FA, IBankCommonData ibankCommonData, MobileSession mobileSession) {
		try{
					
			if(mobileSession.getSafiRequestVO() != null && mobileSession.getSafiRequestVO() instanceof SafiMadisonVO) {
				SafiMadisonVO safiVO = SafiWebHelper.populateSafiVOForMadisonNotify(httpServletRequest, mobileSession, ibankCommonData,  status2FA);
				
				//Add card number to notify call request
				SafiMadisonVO safiAnalysedVO = (SafiMadisonVO) mobileSession.getSafiRequestVO() ;
				if(null != safiAnalysedVO.getCardNumber()) {
					safiVO.setCardNumber(safiAnalysedVO.getCardNumber());
				}
				
				SafiRespVO safiRespVO = madisonService.notifySafiForMadison(ibankCommonData, safiVO);
				
				madisonHelper.handleSafiResponseinCookies(httpServletRequest, httpServletResponse, safiRespVO);
			}
		}catch(BusinessException be){
			Logger.warn("Exception in callSafiNotify: ", be , getClass());
		}finally{
			mobileSession.removeSafiRequestVO();
		}
	}	


	
    private MadisonResponse populateMadisonResponse(RespHeader header, boolean isEligible, String learnMoreLink, String appLink) {
    	MadisonResponse madisonResp = new MadisonResponse(header);
    	madisonResp.setEligible(isEligible);
    	madisonResp.setLearnMoreLink(learnMoreLink);
    	madisonResp.setAppLink(appLink);
		return madisonResp;
		
	}
    
    public ErrorResp validate(IMBReq serviceRequest, HttpServletRequest request) {
		Logger.debug("Service request object - " + ReflectionToStringBuilder.toString(serviceRequest), this.getClass());
		return mbAppValidator.validate(serviceRequest, request);
	}

	public RespHeader populateResponseHeader(String serviceName, MobileSession mobSession) {
		return mbAppHelper.populateResponseHeader(serviceName, mobSession);
	}
	
	public void validateRequestHeader(ReqHeader headerReq, HttpServletRequest request) throws BusinessException {
		Logger.debug("Request header validation: " + ReflectionToStringBuilder.toString(headerReq, ToStringStyle.MULTI_LINE_STYLE), this.getClass());
		new MBAppValidator().validateRequestHeader(headerReq, request);
	}
	
	private String startPerformanceLog(HttpServletRequest httpRequest){
		perfLogger.startAllLogs();
		String logName = MBAppUtils.getLogName(httpRequest);
		perfLogger.startLog(logName);
		return logName;
	}
	
	private void endPerformanceLog(String logName){
		perfLogger.endLog(logName);
		perfLogger.endAllLogs();
	}
	
	
	@RequestMapping(method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE, value = "logGDWForSuccessScreen")
	@ResponseBody
	public IMBResp logGDWForSuccessScreen(HttpServletRequest httpRequest,HttpServletResponse httpServletResponse, @RequestBody final MadisonSuccessGDWRequest request) {
		Logger.debug("MadisonController - logGDWForSuccessScreen. Request: " + request, this.getClass());
		String logName = startPerformanceLog(httpRequest);
		MobileSession mobileSession = new MobileSessionImpl();
		try {
			mobileSession.getSessionContext(httpRequest);
			validateRequestHeader(request.getHeader(), httpRequest);
			ErrorResp errorResponse = validate(request, httpRequest);
			if (errorResponse.hasErrors())
			{
				return errorResponse;
			}
			
			IBankCommonData commonData = mbAppHelper.populateIBankCommonData(mobileSession, httpRequest);
			MadisonCardsVO madisonCardsVO = mobileSession.getMadisonCards();String cardNumber="",productName="";
			if(null != madisonCardsVO && null != madisonCardsVO.getCards()) {
				Cards card = madisonCardsVO.getCards().get(Integer.valueOf(request.getCardIndex()));
				
				if(null !=card && null != card.getCardNumber()) {
					cardNumber=card.getCardNumber();
					productName=card.getCardProductName();
					Logger.info("MadisonController logGDWForSuccessScreen selected card number::::: "+card.getCardNumber()+",selected product name::::::: "+productName, this.getClass());
				}
				else {
					Logger.error(" Madison Card not found in madisonCardsVO - MadisonHelper - populateSafiVO : GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", this.getClass());
					
				}
					
			} else {
				Logger.error(" madisonCardsVO not found in session - MadisonController - logGDWForSuccessScreen : GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", this.getClass());
				throw new BusinessException(BusinessException.SYSTEM_UNAVILABLE);
			}
		
			String entryPoint = mobileSession.getMadisonInAppEntryPoint();
			madisonService.addStatLogsForMadisonInApp(commonData, MadisonServiceImpl.SUCCESS_SCREEN,entryPoint, cardNumber,productName);
			
			
			SuccessResp successResp = new SuccessResp();																			
			RespHeader headerResp = populateResponseHeader(request.getHeader().getServiceName(), mobileSession);
			successResp.setHeader(headerResp);
			successResp.setIsSuccess(true);	
			return successResp;
			
		} catch (BusinessException e) {

			Logger.error("BusinessException in MadisonController - logGDWForSuccessScreen - [key: " + e.getKey() + "] : GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), e, ServiceConstants.MADISON, httpRequest);
		} catch (ResourceException e) {
			Logger.error("ResourceException in MadisonController - logGDWForSuccessScreen - [key: " + e.getKey() + "] : GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.SYSTEM_UNAVILABLE, ServiceConstants.MADISON, httpRequest);
		} catch (Exception e) {
			Logger.error("Exception MadisonController - logGDWForSuccessScreen: GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), ResourceException.MOBILE_NON_FINANCIAL_FATAL_ERR, ServiceConstants.MADISON, httpRequest);
		} finally {
			endPerformanceLog(logName);
		}
	}
	
	@RequestMapping(method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE, value = "logGDWForCardActivation")
	@ResponseBody
	public IMBResp logGDWForCardActivation(HttpServletRequest httpRequest,HttpServletResponse httpServletResponse, @RequestBody final EmptyReq request) {
		Logger.debug("MadisonController - logGDWForCardActivation. Request: " + request, this.getClass());
		String logName = startPerformanceLog(httpRequest);
		MobileSession mobileSession = new MobileSessionImpl();
		try {
			mobileSession.getSessionContext(httpRequest);
			validateRequestHeader(request.getHeader(), httpRequest);
			ErrorResp errorResponse = validate(request, httpRequest);
			if (errorResponse.hasErrors())
			{
				return errorResponse;
			}
			
			IBankCommonData commonData = mbAppHelper.populateIBankCommonData(mobileSession, httpRequest);
		
		
			RespHeader headerResp = populateResponseHeader(request.getHeader().getServiceName(), mobileSession);
			if(mobileSession.getCardActivation()!=null && mobileSession.getCardActivation().getCardNumber()!=null) {
				Logger.info("MadisonController - logGDWForCardActivation activated card::: "+mobileSession.getCardActivation().getCardNumber(), this.getClass());
				madisonService.addStatLogsForMadisonInApp(commonData, MadisonServiceImpl.CARD_ACTIVATION,null, mobileSession.getCardActivation().getCardNumber(),mobileSession.getMadisonInAppProductName());
				mobileSession.setMadisonInAppEntryPoint(MadisonServiceImpl.CARD_ACTIVATION);
			}
			else {
				Logger.warn("Card Number is null from card activation flow", this.getClass());
			}
			SuccessResp successResp = new SuccessResp();
			successResp.setHeader(headerResp);
			successResp.setIsSuccess(true);	
			return successResp;
		} catch (BusinessException e) {

			Logger.error("BusinessException in MadisonController - logGDWForCardActivation - [key: " + e.getKey() + "] : GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), e, ServiceConstants.MADISON, httpRequest);
		} catch (ResourceException e) {
			Logger.error("ResourceException in MadisonController - logGDWForCardActivation - [key: " + e.getKey() + "] : GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.SYSTEM_UNAVILABLE, ServiceConstants.MADISON, httpRequest);
		} catch (Exception e) {
			Logger.error("Exception MadisonController - logGDWForCardActivation: GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), ResourceException.MOBILE_NON_FINANCIAL_FATAL_ERR, ServiceConstants.MADISON, httpRequest);
		} finally {
			endPerformanceLog(logName);
		}
	}
	
	private String populateSDKDevicePrint(ObjectMapper mapper, MobileSession mbSession) {
		String devicePrintForLogger = null; 
		String sdkDevicePrint = mbSession.getSafiLogonInfo() != null ? mbSession.getSafiLogonInfo().getDevicePrint()
				: null;
		try {
			JsonNode jsonNode = mapper.readValue(sdkDevicePrint, JsonNode.class);
			devicePrintForLogger = jsonNode != null ? jsonNode.toString() : "";
			Logger.debug("MadisonController populateSDKDevicePrint():::: " + devicePrintForLogger, this.getClass());
		} catch (Exception e) {
			Logger.error("MadisonController populateSDKDevicePrint() Exception", e, this.getClass());
		}
			
		
		return devicePrintForLogger;

	}

}
