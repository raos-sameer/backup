package au.com.stgeorge.mbank.model.request.newaccount.cpp;

import java.io.Serializable;

import au.com.stgeorge.mbank.model.common.IMBReq;
import au.com.stgeorge.mbank.model.common.ProductReq;
import au.com.stgeorge.mbank.model.common.ReqHeader;

public class TDReq implements IMBReq, Serializable{
	
	private static final long serialVersionUID = -256469501889499119L;


    private ReqHeader header;
    private String tdaAmount;    
	private Integer tdaTerm;
	private Integer selSourceAcctIndex;
	private ProductReq product;
	private String regionId;
	private String branchId;
	
    public ReqHeader getHeader()
	{
		return header;
	}
	public void setHeader(ReqHeader header)
	{
		this.header = header;
	}
	
	public String getTdaAmount() {
		return tdaAmount;
	}
	public void setTdaAmount(String tdaAmount) {
		this.tdaAmount = tdaAmount;
	}	
	
	public int getTdaTerm() {
		return tdaTerm;
	}
	public void setTdaTerm(int tdaTerm) {
		this.tdaTerm = tdaTerm;
		
	}
	
	public Integer getSourceAcctIndex() {
		return selSourceAcctIndex;
	}
	public void setSourceAcctIndex(Integer selSourceAcctIndex) {
		this.selSourceAcctIndex = selSourceAcctIndex;
	}	
	
	public ProductReq getProduct() {
		return product;
	}
	public void setProduct(ProductReq product) {
		this.product = product;
	}
	
	public static long getSerialVersionUID() {
		return serialVersionUID;
	}
	public String getRegionId() {
		return regionId;
	}
	public void setRegionId(String regionId) {
		this.regionId = regionId;
	}
	public String getBranchId() {
		return branchId;
	}
	public void setBranchId(String branchId) {
		this.branchId = branchId;
	} 
}
