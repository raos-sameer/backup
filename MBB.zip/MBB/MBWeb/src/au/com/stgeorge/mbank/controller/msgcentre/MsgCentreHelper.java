/**
 * 
 */
package au.com.stgeorge.mbank.controller.msgcentre;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import au.com.stgeorge.ibank.messagecentre.util.MessageCentreConstants;
import au.com.stgeorge.ibank.messagecentre.valueobject.MessageSearch;
import au.com.stgeorge.mbank.model.common.IMBResp;
import au.com.stgeorge.mbank.model.msgcentre.MsgDetailResp;
import au.com.stgeorge.mbank.model.response.msgcentre.MsgCentreResp;
import au.com.stgeorge.mbank.util.MBAppConstants;

/**
 * @author C50216
 *
 */
public class MsgCentreHelper {
		
	protected IMBResp populateMsgListResp(List<MessageSearch> messages, int unreadCount) throws Exception  {		
		MsgCentreResp msgCntrResp = new MsgCentreResp();
							
		if(messages != null){
			msgCntrResp.setMessages(getMsgDetailListResp(messages));
			msgCntrResp.setUnreadCount(unreadCount);
		}
		
		return msgCntrResp;
	}
				
	private List<MsgDetailResp> getMsgDetailListResp(List<MessageSearch> msgList) throws Exception{
		
		List<MsgDetailResp> msgDtlListResp = null;
		MsgDetailResp msgDtlResp = null;
		MessageSearch msg = null;
		
		if(msgList.size() > 0){
			Iterator<MessageSearch> it = msgList.iterator();
			msgDtlListResp = new ArrayList<MsgDetailResp>();
			while(it.hasNext()){
								
				msg = it.next();
				msgDtlResp = new MsgDetailResp();
				
				msgDtlResp.setCustomerMsgId(msg.getCustMsgID());				
				msgDtlResp.setExpiryDate(msg.getExpiryDate());
			
				if(msg.getMsgType().equalsIgnoreCase("SECM")){										
					msgDtlResp.setEffectiveDate(MBAppConstants.DATETIME_FORMAT_YYYYMMDD_HHMMSS.format(msg.getCreatedOn()));
				}else{
					if(msg.getMsgType().equalsIgnoreCase("ECOR")) {
						msgDtlResp.setEffectiveDate(MBAppConstants.DATE_FORMAT_YYYYMMDD.format(msg.getCreatedOn()));
					}
					else {
						msgDtlResp.setEffectiveDate(MBAppConstants.DATE_FORMAT_YYYYMMDD.format(msg.getEffectiveDate()));
					}
					msgDtlResp.setAllowDeletion(true);
				}
				
				String status = msg.getStatus();
				if("REA".equalsIgnoreCase(status))
					status = "RD";	
												
				msgDtlResp.setStatus(status);
				msgDtlResp.setSubject(msg.getMobSubject());
				msgDtlResp.setType(msg.getMsgType());
				msgDtlListResp.add(msgDtlResp);
			}		
		}				
		return msgDtlListResp;	
	}
			
	protected String replaceLinks(String previewText){
		//Replace any external links with javascript:UserWindow to open the link in a new window
		previewText = previewText.replaceAll("<a href=", "<A href=");
		previewText = previewText.replaceAll("</a>", "</A>");
		previewText = previewText.replaceAll("<A href=\"\"", "<A href=\"");
		previewText = previewText.replaceAll("<A href=\'\"", "<A href=\"");
		previewText = previewText.replaceAll("\"\'>", "\">");
		previewText = previewText.replaceAll("\"\">", "\">");
		String tempText = "";
		int start=0;
		int index= previewText.indexOf("<A href=\"http");
		while (index >= 0 ){
			tempText += previewText.substring(start, index);
			tempText += "<A id=\"msgExtUrl\" href=\"javascript:void(0)\" data =\"";
			int j = previewText.indexOf("\">", index);
			tempText += previewText.substring(index+9,j);
			start = j ;
			index= previewText.indexOf("<A href=\"http", j);
		}
		tempText += previewText.substring(start);
		previewText= tempText;
		//For secure links https://
		previewText = previewText.replaceAll("<A =\"javascript:OpenUrl","<A href=\"javascript:UserWindow");
		previewText = previewText.replaceAll("<a =\"javascript:OpenUrl","<A href=\"javascript:UserWindow");
		previewText = previewText.replaceAll("<A href=\"javascript:OpenUrl","<A href=\"javascript:UserWindow");
		previewText = previewText.replaceAll("<a href=\"javascript:OpenUrl","<A href=\"javascript:UserWindow");
		previewText = previewText.replaceAll("<IMG src=\"\"","<IMG src=\"");		
		previewText = previewText.replaceAll(MessageCentreConstants.LINK_OPEN, "<a href=\"#\">");
		previewText = previewText.replaceAll(MessageCentreConstants.LINK_CLOSE, "</a>");
		return previewText;
	}
}
