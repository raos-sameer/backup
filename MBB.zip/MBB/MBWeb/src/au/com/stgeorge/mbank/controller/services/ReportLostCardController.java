package au.com.stgeorge.mbank.controller.services;

import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.UUID;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang.builder.ReflectionToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;

import au.com.stgeorge.digitalsec.logger.DigitalSecLogger;
import au.com.stgeorge.digitalsec.logger.DigitalSecLogggerVO;
import au.com.stgeorge.framework.common.logging.Logger;
import au.com.stgeorge.framework.common.util.StringMethods;
import au.com.stgeorge.ibank.businessobject.BusinessException;
import au.com.stgeorge.ibank.businessobject.CardService;
import au.com.stgeorge.ibank.businessobject.ResourceException;
import au.com.stgeorge.ibank.businessobject.globalWallet.CardLockUnlockService;
import au.com.stgeorge.ibank.businessobject.globalWallet.GlobalWalletService;
import au.com.stgeorge.ibank.businessobject.globalWallet.GlobalWalletServiceHelper;
import au.com.stgeorge.ibank.common.cache.IBankParams;
import au.com.stgeorge.ibank.common.cache.IBankRefershParams;
import au.com.stgeorge.ibank.messagecentre.util.MessageCentreConstants;
import au.com.stgeorge.ibank.servicestation.businessobject.ServiceStation;
import au.com.stgeorge.ibank.servicestation.businessobject.ServiceStationImpl;
import au.com.stgeorge.ibank.servicestation.businessobject.valueobject.ServiceStationVO;
import au.com.stgeorge.ibank.servicestation.util.ServicetationConstants;
import au.com.stgeorge.ibank.util.ServiceHelper;
import au.com.stgeorge.ibank.util.StringUtil;
import au.com.stgeorge.ibank.valueobject.Account;
import au.com.stgeorge.ibank.valueobject.Address;
import au.com.stgeorge.ibank.valueobject.CreditCardAccount;
import au.com.stgeorge.ibank.valueobject.DebitCardAccount;
import au.com.stgeorge.ibank.valueobject.GCCAccount;
import au.com.stgeorge.ibank.valueobject.LostCardsDetails;
import au.com.stgeorge.ibank.valueobject.database.CodesVO;
import au.com.stgeorge.ibank.valueobject.database.OriginsVO;
import au.com.stgeorge.ibank.valueobject.transfer.IBankCommonData;
import au.com.stgeorge.mbank.controller.IMBController;
import au.com.stgeorge.mbank.controller.customer.LogonHelper;
import au.com.stgeorge.mbank.controller.offers.SalesOfferHelper;
import au.com.stgeorge.mbank.model.common.IMBReq;
import au.com.stgeorge.mbank.model.common.IMBResp;
import au.com.stgeorge.mbank.model.common.ReqHeader;
import au.com.stgeorge.mbank.model.common.RespHeader;
import au.com.stgeorge.mbank.model.request.EmptyReq;
import au.com.stgeorge.mbank.model.request.IndexReq;
import au.com.stgeorge.mbank.model.request.services.LostCardReportReq;
import au.com.stgeorge.mbank.model.response.ErrorResp;
import au.com.stgeorge.mbank.model.response.SuccessResp;
import au.com.stgeorge.mbank.model.response.customer.LockedCardInfoResp;
import au.com.stgeorge.mbank.model.response.services.CardOnHoldDetailsResp;
import au.com.stgeorge.mbank.model.response.services.LockUnlockStatusResp;
import au.com.stgeorge.mbank.session.MobileSession;
import au.com.stgeorge.mbank.session.MobileSessionImpl;
import au.com.stgeorge.mbank.util.MBAppHelper;
import au.com.stgeorge.mbank.util.MBAppUtils;
import au.com.stgeorge.mbank.util.MBAppValidator;
import au.com.stgeorge.mbank.util.ServiceConstants;
import au.com.stgeorge.perflogger.PerformanceLogger;

/**
 * Report lost card service
 * 
 * @author C38854
 * 
 */
@Controller
@RequestMapping("/cards")
public class ReportLostCardController implements IMBController {

	private static final String LOCK_ACTION = "LostcardReportTempBlockConfirmation";
	private static final String UNLOCK_ACTION = "LostcardReportReleaseBlockConfirmation";
	public static final String CATEGORY_CONSUMER_WITHREL_CREDIT = "ConsumerCreditWithRel";
	public static final String CATEGORY_CONSUMER_WOREL_CREDIT = "ConsumerCreditWORel";
	public static final String NOTALLOW_CHAR_OVERSEAS = "$ ) ( + % * ? [ ] < = > } \\^ { | @ # ! ~ ` \"";

	//20E1 GCC
	private static final String LOCK = "LOCK";
	private static final String UNLOCK = "UNLOCK";
	
	@Autowired
	private CardService cardService;

	@Autowired
	private LostCardHelper helper;

	@Autowired
	private MBAppValidator mbAppValidator;
	
	@Autowired
	private MBAppHelper mbAppHelper;

	
    @Autowired
	private ServiceStation serviceStationService;
    
    @Autowired
    private DigitalSecLogger digitalSecurityLogger;
    
    @Autowired
    private CardLockUnlockService cardLockUnlockService;
    
    @Autowired
	private GlobalWalletService globalWalletService;
    
    @Autowired
    private GlobalWalletServiceHelper gwServiceHelper;
    

	/**
	 * Get Cards service operation
	 * 
	 * @param httpRequest
	 * @param request
	 * @return
	 */
	@RequestMapping(method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE, value = "getloststolen")
	@ResponseBody
	public IMBResp getCards(HttpServletRequest httpRequest, @RequestBody final EmptyReq request) {
		UUID appCorrelationID = UUID.randomUUID();
		Logger.debug(appCorrelationID+" ReportLostCardController - getCards(). Request: " + request, this.getClass());
		String logName = startPerformanceLog(httpRequest);
		MobileSession mobileSession = new MobileSessionImpl();
	    //IBankRefershParams ibankRefreshParams = (IBankRefershParams) ServiceHelper.getBean("ibankRefreshParams");

	    try {
			mobileSession.getSessionContext(httpRequest);
			validateRequestHeader(request.getHeader(), httpRequest);
			ErrorResp errorResponse = validate(request, httpRequest);
			if (errorResponse.hasErrors())
				return errorResponse;
			IBankCommonData commonData = new MBAppHelper().populateIBankCommonData(mobileSession, httpRequest);
			Collection<Account> cards = cardService.getCardsList(mobileSession.getCustomer().getGcis(), commonData);
			Collection<Account> filteredCards = new ArrayList<Account>();
			filteredCards.addAll(cards);
			//20E1 - Add GCC cards to list
			if(globalWalletService.isGlobalWalletSwitchOn(commonData.getCustomer().getGcis())){
				cards.addAll(cardService.getLostStolenGlobalWalletCards(commonData));
			}
			
			if(isMadisonLCMSwitchOn(commonData.getCustomer().getGcis())) {
				
				for(Account account:cards ) {
					if(account instanceof CreditCardAccount) {
						CreditCardAccount ccACcount  = (CreditCardAccount) account;
						if(ccACcount.getBlockCode()!=null && (("S").equalsIgnoreCase(ccACcount.getBlockCode()) || (("Q").equalsIgnoreCase(ccACcount.getAccountId().getAcctStatus()) && ("J").equalsIgnoreCase(ccACcount.getBlockCode())))) {
							Logger.debug(appCorrelationID+" Removed card from Report Lost/Stolen Card List: "+StringUtil.formatCardNumber(ccACcount.getAccountId().getAccountNumber()), this.getClass());
							filteredCards.remove(account);
						}
					}
				}
				Logger.info(appCorrelationID+" Actual Cards Size: "+cards.size()+", After Removing Cards & Size: "+filteredCards.size(), this.getClass());
				cards = filteredCards;
			}
			
			mobileSession.setCards((List<Account>) cards);
			return helper.populateCardListResponse(populateResponseHeader(ServiceConstants.CARDS_LIST_SERVICE, mobileSession ), (List<Account>) cards, commonData);
		} catch (BusinessException e) {
			Logger.info(appCorrelationID+" BusinessException in ReportLostCardController - getCards() - [key: " + e.getKey() + "] : GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());
			if ( e.getKey() ==  BusinessException.LOST_CARD_SYS_UNAVAIL )
			{
				return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.MB_NOT_AVAILABLE, ServiceConstants.CARDS_LIST_SERVICE, httpRequest);
			}
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), e, ServiceConstants.CARDS_LIST_SERVICE, httpRequest);
		} catch (ResourceException e) {
			Logger.error(appCorrelationID+" ResourceException in ReportLostCardController - getCards() - [key: " + e.getKey() + "] : GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.SYSTEM_UNAVILABLE, ServiceConstants.CARDS_LIST_SERVICE, httpRequest);
		} catch (Exception e) {
			Logger.error(appCorrelationID+" Exception ReportLostCardController - getCards(): GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), ResourceException.MOBILE_NON_FINANCIAL_FATAL_ERR, ServiceConstants.CARDS_LIST_SERVICE, httpRequest);
		} finally {
			endPerformanceLog(logName);
		}
	}

	/**
	 * Get Lost Stolen Details service operation
	 * 
	 * @param httpRequest
	 * @param request
	 * @return
	 */
	@RequestMapping(method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE, value = "getadditionaldetails")
	@ResponseBody
	public IMBResp getDetails(HttpServletRequest httpRequest, @RequestBody final IndexReq request) {
		Logger.debug("ReportLostCardController - getDetails(). Request: " + request, this.getClass());
		String logName = startPerformanceLog(httpRequest);
		MobileSession mobileSession = new MobileSessionImpl();

		try {
			mobileSession.getSessionContext(httpRequest);
			validateRequestHeader(request.getHeader(), httpRequest);
			ErrorResp errorResponse = validate(request, httpRequest);
			if (errorResponse.hasErrors())
				return errorResponse;
			IBankCommonData commonData = new MBAppHelper().populateIBankCommonData(mobileSession, httpRequest);

			Account card = mobileSession.getCards().get(Integer.parseInt(request.getIndex()));
			boolean replacementRequired = true;
			String cardCategory = card.getAlias();
			Address address = null;
			if (card instanceof DebitCardAccount) {
				cardCategory = "VisaDebit";
				card.getAccountId().setAccountNumber(((DebitCardAccount) card).getCardNumber());// for the service to get address
				CodesVO myCodesVO = IBankParams.getCodesData(IBankParams.DEFAULT_ORIGIN, "BINs", IBankParams.PROP_DEBIT_CARDS);
				if (myCodesVO != null) {
					String strBINList = myCodesVO.getMessage();
					List<String> proprietaryDebitCardsBins = IBankParams.getArrayListFromString(strBINList);
					for (String bin : proprietaryDebitCardsBins)
						if (((DebitCardAccount) card).getCardNumber().startsWith(bin)) {
							replacementRequired = false;
							cardCategory = "PropDebit";
						}
				}
			}
			if (replacementRequired) {
				address = cardService.getAddress(card.getAccountId().getApplicationId(), commonData, card, new LostCardsDetails());
				if (address != null && cardCategory == null) {
					if (CATEGORY_CONSUMER_WOREL_CREDIT.equalsIgnoreCase(address.getLine1())) {
						cardCategory = CATEGORY_CONSUMER_WOREL_CREDIT;
					} else {
						cardCategory = CATEGORY_CONSUMER_WITHREL_CREDIT;
					}
					address = null;
				}
			}

			mobileSession.setLostCardDetails(helper.initLostCardRequest(address, cardCategory, commonData.getCustomer().getGcis(), mobileSession
					.getOrigin(), card));

			return helper.populateDetailsResponse(populateResponseHeader(ServiceConstants.REPORT_LOST_DETAILS_SERVICE, mobileSession), address, cardCategory,
					replacementRequired, mobileSession.getCustomer().getContactDetail().getEmail());
		} catch (BusinessException e) {
			Logger.info("BusinessException in ReportLostCardController - getDetails() - [key: " + e.getKey() + "] : GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), e, ServiceConstants.REPORT_LOST_DETAILS_SERVICE, httpRequest);
		} catch (ResourceException e) {
			Logger.error("ResourceException in ReportLostCardController - getDetails() - [key: " + e.getKey() + "] : GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.SYSTEM_UNAVILABLE, ServiceConstants.REPORT_LOST_DETAILS_SERVICE, httpRequest);
		} catch (Exception e) {
			Logger.error("Exception ReportLostCardController - getDetails(): GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), ResourceException.MOBILE_NON_FINANCIAL_FATAL_ERR, ServiceConstants.REPORT_LOST_DETAILS_SERVICE, httpRequest);
		} finally {
			endPerformanceLog(logName);
		}
	}

	/**
	 * Report Lost or Stolen card service operation
	 * 
	 * @param httpRequest
	 * @param request
	 * @return
	 */
	@RequestMapping(method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE, value = "reportloststolen")
	@ResponseBody
	public IMBResp report(HttpServletRequest httpRequest, @RequestBody final LostCardReportReq request) {
		Logger.debug("ReportLostCardController - getDetails(). Request: " + request, this.getClass());
		String logName = startPerformanceLog(httpRequest);
		MobileSession mobileSession = new MobileSessionImpl();

		DigitalSecLogggerVO digitalSecLoggerVO = null;
		try {
			mobileSession.getSessionContext(httpRequest);
			validateRequestHeader(request.getHeader(), httpRequest);
			ErrorResp errorResponse = validate(request, httpRequest);
			if (errorResponse.hasErrors())
				return errorResponse;

			helper.validateReportLostRequest(request);

			IBankCommonData commonData = new MBAppHelper().populateIBankCommonData(mobileSession, httpRequest);

			LostCardsDetails lostCard = mobileSession.getLostCardDetails();

			Account card = mobileSession.getCards().get(Integer.parseInt(request.getIndex()));

			if (lostCard == null) {
				boolean replacementRequired = true;
				String cardCategory = "";
				Address address = null;
				if (card instanceof DebitCardAccount) {
					cardCategory = "VisaDebit";
					card.getAccountId().setAccountNumber(((DebitCardAccount) card).getCardNumber());// for the service to get address
					CodesVO myCodesVO = IBankParams.getCodesData(IBankParams.DEFAULT_ORIGIN, "BINs", IBankParams.PROP_DEBIT_CARDS);
					if (myCodesVO != null) {
						String strBINList = myCodesVO.getMessage();
						List<String> proprietaryDebitCardsBins = IBankParams.getArrayListFromString(strBINList);
						for (String bin : proprietaryDebitCardsBins)
							if (((DebitCardAccount) card).getCardNumber().startsWith(bin)) {
								replacementRequired = false;
								cardCategory = "PropDebit";
							}
					}
				}
				if (replacementRequired) {
					address = cardService.getAddress(card.getAccountId().getApplicationId(), commonData, card, new LostCardsDetails());
					if (address != null && cardCategory == null) {
						if (CATEGORY_CONSUMER_WOREL_CREDIT.equalsIgnoreCase(address.getLine1())) {
							cardCategory = CATEGORY_CONSUMER_WOREL_CREDIT;
						} else {
							cardCategory = CATEGORY_CONSUMER_WITHREL_CREDIT;
						}
						address = null;
					}
				}
				lostCard = helper.initLostCardRequest(address, cardCategory, commonData.getCustomer().getGcis(), mobileSession.getOrigin(), card);
			}

			lostCard = helper.populateLostCardRequest(lostCard, request);
			
			if (!StringMethods.isEmptyString(commonData.getCustomer().getContactDetail().getEmail())) {
				Logger.debug("Email Address::::"+commonData.getCustomer().getContactDetail().getEmail(), this.getClass());
				Logger.info("Email Address::::"+commonData.getCustomer().getContactDetail().getEmail(), this.getClass());
				lostCard.setEmailRequired(true);				
			}
			Logger.debug("Email Required::::"+lostCard.getEmailRequired(), this.getClass());
			Logger.info("Email Required::::"+lostCard.getEmailRequired(), this.getClass());


			digitalSecLoggerVO = createDigitalSecLogggerVO(lostCard, commonData);
			
			Logger.debug("Lost Card request: " + ReflectionToStringBuilder.toString(lostCard, ToStringStyle.MULTI_LINE_STYLE), this.getClass());

			lostCard = cardService.processLostCardRequest(lostCard, commonData, card);
			mobileSession.removeLostCardDetails();
			
			digitalSecurityLogger.log(digitalSecLoggerVO);
			
			// Getting the service station VO and Setting the service station response.
			long insertionPt = helper.getInsertionPointCode(ServicetationConstants.REPORT_LOST_STOLEN);
			ServiceStationVO servicestationVO=populateServiceMessage(insertionPt,ServiceStationImpl.CHANNEL_MOBILE, commonData);
			
			return helper.populateReportResponse(populateResponseHeader(ServiceConstants.REPORT_LOST_CARD_SERVICE, mobileSession), lostCard.getRequestId(), lostCard.getRplCardNumber(),mobileSession,servicestationVO);
		
		} 
		catch (BusinessException e) {
			
			if(digitalSecLoggerVO != null)
			{
				digitalSecLoggerVO.setStatus(DigitalSecLogger.FAILURE);
				digitalSecurityLogger.log(digitalSecLoggerVO);
			}
			
			Logger.info("BusinessException in ReportLostCardController - getDetails() - [key: " + e.getKey() + "] : GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());
			if (e.getKey() == BusinessException.LOST_CARD_COUNTRY_INVALID){
				return MBAppUtils.createErrorResp(mobileSession.getOrigin(), e.getKey(), 
						MBAppUtils.getMessage(mobileSession.getOrigin(), e.getKey(), new String[] {NOTALLOW_CHAR_OVERSEAS}), ServiceConstants.REPORT_LOST_CARD_SERVICE, httpRequest);
			}
			
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), e, ServiceConstants.REPORT_LOST_CARD_SERVICE, httpRequest);
		} catch (ResourceException e) {
			
			if(digitalSecLoggerVO != null)
			{
				digitalSecLoggerVO.setStatus(DigitalSecLogger.FAILURE);
				digitalSecurityLogger.log(digitalSecLoggerVO);
			}
			
			Logger.error("ResourceException in ReportLostCardController - getDetails() - [key: " + e.getKey() + "] : GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.SYSTEM_UNAVILABLE, ServiceConstants.REPORT_LOST_CARD_SERVICE, httpRequest);
		} catch (Exception e) {
			
			if(digitalSecLoggerVO != null)
			{
				digitalSecLoggerVO.setStatus(DigitalSecLogger.FAILURE);
				digitalSecurityLogger.log(digitalSecLoggerVO);
			}
			Logger.error("Exception ReportLostCardController - getDetails(): GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), ResourceException.MOBILE_NON_FINANCIAL_FATAL_ERR, ServiceConstants.REPORT_LOST_CARD_SERVICE, httpRequest);
		} finally {
			endPerformanceLog(logName);
		}
	}

	
	
	@RequestMapping(method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE, value = "onholddetails")
	@ResponseBody
	public IMBResp getOnholddetails(HttpServletRequest httpRequest, @RequestBody final IndexReq request) {
		Logger.debug("GetOnholddetails - getDetails(). Request: " + request, this.getClass());
		String logName = startPerformanceLog(httpRequest);
		MobileSession mobileSession = new MobileSessionImpl();

		try {
			mobileSession.getSessionContext(httpRequest);
			validateRequestHeader(request.getHeader(), httpRequest);
			ErrorResp errorResponse = validate(request, httpRequest);
			if (errorResponse.hasErrors())
				return errorResponse;
			IBankCommonData commonData = new MBAppHelper().populateIBankCommonData(mobileSession, httpRequest);

			Account card = mobileSession.getCards().get(Integer.parseInt(request.getIndex()));
			Logger.debug("************ card.getAccountId().getAccountNumber() "+ card.getAccountId().getAccountNumber(), this.getClass());
			LostCardsDetails lostCard = cardService.getBlockedLostCard(mobileSession.getCustomer().getGcis(), card.getAccountId().getAccountNumber(), Account.CRA.equalsIgnoreCase(card.getAccountId().getApplicationId()));
			
			CardOnHoldDetailsResp cardOnHoldDetailsResp = new CardOnHoldDetailsResp();
//			cardOnHoldDetailsResp.setRequestId(lostCard.getRequestId().toString());
			String reasonCode = lostCard.getReasonCode();
			cardOnHoldDetailsResp.setReportingOption( lostCard.getReasonCode().toUpperCase()				);
			
			cardOnHoldDetailsResp.setReportingDate(lostCard.getLostDate().toString());
			cardOnHoldDetailsResp.setReportingTime(lostCard.getLostTime());
			cardOnHoldDetailsResp.setLostOverseas(new Boolean("Yes".equalsIgnoreCase(lostCard.getLostOverseas())));
			cardOnHoldDetailsResp.setLocation(lostCard.getLostPlace());
			cardOnHoldDetailsResp.setCountry(lostCard.getCountry());
			cardOnHoldDetailsResp.setCardSigned( new Boolean("Yes".equalsIgnoreCase(lostCard.getCardSigned())));
			cardOnHoldDetailsResp.setFraudulent( new Boolean("Yes".equalsIgnoreCase(lostCard.getFraud())));
			cardOnHoldDetailsResp.setContactNumber(lostCard.getContactNum());
			cardOnHoldDetailsResp.setAdditionalInfo(lostCard.getDescription());
			cardOnHoldDetailsResp.setCardOrdered( new Boolean("Yes".equalsIgnoreCase(lostCard.getReplCardRqed())));
			cardOnHoldDetailsResp.setReplacementCardFee( "15");
			IMBResp serviceResponse = cardOnHoldDetailsResp;
			RespHeader headerResp = populateResponseHeader(ServiceConstants.REPORT_LOST_CARD_SERVICE, mobileSession );
			serviceResponse.setHeader(headerResp);
			return  serviceResponse;
			
			
		} catch (BusinessException e) {
			Logger.info("BusinessException in ReportLostCardController - getDetails() - [key: " + e.getKey() + "] : GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), e, ServiceConstants.REPORT_LOST_DETAILS_SERVICE, httpRequest);
		} catch (ResourceException e) {
			Logger.error("ResourceException in ReportLostCardController - getDetails() - [key: " + e.getKey() + "] : GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.SYSTEM_UNAVILABLE, ServiceConstants.REPORT_LOST_DETAILS_SERVICE, httpRequest);
		} catch (Exception e) {
			Logger.error("Exception ReportLostCardController - getDetails(): GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), ResourceException.MOBILE_NON_FINANCIAL_FATAL_ERR, ServiceConstants.REPORT_LOST_DETAILS_SERVICE, httpRequest);
		} finally {
			endPerformanceLog(logName);
		}
	}

	
	/**
	 * Get Cards service operation
	 * 
	 * @param httpRequest
	 * @param request
	 * @return
	 */
	@RequestMapping(method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE, value = "lockUnlockList")
	@ResponseBody
	public IMBResp getLockUnlockCards(HttpServletRequest httpRequest, @RequestBody final EmptyReq request) {
		Logger.debug("ReportLostCardController - getLockUnlockCards(). Request: " + request, this.getClass());
		String logName = startPerformanceLog(httpRequest);
		MobileSession mobileSession = new MobileSessionImpl();

		Collection<Account> cards = new ArrayList<>(); 
		Exception finalException = null, gccException = null;		
		
		try {
			mobileSession.getSessionContext(httpRequest);
			validateRequestHeader(request.getHeader(), httpRequest);
			ErrorResp errorResponse = validate(request, httpRequest);
			if (errorResponse.hasErrors())
				return errorResponse;
			IBankCommonData commonData = new MBAppHelper().populateIBankCommonData(mobileSession, httpRequest);
			
			// SBGEXP-7606- WWW - LOCK - Exception scenarios for get GCC card list service.
			// Following changes are made to handle exception scenarios.
			// Moved the getCardsList and getLockUnlockGlobalWalletCards calls in two separate try-catch blocks.
			// If any exceptions while fetching both cards types, assign them to finalException and gccException respectively.
			// If both exceptions are not null, throw the finalException, which will result into current prod error message to be populated.
			// Note - in either case, GCC exception will always be suppressed.
			try{
				cards = cardService.getCardsList(mobileSession.getCustomer().getGcis(), commonData);
			} catch (Exception e) {
				finalException = e;				
			}
			
			//20E1 - Add GCC cards to list
			try{
				if(globalWalletService.isGlobalWalletSwitchOn(commonData.getCustomer().getGcis())){
					List<String> lockUnlockValidStatus = Arrays.asList(IBankParams.getCodesData(IBankParams.DEFAULT_ORIGIN, IBankParams.CATEGORY_GLOBAL_WALLET, IBankParams.GLOBAL_WALLET_LOCK_UNLOCK_CARD_STATUS).getMessage().split(","));
					cardService.getLockUnlockGlobalWalletCards(cards, commonData,lockUnlockValidStatus);
				}
			} catch (Exception e) {
				gccException = e;
			}
			
			if(null != finalException && null != gccException)
				throw finalException;
			
			mobileSession.setCards((List<Account>) cards);
			return helper.populateLockUnlockCardListResponse(populateResponseHeader(ServiceConstants.LOCK_UNLOCK_SERVICE, mobileSession ), (List<Account>) cards);
		} catch (BusinessException e) {
			Logger.info("BusinessException in ReportLostCardController - getCards() - [key: " + e.getKey() + "] : GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());
			if ( e.getKey() ==  BusinessException.LOST_CARD_SYS_UNAVAIL )
			{
				return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.MB_NOT_AVAILABLE, ServiceConstants.LOCK_UNLOCK_SERVICE, httpRequest);
			}
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), e, ServiceConstants.LOCK_UNLOCK_SERVICE, httpRequest);
		} catch (ResourceException e) {
			Logger.error("ResourceException in ReportLostCardController - getLockUnlockCards() - [key: " + e.getKey() + "] : GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.SYSTEM_UNAVILABLE, ServiceConstants.LOCK_UNLOCK_SERVICE, httpRequest);
		} catch (Exception e) {
			Logger.error("Exception ReportLostCardController - getLockUnlockCards(): GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), ResourceException.MOBILE_NON_FINANCIAL_FATAL_ERR, ServiceConstants.LOCK_UNLOCK_SERVICE, httpRequest);
		} finally {
			endPerformanceLog(logName);
		}
	}
	
	/**
	 * Report Lost or Stolen card service operation
	 * 
	 * @param httpRequest
	 * @param request
	 * @return
	 */
	@RequestMapping(method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE, value = "lock")
	@ResponseBody
	public IMBResp lockCard(HttpServletRequest httpRequest, @RequestBody final IndexReq request) {
		Logger.debug("ReportLostCardController - lockCard(). Request: " + request, this.getClass());
		String logName = startPerformanceLog(httpRequest);
		MobileSession mobileSession = new MobileSessionImpl();

		DigitalSecLogggerVO digitalSecLoggerVO = null;
		try {
			mobileSession.getSessionContext(httpRequest);
			validateRequestHeader(request.getHeader(), httpRequest);
			ErrorResp errorResponse = validate(request, httpRequest);
			if (errorResponse.hasErrors())
				return errorResponse;


			IBankCommonData commonData = new MBAppHelper().populateIBankCommonData(mobileSession, httpRequest);
			Account card = mobileSession.getCards().get(Integer.parseInt(request.getIndex()));

			//20E1 - Lock for GCC cards - SBGEXP-7609
			if(globalWalletService.isGlobalWalletSwitchOn(commonData.getCustomer().getGcis())){
				if (card instanceof GCCAccount) {
					
					///SBGEXP-8078 - Cross Brand Validations
					String cardNum = ((GCCAccount) card).getCardNumber();					
					String brand = gwServiceHelper.isGlobalWalletCard(cardNum);
					
					//Call WDP API to lock the card.
					cardLockUnlockService.lockUnlockCard(commonData, UUID.randomUUID(), 
							helper.getLockUnlockGCCCardReq(cardNum, commonData.getCustomer().getGcis(), 
									IBankParams.getBaseOriginCode(brand), true));
					
					//Populate the response
					//Set only success as true.
					LockUnlockStatusResp lockUnlockStatusResp = new LockUnlockStatusResp();
					lockUnlockStatusResp.setIsSuccess(true);
					RespHeader headerResp = populateResponseHeader(request.getHeader().getServiceName(), mobileSession );
					lockUnlockStatusResp.setHeader(headerResp);
										
					//SBGEXP-7921
					LostCardsDetails lostCard = helper.gccLostCardRequest(commonData.getCustomer().getGcis(), commonData.getOrigin(), ((GCCAccount)card).getCardNumber(), true);
					cardService.logGCCLockUnlockdRequest(lostCard);
					
					cardService.sendEmail(lostCard, commonData, LOCK_ACTION);
					cardService.sendMessageCentreMsgLockUnlockGWC(commonData, lostCard.getCardNumber().substring(lostCard.getCardNumber().length() - 4, lostCard.getCardNumber().length()), MessageCentreConstants.MSGCNTR_GLOBAL_WALLET_CARD_LOCK);
					
					//GDW entry
					helper.logStatisticGCCCardLockUnlock(((GCCAccount) card).getCardNumber(), commonData, LOCK);
					
					return lockUnlockStatusResp;
				}
			}
			
			
				String cardCategory = "";
				if (card instanceof DebitCardAccount) {
					cardCategory = "VisaDebit";
					card.getAccountId().setAccountNumber(((DebitCardAccount) card).getCardNumber());// for the service to get address
					CodesVO myCodesVO = IBankParams.getCodesData(IBankParams.DEFAULT_ORIGIN, "BINs", IBankParams.PROP_DEBIT_CARDS);
					if (myCodesVO != null) {
						String strBINList = myCodesVO.getMessage();
						List<String> proprietaryDebitCardsBins = IBankParams.getArrayListFromString(strBINList);
						for (String bin : proprietaryDebitCardsBins)
							if (((DebitCardAccount) card).getCardNumber().startsWith(bin)) {
								cardCategory = "PropDebit";
							}
					}
				}
				LostCardsDetails lostCard = helper.initLockUnlockCardRequest(cardCategory, commonData.getCustomer().getGcis(), mobileSession.getOrigin(), card);

			lostCard.setBlockType(LostCardsDetails.BLOCKTYPE_TEMP);
			lostCard.setLostOrStolen(LostCardsDetails.LOST_CODE);
			lostCard.setReasonCode(LostCardsDetails.LOCK_CODE);
			lostCard.setEmailRequired(true);
			
			digitalSecLoggerVO = createDigitalSecLogggerVO(lostCard, commonData);
			
			Logger.debug("Lock Card request: " + ReflectionToStringBuilder.toString(lostCard, ToStringStyle.MULTI_LINE_STYLE), this.getClass());

			lostCard = cardService.processLostCardRequest(lostCard, commonData, card);
		
			digitalSecurityLogger.log(digitalSecLoggerVO);
			
			SuccessResp serviceResponse = null; //new SuccessResp();
			LockUnlockStatusResp lockUnlockStatusResp = null;
			
			try
			{
				 lockUnlockStatusResp = getLockUnlockStatusResp(true,  mobileSession ,  commonData );
					RespHeader headerResp = populateResponseHeader(request.getHeader().getServiceName(), mobileSession );
					lockUnlockStatusResp.setHeader(headerResp);
					lockUnlockStatusResp.setIsSuccess(true);
					return lockUnlockStatusResp;
			}
			catch ( Exception e)
			{
				serviceResponse = new SuccessResp();
				RespHeader headerResp = populateResponseHeader(request.getHeader().getServiceName(), mobileSession );
				serviceResponse.setHeader(headerResp);
				serviceResponse.setIsSuccess(true);
				return serviceResponse;
			}
			
		} 
		catch (BusinessException e) {
			Logger.info("BusinessException in ReportLostCardController - lockCard() - [key: " + e.getKey() + "] : GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());
			if(digitalSecLoggerVO != null)
			{
				digitalSecLoggerVO.setStatus(DigitalSecLogger.FAILURE);
				digitalSecurityLogger.log(digitalSecLoggerVO);
			}
			
			if (e.getKey() ==  BusinessException.GLOBAL_WALLET_LOCK_UNLOCK_CARD_ERROR) {
				BusinessException exp = new BusinessException(BusinessException.GLOBAL_WALLET_LOCK_UNLOCK_CARD_ERROR);				
				
				String baseOrigin = IBankParams.getBaseOriginCode(mobileSession.getOrigin());
	            String gccCustomerCare = IBankParams.getGCCMasterCardCustomerCare(baseOrigin);
	            String gccCustomerCareOverseas = IBankParams.getGCCMasterCardCustomerCareOverseas(baseOrigin);
	            String[] msgParams = {gccCustomerCare, gccCustomerCareOverseas };
	            String message = IBankParams.getErrorMessage(baseOrigin, String.valueOf(BusinessException.GLOBAL_WALLET_LOCK_UNLOCK_CARD_ERROR));
	                                                       
	              if (msgParams != null) {
	                     message = MessageFormat.format(message, (Object[])msgParams);
	              }
				
				return MBAppUtils.createErrorResp(mobileSession.getOrigin(), exp, msgParams, ServiceConstants.LOCK_UNLOCK_UPDATE_SERVICE, httpRequest);				
			}
			else  {
				BusinessException exp = new BusinessException(BusinessException.LOCK_UNLOCK_UPDATE_ERROR);
				OriginsVO myOriginVO  = IBankParams.getOrigin(mobileSession.getOrigin());
				OriginsVO baseOrigin  = IBankParams.getOrigin(myOriginVO.getBankName());
				String[] values = {baseOrigin.getPhone()};	
				return MBAppUtils.createErrorResp(mobileSession.getOrigin(), exp, values, ServiceConstants.LOCK_UNLOCK_UPDATE_SERVICE, httpRequest);
			}
		} catch (ResourceException e) {
			if(digitalSecLoggerVO != null)
			{
				digitalSecLoggerVO.setStatus(DigitalSecLogger.FAILURE);
				digitalSecurityLogger.log(digitalSecLoggerVO);
			}
			Logger.error("ResourceException in ReportLostCardController - lockCard() - [key: " + e.getKey() + "] : GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.SYSTEM_UNAVILABLE, ServiceConstants.LOCK_UNLOCK_UPDATE_SERVICE, httpRequest);
		} catch (Exception e) {
			if(digitalSecLoggerVO != null)
			{
				digitalSecLoggerVO.setStatus(DigitalSecLogger.FAILURE);
				digitalSecurityLogger.log(digitalSecLoggerVO);
			}
			Logger.error("Exception ReportLostCardController - lockCard(): GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), ResourceException.MOBILE_NON_FINANCIAL_FATAL_ERR, ServiceConstants.LOCK_UNLOCK_UPDATE_SERVICE, httpRequest);
		} finally {
			endPerformanceLog(logName);
		}
	}
	
	/**
	 * Report Lost or Stolen card service operation
	 * 
	 * @param httpRequest
	 * @param request
	 * @return
	 */
	@RequestMapping(method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE, value = "unlock")
	@ResponseBody
	public IMBResp unlockCard(HttpServletRequest httpRequest, @RequestBody final IndexReq request) {
		Logger.debug("ReportLostCardController - unlockCard(). Request: " + request, this.getClass());
		String logName = startPerformanceLog(httpRequest);
		MobileSession mobileSession = new MobileSessionImpl();

		DigitalSecLogggerVO digitalSecLoggerVO = null;
		try {
			mobileSession.getSessionContext(httpRequest);
			validateRequestHeader(request.getHeader(), httpRequest);
			ErrorResp errorResponse = validate(request, httpRequest);
			if (errorResponse.hasErrors())
				return errorResponse;


			IBankCommonData commonData = new MBAppHelper().populateIBankCommonData(mobileSession, httpRequest);

			Account card = mobileSession.getCards().get(Integer.parseInt(request.getIndex()));

			//20E1 - Unlock GCC cards - SBGEXP-7611
			if(globalWalletService.isGlobalWalletSwitchOn(commonData.getCustomer().getGcis())){
				
				if (card instanceof GCCAccount) {					
					
					///SBGEXP-8078 - Cross Brand Validations
					String cardNum = ((GCCAccount) card).getCardNumber();					
					String brand = gwServiceHelper.isGlobalWalletCard(cardNum);
					
					//Call WDP API to unlock the card.
					cardLockUnlockService.lockUnlockCard(commonData, UUID.randomUUID(), 
							helper.getLockUnlockGCCCardReq(cardNum, commonData.getCustomer().getGcis(), 
									IBankParams.getBaseOriginCode(brand), false));
					
					//Populate the response
					//Set only success as true.
					LockUnlockStatusResp lockUnlockStatusResp = new LockUnlockStatusResp();
					lockUnlockStatusResp.setIsSuccess(true);
					RespHeader headerResp = populateResponseHeader(request.getHeader().getServiceName(), mobileSession );
					lockUnlockStatusResp.setHeader(headerResp);
										
					//SBGEXP-7921
					LostCardsDetails lostCard = helper.gccLostCardRequest(commonData.getCustomer().getGcis(), commonData.getOrigin(), ((GCCAccount)card).getCardNumber(), false);
					cardService.logGCCLockUnlockdRequest(lostCard);
					cardService.sendEmail(lostCard, commonData, UNLOCK_ACTION);
					cardService.sendMessageCentreMsgLockUnlockGWC(commonData, lostCard.getCardNumber().substring(lostCard.getCardNumber().length() - 4, lostCard.getCardNumber().length()), MessageCentreConstants.MSGCNTR_GLOBAL_WALLET_CARD_UNLOCK);
					
					//GDW entry
					helper.logStatisticGCCCardLockUnlock(((GCCAccount) card).getCardNumber(), commonData, UNLOCK);
					
					return lockUnlockStatusResp;
				}
			}
			
				String cardCategory = "";
				if (card instanceof DebitCardAccount) {
					cardCategory = "VisaDebit";
					card.getAccountId().setAccountNumber(((DebitCardAccount) card).getCardNumber());// for the service to get address
					CodesVO myCodesVO = IBankParams.getCodesData(IBankParams.DEFAULT_ORIGIN, "BINs", IBankParams.PROP_DEBIT_CARDS);
					if (myCodesVO != null) {
						String strBINList = myCodesVO.getMessage();
						List<String> proprietaryDebitCardsBins = IBankParams.getArrayListFromString(strBINList);
						for (String bin : proprietaryDebitCardsBins)
							if (((DebitCardAccount) card).getCardNumber().startsWith(bin)) {
								cardCategory = "PropDebit";
							}
					}
				}
				LostCardsDetails lostCard = helper.initLockUnlockCardRequest(cardCategory, commonData.getCustomer().getGcis(), mobileSession.getOrigin(), card);

			lostCard.setBlockType(LostCardsDetails.BLOCKTYPE_RELEASE);
			lostCard.setReasonCode(LostCardsDetails.UNLOCK_CODE);
			lostCard.setEmailRequired(true);
			
			digitalSecLoggerVO = createDigitalSecLogggerVO(lostCard, commonData);
			
			Logger.debug("Unlock Card request: " + ReflectionToStringBuilder.toString(lostCard, ToStringStyle.MULTI_LINE_STYLE), this.getClass());

			lostCard = cardService.processLostCardRequest(lostCard, commonData, card);
		
			digitalSecurityLogger.log(digitalSecLoggerVO);

			
//			SuccessResp serviceResponse = null; //new SuccessResp();
			LockUnlockStatusResp lockUnlockStatusResp = null;
			
			try
			{
				 lockUnlockStatusResp = getLockUnlockStatusResp(false,  mobileSession ,  commonData );
					RespHeader headerResp = populateResponseHeader(request.getHeader().getServiceName(), mobileSession );
					lockUnlockStatusResp.setHeader(headerResp);
					lockUnlockStatusResp.setIsSuccess(true);
					return lockUnlockStatusResp;
			}
			catch ( Exception e)
			{
				SuccessResp serviceResponse = new SuccessResp();
				RespHeader headerResp = populateResponseHeader(request.getHeader().getServiceName(), mobileSession );
				serviceResponse.setHeader(headerResp);
				serviceResponse.setIsSuccess(true);
				return serviceResponse;
			}

			
		} 
		catch (BusinessException e) {
			Logger.info("BusinessException in ReportLostCardController - unlockCard() - [key: " + e.getKey() + "] : GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());
			if(digitalSecLoggerVO != null)
			{
				digitalSecLoggerVO.setStatus(DigitalSecLogger.FAILURE);
				digitalSecurityLogger.log(digitalSecLoggerVO);
			}
			
			if ( e.getKey() ==  BusinessException.LOST_CARD_REPORT_RELEASE_BY_SECONDARY_UNSUCCESS )
			{
				return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.LOST_CARD_REPORT_RELEASE_BY_SECONDARY_UNSUCCESS, ServiceConstants.LOCK_UNLOCK_UPDATE_SERVICE, httpRequest);
			}
			else if (e.getKey() ==  BusinessException.GLOBAL_WALLET_LOCK_UNLOCK_CARD_ERROR) {
				BusinessException exp = new BusinessException(BusinessException.GLOBAL_WALLET_LOCK_UNLOCK_CARD_ERROR);				
				
				String baseOrigin = IBankParams.getBaseOriginCode(mobileSession.getOrigin());
	            String gccCustomerCare = IBankParams.getGCCMasterCardCustomerCare(baseOrigin);
	            String gccCustomerCareOverseas = IBankParams.getGCCMasterCardCustomerCareOverseas(baseOrigin);
	            String[] msgParams = {gccCustomerCare, gccCustomerCareOverseas };
	            String message = IBankParams.getErrorMessage(baseOrigin, String.valueOf(BusinessException.GLOBAL_WALLET_LOCK_UNLOCK_CARD_ERROR));
	                                                       
	              if (msgParams != null) {
	                     message = MessageFormat.format(message, (Object[])msgParams);
	              }
				
				return MBAppUtils.createErrorResp(mobileSession.getOrigin(), exp, msgParams, ServiceConstants.LOCK_UNLOCK_UPDATE_SERVICE, httpRequest);				
			}
			else{
			BusinessException exp = new BusinessException(BusinessException.LOCK_UNLOCK_UPDATE_ERROR);
			OriginsVO myOriginVO  = IBankParams.getOrigin(mobileSession.getOrigin());
			OriginsVO baseOrigin  = IBankParams.getOrigin(myOriginVO.getBankName());
			String[] values = {baseOrigin.getPhone()};	
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), exp, values, ServiceConstants.LOCK_UNLOCK_UPDATE_SERVICE, httpRequest);
			}
			
		} catch (ResourceException e) {
			if(digitalSecLoggerVO != null)
			{
				digitalSecLoggerVO.setStatus(DigitalSecLogger.FAILURE);
				digitalSecurityLogger.log(digitalSecLoggerVO);
			}
			Logger.error("ResourceException in ReportLostCardController - unlockCard() - [key: " + e.getKey() + "] : GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.SYSTEM_UNAVILABLE, ServiceConstants.LOCK_UNLOCK_UPDATE_SERVICE, httpRequest);
		} catch (Exception e) {
			if(digitalSecLoggerVO != null)
			{
				digitalSecLoggerVO.setStatus(DigitalSecLogger.FAILURE);
				digitalSecurityLogger.log(digitalSecLoggerVO);
			}
			Logger.error("Exception ReportLostCardController - unlockCard(): GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), ResourceException.MOBILE_NON_FINANCIAL_FATAL_ERR, ServiceConstants.LOCK_UNLOCK_UPDATE_SERVICE, httpRequest);
		} finally {
			endPerformanceLog(logName);
		}
	}

	
	
	public ErrorResp validate(IMBReq serviceRequest, HttpServletRequest request) {
		Logger.info("Service request object - " + ReflectionToStringBuilder.toString(serviceRequest), this.getClass());
		return mbAppValidator.validate(serviceRequest, request);
	}

	public void validateRequestHeader(ReqHeader headerReq, HttpServletRequest request) throws BusinessException {
		Logger.debug("Request header validation: " + ReflectionToStringBuilder.toString(headerReq, ToStringStyle.MULTI_LINE_STYLE), this.getClass());
		mbAppValidator.validateRequestHeader(headerReq, request);
	}

	/**
	 * Response for invalid body request
	 * 
	 * @return
	 */
	@ExceptionHandler( { org.springframework.http.converter.HttpMessageNotReadableException.class })
	@ResponseStatus(org.springframework.http.HttpStatus.OK)
	@ResponseBody
	public IMBResp resolveException() {
		return MBAppUtils.createInvalidMessageBodyResponse(ServiceConstants.REPORT_LOST_CARD_SERVICE);
	}

	
	public RespHeader populateResponseHeader(String serviceName, MobileSession mobSession) {
		return mbAppHelper.populateResponseHeader(serviceName, mobSession);
	}

	@Autowired
	private PerformanceLogger perfLogger;
	
	private String startPerformanceLog(HttpServletRequest httpRequest){
		perfLogger.startAllLogs();
		String logName = MBAppUtils.getLogName(httpRequest);
		perfLogger.startLog(logName);
		return logName;
	}
	
	private void endPerformanceLog(String logName){
		perfLogger.endLog(logName);
		perfLogger.endAllLogs();
	}
	
	private ServiceStationVO populateServiceMessage(long insertionPoint,String channel, IBankCommonData commonData)
	{
		ServiceStationVO serviceStationAdminVo=null;
		try
		{
		 serviceStationAdminVo= serviceStationService.getServiceMessage(insertionPoint, ServiceStationImpl.CHANNEL_MOBILE, commonData);			
		}
		 catch(BusinessException ex){
			Logger.error("An error occurred while getting service station message for mobile accoutn details", ex, this.getClass());
		}
		return serviceStationAdminVo;
	}
	
	private DigitalSecLogggerVO createDigitalSecLogggerVO(LostCardsDetails lostCard, IBankCommonData commonData)
	{
		DigitalSecLogggerVO digitalSecLoggerVO =new DigitalSecLogggerVO();
		try{
			digitalSecLoggerVO.setCommonLogData(mbAppHelper.getCommonLogData(commonData));
			digitalSecLoggerVO.setUserAgent(commonData.getUserAgent()); 
			
			if (LostCardsDetails.BLOCKTYPE_TEMP.equals(lostCard.getBlockType()) && LostCardsDetails.LOCK_CODE.equals(lostCard.getReasonCode())) {
				//LockCard
				digitalSecLoggerVO.setTranName(DigitalSecLogger.EVENT_LOCK_CARD);
			}
			else if (LostCardsDetails.BLOCKTYPE_TEMP.equals(lostCard.getBlockType())) {
				//TempBlock
				digitalSecLoggerVO.setTranName(DigitalSecLogger.EVENT_TEMP_BLOCK_CARD);
			}
			else if (LostCardsDetails.BLOCKTYPE_RELEASE.endsWith(lostCard.getBlockType()) && LostCardsDetails.UNLOCK_CODE.equals(lostCard.getReasonCode())) {
				//UnlockCard
				digitalSecLoggerVO.setTranName(DigitalSecLogger.EVENT_UNLOCK_CARD);
			}
			else if (LostCardsDetails.BLOCKTYPE_RELEASE.endsWith(lostCard.getBlockType())) {
				//UnblockCard 
				digitalSecLoggerVO.setTranName(DigitalSecLogger.EVENT_UNBLOCK_CARD);
			}
			else if (LostCardsDetails.BLOCKTYPE_PERM.equals(lostCard.getBlockType()) || LostCardsDetails.BLOCKTYPE_TEMP_TO_PERM.equals(lostCard.getBlockType())) {
				//LostStolenCard
				digitalSecLoggerVO.setTranName(DigitalSecLogger.EVENT_LOST_CARD);
			}
			digitalSecLoggerVO.setStatus(DigitalSecLogger.SUCCESS);
			digitalSecLoggerVO.setValues(new StringBuilder().append(DigitalSecLogger.CARD_NO).append(DigitalSecLogger.DELIMITER_COLON).append(lostCard.getCardNumber()).append(DigitalSecLogger.DELIMITER_COMMA).append(DigitalSecLogger.CARD_BLOCK_TYPE).append(DigitalSecLogger.DELIMITER_COLON).append(lostCard.getBlockType()).append(DigitalSecLogger.DELIMITER_COMMA).append(DigitalSecLogger.CARD_BLOCK_REASON).append(DigitalSecLogger.DELIMITER_COLON).append(lostCard.getReasonCode()).toString());

			LostCardsDetails previousCardsDetails = cardService.getLostCardDetails(commonData.getUser().getGCISNumber(), lostCard.getCardNumber());
			if(previousCardsDetails != null)
			{
				digitalSecLoggerVO.setPrevValues(new StringBuilder().append(DigitalSecLogger.CARD_BLOCK_REASON).append(DigitalSecLogger.DELIMITER_COLON).append(previousCardsDetails.getReasonCode()).toString());
			}
			
		}catch(Exception e)
		{
			//suppress error. not logging anything intentionally
		}
		return digitalSecLoggerVO;
	}
	
	
	private static final String SALES_OFFER_HELPER_BEAN = "salesOfferHelper";

 private LockUnlockStatusResp getLockUnlockStatusResp(boolean isLockedCard, MobileSession mobileSession ,IBankCommonData  ibankCommonData )
 {
	 
	 LockUnlockStatusResp lockUnlockStatusResp = new LockUnlockStatusResp();
	 
	 if ( ! isLockedCard )
	 {
		 isLockedCard = logonHelper.isTempBlockedCard(mobileSession.getCustomer().getGcis(),mobileSession.getOrigin());
	 }

	if  (isLockedCard)
	{
		LockedCardInfoResp lockedCardInfoResp = new LockedCardInfoResp();
		CodesVO codeItem=IBankParams.getCodesData(mobileSession.getOrigin() , IBankParams.CONST_LOCK_UNLOCK,IBankParams.LOCK_UNLOCK_TILE_TXT);
		if ( codeItem != null && ! StringMethods.isEmptyString(codeItem.getMessage()))
		{
			lockedCardInfoResp.setLockText(codeItem.getMessage());
		}
		
		lockUnlockStatusResp.setLockedCardInfoResp(lockedCardInfoResp);
	}
	else
	{
		
		if ( mobileSession.getCustomer().getPreference().isDisplayELeadsSplashPage() )
		{
			lockUnlockStatusResp.setInvitationInfoResp(MBAppHelper.populateInvitation(mobileSession.getCustomer()));
			//My Invitation for sales
			SalesOfferHelper salesOfferHelper = (SalesOfferHelper) ServiceHelper.getBean(SALES_OFFER_HELPER_BEAN);		
			lockUnlockStatusResp.setSalesOfferTeaserResp(salesOfferHelper.populateTeaserResp(mobileSession.getCustomer()));//MyInvitation
		}
		
		// adding the service station message to session and  logon response
		if(null!=lockUnlockStatusResp.getSalesOfferTeaserResp())
		{
			if(null==lockUnlockStatusResp.getSalesOfferTeaserResp().getIsDashboard())
			{
				long insertionPt = logonHelper.getInsertionPointCode(ServicetationConstants.DASHBOARD);
				ServiceStationVO servicestationVO=populateServiceMessage(insertionPt,ServiceStationImpl.CHANNEL_MOBILE, ibankCommonData);

				if(null!=servicestationVO)
				{			
					mobileSession.setServiceStationDashboardMessage(servicestationVO.getServiceStationMsg());
					lockUnlockStatusResp.setServiceStation(logonHelper.populateServiceStationResp(servicestationVO));
				}
			}
		}
	}
	return lockUnlockStatusResp;
 }
 
	@Autowired
	private LogonHelper logonHelper;

	public static boolean isMadisonLCMSwitchOn(String gcisNumber) {
		boolean madisonLCMSwitch=false;
		IBankRefershParams ibankRefreshParams = (IBankRefershParams) ServiceHelper.getBean("ibankRefreshParams");
		String madisonLCMSwitchVal = IBankParams.getBrandSwitchVal(IBankParams.DEFAULT, IBankParams.MADISON_LCM_SWITCH) ;
		
		if(("1").equalsIgnoreCase(madisonLCMSwitchVal)) {
			madisonLCMSwitch=true;
		}else if(("2").equalsIgnoreCase(madisonLCMSwitchVal)) {
			boolean isPilot=ibankRefreshParams.isPilotCustomer(gcisNumber,IBankParams.MADISON_LCM_PILOT_LIST);
			if(isPilot) {
				madisonLCMSwitch=true;
			}
		}
		return madisonLCMSwitch;
	}
}