package au.com.stgeorge.mbank.model.common;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_NULL)
public class BillerResp implements Serializable {

	private static final long serialVersionUID = -5644335741921584851L;

	private int serverIndex;
	private String crn;
	private String billerAlias;
	private String billerCode;
	private String billerName;
	private String payerName;
	private boolean variableCRN;

	public int getBillerIndex() {
		return serverIndex;
	}

	public void setBillerIndex(int serverIndex) {
		this.serverIndex = serverIndex;
	}

	public String getCrn() {
		return crn;
	}

	public void setCrn(String crn) {
		this.crn = crn;
	}

	public String getBillerAlias() {
		return billerAlias;
	}

	public void setBillerAlias(String billerAlias) {
		this.billerAlias = billerAlias;
	}

	public String getBillerCode() {
		return billerCode;
	}

	public void setBillerCode(String billerCode) {
		this.billerCode = billerCode;
	}

	public String getBillerName() {
		return billerName;
	}

	public void setBillerName(String billerName) {
		this.billerName = billerName;
	}

	public String getPayerName() {
		return payerName;
	}

	public void setPayerName(String payerName) {
		this.payerName = payerName;
	}

	public boolean isVariableCRN() {
		return variableCRN;
	}

	public void setVariableCRN(boolean variableCRN) {
		this.variableCRN = variableCRN;
	}

}
