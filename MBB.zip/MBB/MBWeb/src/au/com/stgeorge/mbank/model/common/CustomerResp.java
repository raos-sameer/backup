package au.com.stgeorge.mbank.model.common;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;

import au.com.stgeorge.mbank.model.response.customer.LastTranDetailResp;
import au.com.stgeorge.mbank.model.response.customer.LockedCardInfoResp;
import au.com.stgeorge.mbank.model.response.customer.MarketPreferenceResp;
import au.com.stgeorge.mbank.model.response.offers.SalesOfferTeaserResp;
import au.com.stgeorge.mbank.model.response.servicestation.ServiceStationResp;
import au.com.stgeorge.mbank.util.JsonDateTimeSerializer;

@JsonInclude(Include.NON_NULL)
public class CustomerResp 
{
	private String title;
	private String fullName;
	private String firstName;	
	private String middleName;
	private String lastName;
//	private Date lastLogonDateTime;
//	private String lastTxnAmount;
//	private Date lastTxnDateTime;
//	private String lastTxnType;
	private int unreadMsgCount = -1 ;
	private int unreadOfferCount = -1;
	private Date systemDate;

	private ArrayList<AccountResp> accounts;
	private ArrayList<BillerResp> billers;
	private ArrayList<PayeeResp> payees;

	private ContactInfoResp contact;
	private SecureCodeInfoResp secureCode;
	private CustomerControlResp customerControl;
	
	private FavTranResp mostFavTran;
	private LastTranDetailResp lastTranDetail;
	
	private InvitationInfoResp invitationInfoResp;
	private FastFundingResp fastFundingResp;
	private SalesOfferTeaserResp salesOfferTeaserResp;
	
	private LockedCardInfoResp lockedCardInfoResp;

		
	private BTSuperSearchResp btSuperSearchResp;
	
	private ServiceStationResp serviceStation; // added for ServiceStation

	private OnboardingTileResp onboardingTileResp;
	
	private SplashPageResp splashPage;
	
	private MarketPreferenceResp marketPreference; 
	
	//private GhostTileResp ghostTile;
	private List<GhostTileResp> ghostTiles;
	
	private Boolean hasDDAAccount = true;
	
	//19E1: Savings Habit Onboarding from accounts list
	private List<Integer> savingsHabitFromAccts = new ArrayList<>();
	
	//19E2: Savings Habit Onboarding to accounts list
	private List<Integer> savingsHabitToAccts = new ArrayList<>();

	public SalesOfferTeaserResp getSalesOfferTeaserResp() {
		return salesOfferTeaserResp;
	}

	public void setSalesOfferTeaserResp(SalesOfferTeaserResp salesOfferTeaserResp) {
		this.salesOfferTeaserResp = salesOfferTeaserResp;
	}

	public FastFundingResp getFastFundingResp() {
		return fastFundingResp;
	}

	public void setFastFundingResp(FastFundingResp fastFundingResp) {
		this.fastFundingResp = fastFundingResp;
	}

	public InvitationInfoResp getInvitationInfoResp() {
		return invitationInfoResp;
	}
	
	public void setInvitationInfoResp(InvitationInfoResp specialOfferInfoResp) {
		this.invitationInfoResp = specialOfferInfoResp;
	}
	
	public FavTranResp getMostFavTran()
	{
		return mostFavTran;
	}
	public void setMostFavTran(FavTranResp mostFavTran)
	{
		this.mostFavTran = mostFavTran;
	}
	public String getFullName()
	{
		return fullName;
	}
	public void setFullName(String fullName)
	{
		this.fullName = fullName;
	}
	public String getFirstName()
	{
		return firstName;
	}
	public void setFirstName(String firstName)
	{
		this.firstName = firstName;
	}
	
	@JsonInclude(Include.NON_DEFAULT)
	public int getUnreadMsgCount()
	{
		return unreadMsgCount;
	}
	public void setUnreadMsgCount(int unreadMsgCount)
	{
		this.unreadMsgCount = unreadMsgCount;
	}
	
	@JsonSerialize(using = JsonDateTimeSerializer.class)
	public Date getSystemDate()
	{
		return systemDate;
	}
	public void setSystemDate(Date systemmDate)
	{
		this.systemDate = systemmDate;
	}
	public ArrayList<AccountResp> getAccounts()
	{
		return accounts;
	}
	public void setAccounts(ArrayList<AccountResp> accounts)
	{
		this.accounts = accounts;
	}
	public ArrayList<BillerResp> getBillers()
	{
		return billers;
	}
	public void setBillers(ArrayList<BillerResp> billers)
	{
		this.billers = billers;
	}
	public ArrayList<PayeeResp> getPayees()
	{
		return payees;
	}
	public void setPayees(ArrayList<PayeeResp> payees)
	{
		this.payees = payees;
	}
	public ContactInfoResp getContactInfo()
	{
		return contact;
	}
	public void setContactInfo(ContactInfoResp contact)
	{
		this.contact = contact;
	}
	public SecureCodeInfoResp getSecureCodeInfo()
	{
		return secureCode;
	}
	public void setSecureCodeInfo(SecureCodeInfoResp secureCode)
	{
		this.secureCode = secureCode;
	}
	public CustomerControlResp getCustomerControl()
	{
		return customerControl;
	}
	public void setCustomerControl(CustomerControlResp customerControl)
	{
		this.customerControl = customerControl;
	}
	
	
	public LastTranDetailResp getLastTranDetail()
	{
		return lastTranDetail;
	}
	public void setLastTranDetail(LastTranDetailResp lastTranDetail)
	{
		this.lastTranDetail = lastTranDetail;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getMiddleName() {
		return middleName;
	}
	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public int getUnreadOfferCount() {
		return unreadOfferCount;
	}

	public void setUnreadOfferCount(int unreadOfferCount) {
		this.unreadOfferCount = unreadOfferCount;
	}

	
	public BTSuperSearchResp getBtSuperSearchResp() {
		return btSuperSearchResp;
	}

	public void setBtSuperSearchResp(BTSuperSearchResp btSuperSearchResp) {
		this.btSuperSearchResp = btSuperSearchResp;
	}

	public ServiceStationResp getServiceStation() {
		return serviceStation;
	}

	public void setServiceStation(ServiceStationResp serviceStation) {
		this.serviceStation = serviceStation;
	}

	public OnboardingTileResp getOnboardingTileResp() {
		return onboardingTileResp;
	}

	public void setOnboardingTileResp(OnboardingTileResp onboardingTileResp) {
		this.onboardingTileResp = onboardingTileResp;
	}

	public LockedCardInfoResp getLockedCardInfoResp()
	{
		return lockedCardInfoResp;
	}

	public void setLockedCardInfoResp(LockedCardInfoResp lockedCardInfoResp)
	{
		this.lockedCardInfoResp = lockedCardInfoResp;
	}

	public SplashPageResp getSplashPage() {
		return splashPage;
	}

	public void setSplashPage(SplashPageResp splashPage) {
		this.splashPage = splashPage;
	}

/*	public GhostTileResp getGhostTile() {
		return ghostTile;
	}

	public void setGhostTile(GhostTileResp ghostTile) {
		this.ghostTile = ghostTile;
	}*/

    public List<GhostTileResp> getGhostTiles() {
		return ghostTiles;
	}

	public void setGhostTiles(List<GhostTileResp> ghostTiles) {
		this.ghostTiles = ghostTiles;
	}

	public Boolean getHasDDAAccount() {
		return hasDDAAccount;
	}

	public void setHasDDAAccount(Boolean hasDDAAccount) {
		this.hasDDAAccount = hasDDAAccount;
	}

	public List<Integer> getSavingsHabitFromAccts() {
		return savingsHabitFromAccts;
	}

	public void setSavingsHabitFromAccts(List<Integer> savingsHabitFromAccts) {
		this.savingsHabitFromAccts = savingsHabitFromAccts;
	}

	public List<Integer> getSavingsHabitToAccts() {
		return savingsHabitToAccts;
	}

	public void setSavingsHabitToAccts(List<Integer> savingsHabitToAccts) {
		this.savingsHabitToAccts = savingsHabitToAccts;
	}

	public MarketPreferenceResp getMarketPreference() {
		return marketPreference;
	}

	public void setMarketPreference(MarketPreferenceResp marketPreference) {
		this.marketPreference = marketPreference;
	}
	
}
