package au.com.stgeorge.mbank.model.mortgageinfo;

import java.io.Serializable;
import java.util.List;

import javax.validation.Valid;
import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.Length;
import org.hibernate.validator.constraints.Range;

import au.com.stgeorge.ibank.businessobject.BusinessException;


import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_NULL)
public class DocCategoryDetailInfo implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = -3511955740636187428L;

	private String categoryName;	

	private String categoryId;
	
	private Boolean applicationLevel;
	
	private List<DocApplicantInfo> docApplicants;			
	
	public String getCategoryName() {
		return categoryName;
	}
	
	public void setCategoryName(String categoryName) {
		this.categoryName = categoryName;
	}
	
	public String getCategoryId() {
		return categoryId;
	}
	
	public void setCategoryId(String categoryId) {
		this.categoryId = categoryId;
	}
	
	public List<DocApplicantInfo> getDocApplicants() {
		return docApplicants;
	}
	
	public void setDocApplicants(List<DocApplicantInfo> docApplicants) {
		this.docApplicants = docApplicants;
	}

	public Boolean getApplicationLevel() {
		return applicationLevel;
	}

	public void setApplicationLevel(Boolean applicationLevel) {
		this.applicationLevel = applicationLevel;
	}

	
}
