package au.com.stgeorge.mbank.model.loanApplication;

import java.util.List;

import au.com.stgeorge.mbank.model.common.GhostTileResp;
import au.com.stgeorge.mbank.model.common.IMBResp;
import au.com.stgeorge.mbank.model.common.RespHeader;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_NULL)
public class LoanStatusResp implements IMBResp {
	
	private static final long serialVersionUID = -5955216995766909128L;

	private List<GhostTileResp> ghostTiles;
	private RespHeader header;

	public List<GhostTileResp> getGhostTiles() {
		return ghostTiles;
	}

	public void setGhostTiles(List<GhostTileResp> ghostTiles) {
		this.ghostTiles = ghostTiles;
	}

	@Override
	public RespHeader getHeader() {
		return header;
	}

	@Override
	public void setHeader(RespHeader header) {
		this.header = header;
		
	}
	
	
	
}
