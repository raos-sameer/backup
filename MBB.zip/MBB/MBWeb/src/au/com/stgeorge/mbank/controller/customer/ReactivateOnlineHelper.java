package au.com.stgeorge.mbank.controller.customer;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import au.com.stgeorge.framework.common.logging.Logger;
import au.com.stgeorge.framework.common.util.StringMethods;
import au.com.stgeorge.ibank.common.cache.IBankParams;
import au.com.stgeorge.ibank.util.ServiceHelper;
import au.com.stgeorge.ibank.valueobject.ContactDetail;
import au.com.stgeorge.ibank.valueobject.Customer;
import au.com.stgeorge.ibank.valueobject.database.CodesVO;
import au.com.stgeorge.mbank.model.common.ContactInfoResp;
import au.com.stgeorge.mbank.model.common.PhoneInfoResp;
import au.com.stgeorge.mbank.model.common.SecureCodeInfoResp;
import au.com.stgeorge.mbank.util.OriginResolver;

public class ReactivateOnlineHelper  {
	
	public static final String SPRING_ORIGIN_RESOLVER_BEAN = "originResolver";
	
	public  ContactInfoResp populateContact(ContactDetail contactDetail)
	{
		ContactInfoResp mbContact = new ContactInfoResp();
		
		ArrayList<au.com.stgeorge.mbank.model.common.PhoneInfoResp> phones = new ArrayList<au.com.stgeorge.mbank.model.common.PhoneInfoResp>();
		
		PhoneInfoResp phoneInfo = null;
		if ( contactDetail.getMobileNumber() != null )
		{
			phoneInfo = new PhoneInfoResp();
			phoneInfo.setPhoneType( "MOBILE" );
			if ( StringMethods.isEmptyString(contactDetail.getMobileNumber().getPhoneNumber() ) )
			{
				phoneInfo.setPhoneNum("");
			}
			else
			{
				phoneInfo.setPhoneNum(maskPhoneNumber(contactDetail.getMobileNumber().getAreaCode() + contactDetail.getMobileNumber().getPhoneNumber()));
			}
			phones.add(phoneInfo);
		}

		if ( contactDetail.getHomeNumber() != null )
		{
			phoneInfo = new PhoneInfoResp();
			phoneInfo.setPhoneType( "HOME" );
			if ( StringMethods.isEmptyString(contactDetail.getHomeNumber().getPhoneNumber()) )
			{
				phoneInfo.setPhoneNum("" );
			}
			else
			{
				phoneInfo.setPhoneNum("(" + contactDetail.getHomeNumber().getAreaCode() + ") "
						+ maskPhoneNumber(contactDetail.getHomeNumber().getPhoneNumber()));
			}
			phones.add(phoneInfo);
		}

		if ( contactDetail.getWorkNumber() != null )
		{
			phoneInfo = new PhoneInfoResp();
			phoneInfo.setPhoneType( "WORK" );
			if ( StringMethods.isEmptyString(contactDetail.getWorkNumber().getPhoneNumber()) )
			{
				phoneInfo.setPhoneNum("");
			}
			else
			{
				phoneInfo.setPhoneNum("(" + contactDetail.getWorkNumber().getAreaCode() + ") "
						+ maskPhoneNumber(contactDetail.getWorkNumber().getPhoneNumber()));
			}
			
			phones.add(phoneInfo);
		}
		
		if ( phones.size() > 0 )
		{
			mbContact.setPhones(phones);
		}

		return mbContact;
	}
	
	public  SecureCodeInfoResp populateSecureCodeInfo(Customer customer )
	{
		SecureCodeInfoResp secureCodeInfo = null;
		if(customer.getIBankSecureDetails() != null){
			secureCodeInfo = new SecureCodeInfoResp();
			String delPref = customer.getIBankSecureDetails().getDeliveryPref();
			secureCodeInfo.setDeliveryPref(delPref);
			String phonePref = customer.getIBankSecureDetails().getPhonePref();
			secureCodeInfo.setPhonePref(phonePref);
			//secureCodeInfo.setExempt(isCustomerSecCodeExempted(customer));
		}
		return secureCodeInfo;
	}
		
	public static String maskPhoneNumber(String phoneNumber)
	{
		String phoneNo = "";
		if (!StringMethods.isEmptyString(phoneNumber))
		{
			int len = phoneNumber.length();
			if (len > 4)
			{
				for (int i = 0; i < len - 4; i++)
				{
					phoneNo = phoneNo + "#";
				}
				phoneNo = phoneNo + phoneNumber.substring(len - 4);
			}
		}

		return phoneNo;

	}
	
	
	public String resolveOrigin(HttpServletRequest request)
	{
		OriginResolver originResolver = (OriginResolver) ServiceHelper.getBean(SPRING_ORIGIN_RESOLVER_BEAN);
		String tempOrigin = originResolver.resolveOrigin(request);
		Logger.info("Origin resolved to : " + tempOrigin, LogonHelper.class);
		return tempOrigin;
	}


}
