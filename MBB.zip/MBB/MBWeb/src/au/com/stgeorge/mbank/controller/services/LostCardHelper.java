package au.com.stgeorge.mbank.controller.services;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.List;
import au.com.stgeorge.mbank.session.MobileSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import au.com.stgeorge.ibank.servicestation.businessobject.valueobject.ServiceStationVO;
import au.com.stgeorge.framework.common.logging.Logger;
import au.com.stgeorge.framework.common.util.DateMethods;
import au.com.stgeorge.ibank.businessobject.BusinessException;
import au.com.stgeorge.ibank.businessobject.ResourceException;
import au.com.stgeorge.ibank.businessobject.StatisticsService;
import au.com.stgeorge.ibank.businessobject.model.globalwallet.cardlockunlock.CardNumber;
import au.com.stgeorge.ibank.businessobject.model.globalwallet.cardlockunlock.CardNumber.Status;
import au.com.stgeorge.ibank.businessobject.model.globalwallet.cardlockunlock.CardsManagementRequest;
import au.com.stgeorge.ibank.businessobject.model.globalwallet.cardlockunlock.UpdateCardStatusToMCReq;
import au.com.stgeorge.ibank.businessobject.model.globalwallet.cardlockunlock.CardsManagementRequest.IdScheme;
import au.com.stgeorge.ibank.common.cache.IBankParams;
import au.com.stgeorge.ibank.enumerated.CreditCardType;
import au.com.stgeorge.ibank.servicestation.util.ServicetationConstants;
import au.com.stgeorge.ibank.util.StringUtil;
import au.com.stgeorge.ibank.valueobject.Account;
import au.com.stgeorge.ibank.valueobject.Address;
import au.com.stgeorge.ibank.valueobject.CreditCardAccount;
import au.com.stgeorge.ibank.valueobject.DebitCardAccount;
import au.com.stgeorge.ibank.valueobject.GCCAccount;
import au.com.stgeorge.ibank.valueobject.LostCardsDetails;
import au.com.stgeorge.ibank.valueobject.Statistic;
import au.com.stgeorge.ibank.valueobject.database.CodesVO;
import au.com.stgeorge.ibank.valueobject.transfer.IBankCommonData;
import au.com.stgeorge.mbank.controller.customer.ContactDetailHelper;
import au.com.stgeorge.mbank.model.common.AddressResp;
import au.com.stgeorge.mbank.model.common.IMBResp;
import au.com.stgeorge.mbank.model.common.RespHeader;
import au.com.stgeorge.mbank.model.request.services.LostCardReportReq;
import au.com.stgeorge.mbank.model.response.customer.ContactDetailsResp;
import au.com.stgeorge.mbank.model.response.services.CardListResp;
import au.com.stgeorge.mbank.model.response.services.CardResp;
import au.com.stgeorge.mbank.model.response.services.LockUnlockCardListResp;
import au.com.stgeorge.mbank.model.response.services.LockUnlockCardResp;
import au.com.stgeorge.mbank.model.response.services.LostCardDetailResp;
import au.com.stgeorge.mbank.model.response.services.ReportLostCardResp;
import au.com.stgeorge.mbank.model.response.servicestation.ServiceStationResp;
import au.com.stgeorge.mbank.util.MBAppHelper;
import au.com.stgeorge.security.util.StringMethods;

/**
 * Report Lost or Stolen Card helper
 * 
 * @author C38854
 * 
 */
@Service
public class LostCardHelper {

	private static final String PCS = "PCS";
	
	

	public static final String STOLEN_CODE = "S";
	public static final String LOST_CODE = "L";
	
	//Newly added for Card on Hold
	public static final String TEMP_BLK_CODE = "T";
	public static final String RELEASE_CODE = "R";

	//20E1 - GDW for GCC Lock cards
	private static final String WWW = "WWW";
	
	//20E1 - Matrix Lost Cards
	private static final String BLOCK_CODE_O = "O";
		
	
	/**
	 * Return cards
	 * 
	 * @param header
	 * @param cards
	 * @return
	 */
	protected IMBResp populateCardListResponse(RespHeader header, List<Account> cards, IBankCommonData commonData) throws BusinessException {
		CardListResp response = new CardListResp(header);
		List<CardResp> cardsResp = new ArrayList<CardResp>();
		List<CardResp> tempDebitCardsResp = new ArrayList<CardResp>();
		

		int index = 0;
		for (Account card : cards) {
			CardResp cardResp = new CardResp();
			cardResp.setIndex(String.valueOf(index));
			cardResp.setIsProprietary(Boolean.TRUE);
			cardResp.setIsReplacementAllowed(true);
			if (card instanceof DebitCardAccount) {
				
				
				DebitCardAccount debitCard = (DebitCardAccount) card;
				
				if(IBankParams.isSwitchOn(IBankParams.CARD_NUM_MASK_SWITCH)) {
					cardResp.setAccountNumDisp(StringUtil.formatCardNumber(debitCard.getCardNumber()));
					}
				else {
					cardResp.setAccountNumDisp(new MBAppHelper().getFormattedAcctNumber(debitCard.getCardNumber(), debitCard.getAccountId()
							.getApplicationId(), debitCard.getAccountId().getBsb()));
					
				}
		     if(!"1".equalsIgnoreCase(debitCard.getIssueNumber())){
//		       labelValueBean.setLabel(labelValueBean.getLabel() + "(" + debitCard.getIssueNumber() + ")");
		       cardResp.setAccountNumDisp( cardResp.getAccountNumDisp() + "(" + debitCard.getIssueNumber() + ")");
		      }

				cardResp.setAccountName(debitCard.getCardName());
				cardResp.setDebitCard(true);
				cardResp.setIssueNumber(debitCard.getIssueNumber());
				
				CodesVO myCodesVO = IBankParams.getCodesData(IBankParams.DEFAULT_ORIGIN, "BINs", IBankParams.PROP_DEBIT_CARDS);
				if (myCodesVO != null) {
					String strBINList = myCodesVO.getMessage();
					List<String> proprietaryDebitCardsBins = IBankParams.getArrayListFromString(strBINList);
					for (String bin : proprietaryDebitCardsBins)
						if (((DebitCardAccount) card).getCardNumber().startsWith(bin)) {
							cardResp.setIsProprietary(Boolean.TRUE);
						}
				}

				if ( 	cardResp.getIsProprietary().booleanValue() )
				{
					myCodesVO =  null;
					myCodesVO = IBankParams.getCodesData(IBankParams.DEFAULT_ORIGIN, "BINs", "ConsumerVisaDebit");
					if (myCodesVO != null) {
						String strBINList = myCodesVO.getMessage();
						List<String> consumerVisaDebit = IBankParams.getArrayListFromString(strBINList);
						for (String bin : consumerVisaDebit)
							if (((DebitCardAccount) card).getCardNumber().startsWith(bin)) {
								cardResp.setIsProprietary(Boolean.FALSE);
							}
					}
				}
				
				if ( "R".equalsIgnoreCase(debitCard.getReferInd()) && ! card.isBlocked() )
				{
					cardResp.setIsProprietary(Boolean.TRUE);
				}
				

			} 
			else if(card instanceof GCCAccount) {
				cardResp.setAccountName(card.getName());				
				cardResp.setAccountNumDisp(new MBAppHelper().getFormattedAcctNumber(card.getAccountId().getAccountNumber(), card.getAccountId().getApplicationId(), card.getAccountId().getBsb()));
				
				//Retreive MasterCard customer care numbers
				response.setCustomerCareAus(getGCCLostStolenCustomerCare(IBankParams.GLOBAL_WALLET_MC_CUSTCARE_AUS, IBankParams.getBaseOriginCode(commonData.getOrigin())));
				response.setCustomerCareOverseas(getGCCLostStolenCustomerCare(IBankParams.GLOBAL_WALLET_MC_CUSTCARE_OVERSEAS, IBankParams.getBaseOriginCode(commonData.getOrigin())));
				
			}
			else {
				cardResp.setAccountNumDisp(new MBAppHelper().getFormattedAcctNumber(card.getAccountId().getAccountNumber(), card.getAccountId()
						.getApplicationId(), card.getAccountId().getBsb()));

				
				cardResp.setIsProprietary(Boolean.TRUE);
				boolean consumerCard = false;

				CodesVO myCodesVO = IBankParams.getCodesData(IBankParams.DEFAULT_ORIGIN, "BINs", IBankParams.CONSUMER_CREDIT_CARDS);
				if (myCodesVO != null) {
					String strBINList = myCodesVO.getMessage();
					List<String> proprietaryDebitCardsBins = IBankParams.getArrayListFromString(strBINList);
					for (String bin : proprietaryDebitCardsBins)
					{
						String crAccNum = card.getAccountId().getAccountKey();
						if (crAccNum.startsWith(bin)){
//							cardResp.setIsProprietary(Boolean.FALSE);
							consumerCard = true;
							break;
						}
					}
				}
				
				boolean isTempBlockAllowed = isTempBlockAllowed(card);
				if ( isTempBlockAllowed && consumerCard )
				{
					cardResp.setIsProprietary(Boolean.FALSE);
				}

				cardResp.setDebitCard(false);
				cardResp.setIssueNumber("");
				cardResp.setAccountName(card.getAlias());
				//Check and Set the o Block code
				CreditCardAccount craAccount = (CreditCardAccount) card;
				Boolean isReplacementAllowed = true;
				if(null!= craAccount.getBlockCode() && craAccount.getBlockCode() .equalsIgnoreCase(BLOCK_CODE_O)) {
					isReplacementAllowed = false;					
				}
				cardResp.setIsReplacementAllowed(isReplacementAllowed);
			}

			cardResp.setOnHold(  card.isBlocked() );
			if ( ! cardResp.getIsProprietary() )
			{
				cardResp.setBlocks(getBlocks( cardResp.isOnHold() ) );
			}
			
			if ( card.isBlocked() )
			{
				cardResp.setAccountNumDisp( cardResp.getAccountNumDisp() + " (Blocked)" );
				tempDebitCardsResp.add(cardResp);
			}
			else
			{
				cardsResp.add(cardResp);
			}
			index++;
		}

		if ( tempDebitCardsResp.size() > 0 )
		{
			cardsResp.addAll(tempDebitCardsResp );
		}
		
		
 		
		response.setCards(cardsResp);
		response.setCountries((ArrayList) contactDetailHelper.getCountryNameList());
		response.setReplacementCardFee("15");
		Logger.info("Response: " + response, this.getClass());
		return response;
	}

	/**
	 * Return card info
	 * 
	 * @param header
	 * @param address
	 * @param cardCategory
	 * @param replacementRequired
	 * @return
	 */
	protected IMBResp populateDetailsResponse(RespHeader header, Address address, String cardCategory, boolean replacementRequired, String email) {
		LostCardDetailResp response = new LostCardDetailResp(header);

		AddressResp addr = null;
		
		if ( address != null && address.getLine1() != null && ReportLostCardController.CATEGORY_CONSUMER_WOREL_CREDIT.equalsIgnoreCase(address.getLine1()) )
		{
			addr = new AddressResp();
			addr.setAddrType("LostStln");
			addr.setLine1(ReportLostCardController.CATEGORY_CONSUMER_WOREL_CREDIT);

//			addr.setLine1("Your new card will be sent to the statement address of the account owner");
		}
		else
		{
			if (address != null) {
				addr = new AddressResp();
				addr.setAddrType("LostStln");
				addr.setCountryName(address.getCountryName());
				addr.setLine1(address.getLine1());
				addr.setLine2(address.getLine2());
				addr.setLine3(address.getLine3());
				addr.setPostCode(address.getPostZipcode());
				addr.setState(address.getState());
				addr.setSuburb(address.getSuburb());
			}

		}
		response.setAddress(addr);
		response.setCardCategory(cardCategory);
		response.setReplacementCardAllowed(replacementRequired);
		response.setEmail(email);
		Logger.info("Response: " + response, this.getClass());
		return response;
	}

	/**
	 * Return report result response
	 * 
	 * @param header
	 * @param requestId
	 * @param replacementCardNumber
	 * @return
	 */
	protected IMBResp populateReportResponse(RespHeader header, Long requestId, String replacementCardNumber) 
	{
		return populateReportResponse(header,requestId,replacementCardNumber,null,null);
	}
	protected IMBResp populateReportResponse(RespHeader header, Long requestId, String replacementCardNumber, MobileSession mobileSession,ServiceStationVO serviceStationVO) {
		ReportLostCardResp response = new ReportLostCardResp(header);
		response.setReplCardNum(replacementCardNumber);
		if ( requestId != null )
			response.setReferenceNo(String.valueOf("M "+ requestId));
		
		if(null!=serviceStationVO)
		{
			if(null!=mobileSession)
			{
				mobileSession.setServiceStationMessage(serviceStationVO.getServiceStationMsg());
				populateServiceStationResponse(response,serviceStationVO);
			}
		}
		
		Logger.info("Response: " + response, this.getClass());
		return response;
	}

	/**
	 * Init report lost card request
	 * 
	 * @param address
	 * @param cardCategory
	 * @param gcis
	 * @param origin
	 * @param card
	 * @return
	 */
	protected LostCardsDetails initLostCardRequest(Address address, String cardCategory, String gcis, String origin, Account card) {
		LostCardsDetails lostCard = new LostCardsDetails();

		lostCard.setGcisNumber(gcis);
		lostCard.setOrigin(origin);
		lostCard.setAddress(addressToString(address));
		lostCard.setCardCategory(cardCategory);
		lostCard.setCardNumber(card.getAccountId().getAccountNumber());
		if (Account.CRA.equals(card.getAccountId().getApplicationId())) {
			lostCard.setCardType(Account.CRA);
			lostCard.setCardName(card.getAlias());
		} else {
			lostCard.setCardType(PCS);
			lostCard.setCardName(((DebitCardAccount) card).getCardName());
			lostCard.setIssueNum(((DebitCardAccount) card).getIssueNumber());
		}
		lostCard.setStatus(String.valueOf(LostCardsDetails.LOSTCARD_PENDING_TRANSACTION));
		return lostCard;
	}
	
	/**
	 * Init report lost card request
	 * 
	 * @param address
	 * @param cardCategory
	 * @param gcis
	 * @param origin
	 * @param card
	 * @return
	 */
	protected LostCardsDetails initLockUnlockCardRequest(String cardCategory, String gcis, String origin, Account card) {
		LostCardsDetails lostCard = new LostCardsDetails();

		lostCard.setGcisNumber(gcis);
		lostCard.setOrigin(origin);
		lostCard.setCardCategory(cardCategory);
		lostCard.setCardNumber(card.getAccountId().getAccountNumber());
		if (Account.CRA.equals(card.getAccountId().getApplicationId())) {
			lostCard.setCardType(Account.CRA);
			lostCard.setCardName(card.getAlias());
		} else {
			lostCard.setCardType(PCS);
			lostCard.setCardName(((DebitCardAccount) card).getCardName());
			lostCard.setIssueNum(((DebitCardAccount) card).getIssueNumber());
		}
		lostCard.setStatus(String.valueOf(LostCardsDetails.LOSTCARD_PENDING_TRANSACTION));
		return lostCard;
	}

	/**
	 * Complete request with user input
	 * 
	 * @param lostCard
	 * @param request
	 * @return
	 */

	
	protected LostCardsDetails populateLostCardRequest(LostCardsDetails lostCard, LostCardReportReq request) {
		lostCard.setCardSigned((request.getCardSigned()) ? "Y" : "N");
		lostCard.setContactNum(request.getContactNumber());
		lostCard.setCountry(request.getCountry());
		lostCard.setDescription(request.getAdditionalInfo());
		lostCard.setFraud((request.getFraudulent()) ? "Y" : "N");
		lostCard.setLostOverseas((request.getLostOverseas()) ? "Y" : "N");
		
		if ( request.getReportingDate() != null )
		{
			Date tempDate = DateMethods.getUtilDate(request.getReportingDate());
			if ( tempDate == null )
			{
				tempDate = DateMethods.getUtilDateTime(request.getReportingDate(), "yyyy-MM-dd" );
			}
			lostCard.setLostDate( tempDate );
		}
		else
			lostCard.setLostDate( new Date() );
		
		lostCard.setLostTime(request.getReportingTime());
		lostCard.setLostPlace(request.getLocation());
		lostCard.setReasonCode(request.getReportingOption());
		lostCard.setReplCardRqed((request.getCardOrdered()) ? "Y" : "N");
		lostCard.setEmailRequired(request.getEmailConfirmation());
		lostCard.setStatus(String.valueOf(LostCardsDetails.LOSTCARD_PENDING_TRANSACTION));
		
    if ("L".equalsIgnoreCase(request.getReportingOption())
		    &&  "Temporary".equalsIgnoreCase(request.getBlockType())) {   // BlockType
			lostCard.setBlockType(LostCardsDetails.BLOCKTYPE_TEMP);
			lostCard.setReasonCode(TEMP_BLK_CODE);
			lostCard.setLostOrStolen(LOST_CODE);
		}
		else if ("L".equalsIgnoreCase(request.getReportingOption())
		    && "Permanent".equalsIgnoreCase(request.getBlockType())) {
			lostCard.setBlockType(LostCardsDetails.BLOCKTYPE_PERM);
			lostCard.setReasonCode(LOST_CODE);
			lostCard.setLostOrStolen(LOST_CODE);
		}
		else if ("Reactivate".equalsIgnoreCase(request.getBlockType())) {
			lostCard.setBlockType(LostCardsDetails.BLOCKTYPE_RELEASE);
			lostCard.setReasonCode(RELEASE_CODE);
		}
		else if ("Cancel".equalsIgnoreCase(request.getBlockType())) {
			lostCard.setBlockType(LostCardsDetails.BLOCKTYPE_TEMP_TO_PERM);
			lostCard.setReasonCode(LOST_CODE);
		}  // proper cards Do not show the Temp / Perm clock.
		else if ("L".equalsIgnoreCase(request.getReportingOption()) ) {
			lostCard.setBlockType(LostCardsDetails.BLOCKTYPE_PERM);
			lostCard.setReasonCode(LOST_CODE);
		}
		else if ("S".equalsIgnoreCase(request.getReportingOption()) ) {
			lostCard.setBlockType(LostCardsDetails.BLOCKTYPE_PERM);
			lostCard.setReasonCode(STOLEN_CODE);
		}
		
		return lostCard;
	}
	
	protected void validateReportLostRequest(LostCardReportReq request) throws BusinessException {
		if (request.getLostOverseas().booleanValue() && (request.getCountry() == null || "".equals(request.getCountry().trim())))
			throw new BusinessException(BusinessException.LOST_CARD_COUNTRY_INVALID);
	}

	private String addressToString(Address address) {
		StringBuffer sbuff = new StringBuffer();
		if ( address != null )
		{
				sbuff.append((address.getLine1() == null) ? "" : address.getLine1().trim());
				sbuff.append(" ");
				sbuff.append((address.getLine2() == null) ? "" : address.getLine2().trim());
				sbuff.append(" ");
				sbuff.append((address.getLine3() == null) ? "" : address.getLine3().trim());
				sbuff.append(" ");
				sbuff.append((address.getSuburb() == null) ? "" : address.getSuburb().trim());
				sbuff.append(" ");
				sbuff.append((address.getState() == null) ? "" : address.getState().trim());
				sbuff.append(" ");
				sbuff.append((address.getPostZipcode() == null) ? "" : address.getPostZipcode().trim());
				sbuff.append(" ");
				sbuff.append((address.getCountry() == null) ? "" : address.getCountryName().trim());
				return sbuff.toString();
		}
		else
		{
			return " ";
		}
	}

	private ArrayList<String> getBlocks( boolean isOnHold )
	{
		ArrayList<String> blocks = new ArrayList<String> ();
		if ( isOnHold )
		{
			blocks.add("R");
			blocks.add("C");
		}
		else
		{
			blocks.add("T");
			blocks.add("P");
		}
		return blocks;
	}
	
	@Autowired
	private ContactDetailHelper contactDetailHelper;
	
	
	private boolean isTempBlockAllowed(Account account)
	{
		CodesVO tempCodesVO = IBankParams.getCodesData(IBankParams.DEFAULT_ORIGIN, "LostCardReport", IBankParams.LOST_ALLOWED_TEMP_BLOCKS);
		StringBuffer tempBlockAllowed =  new StringBuffer(",");
		tempBlockAllowed.append(tempCodesVO.getMessage());
		tempBlockAllowed.append(",");
		
		CreditCardAccount craAccount = (CreditCardAccount) account;
//		String craBlockCode = craAccount.getBlockCode();

		if (  craAccount.isBlocked())
		{
			return true;
		}

		if ( StringMethods.isEmptyString(craAccount.getBlockCode()))
		{
			 return true;
		}
		StringBuffer craBlockCode  =  new StringBuffer(",");
		craBlockCode.append(craAccount.getBlockCode());
		craBlockCode.append(",");
		if ( tempBlockAllowed.toString().indexOf(craBlockCode.toString()) >= 0 )
		{
			 return true;
		}
		return false;		
	}
	
	
	/**
	 * Return cards
	 * 
	 * @param header
	 * @param cards
	 * @return
	 */
	protected IMBResp populateLockUnlockCardListResponse(RespHeader header, List<Account> cards) throws BusinessException {
		LockUnlockCardListResp response = new LockUnlockCardListResp(header);
		List<LockUnlockCardResp> cardsResp = new ArrayList<LockUnlockCardResp>();
		List<LockUnlockCardResp> tempDebitCardsResp = new ArrayList<LockUnlockCardResp>();
		

		int index = 0;
		for (Account card : cards) {
			LockUnlockCardResp cardResp = new LockUnlockCardResp();
			cardResp.setIndex(String.valueOf(index));
			cardResp.setIsProprietary(Boolean.TRUE);
			if (card instanceof DebitCardAccount) {
				DebitCardAccount debitCard = (DebitCardAccount) card;
				cardResp.setAccountNumDisp(new MBAppHelper().getFormattedAcctNumber(debitCard.getCardNumber(), debitCard.getAccountId()
						.getApplicationId(), debitCard.getAccountId().getBsb()));
				
				CodesVO myCodesVO = IBankParams.getCodesData(IBankParams.DEFAULT_ORIGIN, "BINs", IBankParams.PROP_DEBIT_CARDS);
				if (myCodesVO != null) {
					String strBINList = myCodesVO.getMessage();
					List<String> proprietaryDebitCardsBins = IBankParams.getArrayListFromString(strBINList);
					for (String bin : proprietaryDebitCardsBins)
						if (((DebitCardAccount) card).getCardNumber().startsWith(bin)) {
							cardResp.setIsProprietary(Boolean.TRUE);
						}
				}

				if ( 	cardResp.getIsProprietary().booleanValue() )
				{
					myCodesVO =  null;
					myCodesVO = IBankParams.getCodesData(IBankParams.DEFAULT_ORIGIN, "BINs", "ConsumerVisaDebit");
					if (myCodesVO != null) {
						String strBINList = myCodesVO.getMessage();
						List<String> consumerVisaDebit = IBankParams.getArrayListFromString(strBINList);
						for (String bin : consumerVisaDebit)
							if (((DebitCardAccount) card).getCardNumber().startsWith(bin)) {
								cardResp.setIsProprietary(Boolean.FALSE);
							}
					}
				}
				
				if ( "R".equalsIgnoreCase(debitCard.getReferInd()) && ! card.isBlocked() )
				{
					cardResp.setIsProprietary(Boolean.TRUE);
				}
				
				myCodesVO = IBankParams.getCodesData(IBankParams.DEFAULT_ORIGIN,
						"BINs", IBankParams.VISA_DEBIT_CARDS);
		 		
		 		if (myCodesVO != null) {
		 			String strBINList = myCodesVO.getMessage();
				
		 		
		 		List<String> debitCardBins = IBankParams.getArrayListFromString(strBINList);
		 		
		 		for (String bin : debitCardBins)
					if (((DebitCardAccount) card).getCardNumber().startsWith(bin)) {
						cardResp.setMasterCard(Boolean.FALSE);
					}
		 		}
				//Always debit cards are Visa Debit only.
				cardResp.setProductName("Visa Debit");

			}
			
			else if (card instanceof GCCAccount) {
			
				cardResp.setAccountNumDisp(new MBAppHelper().getFormattedAcctNumber(card.getAccountId().getAccountNumber(), card.getAccountId().getApplicationId(), card.getAccountId().getBsb()));
				cardResp.setIsProprietary(Boolean.FALSE);
				cardResp.setMasterCard(Boolean.TRUE);
				cardResp.setProductName(card.getAccountId().getProductName());
				cardResp.setGlobalWalletCard(Boolean.TRUE);
			}
			
			else {
				cardResp.setAccountNumDisp(new MBAppHelper().getFormattedAcctNumber(card.getAccountId().getAccountNumber(), card.getAccountId()
						.getApplicationId(), card.getAccountId().getBsb()));

				
				cardResp.setIsProprietary(Boolean.TRUE);
				boolean consumerCard = false;

				CodesVO myCodesVO = IBankParams.getCodesData(IBankParams.DEFAULT_ORIGIN, "BINs", IBankParams.CONSUMER_CREDIT_CARDS);
				if (myCodesVO != null) {
					String strBINList = myCodesVO.getMessage();
					List<String> proprietaryDebitCardsBins = IBankParams.getArrayListFromString(strBINList);
					for (String bin : proprietaryDebitCardsBins)
					{
						String crAccNum = card.getAccountId().getAccountKey();
						if (crAccNum.startsWith(bin)){
//							cardResp.setIsProprietary(Boolean.FALSE);
							consumerCard = true;
							break;
						}
					}
				}
				
				boolean isTempBlockAllowed = isTempBlockAllowed(card);
				if ( isTempBlockAllowed && consumerCard )
				{
					cardResp.setIsProprietary(Boolean.FALSE);
				}

				//cardResp.setAccountName(card.getAlias());
				
				CreditCardType ccCardType  = CreditCardType.fromString(CreditCardType.fromLogoCodeStringVP(card.getAccountId().getGroupCode()).stringValue());
				boolean isVisa = false;
				
				if ( ccCardType.getName().equals("VISA") ) { 
					isVisa = true;
				}
				else if ( ccCardType.getName().equals("MasterCard")) {
					isVisa = false;
				}
				cardResp.setMasterCard(!isVisa);
				cardResp.setProductName(card.getAccountId().getProductName());
			}
			cardResp.setLocked(  card.isBlocked() );
			
			if ( card.isBlocked() )
			{
				if ( ! cardResp.getIsProprietary() )
				{
					cardResp.setIsProprietary(null);
					tempDebitCardsResp.add(cardResp);
				}
			}
			else
			{
				if ( ! cardResp.getIsProprietary() )
				{
					cardResp.setIsProprietary(null);
					cardsResp.add(cardResp);
				}
			}
			index++;
		}

		if ( tempDebitCardsResp.size() > 0 )
		{
			cardsResp.addAll(tempDebitCardsResp );
		}
		
		
		
		response.setCards(cardsResp);
		Logger.info("Response: " + response, this.getClass());
		return response;
	}
	
	public long getInsertionPointCode(String insertionPointString){
		List<CodesVO> CodesVOList = (List<CodesVO>) IBankParams.getCodesDataList(IBankParams.DEFAULT_ORIGIN, ServicetationConstants.CD_CATEGORY_SERVICETATION_INSERTION_PT);
		long insertionPointValue = 0;
		for(CodesVO codesVO : CodesVOList){
			if(codesVO.getMessage().trim().equalsIgnoreCase(insertionPointString)){
				if(StringMethods.isValidString(codesVO.getCode())){
					insertionPointValue = Long.parseLong(codesVO.getCode());
					break;
				}
			}
		}
		if(insertionPointValue == 0){
			Logger.warn("NO match found in RELEASECODES table for the insertion point "+insertionPointString, this.getClass());
		}
		return insertionPointValue;
	}
	
	protected ReportLostCardResp populateServiceStationResponse(ReportLostCardResp resp,ServiceStationVO serviceStationVO) 
	{
		ServiceStationResp ssResponse = null;
		if(null!=serviceStationVO)
		{
			ServiceStationResp serviceResponse = new ServiceStationResp();
			if(null!=serviceStationVO.getContent())
			{
				serviceResponse.setContent(serviceStationVO.getContent());
			}			
			if(null!=serviceStationVO.getServiceStationMsg())
			{
				serviceResponse.setInsertionPointValue(new Long(serviceStationVO.getServiceStationMsg().getInsertionPointValue()).toString());	
			}
			if(null!=serviceStationVO.getSubject())
			{
				serviceResponse.setSubject(serviceStationVO.getSubject());
			}
			if(null!=serviceStationVO.getServiceStationMsg().getFunctionLink())
			{
				serviceResponse.setFunctionLink(serviceStationVO.getServiceStationMsg().getFunctionLink());
			}
			if(null!=serviceStationVO.getServiceStationMsg().getMessageAction())
			{
				serviceResponse.setMessageAction(serviceStationVO.getServiceStationMsg().getMessageAction());
			}
			if(null!=serviceStationVO.getServiceStationMsg())
			{
			    serviceResponse.setMsgID(new Long(serviceStationVO.getServiceStationMsg().getMsgID()).toString());
			}
			
			resp.setServiceStation(serviceResponse);			
		}		
	  else
		{
			resp.setServiceStation(ssResponse);	
		}		
		return resp;
	}
	
	/**
	 * Method to return customer care Australia and Overseas number for GCC lost/stolen card.
	 * 
	 * @param code
	 * @param origin
	 * @return String - phone number
	 */
	private String getGCCLostStolenCustomerCare(String code, String origin) {
		
		CodesVO codes = IBankParams.getCodesData(origin, IBankParams.CATEGORY_GLOBAL_WALLET, code);
		
		if(null != codes)
			return codes.getMessage();
				
		return null;
	}
	
	/**
	 * This method returns the request for lock or unlock of GCC card. 
	 * 
	 * @param cardNum
	 * @param custId
	 * @param origin
	 * @return UpdateCardStatusToMCReq - request to lock or unlock GCC card
	 */
	public UpdateCardStatusToMCReq getLockUnlockGCCCardReq(String cardNum, String custId, String origin, boolean lock) {
		
		UpdateCardStatusToMCReq req = new UpdateCardStatusToMCReq();
				
		CardsManagementRequest customerId = new CardsManagementRequest();
		customerId.setId(custId);
		customerId.setIdScheme(IdScheme.GCISKey);
		
		List<CardNumber> cardNumbers = new ArrayList<>();
		
		CardNumber cardNumber = new CardNumber();
		cardNumber.setCardNumber(cardNum);
		
		if(lock)
			cardNumber.setStatus(Status.lock);
		else
			cardNumber.setStatus(Status.unlock);
		
		cardNumbers.add(cardNumber);
		
		String orgId = IBankParams.getBaseOriginCode(origin);
		if(orgId.equalsIgnoreCase("STG")){
			orgId = "SGB";
		}
		
		req.setBrand(orgId);
		req.setCardNumbers(cardNumbers);
		req.setCustomerId(customerId);
		
		return req;
	}
	
	/**
	 * This method is to log GDW entry for GCC lock/unlock cards
	 * @param cardNum - GCC card number
	 * @param commonData
	 * @param action - LOCK/UNLOCK
	 * @throws BusinessException
	 * @throws ResourceException
	 */
 	public void logStatisticGCCCardLockUnlock(String cardNum, IBankCommonData commonData, String action) throws BusinessException, ResourceException
 	{
	  	try
	 	{
	 		Statistic s = new Statistic();
	 		s.setAction(action);
	 		s.setGcisNumber(commonData.getCustomer().getGcis());
	 		s.setAccountNumberFrom(cardNum);
	 		s.setAccountTypeFrom(WWW);
	 		s.setApplIdFrom(Account.GCC);
		 			
	 		//Do not set -
	 		// description
	 		// Account number to
	 			 		
	 		s.setOriginBank(commonData.getOrigin());
	 		s.setGDWOriginBank(commonData.getGdwOrigin());
	 		s.setIpAddress(commonData.getIpAddress());
	 		s.setSessionId(commonData.getSessionId());
	 		StatisticsService.logStatistic(s);
	 	} catch (Exception e) {
	 		Logger.warn("logStatisticGCCCardLockUnlock : Failed to create a statistic entry for Lock/Unlock GCC card. ", this.getClass());
	  	}   
 	}
 	
 	/**
 	 * This method is created to populate LostCardsDetails for World Wide Wallet cards for lock/unlock requests.<br>
 	 * SBGEXP-7921<br>
 	 * 
 	 * @param address
 	 * @param cardCategory
 	 * @param gcis
 	 * @param origin
 	 * @param card
 	 * @return LostCardsDetails
 	 */
 	public LostCardsDetails gccLostCardRequest(String gcis, String origin, String cardNumber, boolean isLock) {
		LostCardsDetails lostCard = new LostCardsDetails();

		lostCard.setGcisNumber(gcis);
		lostCard.setOrigin(origin);
		lostCard.setCardCategory("Worldwide Wallet Card");
		lostCard.setCardNumber(cardNumber);
	
		lostCard.setCardType(Account.GWC);
		lostCard.setCardName("Worldwide Wallet Card");
		
		lostCard.setEmailRequired(true);
		lostCard.setGWC(true);
		
		if(isLock) {
			lostCard.setReasonCode(LostCardsDetails.LOCK_CODE);
			lostCard.setStatus(String.valueOf(LostCardsDetails.LOSTCARD_SUCCESSFUL_TRANSACTION));
			lostCard.setBlockType(LostCardsDetails.BLOCKTYPE_TEMP);			
		} else {
			lostCard.setReasonCode(LostCardsDetails.UNLOCK_CODE);
			lostCard.setStatus(String.valueOf(LostCardsDetails.LOSTCARD_TEMP_TO_PERMANENT_BLOCK));
			lostCard.setBlockType(LostCardsDetails.BLOCKTYPE_RELEASE);
		}
		
		
		
		return lostCard;
	}

}

