package au.com.stgeorge.mbank.model.request.payments;

import java.math.BigDecimal;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

import org.apache.commons.lang.builder.ReflectionToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;
import org.hibernate.validator.constraints.Length;
import org.hibernate.validator.constraints.NotEmpty;

import au.com.stgeorge.ibank.businessobject.BusinessException;
import au.com.stgeorge.mbank.model.common.IMBReq;
import au.com.stgeorge.mbank.model.common.ReqHeader;

/**
 * TT Transfer request
 * 
 * @author C38854
 *
 */
public class TTTransferReq implements IMBReq {

	private static final String AMT_PATTERN = "^[0-9]*\\.{0,1}(\\d{1,2}){0,1}$";
	private static final String BLOCK_CHARS_PATTERN = "^[0-9A-Za-z',. &/\\-]*$";
	private static final String MOBILE_NUMBER_PATTERN = "^[0-9 ()+]*$";
	protected static final String MASK_NUMBERS = "^[0-9]+$";
	
	private static final long serialVersionUID = 1470378084813803939L;
	
	// @Valid TODO
	private ReqHeader header;
	
	@NotNull(message = "Please select a beneficiary")
	private Long toBeneficiaryId;
	
	@NotEmpty(message = "{errors.amt.required}")
	@Length(max = 14, message = "{errors.amt.maxlength}")
	@Pattern(regexp = AMT_PATTERN, message = "{errors.amt.blockchar}")
	private String audAmt;
	
	@NotEmpty(message = "{errors.amt.required}")
	@Length(max = 14, message = "{errors.amt.maxlength}")
	@Pattern(regexp = AMT_PATTERN, message = "{errors.amt.blockchar}")
	private String foreignAmt;
	
	@NotEmpty(message = "{errors.amt.required}")
	@Length(max = 14, message = "{errors.amt.maxlength}")
	@Pattern(regexp = AMT_PATTERN, message = "{errors.amt.blockchar}")
	private String totalAmt;
	
	@NotEmpty(message = "" + BusinessException.TT_CURRENCY_REQUIRED)
	private String currency;
	
	private BigDecimal exchangeRate;
	
	private Boolean isAUDBase;

	@NotNull(message = "" + BusinessException.ACCOUNT_NO_FROM_ACCOUNT)
	private Integer fromAccountIndex;

	@Pattern(regexp = BLOCK_CHARS_PATTERN, message = "{errors.desc.blockchar}")
	@Length(max = 70, message = "{errors.desc.maxlength}")
	private String desc;

	@NotEmpty(message = "{errors.mobileNumber.required}")
	@Length(max = 20, message = "" + BusinessException.TT_INVALID_CONTACT_NO)
	@Pattern(regexp = MOBILE_NUMBER_PATTERN, message = "" + BusinessException.TT_INVALID_CONTACT_NO)
	private String contactNum;
	
	private Integer dupCount;

	private Boolean overrideDup;
	
	private String purposeCode;
	
	private String devicePrint;

	public Integer getFromAccountIndex() {
		return fromAccountIndex;
	}

	public String getDesc() {
		return desc;
	}

	public Integer getDupCount() {
		return dupCount;
	}

	public Boolean getOverrideDup() {
		return overrideDup;
	}

	public String getAudAmt() {
		return audAmt;
	}

	public String getForeignAmt() {
		return foreignAmt;
	}

	public String getTotalAmt() {
		return totalAmt;
	}

	public String getCurrency() {
		return currency;
	}

	public BigDecimal getExchangeRate() {
		return exchangeRate;
	}

	public Boolean getIsAUDBase() {
		return isAUDBase;
	}

	public Long getToBeneficiaryId() {
		return toBeneficiaryId;
	}
	
	public ReqHeader getHeader() {
		return header;
	}

	public String getContactNum() {
		return contactNum;
	}

	public String getPurposeCode() {
		return purposeCode;
	}

	public void setHeader(ReqHeader header) {
		this.header = header;
	}

	@Override
	public String toString() {
		return ReflectionToStringBuilder.toString(this, ToStringStyle.MULTI_LINE_STYLE);
	}

	public String getDevicePrint() {
		return devicePrint;
	}

	public void setDevicePrint(String devicePrint) {
		this.devicePrint = devicePrint;
	}

}
