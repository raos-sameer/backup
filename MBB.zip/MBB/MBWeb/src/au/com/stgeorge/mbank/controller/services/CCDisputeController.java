package au.com.stgeorge.mbank.controller.services;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.commons.lang.builder.ReflectionToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import au.com.stgeorge.digitalsec.logger.DigitalSecLogger;
import au.com.stgeorge.digitalsec.logger.DigitalSecLogggerVO;
import au.com.stgeorge.framework.common.logging.Logger;
import au.com.stgeorge.ibank.businessobject.AccountFilter;
import au.com.stgeorge.ibank.businessobject.BusinessException;
import au.com.stgeorge.ibank.businessobject.CreditCardChargeBackCustomerFacingService;
import au.com.stgeorge.ibank.businessobject.HeartBeat;
import au.com.stgeorge.ibank.businessobject.ResourceException;
import au.com.stgeorge.ibank.businessobject.StatisticsService;
import au.com.stgeorge.ibank.businessobject.impl.CardDisputeServiceImpl;
import au.com.stgeorge.ibank.cardispute.vo.OneClickCardDispute;
import au.com.stgeorge.ibank.common.cache.IBankParams;
import au.com.stgeorge.ibank.service.businessobject.PhoneService;
import au.com.stgeorge.ibank.service.valueobject.PhoneToken;
import au.com.stgeorge.ibank.servicestation.businessobject.ServiceStationImpl;
import au.com.stgeorge.ibank.valueobject.Account;
import au.com.stgeorge.ibank.valueobject.AccountPayment;
import au.com.stgeorge.ibank.valueobject.CreditCardAccount;
import au.com.stgeorge.ibank.valueobject.CreditCardChargeBackRequestVO;
import au.com.stgeorge.ibank.valueobject.CreditCardChargeBackTransactionVO;
import au.com.stgeorge.ibank.valueobject.Customer;
import au.com.stgeorge.ibank.valueobject.Statistic;
import au.com.stgeorge.ibank.valueobject.TransactionInfo;
import au.com.stgeorge.ibank.valueobject.UserAgentVO;
import au.com.stgeorge.ibank.valueobject.database.CodesVO;
import au.com.stgeorge.ibank.valueobject.transfer.IBankCommonData;
import au.com.stgeorge.mbank.controller.IMBController;
import au.com.stgeorge.mbank.model.common.IMBReq;
import au.com.stgeorge.mbank.model.common.IMBResp;
import au.com.stgeorge.mbank.model.common.ReqHeader;
import au.com.stgeorge.mbank.model.common.RespHeader;
import au.com.stgeorge.mbank.model.request.EmptyReq;
import au.com.stgeorge.mbank.model.request.customer.OneClickCardDiputeReq;
import au.com.stgeorge.mbank.model.request.services.CCDisputeReq;
import au.com.stgeorge.mbank.model.request.services.PhoneTokenReq;
import au.com.stgeorge.mbank.model.response.ErrorResp;
import au.com.stgeorge.mbank.model.response.customer.CardDisputeResp;
import au.com.stgeorge.mbank.session.MobileSession;
import au.com.stgeorge.mbank.session.MobileSessionImpl;
import au.com.stgeorge.mbank.useragent.UserAgentParser;
import au.com.stgeorge.mbank.util.MBAppHelper;
import au.com.stgeorge.mbank.util.MBAppUtils;
import au.com.stgeorge.mbank.util.MBAppValidator;
import au.com.stgeorge.mbank.util.ServiceConstants;
import au.com.stgeorge.perflogger.PerformanceLogger;

import static au.com.stgeorge.ibank.businessobject.impl.CardDisputeServiceImpl.ONE_CLICK_MOBILE_CHANNEL;
import static au.com.stgeorge.ibank.businessobject.impl.CardDisputeServiceImpl.ONE_CLICK_TABLET_CHANNEL;
import static au.com.stgeorge.ibank.businessobject.impl.CardDisputeServiceImpl.ONE_CLICK_DESKTOP_CHANNEL;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * Dispute credit card transaction service
 * 
 * @author C38854
 * 
 */
@Controller
@RequestMapping("/cards")
public class CCDisputeController implements IMBController {

  public static final String CREDIT_CARD_CONFIG = "CreditCard";
  public static final String CARD_DISPUTES_CATEGORY="CardDisputes";
  
  private static final String HELP_DESK_NUM = "HelpDeskPhoneNumber";
  private static final String CALL_INTENT_AU = "AU_DISPUTE_CC_TRAN";
  private static final String CALL_INTENT_OS = "OS_DISPUTE_CC_TRAN";
  private static final String ANDROID = "Android";
  private static final String ANDROID_DEVICE = "android";
  

  private static final String DEVICE_TYPE_MOBILE="MOBILE";

  private static final String DEVICE_TYPE_TABLET="TABLET";
  
  
  @Autowired
  private CreditCardChargeBackCustomerFacingService creditcardChargeback;

  @Autowired
  private CCDisputeHelper helper;


  @Autowired
  private MBAppValidator mbAppValidator;

  @Autowired
  private MBAppHelper mbAppHelper;

  @Autowired
  private DigitalSecLogger digitalSecLogger;

  @Autowired
  private UserAgentParser userAgentParser;

  @Autowired
  private GetCashHelper getCashHelper;

  @Autowired
  private PhoneService phoneService;

  @Autowired
  private CardDisputeServiceImpl cardDisputeService;
  
  private static String TARGET_URL = "cardDisputeOneClickUrl";

  /**
   * Get CC Dispute details service operation
   * 
   * @param httpRequest
   * @param request
   * @return
   */
  @RequestMapping(method = RequestMethod.POST, headers = "content-type=application/json",
      produces = MediaType.APPLICATION_JSON_VALUE, value = "disputedetail")
  @ResponseBody
  public IMBResp getDetails(HttpServletRequest httpRequest, @RequestBody final EmptyReq request) {
    Logger.debug("CCDisputeController - getDetails(). Request: " + request, this.getClass());
    String logName = startPerformanceLog(httpRequest);
    MobileSession mobileSession = new MobileSessionImpl();
    IMBResp disputeDetails = null;List<Integer> indexes = null;
    try {
      mobileSession.getSessionContext(httpRequest);
      validateRequestHeader(request.getHeader(), httpRequest);
      ErrorResp errorResponse = validate(request, httpRequest);
      if (errorResponse.hasErrors())
        return errorResponse;

      if (HeartBeat.isApplicationAvailable(HeartBeat.VISION_PLUS)) {

         indexes = getDisputeCardsList(mobileSession);
        
      }
      else{
    	  indexes = new ArrayList();
    	  Logger.info("CCDisputeController::getDetails() No Credit Cards Populated as Vision Plus is Unavailable", this.getClass());
    	  
      }
      
        // if (indexes.size() == 0) throw new
        // BusinessException(BusinessException.CC_DISPUTE_NO_CARDS);

   //     String helpDeskPhoneNumber =            IBankParams.getCodesData(mobileSession.getOrigin(), CREDIT_CARD_CONFIG, HELP_DESK_NUM).getMessage();
        // fetching credit card amount threshold from codes table
      
      CodesVO codesVO=null;
  /*if(IBankParams.isCardDisputeSwitchON(mobileSession.getOrigin())){
       codesVO = IBankParams.getCodesData(IBankParams.getBaseOriginCode( mobileSession.getOrigin()), CARD_DISPUTES_CATEGORY, HELP_DESK_NUM); 
  }
  else{
	  codesVO = IBankParams.getCodesData(IBankParams.getBaseOriginCode( mobileSession.getOrigin()), CREDIT_CARD_CONFIG, HELP_DESK_NUM);
  }*/
      codesVO = IBankParams.getCodesData(IBankParams.getBaseOriginCode( mobileSession.getOrigin()), CARD_DISPUTES_CATEGORY, HELP_DESK_NUM); 
      String helpDeskPhoneNumber = codesVO.getMessage();
      
      String connectThreshold =
            IBankParams.getCodesData(mobileSession.getOrigin(), IBankParams.VISA_COMPLIANCE_CONFIG,
                IBankParams.CONNECT_THRESHOLD).getMessage();
        List<String> disputeReasonsList =
            (List<String>) IBankParams.getArrayListFromString(IBankParams.getCodesData(
                mobileSession.getOrigin(), IBankParams.CC_DISPUTE_REASON_MB,
                IBankParams.CREDIT_CARD_CONFIG).getMessage());
        if (IBankParams.isCardDisputeSwitchON(mobileSession.getOrigin())) {
        	
        	
        	
          disputeDetails =
              helper.populateCCDisputeDetailsResponse(
                  cardDisputeService,
                  populateResponseHeader(ServiceConstants.CC_TNX_DISPUTE_DETAILS_SERVICE,
                      mobileSession), helpDeskPhoneNumber, disputeReasonsList
                      .toArray(new String[disputeReasonsList.size()]), indexes
                      .toArray(new Integer[indexes.size()]), Integer.parseInt(connectThreshold),
                  mobileSession.getCustomer());
          return disputeDetails;
        } else {
        	 if (HeartBeat.isApplicationAvailable(HeartBeat.VISION_PLUS)) {
        	
        	disputeDetails =
              helper.populateCCDisputeDetailsResponse(
                  populateResponseHeader(ServiceConstants.CC_TNX_DISPUTE_DETAILS_SERVICE,
                      mobileSession), helpDeskPhoneNumber, disputeReasonsList
                      .toArray(new String[disputeReasonsList.size()]), indexes
                      .toArray(new Integer[indexes.size()]), Integer.parseInt(connectThreshold),
                  mobileSession.getCustomer());
          return disputeDetails;
        }
          else {
              return MBAppUtils.createErrorResp(mobileSession.getOrigin(),
                  BusinessException.SYSTEM_UNAVILABLE, ServiceConstants.CC_TNX_DISPUTE_DETAILS_SERVICE,
                  httpRequest);
            }
          
        }


      
    } catch (BusinessException e) {
      Logger.info("BusinessException in CCDisputeController - getDetails() - [key: "
          + e.getKey()
          + "] : GCIS: ["
          + ((mobileSession != null && mobileSession.getCustomer() != null) ? mobileSession
              .getCustomer().getGcis() : "") + "] :", e, this.getClass());
      return MBAppUtils.createErrorResp(mobileSession.getOrigin(), e,
          ServiceConstants.CC_TNX_DISPUTE_DETAILS_SERVICE, httpRequest);
    } catch (ResourceException e) {
      Logger.error("ResourceException in CCDisputeController - getDetails() - [key: "
          + e.getKey()
          + "] : GCIS: ["
          + ((mobileSession != null && mobileSession.getCustomer() != null) ? mobileSession
              .getCustomer().getGcis() : "") + "] :", e, this.getClass());
      return MBAppUtils.createErrorResp(mobileSession.getOrigin(), e,
          ServiceConstants.CC_TNX_DISPUTE_DETAILS_SERVICE, httpRequest);
    } catch (Exception e) {
      Logger.error("Exception CCDisputeController - getDetails() : GCIS: ["
          + ((mobileSession != null && mobileSession.getCustomer() != null) ? mobileSession
              .getCustomer().getGcis() : "") + "] :", e, this.getClass());
      return MBAppUtils.createErrorResp(mobileSession.getOrigin(), ResourceException.GENERIC_ERROR,
          ServiceConstants.CC_TNX_DISPUTE_DETAILS_SERVICE, httpRequest);
    } finally {
      endPerformanceLog(logName);
    }
  }

  private List<Integer> getDisputeCardsList(MobileSession mobileSession) {
    List<Integer> indexes = new ArrayList<Integer>();

    CodesVO codeVo =
        IBankParams.getCodesData(IBankParams.DEFAULT_ORIGIN, IBankParams.RELATIONSHIP_CODE,
            IBankParams.ACCTOWNER);
    if (codeVo != null) {
      String allowedRel = codeVo.getMessage();
      int i = 0;
      Customer customer = mobileSession.getCustomer();
      boolean isMadisonLCMSwitchOn = AccountFilter.isMadisonLCMSwitchOn(customer.getGcis());
      
      for (Account account : mobileSession.getCustomer().getAccounts()) {
       
    	  
		if (Account.CRA.equals(account.getAccountId().getApplicationId())
            && allowedRel.indexOf(account.getAccountId().getRelationshipCode()) >= 0) {
    		  CreditCardAccount ccaccount = (CreditCardAccount)account;
    	  	
        	   if(isMadisonLCMSwitchOn){
        		   if(!(("Q").equalsIgnoreCase(ccaccount.getAccountId().getAcctStatus()) && ("J").equalsIgnoreCase(ccaccount.getBlockCode()))){
        			   indexes.add(i);
        		   }
        	   }
        	   else {
        		   indexes.add(i);
        	   }
        	
   		  	
		}
		i++;
      }
    }
    return indexes;
  }

  /**
   * Dispute credit card transaction service operation
   * 
   * @param httpRequest
   * @param request
   * @return
   */
  @RequestMapping(method = RequestMethod.POST, headers = "content-type=application/json",
      produces = MediaType.APPLICATION_JSON_VALUE, value = "disputetrans")
  @ResponseBody
  public IMBResp disputeCCTransaction(HttpServletRequest httpRequest,
      @RequestBody final CCDisputeReq request) {
    Logger.debug("CCDisputeController - disputeCCTransaction(). Request: " + request,
        this.getClass());
    String logName = startPerformanceLog(httpRequest);
    MobileSession mobileSession = new MobileSessionImpl();
    DigitalSecLogggerVO digitalSecLoggerVO = new DigitalSecLogggerVO();
    digitalSecLoggerVO.setTranName(DigitalSecLogger.CC_DISPUTE);
    digitalSecLoggerVO.setStatus(DigitalSecLogger.SUCCESS);

    try {
      mobileSession.getSessionContext(httpRequest);
      IBankCommonData commonData =
          new MBAppHelper().populateIBankCommonData(mobileSession, httpRequest);
      digitalSecLoggerVO.setCommonLogData(mbAppHelper.getCommonLogData(commonData));
      digitalSecLoggerVO.setUserAgent(commonData.getUserAgent());

      validateRequestHeader(request.getHeader(), httpRequest);
      ErrorResp errorResponse = validate(request, httpRequest);
      if (errorResponse.hasErrors())
        return errorResponse;
      // server side cc dispute threshold validation in case of user changing the value in developer
      // tool.
      if (isInValidDispute(request, mobileSession, commonData)) {
        return MBAppUtils.createErrorResp(mobileSession.getOrigin(),
            BusinessException.CC_DISPUTE_THRESHOLD_AMOUNT_CHECK,
            "This duspute should not be made via online.", ServiceConstants.CC_TNX_DISPUTE_SERVICE,
            httpRequest);
      }

      if (!HeartBeat.isApplicationAvailable(HeartBeat.VISION_PLUS))
        return MBAppUtils.createErrorResp(mobileSession.getOrigin(),
            BusinessException.SYSTEM_UNAVILABLE, ServiceConstants.CC_TNX_DISPUTE_SERVICE,
            httpRequest);

      Account selectedAccount =
          mobileSession.getCustomer().getAccounts()
              .get(Integer.parseInt(request.getAccountIndex()));

      CreditCardChargeBackRequestVO createdVo =
          helper.createCreditCardChargeBackRequestVo(request, commonData,
              mobileSession.getCustomer(), selectedAccount, mobileSession,
              commonData.getIpAddress());
      digitalSecLoggerVO.setValues(createdVo.toDigitalSecurityLog());
      creditcardChargeback.createCreditCardChargeBackRequest(createdVo);
      digitalSecLogger.log(digitalSecLoggerVO);

      return helper.populateCCDisputeResponse(
          populateResponseHeader(ServiceConstants.CC_TNX_DISPUTE_SERVICE, mobileSession), 1);
    } catch (BusinessException e) {
      digitalSecLoggerVO.setStatus(DigitalSecLogger.FAILURE);
      digitalSecLogger.log(digitalSecLoggerVO);
      Logger.info(
          "BusinessException in CCDisputeController - disputeCCTransaction() - [key: "
              + e.getKey()
              + "] : GCIS: ["
              + ((mobileSession != null && mobileSession.getCustomer() != null) ? mobileSession
                  .getCustomer().getGcis() : "") + "] :", e, this.getClass());
      return MBAppUtils.createErrorResp(mobileSession.getOrigin(), e,
          ServiceConstants.CC_TNX_DISPUTE_SERVICE, httpRequest);
    } catch (Exception e) {
      Logger.error("Exception CCDisputeController - disputeCCTransaction() : GCIS: ["
          + ((mobileSession != null && mobileSession.getCustomer() != null) ? mobileSession
              .getCustomer().getGcis() : "") + "] :", e, this.getClass());
      return MBAppUtils.createErrorResp(mobileSession.getOrigin(), new ResourceException(
          ResourceException.GENERIC_ERROR), ServiceConstants.CC_TNX_DISPUTE_SERVICE, httpRequest);
    } finally {
      endPerformanceLog(logName);
    }
  }
  
  /**
   * @param request - CCDisputeReq
   * @param mobileSession - MobileSession
   * @param commonData - IBankCommonData
   */
  private boolean isInValidDispute(CCDisputeReq request, MobileSession mobileSession,
      IBankCommonData commonData) {
    if (null != mobileSession.getTransactionHistory()
        && mobileSession.getTransactionHistory().getTransactions().size() > 0) {
      List<TransactionInfo> txnHistoryList =
          (List<TransactionInfo>) mobileSession.getTransactionHistory().getTransactions();
      if (txnHistoryList.size() > 0) {
        TransactionInfo transactionInfo =
            (TransactionInfo) txnHistoryList.get(request.getDisputeTran().getTranIndex() - 1);
        BigDecimal thresholdAmount =
            new BigDecimal(IBankParams.getCodesData(mobileSession.getOrigin(),
                IBankParams.VISA_COMPLIANCE_CONFIG, IBankParams.CONNECT_THRESHOLD).getMessage());
        if (null != request.getDisputeTran()
            && null != request.getDisputeTran().getReason()
            && request.getDisputeTran().getReason()
                .equalsIgnoreCase("Don't recognise this transaction")
            && null != transactionInfo.getAmount()
            && transactionInfo.getAmount().abs().compareTo(thresholdAmount) >= 0) {
          return true;
        }
      }
    }
    return false;
  }

  @RequestMapping(method = RequestMethod.POST, headers = "content-type=application/json",
      produces = MediaType.APPLICATION_JSON_VALUE, value = "searchtransdesc")
  @ResponseBody
  public IMBResp searchCCTransactionDesc(HttpServletRequest httpRequest,
      @RequestBody final EmptyReq request) {
    Logger.debug("CCDisputeController - searchCCTransactionDesc(). Request: " + request,
        this.getClass());

    MobileSession mobileSession = new MobileSessionImpl();
    try {
      mobileSession.getSessionContext(httpRequest);
      IBankCommonData commonData =
          new MBAppHelper().populateIBankCommonData(mobileSession, httpRequest);

      validateRequestHeader(request.getHeader(), httpRequest);
      ErrorResp errorResponse = validate(request, httpRequest);
      if (errorResponse.hasErrors())
        return errorResponse;
      creditcardChargeback.processGDWEntryForGoogleSearch(commonData);

      return helper.populateSearchCCTransactionDescResponse(
          populateResponseHeader(ServiceConstants.CC_TNX_DISPUTE_SERVICE, mobileSession), 1);

    } catch (BusinessException e) {
      Logger.info("BusinessException in CCDisputeController - searchCCTransactionDesc() - [key: "
          + e.getKey()
          + "] : GCIS: ["
          + ((mobileSession != null && mobileSession.getCustomer() != null) ? mobileSession
              .getCustomer().getGcis() : "") + "] :", e, this.getClass());
      return MBAppUtils.createErrorResp(mobileSession.getOrigin(), e,
          ServiceConstants.CC_TNX_DISPUTE_SERVICE, httpRequest);
    } catch (Exception e) {
      Logger.error("Exception CCDisputeController - searchCCTransactionDesc() : GCIS: ["
          + ((mobileSession != null && mobileSession.getCustomer() != null) ? mobileSession
              .getCustomer().getGcis() : "") + "] :", e, this.getClass());
      return MBAppUtils.createErrorResp(mobileSession.getOrigin(), new ResourceException(
          ResourceException.GENERIC_ERROR), ServiceConstants.CC_TNX_DISPUTE_SERVICE, httpRequest);
    }

  }

  @RequestMapping(value = "/oneClickToken", method = RequestMethod.POST,
      headers = "content-type=application/json", produces = MediaType.APPLICATION_JSON_VALUE)
  @ResponseBody
  public IMBResp getOneClickToken(HttpServletRequest httpServletRequest,
      HttpServletResponse httpServletResponse, @RequestBody final OneClickCardDiputeReq req)
      throws Exception {

    String logName = startPerformanceLog(httpServletRequest);
    MobileSession mbSession = null;
    IBankCommonData commonData = null;
    String gcisNumber = null;
    ObjectMapper mapper = new ObjectMapper();
    String oneClickToken = null;
    DigitalSecLogggerVO digitalSecLoggerVO = new DigitalSecLogggerVO();
    digitalSecLoggerVO.setTranName(DigitalSecLogger.CC_DISPUTE);
    digitalSecLoggerVO.setStatus(DigitalSecLogger.SUCCESS);
    try {
      Logger.info("Inside CCDisputeController.oneClickToken:", this.getClass());
      mbSession = mbAppHelper.getMobileSession(httpServletRequest);
      commonData = new MBAppHelper().populateIBankCommonData(mbSession, httpServletRequest);
      
      digitalSecLoggerVO.setCommonLogData(mbAppHelper.getCommonLogData(commonData));
      digitalSecLoggerVO.setUserAgent(commonData.getUserAgent());
      gcisNumber = commonData.getCustomer().getGcis();
      Logger.info("CCDisputeController.oneClickToken JSON Request :" + mapper.writeValueAsString(req), this.getClass());
      validateRequestHeader( req.getHeader(), httpServletRequest );

      ErrorResp errorResp = validate(req, httpServletRequest);
      if (errorResp != null && errorResp.getErrors() != null && errorResp.getErrors().size() > 0)
      {
          return errorResp;
      }
      
      OneClickCardDispute oneClickCardDispute=populateOneClickCardDispute(req);
      oneClickCardDispute.setGcisNumber(gcisNumber);
     
      oneClickToken = cardDisputeService.getSignedJWSTokenCardDispute(commonData,oneClickCardDispute);
      
      CardDisputeResp cardDisputeResp = new CardDisputeResp();
      cardDisputeResp.setJwtToken(oneClickToken);
      String url =IBankParams.getCodesData(commonData.getOrigin(), IBankParams.EXTERNAL_LINKS, TARGET_URL).getMessage();
      cardDisputeResp.setTargetURL(url);
      cardDisputeResp.setiPAddress(MBAppHelper.resolveIPAddress(httpServletRequest, commonData.getOrigin()));
      
      recordGDW(mbSession, commonData, oneClickCardDispute);
      
      if(null != mbSession.getDeviceID()) {
        cardDisputeResp.setDeviceId(mbSession.getDeviceID());
      }
      cardDisputeResp.setClientApiVersion(IBankParams.SWITCHING_SERVICE_APIVERSION);
      Logger.info("CCDisputeController.getJwt JSON Response :" + mapper.writeValueAsString(cardDisputeResp), this.getClass());
      Logger.info("Card Dispute Token : " + oneClickToken, this.getClass());
      Logger.info("Card Dispute Document gcis : " + gcisNumber, this.getClass());
      
      digitalSecLoggerVO.setValues(toDigitalSecurityLog(oneClickCardDispute, mbSession));
      digitalSecLogger.log(digitalSecLoggerVO);
      
      return cardDisputeResp;
    } catch (BusinessException e) {
    	digitalSecLoggerVO.setStatus(DigitalSecLogger.FAILURE);
        digitalSecLogger.log(digitalSecLoggerVO);
      BusinessException exp = new BusinessException(e.getKey());
      IMBResp resp1 = MBAppUtils.createErrorResp(mbSession.getOrigin() , exp, ServiceConstants.CARDDISPUTE, httpServletRequest);
      return resp1;
  } catch (ResourceException e) {
      return MBAppUtils.createErrorResp(mbSession.getOrigin(), BusinessException.SYSTEM_UNAVILABLE, ServiceConstants.CARDDISPUTE, httpServletRequest);
  }catch (Exception e) {  
      IMBResp resp1 = MBAppUtils.createErrorResp(mbSession.getOrigin(),BusinessException.GENERIC_ERROR, ServiceConstants.CARDDISPUTE, httpServletRequest);
      return resp1;
  } finally {
      endPerformanceLog(logName);
  }
   
  }
  
	public String toDigitalSecurityLog(OneClickCardDispute oneClickCardDispute, MobileSession mbSession) {
		StringBuffer sb = new StringBuffer();
		Customer customer = mbSession.getCustomer();
		try {
			sb.append(DigitalSecLogger.CARD_NUMBER)
					.append(DigitalSecLogger.DELIMITER_COLON)
					.append(oneClickCardDispute.getAccountNumber());

			sb.append(DigitalSecLogger.DELIMITER_COMMA)
					.append(DigitalSecLogger.NAME_ON_CARD)
					.append(DigitalSecLogger.DELIMITER_COLON)
					.append(customer.getFirstName() + customer.getMiddleName() + customer.getLastName());

			sb.append(DigitalSecLogger.DELIMITER_COMMA).append(DigitalSecLogger.TRANSACTION_DATE).append(DigitalSecLogger.DELIMITER_COLON).append(oneClickCardDispute.getTransDate());
			sb.append(DigitalSecLogger.DELIMITER_COMMA)
					.append(DigitalSecLogger.AMOUNT)
					.append(DigitalSecLogger.DELIMITER_COLON)
					.append(oneClickCardDispute.getAmount());

		} catch (Exception e) {
			Logger.debug(
					"AccountTransfer.toDigitalSecurityLog(): Exception while creating data for Fraud Logging",
					AccountPayment.class);
		}

		return sb.toString();

	}

	private void recordGDW(MobileSession mbSession, IBankCommonData commonData,
			OneClickCardDispute oneClickCardDispute) {
		try {
			Statistic statistic = new Statistic();

			StringBuffer description = new StringBuffer(128);

			statistic.setGcisNumber(oneClickCardDispute.getGcisNumber());
			statistic.setAction(Statistic.CREDIT_CARD_CHARGEBACK);
			statistic.setOriginBank(commonData.getOrigin());
			statistic.setGDWOriginBank(commonData.getGdwOrigin());

			statistic.setAccountNumberFrom(oneClickCardDispute
					.getAccountNumber());
			String desc = oneClickCardDispute.getAmount();
			if (oneClickCardDispute.getCardType().equalsIgnoreCase("CR")) {
				desc += " | C ";
			}
			if (oneClickCardDispute.getCardType().equalsIgnoreCase("DR")) {
				desc += " | D ";
			}
			statistic.setDescription(desc + " | " + oneClickCardDispute.getDisputeSource() + " | MB");

			if (oneClickCardDispute.getCardType().equalsIgnoreCase("CR")) {
				statistic.setAccountTypeFrom(IBankParams.CRA);
				statistic.setApplIdFrom(IBankParams.CRA);
			}
			if (oneClickCardDispute.getCardType().equalsIgnoreCase("DR")) {
				statistic.setAccountTypeFrom(IBankParams.DDA);
				statistic.setApplIdFrom(IBankParams.DDA);
			}

			// statistic.setProdCodeFrom(vo.getAccountId().getSubProductCode());

			statistic.setSessionId(mbSession.getSessionID());
			statistic.setIpAddress(commonData.getIpAddress());
			statistic
					.setAmount(new BigDecimal(oneClickCardDispute.getAmount()));

			StatisticsService.logStatistic(statistic);

		} catch (Throwable t) {
			// Don't care if we successfully recorded in GDW or not

		}
	}
 
  
  public ErrorResp validate(IMBReq serviceRequest, HttpServletRequest request) {
    Logger.info("Service request object - " + ReflectionToStringBuilder.toString(serviceRequest),
        this.getClass());
    return mbAppValidator.validate(serviceRequest, request);
  }

  public void validateRequestHeader(ReqHeader headerReq, HttpServletRequest request)
      throws BusinessException {
    Logger.debug(
        "Request header validation: "
            + ReflectionToStringBuilder.toString(headerReq, ToStringStyle.MULTI_LINE_STYLE),
        this.getClass());
    mbAppValidator.validateRequestHeader(headerReq, request);
  }

  public RespHeader populateResponseHeader(String serviceName, MobileSession mobSession) {
    return mbAppHelper.populateResponseHeader(serviceName, mobSession);
  }


  /**
   * Response for invalid body request
   * 
   * @return
   */
  @ExceptionHandler({org.springframework.http.converter.HttpMessageNotReadableException.class})
  @ResponseStatus(org.springframework.http.HttpStatus.OK)
  @ResponseBody
  public IMBResp resolveException() {
    return MBAppUtils.createInvalidMessageBodyResponse(ServiceConstants.CC_TNX_DISPUTE_SERVICE);
  }


  @Autowired
  private PerformanceLogger perfLogger;

  private String startPerformanceLog(HttpServletRequest httpRequest) {
    perfLogger.startAllLogs();
    String logName = MBAppUtils.getLogName(httpRequest);
    perfLogger.startLog(logName);
    return logName;
  }

  private void endPerformanceLog(String logName) {
    perfLogger.endLog(logName);
    perfLogger.endAllLogs();
  }

  /**
   * This API is used to get the phone token based on Overseas or Australia region
   * 
   * @param httpServletRequest - HttpServletRequest
   * @param phoneTokenReq - PhoneTokenReq
   * @return
   */
  @RequestMapping(value = "phonetoken", method = RequestMethod.POST,
      headers = "content-type=application/json", produces = MediaType.APPLICATION_JSON_VALUE)
  @ResponseBody
  public IMBResp getPhoneToken(HttpServletRequest httpServletRequest,
      @RequestBody final PhoneTokenReq phoneTokenReq) {
    Logger.debug("CCDisputeController - getPhoneToken(). Request: " + phoneTokenReq,
        this.getClass());
    MobileSession mobileSession = new MobileSessionImpl();
    try {
      validateRequestHeader(phoneTokenReq.getHeader(), httpServletRequest);
      ErrorResp errorResponse = validate(phoneTokenReq, httpServletRequest);
      if (errorResponse.hasErrors())
        return errorResponse;
      mobileSession.getSessionContext(httpServletRequest);
      IBankCommonData commonData =
          new MBAppHelper().populateIBankCommonData(mobileSession, httpServletRequest);
      // Populate PhoneToken object to make request.

      PhoneToken phoneToken =
          populatePhoneToken(phoneTokenReq.getIsOverseas(),
              getUserAgentVO(httpServletRequest.getHeader("User-Agent")));
      // Call PhoneServiceImpl to get PhoneTokenResponse object
      phoneToken = this.phoneService.getPhoneToken(commonData, phoneToken);
      // Populate and return PhoneTokenResponse JSON object for view
      return helper.populatePhoneTokenResponse(
          populateResponseHeader(ServiceConstants.CC_TNX_DISPUTE_PHONE_TOKEN, mobileSession),
          phoneToken);
    } catch (BusinessException e) {
      Logger.info(
          "BusinessException in CCDisputeController - getPhoneToken() - [key: "
              + e.getKey()
              + "] : GCIS: ["
              + ((mobileSession != null && mobileSession.getCustomer() != null) ? mobileSession
                  .getCustomer().getGcis() : "") + "] :", e, this.getClass());
      return MBAppUtils.createErrorResp(mobileSession.getOrigin(), e,
          ServiceConstants.CC_TNX_DISPUTE_PHONE_TOKEN, httpServletRequest);
    } catch (Exception e) {
      Logger.error("Exception CCDisputeController - getPhoneToken() : GCIS: ["
          + ((mobileSession != null && mobileSession.getCustomer() != null) ? mobileSession
              .getCustomer().getGcis() : "") + "] :", e, this.getClass());
      return MBAppUtils.createErrorResp(mobileSession.getOrigin(), ResourceException.GENERIC_ERROR,
          ServiceConstants.CC_TNX_DISPUTE_PHONE_TOKEN, httpServletRequest);
    }
  }

  /**
   * This method used to populate phone token request.
   * 
   * @param isOverseas - Boolean
   * @param userAgentVO - UserAgentVO
   * @return PhoneToken
   */
  private PhoneToken populatePhoneToken(boolean isOverseas, UserAgentVO userAgentVO) {
    PhoneToken phoneToken = new PhoneToken();
    // populate browser detail, OS detail and device type in case of
    // Android and browser detail is null from UserAgentVO
    if (null == userAgentVO.getBrowserDetails() || ("").equals(userAgentVO.getBrowserDetails())
        && ANDROID.contains(userAgentVO.getDeviceOSDetails())) {
      userAgentVO.setDeviceOSDetails(ANDROID_DEVICE + " " + userAgentVO.getDeviceType());
      userAgentVO.setBrowserDetails(userAgentVO.getDeviceType());
      userAgentVO.setDeviceType(ANDROID_DEVICE);
    } else {
      userAgentVO.setBrowserDetails(null);
    }
    phoneToken.setUserAgent(userAgentVO);
    if (isOverseas) {
      phoneToken.setCallIntent(CALL_INTENT_OS);
    } else {
      phoneToken.setCallIntent(CALL_INTENT_AU);
    }
    phoneToken.setOverseas(isOverseas);
    return phoneToken;
  }

  /**
   * This method used to get UserAgentVO
   * 
   * @param userAgent - String
   * @return UserAgentVO
   */
  private UserAgentVO getUserAgentVO(String userAgent) {
    au.com.stgeorge.mbank.useragent.UserAgentVO mbank_userAgentVO =
        userAgentParser.parseUserAgentString(userAgent);
    return getCashHelper.populateUserAgentVO(mbank_userAgentVO);
  }
  
  private OneClickCardDispute populateOneClickCardDispute(OneClickCardDiputeReq req){

	    OneClickCardDispute oneClickCardDispute=new OneClickCardDispute();
	   
	     if(req.getAccountNumber()!=null){
	    	 oneClickCardDispute.setAccountNumber(req.getAccountNumber());
	     }

		

		 if(req.getBsb()!=null){
			 oneClickCardDispute.setBsb(req.getBsb());
		 }
		 if(req.getAmount()!=null){
			 oneClickCardDispute.setAmount(req.getAmount());
		 }
		 if(req.getTranDesc1()!=null){
			 oneClickCardDispute.setTranDesc1(req.getTranDesc1());
		 }
		 if(req.getTranDesc2()!=null){
			 oneClickCardDispute.setTranDesc2(req.getTranDesc2());
		 }
		 if(req.getTransID()!=null){
			 oneClickCardDispute.setTransID(req.getTransID());
		 }
		 if(req.getChannel()!=null){
			
			 
			 
			 if((req.getChannel().toUpperCase().startsWith(DEVICE_TYPE_TABLET))){
				 oneClickCardDispute.setChannel(ONE_CLICK_TABLET_CHANNEL);
			 }
			 else if((req.getChannel().toUpperCase().startsWith(DEVICE_TYPE_MOBILE))){
				 oneClickCardDispute.setChannel(ONE_CLICK_MOBILE_CHANNEL);
			 }
			 else if((req.getChannel().contains("Desktop"))){
				 oneClickCardDispute.setChannel(ONE_CLICK_DESKTOP_CHANNEL);//TODO to be confirmed
			 }
			 
		 }
		 else{
			 Logger.info("CcDisputeController:: populateOneClickCardDispute channel not set for "+req.getTranDesc1(), this.getClass());
			 
		 }
		 
		  if(req.getCardType()!=null){
			  oneClickCardDispute.setCardType(req.getCardType());
		  }
		  if(req.getDisputeSource()!=null){
			  oneClickCardDispute.setDisputeSource(req.getDisputeSource());
		  }
		  if(req.getTransDate()!=null){
			  oneClickCardDispute.setTransDate(req.getTransDate());
		  }
	    return oneClickCardDispute;
	  }

}
