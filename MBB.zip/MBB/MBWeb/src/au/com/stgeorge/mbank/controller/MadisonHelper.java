package au.com.stgeorge.mbank.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import au.com.stgeorge.framework.common.logging.Logger;
import au.com.stgeorge.framework.common.util.StringMethods;
import au.com.stgeorge.ibank.businessobject.BusinessException;
import au.com.stgeorge.ibank.businessobject.assembler.CustomerVOAssembler;
import au.com.stgeorge.ibank.common.cache.IBankParams;
import au.com.stgeorge.ibank.safi.util.SafiUtil;
import au.com.stgeorge.ibank.safi.valueobject.SafiMadisonVO;
import au.com.stgeorge.ibank.service.valueobject.SafiRespVO;
import au.com.stgeorge.ibank.valueobject.ContactDetail;
import au.com.stgeorge.ibank.valueobject.Customer;
import au.com.stgeorge.ibank.valueobject.database.CodesVO;
import au.com.stgeorge.ibank.valueobject.madison.Cards;
import au.com.stgeorge.ibank.valueobject.madison.MadisonCardsVO;
import au.com.stgeorge.ibank.valueobject.transfer.IBankCommonData;
import au.com.stgeorge.mbank.controller.customer.LogonHelper;
import au.com.stgeorge.mbank.model.common.RespHeader;
import au.com.stgeorge.mbank.model.request.AddToWalletRequest;
import au.com.stgeorge.mbank.model.response.MadisonInAppProvisionEligibleCards;
import au.com.stgeorge.mbank.model.response.MadisonInAppProvisionResp;
import au.com.stgeorge.mbank.session.MobileSession;

public class MadisonHelper {

	private LogonHelper logonHelper;
	
	public LogonHelper getLogonHelper() {
		return logonHelper;
	}

	public void setLogonHelper(LogonHelper logonHelper) {
		this.logonHelper = logonHelper;
	}
	
	
	
	public SafiMadisonVO populateSafiVO(HttpServletRequest httpRequest, MobileSession mobileSession, IBankCommonData commonData, AddToWalletRequest request,String cardNumber) throws BusinessException{
			
		String validDecodedPrint;
		String devicePrint;
		
		Logger.debug("SAFI : populateSafiVO Device Print" +request.getDevicePrint(), this.getClass()) ;
		validDecodedPrint = SafiUtil.validateDevicePrint(request.getDevicePrint());
		devicePrint = validDecodedPrint != null ? request.getDevicePrint():null;
		
		SafiMadisonVO safiVO = new SafiMadisonVO();
		if(null == devicePrint && null != mobileSession.getSafiLogonInfo() && null != mobileSession.getSafiLogonInfo().getDevicePrint()) {
			devicePrint = mobileSession.getSafiLogonInfo().getDevicePrint();
			Logger.debug("SAFI : populateSafiVO :  Device Print from request was null so getting from mobileSession.getSafiLogonInfo():" +devicePrint, this.getClass()) ;
		}
		
		safiVO.setCardNumber(cardNumber);
		
		boolean isMobileApp = ((logonHelper.loadCordova(httpRequest)) == -1) ? false:true;
		Logger.debug("SAFI : populateSafiVO: validDecodedPrint: " +validDecodedPrint + " devicePrint: "+devicePrint+" isMobileApp: "+isMobileApp, this.getClass()) ;
			
		safiVO = SafiWebHelper.populateSafiVOForMadison(httpRequest, devicePrint, commonData, isMobileApp, safiVO, mobileSession);
		
		return safiVO;
	}
	
	public void handleSafiResponseinCookies(HttpServletRequest httpServletRequest,HttpServletResponse httpServletResponse, SafiRespVO safiRespVO){
		if(safiRespVO != null){
			Cookie pmdata2 = SafiWebHelper.readCookies(httpServletRequest);
			Cookie newCookie = SafiWebHelper.createOrUpdatePmdata2Cookie(httpServletRequest,pmdata2,safiRespVO.getDeviceToken());
			httpServletResponse.addCookie(newCookie);
		}
	}	
	
	public boolean isCHSorCombinedCustomer(Customer customer){
		return customer.isCHSCustomer() || customer.isCHSGHSCustomer();
	}	
	
	
    
    
    public int getRegisteredPhoneNumberCount(ContactDetail contactDetail){
		int registeredPhoneNumberCount = 0;
		
		if (!CustomerVOAssembler.BUSINESS_CUSTOMER.equalsIgnoreCase(contactDetail.getCustTypeInd())){
			if (contactDetail.getHomeNumber() != null && !StringMethods.isEmptyString(contactDetail.getHomeNumber().getPhoneNumber())){
				registeredPhoneNumberCount++;
			}
		}
		if (contactDetail.getWorkNumber() != null && !StringMethods.isEmptyString(contactDetail.getWorkNumber().getPhoneNumber())){
			registeredPhoneNumberCount++;
		}
		if (contactDetail.getMobileNumber() != null && !StringMethods.isEmptyString(contactDetail.getMobileNumber().getPhoneNumber())){
			registeredPhoneNumberCount++;
		}
		return registeredPhoneNumberCount;
	}	

    public MadisonInAppProvisionResp populateMadisonInAppProvisionResponse(UUID appCorrelationID, IBankCommonData commonData, RespHeader header, MadisonCardsVO madisonCardsVO) throws BusinessException {
    	MadisonInAppProvisionResp response = new MadisonInAppProvisionResp(header);
    	if(madisonCardsVO != null && madisonCardsVO.getCards() != null && madisonCardsVO.getCards().size() > 0) {
    		List<Cards> madisonCardsList = madisonCardsVO.getCards();
    		List<MadisonInAppProvisionEligibleCards> eligibleCardsList = new ArrayList<MadisonInAppProvisionEligibleCards>();
			for(Cards card : madisonCardsList) {
				MadisonInAppProvisionEligibleCards madisonEligibleCard = new MadisonInAppProvisionEligibleCards();
				madisonEligibleCard.setMaskedCardNumber(card.getMaskedCardNumber());
				madisonEligibleCard.setCardType(card.getCardType());
				madisonEligibleCard.setScheme(card.getScheme());
				madisonEligibleCard.setCardProductName(card.getCardProductName());
				madisonEligibleCard.setStockCode(card.getStockCode());
				madisonEligibleCard.setFpanId(card.getCardNumberReferenceId());
				madisonEligibleCard.setCardArtURL(card.getCardArtURL());
				eligibleCardsList.add(madisonEligibleCard);
			}
			response.setFaqsURL(madisonCardsVO.getFaqsURL());
			response.setTncURL(madisonCardsVO.getTncURL());
			response.setMadisonInAppProvisionEligibleCardsList(eligibleCardsList);
    	}
    	
    	CodesVO cardEligibilityURL = IBankParams.getCodesVO(IBankParams.getBaseOriginCode(commonData.getOrigin()), IBankParams.MADISON_CATEGORY, IBankParams.MADISON_CARD_ELIGIBILITY_URL);
    	
    	if(null != cardEligibilityURL) {
    		response.setCardEligibilityURL(cardEligibilityURL.getMessage());
    	}
    	    	
		return response;
		
	}
    
    
}
