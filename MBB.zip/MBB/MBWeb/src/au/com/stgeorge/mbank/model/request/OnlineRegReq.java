package au.com.stgeorge.mbank.model.request;

import java.io.Serializable;

import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.NotEmpty;

import au.com.stgeorge.ibank.businessobject.BusinessException;
import au.com.stgeorge.mbank.model.common.IMBReq;
import au.com.stgeorge.mbank.model.common.ReqHeader;

/**
 * Secure code request
 * 
 * @author C38854
 * 
 */
public class OnlineRegReq implements IMBReq, Serializable {

	private static final long serialVersionUID = 6319425054755486941L;
	protected static final String BLOCK_CHARS_PATTERN = "^[0-9A-Za-z',. &/\\-]*$";	

//	@Valid TODO
	private ReqHeader header;

	@NotEmpty(message = "{errors.accessnum.required}")
	@Size(min = 9, max = 19, message = ""+BusinessException.INVALID_ACCESS_NUMBER_LEN)
	@Pattern(regexp="([a-z A-Z]?[0-9]+[0-9\\-\\s]*)", message = ""+BusinessException.INVALID_ACC_CARD_ACCESS_NUMBER)
	private String accessNumber;
	
	@NotEmpty(message = "{errors.dateofbirth.required}")
	//@Size(min = 8, max = 8, message = ""+BusinessException.INVALID_DOB)
	private String dateOfBirth;
    
	@Pattern(regexp="([0-9]+[0-9\\-\\s]*)", message = ""+BusinessException.INVALID_BSB_NUMBER)
	private String bsbNumber;
	
	private String regReqToken;

	private Long issueNumber;
	
	private String nameId;
	
	private String pwdEncswitch;
	
	private boolean originMb;
	
	public ReqHeader getHeader() {
		return header;
	}

	public void setHeader(ReqHeader header) {
		this.header = header;
	}

	public String getNameId() {
		return nameId;
	}

	public void setNameId(String nameId) {
		this.nameId = nameId;
	}

	public String getPwdEncswitch() {
		return pwdEncswitch;
	}

	public void setPwdEncswitch(String pwdEncswitch) {
		this.pwdEncswitch = pwdEncswitch;
	}
	
	public String getAccessNumber() {
		return accessNumber;
	}

	public void setAccessNumber(String accessNumber) {
		this.accessNumber = accessNumber;
	}

	public String getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public String getBsbNumber() {
		return bsbNumber;
	}

	public void setBsbNumber(String bsbNumber) {
		this.bsbNumber = bsbNumber;
	}
	public String getRegReqToken() {
		return regReqToken;
	}

	public void setRegReqToken(String regReqToken) {
		this.regReqToken = regReqToken;
	}
	
	public Long getIssueNumber() {
		return issueNumber;
	}

	public void setIssueNumber(Long issueNumber) {
		this.issueNumber = issueNumber;
	}

	public boolean isOriginMb() {
	    return originMb;
	}

	public void setOriginMb(boolean originMb) {
	    this.originMb = originMb;
	}

}
