package au.com.stgeorge.mbank.model.request.customer;

import java.io.Serializable;

import au.com.stgeorge.mbank.model.common.IMBReq;
import au.com.stgeorge.mbank.model.common.ReqHeader;

public class MatrixMigrationReq implements IMBReq, Serializable{
	
	private static final long serialVersionUID = -256469501889499118L;
	
	private ReqHeader header;
	private String gcisNumber;
	private String splashPageAction;
	
	public ReqHeader getHeader() {
		return header;
	}
	public void setHeader(ReqHeader header)	{
		this.header = header;
	}
	public String getGcisNumber() {
		return gcisNumber;
	}
	public void setGcisNumber(String gcisNumber) {
		this.gcisNumber = gcisNumber;
	}
	public String getSplashPageAction() {
	    return splashPageAction;
	}
	public void setSplashPageAction(String splashPageAction) {
	    this.splashPageAction = splashPageAction;
	}
	
}
