package au.com.stgeorge.mbank.model.request.payments;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

import org.apache.commons.lang.builder.ReflectionToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;
import org.hibernate.validator.constraints.Length;
import org.hibernate.validator.constraints.NotEmpty;

import au.com.stgeorge.ibank.businessobject.BusinessException;
import au.com.stgeorge.mbank.model.common.IMBReq;
import au.com.stgeorge.mbank.model.common.ReqHeader;

/**
 * TT Get fee details request
 * 
 * @author C38854
 *
 */
public class TTGetFeeDetailReq implements IMBReq{

	private static final long serialVersionUID = -3018405318665947771L;
	
	// @Valid TODO
	private ReqHeader header;
	
	
	/**
	 * AUD currency
	 */
	@NotEmpty(message = "{errors.amt.required}")
	@Length(max = 14, message = "{errors.amt.maxlength}")
	@Pattern(regexp = "^[0-9]*\\.{0,1}(\\d{1,2}){0,1}$", message = "{errors.amt.blockchar}")
	private String amt;
	
	@NotNull(message = "" + BusinessException.ACCOUNT_NO_FROM_ACCOUNT)
	private Integer fromAccountIndex;
	
	@NotEmpty
	private String country;
	
	@NotEmpty
	private String currency;
	
	private String purposeCode;
	
	@NotEmpty
	private String countryCode;

	private String bankCountryCode; 

	public String getBankCountryCode() {
		return bankCountryCode;
	}

	public void setBankCountryCode(String bankCountryCode) {
		this.bankCountryCode = bankCountryCode;
	}

	public String getAmt() {
		return amt;
	}

	public Integer getFromAccountIndex() {
		return fromAccountIndex;
	}

	public String getCountry() {
		return country;
	}

	public String getCurrency() {
		return currency;
	}

	public ReqHeader getHeader() {
		return header;
	}

	public void setHeader(ReqHeader header) {
		this.header = header;
	}

	@Override
	public String toString() {
		return ReflectionToStringBuilder.toString(this, ToStringStyle.MULTI_LINE_STYLE);
	}

	public String getPurposeCode() {
		return purposeCode;
	}

	public void setPurposeCode(String purposeCode) {
		this.purposeCode = purposeCode;
	}
	
	public String getCountryCode() {
		return countryCode;
	}

}
