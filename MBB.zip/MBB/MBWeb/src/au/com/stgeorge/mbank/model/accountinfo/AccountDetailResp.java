/**
 * 
 */
package au.com.stgeorge.mbank.model.accountinfo;



import au.com.stgeorge.mbank.model.common.AccountKeyInfoResp;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
/**
 * @author C50216
 *
 */

@JsonInclude(Include.NON_NULL)
public class AccountDetailResp{
	
	private AccountKeyInfoResp accountKey;
	private String productName;
	private String balance;
	private String availBalance;
	private String interestRate;
	private DDAAccountDetailResp ddaDetail;
	private CRAAccountDetailResp craDetail;
	private TDAAccountDetailResp tdaDetail;
	private LISAccountDetailResp lisDetail;
	private GCCAccountDetailResp gccDetail;
	private InsuranceAccountDetailResp insDetail;
	private TravelInsuranceAccountDetailsResp atiDetail;
	private Boolean allowTnxCrossSell=false;
	private Boolean isCardLinked=false;
	private Boolean allowTnxCategorisation=false;//17E4 Transaction Categorisation
	private Boolean shareAllowed = false;//17E4 Share BSB and Account Number
	private Boolean allowMadison = false;//17E4 Share BSB and Account Number
	
	private boolean advanceSearchSwitch;
	
	//19E1 CPP
	private Boolean showOffer = false;
	private Boolean firstTimeCheck = Boolean.FALSE;
	
	//	20E1 : Instant Digital Card
	private Boolean showIDCLink;
	
	private String homeLoanDigiOfferFlag;
	  
	private String homeLoanDigiMaturityDate;
	private Boolean showRewards=false;
	
	private String rewardsPoints="";
	
	private Boolean showBalanceSmartPlan = false;
	private boolean showSmartPlanAccountServiceMenu;
	
	public boolean isAdvanceSearchSwitch() {
		return advanceSearchSwitch;
	}
	public void setAdvanceSearchSwitch(boolean advanceSearchSwitch) {
		this.advanceSearchSwitch = advanceSearchSwitch;
	}
	public Boolean getShareAllowed() {
		return shareAllowed;
	}
	public void setShareAllowed(Boolean shareAllowed) {
		this.shareAllowed = shareAllowed;
	}
	
	public DDAAccountDetailResp getDdaDetail() {
		return ddaDetail;
	}
	public void setDdaDetail(DDAAccountDetailResp detail) {
		ddaDetail = detail;
	}
	public CRAAccountDetailResp getCraDetail() {
		return craDetail;
	}
	public void setCraDetail(CRAAccountDetailResp detail) {
		craDetail = detail;
	}
	public TDAAccountDetailResp getTdaDetail() {
		return tdaDetail;
	}
	public void setTdaDetail(TDAAccountDetailResp detail) {
		tdaDetail = detail;
	}
	public LISAccountDetailResp getLisDetail() {
		return lisDetail;
	}
	public void setLisDetail(LISAccountDetailResp detail) {
		lisDetail = detail;
	}
	public AccountKeyInfoResp getAccountKey() {
		return accountKey;
	}
	public void setAccountKey(AccountKeyInfoResp accountKey) {
		this.accountKey = accountKey;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}	
	public String getBalance() {
		return balance;
	}
	public void setBalance(String balance) {
		this.balance = balance;
	}
	public String getAvailBalance() {
		return availBalance;
	}
	public void setAvailBalance(String availBalance) {
		this.availBalance = availBalance;
	}
	public String getInterestRate() {
		return interestRate;
	}
	public void setInterestRate(String interestRate) {
		this.interestRate = interestRate;
	}
	
	public GCCAccountDetailResp getGccDetail() {
		return gccDetail;
	}
	public void setGccDetail(GCCAccountDetailResp gccDetail) {
		this.gccDetail = gccDetail;
	}
	public InsuranceAccountDetailResp getInsDetail() {
		return insDetail;
	}
	public void setInsDetail(InsuranceAccountDetailResp insDetail) {
		this.insDetail = insDetail;
	}
	public TravelInsuranceAccountDetailsResp getAtiDetail() {
		return atiDetail;
	}
	public void setAtiDetail(TravelInsuranceAccountDetailsResp atiDetail) {
		this.atiDetail = atiDetail;
	}
	public Boolean isCardLinked() {
		return isCardLinked;
	}
	public void setCardLinked(Boolean isCardLinked) {
		this.isCardLinked = isCardLinked;
	}
	@JsonInclude(Include.NON_DEFAULT)
	public Boolean getAllowTnxCategorisation() {
		return allowTnxCategorisation;
	}
	public void setAllowTnxCategorisation(Boolean allowTnxCategorisation) {
		this.allowTnxCategorisation = allowTnxCategorisation;
	}
	public Boolean getShowOffer() {
		return showOffer;
	}
	public void setShowOffer(Boolean showOffer) {
		this.showOffer = showOffer;
	}
	public Boolean getAllowTnxCrossSell() {
		return allowTnxCrossSell;
	}
	public void setAllowTnxCrossSell(Boolean allowTnxCrossSell) {
		this.allowTnxCrossSell = allowTnxCrossSell;
	}
	public Boolean getFirstTimeCheck() {
		return firstTimeCheck;
	}
	public void setFirstTimeCheck(Boolean firstTimeCheck) {
		this.firstTimeCheck = firstTimeCheck;

	}
	public Boolean getShowIDCLink() {
		return showIDCLink;
	}
	public void setShowIDCLink(Boolean showIDCLink) {
		this.showIDCLink = showIDCLink;
	}
	public String getHomeLoanDigiOfferFlag() {
		return homeLoanDigiOfferFlag;
	}
	public void setHomeLoanDigiOfferFlag(String homeLoanDigiOfferFlag) {
		this.homeLoanDigiOfferFlag = homeLoanDigiOfferFlag;
	}
	public String getHomeLoanDigiMaturityDate() {
		return homeLoanDigiMaturityDate;
	}
	public void setHomeLoanDigiMaturityDate(String homeLoanDigiMaturityDate) {
		this.homeLoanDigiMaturityDate = homeLoanDigiMaturityDate;
	}
	public Boolean getAllowMadison() {
		return allowMadison;
	}
	public void setAllowMadison(Boolean allowMadison) {
		this.allowMadison = allowMadison;
	}	
	
	public Boolean getShowRewards() {
		return showRewards;
	}
	public void setShowRewards(Boolean showRewards) {
		this.showRewards = showRewards;
	}
	/**
	 * @return the rewardsPoints
	 */
	public String getRewardsPoints() {
		return rewardsPoints;
	}
	/**
	 * @param rewardsPoints the rewardsPoints to set
	 */
	public void setRewardsPoints(String rewardsPoints) {
		this.rewardsPoints = rewardsPoints;
	}
	
	public Boolean getShowBalanceSmartPlan() {
		return showBalanceSmartPlan;
	}
	public void setShowBalanceSmartPlan(Boolean showBalanceSmartPlan) {
		this.showBalanceSmartPlan = showBalanceSmartPlan;
	}
	public boolean isShowSmartPlanAccountServiceMenu() {
		return showSmartPlanAccountServiceMenu;
	}
	public void setShowSmartPlanAccountServiceMenu(boolean showSmartPlanAccountServiceMenu) {
		this.showSmartPlanAccountServiceMenu = showSmartPlanAccountServiceMenu;
	}
	
}
