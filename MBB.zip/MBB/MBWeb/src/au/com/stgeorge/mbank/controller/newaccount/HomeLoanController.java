package au.com.stgeorge.mbank.controller.newaccount;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import au.com.stgeorge.framework.common.logging.Logger;
import au.com.stgeorge.framework.common.model.User;
import au.com.stgeorge.framework.common.util.StringMethods;
import au.com.stgeorge.ibank.businessobject.BusinessException;
import au.com.stgeorge.ibank.businessobject.ResourceException;
import au.com.stgeorge.ibank.businessobject.ServiceTokenService;
import au.com.stgeorge.ibank.common.cache.IBankParams;
import au.com.stgeorge.ibank.util.ServiceHelper;
import au.com.stgeorge.ibank.valueobject.Customer;
import au.com.stgeorge.ibank.valueobject.transfer.IBankCommonData;
import au.com.stgeorge.mbank.controller.IMBController;
import au.com.stgeorge.mbank.model.common.IMBReq;
import au.com.stgeorge.mbank.model.common.IMBResp;
import au.com.stgeorge.mbank.model.common.ReqHeader;
import au.com.stgeorge.mbank.model.common.RespHeader;
import au.com.stgeorge.mbank.model.request.EmptyReq;
import au.com.stgeorge.mbank.model.response.ErrorResp;
import au.com.stgeorge.mbank.model.response.newaccount.HomeLoanResp;
import au.com.stgeorge.mbank.session.MobileSession;
import au.com.stgeorge.mbank.session.MobileSessionImpl;
import au.com.stgeorge.mbank.util.MBAppHelper;
import au.com.stgeorge.mbank.util.MBAppUtils;
import au.com.stgeorge.mbank.util.MBAppValidator;
import au.com.stgeorge.mbank.util.ServiceConstants;
import au.com.stgeorge.perflogger.PerformanceLogger;

import com.fasterxml.jackson.databind.ObjectMapper;

@Controller
@RequestMapping("/homeLoan")
public class HomeLoanController implements IMBController
{


	@Autowired
	private MBAppHelper mbAppHelper;

	
	@RequestMapping(method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE, value = "getToken")
	@ResponseBody
	public IMBResp getToken(HttpServletRequest httpRequest, @RequestBody final EmptyReq request) {
		Logger.debug("HomeLoanController - getToken(). Request: " + request, this.getClass());
		String logName = startPerformanceLog(httpRequest);
		MobileSession mobileSession = new MobileSessionImpl();

		try {
			mobileSession.getSessionContext(httpRequest);
			Customer customer = mobileSession.getCustomer();
			IBankCommonData commonData = new MBAppHelper().populateIBankCommonData(mobileSession, httpRequest);

			validateRequestHeader(request.getHeader(), httpRequest);
			ErrorResp errorResponse = validate(request, httpRequest);
			if (errorResponse.hasErrors())
				return errorResponse;
			
			ServiceTokenService insSSOTokenService = (ServiceTokenService) ServiceHelper.getBean("homeLoanSSOTokenService");
			String serviceToken = insSSOTokenService.generateToken(customer.getGcis() );

			HomeLoanResp homeLoanResp = new HomeLoanResp();
			homeLoanResp.setToken(serviceToken);
			String gdwOrigin = commonData.getGdwOrigin();
			if ( StringMethods.isEmptyString(gdwOrigin ) )
			{
				homeLoanResp.setIsTablet("N");
			}
			else
			{
				if( "TSTG".equalsIgnoreCase(gdwOrigin) || "TBSA".equalsIgnoreCase(gdwOrigin) || "TBOM".equalsIgnoreCase(gdwOrigin))
				{
					homeLoanResp.setIsTablet("Y");
				}
				else
				{
					homeLoanResp.setIsTablet("N");
				}
			}
			IMBResp serviceResponse = homeLoanResp;
			RespHeader headerResp = populateResponseHeader(ServiceConstants.HELP_SEARCH_RESPONSE, mobileSession);
			serviceResponse.setHeader(headerResp);
			ObjectMapper mapper = new ObjectMapper();

			Logger.debug("HomeLoanController - getToken() JSON Response :" + mapper.writeValueAsString(serviceResponse), this.getClass());


			return serviceResponse;


		} catch (BusinessException e) {
			Logger.info("BusinessException in HomeLoanController - getToken() - [key: " + e.getKey() + "], GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), e, ServiceConstants.ACCOUNT_TRANSFER_SERVICE, httpRequest);
		} catch (Exception e) {
			Logger.error("Exception in HomeLoanController - getToken(): ", e, this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.GENERIC_ERROR, ServiceConstants.ACCOUNT_TRANSFER_SERVICE, httpRequest);
		} finally {
			
			mobileSession.invalidateSession();
			Logger.info("Invalidated Session ", this.getClass());
			endPerformanceLog(logName);
		}
	}


	@Autowired
	private PerformanceLogger perfLogger;
	
	private String startPerformanceLog(HttpServletRequest httpRequest){
		perfLogger.startAllLogs();
		String logName = MBAppUtils.getLogName(httpRequest);
		perfLogger.startLog(logName);
		return logName;
	}
	
	private void endPerformanceLog(String logName){
		perfLogger.endLog(logName);
		perfLogger.endAllLogs();
	}
	


	public IBankCommonData populateIBankCommonData(Customer customer, User user)
	{
		IBankCommonData commonData = new IBankCommonData();
		commonData.setUser(user);
		commonData.setOrigin((String) user.getAttribute(IBankParams.USEROBJ_BRAND));
		commonData.setCustomer(customer);
		return commonData;
	}

	public ErrorResp validate(IMBReq serviceRequest, HttpServletRequest request)
	{
		return mbAppValidator.validate(serviceRequest, request);
	}

	public void validateRequestHeader(ReqHeader header, HttpServletRequest request) throws ResourceException
	{
		mbAppValidator.validateRequestHeader(header, request);
	}

	public RespHeader populateResponseHeader(String serviceName, MobileSession mobSession)
	{
		return mbAppHelper.populateResponseHeader(serviceName, mobSession);
	}

	@Autowired
	private MBAppValidator mbAppValidator;

}
