package au.com.stgeorge.mbank.controller.newaccount;

import java.net.URLEncoder;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import au.com.stgeorge.framework.common.logging.Logger;
import au.com.stgeorge.framework.common.util.StringMethods;
import au.com.stgeorge.ibank.businessobject.BusinessException;
import au.com.stgeorge.ibank.businessobject.CustomerService;
import au.com.stgeorge.ibank.businessobject.InsuranceService;
import au.com.stgeorge.ibank.businessobject.InvitationService;
import au.com.stgeorge.ibank.businessobject.ResourceException;
import au.com.stgeorge.ibank.common.cache.IBankParams;
import au.com.stgeorge.ibank.common.cache.IBankRefershParams;
import au.com.stgeorge.ibank.util.ServiceHelper;
import au.com.stgeorge.ibank.valueobject.ExternalLinkVO;
import au.com.stgeorge.ibank.valueobject.database.CodesVO;
import au.com.stgeorge.ibank.valueobject.transfer.IBankCommonData;
import au.com.stgeorge.mbank.controller.IMBController;
import au.com.stgeorge.mbank.model.common.DismissInvitationInfoResp;
import au.com.stgeorge.mbank.model.common.IMBReq;
import au.com.stgeorge.mbank.model.common.IMBResp;
import au.com.stgeorge.mbank.model.common.InvitationInfoReq;
import au.com.stgeorge.mbank.model.common.InvitationInfoResp;
import au.com.stgeorge.mbank.model.common.ReqHeader;
import au.com.stgeorge.mbank.model.common.RespHeader;
import au.com.stgeorge.mbank.model.request.newaccount.OpenCRAReq;
import au.com.stgeorge.mbank.model.response.ErrorResp;
import au.com.stgeorge.mbank.model.response.newaccount.OpenCRAResp;
import au.com.stgeorge.mbank.session.MobileSession;
import au.com.stgeorge.mbank.util.MBAppConstants;
import au.com.stgeorge.mbank.util.MBAppHelper;
import au.com.stgeorge.mbank.util.MBAppUtils;
import au.com.stgeorge.mbank.util.MBAppValidator;
import au.com.stgeorge.mobilebank.businessobject.ExternalLinkService;
import au.com.stgeorge.mobilebank.businessobject.impl.ExternalLinkServiceImpl.InsuranceProductsEnum;
import au.com.stgeorge.mobilebank.businessobject.impl.ExternalLinkServiceImpl.NewCRAProductsEnum;
import au.com.stgeorge.perflogger.PerformanceLogger;


@Controller
@RequestMapping("/newcra")
public class OpenCRAController implements IMBController
{

	public static final String REQ_ACTION_STR = "action";
	public static final String REQ_NEW_ACCOUNT_STR = "newaccount";
	
	public static final String REQ_CATEGORY_STR = "category";
	private static final String REQ_CREDIT_CARD =  "CREDIT CARDS" ;
	private static final String REQ_PERSONAL_LOAN = "PERSONAL LOANS";
	
	public static final String REQ_PRODUCTID_STR = "productId";
	
	
	public static final String ACE_SEARCH_STRING= "ACE|Account|MBank|Apply for Credit Card";
	public static final String PL_SEARCH_STRING="ACE|Account|MBank|Apply for Loans"; 
	public static final String ACE_SEARCH_STRING_BUS= "ACE|Account|MBank|Apply for Business Card";
	
	public static final String INSURANCE = "Insurance|";

	
	@Autowired
	private MBAppHelper mbAppHelper;
	
	@Autowired
	private InvitationService invitationService;
	
	@Autowired
	private InsuranceService insuranceService;
	
	@Autowired
	private IBankRefershParams ibankRefreshParams;

	@RequestMapping(value="getURL", method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public IMBResp getFundingAccount(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse,
			@RequestBody final OpenCRAReq request)
	{
		String logName = startPerformanceLog(httpServletRequest);
		String url = null;
		boolean openInSameBrowser = false;
		MobileSession mbSession = null;
		try
		{
			mbSession = mbAppHelper.getMobileSession(httpServletRequest);		
			validateRequestHeader( request.getHeader(), httpServletRequest );
			ErrorResp errorResp = validate(request, httpServletRequest);

//			String action = request.getParameter(REQ_ACTION_STR);
			String category = request.getProduct().getType();
			String productID = request.getProduct().getSubProdcode();
			IBankCommonData commonData=mbAppHelper.populateIBankCommonData(mbSession,httpServletRequest);
			
			if ( "INSURANCES".equalsIgnoreCase(category))
			{
				//16E4 Comet Insurance SSO for car, home and landlord 
				InsuranceProductsEnum insuranceProdEnum = InsuranceProductsEnum.valueOf(productID.trim());
				String productType  = null;
				
				if(insuranceProdEnum.getSubProdCode().contains("car")){
					productType = "car";
				}else if(insuranceProdEnum.getSubProdCode().contains("home")){
					productType = "home";
				}else if(insuranceProdEnum.getSubProdCode().contains("land")){
					productType = "land";
				}else if(insuranceProdEnum.getSubProdCode().contains("travel")){
					productType = "travel";
				}
				
				//if(IBankParams.isInsuranceSSOSwitchON() && productType != null && (productType.equals("car") || productType.equals("home") || productType.equals("land"))){
				//if(IBankParams.isInsuranceSSOSwitchON() && productType != null && (productType.equals("home") || productType.equals("land"))){
				if(productType != null && ((IBankParams.isInsuranceSSOSwitchON() && (productType.equals("home") || productType.equals("land")))||(IBankParams.isMotorInsuranceSSOSwitchON() && productType.equals("car") ) 
						|| (IBankParams.isTravelInsuranceSSOSwitchON() && productType.equals("travel") ))){
				try{
					//IBankCommonData commonData=mbAppHelper.populateIBankCommonData(mbSession,httpServletRequest);
					url= insuranceService.getSSOUrl(commonData, mbSession.getOrigin(), INSURANCE+insuranceProdEnum.getSubProdCode(), productType, null);
					if(StringMethods.isEmptyString(url)){
						throw new BusinessException (BusinessException.SYSTEM_UNAVILABLE, "Insurance SSO url is empty" );
					}
				}	catch(Exception e){
					Logger.error("Exception Inside getFundingAccount() for Insurance Product. ", e, this.getClass());
					CodesVO myCodesVO = null;
		            myCodesVO = IBankParams.getCodesData(mbSession.getOrigin(),"Features",INSURANCE+insuranceProdEnum.getSubProdCode() );
		            url = myCodesVO.getMessage();
		            
				}
				}
				else{
		            CodesVO myCodesVO = null;
		            myCodesVO = IBankParams.getCodesData(mbSession.getOrigin(),"Features",INSURANCE+insuranceProdEnum.getSubProdCode() );
		            url = myCodesVO.getMessage();
		            
				}
				ExternalLinkService extService = ServiceHelper.getBean("externalLinkService");
				extService.createLogStatistics(commonData, true, INSURANCE+insuranceProdEnum.getSubProdCode());
			}
			else
			{
				NewCRAProductsEnum craProdEnum = NewCRAProductsEnum.valueOf(productID.trim());
				String subProdCode = craProdEnum.getSubProdCode();
				url = getACEurl(commonData, subProdCode,  category);
				openInSameBrowser = checkForOpenInSameBrowser(productID.trim());
				/*Check for switch to extend the session*/
				/*if(subProdCode is in the list --> fetch from codes table){
					--> Put a parameter in mb session which needs to be checked later
					--> Extend the session for a definite amount of time 
					--> Fetch this parameter from codes table
				}*/
				
				/* openInSameBrowser -->
				 * If this flag is true, extend the MB session
				 * */ 
				if(openInSameBrowser){
					mbSession.setRedirectToExternalApp(IBankParams.COMPASS_TO_ACE);
					mbSession.setExtendMobileSession(IBankParams.YES);
				}
				
				Logger.info( " External URL " + url, this.getClass() );
			}
				OpenCRAResp openCRAResp = new OpenCRAResp();
				openCRAResp.setUrl(url);
				openCRAResp.setOpenInSameBrowser(openInSameBrowser);
				RespHeader headerResp = populateResponseHeader(request.getHeader().getServiceName(), mbSession);
				openCRAResp.setHeader(headerResp);
				return openCRAResp;
		}
		catch ( Exception e)
		{
			Logger.error("Exception Inside getFundingAccount() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			BusinessException exp = new BusinessException(BusinessException.SYSTEM_UNAVILABLE);
			IMBResp resp1 = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, MBAppConstants.SMPL_OPENDDAACCOUNT_RESP_NAME, httpServletRequest);
			return resp1;
		}
		finally
		{			
			endPerformanceLog(logName);
		}

	}
	
	private boolean checkForOpenInSameBrowser(String productId) {
		return ibankRefreshParams.checkProductsForOpenInSameBrowser(productId);
	}

	/**
	 * When customer clicks on Not interested
	 * @param httpServletRequest
	 * @param httpServletResponse
	 * @param request
	 * @return
	 */
	@RequestMapping(value="dismissInvitation", method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public IMBResp dismissInvitation(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse,
			@RequestBody final InvitationInfoReq invitationInfoReq)
	{
		String logName = startPerformanceLog(httpServletRequest);
		MobileSession mbSession = null;
		InvitationInfoResp invitationResp= new InvitationInfoResp();
		DismissInvitationInfoResp dismissInvitationResp = new DismissInvitationInfoResp();
		try
		{
			
			validateRequestHeader( invitationInfoReq.getHeader(), httpServletRequest );
			ErrorResp errorResp = validate(invitationInfoReq, httpServletRequest);

			mbSession = mbAppHelper.getMobileSession(httpServletRequest);		
			
			IBankCommonData commonData = mbAppHelper.populateIBankCommonData(mbSession,httpServletRequest);
			invitationService.dismissInvitaion(commonData, invitationInfoReq.getProductType());
			if(commonData.getCustomer().getInvitation() != null) {
				invitationResp = MBAppHelper.populateInvitation(commonData.getCustomer());
			}
			mbSession.setCustomer(commonData.getCustomer());
			RespHeader headerResp = populateResponseHeader(invitationInfoReq.getHeader().getServiceName(), mbSession);
			dismissInvitationResp.setInvitationInfoResp(invitationResp);
			dismissInvitationResp.setHeader(headerResp);
			dismissInvitationResp.setSuccess(true);
			return dismissInvitationResp;
		}
		catch ( Exception e)
		{
			Logger.error("Exception Inside getFundingAccount() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			BusinessException exp = new BusinessException(BusinessException.SYSTEM_UNAVILABLE);
			IMBResp resp1 = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, MBAppConstants.SMPL_OPENDDAACCOUNT_RESP_NAME, httpServletRequest);
			return resp1;
		}
	}


	private String getACEurl(IBankCommonData commonData,String productID, String category) throws BusinessException , ResourceException
	{
		try
		{
			boolean isInviteExists = false;
			InvitationService invitationService = (InvitationService)ServiceHelper.getBean("invitationService");
			String invitaionList = invitationService.getInvitationProductList(commonData.getCustomer(), commonData.getOrigin()) + ",";
			
			Logger.info("Invitation Exists for >>>>  "+ productID + " invitaionList " + invitaionList , this.getClass());

			String tempproductID = productID.toUpperCase();
			
			tempproductID = tempproductID.replaceFirst("QANTAS", "");
			tempproductID = tempproductID.replaceFirst("REWARD", "");
			String invitProd = "";
			if (  tempproductID.length() >= 12  )
			{
				invitProd = tempproductID.substring(0,9);
			}
			else
			{
				invitProd =  tempproductID.substring(0,6);
			}					

			Logger.info("Invitation Prod :  "+ invitProd + " list : "+ invitaionList, this.getClass());

			if ( ! StringMethods.isEmptyString(invitaionList))
			{
				if ( REQ_PERSONAL_LOAN.equalsIgnoreCase(category) )
					invitProd = "PLUNS";
				else
					invitProd = invitProd + ",";
				
				invitaionList = invitaionList.toUpperCase();
				Logger.info("Invitation Exists for "+ invitProd + " list : "+ invitaionList, this.getClass());
				if ( invitProd != null && invitaionList.indexOf(invitProd.toUpperCase()) >= 0 )
				{
					isInviteExists = true;
					
				}
			}

			if( REQ_CREDIT_CARD.equalsIgnoreCase(category))
			{
				String linkType = null;
				if ( productID != null && productID.startsWith("CRAAMPBUS") )
				{
					linkType = ACE_SEARCH_STRING_BUS;
				}
				else
					linkType = ACE_SEARCH_STRING;
				
				ExternalLinkService extService = ServiceHelper.getBean("externalLinkService");
				ExternalLinkVO  externalLinkVO = extService.getExternalURLVO(commonData, true, linkType,productID,null, isInviteExists);
				StringBuffer url = new StringBuffer(externalLinkVO.getUrl());
				if (isInviteExists )
				{
					url.append("&invite=Y");
					Logger.info("Invitation accepted.... "+ invitProd + " url "+ url, this.getClass());
					invitationService.acceptInvitaion(commonData, true);
				}
				if(!CustomerService.isJWTSwitchON()){
					url.append("&data="+ URLEncoder.encode(externalLinkVO.getUnSignedData(),"UTF-8"));
					url.append("&sign="+ URLEncoder.encode(externalLinkVO.getSignedData(), "UTF-8"));
					}
					else{
						url.append("&ACEdata="+ externalLinkVO.getUnSignedData());	
					}

				//url.append("&data="+ URLEncoder.encode(externalLinkVO.getUnSignedData(),"UTF-8"));
				//url.append("&sign="+ URLEncoder.encode(externalLinkVO.getSignedData(), "UTF-8"));
				return url.toString();
			} 
			else if( REQ_PERSONAL_LOAN.equalsIgnoreCase(category))
			{
				String linkType = PL_SEARCH_STRING;
				ExternalLinkService extService = ServiceHelper.getBean("externalLinkService");
				ExternalLinkVO  externalLinkVO = extService.getExternalURLVO(commonData, true, linkType,productID,null, isInviteExists);
				StringBuffer url = new StringBuffer(externalLinkVO.getUrl());
				if (isInviteExists )
				{
					String appType = null;
					CodesVO personalLoanType = IBankParams.getCodesData(commonData.getOrigin(),
							IBankParams.MOBILE_PL_PRD, productID);
					Logger.debug("personalLoanType :" + personalLoanType + "productID :" + productID, this.getClass());
					appType = personalLoanType.getMessage().trim();
					
					if(productID != null && productID.trim().equalsIgnoreCase("unsecPersonalLoan")){
						url.append("&invite=Y");
						Logger.info("Invitation accepted.... "+ invitProd + " url "+ url, this.getClass());
						String promoCode = invitationService.getPromoCode(commonData.getOrigin(), "pluns");
						if ( promoCode != null )
						{
							url.append("&promoCode="+promoCode.trim());
						}
						invitationService.acceptInvitaion(commonData, false );
					}
				}
				if(!CustomerService.isJWTSwitchON()){
					url.append("&data="+ URLEncoder.encode(externalLinkVO.getUnSignedData(),"UTF-8"));
					url.append("&sign="+ URLEncoder.encode(externalLinkVO.getSignedData(), "UTF-8"));
					}
					else{
						url.append("&ACEdata="+ externalLinkVO.getUnSignedData());	
					}
				//url.append("&data="+ URLEncoder.encode(externalLinkVO.getUnSignedData(),"UTF-8"));
				//url.append("&sign="+ URLEncoder.encode(externalLinkVO.getSignedData(), "UTF-8"));
				return url.toString();
			} 
			else
			{
				Logger.error("URL Not found..... " + category, this.getClass());
				throw new ResourceException( ResourceException.SYSTEM_ERROR, "URL Not found..... " + category );
			}
		}
		catch ( Exception e )
		{
			Logger.error("Error in getACEUurl() ", e, this.getClass());
			throw new ResourceException( ResourceException.SYSTEM_ERROR, "URL Not found..... " + category );
		}
	}

	
	public ErrorResp validate(IMBReq serviceRequest, HttpServletRequest request) {
		return  mbAppValidator.validate(serviceRequest, request);
	}

	public RespHeader populateResponseHeader(String serviceName, MobileSession mobSession )
	{
		return mbAppHelper.populateResponseHeader(serviceName, mobSession);
	}

	public void validateRequestHeader(ReqHeader header, HttpServletRequest request) throws ResourceException
	{
		mbAppValidator.validateRequestHeader(header,  request);
	}

	
	@Autowired
	private MBAppValidator mbAppValidator;

	@Autowired
	private PerformanceLogger perfLogger;
	
	private String startPerformanceLog(HttpServletRequest httpServletRequest){
		perfLogger.startAllLogs();
		String logName = MBAppUtils.getLogName(httpServletRequest);
		perfLogger.startLog(logName);
		return logName;
	}
	
	private void endPerformanceLog(String logName){
		perfLogger.endLog(logName);
		perfLogger.endAllLogs();
	}

}