/**
 * 
 */
package au.com.stgeorge.mbank.controller.services;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.UUID;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;

import au.com.stgeorge.framework.common.logging.Logger;
import au.com.stgeorge.framework.common.util.GeneralMethods;
import au.com.stgeorge.ibank.businessobject.BusinessException;
import au.com.stgeorge.ibank.businessobject.CustomerService;
import au.com.stgeorge.ibank.businessobject.ResourceException;
import au.com.stgeorge.ibank.businessobject.globalWallet.GlobalWalletService;
import au.com.stgeorge.ibank.businessobject.globalWallet.GlobalWalletServiceHelper;
import au.com.stgeorge.ibank.businessobject.model.globalwallet.cardservicing.CardsActivationResult;
import au.com.stgeorge.ibank.common.cache.IBankParams;
import au.com.stgeorge.ibank.messagecentre.valueobject.MessageSearch;
import au.com.stgeorge.ibank.messagecentre.util.MessageCentreConstants;
import au.com.stgeorge.ibank.servicestation.businessobject.ServiceStation;
import au.com.stgeorge.ibank.servicestation.businessobject.ServiceStationImpl;
import au.com.stgeorge.ibank.servicestation.businessobject.valueobject.ServiceStationVO;
import au.com.stgeorge.ibank.servicestation.util.ServicetationConstants;
import au.com.stgeorge.ibank.util.StringUtil;
import au.com.stgeorge.ibank.valueobject.CardActivation;
import au.com.stgeorge.ibank.valueobject.database.OriginsVO;
import au.com.stgeorge.ibank.valueobject.globalWallet.GlobalWalletActivation;
import au.com.stgeorge.ibank.valueobject.globalWallet.GlobalWalletDetails;
import au.com.stgeorge.ibank.valueobject.transfer.IBankCommonData;
import au.com.stgeorge.mbank.controller.IMBController;
import au.com.stgeorge.mbank.model.common.IMBReq;
import au.com.stgeorge.mbank.model.common.IMBResp;
import au.com.stgeorge.mbank.model.common.ReqHeader;
import au.com.stgeorge.mbank.model.common.RespHeader;
import au.com.stgeorge.mbank.model.request.services.CardActivationReq;
import au.com.stgeorge.mbank.model.response.ErrorResp;
import au.com.stgeorge.mbank.model.response.services.CardActivationEstmntResponse;
import au.com.stgeorge.mbank.model.response.services.CardActivationResp;
import au.com.stgeorge.mbank.model.response.services.GlobalWalletActivationResp;
import au.com.stgeorge.mbank.session.MobileSession;
import au.com.stgeorge.mbank.util.FraudLogger;
import au.com.stgeorge.mbank.util.MBAppHelper;
import au.com.stgeorge.mbank.util.MBAppUtils;
import au.com.stgeorge.mbank.util.MBAppValidator;
import au.com.stgeorge.mbank.util.ServiceConstants;
import au.com.stgeorge.mobilebank.businessobject.CardService;
import au.com.stgeorge.mobilebank.businessobject.EStatementsService;
import au.com.stgeorge.mobilebank.businessobject.MatrixMigrationService;
import au.com.stgeorge.perflogger.PerformanceLogger;
import au.com.stgeorge.security.util.StringMethods;
import au.com.stgeorge.ibank.valueobject.AccountFlags;
import au.com.stgeorge.ibank.valueobject.Customer;
import au.com.stgeorge.ibank.valueobject.GlobalCardActivation;
import au.com.stgeorge.ibank.valueobject.Account;
import com.fasterxml.jackson.databind.ObjectMapper;
import au.com.stgeorge.mbank.model.request.ManageEStmtDetailReq;
import au.com.stgeorge.mbank.controller.customer.LogonHelper;

/**
 * @author C50216
 *
 */
@Controller
@RequestMapping("/cards")
public class CardActivationController implements IMBController{

	private FraudLogger fraudLogger;
	
	@Autowired
	private MBAppHelper mbAppHelper;
	
	@Autowired
	private MBAppValidator mbAppValidator;
				
	@Autowired
	private PerformanceLogger perfLogger;
	
	@Autowired
	private CardService mobileCardService;
	
    @Autowired
	private ServiceStation serviceStationService;
    
    @Autowired
	private EStatementsService mobileEStatementService;
	
	@Autowired
    private MatrixMigrationService matrixMigrationService;
	
	@Autowired
	private GlobalWalletService globalWalletService;
	
	@Autowired
	private GlobalWalletServiceHelper gwServiceHelper;
	
	@Autowired
    private LogonHelper logonHelper;
	
	@RequestMapping(value= "activate" , method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public IMBResp processActivateCard(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, 
			@RequestBody final CardActivationReq req){
		
		ObjectMapper objectMapper = new ObjectMapper();							
		perfLogger.startAllLogs();
		String logName = MBAppUtils.getLogName(httpServletRequest);
		perfLogger.startLog(logName);
		
		fraudLogger = new FraudLogger();
		MobileSession mbSession = null;
		try{	
			
			mbSession = mbAppHelper.getMobileSession(httpServletRequest);															
			Logger.info("Card activation JSON Request :" + objectMapper.writeValueAsString(req), this.getClass());
			validateRequestHeader(req.getHeader(), httpServletRequest);
			ErrorResp errorResp = validate(req, httpServletRequest);
			if (errorResp != null && errorResp.getErrors() != null && errorResp.getErrors().size() > 0)
			{				
				//fraudLogger.logInvalidInput();
				return errorResp;
			}
			if (!GeneralMethods.isLuhnCheckDigitValid(req.getCardNumber()))
				throw new BusinessException(BusinessException.INVALID_CARD_NUMBER);
														
			IBankCommonData commonData=mbAppHelper.populateIBankCommonData(mbSession,httpServletRequest);
			
			
			CardActivationResp serviceResponse = new CardActivationResp(); 	
			CardActivation serviceVO = new CardActivation();
			serviceVO.setCardNumber(req.getCardNumber());
			Boolean globalWalletCardActivation = false;
			String cardNumber = req.getCardNumber().trim();
			//19E4 - Check the switch for GlobalWallet and call the GlobalWallet card activation service if the BINs are matching
			if(globalWalletService.isGlobalWalletSwitchOn(commonData.getCustomer().getGcis())){
				//check the BIN numbers 
				String brand = gwServiceHelper.isGlobalWalletCard(cardNumber);
				if(null != brand){
					// This means this is GlobalWallet Card 
					globalWalletCardActivation= true;
					String gcisNumber = mbSession.getCustomer().getGcis().trim();
					// Call the service to activate the card
					GlobalWalletDetails globalWallet = globalWalletService.activateCard(commonData,UUID.randomUUID(), cardNumber, gcisNumber, brand);
					serviceResponse = populateCardActivationResponse(globalWallet, serviceVO);
					RespHeader headerResp = populateResponseHeader(ServiceConstants.CARD_ACTIVATE_SERVICE, mbSession);
					serviceResponse.setHeader(headerResp);
					serviceResponse.setGlobalWalletCard(true);
					serviceVO.setNewCard(true);
					serviceVO.setGwCardBrand(brand);
					serviceResponse.setNewCard(serviceVO.isNewCard());
					mbSession.setCardActivation(serviceVO);// This is required for online PIN change from activation flow
				}
			}
			if(!globalWalletCardActivation)
			{
				mobileCardService.activateCard(serviceVO, commonData);
				
				//if card is activated and matrix migration splash page is present then update the status in DB
				MessageSearch messageSearch = mbSession.getSplashInfoMsg();
				if(messageSearch!=null && isMatrixMigrationSplashMsg(messageSearch)){
					matrixMigrationService.deleteMessage(messageSearch, commonData);
				}
									
				RespHeader headerResp = populateResponseHeader(ServiceConstants.CARD_ACTIVATE_SERVICE, mbSession);
				serviceResponse.setHeader(headerResp);
				serviceResponse.setIsSuccess(true);
				serviceResponse.setNewCard(serviceVO.isNewCard());
				serviceResponse.setCardName(serviceVO.getCardName());
				serviceResponse.setDebit(serviceVO.isDebit());
				if(StringMethods.isValidString(serviceVO.getCardNumber())){
					serviceResponse.setCardNumDisp(StringUtil.formatCCSAccountNumber(serviceVO.getCardNumber()));
				}
				if(!serviceVO.isDebit()){
					
					Account account = CustomerService.getAccount(commonData,serviceVO.getCardNumber());
					serviceResponse.setAccountIndex(account.getIndex());
					
					boolean cardEligibility = mobileEStatementService.isCardEligibleForEstmtOnCardActivation(commonData, serviceVO) ;
					
					if(cardEligibility){
						Logger.debug("isCardEligibleForEstmt true ", this.getClass());
						serviceResponse.setCurrentCardActivationStatus(getCurrentEstmtStatus(commonData, serviceVO.getCardNumber()));
						}
					else{
						serviceResponse.setCurrentCardActivationStatus("NE");
					}
					mbSession.setCustomer(commonData.getCustomer());
					List<au.com.stgeorge.mbank.model.common.AccountResp> accountList = logonHelper.populateAccountList(commonData.getCustomer(),mbSession.getAutoApplyRetentionInfo());
					serviceResponse.setAccounts(accountList);
				}
				//populate service tile irrespective of online PIN Activation switch being ON/OFF and new /reissue
				if(!IBankParams.isOnlinePinActivationSwitchON(mbSession.getOrigin())){
					long insertionPt = mbAppHelper.getInsertionPointCode(ServicetationConstants.CARD_ACTIVATION);
					ServiceStationVO servicestationVO=populateServiceMessage(insertionPt,ServiceStationImpl.CHANNEL_MOBILE, commonData);
					mbAppHelper.populateServiceStationResponse(serviceResponse,servicestationVO);
					
					if(null!=servicestationVO){
						mbSession.setServiceStationMessage(servicestationVO.getServiceStationMsg());
					}
				}
				// Getting the Service Station VO : Service station tile shown only for change card pin only if Online PIn Activation Switch is ON
				if(!serviceVO.isNewCard()){
					long insertionPt = mbAppHelper.getInsertionPointCode(ServicetationConstants.CARD_ACTIVATION);
					ServiceStationVO servicestationVO=populateServiceMessage(insertionPt,ServiceStationImpl.CHANNEL_MOBILE, commonData);
					mbAppHelper.populateServiceStationResponse(serviceResponse,servicestationVO);
					
					if(null!=servicestationVO){
						mbSession.setServiceStationMessage(servicestationVO.getServiceStationMsg());
					}				
				}			
				
				mbSession.setCardActivation(serviceVO);// This is required for online PIN change from activation flow
			}
			Logger.info("Card activation JSON Response :" + objectMapper.writeValueAsString(serviceResponse), this.getClass());
			return serviceResponse;		
		}catch (BusinessException e)
		{			
			IMBResp resp1 = null;
			Logger.info("BusinessException Inside processCardActivate() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());			
			BusinessException exp = new BusinessException(e.getKey());
			if(e.getKey() == BusinessException.CIH_PROCESS_ERROR)
			{
				OriginsVO myOriginVO  = IBankParams.getOrigin(mbSession.getOrigin());
				OriginsVO baseOrigin  = IBankParams.getOrigin(myOriginVO.getBankName());
				String[] values = {baseOrigin.getPhone()};	
				resp1  = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, values, ServiceConstants.CARD_ACTIVATE_SERVICE, httpServletRequest);
			}
			//show a different message when secondary card holder tries to activate the message
			else if(e.getKey() == 80 && IBankParams.isOnlinePinActivationSwitchON(mbSession.getOrigin())){
				BusinessException newSeondaryCardActivation =new BusinessException(BusinessException.SECONDARY_CARD_ACTIVATION_ONLINE_PIN);
				resp1  = MBAppUtils.createErrorResp(mbSession.getOrigin(), newSeondaryCardActivation, ServiceConstants.CARD_ACTIVATE_SERVICE, httpServletRequest);
			}
			else if(e.getKey() == BusinessException.GLOBAL_WALLET_COULD_NOT_PROCESS_REQUEST_ERROR)
			{
				OriginsVO myOriginVO  = IBankParams.getOrigin(mbSession.getOrigin());
				OriginsVO baseOrigin  = IBankParams.getOrigin(myOriginVO.getBankName());
				String[] values = {baseOrigin.getPhone()};	
				resp1  = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, values, ServiceConstants.CARD_ACTIVATE_SERVICE, httpServletRequest);
			}
			else if(e.getKey() == BusinessException.GLOBAL_WALLET_CARD_ALREADYACTIVE || e.getKey() == BusinessException.GLOBAL_WALLET_CARD_ACTIVATIONFAILED)
			{
				OriginsVO myOriginVO  = IBankParams.getOrigin(mbSession.getOrigin());
				OriginsVO baseOrigin  = IBankParams.getOrigin(myOriginVO.getBankName());
				String[] values = {baseOrigin.getPhone()};	
				resp1  = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, values, ServiceConstants.CARD_ACTIVATE_SERVICE, httpServletRequest);
			}
			else{				
				resp1  = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, ServiceConstants.CARD_ACTIVATE_SERVICE, httpServletRequest);
			}
			return resp1;
		}catch (ResourceException e) {
			Logger.error("ResourceException Inside processCardActivate() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			ResourceException exp = new ResourceException(e.getKey());
			IMBResp resp1  = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, ServiceConstants.CARD_ACTIVATE_SERVICE, httpServletRequest);
			return resp1;
		}catch (Exception e)
		{
			Logger.error("Exception Inside processCardActivate() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			BusinessException exp = new BusinessException(BusinessException.GENERIC_ERROR);
			IMBResp resp1  = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, ServiceConstants.CARD_ACTIVATE_SERVICE, httpServletRequest);
			return resp1;
		} finally
		{
			perfLogger.endLog(logName);
			perfLogger.endAllLogs();
		}
		
	}
	
	@RequestMapping(value= "setStmtPreference" , method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public IMBResp processStmtPreferenceRequest(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, 
			@RequestBody final ManageEStmtDetailReq req){
		
		ObjectMapper objectMapper = new ObjectMapper();							
		perfLogger.startAllLogs();
		String logName = MBAppUtils.getLogName(httpServletRequest);
		perfLogger.startLog(logName);
		MobileSession mbSession = null;
		try{	
			
			mbSession = mbAppHelper.getMobileSession(httpServletRequest);															
			Logger.info("processStmtPreferenceRequest during card activation JSON Request :" + objectMapper.writeValueAsString(req), this.getClass());
			validateRequestHeader(req.getHeader(), httpServletRequest);
			ErrorResp errorResp = validate(req, httpServletRequest);
			if (errorResp != null && errorResp.getErrors() != null && errorResp.getErrors().size() > 0)
			{
				return errorResp;
			}
						
			IBankCommonData commonData=mbAppHelper.populateIBankCommonData(mbSession,httpServletRequest);
			
			ArrayList<Account> selectedAcctList = new ArrayList<Account>();
			
		
			CardActivation cardActivation =mbSession.getCardActivation();
			
			Account selectedAccount=CustomerService.getAccount(commonData, cardActivation.getCardNumber());
			selectedAccount.setEstmtAcctStatus(req.getEstmtAcctStatus());
			selectedAcctList.add(selectedAccount);		
			
			boolean estmntStatus=false;
			
			if("E".equalsIgnoreCase(selectedAccount.getEstmtAcctStatus())){				
				estmntStatus=true;
				cardActivation.setAcctStmtPreference("E");
				mobileEStatementService.addStatisticsLog(commonData, cardActivation);
			}else if("S".equalsIgnoreCase(selectedAccount.getEstmtAcctStatus())){
				try{					
					mobileEStatementService.updateMobileSuppressStatementList(commonData,selectedAcctList,commonData.getCustomer());					
					estmntStatus=true;
					cardActivation.setAcctStmtPreference("S");
					mobileEStatementService.addStatisticsLog(commonData, cardActivation);
				}
				catch(Exception e){
					estmntStatus=false;
					Logger.error("Exception in CardActivationController::processStmtPreferenceRequest for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :",e, this.getClass());
					
				}
			}
			
			CardActivationEstmntResponse serviceResponse =populateCardActivationResponse(estmntStatus, mbSession );
			
			return serviceResponse;
		}
		catch (BusinessException e)	{			
			Logger.info("BusinessException Inside processEstmtRequest() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());			
			BusinessException exp = new BusinessException(e.getKey());
			IMBResp resp1  = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, ServiceConstants.CARD_ACTIVATE_SERVICE, httpServletRequest);
			return resp1;
		}catch (ResourceException e) {
			Logger.error("ResourceException Inside processEstmtRequest() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			ResourceException exp = new ResourceException(e.getKey());
			IMBResp resp1  = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, ServiceConstants.CARD_ACTIVATE_SERVICE, httpServletRequest);
			return resp1;
		}catch (Exception e)
		{
			Logger.error("Exception Inside processEstmtRequest() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			BusinessException exp = new BusinessException(BusinessException.GENERIC_ERROR);
			IMBResp resp1  = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, ServiceConstants.CARD_ACTIVATE_SERVICE, httpServletRequest);
			return resp1;
		} finally
		{
			perfLogger.endLog(logName);
			perfLogger.endAllLogs();
		}
	}
	
	private String getCurrentEstmtStatus(IBankCommonData commonData, String cardNumber){
		Customer customer = commonData.getCustomer();
			List<Account> accountList = customer.getAccounts();
			
			
			for (Account account : accountList){
				if(account.getAccountId().getAccountNumber().equalsIgnoreCase(cardNumber)){
				  return mobileEStatementService.getCurrentEstmtPreference(commonData, account);
				}
			}
		Logger.info("getCurrentEstmtStatus() Card Number not found in customer accounts",this.getClass());
		return "NE";
	}
	
	/**
	 * Response for invalid body request 
	 * 
	 * @return
	 */
	@ExceptionHandler({org.springframework.http.converter.HttpMessageNotReadableException.class})
	@ResponseStatus(org.springframework.http.HttpStatus.OK)
	@ResponseBody
	public IMBResp resolveException() {		
		return MBAppUtils.createInvalidMessageBodyResponse(ServiceConstants.CARD_ACTIVATE_SERVICE);
	}
	
	public ErrorResp validate(IMBReq serviceRequest, HttpServletRequest request) {
		return mbAppValidator.validate(serviceRequest, request);
	}
	
	public void validateRequestHeader(ReqHeader header, HttpServletRequest request) throws ResourceException
	{	
		mbAppValidator.validateRequestHeader(header,  request);	
	}
	
	public RespHeader populateResponseHeader(String ServiceName)
	{		
		return mbAppHelper.populateResponseHeader(ServiceName);
	}
	
	public RespHeader populateResponseHeader(String serviceName, MobileSession mobSession )
	{
		return mbAppHelper.populateResponseHeader(serviceName, mobSession);
	}
	
	private ServiceStationVO populateServiceMessage(long insertionPoint,String channel, IBankCommonData commonData)
	{
		ServiceStationVO serviceStationAdminVo=null;
		try
		{
		 serviceStationAdminVo= serviceStationService.getServiceMessage(insertionPoint, ServiceStationImpl.CHANNEL_MOBILE, commonData);			
		}
		 catch(BusinessException ex){
			Logger.error("An error occurred while getting service station message for mobile accoutn details", ex, this.getClass());
		}
		return serviceStationAdminVo;
	}
	
	public CardActivationEstmntResponse populateCardActivationResponse(boolean estmntStatus, MobileSession mobSession  ){
		CardActivationEstmntResponse response = new CardActivationEstmntResponse();
		response.setHeader(populateResponseHeader(ServiceConstants.CARD_ACTIVATE_SERVICE, mobSession ));
		response.setEstmntStatus(estmntStatus);
		return response;
	}
	
	public boolean isMatrixMigrationSplashMsg(MessageSearch messageSearch){			

		if(!MessageCentreConstants.SPLASH_OB_MSG_CODE.equalsIgnoreCase(messageSearch.getMsgType()))
				return false;
		
		if(MessageCentreConstants.MATRIX_FORCE_MIGRATION_MSG_ACTION.equalsIgnoreCase(messageSearch.getMessageAction())){
			return true;
		}
		
		return false;
	}
	
	

	/**Populate the card activation response
	 * 
	 * @param globalWalletDetails
	 * @return CardActivationResp
	 */
	public CardActivationResp populateCardActivationResponse(GlobalWalletDetails globalWalletDetails, CardActivation serviceVO) throws BusinessException{
		CardActivationResp serviceResponse = new CardActivationResp(); 	
		if( null != globalWalletDetails.getActivatedCards() && globalWalletDetails.getActivatedCards().size()>0){
			List<GlobalWalletActivationResp> activatedCardRespList = new ArrayList<>();
			List<GlobalCardActivation> activatedCardListVo = new ArrayList<>();
			for(GlobalWalletActivation globalWalletActivation : globalWalletDetails.getActivatedCards()){
				//20E1 SBGEXP-7950 - Add all cards and their statuses returned from response				
				GlobalWalletActivationResp globalWalletActivationResp = new GlobalWalletActivationResp();
				globalWalletActivationResp.setArrangementId(globalWalletActivation.getArrangementId());
				globalWalletActivationResp.setArrangementIdDisplay(globalWalletActivation.getArrangementIdDisplay());
				globalWalletActivationResp.setArrangementIdSetPINDisplay(StringUtil.formatCompassAccountNumber(globalWalletActivation.getArrangementId()));
				globalWalletActivationResp.setActivationStatus(globalWalletActivation.getActivationStatus());
				activatedCardRespList.add(globalWalletActivationResp);				
				
				//20E1- SBGEXP-7950 - Pass only activated card to set PIN.
				//If both cards are activated, one of the cards can be passed to set PIN.
				if(globalWalletActivation.getActivationStatus().equals(CardsActivationResult.Status.ACTIVATED.toString())) {
					GlobalCardActivation globalCardActivation = new GlobalCardActivation();
					globalCardActivation.setArrangementId(globalWalletActivation.getArrangementId());
					activatedCardListVo.add(globalCardActivation);
					serviceVO.setCardNumber(globalWalletActivation.getArrangementId());
				}
			}
			serviceVO.setGlobalCardActivationList(activatedCardListVo);
			serviceResponse.setCardActivationSuccess(globalWalletDetails.getCardActivationSuccess());
			serviceResponse.setCardAlreadyActive(globalWalletDetails.getCardAlreadyActive());
			serviceResponse.setGlobalWalletActivationResp(activatedCardRespList);
		}else{
			// No cardActivation details in the response
			throw new BusinessException(BusinessException.GLOBAL_WALLET_CARD_ACTIVATION_API_ERROR);
		}
		return serviceResponse;
	}
	
}
