package au.com.stgeorge.mbank.model.request.payments;

import javax.validation.Valid;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

import org.apache.commons.lang.builder.ReflectionToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;
import org.hibernate.validator.constraints.Length;
import org.hibernate.validator.constraints.NotEmpty;

import au.com.stgeorge.ibank.businessobject.BusinessException;
import au.com.stgeorge.mbank.model.common.IMBReq;
import au.com.stgeorge.mbank.model.common.ReqHeader;

/**
 * Transfer request
 * 
 * @author C38854
 * 
 */
public abstract class TransferReq implements IMBReq {

	private static final long serialVersionUID = 6857351976956736514L;
	protected static final String AMT_PATTERN = "^[0-9]*\\.{0,1}(\\d{1,2}){0,1}$";
	protected static final String BLOCK_CHARS_PATTERN = "^[0-9A-Za-z',. &/\\-]*$";
	protected static final String BLOCK_CHARS_PATTERN_ORIGIN = "^[0-9A-Za-z_]*$";
	protected static final String MASK_NUMBERS = "^[0-9]+$";
	
	// @Valid TODO
	private ReqHeader header;

	@NotNull(message = "" + BusinessException.ACCOUNT_NO_FROM_ACCOUNT)
	@Min(value = 0, message="" + BusinessException.GENERIC_ERROR)
	private Integer fromAccountIndex;

	@NotEmpty(message = "{errors.amt.required}")
	@Length(max = 14, message = "{errors.amt.maxlength}")
	@Pattern(regexp = AMT_PATTERN, message = "{errors.amt.blockchar}")
	private String amt;

	@Pattern(regexp = BLOCK_CHARS_PATTERN, message = "{errors.desc.blockchar}")
	@Length(max = 280, message = "{errors.desc.maxlength}")
	private String desc;

	@Valid
	private TransferScheduleReq scheduleDetail;

	private Integer dupCount;

	private Boolean overrideDup;

	private Boolean sendEmail;

	private Long favTranID;

	private Integer scheduleID;
	
	@Pattern(regexp = BLOCK_CHARS_PATTERN_ORIGIN, message = "{errors.desc.blockchar}")
	@Length(max = 50, message = "{errors.desc.maxlength}")
	private String origination;
	
	public Long getFavTranID() {
		return favTranID;
	}

	public Integer getFromAccountIndex() {
		return fromAccountIndex;
	}

	public String getAmt() {
		return amt;
	}

	public String getDesc() {
		return desc;
	}

	public Integer getDupCount() {
		return dupCount;
	}

	public Boolean getSendEmail() {
		return sendEmail;
	}

	public Boolean getOverrideDup() {
		return overrideDup;
	}

	public TransferScheduleReq getScheduleDetail() {
		return scheduleDetail;
	}

	public ReqHeader getHeader() {
		return header;
	}

	public void setHeader(ReqHeader header) {
		this.header = header;
	}
	
	public Integer getScheduleID() {
		return scheduleID;
	}
	
	public String getOrigination() {
		return origination;
	}

	public void setOrigination(String origination) {
		this.origination = origination;
	}

	public void setFromAccountIndex(Integer fromAccountIndex) {
		this.fromAccountIndex = fromAccountIndex;
	}

	public void setAmt(String amt) {
		this.amt = amt;
	}

	public void setScheduleDetail(TransferScheduleReq scheduleDetail) {
		this.scheduleDetail = scheduleDetail;
	}

	public void setSendEmail(Boolean sendEmail) {
		this.sendEmail = sendEmail;
	}

	@Override
	public String toString() {
		return ReflectionToStringBuilder.toString(this, ToStringStyle.MULTI_LINE_STYLE);
	}

}
