package au.com.stgeorge.mbank.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import au.com.stgeorge.digitalsec.logger.DigitalSecLogger;
import au.com.stgeorge.digitalsec.logger.DigitalSecLogggerVO;
import au.com.stgeorge.framework.common.logging.Logger;
import au.com.stgeorge.framework.common.model.User;
import au.com.stgeorge.ibank.businessobject.BusinessException;
import au.com.stgeorge.ibank.businessobject.CustomerService;
import au.com.stgeorge.ibank.businessobject.PRMUpdateService;
import au.com.stgeorge.ibank.businessobject.PreferencesService;
import au.com.stgeorge.ibank.businessobject.ResourceException;
import au.com.stgeorge.ibank.common.cache.IBankParams;
import au.com.stgeorge.ibank.util.ServiceHelper;
import au.com.stgeorge.ibank.valueobject.Customer;
import au.com.stgeorge.ibank.valueobject.Preference;
import au.com.stgeorge.ibank.valueobject.database.CodesVO;
import au.com.stgeorge.ibank.valueobject.mortgage.MortgageCommonData;
import au.com.stgeorge.ibank.valueobject.mortgage.MortgageSessionInfo;
import au.com.stgeorge.ibank.valueobject.transfer.AuthenticationData;
import au.com.stgeorge.ibank.valueobject.transfer.IBankCommonData;
import au.com.stgeorge.mbank.controller.customer.LogonHelper;
import au.com.stgeorge.mbank.controller.mortgage.MortgageHelper;
import au.com.stgeorge.mbank.model.common.IMBReq;
import au.com.stgeorge.mbank.model.common.IMBResp;
import au.com.stgeorge.mbank.model.common.ReqHeader;
import au.com.stgeorge.mbank.model.common.RespHeader;
import au.com.stgeorge.mbank.model.request.customer.LogonReq;
import au.com.stgeorge.mbank.model.request.mortgage.MortgageLogonReq;
import au.com.stgeorge.mbank.model.response.ErrorResp;
import au.com.stgeorge.mbank.session.MobileSession;
import au.com.stgeorge.mbank.util.MBAppConstants;
import au.com.stgeorge.mbank.util.MBAppHelper;
import au.com.stgeorge.mbank.util.MBAppUtils;
import au.com.stgeorge.mbank.util.MBAppValidator;
import au.com.stgeorge.mbank.util.ServiceConstants;
import au.com.stgeorge.mobilebank.businessobject.MobileBankService;
import au.com.stgeorge.perflogger.PerformanceLogger;

import com.fasterxml.jackson.databind.ObjectMapper;

@Controller
@RequestMapping(method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE)
public class ExternalLogonController implements IMBController
{
	private static final String COMPASS_CHANNEL = "IBNK";
	
	private static final String SOURCE_ID = null;

	@Autowired
	private LogonHelper logonHelper;
	
	@Autowired
	private MortgageHelper mortgageHelper;
	
	@Autowired
	private MBAppValidator mbAppValidator;
	
	@Autowired
	private PerformanceLogger perfLogger;
	
	@Autowired
    private DigitalSecLogger digitalSecurityLogger;
	
	@Autowired
	private MBAppHelper mbAppHelper;
	
	@RequestMapping("/externalLogon")
	@ResponseBody
	public IMBResp processExternalLogon(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse,@RequestBody final LogonReq req) throws Exception
	{
		Logger.debug("In processLogon ( ExternalLogonController ) " + httpServletRequest.getContentType() + " "+ httpServletRequest.getRemoteAddr() + "  " + httpServletResponse.getCharacterEncoding() + httpServletResponse.getLocale() +
				" True IP >> " + httpServletRequest.getHeader(IBankParams.trueClientIP()), this.getClass());
		perfLogger.startAllLogs();
		String logName = MBAppUtils.getLogName(httpServletRequest);
		perfLogger.startLog(logName);
		
		AuthenticationData authenticationData = new AuthenticationData();
		DigitalSecLogggerVO digitalSecLoggerVO = new DigitalSecLogggerVO();
		
		ObjectMapper mapper = new ObjectMapper();
		User user = null;
		IBankCommonData ibankCommonData=null;
		
		String origin = null;

		try
		{ 
			boolean isDemo = logonHelper.isDemo();
			if (isDemo)
			{
				origin = (String) httpServletRequest.getSession().getAttribute(LogonHelper.ORIGIN);
				Logger.debug("Demo Origin is : " + httpServletRequest.getSession().getAttribute("origin"), this.getClass());
			}
			else
			{
				origin = logonHelper.resolveOrigin(httpServletRequest);
			}
			httpServletRequest.setAttribute(LogonHelper.ORIGIN, origin);
			
			String gdwOrigin  = logonHelper.getGDWOrigin( req.getHeader(),  origin);
			
			ErrorResp errorResp = validate(req, httpServletRequest);
			if (errorResp != null && errorResp.getErrors() != null && errorResp.getErrors().size() > 0)
			{
				return errorResp;
			}

			String userAgent = httpServletRequest.getHeader("User-Agent");
			Logger.debug("External Logon origin" + origin + ": User-Agent :" + userAgent, this.getClass());

			ibankCommonData = populateIBankCommonData(null, null, origin, MBAppHelper.resolveIPAddress(httpServletRequest, origin), userAgent);
			
			if (logonHelper.isDemo())
			{
			   checkDemoSecurityKey( req.getPassword());	
			}
		
			authenticationData = populateAuthenticationData(req, gdwOrigin, MBAppHelper.resolveIPAddress(httpServletRequest, origin));
			authenticationData.setCompassChannel(COMPASS_CHANNEL);
			user = authenticate(authenticationData, false);
			
			ibankCommonData.setUser(user);
			ibankCommonData.setGdwOrigin(gdwOrigin);
						
			user.setAttribute(IBankParams.USEROBJ_BRAND,origin );
			// Forensic Logs			
			digitalSecLoggerVO.setStatus(DigitalSecLogger.SUCCESS);
			digitalSecLoggerVO.setTranName(DigitalSecLogger.APP_LOGON);
			digitalSecLoggerVO.setValues(logonHelper.toDigitalSecurityLog(req,""));
			digitalSecLoggerVO.setCommonLogData(logonHelper.getCommonLogData(req,ibankCommonData,null));
			digitalSecLoggerVO.setUserAgent(ibankCommonData.getUserAgent());
			digitalSecurityLogger.log(digitalSecLoggerVO);
			
			
			MBAppHelper appHelper = new MBAppHelper();
			authenticationData.setUserAgent(replaceString(httpServletRequest.getHeader("user-agent")));
			authenticationData.setRefWebsite(httpServletRequest.getHeader("referer"));
			appHelper.addSecurityLog(user, authenticationData);

			//mbAppHelper.addTrackingIdCookie(customer.getPreference().getTrackingId(), IBankParams.getBaseOriginCode(ibankCommonData.getOrigin()), httpServletRequest, httpServletResponse);
			//mbAppHelper.addWebAnalyticsCookis(IBankParams.getBaseOriginCode(ibankCommonData.getOrigin()), httpServletRequest, httpServletResponse);

			sendLogonPRMMessage(authenticationData, ibankCommonData, user, IBankParams.PRM_LOGON_SUCCESS);
			
			
			IMBResp serviceResponse = logonHelper.populateExternalLogonResponse(user, httpServletRequest, httpServletResponse);
															
			Logger.info("External logon JSON Response :" + mapper.writeValueAsString(serviceResponse), this.getClass());
			RespHeader headerResp = populateResponseHeader(ServiceConstants.EXTERNAL_LOGON_RESPONSE, null );
			serviceResponse.setHeader(headerResp);			
			
			return serviceResponse;

		} catch (BusinessException e)
		{			
		
			Logger.error("BusinessException Inside ExternalLogonController processLogon() " + e.getKey() , e, this.getClass());
			
			digitalSecLoggerVO.setStatus(DigitalSecLogger.FAILURE);
			digitalSecLoggerVO.setTranName(DigitalSecLogger.APP_LOGON);
			digitalSecLoggerVO.setValues(logonHelper.toDigitalSecurityLog(req,""));
			digitalSecLoggerVO.setCommonLogData(logonHelper.getCommonLogData(req,ibankCommonData,null));
			digitalSecLoggerVO.setUserAgent(ibankCommonData.getUserAgent());
			digitalSecurityLogger.log(digitalSecLoggerVO);
						
			String errorMessage = MBAppUtils.getMessage(origin, e.getKey());
			
			return MBAppUtils.createErrorResp(origin, e.getKey(), errorMessage, ServiceConstants.EXTERNAL_LOGON_RESPONSE, httpServletRequest);
		} catch (Exception e)
		{
			Logger.error("Exception Inside ExternalLogonController processLogon() ", e, this.getClass());
			BusinessException exp = new BusinessException(BusinessException.SMPL_SYS_ERROR);
			
			return MBAppUtils.createErrorResp(origin, exp, ServiceConstants.EXTERNAL_LOGON_RESPONSE, httpServletRequest);
		} finally
		{
			perfLogger.endLog(logName);
			perfLogger.endAllLogs();
		}

	}

	@RequestMapping("/mortgageLogon")
	@ResponseBody
	public IMBResp processMortgageLogon(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse,@RequestBody final MortgageLogonReq req)
	{
		Logger.debug("In processLogon ( ExternalLogonController ) " + httpServletRequest.getContentType() + " "+ httpServletRequest.getRemoteAddr() + "  " + httpServletResponse.getCharacterEncoding() + httpServletResponse.getLocale() +
				" True IP >> " + httpServletRequest.getHeader(IBankParams.trueClientIP()), this.getClass());
		perfLogger.startAllLogs();
		String logName = MBAppUtils.getLogName(httpServletRequest);
		perfLogger.startLog(logName);
		
		AuthenticationData authenticationData = new AuthenticationData();
		DigitalSecLogggerVO digitalSecLoggerVO = new DigitalSecLogggerVO();
		ObjectMapper mapper = new ObjectMapper();
		User user = null;
		IBankCommonData ibankCommonData=null;
		MobileSession mobileSession = null;
		String origin = null;

		try
		{ 
			mobileSession = mbAppHelper.getMobileSession(httpServletRequest);
			origin = mobileSession.getOrigin();
			
			String gdwOrigin  = mortgageHelper.getGDWOrigin(req.getHeader(),origin);
			
			ErrorResp errorResp = validate(req, httpServletRequest);
			if (errorResp != null && errorResp.getErrors() != null && errorResp.getErrors().size() > 0)
			{
				return errorResp;
			}

			String userAgent = httpServletRequest.getHeader("User-Agent");

			ibankCommonData = populateIBankCommonData(mobileSession.getSessionID(), null, origin, MBAppHelper.resolveIPAddress(httpServletRequest, origin), userAgent);
		
			if (logonHelper.isDemo())
			{
			   checkDemoSecurityKey( req.getLogonReq().getPassword());	
			}
		
			authenticationData = populateAuthenticationData(req.getLogonReq(), gdwOrigin, MBAppHelper.resolveIPAddress(httpServletRequest, origin));
			authenticationData.setCompassChannel(COMPASS_CHANNEL);
			
			try{
				user = authenticate(authenticationData, false);
				mobileSession.setUser(user);
			}catch (BusinessException e)
			{			
				Logger.error("BusinessException Inside ExternalLogonController processLogon() " + e.getKey() , e, this.getClass());
				
				digitalSecLoggerVO.setStatus(DigitalSecLogger.FAILURE);
				digitalSecLoggerVO.setTranName(DigitalSecLogger.HL_APP_LOGON);
				digitalSecLoggerVO.setValues(logonHelper.toDigitalSecurityLog(req.getLogonReq(),""));
				digitalSecLoggerVO.setCommonLogData(logonHelper.getCommonLogData(req.getLogonReq(),ibankCommonData,null));
				digitalSecLoggerVO.setUserAgent(ibankCommonData.getUserAgent());
				digitalSecurityLogger.log(digitalSecLoggerVO);
				
				throw e;
			}
			
			ibankCommonData.setUser(user);
			ibankCommonData.setGdwOrigin(gdwOrigin);
						
			user.setAttribute(IBankParams.USEROBJ_BRAND,origin );
			
			// Forensic Logs			
			digitalSecLoggerVO.setStatus(DigitalSecLogger.SUCCESS);
			digitalSecLoggerVO.setTranName(DigitalSecLogger.HL_APP_LOGON);
			digitalSecLoggerVO.setValues(logonHelper.toDigitalSecurityLog(req.getLogonReq(),""));
			digitalSecLoggerVO.setCommonLogData(logonHelper.getCommonLogData(req.getLogonReq(),ibankCommonData,null));
			digitalSecLoggerVO.setUserAgent(ibankCommonData.getUserAgent());
			digitalSecurityLogger.log(digitalSecLoggerVO);
			
			sendLogonPRMMessage(authenticationData, ibankCommonData, user, IBankParams.PRM_LOGON_SUCCESS);
			
			MBAppHelper appHelper = new MBAppHelper();
			authenticationData.setUserAgent(replaceString(httpServletRequest.getHeader("user-agent")));
			authenticationData.setRefWebsite(httpServletRequest.getHeader("referer"));
			appHelper.addSecurityLog(user, authenticationData);

			Customer customer = CustomerService.getGHSCustomerWithoutAccountList(user.getGCISNumber(), origin, SOURCE_ID);
			
			MortgageCommonData mortgageCommonData = mortgageHelper.populateMortgageCommonData(mobileSession, req.getHeader(), httpServletRequest);
					
			IMBResp serviceResponse=mortgageHelper.populateLogonResponse(customer,mobileSession.getMortgageSessionInfo(), req, mortgageCommonData);
			
			Logger.info("External logon JSON Response :" + mapper.writeValueAsString(serviceResponse), this.getClass());
			
			Preference myPreference = PreferencesService.getPreferenceForMobileBank(user);
			
			mbAppHelper.addTrackingIdCookie(myPreference.getTrackingId(), IBankParams.getBaseOriginCode(ibankCommonData.getOrigin()), httpServletRequest, httpServletResponse);
			mbAppHelper.addWebAnalyticsCookis(IBankParams.getBaseOriginCode(ibankCommonData.getOrigin()), httpServletRequest, httpServletResponse);
			
			RespHeader headerResp = populateResponseHeader(ServiceConstants.EXTERNAL_LOGON_RESPONSE, mobileSession );
			serviceResponse.setHeader(headerResp);			
			
			return serviceResponse;
		} catch (BusinessException e)
		{			
			Logger.error("BusinessException Inside ExternalLogonController processLogon() " + e.getKey() , e, this.getClass());
			
			if(e.getKey()==BusinessException.MORTGAGE_MAX_APPLICATION_REACHED) {
        		return mortgageHelper.populateMortgageErrorResponse(origin,e,httpServletRequest);
			}
			
			String errorMessage = MBAppUtils.getMessage(origin, e.getKey());
			
			return MBAppUtils.createErrorResp(origin, e.getKey(), errorMessage, ServiceConstants.EXTERNAL_LOGON_RESPONSE, httpServletRequest);
		} catch (Exception e)
		{
			Logger.error("Exception Inside ExternalLogonController processLogon() ", e, this.getClass());
			BusinessException exp = new BusinessException(BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE);
			
			return MBAppUtils.createErrorResp(origin, exp, ServiceConstants.EXTERNAL_LOGON_RESPONSE, httpServletRequest);
		} finally
		{
        	perfLogger.endLog(logName);
			perfLogger.endAllLogs();
		}
	}
	
	@RequestMapping("/mortgageLogonSecondary")
	@ResponseBody
	public IMBResp processMortgageLogonSecondary(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse,@RequestBody final MortgageLogonReq req)
	{
		Logger.debug("In processLogon ( ExternalLogonController ) " + httpServletRequest.getContentType() + " "+ httpServletRequest.getRemoteAddr() + "  " + httpServletResponse.getCharacterEncoding() + httpServletResponse.getLocale() +
				" True IP >> " + httpServletRequest.getHeader(IBankParams.trueClientIP()), this.getClass());
		perfLogger.startAllLogs();
		String logName = MBAppUtils.getLogName(httpServletRequest);
		perfLogger.startLog(logName);
		
		AuthenticationData authenticationData = new AuthenticationData();
		DigitalSecLogggerVO digitalSecLoggerVO = new DigitalSecLogggerVO();
		ObjectMapper mapper = new ObjectMapper();
		User user = null;
		IBankCommonData ibankCommonData=null;
		
		String origin = null;
		MortgageSessionInfo mortgageSessionInfo = null;
		try
		{ 
			MobileSession mobileSession = mbAppHelper.getMobileSession(httpServletRequest);
			if(mobileSession == null || mobileSession.getMortgageSessionInfo() == null){
				throw new BusinessException(BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE);
			}
			mortgageSessionInfo = mobileSession.getMortgageSessionInfo();
			origin = mortgageSessionInfo.getOrigin();
			
			String gdwOrigin  = mortgageHelper.getGDWOrigin(req.getHeader(),origin);
			
			ErrorResp errorResp = validate(req, httpServletRequest);
			if (errorResp != null && errorResp.getErrors() != null && errorResp.getErrors().size() > 0)
			{
				return errorResp;
			}

			String userAgent = httpServletRequest.getHeader("User-Agent");
			Logger.debug("External Logon origin" + origin + ": User-Agent :" + userAgent, this.getClass());

			ibankCommonData = populateIBankCommonData(mobileSession.getSessionID(), null, origin, MBAppHelper.resolveIPAddress(httpServletRequest, origin), userAgent);
		
			if (logonHelper.isDemo())
			{
			   checkDemoSecurityKey( req.getLogonReq().getPassword());	
			}
		
			authenticationData = populateAuthenticationData(req.getLogonReq(), gdwOrigin, MBAppHelper.resolveIPAddress(httpServletRequest, origin));
			authenticationData.setCompassChannel(COMPASS_CHANNEL);
			try{
				user = authenticate(authenticationData, false);
			}catch (BusinessException e)
			{
				Logger.error("BusinessException Inside ExternalLogonController processLogon() " + e.getKey() , e, this.getClass());
				
				digitalSecLoggerVO.setStatus(DigitalSecLogger.FAILURE);
				digitalSecLoggerVO.setTranName(DigitalSecLogger.HL_APP_LOGON);
				digitalSecLoggerVO.setValues(logonHelper.toDigitalSecurityLog(req.getLogonReq(),""));
				digitalSecLoggerVO.setCommonLogData(logonHelper.getCommonLogData(req.getLogonReq(),ibankCommonData,null));
				digitalSecLoggerVO.setUserAgent(ibankCommonData.getUserAgent());
				digitalSecurityLogger.log(digitalSecLoggerVO);
				
				throw e;
			}
			
			ibankCommonData.setUser(user);
			ibankCommonData.setGdwOrigin(gdwOrigin);
						
			user.setAttribute(IBankParams.USEROBJ_BRAND,origin );
			
			// Forensic Logs			
			digitalSecLoggerVO.setStatus(DigitalSecLogger.SUCCESS);
			digitalSecLoggerVO.setTranName(DigitalSecLogger.HL_APP_LOGON);
			digitalSecLoggerVO.setValues(logonHelper.toDigitalSecurityLog(req.getLogonReq(),""));
			digitalSecLoggerVO.setCommonLogData(logonHelper.getCommonLogData(req.getLogonReq(),ibankCommonData,null));
			digitalSecLoggerVO.setUserAgent(ibankCommonData.getUserAgent());
			digitalSecurityLogger.log(digitalSecLoggerVO);
			
			sendLogonPRMMessage(authenticationData, ibankCommonData, user, IBankParams.PRM_LOGON_SUCCESS);
			
			MBAppHelper appHelper = new MBAppHelper();
			authenticationData.setUserAgent(replaceString(httpServletRequest.getHeader("user-agent")));
			authenticationData.setRefWebsite(httpServletRequest.getHeader("referer"));
			appHelper.addSecurityLog(user, authenticationData);

			mortgageHelper.validateSecondaryApplicatLogin(mortgageSessionInfo, user);
			
			Customer customer = CustomerService.getGHSCustomerWithoutAccountList(user.getGCISNumber(), origin, SOURCE_ID);
			
			MortgageCommonData mortgageCommonData = mortgageHelper.populateMortgageCommonData(  mobileSession , req.getHeader(),   httpServletRequest );
			
			IMBResp serviceResponse=mortgageHelper.populateSecondaryLogonResponse(customer,mortgageSessionInfo, req, mobileSession, mortgageCommonData, ibankCommonData, req.getHeader());
			
			Logger.info("External logon JSON Response :" + mapper.writeValueAsString(serviceResponse), this.getClass());
			
			RespHeader headerResp = populateResponseHeader(ServiceConstants.EXTERNAL_LOGON_RESPONSE, mobileSession );
			serviceResponse.setHeader(headerResp);			
			
			return serviceResponse;

		} catch (BusinessException e)
		{			
			if(mortgageSessionInfo != null && mortgageSessionInfo.getApplication().getApplicants().size() > 1){
				mortgageSessionInfo.getApplication().getApplicants().remove(1);//Remove the second applicant
			}
			Logger.error("BusinessException Inside ExternalLogonController processLogon() " + e.getKey() , e, this.getClass());
			
			if(e.getKey()==BusinessException.MORTGAGE_MAX_APPLICATION_REACHED) {
        		return mortgageHelper.populateMortgageErrorResponse(origin,e,httpServletRequest);
			}
			
			String errorMessage = MBAppUtils.getMessage(origin, e.getKey());
			
			return MBAppUtils.createErrorResp(origin, e.getKey(), errorMessage, ServiceConstants.EXTERNAL_LOGON_RESPONSE, httpServletRequest);
		} catch (Exception e)
		{
			if(mortgageSessionInfo != null && mortgageSessionInfo.getApplication().getApplicants().size() > 1){
				mortgageSessionInfo.getApplication().getApplicants().remove(1);//Remove the second applicant
			}
			Logger.error("Exception Inside ExternalLogonController processLogon() ", e, this.getClass());
			BusinessException exp = new BusinessException(BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE);
			
			return MBAppUtils.createErrorResp(origin, exp, ServiceConstants.EXTERNAL_LOGON_RESPONSE, httpServletRequest);
		} finally
		{
			perfLogger.endLog(logName);
			perfLogger.endAllLogs();
		}
	}
	
	private AuthenticationData populateAuthenticationData(LogonReq req, String origin, String ipAddress)
	{
		AuthenticationData authenticationData = new AuthenticationData();
		authenticationData.setUserId(req.getAccessNumber());
		authenticationData.setIssueNumber(req.getIssueNumber());
		authenticationData.setPassword(req.getPassword());
		authenticationData.setSecurityNumber(req.getSecurityNumber());
		authenticationData.setOrigin(origin);
		authenticationData.setIpAddress(ipAddress);
		return authenticationData;
	}
	
	private User authenticate(AuthenticationData authenticationData, boolean skipSecNum) throws BusinessException, ResourceException
	{
		MobileBankService mobileBankService = (MobileBankService) ServiceHelper.getBean(MBAppConstants.SPRING_MOBILE_SERVICE_BEAN);
		return mobileBankService.authenticateRegisteredCustomer(authenticationData);
	}
	
	private IBankCommonData populateIBankCommonData(String sessionId, User user, String origin, String ipAddress ,String userAgent)
	{
		IBankCommonData commonData = new IBankCommonData();
		commonData.setUser(user);
		commonData.setOrigin(origin);
		commonData.setIpAddress(ipAddress);
		commonData.setSessionId(sessionId);
		commonData.setUserAgent(userAgent);
		return commonData;
	}

	private void sendLogonPRMMessage(AuthenticationData authData, IBankCommonData commonData, User myUser, String desc)
	{
		Logger.info("sendLogonPRMMessage - start " + myUser + ":" + authData + ":" + commonData, ExternalLogonController.class);
		Logger.info("myUser:: " + myUser, ExternalLogonController.class);
		PRMUpdateService prmService = (PRMUpdateService) ServiceHelper.getBean("prmServiceBean");
		prmService.sendPRMLogon(authData, commonData, myUser, desc);

		Logger.info("sendLogonPRMMessage - end", ExternalLogonController.class);
	}

	private String replaceString(String userAgent)
	{
		String data = userAgent;
		data = data.replaceAll("&", "&amp;");
		data = data.replaceAll("<", "&lt;");
		data = data.replaceAll(">", "&gt;");
		data = data.replaceAll("'", "&apos;");
		data = data.replaceAll("\"", "&quot;");
		return data;
	}

	public ErrorResp validate(IMBReq serviceRequest, HttpServletRequest request) {
		return mbAppValidator.validate(serviceRequest, request);
	}
	
	public void validateRequestHeader(ReqHeader header, HttpServletRequest request) throws ResourceException
	{
		// Nothing to do in case of logon as Session is not created. Session is
		// created after only successful logon
		mbAppValidator.validateRequestHeader(header,  request);

	}

	public RespHeader populateResponseHeader(String serviceName, MobileSession mobileSession )
	{
		return mbAppHelper.populateResponseHeader(serviceName, mobileSession);
		
	}
	
	private static final String MB_DEMO_SECURITY_KEY = "mbDemoSecurityKey";

	public void checkDemoSecurityKey(String securityKey) throws ResourceException, BusinessException{

		CodesVO code = IBankParams.getCodesData(IBankParams.BRAND_ORIGIN, IBankParams.CONFIGURATION_PROPERTIES, MB_DEMO_SECURITY_KEY);
		if (code == null){
			Logger.error("checkDemoSecurityKey: MB_DEMO_SECURITY_KEY is missing from DB" , this.getClass());
			throw new ResourceException(ResourceException.SYSTEM_ERROR,"MB_DEMO_SECURITY_KEY is missing from DB");
		}else{
			if(!securityKey.equals(code.getMessage())){
				throw new BusinessException(BusinessException.INVALID_USERID_PASSWORD);
			}

		}

	}
}
