package au.com.stgeorge.mbank.model.request.mortgage;

import java.io.Serializable;

import au.com.stgeorge.mbank.model.common.IMBReq;
import au.com.stgeorge.mbank.model.common.ReqHeader;

public class PropertyInsightReq implements IMBReq, Serializable {
	private static final long serialVersionUID = -2334701650351329205L;
	private ReqHeader header;
	private Boolean manualAddress;
	private String qasAddressID;
	private Boolean idCallSuccess;
    private Boolean detailCallSuccess;
	
	public ReqHeader getHeader() {
		return header;
	}
	public void setHeader(ReqHeader header) {
		this.header = header;
	}

	public Boolean getManualAddress() {
		return manualAddress;
	}
	public void setManualAddress(Boolean manualAddress) {
		this.manualAddress = manualAddress;
	}
	public String getQasAddressID() {
		return qasAddressID;
	}
	public void setQasAddressID(String qasAddressID) {
		this.qasAddressID = qasAddressID;
	}
	public Boolean getIdCallSuccess() {
		return idCallSuccess;
	}
	public void setIdCallSuccess(Boolean idCallSuccess) {
		this.idCallSuccess = idCallSuccess;
	}
	public Boolean getDetailCallSuccess() {
		return detailCallSuccess;
	}
	public void setDetailCallSuccess(Boolean detailCallSuccess) {
		this.detailCallSuccess = detailCallSuccess;
	}
	
}
