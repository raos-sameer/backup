package au.com.stgeorge.mbank.model.mortgageinfo;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_NULL)
public class DashboardInfo {
	private boolean personalDetailsStatusInd;
	private boolean loanTypeStatusInd;
	private boolean incomeStatusInd;
	private boolean expenseStatusInd;
	private boolean liabilityStatusInd;
	private boolean assetStatusInd;

	public boolean isPersonalDetailsStatusInd() {
		return personalDetailsStatusInd;
	}

	public void setPersonalDetailsStatusInd(boolean personalDetailsStatusInd) {
		this.personalDetailsStatusInd = personalDetailsStatusInd;
	}

	public boolean isLoanTypeStatusInd() {
		return loanTypeStatusInd;
	}

	public void setLoanTypeStatusInd(boolean loanTypeStatusInd) {
		this.loanTypeStatusInd = loanTypeStatusInd;
	}

	public boolean isIncomeStatusInd() {
		return incomeStatusInd;
	}

	public void setIncomeStatusInd(boolean incomeStatusInd) {
		this.incomeStatusInd = incomeStatusInd;
	}

	public boolean isExpenseStatusInd() {
		return expenseStatusInd;
	}

	public void setExpenseStatusInd(boolean expenseStatusInd) {
		this.expenseStatusInd = expenseStatusInd;
	}

	public boolean isLiabilityStatusInd() {
		return liabilityStatusInd;
	}

	public void setLiabilityStatusInd(boolean liabilityStatusInd) {
		this.liabilityStatusInd = liabilityStatusInd;
	}

	public boolean isAssetStatusInd() {
		return assetStatusInd;
	}

	public void setAssetStatusInd(boolean assetStatusInd) {
		this.assetStatusInd = assetStatusInd;
	}

}
