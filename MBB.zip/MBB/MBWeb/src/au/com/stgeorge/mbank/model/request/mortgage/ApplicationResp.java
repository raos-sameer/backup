package au.com.stgeorge.mbank.model.request.mortgage;

import java.util.List;

import au.com.stgeorge.mbank.model.common.ErrorInfo;
import au.com.stgeorge.mbank.model.common.IMBResp;
import au.com.stgeorge.mbank.model.common.RespHeader;
import au.com.stgeorge.mbank.model.mortgageinfo.ApplicationInfo;

public class ApplicationResp implements IMBResp {
	private static final long serialVersionUID = 1L;

	private boolean success;

	private RespHeader header;

	private List<ErrorInfo> errors;

	private ApplicationInfo app;
	
	private String applicationNum;
	
	private String status; 

	public boolean isSuccess() {
		return success;
	}

	public void setSuccess(boolean success) {
		this.success = success;
	}

	public RespHeader getHeader() {
		return header;
	}

	public void setHeader(RespHeader header) {
		this.header = header;
	}

	public List<ErrorInfo> getErrors() {
		return errors;
	}

	public void setErrors(List<ErrorInfo> errors) {
		this.errors = errors;
	}

	public ApplicationInfo getApp() {
		return app;
	}

	public void setApp(ApplicationInfo app) {
		this.app = app;
	}

	public String getApplicationNum() {
		return applicationNum;
	}

	public void setApplicationNum(String applicationNum) {
		this.applicationNum = applicationNum;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}
	
	

}
