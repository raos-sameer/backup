package au.com.stgeorge.mbank.model.request.payments;

import java.io.Serializable;

import javax.validation.constraints.NotNull;

import org.apache.commons.lang.builder.ReflectionToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;
import org.hibernate.validator.constraints.NotEmpty;

import au.com.stgeorge.mbank.util.JsonDateSerializer;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;

/**
 * Transfer schedule
 * 
 * @author C38854
 * 
 */
public class TransferScheduleReq implements Serializable {
	private static final long serialVersionUID = -2290300454035750499L;

	@NotEmpty(message = "{errors.frequency.required}")
	private String freq;

	@NotNull(message = "{errors.firstPayDate.required}")
	private String firstPayDate;

	@JsonSerialize(using = JsonDateSerializer.class)
	private String lastPayDate;
	
	@JsonSerialize(using = JsonDateSerializer.class)
	private Boolean recreate;
	

	public Boolean getRecreate() {
		return recreate;
	}

	public void setRecreate(Boolean recreate) {
		this.recreate = recreate;
	}

	public String getFreq() {
		return freq;
	}

	public String getFirstPayDate() {
		return firstPayDate;
	}

	public void setFirstPayDate(String firstPayDate) {
		this.firstPayDate = firstPayDate;
	}

	public String getLastPayDate() {
		return lastPayDate;
	}

	public void setLastPayDate(String lastPayDate) {
		this.lastPayDate = lastPayDate;
	}

	@Override
	public String toString() {
		return ReflectionToStringBuilder.toString(this, ToStringStyle.MULTI_LINE_STYLE);
	}

}
