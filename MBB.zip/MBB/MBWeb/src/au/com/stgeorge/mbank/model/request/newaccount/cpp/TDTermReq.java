package au.com.stgeorge.mbank.model.request.newaccount.cpp;

import java.io.Serializable;

import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.NotEmpty;

import au.com.stgeorge.ibank.businessobject.BusinessException;
import au.com.stgeorge.mbank.model.common.IMBReq;
import au.com.stgeorge.mbank.model.common.ReqHeader;

public class TDTermReq implements IMBReq, Serializable{

	private static final long serialVersionUID = 3329640008827767983L;
	
	private static final String NUMBER_PATTERN = "^[0-9]*$";

    private ReqHeader header;
    
    @NotEmpty(message = "{errors.term.required}")
    @Pattern(regexp = NUMBER_PATTERN, message = "" + BusinessException.CPP_TD_INVALID_TERM)
	private String tdTerm;
    
    private Boolean isRenew;
			
	public String getTdTerm() {
		return tdTerm;
	}

	public void setTdTerm(String tdTerm) {
		this.tdTerm = tdTerm;
	}

	@Override
	public ReqHeader getHeader() {
		return header;
	}

	@Override
	public void setHeader(ReqHeader header) {
		this.header = header;
	}

	public Boolean getIsRenew() {
		return isRenew;
	}

	public void setIsRenew(Boolean isRenew) {
		this.isRenew = isRenew;
	}

}
