package au.com.stgeorge.mbank.controller;

import java.net.URLEncoder;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.regex.Pattern;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.AbstractController;

import au.com.stgeorge.framework.common.logging.Logger;
import au.com.stgeorge.ibank.businessobject.BTAccountsService;
import au.com.stgeorge.ibank.businessobject.BusinessException;
import au.com.stgeorge.ibank.businessobject.CustomerService;
import au.com.stgeorge.ibank.businessobject.EncryptionDigestService;
import au.com.stgeorge.ibank.businessobject.OfferService;
import au.com.stgeorge.ibank.businessobject.ResourceException;
import au.com.stgeorge.ibank.businessobject.ServiceTokenService;
import au.com.stgeorge.ibank.businessobject.StatisticsService;
import au.com.stgeorge.ibank.common.cache.IBankParams;
import au.com.stgeorge.ibank.common.log.IBankLog;
import au.com.stgeorge.ibank.util.ServiceHelper;
import au.com.stgeorge.ibank.valueobject.ExternalLinkVO;
import au.com.stgeorge.ibank.valueobject.LabelValueVO;
import au.com.stgeorge.ibank.valueobject.Statistic;
import au.com.stgeorge.ibank.valueobject.database.CodesVO;
import au.com.stgeorge.ibank.valueobject.database.ServiceTokenVO;
import au.com.stgeorge.ibank.valueobject.transfer.IBankCommonData;
import au.com.stgeorge.mbank.controller.customer.LogonHelper;
import au.com.stgeorge.mbank.session.MobileSession;
import au.com.stgeorge.mbank.util.MBAppHelper;
import au.com.stgeorge.mbank.util.MBAppUtils;
import au.com.stgeorge.mobilebank.businessobject.ExternalLinkService;
import au.com.stgeorge.mobilebank.businessobject.impl.ExternalLinkServiceImpl;
import au.com.stgeorge.mobilebank.businessobject.impl.ExternalLinkServiceImpl.NewCRAProductsEnum;
import au.com.stgeorge.perflogger.PerformanceLogger;
import au.com.stgeorge.security.util.StringMethods;

public class ExternalAppController extends AbstractController
{

	public static final String REQ_WDP_LOGOUT = "wdpLogout";
	public static final String REQ_ACTION_STR = "action";
	public static final String REQ_NEW_ACCOUNT_STR = "newaccount";
	
	public static final String REQ_APPLY_HOME_LOAN_BROWSER = "applyHomeLoan";
	
	public static final String REQ_APPLY_HOME_LOAN_NATIVE_APP = "applyHomeLoanNative";
	
	public static final String REQ_BT_SERVICING_STR = "bts";
	public static final String REQ_BT_SEARCH_STR = "btSuperSearch";

	public static final String REQ_ACCOUNT_INDEX_STR = "index";
	
	public static final String REQ_CATEGORY_STR = "category";
	private static final String REQ_CREDIT_CARD =  "CREDIT CARDS" ;
	private static final String REQ_PERSONAL_LOAN = "PERSONAL LOANS";
	
	public static final String REQ_PRODUCTID_STR = "productId";
	
	public static final String ACTION_TYPE_MORTGAGE_EXISTING_CUSTOMER_RETRIEVE = "retrieveExisting";
	
	
	public static final String ACE_SEARCH_STRING= "ACE|Account|MBank|Apply for Credit Card";
	public static final String PL_SEARCH_STRING="ACE|Account|MBank|Apply for Loans";
	private static final String REGEX_PATTERN = "^[0-9A-Za-z',. &/\\-]*$";
	
	@Autowired
	private MBAppHelper mbAppHelper;
	
	@Autowired
	private BTAccountsService btAccService;

	@Autowired
	private OfferService offerService;
	
	@Override
	protected ModelAndView handleRequestInternal(HttpServletRequest request, HttpServletResponse response) throws Exception
	{
		PerformanceLogger performanceLogger = new PerformanceLogger();
		performanceLogger.startAllLogs();
		String logName = MBAppUtils.getLogName(request);
		performanceLogger.startLog(logName);
		ModelAndView model = null;
		String origin = null;
		String url = null;
		MobileSession mbSession = mbAppHelper.getMobileSession(request);	
		IBankCommonData commonData=mbAppHelper.populateIBankCommonData(mbSession,request);
		try
		{
			
			String action = request.getParameter(REQ_ACTION_STR);
			Logger.info("Processing Request for action : " + action , this.getClass());

			if("MGRPDummy".equalsIgnoreCase(action)) {
				model = new ModelAndView("MGRP");
				model.addObject("targetUrl", "/mb/jsp/MGRP.jsp");
				CodesVO vo = IBankParams.getCodesData(commonData.getOrigin(), IBankParams.CATEGORY_MGRP, IBankParams.CODE_CREDENTIALS);
				model.addObject(IBankParams.CODE_CREDENTIALS, vo.getMessage());
				return model;
			}
			
			if(REQ_WDP_LOGOUT.equalsIgnoreCase(action)) {
				model = new ModelAndView("BTServicing");
				model.addObject("targetUrl", "/mb/jsp/logout.jsp");
				return model;
			}
			
			if( REQ_APPLY_HOME_LOAN_NATIVE_APP.equalsIgnoreCase(action))
			{
				model = processNativeAppHomeLoanRequest(request);
				return model;
			}
			
	
			origin = mbSession.getOrigin();

			String category = request.getParameter(REQ_CATEGORY_STR);
			String productID = request.getParameter(REQ_PRODUCTID_STR);
			
			if( REQ_APPLY_HOME_LOAN_BROWSER.equalsIgnoreCase(action))
			{

				model = processHomeLoanSRequest(commonData.getCustomer().getGcis(), "", origin) ;
				
				ExternalLinkService extService = ServiceHelper.getBean("externalLinkService");
				extService.createLogStatistics(commonData, true, "CLASWeb|Account|Apply for Home Loan");

				mbSession.invalidateSession();
				return model;
			}
			else if( REQ_NEW_ACCOUNT_STR.equalsIgnoreCase(action))
			{
				NewCRAProductsEnum craProdEnum = NewCRAProductsEnum.valueOf(productID.trim());
				String subProdCode = craProdEnum.getSubProdCode();

				url = getACEUurl(commonData, subProdCode,  category);
				Logger.info( " External URL " + url, this.getClass() );
//				request.getRequestDispatcher("https://stgeorge.com.au/").forward(request, response);
				response.sendRedirect(url);
				mbSession.invalidateSession();
			}
			else if(REQ_BT_SERVICING_STR.equalsIgnoreCase(action))
			{
				String accountIndex = request.getParameter(REQ_ACCOUNT_INDEX_STR);
				String signedToken = btAccService.getSignedJWTForBT(commonData, Integer.valueOf(accountIndex), null);
				//System.out.println("signed token:: " + signedToken);
				CodesVO vo = IBankParams.getCodesData(commonData.getOrigin(), IBankParams.EXTERNAL_LINKS, 
						BTAccountsService.BT_APPLICATION_URL);
				//System.out.println("VO:: " + vo);
				model = new ModelAndView("BTServicing");
				model.addObject("id_token", signedToken);
				model.addObject("targetUrl", vo.getMessage());
				
				return model;
			}
			else if(BTAccountsService.BT_SUPER_SEARCH.equalsIgnoreCase(action))
			{
				
				
				Object obj = request.getParameter("reqFrom" );
				String reqFrom =  "";
				if ( obj != null )
				{
					reqFrom = ( String) obj;
					
					if ( ! StringMethods.isEmptyString(reqFrom))
					{
						MBAppUtils mbAppUtils = new MBAppUtils();
		  			boolean isValidData = mbAppUtils.validateDataUsingRegEx(reqFrom, REGEX_PATTERN);
		  			if ( ! isValidData )
		  			{
		  				origin = "MSTG";
		  				request.setAttribute(LogonHelper.ORIGIN, origin);
		  				model = new ModelAndView("Error");
		  				Logger.error("Invalid lead Id " +  reqFrom , this.getClass());
		  				return model;
		  			}
					}
				}

				String signedToken = btAccService.getSignedJWTForBTSuperSearch(commonData, true, reqFrom);
				//System.out.println("signed token:: " + signedToken);
				CodesVO vo = IBankParams.getCodesData(commonData.getOrigin(), IBankParams.EXTERNAL_LINKS, BTAccountsService.BT_WEALTH_SEARCH_URL);
				//System.out.println("VO:: " + vo);
				Object objLead = request.getParameter("leadId" );
				if ( objLead != null )
				{
					String leadId = ( String) objLead;
					
					if ( ! StringMethods.isEmptyString(leadId))
					{
						MBAppUtils mbAppUtils = new MBAppUtils();
		  			boolean isValidData = mbAppUtils.validateDataUsingRegEx(leadId, REGEX_PATTERN);
		  			if ( ! isValidData )
		  			{
		  				origin = "MSTG";
		  				request.setAttribute(LogonHelper.ORIGIN, origin);
		  				model = new ModelAndView("Error");
		  				Logger.error("Invalid lead Id " +  leadId , this.getClass());
		  				return model;
		  			}

						offerService.acceptLead(commonData, leadId);
					}
				}

				model = new ModelAndView("BTServicing");
				model.addObject("id_token", signedToken);
				model.addObject("targetUrl", vo.getMessage());
				return model;
			}
			else if(BTAccountsService.BT_COMBINE.equalsIgnoreCase(action))
			{
				String signedToken = btAccService.getSignedJWTForBTCombine(commonData, true);
				CodesVO vo = IBankParams.getCodesData(commonData.getOrigin(), IBankParams.EXTERNAL_LINKS, BTAccountsService.BT_SUPER_SEARCH_URL);
				model = new ModelAndView("BTServicing");
				model.addObject("id_token", signedToken);
				model.addObject("targetUrl", vo.getMessage());
				return model;
			}
			else if(BTAccountsService.BT_NOTIFY.equalsIgnoreCase(action))
			{
				String signedToken = btAccService.getSignedJWTForBTNotifyEmployer(commonData, true);
				CodesVO vo = IBankParams.getCodesData(commonData.getOrigin(), IBankParams.EXTERNAL_LINKS, BTAccountsService.BT_SUPER_SEARCH_URL);
				model = new ModelAndView("BTServicing");
				model.addObject("id_token", signedToken);
				model.addObject("targetUrl", vo.getMessage());
				return model;
			}
			else if(BTAccountsService.BT_CUSTOMISE.equalsIgnoreCase(action))
			{
				String signedToken = btAccService.getSignedJWTForBTInvestment(commonData, true);
				CodesVO vo = IBankParams.getCodesData(commonData.getOrigin(), IBankParams.EXTERNAL_LINKS, BTAccountsService.BT_SUPER_SEARCH_URL);
				model = new ModelAndView("BTServicing");
				model.addObject("id_token", signedToken);
				model.addObject("targetUrl", vo.getMessage());
				return model;
			}			
			return null;
		}
		catch ( Exception e)
		{
			origin = "MSTG";
			request.setAttribute(LogonHelper.ORIGIN, origin);
			model = new ModelAndView("Error");
			Logger.error("Error in Main Controller " , e, this.getClass());
			return model;
		}
		finally
		{
			performanceLogger.endLog(logName);
			performanceLogger.endAllLogs();
		}

	}

	private String getACEUurl(IBankCommonData commonData,String productID, String category) throws BusinessException , ResourceException
	{
		try
		{
			if( REQ_CREDIT_CARD.equalsIgnoreCase(category))
			{
				String linkType = ACE_SEARCH_STRING;
				ExternalLinkService extService = ServiceHelper.getBean("externalLinkService");
				ExternalLinkVO  externalLinkVO = extService.getExternalURLVO(commonData, true, linkType,productID,null);
				String unsignedData = externalLinkVO.getUnSignedData();
				String signedData = externalLinkVO.getSignedData();
				StringBuffer url = new StringBuffer(externalLinkVO.getUrl());
				if(!CustomerService.isJWTSwitchON()){
					url.append("&data="+ URLEncoder.encode(externalLinkVO.getUnSignedData(),"UTF-8"));
					url.append("&sign="+ URLEncoder.encode(externalLinkVO.getSignedData(), "UTF-8"));
					}
					else{
					url.append("&ACEdata="+ externalLinkVO.getUnSignedData());	
					}
				//url.append("&data="+ URLEncoder.encode(externalLinkVO.getUnSignedData(),"UTF-8"));
				//url.append("&sign="+ URLEncoder.encode(externalLinkVO.getSignedData(), "UTF-8"));
				return url.toString();
			} 
			else if( REQ_PERSONAL_LOAN.equalsIgnoreCase(category))
			{
				String linkType = PL_SEARCH_STRING;
				ExternalLinkService extService = ServiceHelper.getBean("externalLinkService");
				ExternalLinkVO  externalLinkVO = extService.getExternalURLVO(commonData, true, linkType,productID,null);
				String unsignedData = externalLinkVO.getUnSignedData();
				String signedData = externalLinkVO.getSignedData();
				StringBuffer url = new StringBuffer(externalLinkVO.getUrl());
				if(!CustomerService.isJWTSwitchON()){
					url.append("&data="+ URLEncoder.encode(externalLinkVO.getUnSignedData(),"UTF-8"));
					url.append("&sign="+ URLEncoder.encode(externalLinkVO.getSignedData(), "UTF-8"));
					}
					else{
					url.append("&ACEdata="+ externalLinkVO.getUnSignedData());	
					}
				//url.append("&data="+ URLEncoder.encode(externalLinkVO.getUnSignedData(),"UTF-8"));
				//url.append("&sign="+ URLEncoder.encode(externalLinkVO.getSignedData(), "UTF-8"));
				return url.toString();
			} 
			else
			{
				Logger.error("URL Not found..... " + category, this.getClass());
				throw new ResourceException( ResourceException.SYSTEM_ERROR, "URL Not found..... " + category );
			}
		}
		catch ( Exception e )
		{
			Logger.error("Error in getACEUurl() ", e, this.getClass());
			throw new ResourceException( ResourceException.SYSTEM_ERROR, "URL Not found..... " + category );
		}
	}

	
	private ModelAndView processHomeLoanSRequest(String gcisNumber, String leadId,
			String origin) {

		ModelAndView model = new ModelAndView("ApplyHomeLoan");
		String baseOrigin = IBankParams.getBaseOriginCode(origin);
		String url = null;
		CodesVO vo = IBankParams.getCodesData(baseOrigin,IBankParams.EXTERNAL_LINKS,"CLASWeb|Account|Apply for Home Loan");
		if (vo != null) {
			url = vo.getMessage();
		} else {
			return null;
		}
		Logger.info( " External URL " + url + " baseOrigin : " + baseOrigin + " Origin : " +origin  , this.getClass() );
		String unsignedData = "";
		LabelValueVO labelVOArray[] = new LabelValueVO[5];

		labelVOArray[0] = new LabelValueVO("gcis", gcisNumber);
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
		labelVOArray[1] = new LabelValueVO("time", sdf.format(new Date()));

		EncryptionDigestService encryptionDigestService = (EncryptionDigestService) ServiceHelper.getBean("homeLoanEncryptionDigestService");

		unsignedData = encryptionDigestService.createEncryptedData(labelVOArray);
		String signedData = encryptionDigestService.getSignedDigest(unsignedData);
		Logger.info("signedData Length   : " + signedData.length(),	this.getClass());

		model.addObject("targetUrl", url);

		model.addObject("data", unsignedData);
		model.addObject("sign", signedData);
		model.addObject("leadId", leadId);

		Logger.info("url formed in processHLCLASRequest() Is : " + url 	+ " length " + url.length(), this.getClass());
		return model;
	}

	private ModelAndView processNativeAppHomeLoanRequest(HttpServletRequest request)
	{
		String origin = LogonHelper.resolveOrigin(request);
		try
		{
			String token = request.getParameter("token");
			Logger.debug("processNativeAppHomeLoanRequest(). Origin : " +  origin + "  Token : "+ token , this.getClass());

			ModelAndView model = null;
			MBAppUtils mbAppUtils = new MBAppUtils();
			boolean isValidData = mbAppUtils.validateDataUsingRegEx(token, REGEX_PATTERN);
			if (!isValidData)
			{
				request.setAttribute(LogonHelper.ORIGIN, origin);
				model = new ModelAndView("Error");
				Logger.error("Invalid Token : " + token, this.getClass());
				return model;
			}

			ServiceTokenService insSSOTokenService = (ServiceTokenService) ServiceHelper.getBean("homeLoanSSOTokenService");
			ServiceTokenVO serviceTokenVO = insSSOTokenService.validateToken(token, true);
			model = processHomeLoanSRequest(serviceTokenVO.getGcisNumber(), "", origin);
			
			
			createStat(  serviceTokenVO.getGcisNumber(), request, true,"CLASWeb|Account|Apply for Home Loan");
			
			return model;
		}
		catch (BusinessException e)
		{
			Logger.error("Error in processNativeAppHomeLoanRequest ", e, this.getClass());
			request.setAttribute(LogonHelper.ORIGIN, origin);
			ModelAndView model = new ModelAndView("Error");
			Logger.error("BusinessException - Invalid Token : ", e, this.getClass());
			return model;

		}
	}
	
	private void createStat(  String GCISNumber, HttpServletRequest request, boolean isCloseSession,
		    String description) throws BusinessException, ResourceException {
			// Add entry in statistic log
			try {
				
				String isTablet = request.getParameter("isTablet");
				String origin = LogonHelper.resolveOrigin(request);
				if ( "Y".equalsIgnoreCase(isTablet) )
				{
					String baseOrigin = IBankParams.getBaseOriginCode(origin);
					origin = "T" + baseOrigin;
				}
				
				Statistic stat = new Statistic();
				stat.setGcisNumber(GCISNumber);
				stat.setOriginBank(origin);
				stat.setGDWOriginBank(origin);
				/*
				 String gdwOrigin = logonHelper.getGDWOrigin(req.getHeader(), origin);
				stat.setGDWOriginBank(gdwOrigin);
				*/
				//stat.setGDWOriginBank(commonData.getGdwOrigin());

				if (isCloseSession) {
					stat.setAction(Statistic.EXPIRY_EXTERNAL_LINK);
				} else {
					stat.setAction(Statistic.DIRECT_EXTERNAL_LINK);
				}
				String ipAddress;
				ipAddress  = MBAppHelper.resolveIPAddress(request, origin);
				if ( ! isValidIPAddress ( ipAddress ) )
				{
					Logger.info("Invalid IP Address : " + ipAddress ,MBAppHelper.class);
					ipAddress = "0.0.0.0";
				}
				
				stat.setIpAddress(ipAddress);
				//stat.setSessionId(commonData.getSessionId());
				if (description == null) {
					stat.setDescription("");
				} else {
					stat.setDescription(description);
				}
				StatisticsService.logStatistic(stat);
			} catch (Throwable t) {
				// do nothing as this is not a part of the transaction
				IBankLog.logERR("Failed to create a statistic entry", t,
				    ExternalLinkServiceImpl.class);
			}
		}
	
private static String IP_ADDRESS_REG_EX = "\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}" ;
	
	public static boolean isValidIPAddress(String str) {
	  Pattern ipPattern = Pattern.compile(IP_ADDRESS_REG_EX);
	  return ipPattern.matcher(str).matches();
	}
	
	@Autowired
	private LogonHelper logonHelper;

}