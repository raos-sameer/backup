package au.com.stgeorge.mbank.model.request.payments;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.NotEmpty;

import au.com.stgeorge.ibank.businessobject.BusinessException;
import au.com.stgeorge.mbank.model.common.IMBReq;
import au.com.stgeorge.mbank.model.common.ReqHeader;

public class PayToMobileCancelReq implements IMBReq {
	/**
	 * 
	 */
	private static final long serialVersionUID = -6106119056636879834L;
		
	private ReqHeader header;
	
	@NotNull(message = "" + BusinessException.WSVC_INVALID_INPUT_PARAM)
	private Integer requestId;
		
	public ReqHeader getHeader() {
		return header;
	}
	public void setHeader(ReqHeader header) {
		this.header = header;
	}
	public Integer getRequestId() {
		return requestId;
	}
	public void setRequestId(Integer requestId) {
		this.requestId = requestId;
	}		
}
