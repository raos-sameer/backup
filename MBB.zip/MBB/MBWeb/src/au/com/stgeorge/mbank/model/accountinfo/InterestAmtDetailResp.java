/**
 * 
 */
package au.com.stgeorge.mbank.model.accountinfo;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
/**
 * @author C50216
 *
 */

@JsonInclude(Include.NON_NULL)
public class InterestAmtDetailResp {

	private String thisYearAmt;
	private String lastYearAmt;
	
	public String getThisYearAmt() {
		return thisYearAmt;
	}
	public void setThisYearAmt(String thisYearAmt) {
		this.thisYearAmt = thisYearAmt;
	}
	public String getLastYearAmt() {
		return lastYearAmt;
	}
	public void setLastYearAmt(String lastYearAmt) {
		this.lastYearAmt = lastYearAmt;
	}		
	
}
