package au.com.stgeorge.mbank.model.request.customer;
import java.io.Serializable;

import au.com.stgeorge.mbank.model.common.IMBReq;
import au.com.stgeorge.mbank.model.common.ReqHeader;
import au.com.stgeorge.mbank.model.request.customer.ev.CRSInfo;

public class CRSMaintenanceReq implements IMBReq, Serializable{
	
	private static final long serialVersionUID = 1067908768223802051L;

	private CRSInfo crsInfo;
	private ReqHeader header;

	public ReqHeader getHeader() {
		return header;
	}
	
	public void setHeader(ReqHeader header) {
		this.header = header;
	}

	public CRSInfo getCrsInfo() {
		return crsInfo;
	}

	public void setCrsInfo(CRSInfo crsInfo) {
		this.crsInfo = crsInfo;
	}	
	
}
