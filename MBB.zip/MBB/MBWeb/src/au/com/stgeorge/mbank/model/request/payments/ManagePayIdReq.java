package au.com.stgeorge.mbank.model.request.payments;

import org.apache.commons.lang.builder.ReflectionToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;
import au.com.stgeorge.mbank.model.common.IMBReq;
import au.com.stgeorge.mbank.model.common.ReqHeader;

/**
 * ManagePayIdReq
 * 
 * @author C72660
 * 
 */
public class ManagePayIdReq implements IMBReq {


	private static final long serialVersionUID = -4723751125232692028L;
	private ReqHeader header;
	private String payIdType;

	public String getPayIdType() {
		return payIdType;
	}
	public void setPayIdType(String payIdType) {
		this.payIdType = payIdType;
	}

	public ReqHeader getHeader() {
		return header;
	}

	public void setHeader(ReqHeader header) {
		this.header = header;
	}
	
	@Override
	public String toString() {
		return ReflectionToStringBuilder.toString(this, ToStringStyle.MULTI_LINE_STYLE);
	}

}
