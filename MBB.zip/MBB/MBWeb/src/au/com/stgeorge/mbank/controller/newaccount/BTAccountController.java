package au.com.stgeorge.mbank.controller.newaccount;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import au.com.stgeorge.framework.common.exception.ResourceException;
import au.com.stgeorge.framework.common.logging.Logger;
import au.com.stgeorge.ibank.businessobject.BTAccountsService;
import au.com.stgeorge.ibank.businessobject.BTSuperSearchService;
import au.com.stgeorge.ibank.businessobject.BusinessException;
import au.com.stgeorge.ibank.businessobject.OfferService;
import au.com.stgeorge.ibank.common.cache.IBankParams;
import au.com.stgeorge.ibank.valueobject.BTSuperSearchTile;
import au.com.stgeorge.ibank.valueobject.database.CodesVO;
import au.com.stgeorge.ibank.valueobject.transfer.IBankCommonData;
import au.com.stgeorge.mbank.controller.IMBController;
import au.com.stgeorge.mbank.model.common.BTSearchStatusResp;
import au.com.stgeorge.mbank.model.common.BTSuperSearchResp;
import au.com.stgeorge.mbank.model.common.BTTileStatusResp;
import au.com.stgeorge.mbank.model.common.IMBReq;
import au.com.stgeorge.mbank.model.common.IMBResp;
import au.com.stgeorge.mbank.model.common.ReqHeader;
import au.com.stgeorge.mbank.model.common.RespHeader;
import au.com.stgeorge.mbank.model.request.EmptyReq;
import au.com.stgeorge.mbank.model.request.newaccount.BTDetailsReq;
import au.com.stgeorge.mbank.model.response.ErrorResp;
import au.com.stgeorge.mbank.model.response.newaccount.BTDetailsResp;
import au.com.stgeorge.mbank.session.MobileSession;
import au.com.stgeorge.mbank.util.BTValidator;
import au.com.stgeorge.mbank.util.MBAppHelper;
import au.com.stgeorge.mbank.util.MBAppUtils;
import au.com.stgeorge.mbank.util.MBAppValidator;
import au.com.stgeorge.mbank.util.ServiceConstants;
import au.com.stgeorge.perflogger.PerformanceLogger;
import au.com.stgeorge.security.util.StringMethods;

/**
 * This allows to do BT related actions.
 * @author c33232
 *@since 16E1
 */
@Controller
@RequestMapping("/bt")
public class BTAccountController implements IMBController{

	@Autowired
	private MBAppHelper mbAppHelper;
	
	@Autowired
	private BTAccountsService btAccService;
	
	@Autowired
	private MBAppValidator mbAppValidator;

	@Autowired
	private OfferService offerService;

	@Autowired
	private BTSuperSearchService btSuperSearchService;
	/**
	 * Validator has been bound to validate only 
	 * for viewing BT controller.
	 * @param binder
	 */
	@InitBinder
	protected void initBinder(WebDataBinder binder) {
	    binder.setValidator(new BTValidator());
	}
	
	/**
	 * Eligibility to open a BT account is checked by
	 * this method when the customer clicks on "Get Started"<br>
	 * OR <br>
	 * enters the flow via deep link  via native app / msite.<br>
	 * @param httpServletRequest
	 * @param httpServletResponse
	 * @param req
	 * @return
	 */
	@ResponseBody
	@RequestMapping(value="/eligibility", method=RequestMethod.POST, headers="content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE)
	public IMBResp checkEligibility(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, 
			@RequestBody BTDetailsReq req)
	{
		MobileSession mobSession = null;
		IBankCommonData ibankCommonData = null;
		RespHeader headerResp = null;
		String serviceName = null;
		BTDetailsResp eligibilityResponse = new BTDetailsResp();
		PerformanceLogger performanceLogger = new PerformanceLogger();
		performanceLogger.startAllLogs();
		String logName = MBAppUtils.getLogName(httpServletRequest);
		performanceLogger.startLog(logName);
		try{
			mobSession = mbAppHelper.getMobileSession(httpServletRequest);
			ibankCommonData = mbAppHelper.populateIBankCommonData(mobSession, httpServletRequest);
			if(req.getHeader() != null)
			{
				serviceName = req.getHeader().getServiceName();
				headerResp = populateResponseHeader(serviceName, mobSession);
				eligibilityResponse.setHeader(headerResp);
			}
			
			/**
			 * Eligibility checks are captured as BusinessException and its 
			 * corresponding messages to show on UI.
			 */
			//check eligibility of existing checks
			return prepareIneligibilityResp(btAccService.isEligibleForBTAccount(ibankCommonData), 
					mbAppHelper.getOrigin(httpServletRequest), 
					eligibilityResponse);
//			eligibilityResponse.setIsEligible(true);
//			
//			eligibilityResponse.setIsSuccess(true);
			
		}
		catch(BusinessException e)
		{
			//e.printStackTrace();
			Logger.error("Exception Inside checkEligibility() for BT. Customer GCIS: ["+ ((mobSession!=null && mobSession.getCustomer()!=null)? mobSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			ErrorResp errRespObj = MBAppUtils.createErrorResp(mbAppHelper.getOrigin(httpServletRequest), e, serviceName, httpServletRequest);
//			if(BusinessException.BT_NEW_APPL_SOURCE_ACCT_VALIDATION_FAILED == e.getKey()
//					|| BusinessException.BT_NEW_APPL_DOB_VALIDATION_FAILED == e.getKey()
//					//|| BusinessException.BT_NEW_APPL_EMAIL_EMPTY == e.getKey() 
//					//|| BusinessException.BT_NEW_APPL_INVALID_EMAIL == e.getKey()
//					|| BusinessException.BT_NEW_APPL_SEX_VALIDATION_FAILED == e.getKey()
//					//|| BusinessException.BT_NEW_APPL_ADDRESS_VALIDATION_FAILED == e.getKey()
//					//|| BusinessException.BT_NEW_APPL_DPID_ADDRESS_VALIDATION_FAILED == e.getKey()
//					//|| BusinessException.NO_CONTACT_PH_NUMBER == e.getKey()
//					|| BusinessException.BT_NEW_APPL_MAX_NUMBER_ACCOUNTS == e.getKey())
//			{
////				eligibilityResponse.setIsEligible(false);
////				if(errRespObj != null && errRespObj.getErrors() != null && errRespObj.getErrors().size() > 0)
////				{
////					eligibilityResponse.setIneligibilityMsg(errRespObj.getErrors().get(0).getMessage());
////				}
////				else
////				{
////					eligibilityResponse.setIneligibilityMsg("System could not identify reason for your ineligibility to apply BT account, please call bank to know reason");
////				}
////				eligibilityResponse.setIsSuccess(true);
////				return eligibilityResponse;
//				List<Integer> errList = new ArrayList<Integer>(1);
//				errList.add(e.getKey());
//				System.out.println("In business exception eligibilityResponse: "+ eligibilityResponse);
//				return prepareIneligibilityResp(errList, mbAppHelper.getOrigin(httpServletRequest), eligibilityResponse);
//			}
			
			return errRespObj;
		}
		finally
		{
			performanceLogger.endLog(logName);
			performanceLogger.endAllLogs();
		}
		
//		return eligibilityResponse;
	}
	
	/**
	 * This prepares the list of ineligibility messages
	 * for BT.
	 * @param businessExcepcodes
	 * @param origin
	 * @return
	 */
	private BTDetailsResp prepareIneligibilityResp(List<Integer> businessExcepcodes, String origin, BTDetailsResp eligibilityResponse)
	{
		if(businessExcepcodes != null && businessExcepcodes.size()>0)
		{
			String[] ineligibilityMsgs = new String[businessExcepcodes.size()];
			int index = 0;
			for(int errCode: businessExcepcodes)
			{
				ineligibilityMsgs[index] = MBAppUtils.getMessage(origin, errCode);
				index ++;
			}
			eligibilityResponse.setIneligibilityMsg(ineligibilityMsgs);
		}
		
		eligibilityResponse.setIsEligible(!(eligibilityResponse.getIneligibilityMsg() != null 
				&& eligibilityResponse.getIneligibilityMsg().length > 0));
		eligibilityResponse.setIsSuccess(true);
		
		
		return eligibilityResponse;
	}
	
	
	/**
	 * This is the API exposed to open a BT account.
	 * @param httpServletRequest
	 * @param httpServletResponse
	 * @param req
	 * @return
	 * @since 16E1
	 */
	@ResponseBody
	@RequestMapping(value="/applyBT", method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE)
	public IMBResp applyBT(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse,
			@RequestBody BTDetailsReq req)
	{
		return generateJWT(httpServletRequest, httpServletResponse, req, BTAccountsService.BT_APPLICATION_URL);
	}
	
	/**
	 * TODO need to check the validity of whether params works
	 * This is the API exposed to view details of an
	 * existing BT account.<br>
	 * <b>index</b> is param passed for selected account.
	 * @param httpServletRequest
	 * @param httpServletResponse
	 * @param req
	 * @return IMBResp
	 * @since 16E1
	 */
	@ResponseBody
	@RequestMapping(value="/viewBT", method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE)
	public IMBResp viewBT(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse,
			@Valid @RequestBody BTDetailsReq req)
	{
		try{
//			System.out.println("index:: " + req);
			ErrorResp errorResp = validate(req, httpServletRequest);
			if (errorResp != null && errorResp.getErrors() != null && errorResp.getErrors().size() > 0)
			{
				Logger.error("Exception Inside viewBT(), probably index parameter not passed", this.getClass());
				return errorResp;
			}
		}
		catch(BusinessException e)
		{
			BusinessException exp = new BusinessException(e.getKey());
			IMBResp resp1 = MBAppUtils.createErrorResp(mbAppHelper.getOrigin(httpServletRequest), exp, ServiceConstants.INVALID_INPUT_PARAMS, httpServletRequest);
			return resp1;
		}
		
		validateReq(  req );
		return generateJWT(httpServletRequest, httpServletResponse, req, BTAccountsService.BT_APPLICATION_URL);
	}
	
	
	/**
	 * This is the API exposed to search super accounts.
	 * @param httpServletRequest
	 * @param httpServletResponse
	 * @param req
	 * @return
	 * @since 17E1
	 */
	@ResponseBody
	@RequestMapping(value="/superSearchBT", method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE)
	public IMBResp superSearchBT(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse,
			@RequestBody BTDetailsReq req)
	{
		String serviceName = null;
		MobileSession mobSession = null;
		BTDetailsResp tokenResponse = new BTDetailsResp();
		try {
			validateRequestHeader( req.getHeader(), httpServletRequest );
			mobSession = mbAppHelper.getMobileSession(httpServletRequest);
			IBankCommonData commonData = mbAppHelper.populateIBankCommonData(mobSession, httpServletRequest);
			serviceName = req.getHeader().getServiceName();
	
			String jwtToken = null;
			String btUrlCode = BTAccountsService.BT_SUPER_SEARCH_URL;
			switch(req.getAction()){
				case BTAccountsService.BT_SUPER_SEARCH 	: 
				{
					jwtToken = btAccService.getSignedJWTForBTSuperSearch(commonData, true, req.getRequestFrom());
					Logger.debug("superSearchBT:btSuperSearch LeadId: " + req.getLeadId(), this.getClass());
					if(req.getLeadId() != null)
					{
						offerService.acceptLead(commonData, req.getLeadId());
					}
					btUrlCode = BTAccountsService.BT_WEALTH_SEARCH_URL;
					break;
				}
				case BTAccountsService.BT_COMBINE 		: jwtToken = btAccService.getSignedJWTForBTCombine(commonData, true);
															break;
				case BTAccountsService.BT_NOTIFY 		: jwtToken = btAccService.getSignedJWTForBTNotifyEmployer(commonData, true);
															break;
				case BTAccountsService.BT_CUSTOMISE 	: jwtToken = btAccService.getSignedJWTForBTInvestment(commonData, true);
															break;
			}
				
			tokenResponse.setFinalToken(jwtToken);
			tokenResponse.setIsSuccess(true);
			tokenResponse.setIsEligible(true);
			
			CodesVO vo = IBankParams.getCodesData(commonData.getOrigin(), IBankParams.EXTERNAL_LINKS, btUrlCode);
			tokenResponse.setTargetUrl(vo.getMessage());
			
			
		} catch (BusinessException e) {
			Logger.error("Exception Inside superSearchBT() for Customer GCIS: ["+ ((mobSession!=null && mobSession.getCustomer()!=null)? mobSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			return MBAppUtils.createErrorResp(mbAppHelper.getOrigin(httpServletRequest), e, serviceName, httpServletRequest);
		}
		return tokenResponse;
	}
	
	
	/**
	 * This is the API exposed to search super accounts.
	 * @param httpServletRequest
	 * @param httpServletResponse
	 * @return
	 * @since 17E1
	 */
	@ResponseBody
	@RequestMapping(value="/tileStatus", method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE)
	public IMBResp tileStatus(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, @RequestBody final EmptyReq req){
		BTTileStatusResp btTileStatusResp = new BTTileStatusResp();
		MobileSession mbSession = null;

		try {
			validateRequestHeader( req.getHeader(), httpServletRequest );
			mbSession = mbAppHelper.getMobileSession(httpServletRequest);
			IBankCommonData commonData=mbAppHelper.populateIBankCommonData(mbSession,httpServletRequest);
			
			boolean isRefresh = true;
			BTSuperSearchTile btSuperSearchTile = btSuperSearchService.getBTSuperSearchTile(commonData.getCustomer(), commonData, isRefresh);
			
			if(btSuperSearchTile != null){
				BTSuperSearchResp btSuperSearchResp = new BTSuperSearchResp();
				btSuperSearchResp.setAccountIndex(btSuperSearchTile.getAccountIndex());
				btSuperSearchResp.setCombine(btSuperSearchTile.getCombineSuper());
				btSuperSearchResp.setCustomise(btSuperSearchTile.getCustomiseInsurance());
				btSuperSearchResp.setNotify(btSuperSearchTile.getNotifyEmployer());
				btSuperSearchResp.setMinimiseTile(btSuperSearchTile.isMinimizeTile());
				btTileStatusResp.setBtSuperSearchResp(btSuperSearchResp);
			} 
			
			RespHeader headerResp = mbAppHelper.populateResponseHeader("bt/tileStatus", mbSession);
			btTileStatusResp.setHeader(headerResp);
			
		} catch (BusinessException e) {
			Logger.error("Exception Inside tileStatus() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			return MBAppUtils.createErrorResp(mbAppHelper.getOrigin(httpServletRequest), e, "bt/tileStatus", httpServletRequest);
		}	
		
		return btTileStatusResp;
	}
	
	
	
	/**
	 * Method to check if BT search has been done or not.
	 * @param httpServletRequest
	 * @param httpServletResponse
	 * @return
	 * @since 17E1
	 */
	@ResponseBody
	@RequestMapping(value="/searchStatus", method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE)
	public IMBResp searchStatus(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse,
			@RequestBody final EmptyReq req){
		BTSearchStatusResp btSearchStatusResp = new BTSearchStatusResp();
		MobileSession mbSession = null;

		try {
			validateRequestHeader( req.getHeader(), httpServletRequest );
			mbSession = mbAppHelper.getMobileSession(httpServletRequest);
			IBankCommonData commonData=mbAppHelper.populateIBankCommonData(mbSession,httpServletRequest);
			
			if(mbSession.isBTSuperSearchDone() == null){
				boolean isSearchDone = btSuperSearchService.isBTSuperSearchDone(commonData);
				mbSession.setBTSuperSearchDone(isSearchDone);
			}
			
			btSearchStatusResp.setBtSearchDone(mbSession.isBTSuperSearchDone());
			RespHeader headerResp = mbAppHelper.populateResponseHeader("bt/searchStatus", mbSession);
			btSearchStatusResp.setHeader(headerResp);
			
		} catch (BusinessException e) {
			Logger.error("Exception Inside searchStatus() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			return MBAppUtils.createErrorResp(mbAppHelper.getOrigin(httpServletRequest), e, "bt/searchStatus", httpServletRequest);
		}	
		
		return btSearchStatusResp;
	}
	
	
	/**
	 * This method generates the JWS token
	 * for both servicing and origination
	 * of BT. Servicing is known by non-null
	 * index passed in request.
	 * @param httpServletRequest
	 * @param httpServletResponse
	 * @param req
	 * @return IMBResp
	 * @since 16E1
	 */

	private IMBResp generateJWT(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse,
			BTDetailsReq req, String btUrlCode) 
	{
		String signedToken = null;
		RespHeader headerResp = null;
		BTDetailsResp tokenResponse = new BTDetailsResp();
		MobileSession mobSession = null;
		IBankCommonData ibankCommonData = null;
		String serviceName = null;
		PerformanceLogger performanceLogger = new PerformanceLogger();
		performanceLogger.startAllLogs();
		String logName = MBAppUtils.getLogName(httpServletRequest);
		performanceLogger.startLog(logName);
		
		
		try {
			mobSession = mbAppHelper.getMobileSession(httpServletRequest);
			
			if(req.getHeader() != null)
			{
				validateRequestHeader( req.getHeader(), httpServletRequest );
				serviceName = req.getHeader().getServiceName();
				headerResp = populateResponseHeader(serviceName, mobSession);
				tokenResponse.setHeader(headerResp);
			}
			
			ibankCommonData = mbAppHelper.populateIBankCommonData(mobSession, httpServletRequest);
			
			signedToken = btAccService.getSignedJWTForBT(ibankCommonData, req.getIndex(), req.getRequestFrom());//account index not null means servicing
			tokenResponse.setFinalToken(signedToken);
			tokenResponse.setIsSuccess(true);
			tokenResponse.setIsEligible(true);// till this point eligibility would have been checked.
			
			CodesVO vo = IBankParams.getCodesData(ibankCommonData.getOrigin(), IBankParams.EXTERNAL_LINKS, btUrlCode);
			if (vo != null)
			{
				tokenResponse.setTargetUrl(vo.getMessage());
			}
			
			if(req.getLeadId() != null )
				offerService.acceptLead(ibankCommonData, req.getLeadId());
			
		}catch (BusinessException e) {
			//e.printStackTrace();
			Logger.error("Exception Inside generateJWSToken() for Customer GCIS: ["+ ((mobSession!=null && mobSession.getCustomer()!=null)? mobSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			return MBAppUtils.createErrorResp(mbAppHelper.getOrigin(httpServletRequest), e, serviceName, httpServletRequest);
		} 
		finally
		{
			performanceLogger.endLog(logName);
			performanceLogger.endAllLogs();
		}
		
		return tokenResponse;
	}
	
	public RespHeader populateResponseHeader(String serviceName,
			MobileSession mobileSession) {
		return mbAppHelper.populateResponseHeader(serviceName, mobileSession);
	}

	public ErrorResp validate(IMBReq serviceRequest,
			HttpServletRequest httpRequest) throws BusinessException {
		return mbAppValidator.validate(serviceRequest, httpRequest);
	}

	public void validateRequestHeader(ReqHeader headerReq,
			HttpServletRequest request) throws BusinessException {
		mbAppValidator.validateRequestHeader(headerReq, request);
		
	}
	
	private static final String BLOCK_CHARS_PATTERN = "^[0-9A-Za-z',. &/\\-]*$";
	private void validateReq( BTDetailsReq req )
	{

		MBAppUtils mbAppUtils = new MBAppUtils();
		if ( req.getIndex() != null )
		{
			if ( ! mbAppUtils.validateDataUsingRegEx(String.valueOf(req.getIndex()), BLOCK_CHARS_PATTERN ) )
			{
				Logger.error("Invalid getIndex : " + req.getIndex() , this.getClass());
				 throw new ResourceException (ResourceException.SYSTEM_ERROR);
			}
				
		}

		if ( ! StringMethods.isEmptyString(req.getRequestFrom()) )
		{
			if ( ! mbAppUtils.validateDataUsingRegEx(String.valueOf(req.getRequestFrom()), BLOCK_CHARS_PATTERN ) )
			{
				Logger.error("Invalid getRequestFrom: " + req.getRequestFrom() , this.getClass());
				 throw new ResourceException (ResourceException.SYSTEM_ERROR);
			}
				
		}

		if ( ! StringMethods.isEmptyString(req.getLeadId()) )
		{
			if ( ! mbAppUtils.validateDataUsingRegEx(String.valueOf(req.getLeadId()), BLOCK_CHARS_PATTERN ) )
			{
				Logger.error("Invalid getLeadId : " + req.getLeadId() , this.getClass());
				 throw new ResourceException (ResourceException.SYSTEM_ERROR);
			}
				
		}

	}
	
	

}
