package au.com.stgeorge.mbank.model.request.customer;

import java.io.Serializable;

import au.com.stgeorge.mbank.model.common.IMBReq;
import au.com.stgeorge.mbank.model.common.ReqHeader;

public class MarketingPreferencesUpdationReq implements IMBReq, Serializable{
	
	private static final long serialVersionUID = -256469544559499302L;
	
	private ReqHeader header;
	private Boolean contactForGeneralMarketing;
    private Boolean contactForTelephoneMarketing;
    private Boolean contactForElectronicMarketing;
    private Boolean receiveOfferViaInternetMobileBanking;
	
	public ReqHeader getHeader() {
		return header;
	}
	public void setHeader(ReqHeader header)	{
		this.header = header;
	}
	public Boolean getContactForGeneralMarketing() {
		return contactForGeneralMarketing;
	}
	public void setContactForGeneralMarketing(Boolean contactForGeneralMarketing) {
		this.contactForGeneralMarketing = contactForGeneralMarketing;
	}
	public Boolean getContactForTelephoneMarketing() {
		return contactForTelephoneMarketing;
	}
	public void setContactForTelephoneMarketing(Boolean contactForTelephoneMarketing) {
		this.contactForTelephoneMarketing = contactForTelephoneMarketing;
	}
	public Boolean getContactForElectronicMarketing() {
		return contactForElectronicMarketing;
	}
	public void setContactForElectronicMarketing(Boolean contactForElectronicMarketing) {
		this.contactForElectronicMarketing = contactForElectronicMarketing;
	}
	public Boolean getReceiveOfferViaInternetMobileBanking() {
		return receiveOfferViaInternetMobileBanking;
	}
	public void setReceiveOfferViaInternetMobileBanking(Boolean receiveOfferViaInternetMobileBanking) {
		this.receiveOfferViaInternetMobileBanking = receiveOfferViaInternetMobileBanking;
	}
	
	
}
