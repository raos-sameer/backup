package au.com.stgeorge.mbank.controller.services;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang.builder.ReflectionToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;

import au.com.stgeorge.framework.common.logging.Logger;
import au.com.stgeorge.framework.common.util.DateMethods;
import au.com.stgeorge.framework.common.util.StringMethods;
import au.com.stgeorge.ibank.businessobject.AccountFilter;
import au.com.stgeorge.ibank.businessobject.BusinessException;
import au.com.stgeorge.ibank.businessobject.PushNotificationService;
import au.com.stgeorge.ibank.businessobject.ResourceException;
import au.com.stgeorge.ibank.businessobject.SMSAlertsService;
import au.com.stgeorge.ibank.common.cache.IBankParams;
import au.com.stgeorge.ibank.valueobject.Account;
import au.com.stgeorge.ibank.valueobject.CreditCardAccount;
import au.com.stgeorge.ibank.valueobject.Customer;
import au.com.stgeorge.ibank.valueobject.Statistic;
import au.com.stgeorge.ibank.valueobject.sms.Alert;
import au.com.stgeorge.ibank.valueobject.sms.SMSAccount;
import au.com.stgeorge.ibank.valueobject.transfer.IBankCommonData;
import au.com.stgeorge.mbank.controller.IMBController;
import au.com.stgeorge.mbank.model.common.IMBReq;
import au.com.stgeorge.mbank.model.common.IMBResp;
import au.com.stgeorge.mbank.model.common.ReqHeader;
import au.com.stgeorge.mbank.model.common.RespHeader;
import au.com.stgeorge.mbank.model.request.EmptyReq;
import au.com.stgeorge.mbank.model.request.services.AlertReq;
import au.com.stgeorge.mbank.model.request.services.AlertsRegisterReq;
import au.com.stgeorge.mbank.model.request.services.OnboardAccountsReq;
import au.com.stgeorge.mbank.model.response.ErrorResp;
import au.com.stgeorge.mbank.session.MobileSession;
import au.com.stgeorge.mbank.session.MobileSessionImpl;
import au.com.stgeorge.mbank.util.MBAppHelper;
import au.com.stgeorge.mbank.util.MBAppUtils;
import au.com.stgeorge.mbank.util.MBAppValidator;
import au.com.stgeorge.mbank.util.ServiceConstants;
import au.com.stgeorge.perflogger.PerformanceLogger;

import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * Alerts service
 * 
 * alerts/summary alerts/register alerts/unregister alerts/accounts alerts/create alerts/modify
 * 
 * @author C38854
 * 
 */
@Controller
@RequestMapping("/alerts")
public class AlertsController implements IMBController {

	private static final int NULL_ALERT_TYPE_GET_ACCOUNTS = -1;
	private static HashMap<Integer, String> emailFormats;
	private static Map<Integer, String> alertTypeToGDWAction ;
	private static Map<Integer, String> alertTypeToGDWDescription ;	
	static {
		emailFormats = new HashMap<Integer, String>();
		emailFormats.put(0, "TEXT");
		emailFormats.put(1, "HTML");
		
		alertTypeToGDWAction = new HashMap<> ();
		alertTypeToGDWAction.put(AlertsHelper.DEPOSIT_ALERT_TYPE, Statistic.ONBOARDING_ALERT);
		alertTypeToGDWAction.put(AlertsHelper.WITHDRAW_ALERT_TYPE, Statistic.ONBOARDING_ALERT);
		alertTypeToGDWAction.put(NULL_ALERT_TYPE_GET_ACCOUNTS, Statistic.ONBOARDING_PUSH_ACCOUNTS);
		
		alertTypeToGDWDescription = new HashMap<> ();
		alertTypeToGDWDescription.put(AlertsHelper.DEPOSIT_ALERT_TYPE, AlertsHelper.GDW_DESC_ONBOARDING_DEPOSIT_ALERT);
		alertTypeToGDWDescription.put(AlertsHelper.WITHDRAW_ALERT_TYPE, AlertsHelper.GDW_DESC_ONBOARDING_WITHDRAWAL_ALERT);
	}

	@Autowired
	private SMSAlertsService smsAlertsService;

	@Autowired
	private AlertsHelper helper;

	
	@Autowired
	private MBAppValidator mbAppValidator;
	
	@Autowired
	private MBAppHelper mbAppHelper;

	@Autowired
	private PushNotificationService pushNotificationService;
	
	
	/**
	 * Get alerts summary operation
	 * 
	 * @param httpRequest
	 * @param request
	 * @return
	 */
	@RequestMapping(method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE, value = "summary")
	@ResponseBody
	public IMBResp summary(HttpServletRequest httpRequest, @RequestBody final EmptyReq request) {
		Logger.debug("AlertsController - summary(). Request: " + request, this.getClass());
		
		String logName = startPerformanceLog(httpRequest);
		MobileSession mobileSession = new MobileSessionImpl();
		try {
			mobileSession.getSessionContext(httpRequest);
			validateRequestHeader(request.getHeader(), httpRequest);
			ErrorResp errorResponse = validate(request, httpRequest);
			if (errorResponse.hasErrors())
				return errorResponse;

			Customer customer = mobileSession.getCustomer();

			int isRegistered = customer.getSMSStatus();

			if (isRegistered == IBankParams.SMS_STATUS_UNREGISTERED) {
				Logger.debug("RegistrationStatus of the customer :" + customer.getGcis() + " : " + isRegistered, this.getClass());
				isRegistered = smsAlertsService.getCustomerRegistration(customer, customer.getGcis());
			}
						
			if (isRegistered == IBankParams.SMS_STATUS_UNREGISTERED)
				return helper.populateSummaryResponse(populateResponseHeader(ServiceConstants.ALERTS_SUMMARY_SERVICE, mobileSession), false, null, null, getPushDeviceList(customer),null);

			return helper.populateSummaryResponse(populateResponseHeader(ServiceConstants.ALERTS_SUMMARY_SERVICE, mobileSession), true, getAlertsSummary(customer),
					customer.getAccounts(), getPushDeviceList(customer),null);

		} catch (BusinessException e) {
			Logger.info("BusinessException in AlertsController - summary() - [key: " + e.getKey() + "], GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());
			if (e.getKey() == BusinessException.INVALID_CHAR_SET) {
				return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.INVALID_CHAR_SET,
						ServiceConstants.ALERTS_SUMMARY_SERVICE, httpRequest);
			}
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), e, ServiceConstants.ALERTS_SUMMARY_SERVICE, httpRequest);
		} catch (ResourceException e) {
			Logger.error("ResourceException in AlertsController - summary() - [key: " + e.getKey() + "], GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.SYSTEM_UNAVILABLE, ServiceConstants.ALERTS_SUMMARY_SERVICE, httpRequest);
		} catch (Exception e) {
			Logger.error("Exception AlertsController - summary(): GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), ResourceException.MOBILE_NON_FINANCIAL_FATAL_ERR,
					ServiceConstants.ALERTS_SUMMARY_SERVICE, httpRequest);
		} finally {
			endPerformanceLog(logName);
		}
	}

	/**
	 * Register to alerts operation
	 * 
	 * @param httpRequest
	 * @param request
	 * @return
	 */
	@RequestMapping(method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE, value = "register")
	@ResponseBody
	public IMBResp register(HttpServletRequest httpRequest, @RequestBody final AlertsRegisterReq request) {
		Logger.debug("AlertsController - register(). Request: " + request, this.getClass());
		String logName = startPerformanceLog(httpRequest);
		
		MobileSession mobileSession = new MobileSessionImpl();

		try {
			mobileSession.getSessionContext(httpRequest);
			validateRequestHeader(request.getHeader(), httpRequest);
			ErrorResp errorResponse = validate(request, httpRequest);
			if (errorResponse.hasErrors())
				return errorResponse;

			Customer customer = mobileSession.getCustomer();
			IBankCommonData commonData = new MBAppHelper().populateIBankCommonData(mobileSession, httpRequest);

			customer.setEmailFormat(emailFormats.get(request.getEmailFormat()));
			customer.setPaymentPlanId(1);

			if (customer.getSMSStatus() == 0) {
				Logger.debug("Adding Registration : " + mobileSession.getUser(), this.getClass());

				customer = smsAlertsService.addRegistrationByCustomer(customer, commonData.getOrigin(), commonData, request.getPushNotfInd());
			} else {
				Logger.debug("Updating Registration : " + mobileSession.getUser(), this.getClass());
				smsAlertsService.updateRegistrationByCustomer(customer);
			}

			return helper.populateRegisterResponse(populateResponseHeader(ServiceConstants.ALERTS_REGISTER_SERVICE, mobileSession), 0);

		} catch (BusinessException e) {
			Logger.info("BusinessException in AlertsController - register() - [key: " + e.getKey() + "], GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());
			if (e.getKey() == BusinessException.INVALID_CHAR_SET) {
				return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.INVALID_CHAR_SET,
						ServiceConstants.ALERTS_REGISTER_SERVICE, httpRequest);
			}
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), e, ServiceConstants.ALERTS_REGISTER_SERVICE, httpRequest);
		} catch (ResourceException e) {
			Logger.error("ResourceException in AlertsController - register() - [key: " + e.getKey() + "], GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.SYSTEM_UNAVILABLE, ServiceConstants.ALERTS_REGISTER_SERVICE, httpRequest);
		} catch (Exception e) {
			Logger.error("Exception AlertsController - register(): GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), ResourceException.MOBILE_NON_FINANCIAL_FATAL_ERR,
					ServiceConstants.ALERTS_REGISTER_SERVICE, httpRequest);
		} finally {
			endPerformanceLog(logName);
		}
	}

	/**
	 * Unregister from alerts operation
	 * 
	 * @param httpRequest
	 * @param request
	 * @return
	 */
	@RequestMapping(method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE, value = "deregister")
	@ResponseBody
	public IMBResp unregister(HttpServletRequest httpRequest, @RequestBody final EmptyReq request) {
		Logger.debug("AlertsController - unregister(). Request: " + request, this.getClass());
		String logName = startPerformanceLog(httpRequest);
		MobileSession mobileSession = new MobileSessionImpl();

		try {
			mobileSession.getSessionContext(httpRequest);
			validateRequestHeader(request.getHeader(), httpRequest);
			ErrorResp errorResponse = validate(request, httpRequest);
			if (errorResponse.hasErrors())
				return errorResponse;

			Customer customer = mobileSession.getCustomer();
			IBankCommonData commonData = new MBAppHelper().populateIBankCommonData(mobileSession, httpRequest);

			Logger.debug("Deleting Registration : " + mobileSession.getUser(), this.getClass());
			smsAlertsService.deleteRegistrationByCustomer(customer, commonData);
			return helper.populateRegisterResponse(populateResponseHeader(ServiceConstants.ALERTS_UNREGISTER_SERVICE, mobileSession), 0);
		} catch (BusinessException e) {
			Logger.info("BusinessException in AlertsController - unregister() - [key: " + e.getKey() + "], GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());
			if (e.getKey() == BusinessException.INVALID_CHAR_SET) {
				return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.INVALID_CHAR_SET,
						ServiceConstants.ALERTS_UNREGISTER_SERVICE, httpRequest);
			}
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), e, ServiceConstants.ALERTS_UNREGISTER_SERVICE, httpRequest);
		} catch (ResourceException e) {
			Logger.error("ResourceException in AlertsController - unregister() - [key: " + e.getKey() + "], GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.SYSTEM_UNAVILABLE, ServiceConstants.ALERTS_UNREGISTER_SERVICE, httpRequest);
		} catch (Exception e) {
			Logger.error("Exception AlertsController - unregister(): GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), ResourceException.MOBILE_NON_FINANCIAL_FATAL_ERR,
					ServiceConstants.ALERTS_UNREGISTER_SERVICE, httpRequest);
		} finally {
			endPerformanceLog(logName);
		}
	}

	/**
	 * Create an alert operation
	 * 
	 * @param httpRequest
	 * @param request
	 * @return
	 */
	@RequestMapping(method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE, value = "create")
	@ResponseBody
	public IMBResp create(HttpServletRequest httpRequest, @RequestBody final AlertReq request) {
		Logger.debug("AlertsController - create(). Request: " + request, this.getClass());
		String logName = startPerformanceLog(httpRequest);
		MobileSession mobileSession = new MobileSessionImpl();

		try {
			mobileSession.getSessionContext(httpRequest);
			validateRequestHeader(request.getHeader(), httpRequest);
			ErrorResp errorResponse = validate(request, httpRequest);
			if (errorResponse.hasErrors())
				return errorResponse;

			Customer customer = mobileSession.getCustomer();
			IBankCommonData commonData = new MBAppHelper().populateIBankCommonData(mobileSession, httpRequest);
			
			if (!StringMethods.isEmptyString(request.getApplication()) && IBankParams.APPLICATION_ONBOARDING.equalsIgnoreCase(request.getApplication())) {
				customer.setSMSStatus(smsAlertsService.getCustomerRegistration(customer, customer.getGcis()));
				Logger.debug("RegistrationStatus of the customer :" + customer.getGcis() + " : " + customer.getSMSStatus(), this.getClass());
			}
			
			helper.validateAlert(request, true);
			if((customer.getSMSStatus() == IBankParams.SMS_STATUS_UNREGISTERED || customer.getSMSStatus() == IBankParams.SMS_STATUS_UNAVAILABLE)){
				Logger.debug("Adding Registration : " + mobileSession.getUser(), this.getClass());
				customer.setEmailFormat(emailFormats.get(1));
				customer.setPaymentPlanId(1);
				if(getPushDeviceList(customer) != null && getPushDeviceList(customer).size()>0){
					customer = smsAlertsService.addRegistrationByCustomer(customer, commonData.getOrigin(), commonData, true);
				}
				else{
					customer = smsAlertsService.addRegistrationByCustomer(customer, commonData.getOrigin(), commonData, false);
				}
			}
			
			Alert alert = helper.populateAlert(request, customer.getAccounts(), customer.getGcis());
			smsAlertsService.addAlert(alert);
			statisticsLogOnboarding(request.getApplication(),request.getAlertType(),alert,commonData);
			return helper.populateSummaryResponse(populateResponseHeader(ServiceConstants.ALERTS_CREATE_SERVICE, mobileSession), true, getAlertsSummary(customer),
					customer.getAccounts(), null, alert);
		} catch (BusinessException e) {
			Logger.info("BusinessException in AlertsController - create() - [key: " + e.getKey() + "], GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());
			if (e.getKey() == BusinessException.INVALID_CHAR_SET) {
				return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.INVALID_CHAR_SET,
						ServiceConstants.ALERTS_CREATE_SERVICE, httpRequest);
			}
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), e, ServiceConstants.ALERTS_CREATE_SERVICE, httpRequest);
		} catch (ResourceException e) {
			Logger.error("ResourceException in AlertsController - create() - [key: " + e.getKey() + "], GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.SYSTEM_UNAVILABLE, ServiceConstants.ALERTS_CREATE_SERVICE, httpRequest);
		} catch (Exception e) {
			Logger.error("Exception AlertsController - create(): GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), ResourceException.MOBILE_NON_FINANCIAL_FATAL_ERR,
					ServiceConstants.ALERTS_CREATE_SERVICE, httpRequest);
		} finally {
			endPerformanceLog(logName);
		}
	}

	/**
	 * Delete an alert operation
	 * 
	 * @param httpRequest
	 * @param request
	 * @return
	 */
	@RequestMapping(method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE, value = "delete")
	@ResponseBody
	public IMBResp delete(HttpServletRequest httpRequest, @RequestBody final AlertReq request) {
		Logger.debug("AlertsController - delete(). Request: " + request, this.getClass());
		String logName = startPerformanceLog(httpRequest);
		MobileSession mobileSession = new MobileSessionImpl();

		try {
			mobileSession.getSessionContext(httpRequest);
			validateRequestHeader(request.getHeader(), httpRequest);
			ErrorResp errorResponse = validate(request, httpRequest);
			if (errorResponse.hasErrors())
				return errorResponse;

			if (request.getAlertID() == null)
				throw new BusinessException(BusinessException.GENERIC_ERROR);// existing behavior

			Customer customer = mobileSession.getCustomer();
			for (Alert alert : getAlertsSummary(customer)) {
				if (alert.getId() == request.getAlertID()) {
					alert.setUserId(customer.getGcis());
					alert.setGCISNumber(customer.getGcis());
					
					for (Account account : customer.getAccounts()) {
						if (alert.getAccountNumber().equals(account.getAccountId().getAccountKey())) {
							alert.setAccountTypeCode(helper.getAccountTypeCode(account));
							break;
						}
					}
					
					smsAlertsService.deleteAlert(alert);
				}
			}
			return helper.populateSummaryResponse(populateResponseHeader(ServiceConstants.ALERTS_DELETE_SERVICE, mobileSession), true, getAlertsSummary(customer),
					customer.getAccounts(), null, null);
		} catch (BusinessException e) {
			Logger.info("BusinessException in AlertsController - delete() - [key: " + e.getKey() + "], GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());
			if (e.getKey() == BusinessException.INVALID_CHAR_SET) {
				return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.INVALID_CHAR_SET,
						ServiceConstants.ALERTS_DELETE_SERVICE, httpRequest);
			}
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), e, ServiceConstants.ALERTS_DELETE_SERVICE, httpRequest);
		} catch (ResourceException e) {
			Logger.error("ResourceException in AlertsController - delete() - [key: " + e.getKey() + "], GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.SYSTEM_UNAVILABLE, ServiceConstants.ALERTS_DELETE_SERVICE, httpRequest);
		} catch (Exception e) {
			Logger.error("Exception AlertsController - delete(): GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), ResourceException.MOBILE_NON_FINANCIAL_FATAL_ERR,
					ServiceConstants.ALERTS_DELETE_SERVICE, httpRequest);
		} finally {
			endPerformanceLog(logName);
		}
	}

	/**
	 * Modify an alert operation
	 * 
	 * @param httpRequest
	 * @param request
	 * @return
	 */
	@RequestMapping(method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE, value = "modify")
	@ResponseBody
	public IMBResp modify(HttpServletRequest httpRequest, @RequestBody final AlertReq request) {
		Logger.debug("AlertsController - modify(). Request: " + request, this.getClass());
		String logName = startPerformanceLog(httpRequest);
		MobileSession mobileSession = new MobileSessionImpl();

		try {
			mobileSession.getSessionContext(httpRequest);
			validateRequestHeader(request.getHeader(), httpRequest);
			ErrorResp errorResponse = validate(request, httpRequest);
			if (errorResponse.hasErrors())
				return errorResponse;

			Customer customer = mobileSession.getCustomer();
			helper.validateAlert(request, false);
			Alert alert = helper.populateAlert(request, customer.getAccounts(), customer.getGcis());
			smsAlertsService.updateAlert(alert);
			return helper.populateSummaryResponse(populateResponseHeader(ServiceConstants.ALERTS_MODIFY_SERVICE, mobileSession), true, getAlertsSummary(customer),
					customer.getAccounts(), null, alert);
		} catch (BusinessException e) {
			Logger.info("BusinessException in AlertsController - modify() - [key: " + e.getKey() + "], GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());
			if (e.getKey() == BusinessException.INVALID_CHAR_SET) {
				return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.INVALID_CHAR_SET,
						ServiceConstants.ALERTS_MODIFY_SERVICE, httpRequest);
			}
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), e, ServiceConstants.ALERTS_MODIFY_SERVICE, httpRequest);
		} catch (ResourceException e) {
			Logger.error("ResourceException in AlertsController - modify() - [key: " + e.getKey() + "], GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.SYSTEM_UNAVILABLE, ServiceConstants.ALERTS_MODIFY_SERVICE, httpRequest);
		} catch (Exception e) {
			Logger.error("Exception AlertsController - getDetails(): GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), ResourceException.MOBILE_NON_FINANCIAL_FATAL_ERR,
					ServiceConstants.ALERTS_MODIFY_SERVICE, httpRequest);
		} finally {
			endPerformanceLog(logName);
		}
	}

	/**
	 * Get eligible accounts operation
	 * 
	 * @param httpRequest
	 * @param request
	 * @return
	 */
	@RequestMapping(method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE, value = "accounts")
	@ResponseBody
	public IMBResp accounts(HttpServletRequest httpRequest, @RequestBody final OnboardAccountsReq request) {
		ObjectMapper mapper = new ObjectMapper();
		String logName = startPerformanceLog(httpRequest);
		MobileSession mobileSession = new MobileSessionImpl();
		IMBResp serviceResponse = null;

		try {
			Logger.debug("AlertsController - accounts(). Request: " + mapper.writeValueAsString(request), this.getClass());
			mobileSession.getSessionContext(httpRequest);
			validateRequestHeader(request.getHeader(), httpRequest);
			ErrorResp errorResponse = validate(request, httpRequest);
			if (errorResponse.hasErrors())
				return errorResponse;

			Customer customer = mobileSession.getCustomer();
			IBankCommonData commonData = new MBAppHelper().populateIBankCommonData(mobileSession, httpRequest);
			List<Account> smsAllowedAccounts = new ArrayList<Account>();
			List<Integer> smsAllowedAccountIndexes = new ArrayList<Integer>();
			int i = 0;
			
			boolean isMadisonLCMSwitchOn = AccountFilter.isMadisonLCMSwitchOn(customer.getGcis());
			for (Account account : customer.getAccounts()) {
				if(isMadisonLCMSwitchOn) {
					if(Account.CRA.equalsIgnoreCase(account.getAccountId().getApplicationId())) {
					CreditCardAccount cacc = (CreditCardAccount) account;
					if((("Q").equalsIgnoreCase(cacc.getAccountId().getAcctStatus()) && ("J").equalsIgnoreCase(cacc.getBlockCode()))|| "S".equalsIgnoreCase(cacc.getBlockCode()) ){
		  			   continue;
		  		   	}
					}
				}
				if (account.getAllowFlags() != null && account.getAllowFlags().isSMSAllowed()) {
					smsAllowedAccounts.add(account);
					smsAllowedAccountIndexes.add(i);
				}
				i++;
			}

			SMSAccount[] validDisonourSMSAccountArray = smsAlertsService.getValidAcctList(customer.getGcis(), smsAllowedAccounts, AlertsHelper.DISHONOUR_ALERT_TYPE);
			statisticsLogOnboarding(request.getApplication(),NULL_ALERT_TYPE_GET_ACCOUNTS, null, commonData);
			serviceResponse = helper.populateAccountsResp(populateResponseHeader(ServiceConstants.ALERTS_ACCOUNTS_SERVICE, mobileSession), customer.getSMSStatus(),
					validDisonourSMSAccountArray, customer.getAccounts(), smsAllowedAccountIndexes, mobileSession.getOrigin(), httpRequest);
			Logger.debug("AlertsController - accounts() Response: " + mapper.writeValueAsString(serviceResponse), this.getClass());
			return serviceResponse;
		} catch (BusinessException e) {
			Logger.info("BusinessException in AlertsController - accounts() - [key: " + e.getKey() + "], GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());
			if (e.getKey() == BusinessException.INVALID_CHAR_SET) {
				return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.INVALID_CHAR_SET,
						ServiceConstants.ALERTS_ACCOUNTS_SERVICE, httpRequest);
			}
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), e, ServiceConstants.ALERTS_ACCOUNTS_SERVICE, httpRequest);
		} catch (ResourceException e) {
			Logger.error("ResourceException in AlertsController - accounts() - [key: " + e.getKey() + "], GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.SYSTEM_UNAVILABLE, ServiceConstants.ALERTS_ACCOUNTS_SERVICE, httpRequest);
		} catch (Exception e) {
			Logger.error("Exception AlertsController - accounts(): GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), ResourceException.MOBILE_NON_FINANCIAL_FATAL_ERR,
					ServiceConstants.ALERTS_ACCOUNTS_SERVICE, httpRequest);
		} finally {
			endPerformanceLog(logName);
		}
	}

	private void statisticsLogOnboarding(String application,Integer alertType, Alert alert, IBankCommonData commonData) {
		if(!StringMethods.isEmptyString(application) && AlertsHelper.APPLICATION_ONBOARDING.equalsIgnoreCase(application)) {
			AlertsHelper.statisticsLogAlertsOnboarding(alertTypeToGDWAction.get(alertType),alertTypeToGDWDescription.get(alertType), alert, commonData);	
		}
	}


	/**
	 * check another user already registered for push on current device.
	 * 
	 * @param httpRequest
	 * @param request
	 * @return
	 */
	@RequestMapping(method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE, value = "pushreg")
	@ResponseBody
	public IMBResp checkPushRegistered(HttpServletRequest httpRequest, @RequestBody final EmptyReq request) {
		Logger.debug("AlertsController - checkPushRegistered(). Request: " + request, this.getClass());
		
		String logName = startPerformanceLog(httpRequest);
		MobileSession mobileSession = new MobileSessionImpl();
		try {
			mobileSession.getSessionContext(httpRequest);
			validateRequestHeader(request.getHeader(), httpRequest);
			ErrorResp errorResponse = validate(request, httpRequest);
			if (errorResponse.hasErrors())
				return errorResponse;

			Customer customer = mobileSession.getCustomer();

			boolean isOtherUserRegistered = pushNotificationService.isDeviceRegisteredForPush(mobileSession.getDeviceID(), customer.getGcis());
			
			return helper.populatePushRegResponse(populateResponseHeader(ServiceConstants.PUSH_CHECK_REGISTRATION_SERVICE, mobileSession), isOtherUserRegistered);

		} catch (BusinessException e) {
			Logger.info("BusinessException in AlertsController - checkPushRegistered() - [key: " + e.getKey() + "], GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());			
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), e, ServiceConstants.PUSH_CHECK_REGISTRATION_SERVICE, httpRequest);
		} catch (ResourceException e) {
			Logger.error("ResourceException in AlertsController - checkPushRegistered() - [key: " + e.getKey() + "], GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.SYSTEM_UNAVILABLE, ServiceConstants.PUSH_CHECK_REGISTRATION_SERVICE, httpRequest);
		} catch (Exception e) {
			Logger.error("Exception AlertsController - checkPushRegistered(): GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), ResourceException.MOBILE_NON_FINANCIAL_FATAL_ERR,
					ServiceConstants.PUSH_CHECK_REGISTRATION_SERVICE, httpRequest);
		} finally {
			endPerformanceLog(logName);
		}
	}
	
	/**
	 * check another user already registered for push on current device.
	 * 
	 * @param httpRequest
	 * @param request
	 * @return
	 */
	@RequestMapping(method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE, value = "overwritepushreg")
	@ResponseBody
	public IMBResp overwritePushReg(HttpServletRequest httpRequest, @RequestBody final EmptyReq request) {
		Logger.debug("AlertsController - overwritePushReg(). Request: " + request, this.getClass());
		
		String logName = startPerformanceLog(httpRequest);
		MobileSession mobileSession = new MobileSessionImpl();
		try {
			mobileSession.getSessionContext(httpRequest);
			validateRequestHeader(request.getHeader(), httpRequest);
			ErrorResp errorResponse = validate(request, httpRequest);
			if (errorResponse.hasErrors())
				return errorResponse;
			
			pushNotificationService.overwriteRegistration(mbAppHelper.populateIBankCommonData(mobileSession,httpRequest),
					helper.populatePushNotfRegistrationVO(mobileSession), mobileSession.getUserAgentWS());
			
			return helper.populateOverwritePushRegResponse(populateResponseHeader(ServiceConstants.PUSH_OVERWRITE_REGISTRATION_SERVICE, mobileSession), 0);

		} catch (BusinessException e) {
			Logger.info("BusinessException in AlertsController - overwritePushReg() - [key: " + e.getKey() + "], GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());			
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), e, ServiceConstants.PUSH_OVERWRITE_REGISTRATION_SERVICE, httpRequest);
		} catch (ResourceException e) {
			Logger.error("ResourceException in AlertsController - overwritePushReg() - [key: " + e.getKey() + "], GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.SYSTEM_UNAVILABLE, ServiceConstants.PUSH_OVERWRITE_REGISTRATION_SERVICE, httpRequest);
		} catch (Exception e) {
			Logger.error("Exception AlertsController - overwritePushReg(): GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), ResourceException.MOBILE_NON_FINANCIAL_FATAL_ERR,
					ServiceConstants.PUSH_OVERWRITE_REGISTRATION_SERVICE, httpRequest);
		} finally {
			endPerformanceLog(logName);
		}
	}
	
	private List<Alert> getAlertsSummary(Customer customer) throws BusinessException {
		return (List<Alert>) smsAlertsService.getAlertSummary(customer.getGcis(), DateMethods.getUtilDateTime(
				AlertsHelper.ALERT_SUMMARY_DEFAULT_FROM_DATE, AlertsHelper.DEFAULT_DATE_FORMAT), DateMethods.getUtilDateTime(
				AlertsHelper.ALERT_SUMMARY_DEFAULT_TO_DATE, AlertsHelper.DEFAULT_DATE_FORMAT), customer.getGcis());
	}
	
	private List<String> getPushDeviceList(Customer customer ) throws BusinessException{
		
		return pushNotificationService.getPushDeviceList(customer);
		
	}

	public ErrorResp validate(IMBReq serviceRequest, HttpServletRequest request) {
		Logger.info("Service request object - " + ReflectionToStringBuilder.toString(serviceRequest), this.getClass());
		return mbAppValidator.validate(serviceRequest, request);
	}

	public void validateRequestHeader(ReqHeader headerReq, HttpServletRequest request) throws BusinessException {
		Logger.debug("Request header validation: " + ReflectionToStringBuilder.toString(headerReq, ToStringStyle.MULTI_LINE_STYLE), this.getClass());
		mbAppValidator.validateRequestHeader(headerReq, request);
	}

	
	public RespHeader populateResponseHeader(String serviceName, MobileSession mobSession) {
		return mbAppHelper.populateResponseHeader(serviceName, mobSession);
	}

	/**
	 * Response for invalid body request
	 * 
	 * @return
	 */
	@ExceptionHandler( { org.springframework.http.converter.HttpMessageNotReadableException.class })
	@ResponseStatus(org.springframework.http.HttpStatus.OK)
	@ResponseBody
	public IMBResp resolveException() {
		return MBAppUtils.createInvalidMessageBodyResponse(ServiceConstants.ALERTS_SUMMARY_SERVICE);
	}

	@Autowired
	private PerformanceLogger perfLogger;
	
	private String startPerformanceLog(HttpServletRequest httpRequest){
		perfLogger.startAllLogs();
		String logName = MBAppUtils.getLogName(httpRequest);
		perfLogger.startLog(logName);
		return logName;
	}
	
	private void endPerformanceLog(String logName){
		perfLogger.endLog(logName);
		perfLogger.endAllLogs();
	}

}
