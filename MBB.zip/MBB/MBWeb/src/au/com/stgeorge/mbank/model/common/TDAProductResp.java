package au.com.stgeorge.mbank.model.common;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.ArrayList;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_NULL)
public class TDAProductResp implements Serializable {
	
	public String getFrequencyCode() {
		return frequencyCode;
	}
	public void setFrequencyCode(String frequencyCode) {
		this.frequencyCode = frequencyCode;
	}
	public String getFrequency() {
		return frequency;
	}
	public void setFrequency(String frequency) {
		this.frequency = frequency;
	}
	public BigDecimal getInterestRate() {
		return interestRate;
	}
	public void setInterestRate(BigDecimal interestRate) {
		this.interestRate = interestRate;
	}
	public BigDecimal getRangeFrom() {
		return rangeFrom;
	}
	public void setRangeFrom(BigDecimal rangeFrom) {
		this.rangeFrom = rangeFrom;
	}
	public BigDecimal getRangeTo() {
		return rangeTo;
	}
	public void setRangeTo(BigDecimal rangeTo) {
		this.rangeTo = rangeTo;
	}
	public String getSubProdCode() {
		return subProductCode;
	}
	public void setSubProdCode(String subProductCode) {
		this.subProductCode = subProductCode;
	}
	public ArrayList<PaymentInstructionsResp> getPaymentInstructions() {
		return paymentInstructions;
	}
	public void setPaymentInstructions(
			ArrayList<PaymentInstructionsResp> paymentInstructions) {
		this.paymentInstructions = paymentInstructions;
	}

	private String frequencyCode;
	private String frequency;
	private BigDecimal interestRate;
	private BigDecimal rangeFrom;
	private BigDecimal rangeTo;
	private String subProductCode; 
	private ArrayList<PaymentInstructionsResp> paymentInstructions;
	
	private boolean exclIntRate;

	public boolean isExclIntRate() {
  	return exclIntRate;
  }

	public void setExclIntRate(boolean exclIntRate) {
  	this.exclIntRate = exclIntRate;
  }

	
}
