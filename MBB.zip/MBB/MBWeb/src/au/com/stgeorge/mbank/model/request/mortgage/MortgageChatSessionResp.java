package au.com.stgeorge.mbank.model.request.mortgage;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import au.com.stgeorge.mbank.model.common.IMBResp;
import au.com.stgeorge.mbank.model.common.RespHeader;

public class MortgageChatSessionResp implements IMBResp {

	@JsonInclude(Include.NON_NULL)
	private static final long serialVersionUID = 4772527674147971692L;

	private RespHeader header;
	private String sessionID;

	public MortgageChatSessionResp(RespHeader header) {
		super();
		this.header = header;
	}

	public String getSessionID() {
		return sessionID;
	}

	public void setSessionID(String sessionID) {
		this.sessionID = sessionID;
	}

	public RespHeader getHeader() {
		return header;
	}

	public void setHeader(RespHeader header) {
		this.header = header;
	}
}
