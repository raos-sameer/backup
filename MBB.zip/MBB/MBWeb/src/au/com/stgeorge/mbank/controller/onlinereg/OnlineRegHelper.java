/**
 * 
 */
package au.com.stgeorge.mbank.controller.onlinereg;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import au.com.stgeorge.framework.common.exception.ResourceException;
import au.com.stgeorge.framework.common.logging.Logger;
import au.com.stgeorge.framework.common.util.GeneralMethods;
import au.com.stgeorge.framework.common.util.StringMethods;
import au.com.stgeorge.ibank.businessobject.BusinessException;
import au.com.stgeorge.ibank.businessobject.IBankSecurityService;
import au.com.stgeorge.ibank.businessobject.onlinereg.OnlineRegistrationService;
import au.com.stgeorge.ibank.common.cache.IBankParams;
import au.com.stgeorge.ibank.onlinereg.valueobject.OnlineRegReqLogVO;
import au.com.stgeorge.ibank.onlinereg.valueobject.OnlineRegSecureCodeDetails;
import au.com.stgeorge.ibank.onlinereg.valueobject.OnlineRegistrationDetails;
import au.com.stgeorge.ibank.onlinereg.valueobject.RegisterCustomerVO;
import au.com.stgeorge.ibank.service.valueobject.SafiVO;
import au.com.stgeorge.ibank.util.DateUtils;
import au.com.stgeorge.ibank.valueobject.database.CodesVO;
import au.com.stgeorge.ibank.valueobject.database.SecurityCodeVO;
import au.com.stgeorge.mbank.controller.customer.LogonHelper;
import au.com.stgeorge.mbank.model.common.PhoneInfoResp;
import au.com.stgeorge.mbank.model.common.ReqHeader;
import au.com.stgeorge.mbank.model.request.CustomerRegReq;
import au.com.stgeorge.mbank.model.request.OnlineRegReq;
import au.com.stgeorge.mbank.model.response.canretrieval.PhoneTypeEnum;
import au.com.stgeorge.mbank.model.response.onlinereg.SecureCodeInfoResp;
import au.com.stgeorge.mbank.util.MBAppHelper;
import au.com.stgeorge.security.StgSecurityService;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;

@Service
public class OnlineRegHelper {

    @Autowired
    OnlineRegistrationService onlineRegistrationService;
    

    
    @Autowired
    private IBankSecurityService ibankSecurityService;
    
    @Autowired
    private StgSecurityService stgSecurityServiceWithAES;
    
    
    	
    public static final String OPEN_BRACKET = "(";
    public static final String CLOSE_BRACKET = ")";
	private static final String COMMA_SEPERATED_ALPHA = "a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z";
	private static final String COMMA_SEPERATED_NUMBERS = "1,2,3,4,5,6,7,8,9,0";
	private static final String PWD_ENC_SWITC = "PwdEncryptionSwitch";
	private static String  STR_SECRET_KEYMAP= "secretKey";
	private static String STR_PASSWORD_KEYMAP = "passwordMap";
	private static String STR_SECNUM_KEYMAP = "securityNumMap";
	private static String STR_ENCRYPTION_SWITCH = "isEncryptionOn";
	private static final String STR_NAME_ID = "nameId";
	private static final String STR_SOURCE_APPL = "ACE";
	private int securityUniqueIDLen = 0;
	
    public SecureCodeInfoResp populateSecureCodeResponse(OnlineRegSecureCodeDetails onlineRegSecureCodeDetails) throws JsonParseException, JsonMappingException, IOException {
    	SecureCodeInfoResp secureCodeInfoResp = new SecureCodeInfoResp();
	    secureCodeInfoResp.setDeliveryPref(onlineRegSecureCodeDetails.getDeliveryPref());
	    secureCodeInfoResp.setPhonePref(onlineRegSecureCodeDetails.getPhonePref());
	    List<PhoneInfoResp> phoneNumsList = new ArrayList<PhoneInfoResp>();
	    String hashedNumber = null;
	    
	    if (onlineRegSecureCodeDetails.getHome() != null) {
			PhoneInfoResp phoneInfoResp = new PhoneInfoResp();
			phoneInfoResp.setPhoneType(PhoneTypeEnum.HOME.toString());
			if (StringMethods.isEmptyString(onlineRegSecureCodeDetails.getHome().getPhoneNumber())){
				hashedNumber = "";
			} else {			
				hashedNumber = OPEN_BRACKET + onlineRegSecureCodeDetails.getHome().getAreaCode() + CLOSE_BRACKET
					+ LogonHelper.maskPhoneNumber(onlineRegSecureCodeDetails.getHome().getPhoneNumber());
			}
			phoneInfoResp.setPhoneNum(hashedNumber);
			phoneNumsList.add(phoneInfoResp);
	    }
	    
	    if (onlineRegSecureCodeDetails.getWork() != null) {
			PhoneInfoResp phoneInfoResp = new PhoneInfoResp();
			phoneInfoResp.setPhoneType(PhoneTypeEnum.WORK.toString());
			if (StringMethods.isEmptyString(onlineRegSecureCodeDetails.getWork().getPhoneNumber())){
				hashedNumber = "";
			} else {			
				hashedNumber = OPEN_BRACKET + onlineRegSecureCodeDetails.getWork().getAreaCode() + CLOSE_BRACKET
					+ LogonHelper.maskPhoneNumber(onlineRegSecureCodeDetails.getWork().getPhoneNumber());
			}
			phoneInfoResp.setPhoneNum(hashedNumber);
			phoneNumsList.add(phoneInfoResp);
	    }
	    
	    if (onlineRegSecureCodeDetails.getMobile() != null) {
			PhoneInfoResp phoneInfoResp = new PhoneInfoResp();
			phoneInfoResp.setPhoneType(PhoneTypeEnum.MOBILE.toString());
			if (StringMethods.isEmptyString(onlineRegSecureCodeDetails.getMobile().getPhoneNumber())){
				hashedNumber = "";
			} else {			
				hashedNumber = LogonHelper.maskPhoneNumber(onlineRegSecureCodeDetails.getMobile().getAreaCode()
					+ onlineRegSecureCodeDetails.getMobile().getPhoneNumber());
			}
			phoneInfoResp.setPhoneNum(hashedNumber);
			phoneNumsList.add(phoneInfoResp);
	    }
	    
	    if (phoneNumsList.size() > 0) {
	    	secureCodeInfoResp.setPhoneNums(phoneNumsList);
	    }

	    return secureCodeInfoResp;
    }

    public Date validateDateOfBirth(String dateString) throws BusinessException {
		Date dob = null;
		Date currDate = new Date();
		SimpleDateFormat sdf = new SimpleDateFormat(DateUtils.ISO_8601_CALENDAR_DATE_FORMAT_PATTERN);
		sdf.setLenient(false);
		try {
		    dob = sdf.parse(dateString);
		    if (dob.after(currDate)) {
		    	throw new BusinessException(BusinessException.INVALID_DATE_OF_BIRTH);
		    }
		} catch (ParseException e) {
		    throw new BusinessException(BusinessException.INVALID_DATE_OF_BIRTH);
		}
		return dob;
    }

   

    

    private static final String DEVICE_TYPE_TABLET = "TABLET";
    private static final String DEVICE_TYPE_MOBILE = "MOBILE";

    public String getGDWOrigin(ReqHeader req, String origin) {
		StringBuffer tempOrigin = new StringBuffer();
		if (req.getDeviceType() != null && req.getDeviceType().toUpperCase().startsWith(DEVICE_TYPE_TABLET)) {
		    tempOrigin.append(origin.substring(1));
		} else {
		    tempOrigin.append(origin);
		}
		return tempOrigin.toString();
    }


    public OnlineRegReqLogVO populateOnlineRegReqToVO(OnlineRegReq req, String origin,SecurityCodeVO securityCodeVO)throws BusinessException{
    	
		String dOB = null;
		String cardAccNum = null;
		OnlineRegReqLogVO onlineRegReqLogVO = new OnlineRegReqLogVO();
		
		if (isPasswordEncryptionSwitchON(origin) && securityCodeVO != null)
		{
			String secKey = getKeyMapSecretKey(req.getNameId());
			dOB = getRealStringFromMap(req.getDateOfBirth(),securityCodeVO.getPasswordMap(),securityCodeVO.getSecNumMap(),secKey);
			cardAccNum = getRealStringFromMap(req.getAccessNumber(),securityCodeVO.getPasswordMap(),securityCodeVO.getSecNumMap(),secKey);
		}
		else
		{
			dOB = req.getDateOfBirth();
			cardAccNum = req.getAccessNumber().replaceAll("[- ]+", "");
		}
		
	   	onlineRegReqLogVO.setOrigin(origin);
		onlineRegReqLogVO.setBSB(req.getBsbNumber() != null ? req.getBsbNumber().replaceAll("[- ]+", "") : null);
		onlineRegReqLogVO.setCardAcctNum(cardAccNum);
		onlineRegReqLogVO.setDOB(dOB);
		onlineRegReqLogVO.setIssueNum(req.getIssueNumber());
		onlineRegReqLogVO.setRegReqToken(req.getRegReqToken());
		
		return onlineRegReqLogVO;
    }
    
    public OnlineRegReqLogVO populateOnlineRegReqToVOForEFinance(OnlineRegReq req, String origin)throws BusinessException{
    	
		String dOB = null;
		String cardAccNum = null;
		OnlineRegReqLogVO onlineRegReqLogVO = new OnlineRegReqLogVO();
		
//		if (isPasswordEncryptionSwitchON(origin) && securityCodeVO != null)
//		{
//			String secKey = getKeyMapSecretKey(req.getNameId());
//			dOB = getRealStringFromMap(req.getDateOfBirth(),securityCodeVO.getPasswordMap(),securityCodeVO.getSecNumMap(),secKey);
//			cardAccNum = getRealStringFromMap(req.getAccessNumber(),securityCodeVO.getPasswordMap(),securityCodeVO.getSecNumMap(),secKey);
//		}
//		else
//		{
//			dOB = req.getDateOfBirth();
//			cardAccNum = req.getAccessNumber().replaceAll("[- ]+", "");
//		}
		
	   	onlineRegReqLogVO.setOrigin(origin);
		onlineRegReqLogVO.setBSB(req.getBsbNumber() != null ? req.getBsbNumber().replaceAll("[- ]+", "") : null);
		onlineRegReqLogVO.setCardAcctNum(cardAccNum);
		onlineRegReqLogVO.setDOB(dOB);
		onlineRegReqLogVO.setIssueNum(req.getIssueNumber());
		onlineRegReqLogVO.setRegReqToken(req.getRegReqToken());
		
		return onlineRegReqLogVO;
    }
    
    public SafiVO populateSafiVO(HttpServletRequest request, OnlineRegReqLogVO onlineRegReqLogVO) {
		SafiVO safiVO = new SafiVO();
		safiVO.setHttpAccept(request.getHeader("Accept"));
		safiVO.setHttpAcceptChars(request.getHeader("Accept-Charset"));
		safiVO.setHttpAcceptEncoding(request.getHeader("Accept-Encoding"));
		safiVO.setHttpAcceptLanguage(request.getHeader("Accept-Language"));
		safiVO.setHttpReferrer(request.getHeader("Referer"));
		safiVO.setIpAddress(MBAppHelper.resolveIPAddress(request, onlineRegReqLogVO.getOrigin()));
		safiVO.setUserAgent(request.getHeader("User-Agent"));
	
		safiVO.setAccessNumber(onlineRegReqLogVO.getCardAcctNum());
		safiVO.setDateOfBirth(onlineRegReqLogVO.getDOB());
		safiVO.setClientTransactionId(onlineRegReqLogVO.getRegReqToken());
		safiVO.setOrigin(onlineRegReqLogVO.getOrigin());
	
		return safiVO;
    }
    
    
	public RegisterCustomerVO populateRegisterCustomerVO(CustomerRegReq req, OnlineRegistrationDetails onlineRegistrationDetails,String origin,SecurityCodeVO securityCodeVO) throws BusinessException{
		
		String password = null;
		String secNum = null;
		if (isPasswordEncryptionSwitchON(origin) && securityCodeVO != null)
		{
			String secKey = getKeyMapSecretKey( req.getNameId() );
			password = getRealStringFromMap(req.getPassword(),securityCodeVO.getPasswordMap(),securityCodeVO.getSecNumMap(),  secKey);
			secNum = getRealStringFromMap(req.getSecNum(),securityCodeVO.getPasswordMap(),securityCodeVO.getSecNumMap(),  secKey);
		}
		else
		{
			password = req.getPassword();
			secNum = req.getSecNum();
		}
		
		RegisterCustomerVO registerCustomerVO = new RegisterCustomerVO();
		registerCustomerVO.setPwd(password);
		registerCustomerVO.setSecNum(secNum);
		registerCustomerVO.setEmailId(req.getEmail());
		if(onlineRegistrationDetails.isCard()){
			registerCustomerVO.setOnlineRegType(OnlineRegistrationService.CARD);
		} else {
			registerCustomerVO.setOnlineRegType(OnlineRegistrationService.ACCOUNT);
		}
		registerCustomerVO.setOnlineRegID(onlineRegistrationDetails.getCardBSBAcctInfoConcat());
		registerCustomerVO.setCardAcctNum(onlineRegistrationDetails.getCardAcctNum());
		registerCustomerVO.setAcctNum(onlineRegistrationDetails.getAcctNum());
		registerCustomerVO.setBranchKey(onlineRegistrationDetails.getBranchKey());
		registerCustomerVO.setIssueNum(onlineRegistrationDetails.getIssueNum());
		registerCustomerVO.setIsAlreadyRegistered(onlineRegistrationDetails.isAlreadyRegistered());
		registerCustomerVO.seteStatementSubscribe(req.geteStatementSubscribe());
		
		return registerCustomerVO;
	}
	
	private String getKeyMapSecretKey(String nameId)
	{
		return (nameId.substring(nameId.length() - 24, nameId.length()));
	}
	
	private String getEncryptedPasswordKeyMap(String secKey) throws ResourceException
	{
		try
		{
			return stgSecurityServiceWithAES.encryptAndEncode(getAlphaKeyMap(), secKey);
		}
		catch (Exception e)
		{
			Logger.error("OnlineRegHelper.getEncryptedPasswordKeyMap(): Unable to encrypt Password Key Map", e, this.getClass());
			throw new ResourceException(ResourceException.SYSTEM_ERROR);
		}

	}

	private String getAlphaKeyMap()
	{
		String str = getKeyMap(COMMA_SEPERATED_ALPHA);
		Logger.debug("OnlineRegHelper.getAlphaKeyMap(): Real Password KeyMap " + str, this.getClass());
		return str;
	}
	
	private String getKeyMap(String commaSeparated)
	{
		Date d = new Date();
		ArrayList<String> items = new ArrayList<String>(Arrays.asList(commaSeparated.split(",")));
		int itemsSize = items.size() - 1;
		StringBuffer strBuf = new StringBuffer();
		for (int i = itemsSize; i >= 0; i--)
		{
			long rand = GeneralMethods.generateRandom(0, i + 1);
			int index = (int) rand;
			String tempStr = items.get(index);
			items.remove(index);
			strBuf.append(tempStr);
		}
	//	Logger.debug("Generate KeyMap " + strBuf.toString() + " Time Took  " + (new Date().getTime() - d.getTime()), this
		//		.getClass());
		return strBuf.toString();
	}
	
	private String getEncryptedSecurityNumberKeyMap(String secKey) throws ResourceException
	{
		try
		{
			return stgSecurityServiceWithAES.encryptAndEncode(getNumberKeyMap(), secKey);
		}
		catch (Exception e)
		{
			Logger.error("OnlineRegHelper.getEncryptedSecurityNumberKeyMap(): Unable to encrypt Security Number Key Map", e, this.getClass());
			throw new ResourceException(ResourceException.SYSTEM_ERROR);
		}

	}
	
	private String getNumberKeyMap()
	{

		String str = getKeyMap(COMMA_SEPERATED_NUMBERS);
		Logger.debug("OnlineRegHelper.getNumberKeyMap(): Real Security Number KeyMap " + str, this.getClass());
		return str;
	}
	
	private String getDeccryptedSecurityUniqueID(String encryptedText) throws ResourceException
	{		
		try
		{
			String strText = ibankSecurityService.decrypt(encryptedText);
			return strText;
		}
		catch (Exception e)
		{
			Logger.error("OnlineRegHelper.getDeccryptedSecurityUniqueID(): Unable to Decrypt :" + encryptedText, e, OnlineRegHelper.class);
			throw new ResourceException(ResourceException.SYSTEM_ERROR, "OnlineRegHelper.getDeccryptedSecurityUniqueID(): Unable to Decrypt :" + encryptedText);
		}
	}
	
	public void populateKeyMaps(HttpServletRequest request,String origin) throws BusinessException
	{
		

		if ( isPasswordEncryptionSwitchON(origin))
		{
			String encryptedUniqueID = getEncryptedSecurityUniqueID();
			String keyMapSecKey = getKeyMapSecretKey(encryptedUniqueID);
			String pwdKeyMap =  getEncryptedPasswordKeyMap(keyMapSecKey);
			String secKeyMap =  getEncryptedSecurityNumberKeyMap(keyMapSecKey);
			request.setAttribute(STR_SECRET_KEYMAP , keyMapSecKey);
			request.setAttribute(STR_PASSWORD_KEYMAP, pwdKeyMap);
			request.setAttribute(STR_SECNUM_KEYMAP , secKeyMap);
			request.setAttribute(STR_ENCRYPTION_SWITCH , IBankParams.YES );
			request.setAttribute(STR_NAME_ID ,encryptedUniqueID);
			String decryptedText = getDeccryptedSecurityUniqueID(encryptedUniqueID);
			ibankSecurityService.addDecryptedUniqueIDDB(decryptedText,pwdKeyMap,secKeyMap );
		}
		else
		{
			request.setAttribute(STR_ENCRYPTION_SWITCH, IBankParams.NO);
		}
		
	}
	
	private boolean isValidSecurityUniqueID(String encryptedUniqueID, HttpServletRequest request) throws BusinessException
	{
		
		String decryptedUniqueID = null;
		
		if (securityUniqueIDLen == 0)
			securityUniqueIDLen = ibankSecurityService.getLengthOfSecurityUniqueID();
		
		try
		{
			if (StringMethods.isEmptyString(encryptedUniqueID))
			{
				Logger.error("OnlineRegHelper.isValidSecurityUniqueID(): NULL Login Unique ID " + encryptedUniqueID + " IP :" + request.getRemoteAddr() + " True IP >> " + request.getHeader(IBankParams.trueClientIP()), this.getClass());
				return false;
			}
			else
			{
				if (securityUniqueIDLen != 0 && encryptedUniqueID.length() != securityUniqueIDLen)
				{
					Logger.error(
							"OnlineRegHelper.isValidSecurityUniqueID(): Invalid Security Unique ID. Lengegth : " + encryptedUniqueID.length() + ". It should be (Config) : " + securityUniqueIDLen, this
									.getClass());
					return false;
				}
								
			}
			return true;
		}
		catch (Exception e)
		{
			Logger.error("OnlineRegHelper.isValidSecurityUniqueID(): Unable to validate Encrypted Unique ID " + encryptedUniqueID + " IP :" + request.getRemoteAddr() + " True IP >> " + request.getHeader(IBankParams.trueClientIP()), e,
					this.getClass());
			return false;
		}
	}
	
	private SecurityCodeVO getSecurityCodeVO(String decryptedUniqueID) throws BusinessException
	{		
		SecurityCodeVO securityCodeVO = ibankSecurityService.getSecurityCodeVO(decryptedUniqueID);
		return securityCodeVO;
	}
	
	public void deleteSecurityCodeVO(String origin,CustomerRegReq request) throws BusinessException
	{
		boolean isPwdEncOn = getValidPwdEncSwitch(origin, request.getPwdEncswitch());
		
		if(isPwdEncOn){
			String decryptedUniqueID = null;
			decryptedUniqueID = getDeccryptedSecurityUniqueID(request.getNameId());
			ibankSecurityService.deleteSecurityCodeVO(decryptedUniqueID);
		}
	}
	
	private boolean getValidPwdEncSwitch(String origin,String requestPwdEncSwitch)throws BusinessException{

		boolean isPwdEncOn =  isPasswordEncryptionSwitchON(origin);
		String tempPwdSwitch = IBankParams.YES;
		if (!isPwdEncOn )
		{
			tempPwdSwitch = IBankParams.NO;
		}

		if (requestPwdEncSwitch == null ||  ! tempPwdSwitch.equalsIgnoreCase(requestPwdEncSwitch)  )
		{
			Logger.error("OnlineRegHelper.validateAuthenticationData(): Invalid Password encryption switch value from client: " + requestPwdEncSwitch + " Server switch:" + tempPwdSwitch , this.getClass());
			throw new BusinessException(BusinessException.ONLINE_REG_GENERIC_ERROR);
		}
		return isPwdEncOn;
	}
	
	private void isValidUniqueId(HttpServletRequest httpRequest,String origin,String nameId)throws BusinessException{
		
		boolean isValidUniqueId = isValidSecurityUniqueID(nameId,httpRequest);
		
		if(!isValidUniqueId){
			
			Logger.error("OnlineRegHelper.validateAuthenticationData(): Invalid Encryption Key value from client: " + nameId , this.getClass());
			throw new BusinessException(BusinessException.ONLINE_REG_GENERIC_ERROR);
			
		}
	}
	
	public SecurityCodeVO validateAuthenticationData(HttpServletRequest httpRequest,String origin,CustomerRegReq request) throws BusinessException{
		 
			boolean isPwdEncOn = getValidPwdEncSwitch(origin, request.getPwdEncswitch());
			SecurityCodeVO securityCodeVO = null;
			
			if ( isPwdEncOn )
			{
			  isValidUniqueId(httpRequest,origin, request.getNameId());
			  String decryptedUniqueID = getDeccryptedSecurityUniqueID(request.getNameId());
			  securityCodeVO =  getSecurityCodeVO(decryptedUniqueID);
			  if ( securityCodeVO != null && StringMethods.isEmptyString(securityCodeVO.getPasswordMap()) ||  StringMethods.isEmptyString(securityCodeVO.getSecNumMap()) )
			  {
					Logger.error("OnlineRegHelper.validateAuthenticationData(): Password & Sec Num Map is Null. PasswordMap " + securityCodeVO.getPasswordMap() + " Sec Num Map + " + securityCodeVO.getSecNumMap() , this.getClass());
					throw new BusinessException(BusinessException.ONLINE_REG_GENERIC_ERROR);
			  }
			}
			
		return 	securityCodeVO;
			
	}
	
	public SecurityCodeVO validateCardDobData(HttpServletRequest httpRequest,String origin,OnlineRegReq request) throws BusinessException{

		boolean isPwdEncOn = getValidPwdEncSwitch(origin, request.getPwdEncswitch());
		SecurityCodeVO securityCodeVO = null;
		
		if ( isPwdEncOn )
		{
			isValidUniqueId(httpRequest,origin, request.getNameId());
			String decryptedUniqueID = getDeccryptedSecurityUniqueID(request.getNameId());
			securityCodeVO =  getSecurityCodeVO(decryptedUniqueID);
			if ( securityCodeVO != null && StringMethods.isEmptyString(securityCodeVO.getPasswordMap()) ||  StringMethods.isEmptyString(securityCodeVO.getSecNumMap()))
			{
				Logger.error("OnlineRegHelper.validateCardDobData(): Password & Sec Num Map is Null. PasswordMap " + securityCodeVO.getPasswordMap() + " Sec Num Map + " + securityCodeVO.getSecNumMap() , this.getClass());
				throw new BusinessException(BusinessException.ONLINE_REG_GENERIC_ERROR);
			}
		}

		return 	securityCodeVO;

	}
	
	private String getRealStringFromMap(String obfPwd, String encPwdKeyMap, String endsecNumKeyMap, String secKey)
			throws BusinessException
	{
		if (obfPwd == null)
			return null;
		try
		{
			String pwdKeyMap = stgSecurityServiceWithAES.decodeAndDecrypt(encPwdKeyMap, secKey);
			String secKeyMap = stgSecurityServiceWithAES.decodeAndDecrypt(endsecNumKeyMap, secKey);

			String strAlpha = COMMA_SEPERATED_ALPHA.replaceAll(",", "");
			String strNumber = COMMA_SEPERATED_NUMBERS.replaceAll(",", "");

			char[] charPwd = obfPwd.toCharArray();
			StringBuffer strBuf = new StringBuffer();
			for (int i = 0; i < charPwd.length; i++)
			{
				String character = String.valueOf(charPwd[i]);
				// String str = COMMA_SEPERATED_ALPHA.replaceAll(",", "");
				if (StringMethods.isNumber(character))
				{
					int pos = secKeyMap.indexOf(character);
					strBuf.append(pos);
				}
				else
				{
					int pos = pwdKeyMap.indexOf(character);
					strBuf.append(strAlpha.charAt(pos));
				}
			}
			return strBuf.toString();
		}
		catch (Exception e)
		{
			Logger.error("OnlineRegHelper.getRealStringFromMap(): Unable to encrypt Password Key Map", e, this.getClass());
			throw new BusinessException(BusinessException.ONLINE_REG_GENERIC_ERROR);
		}

	}
	
	private boolean isPasswordEncryptionSwitchON(String origin)
	{
		CodesVO codesVO = IBankParams.getCodesData(origin, IBankParams.CONFIGURATION_PROPERTIES, PWD_ENC_SWITC);
		if (codesVO != null)
			return codesVO.getMessage().trim().equalsIgnoreCase("ON");

		return true;
	}

	private  String getEncryptedSecurityUniqueID() throws BusinessException
	{
		try
		{
			String strText =  ibankSecurityService.getSecurityUniqueID();
			String uniqueId = ibankSecurityService.encrypt(strText);
			return uniqueId;
		}
		catch (Exception e)
		{
			Logger.error("OnlineRegHelper.getEncryptedSecurityUniqueID(): Unable to Craete UniqueID ", e, OnlineRegHelper.class);
			throw new BusinessException(BusinessException.ONLINE_REG_GENERIC_ERROR);
		}
	}
	
    
public  RegisterCustomerVO populateLoanApplicationRegisterVO(CustomerRegReq req, String origin,SecurityCodeVO securityCodeVO) throws BusinessException{
		
		String password = null;
		String secNum = null;
	
		String secKey = req.getNameId().substring(req.getNameId().length() - 24, req.getNameId().length());
		password = getRealStringFromMap(req.getPassword(),securityCodeVO.getPasswordMap(),securityCodeVO.getSecNumMap(),  secKey);
		secNum = getRealStringFromMap(req.getSecNum(),securityCodeVO.getPasswordMap(),securityCodeVO.getSecNumMap(),  secKey);	
		
		RegisterCustomerVO registerCustomerVO = new RegisterCustomerVO();
		registerCustomerVO.setPwd(password);
		registerCustomerVO.setSecNum(secNum);
		registerCustomerVO.setEmailId(req.getEmail());		
		registerCustomerVO.seteStatementSubscribe(false);
		registerCustomerVO.setOnlineRegType(OnlineRegistrationService.REG_TYPE);
		registerCustomerVO.setSourceAppl(STR_SOURCE_APPL);		
		return registerCustomerVO;
	}
}
