package au.com.stgeorge.mbank.model.mortgageinfo;

import au.com.stgeorge.ibank.valueobject.mortgage.ChildSegment;
import au.com.stgeorge.ibank.valueobject.mortgage.MortgageAddress;
import au.com.stgeorge.ibank.valueobject.mortgage.PropertyInsightDetails;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_NULL)
public class LoanAssessmentInfo {

	private String outcomeMessage;
	private String customerRequestedLoanAmount;
	private String repaymentAmount;
	private String repaymentFrequency;
	private String finalRateOffer;
	private String campaignMarginExpiryDate;
	private String campaignMargin;
	private Integer loanOutcomeStatus;
	
	
	//purchase property
	private MortgageAddress propertyAddress;
	private String estimatedValue;
	private String depositAmount;
	private String  LMIPremium;
	private String buyingCoststs;
	
	private String purchasePrice;
	
	
	//Cost details
	private String stampDuty;
	private String governmentFees;
	private String legalFees;
	private String annualPackageFee;
	private String bankFees;
	private String monthlyAdminFee;
	
	//private PropertyInsightDetails propertyInsightDetails;
	private boolean propertyInsightUp;
	
	//18E4  changes
	private String loanPropertyValue;
	private String concessionStampDuty;
	private String maxPropPurchaseValue;
	
	private String headerText;

	private String bannerMsg;
	private boolean showBanner;

	private String loanAmount;
	
	//Val Assess Data
	private Boolean valAssessRequired;
	private String valutionStatus;

	private String borrowText;
	private boolean showPropertyPrice;	

	
	public String getLoanPropertyValue() {
		return loanPropertyValue;
	}
	public void setLoanPropertyValue(String loanPropertyValue) {
		this.loanPropertyValue = loanPropertyValue;
	}
	private String segmentName;
	private ChildSegment otherSegmentInfo;
	
	public String getOutcomeMessage() {
		return outcomeMessage;
	}
	public void setOutcomeMessage(String outcomeMessage) {
		this.outcomeMessage = outcomeMessage;
	}
	public String getCustomerRequestedLoanAmount() {
		return customerRequestedLoanAmount;
	}
	public void setCustomerRequestedLoanAmount(
			String customerRequestedLoanAmount) {
		this.customerRequestedLoanAmount = customerRequestedLoanAmount;
	}
	public String getRepaymentAmount() {
		return repaymentAmount;
	}
	public void setRepaymentAmount(String repaymentAmount) {
		this.repaymentAmount = repaymentAmount;
	}
	public String getRepaymentFrequency() {
		return repaymentFrequency;
	}
	public void setRepaymentFrequency(String repaymentFrequency) {
		this.repaymentFrequency = repaymentFrequency;
	}
	public String getFinalRateOffer() {
		return finalRateOffer;
	}
	public void setFinalRateOffer(String finalRateOffer) {
		this.finalRateOffer = finalRateOffer;
	}
	public String getCampaignMarginExpiryDate() {
		return campaignMarginExpiryDate;
	}
	public void setCampaignMarginExpiryDate(String campaignMarginExpiryDate) {
		this.campaignMarginExpiryDate = campaignMarginExpiryDate;
	}
	public String getCampaignMargin() {
		return campaignMargin;
	}
	public void setCampaignMargin(String campaignMargin) {
		this.campaignMargin = campaignMargin;
	}
	
	public MortgageAddress getPropertyAddress() {
		return propertyAddress;
	}
	public void setPropertyAddress(MortgageAddress propertyAddress) {
		this.propertyAddress = propertyAddress;
	}
	public String getEstimatedValue() {
		return estimatedValue;
	}
	public void setEstimatedValue(String estimatedValue) {
		this.estimatedValue = estimatedValue;
	}
	public String getDepositAmount() {
		return depositAmount;
	}
	public void setDepositAmount(String depositAmount) {
		this.depositAmount = depositAmount;
	}
	
	public String getLMIPremium() {
		return LMIPremium;
	}
	public void setLMIPremium(String lMIPremium) {
		LMIPremium = lMIPremium;
	}
	public String getBuyingCoststs() {
		return buyingCoststs;
	}
	public void setBuyingCoststs(String buyingCoststs) {
		this.buyingCoststs = buyingCoststs;
	}
	public String getStampDuty() {
		return stampDuty;
	}
	public void setStampDuty(String stampDuty) {
		this.stampDuty = stampDuty;
	}
	public String getGovernmentFees() {
		return governmentFees;
	}
	public void setGovernmentFees(String governmentFees) {
		this.governmentFees = governmentFees;
	}
	
	public String getLegalFees() {
		return legalFees;
	}
	public void setLegalFees(String legalFees) {
		this.legalFees = legalFees;
	}
	public String getAnnualPackageFee() {
		return annualPackageFee;
	}
	public void setAnnualPackageFee(String annualPackageFee) {
		this.annualPackageFee = annualPackageFee;
	}
	public String getMonthlyAdminFee() {
		return monthlyAdminFee;
	}
	public void setMonthlyAdminFee(String monthlyAdminFee) {
		this.monthlyAdminFee = monthlyAdminFee;
	}
	public Integer getLoanOutcomeStatus() {
		return loanOutcomeStatus;
	}
	public void setLoanOutcomeStatus(Integer loanOutcomeStatus) {
		this.loanOutcomeStatus = loanOutcomeStatus;
	}
	public String getPurchasePrice() {
		return purchasePrice;
	}
	public void setPurchasePrice(String purchasePrice) {
		this.purchasePrice = purchasePrice;
	}
	public String getBankFees() {
		return bankFees;
	}
	public void setBankFees(String bankFees) {
		this.bankFees = bankFees;
	}
	/*public PropertyInsightDetails getPropertyInsightDetails() {
		return propertyInsightDetails;
	}
	public void setPropertyInsightDetails(
			PropertyInsightDetails propertyInsightDetails) {
		this.propertyInsightDetails = propertyInsightDetails;
	}*/
	public boolean isPropertyInsightUp() {
		return propertyInsightUp;
	}
	public void setPropertyInsightUp(boolean propertyInsightUp) {
		this.propertyInsightUp = propertyInsightUp;
	}
	public String getSegmentName() {
		return segmentName;
	}
	public String getMaxPropPurchaseValue() {
		return maxPropPurchaseValue;
	}
	public void setMaxPropPurchaseValue(String maxPropPurchaseValue) {
		this.maxPropPurchaseValue = maxPropPurchaseValue;
	}
	public void setSegmentName(String segmentName) {
		this.segmentName = segmentName;
	}
	public ChildSegment getOtherSegmentInfo() {
		return otherSegmentInfo;
	}
	public void setOtherSegmentInfo(ChildSegment otherSegmentInfo) {
		this.otherSegmentInfo = otherSegmentInfo;
	}
	public String getConcessionStampDuty() {
		return concessionStampDuty;
	}
	public void setConcessionStampDuty(String concessionStampDuty) {
		this.concessionStampDuty = concessionStampDuty;
	}
	public String getHeaderText()
	{
		return headerText;
	}
	public void setHeaderText(String headerText)
	{
		this.headerText = headerText;
	}
	public String getBannerMsg()
	{
		return bannerMsg;
	}
	public void setBannerMsg(String bannerMsg)
	{
		this.bannerMsg = bannerMsg;
	}
	public boolean isShowBanner()
	{
		return showBanner;
	}
	public void setShowBanner(boolean showBanner)
	{
		this.showBanner = showBanner;
	}
	public String getLoanAmount()
	{
		return loanAmount;
	}
	public void setLoanAmount(String loanAmount)
	{
		this.loanAmount = loanAmount;
	}
	public Boolean getValAssessRequired() {
		return valAssessRequired;
	}

	public void setValAssessRequired(Boolean valAssessRequired) {
		this.valAssessRequired = valAssessRequired;
	}

	public String getValutionStatus() {
		return valutionStatus;
	}

	public void setValutionStatus(String valutionStatus) {
		this.valutionStatus = valutionStatus;
	}
	public String getBorrowText()
	{
		return borrowText;
	}
	public void setBorrowText(String borrowText)
	{
		this.borrowText = borrowText;
	}
	public boolean isShowPropertyPrice()
	{
		return showPropertyPrice;
	}
	public void setShowPropertyPrice(boolean showPropertyPrice)
	{
		this.showPropertyPrice = showPropertyPrice;
	}
	


}
