package au.com.stgeorge.mbank.controller.mortgage;

import java.math.BigDecimal;
import java.text.DateFormat;
import java.text.MessageFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Random;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.SerializationUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import au.com.stgeorge.framework.common.logging.Logger;
import au.com.stgeorge.framework.common.model.User;
import au.com.stgeorge.framework.common.util.DateMethods;
import au.com.stgeorge.framework.common.util.StringMethods;
import au.com.stgeorge.ibank.businessobject.BusinessException;
import au.com.stgeorge.ibank.businessobject.HeartBeat;
import au.com.stgeorge.ibank.businessobject.TTService;
import au.com.stgeorge.ibank.businessobject.mortgage.MortgageService;
import au.com.stgeorge.ibank.businessobject.mortgage.MortgageServiceClasHelper.HomeLoanSegmentsEnum;
import au.com.stgeorge.ibank.common.cache.IBankParams;
import au.com.stgeorge.ibank.common.cache.MortgageParams;
import au.com.stgeorge.ibank.loanApplication.util.LoanAppConstants;
import au.com.stgeorge.ibank.mortgage.util.MortgageUtil;
import au.com.stgeorge.ibank.mortgage.util.MortgageUtil.ApplicationStatusEnum;
import au.com.stgeorge.ibank.mortgage.util.MortgageUtil.CustomerSituationEnum;
import au.com.stgeorge.ibank.util.DateUtils;
import au.com.stgeorge.ibank.util.ServiceHelper;
import au.com.stgeorge.ibank.util.StringUtil;
import au.com.stgeorge.ibank.valueobject.ContactDetail;
import au.com.stgeorge.ibank.valueobject.Customer;
import au.com.stgeorge.ibank.valueobject.LabelValueVO;
import au.com.stgeorge.ibank.valueobject.collection.LabelValueMap;
import au.com.stgeorge.ibank.valueobject.mortgage.Applicant;
import au.com.stgeorge.ibank.valueobject.mortgage.Application;
import au.com.stgeorge.ibank.valueobject.mortgage.Asset;
import au.com.stgeorge.ibank.valueobject.mortgage.DMRefDataVO;
import au.com.stgeorge.ibank.valueobject.mortgage.DashBoard;
import au.com.stgeorge.ibank.valueobject.mortgage.DocCategoryDetail;
import au.com.stgeorge.ibank.valueobject.mortgage.DocTypeDetail;
import au.com.stgeorge.ibank.valueobject.mortgage.DocUploadDetail;
import au.com.stgeorge.ibank.valueobject.mortgage.Expense;
import au.com.stgeorge.ibank.valueobject.mortgage.Header;
import au.com.stgeorge.ibank.valueobject.mortgage.Income;
import au.com.stgeorge.ibank.valueobject.mortgage.Lender;
import au.com.stgeorge.ibank.valueobject.mortgage.Liability;
import au.com.stgeorge.ibank.valueobject.mortgage.LoanApplicationReferenceVO;
import au.com.stgeorge.ibank.valueobject.mortgage.LoanOutcome;
import au.com.stgeorge.ibank.valueobject.mortgage.LoanOutcomeInfo;
import au.com.stgeorge.ibank.valueobject.mortgage.LoanType;
import au.com.stgeorge.ibank.valueobject.mortgage.MortgageAddress;
import au.com.stgeorge.ibank.valueobject.mortgage.MortgageCommonData;
import au.com.stgeorge.ibank.valueobject.mortgage.MortgageSessionInfo;
import au.com.stgeorge.ibank.valueobject.mortgage.Property;
import au.com.stgeorge.ibank.valueobject.mortgage.PropertyBand;
import au.com.stgeorge.ibank.valueobject.mortgage.PropertyInsightDetails;
import au.com.stgeorge.ibank.valueobject.mortgage.PropertyInsightValuation;
import au.com.stgeorge.ibank.valueobject.schema.mortgage.AffordabilityServiceRespVO;
import au.com.stgeorge.ibank.valueobject.transfer.IBankCommonData;
import au.com.stgeorge.mbank.controller.customer.LogonHelper;
import au.com.stgeorge.mbank.model.common.AddressResp;
import au.com.stgeorge.mbank.model.common.IMBResp;
import au.com.stgeorge.mbank.model.common.ReqHeader;
import au.com.stgeorge.mbank.model.mortgageinfo.AddressInfo;
import au.com.stgeorge.mbank.model.mortgageinfo.ApplicantInfo;
import au.com.stgeorge.mbank.model.mortgageinfo.ApplicationInfo;
import au.com.stgeorge.mbank.model.mortgageinfo.AssetInfo;
import au.com.stgeorge.mbank.model.mortgageinfo.DashboardInfo;
import au.com.stgeorge.mbank.model.mortgageinfo.DocApplicantInfo;
import au.com.stgeorge.mbank.model.mortgageinfo.DocCategoryDetailInfo;
import au.com.stgeorge.mbank.model.mortgageinfo.DocDetailInfo;
import au.com.stgeorge.mbank.model.mortgageinfo.DocTypeDetailInfo;
import au.com.stgeorge.mbank.model.mortgageinfo.DocUploadDetailInfo;
import au.com.stgeorge.mbank.model.mortgageinfo.DocUploadInfo;
import au.com.stgeorge.mbank.model.mortgageinfo.ExpenseInfo;
import au.com.stgeorge.mbank.model.mortgageinfo.IncomeInfo;
import au.com.stgeorge.mbank.model.mortgageinfo.LenderInfo;
import au.com.stgeorge.mbank.model.mortgageinfo.LiabilityInfo;
import au.com.stgeorge.mbank.model.mortgageinfo.LoanAssessmentInfo;
import au.com.stgeorge.mbank.model.mortgageinfo.LoanTypeInfo;
import au.com.stgeorge.mbank.model.mortgageinfo.PropertyInfo;
import au.com.stgeorge.mbank.model.mortgageinfo.PropertyInsightValuationInfo;
import au.com.stgeorge.mbank.model.request.mortgage.ApplicationReq;
import au.com.stgeorge.mbank.model.request.mortgage.ApplicationResp;
import au.com.stgeorge.mbank.model.request.mortgage.DocUploadDetailReq;
import au.com.stgeorge.mbank.model.request.mortgage.MortgageLogonReq;
import au.com.stgeorge.mbank.model.request.mortgage.PropertyInsightReq;
import au.com.stgeorge.mbank.model.response.ErrorResp;
import au.com.stgeorge.mbank.model.response.mortgage.AffordabilityResp;
import au.com.stgeorge.mbank.model.response.mortgage.LenderDetailsResp;
import au.com.stgeorge.mbank.model.response.mortgage.LoanAssessmentResp;
import au.com.stgeorge.mbank.model.response.mortgage.MortgageLogonResp;
import au.com.stgeorge.mbank.model.response.mortgage.PersonalDetailResp;
import au.com.stgeorge.mbank.model.response.mortgage.PropertyInsightResp;
import au.com.stgeorge.mbank.session.IGenericSession;
import au.com.stgeorge.mbank.session.MobileSession;
import au.com.stgeorge.mbank.session.MobileSessionImpl;
import au.com.stgeorge.mbank.util.MBAppConstants;
import au.com.stgeorge.mbank.util.MBAppHelper;
import au.com.stgeorge.mbank.util.MBAppUtils;
import au.com.stgeorge.mbank.util.ServiceConstants;
import au.com.stgeorge.perflogger.PerformanceLogger;
import au.com.westpac.gn.locationmanagement.services.locationmanagement.xsd.retrievepostaladdress.v1.svc0454.AddressType;

import com.fasterxml.jackson.databind.ObjectMapper;



@Service
public class MortgageHelper {
	
	private static final int MIN_NUMBER_OF_BEDROOMS = 0;
	private static final int MAX_NUMBER_OF_BEDROOMS = 20;
	private static final int MIN_NUMBER_OF_BATHROOMS = 0;
	private static final int MAX_NUMBER_OF_BATHROOMS = 20;
	private static final int MIN_NUMBER_OF_CARSPACES = 0;
	private static final int MAX_NUMBER_OF_CARSPACES = 99;
	
	@Autowired
	private MortgageRefDataHelper mortgageRefDataHelper; 
	
	@Autowired
	private TTService ttService;
	
	@Autowired
	private MortgageParams mortgageParams;
	
	@Autowired
	private MortgageService mortgageService;
	
	@Autowired
	private MBAppHelper mbAppHelper;
	
	@Autowired
	private LogonHelper logonHelper;
	private Application applicationVO;
	
	private static final BigDecimal REFINANCE_CUSTOMER_REQUESTED_MIN_LOAN_AMT = new BigDecimal(50000);
	private static final BigDecimal REFINANCE_CUSTOMER_REQUESTED_MAX_LOAN_AMT = BigDecimal.valueOf(9999900);
	private static final BigDecimal REFINANCE_PROPERTY_MIN_ESTIMATED_VALUE = BigDecimal.valueOf(65000);
	private static final BigDecimal REFINANCE_PROPERTY_MAX_ESTIMATED_VALUE = BigDecimal.valueOf(9999999);
	
	private static final BigDecimal CUSTOMER_REQUESTED_LOAN_MIN_AMT = BigDecimal.valueOf(50000);
	private static final BigDecimal LOAN_MIN_AMT = BigDecimal.valueOf(25000);
	private static final BigDecimal LOAN_MAX_AMT = BigDecimal.valueOf(9999900);	
	private static final BigDecimal DEPOSIT_MIN_AMT = BigDecimal.ONE;
	private static final BigDecimal DEPOSIT_MAX_AMT = BigDecimal.valueOf(999999999);
	private static final long LOAN_TERM_MIN = 5;
	private static final long LOAN_TERM_MAX = 30;
	private static final long LOAN_TERM_MAX_OFFER = 35;
	private static final BigDecimal RENTAL_INCOME_MIN_AMT = BigDecimal.ZERO;
	private static final BigDecimal RENTAL_INCOME_MAX_AMT = BigDecimal.valueOf(999999999);
	
	public static String MASK_EMAIL = "(?<=emailAddress\":\")(.*?)(?=\")";
	public static String MASK_DATEOFBIRTH = "(?<=dateOfBirth\":\")(.*?)(?=\")";
	public static String MASK_MOBILENUMBER = "(?<=mobileNum\":\")(.*?)(?=\")";
	
	public boolean validateAndUpdateRequestTransactionNum(MobileSession mobileSession, ReqHeader reqHeader) throws BusinessException {
		boolean valid = true;
		if(reqHeader != null && mobileSession != null) {
			String requestTransactionNum = reqHeader.getTranSeqnbr();
			String sessionTransactionNum = mobileSession.getHomeLoanApplicationTransactionNum();
			if(!StringUtils.isEmpty(requestTransactionNum)) {
				if(!StringUtils.isEmpty(sessionTransactionNum)){
					int sessTranNum = (new Integer(sessionTransactionNum)).intValue();
					int reqTranNum = (new Integer(requestTransactionNum)).intValue();
					if(reqTranNum <= sessTranNum) {
						valid = false;
					} else {
						//Set the latest transaction Number on session
						mobileSession.setHomeLoanApplicationTransactionNum(requestTransactionNum);
					}
				} else {
					throw new BusinessException(BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE);
				}				
			}
		}
		return valid;
	}
	
	public void checkApplicationSubmitted(Long applicationNum, MobileSession mobileSession) throws BusinessException {
	   	 //Check if application is already submitted 
		try{
			if ( applicationNum != null && applicationNum.longValue() > 0  )
			{
				mortgageService.checkApplicationSubmitted(applicationNum);
			}
		}
       catch (BusinessException e)
       {
	      	if (e.getKey() == BusinessException.DIGITAL_MORTGAGE_APPLICATION_SUBMITTED) {
	      		Logger.error("Application Already Submitted: " + e.getMessage(), e, getClass());
	      		mobileSession.invalidateSession();
	      		throw new BusinessException(BusinessException.MORTGAGE_SESSION_SHARING_ERROR);
	      	}			
       }
  	}
	
	public void saveApplication(Application applicationVO, Application sessionApplicationVO, MortgageCommonData  mortgageCommonData, IBankCommonData iBankCommonData,  MobileSession mobileSession, ReqHeader reqHeader) throws BusinessException {
	   	try
		{	
	   		//Check if application is already submitted
	   		checkApplicationSubmitted(mortgageCommonData.getApplicationNumber(), mobileSession);

	   		//Verify request transaction number with session transaction number if the request is new or stale(old)
	   		//If it is the stale/old request DONOT continue with save.
	   		if(!validateAndUpdateRequestTransactionNum(mobileSession, reqHeader)) {
	   			return;
	   		}
	   		
			Application sessionHomeLoanApplication = mobileSession.getHomeLoanApplication();
			Application masterApplicationVO = (Application)SerializationUtils.clone(applicationVO);
			ObjectMapper mapper = new ObjectMapper();
			
			Logger.debug("SAVE START========MortageHelper.saveApplication() - Data Set For Save: " + hashSensitiveData(mapper.writeValueAsString(applicationVO)), this.getClass() ) ;
			Application updatetedApplication = mortgageService.save(applicationVO, sessionHomeLoanApplication, mortgageCommonData, iBankCommonData);
			if(updatetedApplication != null) {
				updateApplicationInSession(  updatetedApplication ,  masterApplicationVO ,  mobileSession );
			} 
		}
       catch (BusinessException e)
        {
	      	if (e.getKey() == BusinessException.MORTGAGE_SESSION_SHARING_ERROR) {
	      		Logger.error("Application could not be saved - application already submitted: " + e.getMessage(), e, getClass());
	      		throw e;
	      	}			
        }		
	   	catch ( Exception e)
		{   
			Logger.info("========Error in Save Data:" , e,  this.getClass());
			throw new BusinessException(BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE);
		}
	}
	
	public AffordabilityResp getAffordabilityServiceResp(AffordabilityServiceRespVO  affordabilityRespVO) throws BusinessException {
		AffordabilityResp affordabilityServiceResp = new AffordabilityResp();
		
		//errors
		if (affordabilityRespVO.getFaultResponseSegment() != null && affordabilityRespVO.getFaultResponseSegment().getErrors() != null && !affordabilityRespVO.getFaultResponseSegment().getErrors().isEmpty()) {
			throw new BusinessException(BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE);
		}
		
		//populate response section
		if (affordabilityRespVO.getSuccessResponseSegment() != null) {
			affordabilityServiceResp.setInterestRate(affordabilityRespVO.getSuccessResponseSegment().getInterestRate());
			affordabilityServiceResp.setMaximumLoanAmount(affordabilityRespVO.getSuccessResponseSegment().getMaximumLoanAmount());
			affordabilityServiceResp.setRepaymentAmount(affordabilityRespVO.getSuccessResponseSegment().getRepaymentAmount());
			affordabilityServiceResp.setRepaymentFrequency(affordabilityRespVO.getSuccessResponseSegment().getRepaymentFrequency());
		}
	  return affordabilityServiceResp;
	}
	

	public void validateLoanType(ApplicationInfo application,boolean offerEligibility) throws BusinessException {		
		boolean isLoanTypeComplete = application.getDashboard().isLoanTypeStatusInd();
		boolean isNewProperty = (application.getLoanType().getLoanType() != null) ? application.getLoanType().getLoanType().equalsIgnoreCase(MortgageUtil.LoanTypeEnum.NEW_PROPERTY.getType()) : true;
				
		LoanTypeInfo loanType = application.getLoanType();
		//Validate against reference data
		
		//Validate "productName" code  against ref data
		if(!StringMethods.isEmptyString(loanType.getProductType())) {			
			if(!mortgageRefDataHelper.isValidCode(mortgageParams.getProductNameRefData(MortgageUtil.COMPASS_REFERENCE_DATA_STATUS_IN_USE),loanType.getProductType())) {
				Logger.error("Not a valid format for Product. "+loanType.getProductType(), this.getClass());
				throw new BusinessException(BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE);
			}			
		}else if(isLoanTypeComplete){
			Logger.error("Loan Type incomplete. ", this.getClass());
			throw new BusinessException(BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE);
		}

		//Validate "propertyType/loanPurpose" code  against ref data
		if(!StringMethods.isEmptyString(loanType.getLoanPurpose())) {
			if(!mortgageRefDataHelper.isValidCode(mortgageParams.getLoanPurposeRefData(MortgageUtil.COMPASS_REFERENCE_DATA_STATUS_IN_USE),loanType.getLoanPurpose())) {
				Logger.error("Not a valid format for loan purpose. "+loanType.getLoanPurpose(), this.getClass());
				throw new BusinessException(BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE);
			}			
		}else if(isLoanTypeComplete){
			Logger.error("Loan Type incomplete. ", this.getClass());
			throw new BusinessException(BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE);
		}
		
		//Validate "repaymentType" code  against ref data
		if(!StringMethods.isEmptyString(loanType.getRepaymentType())) {
			if(!mortgageRefDataHelper.isValidCode(mortgageParams.getRepaymentTypeRefData(MortgageUtil.COMPASS_REFERENCE_DATA_STATUS_IN_USE),loanType.getRepaymentType())) {
				Logger.error("Not a valid format for repayment type. "+loanType.getRepaymentType(), this.getClass());
				throw new BusinessException(BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE);
			}			
		}else if(isLoanTypeComplete){
			Logger.error("Loan Type incomplete. ", this.getClass());
			throw new BusinessException(BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE);
		}
		
		//Validate "repaymentFrequency" code  against ref data
		if(!StringMethods.isEmptyString(loanType.getRepaymentFrequency())) {
			if(!mortgageRefDataHelper.isValidCode(mortgageParams.getRepaymentFrequencyRefData(MortgageUtil.COMPASS_REFERENCE_DATA_STATUS_IN_USE),loanType.getRepaymentFrequency())) {
				Logger.error("Not a valid format for repayment frequency. "+loanType.getRepaymentFrequency(), this.getClass());
				throw new BusinessException(BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE);
			}			
		} else if(isLoanTypeComplete){
			Logger.error("Loan Type incomplete. ", this.getClass());
			throw new BusinessException(BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE);
		}
		
		if (isNewProperty) {
			//Validate "customer situation" code  against ref data
			if (!StringMethods.isEmptyString(loanType.getCustomerSituation())) {
				if(!mortgageRefDataHelper.isValidCode(mortgageParams.getCustomerSituationRefData(MortgageUtil.COMPASS_REFERENCE_DATA_STATUS_IN_USE),loanType.getCustomerSituation())) {
					Logger.error("Not a valid format for customer situation. "+loanType.getCustomerSituation(), this.getClass());
					throw new BusinessException(BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE);
				}			
			} else if(isLoanTypeComplete) {
				Logger.error("Loan Type incomplete. ", this.getClass());
				throw new BusinessException(BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE);
			}		
		} else {
			//validate the refinance property information
			PropertyInfo refinanceProperty = null;
			for (PropertyInfo property : application.getProperties()) {
				if (property.getRefinanceInd() != null && property.getRefinanceInd()) {
					refinanceProperty = property;
					break;
				}
			}
			
			//check if the loan type is complete but there is no refinance property
			if (refinanceProperty == null && isLoanTypeComplete) {
				Logger.error("Loan Type incomplete. ", this.getClass());
				throw new BusinessException(BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE);
			} else if (refinanceProperty != null) {			
				validateRefinanceProperty(refinanceProperty, isLoanTypeComplete);	
				
				//Validate Refinance Property Rental Income if loanPurpose is investment
				if (!StringMethods.isEmptyString(loanType.getLoanPurpose()) && MortgageUtil.LOAN_PURPOSE_INVESTMENT.equals(loanType.getLoanPurpose())) {
					validateRefinancePropertyRentalIncome(application, refinanceProperty, isLoanTypeComplete);
				}
				
				boolean validateLoandAmount = application.getValidateRefinanceLoanAmount() != null ? application.getValidateRefinanceLoanAmount() : true;
				validateRefinanceLVR(loanType, refinanceProperty, isLoanTypeComplete, validateLoandAmount);
			}
		}
		
		if(loanType.getNumOfApplicants() < 1 || loanType.getNumOfApplicants() > 2)
		{
			Logger.error("NumOfApplicants not valid", this.getClass());
			throw new BusinessException(BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE);
		}
		
		//Validate
		if(loanType.getPurchaseProperty() != null && !StringMethods.isEmptyString(loanType.getPurchaseProperty().getPropertyType())) {
			if(!mortgageRefDataHelper.isValidCode(mortgageParams.getPropertyTypeRefData(MortgageUtil.COMPASS_REFERENCE_DATA_STATUS_IN_USE),loanType.getPurchaseProperty().getPropertyType())) {
				Logger.error("MortgageHelper - Purchase property.getPropertyType() is in incorrect format. ", this.getClass());
				throw new BusinessException(BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE);
			}			
		}
				
		if(isLoanTypeComplete) {			
			if (isNewProperty) {
				if(CustomerSituationEnum.FOUND_ONE.getSituation().equalsIgnoreCase(loanType.getCustomerSituation()) || CustomerSituationEnum.SIGNED_CONTRACT.getSituation().equalsIgnoreCase(loanType.getCustomerSituation())){
					if(!StringMethods.isEmptyString(loanType.getLoanAmt()) ){
						
						BigDecimal amt = new BigDecimal(loanType.getLoanAmt());
						
						/*"min": 25000,
					      "max": 9999900,
					      */
						if(amt.compareTo(LOAN_MIN_AMT) < 0 || amt.compareTo(LOAN_MAX_AMT) > 0 || BigDecimal.ZERO.compareTo(amt.remainder(BigDecimal.valueOf(100))) !=0)
						{
							Logger.error("Loan Type incomplete LoanAmt", this.getClass());
							throw new BusinessException(BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE);
						}										
					}
					else{
						Logger.error("Loan Type incomplete LoanAmt", this.getClass());
						throw new BusinessException(BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE);
					}
	
					if(loanType.getNewPropertyInd() == null ){
						Logger.error("Loan Type incomplete NewPropertyInd", this.getClass());
						throw new BusinessException(BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE);
	
					}					
				}
			
				if(!loanType.getCalculateForMeInd()) {
					if(!StringMethods.isEmptyString(loanType.getCustRequestedLoanAmt()) ){						
						BigDecimal amt = new BigDecimal(loanType.getCustRequestedLoanAmt());
						
						/*"min":50000,
					      "max": 9999900,
					      */
						if(amt.compareTo(CUSTOMER_REQUESTED_LOAN_MIN_AMT) < 0 || amt.compareTo(LOAN_MAX_AMT) > 0 || BigDecimal.ZERO.compareTo(amt.remainder(BigDecimal.valueOf(100))) !=0)
						{
							Logger.error("Loan Type incomplete CustRequestedLoanAmt", this.getClass());
							throw new BusinessException(BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE);
						}										
					}
					else{
						Logger.error("Loan Type incomplete CustRequestedLoanAmt", this.getClass());
						throw new BusinessException(BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE);
					}
				}
			
				if(!StringMethods.isEmptyString(loanType.getDepositAmount()) ) {					
					BigDecimal amt = new BigDecimal(loanType.getDepositAmount());
					
					/*  "min": 1,
			      		"max": 999999999
				      */
					if(amt.compareTo(DEPOSIT_MIN_AMT) < 0 || amt.compareTo(DEPOSIT_MAX_AMT) > 0)
					{
						Logger.error("Loan Type incomplete DepositAmount", this.getClass());
						throw new BusinessException(BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE);
					}										
				}
				else{
					Logger.error("Loan Type incomplete DepositAmount", this.getClass());
					throw new BusinessException(BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE);
				}							
				
				//Mandatory validation for PropertyType
				if(loanType.getPurchaseProperty() != null && StringMethods.isEmptyString(loanType.getPurchaseProperty().getPropertyType())){
					   Logger.error(" request.getPurchaseProperty().getPropertyType() Value not provided:", this.getClass());
					   throw new BusinessException(BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE);		

				}
				
				//Validate Purchase Property Rental Income if loanPurpose is investment
				if(!StringMethods.isEmptyString(loanType.getLoanPurpose()) && MortgageUtil.LOAN_PURPOSE_INVESTMENT.equals(loanType.getLoanPurpose())) {
					if(!StringMethods.isEmptyString(loanType.getRentalIncome()) ){
						BigDecimal amt = new BigDecimal(loanType.getRentalIncome());
						// "min": 0, "max": 999999999
						if(amt.compareTo(RENTAL_INCOME_MIN_AMT) < 0 || amt.compareTo(RENTAL_INCOME_MAX_AMT) > 0)
						{
							Logger.error("Loan Type incomplete RentalIncome", this.getClass());
							throw new BusinessException(BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE);
						}										
					}
					else{
						Logger.error("Loan Type incomplete RentalIncome", this.getClass());
						throw new BusinessException(BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE);
					}
					
					//Validate "rentalIncomeFrequency" code  against ref data
					if(!StringMethods.isEmptyString(loanType.getRentalIncomeFrequency())) {
						if(!mortgageRefDataHelper.isValidCode(mortgageParams.getFrequencyRefData(MortgageUtil.COMPASS_REFERENCE_DATA_STATUS_IN_USE),loanType.getRentalIncomeFrequency())) {
							Logger.error("Not a valid format for RentalIncomeFrequency"+loanType.getRentalIncomeFrequency(), this.getClass());
							throw new BusinessException(BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE);
						}			
					} else if(isLoanTypeComplete){
						Logger.error("Loan Type incomplete RentalIncomeFrequency", this.getClass());
						throw new BusinessException(BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE);
					}
				}
			}
			if(!StringMethods.isEmptyString(loanType.getLoanTerm())) {
				int term = Integer.valueOf(loanType.getLoanTerm()).intValue();
				Boolean dmNewLoanTermSwitch = IBankParams.getSwitch(IBankParams.DEFAULT_ORIGIN, IBankParams.MORTGAGE_NEW_LOAN_TERM_SWITCH);
			if(dmNewLoanTermSwitch!=null && dmNewLoanTermSwitch==true){	
				if(offerEligibility){
					
					
					if(term < LOAN_TERM_MIN || term > LOAN_TERM_MAX_OFFER)
					{
						Logger.error("Loan Type incomplete LoanTerm", this.getClass());
						throw new BusinessException(BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE);
					}	
					
				}
				else{
					if(term < LOAN_TERM_MIN || term > LOAN_TERM_MAX)
					{
					if(application.getDashboardIntroInd()){
							loanType.setLoanTerm(String.valueOf(LOAN_TERM_MAX));
						}
					else{
						throw new BusinessException(BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE);
					}
					
						/*Logger.error("Loan Type incomplete LoanTerm", this.getClass());
						throw new BusinessException(BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE);*/
					}
				}
			}	
			else{
				if(term < LOAN_TERM_MIN || term > LOAN_TERM_MAX_OFFER)
				{
					Logger.error("Loan Type incomplete LoanTerm", this.getClass());
					throw new BusinessException(BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE);
				}	
			}
			}
		}
	}

	private void validateRefinancePropertyRentalIncome(ApplicationInfo application, PropertyInfo refinanceProperty, boolean isLoanTypeComplete) throws BusinessException {
		if (refinanceProperty.getRentalIncomeInd() != null) {
			if (refinanceProperty.getRentalIncomeInd()) {
				IncomeInfo rentalIncome = getRentalIncomeRefinanceProperty(application, refinanceProperty);
				
				if (rentalIncome == null) {
					Logger.error("Loan Type incomplete RentalIncome", this.getClass());
					throw new BusinessException(BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE);
				}
				
				if (!StringMethods.isEmptyString(rentalIncome.getBaseAmt()))
				{
					BigDecimal amt = new BigDecimal(rentalIncome.getBaseAmt());
					
					// "min": 0, "max": 999999999
					if (amt.compareTo(RENTAL_INCOME_MIN_AMT) < 0 || amt.compareTo(RENTAL_INCOME_MAX_AMT) > 0) {
						Logger.error("Loan Type incomplete RentalIncome", this.getClass());
						throw new BusinessException(BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE);
					}	
				}
				
				//Validate "rentalIncomeFrequency" code  against ref data
				if (!StringMethods.isEmptyString(rentalIncome.getBaseFrequency())) {
					if(!mortgageRefDataHelper.isValidCode(mortgageParams.getFrequencyRefData(MortgageUtil.COMPASS_REFERENCE_DATA_STATUS_IN_USE), rentalIncome.getBaseFrequency())) {
						Logger.error("Not a valid format for RentalIncomeFrequency" + rentalIncome.getBaseFrequency(), this.getClass());
						throw new BusinessException(BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE);
					}			
				} else if (isLoanTypeComplete) {
					Logger.error("Loan Type incomplete RentalIncomeFrequency", this.getClass());
					throw new BusinessException(BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE);
				}
			}
		} else if (isLoanTypeComplete) {
			Logger.error("Loan Type incomplete RentalIncome", this.getClass());
			throw new BusinessException(BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE);
		}
	}

	private IncomeInfo getRentalIncomeRefinanceProperty(ApplicationInfo application, PropertyInfo refinanceProperty) {
		IncomeInfo income = null;
		if (application.getApplicants() != null) {
			for (ApplicantInfo applicant : application.getApplicants()) {
				//get income for primary applicant
				if (MortgageUtil.ApplicantIndexEnum.PRIMARY.getValue() == applicant.getIndex()) {
					if (applicant.getIncomes() != null && applicant.getIncomes().size() > 0) {
						List<IncomeInfo> incomes = applicant.getIncomes();
						for (IncomeInfo incomeInfo : incomes) {
							if (MortgageUtil.IncomeTypeEnum.RentalIncome.getValue().equals(incomeInfo.getIncomeType())) {
								if (refinanceProperty.getIndex() == incomeInfo.getPropertyIndex()) {
									income = incomeInfo; 
									break;
								}
							}
						}
					}
				}
			}
		}
					
		return income;
	}

	private void validateRefinanceLVR(LoanTypeInfo loanType, PropertyInfo refinanceProperty, boolean isLoanTypeComplete, boolean validateLoanAmount) throws BusinessException {
		Integer lvr = null;
		if(!StringMethods.isEmptyString(loanType.getRepaymentType()) && MortgageUtil.REPAYMENT_TYPE_INTEREST_ONLY.equals(loanType.getRepaymentType())) {
			lvr = mortgageRefDataHelper.getRefinanceInterestOnlyLVR();							
		} else if(!StringMethods.isEmptyString(loanType.getRepaymentType()) && MortgageUtil.REPAYMENT_TYPE_PRINCIPLE_AND_INTEREST.equals(loanType.getRepaymentType())) {
			lvr = mortgageRefDataHelper.getRefinancePrincipalAndInterestLVR();
		}
		
		BigDecimal requestedAmt = null;
		BigDecimal estimatedValue = null;
		
		if (validateLoanAmount) {
			if (!StringMethods.isEmptyString(loanType.getCustRequestedLoanAmt())) {					
				requestedAmt = new BigDecimal(loanType.getCustRequestedLoanAmt());
				
				/*"min": 10000,
			      "max": 9999900,
			      */
				BigDecimal minLoanAmount = getDMCodesDataRefinanceMinimumAmount();
				if (minLoanAmount == null) {
					minLoanAmount = REFINANCE_CUSTOMER_REQUESTED_MIN_LOAN_AMT;
				}
				
				if (requestedAmt.compareTo(minLoanAmount) < 0 || requestedAmt.compareTo(REFINANCE_CUSTOMER_REQUESTED_MAX_LOAN_AMT) > 0 || BigDecimal.ZERO.compareTo(requestedAmt.remainder(BigDecimal.valueOf(100))) !=0)
				{
					Logger.error("Not a valid CustRequestedLoanAmt." + loanType.getCustRequestedLoanAmt(), this.getClass());
					throw new BusinessException(BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE);
				}
			}
			else if (isLoanTypeComplete){
				Logger.error("Loan Type incomplete CustRequestedLoanAmt", this.getClass());
				throw new BusinessException(BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE);
			}
		}
		
		if (!StringMethods.isEmptyString(refinanceProperty.getCustomerEstimatedValue())) {					
			estimatedValue = new BigDecimal(refinanceProperty.getCustomerEstimatedValue());
			
			/*"min": 10000,
		      "max": 9999900,
		      */
			if (estimatedValue.compareTo(REFINANCE_PROPERTY_MIN_ESTIMATED_VALUE) < 0 || estimatedValue.compareTo(REFINANCE_PROPERTY_MAX_ESTIMATED_VALUE) >= 0)
			{
				Logger.error("Not a valid CustomerEstimatedValue." + refinanceProperty.getCustomerEstimatedValue(), this.getClass());
				throw new BusinessException(BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE);
			}
		}
		else if (isLoanTypeComplete){
			Logger.error("Loan Type incomplete CustomerEstimatedValue", this.getClass());
			throw new BusinessException(BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE);
		}
		
		if (requestedAmt != null && estimatedValue != null && lvr != null) {
			if (requestedAmt.divide(estimatedValue, 2).multiply(new BigDecimal(100)).compareTo(new BigDecimal(lvr)) > 0) {
				Logger.error("Not a valid CustRequestedLoanAmt. " + loanType.getCustRequestedLoanAmt() + "", this.getClass());
				throw new BusinessException(BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE);
			}
		}
	}
	
	private void validateRefinanceProperty(PropertyInfo refinanceProperty, boolean isLoanTypeComplete) throws BusinessException {
		//address will be validated in validateAssetInfo method
		
		//Validate "property type" code against ref data
		if (!StringMethods.isEmptyString(refinanceProperty.getPropertyType())) {
			if (!mortgageRefDataHelper.isValidCode(mortgageParams.getPropertyTypeRefinRefData(MortgageUtil.COMPASS_REFERENCE_DATA_STATUS_IN_USE), refinanceProperty.getPropertyType())) {
				Logger.error("Not a valid format for refinane property type. "+ refinanceProperty.getPropertyType(), this.getClass());
				throw new BusinessException(BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE);
			}			
		} else if(isLoanTypeComplete) {
			Logger.error("Loan Type incomplete. ", this.getClass());
			throw new BusinessException(BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE);
		}
		
		//Validate "number of bedrooms" 
		if (refinanceProperty.getBedrooms() != null && (refinanceProperty.getBedrooms() < MIN_NUMBER_OF_BEDROOMS || refinanceProperty.getBedrooms() > MAX_NUMBER_OF_BEDROOMS)) {
			Logger.error("Loan Type incomplete NumberOfBedrooms", this.getClass());
			throw new BusinessException(BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE);									
		}
		//Validate "number of bathrooms"		
		if (refinanceProperty.getBathrooms() != null && (refinanceProperty.getBathrooms() < MIN_NUMBER_OF_BATHROOMS || refinanceProperty.getBathrooms() > MAX_NUMBER_OF_BATHROOMS)) {
			Logger.error("Loan Type incomplete NumberOfBathrooms", this.getClass());
			throw new BusinessException(BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE);										
		}
		//Validate "number of car spaces" 		
		if (refinanceProperty.getCarparks() != null && (refinanceProperty.getCarparks() < MIN_NUMBER_OF_CARSPACES || refinanceProperty.getCarparks() > MAX_NUMBER_OF_CARSPACES)) {
			Logger.error("Loan Type incomplete NumberOfCarSpaces", this.getClass());
			throw new BusinessException(BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE);										
		}
	}
	
	//New 
	
	public LoanType populateLoanTypeInfo(LoanTypeInfo loanType, MobileSession mobileSession, IBankCommonData iBankCommonData, PerformanceLogger perfLogger) throws BusinessException {
		au.com.stgeorge.ibank.valueobject.mortgage.LoanType loanTypeVO = new au.com.stgeorge.ibank.valueobject.mortgage.LoanType();
		
		loanTypeVO.setCalculateForMeInd(loanType.getCalculateForMeInd());
		loanTypeVO.setCombinedNumDependants(loanType.getCombinedNumDependants());//TODO Do we need at the time of getting ref no.
		
		if(!StringMethods.isEmptyString(loanType.getCustRequestedLoanAmt()) ){
			loanTypeVO.setCustRequestedLoanAmt(new BigDecimal(loanType.getCustRequestedLoanAmt()));
		}
		loanTypeVO.setCustomerSituation(loanType.getCustomerSituation());
		if(!StringMethods.isEmptyString(loanType.getDepositAmount()) ){
			loanTypeVO.setDepositAmount(new BigDecimal(loanType.getDepositAmount()));
		}
		loanTypeVO.setFirstHomeBuyerInd(loanType.getFirstHomeBuyerInd());
		
		if(!StringMethods.isEmptyString(loanType.getLoanAmt()) ){
			loanTypeVO.setLoanAmt(new BigDecimal(loanType.getLoanAmt()));
		}
		loanTypeVO.setLoanPurpose(loanType.getLoanPurpose());
		if(!StringMethods.isEmptyString(loanType.getLoanTerm()) ){
			loanTypeVO.setLoanTerm(new Long(loanType.getLoanTerm()));
		}
		
		if(!StringMethods.isEmptyString(loanType.getFixedLoanTerm()) ){
			loanTypeVO.setFixedLoanTerm(new Long(loanType.getFixedLoanTerm()));
		}
		
		if(!StringMethods.isEmptyString(loanType.getInterestOnlyTerm()) ){
			loanTypeVO.setInterestOnlyTerm(new Long(loanType.getInterestOnlyTerm()));
		}
		
		loanTypeVO.setLoanType(loanType.getLoanType());
		loanTypeVO.setNumbOfApplicants(loanType.getNumOfApplicants());
		loanTypeVO.setProductType(loanType.getProductType());
		if(!StringMethods.isEmptyString(loanType.getRentalIncome()) ){
			loanTypeVO.setRentalIncome(new BigDecimal(loanType.getRentalIncome()));
		}
		loanTypeVO.setRentalIncomeFrequency(loanType.getRentalIncomeFrequency());
		loanTypeVO.setNewPropertyInd(loanType.getNewPropertyInd());
		if(loanType.getPurchaseProperty() != null){
			au.com.stgeorge.ibank.valueobject.mortgage.Property propertyVO = new au.com.stgeorge.ibank.valueobject.mortgage.Property();
			PropertyInfo property = loanType.getPurchaseProperty();
			Application homeloanApplication = mobileSession.getHomeLoanApplication();
			
			if(property.getAddress() !=  null ){
				
				if((property.getAddress().getQasAddressId() == null && property.getAddress().getAddressText()!=null )
						&& (null!=homeloanApplication && null!=homeloanApplication.getLoanType() &&  null!=homeloanApplication.getLoanType().getPurchaseProperty())
						&& (null!=homeloanApplication && null!=homeloanApplication.getLoanType() &&  null!=homeloanApplication.getLoanType().getPurchaseProperty().getAddress()))
				{
				   propertyVO.setAddress(homeloanApplication.getLoanType().getPurchaseProperty().getAddress());
				}
				else{
					MortgageAddress addr = populateMortgageAddress(property.getAddress(), mobileSession, iBankCommonData, perfLogger, AddressType.D.toString());
					addr = cloneMortgageAddress(addr);
					addr.setAddrType(property.getAddress().getAddrType());
					propertyVO.setAddress(addr);
				}
			}
			if(!StringMethods.isEmptyString(property.getCustomerEstimatedValue())){
				propertyVO.setCustomerEstimatedValue(new BigDecimal(property.getCustomerEstimatedValue()));
			}
			propertyVO.setIndex(property.getIndex());
			propertyVO.setKeepPropertyInd(property.getKeepPropertyInd());
			propertyVO.setMortgagedInd(property.getMortgagedInd());
			if(!StringMethods.isEmptyString(property.getPropertyInsightValue())){
				propertyVO.setPropertyInsightValue(new BigDecimal(property.getPropertyInsightValue()));
			}
			propertyVO.setRentalIncomeInd(property.getRentalIncomeInd());
			propertyVO.setShareOwnershipInd(property.getShareOwnershipInd());
			propertyVO.setUseAsSecInd(property.getUseAsSecInd());
			propertyVO.setPropertyType(property.getPropertyType());
			
			// Setting the Property valuation info
			if(null!=property.getPropertyInsightValuationInfo()){
				try{
					PropertyInsightValuation prInsightDetail= new PropertyInsightValuation();
					prInsightDetail.setConfidenceLevel(property.getPropertyInsightValuationInfo().getConfidenceLevel());
					
					if(null!=property.getPropertyInsightValuationInfo().getEstimateHighValue() && !property.getPropertyInsightValuationInfo().getEstimateHighValue().isEmpty()){
						String estimatedHighVal=property.getPropertyInsightValuationInfo().getEstimateHighValue();
						estimatedHighVal=estimatedHighVal.replaceAll(",", "");
						prInsightDetail.setEstimateHighValue(new BigDecimal(estimatedHighVal));
					}else
					{
						prInsightDetail.setEstimateHighValue(null);
					}
					if(null!=property.getPropertyInsightValuationInfo().getEstimateLowValue() && !property.getPropertyInsightValuationInfo().getEstimateLowValue().isEmpty()){
						String estimatedLowVal=property.getPropertyInsightValuationInfo().getEstimateLowValue();
						estimatedLowVal=estimatedLowVal.replaceAll(",", "");
						prInsightDetail.setEstimateLowValue(new BigDecimal(estimatedLowVal));
					}else{
						prInsightDetail.setEstimateLowValue(null);
					}
					if(null!=property.getPropertyInsightValuationInfo().getLastFetchedDate()){						
						String str=property.getPropertyInsightValuationInfo().getLastFetchedDate();
						String res=str.replaceAll("T"," ");
						String [] separated=res.split("\\+");
						String lastFetchedDate_tmp=separated[0];						
						String [] sep=lastFetchedDate_tmp.split("\\.");
						String lastFetchedDate_temp=sep[0];
						SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
						Date date_lastFetchedDate = sdf.parse(lastFetchedDate_temp);	
						prInsightDetail.setLastFetchedDate(date_lastFetchedDate);
					}else{
						prInsightDetail.setLastFetchedDate(null);
					}	   		        
					prInsightDetail.setNumberOfCarSpaces(property.getPropertyInsightValuationInfo().getNumberOfCarSpaces());
					prInsightDetail.setNumOfBathRooms(property.getPropertyInsightValuationInfo().getNumOfBathRooms());
					prInsightDetail.setNumOfBedRooms(property.getPropertyInsightValuationInfo().getNumOfBedRooms());	

					//18E4 - CarSpaces, BathRooms, BedRooms now moved to Property from PropertyInsightValuation
					propertyVO.setCarparks(property.getPropertyInsightValuationInfo().getNumberOfCarSpaces());
					propertyVO.setBathrooms(property.getPropertyInsightValuationInfo().getNumOfBathRooms());
					propertyVO.setBedrooms(property.getPropertyInsightValuationInfo().getNumOfBedRooms());	
					
					if(null!=property.getPropertyInsightValuationInfo().getValuationDate()){
						String str=property.getPropertyInsightValuationInfo().getValuationDate();
						SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
						Date date_valuationDate = sdf.parse(str);	
						prInsightDetail.setValuationDate(date_valuationDate);
					}else{
						prInsightDetail.setValuationDate(null);
					}
					propertyVO.setPropertyInsightValuation(prInsightDetail);
				}
				catch(Exception ex){
					Logger.error("Exception caught", this.getClass());
				}
			}			
			loanTypeVO.setPurchaseProperty(propertyVO);			
		}
		loanTypeVO.setRepaymentFrequency(loanType.getRepaymentFrequency());
		loanTypeVO.setRepaymentType(loanType.getRepaymentType());
		loanTypeVO.setShareAddressInd(true);//Hard coded it to true for 18E3 and corresponsing CX question is removed and is assumed that address is shared by applicants

		loanTypeVO = populateLoanTypeDatabaseID(loanTypeVO,  mobileSession); 
		
		
	  return loanTypeVO;
	}
	
	private void validateApplicantsInfo(ApplicationInfo application, boolean creditCheckRequired) throws BusinessException {
		
		boolean isPersonalDetailsComplete = application.getDashboard().isPersonalDetailsStatusInd();
		
		List<ApplicantInfo> applicants = application.getApplicants(); 
		int numOfApplicants = application.getLoanType().getNumOfApplicants();		
		
		//Validate against reference data
		int applicantIndex = 0;
		for(ApplicantInfo applicant : applicants){
		
			//Validate "title" code  against ref data
			if(!StringMethods.isEmptyString(applicant.getTitle())) {
				if(!mortgageRefDataHelper.isValidCode(mortgageParams.getTitleRefData(MortgageUtil.COMPASS_REFERENCE_DATA_STATUS_IN_USE),applicant.getTitle())) {
					Logger.error("MortgageHelper - validateApplicantsInfo(). applicant.getTitle() is in incorrect format. ", this.getClass());
					throw new BusinessException(BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE);
				}			
			}else if(isPersonalDetailsComplete && applicant.getNtbInd() ){
				Logger.error("PersonalDetails incomplete. ", this.getClass());
				throw new BusinessException(BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE);
			}
			boolean checkPrimaryComplete = applicantIndex == 0 && isPersonalDetailsComplete;
			
			//Validate "maritalStatus" code  against ref data
			if(!StringMethods.isEmptyString(applicant.getMaritalStatus())) {
				if(numOfApplicants > 1){
					if(!mortgageRefDataHelper.isValidCode(mortgageParams.getMaritalStatusJointRefData(MortgageUtil.COMPASS_REFERENCE_DATA_STATUS_IN_USE), applicant.getMaritalStatus())) {
						Logger.error("MortgageHelper - validateApplicantsInfo(). applicant.getMaritalStatus() is in incorrect format. ", this.getClass());
						throw new BusinessException(BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE);
					}
				}
				else{
					if(!mortgageRefDataHelper.isValidCode(mortgageParams.getMaritalStatusRefData(MortgageUtil.COMPASS_REFERENCE_DATA_STATUS_IN_USE), applicant.getMaritalStatus())) {
						Logger.error("MortgageHelper - validateApplicantsInfo(). applicant.getMaritalStatus() is in incorrect format. ", this.getClass());
						throw new BusinessException(BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE);
					}
				}
				
			}else if(checkPrimaryComplete){
				Logger.error("PersonalDetails incomplete. ", this.getClass());
				throw new BusinessException(BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE);
			}
			
			//Age validation - 18 yrs or old
			if(!StringMethods.isEmptyString(applicant.getDateOfBirth()))
			{
				Date dob = DateMethods.getUtilDateTime(applicant.getDateOfBirth(), DateUtils.ISO_8601_CALENDAR_DATE_FORMAT_PATTERN);
				
				int applicantAge = MortgageUtil.getDiffYears(dob, MortgageUtil.getCurrentDate()); 
				if(applicantAge < MortgageUtil.DIGITAL_MORTGAGE_APPLICATION_ELIGIBLE_AGE) {
					Logger.error("MortgageHelper - validateApplicantsInfo(). applicant.getDateOfBirth() is less than "+ MortgageUtil.DIGITAL_MORTGAGE_APPLICATION_ELIGIBLE_AGE , this.getClass());
					throw new BusinessException(BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE);
				}
			}else if(isPersonalDetailsComplete && applicant.getNtbInd()){
				Logger.error("PersonalDetails incomplete. ", this.getClass());
				throw new BusinessException(BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE);
			}
			if(application.getDashboard() != null && application.getDashboard().isIncomeStatusInd()){
				validateIncome(application, applicant, creditCheckRequired);
			}
			
									
			if(applicant.getAddress() != null && applicant.getNtbInd()){
				validateAddress(applicant.getAddress(), checkPrimaryComplete);
			}else if(checkPrimaryComplete && applicant.getNtbInd()){//if primary then mandatory
				Logger.error("PersonalDetails incomplete. ", this.getClass());
				throw new BusinessException(BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE);
			}
			
			if(isPersonalDetailsComplete)
			{
				if(applicantIndex == 0 && (applicant.getNumberOfDependants() < 0 || applicant.getNumberOfDependants() > 9))
				{
					Logger.error("PersonalDetails incomplete. ", this.getClass());
					throw new BusinessException(BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE);
				}
				if(StringMethods.isEmptyString(applicant.getFirstName()) || StringMethods.isEmptyString(applicant.getLastName()))
				{
					Logger.error("PersonalDetails incomplete. ", this.getClass());
					throw new BusinessException(BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE);
				}
				if(StringMethods.isEmptyString(applicant.getEmailAddress()) || StringMethods.isEmptyString(applicant.getMobileNum()))
				{
					Logger.error("PersonalDetails incomplete. ", this.getClass());
					throw new BusinessException(BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE);
				}
				//validate is creditCheckRequired true
				if(creditCheckRequired){
					if(applicant.getForeignTaxResiInd() == null){
						Logger.error("PersonalDetails incomplete. ForeignTaxInd() : "+applicant.getForeignTaxResiInd(), this.getClass());
						throw new BusinessException(BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE);
					}
					//ThreeYrsAtCurrAddrInd validate against to primary applicant.
					if(applicantIndex == 0 && applicant.getThreeYrsAtCurrAddrInd() == null){
						Logger.error("PersonalDetails incomplete. ThreeYrsAtCurrAddrInd() : "+applicant.getThreeYrsAtCurrAddrInd(), this.getClass());
						throw new BusinessException(BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE);
					}
				}
			}
			applicantIndex++;
		}
		
	}
	
	private void validateDashboardStatus(ApplicationInfo application) throws BusinessException{
		
		//Check income
		if(application.getDashboard().isIncomeStatusInd())
		{
			boolean hasIncome = false;
			if(application.getApplicants() != null && application.getApplicants().size() > 0)
			{
				for(ApplicantInfo applicant : application.getApplicants()){
					if(applicant.getIncomes() != null && applicant.getIncomes().size() > 0)
					{
						hasIncome = true;
					}
				}
			}
			if(!hasIncome)//Income level validate taken care in validateIncome
			{
				Logger.error("MortgageHelper - validateDashboardStatus(). Income not complete" , this.getClass());
				throw new BusinessException(BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE);
			}
		}
	}
	
	public List<Applicant> populateAppicantInfo(List<ApplicantInfo> applicantList, MobileSession mobileSession, IBankCommonData iBankCommonData, PerformanceLogger perfLogger) throws BusinessException {
		
		List<Applicant> applicants = new ArrayList<Applicant>();
		au.com.stgeorge.ibank.valueobject.mortgage.Applicant applicantVO = null;
		String marriedDefactoOther = null;
		Boolean threeYrsAtCurrAddrInd = null;
		for(ApplicantInfo applicant : applicantList){
			
			if(MortgageUtil.ApplicantIndexEnum.PRIMARY.getValue() == applicant.getIndex()) {
				marriedDefactoOther = applicant.getMaritalStatus();
				threeYrsAtCurrAddrInd = applicant.getThreeYrsAtCurrAddrInd();
			}
			
			if(!applicant.getNtbInd()){
				populateClasAppicantInfo(applicant, applicants, mobileSession, marriedDefactoOther); 
				continue;
			}
			
			
			applicantVO = new au.com.stgeorge.ibank.valueobject.mortgage.Applicant();
			if(applicant.getAddress() != null) {
				MortgageAddress address = populateMortgageAddress(applicant.getAddress(), mobileSession, iBankCommonData, perfLogger, AddressType.D.toString());
				address = cloneMortgageAddress(address);
				address.setAddrType(applicant.getAddress().getAddrType());
				
				applicantVO.setAddress(address);
			}
			if(applicant.getIncomes() != null && !applicant.getIncomes().isEmpty()) {
				applicantVO.setIncomes(populateIncome(applicant.getIncomes(), applicant, mobileSession));
			}
			if(applicant.getDateOfBirth() != null)
			{
				applicantVO.setDateOfBirth(DateMethods.getUtilDateTime(applicant.getDateOfBirth(), DateUtils.ISO_8601_CALENDAR_DATE_FORMAT_PATTERN));
			}
			if(MortgageUtil.ApplicantIndexEnum.SECOND.getValue() == applicant.getIndex()) {
				applicant.setMaritalStatus(marriedDefactoOther); //Set PrimaryApplicant's maritalStatus for second applicant in case of Joint application 
				applicant.setAddress(null); //Second applicant always shares Primary applicant's address --18E3 no address UI for second applicant
			}
			applicantVO.setEmailAddress(applicant.getEmailAddress());
			applicantVO.setFirstName(applicant.getFirstName());
			applicantVO.setMiddleName(applicant.getMiddleName());
			//applicantVO.setGcisNum();
			applicantVO.setLastName(applicant.getLastName());
			applicantVO.setOtherName(applicant.getOtherName());
			applicantVO.setMaritalStatus(applicant.getMaritalStatus());
			applicantVO.setMobileNum(applicant.getMobileNum());
			applicantVO.setNtbInd(applicant.getNtbInd());
			applicantVO.setNumberOfDependants(applicant.getNumberOfDependants());		
			applicantVO.setOwnershipInd(applicant.getOwnershipInd());
			applicantVO.setForeignTaxResidencyInd(applicant.getForeignTaxResiInd());
			applicantVO.setTitle(applicant.getTitle());
			applicantVO.setIndex(applicant.getIndex());
			applicantVO.setThreeYrsAtCurrAddrInd(threeYrsAtCurrAddrInd);
			applicantVO = populateApplicantDatabaseID(applicant, applicantVO, mobileSession );
			
			applicants.add(applicantVO);
		}
		
	  return applicants;
	}
	
	private void populateClasAppicantInfo(ApplicantInfo applicantInfo, List<Applicant> applicants, MobileSession mobileSession, String marriedDefactoOther){
		au.com.stgeorge.ibank.valueobject.mortgage.Applicant applicantVO =  new au.com.stgeorge.ibank.valueobject.mortgage.Applicant();
		if(MortgageUtil.ApplicantIndexEnum.PRIMARY.getValue() == applicantInfo.getIndex())
		{
			applicantVO.setMaritalStatus(applicantInfo.getMaritalStatus());
			applicantVO.setNumberOfDependants(applicantInfo.getNumberOfDependants());
		}
		if(MortgageUtil.ApplicantIndexEnum.SECOND.getValue() == applicantInfo.getIndex()) {
			applicantVO.setMaritalStatus(marriedDefactoOther); //Set PrimaryApplicant's maritalStatus for second applicant in case of Joint application
		}
		if(applicantInfo.getIncomes() != null && !applicantInfo.getIncomes().isEmpty()) {
			applicantVO.setIncomes(populateIncome(applicantInfo.getIncomes(), applicantInfo, mobileSession )); 
		}
		//Middle name from getcustomer resp
		applicantVO.setOtherName(applicantInfo.getOtherName());
		//customer/db provided tax info should be saved to db and sub-sequents retrieves from db not from getCust Resp.
		applicantVO.setForeignTaxResidencyInd(applicantInfo.getForeignTaxResiInd());
		applicantVO.setThreeYrsAtCurrAddrInd(applicantInfo.getThreeYrsAtCurrAddrInd());
		applicantVO.setNtbInd(applicantInfo.getNtbInd());
		applicantVO.setOwnershipInd(applicantInfo.getOwnershipInd());
		applicantVO.setIndex(applicantInfo.getIndex());
		applicantVO = populateApplicantDatabaseID(applicantInfo ,applicantVO, mobileSession ); 
		applicants.add(applicantVO);
	}
	public List<Income> populateIncome(List<IncomeInfo> incomeInfoList, ApplicantInfo applicantInfo, MobileSession mobileSession) {
		List<Income> incomes = null;
		if(incomeInfoList != null && !incomeInfoList.isEmpty()) {
			incomes = new ArrayList<Income>();
			for(IncomeInfo incomeInfo: incomeInfoList){
				Income income  = new Income();
				income.setCategory(incomeInfo.getCategory());
				income.setEmploymentType(incomeInfo.getEmploymentType());
				income.setIncomeType(incomeInfo.getIncomeType());
				if(!StringMethods.isEmptyString(incomeInfo.getBaseAmt())){
					income.setBaseAmt(new BigDecimal(incomeInfo.getBaseAmt()));
				}
				if(!StringMethods.isEmptyString(incomeInfo.getOtherAmt())){
					income.setOtherAmt(new BigDecimal(incomeInfo.getOtherAmt()));
				}
				income.setBaseFrequency(incomeInfo.getBaseFrequency());
				income.setOtherFrequency(incomeInfo.getOtherFrequency());
				if(!StringMethods.isEmptyString(incomeInfo.getSelfEmployedNetIncome())){
					income.setSelfEmployedNetIncome(new BigDecimal(incomeInfo.getSelfEmployedNetIncome()));
				}
				income.setSelfEmployedNetIncomeFrequency(incomeInfo.getSelfEmployedNetIncomeFrequency());
				income.setPropertyIndex(incomeInfo.getPropertyIndex());
				income.setAssetIndex(incomeInfo.getAssetIndex());
				income.setIndex(incomeInfo.getIndex());
				income.setEmpIndustry(incomeInfo.getEmpIndustry());
				income.setEmployerName(incomeInfo.getEmployerName());
				income.setEmpOccupationCode(incomeInfo.getEmpOccupationCode());
				income.setThreeYrsAtCurrEmployerInd(incomeInfo.getThreeYrsAtCurrEmployerInd());
				
				income = populateIncomeDatabaseID(incomeInfo, applicantInfo, income, mobileSession );
				
				incomes.add(income);
			}		
		}
		return incomes;
	}
	
	//NEW
	private void validateIncome(ApplicationInfo application, ApplicantInfo applicant, boolean creditCheckRequired) throws BusinessException {
		
		boolean isIncomeComplete = application.getDashboard().isIncomeStatusInd();							
		
		if(applicant.getIncomes() != null && applicant.getIncomes().size() > 0) {
			List<IncomeInfo> incomeInfoList = applicant.getIncomes();			
					
			//Validate against reference data
			
			for(IncomeInfo income : incomeInfoList){
				
				if(StringMethods.isEmptyString(income.getCategory())){
					Logger.error("MortgageHelper - validateIncome(). income.getCategory() is empty. ", this.getClass());
					throw new BusinessException(BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE);
				}
				
				if(!mortgageRefDataHelper.isValidCode(mortgageParams.getIncomeCategoryRefData(MortgageUtil.COMPASS_REFERENCE_DATA_STATUS_IN_USE),income.getCategory())) {
					Logger.error("MortgageHelper - validateIncome(). income.getCategory() is in incorrect format. ", this.getClass());
					throw new BusinessException(BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE);
				}
				if(MortgageUtil.INCOME_CATEGORY_EMPLOYMENT.equalsIgnoreCase(income.getCategory())){
					
					if(StringMethods.isEmptyString(income.getEmploymentType())
							|| !mortgageRefDataHelper.isValidCode(mortgageParams.getEmploymentTypeRefData(MortgageUtil.COMPASS_REFERENCE_DATA_STATUS_IN_USE),income.getEmploymentType())){
						Logger.error("MortgageHelper - validateIncome(). income.getEmploymentType() is empty/incorrect format. ", this.getClass());
						throw new BusinessException(BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE);
					}
					
					if(!StringMethods.isEmptyString(income.getIncomeType())){
						Logger.error("MortgageHelper - validateIncome(). for Employment category, income.getIncomeType() should be empty. ", this.getClass());
						throw new BusinessException(BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE);
					}
					if(creditCheckRequired){
						if(!StringMethods.isEmptyString(income.getEmpIndustry())){
							if(!mortgageRefDataHelper.isValidCode(mortgageParams.getEmpIndustryRefData(MortgageUtil.COMPASS_REFERENCE_DATA_STATUS_IN_USE),income.getEmpIndustry())) {
								Logger.error("MortgageHelper - validateIncome(). income.getEmpIndustry is in incorrect format. ", this.getClass());
								throw new BusinessException(BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE);
							}	
						}
						if(!StringMethods.isEmptyString(income.getEmpOccupationCode())){
							if(!mortgageRefDataHelper.isValidCode(mortgageParams.getEmpRoleRefData(MortgageUtil.COMPASS_REFERENCE_DATA_STATUS_IN_USE),income.getEmpOccupationCode())) {
								Logger.error("MortgageHelper - validateIncome(). income.getEmpOccupationCode is in incorrect format. ", this.getClass());
								throw new BusinessException(BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE);
							}	
						}
					}
				}
				else{
					
					if(StringMethods.isEmptyString(income.getIncomeType())
							|| !mortgageRefDataHelper.isValidCode(mortgageParams.getIncomeTypeRefData(MortgageUtil.COMPASS_REFERENCE_DATA_STATUS_IN_USE),income.getIncomeType())) 
					{
							Logger.error("MortgageHelper - validateIncome(). income.getIncomeType() is empty/incorrect format. ", this.getClass());
							throw new BusinessException(BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE);
					}
					
					if(!StringMethods.isEmptyString(income.getEmploymentType())){
						Logger.error("MortgageHelper - validateIncome(). for other than Employment category, income.getEmploymentType() should be empty. ", this.getClass());
						throw new BusinessException(BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE);
					}
				}
				
				if(!StringMethods.isEmptyString(income.getBaseFrequency())){
					if(!mortgageRefDataHelper.isValidCode(mortgageParams.getFrequencyRefData(MortgageUtil.COMPASS_REFERENCE_DATA_STATUS_IN_USE),income.getBaseFrequency())) {
						Logger.error("MortgageHelper - validateIncome(). income.getBaseFrequency is in incorrect format. ", this.getClass());
						throw new BusinessException(BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE);
					}	
				}
				
				if(!StringMethods.isEmptyString(income.getOtherFrequency())){
					if(!mortgageRefDataHelper.isValidCode(mortgageParams.getFrequencyRefData(MortgageUtil.COMPASS_REFERENCE_DATA_STATUS_IN_USE),income.getOtherFrequency())) {
						Logger.error("MortgageHelper - validateIncome(). income.getOtherFrequency is in incorrect format. ", this.getClass());
						throw new BusinessException(BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE);
					}	
				}
				
				if(!StringMethods.isEmptyString(income.getSelfEmployedNetIncomeFrequency())){
					if(!mortgageRefDataHelper.isValidCode(mortgageParams.getFrequencyRefData(MortgageUtil.COMPASS_REFERENCE_DATA_STATUS_IN_USE),income.getSelfEmployedNetIncomeFrequency())) {
						Logger.error("MortgageHelper - validateIncome(). income.getSelfEmployedNetIncomeFrequency is in incorrect format. ", this.getClass());
						throw new BusinessException(BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE);
					}	
				}
				
				if(isIncomeComplete)
				{
					validateIncomeComplete(income, application, creditCheckRequired);
				}

			}
		}						
	}
	
	private boolean isExistingPropertyNeitherApplicants(ApplicationInfo applicationInfo, Integer propertyIndex){
		boolean isNeither = false;
		if(applicationInfo != null && applicationInfo.getAssets() != null && applicationInfo.getAssets().size() > 0){
			for(AssetInfo assetInfo : applicationInfo.getAssets()){
				if(propertyIndex == assetInfo.getPropertyIndex() && assetInfo.getOtherPercent() != null && MortgageUtil.SHARE_PERCENTAGE_100_PERCENT == Long.valueOf(assetInfo.getOtherPercent())){
					return true;
				}
			}
		}
		return isNeither;
	}
	
	private void validateIncomeComplete(IncomeInfo income, ApplicationInfo applicationInfo, boolean crditCheckRequired) throws BusinessException
	{
		if(MortgageUtil.INCOME_TYPE_SELFEMPLOYED.equals(income.getEmploymentType()))
		{
			if(!StringMethods.isEmptyString(income.getBaseAmt()) && StringMethods.isEmptyString(income.getBaseFrequency()))
			{
				Logger.error("MortgageHelper - validateIncomeComplete().", this.getClass());
				throw new BusinessException(BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE);
			}
			if(!StringMethods.isEmptyString(income.getSelfEmployedNetIncome()) && StringMethods.isEmptyString(income.getSelfEmployedNetIncomeFrequency()))
			{
				Logger.error("MortgageHelper - validateIncomeComplete().", this.getClass());
				throw new BusinessException(BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE);
			}
			if(StringMethods.isEmptyString(income.getSelfEmployedNetIncome()) && StringMethods.isEmptyString(income.getBaseAmt()))
			{
				Logger.error("MortgageHelper - validateIncomeComplete().", this.getClass());
				throw new BusinessException(BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE);
			}
		}
		else if(MortgageUtil.INCOME_CATEGORY_RENTAL.equals(income.getCategory()))
		{
			if(!isExistingPropertyNeitherApplicants(applicationInfo, income.getPropertyIndex())){
				if(!StringMethods.isEmptyString(income.getBaseAmt()))
				{
					BigDecimal amt = new BigDecimal(income.getBaseAmt());
					
					/*  "min": 1,
				      */
					if(amt.compareTo(BigDecimal.ONE) < 0)
					{
						Logger.error("MortgageHelper - validateIncomeComplete(). Base Income should be > 0 for Rental Category.", this.getClass());
						throw new BusinessException(BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE);
					}
				}
			}
		}
		else 
		{
			if(!StringMethods.isEmptyString(income.getBaseAmt()) && StringMethods.isEmptyString(income.getBaseFrequency()))
			{
				Logger.error("MortgageHelper - validateIncomeComplete().", this.getClass());
				throw new BusinessException(BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE);
			}
			if(!StringMethods.isEmptyString(income.getOtherAmt()) && StringMethods.isEmptyString(income.getOtherFrequency()))
			{
				Logger.error("MortgageHelper - validateIncomeComplete().", this.getClass());
				throw new BusinessException(BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE);
			}
			if(StringMethods.isEmptyString(income.getOtherAmt()) && StringMethods.isEmptyString(income.getBaseAmt()))
			{
				Logger.error("MortgageHelper - validateIncomeComplete().", this.getClass());
				throw new BusinessException(BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE);
			}	
		}	
		//For INCOME_CATEGORY_EMPLOYMENT, Base Amount is mandatory.
		if(MortgageUtil.INCOME_CATEGORY_EMPLOYMENT.equalsIgnoreCase(income.getCategory())){
			
			if(StringMethods.isEmptyString(income.getBaseAmt()))
			{
				Logger.error("MortgageHelper - validateIncomeComplete(). Base Income is Mandatory for Employment Category.", this.getClass());
				throw new BusinessException(BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE);
			}
			
			BigDecimal amt = new BigDecimal(income.getBaseAmt());
			
			/*  "min": 1,
	      		"max": 9999999
		      */
			if(amt.compareTo(BigDecimal.ONE) < 0)
			{
				Logger.error("MortgageHelper - validateIncomeComplete(). Base Income is Mandatory and should be > 0 for Employment Category.", this.getClass());
				throw new BusinessException(BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE);
			}
			if(crditCheckRequired){
				if(StringMethods.isEmptyString(income.getEmpIndustry()))
				{
					Logger.error("MortgageHelper - validateIncomeComplete() - EmpIndustry is empty or null", this.getClass());
					throw new BusinessException(BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE);
				}
				if(StringMethods.isEmptyString(income.getEmpOccupationCode()))
				{
					Logger.error("MortgageHelper - validateIncomeComplete() - EmpOccupationCode is empty or null", this.getClass());
					throw new BusinessException(BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE);
				}
				if(StringMethods.isEmptyString(income.getEmployerName()))
				{
					Logger.error("MortgageHelper - validateIncomeComplete() - EmployerName is empty or null", this.getClass());
					throw new BusinessException(BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE);
				}
				if(income.getThreeYrsAtCurrEmployerInd() == null)
				{
					Logger.error("MortgageHelper - validateIncomeComplete() - ThreeYrsAtCurrEmployerInd is null", this.getClass());
					throw new BusinessException(BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE);
				}
			}


		}
	}
	
	public MortgageAddress cloneMortgageAddress(MortgageAddress addressInfo){
		MortgageAddress address = new MortgageAddress();
		
		address.setLine1(addressInfo.getLine1());
		address.setLine2(addressInfo.getLine2());
		address.setLine3(addressInfo.getLine3());
		address.setSuburb(addressInfo.getSuburb());
		address.setPostCode(addressInfo.getPostCode());
		address.setCountryName(addressInfo.getCountryName());
		address.setState(addressInfo.getState());
		address.setPid(addressInfo.getPid());
		address.setStdAddrId(addressInfo.getStdAddrId());
				
		address.setQasAddressId(addressInfo.getQasAddressId());
		address.setAddressText(addressInfo.getAddressText());
		address.setAddrType(addressInfo.getAddrType());
		
		return address;
	}
	
	public MortgageAddress populateMortgageAddress(AddressInfo addressInfo, MobileSession mobileSession, IBankCommonData iBankCommonData, PerformanceLogger perfLogger, String addressType) throws BusinessException {
		return storeQASAddressInSession(addressInfo, iBankCommonData, mobileSession, perfLogger, addressType);
	}
	
	public MortgageAddress storeQASAddressInSession(AddressInfo addressInfo, IBankCommonData iBankCommonData, MobileSession mobileSession, PerformanceLogger perfLogger, String addressType) throws BusinessException{
		 MortgageAddress mortgageAddr = new MortgageAddress();
		 if(addressInfo.getQasAddressId() != null){
			
			MortgageAddress sessionMortgageAddr =  getQasAddressFromSession(mobileSession, addressInfo.getQasAddressId());
			if(sessionMortgageAddr != null ){
				 Logger.debug("Getting Address From Session : "+ sessionMortgageAddr.getLine1() + " "+ sessionMortgageAddr.getLine2() + " "+ sessionMortgageAddr.getSuburb(), this.getClass());
				return sessionMortgageAddr;
			}
			MortgageAddress addr = mortgageService.getPropertyInsightAddress(addressInfo.getQasAddressId(), iBankCommonData,perfLogger, addressType);
			if(addr != null && !StringMethods.isEmptyString(addr.getLine1()) && !StringMethods.isEmptyString(addr.getSuburb())){
				addr.setAddressText(addressInfo.getAddressText());
				addr.setAddrType(addressInfo.getAddrType());
				addr.setQasAddressId(addressInfo.getQasAddressId());
				 if(mobileSession != null){
					 if(mobileSession.getMortgageSessionInfo().getQasAddressList() != null){
						 Logger.info("Session QAS is not empty. Adding QAS address in to session.", this.getClass());
						 mobileSession.getMortgageSessionInfo().getQasAddressList().add(addr); 
					 }
					 else{
						 Logger.info("Session QAS is empty. Adding QAS address in to session.", this.getClass());
						 List<MortgageAddress> mortgageAddressList = new ArrayList<MortgageAddress>();
						 mortgageAddressList.add(addr);
						 mobileSession.getMortgageSessionInfo().setQasAddressList(mortgageAddressList); 
					 }
				 }
				 return addr;
		 }
		 else{
			 Logger.info("QAS service call failed.", this.getClass());
			 throw new BusinessException(BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE);
		 }
	   }
	   else{
		   
		   Logger.info(" Manual address. ", this.getClass());
		   if(!StringMethods.isEmptyString(addressInfo.getLine1()) && !StringMethods.isEmptyString(addressInfo.getSuburb())){
				mortgageAddr.setLine1(addressInfo.getLine1());
				mortgageAddr.setLine2(addressInfo.getLine2());
				mortgageAddr.setLine3(addressInfo.getLine3());
				mortgageAddr.setSuburb(addressInfo.getSuburb().trim());
				mortgageAddr.setPostCode(addressInfo.getPostCode());
				mortgageAddr.setCountryName(addressInfo.getCountryName());
				mortgageAddr.setState(addressInfo.getState());
				
				mortgageAddr.setQasAddressId(addressInfo.getQasAddressId());
				mortgageAddr.setAddressText(addressInfo.getAddressText());
				mortgageAddr.setAddrType(addressInfo.getAddrType());
		   }
		   else{
			   Logger.info("Manual Address empty.", this.getClass());
		   }
		}
		
		return mortgageAddr;
	}
	
	public MortgageAddress getQasAddressFromSession(MobileSession mobileSession, String qasAddressId){
		if(mobileSession != null && mobileSession.getMortgageSessionInfo().getQasAddressList() != null){
			for(MortgageAddress mortAdd : mobileSession.getMortgageSessionInfo().getQasAddressList()){
				if(mortAdd.getQasAddressId().equals(qasAddressId)){
					Logger.info("QAS address found in session.", this.getClass());
					return mortAdd;
				}
			}
		}
		Logger.info("QAS address not found in session.", this.getClass());
		return null;
	}
	public void validatePropertyForHomeLoan(ApplicationInfo application) throws BusinessException {
		Logger.debug("Entering validatePropertyForHomeLoan()", this.getClass());
		boolean isNewProperty = (application.getLoanType().getLoanType() != null) ? application.getLoanType().getLoanType().equalsIgnoreCase(MortgageUtil.LoanTypeEnum.NEW_PROPERTY.getType()) : true;
		
		if(application.getDashboard().isLiabilityStatusInd()){
			List<PropertyInfo> propertyInfoList = application.getProperties();
			if(application.getLiabilities() != null && application.getLiabilities().size() > 0) {
				List<LiabilityInfo> liabilityInfoList = application.getLiabilities();	
				if(propertyInfoList != null && propertyInfoList.size() > 0){
					for(int i=0; i<propertyInfoList.size(); i++){
						PropertyInfo propertyInfo = propertyInfoList.get(i);
						if(propertyInfo != null && propertyInfo.getMortgagedInd() != null && propertyInfo.getMortgagedInd()){
							for(int j=0; j<liabilityInfoList.size(); j++){
								LiabilityInfo liabilityInfo = liabilityInfoList.get(j);
								if(liabilityInfo.getPropertyIndex() != null && (propertyInfo.getIndex() == Integer.parseInt(liabilityInfo.getPropertyIndex()))){
									if(liabilityInfo != null && MortgageUtil.LiabilityCategoryEnum.HomeLoan.getValue().equalsIgnoreCase(liabilityInfo.getLiabilityCategory())){
										if(StringMethods.isEmptyString(liabilityInfo.getBankCode())){
											Logger.error("Validation failed. MortgageHelper.validatePropertyForHomeLoan(). Home loan - liabilityInfo.getBankCode() is EMPTY", this.getClass());
											throw new BusinessException(BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE);
										}
										if(StringMethods.isEmptyString(liabilityInfo.getRemaningLoanAmt())){
											Logger.error("Validation failed. MortgageHelper.validatePropertyForHomeLoan(). Home loan - liabilityInfo.getRemaningLoanAmt() is EMPTY", this.getClass());
											throw new BusinessException(BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE);
										}
										
										if (isNewProperty) {
											if(StringMethods.isEmptyString(liabilityInfo.getRemainingTermInMonths())){
												Logger.error("Validation failed. MortgageHelper.validatePropertyForHomeLoan(). Home loan - liabilityInfo.getRemainingTermInMonths() is EMPTY", this.getClass());
												throw new BusinessException(BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE);
											}
											if(StringMethods.isEmptyString(liabilityInfo.getRepaymentAmt())){
												Logger.error("Validation failed. MortgageHelper.validatePropertyForHomeLoan(). Home loan - liabilityInfo.getRepaymentAmt() is EMPTY", this.getClass());
												throw new BusinessException(BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE);
											}
											if(StringMethods.isEmptyString(liabilityInfo.getRepaymentFreq())){
												Logger.error("Validation failed. MortgageHelper.validatePropertyForHomeLoan(). Home loan - liabilityInfo.getRepaymentFreq() is EMPTY", this.getClass());
												throw new BusinessException(BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE);
											}					
											if(StringMethods.isEmptyString(liabilityInfo.getRepaymentType())){
												Logger.error("Validation failed. MortgageHelper.validatePropertyForHomeLoan(). Home loan - liabilityInfo.getRepaymentType() is EMPTY", this.getClass());
												throw new BusinessException(BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE);
											}
										}
										
										if(StringMethods.isEmptyString(liabilityInfo.getLiabilityType())){
											Logger.error("Validation failed. MortgageHelper.validatePropertyForHomeLoan(). Home loan - liabilityInfo.getLiabilityType() is EMPTY", this.getClass());
											throw new BusinessException(BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE);
										}
										if(StringMethods.isEmptyString(liabilityInfo.getIntRateForMortgage())){
											Logger.error("Validation failed. MortgageHelper.validatePropertyForHomeLoan(). Home loan - liabilityInfo.getIntRateForMortgage() is EMPTY", this.getClass());
											throw new BusinessException(BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE);
										}
									}
								}
							}
						}
					}				
				}
			}
			Logger.debug("EXITing validatePropertyForHomeLoan() with ALL validations SUCCESS", this.getClass());
		}
	}
	
	public void validateLiabilityInfo(ApplicationInfo application) throws BusinessException {
		Logger.debug("Entering validateLiabilityInfo()", this.getClass());
		if(application.getLiabilities() != null && application.getLiabilities().size() > 0) {
			List<LiabilityInfo> liabilityInfoList = application.getLiabilities();			
					
			//Only for HomeLoan Liability
			validatePropertyForHomeLoan(application);
			
			//"Other than Home Loan" Liabilities 
			for(int i = 0; i < liabilityInfoList.size(); i++){
				LiabilityInfo liabilityInfo = liabilityInfoList.get(i);				
				
				if(!StringMethods.isEmptyString(liabilityInfo.getLiabilityCategory())){
					if(!mortgageRefDataHelper.isValidCode(mortgageParams.getLiabilityCategoryRefData(MortgageUtil.COMPASS_REFERENCE_DATA_STATUS_IN_USE),liabilityInfo.getLiabilityCategory())) {
						Logger.error("Validation failed. MortgageHelper.validateLiabilityInfo(). liabilityInfo.getLiabilityCategory() - UI code is not matching with DB", this.getClass());
						throw new BusinessException(BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE);
					}
					else{
						//CreditCard				
						if(liabilityInfo != null && MortgageUtil.LiabilityCategoryEnum.CreditCard.getValue().equalsIgnoreCase(liabilityInfo.getLiabilityCategory())){
							if(StringMethods.isEmptyString(liabilityInfo.getBankCode())){
								Logger.error("Validation failed. MortgageHelper.validateLiabilityInfo(). Credit card - liabilityInfo.getBankCode() is EMPTY", this.getClass());
								throw new BusinessException(BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE);
							}
							if(StringMethods.isEmptyString(liabilityInfo.getLimitAmt())){
								Logger.error("Validation failed. MortgageHelper.validateLiabilityInfo(). Credit card - liabilityInfo.getLimitAmt() is EMPTY", this.getClass());
								throw new BusinessException(BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE);
							}
							if(liabilityInfo.getSharedLiability() == null || (liabilityInfo.getSharedLiability() != null && StringMethods.isEmptyString(Boolean.toString(liabilityInfo.getSharedLiability())))){
								Logger.error("Validation failed. MortgageHelper.validateLiabilityInfo(). Credit card - liabilityInfo.getSharedLiability() is EMPTY", this.getClass());
								throw new BusinessException(BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE);
							}
						}
						//PersonalLoan
						if(liabilityInfo != null && MortgageUtil.LiabilityCategoryEnum.PersonalLoan.getValue().equalsIgnoreCase(liabilityInfo.getLiabilityCategory())){
							if(StringMethods.isEmptyString(liabilityInfo.getBankCode())){
								Logger.error("Validation failed. MortgageHelper.validateLiabilityInfo(). Personal loan - liabilityInfo.getBankCode() is EMPTY", this.getClass());
								throw new BusinessException(BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE);
							}
							if(StringMethods.isEmptyString(liabilityInfo.getCurrentBal())){
								Logger.error("Validation failed. MortgageHelper.validateLiabilityInfo(). Personal loan - liabilityInfo.getCurrentBal() is EMPTY", this.getClass());
								throw new BusinessException(BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE);
							}
							if(StringMethods.isEmptyString(liabilityInfo.getRepaymentFreq())){
								Logger.error("Validation failed. MortgageHelper.validateLiabilityInfo(). Personal loan - liabilityInfo.getRepaymentFreq() is EMPTY", this.getClass());
								throw new BusinessException(BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE);
							}
							if(StringMethods.isEmptyString(liabilityInfo.getRepaymentAmt())){
								Logger.error("Validation failed. MortgageHelper.validateLiabilityInfo(). Personal loan - liabilityInfo.getRepaymentAmt() is EMPTY", this.getClass());
								throw new BusinessException(BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE);
							}
							if(StringMethods.isEmptyString(liabilityInfo.getRemainingTermInMonths())){
								Logger.error("Validation failed. MortgageHelper.validateLiabilityInfo(). Personal loan - liabilityInfo.getRemainingTermInMonths() is EMPTY", this.getClass());
								throw new BusinessException(BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE);
							}					
							if(liabilityInfo.getSharedLiability() == null || (liabilityInfo.getSharedLiability() != null && StringMethods.isEmptyString(Boolean.toString(liabilityInfo.getSharedLiability())))){
								Logger.error("Validation failed. MortgageHelper.validateLiabilityInfo(). Personal loan - liabilityInfo.getSharedLiability() is EMPTY", this.getClass());
								throw new BusinessException(BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE);
							}
						}
						//OtherLiabilities
						if(liabilityInfo != null && MortgageUtil.LiabilityCategoryEnum.OtherLiabilities.getValue().equalsIgnoreCase(liabilityInfo.getLiabilityCategory())){
							if(StringMethods.isEmptyString(liabilityInfo.getLiabilityType())){
								Logger.error("Validation failed. MortgageHelper.validateLiabilityInfo(). Other liabilities - liabilityInfo.getLiabilityType() is EMPTY", this.getClass());
								throw new BusinessException(BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE);
							}
							else{
								if(!mortgageRefDataHelper.isValidCode(mortgageParams.getLiabilityTypeOtherRefData(MortgageUtil.COMPASS_REFERENCE_DATA_STATUS_IN_USE),liabilityInfo.getLiabilityType())) {
									Logger.error("Validation failed. MortgageHelper.validateLiabilityInfo(). liabilityInfo.getLiabilityType() - UI code is not matching with DB", this.getClass());
									throw new BusinessException(BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE);
								}
								else{
									if(MortgageUtil.LiabilityTypeOtherEnum.UnsecuredLineOfCredit.getValue().equalsIgnoreCase(liabilityInfo.getLiabilityType())){
										if(StringMethods.isEmptyString(liabilityInfo.getLimitAmt())){
											Logger.error("Validation failed. MortgageHelper.validateLiabilityInfo(). Other liabilities - UnsecuredLineOfCredit - liabilityInfo.getLimitAmt() is EMPTY", this.getClass());
											throw new BusinessException(BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE);
										}
										if(liabilityInfo.getSharedLiability() == null || (liabilityInfo.getSharedLiability() != null && StringMethods.isEmptyString(Boolean.toString(liabilityInfo.getSharedLiability())))){
											Logger.error("Validation failed. MortgageHelper.validateLiabilityInfo(). Other liabilities - UnsecuredLineOfCredit - liabilityInfo.getSharedLiability() is EMPTY", this.getClass());
											throw new BusinessException(BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE);
										}
										
									}
									if(MortgageUtil.LiabilityTypeOtherEnum.Overdraft.getValue().equalsIgnoreCase(liabilityInfo.getLiabilityType())){
										if(StringMethods.isEmptyString(liabilityInfo.getLimitAmt())){
											Logger.error("Validation failed. MortgageHelper.validateLiabilityInfo(). Other liabilities - Overdraft - liabilityInfo.getLimitAmt() is EMPTY", this.getClass());
											throw new BusinessException(BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE);
										}
										if(StringMethods.isEmptyString(liabilityInfo.getRepaymentAmt())){
											Logger.error("Validation failed. MortgageHelper.validateLiabilityInfo(). Other liabilities - Overdraft  - liabilityInfo.getRepaymentAmt() is EMPTY", this.getClass());
											throw new BusinessException(BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE);
										}
										if(liabilityInfo.getSharedLiability() == null || (liabilityInfo.getSharedLiability() != null && StringMethods.isEmptyString(Boolean.toString(liabilityInfo.getSharedLiability())))){
											Logger.error("Validation failed. MortgageHelper.validateLiabilityInfo(). Other liabilities - Overdraft - liabilityInfo.getSharedLiability() is EMPTY", this.getClass());
											throw new BusinessException(BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE);
										}
										
									}
									if(MortgageUtil.LiabilityTypeOtherEnum.Lease.getValue().equalsIgnoreCase(liabilityInfo.getLiabilityType())){
										if(StringMethods.isEmptyString(liabilityInfo.getCurrentBal())){
											Logger.error("Validation failed. MortgageHelper.validateLiabilityInfo(). Other liabilities - Lease - liabilityInfo.getCurrentBal() is EMPTY", this.getClass());
											throw new BusinessException(BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE);
										}
										if(StringMethods.isEmptyString(liabilityInfo.getRepaymentAmt())){
											Logger.error("Validation failed. MortgageHelper.validateLiabilityInfo(). Other liabilities - Lease - liabilityInfo.getRepaymentAmt() is EMPTY", this.getClass());
											throw new BusinessException(BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE);
										}
										if(StringMethods.isEmptyString(liabilityInfo.getRemainingTermInMonths())){
											Logger.error("Validation failed. MortgageHelper.validateLiabilityInfo(). Other liabilities - Lease - liabilityInfo.getRemainingTermInMonths() is EMPTY", this.getClass());
											throw new BusinessException(BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE);
										}
										if(liabilityInfo.getSharedLiability() == null || (liabilityInfo.getSharedLiability() != null && StringMethods.isEmptyString(Boolean.toString(liabilityInfo.getSharedLiability())))){
											Logger.error("Validation failed. MortgageHelper.validateLiabilityInfo(). Other liabilities - Lease - liabilityInfo.getSharedLiability() is EMPTY", this.getClass());
											throw new BusinessException(BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE);
										}
									}
									if(MortgageUtil.LiabilityTypeOtherEnum.Childcare.getValue().equalsIgnoreCase(liabilityInfo.getLiabilityType())){
										if(StringMethods.isEmptyString(liabilityInfo.getRepaymentAmt())){
											Logger.error("Validation failed. MortgageHelper.validateLiabilityInfo(). Other liabilities - Childcare - liabilityInfo.getRepaymentAmt() is EMPTY", this.getClass());
											throw new BusinessException(BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE);
										}
										if(liabilityInfo.getSharedLiability() == null || (liabilityInfo.getSharedLiability() != null && StringMethods.isEmptyString(Boolean.toString(liabilityInfo.getSharedLiability())))){
											Logger.error("Validation failed. MortgageHelper.validateLiabilityInfo(). Other liabilities - Childcare - liabilityInfo.getSharedLiability() is EMPTY", this.getClass());
											throw new BusinessException(BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE);
										}
										if(!StringMethods.isEmptyString(liabilityInfo.getRepaymentFreq())){
											if(!mortgageRefDataHelper.isValidCode(mortgageParams.getFrequencyRefData(MortgageUtil.COMPASS_REFERENCE_DATA_STATUS_IN_USE),liabilityInfo.getRepaymentFreq())) {
												Logger.error("Validation failed. MortgageHelper.validateLiabilityInfo(). liabilityInfo.getRepaymentFreq() - UI code is not matching with DB", this.getClass());
												throw new BusinessException(BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE);
											}
										}
										else{
											Logger.error("Validation failed. MortgageHelper.validateLiabilityInfo(). liabilityInfo.getRepaymentFreq() is EMPTY", this.getClass());
											throw new BusinessException(BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE);
										}
									}
									if(MortgageUtil.LiabilityTypeOtherEnum.Other.getValue().equalsIgnoreCase(liabilityInfo.getLiabilityType())){
										if(StringMethods.isEmptyString(liabilityInfo.getCurrentBal())){
											Logger.error("Validation failed. MortgageHelper.validateLiabilityInfo(). Other liabilities - Other - liabilityInfo.getCurrentBal() is EMPTY", this.getClass());
											throw new BusinessException(BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE);
										}
										if(StringMethods.isEmptyString(liabilityInfo.getRepaymentAmt())){
											Logger.error("Validation failed. MortgageHelper.validateLiabilityInfo(). Other liabilities - Other - liabilityInfo.getRepaymentAmt() is EMPTY", this.getClass());
											throw new BusinessException(BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE);
										}
										if(StringMethods.isEmptyString(liabilityInfo.getRemainingTermInMonths())){
											Logger.error("Validation failed. MortgageHelper.validateLiabilityInfo(). Other liabilities - Other - liabilityInfo.getRemainingTermInMonths() is EMPTY", this.getClass());
											throw new BusinessException(BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE);
										}
										if(liabilityInfo.getSharedLiability() == null || (liabilityInfo.getSharedLiability() != null && StringMethods.isEmptyString(Boolean.toString(liabilityInfo.getSharedLiability())))){
											Logger.error("Validation failed. MortgageHelper.validateLiabilityInfo(). Other liabilities - Other - liabilityInfo.getSharedLiability() is EMPTY", this.getClass());
											throw new BusinessException(BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE);
										}
									}									
								}
							}
						}
					}
				}
				else{
					Logger.error("Validation failed. MortgageHelper.validateLiabilityInfo(). liabilityInfo.getLiabilityCategory() is EMPTY", this.getClass());
					throw new BusinessException(BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE);
				}
			}
			Logger.debug("Exiting validateLiabilityInfo() with ALL validations SUCCESS", this.getClass());
		}						
	}

	public void validateExpenseInfo(ApplicationInfo application, boolean creditCheckRequired) throws BusinessException {
		Logger.debug("Entering validateExpenseInfo()", this.getClass());
		if(application.getExpenses() != null && application.getExpenses().size() > 0) {
			List<ExpenseInfo> expenseInfoList = application.getExpenses();			
					
			for(ExpenseInfo expenseInfo : expenseInfoList){
				if(StringMethods.isEmptyString(expenseInfo.getExpenseType())){
					Logger.error("Validation failed. MortgageHelper.validateExpenseInfo() - expenseInfo.getExpenseType() is EMPTY", this.getClass());
					throw new BusinessException(BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE);
				}
				else{
					if(!mortgageRefDataHelper.isValidCode(mortgageParams.getExpenseTypeRefData(MortgageUtil.COMPASS_REFERENCE_DATA_STATUS_IN_USE),expenseInfo.getExpenseType())) {
						Logger.error("Validation failed. MortgageHelper.validateLiabilityInfo(). expenseInfo.getExpenseType() - UI code is not matching with DB", this.getClass());
						throw new BusinessException(BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE);
					}
				}
				if(MortgageUtil.EXPENSE_TYPE_SIGNIFICANT_EVENT.equals(expenseInfo.getExpenseType())) {
					if(expenseInfo.getSigEventsExpectedInd() == null && creditCheckRequired) {
						Logger.error("Validation failed. MortgageHelper.validateExpenseInfo() - SignificantEventsExpectedInd is NULL", this.getClass());
						throw new BusinessException(BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE);
					}
				}
				else {
					if(StringMethods.isEmptyString(expenseInfo.getCategory())){
						Logger.error("Validation failed. MortgageHelper.validateExpenseInfo() - expenseInfo.getCategory() is EMPTY", this.getClass());
						throw new BusinessException(BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE);
					}
					else{
						if(!mortgageRefDataHelper.isValidCode(mortgageParams.getExpenseCategoryRefData(MortgageUtil.COMPASS_REFERENCE_DATA_STATUS_IN_USE),expenseInfo.getCategory())) {
							Logger.error("Validation failed. MortgageHelper.validateLiabilityInfo(). expenseInfo.getCategory() - UI code is not matching with DB", this.getClass());
							throw new BusinessException(BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE);
						}
					}
					if(StringMethods.isEmptyString(expenseInfo.getExpenseFrequency())){
						Logger.error("Validation failed. MortgageHelper.validateExpenseInfo() - expenseInfo.getExpenseFrequency() is EMPTY", this.getClass());
						throw new BusinessException(BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE);
					}
					else{
						if(!mortgageRefDataHelper.isValidCode(mortgageParams.getExpenseFrequencyRefData(MortgageUtil.COMPASS_REFERENCE_DATA_STATUS_IN_USE),expenseInfo.getExpenseFrequency())) {
							Logger.error("Validation failed. MortgageHelper.validateLiabilityInfo(). expenseInfo.getExpenseFrequency() - UI code is not matching with DB", this.getClass());
							throw new BusinessException(BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE);
						}
					}
				}
			}
			Logger.debug("Exiting validateExpenseInfo() with ALL validations SUCCESS", this.getClass());
		}						
	}
	
	public List<Liability> populateLiabilityInfo(List<LiabilityInfo> liabilityInfoList, MobileSession mobileSession) {
		List<Liability> liabilityList = new ArrayList<Liability>();
		Liability liabilityVO = null;
		
		if(null!=liabilityInfoList){
			for(LiabilityInfo liabilityInfo : liabilityInfoList){
				
				liabilityVO = new Liability();
				
				liabilityVO.setIndex(liabilityInfo.getIndex());
				liabilityVO.setAvailableRedrawAmt((liabilityInfo.getAvailableRedrawAmt() != null && !liabilityInfo.getAvailableRedrawAmt().isEmpty()) ? new BigDecimal(liabilityInfo.getAvailableRedrawAmt()) : null);
				liabilityVO.setBankCode(liabilityInfo.getBankCode());
				liabilityVO.setCurrentBal((liabilityInfo.getCurrentBal() != null && !liabilityInfo.getCurrentBal().isEmpty()) ? new BigDecimal(liabilityInfo.getCurrentBal()) : null);
				liabilityVO.setIntRateForMortgage((liabilityInfo.getIntRateForMortgage() != null && !liabilityInfo.getIntRateForMortgage().isEmpty()) ? new BigDecimal(liabilityInfo.getIntRateForMortgage()) : null);
				liabilityVO.setLiabilityCategory(liabilityInfo.getLiabilityCategory());
				liabilityVO.setLiabilityType(liabilityInfo.getLiabilityType());
				liabilityVO.setLimitAmt((liabilityInfo.getLimitAmt() != null && !liabilityInfo.getLimitAmt().isEmpty()) ? new BigDecimal(liabilityInfo.getLimitAmt()) : null);				
				liabilityVO.setOtherPercent((liabilityInfo.getOtherPercent() != null && !liabilityInfo.getOtherPercent().isEmpty()) ? new BigDecimal(liabilityInfo.getOtherPercent()) : null);
				liabilityVO.setOwner1Percent((liabilityInfo.getOwner1Percent() != null && !liabilityInfo.getOwner1Percent().isEmpty()) ? new BigDecimal(liabilityInfo.getOwner1Percent()) : null);
				liabilityVO.setOwner2Percent((liabilityInfo.getOwner2Percent() != null && !liabilityInfo.getOwner2Percent().isEmpty()) ? new BigDecimal(liabilityInfo.getOwner2Percent()) : null);				
				liabilityVO.setPropertyIndex(liabilityInfo.getPropertyIndex() != null ? new Integer(liabilityInfo.getPropertyIndex()) : null);
				liabilityVO.setRemainingLoanAmt((liabilityInfo.getRemaningLoanAmt() != null && !liabilityInfo.getRemaningLoanAmt().isEmpty()) ? new BigDecimal(liabilityInfo.getRemaningLoanAmt()) : null);
				liabilityVO.setRemainingTermInMonths(liabilityInfo.getRemainingTermInMonths() != null ? new Long(liabilityInfo.getRemainingTermInMonths()) : null);
				liabilityVO.setRemainginterestOnlyTermMonths(liabilityInfo.getRemainingInterestTermInMonths() != null ? new Long(liabilityInfo.getRemainingInterestTermInMonths()) : null);
				liabilityVO.setRepaymentAmt((liabilityInfo.getRepaymentAmt() != null && !liabilityInfo.getRepaymentAmt().isEmpty()) ? new BigDecimal(liabilityInfo.getRepaymentAmt()) : null);
				liabilityVO.setRepaymentFreq(liabilityInfo.getRepaymentFreq());
				liabilityVO.setRepaymentType(liabilityInfo.getRepaymentType());
				if(liabilityInfo.getShareCreditCard() != null){
					liabilityVO.setShareCreditCard(MortgageUtil.translateBooleanToDBStatusInd(liabilityInfo.getShareCreditCard()));	
				}
				if(liabilityInfo.getToBePaidOut() != null){
					liabilityVO.setToBePaidOut(liabilityInfo.getToBePaidOut() != null ? MortgageUtil.translateBooleanToDBStatusInd(liabilityInfo.getToBePaidOut()) : null);	
				}
				if(liabilityInfo.getSharedLiability() != null){
					liabilityVO.setLiabilityShared(liabilityInfo.getSharedLiability() != null ? MortgageUtil.translateBooleanToDBStatusInd(liabilityInfo.getSharedLiability()) : null);	
				}
				
				liabilityVO.setLiabilityId(populateLiabilityDatabaseID(liabilityInfo, mobileSession));
				liabilityList.add(liabilityVO);
			}
		}		
		
	  return liabilityList;
	}
	
	// Populate AssetInfo
	
	public List<Asset> populateAssetInfo(List<AssetInfo> assetInfoList, MobileSession mobileSession) {
		List<Asset> assetList = new ArrayList<Asset>();
		Asset assetVO = null;
		
		if(null!=assetInfoList){
			for(AssetInfo asset : assetInfoList){
				
				assetVO = new Asset();
				assetVO.setIndex(asset.getIndex());
				assetVO.setAssetType(asset.getAssetType());
				assetVO.setCategory(asset.getCategory());
				assetVO.setBankCode(asset.getBankCode());
				assetVO.setClasAssetId(asset.getClasAssetId());
				assetVO.setAssetValue((asset.getAssetValue() != null && !asset.getAssetValue().isEmpty()) ? new BigDecimal(asset.getAssetValue()) : null);
				assetVO.setOtherPercent((asset.getOtherPercent() != null && !asset.getOtherPercent().isEmpty()) ? new Integer(asset.getOtherPercent()) : null);
				assetVO.setOwner1Percent((asset.getOwner1Percent() != null && !asset.getOwner1Percent().isEmpty()) ? new Integer(asset.getOwner1Percent()) : null);
				assetVO.setOwner2Percent((asset.getOwner2Percent() != null && !asset.getOwner2Percent().isEmpty()) ? new Integer(asset.getOwner2Percent()) : null);
				assetVO.setPropertyIndex(asset.getPropertyIndex() != null  ? asset.getPropertyIndex() : null);
				assetVO.setAssetId(populateAssetDatabaseID(asset, mobileSession  ) ); 
				assetList.add(assetVO);
			}
		}		
		
	  return assetList;
	}
	
	// Populate ExpenseInfo
	
	public List<Expense> populateExpenseInfo(List<ExpenseInfo> expenseInfoList, Application applicationVO, MobileSession mobileSession) {
		List<Expense> expenseList = new ArrayList<Expense>();
		Expense expenseVO = null;
		
		if(null!=expenseInfoList){
			for(ExpenseInfo expenseInfo : expenseInfoList){
				if(!StringUtils.isEmpty(expenseInfo.getExpenseType()) && expenseInfo.getExpenseType().equals(MortgageUtil.EXPENSE_TYPE_SIGNIFICANT_EVENT)) {
					applicationVO.setSigEventsExpectedInd(expenseInfo.getSigEventsExpectedInd());
					continue;
				}
				expenseVO = new Expense();
				expenseVO.setCategory(expenseInfo.getCategory());
				expenseVO.setAmount((expenseInfo.getAmount() != null && !expenseInfo.getAmount().isEmpty()) ? new BigDecimal(expenseInfo.getAmount()) : null);
				expenseVO.setOtherPercent((expenseInfo.getOtherPercent() != null && !expenseInfo.getOtherPercent().isEmpty()) ? new BigDecimal(expenseInfo.getOtherPercent()) : null);	
				expenseVO.setOwner1Percent((expenseInfo.getOwner1Percent() != null && !expenseInfo.getOwner1Percent().isEmpty()) ? new BigDecimal(expenseInfo.getOwner1Percent()) : null);
				expenseVO.setOwner2Percent((expenseInfo.getOwner2Percent() != null && !expenseInfo.getOwner2Percent().isEmpty()) ? new BigDecimal(expenseInfo.getOwner2Percent()) : null);
				expenseVO.setExpenseType(expenseInfo.getExpenseType() != null  ? expenseInfo.getExpenseType() : null);
				expenseVO.setExpenseFrequency(expenseInfo.getExpenseFrequency() != null  ? expenseInfo.getExpenseFrequency() : null);
				expenseVO.setIndex(expenseInfo.getIndex());
				expenseVO.setExpenseId(populateExpenseDatabaseID(expenseInfo, mobileSession  ) ); 
				expenseList.add(expenseVO);
			}
		}				
	  return expenseList;
	}
	
	
	public ApplicationInfo populateApplicationInfo(Application applicationVO) {
		ApplicationInfo applicationInfo = new ApplicationInfo();
		
		
		//for Invalid status
		if(!StringMethods.isEmptyString(applicationVO.getApplicationStatus()) && applicationVO.getApplicationStatus().equalsIgnoreCase(MortgageUtil.DOC_UPLOAD)){
			//Set LoanTypeInfo
			applicationInfo.setLoanType(populateLoanTypeInfo(applicationVO.getLoanType()));

		}
		else{
		//Set LoanTypeInfo
		applicationInfo.setLoanType(populateLoanTypeInfo(applicationVO.getLoanType()));
		
		//Set ApplicantInfo and IncomeInfo
		applicationInfo.setApplicants(populateApplicantInfoList(applicationVO.getApplicants()));
		
		//Set DashboardInfo
		applicationInfo.setDashboard(populateDashboardInfo(applicationVO.getDashboard()));
		
		//Set AssetInfo
		applicationInfo.setAssets(populateAssetListRetrieval(applicationVO.getAssets()));
		
		//Set LiabilityInfo
		applicationInfo.setLiabilities(populateLiabilityListRetrieval(applicationVO.getLiabilities()));
		
		//Set ExpenseInfo 
		applicationInfo.setExpenses(populateExpenseListRetrieval(applicationVO.getExpenses(), applicationVO));
		
		//Set PropertyInfo
		applicationInfo.setProperties(populatePropertyListRetrieval(applicationVO.getProperties(),applicationVO.getAssets()));
		
		applicationInfo.setDashboardIntroInd(applicationVO.getDashboardIntroInd());
		
		}
		//19E1 credit decision
		if(StringMethods.isEmptyString(applicationVO.getCreditCheckEligible())){
			applicationInfo.setCreditCheckRequired(null);
		}
		else if(applicationVO.getCreditCheckEligible() != null && applicationVO.getCreditCheckEligible().equalsIgnoreCase(MortgageUtil.CreditCheckEligibleEnum.YES.getValue())){
			applicationInfo.setCreditCheckRequired(true);
		}
		else{
			applicationInfo.setCreditCheckRequired(false);
		}

		if(applicationVO.getCustomerModifiedOn() != null)
		{
			applicationInfo.setCustomerModifiedOn(DateMethods.formatDate(DateUtils.DD_MMM_YYYY_FORMAT_PATTERN, applicationVO.getCustomerModifiedOn()));
		}
		//TODO add App Tracker switch
		String CLASstatus = populateApplicationStatus(applicationInfo, applicationVO.getApplicationStatus());
		if(CLASstatus != null){
			applicationInfo.setStatus(CLASstatus);
		}

		applicationInfo.setInflightApp(new Boolean(applicationVO.isInflightApplication()));
		
		//LenderInfo
		applicationInfo.setLender(populateLenderInfo(applicationVO.getLender()));
		
		return applicationInfo;
	}
	
	private String populateApplicationStatus(ApplicationInfo applicationInfo, String status) {
		
		String CLASstatus = null;
		
		if(!StringMethods.isEmptyString(status))
		{
			if(status.equalsIgnoreCase(ApplicationStatusEnum.IN_PROGRESS.getStatus()) || status.equalsIgnoreCase(ApplicationStatusEnum.NEW.getStatus())){
				
				CLASstatus = CLASApplicationStatusEnum.IN_PROGRESS.getStatus();
			}
			else if(status.equalsIgnoreCase(ApplicationStatusEnum.ASSESS.getStatus())){
				
				CLASstatus = CLASApplicationStatusEnum.ASSESS.getStatus();
			}
			else if(status.equalsIgnoreCase(ApplicationStatusEnum.SUBMITTED.getStatus()) || status.equalsIgnoreCase(MortgageUtil.DOC_UPLOAD)){
				
				CLASstatus = CLASApplicationStatusEnum.DOC_UPLOAD.getStatus();
			}
		}
		return CLASstatus;
	}
	private DashBoard populateDashboard(DashboardInfo dashboardInfo) {
		DashBoard dashboard = new DashBoard();
		if(dashboardInfo != null) {
			dashboard.setLoanTypeStatusInd(dashboardInfo.isLoanTypeStatusInd());
			dashboard.setPersonalDetailsStatusInd(dashboardInfo.isPersonalDetailsStatusInd());
			dashboard.setIncomeStatusInd(dashboardInfo.isIncomeStatusInd());
			dashboard.setLiabilityStatusInd(dashboardInfo.isLiabilityStatusInd());
			dashboard.setExpenseStatusInd(dashboardInfo.isExpenseStatusInd());
			dashboard.setAssetStatusInd(dashboardInfo.isAssetStatusInd());
		}
		return dashboard;
	}
	
	private DashboardInfo populateDashboardInfo(DashBoard dashboard) {
		DashboardInfo dashBoardInfo = new DashboardInfo();
		if(dashboard != null) {
			dashBoardInfo.setLoanTypeStatusInd(dashboard.isLoanTypeStatusInd());
			dashBoardInfo.setPersonalDetailsStatusInd(dashboard.isPersonalDetailsStatusInd());
			dashBoardInfo.setIncomeStatusInd(dashboard.isIncomeStatusInd());
			dashBoardInfo.setLiabilityStatusInd(dashboard.isLiabilityStatusInd());
			dashBoardInfo.setExpenseStatusInd(dashboard.isExpenseStatusInd());
			dashBoardInfo.setAssetStatusInd(dashboard.isAssetStatusInd());
		}
		return dashBoardInfo;
	}
	private List<ApplicantInfo> populateApplicantInfoList(List<Applicant> applicants) {
		List<ApplicantInfo> applicantInfoList = null;
		if(applicants != null && !applicants.isEmpty()) {
			applicantInfoList = new ArrayList<ApplicantInfo>();
			for(Applicant applicant : applicants) {
				ApplicantInfo applicantInfo = populateApplicantInfo(applicant);
				applicantInfoList.add(applicantInfo);
			}
		}
		return applicantInfoList;
	}
	
	private List<AssetInfo> populateAssetListRetrieval(List<Asset> assetInfoList) {
		List<AssetInfo> assetInfList = null;
		if(assetInfoList != null && !assetInfoList.isEmpty()) {
			assetInfList = new ArrayList<AssetInfo>();
			for(Asset asset : assetInfoList) {
				AssetInfo assetInfo = populateAssetListForRetrieval(asset);
				assetInfList.add(assetInfo);
			}
		}
		return assetInfList;
	}
	
	private List<LiabilityInfo> populateLiabilityListRetrieval(List<Liability> liabilityList) {
		List<LiabilityInfo> liabilityInfoList = null;
		int index=-1;
		if(liabilityList != null && !liabilityList.isEmpty()) {
			liabilityInfoList = new ArrayList<LiabilityInfo>();
			for(Liability liability : liabilityList) {
				index++;
				LiabilityInfo liabilityInfo = populateLiabilityListForRetrieval(liability);
				liabilityInfo.setIndex(index);
				liabilityInfoList.add(liabilityInfo);
			}
		}
		return liabilityInfoList;
	}

	private List<ExpenseInfo> populateExpenseListRetrieval(List<Expense> expenseList, Application applicationVO) {
		List<ExpenseInfo> expenseInfoList = null;
		if(expenseList != null && !expenseList.isEmpty()) {
			expenseInfoList = new ArrayList<ExpenseInfo>();
			for(Expense expense : expenseList) {
				ExpenseInfo expenseInfo = populateExpenseListForRetrieval(expense);
				expenseInfoList.add(expenseInfo);
			}
		}
		if(applicationVO.getSigEventsExpectedInd() != null) {
			ExpenseInfo expenseInfo = new ExpenseInfo();
			expenseInfo.setExpenseType(MortgageUtil.EXPENSE_TYPE_SIGNIFICANT_EVENT);
			expenseInfo.setCategory(MortgageUtil.EXPENSE_CATEGORY_SIGNIFICANT_EVENTS);
			expenseInfo.setSigEventsExpectedInd(applicationVO.getSigEventsExpectedInd());
			expenseInfo.setIndex(getNextExpenseIndex(expenseInfoList));
			if(expenseInfoList == null) {
				expenseInfoList = new ArrayList<ExpenseInfo>();
			}
			expenseInfoList.add(expenseInfo);
		}
		return expenseInfoList;
	}
	
	private int getNextExpenseIndex(List<ExpenseInfo> expenseInfoList) {
		int nextIndex = 0;
		if(expenseInfoList != null && !expenseInfoList.isEmpty()) {
			int maxIndex = 0;
			for(ExpenseInfo expenseInfo : expenseInfoList) {
				if(expenseInfo.getIndex() > maxIndex) {
					maxIndex = expenseInfo.getIndex();
				}
			}
			if(maxIndex > 0) {
				nextIndex = maxIndex + 1;
			}
		}
		return nextIndex;
	}

	private List<PropertyInfo> populatePropertyListRetrieval(List<Property> propertyList, List<Asset> assetList) {
		List<PropertyInfo> propertyInfoList = null;
		if(propertyList != null && !propertyList.isEmpty()) {
			propertyInfoList = new ArrayList<PropertyInfo>();
			for(Property property: propertyList) {
						PropertyInfo propertyInfo = populatePropertyListForRetrieval(property);
						propertyInfoList.add(propertyInfo);
			}
		}
		return propertyInfoList;
	}
	
	private ApplicantInfo populateApplicantInfo(Applicant applicant) {
		ApplicantInfo applicantInfo = new ApplicantInfo();
		//Set Personal Details
		applicantInfo.setIndex(applicant.getIndex());
		applicantInfo.setNtbInd(applicant.getNtbInd());
		applicantInfo.setTitle(applicant.getTitle());
		applicantInfo.setFirstName(applicant.getFirstName());
		applicantInfo.setMiddleName(applicant.getMiddleName());
		applicantInfo.setLastName(applicant.getLastName());
		applicantInfo.setOtherName(applicant.getOtherName());
		applicantInfo.setForeignTaxResiInd(applicant.getForeignTaxResidencyInd());
		applicantInfo.setMaritalStatus(applicant.getMaritalStatus());
		applicantInfo.setThreeYrsAtCurrAddrInd(applicant.getThreeYrsAtCurrAddrInd());
		if(applicant.getDateOfBirth() != null)
		{
			applicantInfo.setDateOfBirth(DateMethods.formatDate(DateUtils.ISO_8601_CALENDAR_DATE_FORMAT_PATTERN, applicant.getDateOfBirth()));
		}
		applicantInfo.setEmailAddress(applicant.getEmailAddress());
		applicantInfo.setMobileNum(applicant.getMobileNum());
		applicantInfo.setResidentialStatus(applicant.getResidentialStatus());
		if(applicant.getNumberOfDependants() != null) {
			applicantInfo.setNumberOfDependants(applicant.getNumberOfDependants());
		}
		applicantInfo.setOwnershipInd(applicant.getOwnershipInd());
		
		//Set Address
		if( applicant.getAddress() != null && ! StringMethods.isEmptyString(applicant.getAddress().getSuburb() )  &&   ! StringMethods.isEmptyString(applicant.getAddress().getPostCode() )  )  {
			applicantInfo.setAddress(populateAddressInfo(applicant.getAddress()));
		}
		
		//Set incomes
		applicantInfo.setIncomes(populateIncomeInfoList(applicant.getIncomes()));
		
		return applicantInfo;
	}

	
	private AssetInfo populateAssetListForRetrieval(Asset asset) {
		AssetInfo assetInfo =null;
		if(null!=asset){
			assetInfo = new AssetInfo();
	        assetInfo.setAssetType(asset.getAssetType());
	        assetInfo.setAssetValue(asset.getAssetValue()!=null ? asset.getAssetValue().toString() : null);
	        assetInfo.setBankCode(asset.getBankCode());
	        assetInfo.setCategory(asset.getCategory());
	        assetInfo.setIndex(asset.getIndex());
	        assetInfo.setOtherPercent(asset.getOtherPercent()!=null ? asset.getOtherPercent().toString() : null);
	        assetInfo.setOwner1Percent(asset.getOwner1Percent()!=null ? asset.getOwner1Percent().toString() : null);
	        assetInfo.setOwner2Percent(asset.getOwner2Percent()!=null ? asset.getOwner2Percent().toString() : null);
	        assetInfo.setPropertyIndex(asset.getPropertyIndex());
	        
	        assetInfo.setClasAssetId(asset.getClasAssetId());
	        assetInfo.setRelationship(asset.getRelationship());
        	assetInfo.setAccountNumber(asset.getAccountNumber());
		}
		return assetInfo;
	}

	
	private LiabilityInfo populateLiabilityListForRetrieval(Liability liability) {
		LiabilityInfo liabilityInfo = null;
		Boolean isSharedLiability=false;
		if(null!=liability){
			liabilityInfo = new LiabilityInfo();
			liabilityInfo.setAvailableRedrawAmt(liability.getAvailableRedrawAmt()!=null ? liability.getAvailableRedrawAmt().toString() : null);
			liabilityInfo.setBankCode(liability.getBankCode());
			liabilityInfo.setCurrentBal(liability.getCurrentBal()!=null ? liability.getCurrentBal().toString() : null);
			liabilityInfo.setIndex(liability.getIndex());
			liabilityInfo.setIntRateForMortgage(liability.getIntRateForMortgage()!=null ? liability.getIntRateForMortgage().toString() : null);
			liabilityInfo.setLiabilityCategory(liability.getLiabilityCategory());
			liabilityInfo.setLiabilityType(liability.getLiabilityType());
			liabilityInfo.setLimitAmt(liability.getLimitAmt()!=null ? liability.getLimitAmt().toString() : null);
			liabilityInfo.setOtherPercent(liability.getOtherPercent()!=null ? liability.getOtherPercent().toString() : null);
			liabilityInfo.setOwner1Percent(liability.getOwner1Percent()!=null ? liability.getOwner1Percent().toString() : null);
			liabilityInfo.setOwner2Percent(liability.getOwner2Percent()!=null ? liability.getOwner2Percent().toString() : null);
			liabilityInfo.setPropertyIndex(liability.getPropertyIndex() !=null ? liability.getPropertyIndex().toString() : null);
			liabilityInfo.setRemainingInterestTermInMonths(liability.getRemainginterestOnlyTermMonths() !=null ? liability.getRemainginterestOnlyTermMonths().toString() : null);
			liabilityInfo.setRemainingTermInMonths(liability.getRemainingTermInMonths() != null ? Long.toString(liability.getRemainingTermInMonths()) : null);
			liabilityInfo.setRemaningLoanAmt(liability.getRemainingLoanAmt()!=null ? liability.getRemainingLoanAmt().toString() : null);
			liabilityInfo.setRepaymentAmt(liability.getRepaymentAmt()!=null ? liability.getRepaymentAmt().toString() : null);
			liabilityInfo.setRepaymentFreq(liability.getRepaymentFreq());
			liabilityInfo.setRepaymentType(liability.getRepaymentType());
			liabilityInfo.setShareCreditCard(MortgageUtil.translateDBStatusIndToBoolean(liability.getShareCreditCard()));
			if(null!=liability.getLiabilityShared()){
				isSharedLiability=MortgageUtil.translateDBStatusIndToBoolean(liability.getLiabilityShared());
				liabilityInfo.setSharedLiability(isSharedLiability);
			}			
			liabilityInfo.setToBePaidOut(MortgageUtil.translateDBStatusIndToBoolean(liability.getToBePaidOut()));
			liabilityInfo.setAccountNumber(liability.getAccountNumber());
			liabilityInfo.setRelationship(liability.getRelationship());
			liabilityInfo.setPropertyIndexes(liability.getPropertyIndexList());
		}
		return liabilityInfo;
	}
	
	private ExpenseInfo populateExpenseListForRetrieval(Expense expense) {
		ExpenseInfo expenseInfo = null;
		if(null!=expense){
			expenseInfo = new ExpenseInfo();
			expenseInfo.setAmount(expense.getAmount()!=null ? expense.getAmount().toString() : null);
			expenseInfo.setCategory(expense.getCategory());
			expenseInfo.setExpenseFrequency(expense.getExpenseFrequency());
			expenseInfo.setExpenseType(expense.getExpenseType());
			expenseInfo.setOtherPercent(expense.getOtherPercent()!=null ? expense.getOtherPercent().toString() : null);
			expenseInfo.setOwner1Percent(expense.getOwner1Percent()!=null ? expense.getOwner1Percent().toString() : null);
			expenseInfo.setOwner2Percent(expense.getOwner2Percent()!=null ? expense.getOwner2Percent().toString() : null);
			expenseInfo.setIndex(expense.getIndex());
		}		
		return expenseInfo;
	}
	
	
	private PropertyInfo populatePropertyListForRetrieval(Property property) {
		
		PropertyInfo propertyInfo=null;
		if(null!=property){
			propertyInfo = new PropertyInfo();
			propertyInfo.setAddress(populateAddress(property.getAddress()));
			//propertyInfo.setCustomerEstimatedValue(property.getCustomerEstimatedValue());
			if(property.getCustomerEstimatedValue() != null){
				propertyInfo.setCustomerEstimatedValue(property.getCustomerEstimatedValue().toString());
			}
			propertyInfo.setIndex(property.getIndex());
			propertyInfo.setKeepPropertyInd(property.getKeepPropertyInd());
			propertyInfo.setMortgagedInd(property.getMortgagedInd());
			propertyInfo.setRefinanceInd(property.getRefinanceInd());
			propertyInfo.setPropertyInsightValuationInfo(populatePropertyValInfo(property.getPropertyInsightValuation()));
			//propertyInfo.setPropertyInsightValue(property.getPropertyInsightValue());
			if(property.getPropertyInsightValue() != null){
				propertyInfo.setPropertyInsightValue(property.getPropertyInsightValue().toString());
			}
			propertyInfo.setPropertyType(property.getPropertyType());
			propertyInfo.setRentalIncomeInd(property.getRentalIncomeInd());
			propertyInfo.setShareOwnershipInd(property.getShareOwnershipInd());
			propertyInfo.setUseAsSecInd(property.getUseAsSecInd());
			//18E3 setting bedrooms, bathrooms, carparks
			if(property.getBedrooms() != null){
				propertyInfo.setBedrooms(property.getBedrooms().intValue());
			}
			if(property.getBathrooms() != null){
				propertyInfo.setBathrooms(property.getBathrooms().intValue());
			}
			if(property.getCarparks() != null){
				propertyInfo.setCarparks(property.getCarparks().intValue());
			}
			
			propertyInfo.setPrimaryResidenceInd(property.getPrimaryResidenceInd());
		}
		return propertyInfo;
	}
	
	private PropertyInsightValuationInfo populatePropertyValInfo(PropertyInsightValuation propVal){
		PropertyInsightValuationInfo propValInfo=null;
		if(null!=propVal){
			propValInfo=new PropertyInsightValuationInfo();
			propValInfo.setConfidenceLevel(propVal.getConfidenceLevel());
			propValInfo.setEstimateHighValue(propVal.getEstimateHighValue()!=null ? propVal.getEstimateHighValue().toString() : null);
			propValInfo.setEstimateLowValue(propVal.getEstimateLowValue()!=null ? propVal.getEstimateLowValue().toString() : null);			
			if(null!=propVal.getLastFetchedDate())
			{
				propValInfo.setLastFetchedDate(DateMethods.formatDate(DateUtils.ISO_8601_CALENDAR_DATE_FORMAT_PATTERN, propVal.getLastFetchedDate()));
			}			
			propValInfo.setNumberOfCarSpaces(propVal.getNumberOfCarSpaces());
			propValInfo.setNumOfBathRooms(propVal.getNumOfBathRooms());
			propValInfo.setNumOfBedRooms(propVal.getNumOfBedRooms());
			
			if(null!=propVal.getValuationDate()){
				propValInfo.setValuationDate(DateMethods.formatDate(DateUtils.ISO_8601_CALENDAR_DATE_FORMAT_PATTERN, propVal.getValuationDate()));
			}
		}
		return propValInfo;
	}
	
	private AddressInfo populateAddress(MortgageAddress address){
		AddressInfo addressInfo=null;
		if(null!=address){
			addressInfo=new AddressInfo();
			addressInfo.setAddressText(address.getAddressText());
			addressInfo.setAddrType(address.getAddrType());
			addressInfo.setCountryName(address.getCountryName());
			addressInfo.setLine1(address.getLine1());
			addressInfo.setLine2(address.getLine2());
			addressInfo.setLine3(address.getLine3());
			addressInfo.setPostCode(address.getPostCode());
			addressInfo.setQasAddressId(address.getQasAddressId());
			addressInfo.setState(address.getState());
			addressInfo.setSuburb(address.getSuburb());
		}		
		return addressInfo;
	}
	
	private List<IncomeInfo> populateIncomeInfoList(List<Income> incomes) {
		List<IncomeInfo> incomeInfoList = null;
		if(incomes != null && !incomes.isEmpty()) {
			incomeInfoList = new ArrayList<IncomeInfo>();
			for(Income income : incomes) {
				IncomeInfo incomeInfo = new IncomeInfo();
				incomeInfo.setCategory(income.getCategory());
				incomeInfo.setEmploymentType(income.getEmploymentType());
				incomeInfo.setIncomeType(income.getIncomeType());
				incomeInfo.setBaseAmt(income.getBaseAmt()!=null ? income.getBaseAmt().toString() : null);
				incomeInfo.setOtherAmt(income.getOtherAmt()!=null ? income.getOtherAmt().toString() : null);
				incomeInfo.setBaseFrequency(income.getBaseFrequency());
				incomeInfo.setOtherFrequency(income.getOtherFrequency());
				incomeInfo.setSelfEmployedNetIncome(income.getSelfEmployedNetIncome()!=null ? income.getSelfEmployedNetIncome().toString() : null);
				incomeInfo.setSelfEmployedNetIncomeFrequency(income.getSelfEmployedNetIncomeFrequency());
				incomeInfo.setPropertyIndex(income.getPropertyIndex());
				incomeInfo.setAssetIndex(income.getAssetIndex());
				incomeInfo.setIndex(income.getIndex());
				incomeInfo.setEmpIndustry(income.getEmpIndustry());
				incomeInfo.setEmployerName(income.getEmployerName());
				incomeInfo.setEmpOccupationCode(income.getEmpOccupationCode());
				incomeInfo.setThreeYrsAtCurrEmployerInd(income.getThreeYrsAtCurrEmployerInd());
				incomeInfoList.add(incomeInfo);
			}
		}
		return incomeInfoList;
	}
	
	public AddressInfo populateAddressInfo(MortgageAddress mortgageAddress) {
		AddressInfo address = new AddressInfo();
		address.setLine1(mortgageAddress.getLine1());
		address.setLine2(mortgageAddress.getLine2());
		address.setLine3(mortgageAddress.getLine3());
		address.setSuburb(mortgageAddress.getSuburb());
		address.setPostCode(mortgageAddress.getPostCode());
		address.setCountryName(mortgageAddress.getCountryName());
		address.setState(mortgageAddress.getState());
		address.setAddressText(mortgageAddress.getAddressText());
		address.setAddrType(mortgageAddress.getAddrType());
		return address;
	}
	private LoanTypeInfo populateLoanTypeInfo(LoanType loanType) {
		LoanTypeInfo loanTypeInfo = new LoanTypeInfo();
		loanTypeInfo.setLoanType(loanType.getLoanType());
		loanTypeInfo.setProductType(loanType.getProductType());
		//for old applications TwoYearFixedRate should be mapped to FixedRate
		if(MortgageUtil.PRODUCT_TYPE_FIXED_RATE_2YEARS.equals(loanType.getProductType())){
			loanTypeInfo.setProductType(MortgageUtil.PRODUCT_TYPE_FIXED_RATE);
		}
		loanTypeInfo.setNumOfApplicants(loanType.getNumbOfApplicants());
		loanTypeInfo.setFirstHomeBuyerInd(loanType.getFirstHomeBuyerInd());
		loanTypeInfo.setLoanPurpose(loanType.getLoanPurpose());
		loanTypeInfo.setCustomerSituation(loanType.getCustomerSituation());
		loanTypeInfo.setCustRequestedLoanAmt(loanType.getCustRequestedLoanAmt()!=null ? loanType.getCustRequestedLoanAmt().toString() : null);
		loanTypeInfo.setApplicationCompletionStage(loanType.getApplicationCompletionStage());
		loanTypeInfo.setCombinedNumDependants(loanType.getCombinedNumDependants());
		loanTypeInfo.setRepaymentType(loanType.getRepaymentType());
		loanTypeInfo.setLoanTerm(loanType.getLoanTerm()!=null ? loanType.getLoanTerm().toString() : null);
		loanTypeInfo.setFixedLoanTerm(loanType.getFixedLoanTerm() != null ? loanType.getFixedLoanTerm().toString() : null);
		loanTypeInfo.setInterestOnlyTerm(loanType.getInterestOnlyTerm() != null ? loanType.getInterestOnlyTerm().toString() : null);
		loanTypeInfo.setRepaymentFrequency(loanType.getRepaymentFrequency());
		loanTypeInfo.setCalculateForMeInd(loanType.getCalculateForMeInd());
		loanTypeInfo.setDepositAmount(loanType.getDepositAmount()!=null ? loanType.getDepositAmount().toString() : null);
		loanTypeInfo.setRentalIncome(loanType.getRentalIncome()!=null ? loanType.getRentalIncome().toString() : null);
		loanTypeInfo.setRentalIncomeFrequency(loanType.getRentalIncomeFrequency());
		loanTypeInfo.setShareAddressInd(loanType.getShareAddressInd());
		loanTypeInfo.setLoanAmt(loanType.getLoanAmt()!=null ? loanType.getLoanAmt().toString() : null);
		if(loanType.getPurchaseProperty() != null) {
			loanTypeInfo.setPurchaseProperty(populatePropertyInfo(loanType.getPurchaseProperty()));
		}
		loanTypeInfo.setNewPropertyInd(loanType.getNewPropertyInd());
		return loanTypeInfo;
	}
	private PropertyInfo populatePropertyInfo(Property property) {
		PropertyInfo propertyInfo = new PropertyInfo();
		propertyInfo.setIndex(property.getIndex());
		//propertyInfo.setCustomerEstimatedValue(property.getCustomerEstimatedValue());
		if(property.getCustomerEstimatedValue() != null){
			propertyInfo.setCustomerEstimatedValue(property.getCustomerEstimatedValue().toString());
		}
		//propertyInfo.setPropertyInsightValue(property.getPropertyInsightValue());
		if(property.getPropertyInsightValue() != null){
			propertyInfo.setPropertyInsightValue(property.getPropertyInsightValue().toString());
		}
		propertyInfo.setUseAsSecInd(property.getUseAsSecInd());
		propertyInfo.setKeepPropertyInd(property.getKeepPropertyInd());
		propertyInfo.setMortgagedInd(property.getMortgagedInd());
		propertyInfo.setShareOwnershipInd(property.getShareOwnershipInd());
		propertyInfo.setRefinanceInd(property.getRefinanceInd());
		if(property.getAddress() != null ){
			propertyInfo.setAddress(populateAddressInfo(property.getAddress()));
		}
		propertyInfo.setPropertyType(property.getPropertyType());
		if(null!=property.getPropertyInsightValuation()){
			propertyInfo.setPropertyInsightValuationInfo(populatePropInsightValuationRetrieve(property));
		}
		propertyInfo.setPrimaryResidenceInd(property.getPrimaryResidenceInd());
		
		return propertyInfo;
	}
	
	private PropertyInsightValuationInfo populatePropInsightValuationRetrieve(Property prop){
		PropertyInsightValuationInfo propValuationInfo=null;
		if(null!=prop && prop.getPropertyInsightValuation() != null)
		{
			PropertyInsightValuation propValuation = prop.getPropertyInsightValuation();
			propValuationInfo=new PropertyInsightValuationInfo();
			propValuationInfo.setConfidenceLevel(propValuation.getConfidenceLevel());
			propValuationInfo.setEstimateHighValue(propValuation.getEstimateHighValue()!=null ? propValuation.getEstimateHighValue().toString() : null);
			propValuationInfo.setEstimateLowValue(propValuation.getEstimateLowValue()!=null ? propValuation.getEstimateLowValue().toString() : null);			
			propValuationInfo.setLastFetchedDate(propValuation.getLastFetchedDate()!=null ? DateMethods.formatDate(DateUtils.ISO_8601_CALENDAR_DATETIME_FORMAT_PATTERN, propValuation.getLastFetchedDate()) : null);		
			propValuationInfo.setValuationDate(propValuation.getValuationDate()!=null ? DateMethods.formatDate(DateUtils.ISO_8601_CALENDAR_DATETIME_FORMAT_PATTERN, propValuation.getValuationDate()) : null);
			
			//18E4 setting bedrooms, bathrooms, carparks
			if(prop.getBedrooms() != null){
				propValuationInfo.setNumOfBedRooms(prop.getBedrooms());
			}
			if(prop.getBathrooms() != null){
				propValuationInfo.setNumOfBathRooms(prop.getBathrooms());
			}
			if(prop.getCarparks() != null){
				propValuationInfo.setNumberOfCarSpaces(prop.getCarparks());
			}
		}
		return propValuationInfo;
	}
	
	private boolean isPoboxAddress(AddressInfo address) {
		String addressLine1 = address.getLine1();
		String addressLine2 = address.getLine2();
		String addressLine3 = address.getLine3();
		
		boolean isPOBoxAddress = false;
		
		if(addressLine1 != null && addressLine1.length() > 0 )  {
			isPOBoxAddress = !ttService.checkForPOBoxAddress(addressLine1);
		}
	
		if(!isPOBoxAddress && addressLine2 != null && addressLine2.length() > 0){
			isPOBoxAddress = !ttService.checkForPOBoxAddress(addressLine2);
		}
		
		if(!isPOBoxAddress && addressLine3 != null && addressLine3.length() > 0){
			isPOBoxAddress = !ttService.checkForPOBoxAddress(addressLine3);
		}
	
		return isPOBoxAddress;
		
	}
	
	public void validateAppicationInfo(ApplicationInfo application, boolean creditCheckRequired) throws BusinessException {
		
		
		validateLoanType(application,false); 
		
		validateApplicantsInfo(application, creditCheckRequired); 
		
		if(application.getDashboard() != null && application.getDashboard().isLiabilityStatusInd()){
			validateLiabilityInfo(application);
		}
		
		if(application.getDashboard() != null && application.getDashboard().isExpenseStatusInd()){
			validateExpenseInfo(application, creditCheckRequired);
		}

		//AssetInfo
		
		if(application.getDashboard() != null && application.getDashboard().isAssetStatusInd()){
			validateAssetInfo(application, application.getAssets(),application.getProperties(), application.getLiabilities());
		}
		
		validateDashboardStatus(application);		
	}

public void validateAppicationInfo(ApplicationInfo application, boolean creditCheckRequired,boolean offerFlag) throws BusinessException {
		
		
		validateLoanType(application,offerFlag);
		
		validateApplicantsInfo(application, creditCheckRequired); 
		
		if(application.getDashboard() != null && application.getDashboard().isLiabilityStatusInd()){
			validateLiabilityInfo(application);
		}
		
		if(application.getDashboard() != null && application.getDashboard().isExpenseStatusInd()){
			validateExpenseInfo(application, creditCheckRequired);
		}

		//AssetInfo
		
		if(application.getDashboard() != null && application.getDashboard().isAssetStatusInd()){
			validateAssetInfo(application, application.getAssets(),application.getProperties(), application.getLiabilities());
		}
		
		validateDashboardStatus(application);		
	}

	
	
	
	public Application populateAppicationVO(ApplicationInfo application,  MobileSession mobileSession, IBankCommonData iBankCommonData, PerformanceLogger perfLogger) throws BusinessException {
		
		Application applicationVO = new Application();
		if(application != null ){
	        if(null!= application.getLoanType())
			applicationVO.setLoanType(populateLoanTypeInfo(application.getLoanType(), mobileSession, iBankCommonData, perfLogger));
	        
	        if(null!= application.getApplicants())
	        applicationVO.setApplicants(populateAppicantInfo(application.getApplicants(), mobileSession, iBankCommonData, perfLogger));
			
			applicationVO.setDashboard(populateDashboard(application.getDashboard()));
			
			applicationVO.setAssets(populateAssetInfo(application.getAssets(), mobileSession ));
			
			applicationVO.setLiabilities(populateLiabilityInfo(application.getLiabilities(), mobileSession));
			
			applicationVO.setProperties(populatePropertyInfoList(application.getProperties(), application.getAssets(), mobileSession, iBankCommonData, perfLogger));
		    
			applicationVO.setExpenses(populateExpenseInfo(application.getExpenses(), applicationVO, mobileSession));
			
			if(mobileSession.getHomeLoanApplication() != null && mobileSession.getHomeLoanApplication().getApplicationNum() != null) {
				applicationVO.setApplicationNum(mobileSession.getHomeLoanApplication().getApplicationNum());
			}
			if(mobileSession.getHomeLoanApplication() != null && mobileSession.getHomeLoanApplication().getCreditCheckEligible() != null){
				applicationVO.setCreditCheckEligible(mobileSession.getHomeLoanApplication().getCreditCheckEligible());
			}
			
			applicationVO = populateAppicationVOWithLenderId(applicationVO, application, mobileSession);
		}
	  return applicationVO;
	}
	
	public void removeLenderIdFromSession(MobileSession mobileSession) {
		mobileSession.removeDMLenderMap(); 
		mobileSession.removeDMLenderId(); 
	}
	
	private Application populateAppicationVOWithLenderId(Application application, ApplicationInfo applicationInfo,  MobileSession mobileSession) throws BusinessException {
		String lenderId = null;
		if(applicationInfo.getLenderIndex() != null) {
			if(applicationInfo.getLenderIndex() != -1) { //Customer selected a Lender on UI
				//Get the LenderId from Session Map
				 LabelValueMap lenderMap = mobileSession.getDMLenderMap();
				 if(lenderMap != null) {
					 lenderId = lenderMap.get(""+applicationInfo.getLenderIndex());
				 }
			}
		} else {
			//Check if the LenderId is set on Session
			lenderId = mobileSession.getDMLenderId();
		}
		if(lenderId != null) {
			application.setLenderId(lenderId);
		}
		return application;
	}
	private void validateAddress(AddressInfo addressInfo, boolean isComplete) throws BusinessException{
		//Validate AddressType against Defined Constants
		if(addressInfo != null && !StringMethods.isEmptyString(addressInfo.getAddrType())) {
			if(!MortgageUtil.addressTypes.contains(addressInfo.getAddrType())) {
				Logger.error("MortgageHelper - validateApplicantsInfo(). applicant.getAddress().getAddrType() is in incorrect format. ", this.getClass());
				throw new BusinessException(BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE);
			}

			if(!StringMethods.isEmptyString(addressInfo.getQasAddressId())){
				//TODO validate qasId and text
				
			}
			else{
				if(StringMethods.isEmptyString(addressInfo.getLine1())
						|| StringMethods.isEmptyString(addressInfo.getPostCode())
								|| StringMethods.isEmptyString(addressInfo.getSuburb())
										|| StringMethods.isEmptyString(addressInfo.getState())){
					Logger.error("MortgageHelper - validateApplicantsInfo(). applicant.getAddress() line1/Postcode/suburb/state is empty. ", this.getClass());
					throw new BusinessException(BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE);
				}
				
				if(addressInfo.getLine1().length() > 40
						|| (!StringMethods.isEmptyString(addressInfo.getLine2()) && addressInfo.getLine2().length() > 40)
								|| (!StringMethods.isEmptyString(addressInfo.getLine3()) && addressInfo.getLine3().length() > 40) ){
					Logger.error("MortgageHelper - validateApplicantsInfo(). applicant.getAddress() line1/line2/line3 length is greater than 40. ", this.getClass());
					throw new BusinessException(BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE);
				}
				
				//Suburb length check
				if(addressInfo.getSuburb().length() > 25 ){
					Logger.error("MortgageHelper - validateApplicantsInfo(). applicant.getAddress() suburb length is greater than 25. ", this.getClass());
					throw new BusinessException(BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE);
				}
				
				if(!StringUtil.isValidData(addressInfo.getLine1(), StringUtil.ADDRESS_VALID_CHAR_SET)
					|| (!StringMethods.isEmptyString(addressInfo.getLine2()) && !StringUtil.isValidData(addressInfo.getLine2(), StringUtil.ADDRESS_VALID_CHAR_SET))
					|| (!StringMethods.isEmptyString(addressInfo.getLine3()) && !StringUtil.isValidData(addressInfo.getLine3(), StringUtil.ADDRESS_VALID_CHAR_SET))){
					Logger.error("MortgageHelper - validateApplicantsInfo(). applicant.getAddress() line1/line2/line3 data is not valid. ", this.getClass());
					throw new BusinessException(BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE);
				}
				
				if(!StringUtil.isValidData(addressInfo.getSuburb())){
						Logger.error("MortgageHelper - validateApplicantsInfo(). applicant.getAddress() Suburb is not valid. ", this.getClass());
						throw new BusinessException(BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE);
				}
				
				if(!IBankParams.getStates().contains(addressInfo.getState())){
					Logger.error("MortgageHelper - validateApplicantsInfo(). applicant.getAddress().getStates() is not valid. ", this.getClass());
					throw new BusinessException(BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE);
				}
				
				if(!isValidPostCode(addressInfo.getPostCode(), addressInfo.getState())){
					Logger.error("MortgageHelper - validateApplicantsInfo(). applicant.getAddress() Postcode is in incorrect format. ", this.getClass());
					throw new BusinessException(BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE);
				}
				
				if(isPoboxAddress(addressInfo)){
					Logger.error("Address contains POBOX address.  ", this.getClass());
					throw new BusinessException(BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE);
				}

			}
		}else if(isComplete)
		{
			Logger.error("Address incomplete.  ", this.getClass());
			throw new BusinessException(BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE);
		}
		
	}
	
	private boolean isValidPostCode(String value, String state)
	{

		int postCode = 0;
		try
		{
			postCode = Integer.parseInt(value);
		} catch (NumberFormatException ex)
		{
			return false;
		}

		if (state.equals("NSW"))
		{
			if (((postCode < 1000) | (postCode > 1999)) & ((postCode < 2000) | (postCode > 2599)) & ((postCode < 2619) | (postCode > 2899))
					& ((postCode < 2921) | (postCode > 2999)))
			{
				return false;
			} else
				return true;
		} else if (state.equals("ACT"))
		{
			if (((postCode < 200) | (postCode > 299)) & ((postCode < 2600) | (postCode > 2618)) & ((postCode < 2900) | (postCode > 2920)))
			{
				return false;
			} else
				return true;

		} else if (state.equals("VIC"))
		{
			if (((postCode < 3000) | (postCode > 3999)) & ((postCode < 8000) | (postCode > 8999)))
			{
				return false;
			} else
				return true;
		} else if (state.equals("QLD"))
		{
			if (((postCode < 4000) | (postCode > 4999)) & ((postCode < 9000) | (postCode > 9799)))
			{
				return false;
			} else
				return true;
		} else if (state.equals("SA"))
		{
			if ((postCode < 5000) | (postCode > 5999))
			{
				return false;
			} else
				return true;
		} else if (state.equals("WA"))
		{
			if ((postCode < 6000) | (postCode > 6999))
			{
				return false;
			} else
				return true;
		} else if (state.equals("TAS"))
		{
			if ((postCode < 7000) | (postCode > 7999))
			{
				return false;
			} else
				return true;

		} else if (state.equals("NT"))
		{
			if ((postCode < 800) | (postCode > 999))
			{
				return false;
			} else
				return true;
		}
		return false;
	}
	
	public void validatePropertyInsightReq(PropertyInsightReq req){
		
	}
	
	public PropertyInsightResp populatePropertyInsightResp(MortgageAddress addr, boolean heartBeatFlag){
		PropertyInsightResp propertyInsightResponse = new PropertyInsightResp();
		propertyInsightResponse.setAddress(addr);
		propertyInsightResponse.setPropertyInsightUp(heartBeatFlag);

	    return propertyInsightResponse;
	}
	
	public PropertyInsightDetails populatePropertyInsightDetails(){
		
		List<PropertyBand> propertyInsightDtls=new ArrayList<PropertyBand>();
		PropertyInsightDetails insightDtls=new PropertyInsightDetails();
		String [] bandValue=null;
		int lowVal=0;
		int highVal=0;
		String color=null;
		String text=null;
		String url=null;
		String appendText=null;
		String headerName=null;
		String headerSource=null;
     		
		List<DMRefDataVO> dmRefData=new ArrayList<DMRefDataVO>();
		List<DMRefDataVO> dmRefData_text=new ArrayList<DMRefDataVO>();
		
		dmRefData=mortgageParams.getPropertyInsightColorRefData(MortgageUtil.COMPASS_REFERENCE_DATA_STATUS_IN_USE);
		dmRefData_text=mortgageParams.getPropertyInsightTextRefData(MortgageUtil.COMPASS_REFERENCE_DATA_STATUS_IN_USE);
		
		for(DMRefDataVO dmref:dmRefData){
			for(DMRefDataVO dmRef_text:dmRefData_text){
				if(dmref.getCompassCode().equalsIgnoreCase(dmRef_text.getCompassCode())){
					PropertyBand pBand=new PropertyBand();
					bandValue=dmRef_text.getCompassCode().split("-");
					lowVal=Integer.parseInt(bandValue[0]);
					highVal=Integer.parseInt(bandValue[1]);
					color=dmref.getDescription();
					text=dmRef_text.getDescription();
					pBand.setBandLowVal(lowVal);
					pBand.setBandHighVal(highVal);
					pBand.setColor(color);
					pBand.setConfidenceText(text);
					propertyInsightDtls.add(pBand);
				}
			}			
		}
		List<LabelValueVO> labelValueVOList =getDMCodesDataPropertyInsight(MortgageUtil.ORIGIN_ALL,MortgageUtil.REF_DATA_CATEGORY_PROPERTY_INSIGHT);
		
		if (labelValueVOList != null && !labelValueVOList.isEmpty()) 
		{
			for (LabelValueVO labelValueVO : labelValueVOList) 
			{
				if(labelValueVO.getValue().equals(MortgageUtil.PROPERTY_INSIGHT_URL)) {
					url = labelValueVO.getLabel();
				} 
				if(labelValueVO.getValue().equals(MortgageUtil.PROPERTY_INSIGHT_APPEND_TEXT)) {
					appendText = labelValueVO.getLabel();
				}
				if(labelValueVO.getValue().equals(MortgageUtil.PROPERTY_INSIGHT_HEADER_NAME_TAG)) {
					headerName = labelValueVO.getLabel();
				} 
				if(labelValueVO.getValue().equals(MortgageUtil.PROPERTY_INSIGHT_HEADER_SOURCE_TAG)) {
					headerSource = labelValueVO.getLabel();
				}
			}			
		}
		
		
		String appender="DM-";
		Random rnd = new Random();
		int syntheticID = 10000000 + rnd.nextInt(90000000);
		
		DateFormat dateFormat = new SimpleDateFormat("yyyyMMdd");
	    Date date = new Date();
	    String currDate=dateFormat.format(date);
		
	    String uuid_temp=appender.concat(currDate);
	    String uuid=uuid_temp.concat(String.valueOf(syntheticID));
	    
		List<Header> headerList=new ArrayList<Header>();
		
		List<LabelValueVO> labelValueVOList_header =getDMCodesDataPropertyInsight(MortgageUtil.ORIGIN_ALL,MortgageUtil.REF_DATA_CATEGORY_PROPERTY_INSIGHT_HEADER);
		if (labelValueVOList_header != null && !labelValueVOList_header.isEmpty()) 
		{
			for (LabelValueVO labelValueVO : labelValueVOList_header) 
			{				
				if(labelValueVO.getLabel().equals(MortgageUtil.PROPERTY_INSIGHT_HEADER_NAME_TAG)) {
					Header header=new Header();
					headerName = labelValueVO.getLabel();
					header.setParamName(headerName);
					header.setParamVal(uuid);
					headerList.add(header);
				} 
				if(labelValueVO.getLabel().equals(MortgageUtil.PROPERTY_INSIGHT_HEADER_SOURCE_TAG)) {
					Header header=new Header();
					headerName = labelValueVO.getLabel();
					header.setParamName(headerName);
					header.setParamVal(MortgageUtil.PROPERTY_INSIGHT_HEADER_SOURCE);
					headerList.add(header);
				}				
			}
		}
		insightDtls.setUrl(url);
		insightDtls.setAppendText(appendText);
		insightDtls.setPropertyMapping(propertyInsightDtls);
		insightDtls.setHeaderList(headerList);
		
		return insightDtls;
	}
	
	private  List<LabelValueVO> getDMCodesDataPropertyInsight(String origin, String category) {
		if(origin == null || origin.isEmpty()) {
			origin = MortgageUtil.ORIGIN_ALL;
		}
		List<LabelValueVO> labelValueVOList = mortgageParams.getDMCodesDataLabelValueVOList(origin, category);
		return labelValueVOList;
	}
	
	private BigDecimal getDMCodesDataRefinanceMinimumAmount() {
		LabelValueVO labelValueVO = mortgageParams.getDMCodesDataLabelValueVO(MortgageUtil.ORIGIN_ALL, MortgageUtil.MORTGAGE_PARAMETER, MortgageUtil.MORTGAGE_MIN_BORROWING_AMOUNT);
		BigDecimal value = null;
		
		if (labelValueVO != null && labelValueVO.getLabel() != null && !labelValueVO.getLabel().isEmpty()) {
			value = new BigDecimal(labelValueVO.getLabel());
		}
		
		return value;
	}
	
	public Long getDMCodesDataMaxNumberOfDocuments() {
		LabelValueVO labelValueVO = mortgageParams.getDMCodesDataLabelValueVO(MortgageUtil.ORIGIN_ALL, MortgageUtil.MORTGAGE_DOC_UPLOAD, MortgageUtil.MORTGAGE_MAX_NUMBER_DOCUMENTS);
		
		Long value = null;
		
		if (labelValueVO != null && labelValueVO.getLabel() != null && !labelValueVO.getLabel().isEmpty()) {
			value = new Long(labelValueVO.getLabel());
		}
		
		return value;
	}
	
	private String getDMCodesDataMaxDocumentSize() {
		LabelValueVO labelValueVO = mortgageParams.getDMCodesDataLabelValueVO(MortgageUtil.ORIGIN_ALL, MortgageUtil.MORTGAGE_DOC_UPLOAD, MortgageUtil.MORTGAGE_MAX_DOCUMENT_SIZE);
		String value = null;
		
		if (labelValueVO != null && labelValueVO.getLabel() != null && !labelValueVO.getLabel().isEmpty()) {
			value = labelValueVO.getLabel();
		}
		
		return value;
	}
	private String getDMCodesDataMaxDocumentsUploadSize() {
		LabelValueVO labelValueVO = mortgageParams.getDMCodesDataLabelValueVO(MortgageUtil.ORIGIN_ALL, MortgageUtil.MORTGAGE_DOC_UPLOAD, MortgageUtil.MORTGAGE_MAX_DOCUMENT_UPLOAD_SIZE);
		String value = null;
		if (labelValueVO != null && labelValueVO.getLabel() != null && !labelValueVO.getLabel().isEmpty()) {
			value = labelValueVO.getLabel();
		}		
		return value;
	}
	private Long getDMCodesDataMaxNumOfDocsPerUpload() {
		LabelValueVO labelValueVO = mortgageParams.getDMCodesDataLabelValueVO(MortgageUtil.ORIGIN_ALL, MortgageUtil.MORTGAGE_DOC_UPLOAD, MortgageUtil.MORTGAGE_MAX_DOCUMENT_PER_UPLOAD);
		Long value = null;
		if (labelValueVO != null && labelValueVO.getLabel() != null && !labelValueVO.getLabel().isEmpty()) {
			value = new Long(labelValueVO.getLabel());
		}		
		return value;
	}
	private String getDMCodesDataAllowedDocTypes() {
		LabelValueVO labelValueVO = mortgageParams.getDMCodesDataLabelValueVO(MortgageUtil.ORIGIN_ALL, MortgageUtil.MORTGAGE_DOC_UPLOAD, MortgageUtil.MORTGAGE_ALLOWED_DOCUMENTS_TYPE);
		String value = null;
		if (labelValueVO != null && labelValueVO.getLabel() != null && !labelValueVO.getLabel().isEmpty()) {
			value = labelValueVO.getLabel();
		}		
		return value;
	}
	
	private String getDMCodesDataDocumentUploadURL() {
		LabelValueVO labelValueVO = mortgageParams.getDMCodesDataLabelValueVO(MortgageUtil.ORIGIN_ALL, MortgageUtil.MORTGAGE_DOC_UPLOAD, MortgageUtil.MORTGAGE_DOCUMENT_UPLOAD_URL);
		String value = null;
		if (labelValueVO != null && labelValueVO.getLabel() != null && !labelValueVO.getLabel().isEmpty()) {
			value = labelValueVO.getLabel();
		}		
		return value;
	}

	public void validateAssetInfo(ApplicationInfo application,List<AssetInfo> assetInfoList, List<PropertyInfo> propertyList, List<LiabilityInfo> liabilityList) throws BusinessException 
	{	
		List<Integer> propertyIndexSkipList = new ArrayList<Integer>();
		if(null!=assetInfoList){
				for(AssetInfo asset:assetInfoList){
					if(null!=asset){
						
						if(asset.getOtherPercent() != null && "100".equals(asset.getOtherPercent())){
							propertyIndexSkipList.add(asset.getPropertyIndex());
						}
						if(!StringMethods.isEmptyString(asset.getCategory())){
							if(!mortgageRefDataHelper.isValidCode(mortgageParams.getAssetCategoryRefData(MortgageUtil.COMPASS_REFERENCE_DATA_STATUS_IN_USE),asset.getCategory())) {
								Logger.error("Validation failed. MortgageHelper.validateAssetInfo(). asset.getCategory() - UI code is not matching with DB", this.getClass());
								throw new BusinessException(BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE);
							}
							else{
								if(MortgageUtil.AssetCategoryEnum.SAVING.getValue().equalsIgnoreCase(asset.getCategory())){
									if(StringMethods.isEmptyString(asset.getAssetType())){
										Logger.error("Validation failed. MortgageHelper.validateAssetInfo(). Savings - asset.getAssetType() is EMPTY", this.getClass());
										throw new BusinessException(BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE);
									}
									if(StringMethods.isEmptyString(asset.getBankCode())){
										Logger.error("Validation failed. MortgageHelper.validateAssetInfo(). Savings - asset.getBankCode() is EMPTY", this.getClass());
										throw new BusinessException(BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE);
									}
									else{
										if(!mortgageRefDataHelper.isValidCode(mortgageParams.getBankBrandRefData(MortgageUtil.COMPASS_REFERENCE_DATA_STATUS_IN_USE),asset.getBankCode())) {
											Logger.error("Validation failed. MortgageHelper.validateAssetInfo(). asset.getBankCode() - UI code is not matching with DB", this.getClass());
											throw new BusinessException(BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE);
										}
									}
								}
								if(MortgageUtil.AssetCategoryEnum.OTHER.getValue().equalsIgnoreCase(asset.getCategory())){
									if(StringMethods.isEmptyString(asset.getAssetType())){
										Logger.error("Validation failed. MortgageHelper.validateAssetInfo(). Savings - asset.getAssetType() is EMPTY", this.getClass());
										throw new BusinessException(BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE);
									}
									else{
										if(!mortgageRefDataHelper.isValidCode(mortgageParams.getAssetTypeRefData(MortgageUtil.COMPASS_REFERENCE_DATA_STATUS_IN_USE),asset.getAssetType())) {
											Logger.error("Validation failed. MortgageHelper.validateAssetInfo(). asset.getAssetType() - UI code is not matching with DB", this.getClass());
											throw new BusinessException(BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE);
										}
									}
								}
							}
						}
						else{
							Logger.error("Validation failed. MortgageHelper.validateAssetInfo(). asset.getCategory() is EMPTY", this.getClass());
							throw new BusinessException(BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE);
						}
					}
				}
			}
		
			//Only for HomeLoan Liability
			validatePropertyForHomeLoan(application);

			
			if(null!=propertyList){
				for(PropertyInfo property : propertyList){
					if(null!=property){
						if(propertyIndexSkipList.contains(Integer.valueOf(property.getIndex()))){
							continue;
						}
						//Validating mandatory fields.
						if(null!=property.getAddress()){
							// QAS Type address
							if(null!=property.getAddress().getQasAddressId() || !StringMethods.isEmptyString(property.getAddress().getQasAddressId())){ 
								if(StringMethods.isEmptyString(property.getAddress().getAddressText()) || property.getAddress().getAddressText()==null) {
									   Logger.error("QAS Address not provided:", this.getClass());
									   throw new BusinessException(BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE);		
									}
							}
							// Manual address type
							else{
								if(StringMethods.isEmptyString(property.getAddress().getLine1()) || property.getAddress().getLine1()==null) {
									   Logger.error("Line 1 Address not provided:", this.getClass());
									   throw new BusinessException(BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE);		
								}
								if(StringMethods.isEmptyString(property.getAddress().getSuburb()) || property.getAddress().getSuburb()==null) {
									   Logger.error("Suburb not provided:", this.getClass());
									   throw new BusinessException(BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE);		
								}
								if(StringMethods.isEmptyString(property.getAddress().getState()) || property.getAddress().getState()==null) {
									   Logger.error("State not provided:", this.getClass());
									   throw new BusinessException(BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE);		
								}
								if(StringMethods.isEmptyString(property.getAddress().getPostCode()) || property.getAddress().getPostCode()==null) {
									   Logger.error("Postcode not provided:", this.getClass());
									   throw new BusinessException(BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE);		
								}
								if(property.getAddress().getLine1().length() > 40
										|| (!StringMethods.isEmptyString(property.getAddress().getLine2()) && property.getAddress().getLine2().length() > 40)
												|| (!StringMethods.isEmptyString(property.getAddress().getLine3()) && property.getAddress().getLine3().length() > 40) ){
									Logger.error("MortgageHelper - validateAssetInfo(). applicant.getAddress() line1/line2/line3 length is greater than 40. ", this.getClass());
									throw new BusinessException(BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE);
								}
								
								if(property.getAddress().getSuburb().length() > 25 ){
									Logger.error("MortgageHelper - validateAssetInfo(). applicant.getAddress() suburb length is greater than 25. ", this.getClass());
									throw new BusinessException(BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE);
								}
								
								if(!StringUtil.isValidData(property.getAddress().getLine1(), StringUtil.ADDRESS_VALID_CHAR_SET)
									|| (!StringMethods.isEmptyString(property.getAddress().getLine2()) && !StringUtil.isValidData(property.getAddress().getLine2(), StringUtil.ADDRESS_VALID_CHAR_SET))
									|| (!StringMethods.isEmptyString(property.getAddress().getLine3()) && !StringUtil.isValidData(property.getAddress().getLine3(), StringUtil.ADDRESS_VALID_CHAR_SET))){
									Logger.error("MortgageHelper - validateAssetInfo(). applicant.getAddress() line1/line2/line3 data is not valid. ", this.getClass());
									throw new BusinessException(BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE);
								}
								
								if(!StringUtil.isValidData(property.getAddress().getSuburb())){
										Logger.error("MortgageHelper - validateAssetInfo(). applicant.getAddress() Suburb is not valid. ", this.getClass());
										throw new BusinessException(BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE);
								}
								
								if(!IBankParams.getStates().contains(property.getAddress().getState())){
									Logger.error("MortgageHelper - validateAssetInfo(). applicant.getAddress().getStates() is not valid. ", this.getClass());
									throw new BusinessException(BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE);
								}
								
								if(!isValidPostCode(property.getAddress().getPostCode(), property.getAddress().getState())){
									Logger.error("MortgageHelper - validateAssetInfo(). applicant.getAddress() Postcode is in incorrect format. ", this.getClass());
									throw new BusinessException(BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE);
								}
								
								if(isPoboxAddress(property.getAddress())){
									Logger.error("Address contains POBOX address.  ", this.getClass());
									throw new BusinessException(BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE);
								}
							}
						}

						//validating other
						if(StringMethods.isEmptyString(property.getCustomerEstimatedValue()) || property.getCustomerEstimatedValue()==null) {
							   Logger.error("CustomerEstimated Value not provided:", this.getClass());
							   throw new BusinessException(BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE);		
						}
						
						//validating Mandatory field
						if(StringMethods.isEmptyString(property.getPropertyType())) {
							   Logger.error(" property.getPropertyType() Value not provided:", this.getClass());
							   throw new BusinessException(BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE);		
						}
						
						//Validate
						if(!StringMethods.isEmptyString(property.getPropertyType())) {
							if(!mortgageRefDataHelper.isValidCode(mortgageParams.getPropertyTypeRefData(MortgageUtil.COMPASS_REFERENCE_DATA_STATUS_IN_USE),property.getPropertyType())) {
								Logger.error("MortgageHelper - property.getPropertyType() is in incorrect format. ", this.getClass());
								throw new BusinessException(BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE);
							}			
						}
					}
				}
			}
			Logger.debug("Exiting validateAssetInfo() with ALL validations SUCCESS", this.getClass());
		}
	
	private List<Property> populatePropertyInfoList(List<PropertyInfo> property, List<AssetInfo> assetInfoList, MobileSession mobileSession, IBankCommonData iBankCommonData, PerformanceLogger perfLogger) throws BusinessException{
		List<Property> prop=null;
			prop=new ArrayList<Property	>();		
			for(PropertyInfo propInfo: property){
				
				if(populateClasPropertyInfo(propInfo, assetInfoList, prop)){
					continue;
				}
				
				Property propertyObj = new Property();
				propertyObj.setIndex(propInfo.getIndex());
				//propertyObj.setCustomerEstimatedValue(propInfo.getCustomerEstimatedValue());
				if(!StringMethods.isEmptyString(propInfo.getCustomerEstimatedValue())){
					propertyObj.setCustomerEstimatedValue(new BigDecimal(propInfo.getCustomerEstimatedValue()));
				}
				//propertyObj.setPropertyInsightValue(propInfo.getPropertyInsightValue());
				if(!StringMethods.isEmptyString(propInfo.getPropertyInsightValue())){
					propertyObj.setPropertyInsightValue(new BigDecimal(propInfo.getPropertyInsightValue()));
				}
				propertyObj.setUseAsSecInd(propInfo.getUseAsSecInd());
				propertyObj.setKeepPropertyInd(propInfo.getKeepPropertyInd());
				propertyObj.setRefinanceInd(propInfo.getRefinanceInd());
				propertyObj.setMortgagedInd(propInfo.getMortgagedInd());
				propertyObj.setShareOwnershipInd(propInfo.getShareOwnershipInd());
				propertyObj.setRentalIncomeInd(propInfo.getRentalIncomeInd());
				propertyObj.setPropertyType(propInfo.getPropertyType());
				
				if(propInfo.getBedrooms()!= null){
					propertyObj.setBedrooms(new Long(propInfo.getBedrooms().longValue()));
				}
				if(propInfo.getBathrooms() != null){
					propertyObj.setBathrooms(new Long(propInfo.getBathrooms().longValue()));
				}
				if(propInfo.getCarparks() != null){
					propertyObj.setCarparks(new Long(propInfo.getCarparks().longValue()));
				}
				
				if(propInfo.getAddress() != null ){
					Application homeloanApplication = mobileSession.getHomeLoanApplication();
					if((propInfo.getAddress().getQasAddressId() == null && propInfo.getAddress().getAddressText()!=null)
						&& homeloanApplication.getProperties() != null){
						Property sessionProp = getPropertyFromSessionApplication(propInfo,  homeloanApplication.getProperties());

						if(sessionProp != null 
								&& sessionProp.getAddress() != null){
							propertyObj.setAddress(sessionProp.getAddress());
						}
					}
					else{
						MortgageAddress addr =  populateMortgageAddress(propInfo.getAddress(), mobileSession, iBankCommonData, perfLogger, AddressType.D.toString());
						addr = cloneMortgageAddress(addr);
						addr.setAddrType(propInfo.getAddress().getAddrType());
						propertyObj.setAddress(addr);
					}
				}			
				
				propertyObj.setPrimaryResidenceInd(propInfo.getPrimaryResidenceInd());
				propertyObj = populatePropertyDatabaseID(propInfo, propertyObj,  mobileSession );
				
				prop.add(propertyObj);
			}
			
			return prop;
	}
	
	private Property getPropertyFromSessionApplication(PropertyInfo propInfo,  List<Property> propList){
		for(Property p:propList){
			if(p.getIndex() == propInfo.getIndex()){
				return p;
			}
		}
		return null;
	}
	
	
	private boolean populateClasPropertyInfo(PropertyInfo property, List<AssetInfo> assetInfoList,List<Property> props){
		boolean isClasProperty = false;
		for(AssetInfo asset:assetInfoList){
			if(asset.getPropertyIndex() != null && asset.getPropertyIndex().intValue() == property.getIndex()){
				/*
				if(asset.getClasAssetId() != null){
					isClasProperty = true;
					Property propertyObj = new Property();
					propertyObj.setIndex(property.getIndex());
					
					propertyObj.setUseAsSecInd(property.getUseAsSecInd());
					propertyObj.setKeepPropertyInd(property.getKeepPropertyInd());
					propertyObj.setRentalIncomeInd(propInfo.getRentalIncomeInd());
					propertyObj.setShareOwnershipInd(propInfo.getShareOwnershipInd());
					propertyObj.setPropertyType(property.getPropertyType());
					
					if(property.getBedrooms()!= null){
						propertyObj.setBedrooms(new Long(property.getBedrooms().longValue()));
					}
					if(property.getBathrooms() != null){
						propertyObj.setBathrooms(new Long(property.getBathrooms().longValue()));
					}
					if(property.getCarparks() != null){
						propertyObj.setCarparks(new Long(property.getCarparks().longValue()));
					}
					props.add(propertyObj);
				}
				*/
				
				break;
			}
		}
		return isClasProperty;
	}
	
	public LoanAssessmentResp populateLoanAssessmentResp(LoanOutcomeInfo loanOutcomeInfo, MobileSession mobileSession, Boolean valAssessRequired, String valStatus) throws BusinessException{
		LoanAssessmentResp loanAssessmentResp = new LoanAssessmentResp();
		
		ArrayList<LoanOutcome> loanOutcomes = loanOutcomeInfo.getLoanOutcomes();
		if(loanOutcomes != null && loanOutcomes.size() > 0)
		{	
			ArrayList<LoanAssessmentInfo> outComeList = new ArrayList<LoanAssessmentInfo>();
			for ( LoanOutcome  loanOutcome : loanOutcomes )
			{	
				LoanAssessmentInfo loanAssessmentInfo = new LoanAssessmentInfo();
				if(loanOutcome.getMessage1().equalsIgnoreCase(MortgageUtil.LoanOutcomeEnum.HAPPYPATH1.toString()) 
						|| loanOutcome.getMessage1().equalsIgnoreCase(MortgageUtil.LoanOutcomeEnum.MAXPURCHASEPRICE_FAIL.toString()) ){
					if(loanOutcome.getPurchasePrice() != null){
						loanAssessmentInfo.setPurchasePrice(loanOutcome.getPurchasePrice().toString());
					}
					
					
					if ( loanOutcome.getMessage1().equalsIgnoreCase(MortgageUtil.LoanOutcomeEnum.MAXPURCHASEPRICE_FAIL.toString() ) )
					{
						Logger.info("MortgageHelper - Max Purchase fail.", this.getClass());
						loanAssessmentInfo.setLoanOutcomeStatus(Integer.parseInt(MortgageUtil.LoanOutcomeEnum.HAPPYPATH1_WITHPROPERTY.getValue()));
						if(loanOutcome.getPropertyAddress() != null){
							loanAssessmentInfo.setOutcomeMessage(IBankParams.getErrorMessage(mortgageParams.getBaseOriginCode(mobileSession.getOrigin()), String.valueOf(BusinessException.OUTCOME_MAX_PURCHASE_FAIL)));
						}
						else{
							loanAssessmentInfo.setOutcomeMessage(null);
						}
						
						loanAssessmentInfo.setPropertyAddress(loanOutcome.getPropertyAddress());
					}
					else{
						loanAssessmentInfo.setLoanOutcomeStatus(Integer.parseInt(MortgageUtil.LoanOutcomeEnum.HAPPYPATH1_WITHPROPERTY.getValue()));
						loanAssessmentInfo.setOutcomeMessage(getLoanoutcomeMessage(mobileSession, loanOutcome ));
						loanAssessmentInfo.setPropertyAddress(loanOutcome.getPropertyAddress());
						if(loanOutcome.getSegmentUsed().equalsIgnoreCase(HomeLoanSegmentsEnum.SEGMENT2.getClasSegment()) || loanOutcome.getSegmentUsed().equalsIgnoreCase(HomeLoanSegmentsEnum.SEGMENT5.getClasSegment())
							|| loanOutcome.getSegmentUsed().equalsIgnoreCase(HomeLoanSegmentsEnum.SEGMENT6A.getClasSegment())|| loanOutcome.getSegmentUsed().equalsIgnoreCase(HomeLoanSegmentsEnum.SEGMENT6B.getClasSegment()) 
							|| loanOutcome.getSegmentUsed().equalsIgnoreCase(HomeLoanSegmentsEnum.SEGMENT7A.getClasSegment()) || loanOutcome.getSegmentUsed().equalsIgnoreCase(HomeLoanSegmentsEnum.SEGMENT7B.getClasSegment())
							|| loanOutcome.getSegmentUsed().equalsIgnoreCase(HomeLoanSegmentsEnum.SEGMENT9.getClasSegment())){
							if(loanOutcome.getPropertyAddress()!= null ){
								loanAssessmentInfo.setHeaderText("Congratulations!");
							}
							else{
								loanAssessmentInfo.setHeaderText(null);
							}
						}
					}
					
				}
				else if(loanOutcome.getMessage1().equalsIgnoreCase(MortgageUtil.LoanOutcomeEnum.SADPATH2.toString())){
					loanAssessmentInfo.setOutcomeMessage(IBankParams.getErrorMessage(mortgageParams.getBaseOriginCode(mobileSession.getOrigin()), String.valueOf(BusinessException.OUTCOME_SAD_PATH2)));
					Logger.info("MortgageHelper - Sad2 without property.", this.getClass());
					loanAssessmentInfo.setLoanOutcomeStatus(Integer.parseInt(MortgageUtil.LoanOutcomeEnum.SADPATH2.getValue()));
					outComeList.add(loanAssessmentInfo);
					loanAssessmentResp.setLoanAssessmentInfo(outComeList);

					return loanAssessmentResp;
				}
				if(loanOutcome.getLoanEstimatedAmt() != null){
					loanAssessmentInfo.setCustomerRequestedLoanAmount(loanOutcome.getLoanEstimatedAmt().toString());
				}
				if(loanOutcome.getRepaymentAmount() != null){
					loanAssessmentInfo.setRepaymentAmount(loanOutcome.getRepaymentAmount().toString());
				}
				loanAssessmentInfo.setRepaymentFrequency(loanOutcome.getRepaymentFrequency());
				if(loanOutcome.getInterestRate() != null){
					loanAssessmentInfo.setFinalRateOffer(loanOutcome.getInterestRate().toString());
				}		
					
		        BigDecimal discountMargin = BigDecimal.ZERO;
				if ( loanOutcome.getCampaignMargin() != null )
				{
					discountMargin = discountMargin.add(loanOutcome.getCampaignMargin());
					
					if ( loanOutcome.getExpirydate() != null )
					{
						loanAssessmentInfo.setCampaignMarginExpiryDate(DateMethods.formatDate("dd/MM/yyyy", loanOutcome.getExpirydate())); 
					}
			
				}
			
				if ( loanOutcome.getDefaultMargin() != null )
				{
					discountMargin = discountMargin.add(loanOutcome.getDefaultMargin());
				}
			
				if ( loanOutcome.getPackageDiscountMargin() != null )
				{
					discountMargin = discountMargin.add(loanOutcome.getPackageDiscountMargin());
				}
				
				if ( discountMargin.compareTo(BigDecimal.ZERO) < 0 )
				{
					Logger.debug("Discount Margin :" +discountMargin  , this.getClass());
					
					 BigDecimal discountMarginBig = discountMargin.setScale(2 , BigDecimal.ROUND_DOWN);
				   loanAssessmentInfo.setCampaignMargin(discountMarginBig.abs().toString());
				}
					
				
				
				if(loanOutcome.getLMIPremium() != null && loanOutcome.getLMIPremium().intValue() > 0){
					loanAssessmentInfo.setLMIPremium ( loanOutcome.getLMIPremium().toString() );
				}
				else{
					loanAssessmentInfo.setLMIPremium ( null );
				}
				
				if(loanOutcome.getBuyingCost() != null){
					loanAssessmentInfo.setBuyingCoststs(loanOutcome.getBuyingCost().toString());
				}
				
				if(loanOutcome.getStampDuty() != null){
					loanAssessmentInfo.setStampDuty(loanOutcome.getStampDuty().toString());
				}	
					if(loanOutcome.getGovernmentFees() != null){
						loanAssessmentInfo.setGovernmentFees(loanOutcome.getGovernmentFees().toString());
					}
				if(loanOutcome.getLegalFees() != null){
					loanAssessmentInfo.setLegalFees(loanOutcome.getLegalFees().toString());
				}
				if(loanOutcome.getPackageFees() != null && loanOutcome.getPackageFees().intValue() > 0){
					loanAssessmentInfo.setAnnualPackageFee(loanOutcome.getPackageFees().toString() );
				}
				else{
					loanAssessmentInfo.setAnnualPackageFee(null);
				}
				if(loanOutcome.getBankFees() != null){
					loanAssessmentInfo.setBankFees(loanOutcome.getBankFees().toString());
				}
				if(loanOutcome.getAdminFee() != null && loanOutcome.getAdminFee().intValue() > 0){
					loanAssessmentInfo.setMonthlyAdminFee(loanOutcome.getAdminFee().toString() );
				}
				else{
					loanAssessmentInfo.setMonthlyAdminFee(null);
				}
				
				loanAssessmentInfo.setPropertyInsightUp(HeartBeat.isApplicationAvailable(HeartBeat.PROPERTY_INSIGHT));
				
				if(loanOutcome.getDepositAmt() != null){
					loanAssessmentInfo.setDepositAmount(loanOutcome.getDepositAmt().toString());
				}
				if(loanOutcome.getLvr() != null){
					loanAssessmentInfo.setLoanPropertyValue(""+loanOutcome.getLvr().longValue() );
				}
				loanAssessmentInfo.setSegmentName(loanOutcome.getSegmentUsed());
				if(loanOutcome.getConcessionalStampDuty() != null){
					loanAssessmentInfo.setConcessionStampDuty(loanOutcome.getConcessionalStampDuty().toString());
				}
				if(loanOutcome.getMaxPropPurchaseValue() != null){
					loanAssessmentInfo.setMaxPropPurchaseValue(loanOutcome.getMaxPropPurchaseValue().toString());
				}
/*				if ( HomeLoanSegmentsEnum.SEGMENT9.getClasSegment().equalsIgnoreCase (loanOutcome.getSegmentUsed() ) )
				{
					String msg = MBAppUtils.getMessage(mobileSession.getMortgageSessionInfo().getOrigin(), BusinessException.REFINANCE_CASH_BACK_BANNER);
					if ( loanOutcome.isCashBackOffer() )
					{
						loanAssessmentInfo.setShowBanner(true);
						loanAssessmentInfo.setBannerMsg(msg);
					}

				}  */
				
				if ( loanOutcome.getLoanEstimatedAmt() !=  null)
				{
					loanAssessmentInfo.setLoanAmount( loanOutcome.getLoanEstimatedAmt().toString());
				}

				if(valStatus != null && valAssessRequired != null){
					loanAssessmentInfo.setValutionStatus(valStatus);
					loanAssessmentInfo.setValAssessRequired(valAssessRequired);
				}

				loanAssessmentInfo = populateMessages (  loanAssessmentInfo,  loanOutcome,  mobileSession  );
				
				outComeList.add(loanAssessmentInfo);
				loanAssessmentResp.setLoanAssessmentInfo(outComeList);
			}
			
			loanAssessmentResp.setCreditCheck(loanOutcomeInfo.getCreditCheck());
			loanAssessmentResp.setSubmitTimeout(loanOutcomeInfo.getSubmitTimeout());
			loanAssessmentResp.setSpinnerText(loanOutcomeInfo.getSpinnerText());
			
			
			loanAssessmentResp.setIsPolicyOfferApplicable(loanOutcomeInfo.getIsPolicyOfferApplicable());
			loanAssessmentResp.setPolicyOfferNotAvailFlag(loanOutcomeInfo.getPolicyOfferNotAvailFlag());
		}
		else{
			Logger.error("OutcomeSegments null. ", this.getClass());
			throw new BusinessException(BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE);
		}
		return loanAssessmentResp;
	}
		
	public MortgageCommonData populateMortgageCommonData( IGenericSession mobileSession, String origin, ReqHeader req,  HttpServletRequest httpRequest )
	{
		MortgageCommonData mortgageCommonData = new MortgageCommonData();
		mortgageCommonData.setDeviceType(req.getDeviceType());		
		
		mortgageCommonData.setOrigin(getGDWOrigin(req,origin) );
		if ( mobileSession != null )
		 mortgageCommonData.setSessionId(mobileSession.getId());
		
		mortgageCommonData.setUserAgent(httpRequest.getHeader("User-Agent"));
		
		String tempOrigin = origin; 
		if ( tempOrigin.length() > 3 )
		{
			tempOrigin = tempOrigin.substring(1);
		}
		mortgageCommonData.setIpAddress(MBAppHelper.resolveIPAddress(httpRequest, tempOrigin));
		if ( ! MBAppHelper.isValidIPAddress ( mortgageCommonData.getIpAddress() ) )
		{
			Logger.info("Invalid IP Address : " + mortgageCommonData.getIpAddress() ,this.getClass());
			mortgageCommonData.setIpAddress("0.0.0.0");
		}
		mortgageCommonData.setIpAddress(httpRequest.getRemoteAddr());
		
		return mortgageCommonData;
	}
	
	public MortgageCommonData populateMortgageCommonData( MobileSession mobileSession ,ReqHeader req,  HttpServletRequest httpRequest )
	{
		MortgageCommonData mortgageCommonData = new MortgageCommonData();
		MortgageSessionInfo mortgageSessionInfo = mobileSession.getMortgageSessionInfo() ;	
		mortgageCommonData.setApplicationNumber(mortgageSessionInfo.getApplicationNumber());
		mortgageCommonData.setDeviceType(req.getDeviceType());		
		
		mortgageCommonData.setOrigin(getGDWOrigin(req,mortgageSessionInfo.getOrigin()) );
		mortgageCommonData.setSessionId(mobileSession.getSessionID());
		mortgageCommonData.setUserAgent(httpRequest.getHeader("User-Agent"));
		
		String tempOrigin = mobileSession.getOrigin();
		if ( tempOrigin.length() > 3 )
		{
			tempOrigin = tempOrigin.substring(1);
		}
		mortgageCommonData.setIpAddress(MBAppHelper.resolveIPAddress(httpRequest, tempOrigin));
		if ( ! MBAppHelper.isValidIPAddress ( mortgageCommonData.getIpAddress() ) )
		{
			Logger.info("Invalid IP Address : " + mortgageCommonData.getIpAddress() ,this.getClass());
			mortgageCommonData.setIpAddress("0.0.0.0");
		}
		mortgageCommonData.setIpAddress(httpRequest.getRemoteAddr());
		
		return mortgageCommonData;
	}
	
	public String getGDWOrigin(ReqHeader req, String origin)
	{
		StringBuffer tempOrigin = new StringBuffer();
		if ( origin != null && origin.length() > 3 )
			origin  = origin.substring(1);
		else
		{
			Logger.error("NULL Origin. " + origin, this.getClass());
			origin  = "STG";
		}
		if ( req.getDeviceType() != null && req.getDeviceType().toUpperCase().startsWith(LogonHelper.DEVICE_TYPE_TABLET) )
		{
			tempOrigin.append("T");
			tempOrigin.append(origin);
		}
		else if ( req.getDeviceType() != null && req.getDeviceType().toUpperCase().startsWith(LogonHelper.DEVICE_TYPE_MOBILE) )
		{
			tempOrigin.append("M");
			tempOrigin.append(origin);
		}

		else
		{
			tempOrigin.append(origin);
		}
		return tempOrigin.toString();
	}
	
	public String hashSensitiveData(String data){
		  if(!StringMethods.isEmptyString(data)){
			  Logger.info("Masking sensitive data : ", this.getClass() );
			  data = data.replaceAll(MASK_EMAIL , "****");
			  data = data.replaceAll(MASK_DATEOFBIRTH , "****");
			  data = data.replaceAll(MASK_MOBILENUMBER , "****");
		  }
		return data;
	}
	
	public IMBResp populateLogonResponse( Customer customer, MortgageSessionInfo mortgageSessionInfo, MortgageLogonReq req, MortgageCommonData mortgageCommonData) throws BusinessException {
		
		MortgageLogonResp mortgageLogonResp = new MortgageLogonResp();
		ContactDetail contactDetail = customer.getContactDetail();
		try{
			if(mortgageService.isCustomerEligible(customer) && mortgageService.isValidCustomerContactDetail(contactDetail))
			{			
				PersonalDetailResp personalDetailResp = new PersonalDetailResp();
				personalDetailResp.setFirstName(customer.getFirstName());
				//TODO for other, middle and tax
				personalDetailResp.setSurName(customer.getLastName());
				personalDetailResp.setMobile(maskPhoneNumber(contactDetail.getMobileNumber().getDisplayPhoneNumber()));
				personalDetailResp.setEmail(contactDetail.getEmail());
				
				if(contactDetail != null){
					if(contactDetail.getResidentialAddress() != null){
						AddressResp addressResp = new AddressResp();
						addressResp.setLine1(contactDetail.getResidentialAddress().getLine1());
						addressResp.setLine2(contactDetail.getResidentialAddress().getLine2());
						addressResp.setLine3(contactDetail.getResidentialAddress().getLine3());
						addressResp.setPostCode(contactDetail.getResidentialAddress().getPostZipcode());
						addressResp.setState(contactDetail.getResidentialAddress().getState());
						addressResp.setSuburb(contactDetail.getResidentialAddress().getSuburb());						
						personalDetailResp.setAddress(addressResp);
					}
				}				
				Application application = new Application();
				application.setApplicants(new ArrayList<Applicant>(2));
				Applicant primary = new Applicant();
				primary.setGcisNum(customer.getGcis());
				mortgageSessionInfo.setLoggedOnGCISNumber(customer.getGcis()); // For DocUpload GCIS
				primary.setGhscisNumber(customer.getGHSCISNumber());
				primary.setNtbInd(Boolean.FALSE);
				application.getApplicants().add(primary);
				
				mortgageSessionInfo.setApplication(application);			
				mortgageLogonResp.setPersonalDetailResp(personalDetailResp);
				mortgageLogonResp.setSuccess(MortgageUtil.LOGON_SUCCESS);
				mortgageLogonResp.setBusinessCustomer(false);
			}
			else{
				mortgageLogonResp.setSuccess(MortgageUtil.LOGON_INELIGIBLE);
			}
		} catch (BusinessException e){	
			if(e.getKey()==BusinessException.DIGITAL_MORTGAGE_CLAS_GETCUSTOMER_INELIGIBILE_MOBILE_AND_EMAIL_MISSING) {
				mortgageLogonResp.setSuccess(MortgageUtil.LOGON_ERROR_CONTACT_DETAILS);
				return mortgageLogonResp;
			}
			if(e.getKey()==BusinessException.DIGITAL_MORTGAGE_CLAS_GETCUSTOMER_INELIGIBILE_MOBILE_MISSING) {
				mortgageLogonResp.setSuccess(MortgageUtil.LOGON_ERROR_MOBILE);
				return mortgageLogonResp;
			}
			if(e.getKey()==BusinessException.DIGITAL_MORTGAGE_CLAS_GETCUSTOMER_INELIGIBILE_EMAIL_MISSING) {
				mortgageLogonResp.setSuccess(MortgageUtil.LOGON_ERROR_EMAIL);
				return mortgageLogonResp;
			}			
			if(e.getKey()==BusinessException.DIGITAL_MORTGAGE_CLAS_GETCUSTOMER_INELIGIBILE_BUSINESS) {
				mortgageLogonResp.setSuccess(MortgageUtil.LOGON_INELIGIBLE);
				mortgageLogonResp.setBusinessCustomer(true);
				return mortgageLogonResp;
			}
			throw e;
		}
		return mortgageLogonResp;
	}
	
	public IMBResp populateSecondaryLogonResponse(Customer customer, MortgageSessionInfo mortgageSessionInfo, MortgageLogonReq req, MobileSession mobileSession, MortgageCommonData mortgageCommonData, IBankCommonData ibankCommonData, ReqHeader reqHeader) throws BusinessException {
			
			MortgageLogonResp mortgageLogonResp = new MortgageLogonResp();
			ContactDetail contactDetail = customer.getContactDetail();
			try{
				if(mortgageService.isCustomerEligible(customer) && mortgageService.isValidCustomerContactDetail(contactDetail))
				{			
									
					Application application = mortgageSessionInfo.getApplication();			
					Applicant secondary = new Applicant();
					secondary.setGcisNum(customer.getGcis());
					secondary.setGhscisNumber(customer.getGHSCISNumber());
					secondary.setNtbInd(Boolean.FALSE);
					application.getApplicants().add(secondary);
					mortgageSessionInfo.setApplication(application);	
					
					ApplicationResp applicationResp = saveExistingCustomerApplication(req.getApplicationInfo(), mobileSession, mortgageCommonData, ibankCommonData, reqHeader);
					
					mortgageLogonResp.setApp(applicationResp.getApp());
					mortgageLogonResp.setSuccess(MortgageUtil.LOGON_SUCCESS);
				}
				else{

					if(mortgageSessionInfo != null && mortgageSessionInfo.getApplication().getApplicants().size() > 1){
						mortgageSessionInfo.getApplication().getApplicants().remove(1);//Remove the second applicant
					}
					mortgageLogonResp.setSuccess(MortgageUtil.LOGON_INELIGIBLE);
					if((null!=customer.getCustTypeInd() && customer.getCustTypeInd().equalsIgnoreCase(IBankParams.BUSINESS_CUSTOMER)) || customer.isCHSCustomer()){
						mortgageLogonResp.setBusinessCustomer(true);
					}
					else{
						mortgageLogonResp.setBusinessCustomer(false);
					}
				}
			} catch (BusinessException e){	
				if(mortgageSessionInfo != null && mortgageSessionInfo.getApplication().getApplicants().size() > 1){
					mortgageSessionInfo.getApplication().getApplicants().remove(1);//Remove the second applicant
				}
				if(e.getKey()==BusinessException.DIGITAL_MORTGAGE_CLAS_GETCUSTOMER_INELIGIBILE_HARDSTOP) {
					mortgageLogonResp.setSuccess(MortgageUtil.LOGON_INELIGIBLE);
					mortgageLogonResp.setBusinessCustomer(false);
					return mortgageLogonResp;
				}
				if(e.getKey()==BusinessException.DIGITAL_MORTGAGE_CLAS_GETCUSTOMER_INELIGIBILE_MOBILE_AND_EMAIL_MISSING) {
					mortgageLogonResp.setSuccess(MortgageUtil.LOGON_ERROR_CONTACT_DETAILS);
					return mortgageLogonResp;
				}
				if(e.getKey()==BusinessException.DIGITAL_MORTGAGE_CLAS_GETCUSTOMER_INELIGIBILE_MOBILE_MISSING) {
					mortgageLogonResp.setSuccess(MortgageUtil.LOGON_ERROR_MOBILE);
					return mortgageLogonResp;
				}
				if(e.getKey()==BusinessException.DIGITAL_MORTGAGE_CLAS_GETCUSTOMER_INELIGIBILE_EMAIL_MISSING) {
					mortgageLogonResp.setSuccess(MortgageUtil.LOGON_ERROR_EMAIL);
					return mortgageLogonResp;
				}
				if(e.getKey()==BusinessException.MORTGAGE_MAX_APPLICATION_REACHED) {
					throw new BusinessException(BusinessException.MORTGAGE_MAX_APPLICATION_REACHED);
				}
				if(e.getKey()==BusinessException.DIGITAL_MORTGAGE_CLAS_GETCUSTOMER_INELIGIBILE_BUSINESS) {
					mortgageLogonResp.setSuccess(MortgageUtil.LOGON_INELIGIBLE);
					mortgageLogonResp.setBusinessCustomer(true);
					return mortgageLogonResp;
				}
				if(e.getKey()==BusinessException.DIGITAL_MORTGAGE_CLAS_GETCUSTOMER_INELIGIBILE_BANKRUPT_DECEASED) {
					mortgageLogonResp.setSuccess(MortgageUtil.LOGON_INELIGIBLE);
					return mortgageLogonResp;
				}
				throw e;
			}			
			return mortgageLogonResp;
		}
	
	public ApplicationResp saveExistingCustomerApplication(ApplicationInfo applicationInfo, MobileSession mobileSession, MortgageCommonData mortgageCommonData, IBankCommonData ibankCommonData, ReqHeader reqHeader) throws BusinessException {
		MortgageSessionInfo mortgageSessionInfo = mobileSession.getMortgageSessionInfo();

		List<Applicant> applicants = mortgageSessionInfo.getApplication().getApplicants();	
			
		Application applicationCLAS = mortgageService.getCustomerCLASInfo(applicants, mortgageCommonData);  
	    
	    mortgageSessionInfo.setApplication(applicationCLAS);
	    
        Application applicationVO = populateAppicationVO(applicationInfo, mobileSession, ibankCommonData, null);      
         
        mortgageService.mapCLASInfoForSave(applicationVO, applicationCLAS);
        
	    if(IBankParams.isSwitchOn(mortgageCommonData.getOrigin(), IBankParams.MORTGAGE_CREDIT_DECISONING_SWITCH)){
	    	mortgageService.getForeignTaxInfo(applicationVO, ibankCommonData);
	    }
        
        if(applicationVO.getApplicants().size() > 1 && !applicationVO.getApplicants().get(0).getNtbInd() && applicationVO.getApplicants().get(1).getNtbInd())//ETB-NTB 
        {
	        /*
	         * Limit the number of application per e-mail address 
	         * */
	        String emailAddress = applicationVO.getApplicants().get(0).getEmailAddress();
	        mortgageService.getMaxApplicationLimitReached(emailAddress, ibankCommonData.getOrigin());
        }
        
        LoanApplicationReferenceVO referenceRes =mortgageService.getReferenceNumber(applicationVO, mortgageCommonData, ibankCommonData);  
        mortgageSessionInfo.setApplicationNumber(referenceRes.getApplicationNum());
        mortgageCommonData.setApplicationNumber(applicationVO.getApplicationNum());
        
        //Update Session Application object for subsequent save 
        if(referenceRes != null && referenceRes.getApplicationNum() != null) {
            Application applicationVOForSession = mortgageService.getApplication(referenceRes.getApplicationNum());
            mobileSession.setHomeLoanApplication(applicationVOForSession);
            
            //Set the request transaction number from UI on session
            if(reqHeader != null && !StringUtils.isEmpty(reqHeader.getTranSeqnbr())) {
                mobileSession.setHomeLoanApplicationTransactionNum(reqHeader.getTranSeqnbr());
            }

            //Remove LenderId(s) from Session once reference number is generated
            removeLenderIdFromSession(mobileSession);
        }
        
        //Updating the preference table CCLoanIND column 
        List<Applicant> applicantList=mortgageSessionInfo.getApplication().getApplicants();
        
        for(Applicant applicant: applicantList){
        	mortgageService.updatePrefForGhostTileDisplay(applicant.getGcisNum(), "Mortgage");
        }
       
        mortgageService.mergeCLASInfoForRetrieve(applicationVO, applicationCLAS, mortgageParams.getBaseOriginCode(mortgageCommonData.getOrigin()), false);
      
        
        ApplicationResp applicationResp = new ApplicationResp();      
        ApplicationInfo appInfo = populateApplicationInfo(applicationVO);
        		
        applicationResp.setApp(appInfo);
        applicationResp.setSuccess(true);
   
        return applicationResp;
	}
	
	
	
	
	public void prePopulateApplicationVO(ApplicationInfo app, Application applicationCLAS) throws BusinessException {
		
		if(app.getLiabilities() != null && !app.getLiabilities().isEmpty()){
			List<LiabilityInfo> liabilityList = new ArrayList<LiabilityInfo>();
			for(LiabilityInfo liability:app.getLiabilities()){
				if(StringMethods.isEmptyString(liability.getAccountNumber())){
					liabilityList.add(liability);
				}
			}
			app.setLiabilities(liabilityList);
		}
		
		if(app.getAssets() != null && !app.getAssets().isEmpty()){
			List<AssetInfo> assetList = new ArrayList<AssetInfo>();
			for(AssetInfo asset:app.getAssets()){
				if(StringMethods.isEmptyString(asset.getClasAssetId()) || MortgageUtil.AssetTypeEnum.RealEstate.toString().equalsIgnoreCase(asset.getAssetType())){
					assetList.add(asset);
				}
			}
			app.setAssets(assetList);
		}
	}
	
	private static String maskPhoneNumber(String phoneNumber)
	{
		String phoneNo = "";
		if (!StringMethods.isEmptyString(phoneNumber))
		{
			int len = phoneNumber.length();
			if (len > 4)
			{
				for (int i = 0; i < len - 4; i++)
				{
					phoneNo = phoneNo + "#";
				}

				phoneNo = phoneNo + phoneNumber.substring(len - 4);

			}
		}
		return phoneNo;
	}	
	
	public IMBResp populateMortgageErrorResponse(String origin, BusinessException e, HttpServletRequest httpServletRequest){
		String tempOrigin = mortgageParams.getBaseOriginCode(origin);
		LabelValueVO brandPhone = mortgageRefDataHelper.getDMCodesData(tempOrigin, MortgageUtil.REF_DATA_CATEGORY_HELP_DESK, tempOrigin);
		String[] values = { brandPhone.getLabel() };
		Logger.info("Brand Contact Number returned from DM origins :" + brandPhone.getLabel(), this.getClass());
		return MBAppUtils.createErrorResp(origin, e, values, ServiceConstants.MORTGAGE_SERVICE, httpServletRequest);	
	}
	
	public IGenericSession createSession(  HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse ) throws BusinessException{
		IGenericSession genericSession = null ;
		try
	{
			User myUser = new User(); 		
			myUser.setAttribute(IBankParams.USEROBJ_IPADDRESS, httpServletRequest.getRemoteAddr());
		    String origin = logonHelper.resolveOrigin(httpServletRequest);
			try{
				genericSession = logonHelper.createCompassSession(myUser, origin, "WebSrv", httpServletRequest, MBAppHelper.DM_SESSION_PREFIX);			
				//genericSession.setAttribute(MobileSessionImpl.CUSTOMER_OBLECT, commonData.getCustomer());
				genericSession.setAttribute(MobileSessionImpl.ORIGIN_OBLECT, origin);	
				//genericSession.setLoggedonState(LogonHelper.LOGGEDON_STATE_ONLINE_REGISTRATION);
				
				//Set initial/default home loan transaction number
				//19e3 : changed cookie path to /
				genericSession.setAttribute(MobileSessionImpl.HOMELOAN_APPLICATION_TRANSACTION_NUM, "-1");
				httpServletResponse.setHeader("Set-Cookie", MBAppConstants.SMPL_SESS_CONSTANT + "=" + genericSession.getId()   + "; HttpOnly ; Secure    " + "; path=/");
				Logger.info( "*** DM SessionId: " + genericSession.getId() +  "Set-Cookie :"+ MBAppConstants.SMPL_SESS_CONSTANT + "=" + genericSession.getId()   + "; HttpOnly ; Secure    " + "; path=/", this.getClass());

			} catch (Exception e){
				Logger.error("Exception Inside createSession() ", e, this.getClass());
				throw new BusinessException(BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE);
			} finally {
				//if ( genericSession != null )
					//genericSession.updateSession();				
			}
		}
		catch (Exception e )
		{
			Logger.error("Error in session ", e, this.getClass());
		}
		return genericSession;
	}
	
	public void validateSecondaryApplicatLogin(MortgageSessionInfo mortgageSessionInfo, User user) throws BusinessException{
		if(mortgageSessionInfo == null || mortgageSessionInfo.getApplicationNumber() != null ||
				mortgageSessionInfo.getApplication().getApplicants().size() > 1)
		{
			throw new BusinessException(BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE);
		}
		
		if(mortgageSessionInfo.getApplication().getApplicants().get(0).getGcisNum().equals(user.getGCISNumber())){
			throw new BusinessException(BusinessException.DIGITAL_MORTGAGE_SAME_CUSTOMER_LOGIN);
		}
	}
	
	public Long populateAssetDatabaseID(AssetInfo assetInfo ,  MobileSession mobileSession ) {
		Long assetId = null;
		Application application = mobileSession.getHomeLoanApplication();
		if(null != application && application.getAssets() != null ){
			List<Asset> assets = application.getAssets() ;
			for( Asset asset : assets){
				if (assetInfo.getIndex() == asset.getIndex()) {
					assetId = asset.getAssetId();
					Logger.debug("Index : " + assetInfo.getIndex() +   " Asset ID "+ assetId , this.getClass());
					break;
				}
			}
		}		
		
	  return assetId;
	}
	
	public Long populateLiabilityDatabaseID(LiabilityInfo liabilityInfo ,  MobileSession mobileSession ) {
		Long liabilityId = null;
		Application application = mobileSession.getHomeLoanApplication();
		if(null != application && application.getLiabilities() != null ){
			List<Liability> liabilities = application.getLiabilities() ;
			for( Liability liability : liabilities){
				if (liabilityInfo.getIndex() != null && liability.getIndex() != null && liabilityInfo.getIndex().intValue() == liability.getIndex().intValue()) {
					liabilityId = liability.getLiabilityId();
					Logger.debug("Index : " + liabilityInfo.getIndex() +   " Liability ID "+ liabilityId , this.getClass());
					break;
				}
			}
		}		
	  return liabilityId;
	}
	
	public Long populateExpenseDatabaseID(ExpenseInfo expenseInfo ,  MobileSession mobileSession ) {
		Long expenseId = null;
		Application application = mobileSession.getHomeLoanApplication();
		if(null != application && application.getExpenses() != null ){
			List<Expense> expenses = application.getExpenses() ;
			for( Expense expense : expenses){
				if (expenseInfo.getIndex() == expense.getIndex()) {
					expenseId = expense.getExpenseId();
					Logger.debug("Index : " + expenseInfo.getIndex() +   " Expense ID "+ expenseId , this.getClass());
					break;
				}
			}
		}		
	  return expenseId;
	}
	
	public LoanType populateLoanTypeDatabaseID(LoanType loanType,  MobileSession mobileSession ) {
		Application application = mobileSession.getHomeLoanApplication();
		if(null != application && application.getLoanType() != null && loanType != null){
			LoanType sessionLoanType = application.getLoanType();
			loanType.setPurchasePropertyRentalIncomeId(sessionLoanType.getPurchasePropertyRentalIncomeId());
			loanType.setPurchasePropertyRentalApplicantIncomeId(sessionLoanType.getPurchasePropertyRentalApplicantIncomeId());
			loanType.setPurchasePropertyId(sessionLoanType.getPurchasePropertyId());
			loanType.setProductDetailsId(sessionLoanType.getProductDetailsId());
			if(loanType.getPurchaseProperty() != null && sessionLoanType.getPurchaseProperty() != null) {
				loanType.getPurchaseProperty().setPropertyId(sessionLoanType.getPurchaseProperty().getPropertyId());
				loanType.getPurchaseProperty().setPropInsightValuationInfoId(sessionLoanType.getPurchaseProperty().getPropInsightValuationInfoId());
				
				//ValOrder related attributes are set from Session
				loanType.getPurchaseProperty().setValExpiryDate(sessionLoanType.getPurchaseProperty().getValExpiryDate());
				loanType.getPurchaseProperty().setValOrderDate(sessionLoanType.getPurchaseProperty().getValOrderDate());
				loanType.getPurchaseProperty().setValStatus(sessionLoanType.getPurchaseProperty().getValStatus());
				loanType.getPurchaseProperty().setValType(sessionLoanType.getPurchaseProperty().getValType());
				loanType.getPurchaseProperty().setValVMSReference(sessionLoanType.getPurchaseProperty().getValVMSReference());
				loanType.getPurchaseProperty().setSdrFoundInd(sessionLoanType.getPurchaseProperty().getSdrFoundInd());
			}
			if(loanType.getPurchaseProperty() != null && loanType.getPurchaseProperty().getAddress() != null && sessionLoanType.getPurchaseProperty() != null && sessionLoanType.getPurchaseProperty().getAddress() != null) {
				loanType.getPurchaseProperty().getAddress().setAddressId(sessionLoanType.getPurchaseProperty().getAddress().getAddressId());
				loanType.getPurchaseProperty().setAddressId(sessionLoanType.getPurchaseProperty().getAddress().getAddressId());
			}
			
		}		
	  return loanType;
	}
	

	public Income populateIncomeDatabaseID(IncomeInfo incomeInfo , ApplicantInfo applicantInfo, Income income, MobileSession mobileSession ) {
		Long incomeId = null;
		Application application = mobileSession.getHomeLoanApplication();

		if(null != application &&  application.getApplicants() != null && applicantInfo != null){
			for (Applicant applicant : application.getApplicants()) {
				if(applicantInfo.getIndex() == applicant.getIndex()) {
					if(applicant.getIncomes() != null) {
						List<Income> incomes = applicant.getIncomes() ;
						for( Income sessionIncome : incomes){
							if ( incomeInfo.getIndex() ==  sessionIncome.getIndex() )
							{
								incomeId = sessionIncome.getIncomeId();
								income.setIncomeId(incomeId);
								income.setApplicantIncomeId(sessionIncome.getApplicantIncomeId());
								income.setAssetId(sessionIncome.getAssetId());
								income.setPropertyId(sessionIncome.getPropertyId());
								Logger.debug("Index : " + incomeInfo.getIndex() +   " Income ID "+ incomeId , this.getClass());
								break;
							}
						}
					}
				}
			}
		}		
	  return income;
	}

	public Applicant populateApplicantDatabaseID(ApplicantInfo applicantInfo ,  Applicant applicant, MobileSession mobileSession ) {
		Long applicantId = null;
		Application application = mobileSession.getHomeLoanApplication();
		if(null != application && application.getApplicants() != null ){
			List<Applicant> sessionApplicants = application.getApplicants() ;
			for( Applicant sessionApplicant : sessionApplicants){
				if (applicantInfo.getIndex() == sessionApplicant.getIndex()) {
					applicantId = sessionApplicant.getApplicantId();
					applicant.setApplicantAddressId(sessionApplicant.getApplicantAddressId());
					
					if(applicantInfo.getAddress() != null && applicant.getAddress() != null && sessionApplicant.getAddress() != null) {
						applicant.getAddress().setAddressId(sessionApplicant.getAddress().getAddressId());
						applicant.getAddress().setApplicantAddressId(sessionApplicant.getAddress().getApplicantAddressId());
						applicant.setApplicantAddressId(sessionApplicant.getAddress().getApplicantAddressId());
					}
					applicant.setApplicantId(applicantId);
					
					Logger.debug("Index : " + applicantInfo.getIndex() +   " Applicant ID "+ applicantId , this.getClass());
					break;
				}
			}
		}		
	  return applicant;
	}
	
	public Property populatePropertyDatabaseID(PropertyInfo propertyInfo , Property property,  MobileSession mobileSession ) {
		Long propertyId = null;
		Application application = mobileSession.getHomeLoanApplication();
		if(null != application && application.getProperties() != null ){
			List<Property> properties = application.getProperties() ;
			for( Property sessionProperty : properties){
				if (propertyInfo.getIndex() == sessionProperty.getIndex()) {
					propertyId = sessionProperty.getPropertyId();
					property.setPropertyId(propertyId);
					property.setAddressId(sessionProperty.getAddressId());
					if(property.getAddress() != null) {
						property.getAddress().setAddressId(sessionProperty.getAddressId());
					}
					property.setPropInsightValuationInfoId(sessionProperty.getPropInsightValuationInfoId());
					
					//ValOrder related attributes are set from Session
					property.setValExpiryDate(sessionProperty.getValExpiryDate());
					property.setValOrderDate(sessionProperty.getValOrderDate());
					property.setValStatus(sessionProperty.getValStatus());
					property.setValType(sessionProperty.getValType());
					property.setValVMSReference(sessionProperty.getValVMSReference());
					property.setSdrFoundInd(sessionProperty.getSdrFoundInd());
					
					
					Logger.debug("Index : " + propertyInfo.getIndex() +   " Property ID "+ propertyId , this.getClass());
					break;
				}
			}
		}		
	  return property;
	}
	
	private void updateApplicantIncomeInSession(List<Income> updatedIncomes, List<Income> masterIncomes) {
		if(updatedIncomes != null && masterIncomes != null) {
			for(Income updatedIncome : updatedIncomes) {
				for(Income masterIncome : masterIncomes) {
					if(updatedIncome.getIndex() == masterIncome.getIndex()) {
						if(masterIncome.getIncomeId() == null) {
							masterIncome.setIncomeId(updatedIncome.getIncomeId());
							masterIncome.setApplicantIncomeId(updatedIncome.getApplicantIncomeId());
							masterIncome.setAssetId(updatedIncome.getAssetId());
							masterIncome.setPropertyId(updatedIncome.getPropertyId());
						}
					}
				}
			}
		}
	}
	
	public void updateApplicationInSession( Application updatedApplication , Application masterApplication , MobileSession mobileSession )
	{
		masterApplication.setApplicationNum(updatedApplication.getApplicationNum());
		masterApplication.setLmiInd(updatedApplication.getLmiInd());
		masterApplication.setLeadPriority(updatedApplication.getLeadPriority());
		masterApplication.setLeadSentDate(updatedApplication.getLeadSentDate());
		masterApplication.setLeadSentInd(updatedApplication.getLeadSentInd());
		
		//LoanType
		LoanType masterLoanType = masterApplication.getLoanType();
		LoanType updatedLoanType = updatedApplication.getLoanType();
		
		if(masterLoanType.getProductDetailsId() == null) {
			masterLoanType.setProductDetailsId(updatedLoanType.getProductDetailsId());
		}
		
		//Purchase Property
		if(masterLoanType.getPurchaseProperty() != null && updatedLoanType.getPurchaseProperty() != null) {
			
			if(masterLoanType.getPurchasePropertyId() == null) {
				masterLoanType.setPurchasePropertyId(updatedLoanType.getPurchasePropertyId());
				masterLoanType.getPurchaseProperty().setPropertyId(updatedLoanType.getPurchaseProperty().getPropertyId());
			}
			
			if(masterLoanType.getPurchaseProperty().getPropInsightValuationInfoId() == null) {
				masterLoanType.getPurchaseProperty().setPropInsightValuationInfoId(updatedLoanType.getPurchaseProperty().getPropInsightValuationInfoId());
			}
			if(masterLoanType.getPurchaseProperty().getAddress() != null && updatedLoanType.getPurchaseProperty().getAddress() != null) {
				if(masterLoanType.getPurchaseProperty().getAddress().getAddressId() == null) {
					masterLoanType.getPurchaseProperty().getAddress().setAddressId(updatedLoanType.getPurchaseProperty().getAddress().getAddressId());
					masterLoanType.getPurchaseProperty().setAddressId(updatedLoanType.getPurchaseProperty().getAddress().getAddressId());
				}
			}
		} else {
			masterLoanType.setPurchasePropertyId(null);
		}
		
		//Investment - Rental Income - Add
		if(masterLoanType.getPurchasePropertyRentalApplicantIncomeId() == null) {
			masterLoanType.setPurchasePropertyRentalApplicantIncomeId(updatedLoanType.getPurchasePropertyRentalApplicantIncomeId());
		}
		if(masterLoanType.getPurchasePropertyRentalIncomeId() == null) {
			masterLoanType.setPurchasePropertyRentalIncomeId(updatedLoanType.getPurchasePropertyRentalIncomeId());
		}
		
		//Investment - Rental Income - Delete
		if(updatedLoanType.getPurchasePropertyRentalIncomeId() == null) {
			masterLoanType.setPurchasePropertyRentalIncomeId(null);
		}
		if(updatedLoanType.getPurchasePropertyRentalApplicantIncomeId() == null) {
			masterLoanType.setPurchasePropertyRentalApplicantIncomeId(null);
		}
		
		//Incomes, Applicant Address
		List<Applicant> masterApplicnats = masterApplication.getApplicants();
		List<Applicant> updatedApplicnats = updatedApplication.getApplicants();
		if(masterApplicnats != null && updatedApplicnats != null) {
			for (Applicant updatedApplicant : updatedApplicnats) {
				for (Applicant masterApplicant : masterApplicnats) {
					if (masterApplicant.getIndex() == updatedApplicant.getIndex()) {
						masterApplicant.setApplicantAddressId(updatedApplicant.getApplicantAddressId());
						if(updatedApplicant.getAddress() != null && masterApplicant.getAddress() != null) {
							if(masterApplicant.getAddress().getAddressId() == null) {
								masterApplicant.getAddress().setAddressId(updatedApplicant.getAddress().getAddressId());
								masterApplicant.getAddress().setApplicantAddressId(updatedApplicant.getAddress().getApplicantAddressId());
								masterApplicant.setApplicantAddressId(updatedApplicant.getAddress().getApplicantAddressId());
							}
						}
						updateApplicantIncomeInSession(updatedApplicant.getIncomes(), masterApplicant.getIncomes());
						break;
					}
				}
			}
		}
		
		//Liabilities
		List<Liability> updatedLiabilityList = updatedApplication.getLiabilities();
		if(updatedLiabilityList != null && masterApplication.getLiabilities() != null) {
			 for ( Liability  liability :  updatedLiabilityList ){
				 for ( Liability  masterLiability :  masterApplication.getLiabilities() ){
					  if ( masterLiability.getIndex() != null && liability.getIndex() != null && masterLiability.getIndex().intValue() == liability.getIndex().intValue() ){
					  	if ( masterLiability.getLiabilityId() == null ){
						  	masterLiability.setLiabilityId(liability.getLiabilityId());
						  	masterLiability.setPropertyID(liability.getPropertyID());
						  	break;
					  	}
					  }
				 }
			 }
		}
		 
		//Assets
		List<Asset> updatedAssetList = updatedApplication.getAssets();
		if(updatedAssetList != null && masterApplication.getAssets() != null) {
			for (Asset asset : updatedAssetList) {
				for (Asset masterAsset : masterApplication.getAssets()) {
					if (masterAsset.getIndex() == asset.getIndex()) {
						if (masterAsset.getAssetId() == null) {
						  	masterAsset.setAssetId(asset.getAssetId());
						  	masterAsset.setPropertyId(asset.getPropertyId());
						  	break;
					  	}
					  }
				 }
			 }
		}

		//Expenses
		List<Expense> updatedExpenseList = updatedApplication.getExpenses();
		if(updatedExpenseList != null && masterApplication.getExpenses() != null) {
			for (Expense expense : updatedExpenseList) {
				for (Expense masterExpense : masterApplication.getExpenses()) {
					if (masterExpense.getIndex() == expense.getIndex()) {
						if (masterExpense.getExpenseId() == null) {
						  	masterExpense.setExpenseId(expense.getExpenseId());
						  	break;
					  	}
					  }
				 }
			 }
		}

		//Properties
		List<Property> updatedPropertyList = updatedApplication.getProperties();
		if(updatedPropertyList != null && masterApplication.getProperties() != null) {
			for (Property property : updatedPropertyList) {
				for (Property masterProperty : masterApplication.getProperties()) {
					if (masterProperty.getIndex() == property.getIndex()) {
						if (masterProperty.getPropertyId() == null) {
						  	masterProperty.setPropertyId(property.getPropertyId());
					  		masterProperty.setAddressId(property.getAddressId());
						  	if(masterProperty.getAddress() != null) {
						  		masterProperty.getAddress().setAddressId(property.getAddressId());
						  	}
						  	break;
					  	}
					  }
				 }
			 }			 
		}
		 //Set the object in Session
		 mobileSession.setHomeLoanApplication(masterApplication);
	}

	private String getLoanoutcomeMessage(MobileSession mobileSession, LoanOutcome loanOutcome ){
		
		String outcomeMsg = null;
		if(loanOutcome.getSegmentUsed().equalsIgnoreCase(HomeLoanSegmentsEnum.SEGMENT2.getClasSegment()) || loanOutcome.getSegmentUsed().equalsIgnoreCase(HomeLoanSegmentsEnum.SEGMENT5.getClasSegment())){
			Logger.info("MortgageHelper - Happypath1. Segment " + loanOutcome.getSegmentUsed(), this.getClass());
			outcomeMsg = IBankParams.getErrorMessage(mortgageParams.getBaseOriginCode(mobileSession.getOrigin()), String.valueOf(BusinessException.OUTCOME_MSG_PURCHASE));
		}
		else if (loanOutcome.getSegmentUsed().equalsIgnoreCase(HomeLoanSegmentsEnum.SEGMENT6A.getClasSegment()) || loanOutcome.getSegmentUsed().equalsIgnoreCase(HomeLoanSegmentsEnum.SEGMENT6B.getClasSegment())){
			if(loanOutcome.getPropertyAddress() != null){
				Logger.info("MortgageHelper - Happypath1. Segment " + loanOutcome.getSegmentUsed(), this.getClass()); 
				outcomeMsg = IBankParams.getErrorMessage(mortgageParams.getBaseOriginCode(mobileSession.getOrigin()), String.valueOf(BusinessException.OUTCOME_MSG_PURCHASE)); 
			}
			else{
				Logger.info("MortgageHelper - Happypath1 with property. Segment " + loanOutcome.getSegmentUsed(), this.getClass());
				 outcomeMsg = null;//IBankParams.getErrorMessage(mortgageParams.getBaseOriginCode(mobileSession.getOrigin()), String.valueOf(BusinessException.OUTCOME_MSG_BORROWUPTO)); 
			}
		}
		else if (loanOutcome.getSegmentUsed().equalsIgnoreCase(HomeLoanSegmentsEnum.SEGMENT7A.getClasSegment()) || loanOutcome.getSegmentUsed().equalsIgnoreCase(HomeLoanSegmentsEnum.SEGMENT7B.getClasSegment())){
			 if(loanOutcome.getPropertyAddress() != null){
				 Logger.info("MortgageHelper - Happypath1 without property. Segment " + loanOutcome.getSegmentUsed(), this.getClass());
				 outcomeMsg = IBankParams.getErrorMessage(mortgageParams.getBaseOriginCode(mobileSession.getOrigin()), String.valueOf(BusinessException.OUTCOME_MSG_PURCHASE)); 
			 }
			 else {
				 Logger.info("MortgageHelper - Happypath1 with property. Segment " + loanOutcome.getSegmentUsed(), this.getClass());
				 outcomeMsg = null;//IBankParams.getErrorMessage(mortgageParams.getBaseOriginCode(mobileSession.getOrigin()), String.valueOf(BusinessException.OUTCOME_MSG_BORROWUPTO)); 
			}
		}
		else if(loanOutcome.getSegmentUsed().equalsIgnoreCase(HomeLoanSegmentsEnum.SEGMENT9.getClasSegment())){
			 Logger.info("MortgageHelper - Happypath1. Segment " + loanOutcome.getSegmentUsed(), this.getClass());
			 outcomeMsg = IBankParams.getErrorMessage(mortgageParams.getBaseOriginCode(mobileSession.getOrigin()), String.valueOf(BusinessException.OUTCOME_MSG_REFINACE));
		}
		return outcomeMsg;
		
	}
	
	//////////////////////////////////////////////////////////////////////////////////////
	public String jsonString(Object obj)
	{
		try
		{
		  ObjectMapper mapper = new ObjectMapper();
		  String str = mapper.writeValueAsString(obj);
		  return str;
		}
		catch ( Exception e)
		{
			Logger.error("Unable to get JSON String " , e, this.getClass());
			return null;
		}
	}
	//////////////////////////////////////////////////////////////////////////////////////

	public void updateSessionApplicationWithPID(
			Application sessionHomeLoanApplication, int assetIndex,
			String stdAddrId) {

		MortgageAddress address = getAddressToUpdatePID(sessionHomeLoanApplication, assetIndex);
		address.setStdAddrId(stdAddrId);
		
	}
	
	public MortgageAddress getAddressToUpdatePID(
			Application sessionHomeLoanApplication, int assetIndex) {

		if(sessionHomeLoanApplication != null){
			if(sessionHomeLoanApplication.getAssets() != null){
				//Asset asset = sessionHomeLoanApplication.getAssets().get(assetIndex);
				Asset assetToUpdate = null;
				List<Asset> assetList = sessionHomeLoanApplication.getAssets();
				if(assetList !=null && !assetList.isEmpty()){
					for(Asset asset:assetList){
						if(asset.getIndex() == assetIndex){
							assetToUpdate = asset;
							break;
						}
					}
					int propIndex= assetToUpdate.getPropertyIndex();
					List<Property> properties = sessionHomeLoanApplication.getProperties();
					if(properties !=null && !properties.isEmpty()){
						Property property = properties.get(propIndex);
						if(property != null){
							if(property.getAddress() != null){
								return property.getAddress();
							}
							
						}
					}					
				}	
			}
		}
		return null;
		
	}
	
	//getAddressToUpdatePID basesd on Database Id search
	public MortgageAddress getAddressToUpdatePID(
			Application sessionHomeLoanApplication, List<Asset> clasAssetList, int assetIndex) {
		
		String dbClasAssetId = clasAssetList.get(assetIndex).getClasAssetId();

		if(sessionHomeLoanApplication != null){
			if(sessionHomeLoanApplication.getAssets() != null){
				//Asset asset = sessionHomeLoanApplication.getAssets().get(assetIndex);
				Asset assetToUpdate = null;
				List<Asset> assetList = sessionHomeLoanApplication.getAssets();
				if(assetList !=null && !assetList.isEmpty()){
					for(Asset asset:assetList){
						if(asset.getClasAssetId() == dbClasAssetId){
							assetToUpdate = asset;
							break;
						}
					}
					int propId= assetToUpdate.getPropertyId();
					Property propToUpdate = null;
					List<Property> properties = sessionHomeLoanApplication.getProperties();
					if(properties !=null && !properties.isEmpty()){
						//Property property = properties.get(propIndex);
						for(Property property:properties){
							if(property.getPropertyId() ==  propId){
								propToUpdate = property;
								break;
							}
						}
						if(propToUpdate != null){
							if(propToUpdate.getAddress() != null){
								return propToUpdate.getAddress();
							}
							
						}
					}					
				}
			}
		}
		return null;
		
	}
	
	//updateApplicationWithPIDForSave (for subsequent save)once PID is updated
		public void updateApplicationWithPIDForSave(
				Application sessionHomeLoanApplication, Application Application, 
				List<Asset> clasAssetList) {
			
			
			try{
			if(sessionHomeLoanApplication != null){
				if(sessionHomeLoanApplication.getAssets() != null){
					List<Asset> assetList = sessionHomeLoanApplication.getAssets();
					List<Property> properties = sessionHomeLoanApplication.getProperties();
					if(assetList !=null && !assetList.isEmpty() && properties != null && !properties.isEmpty()){
						for(Asset asset:assetList){
							if(asset.getClasAssetId() != null && asset.getPropertyIndex() != null
									&& MortgageUtil.AssetTypeEnum.RealEstate.toString().equals(asset.getAssetType())){
								Property property = getPropertyByIndex(sessionHomeLoanApplication, asset.getPropertyIndex());
								if(property.getAddress() != null){
									if(property.getAddress().getStdAddrId() != null){
										Property property2 = Application.getProperties().get(asset.getPropertyIndex());
										if(property2 != null){
											if(property2.getAddress() != null){
												property2.getAddress().setStdAddrId(property.getAddress().getStdAddrId());
											}
										}
									}
								}
								
							}
						}
					}
				}
			}
			}
			catch ( Exception e)
			{   
				Logger.info("========Error in updateApplicationWithPIDForSave. Used for PID changes." , e,  this.getClass());
			}
		}
		
		private Property getPropertyByIndex(Application app, int index)  {
			if(app.getProperties() != null && !app.getProperties().isEmpty()){
				for(Property prop:app.getProperties()){
					if(prop.getIndex() == index){
						return prop;
					}
				}
			}
			return null;
		}
		

		public String getHelpDeskContactNumber(String origin) {
    		MortgageParams mortgageParams = ServiceHelper.getBean("mortgageParams");
    		String baseOrigin = mortgageParams.getBaseOriginCode(origin);
    		String originHelpDeskPhone = null;
    		if(MortgageUtil.ORIGIN_SGB.equals(baseOrigin)) {
    			baseOrigin = MortgageUtil.ORIGIN_ALL;
    		}
    		List<LabelValueVO> labelValueVOList = mortgageParams.getDMCodesDataLabelValueVOList(baseOrigin,MortgageUtil.REF_DATA_CATEGORY_HELP_DESK);
    		if (labelValueVOList != null && !labelValueVOList.isEmpty()) {
    			for (LabelValueVO labelValueVO : labelValueVOList) {
    				if(labelValueVO.getValue().equals(baseOrigin)) {
    					originHelpDeskPhone = labelValueVO.getLabel();
    					break;
    				} 
    			}
    			if(originHelpDeskPhone == null) {
    				originHelpDeskPhone = labelValueVOList.get(0).getLabel();
    			}
    			
    		}
    		return originHelpDeskPhone;
    	}


		public List<String> getModifiedPropertyList(Application applicationVO, Application sessionApplicationVO) throws BusinessException 
		{
   		List<String> newLsit = null;

	   	try
	   	{
	   		ObjectMapper mapper = new ObjectMapper();
	   		Property appPurchaseProp =  applicationVO.getLoanType().getPurchaseProperty();
	   		Property sessPurchaseProp =  sessionApplicationVO.getLoanType().getPurchaseProperty();
	   		
	   		
	   		if ( appPurchaseProp != null  )
	   		{
	   			
	   			if ( sessPurchaseProp != null && appPurchaseProp.getIndex() == sessPurchaseProp.getIndex()  )
	   			{
	   		   		String appPurchasePropJson = MortgageUtil.getJSONString(mapper, appPurchaseProp);
	   		   		String sessPurchasePropJson = MortgageUtil.getJSONString(mapper, sessPurchaseProp);
	   		   		if ( ! appPurchasePropJson.equalsIgnoreCase(sessPurchasePropJson) || StringMethods.isEmptyString(sessPurchaseProp.getValStatus()) 
	   		   				|| sessPurchaseProp.getValStatus().equalsIgnoreCase(MortgageUtil.ValuationEnum.VAL_ORDER_ERROR.getValue()) )
	   		   		{
	   		   			newLsit = new ArrayList<String>();
	   		   			newLsit.add("pr"+appPurchaseProp.getIndex());
	   		   		}
	   			}
	   			else
	   			{
   		   			newLsit = new ArrayList<String>();
   		   			newLsit.add("pr"+appPurchaseProp.getIndex());
	   			}
	   			
	   		}
	   		
	   		List<Property> propertyList=  applicationVO.getProperties();
	   		List<Property> sessPropertyList=  sessionApplicationVO.getProperties();
	   		StringBuffer strLog = new StringBuffer();
	   		
	   		if ( propertyList == null )
	   			propertyList = new ArrayList<Property>();

	   		if ( sessPropertyList == null )
	   			sessPropertyList = new ArrayList<Property>();
	   		
	   		
	   			   		
	   		for ( Property appProperty : propertyList )
	   		{
	   			boolean isFound = false;
				  String appJson = MortgageUtil.getJSONString(mapper, appProperty);
	     		for ( Property sessProperty : sessPropertyList )
	     		{
		   			if ( sessProperty.getIndex() == appProperty.getIndex() )
		   			{
		   				
	   				  	String sessJson = MortgageUtil.getJSONString(mapper, sessProperty);
		   				  if ( sessJson.equalsIgnoreCase( appJson ))
		   				  {
		   				  	isFound = true;
		   				  	break;
		   				  }
		   				if ( sessPurchaseProp == null || StringMethods.isEmptyString(sessPurchaseProp.getValStatus()) || 
		   						sessPurchaseProp.getValStatus().equalsIgnoreCase(MortgageUtil.ValuationEnum.VAL_ORDER_ERROR.getValue()))
		   				{
		   				  	isFound = false;
		   				  	break;
		   				}

		   			}
		   			
	     		}
	     		if ( ! isFound )
	     		{
		   			if ( newLsit == null )
		   			{
		   			 newLsit = new ArrayList<String>();
		   			}
		   			strLog.append(appProperty.getIndex() +" ," );
		   			newLsit.add(appProperty.getIndex() +"");
	     		}
	   		}
	   		
				Logger.info("getModifiedPropList. List :  " + newLsit , this.getClass() ) ;
		}
		catch ( Exception e)
		{   
			Logger.info("========Error in Save Data:" , e,  this.getClass());
			throw new BusinessException(BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE);
		}

	   	return newLsit;
		}

		public boolean checkAppEligibleForValOder(Application sessionHomeloanApplication){
			
			boolean isPPValid = false;
			
			if(sessionHomeloanApplication != null){
				if(sessionHomeloanApplication.getLoanType().getPurchaseProperty() == null 
						&& !sessionHomeloanApplication.getLoanType().getLoanType().equalsIgnoreCase(MortgageUtil.LoanTypeEnum.REFINANCE.getType())){
					Logger.info("No Purchase Property or refinance :  " , this.getClass() ) ;
					return false;
				}
				
				if(sessionHomeloanApplication.getLoanType().getPurchaseProperty() != null)
				{
					isPPValid = isPurchasePropertyEligibleForValorder(sessionHomeloanApplication.getLoanType().getPurchaseProperty());
					if(!isPPValid){
						Logger.info("NoVal order for PP as PP is a unit or townhouse with no pid or manual address :  " , this.getClass() ) ;
						return false;
					}
					
					if(isPPValid && sessionHomeloanApplication.getLoanType().getPurchaseProperty().getValStatus()!= null &&
							sessionHomeloanApplication.getLoanType().getPurchaseProperty().getValStatus().equalsIgnoreCase(MortgageUtil.ValuationEnum.VAL_ASSESS_FAIL.getValue())){
						Logger.info("PP valorder status is failed :  " , this.getClass() ) ;
						return false;
					}
				}
				if(isPPValid || sessionHomeloanApplication.getLoanType().getLoanType().equalsIgnoreCase(MortgageUtil.LoanTypeEnum.REFINANCE.getType())){
					if(sessionHomeloanApplication.getProperties() != null && sessionHomeloanApplication.getProperties().size() > 0){
						for(Property prop : sessionHomeloanApplication.getProperties()){
							if(prop != null &&  prop.getUseAsSecInd()!= null && prop.getUseAsSecInd()){
								Asset asset = getAssetProperty(prop.getIndex(), sessionHomeloanApplication.getAssets());
								if(asset != null){
									if(asset.getAssetType()!= null && MortgageUtil.ASSET_TYPE_REAL_ESTATE.equals(asset.getAssetType())){
										if(prop.getValStatus()!= null && prop.getValStatus().equalsIgnoreCase(MortgageUtil.ValuationEnum.VAL_ASSESS_FAIL.getValue())){
											Logger.info("Realestate property valorder status is failed :  " , this.getClass() ) ;
											return false;
										}
									}
								}
							}
						}
					}
				}
				
			}
			return true;
		}
		
		public Asset getAssetProperty(Integer propIndex, List<Asset> assetList){
		
			if ( assetList != null  && assetList.size() > 0 )
			{
				for(Asset asset:assetList){
					if(asset!= null && asset.getAssetType()!= null && MortgageUtil.ASSET_TYPE_REAL_ESTATE.equals(asset.getAssetType())){
	
						if(propIndex != null && asset.getPropertyIndex().intValue() == propIndex){
							return asset;
						}
					}
				}
			}
			return null;
		}
	
		private boolean isPurchasePropertyEligibleForValorder(Property purchaeProperty){
			boolean hasEligibleforValorder = true;
			if(((MortgageUtil.PropertyTypeEnum.UNIT.getValue().equals(purchaeProperty.getPropertyType()) || 
					  MortgageUtil.PropertyTypeEnum.TOWNHOUSE.getValue().equals(purchaeProperty.getPropertyType())) && purchaeProperty.getAddress().getStdAddrId() == null)){
			
				hasEligibleforValorder = false;
			}
			
			return hasEligibleforValorder;
		}
	        
	public ErrorResp createErrorResp(String origin, BusinessException e, String serviceName, HttpServletRequest httpRequest) {
		return MBAppUtils.createErrorResp(origin, e.getKey(), getMessage(origin, e.getKey(), null), serviceName, httpRequest);
	}
	
	public String getMessage(String origin, int msgCode, Object[] values) {
		if ( StringMethods.isEmptyString(origin)  )
		{
			origin = "MSTG";
		}
		String msgString = IBankParams.getErrorMessage(origin, String.valueOf(msgCode));
		if (StringMethods.isEmptyString(msgString)) {
			msgString = IBankParams.getErrorMessage(origin, String.valueOf(BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE));
		} else if (values != null && values.length > 0) {
			msgString = MessageFormat.format(msgString, values);
			Logger.info("Origin: "+ origin + "Exception Message :"+msgString + "Replaced Value" + values, MBAppUtils.class);
		}
		return msgString;
	}
	
	private LoanAssessmentInfo populateMessages ( LoanAssessmentInfo loanAssessmentInfo, LoanOutcome loanOutcome, MobileSession mobileSession  )
	{
		boolean hasPurchasePriceAmt = false;
		loanAssessmentInfo.setShowPropertyPrice(true);

		if ( mobileSession.getHomeLoanApplication().getLoanType() != null )
		{
			hasPurchasePriceAmt = mobileSession.getHomeLoanApplication().getLoanType().getLoanAmt() != null ? true : false;
		}
		boolean hasCustReqLoanAmt = mobileSession.getHomeLoanApplication().getLoanType().getCustRequestedLoanAmt()!= null ?true : false;

		Logger.debug( " getCustRequestedLoanAmt : " + mobileSession.getHomeLoanApplication().getCustRequestedLoanAmt() + "  getPurchasePropertyIndicativeAmt : "+ hasCustReqLoanAmt   , this.getClass() );
		
		if (  ( loanOutcome.getSegmentUsed().equalsIgnoreCase(HomeLoanSegmentsEnum.SEGMENT6A.getClasSegment())
				|| loanOutcome.getSegmentUsed().equalsIgnoreCase(HomeLoanSegmentsEnum.SEGMENT6B.getClasSegment() ) )
				&& MortgageUtil.LoanOutcomeEnum.MAXPURCHASEPRICE_FAIL.toString().equalsIgnoreCase(loanOutcome.getMessage1())  )
		{
  		loanAssessmentInfo.setOutcomeMessage("This property looks a bit outside your budget, but here's what you could afford");
		  loanAssessmentInfo.setBorrowText("You're looking good to borrow up to");
			loanAssessmentInfo.setShowPropertyPrice(false);
		}
		else if ( ! hasPurchasePriceAmt && ! hasCustReqLoanAmt 
				&& ( loanOutcome.getSegmentUsed().equalsIgnoreCase(HomeLoanSegmentsEnum.SEGMENT6A.getClasSegment())
				|| loanOutcome.getSegmentUsed().equalsIgnoreCase(HomeLoanSegmentsEnum.SEGMENT6B.getClasSegment() ) ))
		{
			loanAssessmentInfo.setHeaderText("Great News!");
			//loanAssessmentInfo.setOutcomeMessage("");
			loanAssessmentInfo.setBorrowText("You're looking good to borrow up to");
		}
		else if ( ! hasPurchasePriceAmt &&  hasCustReqLoanAmt 
				&& ( loanOutcome.getSegmentUsed().equalsIgnoreCase(HomeLoanSegmentsEnum.SEGMENT7A.getClasSegment())
				|| loanOutcome.getSegmentUsed().equalsIgnoreCase(HomeLoanSegmentsEnum.SEGMENT7B.getClasSegment() ) ) )
		{
			loanAssessmentInfo.setHeaderText("Great News!");
			loanAssessmentInfo.setBorrowText("You're looking good to borrow");
		}
		else if ( ! hasPurchasePriceAmt &&  hasCustReqLoanAmt 
				&& ( loanOutcome.getSegmentUsed().equalsIgnoreCase(HomeLoanSegmentsEnum.SEGMENT6A.getClasSegment())
				|| loanOutcome.getSegmentUsed().equalsIgnoreCase(HomeLoanSegmentsEnum.SEGMENT6B.getClasSegment() )) )
		{
			loanAssessmentInfo.setBorrowText("You're looking good to borrow up to");
		}
		else if (  hasPurchasePriceAmt &&  hasCustReqLoanAmt && loanOutcome.getSegmentUsed().equalsIgnoreCase(HomeLoanSegmentsEnum.SEGMENT2.getClasSegment()))
		{
			loanAssessmentInfo.setHeaderText("Great News!");
  		loanAssessmentInfo.setOutcomeMessage("You're looking good to purchase this property");
		  loanAssessmentInfo.setBorrowText("You could borrow");
		}
		else if (  hasPurchasePriceAmt &&  hasCustReqLoanAmt && loanOutcome.getSegmentUsed().equalsIgnoreCase(HomeLoanSegmentsEnum.SEGMENT5.getClasSegment()))
		{
			loanAssessmentInfo.setHeaderText("Great News!");
  		loanAssessmentInfo.setOutcomeMessage("You're looking good to purchase this property");
		  loanAssessmentInfo.setBorrowText("You will need to borrow");
		}
		else if (  hasPurchasePriceAmt &&  ! hasCustReqLoanAmt && loanOutcome.getSegmentUsed().equalsIgnoreCase(HomeLoanSegmentsEnum.SEGMENT5.getClasSegment()))
		{
			loanAssessmentInfo.setHeaderText("Great News!");
  		loanAssessmentInfo.setOutcomeMessage("You're looking good to purchase this property");
		  loanAssessmentInfo.setBorrowText("You will need to borrow");
		}
		else if (  hasPurchasePriceAmt &&  hasCustReqLoanAmt 
				&& ( loanOutcome.getSegmentUsed().equalsIgnoreCase(HomeLoanSegmentsEnum.SEGMENT6A.getClasSegment())
				|| loanOutcome.getSegmentUsed().equalsIgnoreCase(HomeLoanSegmentsEnum.SEGMENT6B.getClasSegment() ) ))	{
			//loanAssessmentInfo.setHeaderText("Great News!");
  		loanAssessmentInfo.setOutcomeMessage("This property looks a bit outside your budget, but here's what you could afford");
		  loanAssessmentInfo.setBorrowText("You're looking good to borrow up to");
			loanAssessmentInfo.setShowPropertyPrice(false);
		}
		else if (  hasPurchasePriceAmt &&  ! hasCustReqLoanAmt 
				&& ( loanOutcome.getSegmentUsed().equalsIgnoreCase(HomeLoanSegmentsEnum.SEGMENT6A.getClasSegment())
				|| loanOutcome.getSegmentUsed().equalsIgnoreCase(HomeLoanSegmentsEnum.SEGMENT6B.getClasSegment() )) )	{
			//loanAssessmentInfo.setHeaderText("Great News!");
  		loanAssessmentInfo.setOutcomeMessage("This property looks a bit outside your budget, but here's what you could afford");
		  loanAssessmentInfo.setBorrowText("You're looking good to borrow up to");
			loanAssessmentInfo.setShowPropertyPrice(false);

		}
		else if ( loanOutcome.getSegmentUsed().equalsIgnoreCase(HomeLoanSegmentsEnum.SEGMENT9.getClasSegment()))
		{
			loanAssessmentInfo.setHeaderText("Great News!");
  		loanAssessmentInfo.setOutcomeMessage("You�re looking good to refinance with us");
		  loanAssessmentInfo.setBorrowText("Your new loan");
		}
		else
		{
			Logger.info( " ################ No Message set for hasPurchasePriceAmt : " + hasPurchasePriceAmt + "  hasCustReqLoanAmt : "+ hasCustReqLoanAmt + "  loanOutcome.getSegmentUsed() : " + loanOutcome.getSegmentUsed() , this.getClass() );
		}


		
		return loanAssessmentInfo;
	}
	
	
	public boolean isEligibleSegmentForValAssess(ArrayList<LoanOutcome> loanOutcomes){
		boolean isEligible = false;
		if(loanOutcomes != null && !loanOutcomes.isEmpty()){
			String segmentUsed = loanOutcomes.get(0).getSegmentUsed();
			if(!StringMethods.isEmptyString(segmentUsed)){
				segmentUsed = segmentUsed.toLowerCase();
				if(segmentUsed.equalsIgnoreCase(HomeLoanSegmentsEnum.SEGMENT6A.getClasSegment())
						|| segmentUsed.equalsIgnoreCase(HomeLoanSegmentsEnum.SEGMENT6B.getClasSegment())
						|| segmentUsed.equalsIgnoreCase(HomeLoanSegmentsEnum.SEGMENT7A.getClasSegment())
						|| segmentUsed.equalsIgnoreCase(HomeLoanSegmentsEnum.SEGMENT7B.getClasSegment())){
					isEligible = false;
				}
				else{
					isEligible = true;
				}
			}
			
		}
		
		
		return isEligible;
	}

    public HashMap<String,String> getModifiedListOfProperty( Application application)
    {

          HashMap<String,String> hash = new HashMap<String,String>();
          
          if ( application == null )
          {
                return hash;
          }
          
          if ( application.getLoanType() != null && application.getLoanType().getPurchaseProperty() != null )
          {
                Property puchaseProp = application.getLoanType().getPurchaseProperty();
                String puchaseStr = getPropertyAsString(puchaseProp);
                puchaseStr = puchaseStr + "|" + application.getLoanType().getLoanAmt();
                hash.put("pp", puchaseStr);
          }
          
          List<Asset> assetList = application.getAssets();
          List<Property> properties = application.getProperties();
          
          if(assetList !=null && assetList.size() > 0 && properties != null && properties.size() > 0 )
          {
            for(Asset asset:assetList)
            {
                if( MortgageUtil.AssetTypeEnum.RealEstate.toString().equals(asset.getAssetType()))
                {
                      Property property = getPropertyByIndex(application, asset.getPropertyIndex());
                      if ( property.getUseAsSecInd() != null && property.getUseAsSecInd() )
                      {
                            String tempStr = getPropertyAsString(  property);
                            hash.put(property.getIndex()+"", tempStr);
                      }
                }
            }
          }
          return hash;
    }
    
    private String getPropertyAsString( Property property)
    {
          
          StringBuffer strBuff = new StringBuffer();
          
          if ( property != null )
          {
                strBuff.append(property.getIndex() + "|");
                strBuff.append(property.getPropertyType() + "|");
                strBuff.append(property.getBedrooms() + "|");
                strBuff.append(property.getBathrooms()+ "|");
                strBuff.append(property.getCarparks() + "|");

                strBuff.append(property.getCustomerEstimatedValue() + "|");
                strBuff.append(property.getUseAsSecInd() + "|");
                strBuff.append(property.getKeepPropertyInd() + "|");
                
                strBuff.append(property.getAddress().getLine1() + "|");
                strBuff.append(property.getAddress().getLine2()  + "|");
                strBuff.append(property.getAddress().getLine3() + "|");
                strBuff.append(property.getAddress().getSuburb() + "|");
                strBuff.append(property.getAddress().getPostCode() + "|");
                strBuff.append(property.getAddress().getState() + "|");
          }
          return strBuff.toString();
    }
    
    public DocUploadDetailInfo populateDocUploadDetailInfo(List<DocCategoryDetail> docCategoryDetails,Application app){
    	boolean showDocUploadInd = true;
    	List<Applicant> applicants = app.getApplicants();
  		DocUploadDetailInfo docUploadDetailInfo = new DocUploadDetailInfo();
  		docUploadDetailInfo.setAllowedDocumentTypes(Arrays.asList(getDMCodesDataAllowedDocTypes().split(",")));
  		docUploadDetailInfo.setMaxDocumentSize(getDMCodesDataMaxDocumentSize());
  		docUploadDetailInfo.setMaxDocumentsPerUpload(getDMCodesDataMaxNumOfDocsPerUpload());
  		if(app.getDocUploadIntroInd() != null){
  			showDocUploadInd = !app.getDocUploadIntroInd();  			
  		}
  		docUploadDetailInfo.setShowIntro(showDocUploadInd);
  		if(app.getClasNum() != null){
  			docUploadDetailInfo.setClasNum(Long.valueOf(app.getClasNum()));
  		}
  		docUploadDetailInfo.setDocUploadURL(getDMCodesDataDocumentUploadURL());
  		docUploadDetailInfo.setApplicants(populateApplicantInfoListForDocUpload(applicants));
  		docUploadDetailInfo.setDocCategoryDetails(populateDocCategoryDetailInfo(docCategoryDetails));
  		docUploadDetailInfo.setMaxDocumentsUploadSize(getDMCodesDataMaxDocumentsUploadSize());
  		return docUploadDetailInfo;
  	} 
    private List<ApplicantInfo> populateApplicantInfoListForDocUpload(List<Applicant> applicants){
    	List<ApplicantInfo> applicantInfoList = new ArrayList<ApplicantInfo>();					
		ApplicantInfo applicantIno = new ApplicantInfo();
    	for(Applicant applicant : applicants){
    		applicantIno = new ApplicantInfo();
    		applicantIno.setIndex(applicant.getIndex());
    		applicantIno.setFirstName(applicant.getFirstName());
    		applicantIno.setLastName(applicant.getLastName());    		
    		applicantIno.setNtbInd(applicant.getNtbInd());
    		applicantInfoList.add(applicantIno);		
    	}		
		return applicantInfoList;		
	}
    private List<DocCategoryDetailInfo> populateDocCategoryDetailInfo(List<DocCategoryDetail> docCategoryDetails){
    	List<DocCategoryDetailInfo> docCategoryDetailInfoList = new ArrayList<DocCategoryDetailInfo>();
    	for(DocCategoryDetail docCategoryDetail :docCategoryDetails ){
    		DocCategoryDetailInfo docCategoryInfo = new DocCategoryDetailInfo();
    		docCategoryInfo.setCategoryId(docCategoryDetail.getDocCategory().getId().toString());
    		docCategoryInfo.setCategoryName(docCategoryDetail.getDocCategory().getName());
    		//TODO use enum 		
    		docCategoryInfo.setApplicationLevel(docCategoryDetail.getDocCategory().getType() == 0);    		
    		docCategoryInfo.setDocApplicants(populateDocApplicantInfo(docCategoryDetail.getDocTypeDetails(),docCategoryDetail.getOtherDocuments()));
    		docCategoryDetailInfoList.add(docCategoryInfo);
    	}			
		return docCategoryDetailInfoList;		
	}
	private List<DocApplicantInfo> populateDocApplicantInfo(List<DocTypeDetail> docTypeDetails,List<DocUploadDetail> otherDocuments){
		List<DocApplicantInfo> docApplicantInfoList = new ArrayList<DocApplicantInfo>();			
		DocApplicantInfo docApplicantInfoPrimary = null;
		DocApplicantInfo docApplicantInfoSecondary = null;
		
		for(DocTypeDetail docTypeDetail : docTypeDetails){
			DocApplicantInfo docApplicantInfo = null;
			if(docTypeDetail.getApplicantInd().intValue() != 2)//TODO enum
			{
				if(docApplicantInfoPrimary == null){
					docApplicantInfoPrimary = new DocApplicantInfo();
				}
				docApplicantInfo = docApplicantInfoPrimary;
				docApplicantInfo.setApplicantIndex(MortgageUtil.ApplicantIndexEnum.PRIMARY.getValue());
			}	
			else{
				if(docApplicantInfoSecondary == null){
					docApplicantInfoSecondary = new DocApplicantInfo();
				}
				docApplicantInfo = docApplicantInfoSecondary;
				docApplicantInfo.setApplicantIndex(MortgageUtil.ApplicantIndexEnum.SECOND.getValue());
			}
			
			if(docApplicantInfo.getDocTypeDetails() == null)
			{
				docApplicantInfo.setDocTypeDetails(new ArrayList<DocTypeDetailInfo>());
			}
			docApplicantInfo.getDocTypeDetails().add(populateDocTypeDetailInfo(docTypeDetail));
			
		}	
		
		if(otherDocuments != null && !otherDocuments.isEmpty()){
			
			for(DocUploadDetail docUploadDetail : otherDocuments){
				
				DocApplicantInfo docApplicantInfo = null;
				if(docUploadDetail.getApplicantInd().intValue() != 2)//TODO enum
				{
					if(docApplicantInfoPrimary == null){
						docApplicantInfoPrimary = new DocApplicantInfo();
					}
					docApplicantInfo = docApplicantInfoPrimary;
					docApplicantInfo.setApplicantIndex(MortgageUtil.ApplicantIndexEnum.PRIMARY.getValue());
				}	
				else{
					if(docApplicantInfoSecondary == null){
						docApplicantInfoSecondary = new DocApplicantInfo();
					}
					
					docApplicantInfo = docApplicantInfoSecondary;
					docApplicantInfo.setApplicantIndex(MortgageUtil.ApplicantIndexEnum.SECOND.getValue());
				}
				
				
				DocDetailInfo docDetailInfo = new DocDetailInfo();
				docDetailInfo.setName(docUploadDetail.getFileName());		
				
				if(docApplicantInfo.getOtherDocuments() == null){
					docApplicantInfo.setOtherDocuments(new ArrayList<DocDetailInfo>());
				}
				docApplicantInfo.getOtherDocuments().add(docDetailInfo);
			}	
		}
		if(docApplicantInfoPrimary != null){
			docApplicantInfoList.add(docApplicantInfoPrimary);
		}
		if(docApplicantInfoSecondary != null){
			docApplicantInfoList.add(docApplicantInfoSecondary);
		}
		return docApplicantInfoList;		
	}
	
	private DocTypeDetailInfo populateDocTypeDetailInfo(DocTypeDetail docTypeDetail){
		DocTypeDetailInfo docTypeDetailInfo = new DocTypeDetailInfo();
		docTypeDetailInfo.setDocAppMapId(docTypeDetail.getDocAppMapId().toString());
		docTypeDetailInfo.setDocDetails(populateDocDetailInfo(docTypeDetail.getDocDetails()));
		docTypeDetailInfo.setDocTypeName(StringMethods.isEmptyString(docTypeDetail.getCustomdocType()) ? docTypeDetail.getDocType().getType() : docTypeDetail.getCustomdocType());
		if(docTypeDetail.getApplicantInd() != null && docTypeDetail.getApplicantInd() == 3){
			docTypeDetailInfo.setJoint(true);
		}
		if(docTypeDetail.getDocType() != null){
			docTypeDetailInfo.setToolTips(docTypeDetail.getDocType().getDescriptions());
		}
		return docTypeDetailInfo;
	}	
	
	private List<DocDetailInfo> populateDocDetailInfo(List<DocUploadDetail> docUploadDetailList){
		if(docUploadDetailList != null && !docUploadDetailList.isEmpty()){
			List<DocDetailInfo> docDetailInfoList =  new ArrayList<DocDetailInfo>();
			for(DocUploadDetail docUploadDetail : docUploadDetailList){
				DocDetailInfo docDetailInfo = new DocDetailInfo();
				docDetailInfo.setName(docUploadDetail.getFileName());		
				docDetailInfoList.add(docDetailInfo);
			}	
			return docDetailInfoList;
		}
		return null;
	}
	
	public List<DocUploadDetail> populateDocUploadDetails(List<DocUploadInfo> docUploadInfoList) {
		List<DocUploadDetail> docUploadDetailList = null;
		if(docUploadInfoList != null && !docUploadInfoList.isEmpty()) {
			docUploadDetailList = new ArrayList<DocUploadDetail>();
			for(DocUploadInfo docInfo: docUploadInfoList){
				DocUploadDetail docUploadDetail  = new DocUploadDetail();
				docUploadDetail.setApplicantInd(docInfo.getApplicantInd());
				docUploadDetail.setCategoryId(docInfo.getCategoryId());
				docUploadDetail.setDocAppMapId(docInfo.getDocAppMapId());
				docUploadDetail.setFileName(docInfo.getFileName());
				docUploadDetail.setStatus(docInfo.getStatus());	
				docUploadDetail.setDescription(docInfo.getDescription());
				if(!StringMethods.isEmptyString(docInfo.getSize()) && docInfo.getSize().length() > 0){
					docUploadDetail.setSize(new BigDecimal(docInfo.getSize()));
				}				
				docUploadDetailList.add(docUploadDetail);
			}		
		}
		return docUploadDetailList;
	}
	
	public enum CLASApplicationStatusEnum {
	IN_PROGRESS("P"), 
	ASSESS("S"), 
	DOC_UPLOAD("D"), 
	NOT_AVAILABLE("NA");

	private String status;
	private CLASApplicationStatusEnum(String status) {
		this.status = status;
	}
	public String getStatus() {
		return status;
	}
};

	public ApplicationInfo setInflightAppFlag(Date modifiedOn, String origin, ApplicationInfo applicationInfo) {
		LabelValueVO labelValueVO = mortgageParams.getDMCodesDataLabelValueVO(origin, MortgageUtil.MORTGAGE_INFLIGHT_APPLICATIONS_CATEGORY, MortgageUtil.MORTGAGE_INFLIGHT_APPLICATIONS_CODE);
		try{
			if(modifiedOn != null && labelValueVO != null && !StringUtils.isEmpty(labelValueVO.getLabel())){
				Date tempDate = DateUtils.StringtoDate(labelValueVO.getLabel(), "yyyy-MM-dd HH:mm:ss");
				if(modifiedOn.getTime() <= tempDate.getTime()){
					applicationInfo.setInflightApp(true);
				}
			}
		}
		catch(Exception e){
			Logger.error("exception in setInflightApp flag", e,  this.getClass());
		}
		return applicationInfo;
	}
	
	public boolean isDocUploadAllowed(HttpServletRequest httpRequest){
		return logonHelper.isDocUploadAllowed(httpRequest);
	}

	public Boolean crditDecisionEligible(String origin, String customerSituation){
		boolean creditDecisionOffSwitchFound = true;
		//ETB first time save customerSituation is null
		if(StringUtils.isEmpty(customerSituation)){
			Logger.debug("ETB first time save customerSituation is null", this.getClass());
			return null;
		}
		List<String> creditDecisionOffSwitchVales =  mortgageService.getCreditDecisionSwitchOffValues((mortgageParams.getBaseOriginCode(origin)));               
		
		if(creditDecisionOffSwitchVales != null){
			for(String str : creditDecisionOffSwitchVales){
				if(str.equalsIgnoreCase("ALL")){
					creditDecisionOffSwitchFound = false;
					break;
				}
				if(str.equalsIgnoreCase(customerSituation)){
					creditDecisionOffSwitchFound = false;
					break;
				}
			}
		}
		Logger.info("CreditDecison required flag: " + creditDecisionOffSwitchFound, this.getClass());
		return creditDecisionOffSwitchFound;
	}
	
	public boolean validateUploadCustDocDetailsRequest(DocUploadDetailReq request, List<Long> docAppMapIdList){
//		Validate DocAppMapId
		if(docAppMapIdList != null && docAppMapIdList.size() > 0){
			if(request != null && request.getDocUploadInfoList() != null && request.getDocUploadInfoList().size() > 0){
				for(DocUploadInfo docUploadInfo : request.getDocUploadInfoList()){
					if(docUploadInfo != null && docUploadInfo.getDocAppMapId() != null && !docAppMapIdList.contains(docUploadInfo.getDocAppMapId())){
						Logger.error("Validation Failed - Invalid request - DocAppMapId("+docUploadInfo.getDocAppMapId()+") is different from Session", this.getClass());
						return true;
					}
				}
			}
		}
		return false;
	}
	
	public void populateNumberOfDocumentsUploaded(MortgageSessionInfo mortgageSessionInfo, List<DocCategoryDetail> docCategoryDetails){
		long numberOfDocumentsUploaded = 0;
		
		if(docCategoryDetails != null && docCategoryDetails.size() > 0){
			for(DocCategoryDetail docCategoryDetail : docCategoryDetails){
				if(docCategoryDetail != null && docCategoryDetail.getOtherDocuments() != null && docCategoryDetail.getOtherDocuments().size() > 0){
					numberOfDocumentsUploaded = numberOfDocumentsUploaded + docCategoryDetail.getOtherDocuments().size();
				}
				if(docCategoryDetail != null && docCategoryDetail.getDocTypeDetails() != null && docCategoryDetail.getDocTypeDetails().size() > 0){
					for(DocTypeDetail docTypeDetail : docCategoryDetail.getDocTypeDetails()){
						if(docTypeDetail != null && docTypeDetail.getDocDetails() != null && docTypeDetail.getDocDetails().size() > 0){
							numberOfDocumentsUploaded = numberOfDocumentsUploaded + docTypeDetail.getDocDetails().size();
						}
					}
				}
			}
		}
		
		if(mortgageSessionInfo != null){
			mortgageSessionInfo.setNumberOfDocumentsUploaded(numberOfDocumentsUploaded);
			Logger.debug("NumberOfDocumentsUploaded in Session: "+numberOfDocumentsUploaded, this.getClass());
		}
	}	
	
	protected IMBResp populateLenderDetailsResp(List<Lender> lendersList, LabelValueMap lenderMap, MobileSession mobileSession) {		
		LenderDetailsResp lenderDetailsResp = new LenderDetailsResp();

		if(lendersList != null && !lendersList.isEmpty()){
			List<LenderInfo> lenderInfoList = new ArrayList<LenderInfo>(); 
			int index = 1;
			for(Lender lender : lendersList){
				
				LenderInfo info = new LenderInfo();
				info.setAddresssLine1(lender.getAddresssLine1());
				info.setAddresssLine2(lender.getAddresssLine2());
				info.setAddresssLine3(lender.getAddresssLine3());
				info.setPostcode(lender.getAddresssPostcode());
				info.setState(lender.getAddresssState());
				info.setSuburb(lender.getAddresssSuburb());
				info.setBranchName(lender.getBranchName());
				info.setEmail(lender.getEmail());
				info.setFamilyName(lender.getFamilyName());
				info.setFirstName(lender.getFirstName());
				info.setIndex(index);
				if(!StringMethods.isEmptyString(lender.getMobile())){
					info.setPhoneNumber(lender.getMobile());
					info.setIsMobile(true);
				}
				else{
					info.setPhoneNumber(lender.getPhoneNumber());
					info.setIsMobile(false);
				}
				lenderInfoList.add(info);
				lenderMap.put(index+"", lender.getLenedrId());
				
				index++;
				
			}
			
			lenderDetailsResp.setLenderList(lenderInfoList);
		}
		
		return lenderDetailsResp;
	}
	
	protected LenderInfo populateLenderInfo(Lender lender) {		
		LenderInfo info = null;

		if(lender != null){
			int index = 0;
				
			info = new LenderInfo();
			info.setAddresssLine1(lender.getAddresssLine1());
			info.setAddresssLine2(lender.getAddresssLine2());
			info.setAddresssLine3(lender.getAddresssLine3());
			info.setPostcode(lender.getAddresssPostcode());
			info.setState(lender.getAddresssState());
			info.setSuburb(lender.getAddresssSuburb());
			info.setBranchName(lender.getBranchName());
			info.setEmail(lender.getEmail());
			info.setFamilyName(lender.getFamilyName());
			info.setFirstName(lender.getFirstName());
			//info.setIndex(index);
			if(!StringMethods.isEmptyString(lender.getMobile())){
				info.setPhoneNumber(lender.getMobile());
				info.setIsMobile(true);
			}
			else{
				info.setPhoneNumber(lender.getPhoneNumber());
				info.setIsMobile(false);
			}
			
		}
		return info;
	}
	
	public void checkOfferEligbility(List<ApplicantInfo> applicants,Map<String,Boolean> map ){
		
		if(applicants!=null){
			
					//List<Applicant> applicants =applicationReq.getApplicants();
					
					
					boolean checkForAge=false;
					
					
					//Logger.info("MortgageServiceImpl:::checkOfferEligbility() Geting List of applicants for application refnum=="+application.getApplicationNum(),this.getClass());
					for(ApplicantInfo applicant:applicants){
						Logger.debug("applicant index==="+applicant.getIndex(), this.getClass());
					
						Calendar birthDayCalendar = Calendar.getInstance();
						if(Boolean.FALSE.equals( map.get( String.valueOf(applicant.getIndex())))){
							
								continue;
							}
						
						if(applicant.getDateOfBirth()!=null){
							
								Date birthDate =(DateUtils.StringtoDateSoftConvert(applicant.getDateOfBirth(), "yyyy-M-dd"));
								checkForAge=mortgageService.checkAgeConditionForDMPolicyUpdate(birthDate);
								Logger.debug("age elibility for new  applicant==="+applicant.getFirstName()+"==="+checkForAge+"==="+applicant.getDateOfBirth().toString(), this.getClass());
								map.put( String.valueOf(applicant.getIndex()),checkForAge);
								
							
						}
						else{
							Logger.debug("applicant ==="+applicant.getIndex()+" DOB =null", this.getClass());
						}
					}
					
				
		}
		
	}
	
	
	

	public boolean checkOfferEligibility(ApplicationReq req, MobileSession mobileSession) throws BusinessException{
	//Boolean checkOfferEligibility=false;
	boolean offerEligibility=false;
	
	LoanTypeInfo loanTypeOfferEligible =req.getApp().getLoanType();//checking loan type info from request
	List<ApplicantInfo> applicantsInfo =req.getApp().getApplicants();
	Logger.info("DM Offer Eligbility:::: Loan Type::::"+loanTypeOfferEligible.getLoanType()+",First Home Buyer::::"+loanTypeOfferEligible.getFirstHomeBuyerInd(),this.getClass());
	if(loanTypeOfferEligible.getLoanType()!=null && LoanAppConstants.HOMELOAN_LOAN_TYPE_NEW_PROPERTY.equals(loanTypeOfferEligible.getLoanType()) && MortgageUtil.LOAN_PURPOSE_OWNER_OCCUPIED.equals(loanTypeOfferEligible.getLoanPurpose()) ){
	//	if(loanTypeOfferEligible.getFirstHomeBuyerInd()!=null && Boolean.TRUE.equals(loanTypeOfferEligible.getFirstHomeBuyerInd())){
		
			Map<String,Boolean> map = new HashMap<String,Boolean>();
			
				if(mobileSession.getMortgageSessionInfo().getIsExistingCustomer()!=null){
					
					Application classApplication = mobileSession.getMortgageSessionInfo().getApplication();
					
					Logger.info("DM Offer Eligbility:::: Checking for existing customers for application Num::::"+classApplication.getApplicationNum(),this.getClass());
					mortgageService.checkOfferEligbility(classApplication, map );
					if(map.size()<2){
						Logger.info("DM Offer Eligbility:::: Checking for new customers for application Num::::"+req.getHeader().getMortgageApplicationNum(),this.getClass());
						checkOfferEligbility(applicantsInfo, map );
					}
				
				}else{
					Logger.info("Checking for new customers for application Num::::"+req.getHeader().getMortgageApplicationNum(),this.getClass());
					checkOfferEligbility(applicantsInfo, map);
				}
			for(Entry<String,Boolean> entry:map.entrySet()){
				if(entry.getValue()==false){
					offerEligibility=false;
					break;
				}
				else{
					offerEligibility=true;
				}
			}	
	
			map.clear();
				
		//	}
	}
	/*
	int term = Integer.valueOf(loanTypeOfferEligible.getLoanTerm()).intValue();
	if(offerEligibility){
		
		
		if(term < LOAN_TERM_MIN || term > LOAN_TERM_MAX_OFFER)
		{
			Logger.error("Loan Type incomplete LoanTerm", this.getClass());
			throw new BusinessException(BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE);
		}	
		
	}
	else{
		if(term < LOAN_TERM_MIN || term > LOAN_TERM_MAX)
		{
			Logger.error("Loan Type incomplete LoanTerm", this.getClass());
			throw new BusinessException(BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE);
		}	
		
	}*/
	
	
	return offerEligibility;
	}
	
	
}
