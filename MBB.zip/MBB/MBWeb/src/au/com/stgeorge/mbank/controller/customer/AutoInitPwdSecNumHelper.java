package au.com.stgeorge.mbank.controller.customer;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import au.com.stgeorge.framework.common.logging.Logger;
import au.com.stgeorge.ibank.businessobject.BusinessException;
import au.com.stgeorge.ibank.businessobject.CustomerMaintenanceService;
import au.com.stgeorge.ibank.businessobject.ResourceException;
import au.com.stgeorge.ibank.valueobject.Account;
import au.com.stgeorge.ibank.valueobject.transfer.CustomerMaintenance;
import au.com.stgeorge.ibank.valueobject.transfer.IBankCommonData;
import au.com.stgeorge.mbank.model.request.customer.AutoInitPwdSecNumReq;

public class AutoInitPwdSecNumHelper{
	
	protected void validateAutoInitPwdSec(AutoInitPwdSecNumReq req) throws BusinessException 
	{
	    if(null==req.getNewSecNum())
	    {
	    	throw new BusinessException(BusinessException.WSVC_INVALID_INPUT_PARAM);
	    }
	    if(null==req.getNewPassword())
	    {
	    	throw new BusinessException(BusinessException.WSVC_INVALID_INPUT_PARAM);
	    }
	    if(null!=req.getEmailAddress() && !isValidEmailAddress(req.getEmailAddress())){
	    	throw new BusinessException(BusinessException.MB_INVALID_EMAIL);
	    }
	    if(null!=req.getNewSecNum() && req.getNewSecNum().length()>6){
	    	throw new BusinessException(BusinessException.MB_INVALID_SECURITY_NUMBER);
	    }
	    if(null!=req.getNewSecNum() && req.getNewSecNum().length()<4){
	    	throw new BusinessException(BusinessException.MB_INVALID_SECURITY_NUMBER);
	    }
	    if(null!=req.getNewSecNum() && !checkNumbers(req.getNewSecNum())){
	    	throw new BusinessException(BusinessException.MB_INVALID_SECURITY_NUMBER);
	    }
	    if(null!=req.getNewPassword() && !checkCharactersAndNumbers(req.getNewPassword())){
	    	throw new BusinessException(BusinessException.MB_INVALID_PASSWORD);
	    }
	    if(null!=req.getNewPassword() && req.getNewPassword().length()<6){
	    	throw new BusinessException(BusinessException.MB_INVALID_PASSWORD);
	    }
	    if(null!=req.getNewPassword() && req.getNewPassword().length()>12){
	    	throw new BusinessException(BusinessException.MB_INVALID_PASSWORD);
	    }
	    if(null!=req.getNewPassword() && !checkCharactersAndNumbers(req.getNewPassword())){
	    	throw new BusinessException(BusinessException.MB_INVALID_PASSWORD);
	    }
	}
	
	public boolean  checkNumbers(String value){
		boolean result=false;
		String REGEX = "[0-9]*";
		Pattern pattern = Pattern.compile(REGEX);
		Matcher matcher = pattern.matcher(value);
		if (matcher.matches()){
		  result=true;
		}
		else{
			result=false;
		}
		return result;
	}
	
	public boolean  checkCharactersAndNumbers(String value){
		boolean result=false;
		String REGEX = "[a-zA-Z0-9]*";
		Pattern pattern = Pattern.compile(REGEX);
		Matcher matcher = pattern.matcher(value);
		if (matcher.matches()){
		  result=true;
		}
		else{
			result=false;
		}
		return result;
	}
	
	public boolean isValidEmailAddress(String email) {
        String ePattern = "^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@((\\[[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}\\])|(([a-zA-Z\\-0-9]+\\.)+[a-zA-Z]{2,}))$";
        java.util.regex.Pattern p = java.util.regex.Pattern.compile(ePattern);
        java.util.regex.Matcher m = p.matcher(email);
        return m.matches();
 }
	
	public void addCustomerAuditLog(IBankCommonData commonData, String action, String imageType,String desc) throws BusinessException, ResourceException {
        Logger.debug("Start adding CustomerAudit log for PwdReset ", this.getClass());
        CustomerMaintenance custMaintVO = new CustomerMaintenance();
        custMaintVO.setDescription(desc);
        if(commonData != null) {
              custMaintVO.setBrand(commonData.getOrigin());
              if(commonData.getGdwOrigin()!=null){
                    custMaintVO.setBrand(commonData.getGdwOrigin());
              }
              custMaintVO.setGcisNumber(commonData.getUser().getGCISNumber());
        }
                    
        CustomerMaintenanceService.addAuditLog(custMaintVO, action, imageType, commonData.getUser());
  }
	
	public List<Account> getAcctListWithIndex(List<Account> customerAccounts,List<Account> eligibleAccounts){		
		
		List<Account> accountList=new ArrayList<Account>();		
        for(int c=0; c<customerAccounts.size();c++)
        {        	
          Account  custAcc = (Account) customerAccounts.get(c);
          
           if(null != eligibleAccounts)
            {
                for(int i=0;i<eligibleAccounts.size();i++)
                {
                    Account  eligibleaccount = eligibleAccounts.get(i);
                    if(null != eligibleaccount)
                     {
                        if((custAcc.getAccountId().getAccountNumber()).equals(eligibleaccount.getAccountId().getAccountNumber()))
                         {
                        	 Account account = new Account();
                             account.setEstmtAcctStatus("S");
                             account.setAccountId(custAcc.getAccountId());
                             account.setIndex(custAcc.getIndex());
                             account.setAccountId(custAcc.getAccountId());
                             accountList.add(account);
                         }
                     }
                 }
            }
       }
	  return accountList;		
  }
}
