package au.com.stgeorge.mbank.controller;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import au.com.stgeorge.framework.common.logging.Logger;
import au.com.stgeorge.ibank.businessobject.BusinessException;
import au.com.stgeorge.ibank.businessobject.IBankSecureService;
import au.com.stgeorge.ibank.businessobject.ResourceException;
import au.com.stgeorge.ibank.common.cache.IBankParams;
import au.com.stgeorge.ibank.onlinereg.valueobject.OnlineRegistrationDetails;
import au.com.stgeorge.ibank.valueobject.NonFinTransactionDetails;
import au.com.stgeorge.ibank.valueobject.OTP;
import au.com.stgeorge.ibank.valueobject.SecureCodeDetails;
import au.com.stgeorge.ibank.valueobject.TransactionDetails;
import au.com.stgeorge.ibank.valueobject.transfer.IBankCommonData;
import au.com.stgeorge.mbank.model.common.ErrorInfo;
import au.com.stgeorge.mbank.model.common.IMBResp;
import au.com.stgeorge.mbank.model.common.RespHeader;
import au.com.stgeorge.mbank.model.request.SecureCodeReq;
import au.com.stgeorge.mbank.model.response.ErrorResp;
import au.com.stgeorge.mbank.model.response.SecureCodeResp;
import au.com.stgeorge.mbank.session.MobileSession;
import au.com.stgeorge.mbank.util.MBAppHelper;
import au.com.stgeorge.mbank.util.MBAppUtils;
import au.com.stgeorge.mbank.util.ServiceConstants;
import au.com.stgeorge.mobilebank.businessobject.SecureCodeService;

@Service
/*
 * Secure code verification helper
 * 
 * @author C38854
 */
public class SecureCodeHelper {
	
	private static HashMap<Integer, String> transaction2FATypes;

	public static final String FRAUD_TXN_CHANGE_CARD_PIN = "ChangeCardPIN";
	public static final String FRAUD_TXN_SET_CARD_PIN = "SetCardPIN";
	public static final String FRAUD_FAIL_SYSTEM_ERR = "System error";
	public static final String FRAUD_FAIL_2FA_ERR = "2FA error";

	static
	{
		transaction2FATypes = new HashMap<Integer, String>();
		transaction2FATypes.put(ServiceConstants.PAYEE_TRANSFER_2FA_TRAN_CODE, IBankSecureService.THIRD_PARTY_PAYMENT);
		transaction2FATypes.put(ServiceConstants.BPAY_TRANSFER_2FA_TRAN_CODE, IBankSecureService.BPAY_PAYMENT);
		transaction2FATypes.put(ServiceConstants.ADD_PAYEE_2FA_TRAN_CODE, IBankSecureService.THIRD_PARTY_CREATE);
		transaction2FATypes.put(ServiceConstants.INC_PAYEE_LIMIT_2FA_TRAN_CODE, IBankSecureService.INCREASE_PAYEE_LIMIT);
		transaction2FATypes.put(ServiceConstants.OVERSEAS_TT_2FA_TRAN_CODE, IBankSecureService.OVERSEAS_TT);
		transaction2FATypes.put(ServiceConstants.ADD_BILLER_2FA_TRAN_CODE, IBankSecureService.BILLER_CREATE);
		transaction2FATypes.put(ServiceConstants.INITIAL_LOGON_ACTIVATION_2FA_TRAN_CODE, IBankSecureService.INITIAL_LOGON_ACTIVATION);
		transaction2FATypes.put(ServiceConstants.TT_REGISTRATION_2FA_TRAN_CODE, IBankSecureService.TT_REGISTRATION);
		transaction2FATypes.put(ServiceConstants.OVERSEAS_TRAVEL_2FA_TRAN_CODE, IBankSecureService.OVERSEAS_TRAVEL);
		transaction2FATypes.put(ServiceConstants.CUST_DET_UPD_2FA_TRAN_CODE, IBankSecureService.CUST_DET_UPD);
		transaction2FATypes.put(ServiceConstants.GET_CASH_REG_2FA_TRAN_CODE, IBankSecureService.GET_CASH_REGISTRATION);
		transaction2FATypes.put(ServiceConstants.PAY_TO_MOBILE_2FA_TRAN_CODE, IBankSecureService.PAY_TO_MOBILE_ACTIVATE);
		transaction2FATypes.put(ServiceConstants.CAN_RETRIEVAL_TRAN_CODE, IBankSecureService.CAN_RETRIEVAL);
		transaction2FATypes.put(ServiceConstants.PWD_RESET_TRAN_CODE, IBankSecureService.PWD_RESET);		
		transaction2FATypes.put(ServiceConstants.SET_CARD_PIN_TRAN_CODE, IBankSecureService.SET_CARD_PIN);
		transaction2FATypes.put(ServiceConstants.CHANGE_CARD_PIN_TRAN_CODE, IBankSecureService.CHANGE_CARD_PIN);
		transaction2FATypes.put(ServiceConstants.ONLINE_REG_TRAN_CODE, IBankSecureService.ONLINEREG);
		transaction2FATypes.put(ServiceConstants.CRS_MAINTENANCE_TRAN_CODE, IBankSecureService.CRS);
		transaction2FATypes.put(ServiceConstants.SAFI_LOGON_TRAN_CODE, IBankSecureService.LOGON);
		transaction2FATypes.put(ServiceConstants.CCCLOSURE_TRAN_CODE, IBankSecureService.CCCLOSURE);
		transaction2FATypes.put(ServiceConstants.PAYIDREG_TRAN_CODE, IBankSecureService.PAYIDREG);
		transaction2FATypes.put(ServiceConstants.PAY_TO_PAYID_TRAN_CODE, IBankSecureService.PAY_TO_PAY_ID);
		transaction2FATypes.put(ServiceConstants.OSKO_TRANSFER_2FA_TRAN_CODE, IBankSecureService.OSKO_PAYMENT);
		transaction2FATypes.put(ServiceConstants.PERSONAL_LOAN_2FA_TRAN_CODE, IBankSecureService.ECONTRACT);
		transaction2FATypes.put(ServiceConstants.PAYIDREGUPD_TRAN_CODE, IBankSecureService.PAYID_REG_UPD);
		transaction2FATypes.put(ServiceConstants.PAYIDRESOLUTION_TRAN_CODE, IBankSecureService.PAYID_RESOLUTION);
		transaction2FATypes.put(ServiceConstants.FILESHARE_TRAN_CODE, IBankSecureService.FILESHARE);
		transaction2FATypes.put(ServiceConstants.MGRP_TRAN_CODE, IBankSecureService.MGRP);
		transaction2FATypes.put(ServiceConstants.MADISON_TRAN_CODE,IBankSecureService.MADISON);
		transaction2FATypes.put(ServiceConstants.REACTIVATE_ONLINE_TRAN_CODE,IBankSecureService.LOGON); //TO BE CONFIRMED
	}
	
	
	@Value("${errors.deliveryMethod.required}")
	private String deliveryMethodRequiredMessage;

	@Value("${errors.otpPassword.required}")
	private String passRequiredMessage;

	@Value("${errors.resend.required}")
	private String resendRequiredMessage;

	@Value("${errors.phone.required}")
	private String phoneRequiredMessage;

	@Autowired
	private SecureCodeService secCodeService;

	/**
	 * Request secure code To be called by Update Contact Details, Overseas Travel, Initial Logon Activation, Overseas TT
	 * 
	 * @param commonData
	 * @param mobileSession
	 * @param details
	 * @param request
	 * @return
	 */
	public IMBResp reqSecureCode(IBankCommonData commonData, MobileSession mobileSession, TransactionDetails details, SecureCodeReq request, String caller, HttpServletRequest httpRequest) throws Exception{
		return reqSecureCode(commonData, mobileSession, details, null, request, caller, httpRequest);
	}

	/**
	 * Request secure code To be called by Add Payee, Increase Payee Limit
	 * 
	 * @param commonData
	 * @param mobileSession
	 * @param thirdParty
	 * @param request
	 * @return
	 */
	public IMBResp reqSecureCode(IBankCommonData commonData, MobileSession mobileSession, NonFinTransactionDetails thirdParty, SecureCodeReq request, String caller, HttpServletRequest httpRequest) throws Exception {
		return reqSecureCode(commonData, mobileSession, null, thirdParty, request, caller, httpRequest);
	}

	/**
	 * Verify secure code To be called by Update Contact Details, Overseas Travel, Initial Logon Activation, Overseas TT
	 * 
	 * @param commonData
	 * @param mobileSession
	 * @param details
	 * @param request
	 * @return
	 * @throws Exception
	 */
	public ErrorResp verifySecureCode(IBankCommonData commonData, MobileSession mobileSession, TransactionDetails details, SecureCodeReq request, String caller, HttpServletRequest httpRequest)
			throws Exception {
		return verifySecureCode(commonData, mobileSession, details, null, request, caller, httpRequest);
	}

	/**
	 * Verify secure code To be called by Add Payee, Increase Payee Limit
	 * 	
	 * @param commonData
	 * @param mobileSession
	 * @param details
	 * @param request
	 * @return
	 * @throws Exception
	 */
	public ErrorResp verifySecureCode(IBankCommonData commonData, MobileSession mobileSession, NonFinTransactionDetails details, SecureCodeReq request, String caller, HttpServletRequest httpRequest)
			throws Exception {
		return verifySecureCode(commonData, mobileSession, null, details, request, caller, httpRequest);
	}

	/**
	 * Request secure code
	 * 
	 * @param commonData
	 * @param mobileSession
	 * @param details
	 * @param request
	 * @return
	 * @throws Exception
	 */
	public IMBResp reqSecureCode(IBankCommonData commonData, MobileSession mobileSession, TransactionDetails details,
			NonFinTransactionDetails nonFinancialDetails, SecureCodeReq request, String caller, HttpServletRequest httpRequest) throws Exception {
		
		ErrorResp errorResponse = validateReqSecureCodeReq(request, new ErrorResp(new MBAppHelper().populateResponseHeader(caller, httpRequest)));
		if (errorResponse.hasErrors()){
			Logger.info("Error response populated: " + errorResponse, this.getClass());
			return errorResponse;
		}
		SecureCodeDetails secureCodeDetails = mobileSession.getSecureCodeDetails();
		
		if (secureCodeDetails == null) {
			secureCodeDetails = new SecureCodeDetails();
		} /*else {*/
			String tranType = transaction2FATypes.get(request.getTranType());
			if (tranType == null/* || !tranType.equals(secureCodeDetails.getTransactionType())*/) {//TODO sometimes when secureCodeDetails were not killed properly from prev transaction - exception comes
				mobileSession.removeSecureCodeDetails();
				Logger.error("Error in SecureCodeHelper - verifySecureCode(): Transaction Type Unknown or invalid", this.getClass());
				throw new Exception("Transaction Type Unknown or invalid");
			}
		//}
		secureCodeDetails = populateSecureCodeDetails(request, secureCodeDetails);
		mobileSession.setSecureCodeDetails(secureCodeDetails);

		String origin = commonData.getOrigin();
		try {
			OTP otp = null;
			if (IBankSecureService.INCREASE_PAYEE_LIMIT.equalsIgnoreCase(secureCodeDetails.getTransactionType())
					|| IBankSecureService.THIRD_PARTY_CREATE.equalsIgnoreCase(secureCodeDetails.getTransactionType())
					|| IBankSecureService.BILLER_CREATE.equalsIgnoreCase(secureCodeDetails.getTransactionType())
					|| IBankSecureService.PAY_TO_MOBILE_ACTIVATE.equalsIgnoreCase(secureCodeDetails.getTransactionType())
					|| IBankSecureService.CAN_RETRIEVAL.equalsIgnoreCase(secureCodeDetails.getTransactionType())
					|| IBankSecureService.PWD_RESET.equalsIgnoreCase(secureCodeDetails.getTransactionType())
					|| IBankSecureService.SET_CARD_PIN.equalsIgnoreCase(secureCodeDetails.getTransactionType())
					|| IBankSecureService.CHANGE_CARD_PIN.equalsIgnoreCase(secureCodeDetails.getTransactionType())
					|| IBankSecureService.ONLINEREG.equalsIgnoreCase(secureCodeDetails.getTransactionType())
					|| IBankSecureService.CRS.equalsIgnoreCase(secureCodeDetails.getTransactionType())
					|| IBankSecureService.PAYIDREG.equalsIgnoreCase(secureCodeDetails.getTransactionType())
					|| IBankSecureService.LOGON.equalsIgnoreCase(secureCodeDetails.getTransactionType())
					|| IBankSecureService.ECONTRACT.equalsIgnoreCase(secureCodeDetails.getTransactionType())
					|| IBankSecureService.PAYID_REG_UPD.equalsIgnoreCase(secureCodeDetails.getTransactionType())
					|| IBankSecureService.PAYID_RESOLUTION.equalsIgnoreCase(secureCodeDetails.getTransactionType()))
			{ 
				otp = secCodeService.createIBankSecureCode(commonData, nonFinancialDetails, secureCodeDetails);
			} else if (details != null){
				otp = secCodeService.createIBankSecureCode(commonData, details, secureCodeDetails);
			} else {
				otp = secCodeService.createIBankSecureCode(commonData, null, null, secureCodeDetails);
			}
			secureCodeDetails.setOtp(otp);
			secureCodeDetails.setRequestOTP(false);
			mobileSession.setSecureCodeDetails(secureCodeDetails);
			
			if(IBankSecureService.ONLINEREG.equalsIgnoreCase(secureCodeDetails.getTransactionType())){
				OnlineRegistrationDetails onlineRegistrationDetails = (OnlineRegistrationDetails) nonFinancialDetails;
				secCodeService.verifyOnlineRegSecureCounters(onlineRegistrationDetails);
			} else {
				secCodeService.verifyIBankSecureCounters(mobileSession.getUser());
			}
			
			return populateSecureCodeResponse(otp, new MBAppHelper().populateResponseHeader(caller, mobileSession));
		} catch (BusinessException e) {
			Logger.info("BusinessException in SecureCodeHelper - reqSecureCode(): ", e, this.getClass());
			if (e.getKey() == BusinessException.IBANK_SECURE_SEND_WARNING || e.getKey() == BusinessException.IBANK_SECURE_SEND_WARNING_SENDCOUNT_2) {
				return MBAppUtils.createWarningResp(origin, e.getKey(), MBAppUtils.getMessage(origin, e.getKey(), new String[] { IBankParams
						.getOrigin(commonData.getOrigin()).getTradingHours() }), caller, mobileSession);
			} else if (e.getKey() == BusinessException.IBANK_SECURE_ACCESS_SUSPENDED) {
				return MBAppUtils.createErrorResp(origin, e, caller, ErrorResp.STATUS_2FA_SUSPENDED, httpRequest);
			} else {
				if (secureCodeDetails.getOtp() != null) {
					secureCodeDetails.getOtp().setIssueNumber(secureCodeDetails.getOtp().getIssueNumber() - 1);
					mobileSession.setSecureCodeDetails(secureCodeDetails);
				}
				return MBAppUtils.createErrorResp(origin, e, caller, httpRequest);
			}
		} catch (ResourceException e) {
			if (e.getKey() == ResourceException.IBANK_SYSTEM_UNAVAILABLE) {
				throw new BusinessException(BusinessException.IBANK_SECURE_OTP_UNAVAILABLE);
			}
			throw e;
		}
	}

	/**
	 * Verify secure code
	 * 
	 * @param commonData
	 * @param mobileSession
	 * @param details
	 * @param request
	 * @return
	 * @throws Exception
	 */
	private ErrorResp verifySecureCode(IBankCommonData commonData, MobileSession mobileSession, TransactionDetails details,
			NonFinTransactionDetails nonFinTransactionDetails, SecureCodeReq request, String caller, HttpServletRequest httpRequest) throws Exception {
		
		ErrorResp errorResponse = validateVerifySecureCodeReq(request, new ErrorResp(new MBAppHelper().populateResponseHeader(caller, httpRequest)));
		if (errorResponse.hasErrors())
			return errorResponse;

		SecureCodeDetails secureCodeDetails = mobileSession.getSecureCodeDetails();
		
		String origin = commonData.getOrigin();
		String tranType = transaction2FATypes.get(request.getTranType());
		try {
			
			if (tranType == null || !tranType.equals(secureCodeDetails.getTransactionType())){
				mobileSession.setSecureCodeDetails(null);
				Logger.error("Error in SecureCodeHelper - verifySecureCode(): Transaction Type Unknown or invalid", this.getClass());
				throw new Exception("Transaction Type Unknown or invalid");
			}
			secureCodeDetails.getOtp().setVerified(false);

			//for verify - if add payee or increase payee limit or GetCash Registration - non-fin transaction details,
			//if transaction - transaction details
			//if update contact details or logon activation - neither of them
			//else - error
			if (nonFinTransactionDetails == null && details != null || IBankSecureService.CUST_DET_UPD.equals(tranType) || IBankSecureService.INITIAL_LOGON_ACTIVATION.equals(tranType) || IBankSecureService.GET_CASH_REGISTRATION.equals(tranType) || IBankSecureService.PAY_TO_MOBILE_ACTIVATE.equals(tranType) || IBankSecureService.FILESHARE.equals(tranType) || IBankSecureService.MGRP.equals(tranType) || IBankSecureService.MADISON.equals(tranType)) {
				secCodeService.verifyIBankSecureCode(secureCodeDetails.getOtp(), request.getOtpPwd(), commonData, details);
			} else if (nonFinTransactionDetails != null && details == null) {
				secCodeService.verifyIBankSecureCode(secureCodeDetails.getOtp(), request.getOtpPwd(), commonData, nonFinTransactionDetails);
			} else {
				mobileSession.removeSecureCodeDetails();
				throw new Exception("No secure transaction found in session");
			}
			
			//	Setting last successful 2FA date in session which will be used in subsequent SAFI calls
			if(mobileSession != null) {
				Logger.info("User authenticated successfully after 2FA and setting SafiLast2FASuccessTime in session : "+new Date().getTime(), this.getClass());
				mobileSession.setSafiLast2FASuccessTime(new Date());
			}
			
			secureCodeDetails.getOtp().setVerified(true);
			return new ErrorResp(new MBAppHelper().populateResponseHeader(caller, httpRequest));// success
		} catch (BusinessException be) {
			Logger.info("BusinessException in SecureCodeHelper - verifySecureCode(): ", be, this.getClass());
			if (be.getKey() == BusinessException.IBANK_SECURE_CODE_INCORRECT || be.getKey() == BusinessException.IBANK_SECURE_BLANK_SECURECODE) {
				try {
				    if(IBankSecureService.ONLINEREG.equals(tranType)) {
					OnlineRegistrationDetails onlineRegistrationDetails = (OnlineRegistrationDetails) nonFinTransactionDetails;
					secCodeService.verifyOnlineRegSecureCounters(onlineRegistrationDetails);
				    }
				    else {
					secCodeService.verifyIBankSecureCounters(mobileSession.getUser());
				    }
					
				} catch (BusinessException busex) {
					if (busex.getKey() == BusinessException.IBANK_SECURE_AUTH_WARNING) {
						return MBAppUtils.createWarningResp(origin, busex.getKey(), MBAppUtils.getMessage(origin, busex.getKey()), caller, mobileSession);
//					}else if (busex.getKey() == BusinessException.IBANK_SECURE_SEND_WARNING_SENDCOUNT_2) {
//						return MBAppUtils.createWarningResp(origin, busex.getKey(), MBAppUtils.getMessage(origin, busex.getKey(), new String[] { IBankParams
//									.getOrigin(commonData.getOrigin()).getTradingHours() }), caller);
					} else if (busex.getKey() == BusinessException.IBANK_SECURE_ACCESS_SUSPENDED) {
						return MBAppUtils.createErrorResp(origin, busex, caller, ErrorResp.STATUS_2FA_SUSPENDED, httpRequest);
					}
				}
			} else if (be.getKey() == BusinessException.IBANK_SECURE_MAX_RETRIES_EXCEEDED
					|| be.getKey() == BusinessException.IBANK_SECURE_CODE_EXPIRED) {
				secureCodeDetails.getOtp().setRetryCount(0);
				secureCodeDetails.setRequestOTP(false);
				secureCodeDetails.setEnterOTP(false);
				secureCodeDetails.setResendOTP(true);
				mobileSession.setSecureCodeDetails(secureCodeDetails);
				return MBAppUtils.createErrorResp(origin, be, caller, ErrorResp.STATUS_2FA_EXPIRED_OR_EXCEEDED, httpRequest);
			} else if (be.getKey() == BusinessException.IBANK_SECURE_ACCESS_SUSPENDED){
				return MBAppUtils.createErrorResp(origin, be, caller, ErrorResp.STATUS_2FA_SUSPENDED, httpRequest);
			} else {
				secureCodeDetails.setRequestOTP(false);
				secureCodeDetails.setEnterOTP(true);
				secureCodeDetails.setResendOTP(false);
			}
			mobileSession.setSecureCodeDetails(secureCodeDetails);
			return MBAppUtils.createErrorResp(origin, be, caller, httpRequest);
		} catch (ResourceException e) {
			if (e.getKey() == ResourceException.IBANK_SYSTEM_UNAVAILABLE) {
				throw new BusinessException(BusinessException.IBANK_SECURE_OTP_UNAVAILABLE);
			}
			throw e;
		}

	}

	/**
	 * Populate service response - secure code
	 * 
	 * @param otp
	 * @param header
	 * @return
	 */
	private SecureCodeResp populateSecureCodeResponse(OTP otp, RespHeader header) {
		SecureCodeResp response = new SecureCodeResp(header);
		response.setIssueNumber(otp.getIssueNumber());
		response.setRetryCount(otp.getRetryCount());
		response.setTranId(otp.getTransactionId());
		Logger.info("Response: " + response, this.getClass());		
		return response;
	}

	/**
	 * Populate secure code bean
	 * 
	 * @param request
	 * @param secureCodeDetails
	 * @return
	 */
	private SecureCodeDetails populateSecureCodeDetails(final SecureCodeReq request, SecureCodeDetails secureCodeDetails) {
		secureCodeDetails.setDeliveryMethod(request.getDeliveryMethod());
		secureCodeDetails.setPhoneNumber(request.getPhone());
		secureCodeDetails.setEnterOTP(!request.getResend());
		secureCodeDetails.setResendOTP(request.getResend());
		secureCodeDetails.setRequestOTP(!request.getResend());

		OTP otp = new OTP();
		if (secureCodeDetails.isRequestOTP()) {
			otp = new OTP();
			otp.setIssueNumber(1);
			otp.setRetryCount(0);
			otp.setTransactionId(0);
		}

		if (secureCodeDetails.isResendOTP()) {
			otp = secureCodeDetails.getOtp();
			otp.setRetryCount(0);
			otp.setIssueNumber(otp.getIssueNumber() + 1);
		}

		secureCodeDetails.setOtp(otp);
		secureCodeDetails.setTransactionType(transaction2FATypes.get(request.getTranType()));
		return secureCodeDetails;
	}

	/**
	 * Additional validation for request secure code
	 * 
	 * @param serviceRequest
	 * @param errors
	 * @return
	 */
	private ErrorResp validateReqSecureCodeReq(SecureCodeReq serviceRequest, ErrorResp errors) {

		if (serviceRequest.getDeliveryMethod() == null) {
			ErrorInfo error = new ErrorInfo();
			error.setCode("");
			error.setMessage(deliveryMethodRequiredMessage);
			errors.getErrors().add(error);
		}
		if (serviceRequest.getPhone() == null) {
			ErrorInfo error = new ErrorInfo();
			error.setCode("");
			error.setMessage(phoneRequiredMessage);
			errors.getErrors().add(error);
		}
		if (serviceRequest.getResend() == null) {
			ErrorInfo error = new ErrorInfo();
			error.setCode("");
			error.setMessage(resendRequiredMessage);
			errors.getErrors().add(error);
		}
		return errors;
	}

	/**
	 * Additional validation for transfer secure
	 * 
	 * @param serviceRequest
	 * @param errors
	 * @return
	 */
	private ErrorResp validateVerifySecureCodeReq(SecureCodeReq serviceRequest, ErrorResp errors) {
		if (serviceRequest.getOtpPwd() == null) {
			ErrorInfo error = new ErrorInfo();
			error.setCode("");
			error.setMessage(passRequiredMessage);
			if (errors.getErrors() == null)
				errors.setErrors(new ArrayList<ErrorInfo>());
			errors.getErrors().add(error);
		}
		return errors;
	}

}
