package au.com.stgeorge.mbank.controller.payments;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.xml.datatype.DatatypeConfigurationException;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import au.com.stgeorge.digitalsec.logger.DigitalSecLogggerVO;
import au.com.stgeorge.framework.common.logging.Logger;
import au.com.stgeorge.framework.common.util.StringMethods;
import au.com.stgeorge.ibank.businessobject.BSBService;
import au.com.stgeorge.ibank.businessobject.BusinessException;
import au.com.stgeorge.ibank.businessobject.CustomerService;
import au.com.stgeorge.ibank.businessobject.HeartBeat;
import au.com.stgeorge.ibank.businessobject.IBankSecureService;
import au.com.stgeorge.ibank.businessobject.MemoryThrottlingService;
import au.com.stgeorge.ibank.businessobject.ResourceException;
import au.com.stgeorge.ibank.common.cache.IBankParams;
import au.com.stgeorge.ibank.common.cache.IBankRefershParams;
import au.com.stgeorge.ibank.npp.PayIdPaymentSwitchParams;
import au.com.stgeorge.ibank.npp.dao.valueobject.NPPPayIdPayee;
import au.com.stgeorge.ibank.servicestation.util.ServicetationConstants;
import au.com.stgeorge.ibank.util.NPPUtil;
import au.com.stgeorge.ibank.util.ServiceHelper;
import au.com.stgeorge.ibank.util.StringUtil;
import au.com.stgeorge.ibank.valueobject.Account;
import au.com.stgeorge.ibank.valueobject.Biller;
import au.com.stgeorge.ibank.valueobject.Customer;
import au.com.stgeorge.ibank.valueobject.LabelValueVO;
import au.com.stgeorge.ibank.valueobject.NPPPayment;
import au.com.stgeorge.ibank.valueobject.PayIDResolution;
import au.com.stgeorge.ibank.valueobject.PayIdThirdParty;
import au.com.stgeorge.ibank.valueobject.PaymentsLog;
import au.com.stgeorge.ibank.valueobject.Receipt;
import au.com.stgeorge.ibank.valueobject.ThirdParty;
import au.com.stgeorge.ibank.valueobject.ThirdPartyPayment;
import au.com.stgeorge.ibank.valueobject.TransactionReceipt;
import au.com.stgeorge.ibank.valueobject.database.CodesVO;
import au.com.stgeorge.ibank.valueobject.transfer.IBankCommonData;
import au.com.stgeorge.ibank.valueobject.transfer.NPPEnrichmentDetails;
import au.com.stgeorge.ibank.valueobject.transfer.NPPValidations;
import au.com.stgeorge.mbank.model.common.RespHeader;
import au.com.stgeorge.mbank.model.request.payments.AddPayeeReq;
import au.com.stgeorge.mbank.model.request.payments.PayeeTransferReq;
import au.com.stgeorge.mbank.model.response.HistoryReceiptDetailResp;
import au.com.stgeorge.mbank.model.response.SuccessResp;
import au.com.stgeorge.mbank.model.response.payments.AddPayeeResp;
import au.com.stgeorge.mbank.model.response.payments.BPayReceiptsResp;
import au.com.stgeorge.mbank.model.response.payments.DeletePayIdPayeeResp;
import au.com.stgeorge.mbank.model.response.payments.DeletePayeeResp;
import au.com.stgeorge.mbank.model.response.payments.IncreasePayeeLimitResp;
import au.com.stgeorge.mbank.model.response.payments.PayIDCountry;
import au.com.stgeorge.mbank.model.response.payments.PayToPayIdLandingPageResp;
import au.com.stgeorge.mbank.model.response.payments.PayeeReceiptsResp;
import au.com.stgeorge.mbank.model.response.payments.PayeesAndBillersListResp;
import au.com.stgeorge.mbank.model.response.payments.ResolvePayIdResp;
import au.com.stgeorge.mbank.model.response.payments.TransferResp;
import au.com.stgeorge.mbank.session.MobileSession;
import au.com.stgeorge.mbank.util.MBAppHelper;
import au.com.stgeorge.mbank.util.MBAppUtils;
import au.com.stgeorge.mbank.util.ServiceConstants;
import au.com.stgeorge.mobilebank.businessobject.impl.MobileBankServiceImpl;

/**
 * Transfer to Payee Helper
 * 
 * @author C38854
 */

@Service
public class PayeeHelper extends TransferHelper {

	@Autowired
	private IBankRefershParams ibankRefreshParams;
	
	private static final int TPY_MAX_NAME_LEN = 32;
	private static final boolean LENGTH_NOT_EXACT = false;
	private static final String ONUS = "OnUs";
	private static final String PAY_ID_TYPES = "payIdTypes";
	
	private static String PAYID_PAYMENT_COUNTRY_DROPDOWN_CODE = "payIdPaymentCountryList";
	
	/**
	 * Populate Payment bean for transfer
	 * 
	 * @param customer
	 * @param commonData
	 * @param request
	 * @param ip
	 * @param sessionId
	 * @return
	 * @throws BusinessException
	 */
	protected ThirdPartyPayment populatePayment(Account fromAccount, Customer customer, IBankCommonData commonData, PayeeTransferReq request, MobileSession mobileSession)
			throws BusinessException {
		ThirdPartyPayment thirdPartyPayment = new ThirdPartyPayment();
		thirdPartyPayment.setBatch(false);
		thirdPartyPayment.setCommonData(commonData);
		thirdPartyPayment.setFromAccount(fromAccount.getAccountId());
		thirdPartyPayment.setFlEmailCopy(Boolean.TRUE.equals(request.getSendEmail())
				&& request.getPayeeEmail() != null && request.getPayeeEmail().length() > 0);
		thirdPartyPayment.setToThirdParty(customer.getThirdParties().get(request.getToPayeeIndex()));
		// override third party email
		thirdPartyPayment.getToThirdParty().setEmailPayee(request.getPayeeEmail());
		
		thirdPartyPayment.getToThirdParty().setPayerName(request.getPayerName());
		if (thirdPartyPayment.getToThirdParty().getPayerName()==null){
			thirdPartyPayment.getToThirdParty().setPayerName("");
		}
		thirdPartyPayment.setAmount(new BigDecimal(request.getAmt()));
		thirdPartyPayment.setDescription(request.getDesc());
		if (thirdPartyPayment.getDescription()==null){
			thirdPartyPayment.setDescription("");
		}
		thirdPartyPayment.setIpAddress(commonData.getIpAddress());
		thirdPartyPayment.setSessionId(commonData.getSessionId());
		thirdPartyPayment.setBrand(commonData.getOrigin());
		thirdPartyPayment.setCheckForDuplicate(true);
		if (request.getOverrideDup() != null)
			thirdPartyPayment.setCheckForDuplicate(!request.getOverrideDup());
		if (request.getDupCount() != null)
			thirdPartyPayment.setDuplicatePaymentCount(request.getDupCount());
		thirdPartyPayment.setPayerName(request.getPayerName());
		if (thirdPartyPayment.getPayerName()==null){
			thirdPartyPayment.setPayerName("");
		}		
		thirdPartyPayment.setNewThirdParty(false);
		if ((request.getScheduleID() !=null && !"".equals(request.getScheduleID())) || request.getScheduleDetail() != null){
			thirdPartyPayment.setSchedule(true);
			thirdPartyPayment
					.setScheduleDetails(populateScheduleDetails(request.getScheduleID(), commonData, request.getScheduleDetail(), request.getSendEmail(), request.getPayerName()));
		} else {
			thirdPartyPayment.setSchedule(false);
		}
		
		if (request.getFavTranID()!=null) thirdPartyPayment.setFavTranId(request.getFavTranID());
		thirdPartyPayment.setOrigination(request.getOrigination());
		//thirdPartyPayment.setRetryDEConsent(false);
		//set the OnUs flag true if it is OnUs payment
		if (ONUS.equals(mobileSession.getPaymentType())){
			thirdPartyPayment.setOnUsTransfer(true);
		}else{
			thirdPartyPayment.setOnUsTransfer(false);
		}
		
		if (null != mobileSession && Boolean.TRUE.equals(mobileSession.isResubmitPayment())){
			thirdPartyPayment.setResubmitPayment(true);
		}
		//SBGEXP-6271 
		//set the OnUs check condition is not done in case of no payment type.
		/*if (null == mobileSession.getPaymentType()) {
			thirdPartyPayment.setOnUsTransferCheckDone(false);
		} else {
			thirdPartyPayment.setOnUsTransferCheckDone(true);
		}*/
		return thirdPartyPayment;
	}
	
	protected NPPPayment populateNPPPayment(Account fromAccount, Customer customer, IBankCommonData commonData, PayeeTransferReq request, MobileSession mobileSession)
			throws BusinessException, DatatypeConfigurationException {
		NPPPayment nppPayment = new NPPPayment();
		nppPayment.setBatch(false);
		nppPayment.setCommonData(commonData);
		nppPayment.setFromAccount(fromAccount.getAccountId());
		nppPayment.setFromAccoutBrand(fromAccount.getBrand());
		nppPayment.setFlEmailCopy(Boolean.TRUE.equals(request.getSendEmail())
				&& request.getPayeeEmail() != null && request.getPayeeEmail().length() > 0);
		//PayId payment
		PayIDResolution payIDResolution = mobileSession.getPayIDResolution();
		if(payIDResolution != null && payIDResolution.isPayIDResolutionStatus()){
			Logger.debug("PayeeHelper.populateNPPPayment() : PayID Resolved. Populating PAYID Values ", this.getClass());
			PayIdThirdParty payIDTP =  new PayIdThirdParty();
			payIDTP.setPayIDType(payIDResolution.getPayIDType());
			
			if(!StringMethods.isEmptyString(payIDTP.getPayIDType()) && payIDTP.getPayIDType().equalsIgnoreCase(NPPUtil.EMAL)){
				payIDTP.setPayID(payIDResolution.getPayIDValue().trim().toLowerCase());
			}else{
				payIDTP.setPayID(payIDResolution.getPayIDValue());
			}
			payIDTP.setBsb(payIDResolution.getIssuer());
			payIDTP.setBankSetup(false);
			payIDTP.setNumber(payIDResolution.getAccountNumber());
			payIDTP.setAccountNumOsko(payIDResolution.getAccountNumber());
			payIDTP.setTrusted(IBankSecureService.NOT_TRUSTED_STATUS);
			if (payIDResolution.isIs2FAdone()) {
				payIDTP.setTrusted(IBankSecureService.TRUSTED_STATUS);
			} else {
				if(IBankParams.isNPPPayIdAddressBookSwitchON(commonData.getOrigin())) {
					for (NPPPayIdPayee nppPayIdPayee : customer.getNppPayIdPayees()) {
						if (nppPayIdPayee.getPayId().equals(payIDResolution.getPayIDValue())
								&& nppPayIdPayee.getPayIdType().equals(payIDResolution.getPayIDTypeOrig())
								&& nppPayIdPayee.getTrusted().equals(NPPPayIdPayee.TRUSTED_STATUS)) {
							payIDTP.setTrusted(NPPPayIdPayee.TRUSTED_STATUS);
							break;
						}
					}
				}
			}
			payIDTP.setName(payIDResolution.getShortName());
			nppPayment.setPayIDResultion(payIDResolution);
			nppPayment.setToThirdParty(payIDTP);
			
		} else {
			Logger.debug("PayeeHelper.populateNPPPayment() : Not a PayID payment ", this.getClass());
			nppPayment.setToThirdParty(customer.getThirdParties().get(request.getToPayeeIndex()));
		}
		// override third party email
		nppPayment.getToThirdParty().setEmailPayee(request.getPayeeEmail());
		
		nppPayment.getToThirdParty().setPayerName(request.getPayerName());
		if (nppPayment.getToThirdParty().getPayerName()==null){
			nppPayment.getToThirdParty().setPayerName("");
		}
		nppPayment.setAmount(new BigDecimal(request.getAmt()));
		nppPayment.setDescription(request.getDesc());
		if (nppPayment.getDescription()==null){
			nppPayment.setDescription("");
		}
		
		if(IBankParams.isNPPEndToEndIdSwitchON(commonData.getOrigin())) {
			if(ibankRefreshParams.isNPPBugFixSwitchOn()) {
				nppPayment.setEndToEndId(!StringMethods.isEmptyString(request.getEndToEndID()) ? request.getEndToEndID().trim() : request.getEndToEndID());
			}else {
				nppPayment.setEndToEndId(request.getEndToEndID());
			}
		}
		
		nppPayment.setIpAddress(commonData.getIpAddress());
		nppPayment.setSessionId(commonData.getSessionId());
		nppPayment.setBrand(commonData.getOrigin());
		nppPayment.setCheckForDuplicate(true);
		if (request.getOverrideDup() != null)
			nppPayment.setCheckForDuplicate(!request.getOverrideDup());
		if (request.getDupCount() != null)
			nppPayment.setDuplicatePaymentCount(request.getDupCount());
		nppPayment.setPayerName(request.getPayerName());
		if (nppPayment.getPayerName()==null){
			nppPayment.setPayerName("");
		}		
		nppPayment.setNewThirdParty(false);
		nppPayment.setSchedule(false);
		
		if (request.getFavTranID()!=null) nppPayment.setFavTranId(request.getFavTranID());
		nppPayment.setOrigination(request.getOrigination());
		//nppPayment.setRetryDEConsent(request.isRetryDEConsent());
		//set the OnUs flag true is it is OnUs payment
		if (ONUS.equals(mobileSession.getPaymentType())){
			nppPayment.setOnUsTransfer(true);
		}else{
			nppPayment.setOnUsTransfer(false);
		}
		
		Logger.debug("Payee Email  " + request.getPayeeEmail() + " Payer :  " + request.getSendEmail() +  " Payeee "+ request.getSendPayeeEmail(), this.getClass());
        if (request.getSendPayeeEmail() != null ){
        	nppPayment.setEmailPayee(request.getSendPayeeEmail().booleanValue());
        }
        if ( request.getSendEmail()  != null ){
        	nppPayment.setEmailPayer(request.getSendEmail().booleanValue());
        }
        //21E1 Npp Enrichment API details
        NPPEnrichmentDetails nppEnrichmentDetailsVO = mobileSession.getNPPEnrichmentDetails();
        if(nppEnrichmentDetailsVO != null) {
			nppPayment.setFlan(nppEnrichmentDetailsVO.getFlan());
			nppPayment.setDebtorAddress(nppEnrichmentDetailsVO.getDebtorAddress());
			nppPayment.setDebtorCustomerType(nppEnrichmentDetailsVO.getDebtorCustomerType());
			nppPayment.setDebtorDOB(nppEnrichmentDetailsVO.getDebtorDOB());
			nppPayment.setDebtorIdentifier(nppEnrichmentDetailsVO.getDebtorIdentifier());
			nppPayment.setDebtorIssuer(nppEnrichmentDetailsVO.getDebtorIssuer());
			nppPayment.setDebtorName(nppEnrichmentDetailsVO.getDebtorName());
        }

		return nppPayment;
	}

	/**
	 * Populate ThirdParty VO
	 * 
	 * @param payeeBean
	 * @param payerName
	 * @return
	 */
	protected ThirdParty populateThirdParty(AddPayeeReq payeeBean, String payerName) {
		ThirdParty thirdParty = new ThirdParty();
		thirdParty.setBsb(payeeBean.getPayeeAccountKeyInfo().getBsb());
		thirdParty.setNumber(StringUtil.padLeadingString(payeeBean.getPayeeAccountKeyInfo().getAccountNum(), ThirdParty.TPY_MIN_ACCOUNT_LEN,
				ThirdParty.TPY_ACCOUNT_PADDING_CHAR));
		thirdParty.setName(payeeBean.getPayeeAccountKeyInfo().getAccountName());
		thirdParty.setEmailPayee(payeeBean.getPayeeEmail());
		thirdParty.setSavedThirdPartyStatus(ThirdParty.NEWLY_SAVED_THIRD_PARTY);
		thirdParty.setDeleteFlag(ThirdParty.THIRD_PARTY_NOT_DELETED);
//		thirdParty.setCreatedBy(commonData.getUser().getUserId());
//		thirdParty.setLastUpdatedBy(commonData.getUser().getUserId());
		thirdParty.setAccountNumOsko(payeeBean.getPayeeAccountKeyInfo().getAccountNum());
		thirdParty.setBankSetup(false);
		thirdParty.setPayerName(payerName);
		return thirdParty;
	}

	/**
	 * Check for Old internal group account
	 * @param AddPayeeReq payeeBean
	 *
	 */
	public boolean isOldFormatStgAcct(AddPayeeReq payeeBean){
		boolean oldFormatStgAcct=false;
		if(payeeBean!=null && payeeBean.getPayeeAccountKeyInfo().getBsb()!=null){
			String bsb=payeeBean.getPayeeAccountKeyInfo().getBsb();
			if(StringUtil.isInternalAcct(bsb)){
				if(payeeBean.getPayeeAccountKeyInfo().getAccountNum()!=null 
						&& payeeBean.getPayeeAccountKeyInfo().getAccountNum().length() < 9){
					oldFormatStgAcct=true;
				}
			}
		}		
		return oldFormatStgAcct;
	}
	
	/**
	 * Populate service response - add payee
	 * 
	 * @param header
	 * @param duplicates
	 * @return
	 */
	protected AddPayeeResp populateAddPayeeResp(RespHeader header, List<ThirdParty> payeeList, ThirdParty newPayee) {
		AddPayeeResp response = new AddPayeeResp(header);
		int i = 0;
		response.setNewPayeeIndex("");
		for (ThirdParty tp : payeeList) {
			if (newPayee.getBsb().trim().equals(tp.getBsb().trim()) 
					&& newPayee.getNumber().trim().equals(tp.getNumber().trim())) {
				response.setNewPayeeIndex(String.valueOf(i));
				break;
			}
			i++;
		}
		Logger.info("PayeeHelper. response.getNewPayeeIndex = " + response.getNewPayeeIndex(), this.getClass());
		response.setPayees(MBAppHelper.populatePayees(payeeList));
		Logger.debug("PayeeHelper. Response populated: " + response, this.getClass());
		return response;
	}
	
	
	/**
	 * Populate service response - delete payee
	 * 
	 * @param header
	 * @param duplicates
	 * @return
	 */
	protected DeletePayeeResp populateDeletePayeeResp(RespHeader header, List<ThirdParty> payeeList) {
		DeletePayeeResp response = new DeletePayeeResp(header);
		response.setPayees(MBAppHelper.populatePayees(payeeList));
		Logger.debug("PayeeHelper. Response populated: " + response, this.getClass());
		return response;
	}
	
	/**
	 * Populate service response - delete payId payee
	 * 
	 * @param header - RespHeader
	 * @param payeeList - ArryList
	 * @return DeletePayIdPayeeResp
	 */
	protected DeletePayIdPayeeResp populateDeletePayIdPayeeResp(RespHeader header, List<NPPPayIdPayee> payeeList) {
		DeletePayIdPayeeResp response = new DeletePayIdPayeeResp(header);
		response.setPayIdPayees(MBAppHelper.populatePayIdPayeesList(payeeList));
		Logger.debug("PayeeHelper. Response populated: " + response, this.getClass());
		return response;
	}
	
	/**
	 * Populate service response - payee receipts
	 * 
	 * @param header
	 * @param duplicates
	 * @return
	 */
	protected PayeeReceiptsResp populatePayeeReceiptsResp(RespHeader header, List<PaymentsLog> payments, List<Account> accounts) {
		PayeeReceiptsResp response = new PayeeReceiptsResp(header);
		response.setReceipts(convertToReceipts(payments, accounts));
		Logger.info("Response: " + response, this.getClass());
		return response;
	}
	
	protected BPayReceiptsResp populateBPayReceiptsResp(RespHeader header, List<PaymentsLog> payments, List<Account> accounts,String bPayName, String bPayAlias) {
		BPayReceiptsResp response = new BPayReceiptsResp(header);
		response.setBpayAlias(bPayAlias);
		response.setBpayName(bPayName);
		response.setReceipts(convertToBPayReceipts(payments, accounts));
		Logger.info("Response: " + response, this.getClass());
		return response;
	}
	
	/**
	 * Populate service response - delete payee
	 * 
	 * @param header
	 * @param duplicates
	 * @return
	 */
	protected IncreasePayeeLimitResp populateIncreasePayeeLimitResp(RespHeader header, String requestId, boolean isPending) {
		IncreasePayeeLimitResp response = new IncreasePayeeLimitResp(header);
		if (!isPending) {
			response.setSuccess(requestId != null && !"".equals(requestId));
		} else {
			response.setRequestPending(true);
		}
		Logger.info("PayeeHelper. Response populated: " + response, this.getClass());
		return response;
	}
	
	private List<HistoryReceiptDetailResp> convertToReceipts(List<PaymentsLog> payments, List<Account> accounts) {
		List<HistoryReceiptDetailResp> history = new ArrayList<HistoryReceiptDetailResp>();
		for (PaymentsLog payment: payments){
			
			Account fromAccount = MBAppHelper.getAccountByAccountNumber(accounts, payment.getAccountNumberFrom());
			
			HistoryReceiptDetailResp receipt = new HistoryReceiptDetailResp();
			receipt.setAmt(String.valueOf(payment.getAmount()));
			receipt.setTranDateTime(payment.getHostTimestamp());
			receipt.setStatus(payment.getStatusDescription());
			receipt.setDesc(payment.getReferenceNumber());
			if(null != payment.getReceiptNumber())
				receipt.setReceiptNumDisp(MBAppUtils.formatReceiptNumber(payment.getReceiptNumber()));
			receipt.setPaymentLogId(payment.getId());
			
			receipt.setFromAccountName(payment.getFromAccountAlias());
			receipt.setFromAccountNumDisp(payment.getAccountNumberFrom());
			
			if (fromAccount != null) {
				receipt.setFromAccountNumDisp(new MBAppHelper().getFormattedAcctNumber(fromAccount.getAccountId().getAccountNumber(), fromAccount
						.getAccountId().getApplicationId(), fromAccount.getAccountId().getBsb()));
				receipt.setFromAccountName(fromAccount.getAlias());
			}
			
			receipt.setFromBsbDisp(fromAccount.getAccountId().getBsb());
			
			receipt.setCanAddToFavourite(true);
			
			history.add(receipt);
		}
		return history;
	}
	
	private List<HistoryReceiptDetailResp> convertToBPayReceipts(List<PaymentsLog> payments, List<Account> accounts) {
		List<HistoryReceiptDetailResp> history = new ArrayList<HistoryReceiptDetailResp>();
		for (PaymentsLog payment: payments){
			
			Account fromAccount = MBAppHelper.getAccountByAccountNumber(accounts, payment.getAccountNumberFrom());
			
			HistoryReceiptDetailResp receipt = new HistoryReceiptDetailResp();
			receipt.setAmt(String.valueOf(payment.getAmount()));
			receipt.setTranDateTime(payment.getHostTimestamp());
			receipt.setStatus(payment.getStatusDescription());
			receipt.setDesc(payment.getReferenceNumber());
			if(null != payment.getReceiptNumber())
				receipt.setReceiptNumDisp(MBAppUtils.formatReceiptNumber(payment.getReceiptNumber()));
			receipt.setPaymentLogId(payment.getId());
			
			receipt.setFromAccountName(payment.getFromAccountAlias());
			receipt.setFromAccountNumDisp(payment.getAccountNumberFrom());
			
			if (fromAccount != null) {
				receipt.setFromAccountNumDisp(new MBAppHelper().getFormattedAcctNumber(fromAccount.getAccountId().getAccountNumber(), fromAccount
						.getAccountId().getApplicationId(), fromAccount.getAccountId().getBsb()));
				receipt.setFromAccountName(fromAccount.getAlias());
			}
			if(fromAccount.getAccountId().getBsb()!=null) {
				receipt.setFromBsbDisp(fromAccount.getAccountId().getBsb());
			}
			else {
				receipt.setFromBsbDisp("");
			}
			receipt.setCanAddToFavourite(true);
			receipt.setBillerAlias(payment.getDescription());
			receipt.setBillerCode(payment.getBillerCode());
			receipt.setCrn(payment.getReferenceNumber());
			history.add(receipt);
		}
		return history;
	} 
	
	
	/**
	 * Additional validation for add payee request
	 * 
	 * @param payeeBean
	 * @throws BusinessException
	 */
	protected void validatePayeeReq(AddPayeeReq payeeBean) throws BusinessException {

		if (payeeBean.getPayeeAccountKeyInfo() == null)
			throw new BusinessException(BusinessException.ACCOUNT_NO_THIRD_PARTY_BSB);

		if (!StringUtil.isNameValid(payeeBean.getPayeeAccountKeyInfo().getAccountName().trim(), TPY_MAX_NAME_LEN)) {
			throw new BusinessException(BusinessException.INVALID_NAME);
		}
		// check for submitted account number
		String tpAcctNumber = payeeBean.getPayeeAccountKeyInfo().getAccountNum();
		tpAcctNumber = tpAcctNumber.trim().replaceAll(" ", "");

		if (StringMethods.isEmptyString(tpAcctNumber)) {
			throw new BusinessException(BusinessException.ACCOUNT_NO_THIRD_PARTY_ACCT);
		}
		if (!StringUtil.isNumberValid(StringMethods.safeString(tpAcctNumber, ""), ThirdParty.TPY_MAX_ACCOUNT_LEN, LENGTH_NOT_EXACT)) {
			throw new BusinessException(BusinessException.ACCOUNT_INVALID_THIRD_PARTY_ACCT);
		}
		try {
			Long.parseLong(tpAcctNumber);
		} catch (NumberFormatException e) {
			throw new BusinessException(BusinessException.ACCOUNT_INVALID_THIRD_PARTY_ACCT, "Invalid account number");
		}
		Logger.debug("Third party account number length in validatePayeeReq():"+tpAcctNumber.length(), getClass());
		if (tpAcctNumber.length() < 1 || tpAcctNumber.length() > 9) {
			throw new BusinessException(BusinessException.ACCOUNT_INVALID_THIRD_PARTY_ACCT);
		}
		// check for submitted bsb
		String payeeBsb = payeeBean.getPayeeAccountKeyInfo().getBsb();
		if (StringMethods.isEmptyString(payeeBsb)) {
			throw new BusinessException(BusinessException.ACCOUNT_NO_THIRD_PARTY_BSB);
		} else {
			payeeBsb = payeeBsb.trim().replaceAll("-", "");
			payeeBsb = payeeBsb.replaceAll(" ", "");
			try {
				Integer.parseInt(payeeBsb);
			} catch (NumberFormatException e) {
				throw new BusinessException(BusinessException.ACCOUNT_INVALID_BSB);
			}
		}

		if (!BSBService.isValidBSB(payeeBean.getPayeeAccountKeyInfo().getBsb())) {
			throw new BusinessException(BusinessException.ACCOUNT_INVALID_BSB);
		} else if (StringMethods.isEmptyString(payeeBean.getPayeeAccountKeyInfo().getAccountNum())) {
			throw new BusinessException(BusinessException.ACCOUNT_NO_THIRD_PARTY_ACCT);

		} else if (StringMethods.isEmptyString(payeeBean.getPayeeAccountKeyInfo().getAccountName())) {
			throw new BusinessException(BusinessException.ACCOUNT_NO_THIRD_PARTY_NAME);

		} else if (!StringUtil.isNameValid(StringMethods.safeString(payeeBean.getPayeeAccountKeyInfo().getAccountName(), ""),
				ServiceConstants.THIRDPARTY_MAX_NAME_LEN)) {
			throw new BusinessException(BusinessException.INVALID_NAME);
		}

		if (StringMethods.isEmptyString(payeeBean.getPayeeAccountKeyInfo().getBsb())) {
			throw new BusinessException(BusinessException.ACCOUNT_NO_THIRD_PARTY_BSB);
		} else {
			if (payeeBean.getPayeeAccountKeyInfo().getBsb().length() != ServiceConstants.BSB_LENGTH) {
				throw new BusinessException(BusinessException.ACCOUNT_INVALID_BSB);
			} else {
				try {
					Integer.parseInt(payeeBean.getPayeeAccountKeyInfo().getBsb());
				} catch (NumberFormatException e) {
					throw new BusinessException(BusinessException.ACCOUNT_INVALID_BSB);
				}
			}
		}

	}

	/**
	 * Additional validation for payee transfer request
	 * 
	 * @param payeeBean
	 * @throws BusinessException
	 */
	protected void validatePayeeTransferReq(PayeeTransferReq req) throws BusinessException {
		if (req.getScheduleDetail() != null) validateTransferSchedule(req.getScheduleDetail());
	}
	
	public long getInsertionPointCode(String insertionPointString){
		List<CodesVO> CodesVOList = (List<CodesVO>) IBankParams.getCodesDataList(IBankParams.DEFAULT_ORIGIN, ServicetationConstants.CD_CATEGORY_SERVICETATION_INSERTION_PT);
		long insertionPointValue = 0;
		for(CodesVO codesVO : CodesVOList){
			if(codesVO.getMessage().trim().equalsIgnoreCase(insertionPointString)){
				if(StringMethods.isValidString(codesVO.getCode())){
					insertionPointValue = Long.parseLong(codesVO.getCode());
					break;
				}
			}
		}
		if(insertionPointValue == 0){
			Logger.warn("NO match found in RELEASECODES table for the insertion point "+insertionPointString, this.getClass());
		}
		return insertionPointValue;
	}
	
	
	protected ResolvePayIdResp populateResolvePayIdResp(RespHeader header,PayIDResolution payIDResolution, String payIdType, boolean isNameChanged) {
		Logger.info("PayeeHelper.populateResolvePayIdResp():Start ", this.getClass());
	
		ResolvePayIdResp resolvePayIdResponse = new ResolvePayIdResp(header);

		if(payIDResolution != null && payIDResolution.isPayIDResolutionStatus()){
			resolvePayIdResponse.setPayId(payIDResolution.getPayIDValue());
			resolvePayIdResponse.setPayIdDisp(NPPUtil.getFormattedPayID(payIDResolution.getPayIDValue(), payIdType, false));
			resolvePayIdResponse.setPayIdName(payIDResolution.getShortName());
			resolvePayIdResponse.setSuccess(true);
			resolvePayIdResponse.setNameChanged(isNameChanged);
			resolvePayIdResponse.setPayIdType(payIdType);
		}else{
			resolvePayIdResponse.setSuccess(false);
		}
		Logger.info("PayeeHelper.populateResolvePayIdResp(): End.", this.getClass());
		
		return resolvePayIdResponse;
	}

	protected PayToPayIdLandingPageResp populatePayIdLandingPageResp(RespHeader header, IBankCommonData commonData, PayIdPaymentSwitchParams payIdPaymentSwitchParams) throws BusinessException{
		Logger.info("PayeeHelper.populatePayIdLandingPageResp():Start ", this.getClass());
		
		PayToPayIdLandingPageResp payToPayIdLandingPageResp = new PayToPayIdLandingPageResp(header);
		
		List<CodesVO> payIdTypeCodes = (List<CodesVO>)(IBankParams.getCodesDataList(commonData.getOrigin(), PAY_ID_TYPES));
		List<LabelValueVO> payIdTypeList = new ArrayList<LabelValueVO>(payIdTypeCodes.size()+1);
		for(int i=0;i<payIdTypeCodes.size()+1;i++) {
			payIdTypeList.add(i, null);
		}
		
		Iterator<CodesVO> iterator = payIdTypeCodes.iterator();
		while (iterator.hasNext()) {
			CodesVO codesVO = (CodesVO)iterator.next();
			int position = Integer.parseInt(codesVO.getCode().substring(0,1));
			LabelValueVO bean = new LabelValueVO(codesVO.getMessage(),codesVO.getCode().substring(2));
			payIdTypeList.set(position, bean);
		}
		
		//	Removing first element from list because default select dropdown value will be handled at UI
		payIdTypeList.remove(0);
		
		payToPayIdLandingPageResp.setPayIDTypeList(payIdTypeList);
		payToPayIdLandingPageResp.setPayIDCountryList(getPayIdCountryMBDropdownList(commonData.getOrigin()));
		
		Logger.info("PayeeHelper.populatePayIdLandingPageResp():End ", this.getClass());
		
		return payToPayIdLandingPageResp;
	}
	
	/**
	 * This method checks for SAFI pay to payid switch, heartbeat and throttling
	 * @param thirdPartyPayment
	 * @param sessionInfo
	 * @return
	 */
	public static boolean isSafiCallAllowed(ThirdPartyPayment thirdPartyPayment, String paymentType) {
		boolean isSafiCallAllowed = false;
		Logger.debug("Checking if safi call is allowed or not for "+paymentType+" payment", PayeeHelper.class);
		if(IBankParams.isSwitchOn(IBankParams.getBaseOriginCode(thirdPartyPayment.getCommonData().getOrigin()), IBankParams.SAFI_PAY_TO_PAYID_PAYMENT_SWITCH)
				&& HeartBeat.isApplicationAvailable(HeartBeat.SAFI2_SERVICE_APPLICATION)) {
			isSafiCallAllowed = true;
		}
			
		try {
			if(isSafiCallAllowed) {
				MemoryThrottlingService throttleService = ServiceHelper.getBean("memoryThrottlingService");
				isSafiCallAllowed = throttleService.processThrottling(IBankParams.THROTTLE_CAT_PAY_TO_PAYID_PAYMENT, thirdPartyPayment.getCommonData().getCustomer().getGcis(), thirdPartyPayment.getSessionId());
			}
		} catch(Exception e) {
			Logger.warn("SAFI : Exception occured in throttle service in PayeeHelper.isSafiCallAllowed() "+e, PayeeHelper.class);					
		}
		return isSafiCallAllowed;
	}
	
	public PayeesAndBillersListResp populateAllTypePayeesList(IBankCommonData commonData, Customer customer) throws ResourceException, BusinessException{
		PayeesAndBillersListResp resp = new PayeesAndBillersListResp();
		List<ThirdParty> myThirdPartyList;
		List<Biller> myBillerList;
		List<NPPPayIdPayee> myPayIdPayeeList = null;
		if (customer == null){
			Logger.error("populateAllTypePayeesList: Customer null! Session issue!", PayeeHelper.class);
			return resp;
		}
		//TODO get back to the condition to add the PayID is already loaded	
		if(customer.getBillers() == null || customer.getThirdParties() == null || ((customer.getBillers() != null && customer.getBillers().size() == 0) && (customer.getThirdParties() != null && customer.getThirdParties().size() == 0))){
			myThirdPartyList = CustomerService.getThirdPartyList(commonData, commonData.getUser().getGCISNumber());
			myThirdPartyList = MobileBankServiceImpl.trimAccountList(myThirdPartyList, MobileBankServiceImpl.MAX_TP_CODE);
			myBillerList = CustomerService.getBillerList(commonData, commonData.getUser().getGCISNumber());
			myBillerList = MobileBankServiceImpl.trimAccountList(myBillerList,MobileBankServiceImpl.MAX_BILLER_CODE);
			if(IBankParams.isNPPPayIdAddressBookSwitchON(commonData.getOrigin())) { //set NPPayIdPayees only if Switch is ON
				myPayIdPayeeList = CustomerService.getPayIdPayeeList(commonData, commonData.getUser().getGCISNumber());
				//TODO check if the MAX_TP_CODE needs to change for Pay to PayId address book
				myPayIdPayeeList = MobileBankServiceImpl.trimAccountList(myPayIdPayeeList,MobileBankServiceImpl.MAX_TP_CODE);
				customer.setNppPayIdPayees(myPayIdPayeeList);
			}
			customer.setBillers(myBillerList);
			customer.setThirdParties(myThirdPartyList);
		}
		else{
			myThirdPartyList = customer.getThirdParties();
			myBillerList = customer.getBillers();
			myPayIdPayeeList = customer.getNppPayIdPayees();
		}
		resp.setThirdPartyPayees(MBAppHelper.populatePayees(myThirdPartyList));
		resp.setBillers(MBAppHelper.populateBillerList(myBillerList));
		resp.setPayIdPayees(MBAppHelper.populatePayIdPayeesList(myPayIdPayeeList));
		return resp;
	}
	
	public PayeesAndBillersListResp populateAllTypePayeesListAsync(IBankCommonData commonData, MobileSession mobileSession) throws ResourceException, BusinessException{
		PayeesAndBillersListResp resp = new PayeesAndBillersListResp();
		List<ThirdParty> myThirdPartyList;
		List<Biller> myBillerList;
		List<NPPPayIdPayee> myPayIdPayeeList;
		Customer customer = mobileSession.getCustomer();
		if (customer == null){
			Logger.error("populateAllTypePayeesList: Customer null! Session issue!", PayeeHelper.class);
			return resp;
		}
		myThirdPartyList = CustomerService.getThirdPartyList(commonData, commonData.getUser().getGCISNumber());
		myThirdPartyList = MobileBankServiceImpl.trimAccountList(myThirdPartyList, MobileBankServiceImpl.MAX_TP_CODE);
		myBillerList = CustomerService.getBillerList(commonData, commonData.getUser().getGCISNumber());
		myBillerList = MobileBankServiceImpl.trimAccountList(myBillerList,MobileBankServiceImpl.MAX_BILLER_CODE);
		if(IBankParams.isNPPPayIdAddressBookSwitchON(commonData.getOrigin())) {//Set PayIdPayees List only if Switch is ON
			myPayIdPayeeList = CustomerService.getPayIdPayeeList(commonData, commonData.getUser().getGCISNumber());
			myPayIdPayeeList = MobileBankServiceImpl.trimAccountList(myPayIdPayeeList,MobileBankServiceImpl.MAX_TP_CODE);
			customer.setNppPayIdPayees(myPayIdPayeeList);
			resp.setPayIdPayees(MBAppHelper.populatePayIdPayeesList(myPayIdPayeeList));
		}
		//TODO check if the MAX_TP_CODE needs to change for Pay to PayId address book
		customer.setBillers(myBillerList);
		customer.setThirdParties(myThirdPartyList);
		mobileSession.setCustomer(customer);
		resp.setThirdPartyPayees(MBAppHelper.populatePayees(myThirdPartyList));
		resp.setBillers(MBAppHelper.populateBillerList(myBillerList));
		return resp;
	}
	
	/**
	 * @param commonData - CommonData
	 * @param tranName - String
	 * @param status - String
	 * @param commonLogData - String
	 * @param userAgent - String
	 * @return
	 */
	public DigitalSecLogggerVO initializeDigitalLogger(IBankCommonData commonData, String tranName, String status, String commonLogData) {
		DigitalSecLogggerVO digitalSecurityLogVO = new DigitalSecLogggerVO();
		digitalSecurityLogVO.setUserAgent(commonData.getUserAgent());
		digitalSecurityLogVO.setCommonLogData(commonLogData);
		digitalSecurityLogVO.setTranName(tranName);
		digitalSecurityLogVO.setStatus(status);
		return digitalSecurityLogVO;
	}

	public SuccessResp populateDeccreasePayeeLimitResp(RespHeader header, int count) {
		SuccessResp response = new SuccessResp();
		response.setHeader(header);
		if(count==1){
			response.setIsSuccess(true);
		}else{
			response.setIsSuccess(false);
		}
		Logger.info("Decrease Payee Limit response populated: " + response, this.getClass());
		return response;
	}
	
	public SuccessResp populateValidateBicResp(RespHeader header, boolean isActive) {
		SuccessResp response = new SuccessResp();
		response.setHeader(header);
		if(isActive){
			response.setIsSuccess(true);
		}else{
			response.setIsSuccess(false);
		}
		Logger.info("ValidateBic response populated: " + response, this.getClass());
		return response;
	}
	
	protected boolean isPayIDPayment(ThirdPartyPayment payment) {
		if (payment instanceof NPPPayment && null != ((NPPPayment)payment).getPayIDResultion()) {
			return true;
		}else {
			return false;
		}
	}
	
	protected void populatePayIdPayeeResp(Receipt receipt, TransferResp response, IBankCommonData commonData) {
		if (null != ((TransactionReceipt) receipt).getPayIdPayee()){
			response.setPayIdPayees(MBAppHelper.populatePayIdPayeesList(commonData.getCustomer().getNppPayIdPayees()));
		}
	}
	
	/**
	 * Method to populate country dropdown list for pay id payments from release codes table
	 * @param origin
	 * @return
	 */
	public List<PayIDCountry> getPayIdCountryMBDropdownList(String origin) {
		Logger.debug("NPPUtil - Start of getPayIdCountryMBDropdownList(). method", NPPUtil.class);
		
		List<CodesVO> countryListCodes = (List<CodesVO>)(IBankParams.getCodesDataList(origin, PAYID_PAYMENT_COUNTRY_DROPDOWN_CODE));
		int dropDownSize = countryListCodes.size();
		
		List<PayIDCountry> countryList = new ArrayList<PayIDCountry>(dropDownSize);
		Logger.debug("dropDownSize:" + countryList.size(), NPPUtil.class);
		for(int i=0;i<dropDownSize;i++) {
			countryList.add(i, null);
		}
		
		Iterator<CodesVO> iterator = countryListCodes.iterator();
		
		while (iterator.hasNext()) {
			CodesVO codesVO = (CodesVO)iterator.next();
			PayIDCountry payIdCountry = new PayIDCountry();
			Logger.debug("NPPUtil - End of getPayIdCountryMBDropdownList(). method: size of country dropdown with default label:" + countryList.size()  , NPPUtil.class);
			int position = Integer.parseInt(codesVO.getCode().substring(0, codesVO.getCode().indexOf("_")));
			StringBuffer countryIdBuffer ;
			if(codesVO.getMessage().equals("Other")) {
				countryIdBuffer = new StringBuffer("+");
			}else {
				countryIdBuffer = new StringBuffer("+").append(codesVO.getCode().substring(codesVO.getCode().indexOf("_")+1));
			}
			payIdCountry.setId(countryIdBuffer.toString());
			payIdCountry.setLabel(codesVO.getMessage());
			countryList.set(position-1,payIdCountry);
		}
		
		Logger.debug("NPPUtil - End of getPayIdCountryMBDropdownList(). method: size of country dropdown with default label:" + countryList.size(), NPPUtil.class);
		
		return countryList;
	}
	
	public NPPPayIdPayee getPayIDPayee(String payIdType, String payIdValue, Customer customer) {
		List<NPPPayIdPayee> nppPayIds = customer.getNppPayIdPayees();
		NPPPayIdPayee payIDPayee = null;
		if(!StringMethods.isEmptyString(payIdType) && !StringMethods.isEmptyString(payIdValue) ) {
			String payId = payIdValue.trim();
			for(NPPPayIdPayee eachPayee : nppPayIds) {
				if(eachPayee.getPayIdType().equals(payIdType) && eachPayee.getPayId().equalsIgnoreCase(payId)) {
					payIDPayee = eachPayee;
					break;
				}
			}
		}
		return payIDPayee;
	}
	
	public void populatePayees(IBankCommonData commonData, Customer customer) throws ResourceException, BusinessException{
		List<ThirdParty> myThirdPartyList;
		if(customer.getThirdParties() == null || (customer.getThirdParties() != null && customer.getThirdParties().size() == 0)) {
			myThirdPartyList = CustomerService.getThirdPartyList(commonData, commonData.getUser().getGCISNumber());
			myThirdPartyList = MobileBankServiceImpl.trimAccountList(myThirdPartyList, MobileBankServiceImpl.MAX_TP_CODE);
			customer.setThirdParties(myThirdPartyList);
			if (myThirdPartyList!=null && myThirdPartyList.size()>0) {
				Logger.warn("populatePayees: fallback to populate Third Parties size: " +  myThirdPartyList.size(), this.getClass());	
			}
		}
	}
	
	public void populatePayIdPayees(IBankCommonData commonData, Customer customer) throws ResourceException, BusinessException{
		List<NPPPayIdPayee> myPayIdPayeeList;
		if(IBankParams.isNPPPayIdAddressBookSwitchON(commonData.getOrigin()) && (customer.getNppPayIdPayees() == null || (customer.getNppPayIdPayees() != null && customer.getNppPayIdPayees().size() == 0))) {
			myPayIdPayeeList = CustomerService.getPayIdPayeeList(commonData, commonData.getUser().getGCISNumber());
			myPayIdPayeeList = MobileBankServiceImpl.trimAccountList(myPayIdPayeeList,MobileBankServiceImpl.MAX_TP_CODE);
			customer.setNppPayIdPayees(myPayIdPayeeList);
			if (myPayIdPayeeList!=null && myPayIdPayeeList.size()>0) {
				Logger.warn("populatePayIdPayees: fallback to populate PayId Payees size: " +  myPayIdPayeeList.size(), this.getClass());	
			}
		}
	}
	
	public NPPEnrichmentDetails populateNPPEnrichmentDetailsVO(NPPValidations nppValidationsVO) {
		NPPEnrichmentDetails nppEnrichmentDetailsVO = new NPPEnrichmentDetails();
		nppEnrichmentDetailsVO.setAmount(nppValidationsVO.getAmount());
		nppEnrichmentDetailsVO.setFromAccount(nppValidationsVO.getFromAccount());
		nppEnrichmentDetailsVO.setPayerName(nppValidationsVO.getPayerName());
		nppEnrichmentDetailsVO.setToAccountBsb(nppValidationsVO.getToAccountBsb());
		nppEnrichmentDetailsVO.setToAccountNumber(nppValidationsVO.getToAccountNumber());
		return nppEnrichmentDetailsVO;
	}
}