package au.com.stgeorge.mbank.model.request.customer.ev;

import java.io.Serializable;
import java.util.List;

public class ReIDVInfo implements Serializable{
	private static final long serialVersionUID = 5175983021982211784L;
	private String otherName;
	private List<String> sourceOfWealth;
	private List<String> sourceOfFunds;
	private List<String> products;
	private String empType;
	private String occupation;
	
	public List<String> getSourceOfWealth() {
		return sourceOfWealth;
	}
	public void setSourceOfWealth(List<String> sourceOfWealth) {
		this.sourceOfWealth = sourceOfWealth;
	}
	public List<String> getSourceOfFunds() {
		return sourceOfFunds;
	}
	public void setSourceOfFunds(List<String> sourceOfFunds) {
		this.sourceOfFunds = sourceOfFunds;
	}
	public List<String> getProducts() {
		return products;
	}
	public void setProducts(List<String> products) {
		this.products = products;
	}
	public String getOtherName() {
		return otherName;
	}
	public void setOtherName(String otherName) {
		this.otherName = otherName;
	}
	public String getEmpType() {
		return empType;
	}
	public void setEmpType(String empType) {
		this.empType = empType;
	}
	public String getOccupation() {
		return occupation;
	}
	public void setOccupation(String occupation) {
		this.occupation = occupation;
	}
	
}
