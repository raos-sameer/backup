package au.com.stgeorge.mbank.controller.offers;


import au.com.stgeorge.mbank.model.common.IMBResp;
import au.com.stgeorge.mbank.model.common.RespHeader;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_NULL)
public class DeepLinkTeaserResp implements IMBResp{

	private static final long serialVersionUID = 7318555383399564045L;
	
	private RespHeader header;
	
	private String subject;
    private boolean isExternalLink;
    
    public RespHeader getHeader() {
		return header;
	}
	public void setHeader(RespHeader header) {
		this.header = header;
	}
	public String getSubject() {
		return subject;
	}
	public void setSubject(String subject) {
		this.subject = subject;
	}
	public boolean getIsExternalLink() {
		return isExternalLink;
	}
	public void setIsExternalLink(boolean isExternalLink) {
		this.isExternalLink = isExternalLink;
	}
	public String getApplicationType() {
		return applicationType;
	}
	public void setApplicationType(String applicationType) {
		this.applicationType = applicationType;
	}
	public Integer getAccountIndex() {
		return accountIndex;
	}
	public void setAccountIndex(Integer accountIndex) {
		this.accountIndex = accountIndex;
	}
	private String applicationType;
     private Integer accountIndex;				
     
 	
 	     
}
