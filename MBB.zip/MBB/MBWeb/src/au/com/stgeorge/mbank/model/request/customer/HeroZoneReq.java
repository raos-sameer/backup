package au.com.stgeorge.mbank.model.request.customer;

import java.io.Serializable;

import au.com.stgeorge.mbank.model.common.FavTranReq;
import au.com.stgeorge.mbank.model.common.IMBReq;
import au.com.stgeorge.mbank.model.common.ReqHeader;

public class HeroZoneReq implements IMBReq, Serializable
{
private ReqHeader header;
private FavTranReq favTranReq;

public FavTranReq getFavTranReq()
{
	return favTranReq;
}
public void setFavTranReq(FavTranReq favTranReq)
{
	this.favTranReq = favTranReq;
}
public ReqHeader getHeader()
	{
		return header;
	}
	public void setHeader(ReqHeader header)
	{
		this.header = header;
	}
	
  
}
