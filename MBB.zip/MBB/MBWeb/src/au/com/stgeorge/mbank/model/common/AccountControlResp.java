package au.com.stgeorge.mbank.model.common;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_NULL)
public class AccountControlResp
{
	boolean allowDeposit;
	boolean  allowWithdrawal;
	boolean  allowBpay;
	boolean  allowTP;
	boolean  allowTT;
	boolean  allowSMS;
	boolean  allowViewDetails;
	boolean allowViewEstmt;
	boolean  allowCashAdv;
	boolean  allowTDAFunding;
	boolean  allowPayToCreditCard;
	boolean  allowTnxCategorisation;//17E3 Transaction Categorisation
	private boolean allowPayID;//19E1: Pay to PayID
	private boolean allowAutoPay;//21E1 : Card Auto Pay 
	
	public boolean isAllowPayToCreditCard()
	{
		return allowPayToCreditCard;
	}
	public void setAllowPayToCreditCard(boolean allowPayToCreditCard)
	{
		this.allowPayToCreditCard = allowPayToCreditCard;
	}
	public boolean isAllowTDAFunding()
	{
		return allowTDAFunding;
	}
	public void setAllowTDAFunding(boolean allowTDAFunding)
	{
		this.allowTDAFunding = allowTDAFunding;
	}
	
	public boolean isAllowDeposit()
	{
		return allowDeposit;
	}
	public void setAllowDeposit(boolean allowDeposit)
	{
		this.allowDeposit = allowDeposit;
	}
	public boolean isAllowWithdrawal()
	{
		return allowWithdrawal;
	}
	public void setAllowWithdrawal(boolean allowWithdrawal)
	{
		this.allowWithdrawal = allowWithdrawal;
	}
	public boolean isAllowBpay()
	{
		return allowBpay;
	}
	public void setAllowBpay(boolean allowBpay)
	{
		this.allowBpay = allowBpay;
	}
	public boolean isAllowTP()
	{
		return allowTP;
	}
	public void setAllowTP(boolean allowTP)
	{
		this.allowTP = allowTP;
	}
	public boolean isAllowTT()
	{
		return allowTT;
	}
	public void setAllowTT(boolean allowTT)
	{
		this.allowTT = allowTT;
	}
	public boolean isAllowSMS()
	{
		return allowSMS;
	}
	public void setAllowSMS(boolean allowSMS)
	{
		this.allowSMS = allowSMS;
	}
	public boolean isAllowViewDetails()
	{
		return allowViewDetails;
	}
	public void setAllowViewDetails(boolean allowViewDetails)
	{
		this.allowViewDetails = allowViewDetails;
	}
	public boolean isAllowViewEstmt()
	{
		return allowViewEstmt;
	}
	public void setAllowViewEstmt(boolean allowViewEstmt)
	{
		this.allowViewEstmt = allowViewEstmt;
	}
	public boolean isAllowCashAdv()
	{
		return allowCashAdv;
	}
	public void setAllowCashAdv(boolean allowCashAdv)
	{
		this.allowCashAdv = allowCashAdv;
	}
	@JsonInclude(Include.NON_DEFAULT)
	public boolean isAllowTnxCategorisation() {
		return allowTnxCategorisation;
	}
	public void setAllowTnxCategorisation(boolean allowTnxCategorisation) {
		this.allowTnxCategorisation = allowTnxCategorisation;
	}
	public Boolean getAllowPayID() {
		return allowPayID;
	}
	public void setAllowPayID(Boolean allowPayID) {
		this.allowPayID = allowPayID;
	}
	public boolean isAllowAutoPay() {
		return allowAutoPay;
	}
	public void setAllowAutoPay(boolean allowAutoPay) {
		this.allowAutoPay = allowAutoPay;
	}

}
