package au.com.stgeorge.mbank.model.request.customer.ev;

import java.util.List;

public class WidgetTaxResidency {

	private String countryCode;//country
	private boolean foreignTaxInfoAvailable;
	private String foreignTaxInfovalue;// Yes or No
	private boolean showTaxInputType;// true if reason or TIN is provided
	private String foreignTaxIDNumber; // Tax Identification number
	private String reason; // reason for not providing TIN
	private int taxDataIndex;
	private boolean showAddBtn;
	private boolean showForNoTIN;
	private boolean isTINApplicable;
	private List<String> regexList;
	
	public boolean getIsTINApplicable() {
		return isTINApplicable;
	}
	public void setTINApplicable(boolean isTINApplicable) {
		this.isTINApplicable = isTINApplicable;
	}
	
	public List<String> getRegexList() {
		return regexList;
	}
	public void setRegexList(List<String> regexList) {
		this.regexList = regexList;
	}
	private String tinRegexException;
	
	public String getCountryCode() {
		return countryCode;
	}
	public void setCountryCode(String countryCode) {
		this.countryCode = countryCode;
	}
	public boolean isForeignTaxInfoAvailable() {
		return foreignTaxInfoAvailable;
	}
	public void setForeignTaxInfoAvailable(boolean foreignTaxInfoAvailable) {
		this.foreignTaxInfoAvailable = foreignTaxInfoAvailable;
	}
	public String getForeignTaxInfovalue() {
		return foreignTaxInfovalue;
	}
	public void setForeignTaxInfovalue(String foreignTaxInfovalue) {
		this.foreignTaxInfovalue = foreignTaxInfovalue;
	}
	public boolean isShowTaxInputType() {
		return showTaxInputType;
	}
	public void setShowTaxInputType(boolean showTaxInputType) {
		this.showTaxInputType = showTaxInputType;
	}
	public String getForeignTaxIDNumber() {
		return foreignTaxIDNumber;
	}
	public void setForeignTaxIDNumber(String foreignTaxIDNumber) {
		this.foreignTaxIDNumber = foreignTaxIDNumber;
	}
	public String getReason() {
		return reason;
	}
	public void setReason(String reason) {
		this.reason = reason;
	}
	public int getTaxDataIndex() {
		return taxDataIndex;
	}
	public void setTaxDataIndex(int taxDataIndex) {
		this.taxDataIndex = taxDataIndex;
	}
	public boolean isShowAddBtn() {
		return showAddBtn;
	}
	public void setShowAddBtn(boolean showAddBtn) {
		this.showAddBtn = showAddBtn;
	}
	public boolean isShowForNoTIN() {
		return showForNoTIN;
	}
	public void setShowForNoTIN(boolean showForNoTIN) {
		this.showForNoTIN = showForNoTIN;
	}
	
	
	public String getTinRegexException() {
		return tinRegexException;
	}
	public void setTinRegexException(String tinRegexException) {
		this.tinRegexException = tinRegexException;
	}
	
	
}
