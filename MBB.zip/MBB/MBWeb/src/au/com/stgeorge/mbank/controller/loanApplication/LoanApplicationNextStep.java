package au.com.stgeorge.mbank.controller.loanApplication;

import java.io.Serializable;
import java.util.ArrayList;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_NULL)
public class LoanApplicationNextStep implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1998253897985221379L;
	private String stepName;
	private boolean activeStep;
	private boolean stepCompleted;
	private ArrayList<String> stepDetails;
	public String getStepName() {
		return stepName;
	}
	public void setStepName(String stepName) {
		this.stepName = stepName;
	}
	public boolean isActiveStep() {
		return activeStep;
	}
	public void setActiveStep(boolean activeStep) {
		this.activeStep = activeStep;
	}
	public boolean isStepCompleted() {
		return stepCompleted;
	}
	public void setStepCompleted(boolean stepCompleted) {
		this.stepCompleted = stepCompleted;
	}
	public ArrayList<String> getStepDetails() {
		return stepDetails;
	}
	public void setStepDetails(ArrayList<String> stepDetails) {
		this.stepDetails = stepDetails;
	}
	
	
}
