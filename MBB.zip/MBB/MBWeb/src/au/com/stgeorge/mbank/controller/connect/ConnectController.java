package au.com.stgeorge.mbank.controller.connect;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang.builder.ReflectionToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;

import au.com.stgeorge.framework.common.logging.Logger;
import au.com.stgeorge.ibank.businessobject.BusinessException;
import au.com.stgeorge.ibank.businessobject.ResourceException;
import au.com.stgeorge.ibank.businessobject.StatisticsService;
import au.com.stgeorge.ibank.service.businessobject.PhoneService;
import au.com.stgeorge.ibank.valueobject.Statistic;
import au.com.stgeorge.ibank.valueobject.transfer.IBankCommonData;
import au.com.stgeorge.mbank.controller.IMBController;
import au.com.stgeorge.mbank.model.common.IMBReq;
import au.com.stgeorge.mbank.model.common.IMBResp;
import au.com.stgeorge.mbank.model.common.ReqHeader;
import au.com.stgeorge.mbank.model.common.RespHeader;
import au.com.stgeorge.mbank.model.request.connect.ConnectReq;
import au.com.stgeorge.mbank.model.response.ErrorResp;
import au.com.stgeorge.mbank.model.response.connect.ConnectResp;
import au.com.stgeorge.mbank.session.MobileSession;
import au.com.stgeorge.mbank.session.MobileSessionImpl;
import au.com.stgeorge.mbank.util.MBAppHelper;
import au.com.stgeorge.mbank.util.MBAppUtils;
import au.com.stgeorge.mbank.util.MBAppValidator;
import au.com.stgeorge.mbank.util.ServiceConstants;
import au.com.stgeorge.perflogger.PerformanceLogger;

/**
 * Connect Session ID Conversion Service
 * 
 * @author C69934
 * 
 */
@Controller
@RequestMapping("/connect")
public class ConnectController implements IMBController {
	private final String DASHBOARD = "dashboard";
	
	@Autowired
	private MBAppValidator mbAppValidator;
	
	@Autowired
	private MBAppHelper mbAppHelper;
	
	@Autowired
	private PhoneService phoneService;
	
	@RequestMapping(method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public IMBResp get(HttpServletRequest httpRequest, @RequestBody final ConnectReq request) {
		Logger.debug("ConnectController - get(). Request: " + request, this.getClass());
		String logName = startPerformanceLog(httpRequest);
		MobileSession mobileSession = new MobileSessionImpl();

		try {
			mobileSession.getSessionContext(httpRequest);
			validateRequestHeader(request.getHeader(), httpRequest);
			ErrorResp errorResponse = validate(request, httpRequest);
			if (errorResponse.hasErrors())
				return errorResponse;

			IBankCommonData commonData = new MBAppHelper().populateIBankCommonData(mobileSession, httpRequest);
			
			String sessionID = phoneService.createConnectSession(mobileSession.getDeviceID(),mobileSession.getUserAgentWS(),mobileSession.getUser());
			
			mobileSession.invalidateSession();
			
			createStatisticsLog(commonData, sessionID, request.getEntryPoint());
			
			IMBResp serviceResponse = populateConnectResponse(populateResponseHeader(ServiceConstants.CONNECT_SERVICE, mobileSession),sessionID);
			
			return serviceResponse;
			
		} catch (BusinessException e) {
			Logger.info("BusinessException in ConnectController - check() - [key: " + e.getKey() + "] : GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), e, ServiceConstants.CONNECT_SERVICE, httpRequest);
		} catch (ResourceException e) {
			Logger.error("ResourceException in ConnectController - check() - [key: " + e.getKey() + "] : GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.SYSTEM_UNAVILABLE, ServiceConstants.CONNECT_SERVICE, httpRequest);
		} catch (Exception e) {
			Logger.error("Exception ConnectController - check(): GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), ResourceException.MOBILE_NON_FINANCIAL_FATAL_ERR,
					ServiceConstants.CONNECT_SERVICE, httpRequest);
		} finally {
			endPerformanceLog(logName);
		}
	}

	private void createStatisticsLog(IBankCommonData commonData, String sessionID, String entryPoint) {
		try {
			Statistic s = new Statistic();
			
			if (entryPoint != null && entryPoint.equals(DASHBOARD)) {
				s.setAction(Statistic.CONNECT_FROM_MB_DASHBOARD);
				s.setDescription("Connect Dashboard");
			} else {
				s.setAction(Statistic.CONNECT_FROM_MB);
				s.setDescription("Connect Native");
			}
			
			s.setGcisNumber(commonData.getUser().getGCISNumber());
			s.setOriginBank(commonData.getOrigin());
			s.setIpAddress(commonData.getIpAddress());
			s.setGDWOriginBank(commonData.getGdwOrigin());
			int sessionLength = sessionID.length();
			s.setSessionId(sessionID.substring(sessionLength - 32, sessionLength));
			StatisticsService.logStatistic(s);
		} catch (Exception e) {
			Logger.error("Mobile Banking - Failed Statistic log for Create Connect Session : ",e, this.getClass());
		}
	}

	public ErrorResp validate(IMBReq serviceRequest, HttpServletRequest request) {
		Logger.info("Service request object - " + ReflectionToStringBuilder.toString(serviceRequest), this.getClass());
		return mbAppValidator.validate(serviceRequest, request);
	}

	public void validateRequestHeader(ReqHeader headerReq, HttpServletRequest request) throws BusinessException {
		Logger.debug("Request header validation: " + ReflectionToStringBuilder.toString(headerReq, ToStringStyle.MULTI_LINE_STYLE), this.getClass());
		mbAppValidator.validateRequestHeader(headerReq, request);
	}

	public RespHeader populateResponseHeader(String serviceName, MobileSession mobSession) {
		return mbAppHelper.populateResponseHeader(serviceName, mobSession);
	}
	
	private ConnectResp populateConnectResponse(RespHeader header,String sessionID) throws BusinessException{
		ConnectResp connectResp = new ConnectResp(header);
		
		connectResp.setSessionID(sessionID);

		return connectResp;
	}	

	/**
	 * Response for invalid body request
	 * 
	 * @return
	 */
	@ExceptionHandler( { org.springframework.http.converter.HttpMessageNotReadableException.class })
	@ResponseStatus(org.springframework.http.HttpStatus.OK)
	@ResponseBody
	public IMBResp resolveException() {
		return MBAppUtils.createInvalidMessageBodyResponse(ServiceConstants.CONNECT_SERVICE);
	}
	
	@Autowired
	private PerformanceLogger perfLogger;
	
	private String startPerformanceLog(HttpServletRequest httpRequest){
		perfLogger.startAllLogs();
		String logName = MBAppUtils.getLogName(httpRequest);
		perfLogger.startLog(logName);
		return logName;
	}
	
	private void endPerformanceLog(String logName){
		perfLogger.endLog(logName);
		perfLogger.endAllLogs();
	}
}
