package au.com.stgeorge.mbank.controller.expensesplitter;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.builder.ReflectionToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import au.com.stgeorge.framework.common.logging.Logger;
import au.com.stgeorge.ibank.businessobject.BusinessException;
import au.com.stgeorge.ibank.businessobject.ResourceException;
import au.com.stgeorge.ibank.expensesplitter.businessobject.ExpenseSplitterService;
import au.com.stgeorge.ibank.expensesplitter.businessobject.valueobject.ExpenseSplitterDashboardVO;
import au.com.stgeorge.ibank.expensesplitter.businessobject.valueobject.ExpenseSplitterUpdateVO;
import au.com.stgeorge.ibank.expensesplitter.businessobject.valueobject.ExpenseSplitterVO;
import au.com.stgeorge.ibank.expensesplitter.dao.valueobject.ExpenseGroup;
import au.com.stgeorge.ibank.expensesplitter.dao.valueobject.ExpenseSearch;
import au.com.stgeorge.ibank.expensesplitter.dao.valueobject.ExpenseSplitterContact;
import au.com.stgeorge.ibank.valueobject.Account;
import au.com.stgeorge.ibank.valueobject.AccountingTransactionHistory;
import au.com.stgeorge.ibank.valueobject.Customer;
import au.com.stgeorge.ibank.valueobject.TransactionHistory;
import au.com.stgeorge.ibank.valueobject.transfer.IBankCommonData;
import au.com.stgeorge.mbank.controller.IMBController;
import au.com.stgeorge.mbank.model.common.IMBReq;
import au.com.stgeorge.mbank.model.common.IMBResp;
import au.com.stgeorge.mbank.model.common.ReqHeader;
import au.com.stgeorge.mbank.model.common.RespHeader;
import au.com.stgeorge.mbank.model.request.EmptyReq;
import au.com.stgeorge.mbank.model.request.expensesplitter.ContactAmountDetailReq;
import au.com.stgeorge.mbank.model.request.expensesplitter.ContactDetailReq;
import au.com.stgeorge.mbank.model.request.expensesplitter.ContactReq;
import au.com.stgeorge.mbank.model.request.expensesplitter.ExpenseGroupDetailReq;
import au.com.stgeorge.mbank.model.request.expensesplitter.ExpenseGroupReq;
import au.com.stgeorge.mbank.model.request.expensesplitter.ExpenseGrpAmountPaidReq;
import au.com.stgeorge.mbank.model.request.expensesplitter.ExpenseSplitterContactListReq;
import au.com.stgeorge.mbank.model.request.expensesplitter.ExpenseSplitterReq;
import au.com.stgeorge.mbank.model.request.expensesplitter.ExpenseSplitterTransHistReq;
import au.com.stgeorge.mbank.model.response.ErrorResp;
import au.com.stgeorge.mbank.model.response.expensesplitter.ContactGroupDetailResp;
import au.com.stgeorge.mbank.model.response.expensesplitter.ContactResp;
import au.com.stgeorge.mbank.model.response.expensesplitter.ExpenseGrpListResp;
import au.com.stgeorge.mbank.model.response.expensesplitter.ExpenseSplitterDashboardResp;
import au.com.stgeorge.mbank.model.response.expensesplitter.ExpenseSplitterResp;
import au.com.stgeorge.mbank.model.response.expensesplitter.ExpenseSplitterTransHistResp;
import au.com.stgeorge.mbank.session.MobileSession;
import au.com.stgeorge.mbank.session.MobileSessionImpl;
import au.com.stgeorge.mbank.util.MBAppHelper;
import au.com.stgeorge.mbank.util.MBAppUtils;
import au.com.stgeorge.mbank.util.MBAppValidator;
import au.com.stgeorge.mbank.util.ServiceConstants;
import au.com.stgeorge.mobilebank.businessobject.MobileBankService;
import au.com.stgeorge.perflogger.PerformanceLogger;

@Controller
@RequestMapping("/expsplit")
public class ExpenseSplitterController implements IMBController {

	private static final int EXPENSE_SPLITTER_MAX_LENGTH = 50; 
	
	@Autowired
	private ExpenseSplitterService expenseSplit;

	@Autowired
	private ExpenseSplitterHelper helper;

	@Autowired
	private MBAppValidator mbAppValidator;
	
	@Autowired
	private MBAppHelper mbAppHelper;

	@Autowired
	private PerformanceLogger perfLogger;
	
	@Autowired
	private MobileBankService mobileBankService;
	

	/**
	 * Create Expense Group
	 * 
	 * @param httpRequest
	 * @param request
	 * @return
	 */
	@RequestMapping(method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE, value = "create")
	@ResponseBody
	public IMBResp createExpense(HttpServletRequest httpRequest, @RequestBody final ExpenseSplitterReq request) {
		Logger.debug("ExpenseSplitterController - createExpense. Request: " + request, this.getClass());
		String logName = startPerformanceLog(httpRequest);
		MobileSession mobileSession = new MobileSessionImpl();
		ExpenseSplitterResp resp = null;
		boolean equalSplit = true;
		ExpenseSplitterVO expenseSplitterVO = null;
		try {
			mobileSession.getSessionContext(httpRequest);
			validateRequestHeader(request.getHeader(), httpRequest);
			ErrorResp errorResponse = validate(request, httpRequest);
			if (errorResponse.hasErrors())
				return errorResponse;
			//Check if either contact or expense exists for the entire group
			if((request.getExpenseList() == null || request.getExpenseList().isEmpty())&& (request.getContactList() == null || request.getContactList().isEmpty())){
				return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.SYSTEM_UNAVILABLE, ServiceConstants.EXPENSE_SPLITTER_SERVICE, httpRequest);
			}
			IBankCommonData commonData = new MBAppHelper().populateIBankCommonData(mobileSession, httpRequest);
			if(request.getContactList() != null && request.getContactList().size()> EXPENSE_SPLITTER_MAX_LENGTH){
				return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.EXP_SPLITTER_MAXIMUM_CONTACTS_REACHED, ServiceConstants.EXPENSE_SPLITTER_SERVICE, httpRequest);
			}
			if (request.getExpenseList() != null && request.getExpenseList().size() > EXPENSE_SPLITTER_MAX_LENGTH){
				return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.EXP_SPLITTER_MAXIMUM_EXPENSES_REACHED, ServiceConstants.EXPENSE_SPLITTER_SERVICE, httpRequest);
			}
			ExpenseSplitterVO expenseSplitterVo = helper.populateExpenseSplitterVO(request,commonData);
			if(request.getContactList() == null || request.getContactList().isEmpty()){
			expenseSplit.addExpensesOnly(commonData, expenseSplitterVo);
				
			}else if(request.getExpenseList() == null || request.getExpenseList().isEmpty()){
				expenseSplit.addContactsOnly(commonData, expenseSplitterVo);
			}else{
				equalSplit = request.getSplitOption().equals("2") ? false: true;
				expenseSplitterVO = expenseSplit.addExpensesWithContacts(commonData, expenseSplitterVo, equalSplit);
			}
			resp = helper.populateExpenseSplitterResponse(populateResponseHeader(ServiceConstants.EXPENSE_SPLITTER_SERVICE, mobileSession ), expenseSplitterVO);
			return resp;
		} catch (BusinessException e) {
			Logger.info("BusinessException in ExpenseSplitterController - createExpense() - [key: " + e.getKey() + "] : GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), e, ServiceConstants.EXPENSE_SPLITTER_SERVICE, httpRequest);
		} catch (ResourceException e) {
			Logger.error("ResourceException in ExpenseSplitterController - createExpense() - [key: " + e.getKey() + "] : GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.SYSTEM_UNAVILABLE, ServiceConstants.EXPENSE_SPLITTER_SERVICE, httpRequest);
		} catch (Exception e) {
			Logger.error("Exception ExpenseSplitterController - createExpense(): GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), ResourceException.MOBILE_NON_FINANCIAL_FATAL_ERR, ServiceConstants.EXPENSE_SPLITTER_SERVICE, httpRequest);
		} finally {
			endPerformanceLog(logName);
		}
	}

	/**
	 * Save Split
	 * 
	 * @param httpRequest
	 * @param request
	 * @return
	 */
	@RequestMapping(method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE, value = "savesplit")
	@ResponseBody
	public IMBResp saveSplit(HttpServletRequest httpRequest, @RequestBody final ExpenseSplitterReq request) {
		Logger.debug("ExpenseSplitterController - saveSplit. Request: " + request, this.getClass());
		String logName = startPerformanceLog(httpRequest);
		MobileSession mobileSession = new MobileSessionImpl();
		ExpenseSplitterResp resp = null;
		boolean equalSplit = true;
		ExpenseSplitterVO expenseSplitterVO = null;
		try {
			mobileSession.getSessionContext(httpRequest);
			validateRequestHeader(request.getHeader(), httpRequest);
			ErrorResp errorResponse = validate(request, httpRequest);
			if (errorResponse.hasErrors())
				return errorResponse;
			IBankCommonData commonData = new MBAppHelper().populateIBankCommonData(mobileSession, httpRequest);
			if(request.getContactList() != null && request.getContactList().size()> EXPENSE_SPLITTER_MAX_LENGTH){
				return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.EXP_SPLITTER_MAXIMUM_CONTACTS_REACHED, ServiceConstants.EXPENSE_SPLITTER_SERVICE, httpRequest);
			}
			if (request.getExpenseList() != null && request.getExpenseList().size() > EXPENSE_SPLITTER_MAX_LENGTH){
				return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.EXP_SPLITTER_MAXIMUM_EXPENSES_REACHED, ServiceConstants.EXPENSE_SPLITTER_SERVICE, httpRequest);
			}
			ExpenseSplitterVO expenseSplitterVo = helper.populateExpenseSplitterVO(request,commonData);
			equalSplit = request.getSplitOption().equals("2") ? false: true;
			expenseSplitterVO = expenseSplit.updateExpenseGroup(commonData, expenseSplitterVo, equalSplit);
			if(expenseSplitterVO == null){
				return helper.populateSuccessResp(populateResponseHeader(ServiceConstants.EXPENSE_SPLITTER_SERVICE, mobileSession ));
			}

			resp = helper.populateExpenseSplitterResponse(populateResponseHeader(ServiceConstants.EXPENSE_SPLITTER_SERVICE, mobileSession ), expenseSplitterVO);
			return resp;
		} catch (BusinessException e) {
			Logger.info("BusinessException in ExpenseSplitterController - saveSplit() - [key: " + e.getKey() + "] : GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), e, ServiceConstants.EXPENSE_SPLITTER_SERVICE, httpRequest);
		} catch (ResourceException e) {
			Logger.error("ResourceException in ExpenseSplitterController - saveSplit() - [key: " + e.getKey() + "] : GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.SYSTEM_UNAVILABLE, ServiceConstants.EXPENSE_SPLITTER_SERVICE, httpRequest);
		} catch (Exception e) {
			Logger.error("Exception ExpenseSplitterController - saveSplit(): GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), ResourceException.MOBILE_NON_FINANCIAL_FATAL_ERR, ServiceConstants.EXPENSE_SPLITTER_SERVICE, httpRequest);
		} finally {
			endPerformanceLog(logName);
		}
	}
	
	/**
	 * Get Dashboard View
	 * 
	 * @param httpRequest
	 * @param request
	 * @return
	 */
	@RequestMapping(method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE, value = "dashboard")
	@ResponseBody
	public IMBResp getDashboard(HttpServletRequest httpRequest, @RequestBody final EmptyReq request) {
		Logger.debug("ExpenseSplitterController - getDashboard. Request: " + request, this.getClass());
		String logName = startPerformanceLog(httpRequest);
		MobileSession mobileSession = new MobileSessionImpl();
		ExpenseSplitterDashboardResp resp = null;
		ExpenseSplitterDashboardVO expenseSplitterDashboardVO = null;
		try {
			mobileSession.getSessionContext(httpRequest);
			validateRequestHeader(request.getHeader(), httpRequest);
			ErrorResp errorResponse = validate(request, httpRequest);
			if (errorResponse.hasErrors())
				return errorResponse;
			IBankCommonData commonData = new MBAppHelper().populateIBankCommonData(mobileSession, httpRequest);
			expenseSplitterDashboardVO = expenseSplit.getDashboardView(commonData);
			
			resp = helper.populateExpenseSplitterDashboardResponse(populateResponseHeader(ServiceConstants.EXPENSE_SPLITTER_SERVICE, mobileSession ), expenseSplitterDashboardVO);
			return resp;
		} catch (BusinessException e) {
			Logger.info("BusinessException in ExpenseSplitterController - getDashboard() - [key: " + e.getKey() + "] : GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), e, ServiceConstants.EXPENSE_SPLITTER_SERVICE, httpRequest);
		} catch (ResourceException e) {
			Logger.error("ResourceException in ExpenseSplitterController - getDashboard() - [key: " + e.getKey() + "] : GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.SYSTEM_UNAVILABLE, ServiceConstants.EXPENSE_SPLITTER_SERVICE, httpRequest);
		} catch (Exception e) {
			Logger.error("Exception ExpenseSplitterController - getDashboard(): GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), ResourceException.MOBILE_NON_FINANCIAL_FATAL_ERR, ServiceConstants.EXPENSE_SPLITTER_SERVICE, httpRequest);
		} finally {
			endPerformanceLog(logName);
		}
	}
	
	private String startPerformanceLog(HttpServletRequest httpRequest){
		perfLogger.startAllLogs();
		String logName = MBAppUtils.getLogName(httpRequest);
		perfLogger.startLog(logName);
		return logName;
	}
	
	private void endPerformanceLog(String logName){
		perfLogger.endLog(logName);
		perfLogger.endAllLogs();
	}

	public ErrorResp validate(IMBReq serviceRequest, HttpServletRequest request) {
		Logger.info("Service request object - " + ReflectionToStringBuilder.toString(serviceRequest), this.getClass());
		return mbAppValidator.validate(serviceRequest, request);
	}

	public void validateRequestHeader(ReqHeader headerReq, HttpServletRequest request) throws BusinessException {
		Logger.debug("Request header validation: " + ReflectionToStringBuilder.toString(headerReq, ToStringStyle.MULTI_LINE_STYLE), this.getClass());
		mbAppValidator.validateRequestHeader(headerReq, request);
	}
	
	public RespHeader populateResponseHeader(String serviceName, MobileSession mobSession) {
		return mbAppHelper.populateResponseHeader(serviceName, mobSession);
	}
	
	/**
	 * get transaction history of selected account
	 * 
	 * @param httpRequest
	 * @param request
	 * @return
	 */
	@RequestMapping(value ="tranhistory", method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public IMBResp getTransactionHistory(HttpServletRequest httpRequest, HttpServletResponse httpServletResponse,
			@RequestBody final ExpenseSplitterTransHistReq request)
	{
		Logger.debug("ExpenseSplitterController - getTransactionHistory. Request: " + request, this.getClass());
		String logName = startPerformanceLog(httpRequest);
		MobileSession mobileSession = new MobileSessionImpl();
		TransactionHistory tranHistory = null;
		Collection cardAuthorizations = null;
		StringBuffer[] cardAuthtotAmt = { new StringBuffer() };
		
		try{
			mobileSession.getSessionContext(httpRequest);
			validateRequestHeader(request.getHeader(), httpRequest);
			ErrorResp errorResponse = validate(request, httpRequest);
			if (errorResponse != null && errorResponse.getErrors() != null && errorResponse.getErrors().size() > 0)			
				return errorResponse;
			
			//Get index of account selected from dropdown.
			int selectedAccountIndex = request.getAccountIndex();
			Customer customer = mobileSession.getCustomer();
			Account selectedAccount = mbAppHelper.getAccountFromCustomer(customer, selectedAccountIndex);
			
			if(null!=selectedAccount){								
				IBankCommonData commonData = mbAppHelper.populateIBankCommonData(mobileSession,httpRequest);	
				//Getting transaction history of selected account
				tranHistory = mobileBankService.getTransactionHistory(selectedAccount.getAccountId(),commonData,request.getHistoryPeriod());
				
				//Getting pending authorizations
				if(Account.CREDIT_CARD.equalsIgnoreCase(selectedAccount.getAccountId().getEhubProductCode())     || 
						Account.SAVING_ACCOUNT.equalsIgnoreCase(selectedAccount.getAccountId().getEhubProductCode()) ||
						Account.CHEQUE_ACCOUNT.equalsIgnoreCase(selectedAccount.getAccountId().getEhubProductCode())
					  )
					cardAuthorizations = mobileBankService.getCardAuthorisations(selectedAccount.getAccountId(), cardAuthtotAmt);
			}else
				throw new BusinessException(BusinessException.NO_INFORMATION);
			
			if(null == tranHistory){
				//if null populate empty obj of transaction history
				tranHistory = new AccountingTransactionHistory();
			}
			
			//Populate response
			ExpenseSplitterTransHistResp resp = new ExpenseSplitterTransHistResp();
			helper.populateEntireHistoryResp(resp, selectedAccount, cardAuthorizations, cardAuthtotAmt, tranHistory);
			//helper.populateTranHistoryResp(resp, tranHistory);
			RespHeader headerResp = populateResponseHeader(ServiceConstants.EXPENSE_SPLITTER_SERVICE, mobileSession);
			resp.setHeader(headerResp);
			return resp;
		}catch (BusinessException e){
			Logger.info("BusinessException In ExpenseSplitterController-getTransactionHistory() for Customer GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "]", e, this.getClass());
			BusinessException exp = new BusinessException(e.getKey());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), exp, ServiceConstants.EXPENSE_SPLITTER_SERVICE, httpRequest);
		} catch (ResourceException e) {
			Logger.error("ResourceException In ExpenseSplitterController-getTransactionHistory()  for Customer GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "]", e, this.getClass());
			ResourceException exp = new ResourceException(e.getKey());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), exp, ServiceConstants.EXPENSE_SPLITTER_SERVICE, httpRequest);
		}catch (Exception e)
		{
			Logger.error("Exception In ExpenseSplitterController-getTransactionHistory()  for Customer GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "]", e, this.getClass());
			BusinessException exp = new BusinessException(BusinessException.GENERIC_ERROR);
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), exp, ServiceConstants.EXPENSE_SPLITTER_SERVICE, httpRequest);
		}finally {
			endPerformanceLog(logName);
		}
				
	}
	
	@RequestMapping(method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE, value = "checkcontact")
	@ResponseBody
	public IMBResp checkContactExists(HttpServletRequest httpRequest, @RequestBody final ExpenseSplitterContactListReq request) {
		Logger.debug("ExpenseSplitterController - checkContactExists. Request: " + request, this.getClass());
		String logName = startPerformanceLog(httpRequest);
		MobileSession mobileSession = new MobileSessionImpl();
		ContactResp resp = new ContactResp();

		int count_id=0;
		int count=0;
		List<ExpenseSplitterContact> expSplitterContactList_contactID=new ArrayList<ExpenseSplitterContact>();
		List<ExpenseSplitterContact> expSplitterContactList=new ArrayList<ExpenseSplitterContact>();
		
		List<ExpenseSplitterContact> expSplitterContactListID_res=new ArrayList<ExpenseSplitterContact>();
		List<ExpenseSplitterContact> expSplitterContactList_res=new ArrayList<ExpenseSplitterContact>();
		
		List<Integer> indexList=new ArrayList<Integer>();
		
		try {
			mobileSession.getSessionContext(httpRequest);
			validateRequestHeader(request.getHeader(), httpRequest);
			ErrorResp errorResponse = validate(request, httpRequest);
			if (errorResponse.hasErrors())
				return errorResponse;
			//Check: is the contacts added is a ME contact
			if(null!=request.getContactList()){
				for(ContactReq req:request.getContactList()){
					if("Me".equalsIgnoreCase(req.getContactName())) {
						return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.EXP_SPLITTER_CONTACT_ALREADY_EXISTS, ServiceConstants.EXPENSE_SPLITTER_SERVICE, httpRequest);
					}
				}
			}
			IBankCommonData commonData = new MBAppHelper().populateIBankCommonData(mobileSession, httpRequest);
			
			for(ContactReq req:request.getContactList())
			{
				if(req.getContactID()!=null){
					count_id++;
					ExpenseSplitterContact expSplitterContact = helper.createExpenseSplitterContactObject(req,commonData);
					expSplitterContactList_contactID.add(expSplitterContact);
				}
				else{
					count++;
					ExpenseSplitterContact expSplitterContact = helper.createExpenseSplitterContactObject(req,commonData);
					expSplitterContactList.add(expSplitterContact);
				}
			}
						
			if(count_id > 0)
				expSplitterContactListID_res = expenseSplit.checkContactExistsByContactID(commonData,expSplitterContactList_contactID);	
			if(count > 0)
				expSplitterContactList_res = expenseSplit.checkContactExists(commonData,expSplitterContactList);
			
			
			
			List<ExpenseSplitterContact> contactIndexList=new ArrayList<ExpenseSplitterContact>(expSplitterContactListID_res);
			contactIndexList.addAll(expSplitterContactList_res);
			
			for(ContactReq  exc: request.getContactList()){
				for(ExpenseSplitterContact ex: contactIndexList){
					if(exc.getContactName().trim().equalsIgnoreCase(ex.getContactName().trim())){
						indexList.add(Integer.parseInt(exc.getContactIndex()));
					}
				}
			}
			RespHeader headerResp = populateResponseHeader(ServiceConstants.EXPENSE_SPLITTER_SERVICE, mobileSession);
			resp.setHeader(headerResp);
			resp.setContactIndexList(indexList);
			return resp;
		} catch (BusinessException e) {
			Logger.info("BusinessException in ExpenseSplitterController - checkContactExistsNew() - [key: " + e.getKey() + "] : GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), e, ServiceConstants.EXPENSE_SPLITTER_SERVICE, httpRequest);
		} catch (ResourceException e) {
			Logger.error("ResourceException in ExpenseSplitterController - checkContactExistsNew() - [key: " + e.getKey() + "] : GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.SYSTEM_UNAVILABLE, ServiceConstants.EXPENSE_SPLITTER_SERVICE, httpRequest);
		} catch (Exception e) {
			Logger.error("Exception ExpenseSplitterController - checkContactExistsNew(): GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), ResourceException.MOBILE_NON_FINANCIAL_FATAL_ERR, ServiceConstants.EXPENSE_SPLITTER_SERVICE, httpRequest);
		} finally {
			endPerformanceLog(logName);
		}
	}

	
	/**
	 * Get Dashboard View
	 * 
	 * @param httpRequest
	 * @param request
	 * @return
	 */
	@RequestMapping(method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE, value = "expgrpdetail")
	@ResponseBody
	public IMBResp getExpenseGroupDetails(HttpServletRequest httpRequest, @RequestBody final ExpenseGroupDetailReq request) {
		Logger.debug("ExpenseSplitterController - getDashboard. Request: " + request, this.getClass());
		String logName = startPerformanceLog(httpRequest);
		MobileSession mobileSession = new MobileSessionImpl();
		ExpenseSplitterResp resp = null;
		ExpenseSplitterVO expenseSplitterVO = null;
		try {
			mobileSession.getSessionContext(httpRequest);
			validateRequestHeader(request.getHeader(), httpRequest);
			ErrorResp errorResponse = validate(request, httpRequest);
			if (errorResponse.hasErrors()){
				return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.SYSTEM_UNAVILABLE, ServiceConstants.EXPENSE_SPLITTER_SERVICE, httpRequest);
			}
			IBankCommonData commonData = new MBAppHelper().populateIBankCommonData(mobileSession, httpRequest);
			expenseSplitterVO = expenseSplit.getExpenseGroupDetail(commonData, new Long(request.getExpGrpID()));
			
			resp = helper.populateExpenseGroupDetailResponse(populateResponseHeader(ServiceConstants.EXPENSE_SPLITTER_SERVICE, mobileSession ), expenseSplitterVO);
			return resp;
		} catch (BusinessException e) {
			Logger.info("BusinessException in ExpenseSplitterController - getExpenseGroupDetails() - [key: " + e.getKey() + "] : GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), e, ServiceConstants.EXPENSE_SPLITTER_SERVICE, httpRequest);
		} catch (ResourceException e) {
			Logger.error("ResourceException in ExpenseSplitterController - getExpenseGroupDetails() - [key: " + e.getKey() + "] : GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.SYSTEM_UNAVILABLE, ServiceConstants.EXPENSE_SPLITTER_SERVICE, httpRequest);
		} catch (Exception e) {
			Logger.error("Exception ExpenseSplitterController - getExpenseGroupDetails(): GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), ResourceException.MOBILE_NON_FINANCIAL_FATAL_ERR, ServiceConstants.EXPENSE_SPLITTER_SERVICE, httpRequest);
		} finally {
			endPerformanceLog(logName);
		}
	}
	
	
	@RequestMapping(method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE, value = "contactGrpDetail")
	@ResponseBody
	public IMBResp getContactDetails(HttpServletRequest httpRequest, @RequestBody final ContactDetailReq request) {
		Logger.debug("ExpenseSplitterController - getContactDetails. Request: " + request, this.getClass());
		String logName = startPerformanceLog(httpRequest);
		MobileSession mobileSession = new MobileSessionImpl();
		ContactGroupDetailResp resp = null;
		try {
			mobileSession.getSessionContext(httpRequest);
			validateRequestHeader(request.getHeader(), httpRequest);
			ErrorResp errorResponse = validate(request, httpRequest);
			if (errorResponse.hasErrors()){
				return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.SYSTEM_UNAVILABLE, ServiceConstants.EXPENSE_SPLITTER_SERVICE, httpRequest);
			}
			IBankCommonData commonData = new MBAppHelper().populateIBankCommonData(mobileSession, httpRequest);
			List<ExpenseSearch> groupList = expenseSplit.getContactDetail(commonData, new Long(request.getContactID()));
			
			resp = helper.populateContactDetailResponse(populateResponseHeader(ServiceConstants.EXPENSE_SPLITTER_SERVICE, mobileSession ), groupList);
			return resp;
		} catch (BusinessException e) {
			Logger.info("BusinessException in ExpenseSplitterController - getContactDetails() - [key: " + e.getKey() + "] : GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), e, ServiceConstants.EXPENSE_SPLITTER_SERVICE, httpRequest);
		} catch (ResourceException e) {
			Logger.error("ResourceException in ExpenseSplitterController - getContactDetails() - [key: " + e.getKey() + "] : GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.SYSTEM_UNAVILABLE, ServiceConstants.EXPENSE_SPLITTER_SERVICE, httpRequest);
		} catch (Exception e) {
			Logger.error("Exception ExpenseSplitterController - getContactDetails(): GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), ResourceException.MOBILE_NON_FINANCIAL_FATAL_ERR, ServiceConstants.EXPENSE_SPLITTER_SERVICE, httpRequest);
		} finally {
			endPerformanceLog(logName);
		}
	}
	
	
	
	@RequestMapping(method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE, value = "deleteExpGrp")
	@ResponseBody
	public IMBResp deleteExpenseGroup(HttpServletRequest httpRequest, @RequestBody final ExpenseGroupDetailReq request) {
		Logger.debug("ExpenseSplitterController - deleteExpenseGroup. Request: " + request, this.getClass());
		String logName = startPerformanceLog(httpRequest);
		MobileSession mobileSession = new MobileSessionImpl();
		try {
			mobileSession.getSessionContext(httpRequest);
			validateRequestHeader(request.getHeader(), httpRequest);
			ErrorResp errorResponse = validate(request, httpRequest);
			if (errorResponse.hasErrors()){
				return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.SYSTEM_UNAVILABLE, ServiceConstants.EXPENSE_SPLITTER_SERVICE, httpRequest);
			}
			IBankCommonData commonData = new MBAppHelper().populateIBankCommonData(mobileSession, httpRequest);
			expenseSplit.deleteGroup(commonData, new Long(request.getExpGrpID()));
			
			return helper.populateSuccessResp(populateResponseHeader(ServiceConstants.EXPENSE_SPLITTER_SERVICE, mobileSession ));
		} catch (BusinessException e) {
			Logger.info("BusinessException in ExpenseSplitterController - deleteExpenseGroup() - [key: " + e.getKey() + "] : GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), e, ServiceConstants.EXPENSE_SPLITTER_SERVICE, httpRequest);
		} catch (ResourceException e) {
			Logger.error("ResourceException in ExpenseSplitterController - deleteExpenseGroup() - [key: " + e.getKey() + "] : GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.SYSTEM_UNAVILABLE, ServiceConstants.EXPENSE_SPLITTER_SERVICE, httpRequest);
		} catch (Exception e) {
			Logger.error("Exception ExpenseSplitterController - deleteExpenseGroup(): GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), ResourceException.MOBILE_NON_FINANCIAL_FATAL_ERR, ServiceConstants.EXPENSE_SPLITTER_SERVICE, httpRequest);
		} finally {
			endPerformanceLog(logName);
		}
	}
	
	
	@RequestMapping(method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE, value = "contactpaid")
	@ResponseBody
	public IMBResp updateContactAmountPaid(HttpServletRequest httpRequest, @RequestBody final ContactAmountDetailReq request) {
		Logger.debug("ExpenseSplitterController - upadte Contact amount. Request: " + request, this.getClass());
		String logName = startPerformanceLog(httpRequest);
		MobileSession mobileSession = new MobileSessionImpl();
		try {
			mobileSession.getSessionContext(httpRequest);
			validateRequestHeader(request.getHeader(), httpRequest);
			ErrorResp errorResponse = validate(request, httpRequest);
			if (errorResponse.hasErrors()){
				return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.SYSTEM_UNAVILABLE, ServiceConstants.EXPENSE_SPLITTER_SERVICE, httpRequest);
			}
			IBankCommonData commonData = new MBAppHelper().populateIBankCommonData(mobileSession, httpRequest);
			ExpenseSplitterUpdateVO updateVo = helper.populateExpenseSplitterUpdateVO(request, commonData);
			expenseSplit.updateContactAmount(updateVo, commonData);
			
			return helper.populateSuccessResp(populateResponseHeader(ServiceConstants.EXPENSE_SPLITTER_SERVICE, mobileSession ));
		} catch (BusinessException e) {
			Logger.info("BusinessException in ExpenseSplitterController - updateContactAmountPaid() - [key: " + e.getKey() + "] : GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), e, ServiceConstants.EXPENSE_SPLITTER_SERVICE, httpRequest);
		} catch (ResourceException e) {
			Logger.error("ResourceException in ExpenseSplitterController - updateContactAmountPaid() - [key: " + e.getKey() + "] : GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.SYSTEM_UNAVILABLE, ServiceConstants.EXPENSE_SPLITTER_SERVICE, httpRequest);
		} catch (Exception e) {
			Logger.error("Exception ExpenseSplitterController - updateContactAmountPaid): GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), ResourceException.MOBILE_NON_FINANCIAL_FATAL_ERR, ServiceConstants.EXPENSE_SPLITTER_SERVICE, httpRequest);
		} finally {
			endPerformanceLog(logName);
		}
	}
	
	@RequestMapping(method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE, value = "expensepaid")
	@ResponseBody
	public IMBResp updateExpenseGroupAmountPaid(HttpServletRequest httpRequest, @RequestBody final ExpenseGrpAmountPaidReq request) {
		Logger.debug("ExpenseSplitterController - upadte Contact amount. Request: " + request, this.getClass());
		String logName = startPerformanceLog(httpRequest);
		MobileSession mobileSession = new MobileSessionImpl();
		try {
			mobileSession.getSessionContext(httpRequest);
			validateRequestHeader(request.getHeader(), httpRequest);
			ErrorResp errorResponse = validate(request, httpRequest);
			if (errorResponse.hasErrors()){
				return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.SYSTEM_UNAVILABLE, ServiceConstants.EXPENSE_SPLITTER_SERVICE, httpRequest);
			}
			IBankCommonData commonData = new MBAppHelper().populateIBankCommonData(mobileSession, httpRequest);
			ExpenseSplitterUpdateVO updateVo = helper.populateExpenseSplitterUpdateVOForExpenseGroup(request, commonData);
			expenseSplit.updateExpenseGroupAmountPaid(updateVo, commonData);
			
			return helper.populateSuccessResp(populateResponseHeader(ServiceConstants.EXPENSE_SPLITTER_SERVICE, mobileSession ));
		} catch (BusinessException e) {
			Logger.info("BusinessException in ExpenseSplitterController - updateExpenseGroupAmountPaid - [key: " + e.getKey() + "] : GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), e, ServiceConstants.EXPENSE_SPLITTER_SERVICE, httpRequest);
		} catch (ResourceException e) {
			Logger.error("ResourceException in ExpenseSplitterController - updateExpenseGroupAmountPaid() - [key: " + e.getKey() + "] : GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.SYSTEM_UNAVILABLE, ServiceConstants.EXPENSE_SPLITTER_SERVICE, httpRequest);
		} catch (Exception e) {
			Logger.error("Exception ExpenseSplitterController - updateExpenseGroupAmountPaid(): GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), ResourceException.MOBILE_NON_FINANCIAL_FATAL_ERR, ServiceConstants.EXPENSE_SPLITTER_SERVICE, httpRequest);
		} finally {
			endPerformanceLog(logName);
		}
	}
	
	
	@RequestMapping(method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE, value = "updexpgrpname")
	@ResponseBody
	public IMBResp updateExpenseGroupName(HttpServletRequest httpRequest, @RequestBody final ExpenseGroupReq request) {
		Logger.debug("ExpenseSplitterController - upadte Expense Group name. Request: " + request, this.getClass());
		String logName = startPerformanceLog(httpRequest);
		MobileSession mobileSession = new MobileSessionImpl();
		try {
			mobileSession.getSessionContext(httpRequest);
			validateRequestHeader(request.getHeader(), httpRequest);
			ErrorResp errorResponse = validate(request, httpRequest);
			if (errorResponse.hasErrors()){
				return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.SYSTEM_UNAVILABLE, ServiceConstants.EXPENSE_SPLITTER_SERVICE, httpRequest);
			}
			IBankCommonData commonData = new MBAppHelper().populateIBankCommonData(mobileSession, httpRequest);
			ExpenseGroup expGrp = helper.populateExpenseGroupObject(request, commonData);
			expenseSplit.updateGroupName(expGrp, commonData);
			
			return helper.populateSuccessResp(populateResponseHeader(ServiceConstants.EXPENSE_SPLITTER_SERVICE, mobileSession ));
		} catch (BusinessException e) {
			Logger.info("BusinessException in ExpenseSplitterController - upadte Expense Group name.- [key: " + e.getKey() + "] : GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), e, ServiceConstants.EXPENSE_SPLITTER_SERVICE, httpRequest);
		} catch (ResourceException e) {
			Logger.error("ResourceException in ExpenseSplitterController - upadte Expense Group name. - [key: " + e.getKey() + "] : GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.SYSTEM_UNAVILABLE, ServiceConstants.EXPENSE_SPLITTER_SERVICE, httpRequest);
		} catch (Exception e) {
			Logger.error("Exception ExpenseSplitterController -  upadte Expense Group name.: GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), ResourceException.MOBILE_NON_FINANCIAL_FATAL_ERR, ServiceConstants.EXPENSE_SPLITTER_SERVICE, httpRequest);
		} finally {
			endPerformanceLog(logName);
		}
	}
	
	@RequestMapping(method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE, value = "checkGroupName")
	@ResponseBody
	public IMBResp checkGroupName(HttpServletRequest httpRequest, @RequestBody final ExpenseGroupReq request) {
		Logger.debug("ExpenseSplitterController - checkGroupName. Request: " + request, this.getClass());
		String logName = startPerformanceLog(httpRequest);
		MobileSession mobileSession = new MobileSessionImpl();
		ExpenseGrpListResp resp = new ExpenseGrpListResp();
		try {
			mobileSession.getSessionContext(httpRequest);
			validateRequestHeader(request.getHeader(), httpRequest);
			ErrorResp errorResponse = validate(request, httpRequest);
			if (errorResponse.hasErrors()){
				return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.SYSTEM_UNAVILABLE, ServiceConstants.EXPENSE_SPLITTER_SERVICE, httpRequest);
			}
			IBankCommonData commonData = new MBAppHelper().populateIBankCommonData(mobileSession, httpRequest);
			boolean isGroupNameExisits = expenseSplit.isGroupNameExists(request.getExpenseGrpName(), commonData.getCustomer().getGcis());
			
			RespHeader headerResp = populateResponseHeader(ServiceConstants.EXPENSE_SPLITTER_SERVICE, mobileSession);
			resp.setHeader(headerResp);
			resp.setExpenseGrpNameExists(isGroupNameExisits);
			return resp;
		} catch (BusinessException e) {
			Logger.info("BusinessException in ExpenseSplitterController - getContactDetails() - [key: " + e.getKey() + "] : GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), e, ServiceConstants.EXPENSE_SPLITTER_SERVICE, httpRequest);
		} catch (ResourceException e) {
			Logger.error("ResourceException in ExpenseSplitterController - getContactDetails() - [key: " + e.getKey() + "] : GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.SYSTEM_UNAVILABLE, ServiceConstants.EXPENSE_SPLITTER_SERVICE, httpRequest);
		} catch (Exception e) {
			Logger.error("Exception ExpenseSplitterController - getContactDetails(): GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), ResourceException.MOBILE_NON_FINANCIAL_FATAL_ERR, ServiceConstants.EXPENSE_SPLITTER_SERVICE, httpRequest);
		} finally {
			endPerformanceLog(logName);
		}
	}
	
}
