package au.com.stgeorge.mbank.model.payments;

import java.util.Date;

import au.com.stgeorge.mbank.util.JsonDateSerializer;
import au.com.stgeorge.mbank.util.JsonDateTimeSerializer;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;

@JsonInclude(Include.NON_NULL)
public class PayToMobileDetailResp {

	private Long id;
	private String idDisp;
	private String fromAccountName;
	private String fromAccountNumDisp;
	private String fromBsbDisp;
	private String mobileNum;
	private Integer statusCode;
	private String statusDisp;
	private String errorDesc;
	private Date requestDate;
	private String amt;
	private String desc;
	private Date expiryDate;
	private String payerName;
	private String toAccountName;
	private String toAccountNumDisp;
	private String toBsbDisp;
	private Date completionDate;
	private String receiptNumDisp;
	
	public String getFromAccountName() {
		return fromAccountName;
	}
	public void setFromAccountName(String fromAccountName) {
		this.fromAccountName = fromAccountName;
	}
	public String getFromAccountNumDisp() {
		return fromAccountNumDisp;
	}
	public void setFromAccountNumDisp(String fromAccountNumDisp) {
		this.fromAccountNumDisp = fromAccountNumDisp;
	}
	public String getFromBsbDisp() {
		return fromBsbDisp;
	}
	public void setFromBsbDisp(String fromBsbDisp) {
		this.fromBsbDisp = fromBsbDisp;
	}
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getIdDisp() {
		return idDisp;
	}
	public void setIdDisp(String idDisp) {
		this.idDisp = idDisp;
	}
	public String getMobileNum() {
		return mobileNum;
	}
	public void setMobileNum(String mobileNum) {
		this.mobileNum = mobileNum;
	}
	public Integer getStatusCode() {
		return statusCode;
	}
	public void setStatusCode(Integer statusCode) {
		this.statusCode = statusCode;
	}
	public String getStatusDisp() {
		return statusDisp;
	}
	public void setStatusDisp(String statusDisp) {
		this.statusDisp = statusDisp;
	}			
	public String getErrorDesc() {
		return errorDesc;
	}
	public void setErrorDesc(String errorDesc) {
		this.errorDesc = errorDesc;
	}
	@JsonSerialize(using = JsonDateTimeSerializer.class)
	@JsonInclude(Include.NON_NULL)
	public Date getRequestDate() {
		return requestDate;
	}
	public void setRequestDate(Date requestDate) {
		this.requestDate = requestDate;
	}
	public String getAmt() {
		return amt;
	}
	public void setAmt(String amt) {
		this.amt = amt;
	}
	public String getDesc() {
		return desc;
	}
	public void setDesc(String desc) {
		this.desc = desc;
	}
	
	@JsonSerialize(using = JsonDateSerializer.class)
	@JsonInclude(Include.NON_NULL)
	public Date getExpiryDate() {
		return expiryDate;
	}
	public void setExpiryDate(Date expiryDate) {
		this.expiryDate = expiryDate;
	}
	public String getPayerName() {
		return payerName;
	}
	public void setPayerName(String payerName) {
		this.payerName = payerName;
	}
	public String getToAccountName() {
		return toAccountName;
	}
	public void setToAccountName(String toAccountName) {
		this.toAccountName = toAccountName;
	}
	public String getToAccountNumDisp() {
		return toAccountNumDisp;
	}
	public void setToAccountNumDisp(String toAccountNumDisp) {
		this.toAccountNumDisp = toAccountNumDisp;
	}
	public String getToBsbDisp() {
		return toBsbDisp;
	}
	public void setToBsbDisp(String toBsbDisp) {
		this.toBsbDisp = toBsbDisp;
	}
	@JsonSerialize(using = JsonDateTimeSerializer.class)
	@JsonInclude(Include.NON_NULL)
	public Date getCompletionDate() {
		return completionDate;
	}
	public void setCompletionDate(Date completionDate) {
		this.completionDate = completionDate;
	}
	public String getReceiptNumDisp() {
		return receiptNumDisp;
	}
	public void setReceiptNumDisp(String receiptNumDisp) {
		this.receiptNumDisp = receiptNumDisp;
	}
}
