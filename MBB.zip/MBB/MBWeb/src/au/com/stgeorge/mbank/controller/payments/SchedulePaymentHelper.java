/**
 * 
 */
package au.com.stgeorge.mbank.controller.payments;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import au.com.stgeorge.framework.common.logging.Logger;
import au.com.stgeorge.framework.common.util.DateMethods;
import au.com.stgeorge.framework.common.util.StringMethods;
import au.com.stgeorge.ibank.businessobject.BusinessException;
import au.com.stgeorge.ibank.common.cache.IBankParams;
import au.com.stgeorge.ibank.util.StringUtil;
import au.com.stgeorge.ibank.valueobject.Account;
import au.com.stgeorge.ibank.valueobject.AccountId;
import au.com.stgeorge.ibank.valueobject.AccountPayment;
import au.com.stgeorge.ibank.valueobject.BPayPayment;
import au.com.stgeorge.ibank.valueobject.CreditCardPayment;
import au.com.stgeorge.ibank.valueobject.Customer;
import au.com.stgeorge.ibank.valueobject.Payment;
import au.com.stgeorge.ibank.valueobject.ScheduleDetails;
import au.com.stgeorge.ibank.valueobject.ThirdPartyPayment;
import au.com.stgeorge.ibank.valueobject.database.CodesVO;
import au.com.stgeorge.mbank.model.common.AccountKeyInfoResp;
import au.com.stgeorge.mbank.model.common.IMBResp;
import au.com.stgeorge.mbank.model.payments.SchedulePaymentInfoResp;
import au.com.stgeorge.mbank.model.payments.TransferScheduleResp;
import au.com.stgeorge.mbank.model.response.payments.SchedulePaymentDetailResp;
import au.com.stgeorge.mbank.model.response.payments.SchedulePaymentResp;
import au.com.stgeorge.mbank.util.MBAppConstants;
import au.com.stgeorge.mbank.util.MBAppHelper;

/**
 * @author C50216
 *
 */
@Service
public class SchedulePaymentHelper {

	@Autowired
	private MBAppHelper mbAppHelper;
	
	protected IMBResp populateScheduleListResp(Collection scheduleList,Customer customer, boolean isExpiredSchedules) {
		
		SchedulePaymentResp scheduleResp = new SchedulePaymentResp();
									
		if(scheduleList != null){
			
			CodesVO myCodes = IBankParams.getCodesData(IBankParams.BRAND_ORIGIN, IBankParams.MOBILE_BANKING, IBankParams.MAX_SCHEDULES_DISPLAY);			
			Integer maxSchedules = Integer.parseInt(myCodes.getMessage());
			
			if (scheduleList.size() > maxSchedules.intValue())
				scheduleResp.setOverThreshold(true);
			else
				scheduleResp.setOverThreshold(false);
			
			scheduleResp.setScheduleList(getSchPaymentListResp(scheduleList,customer,maxSchedules,isExpiredSchedules));			
		}	
						
		return scheduleResp;		
	}
	
	protected IMBResp populateScheduleModifyResp(String status) {
		
		SchedulePaymentResp scheduleResp = new SchedulePaymentResp();
		
		if(status != null)
			scheduleResp.setStatus(status);
						
		return scheduleResp;		
	}
	
	protected IMBResp populateScheduleDetailResp(Payment payment,Customer customer) throws BusinessException {
		
		SchedulePaymentDetailResp scheduleResp = new SchedulePaymentDetailResp();
		TransferScheduleResp transSchDtl = null;
		
		if(payment != null){
						
			int fromIndex = mbAppHelper.getAccountIndexByAccountId(customer.getAccounts(), payment.getFromAccount());
			int toIndex = -1;					
			scheduleResp.setFromAccountIndex(fromIndex);
			scheduleResp.setAmt(payment.getAmount().toString());
			
			transSchDtl = new TransferScheduleResp();
			transSchDtl.setFreq(payment.getScheduleDetails().getFrequency());
			transSchDtl.setNextPayDate(payment.getScheduleDetails().getNextPaymentDate());
			transSchDtl.setLastPayDate(payment.getScheduleDetails().getLastPaymentDate());
			transSchDtl.setFirstPaymentDate(payment.getScheduleDetails().getFirstPaymentDate());
			transSchDtl.setScheduleId(Integer.parseInt(payment.getScheduleDetails().getId()));
			transSchDtl.setScheduleIdDisp("S"+payment.getScheduleDetails().getId());
			
			scheduleResp.setScheduleDetail(transSchDtl);
						
			if(payment.getScheduleDetails().isEmailReceipt())
				scheduleResp.setSendEmail(true);
			else
				scheduleResp.setSendEmail(false);
			
			
			if (payment instanceof ThirdPartyPayment){
				ThirdPartyPayment tp = (ThirdPartyPayment) payment;
				toIndex = mbAppHelper.getThirdPartyIndexFromCustomer(customer, tp.getToThirdParty().getBsb(), tp.getToThirdParty().getNumber());
				if (toIndex <0){
					Logger.error("Scheduled From Account not found in Customer cache", this.getClass());
					throw new BusinessException(BusinessException.ACCT_NOT_AVAILABLE_TO_DEPOSIT);
				}
				scheduleResp.setTranType(MBAppConstants.TRAN_TYPE_PAYEE);
				scheduleResp.setDesc(payment.getDescription());
				scheduleResp.setPayeeEmail(tp.getToThirdParty().getEmailPayee());
				scheduleResp.setPayerName(payment.getPayerName());
							
			}else if (payment instanceof BPayPayment){
				BPayPayment bpay = (BPayPayment)payment;
				toIndex = mbAppHelper.getBillerIndexFromCustomer(customer, bpay.getToBiller(), false);
				if (toIndex <0){
					Logger.info("Scheduled BillerCode with CRN not found in Customer cache", this.getClass());
					toIndex = mbAppHelper.getBillerIndexFromCustomer(customer, bpay.getToBiller(), true);
					if (toIndex <0){
						Logger.error("Scheduled Biller not found in Customer cache", this.getClass());
						throw new BusinessException(BusinessException.ACCT_NOT_AVAILABLE_TO_DEPOSIT);
					}
				}
				scheduleResp.setTranType(MBAppConstants.TRAN_TYPE_BPAY);
				scheduleResp.setPayerName(payment.getPayerName());				
				scheduleResp.setCustRefNum(bpay.getReferenceNumber());				
				
			}else if (payment instanceof CreditCardPayment){
				
				CreditCardPayment cc = (CreditCardPayment)payment;
				
				scheduleResp.setTranType(MBAppConstants.TRAN_TYPE_ACCOUNT);
				toIndex = mbAppHelper.getAccountIndexByAccountId(customer.getAccounts(), cc.getToCard());
				if (toIndex <0){
					Logger.error("Scheduled To Account not found in Customer cache", this.getClass());
					throw new BusinessException(BusinessException.ACCT_NOT_AVAILABLE_TO_DEPOSIT);
				}else{
					checkToAccountForDeposit(MBAppHelper.getAccountbyAccountId(cc.getToCard(), customer.getAccounts()));
				}
				
				if (CreditCardPayment.OPTION_MINIMUM.equalsIgnoreCase(cc.getPaymentOption()))
					scheduleResp.setCcPaymentType(MBAppConstants.TRAN_TYPE_CREDITCARD_MIN_AMT);					
				else if (CreditCardPayment.OPTION_STETEMENT_BALANCE.equalsIgnoreCase(cc.getPaymentOption()))
					scheduleResp.setCcPaymentType(MBAppConstants.TRAN_TYPE_CREDITCARD_LAST_STMT_AMT);					
				else if (CreditCardPayment.OPTION_FULL.equalsIgnoreCase(cc.getPaymentOption()))
					scheduleResp.setCcPaymentType(MBAppConstants.TRAN_TYPE_CREDITCARD_CURR_BAL);					
				else if (CreditCardPayment.OPTION_AMOUNT.equalsIgnoreCase(cc.getPaymentOption()))
					scheduleResp.setCcPaymentType(MBAppConstants.TRAN_TYPE_CREDITCARD_OTHER);	
				
			}else{
				AccountPayment pay = (AccountPayment)payment;
				
				scheduleResp.setTranType(MBAppConstants.TRAN_TYPE_ACCOUNT);
				toIndex = mbAppHelper.getAccountIndexByAccountId(customer.getAccounts(), pay.getToAccount());
				if (toIndex <0){
					Logger.error("Scheduled To Account not found in Customer cache", this.getClass());
					throw new BusinessException(BusinessException.ACCT_NOT_AVAILABLE_TO_DEPOSIT);
				}else{
					checkToAccountForDeposit(MBAppHelper.getAccountbyAccountId(pay.getToAccount(), customer.getAccounts()));
				}
				scheduleResp.setDesc(payment.getDescription());
			}									
			
			scheduleResp.setToItemIndex(toIndex);
						
		}						
		return scheduleResp;		
	}
			
	private List<SchedulePaymentInfoResp> getSchPaymentListResp(Collection scheduleList,Customer customer,int maxSchedules, boolean isExpiredSchedules){
		
		List<SchedulePaymentInfoResp> scheduleListResp = null;
		
		SchedulePaymentInfoResp scheduleInfo = null;
		TransferScheduleResp transferSchedule = null;
		int scheduleCount = 0;
		
		if(scheduleList != null){
			
			scheduleListResp = new ArrayList<SchedulePaymentInfoResp>();
			Iterator<Payment> it = scheduleList.iterator();
			List<Account> accts = customer.getAccounts();
			int toIndex;
			while(it.hasNext() && scheduleCount < maxSchedules){
				scheduleInfo = new SchedulePaymentInfoResp();				
				transferSchedule = new TransferScheduleResp();
				Payment schPayment = it.next();
				
				scheduleInfo.setAmt(schPayment.getAmount().toString());
				
				transferSchedule.setNextPayDate(schPayment.getScheduleDetails().getNextPaymentDate());
				transferSchedule.setFirstPaymentDate(schPayment.getScheduleDetails().getFirstPaymentDate());
				transferSchedule.setLastPayDate(schPayment.getScheduleDetails().getLastPaymentDate());
				transferSchedule.setScheduleId(Integer.parseInt(schPayment.getScheduleDetails().getId()));
				transferSchedule.setScheduleIdDisp("S" + schPayment.getScheduleDetails().getId());
				transferSchedule.setFreq(schPayment.getScheduleDetails().getFrequency());
				transferSchedule.setDueDaysCount(DateMethods.dateDiffInDays(schPayment.getScheduleDetails().getNextPaymentDate(), DateMethods.getUtilDate()));
				transferSchedule.setCreatedOn(schPayment.getScheduleDetails().getCreatedDate());
				
				String today = MBAppConstants.DATE_FORMAT_YYYYMMDD.format(DateMethods.getUtilDate());
				String nextPayDate = MBAppConstants.DATE_FORMAT_YYYYMMDD.format(schPayment.getScheduleDetails().getNextPaymentDate());
				
				if (!isExpiredSchedules){
					if (today.equals(nextPayDate) && (!ScheduleDetails.STATUS_SUSPENDED.equalsIgnoreCase(schPayment.getScheduleDetails().getStatusCode()))){
						scheduleInfo.setIsInProgress(true);
					}
				}				
				
				scheduleInfo.setStatus(schPayment.getScheduleDetails().getStatusCode());				
				Account fromAccount = MBAppHelper.getAccountbyAccountId(schPayment.getFromAccount(),accts);								
				if(fromAccount == null){					
					scheduleInfo.setIsFromAccountInvalid(true);
				}
										
				if (fromAccount!=null){
					
					AccountKeyInfoResp keyInfo = mbAppHelper.getAcctKeyInfoResp(fromAccount);
										
					scheduleInfo.setFromAccountName(fromAccount.getAlias());
					scheduleInfo.setFromAccountNumDisp(keyInfo.getAccountNumDisp());
					scheduleInfo.setFromBsbDisp(keyInfo.getBsbDisp());
					
					if (Account.BT.equals(fromAccount.getAccountId().getApplicationId()))
						scheduleInfo.setIsBTSchedule(true);
					
				}else{
					scheduleInfo.setFromAccountName(schPayment.getFromAccount().getFormattedAccountNumber());
					scheduleInfo.setIsAccountExpired(true);
				}
				
				if (schPayment instanceof AccountPayment){
					AccountPayment accountPayment = (AccountPayment)schPayment;
					Account toAccount = MBAppHelper.getAccountbyAccountId(accountPayment.getToAccount(),accts);
					
					if(toAccount == null){						
						scheduleInfo.setIsToAccountInvalid(true);
					}
					
					scheduleInfo.setTranType(MBAppConstants.TRAN_TYPE_ACCOUNT);
					scheduleInfo.setDesc(accountPayment.getDescription());
					
					if (toAccount!=null){
												
						AccountKeyInfoResp keyInfo = mbAppHelper.getAcctKeyInfoResp(toAccount);
						
						scheduleInfo.setToAccountName(toAccount.getAlias());
						scheduleInfo.setToAccountNumDisp(keyInfo.getAccountNumDisp());
						scheduleInfo.setToBsbDisp(keyInfo.getBsbDisp());
						
						if (StringMethods.isEmptyString(schPayment.getDescription()))
							scheduleInfo.setDesc("");
						else
							scheduleInfo.setDesc(schPayment.getDescription());
						
					}else{
						scheduleInfo.setToAccountName(accountPayment.getToAccount().getFormattedAccountNumber());
						scheduleInfo.setIsAccountExpired(true);
					}
					
				}else if(schPayment instanceof CreditCardPayment){
					CreditCardPayment creditPayment = (CreditCardPayment)schPayment;
					
					Account craAccount = MBAppHelper.getAccountbyAccountId(creditPayment.getToCard(),accts);					
					if(craAccount == null){						
						scheduleInfo.setIsToAccountInvalid(true);
					}
					
					scheduleInfo.setTranType(MBAppConstants.TRAN_TYPE_ACCOUNT);
					scheduleInfo.setDesc(creditPayment.getDescription());
					if (craAccount!=null){
						
						AccountKeyInfoResp keyInfo = mbAppHelper.getAcctKeyInfoResp(craAccount);
						
						scheduleInfo.setToAccountName(craAccount.getAlias());
						scheduleInfo.setToAccountNumDisp(keyInfo.getAccountNumDisp());
						scheduleInfo.setToBsbDisp(keyInfo.getBsbDisp());
						
						if (StringMethods.isEmptyString(schPayment.getDescription()))
							scheduleInfo.setDesc("");
						else
							scheduleInfo.setDesc(schPayment.getDescription());
					}else{
						scheduleInfo.setToAccountName(creditPayment.getToCard().getFormattedAccountNumber());
						scheduleInfo.setIsAccountExpired(true);
					}
					
				}else if(schPayment instanceof ThirdPartyPayment){
					ThirdPartyPayment tpPayment = (ThirdPartyPayment)schPayment;
					scheduleInfo.setTranType(MBAppConstants.TRAN_TYPE_PAYEE);
					
					toIndex = mbAppHelper.getThirdPartyIndexFromCustomer(customer, tpPayment.getToThirdParty().getBsb(), tpPayment.getToThirdParty().getNumber());
					if(toIndex < 0)
						scheduleInfo.setIsToAccountInvalid(true);
					
					if (tpPayment.isBTFundTransfer()){
						
						scheduleInfo.setIsBTSchedule(true);
						
						AccountId accountId = new AccountId();
						accountId.setApplicationId(Account.BT);
						accountId.setAccountNumber(tpPayment.getToThirdParty().getNumber());
						accountId.setBsb(tpPayment.getToThirdParty().getBsb());
						
						Account btAccount = MBAppHelper.getAccountbyAccountId(accountId,accts);
						
						AccountKeyInfoResp keyInfo = mbAppHelper.getAcctKeyInfoResp(btAccount);
						
						scheduleInfo.setPayeeName(btAccount.getAlias());
						scheduleInfo.setPayeeNum(keyInfo.getAccountNumDisp());
						scheduleInfo.setToBsbDisp(keyInfo.getBsbDisp());
																		
					}else{
						scheduleInfo.setPayeeName(tpPayment.getToThirdParty().getName());
						scheduleInfo.setPayeeNum(tpPayment.getToThirdParty().getFormattedAccountNumber());
						scheduleInfo.setToBsbDisp(StringUtil.formatBSBNumber(tpPayment.getToThirdParty().getBsb()));
					}
					
					scheduleInfo.setDesc(tpPayment.getDescription());
															
				}else if(schPayment instanceof BPayPayment){										
					BPayPayment bpayPayment = (BPayPayment)schPayment;
					scheduleInfo.setTranType(MBAppConstants.TRAN_TYPE_BPAY);
					
					toIndex = mbAppHelper.getBillerIndexFromCustomer(customer, bpayPayment.getToBiller(), false);
					if (toIndex < 0){
						toIndex = mbAppHelper.getBillerIndexFromCustomer(customer, bpayPayment.getToBiller(), true);
						if(toIndex < 0)
							scheduleInfo.setIsToAccountInvalid(true);
					}
					
					scheduleInfo.setBillerAlias(bpayPayment.getToBiller().getBillerAlias());
					scheduleInfo.setBillerCode(bpayPayment.getToBiller().getCode());
					scheduleInfo.setCrn(bpayPayment.getReferenceNumber());
				}
				
				scheduleInfo.setTranSchedule(transferSchedule);
				if(!(isExpiredSchedules && ScheduleDetails.FREQUENCY_ONCE_ONLY.equalsIgnoreCase(schPayment.getScheduleDetails().getFrequency()))) scheduleListResp.add(scheduleInfo);
				scheduleCount++;
			}			
		}		
		return scheduleListResp;		
	}
	
	private void checkToAccountForDeposit(Account toAccount) throws BusinessException {
		
		if ((toAccount.getAllowFlags() != null) && (!toAccount.getAllowFlags().isDepositAllowed())) {
			throw new BusinessException(BusinessException.ACCOUNT_TO_ACCT_NOT_ALLOW_DEPOSIT);
		}
	}
	
}
