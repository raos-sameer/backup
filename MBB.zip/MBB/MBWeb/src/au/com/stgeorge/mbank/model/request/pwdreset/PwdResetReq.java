package au.com.stgeorge.mbank.model.request.pwdreset;

import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import org.apache.commons.lang.builder.ReflectionToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;
import org.hibernate.validator.constraints.NotEmpty;

import au.com.stgeorge.ibank.businessobject.BusinessException;
import au.com.stgeorge.mbank.model.common.IMBReq;
import au.com.stgeorge.mbank.model.common.ReqHeader;

public class PwdResetReq implements IMBReq{

	/**
	 * 
	 */
	private static final long serialVersionUID = 3252631113988297336L;
	
	private ReqHeader header;
	
	@NotEmpty(message = "{errors.can.required}")
	@Size(min = 5, max = 8, message = ""+BusinessException.INVALID_ACCESS_NUMBER2)
	@Pattern(regexp="([0-9-]+)", message = ""+BusinessException.INVALID_ACCESS_NUMBER2)	
	private String can;
	
	@NotEmpty(message = "{errors.dateOfBirth.required}")
	@Pattern(regexp="\\d{4}-(0?[1-9]|1[012])-(0?[1-9]|[12][0-9]|3[01])", message = ""+BusinessException.INVALID_DATE_OF_BIRTH)	
	private String dateOfBirth;
	
	private String devicePrint;
	
	public ReqHeader getHeader() {
		return header;
	}

	public void setHeader(ReqHeader header) {
		this.header = header;
	}

	public String getCan() {
		return can;
	}

	public void setCan(String can) {
		this.can = can;
	}

	public String getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}
	
	public String getDevicePrint() {
		return devicePrint;
	}

	public void setDevicePrint(String devicePrint) {
		this.devicePrint = devicePrint;
	}

	@Override
	public String toString() {
		return ReflectionToStringBuilder.toString(this, ToStringStyle.MULTI_LINE_STYLE);
	}	
	

}
