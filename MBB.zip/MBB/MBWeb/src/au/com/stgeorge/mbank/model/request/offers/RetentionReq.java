package au.com.stgeorge.mbank.model.request.offers;

import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

import org.apache.commons.lang.builder.ReflectionToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;
import org.hibernate.validator.constraints.Length;
import org.hibernate.validator.constraints.NotEmpty;

import au.com.stgeorge.ibank.businessobject.BusinessException;
import au.com.stgeorge.mbank.model.common.IMBReq;
import au.com.stgeorge.mbank.model.common.ReqHeader;

/**
 * Transfer request
 * 
 * @author C38854
 * 
 */
public class RetentionReq implements IMBReq {

	/**
	 * 
	 */
	private static final long serialVersionUID = -4723751125232692028L;
	protected static final String AMT_PATTERN = "^[0-9]*\\.{0,1}(\\d{1,2}){0,1}$";
	protected static final String BLOCK_CHARS_PATTERN = "^[0-9A-Za-z',. &/\\-]*$";
	protected static final String BLOCK_CHARS_PATTERN_ORIGIN = "^[0-9A-Za-z_]*$";
	protected static final String MASK_NUMBERS = "^[0-9]+$";
	
	// @Valid TODO
	private ReqHeader header;

	@NotNull(message = "" + BusinessException.ACCOUNT_NO_FROM_ACCOUNT)
	@Min(value = 0, message="" + BusinessException.GENERIC_ERROR)
	private Integer fromAccountIndex;
	
	@NotNull(message = "" + BusinessException.ACCOUNT_NO_TO_ACCOUNT)
	private Integer toAccountIndex;
	
	@NotEmpty(message = "{errors.amt.required}")
	@Length(max = 14, message = "{errors.amt.maxlength}")
	@Pattern(regexp = AMT_PATTERN, message = "{errors.amt.blockchar}")
	private String amt;
	
	public Integer getToAccountIndex() {
		return toAccountIndex;
	}

	public void setToAccountIndex(Integer toAccountIndex) {
		this.toAccountIndex = toAccountIndex;
	}

	public Integer getFromAccountIndex() {
		return fromAccountIndex;
	}

	public String getAmt() {
		return amt;
	}

	public ReqHeader getHeader() {
		return header;
	}

	public void setHeader(ReqHeader header) {
		this.header = header;
	}
	
	@Override
	public String toString() {
		return ReflectionToStringBuilder.toString(this, ToStringStyle.MULTI_LINE_STYLE);
	}
}
