package au.com.stgeorge.mbank.model.request.mortgage;

import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.NotBlank;

import au.com.stgeorge.ibank.businessobject.BusinessException;
import au.com.stgeorge.mbank.model.common.IMBReq;
import au.com.stgeorge.mbank.model.common.ReqHeader;

public class RetrieveDetailsReq implements IMBReq {
	private ReqHeader header;

	@NotBlank(message = ""+BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE)
	@Pattern(regexp="([a-zA-Z0-9 ]+)",message = ""+BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE)
	private String referenceNumber; 
	
	@Email(message = ""+BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE)
	@NotBlank(message = ""+BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE)
	private String email;
	
	public ReqHeader getHeader() {
		return header;
	}

	public void setHeader(ReqHeader header) {
		this.header = header;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getReferenceNumber() {
		return referenceNumber;
	}

	public void setReferenceNumber(String referenceNumber) {
		this.referenceNumber = referenceNumber;
	}	
}
