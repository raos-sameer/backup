package au.com.stgeorge.mbank.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.AbstractController;

import au.com.stgeorge.framework.common.logging.Logger;
import au.com.stgeorge.ibank.businessobject.AscendaService;
import au.com.stgeorge.ibank.businessobject.BusinessException;
import au.com.stgeorge.ibank.businessobject.ResourceException;
import au.com.stgeorge.ibank.businessobject.impl.AscendaServiceHelper;
import au.com.stgeorge.ibank.valueobject.SAMLStore;
import au.com.stgeorge.ibank.valueobject.transfer.IBankCommonData;
import au.com.stgeorge.mbank.session.MobileSession;
import au.com.stgeorge.mbank.util.MBAppHelper;
import au.com.stgeorge.mbank.util.MBAppUtils;
import au.com.stgeorge.perflogger.PerformanceLogger;
import au.com.stgeorge.security.util.StringMethods;

@Controller
public class AscendaExternalController extends AbstractController{
	

	private static final String ASCENDA = "ascendaExternal";
	
	@Autowired
	private PerformanceLogger perfLogger;

	@Autowired
	private AscendaService ascendaService;
	
	@Autowired
	private MBAppHelper mbAppHelper;

	@Override
	protected ModelAndView handleRequestInternal(HttpServletRequest request, HttpServletResponse response) throws Exception
	{
		Logger.debug("AscendaExternalController - handleRequestInternal(). Request: " + request, this.getClass());	
		perfLogger.startAllLogs();
		String logName = MBAppUtils.getLogName(request);
		perfLogger.startLog(logName);
		
		String actionType = request.getParameter("actionType");	
		String token = request.getParameter("token");
		String brand = request.getParameter("brand");
		String origin = null;
		
		ModelAndView model = null;
		
		Logger.debug("ActionType :: " + actionType, this.getClass());	
		Logger.debug("Token :: " + token, this.getClass());	
		Logger.debug("Brand :: " + brand, this.getClass());	
		
		MobileSession mbSession = null;
		
		try
		{
			mbSession = mbAppHelper.getMobileSession(request);
			
			if ((ASCENDA.equalsIgnoreCase(actionType) && !StringMethods.isEmptyString(token) ))
			{
								
				SAMLStore samlStore = ascendaService.getIDToken(token, AscendaServiceHelper.ASCENDA);
				
				if(samlStore == null){
					throw new BusinessException(BusinessException.PDF_STATEMENT_NOT_FOUND);
				}
				
				String samlData = samlStore.getSamlData();						
				ascendaService.deleteIDTokenDetails(token, AscendaServiceHelper.ASCENDA);
				model = new ModelAndView(ASCENDA);
				
				if(brand.contains("Melbourne")) {
					origin="BOM";
				}else if (brand.contains("St.George")) {
					origin="STG";
				}else if(brand.contains("BankSA")) {
					origin="BSA";
				}
				
				Logger.debug("origin**** " + origin, this.getClass());		
				
				IBankCommonData commonData=  new IBankCommonData();
				commonData.setOrigin(origin);
		 	  						
				model.addObject("targetUrl", "/mb/jsp/ascendaExternal.jsp");
				String ascendaHTTPPOSTBindingURL = AscendaServiceHelper.getAscendaRedirectURL(origin)+"?idtoken="+samlData+"&ctxrefid="+samlStore.getToken();
				model.addObject("ascendaHTTPPOSTBindingURL", ascendaHTTPPOSTBindingURL);
				model.addObject("idtoken", samlData);
				model.addObject("ctxrefid", samlStore.getToken());
				
				Logger.debug("Ascenda recepient********* " + AscendaServiceHelper.getAscendaRedirectURL(origin), this.getClass());	
				Logger.debug("Ascenda - idtoken ********** " + samlData, this.getClass());
				Logger.debug("Ascenda - ctxrefid ********** " + samlStore.getToken(), this.getClass());	
				
				return model;
			}		

		} catch (BusinessException be) {
			Logger.error("BusinessException : " , be , this.getClass());
		} catch (ResourceException re) {
			Logger.error("ResourceException : " , re , this.getClass());
		} catch (Exception ex) {
			Logger.error("Exception : " , ex , this.getClass());		
		} finally {
			perfLogger.endLog(logName);
			perfLogger.endAllLogs();
			
			if(null != mbSession)
				mbSession.invalidateSession();
		}	
		return model;
	}

	

}
