package au.com.stgeorge.mbank.model.common;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_NULL)
public class BTSuperSearchResp {
	
	private int accountIndex;
	private String combine;
	private String notify;
	private String customise;
	private boolean minimiseTile;
	
	public int getAccountIndex() {
		return accountIndex;
	}
	public void setAccountIndex(int accountIndex) {
		this.accountIndex = accountIndex;
	}
	
	public String getCombine() {
		return combine;
	}
	public void setCombine(String combine) {
		this.combine = combine;
	}
	
	public String getNotify() {
		return notify;
	}
	public void setNotify(String notify) {
		this.notify = notify;
	}
	
	public String getCustomise() { 
		return customise;
	}
	public void setCustomise(String customise) {
		this.customise = customise;
	}
	
	public boolean isMinimiseTile() {
		return minimiseTile;
	}
	public void setMinimiseTile(boolean minimiseTile) {
		this.minimiseTile = minimiseTile;
	}

}
