package au.com.stgeorge.mbank.interceptor;

import java.util.Arrays;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

import au.com.stgeorge.framework.common.logging.Logger;


public class HttpResponseHeaderInterceptor extends HandlerInterceptorAdapter {
	
	private static final String CONTEXT_ROOT = "/mb/";
	private static final String CACHE_CONTROL = "Cache-Control";
	private static final String PRAGMA = "Pragma";
	private static final String EXPIRES = "Expires";
	private String cacheControl;
	private String pragma;
	private String expires;
	private String byPassURLs;


    @Override
    public boolean preHandle(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, Object handler) throws Exception {
    	Logger.debug("Inside preHandle(): ", this.getClass());
    	String newURL = httpServletRequest.getRequestURI();
    	newURL = newURL.replace(CONTEXT_ROOT, "");
    	List<String> byPassURLsList = Arrays.asList(byPassURLs.split("\\s*,\\s*"));
        if (!StringUtils.isEmpty(newURL) && !byPassURLsList.contains(newURL)) {
            httpServletResponse.setHeader(CACHE_CONTROL, cacheControl); 
            httpServletResponse.setHeader(PRAGMA, pragma); 
            httpServletResponse.setHeader(EXPIRES, expires); 
         }    	
		return true;
    }

    @Override
    public void postHandle(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, Object handler, ModelAndView modelAndView) throws Exception {
    	Logger.debug("Inside postHandle(): ", this.getClass());
    }

    @Override
    public void afterCompletion(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, Object handler, Exception e) throws Exception {
    	Logger.debug("Inside afterCompletion(): ", this.getClass());
    }

	public String getCacheControl() {
		return cacheControl;
	}

	public void setCacheControl(String cacheControl) {
		this.cacheControl = cacheControl;
	}

	public String getPragma() {
		return pragma;
	}

	public void setPragma(String pragma) {
		this.pragma = pragma;
	}

	public String getExpires() {
		return expires;
	}

	public void setExpires(String expires) {
		this.expires = expires;
	}

	public String getByPassURLs() {
		return byPassURLs;
	}

	public void setByPassURLs(String byPassURLs) {
		this.byPassURLs = byPassURLs;
	}

}
