package au.com.stgeorge.mbank.controller.newaccount;

import static au.com.stgeorge.ibank.businessobject.acctsvc.AccountService.DDA_ACCT_OPEN_SERVICE;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import au.com.stgeorge.debitcard.service.impl.DebitCardServiceImpl;
import au.com.stgeorge.framework.common.logging.Logger;
import au.com.stgeorge.framework.common.model.User;
import au.com.stgeorge.framework.common.util.StringMethods;
import au.com.stgeorge.ibank.businessobject.BusinessException;
import au.com.stgeorge.ibank.businessobject.ContentManagementService;
import au.com.stgeorge.ibank.businessobject.InvitationService;
import au.com.stgeorge.ibank.businessobject.OfferService;
import au.com.stgeorge.ibank.businessobject.ResourceException;
import au.com.stgeorge.ibank.businessobject.acctopenservice.AccountOpeningService;
import au.com.stgeorge.ibank.businessobject.acctsvc.DDAAccountOpeningService;
import au.com.stgeorge.ibank.common.cache.IBankParams;
import au.com.stgeorge.ibank.common.log.IBankLog;
import au.com.stgeorge.ibank.evcrs.util.EVConstants;
import au.com.stgeorge.ibank.util.ServiceHelper;
import au.com.stgeorge.ibank.valueobject.Account;
import au.com.stgeorge.ibank.valueobject.CRAProductListContent;
import au.com.stgeorge.ibank.valueobject.Customer;
import au.com.stgeorge.ibank.valueobject.Invitation.InvitationStatus;
import au.com.stgeorge.ibank.valueobject.database.AcctOpeningVO;
import au.com.stgeorge.ibank.valueobject.database.BranchVO;
import au.com.stgeorge.ibank.valueobject.database.CodesVO;
import au.com.stgeorge.ibank.valueobject.database.OriginsVO;
import au.com.stgeorge.ibank.valueobject.database.RegionVO;
import au.com.stgeorge.ibank.valueobject.transfer.IBankCommonData;
import au.com.stgeorge.ibank.valueobject.transfer.NewDDAAccount;
import au.com.stgeorge.mbank.controller.IMBController;
import au.com.stgeorge.mbank.controller.MainController;
import au.com.stgeorge.mbank.controller.customer.LogonHelper;
import au.com.stgeorge.mbank.controller.services.TFNHelper;
import au.com.stgeorge.mbank.model.common.IMBReq;
import au.com.stgeorge.mbank.model.common.IMBResp;
import au.com.stgeorge.mbank.model.common.ProductReq;
import au.com.stgeorge.mbank.model.common.ReqHeader;
import au.com.stgeorge.mbank.model.common.RespHeader;
import au.com.stgeorge.mbank.model.request.newaccount.FundDDAAcctReq;
import au.com.stgeorge.mbank.model.request.newaccount.OpenDDAAcctReq;
import au.com.stgeorge.mbank.model.request.newaccount.OpenDDAReq;
import au.com.stgeorge.mbank.model.response.ErrorResp;
import au.com.stgeorge.mbank.model.response.services.TFNCheckResp;
import au.com.stgeorge.mbank.session.MobileSession;
import au.com.stgeorge.mbank.util.FraudLogger;
import au.com.stgeorge.mbank.util.MBAppConstants;
import au.com.stgeorge.mbank.util.MBAppHelper;
import au.com.stgeorge.mbank.util.MBAppUtils;
import au.com.stgeorge.mbank.util.MBAppValidator;
import au.com.stgeorge.mobilebank.businessobject.MobileBankService;
import au.com.stgeorge.mobilebank.businessobject.OpenDDAService;
import au.com.stgeorge.mobilebank.businessobject.impl.OpenDDAServiceImpl;
import au.com.stgeorge.perflogger.PerformanceLogger;

import com.fasterxml.jackson.databind.ObjectMapper;

@Controller
@RequestMapping("/newaccount")
public class OpenDDAController implements IMBController {

  private static final String OPEN_DDA_ACCOUNT = "openDDAAccount";

  private static final String ACCT_OPEN_SERVICE = "acctOpenService";

  private FraudLogger fraudLogger;

  @Autowired
  private MBAppHelper mbAppHelper;

  @Autowired
  private OpenDDAHelper openDDAHelper;

  @Autowired
  private DDAAccountOpeningService ddaAcctOpenSvc;

  @Autowired
  private OpenDDAService openDDAService;

  @Autowired
  private MobileBankService mobileBankService;

  @Autowired
  private LogonHelper logonHelper;

  @Autowired
  private NewAcctStructureLocator newAcctStructureLocator;

  @Autowired
  private InvitationService invitationService;

  @Autowired
  private OfferService offerService;

  @Autowired
  private ContentManagementService contentManagementService;

  @Autowired
  private DebitCardServiceImpl debitCardService;

  @Autowired
  private MBAppValidator mbAppValidator;
  
  //19E3 code
  @Autowired
  private TFNHelper tfnHelper;
  

  @RequestMapping(value = "detail", method = RequestMethod.POST,
      headers = "content-type=application/json", produces = MediaType.APPLICATION_JSON_VALUE)
  @ResponseBody
  public IMBResp getFundingAccount(HttpServletRequest httpServletRequest,
      HttpServletResponse httpServletResponse, @RequestBody final OpenDDAReq req) {
    Logger.debug("In getFundingAccount ( OpenDDAController )  for Customer " + "  "
        + httpServletRequest.getContentType() + " " + httpServletRequest.getRemoteAddr() + "  "
        + httpServletResponse.getCharacterEncoding() + httpServletResponse.getLocale()
        + " True IP >> " + httpServletRequest.getHeader(IBankParams.trueClientIP()),
        this.getClass());

    PerformanceLogger performanceLogger = new PerformanceLogger();
    fraudLogger = new FraudLogger();
    performanceLogger.startAllLogs();
    String logName = MBAppUtils.getLogName(httpServletRequest);
    performanceLogger.startLog(logName);
    boolean hasEligibleWorkAcc = false;
    MobileSession mbSession = null;
    ObjectMapper mapper = new ObjectMapper();
    try {
      Logger.info("getFundingAccount JSON Request :" + mapper.writeValueAsString(req),
          this.getClass());
      mbSession = mbAppHelper.getMobileSession(httpServletRequest);

      ErrorResp errorResp = validateRequest(httpServletRequest, req);
      if (errorResp != null) {
    	  return errorResp;
      }
      
      IBankCommonData ibankCommonData =
          mbAppHelper.populateIBankCommonData(mbSession, httpServletRequest);
      
      //20E2 - Redirect to GCC WDP UI if Master Card Switch is ON
      String actionType = (String) httpServletRequest.getAttribute(MainController.REQ_ACTION_TYPE);
      Logger.info("getFundingAccount GCC ActionType:" + actionType, this.getClass());
	  if(!StringUtils.isEmpty(actionType) && MainController.APPLY_GCC.equalsIgnoreCase(actionType) ) {
		  if ( IBankParams.isGCCMasterCardOriginationSwitchOn(ibankCommonData.getOrigin(), ibankCommonData.getCustomer().getGcis()))
		  {
	  		Logger.debug("Redirecting to launch action...", this.getClass());
	  		httpServletResponse.sendRedirect("redirect:" + "launch?app=GCCOrigination");
		  }
		  else
		  {
			Logger.debug("Redirecting to return Dashboard action. GCIS : " + ibankCommonData.getCustomer().getGcis() , this.getClass());
			httpServletResponse.sendRedirect("redirect:" + "return");
			return null;
		  }	  
	  }
      
      List<Account> fundingAccounts = openDDAService.getFundingAccounts(ibankCommonData);
      Collection<RegionVO> regions = null;
      if (MBAppConstants.ORIGIN_MBSA.equals(ibankCommonData.getOrigin())) {
        regions = openDDAService.getRegion();
      }

      int subProdcode = openDDAHelper.getProdID(req.getProduct().getSubProdcode());
      if (IBankParams.MAXI_SAVER_ACCOUNT == subProdcode) {
        hasEligibleWorkAcc = openDDAService.hasEligibleAccount(ibankCommonData);
      }

      IMBResp serviceResponse =
          openDDAHelper.populateResponse(mbSession, fundingAccounts, mbSession.getCustomer()
              .getAccounts(), regions, req.getProduct(), hasEligibleWorkAcc);
      Logger.info("getFundingAccount JSON Response :" + mapper.writeValueAsString(serviceResponse),
          this.getClass());
      RespHeader headerResp = populateResponseHeader(req.getHeader().getServiceName(), mbSession);
      serviceResponse.setHeader(headerResp);
      return serviceResponse;
    } catch (BusinessException e) {
      Logger.error("Exception Inside getFundingAccount() for Customer GCIS: ["
          + ((mbSession != null && mbSession.getCustomer() != null) ? mbSession.getCustomer()
              .getGcis() : "") + "] :", e, this.getClass());
      String errorMsg = null;
      IMBResp resp1 = null;
      resp1 =
          MBAppUtils.createErrorResp(mbSession.getOrigin(), e,
              MBAppConstants.SMPL_OPENDDAACCOUNT_RESP_NAME, httpServletRequest);
      return resp1;
    } catch (Exception e) {
      Logger.error("Exception Inside getFundingAccount() for Customer GCIS: ["
          + ((mbSession != null && mbSession.getCustomer() != null) ? mbSession.getCustomer()
              .getGcis() : "") + "] :", e, this.getClass());
      BusinessException exp = new BusinessException(BusinessException.SMPL_SYS_ERROR);
      IMBResp resp1 =
          MBAppUtils.createErrorResp(mbSession.getOrigin(), exp,
              MBAppConstants.SMPL_OPENDDAACCOUNT_RESP_NAME, httpServletRequest);
      return resp1;
    } finally {
      performanceLogger.endLog(logName);
      performanceLogger.endAllLogs();
    }
  }

  @RequestMapping(value = "branches", method = RequestMethod.POST,
      headers = "content-type=application/json", produces = MediaType.APPLICATION_JSON_VALUE)
  @ResponseBody
  public IMBResp getBranches(HttpServletRequest httpServletRequest,
      HttpServletResponse httpServletResponse, @RequestBody final OpenDDAReq req) {
    Logger.debug(
        "In getBranches ( OpenDDAController )  for OpenDDA " + "  "
            + httpServletRequest.getContentType() + " " + httpServletRequest.getRemoteAddr() + "  "
            + httpServletResponse.getCharacterEncoding() + httpServletResponse.getLocale()
            + " True IP >> " + httpServletRequest.getHeader(IBankParams.trueClientIP()),
        this.getClass());

    PerformanceLogger performanceLogger = new PerformanceLogger();
    fraudLogger = new FraudLogger();
    performanceLogger.startAllLogs();
    String logName = MBAppUtils.getLogName(httpServletRequest);
    performanceLogger.startLog(logName);
    ObjectMapper mapper = new ObjectMapper();
    MobileSession mbSession = null;
    try {
      Logger.info("getBranches JSON Request :" + mapper.writeValueAsString(req), this.getClass());
      mbSession = mbAppHelper.getMobileSession(httpServletRequest);

      ErrorResp errorResp = validateRequest(httpServletRequest, req);
      if (errorResp != null) {
    	  return errorResp;
      }
      
      List<BranchVO> branches = openDDAService.getBranch(req.getRegionId());
      IMBResp serviceResponse = openDDAHelper.populateBranchDtlResp(branches);
      Logger.info("getBranches JSON Response :" + mapper.writeValueAsString(serviceResponse),
          this.getClass());
      RespHeader headerResp = populateResponseHeader(req.getHeader().getServiceName(), mbSession);
      serviceResponse.setHeader(headerResp);
      return serviceResponse;
    } catch (BusinessException e) {
      Logger.error("Exception Inside getBranches() for OpenDDA GCIS: ["
          + ((mbSession != null && mbSession.getCustomer() != null) ? mbSession.getCustomer()
              .getGcis() : "") + "] :", e, this.getClass());
      IMBResp resp1 =
          MBAppUtils.createErrorResp(mbSession.getOrigin(), e,
              MBAppConstants.SMPL_OPENDDAACCOUNT_RESP_NAME, httpServletRequest);
      return resp1;
    } catch (Exception e) {
      Logger.error("Exception Inside getBranches() for OpenDDA GCIS: ["
          + ((mbSession != null && mbSession.getCustomer() != null) ? mbSession.getCustomer()
              .getGcis() : "") + "] :", e, this.getClass());
      BusinessException exp = new BusinessException(BusinessException.SMPL_SYS_ERROR);
      IMBResp resp1 =
          MBAppUtils.createErrorResp(mbSession.getOrigin(), exp,
              MBAppConstants.SMPL_OPENDDAACCOUNT_RESP_NAME, httpServletRequest);
      return resp1;
    } finally {
      performanceLogger.endLog(logName);
      performanceLogger.endAllLogs();
    }
  }

  @RequestMapping(value = "bsaregions", method = RequestMethod.POST,
      headers = "content-type=application/json", produces = MediaType.APPLICATION_JSON_VALUE)
  @ResponseBody
  public IMBResp getBankSARegions(HttpServletRequest httpServletRequest,
      HttpServletResponse httpServletResponse, @RequestBody final OpenDDAReq req) {
    Logger.debug("In getBankSARegions ( OpenDDAController )  for OpenDDA " + "  "
        + httpServletRequest.getContentType() + " " + httpServletRequest.getRemoteAddr() + "  "
        + httpServletResponse.getCharacterEncoding() + httpServletResponse.getLocale()
        + " True IP >> " + httpServletRequest.getHeader(IBankParams.trueClientIP()),
        this.getClass());

    PerformanceLogger performanceLogger = new PerformanceLogger();
    fraudLogger = new FraudLogger();
    performanceLogger.startAllLogs();
    String logName = MBAppUtils.getLogName(httpServletRequest);
    performanceLogger.startLog(logName);
    ObjectMapper mapper = new ObjectMapper();
    MobileSession mbSession = null;
    try {
      Logger.info("getBankSARegions JSON Request :" + mapper.writeValueAsString(req),
          this.getClass());
      mbSession = mbAppHelper.getMobileSession(httpServletRequest);

      ErrorResp errorResp = validateRequest(httpServletRequest, req);
      if (errorResp != null) {
    	  return errorResp;
      }
      
      IBankCommonData ibankCommonData =
          mbAppHelper.populateIBankCommonData(mbSession, httpServletRequest);
      Collection<RegionVO> regions = null;
      if (MBAppConstants.ORIGIN_MBSA.equals(ibankCommonData.getOrigin())) {
        regions = openDDAService.getRegion();
      }

      IMBResp serviceResponse = openDDAHelper.populateBankSARegionsResp(regions);
      Logger.info("getBankSARegions JSON Response :" + mapper.writeValueAsString(serviceResponse),
          this.getClass());
      RespHeader headerResp = populateResponseHeader(req.getHeader().getServiceName(), mbSession);
      serviceResponse.setHeader(headerResp);
      return serviceResponse;
    } catch (BusinessException e) {
      Logger.error("Exception Inside getBankSARegions() for OpenDDA GCIS: ["
          + ((mbSession != null && mbSession.getCustomer() != null) ? mbSession.getCustomer()
              .getGcis() : "") + "] :", e, this.getClass());
      IMBResp resp1 =
          MBAppUtils.createErrorResp(mbSession.getOrigin(), e,
              MBAppConstants.SMPL_OPENDDAACCOUNT_RESP_NAME, httpServletRequest);
      return resp1;
    } catch (Exception e) {
      Logger.error("Exception Inside getBankSARegions() for OpenDDA GCIS: ["
          + ((mbSession != null && mbSession.getCustomer() != null) ? mbSession.getCustomer()
              .getGcis() : "") + "] :", e, this.getClass());
      BusinessException exp = new BusinessException(BusinessException.SMPL_SYS_ERROR);
      IMBResp resp1 =
          MBAppUtils.createErrorResp(mbSession.getOrigin(), exp,
              MBAppConstants.SMPL_OPENDDAACCOUNT_RESP_NAME, httpServletRequest);
      return resp1;
    } finally {
      performanceLogger.endLog(logName);
      performanceLogger.endAllLogs();
    }
  }

  @RequestMapping(value = "branchaddress", method = RequestMethod.POST,
      headers = "content-type=application/json", produces = MediaType.APPLICATION_JSON_VALUE)
  @ResponseBody
  public IMBResp getBranch(HttpServletRequest httpServletRequest,
      HttpServletResponse httpServletResponse, @RequestBody final OpenDDAReq req) {
    Logger.debug(
        "In getBranch ( OpenDDAController )  for Customer " + "  "
            + httpServletRequest.getContentType() + " " + httpServletRequest.getRemoteAddr() + "  "
            + httpServletResponse.getCharacterEncoding() + httpServletResponse.getLocale()
            + " True IP >> " + httpServletRequest.getHeader(IBankParams.trueClientIP()),
        this.getClass());

    PerformanceLogger performanceLogger = new PerformanceLogger();
    fraudLogger = new FraudLogger();
    performanceLogger.startAllLogs();
    String logName = MBAppUtils.getLogName(httpServletRequest);
    performanceLogger.startLog(logName);
    ObjectMapper mapper = new ObjectMapper();
    MobileSession mbSession = null;
    try {
      Logger.info("getBranch JSON Request :" + mapper.writeValueAsString(req), this.getClass());
      mbSession = mbAppHelper.getMobileSession(httpServletRequest);
      
      ErrorResp errorResp = validateRequest(httpServletRequest, req);
      if (errorResp != null) {
    	  return errorResp;
      }
      
      List<BranchVO> branches = openDDAService.getBranch(req.getRegionId());
      BranchVO branch = getBranch(branches, req.getBranchId());
      IMBResp serviceResponse = openDDAHelper.populateBranchResp(branch);
      Logger.info("getFundingAccount JSON Response :" + mapper.writeValueAsString(serviceResponse),
          this.getClass());
      RespHeader headerResp = populateResponseHeader(req.getHeader().getServiceName(), mbSession);
      serviceResponse.setHeader(headerResp);
      return serviceResponse;
    } catch (BusinessException e) {
      Logger.error("Exception Inside getFundingAccount() for Customer GCIS: ["
          + ((mbSession != null && mbSession.getCustomer() != null) ? mbSession.getCustomer()
              .getGcis() : "") + "] :", e, this.getClass());
      IMBResp resp1 =
          MBAppUtils.createErrorResp(mbSession.getOrigin(), e,
              MBAppConstants.SMPL_OPENDDAACCOUNT_RESP_NAME, httpServletRequest);
      return resp1;
    } catch (Exception e) {
      Logger.error("Exception Inside getFundingAccount() for Customer GCIS: ["
          + ((mbSession != null && mbSession.getCustomer() != null) ? mbSession.getCustomer()
              .getGcis() : "") + "] :", e, this.getClass());
      BusinessException exp = new BusinessException(BusinessException.SMPL_SYS_ERROR);
      IMBResp resp1 =
          MBAppUtils.createErrorResp(mbSession.getOrigin(), exp,
              MBAppConstants.SMPL_OPENDDAACCOUNT_RESP_NAME, httpServletRequest);
      return resp1;
    } finally {
      performanceLogger.endLog(logName);
      performanceLogger.endAllLogs();
    }
  }

  @RequestMapping(value = "maxisaverdetail", method = RequestMethod.POST,
      headers = "content-type=application/json", produces = MediaType.APPLICATION_JSON_VALUE)
  @ResponseBody
  public IMBResp getMaxiSaverDetail(HttpServletRequest httpServletRequest,
      HttpServletResponse httpServletResponse, @RequestBody final OpenDDAReq req) {
    Logger.debug("In maxisaverdetail ( OpenDDAController )  for OpenDDA " + "  "
        + httpServletRequest.getContentType() + " " + httpServletRequest.getRemoteAddr() + "  "
        + httpServletResponse.getCharacterEncoding() + httpServletResponse.getLocale()
        + " True IP >> " + httpServletRequest.getHeader(IBankParams.trueClientIP()),
        this.getClass());

    PerformanceLogger performanceLogger = new PerformanceLogger();
    fraudLogger = new FraudLogger();
    performanceLogger.startAllLogs();
    String logName = MBAppUtils.getLogName(httpServletRequest);
    performanceLogger.startLog(logName);
    ObjectMapper mapper = new ObjectMapper();
    MobileSession mbSession = null;
    boolean hasEligibleWorkAcc = false;
    try {
      Logger.info("maxisaverdetail JSON Request :" + mapper.writeValueAsString(req),
          this.getClass());
      mbSession = mbAppHelper.getMobileSession(httpServletRequest);

      ErrorResp errorResp = validateRequest(httpServletRequest, req);
      if (errorResp != null) {
    	  return errorResp;
      }
      
      IBankCommonData ibankCommonData =
          mbAppHelper.populateIBankCommonData(mbSession, httpServletRequest);
      
      Customer customer = ibankCommonData.getCustomer();
      
      int subProdcode = openDDAHelper.getProdID(req.getProduct().getSubProdcode());
      if (IBankParams.MAXI_SAVER_ACCOUNT == subProdcode) {
        hasEligibleWorkAcc = openDDAService.hasEligibleAccount(ibankCommonData);
      }
      
    //19E3 TFN code
	  Boolean showTfn = tfnHelper.showTfn(ibankCommonData,mbSession);
	  TFNCheckResp tfnCheck=null;
	  if(showTfn!=null && showTfn){
			 Logger.debug("OpenDDAController - getMaxiSaverDetail - populating tfn widget properties:START", this.getClass());
			//populate the response
			 tfnCheck = new TFNCheckResp();
			 tfnCheck.setExemptionList(tfnHelper.getTFNExemptOptList());
			 tfnCheck.setTfnOptionList(tfnHelper.getTFNOptionList());	
			 
			//Business customer
			if(null!= customer && ("B".equalsIgnoreCase(customer.getCustTypeInd()) 
						|| customer.isCHSCustomer() || customer.isCHSGHSCustomer())){
				Logger.debug("TaxFileNumberHelper - Business customer", this.getClass());
				tfnCheck.setBusinessCustomer(true);
			}
				
			Logger.debug("OpenDDAController - getMaxiSaverDetail - populating tfn widget properties:END", this.getClass());
		}
		
		//set showTfn irrespective true or false to avoid null pointer in openTermDepositAccount method.
	  mbSession.setShowTfn(showTfn);
      IMBResp serviceResponse = openDDAHelper.populateMaxiSaverDetail(hasEligibleWorkAcc,tfnCheck);

      Logger.info("maxisaverdetail JSON Response :" + mapper.writeValueAsString(serviceResponse),
          this.getClass());
      RespHeader headerResp = populateResponseHeader(req.getHeader().getServiceName(), mbSession);
      serviceResponse.setHeader(headerResp);
      return serviceResponse;
    } catch (BusinessException e) {
      Logger.error("Exception Inside maxisaverdetail() for OpenDDA GCIS: ["
          + ((mbSession != null && mbSession.getCustomer() != null) ? mbSession.getCustomer()
              .getGcis() : "") + "] :", e, this.getClass());
      IMBResp resp1 =
          MBAppUtils.createErrorResp(mbSession.getOrigin(), e,
              MBAppConstants.SMPL_OPENDDAACCOUNT_RESP_NAME, httpServletRequest);
      return resp1;
    } catch (Exception e) {
      Logger.error("Exception Inside maxisaverdetail() for OpenDDA GCIS: ["
          + ((mbSession != null && mbSession.getCustomer() != null) ? mbSession.getCustomer()
              .getGcis() : "") + "] :", e, this.getClass());
      BusinessException exp = new BusinessException(BusinessException.SMPL_SYS_ERROR);
      IMBResp resp1 =
          MBAppUtils.createErrorResp(mbSession.getOrigin(), exp,
              MBAppConstants.SMPL_OPENDDAACCOUNT_RESP_NAME, httpServletRequest);
      return resp1;
    } finally {
      performanceLogger.endLog(logName);
      performanceLogger.endAllLogs();
    }
  }

  @RequestMapping(value = "open", method = RequestMethod.POST,
      headers = "content-type=application/json", produces = MediaType.APPLICATION_JSON_VALUE)
  @ResponseBody
  public IMBResp openDDAAccount(HttpServletRequest httpServletRequest,
      HttpServletResponse httpServletResponse, @RequestBody final OpenDDAReq req) {
    Logger.debug("In openDDAAccount ( OpenDDAController )  for Customer " + "  "
        + httpServletRequest.getContentType() + " " + httpServletRequest.getRemoteAddr() + "  "
        + httpServletResponse.getCharacterEncoding() + httpServletResponse.getLocale()
        + " True IP >> " + httpServletRequest.getHeader(IBankParams.trueClientIP()),
        this.getClass());
    PerformanceLogger performanceLogger = new PerformanceLogger();
    fraudLogger = new FraudLogger();
    performanceLogger.startAllLogs();
    String logName = MBAppUtils.getLogName(httpServletRequest);
    performanceLogger.startLog(logName);
    ObjectMapper mapper = new ObjectMapper();
    MobileSession mbSession = null;
    try {
      Logger
          .info("openDDAAccount JSON Request :" + mapper.writeValueAsString(req), this.getClass());
      mbSession = mbAppHelper.getMobileSession(httpServletRequest);

      ErrorResp errorResp = validateRequest(httpServletRequest, req);
      if (errorResp != null) {
    	  return errorResp;
      }
      
      IBankCommonData ibankCommonData =
          mbAppHelper.populateIBankCommonData(mbSession, httpServletRequest);
      
      
      IMBResp serviceResponse;
      openDDAHelper.validateAmount(req);
      openDDAHelper.validateAddress(mbSession.getCustomer());
      openDDAHelper.validateFundingAccount(mbSession.getCustomer(), req.getFundingAccountIndex());
      boolean isCustomerOver18 = openDDAHelper.isCustomerOver18(mbSession.getCustomer());
      // if (!isCustomerOver18)
      // openDDAHelper.setRequestCard("N");
      openDDAHelper.validateCardDeliveryAddress(mbSession.getCustomer(), isCustomerOver18);

      if (req.isCheckDuplicate()) {
        ArrayList duplicateAcctOpeningList =
            getDuplicateList(mbSession, req.getProduct(), ibankCommonData);
        if (duplicateAcctOpeningList != null && duplicateAcctOpeningList.size() > 0) {
          serviceResponse = openDDAHelper.populateDuplicateAcctsList(duplicateAcctOpeningList);
        } else {
          NewDDAAccount account = openDDAHelper.populateNewAccount(mbSession, req, ibankCommonData);
          account.setAccountOpenedMode("MB");
          if (!isCustomerOver18)
            account.setIsNewCardRequested(false);
          NewDDAAccount newDDAAccount = (NewDDAAccount) ddaAcctOpenSvc.createAccount(account);
          
          // ArrayList<au.com.stgeorge.mbank.model.common.AccountResp>
          // accountList =
          // logonHelper.populateAccountList(mbSession.getCustomer().getAccounts());
          ArrayList<au.com.stgeorge.mbank.model.common.AccountResp> accountList =
              logonHelper.populateAccountList(mbSession.getCustomer(),
                  mbSession.getAutoApplyRetentionInfo());
          serviceResponse = openDDAHelper.populateopenDDAAccountResp(accountList, newDDAAccount);
        }
      } else {
        NewDDAAccount account = openDDAHelper.populateNewAccount(mbSession, req, ibankCommonData);
        account.setAccountOpenedMode("MB");
        if (!isCustomerOver18)
          account.setIsNewCardRequested(false);
        NewDDAAccount newDDAAccount = (NewDDAAccount) ddaAcctOpenSvc.createAccount(account);
        ArrayList<au.com.stgeorge.mbank.model.common.AccountResp> accountList =
            logonHelper.populateAccountList(mbSession.getCustomer(),
                mbSession.getAutoApplyRetentionInfo());
        serviceResponse = openDDAHelper.populateopenDDAAccountResp(accountList, newDDAAccount);
      }
      Logger.info("openDDAAccount JSON Response :" + mapper.writeValueAsString(serviceResponse),
          this.getClass());
      RespHeader headerResp = populateResponseHeader(req.getHeader().getServiceName(), mbSession);
      serviceResponse.setHeader(headerResp);
      return serviceResponse;
    } catch (BusinessException e) {
      Logger.error("Exception Inside openDDAAccount() for Customer " + e.getKey(), e,
          this.getClass());
      IMBResp resp1 = null;

      if (e.getKey() == BusinessException.AMT_EXCEEDS_AVAILABLE_AMT) {
        BusinessException bx = new BusinessException(BusinessException.ACCOUNT_OPENING_INSUF_FUND);
        resp1 =
            MBAppUtils.createErrorResp(mbSession.getOrigin(), bx,
                MBAppConstants.SMPL_OPENDDAACCOUNT_RESP_NAME, httpServletRequest);
      } else if (e.getKey() == BusinessException.MAX_ACCT_OPENING_REQ
          || e.getKey() == BusinessException.INVALID_MIN_AMT) {
        resp1 =
            MBAppUtils.createErrorResp(mbSession.getOrigin(), e, e.getValues(),
                MBAppConstants.SMPL_OPENDDAACCOUNT_RESP_NAME, httpServletRequest);
      } else {
        resp1 =
            MBAppUtils.createErrorResp(mbSession.getOrigin(), e,
                MBAppConstants.SMPL_OPENDDAACCOUNT_RESP_NAME, httpServletRequest);
      }
      return resp1;
    } catch (Exception e) {
      Logger.error("Exception Inside openDDAAccount() for Customer GCIS: ["
          + ((mbSession != null && mbSession.getCustomer() != null) ? mbSession.getCustomer()
              .getGcis() : "") + "] :", e, this.getClass());
      BusinessException exp = new BusinessException(BusinessException.SMPL_SYS_ERROR);
      IMBResp resp1 =
          MBAppUtils.createErrorResp(mbSession.getOrigin(), exp,
              MBAppConstants.SMPL_OPENDDAACCOUNT_RESP_NAME, httpServletRequest);
      return resp1;
    } finally {
      performanceLogger.endLog(logName);
      performanceLogger.endAllLogs();
    }
  }
	
	@RequestMapping(value = "openacct", method = RequestMethod.POST, headers = "content-type=application/json", produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public IMBResp openDDANewAccount(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, @RequestBody final OpenDDAAcctReq req) {
	    Logger.debug("In openDDANewAccount ( OpenDDAController )  for Customer " + "  "
	        + httpServletRequest.getContentType() + " " + httpServletRequest.getRemoteAddr() + "  "
	        + httpServletResponse.getCharacterEncoding() + httpServletResponse.getLocale()
	        + " True IP >> " + httpServletRequest.getHeader(IBankParams.trueClientIP()),
	        this.getClass());
	    
	    PerformanceLogger performanceLogger = new PerformanceLogger();
	    fraudLogger = new FraudLogger();
	    performanceLogger.startAllLogs();
	    String logName = MBAppUtils.getLogName(httpServletRequest);
	    performanceLogger.startLog(logName);
	    
	    MobileSession mbSession = null;
	    IMBResp serviceResponse;
	    
	    try {
	    	ObjectMapper mapper = new ObjectMapper();
		    
	    	Logger.info("openDDANewAccount JSON Request :" + mapper.writeValueAsString(req), this.getClass());
	    	mbSession = mbAppHelper.getMobileSession(httpServletRequest);
	
	    	ErrorResp errorResp = validateRequest(httpServletRequest, req);
	    	if (errorResp != null) {
	    		return errorResp;
	    	}
	      
	    	IBankCommonData ibankCommonData = mbAppHelper.populateIBankCommonData(mbSession, httpServletRequest);
	    	openDDAHelper.validateAddress(mbSession.getCustomer());
	      
	    	// validate the sense target
	    	validateSenseTarget(req);
	    	
	    	//19E3 Changes
			//if switch is On and !tfnheld - then get values from req and do validation
			Boolean statUpdTfn=false;
			Boolean showTfn = mbSession.getShowTfn();
			Logger.debug("OpenDDAController - openDDANewAccount - showTfnValue : "+showTfn,this.getClass());
			if(showTfn!=null){
				if(showTfn){
					//trigger validations
					 Logger.debug("OpenDDAController - openDDANewAccount - validations", this.getClass());
					 if(null != req.getSelectedOption() && !req.getSelectedOption().equals("1")){
					    tfnHelper.validateTFN(req.getSelectedOption(),req.getTaxFileNumber(),req.getSelectedExemption());
					    statUpdTfn = tfnHelper.updateTFN(ibankCommonData,req.getSelectedOption(),req.getTaxFileNumber(),req.getSelectedExemption());
					    Logger.debug("OpenDDAController - openDDANewAccount- TFN update :"+statUpdTfn, this.getClass());
				      } 
				}else{
					Logger.debug("Open DDAController this condition gets executed when TFN widget was not shown and TFN was already submitted previously::", this.getClass());
					  statUpdTfn=true;
				}
				 
	        }

	    	AccountOpeningService accountOpeningService = (AccountOpeningService) ServiceHelper.getBean(DDA_ACCT_OPEN_SERVICE);
	    	
	    	//Fixing security flaw
	    	//verify if there max number of accounts was reached, if the MAX_ACCT_OPENING_REQ exception is raised, there is not need to chek
			//the overrideDuplicate flag
			ArrayList<AcctOpeningVO> duplicateAcctOpeningList = openDDAHelper.getNewAcctDuplicateList(req.getProduct(), ibankCommonData, accountOpeningService);
			
	    	// override the duplicate check
	    	if (req.getOverrideDuplicate()) {
	    		serviceResponse = openDDAHelper.openNewDDAAccount(req, mbSession, ibankCommonData, accountOpeningService, logonHelper, openDDAService, debitCardService,statUpdTfn);
	    	} else {
	    		if (duplicateAcctOpeningList != null && duplicateAcctOpeningList.size() > 0) {
	    			serviceResponse = openDDAHelper.populateDDADuplicateList(duplicateAcctOpeningList);
	    		} else {
	    			serviceResponse = openDDAHelper.openNewDDAAccount(req, mbSession, ibankCommonData, accountOpeningService, logonHelper, openDDAService, debitCardService,statUpdTfn);
	    		}
	    	}
	    	
		      
			//19E3 warranty changes
	    	if(req.getProduct().getSubProdcode().equals("COMPLETE_FREEDOM") && req.getProduct().getType().equals("DDA")) {
				Boolean showTFNCompleteFreedon = null;
				boolean tfnException = false;
				try {
					showTFNCompleteFreedon = tfnHelper.showTfn(ibankCommonData, mbSession);
					
					if(null == showTFNCompleteFreedon)
						showTFNCompleteFreedon = false;
					
				} catch (Exception e){
					Logger.warn("openDDANewAccount : Exception while TFN Enquiry: "+e.getMessage(), this.getClass());
					tfnException = true;
				}
				
				openDDAHelper.populateTFNResponse(serviceResponse, showTFNCompleteFreedon, tfnException);
	    	} else {
	    		openDDAHelper.populateTFNResponse(serviceResponse, false, false);
	    	}
		
	    	Logger.info("openDDANewAccount JSON Response :" + mapper.writeValueAsString(serviceResponse), this.getClass());
	    	RespHeader headerResp = populateResponseHeader(req.getHeader().getServiceName(), mbSession);
	    	serviceResponse.setHeader(headerResp);

	    	//19E3 : Warranty fix
	    	mbSession.removeShowTfn();
	    	
	    	return serviceResponse;
		} catch (BusinessException e) {
			Logger.error("Exception Inside openDDANewAccount() for Customer " + e.getKey(), e, this.getClass());
			IMBResp resp1 = null;
			if (e.getKey() == BusinessException.MAX_ACCT_OPENING_REQ) {
				resp1 = MBAppUtils.createErrorResp(mbSession.getOrigin(), e, e.getValues(),	MBAppConstants.SMPL_OPENDDAACCOUNT_RESP_NAME, httpServletRequest);
			} else {
				resp1 = MBAppUtils.createErrorResp(mbSession.getOrigin(), e, MBAppConstants.SMPL_OPENDDAACCOUNT_RESP_NAME, httpServletRequest);
			}		
			return resp1;
		} catch (Exception e) {
			Logger.error("Exception Inside openDDANewAccount() for Customer GCIS: [" + ((mbSession != null && mbSession.getCustomer() != null) ? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			BusinessException exp = new BusinessException(BusinessException.SMPL_SYS_ERROR);
			IMBResp resp1 = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, MBAppConstants.SMPL_OPENDDAACCOUNT_RESP_NAME, httpServletRequest);	
			return resp1;
		} finally {
			performanceLogger.endLog(logName);
			performanceLogger.endAllLogs();
		}
    }

  @RequestMapping(value = "fundacct", method = RequestMethod.POST,
      headers = "content-type=application/json", produces = MediaType.APPLICATION_JSON_VALUE)
  @ResponseBody
  public IMBResp fundNewDDAAccount(HttpServletRequest httpServletRequest,
      HttpServletResponse httpServletResponse, @RequestBody final FundDDAAcctReq req) {
    Logger.debug("In fundNewDDAAccount ( OpenDDAController )  for Customer " + "  "
        + httpServletRequest.getContentType() + " " + httpServletRequest.getRemoteAddr() + "  "
        + httpServletResponse.getCharacterEncoding() + httpServletResponse.getLocale()
        + " True IP >> " + httpServletRequest.getHeader(IBankParams.trueClientIP()),
        this.getClass());
    PerformanceLogger performanceLogger = new PerformanceLogger();
    fraudLogger = new FraudLogger();
    performanceLogger.startAllLogs();
    String logName = MBAppUtils.getLogName(httpServletRequest);
    performanceLogger.startLog(logName);
    ObjectMapper mapper = new ObjectMapper();
    MobileSession mbSession = null;
    try {
      Logger.info("fundNewDDAAccount JSON Request :" + mapper.writeValueAsString(req),
          this.getClass());
      mbSession = mbAppHelper.getMobileSession(httpServletRequest);

      ErrorResp errorResp = validateRequest(httpServletRequest, req);
      if (errorResp != null) {
    	  return errorResp;
      }
      
      IBankCommonData ibankCommonData =
          mbAppHelper.populateIBankCommonData(mbSession, httpServletRequest);
      openDDAHelper.validateFundingAmt(req.getInitialAmount());
      openDDAHelper.validateFundingAccount(mbSession.getCustomer(), req.getFundingAccountIndex());
      IMBResp serviceResponse;
      NewDDAAccount account =
          openDDAHelper.populateNewDDAAccountForFunding(mbSession, req, ibankCommonData);
      // call the new service for funding
      AccountOpeningService accountOpeningService =
          (AccountOpeningService) ServiceHelper.getBean(DDA_ACCT_OPEN_SERVICE);
      NewDDAAccount responseAcct = new NewDDAAccount();
      responseAcct = (NewDDAAccount) accountOpeningService.performFundsTransferNewAccount(account);
      ArrayList<au.com.stgeorge.mbank.model.common.AccountResp> accountList = null;
      if (responseAcct.getCommonData() != null
          && responseAcct.getCommonData().getCustomer() != null) {
        accountList =
            logonHelper.populateAccountList(responseAcct.getCommonData().getCustomer(), null);
      }
      serviceResponse =
          openDDAHelper.populateFundDDAAcctResp(accountList, responseAcct, mbSession.getCustomer()
              .getAccounts(), account, req.getFundingAccountIndex());
      // update the customer in session
      if (responseAcct.getCommonData() != null
          && responseAcct.getCommonData().getCustomer() != null) {
        mbSession.setCustomer(responseAcct.getCommonData().getCustomer());
      }
      Logger.info("fundNewDDAAccount JSON Response :" + mapper.writeValueAsString(serviceResponse),
          this.getClass());
      RespHeader headerResp = populateResponseHeader(req.getHeader().getServiceName(), mbSession);
      serviceResponse.setHeader(headerResp);
      return serviceResponse;
    } catch (BusinessException e) {
      Logger.error("Exception Inside fundNewDDAAccount() for Customer " + e.getKey(), e,
          this.getClass());
      IMBResp resp1 = null;

      if (e.getKey() == BusinessException.AMT_EXCEEDS_AVAILABLE_AMT) {
        BusinessException bx = new BusinessException(BusinessException.ACCOUNT_OPENING_INSUF_FUND);
        resp1 =
            MBAppUtils.createErrorResp(mbSession.getOrigin(), bx,
                MBAppConstants.SMPL_OPENDDAACCOUNT_RESP_NAME, httpServletRequest);
      } else if (e.getKey() == BusinessException.MAX_ACCT_OPENING_REQ
          || e.getKey() == BusinessException.INVALID_MIN_AMT) {
        resp1 =
            MBAppUtils.createErrorResp(mbSession.getOrigin(), e, e.getValues(),
                MBAppConstants.SMPL_OPENDDAACCOUNT_RESP_NAME, httpServletRequest);
      } else {
        resp1 =
            MBAppUtils.createErrorResp(mbSession.getOrigin(), e,
                MBAppConstants.SMPL_OPENDDAACCOUNT_RESP_NAME, httpServletRequest);
      }
      return resp1;
    } catch (Exception e) {
      Logger.error("Exception Inside fundNewDDAAccount() for Customer GCIS: ["
          + ((mbSession != null && mbSession.getCustomer() != null) ? mbSession.getCustomer()
              .getGcis() : "") + "] :", e, this.getClass());
      BusinessException exp = new BusinessException(BusinessException.SMPL_SYS_ERROR);
      IMBResp resp1 =
          MBAppUtils.createErrorResp(mbSession.getOrigin(), exp,
              MBAppConstants.SMPL_OPENDDAACCOUNT_RESP_NAME, httpServletRequest);
      return resp1;
    } finally {
      performanceLogger.endLog(logName);
      performanceLogger.endAllLogs();
    }
  }


  @RequestMapping(value = "productList", method = RequestMethod.POST,
      headers = "content-type=application/json", produces = MediaType.APPLICATION_JSON_VALUE)
  @ResponseBody
  public IMBResp landingPage(HttpServletRequest httpServletRequest,
      HttpServletResponse httpServletResponse, @RequestBody final OpenDDAReq req) {

    MobileSession mbSession = null;
    PerformanceLogger performanceLogger = new PerformanceLogger();
    fraudLogger = new FraudLogger();
    performanceLogger.startAllLogs();
    String logName = MBAppUtils.getLogName(httpServletRequest);
    performanceLogger.startLog(logName);
    ObjectMapper mapper = new ObjectMapper();
    try {
      mbSession = mbAppHelper.getMobileSession(httpServletRequest);
      validateRequestHeader(req.getHeader(), httpServletRequest);
      Collection<UserFunction> userFunctions = getUserFunctions(mbSession);
      List<Category> catList =
          createPageData(userFunctions, mbSession.getOrigin(), mbSession.getCustomer());
      RespHeader headerResp = populateResponseHeader(req.getHeader().getServiceName(), mbSession);
      IBankCommonData ibankCommonData =
          mbAppHelper.populateIBankCommonData(mbSession, httpServletRequest);


      CRAProductListContent craProductListContent = null;


      boolean isDemo = logonHelper.isDemo();
      if (isDemo) {
        Logger.info("isDemo :" + isDemo, this.getClass());
        String encodedDemoDigest = req.getAemDigester();
        Logger.info("encodedDemoDigest :" + encodedDemoDigest, this.getClass());
        if (!StringMethods.isEmptyString(encodedDemoDigest) && encodedDemoDigest.length() > 5) {
          // Encoded data coming in url (from admin to demo) is replacing + with space. so, to get
          // back that characters replacing space with +
          encodedDemoDigest = encodedDemoDigest.replace(" ", "+");
          mbSession.setAEMDigester(encodedDemoDigest);
          craProductListContent =
              contentManagementService.getCreditCardProdListContentForDemo(encodedDemoDigest,
                  IBankParams.getBaseOriginCode(ibankCommonData.getOrigin()));
        } else {
          // TODO
          craProductListContent =
              contentManagementService.getCreditCardProdListContentForDemo("",
                  IBankParams.getBaseOriginCode(ibankCommonData.getOrigin()));
        }
      } else {
        try {
          // CAll Prod content
          if (IBankParams.isAEMContentMgmtSwitchON(ibankCommonData.getOrigin())) {
            craProductListContent =
                contentManagementService.getCreditCardProdListContentForProd(IBankParams
                    .getBaseOriginCode(ibankCommonData.getOrigin()));
          }
        } catch (Exception e) {
          craProductListContent = null;
          Logger.error(
              "Exception Inside landingPage() for get Credit card content from AEM for Customer GCIS: ["
                  + ((mbSession != null && mbSession.getCustomer() != null) ? mbSession
                      .getCustomer().getGcis() : "") + "] :", e, this.getClass());

        }
      }



      IMBResp serviceResponse =
          openDDAHelper.populateLandingStructure(mbSession, ibankCommonData, catList,
              craProductListContent);
      serviceResponse.setHeader(headerResp);

      if (req.isGreenBirdInfoClicked()) {
        try {

          invitationService.updateInvitationStatus(ibankCommonData,
              InvitationStatus.SELECTED.getStatus(), InvitationStatus.SELECTED.getStatus());
        } catch (Exception e) {
          // This update is less significant, so exception suppressed to avoid failure of landing
          // page
          Logger.error("Exception Inside landingPage() updateInvitationStatus for Customer GCIS: ["
              + ((mbSession != null && mbSession.getCustomer() != null) ? mbSession.getCustomer()
                  .getGcis() : "") + "] :", e, this.getClass());
        }
      }

      Logger.debug("ProductList Response : " + mapper.writeValueAsString(serviceResponse),
          getClass());
      return serviceResponse;
    } catch (BusinessException e) {
      Logger.error("Exception Inside openDDAAccount() for Customer " + e.getKey(), e,
          this.getClass());
      IMBResp resp1 = null;
      resp1 =
          MBAppUtils.createErrorResp(mbSession.getOrigin(), e,
              MBAppConstants.SMPL_OPENDDAACCOUNT_RESP_NAME, httpServletRequest);
      try {
        Logger.debug("ProductList Response Error resp : " + mapper.writeValueAsString(resp1), e,
            getClass());
      } catch (Exception e1) {
        Logger.error("Error in productList", e1, getClass());
      }
      return resp1;
    } catch (Exception e) {
      Logger.error("Exception Inside openDDAAccount() for Customer GCIS: ["
          + ((mbSession != null && mbSession.getCustomer() != null) ? mbSession.getCustomer()
              .getGcis() : "") + "] :", e, this.getClass());
      BusinessException exp = new BusinessException(BusinessException.SMPL_SYS_ERROR);
      IMBResp resp1 =
          MBAppUtils.createErrorResp(mbSession.getOrigin(), exp,
              MBAppConstants.SMPL_OPENDDAACCOUNT_RESP_NAME, httpServletRequest);
      try {
        Logger.debug("ProductList Response Error resp : " + mapper.writeValueAsString(resp1), e,
            getClass());
      } catch (Exception e1) {
        Logger.error("Error in productList", e1, getClass());
      }
      return resp1;
    } finally {
      performanceLogger.endLog(logName);
      performanceLogger.endAllLogs();
    }
  }
  
  	public BranchVO getBranch(List<BranchVO> branchList, String branchId) throws BusinessException, ResourceException {
	    Iterator<BranchVO> it = branchList.iterator();
	    BranchVO branch = null;
	    while (it.hasNext()) {
	      branch = it.next();
	      if (branch.getBranchId().equalsIgnoreCase(branchId))
	        break;
	    }
	    if (branch == null)
	      throw new BusinessException(BusinessException.GENERIC_ERROR);
	    return branch;
	}

  public boolean isDuplicate(MobileSession mobileSession, OpenDDAReq req,
      IBankCommonData ibankCommonData) throws BusinessException {
    boolean isDuplicate = false;
    if (req.isCheckDuplicate()) {
      return false;
    }
    ArrayList<?> duplicateList = getDuplicateList(mobileSession, req.getProduct(), ibankCommonData);
    if (duplicateList != null && duplicateList.size() > 0) {
      isDuplicate = true;
    }
    return isDuplicate;
  }

  public ArrayList<AcctOpeningVO> getDuplicateList(MobileSession mobileSession, ProductReq product,
      IBankCommonData ibankCommonData) throws BusinessException {
    IBankCommonData commonData = ibankCommonData;
    ArrayList<AcctOpeningVO> duplicateAcctOpeningList = null;
    AcctOpeningVO newAcct = new AcctOpeningVO();
    newAcct.setGcisNumber(commonData.getUser().getGCISNumber());
    newAcct.setSubProdCode(String.valueOf(openDDAHelper.getProdID(product.getSubProdcode())));
    OpenDDAService service = new OpenDDAServiceImpl();
    try {

      duplicateAcctOpeningList = (ArrayList<AcctOpeningVO>) service.getDuplicateRequest(newAcct);
    } catch (BusinessException e) {
      if (e.getKey() == BusinessException.MAX_ACCT_OPENING_REQ) {
        IBankLog.logWRN("Max Acct Opening Req reached ", this.getClass());
        throw e;
      }
    } catch (ResourceException e) {
      IBankLog.logWRN(" ResourceException in getDuplicateReqList in New Acct Opening",
          this.getClass());
    }
    return duplicateAcctOpeningList;
  }

  public IBankCommonData populateIBankCommonData(Customer customer, User user) {
    IBankCommonData commonData = new IBankCommonData();
    commonData.setUser(user);
    commonData.setOrigin((String) user.getAttribute(IBankParams.USEROBJ_BRAND));
    commonData.setCustomer(customer);
    return commonData;
  }

	public ErrorResp validate(IMBReq serviceRequest, HttpServletRequest request) {
		return mbAppValidator.validate(serviceRequest, request);
	}

	public void validateRequestHeader(ReqHeader header, HttpServletRequest request) throws ResourceException {
		mbAppValidator.validateRequestHeader(header, request);
	}
  
	private ErrorResp validateRequest(HttpServletRequest httpServletRequest, IMBReq req) {
		validateRequestHeader(req.getHeader(), httpServletRequest);

		ErrorResp errorResp = validate(req, httpServletRequest);
		if (errorResp != null && errorResp.getErrors() != null && errorResp.getErrors().size() > 0) {
			return errorResp;
		}

		return null;
	}

  public List<UserFunction> getUserFunctions(MobileSession mobileSession) throws BusinessException,
      ResourceException {
    Customer customer = mobileSession.getCustomer();
    User user = mobileSession.getUser();

    MobileBankService mobileBankService =
        (MobileBankService) ServiceHelper.getBean(MBAppConstants.SPRING_MOBILE_SERVICE_BEAN);
    IBankCommonData commonData = populateIBankCommonData(customer, user);
    Collection<String> landingFunctions =
        (Collection<String>) mobileBankService.getUserFunctions(commonData,
            MBAppConstants.HTTP_REQUEST_PARAM_PRODUCTS);
    List<UserFunction> userFunctions = populateUserFunctions(landingFunctions);
    return userFunctions;

  }

  private List<UserFunction> populateUserFunctions(Collection<String> strings) {
    List<UserFunction> userFunctions = new ArrayList<UserFunction>();
    for (String function : strings) {
      userFunctions.add(new UserFunction(function, true));
    }
    return userFunctions;
  }

  private List<Category> createPageData(Collection<UserFunction> userFunctions, String origin,
      Customer customer) throws BusinessException {
    NewAcctStructure newStructure = newAcctStructureLocator.getNewAcctStructure();
    CodesVO codesVO = null;
    codesVO =
        IBankParams
            .getCodesData(origin, IBankParams.CREDIT_CARD_CONFIG, IBankParams.AO_CC_PRODUCTS);
    String[] CCProducts = codesVO.getMessage().split(",");
    StringBuffer productsBuffer = new StringBuffer();
    productsBuffer.append(";");
    for (String product : CCProducts) {
      productsBuffer.append(product + ";");
    }
    productsBuffer.append(";");
    String products = productsBuffer.toString();
    Logger.debug("Products Message : " + products, this.getClass());

    String invitationList = invitationService.getInvitationProductList(customer, origin);
    String[] invitationSplit = invitationList.split(",");
    StringBuffer invitationListBuffer = new StringBuffer();
    invitationListBuffer.append(";");
    for (String product : invitationSplit) {
      invitationListBuffer.append(product + ";");
    }
    invitationListBuffer.append(";");
    String invitation = invitationListBuffer.toString();
    Logger.debug("Invitation Products Message : " + invitation, this.getClass());

    List<Category> pageSections = new ArrayList<Category>();
    if ((userFunctions != null && !userFunctions.isEmpty()))
      for (Category category : newStructure.getCategories()) {
        List<SubCategory> subCats = new ArrayList<SubCategory>();
        Logger.debug("\n* Head category **" + category.getName(), this.getClass());

        if (category.getSubCats() != null) {
          for (SubCategory subCat : category.getSubCats()) {
            if (userFunctions.contains(new UserFunction(subCat.getCode(), true))) {
              if (subCat.getGroup().equalsIgnoreCase("creditCards")) {
                String subCategory = subCat.getId() + ";";
                if (products.indexOf(subCategory) >= 0) {
                  // subCats.add(new SubCategory(subCat.getType(),
                  // subCat.getCode(),
                  // replaceBaseOrigin(filterLabel(subCat.getName()), origin),
                  // replaceBaseOrigin(subCat.getText(),origin),
                  // subCat.getGroup(), subCat.getId()));
                  subCats.add(new SubCategory(subCat.getType(), subCat.getCode(), null,
                      replaceBaseOrigin(subCat.getText(), origin), subCat.getGroup(), subCat
                          .getId(), subCat.getClientId()));
                  Logger.debug("***" + subCat.getId(), this.getClass());
                }
              }
              // myInvitations
            //19E4 Tech Debt Start/END:Switch Removal
              else if (/*openDDAHelper.isGreenBirdSwitch(origin)*/
                 /* &&*/ subCat.getGroup().equalsIgnoreCase("myInvitations")) {
                String subCategory = subCat.getId() + ";";
                if (invitation.indexOf(subCategory) >= 0) {
                  subCats.add(new SubCategory(subCat.getType(), subCat.getCode(), null,
                      replaceBaseOrigin(subCat.getText(), origin), subCat.getGroup(), subCat
                          .getId(), subCat.getClientId()));
                  Logger.debug("myInvitations ***" + subCat.getId(), this.getClass());
                }
              } else {
                // subCats.add(new SubCategory(subCat.getType(),
                // subCat.getCode(),
                // replaceBaseOrigin(filterLabel(subCat.getName()), origin),
                // replaceBaseOrigin(subCat.getText(),origin),
                // subCat.getGroup(), subCat.getId()));
                subCats.add(new SubCategory(subCat.getType(), subCat.getCode(), null,
                    replaceBaseOrigin(subCat.getText(), origin), subCat.getGroup(), subCat.getId(),
                    subCat.getClientId()));

                Logger.debug("** " + subCat.getId(), this.getClass());

              }

            } else {
              Logger.info("Menu " + subCat.getName() + " is not allowed", this.getClass());
            }
          }
        }
        pageSections.add(new Category(category.getName(), subCats, category.getType(), category
            .getId(), replaceBaseOrigin(category.getText(), origin)));
      }
    return pageSections;
  }

  private String replaceBaseOrigin(String inputText, String origin) {
    if (inputText != null && inputText.contains(MBAppConstants.BASEORIGIN)) {
      inputText = inputText.replace(MBAppConstants.BASEORIGIN, getBankName(origin));
    }
    return inputText;
  }

  private String getBankName(String origin) {
    String output;

    OriginsVO originVO = IBankParams.getOrigin(origin);
    output = originVO.getName();
    if (output.indexOf(" Bank") > 0) {
      // remove the word bank.
      output = output.substring(0, output.indexOf(" Bank"));
    }
    return output;
  }

  	public RespHeader populateResponseHeader(String serviceName, MobileSession mobSession) {
  		return mbAppHelper.populateResponseHeader(serviceName, mobSession);
  	}
  
    private void validateSenseTarget(final OpenDDAAcctReq req) throws BusinessException {
		if (req.getProduct() != null && openDDAHelper.getProdID(req.getProduct().getSubProdcode()) == IBankParams.SENSE_EVERYDAY_ACCOUNT) {
			openDDAHelper.validateSavingTarget(req.getSavingTargetAmount(), req.getProduct());
		}
	}
}
