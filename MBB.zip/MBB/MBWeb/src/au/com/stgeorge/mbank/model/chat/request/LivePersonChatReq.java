package au.com.stgeorge.mbank.model.chat.request;

import java.io.Serializable;

import au.com.stgeorge.mbank.model.common.IMBReq;
import au.com.stgeorge.mbank.model.common.ReqHeader;

public class LivePersonChatReq implements IMBReq, Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -29602835278627168L;

	private Integer eventType;
	
	private String campaignId;
	
	private String visitorId;
	
	private String agentId;
	
	private String agentName;
	
	private String pageName;
	
	private ReqHeader header;

	public String getPageName() {
		return pageName;
	}

	public void setPageName(String pageName) {
		this.pageName = pageName;
	}
	
	public Integer getEventType() {
		return eventType;
	}

	public void setEventType(Integer eventType) {
		this.eventType = eventType;
	}

	public String getCampaignId() {
		return campaignId;
	}

	public void setCampaignId(String campaignId) {
		this.campaignId = campaignId;
	}

	public String getVisitorId() {
		return visitorId;
	}

	public void setVisitorId(String visitorId) {
		this.visitorId = visitorId;
	}

	public String getAgentId() {
		return agentId;
	}

	public void setAgentId(String agentId) {
		this.agentId = agentId;
	}

	public String getAgentName() {
		return agentName;
	}

	public void setAgentName(String agentName) {
		this.agentName = agentName;
	}

	@Override
	public ReqHeader getHeader() {
		return header;
	}

	@Override
	public void setHeader(ReqHeader header) {
		this.header = header;
		
	}

	
}
