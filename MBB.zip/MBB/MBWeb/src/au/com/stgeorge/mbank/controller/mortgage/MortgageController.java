package au.com.stgeorge.mbank.controller.mortgage;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.SerializationUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import au.com.stgeorge.framework.common.logging.Logger;
import au.com.stgeorge.framework.common.model.User;
import au.com.stgeorge.framework.common.util.StringMethods;
import au.com.stgeorge.ibank.businessobject.BusinessException;
import au.com.stgeorge.ibank.businessobject.CustomerService;
import au.com.stgeorge.ibank.businessobject.HeartBeat;
import au.com.stgeorge.ibank.businessobject.LivePersonChatService;
import au.com.stgeorge.ibank.businessobject.ResourceException;
import au.com.stgeorge.ibank.businessobject.ThrottlingService;
import au.com.stgeorge.ibank.businessobject.mortgage.MortgageLenderService;
import au.com.stgeorge.ibank.businessobject.mortgage.MortgageService;
import au.com.stgeorge.ibank.common.cache.IBankParams;
import au.com.stgeorge.ibank.common.cache.MortgageParams;
import au.com.stgeorge.ibank.loanApplication.util.LoanAppConstants;
import au.com.stgeorge.ibank.mortgage.util.MortgageUtil;
import au.com.stgeorge.ibank.mortgage.util.MortgageUtil.LoanOutcomeEnum;
import au.com.stgeorge.ibank.mortgage.util.MortgageUtil.ValAssessEnum;
import au.com.stgeorge.ibank.util.ServiceHelper;
import au.com.stgeorge.ibank.util.StringUtil;
import au.com.stgeorge.ibank.valueobject.Customer;
import au.com.stgeorge.ibank.valueobject.LabelValueVO;
import au.com.stgeorge.ibank.valueobject.LivePersonChat;
import au.com.stgeorge.ibank.valueobject.collection.LabelValueMap;
import au.com.stgeorge.ibank.valueobject.database.OriginsVO;
import au.com.stgeorge.ibank.valueobject.mortgage.Applicant;
import au.com.stgeorge.ibank.valueobject.mortgage.Application;
import au.com.stgeorge.ibank.valueobject.mortgage.Asset;
import au.com.stgeorge.ibank.valueobject.mortgage.DocCategoryDetail;
import au.com.stgeorge.ibank.valueobject.mortgage.DocTypeDetail;
import au.com.stgeorge.ibank.valueobject.mortgage.DocUploadDetail;
import au.com.stgeorge.ibank.valueobject.mortgage.Lender;
import au.com.stgeorge.ibank.valueobject.mortgage.LoanApplicationReferenceVO;
import au.com.stgeorge.ibank.valueobject.mortgage.LoanOutcome;
import au.com.stgeorge.ibank.valueobject.mortgage.LoanOutcomeInfo;
import au.com.stgeorge.ibank.valueobject.mortgage.LoanType;
import au.com.stgeorge.ibank.valueobject.mortgage.MortgageAddress;
import au.com.stgeorge.ibank.valueobject.mortgage.MortgageCommonData;
import au.com.stgeorge.ibank.valueobject.mortgage.MortgageSessionInfo;
import au.com.stgeorge.ibank.valueobject.mortgage.PropertyInsightDetails;
import au.com.stgeorge.ibank.valueobject.transfer.IBankCommonData;
import au.com.stgeorge.mbank.controller.IMBController;
import au.com.stgeorge.mbank.controller.customer.LogonHelper;
import au.com.stgeorge.mbank.controller.mortgage.MortgageHelper.CLASApplicationStatusEnum;
import au.com.stgeorge.mbank.model.common.IMBReq;
import au.com.stgeorge.mbank.model.common.IMBResp;
import au.com.stgeorge.mbank.model.common.ReqHeader;
import au.com.stgeorge.mbank.model.common.RespHeader;
import au.com.stgeorge.mbank.model.mortgage.MortgageAppParams;
import au.com.stgeorge.mbank.model.mortgageinfo.AddressInfo;
import au.com.stgeorge.mbank.model.mortgageinfo.ApplicantInfo;
import au.com.stgeorge.mbank.model.mortgageinfo.ApplicationInfo;
import au.com.stgeorge.mbank.model.mortgageinfo.DocUploadDetailInfo;
import au.com.stgeorge.mbank.model.mortgageinfo.DocUploadInfo;
import au.com.stgeorge.mbank.model.mortgageinfo.LoanAssessmentInfo;
import au.com.stgeorge.mbank.model.mortgageinfo.LoanTypeInfo;
import au.com.stgeorge.mbank.model.request.EmptyReq;
import au.com.stgeorge.mbank.model.request.mortgage.ApplicationListResp;
import au.com.stgeorge.mbank.model.request.mortgage.ApplicationReq;
import au.com.stgeorge.mbank.model.request.mortgage.ApplicationResp;
import au.com.stgeorge.mbank.model.request.mortgage.ChatEventReq;
import au.com.stgeorge.mbank.model.request.mortgage.DocUploadDetailReq;
import au.com.stgeorge.mbank.model.request.mortgage.PropertyInsightReq;
import au.com.stgeorge.mbank.model.request.mortgage.RetrieveDetailsReq;
import au.com.stgeorge.mbank.model.request.mortgage.SubmitReq;
import au.com.stgeorge.mbank.model.request.mortgage.UpdatePIDReq;
import au.com.stgeorge.mbank.model.request.mortgage.WintelReq;
import au.com.stgeorge.mbank.model.response.ErrorResp;
import au.com.stgeorge.mbank.model.response.SuccessResp;
import au.com.stgeorge.mbank.model.response.mortgage.ChatTokenResp;
import au.com.stgeorge.mbank.model.response.mortgage.DocUploadDetailResp;
import au.com.stgeorge.mbank.model.response.mortgage.DocUploadJWTTokenResp;
import au.com.stgeorge.mbank.model.response.mortgage.InitialRefDataResp;
import au.com.stgeorge.mbank.model.response.mortgage.LenderDetailsResp;
import au.com.stgeorge.mbank.model.response.mortgage.LivePersonChatStatusResp;
import au.com.stgeorge.mbank.model.response.mortgage.LoanAssessmentResp;
import au.com.stgeorge.mbank.model.response.mortgage.LoanTypeResp;
import au.com.stgeorge.mbank.model.response.mortgage.MortgageSubmitResp;
import au.com.stgeorge.mbank.model.response.mortgage.PersonalDetailResp;
import au.com.stgeorge.mbank.model.response.mortgage.PropertyInsightResp;
import au.com.stgeorge.mbank.model.response.mortgage.SessionResp;
import au.com.stgeorge.mbank.model.response.mortgage.ValAssessResp;
import au.com.stgeorge.mbank.session.IGenericSession;
import au.com.stgeorge.mbank.session.MobileSession;
import au.com.stgeorge.mbank.session.MobileSessionImpl;
import au.com.stgeorge.mbank.util.MBAppHelper;
import au.com.stgeorge.mbank.util.MBAppUtils;
import au.com.stgeorge.mbank.util.MBAppValidator;
import au.com.stgeorge.mbank.util.ServiceConstants;
import au.com.stgeorge.perflogger.PerformanceLogger;
import au.com.westpac.gn.locationmanagement.services.locationmanagement.xsd.retrievepostaladdress.v1.svc0454.AddressType;

import com.fasterxml.jackson.databind.ObjectMapper;



@Controller
@RequestMapping("/mortgage")
public class MortgageController implements IMBController
{
	@Autowired
	private MBAppHelper mbAppHelper;

	@Autowired
	private MBAppValidator mbAppValidator;
	
	@Autowired
	private PerformanceLogger perfLogger;
	
	@Autowired
	private MortgageService mortgageService;
	
	@Autowired
	private MortgageRefDataHelper mortgageRefDataHelper; 
	
	@Autowired
	private MortgageHelper mortgageHelper;
	
	@Autowired
	private MortgageParams mortgageParams;
	
	@Autowired
	private ThrottlingService throttleService;
	
	@Autowired
	private MortgageLenderService mortgageLenderService;
	
	@Autowired
	private LivePersonChatService livePersonChatService;
	
	private static final String SOURCE_ID = "GHS";
	
	private static final long LOAN_TERM_MIN = 5;
	private static final long LOAN_TERM_MAX = 30;
	private static final long LOAN_TERM_MAX_OFFER = 35;
	
	@RequestMapping(method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE, value = "referenceNum")
    @ResponseBody
    public IMBResp generateReference(HttpServletRequest httpRequest, HttpServletResponse httpResponse, @RequestBody final ApplicationReq request) {
        
        String logName = startPerformanceLog(httpRequest);
        MobileSession mobileSession = null;

        try {
            ObjectMapper mapper = new ObjectMapper();
            Logger.info("MortgageController - generateReference(). Request: " + mortgageHelper.hashSensitiveData(mapper.writeValueAsString(request)), this.getClass());

           mobileSession = mbAppHelper.getMobileSession(httpRequest);
           
            //Throttling check
			boolean isThrottleAllowed = true;
			try{
				isThrottleAllowed = throttleService.processThrottling(IBankParams.HOMELOAN_APPLICATION_SOURCE);
			}catch(Exception e){
				//Do nothing . Go ahaead with call
				Logger.error("Mortgage : Exception occured in throttle service.."+e, this.getClass());					
			}
			if(!isThrottleAllowed){
				Logger.info("Mortgage max throttling exceeded : ", this.getClass());
				throw new BusinessException(BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE);
			}
			
            if(mobileSession.getMortgageSessionInfo() != null && mobileSession.getMortgageSessionInfo().getApplicationNumber() != null){
            	//Application already generated
            	Logger.error("MortgageController - generateReference(). Reference already generated " , this.getClass());
            	mobileSession.invalidateSession();
                throw new BusinessException(BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE);
            }   		
    		
            validateRequestHeader(request.getHeader(), httpRequest);
            ErrorResp errorResponse = validate(request, httpRequest);
            if (errorResponse.hasErrors()){
                return errorResponse;
            }
            if(request.getApp() == null){
                Logger.error("MortgageController - generateReference(). Request: " + request.getApp() , this.getClass());
                throw new BusinessException(BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE);
            }
            ApplicationInfo application = request.getApp();
            
            LoanTypeInfo loanType = application.getLoanType();
            List<ApplicantInfo> applicantsInfo = application.getApplicants();

            if(loanType == null || applicantsInfo.isEmpty() || applicantsInfo.size() == 0){
                Logger.error("MortgageController - generateReference(). Request: loan type or applicant data is empty. " , this.getClass());
                throw new BusinessException(BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE);
            }
            
            MortgageCommonData mortgageCommonData = mortgageHelper.populateMortgageCommonData(mobileSession, request.getHeader(), httpRequest);
            
            //validate
            mortgageHelper.validateAppicationInfo(application, false);
            
            //iBankCommonData is needed to retrieve QAS address using ESB SRV524
            IBankCommonData iBankCommonData = mbAppHelper.populateIBankCommonData(mobileSession,httpRequest);
            iBankCommonData.setOrigin(mobileSession.getMortgageSessionInfo().getOrigin());
            iBankCommonData.setUser(new User("gcisNumber", "can","", null, false, true,false));
            Application applicationVO = mortgageHelper.populateAppicationVO(application, mobileSession, iBankCommonData, perfLogger);
            
            /*
             * Limit the number of application per e-mail address 
             * */
            String emailAddress = applicationVO.getApplicants().get(0).getEmailAddress();
            mortgageService.getMaxApplicationLimitReached(emailAddress, iBankCommonData.getOrigin());
            
            //setCreditdecisionFlag
            if(application!= null &&  application.getLoanType()!= null){
				Boolean creditCheckRequired = false;
				if(application.getLoanType().getCustomerSituation() != null){
					creditCheckRequired = mortgageHelper.crditDecisionEligible(mortgageCommonData.getOrigin(), application.getLoanType().getCustomerSituation());
				}
				else if(!StringMethods.isEmptyString(application.getLoanType().getLoanType()) && 
			    		MortgageUtil.LoanTypeEnum.REFINANCE.getType().equalsIgnoreCase(application.getLoanType().getLoanType())){
					creditCheckRequired = mortgageHelper.crditDecisionEligible(mortgageCommonData.getOrigin(), MortgageUtil.LoanTypeEnum.REFINANCE.getType() );
				}
				 if(creditCheckRequired){
				 	applicationVO.setCreditCheckEligible(MortgageUtil.CreditCheckEligibleEnum.YES.getValue());
				 }
				 else{
				 	applicationVO.setCreditCheckEligible(MortgageUtil.CreditCheckEligibleEnum.NO.getValue());
				 }
            }
            
            LoanApplicationReferenceVO applicationReference = mortgageService.getReferenceNumber(applicationVO, mortgageCommonData, iBankCommonData);
            
            if(applicationReference != null && applicationReference.getApplicationNum() != null) {
                Application applicationVOForSession = mortgageService.getApplication(applicationReference.getApplicationNum());
                mobileSession.setHomeLoanApplication(applicationVOForSession);
                
                //Set the request transaction number from UI on session
                if(request.getHeader() != null && !StringUtils.isEmpty(request.getHeader().getTranSeqnbr())) {
                    mobileSession.setHomeLoanApplicationTransactionNum(request.getHeader().getTranSeqnbr());
                }
                
                //Remove LenderId(s) from Session once reference number is generated
                mortgageHelper.removeLenderIdFromSession(mobileSession);
            }
			mortgageService.logStatistics(mortgageCommonData, "New Application", MortgageUtil.GWDStatatisticActionsEnum.NewApplication.getValue());

			//Update Mortgage Session Object with customerReferenceNum, applicationNum, email
			mobileSession.getMortgageSessionInfo().setRefNumber(applicationReference.getCustomerReferenceNum());
			mobileSession.getMortgageSessionInfo().setApplicationNumber(applicationReference.getApplicationNum());
			mobileSession.getMortgageSessionInfo().setEmail(applicantsInfo.get(0).getEmailAddress());
            
            
            LoanTypeResp loanTypeResp = new LoanTypeResp();
            String formattedReferenceNumber = StringUtil.formatReferenceNumber(applicationReference.getCustomerReferenceNum().toString().trim(), 4);
            loanTypeResp.setReferenceNumber(formattedReferenceNumber.trim());
            loanTypeResp.setApplicationNum(applicationReference.getApplicationNum().toString());
            
            RespHeader headerResp = populateResponseHeader(ServiceConstants.MORTGAGE_SERVICE, null);
            loanTypeResp.setHeader(headerResp);
            
            return loanTypeResp;
        }  
        catch (BusinessException be) {
        	if(be.getKey()==BusinessException.MORTGAGE_MAX_APPLICATION_REACHED) {
        		Logger.info("Max application limit for the email has excedded :", be, this.getClass());
        		String tempOrigin = mortgageParams.getBaseOriginCode(mobileSession.getOrigin());
        		LabelValueVO brandPhone = mortgageRefDataHelper.getDMCodesData(tempOrigin, MortgageUtil.REF_DATA_CATEGORY_HELP_DESK, tempOrigin);
        		String[] values = { brandPhone.getLabel() };
        		Logger.info("Brand Contact Number returned from DM origins :" + brandPhone.getLabel(), this.getClass());
        		return MBAppUtils.createErrorResp(mobileSession.getOrigin(), be, values, ServiceConstants.MORTGAGE_SERVICE, httpRequest);
        	}
        	return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE, ServiceConstants.MORTGAGE_SERVICE, httpRequest);
        }
        catch (Exception e) {
            Logger.error("Exception in MortgageController - generateReference(): ", e, this.getClass());
            return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE, ServiceConstants.MORTGAGE_SERVICE, httpRequest);
        } finally {
            endPerformanceLog(logName);
        }
    }
	
	@RequestMapping(method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE, value = "getInitialRefData")
	@ResponseBody
	public IMBResp getInitialRefData(HttpServletRequest httpRequest, HttpServletResponse httpResponse, @RequestBody final EmptyReq request) {
		String logName = startPerformanceLog(httpRequest);
	    String origin = logonHelper.resolveOrigin(httpRequest);
	    
		try {
			ObjectMapper mapper = new ObjectMapper();
			Logger.debug("MortgageController - getInitialRefData(). Request: " + mapper.writeValueAsString(request), this.getClass());

			validateRequestHeader(request.getHeader(), httpRequest);
			ErrorResp errorResponse = validate(request, httpRequest);
			if (errorResponse.hasErrors()){
				return errorResponse;
			}
			
			InitialRefDataResp initialRefDataResp = new InitialRefDataResp();

			//Get Ref Data
			perfLogger.startLog("mortgageRefDataHelper.getInitialRefData");
			MortgageAppParams appParams = mortgageRefDataHelper.getInitialRefData(origin, httpRequest);
			perfLogger.endLog("mortgageRefDataHelper.getInitialRefData");
			
			PropertyInsightDetails insightDtls=mortgageHelper.populatePropertyInsightDetails();
			if(insightDtls != null){
				appParams.setPropertyInsightDetails(insightDtls);
			}
			// Set device type as either mob or desktop.  Mob will set irrespective of Mobile or Tablet as mob only.
			String userAgentRegex= mortgageRefDataHelper.getDMCodesData(MortgageUtil.ORIGIN_ALL, MortgageUtil.MORTGAGE_DM_USERAGENT, MortgageUtil.MORTGAGE_DM_DEVICEREGEX).getLabel().toLowerCase();
			String deviceType = mbAppHelper.fetchDeviceType(httpRequest.getHeader("User-Agent"),userAgentRegex);
			appParams.setDeviceType(deviceType);
			Logger.debug("MortgageController - getInitialRefData() deviceType: " + deviceType , this.getClass());
			initialRefDataResp.setAppParams(appParams);
			RespHeader headerResp = populateResponseHeader(ServiceConstants.MORTGAGE_SERVICE, null);
			initialRefDataResp.setHeader(headerResp);
						
			Logger.debug("MortgageController - getInitialRefData() JSON Response :" + mapper.writeValueAsString(initialRefDataResp), this.getClass());

			return initialRefDataResp;
		}  catch (Exception e) {
			Logger.error("Exception in MortgageController - getInitialRefData(): ", e, this.getClass());
			return MBAppUtils.createErrorResp(origin, BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE, ServiceConstants.MORTGAGE_SERVICE, httpRequest);
		} finally {
			endPerformanceLog(logName);
		}
	}
	
	
	@RequestMapping(method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE, value = "initChat")
	@ResponseBody
	public IMBResp getLivePersonToken(HttpServletRequest httpRequest, @RequestBody final EmptyReq request) {
		Logger.debug("MortgageController - getLivePersonToken(). Request: " + request, this.getClass());
		
		String logName = startPerformanceLog(httpRequest);
		MobileSession mobileSession = null;

		try {
			mobileSession = mbAppHelper.getMobileSession(httpRequest);
			//validateRequestHeader(request.getHeader(), httpRequest);
			//Added to solve the issue of Session sharing among multiple tabs or browsers and multiple applications are trying to update using the same session.
			validateDigitalMortgageRequestHeader(request.getHeader(), httpRequest);
			ErrorResp errorResponse = validate(request, httpRequest);
			if (errorResponse.hasErrors()){
				return errorResponse;
			}
			
			ChatTokenResp chatTokenResp = new ChatTokenResp();
			IBankCommonData commonData = mbAppHelper.populateIBankCommonData(mobileSession, httpRequest);
			commonData.setOrigin(mobileSession.getMortgageSessionInfo().getOrigin());
			MortgageCommonData mortgageCommonData = mortgageHelper.populateMortgageCommonData(mobileSession,  request.getHeader(), httpRequest);
			
			//Get LoanType Ref Data 
			String token = mortgageService.getSignedJWTForLivePerson(mobileSession.getMortgageSessionInfo().getApplicationNumber());
			
			chatTokenResp.setJwtToken(token);

			mortgageService.makeChatStatsEntry(mortgageCommonData, "Chat Initiated", MortgageUtil.GWDStatatisticActionsEnum.ChatInit.getValue());

			RespHeader headerResp = populateResponseHeader(ServiceConstants.MORTGAGE_SERVICE, mobileSession);
			chatTokenResp.setHeader(headerResp);
			ObjectMapper mapper = new ObjectMapper();

			Logger.debug("MortgageController - getLivePersonToken() JSON Response :" + mapper.writeValueAsString(chatTokenResp), this.getClass());

			return chatTokenResp;
		}  
		catch (BusinessException e) {
			Logger.error("BusinessException - getLivePersonToken():", e, this.getClass());			

			if(e.getKey() == BusinessException.MORTGAGE_SESSION_SHARING_ERROR){
				Logger.error("Session is sharing among multiple tabs or browsers and multiple applications are trying to update using the same session......", this.getClass());									
				return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.MORTGAGE_SESSION_SHARING_ERROR, ServiceConstants.MORTGAGE_SERVICE, httpRequest);
			}
			else{
				return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE, ServiceConstants.MORTGAGE_SERVICE, httpRequest);
			}
		}
		catch (Exception e) {
			Logger.error("Exception in MortgageController - getInitialRefData(): ", e, this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE, ServiceConstants.MORTGAGE_SERVICE, httpRequest);
		} finally {
			endPerformanceLog(logName);
		}
	}
	
	@RequestMapping(method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE, value = "getLoanAssessment")
	@ResponseBody
	public IMBResp getLoanAssessment(HttpServletRequest httpRequest, @RequestBody final EmptyReq request) {
		String logName = startPerformanceLog(httpRequest);
		MobileSession mobileSession = null;
		try {
			ObjectMapper mapper = new ObjectMapper();
			Logger.info("MortgageController - getLoanAssessment(). Request: " + mortgageHelper.hashSensitiveData(mapper.writeValueAsString(request)), this.getClass());
			mobileSession = mbAppHelper.getMobileSession(httpRequest);

			//Added to solve the issue of Session sharing among multiple tabs or browsers and multiple applications are trying to update using the same session.
			validateDigitalMortgageRequestHeader(request.getHeader(), httpRequest);
			ErrorResp errorResponse = validate(request, httpRequest);
			if (errorResponse.hasErrors()){
				return errorResponse;
			}

			MortgageCommonData mortgageCommonData = mortgageHelper.populateMortgageCommonData(mobileSession,  request.getHeader(), httpRequest);
			
			MortgageSessionInfo mortgageSessionInfo = mobileSession.getMortgageSessionInfo() ;	
			
	   		//Check if application is already submitted
	   		mortgageHelper.checkApplicationSubmitted(mobileSession.getMortgageSessionInfo().getApplicationNumber(), mobileSession);
			LoanOutcomeInfo loanOutcomeInfo = mortgageService.getLoanAssessmentOutCome(mobileSession.getMortgageSessionInfo().getApplicationNumber(),  mortgageCommonData, mobileSession.getMortgageSessionInfo().getApplication());
			ArrayList<LoanOutcome> loanOutcomes = loanOutcomeInfo.getLoanOutcomes();
			LoanAssessmentResp loanAssessmentResp = null;
			
			//ValAssess data
			boolean isRequired = mortgageService.isValAssessRequired(mobileSession.getHomeLoanApplication());
			boolean valOrderSwitch = IBankParams.isSwitchOn(mortgageCommonData.getOrigin(), IBankParams.MORTGAGE_VAL_ORDER_SWITCH);
			Logger.info("Applcation has eligible Property(PP or Refi) to consider for Val Assess. ",this.getClass());
			if(isRequired && mobileSession.getHomeLoanApplication() != null && loanOutcomes != null && !loanOutcomes.isEmpty() 
					&& mortgageHelper.isEligibleSegmentForValAssess(loanOutcomes)
					&& valOrderSwitch){
				
				//Boolean valAssessRequired = mortgageService.isEligibleForValAssess(mobileSession.getHomeLoanApplication());
				Boolean valAssessRequired = mortgageService.checkValAssessEligibility(loanOutcomes, mobileSession.getHomeLoanApplication());
				Logger.info("valAssessRequired : "+valAssessRequired ,this.getClass());
				String valStatus = null;
				
				if(valAssessRequired){
					valStatus = ValAssessEnum.INPROGRESS.getValue();
				}
				else{
					valStatus = ValAssessEnum.SUBJECT_TO_VALUATION.getValue();
				}

				//Update Val Status in LoanOutcome table
				loanOutcomes.get(0).setValuationStatus(valStatus);
				mortgageService.saveLoanOutcome(mobileSession.getMortgageSessionInfo().getApplicationNumber(), loanOutcomes.get(0));
				loanAssessmentResp = mortgageHelper.populateLoanAssessmentResp(loanOutcomeInfo, mobileSession, valAssessRequired, valStatus);
			}
			else{
				loanAssessmentResp = mortgageHelper.populateLoanAssessmentResp(loanOutcomeInfo, mobileSession, null, null);
			}
			
			
			
			if(loanOutcomeInfo.getValAssessPostReq() != null){
			//	mortgageSessionInfo.setValAssessPostReq(loanOutcomeInfo.getValAssessPostReq());
				mobileSession.setValAssessPostReqStr(mapper.writeValueAsString(loanOutcomeInfo.getValAssessPostReq()));
			}
			
			//Used in Post submit screen, in case CLAS submit service is down
			mortgageSessionInfo.setOutcomeStatus(loanAssessmentResp.getLoanAssessmentInfo().get(0).getLoanOutcomeStatus().toString());
			//Used in submit call, in case customer selected/changed the segment using LMI toggle(to update loan outcome table with new segment data)
			if(loanOutcomes != null && !loanOutcomes.isEmpty()){
				mobileSession.setLoanOutcomes(loanOutcomes);
			}
			RespHeader headerResp = populateResponseHeader(ServiceConstants.MORTGAGE_SERVICE, mobileSession);
			loanAssessmentResp.setHeader(headerResp);
			
			//sets in session the H1 priority, after assessing
			mobileSession.getHomeLoanApplication().setLeadPriority(MortgageUtil.LeadPriorityEnum.H1.getLabel());
        	
			
			
			
			Logger.debug("MortgageController - getLoanAssessment() JSON Response :" + mortgageHelper.hashSensitiveData(mapper.writeValueAsString(loanAssessmentResp)), this.getClass());

			return loanAssessmentResp;
		}  catch (BusinessException e) {
			Logger.error("BusinessException in MortgageController - getLoanAssessment(): ", e, this.getClass());
			BusinessException exp = new BusinessException(e.getKey());
			if(e.getKey() == BusinessException.MORTGAGE_APP_ERROR
					|| e.getKey() == BusinessException.MORTGAGE_APP_SUBMIT_TIMEOUT)
			{
				exp = new BusinessException(BusinessException.MORTGAGE_APP_ERROR);
				Logger.debug("Showing error message on Review/Summary screen", this.getClass());
				LabelValueVO dmCodesLabelVO = mortgageParams.getDMCodesDataLabelValueVO(mortgageParams.getBaseOriginCode(mobileSession.getOrigin()),
						MortgageUtil.REF_DATA_CATEGORY_HELP_DESK,
						mortgageParams.getBaseOriginCode(mobileSession.getOrigin()));
				String[] values = {dmCodesLabelVO.getLabel()};	
				IMBResp resp1   = MBAppUtils.createErrorResp(mortgageParams.getBaseOriginCode(mobileSession.getOrigin()), exp, values, ServiceConstants.MORTGAGE_SERVICE, httpRequest);
				return resp1;
			}
			else if(e.getKey() == BusinessException.MORTGAGE_APP_VALIDATION_ERROR)
			{
				Logger.debug("Showing Hard block scrren", this.getClass());
				LoanAssessmentResp loanAssessmentResp = new LoanAssessmentResp();
				LoanAssessmentInfo loanAssessmentInfo = new LoanAssessmentInfo();
				loanAssessmentInfo.setLoanOutcomeStatus(Integer.parseInt(LoanOutcomeEnum.HARDBLOCK.getValue()));
				//loanAssessmentInfo.setOutcomeMessage(IBankParams.getErrorMessage(IBankParams.DEFAULT_ORIGIN, String.valueOf(BusinessException.OUTCOME_SAD_PATH2)));
				ArrayList<LoanAssessmentInfo> outComeList = new ArrayList<LoanAssessmentInfo>();
				outComeList.add(loanAssessmentInfo);
				loanAssessmentResp.setLoanAssessmentInfo(outComeList);
				RespHeader headerResp = populateResponseHeader(ServiceConstants.MORTGAGE_SERVICE, mobileSession);
				loanAssessmentResp.setHeader(headerResp);
				
				return loanAssessmentResp;
			}
			else if(e.getKey() == BusinessException.MORTGAGE_SESSION_SHARING_ERROR){
				Logger.error("Session is sharing among multiple tabs or browsers and multiple applications are trying to update using the same session......", this.getClass());									
				return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.MORTGAGE_SESSION_SHARING_ERROR, ServiceConstants.MORTGAGE_SERVICE, httpRequest);
			}
			else if(e.getKey() == BusinessException.MORTGAGE_DATA_ERROR){
				Logger.info("EXPENSES_VALIDATION_ERROR. So, invalidating the session", getClass() );
	            mobileSession.invalidateSession();
				return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE, ServiceConstants.MORTGAGE_SERVICE, httpRequest);
			}
			else{
				IMBResp resp1  = MBAppUtils.createErrorResp(mortgageParams.getBaseOriginCode(mobileSession.getOrigin()) ,exp, ServiceConstants.MORTGAGE_SERVICE, httpRequest);
				return resp1;
			}
			
		}
		catch (Exception e) {
			Logger.error("Exception in MortgageController - getLoanAssessment(): ", e, this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.DIGITAL_MORTGAGE_CLAS_SVC_UNAVAILABLE, ServiceConstants.MORTGAGE_SERVICE, httpRequest);
		} 
		finally {
			endPerformanceLog(logName);
		}
	}
	
	@RequestMapping(method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE, value = "saveApplication")
	@ResponseBody
	public IMBResp saveApplication(HttpServletRequest httpRequest, @RequestBody final ApplicationReq request) {
		
		String logName = startPerformanceLog(httpRequest);
		MobileSession mobileSession = null;

		try {
			ObjectMapper mapper = new ObjectMapper();
			Logger.info("MortgageController - saveApplication(). Request: " + mortgageHelper.hashSensitiveData(mapper.writeValueAsString(request) + " PageName : " + request.getApp().getPageName()), this.getClass());
			mobileSession = mbAppHelper.getMobileSession(httpRequest);
			
			
			boolean dbUpdateReq = isDBUpdateRequired( request.getApp(),  mobileSession );
			Logger.info( " isDBUpdateRequired : " + dbUpdateReq , this.getClass() );
			
			//Added to solve the issue of Session sharing among multiple tabs or browsers and multiple applications are trying to update using the same session.
			validateDigitalMortgageRequestHeader(request.getHeader(), httpRequest);
			ErrorResp errorResponse = validate(request, httpRequest);
			if (errorResponse.hasErrors()){
				Logger.error("ERROR in Request Params while calling saveApplication() - Invalid Request: "  , this.getClass());
				return errorResponse;
			}
			if(request.getApp() == null){
				Logger.error("MortgageController - saveApplication(). Request: " + request.getApp() , this.getClass());
				throw new BusinessException(BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE);
			}
			ApplicationInfo application = request.getApp();
			
			LoanTypeInfo loanType = application.getLoanType();
			List<ApplicantInfo> applicantsInfo = application.getApplicants();

			if(loanType == null || applicantsInfo.isEmpty() || applicantsInfo.size() == 0){
				Logger.error("MortgageController - saveApplication(). Request: loan type or applicant data is empty. " , this.getClass());
				throw new BusinessException(BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE);
			}
			Application applicationCLAS = mobileSession.getMortgageSessionInfo().getApplication();
			
			
			if(applicationCLAS != null){
				mortgageHelper.prePopulateApplicationVO(application, applicationCLAS);
	        }
			
			
			MortgageCommonData mortgageCommonData = mortgageHelper.populateMortgageCommonData(  mobileSession , request.getHeader(),   httpRequest );
			boolean creditCheckRequired = false;
			
			if(mobileSession.getHomeLoanApplication() != null && StringMethods.isEmptyString( mobileSession.getHomeLoanApplication().getCreditCheckEligible())){
				if(application.getLoanType().getCustomerSituation() != null){
					creditCheckRequired = mortgageHelper.crditDecisionEligible(mortgageCommonData.getOrigin(), application.getLoanType().getCustomerSituation());
				}
				else if(!StringMethods.isEmptyString(application.getLoanType().getLoanType()) && 
			    		MortgageUtil.LoanTypeEnum.REFINANCE.getType().equalsIgnoreCase(application.getLoanType().getLoanType())){
					creditCheckRequired = mortgageHelper.crditDecisionEligible(mortgageCommonData.getOrigin(), MortgageUtil.LoanTypeEnum.REFINANCE.getType() );
				}
			}
			else{
				creditCheckRequired = MortgageUtil.CreditCheckEligibleEnum.YES.getValue().equalsIgnoreCase(mobileSession.getHomeLoanApplication().getCreditCheckEligible()) ?  true : false;
			}
				
			boolean offerFlag =false;
			Boolean dmNewLoanTermSwitch = IBankParams.getSwitch(IBankParams.DEFAULT_ORIGIN, IBankParams.MORTGAGE_NEW_LOAN_TERM_SWITCH);
			if(null!=dmNewLoanTermSwitch && dmNewLoanTermSwitch==true){
				 offerFlag =mortgageHelper.checkOfferEligibility(request, mobileSession);
				 mortgageHelper.validateAppicationInfo(application, creditCheckRequired,offerFlag);
			}
			else{
				mortgageHelper.validateAppicationInfo(application, creditCheckRequired);
			}
			
			
			
			//validate
			
			
			//iBankCommonData is needed to retrieve QAS address using ESB SRV524
			IBankCommonData iBankCommonData = mbAppHelper.populateIBankCommonData(mobileSession,httpRequest);
			
			Application applicationVO = mortgageHelper.populateAppicationVO(application,mobileSession, iBankCommonData, perfLogger);
			Application masterApplicationVO = mortgageHelper.populateAppicationVO(application,mobileSession, iBankCommonData, perfLogger);
			
			
			if(applicationCLAS != null){
				mortgageService.mergeCLASInfoForSave(applicationVO, applicationCLAS);
			}
			
			
			iBankCommonData.setOrigin(mobileSession.getMortgageSessionInfo().getOrigin());
			iBankCommonData.setUser(new User("gcisNumber", "can","", null, false, true,false));
			
			Application sessionHomeLoanApplication = mobileSession.getHomeLoanApplication();
			
			
			
			if(sessionHomeLoanApplication != null && sessionHomeLoanApplication.getApplicationNum() != null && sessionHomeLoanApplication.getCreditCheckEligible() != null){
				Logger.info( "Application num : " + sessionHomeLoanApplication.getApplicationNum() + "Credit decision value :  " + sessionHomeLoanApplication.getCreditCheckEligible(), this.getClass() );
			}
			
			//Update application with session PID(i.e; db PID..)..
			//Get the list of CLASassets
			if(applicationCLAS != null && applicationCLAS.getAssets() != null && !applicationCLAS.getAssets().isEmpty()){
				mortgageHelper.updateApplicationWithPIDForSave(sessionHomeLoanApplication, applicationVO, applicationCLAS.getAssets());
			}
			
			
			
			
			
			if ( dbUpdateReq )
			{
				HashMap mapPropertiesBeforeSave = mortgageHelper.getModifiedListOfProperty(sessionHomeLoanApplication);
				
				//Logger.debug("***********START MortgageController - mortgageHelper.saveApplication()" , this.getClass());
				
				if ( application.getLoanType() != null  && (application.getLoanType().getCustomerSituation() != null || 
						MortgageUtil.LoanTypeEnum.REFINANCE.getType().equalsIgnoreCase(application.getLoanType().getLoanType()))) 
				{
					if(creditCheckRequired){
						applicationVO.setCreditCheckEligible(MortgageUtil.CreditCheckEligibleEnum.YES.getValue());
					}
					else{
						applicationVO.setCreditCheckEligible(MortgageUtil.CreditCheckEligibleEnum.NO.getValue());
					}
					Logger.info( "Application num : " + applicationVO.getApplicationNum() + "Credit decision value :  " + applicationVO.getCreditCheckEligible(), this.getClass() );
				}
	        	mortgageHelper.saveApplication(applicationVO, sessionHomeLoanApplication, mortgageCommonData, iBankCommonData, mobileSession, request.getHeader());
	        	//Logger.debug("***********END MortgageController - mortgageHelper.saveApplication()" , this.getClass());

	        	if ( application.getLoanType() != null  && application.getLoanType().getCustomerSituation() != null && StringMethods.isEmptyString(mobileSession.getHomeLoanApplication().getCreditCheckEligible()) ) 
	        	{
		        	mobileSession.getHomeLoanApplication().setCreditCheckEligible( applicationVO.getCreditCheckEligible());
	        	}

	        	
	        	
	        	HashMap mapPropertiesAfterSave = mortgageHelper.getModifiedListOfProperty(mobileSession.getHomeLoanApplication());
	        	
	        	//request for valorder
					Boolean valOrderSwitch = IBankParams.getSwitch(mortgageCommonData.getOrigin(), IBankParams.MORTGAGE_VAL_ORDER_SWITCH);
					if(valOrderSwitch){
						Logger.info( "ValOrderSwitch is On ", this.getClass() );
						//Logger.debug("***********START MortgageController - mortgageService.requestValOrdeProperty()" , this.getClass());
						if(mobileSession.getDMEvalRequestedList() == null){
							List valOrderList = new ArrayList<String>();
							mobileSession.setDMEvalRequestedList(valOrderList);
						}
						Application valOrderApp = mortgageService.requestValOrderProperty( mobileSession.getHomeLoanApplication(), mortgageCommonData, mapPropertiesBeforeSave, mapPropertiesAfterSave, mobileSession.getDMEvalRequestedList()); 
						mobileSession.setHomeLoanApplication(valOrderApp);
						
						//Logger.debug("***********END MortgageController - mortgageService.requestValOrdeProperty()" , this.getClass());
					}
					
					
			}
			
			SuccessResp successResp = new SuccessResp();																			
			RespHeader headerResp = populateResponseHeader(request.getHeader().getServiceName(), mobileSession);
			
			successResp.setIsPolicyOfferApplicable(offerFlag);
			
			if(request.getApp().getIsbackgroundCall()) {
				headerResp = mbAppHelper.populateAsyncResponseHeader(request.getHeader().getServiceName(), mobileSession, request.getApp().getIsbackgroundCall());
			}
			
			successResp.setHeader(headerResp);
			successResp.setIsSuccess(true);
			
			Logger.info("MortgageController - saveApplication(): Info JSON Response :" + mortgageHelper.hashSensitiveData(mapper.writeValueAsString(successResp)), this.getClass());

			
			return successResp;
		}catch (BusinessException e) {
			Logger.error("BusinessException - saveApplication():", e, this.getClass());			

			if(e.getKey() == BusinessException.MORTGAGE_SESSION_SHARING_ERROR){
				Logger.error("Session is sharing among multiple tabs or browsers and multiple applications are trying to update using the same session......", this.getClass());									
				return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.MORTGAGE_SESSION_SHARING_ERROR, ServiceConstants.MORTGAGE_SERVICE, httpRequest);
			}
			else{
				return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE, ServiceConstants.MORTGAGE_SERVICE, httpRequest);
			}
		}  
		catch (Exception e) {
			Logger.error("Exception in MortgageController - saveApplication(): ", e, this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE, ServiceConstants.MORTGAGE_SERVICE, httpRequest);
		} finally {
			endPerformanceLog(logName);
		}
	}
	

	
	@RequestMapping(method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE, value = "saveAndAssess")
	@ResponseBody
	public IMBResp saveAndAssessApplication(HttpServletRequest httpRequest, @RequestBody final ApplicationReq request) {
		
		String logName = startPerformanceLog(httpRequest);
		MobileSession mobileSession = null;

		try {
			ObjectMapper mapper = new ObjectMapper();
			Logger.info("MortgageController - saveAndAssessApplication(). Request: " + mortgageHelper.hashSensitiveData(mapper.writeValueAsString(request)), this.getClass());
			mobileSession = mbAppHelper.getMobileSession(httpRequest);
			boolean dbUpdateReq = isDBUpdateRequired( request.getApp(),  mobileSession );
			Logger.info( " isDBUpdateRequired : " + dbUpdateReq , this.getClass() );

			//Added to solve the issue of Session sharing among multiple tabs or browsers and multiple applications are trying to update using the same session.
			validateDigitalMortgageRequestHeader(request.getHeader(), httpRequest);
			ErrorResp errorResponse = validate(request, httpRequest);
			if (errorResponse.hasErrors()){
				Logger.error("ERROR in Request Params while calling saveAndAssessApplication() - Invalid Request: "  , this.getClass());
				return errorResponse;
			}
			if(request.getApp() == null){
				Logger.error("MortgageController - saveAndAssessApplication(). Request: " + request.getApp() , this.getClass());
				throw new BusinessException(BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE);
			}
			ApplicationInfo application = request.getApp();
			
			LoanTypeInfo loanType = application.getLoanType();
			List<ApplicantInfo> applicantsInfo = application.getApplicants();
			//List<LiabilityInfo> liabilityInfoList = application.getLiabilities();

			if(loanType == null || applicantsInfo.isEmpty() || applicantsInfo.size() == 0){
				Logger.error("MortgageController - saveAndAssessApplication(). Request: loan type or applicant data is empty. " , this.getClass());
				throw new BusinessException(BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE);
			}
			Application applicationCLAS = mobileSession.getMortgageSessionInfo().getApplication();
			if(applicationCLAS != null){
				mortgageHelper.prePopulateApplicationVO(application, applicationCLAS);
	        }
			
			MortgageCommonData mortgageCommonData = mortgageHelper.populateMortgageCommonData(  mobileSession , request.getHeader(),   httpRequest );
			
			//CreditDecision
			boolean creditCheckRequired = false;
			if(mobileSession.getHomeLoanApplication() != null && StringMethods.isEmptyString( mobileSession.getHomeLoanApplication().getCreditCheckEligible())){
				if(application.getLoanType().getCustomerSituation() != null){
					creditCheckRequired = mortgageHelper.crditDecisionEligible(mortgageCommonData.getOrigin(), application.getLoanType().getCustomerSituation());
				}
				else if(!StringMethods.isEmptyString(application.getLoanType().getLoanType()) && 
			    		MortgageUtil.LoanTypeEnum.REFINANCE.getType().equalsIgnoreCase(application.getLoanType().getLoanType())){
					creditCheckRequired = mortgageHelper.crditDecisionEligible(mortgageCommonData.getOrigin(), MortgageUtil.LoanTypeEnum.REFINANCE.getType() );
				}
			}
			else{
				creditCheckRequired = "Y".equalsIgnoreCase(mobileSession.getHomeLoanApplication().getCreditCheckEligible()) ?  true : false;
			}
			
			
	        //validate
			boolean offerFlag =false;
			Boolean dmNewLoanTermSwitch = IBankParams.getSwitch(IBankParams.DEFAULT_ORIGIN, IBankParams.MORTGAGE_NEW_LOAN_TERM_SWITCH);
			if(null!=dmNewLoanTermSwitch && dmNewLoanTermSwitch==true){
				 offerFlag =mortgageHelper.checkOfferEligibility(request, mobileSession);
				 mortgageHelper.validateAppicationInfo(application, creditCheckRequired,offerFlag);
			}
			else{
				mortgageHelper.validateAppicationInfo(application, creditCheckRequired);
			}
			
			
			//iBankCommonData is needed to retrieve QAS address using ESB SRV524
			IBankCommonData iBankCommonData = mbAppHelper.populateIBankCommonData(mobileSession,httpRequest);
			
			Application applicationVO = mortgageHelper.populateAppicationVO(application,mobileSession, iBankCommonData, perfLogger);
			
			if(applicationCLAS != null){
				mortgageService.mergeCLASInfoForSave(applicationVO, applicationCLAS);
			}
			
			iBankCommonData.setOrigin(mobileSession.getMortgageSessionInfo().getOrigin());
			iBankCommonData.setUser(new User("gcisNumber", "can","", null, false, true,false));
			
			Application sessionHomeLoanApplication = mobileSession.getHomeLoanApplication();
			if(sessionHomeLoanApplication != null && sessionHomeLoanApplication.getApplicationNum() != null && sessionHomeLoanApplication.getCreditCheckEligible() != null){
				Logger.info( "Application num : " + sessionHomeLoanApplication.getApplicationNum() + "Credit decision value :  " + sessionHomeLoanApplication.getCreditCheckEligible(), this.getClass() );
			}
			
			//Update application with session PID(i.e; db PID..)..
			//Get the list of CLASassets
			if(applicationCLAS != null && applicationCLAS.getAssets() != null && !applicationCLAS.getAssets().isEmpty()){
				mortgageHelper.updateApplicationWithPIDForSave(sessionHomeLoanApplication, applicationVO, applicationCLAS.getAssets());
			}
			
			
			if ( dbUpdateReq )
			{
				HashMap mapPropertiesBeforeSave = mortgageHelper.getModifiedListOfProperty(sessionHomeLoanApplication);
				if ( application.getLoanType() != null  && (application.getLoanType().getCustomerSituation() != null || 
						MortgageUtil.LoanTypeEnum.REFINANCE.getType().equalsIgnoreCase(application.getLoanType().getLoanType()))) 
				{
					if(creditCheckRequired){
						applicationVO.setCreditCheckEligible(MortgageUtil.CreditCheckEligibleEnum.YES.getValue());
					}
					else{
						applicationVO.setCreditCheckEligible(MortgageUtil.CreditCheckEligibleEnum.NO.getValue());
					}
					Logger.info( "Application num : " + applicationVO.getApplicationNum() + "Credit decision value :  " + applicationVO.getCreditCheckEligible(), this.getClass() );
				}
				mortgageHelper.saveApplication(applicationVO, sessionHomeLoanApplication, mortgageCommonData, iBankCommonData, mobileSession, request.getHeader());
				
				HashMap mapPropertiesAfterSave = mortgageHelper.getModifiedListOfProperty(mobileSession.getHomeLoanApplication());
				
				//request for valorder
					Boolean valOrderSwitch = IBankParams.getSwitch(mortgageCommonData.getOrigin(), IBankParams.MORTGAGE_VAL_ORDER_SWITCH);
					if(valOrderSwitch){
						Logger.info( "ValOrderSwitch is On ", this.getClass() );
						if(mobileSession.getDMEvalRequestedList() == null){
							List valOrderList = new ArrayList<String>();
							mobileSession.setDMEvalRequestedList(valOrderList);
						}
						Application valOrderApp = mortgageService.requestValOrderProperty( mobileSession.getHomeLoanApplication(), mortgageCommonData, mapPropertiesBeforeSave, mapPropertiesAfterSave, mobileSession.getDMEvalRequestedList());
						mobileSession.setHomeLoanApplication(valOrderApp);
					}
			}
			MortgageSessionInfo mortgageSessionInfo = mobileSession.getMortgageSessionInfo() ;	
			LoanOutcomeInfo loanOutcomeInfo = mortgageService.getLoanAssessmentOutCome(mobileSession.getMortgageSessionInfo().getApplicationNumber(),  mortgageCommonData, mobileSession.getMortgageSessionInfo().getApplication());
			ArrayList<LoanOutcome> loanOutcomes = loanOutcomeInfo.getLoanOutcomes();
			
			LoanAssessmentResp loanAssessmentResp = null;
			
			//ValAssess data
			boolean isRequired = mortgageService.isValAssessRequired(mobileSession.getHomeLoanApplication());
			boolean valOrderSwitch = IBankParams.isSwitchOn(mortgageCommonData.getOrigin(), IBankParams.MORTGAGE_VAL_ORDER_SWITCH);
			Logger.info("Applcation has eligible Property(PP or Refi) to consider for Val Assess. ",this.getClass());
			if(isRequired && mobileSession.getHomeLoanApplication() != null && loanOutcomes != null && !loanOutcomes.isEmpty() 
					&& mortgageHelper.isEligibleSegmentForValAssess(loanOutcomes)
					&& valOrderSwitch){
				
				Boolean valAssessRequired = mortgageService.checkValAssessEligibility(loanOutcomes, mobileSession.getHomeLoanApplication());
				Logger.info("valAssessRequired : "+valAssessRequired ,this.getClass());
				String valStatus = null;
				
				if(valAssessRequired){
					valStatus = ValAssessEnum.INPROGRESS.getValue();
				}
				else{
					valStatus = ValAssessEnum.SUBJECT_TO_VALUATION.getValue();
				}

				//Update Val Status in LoanOutcome table
				loanOutcomes.get(0).setValuationStatus(valStatus);
				mortgageService.saveLoanOutcome(mobileSession.getMortgageSessionInfo().getApplicationNumber(), loanOutcomes.get(0));
				loanAssessmentResp = mortgageHelper.populateLoanAssessmentResp(loanOutcomeInfo, mobileSession, valAssessRequired, valStatus);
			}
			else{
				loanAssessmentResp = mortgageHelper.populateLoanAssessmentResp(loanOutcomeInfo, mobileSession, null, null);
			}
			
			
			
			if(loanOutcomeInfo.getValAssessPostReq() != null){
				mobileSession.setValAssessPostReqStr(mapper.writeValueAsString(loanOutcomeInfo.getValAssessPostReq()));
			}
			
			//Used in Post submit screen, in case CLAS submit service is down
			mortgageSessionInfo.setOutcomeStatus(loanAssessmentResp.getLoanAssessmentInfo().get(0).getLoanOutcomeStatus().toString());
			//Used in submit call, in case customer selected/changed the segment using LMI toggle(to update loan outcome table with new segment data)
			if(loanOutcomes != null && !loanOutcomes.isEmpty()){
				mobileSession.setLoanOutcomes(loanOutcomes);
			}
			
			
			
			
			
			RespHeader headerResp = populateResponseHeader(ServiceConstants.MORTGAGE_SERVICE, mobileSession);
			
			loanAssessmentResp.setIsPolicyOfferApplicable(offerFlag);
			loanAssessmentResp.setHeader(headerResp);

			
			

			Logger.info("MortgageController - saveAndAssessApplication(): Info JSON Response :" + mortgageHelper.hashSensitiveData(mapper.writeValueAsString(loanAssessmentResp)), this.getClass());

			
			return loanAssessmentResp;
		}catch (BusinessException e) {
			Logger.error("BusinessException in MortgageController - saveAndAssessApplication(): ", e, this.getClass());
			BusinessException exp = new BusinessException(e.getKey());
			if(e.getKey() == BusinessException.MORTGAGE_APP_ERROR
					|| e.getKey() == BusinessException.MORTGAGE_APP_SUBMIT_TIMEOUT)
			{
				exp = new BusinessException(BusinessException.MORTGAGE_APP_ERROR);
				Logger.debug("Showing error message on Review/Summary screen", this.getClass());
				LabelValueVO dmCodesLabelVO = mortgageParams.getDMCodesDataLabelValueVO(mortgageParams.getBaseOriginCode(mobileSession.getOrigin()),
						MortgageUtil.REF_DATA_CATEGORY_HELP_DESK,
						mortgageParams.getBaseOriginCode(mobileSession.getOrigin()));
				String[] values = {dmCodesLabelVO.getLabel()};	
				IMBResp resp1   = MBAppUtils.createErrorResp(mortgageParams.getBaseOriginCode(mobileSession.getOrigin()), exp, values, ServiceConstants.MORTGAGE_SERVICE, httpRequest);
				return resp1;
			}
			else if(e.getKey() == BusinessException.MORTGAGE_APP_VALIDATION_ERROR)
			{
				Logger.debug("Showing Hard block scrren", this.getClass());
				LoanAssessmentResp loanAssessmentResp = new LoanAssessmentResp();
				LoanAssessmentInfo loanAssessmentInfo = new LoanAssessmentInfo();
				loanAssessmentInfo.setLoanOutcomeStatus(Integer.parseInt(LoanOutcomeEnum.HARDBLOCK.getValue()));
				ArrayList<LoanAssessmentInfo> outComeList = new ArrayList<LoanAssessmentInfo>();
				outComeList.add(loanAssessmentInfo);
				loanAssessmentResp.setLoanAssessmentInfo(outComeList);

				RespHeader headerResp = populateResponseHeader(ServiceConstants.MORTGAGE_SERVICE, mobileSession);
				loanAssessmentResp.setHeader(headerResp);
				return loanAssessmentResp;
			}
			else if(e.getKey() == BusinessException.MORTGAGE_SESSION_SHARING_ERROR){
				Logger.error("Session is sharing among multiple tabs or browsers and multiple applications are trying to update using the same session......", this.getClass());									
				return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.MORTGAGE_SESSION_SHARING_ERROR, ServiceConstants.MORTGAGE_SERVICE, httpRequest);
			}
			else if(e.getKey() == BusinessException.MORTGAGE_DATA_ERROR){
				Logger.info("EXPENSES_VALIDATION_ERROR. So, invalidating the session", getClass() );
	            mobileSession.invalidateSession();
				return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE, ServiceConstants.MORTGAGE_SERVICE, httpRequest);
			}
			else{
				IMBResp resp1  = MBAppUtils.createErrorResp(mortgageParams.getBaseOriginCode(mobileSession.getOrigin()) ,exp, ServiceConstants.MORTGAGE_SERVICE, httpRequest);
				return resp1;
			}
			
		}
		catch (Exception e) {
			Logger.error("Exception in MortgageController - saveAndAssessApplication(): ", e, this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE, ServiceConstants.MORTGAGE_SERVICE, httpRequest);
		} finally {
			endPerformanceLog(logName);
		}
	}
	
	@RequestMapping(method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE, value = "retrieveApplication")
	@ResponseBody
	public IMBResp retrieveApplication(HttpServletRequest httpRequest, HttpServletResponse httpResponse,  @RequestBody final RetrieveDetailsReq request) {
		Logger.debug("MortgageController - retrieveApplication(). Request: " + request, this.getClass());
		
		String logName = startPerformanceLog(httpRequest);
		MobileSession mobileSession = null;
	    String origin = logonHelper.resolveOrigin(httpRequest);
	    IGenericSession genericSession =  null;
		try {	
			mobileSession = mbAppHelper.getMobileSession(httpRequest);

			validateRequestHeader(request.getHeader(), httpRequest);
			ErrorResp errorResponse = validate(request, httpRequest);
			if (errorResponse.hasErrors()){
				return errorResponse;
			}
			
			 //Throttling check
			boolean isThrottleAllowed = true;
			try{
				isThrottleAllowed = throttleService.processThrottling(IBankParams.HOMELOAN_APPLICATION_SOURCE);
			}catch(Exception e){
				//Do nothing . Go ahaead with call
				Logger.error("Mortgage : Exception occured in throttle service.."+e, this.getClass());					
			}
			if(!isThrottleAllowed){
				Logger.info("Mortgage max throttling exceeded : ", this.getClass());
				throw new BusinessException(BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE);
			}
			 
			
			MortgageCommonData mortgageCommonData =  mortgageHelper.populateMortgageCommonData(  genericSession,  origin, request.getHeader(),  httpRequest );
			//replace space with empty string
			String refNum = request.getReferenceNumber().replaceAll("\\s+",""); 
			Application applicationVO = mortgageService.retrieveApplication(request.getEmail(),refNum, mortgageCommonData);
			mobileSession.setHomeLoanApplication((Application)SerializationUtils.clone(applicationVO));
			
			genericSession = mortgageHelper.createSession( httpRequest, httpResponse);
			mortgageCommonData.setSessionId(genericSession.getId());
			genericSession.setAttribute(MobileSessionImpl.HOMELOAN_APPLICATION, applicationVO);
			
			mortgageService.logStatistics(mortgageCommonData, "Retrieve Application ", MortgageUtil.GWDStatatisticActionsEnum.RetrieveApplication.getValue());;
			
			
			//Update Mortgage Session Object with customerReferenceNum, applicationNum, email
			
			MortgageSessionInfo mortgageSessionInfo = new MortgageSessionInfo();
			mortgageSessionInfo.setOrigin((String)genericSession.getAttribute(MobileSessionImpl.ORIGIN_OBLECT));
			mortgageSessionInfo.setRefNumber(new Long(refNum));
			mortgageSessionInfo.setApplicationNumber(applicationVO.getApplicationNum());
			mortgageSessionInfo.setEmail(request.getEmail());  
			genericSession.setAttribute(MobileSessionImpl.MORTGAGE_APPLICATION,mortgageSessionInfo);
			
			ApplicationResp applicationResp = new ApplicationResp();
			List<Applicant> applicants = applicationVO.getApplicants();	
			Applicant primaryApplicant = applicants.get(0);
  
			IBankCommonData iBankCommonData = mbAppHelper.populateIBankCommonData(mobileSession,httpRequest);
			
			mortgageService.updateBrand(applicationVO.getApplicationNum(), mortgageCommonData.getOrigin()); //TODO VB
			
			//If primary applicant in Ext then merge data from class
			if(!primaryApplicant.getNtbInd()){
				
				Application applicationCLAS = mortgageService.getCustomerCLASInfo(applicants, mortgageCommonData);  
			    
			    mortgageSessionInfo.setApplication(applicationCLAS);
			    
			    boolean hasChanged = mortgageService.mapCLASInfoForSave(applicationVO, applicationCLAS);
			    
			    if(IBankParams.isSwitchOn(mortgageCommonData.getOrigin(), IBankParams.MORTGAGE_CREDIT_DECISONING_SWITCH)){
				    mortgageService.getForeignTaxInfo(applicationVO, iBankCommonData);
			    }
			    
			    if(hasChanged){
			    	if(applicationVO.getDashboard() != null && applicationVO.getDashboard().isAssetStatusInd())
			    	{
			    		//TODO check if total asset value not greater than 1
			    		/*if(){
			    			applicationVO.getDashboard().setAssetStatusInd(false);
			    		}*/
			    	}
			    	
			    	Application applicationForSave = (Application)SerializationUtils.clone(applicationVO);
			    	mortgageHelper.saveApplication(applicationForSave, mobileSession.getHomeLoanApplication(), mortgageCommonData, iBankCommonData, mobileSession, request.getHeader());
			    }
			    
			    mortgageService.mergeCLASInfoForRetrieve(applicationVO, applicationCLAS, mortgageParams.getBaseOriginCode(mortgageCommonData.getOrigin()), false);
			}
			
			//Retrieve application and do the val order, if any missing based on Application status like Inprogress..and etc..not for Submiited..status
			//For all retrievals..
			
			String applicationStatus = applicationVO.getApplicationStatus();
			if(MortgageUtil.ApplicationStatusEnum.NEW.getStatus().equalsIgnoreCase(applicationStatus)  
				    || MortgageUtil.ApplicationStatusEnum.IN_PROGRESS.getStatus().equalsIgnoreCase(applicationStatus) 
				    || MortgageUtil.ApplicationStatusEnum.ASSESS.getStatus().equalsIgnoreCase(applicationStatus)){
	        	
	        	//request for valorder
				Boolean valOrderSwitch = IBankParams.getSwitch(mortgageCommonData.getOrigin(), IBankParams.MORTGAGE_VAL_ORDER_SWITCH);
				if(valOrderSwitch){
					Logger.info( "ValOrderSwitch is On ", this.getClass() );
					if(genericSession.getAttribute(MobileSessionImpl.EVALORDERED_LIST) == null){
						List valOrderList = new ArrayList<String>();
						//Since mobile session is not updating the values of valOrderList, using genericSession to update (same as above HOMELOAN_APPLICATION)
						genericSession.setAttribute(MobileSessionImpl.EVALORDERED_LIST, valOrderList);
						
					}
					HashMap mapProperties = mortgageHelper.getModifiedListOfProperty(mobileSession.getHomeLoanApplication());
					//Logger.debug("***********START MortgageController - mortgageService.requestValOrdeProperty()" , this.getClass());
					//Since mobile session is not updating the values of valOrderList, using genericSession for getter also.
					Application valOrderApp = mortgageService.requestValOrderProperty((Application) genericSession.getAttribute(MobileSessionImpl.HOMELOAN_APPLICATION), mortgageCommonData, mapProperties, mapProperties, (List<String>)genericSession.getAttribute(MobileSessionImpl.EVALORDERED_LIST));
					//mobileSession.setHomeLoanApplication(valOrderApp);
					genericSession.setAttribute(MobileSessionImpl.HOMELOAN_APPLICATION, valOrderApp);
					//Logger.debug("***********END MortgageController - mortgageService.requestValOrdeProperty()" , this.getClass());
				}
			}

			
			ApplicationInfo applicationInfo = mortgageHelper.populateApplicationInfo(applicationVO);
			
			applicationResp.setApp(applicationInfo);
			
			applicationResp.setApplicationNum(applicationVO.getApplicationNum().toString());	
			RespHeader headerResp = populateResponseHeader(ServiceConstants.MORTGAGE_SERVICE, null);
			applicationResp.setHeader(headerResp);

			applicationResp.setSuccess(true);

			ObjectMapper mapper = new ObjectMapper();
			Logger.info("MortgageController - retrieveApplication() JSON Response :" + mortgageHelper.hashSensitiveData(mapper.writeValueAsString(applicationResp)), this.getClass());

			return applicationResp;
		} catch (BusinessException e) {
			Logger.error("Exception in MortgageController - retrieveApplication(): ", e, this.getClass());
			
		    if(e.getKey() == BusinessException.DIGITAL_MORTGAGES_NTB_INVALID_LOGIN_CREDENTIALS){
		    	String[] values = { mortgageRefDataHelper.getHelpDeskContactNumber(origin) };
		    	return MBAppUtils.createErrorResp(origin, e, values, ServiceConstants.MORTGAGE_SERVICE, httpRequest);
		    }
		    else if(e.getKey() == BusinessException.DIGITAL_MORTGAGES_REFINANCE_SWITCH_OFF){
		    	String[] values = { mortgageRefDataHelper.getHelpDeskContactNumber(origin) };
		    	return MBAppUtils.createErrorResp(origin, e, values, ServiceConstants.MORTGAGE_SERVICE, httpRequest);
		    }else {
		    	return MBAppUtils.createErrorResp(origin, BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE, ServiceConstants.MORTGAGE_SERVICE, httpRequest);
		    }
		}  catch (Exception e) {
			Logger.error("Exception in MortgageController - retrieveApplication(): ", e, this.getClass());
			return MBAppUtils.createErrorResp(origin, BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE, ServiceConstants.MORTGAGE_SERVICE, httpRequest);
		} finally {
			if ( genericSession != null )
				genericSession.updateSession();				
			endPerformanceLog(logName);
		}
		

	}
	

	
	@RequestMapping(method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE, value = "getPropertyInsightDetails")
	@ResponseBody
	public IMBResp getPropertyInsightDetails(HttpServletRequest httpRequest, @RequestBody final PropertyInsightReq request) {
		Logger.debug("MortgageController - getPropertyInsightDetails(). Request: " + request, this.getClass());
		String logName = startPerformanceLog(httpRequest);
		MobileSession mobileSession = null;
		MortgageAddress addr=null;
		MortgageAddress mortgageAddr=null;
		boolean heartBeatFlag=false;
		String origin = logonHelper.resolveOrigin(httpRequest);

		try {
			ObjectMapper mapper = new ObjectMapper();
			Logger.debug("MortgageController - callPropertyInsight(). Request: " + mapper.writeValueAsString(request), this.getClass());
			mobileSession = mbAppHelper.getMobileSession(httpRequest);

			//validateRequestHeader(request.getHeader(), httpRequest);
			//Added to solve the issue of Session sharing among multiple tabs or browsers and multiple applications are trying to update using the same session.
			validateDigitalMortgageRequestHeader(request.getHeader(), httpRequest);
			ErrorResp errorResponse = validate(request, httpRequest);
			if (errorResponse.hasErrors()){
				return errorResponse;
			}

			// Heart Beat check
			if (!HeartBeat.isApplicationAvailable(HeartBeat.PROPERTY_INSIGHT)) {
				Logger.debug("MortgageController - Inside heartbeat down: ", this.getClass());
				heartBeatFlag=false;
				PropertyInsightResp propertyInsightResp=new PropertyInsightResp();
				RespHeader headerResp = populateResponseHeader(ServiceConstants.MORTGAGE_SERVICE, mobileSession);				
				propertyInsightResp.setHeader(headerResp);
				propertyInsightResp.setPropertyInsightUp(heartBeatFlag);
                propertyInsightResp.setSuccess(false);		
				return propertyInsightResp;
			}
			else{
				Logger.debug("MortgageController - Inside heartbeat up: ", this.getClass());
				heartBeatFlag=true;
			}
			Logger.debug("MortgageController - Continuing for heartbeat up: ", this.getClass());
			//validate
			mortgageHelper.validatePropertyInsightReq(request);
			
			//iBankCommonData is needed to retrieve QAS address using ESB SRV524
			IBankCommonData iBankCommonData = mbAppHelper.populateIBankCommonData(mobileSession,httpRequest);
			iBankCommonData.setOrigin(origin);
			iBankCommonData.setUser(new User("gcisNumber", "can","", null, false, true,false));

			if(heartBeatFlag && !request.getManualAddress()){
				 
				 AddressInfo addressInfo = new AddressInfo();
				 addressInfo.setQasAddressId(request.getQasAddressID());
				 addressInfo.setAddrType(AddressType.D.toString());
				 
				 addr= mortgageHelper.storeQASAddressInSession( addressInfo,  iBankCommonData,  mobileSession,  perfLogger,  AddressType.D.toString());

				 mortgageAddr=new MortgageAddress();
				 mortgageAddr.setLine1(addr.getLine1());
				 mortgageAddr.setLine2(addr.getLine2());
				 mortgageAddr.setLine3(addr.getLine3());
				 mortgageAddr.setPostCode(addr.getPostCode());
				 mortgageAddr.setSuburb(addr.getSuburb());
				 mortgageAddr.setState(addr.getState());
				 mortgageAddr.setCountry(addr.getCountry());
				 mortgageAddr.setCountryName(addr.getCountryName());
				 
			}
			
			PropertyInsightResp propertyInsightResp=new PropertyInsightResp();
            propertyInsightResp=mortgageHelper.populatePropertyInsightResp(mortgageAddr,heartBeatFlag);                                            
			
			RespHeader headerResp = populateResponseHeader(ServiceConstants.MORTGAGE_SERVICE, mobileSession);
			propertyInsightResp.setHeader(headerResp);
			propertyInsightResp.setSuccess(true);
			Logger.debug("MortgageController - retrieveApplication() JSON Response :" + mapper.writeValueAsString(propertyInsightResp), this.getClass());			
			return propertyInsightResp;
			
		} 
		catch (BusinessException e) {
			Logger.error("BusinessException - callPropertyInsight():", e, this.getClass());			

			if(e.getKey() == BusinessException.MORTGAGE_SESSION_SHARING_ERROR){
				Logger.error("Session is sharing among multiple tabs or browsers and multiple applications are trying to update using the same session......", this.getClass());									
				return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.MORTGAGE_SESSION_SHARING_ERROR, ServiceConstants.MORTGAGE_SERVICE, httpRequest);
			}
			else{
				return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE, ServiceConstants.MORTGAGE_SERVICE, httpRequest);
			}
		}  
		catch (Exception e) {
			Logger.error("Exception in MortgageController - saveApplication(): ", e, this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE, ServiceConstants.MORTGAGE_SERVICE, httpRequest);
		} finally {
			endPerformanceLog(logName);
		}
	}
	
	@RequestMapping(method = RequestMethod.POST, headers = "content-type=application/json", produces = MediaType.APPLICATION_JSON_VALUE, value = "ChatEvent")
	@ResponseBody
	public IMBResp ChatEventGDWEntry(HttpServletRequest httpRequest, @RequestBody final ChatEventReq request) {
		String logName = startPerformanceLog(httpRequest);
		MobileSession mobileSession = null;

		try {
			mobileSession = mbAppHelper.getMobileSession(httpRequest);
			
			if (mobileSession == null) {
				return null;
			}
			
			//validateRequestHeader(request.getHeader(), httpRequest);
			//Added to solve the issue of Session sharing among multiple tabs or browsers and multiple applications are trying to update using the same session.
			validateDigitalMortgageRequestHeader(request.getHeader(), httpRequest);
			ErrorResp errorResponse = validate(request, httpRequest);
			if (errorResponse.hasErrors()) {
				return errorResponse;
			}
			
			MortgageCommonData mortgageCommonData = mortgageHelper.populateMortgageCommonData(mobileSession,  request.getHeader(), httpRequest);
			if (request.getChatEvent() != null) {
				if (request.getChatEvent().equals(MortgageUtil.GWDStatatisticActionsEnum.ChatStart.getValue())) {
					mortgageService.updateLastChatInitiatedDate(mobileSession.getMortgageSessionInfo().getApplicationNumber());
					mortgageService.makeChatStatsEntry(mortgageCommonData, "Chat Started", MortgageUtil.GWDStatatisticActionsEnum.ChatStart.getValue());
					
				}
				else if (request.getChatEvent().equals(MortgageUtil.GWDStatatisticActionsEnum.ChatClose.getValue())) {
					mortgageService.makeChatStatsEntry(mortgageCommonData, "Chat Closed", MortgageUtil.GWDStatatisticActionsEnum.ChatClose.getValue());
				}
				else if (request.getChatEvent().equals(MortgageUtil.GWDStatatisticActionsEnum.ChatInit.getValue())) {
                    mortgageService.makeChatStatsEntry(mortgageCommonData, "Chat Initiated", MortgageUtil.GWDStatatisticActionsEnum.ChatInit.getValue());
              }
			}
			SuccessResp successResp = new SuccessResp();
			RespHeader headerResp = mbAppHelper.populateAsyncResponseHeader(request.getHeader().getServiceName(), mobileSession,request.isIsbackGroundCall());
			successResp.setHeader(headerResp);
			successResp.setIsSuccess(true);
			
			return successResp;
		} 
		catch (BusinessException e) {
			Logger.error("BusinessException - ChatEventGDWEntry():", e, this.getClass());			

			if(e.getKey() == BusinessException.MORTGAGE_SESSION_SHARING_ERROR){
				Logger.error("Session is sharing among multiple tabs or browsers and multiple applications are trying to update using the same session......", this.getClass());									
				return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.MORTGAGE_SESSION_SHARING_ERROR, ServiceConstants.MORTGAGE_SERVICE, httpRequest);
			}
			else{
				return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE, ServiceConstants.MORTGAGE_SERVICE, httpRequest);
			}
		}  
		catch (Exception e) {
			Logger.error("Exception in MortgageController - ChatEventGDWEntry(): ",e, this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE, ServiceConstants.MORTGAGE_SERVICE, httpRequest);
		} finally {
			endPerformanceLog(logName);
		}
	}
	
	
	@RequestMapping(method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE, value = "submit")
	@ResponseBody
	public IMBResp submit(HttpServletRequest httpRequest, @RequestBody final SubmitReq request) {
		String logName = startPerformanceLog(httpRequest);
		MobileSession mobileSession = null;
		try {
			ObjectMapper mapper = new ObjectMapper();
			Logger.info("MortgageController - submit(). Request: " + mortgageHelper.hashSensitiveData(mapper.writeValueAsString(request)), this.getClass());
			mobileSession = mbAppHelper.getMobileSession(httpRequest);

			//validateRequestHeader(request.getHeader(), httpRequest);
			//Added to solve the issue of Session sharing among multiple tabs or browsers and multiple applications are trying to update using the same session.
			validateDigitalMortgageRequestHeader(request.getHeader(), httpRequest);
			ErrorResp errorResponse = validate(request, httpRequest);
			if (errorResponse.hasErrors()){
				return errorResponse;
			}

			MortgageCommonData mortgageCommonData = mortgageHelper.populateMortgageCommonData(mobileSession,  request.getHeader(), httpRequest);
			IBankCommonData commonData = mbAppHelper.populateIBankCommonData(mobileSession,httpRequest);
			
			LoanOutcome loanOutcomeUsed = null;
			if(request.getSegmentName() != null){
				String segmentUsed = request.getSegmentName();
				MortgageSessionInfo mortgageSessionInfo = mobileSession.getMortgageSessionInfo() ;	
				if(mobileSession != null){
					if(mobileSession.getLoanOutcomes() != null && !mobileSession.getLoanOutcomes().isEmpty() && mobileSession.getLoanOutcomes().size() > 1){
						for(LoanOutcome loanOutcome : mobileSession.getLoanOutcomes()) {
							if(  loanOutcome.getSegmentUsed().equalsIgnoreCase(segmentUsed)){
								loanOutcomeUsed = loanOutcome;
								Logger.info("loanOutcomeUsed.getCampaignMarginDate() : "+loanOutcomeUsed.getCampaignMarginDate(), this.getClass());
								mortgageService.saveLoanOutcome(mobileSession.getMortgageSessionInfo().getApplicationNumber(), loanOutcomeUsed);
								break;
							}
						}
					}
				}
			}
			
	   		//Check if application is already submitted
	   		mortgageHelper.checkApplicationSubmitted(mobileSession.getMortgageSessionInfo().getApplicationNumber(), mobileSession);

			String creditCheckStatus = mortgageService.submitApplication(mobileSession.getMortgageSessionInfo().getApplicationNumber(), mortgageCommonData, mobileSession.getMortgageSessionInfo().getApplication());			

			
			MortgageSubmitResp successResp = populateSubmitResponse(mobileSession);
			successResp.setCreditCheckStatus(creditCheckStatus);
			RespHeader headerResp = populateResponseHeader(request.getHeader().getServiceName(), mobileSession);
			successResp.setHeader(headerResp);

			Logger.debug("MortgageController - submit() JSON Response :" + mapper.writeValueAsString(successResp), this.getClass());

			return successResp;
		}  
		catch (BusinessException e) {
			Logger.error("Exception in MortgageController - submit(): ", e, this.getClass());
			BusinessException exp = new BusinessException(e.getKey());
			
			//MORTGAGE_APP_SUBMIT_TIMEOUT
			if(e.getKey() == BusinessException.MORTGAGE_APP_ERROR)
			{
				LabelValueVO dmCodesLabelVO = mortgageParams.getDMCodesDataLabelValueVO(mortgageParams.getBaseOriginCode(mobileSession.getOrigin()),
						MortgageUtil.REF_DATA_CATEGORY_HELP_DESK,
						mortgageParams.getBaseOriginCode(mobileSession.getOrigin()));
				String[] values = {dmCodesLabelVO.getLabel()};	
				IMBResp resp1   = MBAppUtils.createErrorResp(mortgageParams.getBaseOriginCode(mobileSession.getOrigin()), exp, values, ServiceConstants.MORTGAGE_SERVICE, httpRequest);
				return resp1;
			}
			else if(e.getKey() == BusinessException.MORTGAGE_APP_CLAS_DOWN)
			{
				MortgageSubmitResp successResp = populateSubmitResponse(mobileSession);
				RespHeader headerResp = populateResponseHeader(request.getHeader().getServiceName(), mobileSession);
				successResp.setHeader(headerResp);
				successResp.setClasDown(true);
				Logger.info("Session is invalidated. " , this.getClass());
				
				return successResp;
				
			}
			else if(e.getKey() == BusinessException.MORTGAGE_APP_SUBMIT_TIMEOUT || 
					e.getKey() == BusinessException.MORTGAGE_APP_VALIDATION_ERROR)
			{
				MortgageSubmitResp successResp = new MortgageSubmitResp();																			
				RespHeader headerResp = populateResponseHeader(request.getHeader().getServiceName(), mobileSession);
				successResp.setHeader(headerResp);
				successResp.setStatus(MortgageUtil.FAIL);

				
				Logger.info("Session is invalidated. " , this.getClass());
				
				return successResp;
			}
			else if(e.getKey() == BusinessException.MORTGAGE_SESSION_SHARING_ERROR){
				Logger.error("Session is sharing among multiple tabs or browsers and multiple applications are trying to update using the same session......", this.getClass());									
				return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.MORTGAGE_SESSION_SHARING_ERROR, ServiceConstants.MORTGAGE_SERVICE, httpRequest);
			}
			else{
				IMBResp resp1  = MBAppUtils.createErrorResp(mortgageParams.getBaseOriginCode(mobileSession.getOrigin()) ,exp, ServiceConstants.MORTGAGE_SERVICE, httpRequest);
				return resp1;
			}
		}
		catch (Exception e) {
			Logger.error("Exception in MortgageController - submit(): ", e, this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.DIGITAL_MORTGAGE_CLAS_SVC_UNAVAILABLE, ServiceConstants.MORTGAGE_SERVICE, httpRequest);
		} finally {
			endPerformanceLog(logName);
		}
	}
	
	@RequestMapping(method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE, value = "saveDashboardIntro")
	@ResponseBody
	public IMBResp saveDashboardIntro(HttpServletRequest httpRequest, @RequestBody final EmptyReq request) {
		
		String logName = startPerformanceLog(httpRequest);
		MobileSession mobileSession = null;

		try {
			ObjectMapper mapper = new ObjectMapper();
			Logger.info("MortgageController - saveDashboardIntro(). Request: " + mortgageHelper.hashSensitiveData(mapper.writeValueAsString(request)), this.getClass());
			mobileSession = mbAppHelper.getMobileSession(httpRequest);

			//validateRequestHeader(request.getHeader(), httpRequest);
			//Added to solve the issue of Session sharing among multiple tabs or browsers and multiple applications are trying to update using the same session.
			validateDigitalMortgageRequestHeader(request.getHeader(), httpRequest);
			ErrorResp errorResponse = validate(request, httpRequest);
			if (errorResponse.hasErrors()){
				Logger.error("ERROR in Request while calling saveDashboardIntro() - Invalid Request: "  , this.getClass());
				return errorResponse;
			}
			
			MortgageCommonData mortgageCommonData = mortgageHelper.populateMortgageCommonData(  mobileSession , request.getHeader(),   httpRequest );
			
	   		//Check if application is already submitted
	   		mortgageHelper.checkApplicationSubmitted(mortgageCommonData.getApplicationNumber(), mobileSession);

			mortgageService.saveDashboardIntro(mortgageCommonData);														
			
			SuccessResp successResp = new SuccessResp();																			
			RespHeader headerResp = populateResponseHeader(request.getHeader().getServiceName(), mobileSession);
			successResp.setHeader(headerResp);
			successResp.setIsSuccess(true);
			
			Logger.info("MortgageController - saveDashboardIntro(): Info JSON Response :" + mapper.writeValueAsString(successResp), this.getClass());

			
			return successResp;
		}  
		catch (BusinessException e) {
			Logger.error("BusinessException - saveDashboardIntro():", e, this.getClass());			

			if(e.getKey() == BusinessException.MORTGAGE_SESSION_SHARING_ERROR){
				Logger.error("Session is sharing among multiple tabs or browsers and multiple applications are trying to update using the same session......", this.getClass());									
				return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.MORTGAGE_SESSION_SHARING_ERROR, ServiceConstants.MORTGAGE_SERVICE, httpRequest);
			}
			else{
				return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE, ServiceConstants.MORTGAGE_SERVICE, httpRequest);
			}
		} 
		catch (Exception e) {
			Logger.error("Exception in MortgageController - saveDashboardIntro(): ", e, this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE, ServiceConstants.MORTGAGE_SERVICE, httpRequest);
		} finally {
			endPerformanceLog(logName);
		}
	}
		
	@RequestMapping(method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE, value = "logout")
    @ResponseBody
    public IMBResp logout(HttpServletRequest httpRequest, @RequestBody final EmptyReq request) {
        
        String logName = startPerformanceLog(httpRequest);
        MobileSession mobileSession = null;

        try {
            ObjectMapper mapper = new ObjectMapper();
            Logger.debug("MortgageController - logout(). Request: " + mapper.writeValueAsString(request), this.getClass());

            mobileSession = mbAppHelper.getMobileSession(httpRequest);
            
            mobileSession.invalidateSession();
            
            
            SuccessResp successResp = new SuccessResp();																			
			RespHeader headerResp = populateResponseHeader(request.getHeader().getServiceName(), mobileSession);
			successResp.setHeader(headerResp);
			successResp.setIsSuccess(true);
			
			Logger.info("MortgageController - logout(): Info JSON Response :" + mapper.writeValueAsString(successResp), this.getClass());

			
			return successResp;
        }         
        catch (Exception e) {
            Logger.error("Exception in MortgageController - logout(): ", e, this.getClass());
            return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE, ServiceConstants.MORTGAGE_SERVICE, httpRequest);
        } finally {
            endPerformanceLog(logName);
        }
    }
	
	private String startPerformanceLog(HttpServletRequest httpRequest){
		try{
			MobileSession mobileSession = mbAppHelper.getMobileSession(httpRequest);
			if (mobileSession.getMortgageSessionInfo() != null && mobileSession.getMortgageSessionInfo().getApplicationNumber() != null){
				perfLogger = new PerformanceLogger(true, "ApplicationNum: " + mobileSession.getMortgageSessionInfo().getApplicationNumber());
			} else {
				perfLogger = new PerformanceLogger(true, "");
			}
			
			perfLogger.startAllLogs();
			String logName = MBAppUtils.getLogName(httpRequest);
			perfLogger.startLog(logName);
			return logName;
		}catch (Exception e){
			Logger.error("Performance Logger not starting ", this.getClass());
		}
		return null;
	}
	
	private void endPerformanceLog(String logName){
		perfLogger.endLog(logName);
		perfLogger.endAllLogs();
	}

	public ErrorResp validate(IMBReq serviceRequest, HttpServletRequest request)
	{
		return mbAppValidator.validate(serviceRequest, request);
	}

	public void validateRequestHeader(ReqHeader header, HttpServletRequest request) throws ResourceException
	{
		mbAppValidator.validateRequestHeader(header, request);
	}

	
	public void validateDigitalMortgageRequestHeader(ReqHeader header, HttpServletRequest request) throws ResourceException, BusinessException
	{
		mbAppValidator.validateDigitalMortgageRequestHeader(header, request);
	}
	
	public RespHeader populateResponseHeader(String serviceName, MobileSession mobSession)
	{
		return mbAppHelper.populateResponseHeader(serviceName, mobSession);
	}
	
	
	
	
	private MortgageSubmitResp populateSubmitResponse(MobileSession mobileSession){
		String postSubmitStatus = "SAD";
		if(mobileSession.getMortgageSessionInfo() != null ){
			String outcomeStatus = mobileSession.getMortgageSessionInfo().getOutcomeStatus();
			if(outcomeStatus != null &&
					(outcomeStatus.equalsIgnoreCase(LoanOutcomeEnum.HAPPYPATH1.getValue())
					|| outcomeStatus.equalsIgnoreCase(LoanOutcomeEnum.HAPPYPATH1_WITHPROPERTY.getValue())
					|| outcomeStatus.equalsIgnoreCase(LoanOutcomeEnum.HAPPYPATH2.getValue())
					|| outcomeStatus.equalsIgnoreCase(LoanOutcomeEnum.HAPPYPATH2_WITHPROPERTY.getValue()))){
						postSubmitStatus = "HAPPY";
			}
		}
		
		MortgageSubmitResp successResp = new MortgageSubmitResp();																			
		
		if(postSubmitStatus.equalsIgnoreCase("HAPPY")){
			successResp.setStatus(MortgageUtil.SUCCESS);
		}
		else{
			successResp.setStatus(MortgageUtil.FAIL);
		}
		return successResp;
	}
	@RequestMapping(method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE, value = "propertyInsightGDWEntry")
    @ResponseBody
    public IMBResp propertyInsightGDWEntry(HttpServletRequest httpRequest, @RequestBody final PropertyInsightReq req) {
    	Logger.debug("MortgageController - propertyInsightGDWEntry::", this.getClass());
		String logName = startPerformanceLog(httpRequest);
		MobileSession mobileSession = null;

		try {
			mobileSession = mbAppHelper.getMobileSession(httpRequest);
			//validateRequestHeader(req.getHeader(), httpRequest);
			//Added to solve the issue of Session sharing among multiple tabs or browsers and multiple applications are trying to update using the same session.
			validateDigitalMortgageRequestHeader(req.getHeader(), httpRequest);
			ErrorResp errorResponse = validate(req, httpRequest);
			if (errorResponse.hasErrors()) {
				return errorResponse;
			}
			MortgageCommonData mortgageCommonData = mortgageHelper.populateMortgageCommonData(mobileSession,  req.getHeader(), httpRequest);
			
			if(null!=req.getIdCallSuccess() && null!=req.getDetailCallSuccess()){
				if(req.getIdCallSuccess()){
					if(req.getDetailCallSuccess()){
						mortgageService.logPropertyInsightGDWEntry(mortgageCommonData,"Property ID and Details found",MortgageUtil.GWDStatatisticActionsEnum.PropertyInsightCallSuccess.getValue());
					}else{
						mortgageService.logPropertyInsightGDWEntry(mortgageCommonData,"Partial Success-Property Details Not Found",MortgageUtil.GWDStatatisticActionsEnum.PropertyInsightCallPartialSuccess.getValue());
					}
				}
			}
			
			if(null!=req.getIdCallSuccess() && req.getDetailCallSuccess()==null){
				if(req.getIdCallSuccess()){
					mortgageService.logPropertyInsightGDWEntry(mortgageCommonData,"Partial Success-Property Details Not Found",MortgageUtil.GWDStatatisticActionsEnum.PropertyInsightCallPartialSuccess.getValue());
				}
				else{
					Logger.info("Property Insight Call Failed : PROPINSFAIL", this.getClass());
				}
			}

			SuccessResp successResp = new SuccessResp();
			RespHeader headerResp = populateResponseHeader(ServiceConstants.MORTGAGE_SERVICE, mobileSession);
			successResp.setHeader(headerResp);
			successResp.setIsSuccess(true);			
			return successResp;
		} 
		catch (BusinessException e) {
			Logger.error("BusinessException - propertyInsightGDWEntry():", e, this.getClass());			

			if(e.getKey() == BusinessException.MORTGAGE_SESSION_SHARING_ERROR){
				Logger.error("Session is sharing among multiple tabs or browsers and multiple applications are trying to update using the same session......", this.getClass());									
				return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.MORTGAGE_SESSION_SHARING_ERROR, ServiceConstants.MORTGAGE_SERVICE, httpRequest);
			}
			else{
				return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE, ServiceConstants.MORTGAGE_SERVICE, httpRequest);
			}
		}  
		catch (Exception e) {
			Logger.error("Exception in MortgageController - propertyInsightGDWEntry(): ",e, this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE, ServiceConstants.MORTGAGE_SERVICE, httpRequest);
		} finally {
			endPerformanceLog(logName);
		}
    }
	
	
	@RequestMapping(method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE, value = "saveExistingCustomerApp")
	@ResponseBody
	public IMBResp saveExistingCustomerApp(HttpServletRequest httpRequest, @RequestBody final ApplicationReq request) {
		//Only called for first time save
		String logName = startPerformanceLog(httpRequest);
		MobileSession mobileSession = null;
		ApplicationResp applicationResp = null;

		try {
			ObjectMapper mapper = new ObjectMapper();
			Logger.info("MortgageController - saveExistingCustomerApp(). Request: " + mortgageHelper.hashSensitiveData(mapper.writeValueAsString(request)), this.getClass());
			
			mobileSession = mbAppHelper.getMobileSession(httpRequest);
			
			//Added to solve the issue of Session sharing among multiple tabs or browsers and multiple applications are trying to update using the same session.
			validateDigitalMortgageRequestHeader(request.getHeader(), httpRequest);
			ErrorResp errorResponse = validate(request, httpRequest);
			if (errorResponse.hasErrors()){
				Logger.error("ERROR in Request Params while calling saveExistingCustomerApp() - Invalid Request: "  , this.getClass());
				return errorResponse;
			}
			if(request.getApp() == null){
				Logger.error("MortgageController - saveExistingCustomerApp(). Request: " + request.getApp() , this.getClass());
				throw new BusinessException(BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE);
			}
			ApplicationInfo application = request.getApp();
			
			LoanTypeInfo loanType = application.getLoanType();
			List<ApplicantInfo> applicantsInfo = application.getApplicants();

			if(loanType == null || applicantsInfo.isEmpty() || applicantsInfo.size() == 0){
				Logger.error("MortgageController - saveExistingCustomerApp(). Request: loan type or applicant data is empty. " , this.getClass());
				throw new BusinessException(BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE);
			}
			
			
			
			
			MortgageCommonData mortgageCommonData = mortgageHelper.populateMortgageCommonData(  mobileSession , request.getHeader(),   httpRequest );
			
			//CreditDecision fields validation is false
			//validate
			mortgageHelper.validateAppicationInfo(application, false);
			
			IBankCommonData iBankCommonData = mbAppHelper.populateIBankCommonData(mobileSession,httpRequest);
			
			iBankCommonData.setOrigin(mobileSession.getMortgageSessionInfo().getOrigin());
			iBankCommonData.setUser(new User("gcisNumber", "can","", null, false, true,false));
			
			applicationResp = mortgageHelper.saveExistingCustomerApplication(application, mobileSession, mortgageCommonData, iBankCommonData, request.getHeader());
			
			
			
			Boolean dmNewLoanTermSwitch = IBankParams.getSwitch(IBankParams.DEFAULT_ORIGIN, IBankParams.MORTGAGE_NEW_LOAN_TERM_SWITCH);
			if(null!=dmNewLoanTermSwitch && dmNewLoanTermSwitch==true){
				mobileSession.getMortgageSessionInfo().setIsExistingCustomer(true);
			}
			
			
			
			mortgageService.logStatistics(mortgageCommonData, "New Application", MortgageUtil.GWDStatatisticActionsEnum.NewApplication.getValue());
			
			
			
			RespHeader headerResp = populateResponseHeader(request.getHeader().getServiceName(), mobileSession);
			
			applicationResp.setHeader(headerResp);
			
			Logger.info("MortgageController - saveExistingCustomerApp(): Info JSON Response :" + mortgageHelper.hashSensitiveData(mapper.writeValueAsString(applicationResp)), this.getClass());

			
			return applicationResp;
		}catch (BusinessException e) {
			Logger.error("BusinessException - saveExistingCustomerApp():", e, this.getClass());		
			if(e.getKey()==BusinessException.DIGITAL_MORTGAGE_CLAS_GETCUSTOMER_INELIGIBILE_HARDSTOP) {
				applicationResp = new ApplicationResp();
				applicationResp.setStatus(MortgageUtil.LOGON_INELIGIBLE);
				return applicationResp;
			}
			if(e.getKey()==BusinessException.DIGITAL_MORTGAGE_CLAS_GETCUSTOMER_INELIGIBILE_BANKRUPT_DECEASED) {
				applicationResp = new ApplicationResp();
				applicationResp.setStatus(MortgageUtil.LOGON_INELIGIBLE);
				return applicationResp;
			}
			if(e.getKey() == BusinessException.MORTGAGE_SESSION_SHARING_ERROR){
				Logger.error("Session is sharing among multiple tabs or browsers and multiple applications are trying to update using the same session......", this.getClass());									
				return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.MORTGAGE_SESSION_SHARING_ERROR, ServiceConstants.MORTGAGE_SERVICE, httpRequest);
			}
			if(e.getKey()==BusinessException.MORTGAGE_MAX_APPLICATION_REACHED) {
        		Logger.info("Max application limit for the email has excedded :", e, this.getClass());
        		String tempOrigin = mortgageParams.getBaseOriginCode(mobileSession.getOrigin());
        		LabelValueVO brandPhone = mortgageRefDataHelper.getDMCodesData(tempOrigin, MortgageUtil.REF_DATA_CATEGORY_HELP_DESK, tempOrigin);
        		String[] values = { brandPhone.getLabel() };
        		Logger.info("Brand Contact Number returned from DM origins :" + brandPhone.getLabel(), this.getClass());
        		return MBAppUtils.createErrorResp(mobileSession.getOrigin(), e, values, ServiceConstants.MORTGAGE_SERVICE, httpRequest);
        	}
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), e.getKey(), ServiceConstants.MORTGAGE_SERVICE, httpRequest);
		}  
		catch (Exception e) {
			Logger.error("Exception in MortgageController - saveExistingCustomerApp(): ", e, this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE, ServiceConstants.MORTGAGE_SERVICE, httpRequest);
		} finally {
			endPerformanceLog(logName);
		}
	}
	
	@RequestMapping(method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE, value = "resetSession")
    @ResponseBody
    public IMBResp resetSession(HttpServletRequest httpRequest, HttpServletResponse httpResponse, @RequestBody final EmptyReq request) {
		IMBResp response =  logout(httpRequest, request);
		SuccessResp  successResp = (SuccessResp)response;
		if(successResp.getIsSuccess()){
			response = getSession(httpRequest,httpResponse,request, null);
		}
		return response;
    }
	
	private boolean isDBUpdateRequired( ApplicationInfo app, MobileSession mobSession )
	{
		try
		{
			
			String hashCodeSession = mobSession.getMortgageHashcode();
			String hashCodeReq  = getHashCodeForReq(  app );
			
			
			if (hashCodeReq.equalsIgnoreCase(hashCodeSession) )
			{
				Logger.info("No DB update required" + hashCodeReq , this.getClass());
				return false;
			}

			mobSession.setMortgageHashcode(hashCodeReq);
			Logger.debug("DB update required. hashCodeSession : " + hashCodeSession + " hashCodeReq : "+ hashCodeReq , this.getClass());

			return true ;
		}
		catch (Exception e)
		{
			Logger.error("Error in getHashCodeForReq "  , e,  this.getClass());
			return true;
		}
	}


	@RequestMapping(method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE, value = "splitAddress")
	@ResponseBody
	public IMBResp getSplitAddrees(HttpServletRequest httpRequest, @RequestBody final PropertyInsightReq request) {
		Logger.debug("MortgageController - getSplitAddrees(). Request: " + request, this.getClass());
		String logName = startPerformanceLog(httpRequest);
		MobileSession mobileSession = null;
		MortgageAddress addr=null;
		boolean heartBeatFlag=false;
		String origin = logonHelper.resolveOrigin(httpRequest);

		try {
			ObjectMapper mapper = new ObjectMapper();
			Logger.debug("MortgageController - callPropertyInsight(). Request: " + mapper.writeValueAsString(request), this.getClass());
			mobileSession = mbAppHelper.getMobileSession(httpRequest);

			//validateRequestHeader(request.getHeader(), httpRequest);
			//Added to solve the issue of Session sharing among multiple tabs or browsers and multiple applications are trying to update using the same session.
			validateDigitalMortgageRequestHeader(request.getHeader(), httpRequest);
			ErrorResp errorResponse = validate(request, httpRequest);
			if (errorResponse.hasErrors()){
				return errorResponse;
			}

			// Heart Beat check
			if (!HeartBeat.isApplicationAvailable(HeartBeat.PROPERTY_INSIGHT)) {
				Logger.debug("MortgageController - Inside heartbeat down: ", this.getClass());
				heartBeatFlag=false;
				PropertyInsightResp propertyInsightResp=new PropertyInsightResp();
				RespHeader headerResp = populateResponseHeader(ServiceConstants.MORTGAGE_SERVICE, mobileSession);				
				propertyInsightResp.setHeader(headerResp);
				propertyInsightResp.setPropertyInsightUp(heartBeatFlag);
                propertyInsightResp.setSuccess(false);		
				return propertyInsightResp;
			}
			else{
				Logger.debug("MortgageController - Inside heartbeat up: ", this.getClass());
				heartBeatFlag=true;
			}
			Logger.debug("MortgageController - Continuing for heartbeat up: ", this.getClass());
			//validate
			mortgageHelper.validatePropertyInsightReq(request);
			
			//iBankCommonData is needed to retrieve QAS address using ESB SRV524
			IBankCommonData iBankCommonData = mbAppHelper.populateIBankCommonData(mobileSession,httpRequest);
			iBankCommonData.setOrigin(origin);
			iBankCommonData.setUser(new User("gcisNumber", "can","", null, false, true,false));

			//Check if application is already submitted
			if(mobileSession.getMortgageSessionInfo() != null) {
		   		mortgageHelper.checkApplicationSubmitted(mobileSession.getMortgageSessionInfo().getApplicationNumber(), mobileSession);
			}	   		
			if(heartBeatFlag && !request.getManualAddress()){
				 
				 AddressInfo addressInfo = new AddressInfo();
				 addressInfo.setQasAddressId(request.getQasAddressID());
				 addressInfo.setAddrType(AddressType.D.toString());
				 
				 addr= mortgageHelper.storeQASAddressInSession( addressInfo,  iBankCommonData,  mobileSession,  perfLogger,  AddressType.D.toString());

					if ( addr == null )
					{
						throw new BusinessException ( BusinessException.SYSTEM_UNAVILABLE,  "Split address failed " );
					}
				 
			}
			PropertyInsightResp propertyInsightResp=new PropertyInsightResp();
			propertyInsightResp=mortgageHelper.populatePropertyInsightResp(addr,heartBeatFlag);											
			
			
			RespHeader headerResp = populateResponseHeader(ServiceConstants.MORTGAGE_SERVICE, mobileSession);
			propertyInsightResp.setHeader(headerResp);
			propertyInsightResp.setSuccess(true);
			Logger.debug("MortgageController - retrieveApplication() JSON Response :" + mapper.writeValueAsString(propertyInsightResp), this.getClass());			
			return propertyInsightResp;
			
		} 
		catch (BusinessException e) {
			Logger.error("BusinessException - callPropertyInsight():", e, this.getClass());			

			if(e.getKey() == BusinessException.MORTGAGE_SESSION_SHARING_ERROR){
				Logger.error("Session is sharing among multiple tabs or browsers and multiple applications are trying to update using the same session......", this.getClass());									
				return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.MORTGAGE_SESSION_SHARING_ERROR, ServiceConstants.MORTGAGE_SERVICE, httpRequest);
			}
			else{
				return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE, ServiceConstants.MORTGAGE_SERVICE, httpRequest);
			}
		}  
		catch (Exception e) {
			Logger.error("Exception in MortgageController - saveApplication(): ", e, this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE, ServiceConstants.MORTGAGE_SERVICE, httpRequest);
		} finally {
			endPerformanceLog(logName);
		}
	}
	
	@RequestMapping(method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE, value = "updatePID")
	@ResponseBody
	public IMBResp updatePID(HttpServletRequest httpRequest, @RequestBody final UpdatePIDReq request) {
		Logger.debug("MortgageController - updatePID(). Request: " + request, this.getClass());
		String logName = startPerformanceLog(httpRequest);
		MobileSession mobileSession = null;
		MortgageAddress addr=null;
		boolean heartBeatFlag=false;
		String origin = logonHelper.resolveOrigin(httpRequest);

		try {
			ObjectMapper mapper = new ObjectMapper();
			Logger.debug("MortgageController - updatePID(). Request: " + mapper.writeValueAsString(request), this.getClass());
			mobileSession = mbAppHelper.getMobileSession(httpRequest);

			//validateRequestHeader(request.getHeader(), httpRequest);
			//Added to solve the issue of Session sharing among multiple tabs or browsers and multiple applications are trying to update using the same session.
			validateDigitalMortgageRequestHeader(request.getHeader(), httpRequest);
			ErrorResp errorResponse = validate(request, httpRequest);
			if (errorResponse.hasErrors()){
				return errorResponse;
			}
			
			// Heart Beat check
			if (!HeartBeat.isApplicationAvailable(HeartBeat.PROPERTY_INSIGHT)) {
				Logger.debug("MortgageController - Inside heartbeat down: ", this.getClass());
				heartBeatFlag=false;
				SuccessResp successResp = new SuccessResp();																			
				RespHeader headerResp = populateResponseHeader(request.getHeader().getServiceName(), mobileSession);
				successResp.setHeader(headerResp);
				successResp.setIsSuccess(false);
			}
			else{
				Logger.debug("MortgageController - Inside heartbeat up: ", this.getClass());
				heartBeatFlag=true;
			}
			Logger.debug("MortgageController - Continuing for heartbeat up: ", this.getClass());
			
			//validate
			
			Application applicationCLAS = mobileSession.getMortgageSessionInfo().getApplication();
			
			MortgageCommonData mortgageCommonData = mortgageHelper.populateMortgageCommonData(  mobileSession , request.getHeader(),   httpRequest );
			IBankCommonData iBankCommonData = mbAppHelper.populateIBankCommonData(mobileSession,httpRequest);
			iBankCommonData.setOrigin(origin);
			iBankCommonData.setUser(new User("gcisNumber", "can","", null, false, true,false));

			List<Asset> clasAssetList = applicationCLAS.getAssets();
			if(!StringMethods.isInt(request.getClasAssetId())){
				Logger.error("ClasAssetId Index must be integer - mergeCLASAssetInfoForSave ", this.getClass());
				throw new BusinessException(BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE); 
			}
			int assetIndex = Integer.valueOf(request.getClasAssetId());
			if(clasAssetList == null || clasAssetList.size() < assetIndex + 1){
				Logger.error("asset not found for clasAssetIndex - mergeCLASAssetInfoForSave ", this.getClass());
				throw new BusinessException(BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE);  
			}

			if(heartBeatFlag){
				//Approach 2 (by getting application from session, which has all the db id's)
				
				if(mobileSession.getHomeLoanApplication() != null){
					Application sessionHomeLoanApplication = mobileSession.getHomeLoanApplication();
					
					MortgageAddress address = mortgageHelper.getAddressToUpdatePID(sessionHomeLoanApplication, assetIndex);
					
					if(StringMethods.isEmptyString(address.getStdAddrId())){
						addr=mortgageService.getPropertyInsightAddress(request.getQasAddressID(), iBankCommonData,perfLogger, AddressType.D.toString());
						
						if ( addr == null )
						{
							throw new BusinessException ( BusinessException.SYSTEM_UNAVILABLE,  "Split address failed " );
						}
						mortgageService.updateAddressWithPID(address, addr.getStdAddrId());
						mortgageHelper.updateSessionApplicationWithPID(sessionHomeLoanApplication, assetIndex, addr.getStdAddrId());
						
					}
					
				}
				
				
			}
			SuccessResp successResp = new SuccessResp();																			
			RespHeader headerResp = populateResponseHeader(request.getHeader().getServiceName(), mobileSession);
			successResp.setHeader(headerResp);
			successResp.setIsSuccess(true);
			Logger.debug("MortgageController - updatePID() JSON Response :" + mapper.writeValueAsString(successResp), this.getClass());			
			return successResp;
			
		} 
		catch (BusinessException e) {
			Logger.error("BusinessException - updatePID():", e, this.getClass());			

			if(e.getKey() == BusinessException.MORTGAGE_SESSION_SHARING_ERROR){
				Logger.error("Session is sharing among multiple tabs or browsers and multiple applications are trying to update using the same session......", this.getClass());									
				return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.MORTGAGE_SESSION_SHARING_ERROR, ServiceConstants.MORTGAGE_SERVICE, httpRequest);
			}
			else{
				return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE, ServiceConstants.MORTGAGE_SERVICE, httpRequest);
			}
		}  
		catch (Exception e) {
			Logger.error("Exception in MortgageController - updatePID(): ", e, this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE, ServiceConstants.MORTGAGE_SERVICE, httpRequest);
		} finally {
			endPerformanceLog(logName);
		}
	}
	
	@RequestMapping(method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE, value = "retrieveExisting")
	@ResponseBody
	public IMBResp retrieveApplicationViaGhostTile(HttpServletRequest httpRequest, HttpServletResponse httpResponse,  @RequestBody final EmptyReq request) {
		Logger.debug("MortgageController - retrieveApplicationViaGhostTile(). Request: " + request, this.getClass());		
		String logName = startPerformanceLog(httpRequest);
		MobileSession mobileSession = null;	  
	String origin = logonHelper.resolveOrigin(httpRequest);	
		ApplicationListResp applicationResp = null;
		try {	
			mobileSession = mbAppHelper.getMobileSession(httpRequest);
            MortgageSessionInfo mortgageSessionInfo = mobileSession.getMortgageSessionInfo();
			
			MortgageCommonData mortgageCommonData =  mortgageHelper.populateMortgageCommonData(mobileSession, request.getHeader(), httpRequest);		
			String gcisNumber = mortgageSessionInfo.getApplication().getApplicants().get(0).getGcisNum(); 
			
			//Added below code to get the list of applications from 484 service
			List<Application> applications = null;
			applications = mortgageService.getCLASLoanDetailsForGhostTile(gcisNumber);
			
			List<Application> appList = mortgageService.getLoanDetailsForGhostTile(gcisNumber);	
			
			if(applications != null && !applications.isEmpty() && applications.size() > 0){
				if(appList == null){
					appList= new ArrayList<Application>();
				}
				appList.addAll(0, applications);
			}

			List<ApplicationInfo> appInfoList = null;
			if(appList.size() > 1 ){	
				mortgageService.checkMortgageETBRetrivalSwitch(mortgageCommonData.getOrigin(), null);
				applicationResp  = (ApplicationListResp)retrieveApplication(appList, mobileSession, mortgageCommonData);
			}
			else{						
				ApplicationInfo applicationInfo = null;
				//Single application Retrieve 
				IBankCommonData iBankCommonData = mbAppHelper.populateIBankCommonData(mobileSession,httpRequest);

				//For 484 returned applications, no need to get the data from DMApplication table. So, based on status in session, sending the status to UI.
				if(appList.get(0) != null && appList.get(0).getApplicationStatus().equalsIgnoreCase(MortgageUtil.DOC_UPLOAD)){
					mortgageService.checkDocUploadSwitch(mortgageCommonData.getOrigin());
					
					boolean isDocUploadAllowed = mortgageHelper.isDocUploadAllowed(httpRequest);
					if(!isDocUploadAllowed){
   					 	throw new BusinessException(BusinessException.DIGITAL_MORTGAGE_DOC_UPLOAD_NOT_ALLOWED, "Doc Upload Not Allowed");
   				 	}
					
					applicationInfo = new ApplicationInfo();
					applicationInfo.setStatus(CLASApplicationStatusEnum.DOC_UPLOAD.getStatus());
					mortgageSessionInfo.setApplicationNumber(appList.get(0).getApplicationNum());
					mortgageCommonData.setApplicationNumber(appList.get(0).getApplicationNum());	
					
					//Call service and get lender details and populate resp..
					if (appList.get(0).getLenderId() != null /*&& mortgageLenderService.isMortgageLenderInitiatedSwtichON(mobileSession.getOrigin())*/) {
						Lender lender = mortgageLenderService.getLenderDetails(appList.get(0).getLenderId(), mobileSession.getOrigin());
						if(lender != null){
							applicationInfo.setLender(mortgageHelper.populateLenderInfo(lender));
						}
					}
					
				}
				else{
					Application application = appList.get(0);

					Boolean dmApraSwitch= IBankParams.getSwitch(origin, IBankParams.DM_APRA_SWITCH);
					if(dmApraSwitch!=null && dmApraSwitch){
						boolean isInflightApp = mortgageService.checkInflightAppAndUpdteAssetExpenseInd(application , mortgageCommonData.getOrigin());
						
						if ( isInflightApp ){
							application.setInflightApplication(isInflightApp);
						}
					}
					applicationInfo = retrieveApplicationByNumber(application.getApplicationNum(), mortgageSessionInfo, mortgageCommonData, iBankCommonData, mobileSession, request.getHeader());	
					
					//Retrieve application and do the val order, if any missing based on Application status like Inprogress..and etc..not for Submiited..status
					//For all retrievals..
					
					String applicationStatus = appList.get(0).getApplicationStatus();
					if(MortgageUtil.ApplicationStatusEnum.NEW.getStatus().equalsIgnoreCase(applicationStatus)  
						    || MortgageUtil.ApplicationStatusEnum.IN_PROGRESS.getStatus().equalsIgnoreCase(applicationStatus) 
						    || MortgageUtil.ApplicationStatusEnum.ASSESS.getStatus().equalsIgnoreCase(applicationStatus)){
			        	
			        	//request for valorder
						Boolean valOrderSwitch = IBankParams.getSwitch(mortgageCommonData.getOrigin(), IBankParams.MORTGAGE_VAL_ORDER_SWITCH);
						if(valOrderSwitch){
							Logger.info( "ValOrderSwitch is On ", this.getClass() );
							if(mobileSession.getDMEvalRequestedList() == null){
								List valOrderList = new ArrayList<String>();
								mobileSession.setDMEvalRequestedList(valOrderList);
							}
							HashMap mapProperties = mortgageHelper.getModifiedListOfProperty(mobileSession.getHomeLoanApplication());
							Application valOrderApp = mortgageService.requestValOrderProperty( mobileSession.getHomeLoanApplication(), mortgageCommonData, mapProperties, mapProperties, mobileSession.getDMEvalRequestedList()); 
							mobileSession.setHomeLoanApplication(valOrderApp);
							//Logger.debug("***********END MortgageController - mortgageService.requestValOrdeProperty()" , this.getClass());
						}
					}
					

					
					//check for inflight applications
					applicationInfo.setInflightApp(new Boolean(appList.get(0).isInflightApplication()));
				}
				
				appInfoList = new ArrayList<ApplicationInfo>();
				appInfoList.add(applicationInfo);
				applicationResp = new ApplicationListResp();
				applicationResp.setAppList(appInfoList);	
			}
			RespHeader headerResp = populateResponseHeader(ServiceConstants.MORTGAGE_SERVICE, mobileSession);
			applicationResp.setHeader(headerResp);		
			applicationResp.setSuccess(true);
			
			ObjectMapper mapper = new ObjectMapper();
			Logger.info("MortgageController - retrieveApplicationViaGhostTile() JSON Response :" + mortgageHelper.hashSensitiveData(mapper.writeValueAsString(applicationResp)), this.getClass());
  			return applicationResp;
			
		} catch (BusinessException e) {
			Logger.error("Exception in MortgageController - retrieveApplicationViaGhostTile(): ", e, this.getClass());
			if(e.getKey()==BusinessException.DIGITAL_MORTGAGE_CLAS_GETCUSTOMER_INELIGIBILE_BANKRUPT_DECEASED) {
				applicationResp = new ApplicationListResp();
				applicationResp.setStatus(MortgageUtil.LOGON_INELIGIBLE);
				return applicationResp;
			}else if(e.getKey()==BusinessException.DIGITAL_MORTGAGE_DOC_UPLOAD_NOT_ALLOWED) {
				String originCode = mortgageParams.getBaseOriginCode(mobileSession.getOrigin());
				OriginsVO originVO  = IBankParams.getOrigin(originCode);
				return MBAppUtils.createErrorResp(originCode, e, new String[]{originVO.getName()}, ServiceConstants.MORTGAGE_SERVICE, httpRequest);
			}
			else{
		    	return MBAppUtils.createErrorResp(origin, e, ServiceConstants.MORTGAGE_SERVICE, httpRequest);	
			}
		}  catch (Exception e) {
			Logger.error("Exception in MortgageController - retrieveApplicationViaGhostTile(): ", e, this.getClass());
			return MBAppUtils.createErrorResp(origin, BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE, ServiceConstants.MORTGAGE_SERVICE, httpRequest);
		} finally {
			endPerformanceLog(logName);
		}
	}		
	
	private ApplicationInfo retrieveApplicationByNumber(Long applicationNum, MortgageSessionInfo mortgageSessionInfo, MortgageCommonData mortgageCommonData, IBankCommonData iBankCommonData, MobileSession mobileSession, ReqHeader reqHeader) throws BusinessException{
		Application application = null;
		if(applicationNum != null){
			application = mortgageService.getApplication(applicationNum);

			if(application.getLockedInd() != null && application.getLockedInd().equals(MortgageUtil.LOCK_APP_INDICATOR)){
				throw new BusinessException(BusinessException.DIGITAL_MORTGAGE_APPLICATION_LOCKED);
			}
			mortgageSessionInfo.setApplicationNumber(applicationNum);
			mortgageCommonData.setApplicationNumber(applicationNum);			
		}else{
			Logger.info("Application Num is null unable to retrieve application : ", this.getClass());
			throw new BusinessException(BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE);
		}
		
		mortgageService.checkMortgageETBRetrivalSwitch(mortgageCommonData.getOrigin(), application);
		
		mortgageService.checkRefinanceRetrivalSwitch(mortgageCommonData.getOrigin(), application);
		
		//Update Session Application object for subsequent save
		mobileSession.setHomeLoanApplication((Application)SerializationUtils.clone(application));
		
		List<Applicant> applicants = application.getApplicants();	
		
		//If primary applicant in Ext then merge data from class	
		Application applicationCLAS = mortgageService.getCustomerCLASInfo(applicants, mortgageCommonData);  
		mortgageSessionInfo.setApplication(applicationCLAS);
		boolean hasChanged = mortgageService.mapCLASInfoForSave(application, applicationCLAS);
		
	    if(IBankParams.isSwitchOn(mortgageCommonData.getOrigin(), IBankParams.MORTGAGE_CREDIT_DECISONING_SWITCH)){
	    	mortgageService.getForeignTaxInfo(application, iBankCommonData);
	    }
		
		if(hasChanged){
			Application applicationForSave = (Application)SerializationUtils.clone(application);
			mortgageHelper.saveApplication(applicationForSave, mobileSession.getHomeLoanApplication(), mortgageCommonData, iBankCommonData, mobileSession, reqHeader);
		}
		mortgageService.updateBrand(applicationNum, mortgageCommonData.getOrigin()); //TODO VB
		
		mortgageService.mergeCLASInfoForRetrieve(application, applicationCLAS, mortgageParams.getBaseOriginCode(mortgageCommonData.getOrigin()), false);
			
		return mortgageHelper.populateApplicationInfo(application);
	}
	
	@RequestMapping(method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE, value = "retrieveSelectedApp")
	@ResponseBody
	public IMBResp retrieveSelectedApplication(HttpServletRequest httpRequest, HttpServletResponse httpResponse,  @RequestBody final ApplicationReq request) {
		Logger.debug("MortgageController - retrieveSelectedApplication(). Request: " + request, this.getClass());		
		String logName = startPerformanceLog(httpRequest);
		MobileSession mobileSession = null;	  
		String origin = logonHelper.resolveOrigin(httpRequest);	
		ApplicationResp applicationResp = new ApplicationResp();
		try {	
			mobileSession = mbAppHelper.getMobileSession(httpRequest);
            MortgageSessionInfo mortgageSessionInfo = mobileSession.getMortgageSessionInfo();
			
			MortgageCommonData mortgageCommonData =  mortgageHelper.populateMortgageCommonData(mobileSession, request.getHeader(), httpRequest);
			
			List<Application> applicationList = mobileSession.getMortgageApplicationList();
			
			if(applicationList == null || applicationList.isEmpty() || request.getApp() == null || applicationList.size() <= request.getApp().getIndex()){
				Logger.error("MortgageController - retrieveSelectedApplication(), invalid request", this.getClass());
				throw new BusinessException(BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE);
			}
			
			Application tileApp = applicationList.get(request.getApp().getIndex());
			
			ApplicationInfo applicationInfo = null;
			//Single application Retrieve 
			IBankCommonData iBankCommonData = mbAppHelper.populateIBankCommonData(mobileSession,httpRequest);

			//For 484 returned applications, no need to get the data from DMApplication table. So, based on status in session, sending the status to UI.
			if(tileApp != null && tileApp.getApplicationStatus().equalsIgnoreCase(MortgageUtil.DOC_UPLOAD)){
				mortgageService.checkDocUploadSwitch(mortgageCommonData.getOrigin());
				boolean isDocUploadAllowed = mortgageHelper.isDocUploadAllowed(httpRequest);
				if(!isDocUploadAllowed){
					 	throw new BusinessException(BusinessException.DIGITAL_MORTGAGE_DOC_UPLOAD_NOT_ALLOWED, "Doc Upload Not Allowed");
				 }
				applicationInfo = new ApplicationInfo();
				applicationInfo.setStatus(CLASApplicationStatusEnum.DOC_UPLOAD.getStatus());
				mortgageSessionInfo.setApplicationNumber(tileApp.getApplicationNum());
				mortgageCommonData.setApplicationNumber(tileApp.getApplicationNum());	
				
				//Call service and get lender details and populate resp..
				if (tileApp.getLenderId() != null /*&& isMortgageLenderInitiatedSwtichON(mobileSession.getOrigin())*/) {
					Lender lender = mortgageLenderService.getLenderDetails(tileApp.getLenderId(), mobileSession.getOrigin());
					if(lender != null){
						applicationInfo.setLender(mortgageHelper.populateLenderInfo(lender));
					}
				}
			}
			else{
				Boolean dmApraSwitch= IBankParams.getSwitch(origin, IBankParams.DM_APRA_SWITCH);
				if(dmApraSwitch!=null && dmApraSwitch){
					boolean isInflightApp = mortgageService.checkInflightAppAndUpdteAssetExpenseInd(tileApp, mortgageCommonData.getOrigin());
					
					if ( isInflightApp )
						tileApp.setInflightApplication(isInflightApp);
				}
				
				applicationInfo = retrieveApplicationByNumber(tileApp.getApplicationNum(), mortgageSessionInfo, mortgageCommonData, iBankCommonData, mobileSession, request.getHeader());

				//Retrieve application and do the val order, if any missing based on Application status like Inprogress..and etc..not for Submiited..status
				//For all retrievals..
				
				
				String applicationStatus = tileApp.getApplicationStatus();
				if(MortgageUtil.ApplicationStatusEnum.NEW.getStatus().equalsIgnoreCase(applicationStatus)  
					    || MortgageUtil.ApplicationStatusEnum.IN_PROGRESS.getStatus().equalsIgnoreCase(applicationStatus) 
					    || MortgageUtil.ApplicationStatusEnum.ASSESS.getStatus().equalsIgnoreCase(applicationStatus)){
		        	
		        	//request for valorder
					Boolean valOrderSwitch = IBankParams.getSwitch(mortgageCommonData.getOrigin(), IBankParams.MORTGAGE_VAL_ORDER_SWITCH);
					if(valOrderSwitch){
						Logger.info( "ValOrderSwitch is On ", this.getClass() );
						if(mobileSession.getDMEvalRequestedList() == null){
							List valOrderList = new ArrayList<String>();
							mobileSession.setDMEvalRequestedList(valOrderList);
						}
						HashMap mapProperties = mortgageHelper.getModifiedListOfProperty(mobileSession.getHomeLoanApplication());
						Application valOrderApp = mortgageService.requestValOrderProperty( mobileSession.getHomeLoanApplication(), mortgageCommonData, mapProperties, mapProperties, mobileSession.getDMEvalRequestedList()); 
						mobileSession.setHomeLoanApplication(valOrderApp);

						//Logger.debug("***********END MortgageController - mortgageService.requestValOrdeProperty()" , this.getClass());
					}
				}
				

				//check for inflight applications
				applicationInfo.setInflightApp(new Boolean(tileApp.isInflightApplication()));
			}
			
			applicationResp.setApp(applicationInfo);
			
			RespHeader headerResp = populateResponseHeader(ServiceConstants.MORTGAGE_SERVICE, mobileSession);
			applicationResp.setHeader(headerResp);

			applicationResp.setSuccess(true);
			
			ObjectMapper mapper = new ObjectMapper();
			Logger.info("MortgageController - retrieveSelectedApplication() JSON Response :" + mortgageHelper.hashSensitiveData(mapper.writeValueAsString(applicationResp)), this.getClass());
			return applicationResp;
			
		} catch (BusinessException e) {
			Logger.error("Exception in MortgageController - retrieveSelectedApplication(): ", e, this.getClass());		
			if(BusinessException.DIGITAL_MORTGAGE_APPLICATION_LOCKED == e.getKey()){
				String originHelpDeskPhone=mortgageHelper.getHelpDeskContactNumber(origin);
        		String[] value={originHelpDeskPhone};
				return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.DIGITAL_MORTGAGE_APPLICATION_LOCKED, MBAppUtils.getMessage(mobileSession.getOrigin(), BusinessException.DIGITAL_MORTGAGE_APPLICATION_LOCKED, value), ServiceConstants.MORTGAGE_SERVICE, httpRequest);         
			}else if(e.getKey()==BusinessException.DIGITAL_MORTGAGE_DOC_UPLOAD_NOT_ALLOWED) {
				String originCode = mortgageParams.getBaseOriginCode(mobileSession.getOrigin());
				OriginsVO originVO  = IBankParams.getOrigin(originCode);
				return MBAppUtils.createErrorResp(originCode, e, new String[]{originVO.getName()}, ServiceConstants.MORTGAGE_SERVICE, httpRequest);
			}
			return mortgageHelper.createErrorResp(origin, e, ServiceConstants.MORTGAGE_SERVICE, httpRequest);
		}  catch (Exception e) {
			Logger.error("Exception in MortgageController - retrieveSelectedApplication(): ", e, this.getClass());
			return MBAppUtils.createErrorResp(origin, BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE, ServiceConstants.MORTGAGE_SERVICE, httpRequest);
		} finally {
			endPerformanceLog(logName);
		}
	}	
	
	@RequestMapping(method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE, value = "getApplicant")
	@ResponseBody
	public IMBResp getApplicant(HttpServletRequest httpRequest, HttpServletResponse httpResponse,  @RequestBody final EmptyReq request) {
		Logger.debug("MortgageController - getApplicant(). Request: " + request, this.getClass());		
		String logName = startPerformanceLog(httpRequest);
		MobileSession mobileSession = null;	  
		String origin = logonHelper.resolveOrigin(httpRequest);	
		try {	
			mobileSession = mbAppHelper.getMobileSession(httpRequest);
            MortgageSessionInfo mortgageSessionInfo = mobileSession.getMortgageSessionInfo();
			
			String gcisNumber = mortgageSessionInfo.getApplication().getApplicants().get(0).getGcisNum(); 
			
			Customer customer = CustomerService.getGHSCustomerWithoutAccountList(gcisNumber, origin, SOURCE_ID);
			mortgageSessionInfo.getApplication().getApplicants().get(0).setGhscisNumber(customer.getGHSCISNumber());
			PersonalDetailResp personalDetailResp = new PersonalDetailResp();
			personalDetailResp.setFirstName(customer.getFirstName());
			personalDetailResp.setSurName(customer.getLastName());
			
			RespHeader headerResp = populateResponseHeader(ServiceConstants.MORTGAGE_SERVICE, mobileSession);
			personalDetailResp.setHeader(headerResp);		
			personalDetailResp.setSuccess(true);
			
			//Start : SBGEXP-5664: DM Simplified logon for lender
			String lenderId = null;
			lenderId = mobileSession.getDMLenderId();
			Logger.info("In session, The value for lenderId is  " + lenderId,this.getClass());
			
			if(!StringMethods.isEmptyString(lenderId) && StringUtil.isValidAlphaNumeric(lenderId) ){
				try
				{
					//Call service and get lender details and populate resp..
					Lender lender = mortgageLenderService.getLenderDetails(lenderId, mortgageParams.getBaseOriginCode((String)mobileSession.getOrigin()));
					if(lender != null){
						personalDetailResp.setLender(mortgageHelper.populateLenderInfo(lender));
						
					}
				}
				catch (Exception e)
				{
					Logger.error("Error in getting lender details "  , e,  this.getClass());
					
				}
				
			}
			//End : SBGEXP-5664: DM Simplified logon for lender

			
			ObjectMapper mapper = new ObjectMapper();
			Logger.info("MortgageController - getApplicant() JSON Response :" + mortgageHelper.hashSensitiveData(mapper.writeValueAsString(personalDetailResp)), this.getClass());
			return personalDetailResp;
			
		} catch (BusinessException e) {
			Logger.error("Exception in MortgageController - getApplicant(): ", e, this.getClass());
			return MBAppUtils.createErrorResp(origin, BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE, ServiceConstants.MORTGAGE_SERVICE, httpRequest);	
		}  catch (Exception e) {
			Logger.error("Exception in MortgageController - getApplicant(): ", e, this.getClass());
			return MBAppUtils.createErrorResp(origin, BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE, ServiceConstants.MORTGAGE_SERVICE, httpRequest);
		} finally {
			endPerformanceLog(logName);
		}
	}
	
	@RequestMapping(method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE, value = "valAssess")
	@ResponseBody
	public IMBResp valAssess(HttpServletRequest httpRequest, @RequestBody final EmptyReq request) {
		String logName = startPerformanceLog(httpRequest);
		MobileSession mobileSession = null;
		try {
			ObjectMapper mapper = new ObjectMapper();
			Logger.info("MortgageController - valAssess(). Request: " + mortgageHelper.hashSensitiveData(mapper.writeValueAsString(request)), this.getClass());
			mobileSession = mbAppHelper.getMobileSession(httpRequest);

			//validateRequestHeader(request.getHeader(), httpRequest);
			//Added to solve the issue of Session sharing among multiple tabs or browsers and multiple applications are trying to update using the same session.
			validateDigitalMortgageRequestHeader(request.getHeader(), httpRequest);
			ErrorResp errorResponse = validate(request, httpRequest);
			if (errorResponse.hasErrors()){
				return errorResponse;
			}

			MortgageCommonData mortgageCommonData = mortgageHelper.populateMortgageCommonData(mobileSession,  request.getHeader(), httpRequest);
			
			String valAssessStatus = null;
			
			RespHeader headerResp = populateResponseHeader(ServiceConstants.MORTGAGE_SERVICE, mobileSession);
			ValAssessResp valAssessResp = new ValAssessResp();
			MortgageSessionInfo mortgageSessionInfo = mobileSession.getMortgageSessionInfo();
			List<LoanOutcome> loanOutcomes = mobileSession.getLoanOutcomes();
			if(loanOutcomes != null && !loanOutcomes.isEmpty()){
				
				if(mortgageService.checkValAssessEligibility(loanOutcomes, mobileSession.getHomeLoanApplication())){
					valAssessStatus = mortgageService.valAssess(mobileSession.getMortgageSessionInfo().getApplicationNumber(), mortgageCommonData,
							mortgageSessionInfo.getApplication(), 
							mobileSession.getValAssessPostReqStr(),null);
					
					valAssessResp.setValutionStatus(valAssessStatus);
				}
				else{
					valAssessStatus = ValAssessEnum.SUBJECT_TO_VALUATION.getValue();
					loanOutcomes.get(0).setValuationStatus(valAssessStatus);
					mortgageService.saveLoanOutcome(mobileSession.getMortgageSessionInfo().getApplicationNumber(), loanOutcomes.get(0));
					valAssessResp.setValutionStatus(valAssessStatus);
				}
			}
			
			
			valAssessResp.setHeader(headerResp);
        	
			Logger.debug("MortgageController - valAssess() JSON Response :" + mortgageHelper.hashSensitiveData(mapper.writeValueAsString(valAssessResp)), this.getClass());

			return valAssessResp;
		}  
		catch (Exception e) {
			Logger.error("Exception in MortgageController - valAssess(): ", e, this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.DIGITAL_MORTGAGE_CLAS_SVC_UNAVAILABLE, ServiceConstants.MORTGAGE_SERVICE, httpRequest);
		} 
		finally {
			endPerformanceLog(logName);
		}
	}
	
	@RequestMapping(method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE, value = "retrieveDocUploadDetails")
	@ResponseBody
	public IMBResp retrieveDocUploadDetails(HttpServletRequest httpRequest, HttpServletResponse httpResponse,  @RequestBody final EmptyReq request) {
		Logger.debug("MortgageController - retrieveDocUploadDetails(). Request: " + request, this.getClass());		
		String logName = startPerformanceLog(httpRequest);
		MobileSession mobileSession = null;	  
		String origin = logonHelper.resolveOrigin(httpRequest);	
		try {	

			boolean isDocUploadAllowed = mortgageHelper.isDocUploadAllowed(httpRequest);
			if(!isDocUploadAllowed){
				 	throw new BusinessException(BusinessException.DIGITAL_MORTGAGE_DOC_UPLOAD_NOT_ALLOWED, "Doc Upload Not Allowed");
			 }
			
			mobileSession = mbAppHelper.getMobileSession(httpRequest);
            MortgageSessionInfo mortgageSessionInfo = mobileSession.getMortgageSessionInfo();
            
            Application application = mortgageService.getApplication(mortgageSessionInfo.getApplicationNumber());
			List<DocCategoryDetail> docCategoryDetails = mortgageService.retrieveDocUploadDetails(mortgageSessionInfo.getApplicationNumber());
			
			if(docCategoryDetails == null || docCategoryDetails.isEmpty()){
				mortgageService.generateDocumentToUpload(application);
				docCategoryDetails = mortgageService.retrieveDocUploadDetails(mortgageSessionInfo.getApplicationNumber());
			}
			
			List<Long> docAppMapIdList = getDocAppMapIdList(docCategoryDetails);
			mortgageSessionInfo.setDocAppMapIdList(docAppMapIdList);
			
			DocUploadDetailInfo docUploadDetails = mortgageHelper.populateDocUploadDetailInfo(docCategoryDetails, application);
//			Populate numberOfDocumentsUploaded
			mortgageHelper.populateNumberOfDocumentsUploaded(mortgageSessionInfo, docCategoryDetails);
			
			DocUploadDetailResp docUploadDetailResp = new DocUploadDetailResp();
			docUploadDetailResp.setDocUploadDetails(docUploadDetails);			
			
			RespHeader headerResp = populateResponseHeader(ServiceConstants.MORTGAGE_SERVICE, mobileSession);
			docUploadDetailResp.setHeader(headerResp);		
			docUploadDetailResp.setSuccess(true);
			
			ObjectMapper mapper = new ObjectMapper();
			Logger.info("MortgageController - retrieveDocUploadDetails() JSON Response :" + mortgageHelper.hashSensitiveData(mapper.writeValueAsString(docUploadDetailResp)), this.getClass());
			return docUploadDetailResp;
			
		} catch (BusinessException e) {
			if(e.getKey()==BusinessException.DIGITAL_MORTGAGE_DOC_UPLOAD_NOT_ALLOWED) {
				String originCode = mortgageParams.getBaseOriginCode(mobileSession.getOrigin());
				OriginsVO originVO  = IBankParams.getOrigin(originCode);
				return MBAppUtils.createErrorResp(originCode, e, new String[]{originVO.getName()}, ServiceConstants.MORTGAGE_SERVICE, httpRequest);
			}
			Logger.error("Exception in MortgageController - retrieveDocUploadDetails(): ", e, this.getClass());
			return MBAppUtils.createErrorResp(origin, BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE, ServiceConstants.MORTGAGE_SERVICE, httpRequest);	
		}  catch (Exception e) {
			Logger.error("Exception in MortgageController - retrieveDocUploadDetails(): ", e, this.getClass());
			return MBAppUtils.createErrorResp(origin, BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE, ServiceConstants.MORTGAGE_SERVICE, httpRequest);
		} finally {
			endPerformanceLog(logName);
		}
	}
	
	private List<Long> getDocAppMapIdList(List<DocCategoryDetail> docCategoryDetails){
		List<Long> docAppMapIdList = new ArrayList<Long>();
		for(DocCategoryDetail categoryDetail:docCategoryDetails){
			if(categoryDetail.getDocTypeDetails() != null){
				for(DocTypeDetail docTypeDetail:categoryDetail.getDocTypeDetails()){
					if(docTypeDetail.getDocAppMapId() != null){
						docAppMapIdList.add(docTypeDetail.getDocAppMapId());
					}
				}
			}
		}
		return docAppMapIdList;
	}
	
	@RequestMapping(method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE, value = "saveDocUploadIntro")
	@ResponseBody
	public IMBResp saveDocUploadIntro(HttpServletRequest httpRequest, @RequestBody final EmptyReq request) {
		
		String logName = startPerformanceLog(httpRequest);
		MobileSession mobileSession = null;

		try {
			ObjectMapper mapper = new ObjectMapper();
			Logger.info("MortgageController - saveDocUploadIntro(). Request: " + mortgageHelper.hashSensitiveData(mapper.writeValueAsString(request)), this.getClass());
			mobileSession = mbAppHelper.getMobileSession(httpRequest);

			//validateRequestHeader(request.getHeader(), httpRequest);
			//Added to solve the issue of Session sharing among multiple tabs or browsers and multiple applications are trying to update using the same session.
			validateDigitalMortgageRequestHeader(request.getHeader(), httpRequest);
			ErrorResp errorResponse = validate(request, httpRequest);
			if (errorResponse.hasErrors()){
				Logger.error("ERROR in Request while calling saveDocUploadIntro() - Invalid Request: "  , this.getClass());
				return errorResponse;
			}
			
			MortgageCommonData mortgageCommonData = mortgageHelper.populateMortgageCommonData(  mobileSession , request.getHeader(),   httpRequest );
			
			mortgageService.saveDocUploadIntro(mortgageCommonData);														
			
			SuccessResp successResp = new SuccessResp();																			
			RespHeader headerResp = populateResponseHeader(request.getHeader().getServiceName(), mobileSession);
			successResp.setHeader(headerResp);
			successResp.setIsSuccess(true);
			
			Logger.info("MortgageController - saveDocUploadIntro(): Info JSON Response :" + mapper.writeValueAsString(successResp), this.getClass());

			
			return successResp;
		}  
		catch (BusinessException e) {
			Logger.error("BusinessException - saveDocUploadIntro():", e, this.getClass());			

			if(e.getKey() == BusinessException.MORTGAGE_SESSION_SHARING_ERROR){
				Logger.error("Session is sharing among multiple tabs or browsers and multiple applications are trying to update using the same session......", this.getClass());									
				return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.MORTGAGE_SESSION_SHARING_ERROR, ServiceConstants.MORTGAGE_SERVICE, httpRequest);
			}
			else{
				return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE, ServiceConstants.MORTGAGE_SERVICE, httpRequest);
			}
		} 
		catch (Exception e) {
			Logger.error("Exception in MortgageController - saveDocUploadIntro(): ", e, this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE, ServiceConstants.MORTGAGE_SERVICE, httpRequest);
		} finally {
			endPerformanceLog(logName);
		}
	}
	
	
	private IMBResp retrieveApplication(List<Application> appList, MobileSession mobileSession, MortgageCommonData mortgageCommonData) {
		ApplicationListResp applicationListResp = new ApplicationListResp();						
		List<ApplicationInfo> appInfoList = new ArrayList<ApplicationInfo>();
		int index = -1;
		for(Application app : appList){
			index++;
			app.setIndex(index);
			ApplicationInfo applicationInfo = mortgageHelper.populateApplicationInfo(app);
			applicationInfo.setIndex(index);					
			appInfoList.add(applicationInfo);
		}				
		mobileSession.setMortgageApplicationList(appList);
		applicationListResp.setAppList(appInfoList);	
		return applicationListResp;
	} 
		
	@RequestMapping(method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE, value = "getSession")
	@ResponseBody
	public IMBResp getSession(HttpServletRequest httpRequest, HttpServletResponse httpResponse, @RequestBody final EmptyReq request, @RequestParam(value = MortgageUtil.MORTGAGE_LENDER_ID, required=false) String lenderId) {
		String logName = startPerformanceLog(httpRequest);
		MobileSession mobileSession = new MobileSessionImpl();
		IGenericSession genericSession = null;
		try {
			ObjectMapper mapper = new ObjectMapper();
			Logger.debug("MortgageController - getSession(). Request: " + mapper.writeValueAsString(request), this.getClass());
			mobileSession.getSessionContext(httpRequest);

			validateRequestHeader(request.getHeader(), httpRequest);
			ErrorResp errorResponse = validate(request, httpRequest);
			if (errorResponse.hasErrors()){
				return errorResponse;
			}
			
			
			InitialRefDataResp initialRefDataResp = new InitialRefDataResp();
			
			genericSession = mortgageHelper.createSession( httpRequest, httpResponse);
			
			MortgageSessionInfo application = new MortgageSessionInfo();
			application.setOrigin((String)genericSession.getAttribute(MobileSessionImpl.ORIGIN_OBLECT));
			
			
			mobileSession.setMortgageSessionInfo(application);
			genericSession.setAttribute(MobileSessionImpl.MORTGAGE_APPLICATION, application);
			
			
			SessionResp successResp = new SessionResp();																			
			RespHeader headerResp = populateResponseHeader(request.getHeader().getServiceName(), mobileSession);
			successResp.setHeader(headerResp);
			successResp.setIsSuccess(true);
			
			Logger.info("The value for lenderId is  " + lenderId,this.getClass());
			if(!StringMethods.isEmptyString(lenderId) && StringUtil.isValidAlphaNumeric(lenderId) ){
				try
				{
					//Call service and get lender details and populate resp..
					Lender lender = mortgageLenderService.getLenderDetails(lenderId, mortgageParams.getBaseOriginCode((String)genericSession.getAttribute(MobileSessionImpl.ORIGIN_OBLECT)));
					if(lender != null){
						successResp.setLender(mortgageHelper.populateLenderInfo(lender));
						//Then store lenderId in session if lender details are present
						genericSession.setAttribute(MobileSessionImpl.MORTGAGE_LENDER_ID, lenderId);
					}
				}
				catch (Exception e)
				{
					Logger.error("Error in getting lender details "  , e,  this.getClass());
					
				}
				
			}
			
			Logger.debug("MortgageController - getSession() JSON Response :" + mapper.writeValueAsString(successResp), this.getClass());

			return successResp;
		}  catch (Exception e) {
			Logger.error("Exception in MortgageController - getSession(): ", e, this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE, ServiceConstants.MORTGAGE_SERVICE, httpRequest);
		} finally {
			
			if ( genericSession != null )
				genericSession.updateSession();				

			endPerformanceLog(logName);
		}
	}
	
	private String getHashCodeForReq( ApplicationInfo app )
	{
		try
		{
			ObjectMapper mapper = new ObjectMapper();
			String jsonReq = mapper.writeValueAsString(app);
			Logger.info("MortgageController - getHashCodeForReq()  HashCode : " + jsonReq.hashCode() , this.getClass());

			return jsonReq.hashCode()+"" ;
		}
		catch (Exception e)
		{
			Logger.error("Error in getHashCodeForReq "  , e,  this.getClass());
			return "0";
		}
	}

	
	
	@Autowired
	private LogonHelper logonHelper;

	
	@RequestMapping(method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE, value = "uploadCustDocDetails")	
	@ResponseBody
	public IMBResp processCustUploadDetails(HttpServletRequest httpRequest, HttpServletResponse httpResponse,  @RequestBody final DocUploadDetailReq request) {
		ObjectMapper mapper = new ObjectMapper();
		String logName = startPerformanceLog(httpRequest);
		MobileSession mobileSession = null;	  
		String origin = logonHelper.resolveOrigin(httpRequest);	
		try {
			Logger.debug("MortgageController - processCustUploadDetails(). Request: " + mapper.writeValueAsString(request), this.getClass());			
			mobileSession = mbAppHelper.getMobileSession(httpRequest);
	
			if(mobileSession == null || (mobileSession.getMortgageSessionInfo() == null)){
				Logger.error("Mobile Session is null", this.getClass());
				throw new BusinessException(BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE);
			}
			MortgageSessionInfo mortgageSessionInfo = mobileSession.getMortgageSessionInfo();
//				validate NumberOfDocumentsUploaded
			if(mortgageHelper.getDMCodesDataMaxNumberOfDocuments() != null && (mortgageSessionInfo.getNumberOfDocumentsUploaded() != null && (mortgageSessionInfo.getNumberOfDocumentsUploaded() >= mortgageHelper.getDMCodesDataMaxNumberOfDocuments().longValue()))){
				Logger.error("Validation Failed - Maximum number of Uploaded documents Reached", this.getClass());
				throw new BusinessException(BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE);
			}
//				Calculate Doc Upload Timings				
			if(mortgageSessionInfo.getDocUploadStartTimeInSeconds() != null){
				Logger.info("Doc Upload - START time: " + mortgageSessionInfo.getDocUploadStartTimeInSeconds()+", END time: "+(new Date()).getTime()+", Time DIFF: "+((new Date()).getTime() - mortgageSessionInfo.getDocUploadStartTimeInSeconds())+" milliseconds", this.getClass());
				mortgageSessionInfo.setDocUploadStartTimeInSeconds(null);
			}

			//validate categoryid and docAppMapId
			List<Long> categoryIdList = new ArrayList<>();
			if(request.getDocUploadInfoList() != null){
				for(DocUploadInfo docUploadInfo : request.getDocUploadInfoList()){
					categoryIdList.add(docUploadInfo.getCategoryId());
				}
			}
			if(mortgageHelper.validateUploadCustDocDetailsRequest(request, mortgageSessionInfo.getDocAppMapIdList())
					|| mortgageService.validateCategoryId(categoryIdList)
					){
				Logger.error("Validation Failed - Invalid request(DocUploadDetailReq)", this.getClass());
				throw new BusinessException(BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE);
			}
			
			validateDigitalMortgageRequestHeader(request.getHeader(), httpRequest);
			ErrorResp errorResponse = validate(request, httpRequest);
			if (errorResponse.hasErrors()){
				return errorResponse;
			}
			
			List<DocUploadDetail> docUploadDetailsList=mortgageHelper.populateDocUploadDetails(request.getDocUploadInfoList());
			
			mortgageService.processDocUploadDetails(docUploadDetailsList,mortgageSessionInfo.getApplicationNumber());
			
			try{
				long currentNumberOfDocsUploadedSuccess = 0; 
				if(docUploadDetailsList != null){
					BigDecimal totalSize = BigDecimal.ZERO;
					for(DocUploadDetail docUploadDetail:docUploadDetailsList){
						if(docUploadDetail.getSize() != null){
							totalSize = totalSize.add(docUploadDetail.getSize());
						}
						if(MortgageUtil.SUCCESS.equalsIgnoreCase(docUploadDetail.getStatus())){
							++currentNumberOfDocsUploadedSuccess;
						}
					}
					Long numberOfDocumentsUploadedInSession = mobileSession.getMortgageSessionInfo().getNumberOfDocumentsUploaded();
					if(numberOfDocumentsUploadedInSession == null){
						numberOfDocumentsUploadedInSession = 0L;
					}
					mobileSession.getMortgageSessionInfo().setNumberOfDocumentsUploaded(numberOfDocumentsUploadedInSession + currentNumberOfDocsUploadedSuccess);
					Logger.debug("NumberOfDocumentsUploaded in Session: "+numberOfDocumentsUploadedInSession+" currentNumberOfDocsUploadedSuccess: "+currentNumberOfDocsUploadedSuccess, this.getClass());
					MortgageCommonData mortgageCommonData = mortgageHelper.populateMortgageCommonData(mobileSession, request.getHeader(), httpRequest);
					mortgageService.logStatistics(mortgageCommonData, "Size: "+totalSize.setScale(1,RoundingMode.DOWN).toPlainString(), MortgageUtil.GWDStatatisticActionsEnum.DocumentUpload.getValue());
				}
			}catch(Exception e){
				Logger.error("Exception in MortgageController - processCustUploadDetails() logStatistics : ", e, this.getClass());
			}
			
			SuccessResp successResp = new SuccessResp();																			
			RespHeader headerResp = populateResponseHeader(request.getHeader().getServiceName(), mobileSession);
			successResp.setHeader(headerResp);
			successResp.setIsSuccess(true);	
			return successResp;
			
		} catch (BusinessException e) {
			Logger.error("BusinessException in MortgageController - processCustUploadDetails(): ", e, this.getClass());
			return MBAppUtils.createErrorResp(origin, BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE, ServiceConstants.MORTGAGE_SERVICE, httpRequest);	
		}  catch (Exception e) {
			Logger.error("Exception in MortgageController - processCustUploadDetails(): ", e, this.getClass());
			return MBAppUtils.createErrorResp(origin, BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE, ServiceConstants.MORTGAGE_SERVICE, httpRequest);
		} finally {
			endPerformanceLog(logName);
		}
	}
	
	

	@RequestMapping(method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE, value = "getDocUploadJWTToken")
	@ResponseBody
	public IMBResp getDocUploadJWTToken(HttpServletRequest httpRequest, HttpServletResponse httpResponse,  @RequestBody final EmptyReq request) {
		Logger.debug("MortgageController - getDocUploadJWTToken(). Request: " + request, this.getClass());		
		String logName = startPerformanceLog(httpRequest);
		MobileSession mobileSession = null;	 
		DocUploadJWTTokenResp docUploadJWTTokenResp = new DocUploadJWTTokenResp();
		RespHeader headerResp = populateResponseHeader(ServiceConstants.MORTGAGE_SERVICE, mobileSession);
		docUploadJWTTokenResp.setHeader(headerResp);		
		
		String origin = logonHelper.resolveOrigin(httpRequest);	
		try {	
			mobileSession = mbAppHelper.getMobileSession(httpRequest);
            IBankCommonData iBankCommonData = mbAppHelper.populateIBankCommonData(mobileSession,httpRequest);
            if(mobileSession != null && mobileSession.getMortgageSessionInfo() != null){
	            Customer customer = new Customer();
	            customer.setGcis(mobileSession.getMortgageSessionInfo().getLoggedOnGCISNumber());
	            iBankCommonData.setCustomer(customer);
            }
			String jwtToken = mortgageService.getDocUploadSignedJWT(iBankCommonData, mobileSession.getMortgageSessionInfo().getApplicationNumber());
			
			if(StringUtils.isBlank(jwtToken)){
				Logger.error("jwtToken is NULL", this.getClass());
				throw new BusinessException(BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE);
			}
			else{
				docUploadJWTTokenResp.setJwtToken(jwtToken);
				docUploadJWTTokenResp.setSuccess(true);
				mobileSession.getMortgageSessionInfo().setDocUploadStartTimeInSeconds((new Date()).getTime());
			}
			
			ObjectMapper mapper = new ObjectMapper();
			Logger.info("MortgageController - getDocUploadJWTToken() JSON Response :" + mortgageHelper.hashSensitiveData(mapper.writeValueAsString(docUploadJWTTokenResp)), this.getClass());
            MortgageCommonData mortgageCommonData = mortgageHelper.populateMortgageCommonData(mobileSession, request.getHeader(), httpRequest);              
            String applicationNum=null;
            Long applicationNumber=mortgageCommonData.getApplicationNumber();
            if(null!=applicationNumber){
                  applicationNum=String.valueOf(applicationNumber);
            }
            String gcisNumber=mortgageCommonData.getGcisNumber();
            mortgageService.logStatistics(mortgageCommonData, "Application Number: "+applicationNum+" Gcis:"+gcisNumber, MortgageUtil.GWDStatatisticActionsEnum.DocumentUploadJWT.getValue());
			
			return docUploadJWTTokenResp;
			
		} catch (BusinessException e) {
			Logger.error("BusinessException in MortgageController - getDocUploadJWTToken(): ", e, this.getClass());
			return MBAppUtils.createErrorResp(origin, BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE, ServiceConstants.MORTGAGE_SERVICE, httpRequest);	
		}  catch (Exception e) {
			Logger.error("Exception in MortgageController - getDocUploadJWTToken(): ", e, this.getClass());
			return MBAppUtils.createErrorResp(origin, BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE, ServiceConstants.MORTGAGE_SERVICE, httpRequest);
		} finally {
			endPerformanceLog(logName);
		}
	}
	
	@RequestMapping(method = RequestMethod.POST, headers = "content-type=application/json", produces = MediaType.APPLICATION_JSON_VALUE, value = "getLivePersonChatStatus")
	@ResponseBody
	public IMBResp getLivePersonChatStatus(HttpServletRequest httpRequest, @RequestBody final EmptyReq request) {
		Logger.debug("MortgageController - LivePersonChatStatus(). Request: " + request, this.getClass());
		String logName = startPerformanceLog(httpRequest);
		MobileSession mobileSession = new MobileSessionImpl();
		String origin = "";
		try {	
			origin = logonHelper.resolveOrigin(httpRequest);
			mobileSession = mbAppHelper.getMobileSession(httpRequest);
			validateDigitalMortgageRequestHeader(request.getHeader(), httpRequest);
			ErrorResp errorResponse = validate(request, httpRequest);
			if (errorResponse.hasErrors())
				return errorResponse;
			int status = 0;
			
			LivePersonChat livePersonChat = new LivePersonChat();
			if (null == mobileSession.getMortgageSessionInfo()) {
				IBankCommonData commonData = mbAppHelper.populateIBankCommonData(mobileSession, httpRequest);
				commonData.setOrigin(mobileSession.getOrigin());
				livePersonChat.setIBMBChannel(true);
				livePersonChat.setCommonData(commonData);
			}else {
				livePersonChat.setMortgageSession(mobileSession.getMortgageSessionInfo());
			}
			
			status = livePersonChatService.getLivePersonChatStatus(livePersonChat);
			
			IMBResp serviceResponse = populateChatStatusResponse(
					populateResponseHeader(ServiceConstants.MORTGAGE_SERVICE, mobileSession), status);
			
			return serviceResponse;
			
		}catch (BusinessException e) {
			Logger.error("BusinessException in MortgageController - getDocUploadJWTToken(): ", e, this.getClass());
			return MBAppUtils.createErrorResp(origin, BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE, ServiceConstants.MORTGAGE_SERVICE, httpRequest);	
		}  catch (Exception e) {
			Logger.error("Exception in MortgageController - getDocUploadJWTToken(): ", e, this.getClass());
			return MBAppUtils.createErrorResp(origin, BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE, ServiceConstants.MORTGAGE_SERVICE, httpRequest);
		} finally {
			endPerformanceLog(logName);
		}
	}
	
	
	private LivePersonChatStatusResp populateChatStatusResponse(RespHeader header, int  status)
			throws BusinessException {
		LivePersonChatStatusResp response = new LivePersonChatStatusResp();
		if (status == 1) {
			response.setSecureChatActiveFlag(true);
		}
		return response;
	}
	
	@RequestMapping(method = RequestMethod.POST, headers = "content-type=application/json", produces = MediaType.APPLICATION_JSON_VALUE, value = "logWintelResGDWEntry")
	@ResponseBody
	public IMBResp logWintelResGDWEntry(HttpServletRequest httpRequest, @RequestBody final WintelReq request) {
		ObjectMapper mapper = new ObjectMapper();
		String logName = startPerformanceLog(httpRequest);		
		MobileSession mobileSession = null;
		try {
			Logger.info("START - logWintelResGDWEntry(): Request: "+mapper.writeValueAsString(request), this.getClass());

			mobileSession = mbAppHelper.getMobileSession(httpRequest);
			
			if (mobileSession == null) {
				return null;
			}
			
			validateDigitalMortgageRequestHeader(request.getHeader(), httpRequest);
			ErrorResp errorResponse = validate(request, httpRequest);
			if (errorResponse.hasErrors()) {
				return errorResponse;
			}
			
			MortgageCommonData mortgageCommonData = mortgageHelper.populateMortgageCommonData(mobileSession,  request.getHeader(), httpRequest);
			mortgageService.wintelStatsEntry(mortgageCommonData, request.getLogData(), "DMDOUP");
			SuccessResp successResp = new SuccessResp();
			RespHeader headerResp = mbAppHelper.populateAsyncResponseHeader(request.getHeader().getServiceName(), mobileSession, true);
			successResp.setHeader(headerResp);
			successResp.setIsSuccess(true);
			Logger.debug("END - logWintelResGDWEntry():", this.getClass());
			return successResp;
		} 
		catch (BusinessException e) {
			Logger.error("BusinessException - logWintelResGDWEntry():", e, this.getClass());			
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE, ServiceConstants.MORTGAGE_SERVICE, httpRequest);
		}  
		catch (Exception e) {
			Logger.error("Exception in MortgageController - logWintelResGDWEntry(): ",e, this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE, ServiceConstants.MORTGAGE_SERVICE, httpRequest);
		} finally {
			endPerformanceLog(logName);
		}
	}	
	
	@RequestMapping(method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE, value = "allLenders")
	@ResponseBody
	public IMBResp getAllLenders(HttpServletRequest httpRequest, HttpServletResponse httpResponse, @RequestBody final EmptyReq request) {
		Logger.debug("MortgageController - getAllLenders(). Request: " + request, this.getClass());
		
		String logName = startPerformanceLog(httpRequest);
		MobileSession mobileSession = null;
	    String origin = logonHelper.resolveOrigin(httpRequest);
		try {	
			mobileSession = mbAppHelper.getMobileSession(httpRequest);

			validateRequestHeader(request.getHeader(), httpRequest);
			ErrorResp errorResponse = validate(request, httpRequest);
			if (errorResponse.hasErrors()){
				return errorResponse;
			}
			
			 MortgageCommonData mortgageCommonData = mortgageHelper.populateMortgageCommonData(mobileSession, request.getHeader(), httpRequest);
			 
			 //Origin from mortgageCommonData and base origin..
			//or origin or mortgageCommonData.getOrigin()
			 
			//Service call to fetch getLenderDetails
			 List<Lender> lendersList = mortgageLenderService.getAllLenders(mortgageParams.getBaseOriginCode(mobileSession.getOrigin())); 
			 IMBResp serviceResponse = new LenderDetailsResp();
			 if(lendersList != null && !lendersList.isEmpty()){
				 
				//Populate resp..LenderDetailsResp
				//IMBResp serviceResponse = new AccountInfoResp();
				
				 //Store list in session..(index+eid)
				 
				 LabelValueMap lenderMap = new LabelValueMap();
				 
				 
				//Populate resp..LenderDetailsResp
				serviceResponse = mortgageHelper.populateLenderDetailsResp(lendersList, lenderMap, mobileSession);
				mobileSession.setDMLenderList(lenderMap);
			 }
			 else{
				 Logger.info("Lender list is empty or null " , this.getClass());
			 }
			 RespHeader headerResp = populateResponseHeader(ServiceConstants.MORTGAGE_SERVICE, mobileSession);
			 serviceResponse.setHeader(headerResp);

			ObjectMapper mapper = new ObjectMapper();
			Logger.info("MortgageController - getAllLenders() JSON Response :" + mapper.writeValueAsString(serviceResponse), this.getClass());

			return serviceResponse;
			
		} catch (BusinessException e) {
			Logger.error("Exception in MortgageController - getAllLenders(): ", e, this.getClass());
			return MBAppUtils.createErrorResp(origin, BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE, ServiceConstants.MORTGAGE_SERVICE, httpRequest);
		}  catch (Exception e) {
			Logger.error("Exception in MortgageController - getAllLenders(): ", e, this.getClass());
			return MBAppUtils.createErrorResp(origin, BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE, ServiceConstants.MORTGAGE_SERVICE, httpRequest);
		} finally {
			endPerformanceLog(logName);
		}
		

	}
	
	
	
	
	
	
	
	
}
