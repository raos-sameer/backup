package au.com.stgeorge.mbank.controller.services;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import au.com.stgeorge.framework.common.logging.Logger;
import au.com.stgeorge.framework.common.util.StringMethods;
import au.com.stgeorge.ibank.businessobject.StatisticsService;
import au.com.stgeorge.ibank.businessobject.assembler.CustomerVOAssembler;
import au.com.stgeorge.ibank.common.log.IBankLog;
import au.com.stgeorge.ibank.safi.util.SafiUtil;
import au.com.stgeorge.ibank.safi.valueobject.SafiMgrpVO;
import au.com.stgeorge.ibank.service.valueobject.SafiRespVO;
import au.com.stgeorge.ibank.valueobject.ContactDetail;
import au.com.stgeorge.ibank.valueobject.Customer;
import au.com.stgeorge.ibank.valueobject.Statistic;
import au.com.stgeorge.ibank.valueobject.transfer.IBankCommonData;
import au.com.stgeorge.mbank.controller.SafiWebHelper;
import au.com.stgeorge.mbank.controller.customer.LogonHelper;
import au.com.stgeorge.mbank.model.request.services.MgrpReq;
import au.com.stgeorge.mbank.session.MobileSession;

public class MgrpHelper {

	private LogonHelper logonHelper;
	
	public LogonHelper getLogonHelper() {
		return logonHelper;
	}

	public void setLogonHelper(LogonHelper logonHelper) {
		this.logonHelper = logonHelper;
	}
	
	private static final String GDW_DESCRPTION = "MGRP|Amplify Rewards Website";
	
	public SafiMgrpVO populateSafiVO(HttpServletRequest httpRequest, MobileSession mobileSession, IBankCommonData commonData, MgrpReq request) {
			
		String validDecodedPrint;
		String devicePrint;
		
		Logger.debug("SAFI : populateSafiVO Device Print" +request.getDevicePrint(), this.getClass()) ;
		validDecodedPrint = SafiUtil.validateDevicePrint(request.getDevicePrint());
		devicePrint = validDecodedPrint != null ? request.getDevicePrint():null;
		
		SafiMgrpVO safiVO = new SafiMgrpVO();
		
		if(null == devicePrint && null != mobileSession.getSafiLogonInfo() && null != mobileSession.getSafiLogonInfo().getDevicePrint()) {
			devicePrint = mobileSession.getSafiLogonInfo().getDevicePrint();
			Logger.debug("SAFI : populateSafiVO :  Device Print from request was null so getting from mobileSession.getSafiLogonInfo():" +devicePrint, this.getClass()) ;
		}
			
		boolean isMobileApp = ((logonHelper.loadCordova(httpRequest)) == -1) ? false:true;
		Logger.debug("SAFI : populateSafiVO: validDecodedPrint: " +validDecodedPrint + " devicePrint: "+devicePrint+" isMobileApp: "+isMobileApp, this.getClass()) ;
			
		safiVO = SafiWebHelper.populateSafiVOForMgrp(httpRequest, devicePrint, commonData, isMobileApp, safiVO, mobileSession);
		
		return safiVO;
	}
	
	public void handleSafiResponseinCookies(HttpServletRequest httpServletRequest,HttpServletResponse httpServletResponse, SafiRespVO safiRespVO){
		if(safiRespVO != null){
			Cookie pmdata2 = SafiWebHelper.readCookies(httpServletRequest);
			Cookie newCookie = SafiWebHelper.createOrUpdatePmdata2Cookie(httpServletRequest,pmdata2,safiRespVO.getDeviceToken());
			httpServletResponse.addCookie(newCookie);
		}
	}	
	
	public boolean isCHSorCombinedCustomer(Customer customer){
		return customer.isCHSCustomer() || customer.isCHSGHSCustomer();
	}	
	
	
    
    
    public void setStatisticGDWLog(IBankCommonData commonData) {
        try {
            Statistic statistic = new Statistic();
    
            statistic.setGcisNumber(commonData.getCustomer().getGcis());
            statistic.setAction(Statistic.EXTERNAL_LINK);
            statistic.setOriginBank(commonData.getOrigin());
            statistic.setGDWOriginBank(commonData.getGdwOrigin());
            statistic.setDescription(GDW_DESCRPTION);
            statistic.setSessionId(commonData.getSessionId());
            statistic.setIpAddress(commonData.getIpAddress());
            
            StatisticsService.logStatistic(statistic);
        }
        catch(Exception e) {
            IBankLog.logTRC("MgrpHelper Unable to create statistic entry for GCIS "
                      + commonData.getUser().getGCISNumber(), e, this.getClass());
            
        }
     }
    public int getRegisteredPhoneNumberCount(ContactDetail contactDetail){
		int registeredPhoneNumberCount = 0;
		
		if (!CustomerVOAssembler.BUSINESS_CUSTOMER.equalsIgnoreCase(contactDetail.getCustTypeInd())){
			if (contactDetail.getHomeNumber() != null && !StringMethods.isEmptyString(contactDetail.getHomeNumber().getPhoneNumber())){
				registeredPhoneNumberCount++;
			}
		}
		if (contactDetail.getWorkNumber() != null && !StringMethods.isEmptyString(contactDetail.getWorkNumber().getPhoneNumber())){
			registeredPhoneNumberCount++;
		}
		if (contactDetail.getMobileNumber() != null && !StringMethods.isEmptyString(contactDetail.getMobileNumber().getPhoneNumber())){
			registeredPhoneNumberCount++;
		}
		return registeredPhoneNumberCount;
	}	

}
