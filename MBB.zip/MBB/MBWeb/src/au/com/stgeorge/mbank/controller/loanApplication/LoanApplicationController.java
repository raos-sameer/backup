package au.com.stgeorge.mbank.controller.loanApplication;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import au.com.stgeorge.framework.common.logging.Logger;
import au.com.stgeorge.ibank.businessobject.BusinessException;
import au.com.stgeorge.ibank.businessobject.loanapplication.LoanApplicationService;
import au.com.stgeorge.ibank.businessobject.onlinereg.OnlineRegistrationService;
import au.com.stgeorge.ibank.common.cache.IBankParams;
import au.com.stgeorge.ibank.loanApplication.LoanApplicationDetail;
import au.com.stgeorge.ibank.loanApplication.util.LoanAppConstants;
import au.com.stgeorge.ibank.onlinereg.valueobject.RegisterCustomerVO;
import au.com.stgeorge.ibank.util.ServiceHelper;
import au.com.stgeorge.ibank.valueobject.ExternalLinkVO;
import au.com.stgeorge.ibank.valueobject.database.SecurityCodeVO;
import au.com.stgeorge.ibank.valueobject.transfer.IBankCommonData;
import au.com.stgeorge.mbank.controller.onlinereg.OnlineRegHelper;
import au.com.stgeorge.mbank.model.common.IMBResp;
import au.com.stgeorge.mbank.model.common.RespHeader;
import au.com.stgeorge.mbank.model.request.CustomerRegReq;
import au.com.stgeorge.mbank.model.request.EmptyReq;
import au.com.stgeorge.mbank.session.MobileSession;
import au.com.stgeorge.mbank.session.MobileSessionImpl;
import au.com.stgeorge.mbank.util.MBAppHelper;
import au.com.stgeorge.mbank.util.MBAppUtils;
import au.com.stgeorge.mbank.util.ServiceConstants;
import au.com.stgeorge.mobilebank.businessobject.ExternalLinkService;
import au.com.stgeorge.mobilebank.businessobject.impl.ExternalLinkServiceImpl;

import com.fasterxml.jackson.databind.ObjectMapper;
import au.com.stgeorge.mbank.model.response.CustomerRegResp;

@Controller
@RequestMapping("/onlinereg/efinance")
public class LoanApplicationController {	
	
	@Autowired
	private OnlineRegHelper onlineRegHelper;
	 
	@Autowired
	private OnlineRegistrationService onlineRegistrationService;
	
	@Autowired
	private LoanApplicationService loanService;
	
	@Autowired
	private LoanApplicationHelper loanApplicationHelper;
	
	@Autowired
    private MBAppHelper mbAppHelper;
	
	@RequestMapping(value="registerloancustomer", method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public IMBResp registerCustomer(HttpServletRequest httpRequest, HttpServletResponse httpServletResponse, @RequestBody final CustomerRegReq request){
		Logger.debug("LoanApplicationController - registerCustomer(). Request: " + request, this.getClass());		
		MobileSession mobileSession = new MobileSessionImpl();		
		String origin = null;
		LoanApplicationDetail loanDetails=null;
		ObjectMapper mapper = new ObjectMapper();
		
		
		try {			
			mobileSession.getSessionContext(httpRequest);
			boolean originTriggerMb = request.isOriginMb();
			 origin = mbAppHelper.getOrigin(httpRequest);
			    
			if(!originTriggerMb)
			{
				origin = origin.substring(1);
			}	
			mobileSession.setOrigin(origin);
			IBankCommonData commonData = new MBAppHelper().populateIBankCommonData(mobileSession, httpRequest);			
			commonData.setOrigin(origin);
			if(mobileSession.getLoanApplicationDetail() != null){
				loanDetails = mobileSession.getLoanApplicationDetail();
			}else{
				loanDetails=loanService.getLoanApplicationDetails(commonData);
			}
			
			SecurityCodeVO securityCodeVO = onlineRegHelper.validateAuthenticationData(httpRequest,origin,request);			
			RegisterCustomerVO registerVO =onlineRegHelper.populateLoanApplicationRegisterVO(request, origin,securityCodeVO);
			if(null != registerVO){

				if(null!=loanDetails){
				  registerVO.setApplicationRefNum(loanDetails.getSourceApplRefNum());
				}				

				//Found, Plain password and security number are visible in info logs while testing. As discussed, commented logging, since password and security number should not be printed in logs.
				/*
				if(null != registerVO.getSecNum()){
					Logger.info("decryptedSecuNumber"+ registerVO.getSecNum(), this.getClass());
				}
				if(null != registerVO.getPwd()){
					Logger.info(" decryptedPassword"+ registerVO.getPwd(), this.getClass());
				}
				*/
			}			

			//CSH Auto Reg changes : If customer is not registered, proceed with CSH WDP API reg flow, else existing flow.
			//If CSH switch is ON only, calling IDM enquiry to check customer is not registered
			//Below logic is moved from service to controller, to send same flag to UI.

			boolean isRegistered = false;
			boolean cshAutoRegFlag = false;
			if(IBankParams.isSwitchOn(IBankParams.DEFAULT_ORIGIN, IBankParams.CSH_AUTO_REG_SWITCH)) {
				isRegistered = onlineRegistrationService.isCustomerRegistered(commonData.getCustomer());
				if(!isRegistered) {
					cshAutoRegFlag = true;
				}
			}
			
			String can = onlineRegistrationService.registerCustomer(commonData,registerVO,isRegistered);
			Logger.info("CAN "+ can, this.getClass());
			
			//Changes for issue#1574
			//loanDetails=loanService.getLoanApplicationDetails(commonData);
			Logger.info("update Loan status", getClass());
			if(null!=loanDetails){
				loanDetails.setStatus(LoanAppConstants.LOAN_STATUS_REGISTERED);
				loanService.updateLoanApplStatus(loanDetails);
			}			

			IMBResp serviceResponse=loanApplicationHelper.populateCustomerRegResponse(loanDetails, commonData,can);
			Logger.info("registerCustomer: LOANAPPLICATION JSON Response :" + mapper.writeValueAsString(serviceResponse), this.getClass());
			RespHeader headerResp = populateResponseHeader(ServiceConstants.ONLINE_REG, null);
			serviceResponse.setHeader(headerResp);
		
			if(IBankParams.isSwitchOn(IBankParams.IV_SWITCH)) {
				((CustomerRegResp)serviceResponse).setIncomeVerificationSwitch("ON");
			}
			else {
				((CustomerRegResp)serviceResponse).setIncomeVerificationSwitch("OFF");
			}
			((CustomerRegResp)serviceResponse).setCshAutoRegFlag(cshAutoRegFlag);
			
			return serviceResponse;

			
		} catch (Exception e) {					
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.GENERIC_ERROR, ServiceConstants.ONLINE_REG, httpRequest);
		} finally {
			
		}
	
	}
	
	public RespHeader populateResponseHeader(String serviceName, MobileSession mobSession )
	{
		RespHeader headerResp = new RespHeader();
		headerResp.setClientApiVersion(ServiceConstants.API_VERSION);
		String newNameId = null;		
		headerResp.setServiceName(serviceName);
		Logger.info(" populateResponseHeader (2). serviceName  " + serviceName + " newNameId "+ newNameId, this.getClass());
		return headerResp;
	}
	
	/**
	 * 
	 * User to be displayed to new compass screen after click on "Next" button on "What's next" page.<br/>
	 * When user clicks on "Verify Your Income" button on the new screen, user is redirected to ACE page,
	 * with JWT token and post parameter : IV=Y <br/><br/>
	 *  
	 * @param httpRequest
	 * @param httpServletResponse
	 * @param req
	 * @return IMBResp
	 */
    @RequestMapping(value="redirectToIncomeVerification", method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    public IMBResp redirectToIncomeVerification(HttpServletRequest httpRequest, HttpServletResponse httpServletResponse, @RequestBody final EmptyReq req){
        
    	Logger.debug("LoanApplicationController - redirectToIncomeVerification() - Start.", this.getClass());       
        
        MobileSession mobileSession = new MobileSessionImpl();
        LoanApplicationDetail loanDetails=null;
        String aceUrl = null;
        ExternalLinkVO  externalLinkVO = null;
        
        try {            
            mobileSession.getSessionContext(httpRequest);
            IBankCommonData commonData = new MBAppHelper().populateIBankCommonData(mobileSession, httpRequest);
            loanDetails=loanService.getLoanApplicationDetails(commonData);
                              
            if(null!=loanDetails){              
                aceUrl = loanService.getACEUrl(commonData, loanDetails);
                ExternalLinkService extService = ServiceHelper.getBean("externalLinkService");
                externalLinkVO = ((ExternalLinkServiceImpl) extService).processAcePOSTRequest(commonData.getCustomer().getGcis(), aceUrl, loanDetails.getSourceApplRefNum(), LoanAppConstants.FROM_EFINANCE + LoanAppConstants.EFINANCE_DELIMITER + commonData.getCustomer().getGHSCISNumber(), null, null);
                
                IMBResp serviceResponse=loanApplicationHelper.populateIncomeVerificationResp(httpRequest,mobileSession,commonData, externalLinkVO);               
                RespHeader headerResp = populateResponseHeader(ServiceConstants.EFINANCE, null);
                serviceResponse.setHeader(headerResp);
                
                return serviceResponse; 
            }
            else{
            	return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.GENERIC_ERROR, ServiceConstants.EFINANCE, httpRequest);
            }
            
        } catch(Exception e) {                    
            return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.GENERIC_ERROR, ServiceConstants.EFINANCE, httpRequest);
            
        } finally {
        	Logger.debug("LoanApplicationController - redirectToIncomeVerification() - End.", this.getClass()); 
        }    
    }
}
