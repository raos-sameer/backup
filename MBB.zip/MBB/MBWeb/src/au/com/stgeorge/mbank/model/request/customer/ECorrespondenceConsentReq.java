package au.com.stgeorge.mbank.model.request.customer;

import java.io.Serializable;

import au.com.stgeorge.mbank.model.common.IMBReq;
import au.com.stgeorge.mbank.model.common.ReqHeader;

public class ECorrespondenceConsentReq implements IMBReq, Serializable {

	
	private static final long serialVersionUID = 2264113126810901155L;

	private boolean eCorrespondenceConsent;

	public boolean iseCorrespondenceConsent() {
		return eCorrespondenceConsent;
	}
	public void seteCorrespondenceConsent(boolean eCorrespondenceConsent) {
		this.eCorrespondenceConsent = eCorrespondenceConsent;
	}
	private ReqHeader header;
	
	public ReqHeader getHeader(){
		return header;
	}
	public void setHeader(ReqHeader header)
	{
		this.header = header;
	}

}
