package au.com.stgeorge.mbank.controller.newaccount.cpp;

import static au.com.stgeorge.ibank.businessobject.acctsvc.AccountService.ACCT_OPEN;
import static au.com.stgeorge.ibank.businessobject.acctsvc.AccountService.MAX_TD_ACCT_OPENING_REQ;

import java.math.BigDecimal;
import java.security.SecureRandom;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.List;
import java.util.UUID;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import au.com.stgeorge.framework.common.logging.Logger;
import au.com.stgeorge.framework.common.util.DateMethods;
import au.com.stgeorge.ibank.businessobject.AccountFilter;
import au.com.stgeorge.ibank.businessobject.BusinessException;
import au.com.stgeorge.ibank.businessobject.ResourceException;
import au.com.stgeorge.ibank.businessobject.TaxFileNumberService;
import au.com.stgeorge.ibank.businessobject.wdp.WDPServiceHelper;
import au.com.stgeorge.ibank.common.cache.IBankParams;
import au.com.stgeorge.ibank.common.log.IBankLog;
import au.com.stgeorge.ibank.cpp.businessobject.CustomerPricingService;
import au.com.stgeorge.ibank.cpp.businessobject.CustomerPricingServiceHelper;
import au.com.stgeorge.ibank.cpp.util.InterestPaidEnum;
import au.com.stgeorge.ibank.cpp.valueobjects.CustomerPricingTdDetails;
import au.com.stgeorge.ibank.cpp.valueobjects.TDGetRates;
import au.com.stgeorge.ibank.cpp.valueobjects.TermDepositCustomer;
import au.com.stgeorge.ibank.cpp.valueobjects.TermDepositDetails;
import au.com.stgeorge.ibank.cpp.valueobjects.TermDepositProducts;
import au.com.stgeorge.ibank.util.StringUtil;
import au.com.stgeorge.ibank.util.TermDepositConstants;
import au.com.stgeorge.ibank.valueobject.Account;
import au.com.stgeorge.ibank.valueobject.BaseSessionReceipts;
import au.com.stgeorge.ibank.valueobject.Customer;
import au.com.stgeorge.ibank.valueobject.TermDepositAccount;
import au.com.stgeorge.ibank.valueobject.TermDepositProduct;
import au.com.stgeorge.ibank.valueobject.TermDepositRenewalSessionReceipts;
import au.com.stgeorge.ibank.valueobject.TermDepositSessionReceipts;
import au.com.stgeorge.ibank.valueobject.ThirdParty;
import au.com.stgeorge.ibank.valueobject.database.AcctOpeningVO;
import au.com.stgeorge.ibank.valueobject.database.BranchVO;
import au.com.stgeorge.ibank.valueobject.database.CodesVO;
import au.com.stgeorge.ibank.valueobject.database.OriginsVO;
import au.com.stgeorge.ibank.valueobject.database.RegionVO;
import au.com.stgeorge.ibank.valueobject.transfer.IBankCommonData;
import au.com.stgeorge.ibank.valueobject.transfer.NewTermDepositAccount;
import au.com.stgeorge.ibank.valueobject.transfer.TermDepositRenewal;
import au.com.stgeorge.mbank.controller.IMBController;
import au.com.stgeorge.mbank.controller.newaccount.TermDepositHelper;
import au.com.stgeorge.mbank.controller.services.TFNHelper;
import au.com.stgeorge.mbank.model.common.IMBReq;
import au.com.stgeorge.mbank.model.common.IMBResp;
import au.com.stgeorge.mbank.model.common.ReqHeader;
import au.com.stgeorge.mbank.model.common.RespHeader;
import au.com.stgeorge.mbank.model.request.EmptyReq;
import au.com.stgeorge.mbank.model.request.newaccount.cpp.TDGetRatesReq;
import au.com.stgeorge.mbank.model.request.newaccount.cpp.TDOpenAcctReq;
import au.com.stgeorge.mbank.model.request.newaccount.cpp.TDRenewAcctReq;
import au.com.stgeorge.mbank.model.request.newaccount.cpp.TDRenewalReq;
import au.com.stgeorge.mbank.model.request.newaccount.cpp.TDReq;
import au.com.stgeorge.mbank.model.request.newaccount.cpp.TDTermReq;
import au.com.stgeorge.mbank.model.response.ErrorResp;
import au.com.stgeorge.mbank.model.response.SuccessResp;
import au.com.stgeorge.mbank.model.response.services.TFNCheckResp;
import au.com.stgeorge.mbank.session.MobileSession;
import au.com.stgeorge.mbank.util.MBAppConstants;
import au.com.stgeorge.mbank.util.MBAppHelper;
import au.com.stgeorge.mbank.util.MBAppUtils;
import au.com.stgeorge.mbank.util.MBAppValidator;
import au.com.stgeorge.mbank.util.ServiceConstants;
import au.com.stgeorge.mobilebank.businessobject.OpenDDAService;
import au.com.stgeorge.mobilebank.businessobject.TermDepositService;
import au.com.stgeorge.perflogger.PerformanceLogger;

import com.fasterxml.jackson.databind.ObjectMapper;


@Controller
@RequestMapping("/cppTermDeposit")
public class TDController implements IMBController
{
	
	@Autowired
	private MBAppHelper mbAppHelper;
	
	@Autowired
	private TDHelper tdHelper;
	
	@Autowired
	private TermDepositService termDepositService;
	
	@Autowired
	private CustomerPricingService customerPricingService;
    
	@Autowired
	private MBAppValidator mbAppValidator;

	@Autowired
	private OpenDDAService openDDAService;	
	
	//19E3 code
	@Autowired
	private TFNHelper tfnHelper;

	private static final String NEW_TERM_DEPOSIT = "TDNEW";
	private static final String TERM_DEPOSIT_RENEWAL = "TDREN";
	public static final String TERM_DEPOSIT = "TermDeposit";
	public static final String BILLER_CODE = "BillerCode";
	public static final String NOT_AVAILABLE ="Not Available";
	
	public RespHeader populateResponseHeader(String serviceName, MobileSession mobSession )
	{
		return mbAppHelper.populateResponseHeader(serviceName, mobSession);
	}

	@Override
	public void validateRequestHeader(ReqHeader headerReq,
			HttpServletRequest request) throws BusinessException {
		mbAppValidator.validateRequestHeader(headerReq,  request);		
	}

	@Override
	public ErrorResp validate(IMBReq serviceRequest,
			HttpServletRequest httpRequest) throws BusinessException {
		return  mbAppValidator.validate(serviceRequest, httpRequest);
	}		
	
	@RequestMapping(value="applySingle", method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public IMBResp getFundFromAndInterestPaid(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, @RequestBody final EmptyReq req)
	{
		Logger.debug("CPP: In getFundFromAndInterestPaid TDController  " +  "  " + httpServletRequest.getContentType() + " "
				+ httpServletRequest.getRemoteAddr() + "  " + httpServletResponse.getCharacterEncoding() + httpServletResponse.getLocale() +
				" True IP >> " + httpServletRequest.getHeader(IBankParams.trueClientIP()), this.getClass());

		PerformanceLogger performanceLogger = new PerformanceLogger();		
		String logName = startPerformanceLog(performanceLogger, httpServletRequest);
		
		MobileSession mbSession =  null;
		
		TFNCheckResp tfnCheck=null;
		try
		{
			mbSession = mbAppHelper.getMobileSession(httpServletRequest);
			validateRequestHeader(req.getHeader(), httpServletRequest);
			
			mbSession.removeSelectedAccount(); //clearing seleceted account from session if any.

			IBankCommonData ibankCommonData = mbAppHelper.populateIBankCommonData(mbSession, httpServletRequest);
			Customer customer = ibankCommonData.getCustomer();
						
			Collection<Account> fundFromAcctList = termDepositService.getFundingAccounts(ibankCommonData);
			
			Collection<Account> paidToInterestAccountsList = AccountFilter.getTermDepositPaidToInterestAccounts(mbSession.getCustomer().getAccounts());			
			
			Collection<RegionVO> regions = null;
			Logger.debug("CPP : getFundFromAndInterestPaid-branch : "+ibankCommonData.getOrigin(), this.getClass());
			
			if (MBAppConstants.ORIGIN_MBSA.equals(ibankCommonData.getOrigin()) || "BSGD".equalsIgnoreCase(ibankCommonData.getOrigin())
					|| "BSA".equalsIgnoreCase(ibankCommonData.getOrigin()))
			{
				Logger.debug("CPP : getFundFromAndInterestPaid-branch : populating regions", this.getClass());
				regions = openDDAService.getRegion();
			}
			
			//19E3 TFN code
			Boolean showTfn = tfnHelper.showTfn(ibankCommonData,mbSession);
			
			if(null!= showTfn){
				if(showTfn){
					Logger.debug("TDController - populating tfn widget properties:START", this.getClass());
					//populate the response
					tfnCheck = new TFNCheckResp();
					tfnCheck.setExemptionList(tfnHelper.getTFNExemptOptList());
					tfnCheck.setTfnOptionList(tfnHelper.getTFNOptionList());
					//Business customer
					if(null!= customer && ("B".equalsIgnoreCase(customer.getCustTypeInd()) 
							|| customer.isCHSCustomer() || customer.isCHSGHSCustomer())){
						Logger.debug("TaxFileNumberHelper - Business customer", this.getClass());
						tfnCheck.setBusinessCustomer(true);
					}
				}else
					Logger.debug("TDController - Customer has already provided TFN ", this.getClass());			
			}else{
				Logger.debug("TDController - TFN switch is OFF.. no widget", this.getClass());
			}
			
			//set showTfn irrespective true or false to avoid null pointer in openTermDepositAccount method.
			 mbSession.setShowTfn(showTfn);
			
			//Change this method call
			IMBResp serviceResponse = tdHelper.populateTDResponse(tfnCheck,fundFromAcctList,mbSession.getCustomer(),null,paidToInterestAccountsList,regions,null,null);
			
			ObjectMapper mapper = new ObjectMapper();
			Logger.info("CPP: getFundFromAndInterestPaid JSON Response :" + mapper.writeValueAsString(serviceResponse), this.getClass());
			RespHeader headerResp = populateResponseHeader(ServiceConstants.CPP_OPEN_TD_SERVICE, mbSession);
			serviceResponse.setHeader(headerResp);
			return serviceResponse;
		} catch (BusinessException e)
		{
			Logger.error("CPP:Exception Inside getFundFromAndInterestPaid() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			IMBResp errorResponse = MBAppUtils.createErrorResp(mbSession.getOrigin(), e, ServiceConstants.CPP_OPEN_TD_SERVICE, httpServletRequest);
			return errorResponse;
		}
		catch (Exception e)
		{
			Logger.error("CPP:Exception Inside getFundFromAndInterestPaid() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			BusinessException exp = new BusinessException(BusinessException.SYSTEM_UNAVILABLE);
			IMBResp errorResponse = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, ServiceConstants.CPP_OPEN_TD_SERVICE, httpServletRequest);
			return errorResponse;
		} finally
		{
			endPerformanceLog(performanceLogger, logName);
		}
	}		
	
	@RequestMapping(value="showInterestRates", method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public IMBResp showInterestRates(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse,
			@RequestBody final TDGetRatesReq tdRatesReq)
	{
		Logger.debug("CPP: showInterestRates :: START", this.getClass());
		
		PerformanceLogger performanceLogger = new PerformanceLogger();		
		String logName = startPerformanceLog(performanceLogger, httpServletRequest);
		
		MobileSession mbSession =  null;
        IBankCommonData ibankCommonData = null;
        
        TDGetRates tdGetRatesObj = null;
		CustomerPricingTdDetails customerPricingTdDetails = null;
        List <TermDepositProducts>termDepositProdSess = null;
        boolean isRenewal = false;
        
        // currentrollOverDate of renewal account, would be null for origination
        Date currentrollOverDate = null;
        
		try {
			mbSession = mbAppHelper.getMobileSession(httpServletRequest);
			validateRequestHeader( tdRatesReq.getHeader(), httpServletRequest );
			ErrorResp errorResp = validate(tdRatesReq, httpServletRequest);
			if (errorResp != null && errorResp.getErrors() != null && errorResp.getErrors().size() > 0)
			   return errorResp;
			
			ibankCommonData = mbAppHelper.populateIBankCommonData(mbSession, httpServletRequest);
			Customer customer = ibankCommonData.getCustomer();
			
			isRenewal= tdRatesReq.getIsRenew();
			Logger.debug("CPP : showInterestRates - isRenewal"+isRenewal, this.getClass());
			
			//Populate the vo from the request
			tdGetRatesObj = new TDGetRates();				
			tdGetRatesObj.setTdaAmount(new BigDecimal(tdRatesReq.getTdaAmount()));
			tdGetRatesObj.setTdaTerm(tdRatesReq.getTdaTerm());
			tdGetRatesObj.setTdaInterestFrequency(tdRatesReq.getTdaInterestPaid());
			if(tdRatesReq.getRenewalAmount()!=null)
				tdGetRatesObj.setRenewalAmount(new BigDecimal(tdRatesReq.getRenewalAmount()));	
						

			//Check if amount is changed
			boolean isChangeInAmount = tdHelper.isChangeInAmount(mbSession.getTermDepositAmount(), new BigDecimal(tdRatesReq.getTdaAmount()));
			
			if(mbSession.getTermDepositAmount()== null || isChangeInAmount || mbSession.getCustomerPricingTdDetails()== null || 
					mbSession.getSelectedAccountIndex() == null || !mbSession.getSelectedAccountIndex().equals(tdRatesReq.getActIndx())) {
				
				Logger.debug("CPP : showInterestRates - either this is first time or ampount is changed - calling get holding /get Price API", this.getClass());
					
				//setting investment amount in session
				mbSession.setTermDepositAmount(tdGetRatesObj.getTdaAmount());			
				mbSession.setTermDepositIntFrequency(tdGetRatesObj.getTdaInterestFrequency());
				mbSession.setSelectedAccountIndex(tdRatesReq.getActIndx());
				
				Account selectedAccount = null;
				boolean isFundExternally = false;				
				int addWithdrawIndicator = TermDepositConstants.NO_TRANSFER_INDICATOR;				
				String selAccountindex = null;
				
				List<TermDepositCustomer>termDepositCustomers = new ArrayList<TermDepositCustomer>() ;
				

				if(isRenewal) {
					Logger.debug("CPP : showInterestRates - for renewal", this.getClass());
					
					selAccountindex = tdRatesReq.getActIndx(); // This is account index and NOT array index
					addWithdrawIndicator = tdRatesReq.getRenewalOption().intValue();
					
					mbSession.setTermDepositTransferAmount(new BigDecimal(tdRatesReq.getRenewalAmount()));
					
					if(null == selAccountindex){
						Logger.debug("CPP : showInterestRates - for renewal - use existing case", this.getClass());
					}
					else if(TermDepositConstants.FUND_EXTERNALLY.equalsIgnoreCase(selAccountindex)){
						Logger.debug("CPP : showInterestRates - for renewal - Add with fund externally", this.getClass());
						isFundExternally = true;
					}else{
						Logger.debug("CPP : showInterestRates - for renewal - Add Internally /Withdraw ", this.getClass());
						
						Collection<Account> accountList = null;
						switch (addWithdrawIndicator) {
					        case TermDepositConstants.ADD_INDICATOR :
					        	accountList = termDepositService.getFundingAccounts(ibankCommonData);		
					            break;
					        case TermDepositConstants.WITHDRAWL_INDICATOR :
					        	List<Account> customerAllAccountsList = mbSession.getCustomer().getAccounts();
					        	accountList = AccountFilter.getTermDepDepositToAccounts(customerAllAccountsList);
					            break;
					        default:
					            break;
						}
						
						selectedAccount = tdHelper.getSelectedAccount(accountList,selAccountindex);
					}
					
					
			        TermDepositAccount tdaAccount = (TermDepositAccount)mbSession.getSelectedAccount();
			        tdGetRatesObj.setSelectedTdAccount(tdaAccount);
										
					//set currentrollOverDate only for renewal
					if(null != tdaAccount.getTermDepositAdditionalInfo() && null != tdaAccount.getTermDepositAdditionalInfo().getRollOverDate())
						currentrollOverDate = tdaAccount.getTermDepositAdditionalInfo().getRollOverDate();					
					
					tdGetRatesObj.setCurrentrollOverDate(currentrollOverDate);
					
					//primary owner check
					String primaryOwnerGcis = customerPricingService.getPrimaryOwner(ibankCommonData, tdaAccount,termDepositCustomers);
					tdGetRatesObj.setPrimaryGcis(primaryOwnerGcis);					
					
				}else{
					Logger.debug("CPP : showInterestRates - for origination", this.getClass());
					selAccountindex = tdRatesReq.getSelSourceAcct(); // This is account index and NOT array index
					if(TermDepositConstants.FUND_EXTERNALLY.equalsIgnoreCase(selAccountindex)) {
						Logger.debug("CPP : showInterestRates - for Origination - fund externally", this.getClass());
						isFundExternally = true;
					}else {
						Logger.debug("CPP : showInterestRates - for Origination - fund internally", this.getClass());
						Collection<Account> accountList = termDepositService.getFundingAccounts(ibankCommonData);						
						selectedAccount = tdHelper.getSelectedAccount(accountList,selAccountindex);
					}
					tdGetRatesObj.setPrimaryGcis(ibankCommonData.getCustomer().getGcis());
					
					TermDepositCustomer tdCust = new TermDepositCustomer();
					tdCust.setGcis(customer.getGcis());
					tdCust.setFirstName(customer.getFirstName());
					tdCust.setLastName(customer.getLastName());
					tdCust.setCustTypeInd(customer.getCustTypeInd());
					tdCust.setPrimary(true);
					termDepositCustomers.add(tdCust);
					
				}
				
				tdGetRatesObj.setSelectedAccount(selectedAccount);
				tdGetRatesObj.setFundExternally(isFundExternally);
				tdGetRatesObj.setAddWithdrawInd(addWithdrawIndicator);
				tdGetRatesObj.setFcastInterestAmount(mbSession.getTermDepositFcastInterestAmount());
				tdGetRatesObj.setTermDepositCustomers(termDepositCustomers);

				//WDP API call to get rates
				UUID appCorrelationId = WDPServiceHelper.generateAppCorrelationId();
				
				customerPricingTdDetails = customerPricingService.getRates(ibankCommonData, appCorrelationId, tdGetRatesObj, isRenewal);
				
				//saving wdp api get rates response in session.
				if(null!= mbSession.getCustomerPricingTdDetails()){
					Logger.debug("CPP : mb session has cached get Rates. Removing from session before adding updated resp..", this.getClass());
					mbSession.removeCustomerPricingTdDetails();
				}			
				mbSession.setCustomerPricingTdDetails(customerPricingTdDetails);
			}
			else {
				Logger.debug("CPP: showInterestRates :: isChangeInAmount: "+isChangeInAmount+" Iterate through the cached rates", this.getClass());
				if(null!= mbSession.getCustomerPricingTdDetails()){
					customerPricingTdDetails = mbSession.getCustomerPricingTdDetails();
				}							
			}
			
			//Populating termDepositProdSess to filter and sorting.
			if(null!= customerPricingTdDetails){
				termDepositProdSess= new ArrayList<TermDepositProducts>();
				termDepositProdSess.addAll(customerPricingTdDetails.getTermDepositRates());
			}
			
			//Filtering get price
			List<TermDepositProducts> filteredResponse = CustomerPricingServiceHelper.filterOnInterestFrequency(termDepositProdSess, InterestPaidEnum.valueOf(tdGetRatesObj.getTdaInterestFrequency()).getLabel());		
			if(filteredResponse==null || filteredResponse.size()==0)
				throw new BusinessException(BusinessException.CPP_RATES_NOT_RETRIEVED);
			
			String subProductCode = customerPricingService.getSubProductCode(tdGetRatesObj, ibankCommonData);
			updateFileredResponse(filteredResponse, subProductCode, false);
			//Sort filtered response
			List<TermDepositDetails> sortRatesResp = customerPricingService.sortRates(ibankCommonData, filteredResponse, tdGetRatesObj);
			
			//update maturity date for each rate
			tdHelper.updateMaturityDate(sortRatesResp, currentrollOverDate);
			
			//save isCardedRate as False in session
			mbSession.setCardedRate(Boolean.FALSE);
			//populate resp
			IMBResp serviceResponse = tdHelper.populategetRatesResp(sortRatesResp, null, ibankCommonData);
			
			// Populate the response header
			RespHeader headerResp = populateResponseHeader(ServiceConstants.CPP_OPEN_TD_SERVICE, mbSession);
			serviceResponse.setHeader(headerResp);
			
			return serviceResponse;
		} catch (BusinessException e) {
			Logger.debug("CPP : BusinessException Inside showInterestRates() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
            return getCardedRates(tdGetRatesObj, ibankCommonData, httpServletRequest, mbSession, e);
		}catch (Exception e){	
			Logger.debug("CPP : Exception Inside showInterestRates() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			BusinessException exp = new BusinessException(BusinessException.CPP_RATES_NOT_RETRIEVED);
			return getCardedRates(tdGetRatesObj, ibankCommonData, httpServletRequest, mbSession, exp);
		}finally{
			endPerformanceLog(performanceLogger, logName);
			Logger.debug("CPP: showInterestRates :: END", this.getClass());			
		}	
	}
	
	private void updateFileredResponse(List<TermDepositProducts> termDepositProducts, String subProductCode, boolean isCardedRate){
		for(TermDepositProducts product : termDepositProducts){
			product.setSubProductCode(subProductCode);
			product.setCardedRate(isCardedRate);
		}
	}
	
    private IMBResp getCardedRates(TDGetRates tdGetRatesVO, IBankCommonData commonData, HttpServletRequest httpServletRequest, MobileSession mbSession, BusinessException e){
        IMBResp serviceResponse = null;
        try{
        	List<TermDepositProducts> ratesResponse = customerPricingService.getCardedRates(tdGetRatesVO, commonData);
        	List <TermDepositDetails> tdRateDetails = CustomerPricingServiceHelper.sortRates(ratesResponse,tdGetRatesVO);
        	
        	//update maturity date for each rate
        	tdHelper.updateMaturityDate(tdRateDetails, tdGetRatesVO.getCurrentrollOverDate());
        	
        	//Save isCardedRate as True in session
        	mbSession.setCardedRate(Boolean.TRUE);
        	
        	serviceResponse = tdHelper.populategetRatesResp(tdRateDetails, e, commonData);
        	RespHeader headerResp = populateResponseHeader(ServiceConstants.CPP_OPEN_TD_SERVICE, mbSession);
			serviceResponse.setHeader(headerResp);
        }catch(BusinessException exp){
        	Logger.debug("CPP: Exception while retrieving  carded rate" + exp.getMessage(), this.getClass());        	
        	serviceResponse = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, ServiceConstants.CPP_OPEN_TD_SERVICE, httpServletRequest);
        }catch(Exception ex){
        	Logger.debug("CPP: Exception while retrieving  carded rate " + ex.getMessage(), this.getClass());
        	BusinessException exp = new BusinessException(BusinessException.SYSTEM_UNAVILABLE);
        	serviceResponse = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, ServiceConstants.CPP_OPEN_TD_SERVICE, httpServletRequest);		
        }
        return serviceResponse;
    }


	/**
	 *  This method will be called when customer clicks on "Renew now" link (blue banner)
	 *  on the dash board or account details page.<br><br>
	 *  
	 *  There will be three API calls to fetch offer details when customer opts to renew the FD with NO changes -
	 *   
	 *  <li>Get primary owner</li>
	 *  <li>Get holdings</li>
	 *  <li>Get price</li>
	 *  <br>
	 * 
	 * @param httpServletRequest
	 * @param httpServletResponse
	 * @return IMBResp
	 */
	@RequestMapping(value="renewalDetails", method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public IMBResp renewalDetails(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, @RequestBody final TDRenewalReq tdRenewRequest)
	{
		Logger.debug("CPP: renewalDetails :: START", this.getClass());

		PerformanceLogger performanceLogger = new PerformanceLogger();		
		String logName = startPerformanceLog(performanceLogger, httpServletRequest);
		
		MobileSession mbSession =  null;
		String origin = null;
		try{			
			mbSession = mbAppHelper.getMobileSession(httpServletRequest);	
			mbSession.removeSelectedAccount(); //clearing seleceted account from session if any.
			
			validateRequestHeader( tdRenewRequest.getHeader(), httpServletRequest );
				
			ErrorResp errorResp = validate(tdRenewRequest, httpServletRequest);
			
			if (errorResp != null && errorResp.getErrors() != null && errorResp.getErrors().size() > 0)
				return errorResp;
								
			IBankCommonData commonData = mbAppHelper.populateIBankCommonData(mbSession, httpServletRequest);	
			origin = commonData.getOrigin();
			
			//Fetch the selected TD account
			Account selectedAccount = mbAppHelper.getAccountFromCustomer(mbSession.getCustomer(), tdRenewRequest.getRenewTDAIndex());		
			
			//Save in session for Renewal			
			//mbSession.setSelectedAccount(selectedAccount);
			
			//Fetch the TD account details - this will make a WMQI call
			TermDepositAccount tdaAccount = (TermDepositAccount)termDepositService.getTDAAccount(selectedAccount.getAccountId(), commonData);
			
			//19E3 - Warranty  - restrain check moved back to first page  
			//restraint check
			if("Y".equalsIgnoreCase(tdaAccount.getRestrainInd())){
				Logger.error("CPP : RenewalDetails - some restarint on this td account , Can not renew.", this.getClass());
				throw new BusinessException(BusinessException.CPP_RENEWAL_RESTAINT);
			}
			mbSession.setTermDepositFcastInterestAmount(tdaAccount.getTermDepositAdditionalInfo().getInterestAmount());
			
			//Add selected TD account to session for confirmation screen - for renewal flow
			mbSession.setSelectedAccount(tdaAccount);
			
			//Construct the response
			IMBResp serviceResponse = tdHelper.populateRenewAsISRatesResp(tdaAccount, commonData);
			
			//Populate the response header
			RespHeader headerResp = populateResponseHeader(ServiceConstants.CPP_OPEN_TD_SERVICE, mbSession);
	        serviceResponse.setHeader(headerResp);       
				        	
			return serviceResponse;
		} catch (BusinessException e){
			Logger.error("CPP : BusinessException Inside renewDetails() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			if(BusinessException.CPP_RENEWAL_RESTAINT == e.getKey()){
				String originHelpDeskPhone = null;
				String branchName = null;    							  
    			OriginsVO originVO = IBankParams.getOrigin(IBankParams.getBaseOriginCode(origin));	   			    			
    			if(null!=originVO){
    				originHelpDeskPhone=originVO.getPhone();
    				branchName = originVO.getName();
    			} 						
    			Object[] values = {branchName,originHelpDeskPhone};			
				return MBAppUtils.createErrorResp(mbSession.getOrigin(), e.getKey(), MessageFormat.format(MBAppUtils.getMessage(mbSession.getOrigin(), e.getKey()), values),
						ServiceConstants.CPP_OPEN_TD_SERVICE, httpServletRequest);
			}
			BusinessException exp = new BusinessException(BusinessException.SYSTEM_UNAVILABLE);
			IMBResp errorResponse = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, ServiceConstants.CPP_OPEN_TD_SERVICE, httpServletRequest);
			return errorResponse;
		} catch (Exception e){	
			Logger.error("CPP : Exception Inside renewDetails() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			BusinessException exp = new BusinessException(BusinessException.SYSTEM_UNAVILABLE);
			IMBResp errorResponse = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, ServiceConstants.CPP_OPEN_TD_SERVICE, httpServletRequest);
			return errorResponse;
		} finally{
			endPerformanceLog(performanceLogger, logName);
			Logger.debug("CPP: renewalDetails :: END", this.getClass());
		}
	}	
	
	@RequestMapping(value="reviewTDRenewal", method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public IMBResp reviewTDRenewal(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, @RequestBody final TDRenewalReq tdRenewRequest)
	{
		Logger.debug("CPP: reviewTDRenewal :: START", this.getClass());

		PerformanceLogger performanceLogger = new PerformanceLogger();		
		String logName = startPerformanceLog(performanceLogger, httpServletRequest);
		
		MobileSession mbSession =  null;
		String origin = null;
		try{			
			mbSession = mbAppHelper.getMobileSession(httpServletRequest);	
			mbSession.removeSelectedAccount(); //clearing seleceted account from session if any.
			
			validateRequestHeader( tdRenewRequest.getHeader(), httpServletRequest );
				
			ErrorResp errorResp = validate(tdRenewRequest, httpServletRequest);
			
			if (errorResp != null && errorResp.getErrors() != null && errorResp.getErrors().size() > 0)
				return errorResp;
								
			IBankCommonData commonData = mbAppHelper.populateIBankCommonData(mbSession, httpServletRequest);	
			origin = commonData.getOrigin();
			
			//Fetch the selected TD account
			Account selectedAccount = mbAppHelper.getAccountFromCustomer(mbSession.getCustomer(),tdRenewRequest.getRenewTDAIndex());
			
			//Fetch the TD account details - this will make a WMQI call
			TermDepositAccount tdaAccount = (TermDepositAccount)termDepositService.getTDAAccount(selectedAccount.getAccountId(), commonData);
			
			final String appReferenceId = IBankParams.getCodesMessage(IBankParams.DEFAULT_ORIGIN, IBankParams.CONFIGURATION_PROPERTIES, IBankParams.APPREFERENCE_ID);
			SecureRandom secureRandom = new SecureRandom();
			Double temp = secureRandom.nextDouble();
	  		Double secNum = new Double(temp * 10000);
	  		long secNo = secNum.longValue();
			
	  		Long appReferenceID = secNo + new Long(appReferenceId);
			 
			//19E3 - remove M from Origin in case of its IB-MB redirection
			if(null != mbSession && null != mbSession.getState()){
				if(mbSession.getState().equals(MBAppConstants.STATE_MOBILE)){
					termDepositService.reviewTDRenewal(tdaAccount,commonData,true,appReferenceID.toString());
				}				
			}
			else {
				termDepositService.reviewTDRenewal(tdaAccount,commonData,false,appReferenceID.toString());
			}
			
			//Construct the response
			SuccessResp serviceResponse = new SuccessResp();
			serviceResponse.setIsSuccess(true);
			
			//Populate the response header
			RespHeader headerResp = populateResponseHeader(ServiceConstants.CPP_OPEN_TD_SERVICE, mbSession);
	        serviceResponse.setHeader(headerResp);       
				        	
			return serviceResponse;
		} catch (Exception e){	
			Logger.error("CPP : Exception Inside reviewTDRenewal() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			BusinessException exp = new BusinessException(BusinessException.SYSTEM_UNAVILABLE);
			IMBResp errorResponse = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, ServiceConstants.CPP_OPEN_TD_SERVICE, httpServletRequest);
			return errorResponse;
		} finally{
			endPerformanceLog(performanceLogger, logName);
			Logger.debug("CPP: reviewTDRenewal :: END", this.getClass());
		}
	}
	
	@RequestMapping(value="makeChangesAndRenew", method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public IMBResp makeChangesAndRenew(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, @RequestBody final EmptyReq emptyReq)	
	{
		Logger.debug("CPP: makeChangesAndRenew :: START", this.getClass());
		PerformanceLogger performanceLogger = new PerformanceLogger();		
		String logName = startPerformanceLog(performanceLogger, httpServletRequest);
		MobileSession mbSession =  null;
		TFNCheckResp tfnCheck=null;
		
		try {
			mbSession = mbAppHelper.getMobileSession(httpServletRequest);	
			
			validateRequestHeader( emptyReq.getHeader(), httpServletRequest );
			
			IBankCommonData ibankCommonData = mbAppHelper.populateIBankCommonData(mbSession, httpServletRequest);				
			
			List<Account> customerAllAccountsList = mbSession.getCustomer().getAccounts();
			Collection<Account> fundFromAcctList = termDepositService.getFundingAccounts(ibankCommonData);			
			Collection<Account> depositToAcctList = AccountFilter.getTermDepDepositToAccounts(customerAllAccountsList);
			
			Collection<Account> paidToInterestAccountsList = AccountFilter.getTermDepositPaidToInterestAccounts(mbSession.getCustomer().getAccounts());
			
			Collection<RegionVO> regions = null;
			if (MBAppConstants.ORIGIN_MBSA.equals(ibankCommonData.getOrigin())  || "BSGD".equalsIgnoreCase(ibankCommonData.getOrigin())
					|| "BSA".equalsIgnoreCase(ibankCommonData.getOrigin()))
			{
				regions = openDDAService.getRegion();
			}
			
			//19E3 TFN code
			Boolean showTfn = tfnHelper.showTfn(ibankCommonData,mbSession);
			
			if(null!= showTfn){
				if(showTfn){
					Logger.debug("TDController - populating tfn widget properties:START", this.getClass());
					//populate the response
					tfnCheck = new TFNCheckResp();
					tfnCheck.setExemptionList(tfnHelper.getTFNExemptOptList());
					tfnCheck.setTfnOptionList(tfnHelper.getTFNOptionList());	
				}else
					Logger.debug("TDController - Customer has already provided TFN ", this.getClass());			
			}else{
				Logger.debug("TDController - TFN switch is OFF.. no widget", this.getClass());
			}
			
			//set showTfn irrespective true or false to avoid null pointer in openTermDepositAccount method.
			mbSession.setShowTfn(showTfn);
			
			// Populate the response
			IMBResp serviceResponse = tdHelper.populateTDResponse(tfnCheck,fundFromAcctList, mbSession.getCustomer() ,depositToAcctList,paidToInterestAccountsList,regions,null,null);
			
			// Populate the response header
			RespHeader headerResp = populateResponseHeader(ServiceConstants.CPP_OPEN_TD_SERVICE, mbSession);
			serviceResponse.setHeader(headerResp);
			ObjectMapper mapper = new ObjectMapper();
			Logger.info("CPP: makeChangesAndRenew JSON Response :" + mapper.writeValueAsString(serviceResponse), this.getClass());
		    return serviceResponse;
		}catch (BusinessException e) {
			Logger.error("CPP : BusinessException Inside makeChangesAndRenew() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			IMBResp errorResponse = MBAppUtils.createErrorResp(mbSession.getOrigin(), e, ServiceConstants.CPP_OPEN_TD_SERVICE, httpServletRequest);
			return errorResponse;
			
		}catch (Exception e){	
			Logger.error("CPP : Exception Inside makeChangesAndRenew() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			BusinessException exp = new BusinessException(BusinessException.SYSTEM_UNAVILABLE);
			IMBResp errorResponse = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, ServiceConstants.CPP_OPEN_TD_SERVICE, httpServletRequest);
			return errorResponse;
		}finally{
			endPerformanceLog(performanceLogger, logName);
			Logger.debug("CPP: makeChangesAndRenew :: END", this.getClass());			
		
		}
	}	
	
	@RequestMapping(value="getBranches", method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public IMBResp getBranches(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse,@RequestBody final TDReq tdReq)	
	{
		Logger.debug("CPP: getBranches :: START", this.getClass());
		PerformanceLogger performanceLogger = new PerformanceLogger();		
		String logName = startPerformanceLog(performanceLogger, httpServletRequest);
		MobileSession mbSession =  null;
		
		try {
			mbSession = mbAppHelper.getMobileSession(httpServletRequest);	
			
			validateRequestHeader( tdReq.getHeader(), httpServletRequest );
			
			ErrorResp errorResp = validate(tdReq, httpServletRequest);
			
			if (errorResp != null && errorResp.getErrors() != null && errorResp.getErrors().size() > 0)
				return errorResp;			
			
			List<BranchVO> branches = openDDAService.getBranch(tdReq.getRegionId());
			
			// Populate the response
			IMBResp serviceResponse = tdHelper.populateTDResponse(null,null, mbSession.getCustomer() ,null,null,null,branches,null);
			
			// Populate the response header
			RespHeader headerResp = populateResponseHeader(ServiceConstants.CPP_OPEN_TD_SERVICE, mbSession);
			serviceResponse.setHeader(headerResp);
			ObjectMapper mapper = new ObjectMapper();
			Logger.info("CPP: getBranches JSON Response :" + mapper.writeValueAsString(serviceResponse), this.getClass());
		    return serviceResponse;
		}
		catch (BusinessException e) {
			Logger.error("CPP : BusinessException Inside getBranches() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			IMBResp errorResponse = MBAppUtils.createErrorResp(mbSession.getOrigin(), e, ServiceConstants.CPP_OPEN_TD_SERVICE, httpServletRequest);
			return errorResponse;
			
		}catch (Exception e){	
			Logger.error("CPP : Exception Inside getBranches() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			BusinessException exp = new BusinessException(BusinessException.SYSTEM_UNAVILABLE);
			IMBResp errorResponse = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, ServiceConstants.CPP_OPEN_TD_SERVICE, httpServletRequest);
			return errorResponse;
		}finally{
			endPerformanceLog(performanceLogger, logName);
			Logger.debug("CPP: getBranches :: END", this.getClass());			
		
		}
	}
	
	@RequestMapping(value="getBranchAddress", method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public IMBResp getBranchAddress(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse,@RequestBody final TDReq tdReq)	
	{
		Logger.debug("CPP: getBranchAddress :: START", this.getClass());
		PerformanceLogger performanceLogger = new PerformanceLogger();		
		String logName = startPerformanceLog(performanceLogger, httpServletRequest);
		MobileSession mbSession =  null;
		
		try {
			mbSession = mbAppHelper.getMobileSession(httpServletRequest);	
			
			validateRequestHeader( tdReq.getHeader(), httpServletRequest );
			
			ErrorResp errorResp = validate(tdReq, httpServletRequest);
			
			if (errorResp != null && errorResp.getErrors() != null && errorResp.getErrors().size() > 0)
				return errorResp;			
			
			List<BranchVO> branches = openDDAService.getBranch(tdReq.getRegionId());
			BranchVO branch = tdHelper.getBranch(branches, tdReq.getBranchId());
			
			// Populate the response
			IMBResp serviceResponse = tdHelper.populateTDResponse(null,null, mbSession.getCustomer() ,null,null,null,null,branch);
			
			// Populate the response header
			RespHeader headerResp = populateResponseHeader(ServiceConstants.CPP_OPEN_TD_SERVICE, mbSession);
			serviceResponse.setHeader(headerResp);
			ObjectMapper mapper = new ObjectMapper();
			Logger.info("CPP: getBranchAddress JSON Response :" + mapper.writeValueAsString(serviceResponse), this.getClass());
		    return serviceResponse;
		}
		catch (BusinessException e) {
			Logger.error("CPP : BusinessException Inside getBranchAddress() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			IMBResp errorResponse = MBAppUtils.createErrorResp(mbSession.getOrigin(), e, ServiceConstants.CPP_OPEN_TD_SERVICE, httpServletRequest);
			return errorResponse;
			
		}catch (Exception e){	
			Logger.error("CPP : Exception Inside getBranchAddress() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			BusinessException exp = new BusinessException(BusinessException.SYSTEM_UNAVILABLE);
			IMBResp errorResponse = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, ServiceConstants.CPP_OPEN_TD_SERVICE, httpServletRequest);
			return errorResponse;
		}finally{
			endPerformanceLog(performanceLogger, logName);
			Logger.debug("CPP: getBranchAddress :: END", this.getClass());			
		
		}
	}


	@RequestMapping(value="showConfirmation", method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public IMBResp showConfirmation(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, @RequestBody final TDTermReq req)	
	{
		Logger.debug("CPP: showConfirmation :: START", this.getClass());
		
		PerformanceLogger performanceLogger = new PerformanceLogger();		
		String logName = startPerformanceLog(performanceLogger, httpServletRequest);
		
		MobileSession mbSession =  null;
		boolean isRenewal = false;
		
		try {
			mbSession = mbAppHelper.getMobileSession(httpServletRequest);	
			
			validateRequestHeader( req.getHeader(), httpServletRequest );
			
			ErrorResp errorResp = validate(req, httpServletRequest);
			
			if (errorResp != null && errorResp.getErrors() != null && errorResp.getErrors().size() > 0)
				return errorResp;			
			
			
			TermDepositAccount selectedAccount = null;
						
			String term = req.getTdTerm(); 
			isRenewal= req.getIsRenew();
						
			//Populate the maturity date
			Date maturityDate = null;
			if(isRenewal){
				//Fetch the selected TD account from session
				selectedAccount = (TermDepositAccount) mbSession.getSelectedAccount();
				//renewal date
				Date currentrollOverDate = selectedAccount.getTermDepositAdditionalInfo()!= null ? selectedAccount.getTermDepositAdditionalInfo().getRollOverDate() : null;
				maturityDate = tdHelper.getMaturityDate(term ,currentrollOverDate);
				Logger.debug("CPP: showConfirmation - renewal maturity date:"+maturityDate.toString(), this.getClass());
			}				
			else{
				//origination
				maturityDate = tdHelper.getMaturityDate(term ,null);
				Logger.debug("CPP: showConfirmation - Origination maturity date:"+maturityDate.toString(), this.getClass());
			}
			
			
			//Populate the response
			IMBResp serviceResponse = tdHelper.populateConfirmationResponse(maturityDate, selectedAccount, mbSession.getCustomer().getAccounts());
			
			//Populate the response header
			RespHeader headerResp = populateResponseHeader(ServiceConstants.CPP_OPEN_TD_SERVICE, mbSession);
			serviceResponse.setHeader(headerResp);
			
			//Log the response
			ObjectMapper mapper = new ObjectMapper();
			Logger.info("CPP: showConfirmation JSON Response : " + mapper.writeValueAsString(serviceResponse), this.getClass());
			
			//Remove the selected account from session
			//mbSession.removeSelectedAccount();
			
		    return serviceResponse;
		}
		catch (BusinessException e) {
			Logger.error("CPP : BusinessException Inside showConfirmation() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] : ", e, this.getClass());
			IMBResp errorResponse = MBAppUtils.createErrorResp(mbSession.getOrigin(), e, ServiceConstants.CPP_OPEN_TD_SERVICE, httpServletRequest);
			return errorResponse;
			
		}catch (Exception e){	
			Logger.error("CPP : Exception Inside showConfirmation() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] : ", e, this.getClass());
			BusinessException exp = new BusinessException(BusinessException.SYSTEM_UNAVILABLE);
			IMBResp errorResponse = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, ServiceConstants.CPP_OPEN_TD_SERVICE, httpServletRequest);
			return errorResponse;
		}finally{
			endPerformanceLog(performanceLogger, logName);
			Logger.debug("CPP: showConfirmation :: END", this.getClass());
		}
	}
	
	@RequestMapping(value="interestFrequency", method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public IMBResp getInterestFrequency(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse,  @RequestBody final TDTermReq req)
	{
		Logger.debug("CPP: In getInterestFrequency TDController  " +  "  " + httpServletRequest.getContentType() + " "
				+ httpServletRequest.getRemoteAddr() + "  " + httpServletResponse.getCharacterEncoding() + httpServletResponse.getLocale() +
				" True IP >> " + httpServletRequest.getHeader(IBankParams.trueClientIP()), this.getClass());

		PerformanceLogger performanceLogger = new PerformanceLogger();		
		String logName = startPerformanceLog(performanceLogger, httpServletRequest);
		
		MobileSession mbSession =  null;
		try
		{
			mbSession = mbAppHelper.getMobileSession(httpServletRequest);
			
			validateRequestHeader( req.getHeader(), httpServletRequest );
			
			ErrorResp errorResp = validate(req, httpServletRequest);
			
			if (errorResp != null && errorResp.getErrors() != null && errorResp.getErrors().size() > 0)
				return errorResp;	
			
			List<CodesVO> termFrequencyList = ((List<CodesVO>)(IBankParams.getCodesDataList("ALL", "CPPTermFrequencyMap"))); 	
			
			IMBResp serviceResponse = tdHelper.populateTDInterestFreqResp(req.getTdTerm(),termFrequencyList);
			
			ObjectMapper mapper = new ObjectMapper();
			Logger.info("CPP: getInterestFrequency JSON Response :" + mapper.writeValueAsString(serviceResponse), this.getClass());
			RespHeader headerResp = populateResponseHeader(ServiceConstants.CPP_OPEN_TD_SERVICE, mbSession);
			serviceResponse.setHeader(headerResp);
			return serviceResponse;
		} catch (BusinessException e)
		{
			Logger.error("CPP:Exception Inside getInterestFrequency() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			IMBResp errorResponse = MBAppUtils.createErrorResp(mbSession.getOrigin(), e, ServiceConstants.CPP_OPEN_TD_SERVICE, httpServletRequest);
			return errorResponse;
		}
		catch (Exception e)
		{
			Logger.error("CPP:Exception Inside getInterestFrequency() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			BusinessException exp = new BusinessException(BusinessException.SYSTEM_UNAVILABLE);
			IMBResp errorResponse = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, ServiceConstants.CPP_OPEN_TD_SERVICE, httpServletRequest);
			return errorResponse;
		} finally
		{
			endPerformanceLog(performanceLogger, logName);
		}
	}	
	
	
	@RequestMapping(value="sessionCleanup", method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public IMBResp cleanSession(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse)
	{
		Logger.debug("CPP: In sessionCleanup TDController  " +  "  " + httpServletRequest.getContentType() + " "
				+ httpServletRequest.getRemoteAddr() + "  " + httpServletResponse.getCharacterEncoding() + httpServletResponse.getLocale() +
				" True IP >> " + httpServletRequest.getHeader(IBankParams.trueClientIP()), this.getClass());

		PerformanceLogger performanceLogger = new PerformanceLogger();		
		String logName = startPerformanceLog(performanceLogger, httpServletRequest);
		
		MobileSession mbSession =  null;
		try
		{
			mbSession = mbAppHelper.getMobileSession(httpServletRequest);
			
			//Session cleanup
			if(null!= mbSession){
				mbSession.removeCustomerPricingTdDetails();
				mbSession.removeTermDepositAmount();
				mbSession.removeTermDepositFcastInterestAmount();
				mbSession.removeCardedRate();
				mbSession.removeTermDepositTransferAmount();
				mbSession.removeTermDepositIntFrequency();
				mbSession.removeShowTfn();
				mbSession.setSelectedAccountIndex(null);

			}
						
			SuccessResp successResp = new SuccessResp();																			
			RespHeader headerResp = populateResponseHeader(ServiceConstants.CPP_OPEN_TD_SERVICE, mbSession);
			successResp.setHeader(headerResp);
			successResp.setIsSuccess(true);
			return successResp;
			
		} catch (BusinessException e)
		{
			Logger.error("CPP:Exception Inside sessionCleanup() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			IMBResp errorResponse = MBAppUtils.createErrorResp(mbSession!= null ? mbSession.getOrigin():"", e, ServiceConstants.CPP_OPEN_TD_SERVICE, httpServletRequest);
			return errorResponse;
		}
		catch (Exception e)
		{
			Logger.error("CPP:Exception Inside sessionCleanup() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			BusinessException exp = new BusinessException(BusinessException.SYSTEM_UNAVILABLE);
			IMBResp errorResponse = MBAppUtils.createErrorResp(mbSession!= null ? mbSession.getOrigin():"", exp, ServiceConstants.CPP_OPEN_TD_SERVICE, httpServletRequest);
			return errorResponse;
		} finally
		{
			endPerformanceLog(performanceLogger, logName);
		}
	}	
	
	@RequestMapping(value="openTermDepositAccount", method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public IMBResp openTermDepositAccount(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse,
			@RequestBody final TDOpenAcctReq tdOpenAcctReq)
	{
		Logger.debug("CPP: openTermDepositAccount :: START", this.getClass());
		
		PerformanceLogger performanceLogger = new PerformanceLogger();		
		String logName = startPerformanceLog(performanceLogger, httpServletRequest);
		
		MobileSession mbSession =  null;
		CustomerPricingTdDetails customerPricingTdDetails = null;
		TermDepositProducts termDepositProduct = null;
		String pricingOfferId = null;
		IMBResp serviceResponse = null;
		
		try { 

			mbSession = mbAppHelper.getMobileSession(httpServletRequest);	
			
			validateRequestHeader( tdOpenAcctReq.getHeader(), httpServletRequest );
			
			ErrorResp errorResp = validate(tdOpenAcctReq, httpServletRequest);
			
			if (errorResp != null && errorResp.getErrors() != null && errorResp.getErrors().size() > 0)
				return errorResp;			
			
			IBankCommonData ibankCommonData = mbAppHelper.populateIBankCommonData(mbSession, httpServletRequest);	
			
			//19E3 Changes
			//if switch is On and !tfnheld - then get values from req and do validation
			Boolean statUpdTfn=false;
			Boolean showTfn = mbSession.getShowTfn();
			
			if(showTfn!=null){
				if(showTfn){
					//trigger validations
					 Logger.debug("TDController - openTermDepositAccount - validations", this.getClass());
					 if(!tdOpenAcctReq.getSelectedOption().equals("1")){
					    tfnHelper.validateTFN(tdOpenAcctReq.getSelectedOption(),tdOpenAcctReq.getTaxFileNumber(),tdOpenAcctReq.getSelectedExemption());
					    statUpdTfn = tfnHelper.updateTFN(ibankCommonData,tdOpenAcctReq.getSelectedOption(),tdOpenAcctReq.getTaxFileNumber(),tdOpenAcctReq.getSelectedExemption());
					    Logger.debug("TDController - TFN update :"+statUpdTfn, this.getClass());
					    // Remove showTfn from session
						mbSession.removeShowTfn();
				      } 
				}else{
					Logger.debug("TDController this condition gets executed when TFN widget was not shown and TFN was already submitted previously::", this.getClass());
					  statUpdTfn=true;
	 			}				 
             }
			
			if(null!= mbSession && null!= mbSession.getCustomerPricingTdDetails()){
				Logger.debug("CPP TD : Customer has selected CPP rate. Iterating over list in session.", this.getClass());
				customerPricingTdDetails = mbSession.getCustomerPricingTdDetails();
				List<TermDepositProducts> termDepositList = customerPricingTdDetails.getTermDepositRates();
				for(TermDepositProducts tdProduct : termDepositList){
					if(tdProduct.getTermDepositProductIndex() == tdOpenAcctReq.getTermDepositProductIndex()){
							termDepositProduct = tdProduct;
							break;
						}
				} 

				pricingOfferId = customerPricingTdDetails.getPricingOfferId();
			}
			
			if(null!= mbSession && Boolean.TRUE.equals(mbSession.isCardedRate()) && null == termDepositProduct){
				Logger.debug("CPP TD : Customer has selected Carded rate.", this.getClass());
				termDepositProduct = customerPricingService.getSelectedCardedRate(ibankCommonData ,tdOpenAcctReq.getTermDepositProductIndex() );
			}
					
			NewTermDepositAccount account = tdHelper.populateNewTermDepositAccount(mbSession, tdOpenAcctReq, ibankCommonData,termDepositProduct,statUpdTfn);
			ArrayList duplicateAcctOpeningList = checkDuplicateAcctOpeningReq(ibankCommonData, termDepositProduct.getSubProductCode());
			
			if(duplicateAcctOpeningList!=null && duplicateAcctOpeningList.size() > getTDMaxAcctOpeningReq()){
				serviceResponse = tdHelper.populateDuplicateAcctsList(mbSession, duplicateAcctOpeningList, mbSession.getSecurityUniqueID());
			}else{
			NewTermDepositAccount newDDAAccount = (NewTermDepositAccount) termDepositService.openAccount(account, termDepositProduct, pricingOfferId, ibankCommonData);
			
			if(newDDAAccount.getReceipt()!=null) {
				Logger.debug("CPP: openTermDepositAccount termDepositService.openAccount is successfull with ReceiptNumber: "+newDDAAccount.getReceipt().getReceiptNumber()
					+" and NewAcctNumber: "+newDDAAccount.getNewAcctNumber(), this.getClass());
				
			
			}
			else {
				Logger.debug("CPP: openTermDepositAccount termDepositService.openAccount is successfull with Status: "+newDDAAccount.getAcctOpenStatus()
						, this.getClass());
			}
			
			// Call the update quote API only for CPP rates
			if((null!= mbSession && Boolean.FALSE.equals(mbSession.isCardedRate())) && null!= newDDAAccount.getNewAcctNumber()){
				Logger.debug("CPP : Calling Update quote for CPP rates .", this.getClass());
				customerPricingService.updateQuote(ibankCommonData, WDPServiceHelper.generateAppCorrelationId(), newDDAAccount.getNewAcctNumber(), pricingOfferId, true);
			}else{
				Logger.debug("CPP : Not calling Update Quote - either rates are carded or account is NOT opened", this.getClass());
			}
			
			
			// Call service to check TFN
			Boolean tfnHeld = null;
			Boolean tfnExemption = null;
			if(!IBankParams.isSwitchOn(ibankCommonData.getOrigin(), IBankParams.TFN_SWITCH)){
				        tfnHeld =false;
				        tfnExemption=false;
				        Customer customer = mbSession.getCustomer();
						String description = TaxFileNumberService.getTFNDescription(customer);
						
						if (description.equalsIgnoreCase(TaxFileNumberService.TAX_FILE_NUMBER_HELD))
							tfnHeld = true;
						else if (description.equalsIgnoreCase(TaxFileNumberService.FOREIGN_EXEMPTION))
							tfnExemption = true;
			}
			//Session cleanup
			cleanMBSession(mbSession);
			
		
			
			//Populate the response
			
			serviceResponse = tdHelper.populateopenTDAAccountResp(newDDAAccount,ibankCommonData.getOrigin(),tfnHeld,tfnExemption);
			
			//Populate the response header
			RespHeader headerResp = populateResponseHeader(ServiceConstants.CPP_OPEN_TD_SERVICE, mbSession);
			serviceResponse.setHeader(headerResp);
			
			//Log the response	
			ObjectMapper mapper = new ObjectMapper();
			Logger.info("CPP: openTermDepositAccount JSON Response : " + mapper.writeValueAsString(serviceResponse), this.getClass());
			
			if(null != mbSession && null != mbSession.getState()){
				if(mbSession.getState().equals(MBAppConstants.STATE_MOBILE)){
					Logger.info("TDController : OpenAccount -CPP Mobile state received - creating session receipt", this.getClass());
					TermDepositSessionReceipts sessionReceipt = createSessionReceipt(newDDAAccount,ibankCommonData);
					insertInCompassSession(sessionReceipt,mbSession);			
				}
			}
			
		
			}
		}
		catch (BusinessException e) {
			Logger.error("CPP : BusinessException Inside openTermDepositAccount() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] : ", e, this.getClass());
			IMBResp errorResponse = MBAppUtils.createErrorResp(mbSession.getOrigin(), e, ServiceConstants.CPP_OPEN_TD_SERVICE, httpServletRequest);
			return errorResponse;
			
		}catch (Exception e){	
			Logger.error("CPP : Exception Inside openTermDepositAccount() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] : ", e, this.getClass());
			BusinessException exp = new BusinessException(BusinessException.SYSTEM_UNAVILABLE);
			IMBResp errorResponse = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, ServiceConstants.CPP_OPEN_TD_SERVICE, httpServletRequest);
			return errorResponse;
		}finally{
			endPerformanceLog(performanceLogger, logName);
			Logger.debug("CPP: openTermDepositAccount :: END", this.getClass());
		}
		return serviceResponse;
	}	
	
	@RequestMapping(value="renewTermDepositAccount", method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public IMBResp renewTermDepositAccount(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse,
			@RequestBody final TDRenewAcctReq tdRenewAcctReq){
		Logger.debug("CPP TD RENEWAL : renewTermDepositAccount :: START", this.getClass());
		PerformanceLogger performanceLogger = new PerformanceLogger();		
		String logName = startPerformanceLog(performanceLogger, httpServletRequest);
		
		MobileSession mbSession =  null;
		CustomerPricingTdDetails customerPricingTdDetails = null;
		TermDepositProducts termDepositProduct = null;
		String pricingOfferId = null;
		
		IMBResp serviceResponse = null;
		String origin = null;
		
		try {

			mbSession = mbAppHelper.getMobileSession(httpServletRequest);	
			
			validateRequestHeader(tdRenewAcctReq.getHeader(), httpServletRequest );
			
			ErrorResp errorResp = validate(tdRenewAcctReq, httpServletRequest);
			
			if (errorResp != null && errorResp.getErrors() != null && errorResp.getErrors().size() > 0)
				return errorResp;			
			
			IBankCommonData ibankCommonData = mbAppHelper.populateIBankCommonData(mbSession, httpServletRequest);	
			origin = ibankCommonData.getOrigin();
			
			//19E3 Changes
			//if switch is On and !tfnheld - then get values from req and do validation
			Boolean statUpdTfn=false;
			Boolean showTfn = mbSession.getShowTfn();
			
			if(showTfn!=null){
				if(showTfn){
					//trigger validations
					 Logger.debug("CPP TD RENEWAL : - renewTermDepositAccount - TFN validations", this.getClass());
					 if(!tdRenewAcctReq.getSelectedOption().equals("1")){
					    tfnHelper.validateTFN(tdRenewAcctReq.getSelectedOption(),tdRenewAcctReq.getTaxFileNumber(),tdRenewAcctReq.getSelectedExemption());
					    statUpdTfn = tfnHelper.updateTFN(ibankCommonData,tdRenewAcctReq.getSelectedOption(),tdRenewAcctReq.getTaxFileNumber(),tdRenewAcctReq.getSelectedExemption());
					    Logger.debug("CPP TD RENEWAL : - renewTermDepositAccount - TFN update :"+statUpdTfn, this.getClass());
					    // Remove showTfn from session
						mbSession.removeShowTfn();
				      } 
				}else{
					Logger.debug("TDController this condition gets executed when TFN widget was not shown and TFN was already submitted previously::", this.getClass());
					  statUpdTfn=true;
				}			 
             }
			
			//19E3 - warranty - restrain check moved to renewalDetails method.
			
			if(null!= mbSession && null!= mbSession.getCustomerPricingTdDetails()){
				Logger.debug("CPP TD RENEWAL : Customer has selected CPP rate. Iterating over list in session.", this.getClass());
				customerPricingTdDetails = mbSession.getCustomerPricingTdDetails();
				List<TermDepositProducts> termDepositList = customerPricingTdDetails.getTermDepositRates();
				for(TermDepositProducts tdProduct : termDepositList){
					if(tdProduct.getTermDepositProductIndex() == tdRenewAcctReq.getTermDepositProductIndex()){
							termDepositProduct = tdProduct;
							break;
						}
				} 

				pricingOfferId = customerPricingTdDetails.getPricingOfferId();
			}
				
			if(null!= mbSession && Boolean.TRUE.equals(mbSession.isCardedRate()) && null == termDepositProduct){
				Logger.debug("CPP TD RENEWAL : Customer has selected Carded rate.", this.getClass());
				termDepositProduct = customerPricingService.getSelectedCardedRate(ibankCommonData ,tdRenewAcctReq.getTermDepositProductIndex() );
			}
			
		TermDepositRenewal termDepositRenewal = tdHelper.populateTDRenewal(tdRenewAcctReq, ibankCommonData,mbSession,termDepositProduct);
			
		termDepositRenewal =	customerPricingService.renewTermDeposit(ibankCommonData, WDPServiceHelper.generateAppCorrelationId(), termDepositRenewal, termDepositProduct, pricingOfferId);
		
		//This host call is required to get the new balance after successful renew
		TermDepositAccount tdaAccount = (TermDepositAccount)termDepositService.getTDAAccount(termDepositRenewal.getAccount().getAccountId(),ibankCommonData);
		termDepositRenewal.setAccount(tdaAccount);
	
		// Call service to check TFN
		Customer customer = mbSession.getCustomer();
		String description = TaxFileNumberService.getTFNDescription(customer);
		boolean tfnHeld = false;
		boolean tfnExemption = false;
		if (description.equalsIgnoreCase(TaxFileNumberService.TAX_FILE_NUMBER_HELD))
			tfnHeld = true;
		else if (description.equalsIgnoreCase(TaxFileNumberService.FOREIGN_EXEMPTION))
			tfnExemption = true;
					
		//Populate the response
		serviceResponse = tdHelper.populateRenewTDAAccountResp(termDepositRenewal,ibankCommonData.getOrigin(),tfnHeld,tfnExemption );
		
		//Populate the response header
		RespHeader headerResp = populateResponseHeader(ServiceConstants.CPP_OPEN_TD_SERVICE, mbSession);
		serviceResponse.setHeader(headerResp);
		
		//Log the response	
		ObjectMapper mapper = new ObjectMapper();
		Logger.info("CPP TD RENEWAL: renewTermDepositAccount JSON Response : " + mapper.writeValueAsString(serviceResponse), this.getClass());
		
		//Session cleanup
		cleanMBSession(mbSession);
		
		//creating session receipts
		if(null != mbSession && null != mbSession.getState()){
			if(mbSession.getState().equals(MBAppConstants.STATE_MOBILE)){
				Logger.info("TDController : Renew TD -CPP Mobile state received - creating session receipt", this.getClass());
				TermDepositRenewalSessionReceipts sessionReceipt = createRenewalSessionReceipt(termDepositRenewal);
				insertInCompassSession(sessionReceipt,mbSession);			
			}
		}
		
		
	    return serviceResponse;
	}
	catch (BusinessException e) {
		Logger.error("CPP : BusinessException Inside renewTermDepositAccount() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] : ", e, this.getClass());
		/**
		 * Below if is added to fix <br> UAT defect ,in generic error in case of IB - MB renewal.
		 * changing origin to mobile to pick up error message without <br>
		 * 
		 * */
		String originMB = mbSession.getOrigin();
		String errorOrigin = null;
		Logger.debug("CPP : renewal Business exception origin -"+originMB, this.getClass());
		if(BusinessException.GENERIC_ERROR == e.getKey()){
			if(null != mbSession && null != mbSession.getState()){
				if(mbSession.getState().equals(MBAppConstants.STATE_MOBILE)){
					switch(originMB){
					case "STG" : errorOrigin = "MSTG";
						break;
					case "BOM" : errorOrigin = "MBOM";
						break;
					case "BSA" : errorOrigin = "MBSA";
						break;
					case "BSGD": errorOrigin = "MBSA";
						break;
					case "STGD" : errorOrigin = "MSTG";
						break;
					case "BOMG" : errorOrigin = "MBOM";
						break;
					}
				}
			}
        }else if(BusinessException.INVALID_MIN_AMT_TDA == e.getKey()){
            CodesVO myCodesVO = IBankParams.getCodesData(IBankParams.DEFAULT_ORIGIN, IBankParams.CATEGORY_TERM_DEP, IBankParams.CD_NEW_ACC_MIN_AMT);
            String[] params = {"Term Deposit Account", myCodesVO.getMessage()};
            return MBAppUtils.createErrorResp(originMB, BusinessException.INVALID_MIN_AMT_TDA, MBAppUtils.getMessage(originMB, BusinessException.INVALID_MIN_AMT_TDA, params), ServiceConstants.CPP_OPEN_TD_SERVICE, httpServletRequest);
        }
		
		if(null == errorOrigin){
			errorOrigin = originMB;
		}
		IMBResp errorResponse = MBAppUtils.createErrorResp(errorOrigin, e, ServiceConstants.CPP_OPEN_TD_SERVICE, httpServletRequest);
		return errorResponse;
		
	}catch (Exception e){	
		Logger.error("CPP : Exception Inside renewTermDepositAccount() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] : ", e, this.getClass());
		BusinessException exp = new BusinessException(BusinessException.SYSTEM_UNAVILABLE);
		IMBResp errorResponse = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, ServiceConstants.CPP_OPEN_TD_SERVICE, httpServletRequest);
		return errorResponse;
	}finally{
		endPerformanceLog(performanceLogger, logName);
		Logger.debug("CPP: renewTermDepositAccount :: END", this.getClass());
	}
  }
	
	private String startPerformanceLog(PerformanceLogger performanceLogger, HttpServletRequest httpServletRequest){
		String logName = MBAppUtils.getLogName(httpServletRequest);
		performanceLogger.startAllLogs();
		performanceLogger.startLog(logName);
		
		return logName;
	}
	
	private void endPerformanceLog(PerformanceLogger performanceLogger, String logName){
		performanceLogger.endLog(logName);
		performanceLogger.endAllLogs();
	}
	
	private TermDepositSessionReceipts createSessionReceipt(NewTermDepositAccount newDDAAccount,IBankCommonData ibankCommonData) {
		Logger.debug("CPP : TDController - createSessionReceipt - START" , this.getClass());
		TermDepositSessionReceipts myReceipt = new TermDepositSessionReceipts();
		
		if(null!= newDDAAccount.getReceipt() ){
			myReceipt.setDisplayReceiptNumber(true);
			myReceipt.setReceiptNumber(newDDAAccount.getReceipt().getReceiptNumber());	
		}else
			myReceipt.setReceiptNumber(NOT_AVAILABLE);
		
		myReceipt.setTransactionDateTime(DateMethods.getTimestamp());
		
		myReceipt.setTransactionType(NEW_TERM_DEPOSIT);
		
		myReceipt.setAmount(newDDAAccount.getAmount());
		myReceipt.setTermInMonths(""+newDDAAccount.getTermInMonths());
		
		if(null!= newDDAAccount.getSelectedProductInstance()){
			TermDepositProduct product = newDDAAccount.getSelectedProductInstance();
			myReceipt.setInterestRate(product.getInterestRate());			
			myReceipt.setFrequency(product.getFrequency());
		}
		
		myReceipt.setInterestInstruction(newDDAAccount.getInterestInstruction());
		
		Account fromAccount = newDDAAccount.getSourceFundsFrom();
		if(null!= fromAccount){
			myReceipt.setFromAccountNumber(fromAccount.getAccountId().getAccountNumber());
			myReceipt.setFromAccountAlias(fromAccount.getAlias());
		}
		
		if(null!= newDDAAccount.getNewAcctNumber()){
			myReceipt.setNewAcctNumber(newDDAAccount.getNewAcctNumber());
		}	
		
		if(null!= newDDAAccount.getPaidToAccount()){
			Object obj = newDDAAccount.getPaidToAccount();
			if(obj instanceof Account ){
				myReceipt.setPaidToAccount(((Account)obj).getAlias()+ " "+ ((Account)obj).getAccountId().getFormattedAccountNumber());
			}
			if(obj instanceof ThirdParty){
				myReceipt.setPaidToAccount(((ThirdParty)obj).getFormattedBsb() + " "+ ((ThirdParty)obj).getFormattedAccountNumber());
			}
		}
		
		myReceipt.setBillerCode(getBillerCodeForBrand(ibankCommonData));
		myReceipt.setPaymentHistory(false);
	
		Logger.debug("CPP : TDController - createSessionReceipt - END" , this.getClass());
		return myReceipt;
	}
	
	private String getBillerCodeForBrand(IBankCommonData commonData) {
			CodesVO codesVo = null;
			codesVo = IBankParams.getCodesData(commonData.getOrigin(), TERM_DEPOSIT,BILLER_CODE);
			return codesVo.getMessage();
		}
	
	private TermDepositRenewalSessionReceipts createRenewalSessionReceipt(TermDepositRenewal termDepositRenewal) {
		Logger.debug("Enter createSessionReceipt", this.getClass());
		TermDepositRenewalSessionReceipts myReceipt = new TermDepositRenewalSessionReceipts();
		myReceipt.setTransactionDateTime(DateMethods.getTimestamp());
		myReceipt.setTransactionType(TERM_DEPOSIT_RENEWAL);

		myReceipt.setTermDepositAccountNumber(StringUtil.formatCDAAccountNumber(termDepositRenewal.getAccount().getAccountId().getAccountNumber()));
		myReceipt.setBalance(termDepositRenewal.getAccount().getBalance());
		myReceipt.setInterestRate(termDepositRenewal.getAccount().getInterestRate());		
		myReceipt.setTermLength(""+termDepositRenewal.getAccount().getTermInMonth());
		myReceipt.setMaturityDate(termDepositRenewal.getAccount().getMaturityDate());
		myReceipt.setFreqWording(termDepositRenewal.getAccount().getInterestInstruction().getFreqWording());
		myReceipt.setInterestPaymentInstruction(termDepositRenewal.getInterestPaymentOption());
		myReceipt.setRenewedTermDep(true);
		myReceipt.setTransferAmount(termDepositRenewal.getTransferAmount());
		
		if(termDepositRenewal.getFundFrom().equalsIgnoreCase(TermDepositConstants.FUND_EXTERNAL)){
			myReceipt.setAddWidthdrawlIndicator(3);
		}else if(termDepositRenewal.getFundFrom().equalsIgnoreCase(TermDepositConstants.FUND_INTERNAL)){
			myReceipt.setAddWidthdrawlIndicator(1);
		}else if(termDepositRenewal.getFundFrom().equalsIgnoreCase(TermDepositConstants.FUNDS_FROM_WITHDRAW)){
			myReceipt.setAddWidthdrawlIndicator(2);
		}else if(termDepositRenewal.getFundFrom().equalsIgnoreCase(TermDepositConstants.FUNDS_FROM_USE_EXISTING)){
			myReceipt.setAddWidthdrawlIndicator(4);
		}
		
		if(null!= termDepositRenewal.getSourceFromAccount()){
			//add , withdraw account to display
			Account accnt = termDepositRenewal.getSourceFromAccount();
			myReceipt.setSourceAccount(accnt);
			myReceipt.setSourceAcctDisplay(accnt.getAlias()+" "+accnt.getAccountId().getFormattedAccountNumber());
			myReceipt.setFundedAccount(true);
		}else
			myReceipt.setFundedAccount(false); // fund externally
		
		myReceipt.setTotalNewBalance(termDepositRenewal.getAccount().getBalance());
		
		StringBuffer sb = new StringBuffer();
		if (null!= termDepositRenewal.getPaidToAccount()) {
			Object obj = termDepositRenewal.getPaidToAccount();
			if(obj instanceof Account ){
				sb.append(((Account)obj).getAlias()).append(" ");
				sb.append(((Account)obj).getAccountId().getFormattedAccountNumber());
			}
			if(obj instanceof ThirdParty){
				sb.append(((ThirdParty)obj).getFormattedBsb()).append(" ");
				sb.append(((ThirdParty)obj).getFormattedAccountNumber());
			}
			
			myReceipt.setPaidToAccount(sb.toString());
		}
		myReceipt.setPaidToAccount(sb.toString());
		myReceipt.setMaintainInd(false);
		myReceipt.setPaymentHistory(false);
		Logger.debug("Exit createSessionReceipt", this.getClass());
		return myReceipt;
	}
	
	// This method adds a session receipt object into Compass session
		public void insertInCompassSession(BaseSessionReceipts sReceipt,MobileSession mbSession) {
			List<BaseSessionReceipts> colSessionReceipts = null;
			try {

				colSessionReceipts = mbSession.getBaseSessionReceipts();
				if (colSessionReceipts == null) {
					colSessionReceipts = new ArrayList<BaseSessionReceipts>();
				}else{
					Logger.debug("TDController - insertInCompassSession : size of session receipt -"+colSessionReceipts.size(), this.getClass());
				}
				colSessionReceipts.add(sReceipt);

			} // End of try
			catch (Exception e) {
				Logger.warn("Error occured while inserting data into the session "+ e.getMessage(), this.getClass());

			}
			mbSession.setBaseSessionReceipts(colSessionReceipts);
		}
	
		
		/**
		 * Method added to clean MB session in case of exception on receipt page for TDO and TDR 
		 * @param mbSession
		 */
		public void cleanMBSession(MobileSession mbSession) {
			
			Logger.debug("CPP: cleanMBSession :: START", this.getClass());
			
			if(null != mbSession) {
				mbSession.removeCustomerPricingTdDetails();
				mbSession.removeTermDepositAmount();
				mbSession.removeTermDepositFcastInterestAmount();
				mbSession.removeCardedRate();
				mbSession.removeTermDepositTransferAmount();
				mbSession.removeTermDepositIntFrequency();
				mbSession.setSelectedAccountIndex(null);
			}
			
			Logger.debug("CPP: cleanMBSession :: END", this.getClass());
		}

		public ArrayList checkDuplicateAcctOpeningReq(IBankCommonData commonData, String selProduct) throws BusinessException{
			 boolean isDuplicate=false;
			 ArrayList duplicateAcctOpeningList=null;
			 
			 //Customer customer=mobileSession.getCustomer();
			 //User user=mobileSession.getUser();
				
			 //IBankCommonData commonData=populateIBankCommonData(customer,user);
				
			  try{
					AcctOpeningVO newAcct=new AcctOpeningVO();
					newAcct.setGcisNumber(commonData.getUser().getGCISNumber());
					newAcct.setSubProdCode(""+selProduct);			
					duplicateAcctOpeningList=(ArrayList)termDepositService.getDuplicateReqList(newAcct);
				}
				catch(BusinessException e){
					if(e.getKey()==BusinessException.MAX_TD_ACCT_OPENING_REQ){
						IBankLog.logWRN("Max TDA Acct Opening Req reached ", this.getClass());
						e = new BusinessException(BusinessException.MAX_ACCT_OPENING_REQ);
						throw e;
					}
				}
				catch(ResourceException re){
					IBankLog.logWRN("Resourceexception in checkTDDuplicateAcctOpeningReq() ", this.getClass());
				}	  
				return duplicateAcctOpeningList;
		}
		
		private int getTDMaxAcctOpeningReq() {
			int retVal = 5;
			try {
				CodesVO code = IBankParams.getCodesData(IBankParams.DEFAULT_ORIGIN,
				    ACCT_OPEN, MAX_TD_ACCT_OPENING_REQ);

				if (code != null) {
					retVal = Integer.parseInt(code.getMessage());
				}
				// temp only
				// retVal = 100;
			} catch (Exception e) {
				IBankLog.logERR("Exception in getTDMaxAcctOpeningReq ", e, this
				    .getClass());
			}
			return retVal;
		}
}
