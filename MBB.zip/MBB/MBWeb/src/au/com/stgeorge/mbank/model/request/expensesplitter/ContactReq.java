package au.com.stgeorge.mbank.model.request.expensesplitter;


import java.io.Serializable;

import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.Length;
import org.hibernate.validator.constraints.NotEmpty;

import au.com.stgeorge.ibank.businessobject.BusinessException;
import au.com.stgeorge.mbank.model.common.IMBReq;
import au.com.stgeorge.mbank.model.common.ReqHeader;


public class ContactReq implements Serializable,IMBReq {

	/**
	 * 
	 */
	private static final long serialVersionUID = 8138476587863169833L;
	protected static final String AMT_PATTERN = "^[0-9]*\\.{0,1}(\\d{1,2}){0,1}$";
	protected static final String BLOCK_CHARS_PATTERN = "^[0-9A-Za-z',. &/\\-]*$";
	protected static final String MASK_NUMBERS = "^[0-9]+$";
		
	private ReqHeader header;

	public ReqHeader getHeader() {
		return header;
	}

	public void setHeader(ReqHeader header) {
		this.header = header;
	}
	@NotEmpty(message = "{errors.contactName.required}")
	@Pattern(regexp = BLOCK_CHARS_PATTERN, message = "{errors.desc.blockchar}")
	@Length(max = 15, message = "{errors.desc.maxlength}")
	private String contactName;
	
	@NotEmpty(message = "{errors.mobileNumber.required}")
	@Length(max = 10, min = 10, message = "" + BusinessException.P2P_INVALID_MOBILE_NUM)
	@Pattern(regexp = MASK_NUMBERS, message = "" + BusinessException.P2P_INVALID_MOBILE_NUM)
	private String contactMobileNum;
	
	@Length(max = 14, message = "{errors.amt.maxlength}")
	@Pattern(regexp = AMT_PATTERN, message = "{errors.amt.blockchar}")
	private String contactAmt;
	
	@Length(max = 14, message = "{errors.amt.maxlength}")
	@Pattern(regexp = AMT_PATTERN, message = "{errors.amt.blockchar}")
	private String unequalContactAmt;
	
	@Length(max = 14, message = "{errors.amt.maxlength}")
	@Pattern(regexp = AMT_PATTERN, message = "{errors.amt.blockchar}")
	private String totalAmt;
	
	@Length(max = 14, message = "{errors.amt.maxlength}")
	@Pattern(regexp = AMT_PATTERN, message = "{errors.amt.blockchar}")
	private String amtPaid;
	
	@Length(max = 14, message = "{errors.amt.maxlength}")
	@Pattern(regexp = AMT_PATTERN, message = "{errors.amt.blockchar}")
	private String amtDue;
	
	@Length(max = 14, message = "{errors.amt.maxlength}")
	@Pattern(regexp = AMT_PATTERN, message = "{errors.amt.blockchar}")
	private String amtPaidNow;
	
	@Pattern(regexp = MASK_NUMBERS, message = "" + BusinessException.WSVC_INVALID_INPUT_PARAM)
	private String contactID;

	private boolean meContact;
	
	private boolean settled;
	
	private String contactIndex;
	
	public String getContactName() {
		return contactName;
	}

	public void setContactName(String contactName) {
		this.contactName = contactName;
	}

	public String getContactMobileNum() {
		return contactMobileNum;
	}

	public void setContactMobileNum(String mobileNumber) {
		this.contactMobileNum = mobileNumber;
	}

	public String getContactAmt() {
		return contactAmt;
	}

	public void setContactAmt(String contactAmt) {
		this.contactAmt = contactAmt;
	}

	public boolean isMeContact() {
		return meContact;
	}

	public void setMeContact(boolean meContact) {
		this.meContact = meContact;
	}

	public boolean isSettled() {
		return settled;
	}

	public void setSettled(boolean settled) {
		this.settled = settled;
	}

	public String getTotalAmt() {
		return totalAmt;
	}

	public void setTotalAmt(String totalAmt) {
		this.totalAmt = totalAmt;
	}

	public String getAmtPaid() {
		return amtPaid;
	}

	public void setAmtPaid(String amtPaid) {
		this.amtPaid = amtPaid;
	}

	public String getAmtDue() {
		return amtDue;
	}

	public void setAmtDue(String amtDue) {
		this.amtDue = amtDue;
	}

	public String getContactID() {
		return contactID;
	}

	public void setContactID(String contactID) {
		this.contactID = contactID;
	}

	public String getAmtPaidNow() {
		return amtPaidNow;
	}

	public void setAmtPaidNow(String amtPaidNow) {
		this.amtPaidNow = amtPaidNow;
	}

	public String getContactIndex() {
		return contactIndex;
	}

	public void setContactIndex(String contactIndex) {
		this.contactIndex = contactIndex;
	}

	public String getUnequalContactAmt() {
		return unequalContactAmt;
	}

	public void setUnequalContactAmt(String unequalContactAmt) {
		this.unequalContactAmt = unequalContactAmt;
	}

}
