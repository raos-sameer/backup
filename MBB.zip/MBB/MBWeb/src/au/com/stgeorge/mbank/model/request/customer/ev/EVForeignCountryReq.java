package au.com.stgeorge.mbank.model.request.customer.ev;
import au.com.stgeorge.mbank.model.common.IMBReq;
import java.io.Serializable;
import au.com.stgeorge.mbank.model.common.ReqHeader;

public class EVForeignCountryReq implements IMBReq, Serializable{
	
	private static final long serialVersionUID = -256469501889499119L;
	private ReqHeader header;
	public ReqHeader getHeader() {
		return header;
	}
	public void setHeader(ReqHeader header) {
		this.header = header;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
}
