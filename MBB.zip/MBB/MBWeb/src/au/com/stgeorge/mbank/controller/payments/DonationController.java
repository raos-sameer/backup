package au.com.stgeorge.mbank.controller.payments;

import java.math.BigDecimal;
import java.util.List;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.builder.ReflectionToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;

import au.com.stgeorge.digitalsec.logger.DigitalSecLogger;
import au.com.stgeorge.digitalsec.logger.DigitalSecLogggerVO;
import au.com.stgeorge.framework.common.logging.Logger;
import au.com.stgeorge.ibank.businessobject.BusinessException;
import au.com.stgeorge.ibank.businessobject.DuplicateException;
import au.com.stgeorge.ibank.businessobject.IBankSecureService;
import au.com.stgeorge.ibank.businessobject.PrudentialLimitHelper;
import au.com.stgeorge.ibank.businessobject.ResourceException;
import au.com.stgeorge.ibank.businessobject.ThirdPartyTransferHelper;
import au.com.stgeorge.ibank.businessobject.DonationsService;
import au.com.stgeorge.ibank.common.cache.IBankParams;
import au.com.stgeorge.ibank.safi.util.SafiConstants;
import au.com.stgeorge.ibank.safi.util.SafiUtil;
import au.com.stgeorge.ibank.safi.valueobject.SafiForensicInfo;
import au.com.stgeorge.ibank.safi.valueobject.SafiPayTranVO;
import au.com.stgeorge.ibank.service.valueobject.SafiRespVO;
import au.com.stgeorge.ibank.util.CommonBusinessUtil;
import au.com.stgeorge.ibank.util.StringUtil;
import au.com.stgeorge.ibank.valueobject.Account;
import au.com.stgeorge.ibank.valueobject.CharityVO;
import au.com.stgeorge.ibank.valueobject.Customer;
import au.com.stgeorge.ibank.valueobject.NPPPayment;
import au.com.stgeorge.ibank.valueobject.PaymentDuplicateVO;
import au.com.stgeorge.ibank.valueobject.Receipt;
import au.com.stgeorge.ibank.valueobject.ThirdPartyPayment;
import au.com.stgeorge.ibank.valueobject.collection.LabelValueMap;
import au.com.stgeorge.ibank.valueobject.database.OriginsVO;
import au.com.stgeorge.ibank.valueobject.transfer.IBankCommonData;
import au.com.stgeorge.mbank.controller.IMBController;
import au.com.stgeorge.mbank.controller.SafiWebHelper;
import au.com.stgeorge.mbank.controller.SecureCodeHelper;
import au.com.stgeorge.mbank.controller.customer.LogonHelper;
import au.com.stgeorge.mbank.model.common.IMBReq;
import au.com.stgeorge.mbank.model.common.IMBResp;
import au.com.stgeorge.mbank.model.common.ReqHeader;
import au.com.stgeorge.mbank.model.common.RespHeader;
import au.com.stgeorge.mbank.model.request.EmptyReq;
import au.com.stgeorge.mbank.model.request.SecureCodeReq;
import au.com.stgeorge.mbank.model.request.payments.DonationTransferReq;
import au.com.stgeorge.mbank.model.response.ErrorResp;
import au.com.stgeorge.mbank.model.response.donation.CharityDetailResp;
import au.com.stgeorge.mbank.model.response.payments.TransferResp;
import au.com.stgeorge.mbank.session.MobileSession;
import au.com.stgeorge.mbank.session.MobileSessionImpl;
import au.com.stgeorge.mbank.util.MBAppHelper;
import au.com.stgeorge.mbank.util.MBAppUtils;
import au.com.stgeorge.mbank.util.MBAppValidator;
import au.com.stgeorge.mbank.util.ServiceConstants;
import au.com.stgeorge.mobilebank.businessobject.PayeeService;
import au.com.stgeorge.mobilebank.businessobject.TransactService;
import au.com.stgeorge.perflogger.PerformanceLogger;

/**
 * Transfer to Donation controller
 * 
 */
@Controller
@RequestMapping("/donation")
public class DonationController implements IMBController {
	
	
	private static final String NOTALLOW_CHAR_PAYER_NAME = "$ : _ + % * ? [ ] > ; = < } \\^ { | @ # ! ~ ` - \"";

	@Autowired
	private DonationsService donationsService;
	
	@Autowired
	private TransactService transactService;
	
	@Autowired
	private PayeeHelper payeeHelper;

	@Autowired
	private SecureCodeHelper secureCodeHelper;

	@Autowired
	private PayeeService payeeService;
	
	@Autowired
	private MBAppValidator mbAppValidator;
	
	@Autowired
	private MBAppHelper mbAppHelper;
	
    @Autowired
    private DigitalSecLogger digitalSecLogger;

    @Autowired
   	private LogonHelper logonHelper;

    private static final String DE = "DE";
    private static final String OSKO = "osko";
    private static final String REASON_2FA_SAFI = "SAFI";
	private static final String REASON_2FA_EHUB = "EHUB";
	
	private static final String TRANSFER_DESC = "Donation";
	
	private static final String ORIGINATION = "Donation";
    
	@RequestMapping(method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE, value = "charityDetails")
	@ResponseBody
	public IMBResp getCharityDetails(HttpServletRequest httpRequest, @RequestBody final EmptyReq request) {
		Logger.debug("DonationController - getCharityDetails. Request: " + request, this.getClass());
		String logName = startPerformanceLog(httpRequest);
		MobileSession mobileSession = new MobileSessionImpl();
		CharityDetailResp resp = null;
		try {
			mobileSession.getSessionContext(httpRequest);
			validateRequestHeader(request.getHeader(), httpRequest);
			ErrorResp errorResponse = validate(request, httpRequest);
			if (errorResponse.hasErrors())
			{
				return errorResponse;
			}
			
			IBankCommonData commonData = mbAppHelper.populateIBankCommonData(mobileSession, httpRequest);
			
			CharityVO charityVO = donationsService.getCharityDetails(commonData);
			
			if(null!=charityVO) {
				resp = populateCharityDetailResponse(populateResponseHeader(ServiceConstants.DONATIONS, mobileSession ), charityVO);
				donationsService.addStatLogsForDonations(commonData);			
				return resp;
			}else {
				Logger.debug("DonationController - inside no donations available" + request, this.getClass());
				throw new BusinessException(BusinessException.DONATIONS_NO_ACTIVE_AVAILABLE);
			}
			

		} catch (BusinessException e) {
			Logger.info("BusinessException in DonationController - getCharityDetails - [key: " + e.getKey() + "] : GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), e, ServiceConstants.DONATIONS, httpRequest);
		} catch (ResourceException e) {
			Logger.error("ResourceException in DonationController - getCharityDetails - [key: " + e.getKey() + "] : GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.SYSTEM_UNAVILABLE, ServiceConstants.DONATIONS, httpRequest);
		} catch (Exception e) {
			Logger.error("Exception DonationController - getCharityDetails: GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), ResourceException.MOBILE_NON_FINANCIAL_FATAL_ERR, ServiceConstants.DONATIONS, httpRequest);
		} finally {
			endPerformanceLog(logName);
		}
	}
	
    private CharityDetailResp populateCharityDetailResponse(RespHeader header, CharityVO charity ) {
    	  CharityDetailResp charityDetailResp = new CharityDetailResp(header);
    	  charityDetailResp.setCharityName(charity.getCharityName()); 
    	  charityDetailResp.setDescription(charity.getDescription()); 
    	  charityDetailResp.setDisclaimer(charity.getDisclaimer()); 
    	  charityDetailResp.setLink(charity.getLink()); 
    	  charityDetailResp.setAbn(charity.getABN());
    	  charityDetailResp.setBsb(StringUtil.formatBSBNumber(charity.getBSB())); 
    	  charityDetailResp.setAccountNumber(formatGenericAccountNumber(charity.getAccountNumber()));
    	  charityDetailResp.setTransferDesc(TRANSFER_DESC);
		return charityDetailResp;
		
	}
    
    private String formatGenericAccountNumber(String accountNumber) {
		StringBuffer formattedAccNumber = new StringBuffer("");
		if (accountNumber != null) {
			accountNumber = accountNumber.trim();
			
			int firstPart = accountNumber.length()%3;
			if(firstPart != 0){
				formattedAccNumber.append(accountNumber.substring(0,firstPart));
			}
			for(int i = firstPart;i<accountNumber.length();i=i+3){
					if(formattedAccNumber.length() > 0){
						formattedAccNumber.append(' ');
					}
					formattedAccNumber.append(accountNumber.substring(i, i+3));
			}
		}
		return formattedAccNumber.toString();
	}

	/**
	 * Transfer to Payee service operation
	 * 
	 * @param httpRequest
	 * @param request
	 * @return
	 */
	@RequestMapping(method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE, value = "transfer")
	@ResponseBody
	public IMBResp transfer(HttpServletRequest httpRequest, HttpServletResponse httpServletResponse,@RequestBody final DonationTransferReq request) {
		Logger.debug("DonationController - transfer(). Request: " + request, this.getClass());
		String logName = startPerformanceLog(httpRequest);
		MobileSession mobileSession = new MobileSessionImpl(); 
		IBankCommonData commonData = null;
		ThirdPartyPayment payment = null;
		try {
			mobileSession.getSessionContext(httpRequest);
			
			mobileSession.setPaymentType(DE);
			
			Customer customer = mobileSession.getCustomer();
			commonData = new MBAppHelper().populateIBankCommonData(mobileSession, httpRequest);
			validateRequestHeader(request.getHeader(), httpRequest);
			ErrorResp errorResponse = validate(request, httpRequest);// validate json
			if (errorResponse.hasErrors())
				return errorResponse;
			
			Account fromAccount = customer.getAccounts().get(request.getFromAccountIndex());

			Logger.debug("On Confirm btn Click - Payment will be processed via existing DE.",getClass());	
			payment = populatePayment(fromAccount, customer, commonData, request, mobileSession);		
		
			//18E4: Safi
			populateSafiPayTranVO(httpRequest, request, mobileSession,	commonData, payment);
			//18E4: Safi 
			
			mobileSession.setSendPaymentEmail(true);
            IMBResp resp = performTransfer(mobileSession, fromAccount, payment, ServiceConstants.DONATIONS, commonData, httpRequest,false);
            mobileSession.setTransaction(payment);
			return  resp;
			
		} catch (BusinessException e) {
			Logger.info("BusinessException in DonationController - transfer() - [key: " + e.getKey() + "], GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), e, ServiceConstants.DONATIONS, httpRequest);
		} catch (ResourceException e) {
			Logger.error("ResourceException in DonationController - transfer() - [key: " + e.getKey() + "], GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());
			mobileSession.removeTransaction();
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.SYSTEM_UNAVILABLE, ServiceConstants.DONATIONS, httpRequest);
		} catch (Exception e) {
			Logger.error("Exception DonationController - transfer(): GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			mobileSession.removeTransaction();
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.GENERIC_ERROR, ServiceConstants.DONATIONS, httpRequest);
		} finally {
			//18E4 : SAFI changes for third party transfers
			handleSafiResponse(payment,httpRequest,httpServletResponse);
			//18E4 : SAFI changes for third party transfers ENDS
			endPerformanceLog(logName);
		}
	}

	private void populateSafiPayTranVO(HttpServletRequest httpRequest,
			final DonationTransferReq request, MobileSession mobileSession,
			IBankCommonData commonData, ThirdPartyPayment payment) throws BusinessException {
		String validDecodedPrint;
		String devicePrint;
		if(ThirdPartyTransferHelper.isSafiCallAllowed(payment, mobileSession.getPaymentType()) &&
				payment != null && ThirdPartyTransferHelper.isSafiApplicableForAnalyze(payment)) {
			Logger.debug("SAFI : DonationController.transfer(): Device Print Received in Payee Transfer Request: " +request.getDevicePrint(), this.getClass()) ;
			validDecodedPrint = SafiUtil.validateDevicePrint(request.getDevicePrint());
			devicePrint = validDecodedPrint != null ? request.getDevicePrint():null;
			
			if(null == devicePrint && null != mobileSession.getSafiLogonInfo() && null != mobileSession.getSafiLogonInfo().getDevicePrint()) {
				devicePrint = mobileSession.getSafiLogonInfo().getDevicePrint();
				Logger.debug("SAFI : DonationController.transfer(): Device Print from request was null so getting from mobileSession.getSafiLogonInfo():" +devicePrint, this.getClass()) ;
			}
			
			boolean isMobileApp = ((logonHelper.loadCordova(httpRequest)) == -1) ? false:true;
			Logger.debug("SAFI : DonationController.transfer(): validDecodedPrint: " +validDecodedPrint + " devicePrint: "+devicePrint+" isMobileApp: "+isMobileApp, this.getClass()) ;
			
			SafiPayTranVO safiPaymentTransferVO = SafiWebHelper.populateSafiPayTranVOForThirdPartyPayment(httpRequest, payment, commonData,devicePrint,mobileSession,isMobileApp);
			safiPaymentTransferVO.setEventType(SafiConstants.CLIENT_DEFINED_EVENT_TYPE_DONATION);
			payment.setSafiPayTranVO(safiPaymentTransferVO);
			payment.setSafiCall(SafiConstants.SAFI_CALL_ANALYZE);
			payment.setOnUsTransferCheckDone(false);
		}
	}
	
	private void notifyCallForSafi(HttpServletRequest httpRequest,
			HttpServletResponse httpResponse, MobileSession mobileSession,
			IBankCommonData commonData, ThirdPartyPayment payment,
			LabelValueMap digitalSecLoggerMap,boolean status2FA , boolean isPaymentSuccess)
			throws BusinessException {
		if (payment != null && mobileSession != null) {
			if (payment.getSafiRespVO() != null
					&& SafiConstants.SAFI_ACTION_CHALLENGE.equals(payment
							.getSafiRespVO().getSafiAction()) && ThirdPartyTransferHelper.isSafiApplicableForNotify(payment)) {
				Logger.info("SAFI : DonationController - transferSecure(): Notify Call:START STATUS_2FA_SUSPENDED while requesting secure code",this.getClass());
				String devicePrint = mobileSession.getSafiLogonInfo() != null ? mobileSession
						.getSafiLogonInfo().getDevicePrint() : "";
				Logger.debug("reqSecureCode() suspended devicePrint from native app : " + devicePrint, this.getClass());
				payment.setSafiCall(SafiConstants.SAFI_CALL_NOTIFY);
				mobileSession.setTransaction(payment);
				notifyCallAndUpdateCookie(httpRequest, mobileSession, payment, httpRequest,
						httpResponse, commonData, digitalSecLoggerMap,
						status2FA /* status2FA */, isPaymentSuccess /* isPaymentSuccess */);
				Logger.info("SAFI : DonationController - transferSecure(): Notify Call: END",this.getClass());
			}
		}
	}

	/**
	 * Make secure transfer service operation
	 * 
	 * @param request
	 * @return
	 */
	@RequestMapping(method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE, value = "transfersecure")
	@ResponseBody
	public IMBResp transferSecure(HttpServletRequest httpRequest, HttpServletResponse httpResponse, @RequestBody final SecureCodeReq request) {
		Logger.debug("DonationController - transferSecure(). Request: " + request, this.getClass());
		String logName = startPerformanceLog(httpRequest);
		MobileSession mobileSession = new MobileSessionImpl();
		String safiAction = null;

		try {
			mobileSession.getSessionContext(httpRequest);
			IBankCommonData commonData = new MBAppHelper().populateIBankCommonData(mobileSession, httpRequest);
			validateRequestHeader(request.getHeader(), httpRequest);
			ErrorResp errorResponse = validate(request, httpRequest);// validate json
			if (errorResponse.hasErrors())
				return errorResponse;

			if (ServiceConstants.PAYEE_TRANSFER_2FA_TRAN_CODE != request.getTranType()) return MBAppUtils.createInvalid2FATransactionTypeResponse(ServiceConstants.DONATIONS);
			
			ThirdPartyPayment payment = (ThirdPartyPayment) mobileSession.getTransaction();
			safiAction = payment.getSafiRespVO() != null && payment.getSafiRespVO().getSafiAction() != null ? payment.getSafiRespVO().getSafiAction(): null ;
			
			String reasonCode = "";
			if(payment instanceof NPPPayment) { 
				reasonCode = ((NPPPayment)payment).getReasonCode();			
			}
			
			String paymentType = mobileSession.getPaymentType();
			if (null == mobileSession.getPaymentType()) {
				paymentType = "";
			}
			
			boolean isMobileApp = ((logonHelper.loadCordova(httpRequest)) == -1) ? false:true;
			
			LabelValueMap digitalSecMap = mobileSession.getDigitalSecLoggerMap();
			errorResponse = secureCodeHelper.verifySecureCode(commonData, mobileSession, mobileSession.getTransaction(), request, ServiceConstants.PAYEE_TRANSFER_SECURE_SERVICE, httpRequest);
			if (errorResponse.hasErrors()){
				Logger.debug("Error in transferSecure() after verifySecureCode with safiAction : "+safiAction, this.getClass());
				DigitalSecLogggerVO digitalSecLoggerVO = initializeDigitalLoggers(commonData);
				String devicePrint = mobileSession.getSafiLogonInfo()!= null ? mobileSession.getSafiLogonInfo().getDevicePrint() : "";
				if(payment.getScheduleDetails()==null) {
					SafiForensicInfo safiForensicInfo = populateSafiForensicInfoVO(payment.getSafiRespVO(), devicePrint);
					/*if(null != payment && payment instanceof NPPPayment && ((NPPPayment)payment).isDeRetry()) {
						digitalSecLoggerVO.setStatus(DigitalSecLogger.FAILURE);
						digitalSecLoggerVO.setValues(((ThirdPartyPayment)payment).toDigitalSecurityLogNPP(((ThirdPartyPayment)payment).toDigitalSecurityLog(false,digitalSecMap.get(DigitalSecLogger.AUTHTYPE),digitalSecMap.get(DigitalSecLogger.AUTHPHONE),null), "Osko", payment.isRetryDEConsent(),reasonCode, safiForensicInfo, isMobileApp, false is2FADone));
						digitalSecLogger.log(digitalSecLoggerVO);
						digitalSecLoggerVO.setStatus(DigitalSecLogger.SUCCESS);
						paymentType = "DE";
					}*/
					digitalSecLoggerVO.setValues(((ThirdPartyPayment)payment).toDigitalSecurityLogNPP(((ThirdPartyPayment)payment).toDigitalSecurityLog(false,digitalSecMap.get(DigitalSecLogger.AUTHTYPE),digitalSecMap.get(DigitalSecLogger.AUTHPHONE),null, null), paymentType.equalsIgnoreCase(OSKO) ? "Osko" : "DE", null, reasonCode,safiForensicInfo, isMobileApp, false /*is2FADone*/));
					
				} else if(payment.getScheduleDetails() != null && ((payment.getScheduleDetails().getId()== null || "".equals(payment.getScheduleDetails().getId() ) ))) {
					digitalSecLoggerVO.setValues(((ThirdPartyPayment)payment).toSchLog(false,digitalSecMap.get(DigitalSecLogger.AUTHTYPE),digitalSecMap.get(DigitalSecLogger.AUTHPHONE),null));
				}
				digitalSecLogger.log(digitalSecLoggerVO);
				
				//18E4: Safi Notify if SAFI response is challenge or customer account is suspended after unsuccessful 2FA attempts
				if((errorResponse.getStatus() ==  ErrorResp.STATUS_2FA_SUSPENDED )){
					notifyCallForSafi(httpRequest, httpResponse, mobileSession, commonData, payment, digitalSecMap,false, false);
				}
				
				//18E4: Safi Notify
				
				return errorResponse;
			}
			
			// do transfer
			payment.getToThirdParty().setTrusted(IBankSecureService.TRUSTED_NOW_STATUS);
			Logger.debug("transferSecure : changed to Trusted Now " + payment.getToThirdParty().getTrusted(), this.getClass());
			payment.setOtp(mobileSession.getSecureCodeDetails().getOtp());

			Account fromAccount = MBAppHelper.getAccountbyAccountId(payment.getFromAccount(), mobileSession.getCustomer().getAccounts());
			
			//	Before making transfer, remove value from safi call so that analyze call is not made again in ThirdPartyTransferTransaction
			//	If reason of 2FA is SAFI challenge response then call notify method
			//	If reason of 2FA is thrown EHUB then do not call notify method
			if(payment != null && null != payment.getReasonFor2FA() && REASON_2FA_SAFI.equalsIgnoreCase(payment.getReasonFor2FA())) {
				payment.setSafiCall(SafiConstants.SAFI_CALL_NOTIFY);		//	flag to indicate which SAFI action to call
			} else {
				payment.setSafiCall("");
			}
			mobileSession.setTransaction(payment);
			
			IMBResp transferResponse = performTransfer(mobileSession, fromAccount, payment, ServiceConstants.PAYEE_TRANSFER_SECURE_SERVICE, commonData, httpRequest,true);
			
			//18E4: Safi Notify Call when Payment is Successful
			boolean isPaymentSuccess = isPaymentSuccess(transferResponse);
			notifyCallForSafi(httpRequest, httpResponse, mobileSession, commonData, payment, digitalSecMap, true /*status2FA*/, isPaymentSuccess);
			//18E4: Safi Notify Call when Payment is Successful
			
			return transferResponse;
		} catch (ResourceException e) {
			Logger.error("Exception DonationController - transferSecure(): GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "]", e, this.getClass());
			mobileSession.removeTransaction();
			mobileSession.removeSecureCodeDetails();
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.SYSTEM_UNAVILABLE, ServiceConstants.PAYEE_TRANSFER_SECURE_SERVICE, httpRequest);
		} catch (Exception e) {
			Logger.error("Exception DonationController - transferSecure(): GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "]", e, this.getClass());
			mobileSession.removeTransaction();
			mobileSession.removeSecureCodeDetails();
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.GENERIC_ERROR, ServiceConstants.PAYEE_TRANSFER_SECURE_SERVICE, httpRequest);
		} finally {
			endPerformanceLog(logName);
		}

	}

	private boolean isPaymentSuccess(IMBResp transferResponse) {
		boolean isPaymentSuccess = true;
		if(transferResponse != null && transferResponse instanceof ErrorResp) {
			ErrorResp errResponse = (ErrorResp)transferResponse;
			if(errResponse.hasErrors()) {
				isPaymentSuccess = false;
			}
		}
		return isPaymentSuccess;
	}

	
	private DigitalSecLogggerVO initializeDigitalLoggers(
			IBankCommonData commonData) {
		DigitalSecLogggerVO digitalSecLoggerVO =new DigitalSecLogggerVO();
		digitalSecLoggerVO.setTranName(DigitalSecLogger.TRANSFER_TO_PAYEE);
		digitalSecLoggerVO.setStatus(DigitalSecLogger.FAILURE_2FA);
		digitalSecLoggerVO.setCommonLogData(mbAppHelper.getCommonLogData(commonData));
		digitalSecLoggerVO.setUserAgent(commonData.getUserAgent());
		return digitalSecLoggerVO;
	}
	
	
	
	/**
	 * Response for invalid body request 
	 * 
	 * @return
	 */
	@ExceptionHandler({org.springframework.http.converter.HttpMessageNotReadableException.class})
	@ResponseStatus(org.springframework.http.HttpStatus.OK)
	@ResponseBody
	public IMBResp resolveException() {
		return MBAppUtils.createInvalidMessageBodyResponse(ServiceConstants.DONATIONS);
	}

	@SuppressWarnings("unchecked")
	private IMBResp performTransfer(MobileSession mobileSession, Account fromAccount, ThirdPartyPayment payment, String caller, IBankCommonData commonData, HttpServletRequest httpRequest,boolean is2FADone)
			throws BusinessException, Exception {
		
		DigitalSecLogggerVO digitalSecLoggerVO =new DigitalSecLogggerVO();
        digitalSecLoggerVO.setTranName(DigitalSecLogger.TRANSFER_TO_PAYEE);
        digitalSecLoggerVO.setStatus(DigitalSecLogger.SUCCESS);
		digitalSecLoggerVO.setCommonLogData(mbAppHelper.getCommonLogData(commonData));
		digitalSecLoggerVO.setUserAgent(commonData.getUserAgent());
		
		//	devicePrint will be available in case of native app only and will be passed to forensic log
		String devicePrint = mobileSession.getSafiLogonInfo()!= null ? mobileSession.getSafiLogonInfo().getDevicePrint() : "";
		Logger.debug("performTransfer() devicePrint from native app : "+devicePrint, this.getClass());
		
		try {
			Receipt receipt = pay(payment, mobileSession);
			
			TransferResp response = payeeHelper
					.populateTransferResponse(populateResponseHeader(ServiceConstants.DONATIONS, mobileSession), receipt, payment, mobileSession.getCustomer());
			
			response = payeeHelper.populateDescriptionPayer(mobileSession, response, receipt, commonData);
			
			LabelValueMap digitalSecMap = mobileSession.getDigitalSecLoggerMap();
			String digitalSecValues = null;
			
			boolean isMobileApp = ((logonHelper.loadCordova(httpRequest)) == -1) ? false:true;
			SafiForensicInfo safiForensicInfo = populateSafiForensicInfoVO(payment.getSafiRespVO(), devicePrint);
			if(is2FADone){				
				if (payment.getScheduleDetails() != null && ((payment.getScheduleDetails().getId()== null || "".equals(payment.getScheduleDetails().getId() ) ))) {
					digitalSecLoggerVO.setValues(((ThirdPartyPayment)payment).toSchLog(false,digitalSecMap.get(DigitalSecLogger.AUTHTYPE),digitalSecMap.get(DigitalSecLogger.AUTHPHONE),null));
					digitalSecLogger.log(digitalSecLoggerVO);
				}
				else if(payment.getScheduleDetails() == null){
					digitalSecValues = ((ThirdPartyPayment)payment).toDigitalSecurityLog(false,digitalSecMap.get(DigitalSecLogger.AUTHTYPE),digitalSecMap.get(DigitalSecLogger.AUTHPHONE),null, null);
				}
			}
			else {
				if (payment.getScheduleDetails() != null && ((payment.getScheduleDetails().getId()== null || "".equals(payment.getScheduleDetails().getId() ) ))) {
					digitalSecLoggerVO.setValues(((ThirdPartyPayment)payment).toSchLog(false,CommonBusinessUtil.get2FAExemptType(commonData.getCustomer()),null,null));
					digitalSecLogger.log(digitalSecLoggerVO);

				}
				else if(payment.getScheduleDetails() == null){
					digitalSecValues = ((ThirdPartyPayment)payment).toDigitalSecurityLog(false,CommonBusinessUtil.get2FAExemptType(commonData.getCustomer()),null,null, null);
				}
			}
			if(payment.getScheduleDetails() == null ) {
				digitalSecLoggerVO.setValues(((ThirdPartyPayment)payment).toDigitalSecurityLogNPP(digitalSecValues, "DE", null, "", safiForensicInfo, isMobileApp, is2FADone));
				digitalSecLogger.log(digitalSecLoggerVO);
			}
			
			mobileSession.removeDigitalSecLoggerMap();
			
			mobileSession.removeTransaction();
			mobileSession.removeSecureCodeDetails();
			Logger.debug("DonationController - performTransfer(). Response: " + response, this.getClass());
			
			return response;
		} catch (DuplicateException e) {
			Logger.info("DuplicateException in DonationController - transfer() - [key: " + e.getKey() + "], GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());
			if (e.getKey() == BusinessException.DUPLICATE_PAYMENT) {
				return payeeHelper.populateTransferResponse(populateResponseHeader(caller, mobileSession), (List<PaymentDuplicateVO>) ((DuplicateException) e)
						.getDuplicatePaymentList(), mobileSession.getCustomer().getAccounts());
			}
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), e, caller, httpRequest);
		} catch (BusinessException e) {
			Logger.info("BusinessException in DonationController - transfer() - [key: " + e.getKey() + "], GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());

			if (e.getKey() == BusinessException.IBANK_SECURE_REQUIRED) {
				//	Call SAFI notify call only when it gives challenge response in analyze call
				//	In case SAFI gives allow response and EHUB throws a 2FA challenge then do not make SAFI notify call
				setReasonFor2FA(payment);
				
				return payeeHelper.populateSecureRequiredResponse(populateResponseHeader(caller, mobileSession), mobileSession.getCustomer(), mobileSession.getOrigin(), caller, httpRequest);
			
			} else if(e.getKey() == BusinessException.SAFI_PAYMENT_NO_PHONE_EXIST
					|| e.getKey() == BusinessException.SAFI_PAYMENT_2FA_EXEMPT
					|| e.getKey() == BusinessException.SAFI_PAYMENT_2FA_GLOBAL_BYPASS) {
				
				String[] values = getContactNumber(mobileSession);
				return MBAppUtils.createErrorResp(mobileSession.getOrigin(), e,values, ServiceConstants.DONATIONS, httpRequest);
				
			} else {
				saveDigitalSecureLog(httpRequest, mobileSession, commonData, payment, is2FADone /*is2FADone*/, false /*paymentSuccess*/);

				if (e.getKey() == BusinessException.ACCOUNT_AMT_BELOW_MIN_REDRAW) {
					String minAmt = "";
					if (fromAccount != null && fromAccount.getLimits() != null) {
						minAmt = String.valueOf(fromAccount.getLimits().getMinimumRedrawAmount());
					}
					return MBAppUtils.createErrorResp(mobileSession.getOrigin(), e.getKey(), MBAppUtils.getMessage(mobileSession.getOrigin(), e.getKey(), new String[] { minAmt }), caller, httpRequest);

				} else if (e.getKey() == BusinessException.PAYER_NAME_INVALID) {
					return MBAppUtils.createErrorResp(mobileSession.getOrigin(), e.getKey(), MBAppUtils.getMessage(mobileSession.getOrigin(), e.getKey(), new String[] { NOTALLOW_CHAR_PAYER_NAME }), caller, httpRequest);
				} else if (e.getKey() == BusinessException.INVALID_CHAR_SET) {
					throw new BusinessException(BusinessException.INVALID_CHAR_SET, "Invalid Character");
				} else if(e.getKey()==BusinessException.SAFI_PAYMENT_DENY_ERROR){
					
					String[] values = getContactNumber(mobileSession);
					IMBResp resp1 = MBAppUtils.createErrorResp(mobileSession.getOrigin(), e,values, ServiceConstants.DONATIONS, httpRequest);
					return resp1;
				} 
				else if (e.getKey() == BusinessException.EXCEED_DAILY_LIMIT) {
					BusinessException businessException;
					String[] errorParams = new String[1];
					if(PrudentialLimitHelper.isAsgardNominatedAccount(payment)){
						errorParams[0] = PrudentialLimitHelper.ECASH_BANK_SETUP_EXCEPTION_PARAM;						
					}
					else if(payment.getToThirdParty().getBankSetup()) {
						errorParams[0] = PrudentialLimitHelper.BANK_SETUP_EXCEPTION_PARAM;						
					}
					else {
						errorParams[0] = PrudentialLimitHelper.CUST_SETUP_CUMULATIVE_EXCEPTION_PARAM;						
					}
					businessException = new BusinessException(BusinessException.DB_ACCT_EXCEEDS_DAILY_LIMIT,errorParams);
					return MBAppUtils.createErrorResp(mobileSession.getOrigin(), businessException, businessException.getValues(),caller, httpRequest);
				}
				else {					
					return MBAppUtils.createErrorResp(mobileSession.getOrigin(), e, e.getValues(),caller, httpRequest);
				}
			}
		} catch (ResourceException e) {
			saveDigitalSecureLog(httpRequest, mobileSession, commonData, payment,  is2FADone /*is2FADone*/, false /*paymentSuccess*/);
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), e, caller, httpRequest);
		}
	}
	
	private String[] getContactNumber(MobileSession mobileSession) {
		OriginsVO myOriginVO = IBankParams.getOrigin(mobileSession.getOrigin());
		OriginsVO baseOrigin = IBankParams.getOrigin(myOriginVO.getBankName());
		String[] values = { baseOrigin.getBpayPhone() };
		return values;
	}

	private void setReasonFor2FA(ThirdPartyPayment payment) {
		if(null != payment.getSafiRespVO() && null != payment.getSafiRespVO().getSafiAction() && SafiConstants.SAFI_ACTION_CHALLENGE.equalsIgnoreCase(payment.getSafiRespVO().getSafiAction())) {
			payment.setReasonFor2FA(REASON_2FA_SAFI);
			Logger.debug("performTransfer() SAFI responded with 2FA challenge so setting 2FA reason as SAFI.", this.getClass());
		} else {
			payment.setReasonFor2FA(REASON_2FA_EHUB);
			Logger.debug("performTransfer() EHUB threw 2FA challenge so setting 2FA reason as EHUB.", this.getClass());
		}	
	}

	private Receipt pay(ThirdPartyPayment payment, MobileSession mobileSession) throws BusinessException {
		Logger.debug("Payment object - " + ReflectionToStringBuilder.toString(payment, ToStringStyle.MULTI_LINE_STYLE), this.getClass());
		Receipt receipt = transactService.performTransfer(payment);
		Logger.debug("Receipt - " + ReflectionToStringBuilder.toString(receipt, ToStringStyle.MULTI_LINE_STYLE), this.getClass());
		// throw new BusinessException(BusinessException.IBANK_SECURE_REQUIRED);
		Customer updatedCustomer = payment.getCommonData().getCustomer();
		mobileSession.setCustomer(updatedCustomer);
		// send email if needed
		if (mobileSession.isSendPaymentEmail() != null && mobileSession.isSendPaymentEmail()) {
			// if an email needs to be sent to customer
			Logger.debug("Sending email: ", this.getClass());
			transactService.sendPayerEmailReceipt(payment, receipt, MBAppHelper.getAccountbyAccountId(payment.getFromAccount(), updatedCustomer
					.getAccounts()), payment.getToThirdParty());
			mobileSession.removeSendPaymentEmail();
		}
		return receipt;
	}
	
	public ErrorResp validate(IMBReq serviceRequest, HttpServletRequest request) {
		Logger.info("Service request object - " + ReflectionToStringBuilder.toString(serviceRequest), this.getClass());
		return mbAppValidator.validate(serviceRequest, request);
	}

	public RespHeader populateResponseHeader(String serviceName, MobileSession mobSession) {
		return mbAppHelper.populateResponseHeader(serviceName, mobSession);
	}
	
	public void validateRequestHeader(ReqHeader headerReq, HttpServletRequest request) throws BusinessException {
		Logger.debug("Request header validation: " + ReflectionToStringBuilder.toString(headerReq, ToStringStyle.MULTI_LINE_STYLE), this.getClass());
		new MBAppValidator().validateRequestHeader(headerReq, request);
	}
	
	@Autowired
	private PerformanceLogger perfLogger;
	
	private String startPerformanceLog(HttpServletRequest httpRequest){
		perfLogger.startAllLogs();
		String logName = MBAppUtils.getLogName(httpRequest);
		perfLogger.startLog(logName);
		return logName;
	}
	
	private void endPerformanceLog(String logName){
		perfLogger.endLog(logName);
		perfLogger.endAllLogs();
	}
	
	private void createOrUpdatePMData2Cookie(HttpServletRequest httpServletRequest,SafiRespVO safiRespVO,HttpServletResponse httpServletResponse){
		
		if(safiRespVO != null){
			Logger.debug("SAFI : DonationController Read cookie ", this.getClass());
			Cookie pmdata2 = SafiWebHelper.readCookies(httpServletRequest);
			Logger.debug("SAFI : DonationController.createOrUpdatePMData2Cookie(): PMDATA2 cookie received : "+ pmdata2, this.getClass());
			//create or update cookie and save
			Cookie newCookie = SafiWebHelper.createOrUpdatePmdata2Cookie(httpServletRequest,pmdata2,safiRespVO.getDeviceToken());
			Logger.debug("SAFI : DonationController.createOrUpdatePMData2Cookie(): Setting PMDATA2 cookie in resp : "+ newCookie.getValue(), this.getClass());
			httpServletResponse.addCookie(newCookie);
			Logger.debug("SAFI : DonationController.createOrUpdatePMData2Cookie(): PMDATA2 cookie setting resp done: "+ newCookie.getValue(), this.getClass());
		}
	}

	private void handleSafiResponse(ThirdPartyPayment tpPayment,HttpServletRequest httpRequest,HttpServletResponse httpServletResponse) {
		if(tpPayment != null && ThirdPartyTransferHelper.isSafiApplicableForAnalyze(tpPayment) && 
			    tpPayment.getSafiCall() != null && tpPayment.getSafiCall().equalsIgnoreCase(SafiConstants.SAFI_CALL_ANALYZE)) {
			if(tpPayment != null && tpPayment.getSafiRespVO() != null) {
				SafiRespVO safiRespVO = tpPayment.getSafiRespVO();
				Logger.debug("SAFI : DonationController.handleSafiResponse: safiRespVO not NULL. Updating PMData2 Cookie.",this.getClass());
				createOrUpdatePMData2Cookie(httpRequest,safiRespVO, httpServletResponse);			
			}
		}
	}

	private void notifyCallAndUpdateCookie(HttpServletRequest httpRequest, MobileSession mobileSession, ThirdPartyPayment payment,HttpServletRequest httpServletRequest,HttpServletResponse httpServletResponse ,IBankCommonData commonData,LabelValueMap digitalSecMap,boolean status2FA,boolean isPaymentSuccess) throws BusinessException{
		Logger.debug("SAFI : DonationController.notifyCallAndUpdateCookie():START", this.getClass());
		if(payment != null){
			//populate the safiPayTranVO for notify call
			SafiWebHelper.populateSafiVOForNotifyThirdPartyPayment(httpRequest, mobileSession, payment, digitalSecMap, status2FA,isPaymentSuccess);
			
			//SAFI Notify Call
			SafiRespVO safiRespVO = payeeService.notifyCallForThirdPartyTransfer(commonData,payment.getSafiPayTranVO());
			//create or update cookie and save
			createOrUpdatePMData2Cookie(httpServletRequest,safiRespVO , httpServletResponse);
		}
		Logger.debug("SAFI : DonationController.notifyCallAndUpdateCookie():END", this.getClass());
	}
	
	//	This method saves payment and SAFI response details in digital secure log
	private void saveDigitalSecureLog(HttpServletRequest httpRequest, MobileSession mobileSession, IBankCommonData commonData, ThirdPartyPayment payment, boolean is2FADone, boolean paymentSuccess) throws BusinessException {
		DigitalSecLogggerVO digitalSecLoggerVO = new DigitalSecLogggerVO();
        digitalSecLoggerVO.setTranName(DigitalSecLogger.TRANSFER_TO_PAYEE);
		digitalSecLoggerVO.setCommonLogData(mbAppHelper.getCommonLogData(commonData));
		digitalSecLoggerVO.setUserAgent(commonData.getUserAgent());
		if(paymentSuccess) {
			digitalSecLoggerVO.setStatus(DigitalSecLogger.SUCCESS);
		} else {
			digitalSecLoggerVO.setStatus(DigitalSecLogger.FAILURE);
		}
		
		LabelValueMap digitalSecMap = mobileSession.getDigitalSecLoggerMap();
		String reasonCode = "";
		if(payment instanceof NPPPayment) {
			reasonCode = ((NPPPayment)payment).getReasonCode();			
		}
		
		String paymentType = mobileSession.getPaymentType();
		if (null == mobileSession.getPaymentType()) {
			paymentType = "";
		}
		String devicePrint =  mobileSession.getSafiLogonInfo()!= null ? mobileSession.getSafiLogonInfo().getDevicePrint() : "";
		
		boolean isMobileApp = ((logonHelper.loadCordova(httpRequest)) == -1) ? false:true;
		SafiForensicInfo safiForensicInfo = populateSafiForensicInfoVO(payment.getSafiRespVO(), devicePrint);
		String digiSecValues = null;
		if(is2FADone){
			digiSecValues = ((ThirdPartyPayment)payment).toDigitalSecurityLog(false,digitalSecMap.get(DigitalSecLogger.AUTHTYPE),digitalSecMap.get(DigitalSecLogger.AUTHPHONE),null, null);
		} else {
			digiSecValues = ((ThirdPartyPayment)payment).toDigitalSecurityLog(false,CommonBusinessUtil.get2FAExemptType(commonData.getCustomer()),null,null, null);
		}
		/*if(null != payment && payment instanceof NPPPayment && ((NPPPayment)payment).isDeRetry()) {
			digitalSecLoggerVO.setStatus(DigitalSecLogger.FAILURE);
			digitalSecLoggerVO.setValues(((ThirdPartyPayment)payment).toDigitalSecurityLogNPP(digiSecValues, paymentType.equalsIgnoreCase(OSKO) ? "Osko" : "DE", payment.isRetryDEConsent(),reasonCode, safiForensicInfo, isMobileApp, is2FADone));
			digitalSecLogger.log(digitalSecLoggerVO);
			digitalSecLoggerVO.setStatus(DigitalSecLogger.SUCCESS);
			paymentType = "DE";
		}*/
		digitalSecLoggerVO.setValues(((ThirdPartyPayment)payment).toDigitalSecurityLogNPP(digiSecValues, paymentType.equalsIgnoreCase(OSKO) ? "Osko" : "DE", null, reasonCode, safiForensicInfo, isMobileApp, is2FADone));
		digitalSecLogger.log(digitalSecLoggerVO);
		
		mobileSession.removeDigitalSecLoggerMap();
	}
	
	private SafiForensicInfo populateSafiForensicInfoVO(SafiRespVO safiRespVO, String devicePrint) {
		SafiForensicInfo safiForensicInfo = null;
		if(safiRespVO != null) {
			safiForensicInfo = new SafiForensicInfo();
			
			safiForensicInfo.setSafiAction(safiRespVO.getSafiAction());
			safiForensicInfo.setSafiClientTransactionId(safiRespVO.getSafiClientTransactionId());
			safiForensicInfo.setSafiRiskScore(safiRespVO.getSafiRiskScore() != null ? safiRespVO.getSafiRiskScore().toString() : "");
			safiForensicInfo.setSafiRuleName(safiRespVO.getSafiRuleName());
			safiForensicInfo.setSafiSdkDevicePrint(devicePrint);
		}
		return safiForensicInfo;
	}
	
	private ThirdPartyPayment populatePayment(Account fromAccount, Customer customer, IBankCommonData commonData, DonationTransferReq request, MobileSession mobileSession)
			throws BusinessException {
		ThirdPartyPayment thirdPartyPayment = new ThirdPartyPayment();
		thirdPartyPayment.setBatch(false);
		thirdPartyPayment.setCommonData(commonData);
		thirdPartyPayment.setFromAccount(fromAccount.getAccountId());
		thirdPartyPayment.setFlEmailCopy(false);
		thirdPartyPayment.setToThirdParty(donationsService.getFoundationParty(commonData));
		
		thirdPartyPayment.getToThirdParty().setPayerName(request.getPayerName());
		if (thirdPartyPayment.getToThirdParty().getPayerName()==null){
			thirdPartyPayment.getToThirdParty().setPayerName("");
		}
		thirdPartyPayment.setAmount(new BigDecimal(request.getAmt()));
		thirdPartyPayment.setDescription(TRANSFER_DESC); 
		if (thirdPartyPayment.getDescription()==null){
			thirdPartyPayment.setDescription("");
		}
		thirdPartyPayment.setIpAddress(commonData.getIpAddress());
		thirdPartyPayment.setSessionId(commonData.getSessionId());
		thirdPartyPayment.setBrand(commonData.getOrigin());
		thirdPartyPayment.setCheckForDuplicate(true);
		if (request.getOverrideDup() != null)
			thirdPartyPayment.setCheckForDuplicate(!request.getOverrideDup());
		if (request.getDupCount() != null)
			thirdPartyPayment.setDuplicatePaymentCount(request.getDupCount());
		thirdPartyPayment.setPayerName(request.getPayerName());
		if (thirdPartyPayment.getPayerName()==null){
			thirdPartyPayment.setPayerName("");
		}		
		thirdPartyPayment.setNewThirdParty(true);
		
		thirdPartyPayment.setSchedule(false);
		
		thirdPartyPayment.setOrigination(ORIGINATION);
		//thirdPartyPayment.setRetryDEConsent(false);
		thirdPartyPayment.setOnUsTransfer(false);
		
		return thirdPartyPayment;
	}
	
}
