package au.com.stgeorge.mbank.model.accountinfo;

import au.com.stgeorge.mbank.model.common.IMBResp;
import au.com.stgeorge.mbank.model.common.RespHeader;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

/**
 * 
 * @author C38854
 * 
 */
@JsonInclude(Include.NON_NULL)
public class HomeLoanIncreaseLinkResp extends HomeLoanIncreaseResp implements IMBResp {

	private static final long serialVersionUID = -5035742318425676965L;
	private RespHeader header;

	public HomeLoanIncreaseLinkResp(RespHeader header) {
		this.header = header;
	}

	public void setHeader(RespHeader header) {
		this.header = header;
	}

	public RespHeader getHeader() {
		return header;
	}
	

}
