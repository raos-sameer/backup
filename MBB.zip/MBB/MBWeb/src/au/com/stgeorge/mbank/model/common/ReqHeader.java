package au.com.stgeorge.mbank.model.common;

import java.io.Serializable;

import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.NotEmpty;

import au.com.stgeorge.ibank.businessobject.BusinessException;
import au.com.stgeorge.mbank.util.ServiceConstants;


public class ReqHeader implements Serializable{

	private static final long serialVersionUID = 5297519451570513390L;	
	
	@NotEmpty (message = ""+BusinessException.WSVC_INVALID_INPUT_PARAM)
	@Size(max = 10,message = ServiceConstants.INVALID_INPUT_PARAMS)
	@Pattern(regexp="([0-9\\.]+)",message = ServiceConstants.INVALID_INPUT_PARAMS)	
	protected String clientApiVersion;

	public String getClientApiVersion() {
		return clientApiVersion;
	}

	public void setClientApiVersion(String clientApiVersion) {
		this.clientApiVersion = clientApiVersion;
	}
	
	
	/*
	@NotEmpty (message = ""+BusinessException.WSVC_INVALID_INPUT_PARAM)
	//@Size(max = 10,message = ServiceConstants.INVALID_INPUT_PARAMS)
	@Pattern(regexp="([a-zA-Z0-9]+)",message = ""+BusinessException.WSVC_INVALID_INPUT_PARAM)
	private String nameId;

	public String getNameId()
	{
		return nameId;
	}

	public void setNameId(String nameId)
	{
		this.nameId = nameId;
	}
 */

	@NotEmpty (message = ""+BusinessException.WSVC_INVALID_INPUT_PARAM)
	//@Size(max = 10,message = ServiceConstants.INVALID_INPUT_PARAMS)
	@Pattern(regexp="([a-zA-Z0-9]+)",message = ""+BusinessException.WSVC_INVALID_INPUT_PARAM)
	protected String serviceName;

	public String getServiceName()
	{
		return serviceName;
	}

	public void setServiceName(String serviceName)
	{
		this.serviceName = serviceName;
	}
	

	@NotEmpty (message = ""+BusinessException.SMPL_INV_INP_PARAMS)
	@Size(max = 50,message = ""+BusinessException.SMPL_INV_INP_PARAMS)
	@Pattern(regexp="([a-zA-Z0-9-]+)",message = ""+BusinessException.SMPL_INV_INP_PARAMS)	
	protected String deviceID;
	
	public String getDeviceID()
	{
		return deviceID;
	}

	public void setDeviceID(String deviceID)
	{
		this.deviceID = deviceID;
	}

	@NotEmpty (message = ""+BusinessException.SMPL_INV_INP_PARAMS)
	@Size(max = 100,message = ""+BusinessException.SMPL_INV_INP_PARAMS)
	@Pattern(regexp="([a-zA-Z0-9-]+)",message = ""+BusinessException.SMPL_INV_INP_PARAMS)	
	protected String nameId;

	public String getNameId()
	{
		return nameId;
	}

	public void setNameId(String nameId)
	{
		this.nameId = nameId;
	}

	@NotEmpty (message = ""+BusinessException.WSVC_INVALID_INPUT_PARAM)
	protected String prevTime;

	public String getPrevTime() {
		return prevTime;
	}

	public void setPrevTime(String prevTime) {
		this.prevTime = prevTime;
	}

	@NotEmpty (message = ""+BusinessException.WSVC_INVALID_INPUT_PARAM)
	protected String prevTran;
	
	
	
	public String getPrevTran() {
		return prevTran;
	}

	public void setPrevTran(String prevTran) {
		this.prevTran = prevTran;
	}
	
	private String deviceType;


	public String getDeviceType()
	{
		return deviceType;
	}
	public void setDeviceType(String deviceType)
	{
		this.deviceType = deviceType;
	}
	
	//Added to solve the issue of Session sharing among multiple tabs or browsers and multiple applications are trying to update using the same session. 
	@Pattern(regexp="([0-9]+)",message = ""+BusinessException.DIGITAL_MORTGAGE_CLAS_SVC_UNAVAILABLE)
	protected String mortgageApplicationNum;

	public String getMortgageApplicationNum() {
		return mortgageApplicationNum;
	}

	public void setMortgageApplicationNum(String mortgageApplicationNum) {
		this.mortgageApplicationNum = mortgageApplicationNum;
	}

	
	@Pattern(regexp="([0-9]+)",message = ""+BusinessException.DIGITAL_MORTGAGE_CLAS_SVC_UNAVAILABLE)
	protected String tranSeqnbr;

	public String getTranSeqnbr()
	{
		return tranSeqnbr;
	}

	public void setTranSeqnbr(String tranSeqnbr)
	{
		this.tranSeqnbr = tranSeqnbr;
	}

	

}
