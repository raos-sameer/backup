package au.com.stgeorge.mbank.controller.statements;


import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;

import au.com.stgeorge.framework.common.logging.Logger;
import au.com.stgeorge.ibank.businessobject.BusinessException;
import au.com.stgeorge.ibank.businessobject.CardService;
import au.com.stgeorge.ibank.businessobject.ProofOfStmtService;
import au.com.stgeorge.ibank.businessobject.ResourceException;
import au.com.stgeorge.ibank.util.PDFStatmentUtil;
import au.com.stgeorge.ibank.valueobject.Account;
import au.com.stgeorge.ibank.valueobject.PDFStore;
import au.com.stgeorge.ibank.valueobject.Statistic;
import au.com.stgeorge.ibank.valueobject.TransactionHistory;
import au.com.stgeorge.ibank.valueobject.transfer.IBankCommonData;
import au.com.stgeorge.mbank.controller.IMBController;
import au.com.stgeorge.mbank.model.common.IMBReq;
import au.com.stgeorge.mbank.model.common.IMBResp;
import au.com.stgeorge.mbank.model.common.ReqHeader;
import au.com.stgeorge.mbank.model.common.RespHeader;
import au.com.stgeorge.mbank.model.request.statements.ProofOfStmtReq;
import au.com.stgeorge.mbank.model.response.ErrorResp;
import au.com.stgeorge.mbank.model.response.statements.ProofOfStmtResp;
import au.com.stgeorge.mbank.session.MobileSession;
import au.com.stgeorge.mbank.util.MBAppHelper;
import au.com.stgeorge.mbank.util.MBAppUtils;
import au.com.stgeorge.mbank.util.MBAppValidator;
import au.com.stgeorge.mbank.util.ServiceConstants;
import au.com.stgeorge.perflogger.PerformanceLogger;
import au.com.stgeorge.security.util.StringMethods;

import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * @author c50216
 *
 */
@Controller
@RequestMapping("/proofstmt")
public class ProofOfStmtController implements IMBController{

	private static final String PROOF_ACCOUNT_BALANCE = "acctBalance";
	private static final String TRANSACTION_LISTING = "transactionListing";
	
	@Autowired
	private CardService cardService;
	
	@Autowired
	private MBAppHelper mbAppHelper;
	
	@Autowired
	private MBAppValidator mbAppValidator;
	
	@Autowired
	private PerformanceLogger perfLogger;
	
	@Autowired
	private ProofOfStmtHelper proofOfStmtHelper;			
	
	@Autowired
	private ProofOfStmtService proofOfStmtService;	
	
	@RequestMapping(value= "acctList" , method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public IMBResp getAccountList(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse,
			@RequestBody final ProofOfStmtReq req)
	{				
				
		ObjectMapper objectMapper = new ObjectMapper();							
		perfLogger.startAllLogs();
		String logName = MBAppUtils.getLogName(httpServletRequest);
		perfLogger.startLog(logName);		
		MobileSession mbSession = null;		
		try{	
			
			mbSession = mbAppHelper.getMobileSession(httpServletRequest);												
			Logger.info("getAccountList()  Info JSON Request :" + objectMapper.writeValueAsString(req), this.getClass());
			
			validateRequestHeader(req.getHeader(), httpServletRequest);
			ErrorResp errorResp = validate(req, httpServletRequest);
			if (errorResp != null && errorResp.getErrors() != null && errorResp.getErrors().size() > 0)
			{									
				return errorResp;
			}								
			
			IBankCommonData commonData=mbAppHelper.populateIBankCommonData(mbSession, httpServletRequest);
			
			List<Account> acctList = (List<Account>)proofOfStmtService.getAccountList(commonData, req.getStmtType());
				
			IMBResp serviceResponse = proofOfStmtHelper.populateProofOfBalanceAcctListResp(acctList);	
			
			RespHeader headerResp = populateResponseHeader(ServiceConstants.PROOF_OF_STATEMENT, mbSession);
			serviceResponse.setHeader(headerResp);			
			Logger.info("getAccountList() JSON Response :" + objectMapper.writeValueAsString(serviceResponse), this.getClass());
			
			return serviceResponse;		
			
		}catch (BusinessException e)
		{
			BusinessException exp = null;
			Logger.info("BusinessException Inside getAccountList() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "]", e, this.getClass());		
			
			exp = new BusinessException(e.getKey());
			IMBResp resp1  = MBAppUtils.createErrorResp(mbSession.getOrigin() ,exp, ServiceConstants.PROOF_OF_STATEMENT, httpServletRequest);
			return resp1;
		}catch (ResourceException e) {
			Logger.error("ResourceException Inside getAccountList() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "]", e, this.getClass());			
			ResourceException exp = new ResourceException(e.getKey());
			IMBResp resp1  = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, ServiceConstants.PROOF_OF_STATEMENT, httpServletRequest);
			return resp1;
		}catch (Exception e)
		{			
			Logger.error("Exception Inside getAccountList() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "]", e, this.getClass());
			BusinessException exp = new BusinessException(BusinessException.GENERIC_ERROR);
			IMBResp resp1  = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, ServiceConstants.PROOF_OF_STATEMENT, httpServletRequest);
			return resp1;
		} finally
		{
			perfLogger.endLog(logName);
			perfLogger.endAllLogs();
		}				
	}
	
	@RequestMapping(value= "acctBalance" , method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public IMBResp accountBalance(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse,
			@RequestBody final ProofOfStmtReq req)
	{				
		return null;
	}

	@RequestMapping(value= "proofOfStmtToken" , method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public IMBResp getProofOfStmtToken(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse,
			@RequestBody final ProofOfStmtReq req)
	{
		
		Logger.debug("ProofOfStmtController - getProofOfStmtToken(). Request: " + httpServletRequest, this.getClass());
		perfLogger.startAllLogs();
		String logName = MBAppUtils.getLogName(httpServletRequest);
		perfLogger.startLog(logName);		

		ProofOfStmtResp serviceResponse = null;
		MobileSession mbSession = null;
		try {
			
			mbSession = mbAppHelper.getMobileSession(httpServletRequest);
			
			validateRequestHeader(req.getHeader(), httpServletRequest);
			ErrorResp errorResp = validate(req, httpServletRequest);
			if (errorResp != null && errorResp.getErrors() != null && errorResp.getErrors().size() > 0)
			{									
				return errorResp;
			}
			
			IBankCommonData commonData=mbAppHelper.populateIBankCommonData(mbSession, httpServletRequest);
				
			if (PROOF_ACCOUNT_BALANCE.equalsIgnoreCase(req.getStmtType()) && req.getAccountList() != null && !req.getAccountList().isEmpty())
			{
				ArrayList<Account> selectedAcctList = new ArrayList<Account>();
		
				for (Integer index : req.getAccountList())
				{
					Account acct = mbAppHelper.getAccountFromCustomer(commonData.getCustomer(), index);
					if (acct != null)
					{
						selectedAcctList.add(acct);
					}
				}
				
				if(!selectedAcctList.isEmpty())
				{							
					Date todayDate = new Date();
					String reportDate = PDFStatmentUtil.getReportDate(todayDate);
					
					byte[] pdfData = proofOfStmtService.generateAccountBalancePdf(commonData.getCustomer(), selectedAcctList, reportDate, commonData.getOrigin());

					String pdfFileName = PDFStatmentUtil.getAccountBalanceFileName(todayDate);
					
					PDFStore pdfStore = new PDFStore();
					Date today = new Date();
					
					String pdfToken = mbAppHelper.getPdfDocToken();
					pdfStore.setToken(pdfToken);
					pdfStore.setCreatedby(mbSession.getUser().getUserId());
					pdfStore.setCreatedon(today);
					pdfStore.setExpiryTime(getExpiryDate(today));
					pdfStore.setGcisNumber(mbSession.getCustomer().getGcis());
					pdfStore.setPdfData(pdfData);
					pdfStore.setPdfFilename(pdfFileName);
					
					proofOfStmtService.addPDFDocTokenDetails(pdfStore);
					
					serviceResponse = new ProofOfStmtResp();
					serviceResponse.setToken(pdfToken);
					
					RespHeader headerResp = populateResponseHeader(ServiceConstants.PROOF_OF_STATEMENT_TOKEN, mbSession);
					serviceResponse.setHeader(headerResp);
					
					//GDW Statistics log
					proofOfStmtService.makeStatisticsLog(commonData, selectedAcctList, Statistic.PROOF_OF_BALANCE, null);					 										
				}
			}else if (TRANSACTION_LISTING.equalsIgnoreCase(req.getStmtType()) && req.getAccountList() != null && !req.getAccountList().isEmpty() && !StringMethods.isEmptyString(req.getTransactionPeriod()))
			{
				Integer accountIndex = req.getAccountList().get(0);
				Account selectedAccount = mbAppHelper.getAccountFromCustomer(commonData.getCustomer(), accountIndex);
				
				if(selectedAccount != null)
				{							
					Date todayDate = new Date();
					
					String transPeriod = req.getTransactionPeriod();
					
					TransactionHistory transactionHistory = proofOfStmtService.fetchTransactionHistory(selectedAccount, commonData, Integer.parseInt(transPeriod));
					
					byte[] pdfData = proofOfStmtService.generateTransactionListingPdf(commonData.getCustomer(), selectedAccount, transactionHistory, todayDate, Integer.parseInt(transPeriod), commonData.getOrigin());

					String pdfFileName = PDFStatmentUtil.getTransactionListingFileName(selectedAccount, todayDate);
					
					PDFStore pdfStore = new PDFStore();
					Date today = new Date();
					
					String pdfToken = mbAppHelper.getPdfDocToken();
					pdfStore.setToken(pdfToken);
					pdfStore.setCreatedby(mbSession.getUser().getUserId());
					pdfStore.setCreatedon(today);
					pdfStore.setExpiryTime(getExpiryDate(today));
					pdfStore.setGcisNumber(mbSession.getCustomer().getGcis());
					pdfStore.setPdfData(pdfData);
					pdfStore.setPdfFilename(pdfFileName);
					
					proofOfStmtService.addPDFDocTokenDetails(pdfStore);
					
					serviceResponse = new ProofOfStmtResp();
					serviceResponse.setToken(pdfToken);
					
					RespHeader headerResp = populateResponseHeader(ServiceConstants.PROOF_OF_STATEMENT_TOKEN, mbSession);
					serviceResponse.setHeader(headerResp);
				
					List<Account> selectedAccountList = new ArrayList<Account>();
					selectedAccountList.add(selectedAccount);
					//GDW Statistics log
					proofOfStmtService.makeStatisticsLog(commonData, selectedAccountList, Statistic.PROOF_OF_TRANSACTION, transPeriod);
				}
			}					
		} catch (BusinessException e) {
			Logger.info("BusinessException Inside getProofOfStmtToken() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "]", e, this.getClass());		
			
			IMBResp resp1  = MBAppUtils.createErrorResp(mbSession!=null ? mbSession.getOrigin():null ,e, ServiceConstants.PROOF_OF_STATEMENT_TOKEN, httpServletRequest);
			return resp1;
		} finally
		{
			perfLogger.endLog(logName);
			perfLogger.endAllLogs();
		}	
		
		if(serviceResponse == null)
		{
			return new ErrorResp(null);
		}
		
		return serviceResponse;
	}

	/**
	 * Response for invalid body request 
	 * 
	 * @return
	 */
	@ExceptionHandler({org.springframework.http.converter.HttpMessageNotReadableException.class})
	@ResponseStatus(org.springframework.http.HttpStatus.OK)
	@ResponseBody
	public IMBResp resolveException() {		
		return MBAppUtils.createInvalidMessageBodyResponse(ServiceConstants.ATM_LIMIT_UPDATE);
	}
	
	public ErrorResp validate(IMBReq serviceRequest, HttpServletRequest request) {
		return mbAppValidator.validate(serviceRequest, request);
	}
	
	public void validateRequestHeader(ReqHeader header, HttpServletRequest request) throws ResourceException
	{	
		mbAppValidator.validateRequestHeader(header,  request);	
	}
	
	public RespHeader populateResponseHeader(String serviceName, MobileSession mobSession )
	{
		return mbAppHelper.populateResponseHeader(serviceName, mobSession);
	}
	
	private Date getExpiryDate(Date today){
		Calendar cal = Calendar.getInstance(); 
	    cal.setTime(today); 
	    cal.add(Calendar.MINUTE, 3);
	    return cal.getTime();
	}
	
}
