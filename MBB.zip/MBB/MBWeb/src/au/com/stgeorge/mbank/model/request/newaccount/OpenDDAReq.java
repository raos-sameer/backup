package au.com.stgeorge.mbank.model.request.newaccount;

import java.io.Serializable;

import au.com.stgeorge.ibank.valueobject.transfer.NewDDAAccount;
import au.com.stgeorge.mbank.model.common.IMBReq;
import au.com.stgeorge.mbank.model.common.ProductReq;
import au.com.stgeorge.mbank.model.common.ReqHeader;

public class OpenDDAReq implements IMBReq, Serializable{
	
	private static final long serialVersionUID = -256469501889499119L;
	
	//19E3 TFN Changes
	private String selectedOption;
	private String taxFileNumber;
	private String selectedExemption;
	

	public String getDupCount() {
		return dupCount;
	}
	public void setDupCount(String dupCount) {
		this.dupCount = dupCount;
	}
	public String getCheckDup() {
		return checkDup;
	}
	public void setCheckDup(String checkDup) {
		this.checkDup = checkDup;
	}
	public String getBranchId() {
		return branchId;
	}
	public void setBranchId(String branchId) {
		this.branchId = branchId;
	}
	public String getSavingsTarget() {
		return savingTargetAmount;
	}
	public void setSavingsTarget(String savingTargetAmount) {
		this.savingTargetAmount = savingTargetAmount;
	}
	/*public String getHisaWorkAcct() {
		return hisaWorkAcct;
	}
	public void setHisaWorkAcct(String hisaWorkAcct) {
		this.hisaWorkAcct = hisaWorkAcct;
	} */

    private ReqHeader header;
 
	private ProductReq product;
	public ProductReq getProduct() {
		return product;
	}
	public void setProduct(ProductReq product) {
		this.product = product;
	}

	private String initialAmount;
	public String getInitialAmount() {
		return initialAmount;
	}
	public void setInitialAmount(String initialAmount) {
		this.initialAmount = initialAmount;
	}

	private Integer fundingAccountIndex;
	public Integer getFundingAccountIndex() {
		return fundingAccountIndex;
	}
	public void setFundingAccountIndex(Integer fundingAccountIndex) {
		this.fundingAccountIndex = fundingAccountIndex;
	}

	private boolean requestCard;
	public boolean isRequestCard()
	{
		return requestCard;
	}
	public void setRequestCard(boolean requestCard)
	{
		this.requestCard = requestCard;
	}
	public boolean isCheckDuplicate()
	{
		return checkDuplicate;
	}
	public void setCheckDuplicate(boolean checkDuplicate)
	{
		this.checkDuplicate = checkDuplicate;
	}
	public boolean isDepositNow()
	{
		return depositNow;
	}
	public void setDepositNow(boolean depositNow)
	{
		this.depositNow = depositNow;
	}

	private String dupCount;
	private String checkDup;
	private String branchId;
	private String savingTargetAmount;
//	private String hisaWorkAcct;
	
	private ProductReq additionalProduct;
	public ProductReq getAdditionalProduct()
	{
		return additionalProduct;
	}
	public void setAdditionalProduct(ProductReq additionalProduct)
	{
		this.additionalProduct = additionalProduct;
	}

	private String regionId;
	
	private boolean checkDuplicate;
	private boolean depositNow;
	
	
	
	public String getRegionId() {
		return regionId;
	}
	public void setRegionId(String regionId) {
		this.regionId = regionId;
	}

	private NewDDAAccount newDDAAccount;
   
	public NewDDAAccount getNewDDAAccount() {
		return newDDAAccount;
	}
	public void setNewDDAAccount(NewDDAAccount newDDAAccount) {
		this.newDDAAccount = newDDAAccount;
	}
	public ReqHeader getHeader()
	{
		return header;
	}
	public void setHeader(ReqHeader header)
	{
		this.header = header;
	}
	
	public static long getSerialVersionUID() {
		return serialVersionUID;
	}
	
	
	private boolean isGreenBirdInfoClicked;

	public boolean isGreenBirdInfoClicked() {
		return isGreenBirdInfoClicked;
	}
	public void setIsGreenBirdInfoClicked(boolean isGreenBirdInfoClicked) {
		this.isGreenBirdInfoClicked = isGreenBirdInfoClicked;
	}

	private String aemDigester;

	
	
	public String getAemDigester() {
		return aemDigester;
	}
	public void setAemDigester(String aemDigester) {
		this.aemDigester = aemDigester;
	}
	public String getSelectedOption() {
		return selectedOption;
	}
	public void setSelectedOption(String selectedOption) {
		this.selectedOption = selectedOption;
	}
	public String getTaxFileNumber() {
		return taxFileNumber;
	}
	public void setTaxFileNumber(String taxFileNumber) {
		this.taxFileNumber = taxFileNumber;
	}
	public String getSelectedExemption() {
		return selectedExemption;
	}
	public void setSelectedExemption(String selectedExemption) {
		this.selectedExemption = selectedExemption;
	}

}
