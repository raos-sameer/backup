package au.com.stgeorge.mbank.model.request.payments;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

import org.apache.commons.lang.builder.ReflectionToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;

import au.com.stgeorge.ibank.businessobject.BusinessException;
import au.com.stgeorge.mbank.model.common.IMBReq;
import au.com.stgeorge.mbank.model.common.ReqHeader;

public class PayIdRegStatusReq implements IMBReq {

	private static final long serialVersionUID = -4723751125232692028L;
	private ReqHeader header;
	private String payIdRegIdentifier;
	
	
	//@NotNull(message = "" + BusinessException.WSVC_INVALID_INPUT_PARAM)
	//@Pattern(regexp = "^[0-9]+$", message = "" + BusinessException.WSVC_INVALID_INPUT_PARAM)
	private Integer accountIndex;
	
	public Integer getAccountIndex() {
		return accountIndex;
	}

	public void setAccountIndex(Integer accountIndex) {
		this.accountIndex = accountIndex;
	}

	private boolean isUpdateFlow;
	



	public boolean isUpdateFlow() {
		return isUpdateFlow;
	}

	public void setUpdateFlow(boolean isUpdateFlow) {
		this.isUpdateFlow = isUpdateFlow;
	}

	public ReqHeader getHeader() {
		return header;
	}

	public void setHeader(ReqHeader header) {
		this.header = header;
	}
	
	@Override
	public String toString() {
		return ReflectionToStringBuilder.toString(this, ToStringStyle.MULTI_LINE_STYLE);
	}

	public String getPayIdRegIdentifier() {
		return payIdRegIdentifier;
	}

	public void setPayIdRegIdentifier(String payIdRegIdentifier) {
		this.payIdRegIdentifier = payIdRegIdentifier;
	}

	

}
