/**
 * 
 */
package au.com.stgeorge.mbank.model.msgcentre;

import java.util.Date;

import au.com.stgeorge.mbank.util.JsonDateSerializer;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;

/**
 * @author C50216
 *
 */
@JsonInclude(Include.NON_NULL)
public class MsgDetailResp {

	private long customerMsgId;
	private Boolean allowDeletion=false;
	private String subject;
	private String status;
	private String type;
	private String effectiveDate;
	private Date expiryDate;
					
	public long getCustomerMsgId() {
		return customerMsgId;
	}
	public void setCustomerMsgId(long customerMsgId) {
		this.customerMsgId = customerMsgId;
	}	
	public Boolean isAllowDeletion() {
		return allowDeletion;
	}
	public void setAllowDeletion(Boolean allowDeletion) {
		this.allowDeletion = allowDeletion;
	}
	public String getSubject() {
		return subject;
	}
	public void setSubject(String subject) {
		this.subject = subject;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}	
	
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	@JsonSerialize(using = JsonDateSerializer.class)
	@JsonInclude(Include.NON_NULL)
	public Date getExpiryDate() {						
		return expiryDate;
	}
	public void setExpiryDate(Date expiryDate) {
		this.expiryDate = expiryDate;
	}					
		
	public String getEffectiveDate() {		
		return effectiveDate;
	}
	public void setEffectiveDate(String effectiveDate) {	
		this.effectiveDate = effectiveDate;		
	}			
								
}
