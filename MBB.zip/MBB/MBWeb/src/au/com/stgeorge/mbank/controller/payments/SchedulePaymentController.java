/**
 * 
 */
package au.com.stgeorge.mbank.controller.payments;

import java.util.Calendar;
import java.util.Collection;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;

import au.com.stgeorge.framework.common.logging.Logger;
import au.com.stgeorge.framework.common.util.DateMethods;
import au.com.stgeorge.ibank.businessobject.BusinessException;
import au.com.stgeorge.ibank.businessobject.ResourceException;
import au.com.stgeorge.ibank.util.StringUtil;
import au.com.stgeorge.ibank.valueobject.Account;
import au.com.stgeorge.ibank.valueobject.Customer;
import au.com.stgeorge.ibank.valueobject.Payment;
import au.com.stgeorge.ibank.valueobject.ScheduleDetails;
import au.com.stgeorge.ibank.valueobject.transfer.IBankCommonData;
import au.com.stgeorge.mbank.controller.IMBController;
import au.com.stgeorge.mbank.model.common.IMBReq;
import au.com.stgeorge.mbank.model.common.IMBResp;
import au.com.stgeorge.mbank.model.common.ReqHeader;
import au.com.stgeorge.mbank.model.common.RespHeader;
import au.com.stgeorge.mbank.model.request.EmptyReq;
import au.com.stgeorge.mbank.model.request.IndexReq;
import au.com.stgeorge.mbank.model.request.payments.SchedulePaymentModifyReq;
import au.com.stgeorge.mbank.model.request.payments.SchedulePaymentReq;
import au.com.stgeorge.mbank.model.response.ErrorResp;
import au.com.stgeorge.mbank.model.response.payments.SchedulePaymentResp;
import au.com.stgeorge.mbank.session.MobileSession;
import au.com.stgeorge.mbank.util.FraudLogger;
import au.com.stgeorge.mbank.util.MBAppConstants;
import au.com.stgeorge.mbank.util.MBAppHelper;
import au.com.stgeorge.mbank.util.MBAppUtils;
import au.com.stgeorge.mbank.util.MBAppValidator;
import au.com.stgeorge.mbank.util.ServiceConstants;
import au.com.stgeorge.mobilebank.businessobject.ScheduledPaymentService;
import au.com.stgeorge.perflogger.PerformanceLogger;

import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * @author C50216
 *
 */
@Controller
@RequestMapping("/schedule")
public class SchedulePaymentController implements IMBController{

	private FraudLogger fraudLogger;
	
	@Autowired
	private SchedulePaymentHelper schedulePaymentHelper;
	
	@Autowired
	private MBAppHelper mbAppHelper;
	
	@Autowired
	private MBAppValidator mbAppValidator;
		
	@Autowired
	private ScheduledPaymentService scheduledPaymentService;
	
	@RequestMapping(value = "list", method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public IMBResp processScheduleList(HttpServletRequest httpServletRequest,HttpServletResponse httpServletResponse,
			@RequestBody final EmptyReq req){ 
		
		PerformanceLogger performanceLogger = new PerformanceLogger();
		ObjectMapper objectMapper = new ObjectMapper();										
		Collection scheduleList = null;
		Customer customer = null;		
		performanceLogger.startAllLogs();
		String logName = MBAppUtils.getLogName(httpServletRequest);
		performanceLogger.startLog(logName);		
		fraudLogger = new FraudLogger();		
		MobileSession mbSession = null;
		try{
			mbSession = mbAppHelper.getMobileSession(httpServletRequest);
			Logger.info("Schedule List JSON Request :" + objectMapper.writeValueAsString(req), this.getClass());
			validateRequestHeader(req.getHeader(), httpServletRequest);
			ErrorResp errorResp = validate(req, httpServletRequest);
					
			if (errorResp != null && errorResp.getErrors() != null && errorResp.getErrors().size() > 0)
			{				
				//fraudLogger.logInvalidInput();
				return errorResp;
			}			
																		
			customer = mbSession.getCustomer();
									
			IBankCommonData commonData=mbAppHelper.populateIBankCommonData(mbSession,httpServletRequest);
			scheduleList = scheduledPaymentService.getAllScheduledPayments(commonData);
									
			IMBResp serviceResponse = schedulePaymentHelper.populateScheduleListResp(scheduleList, customer, false);
			
			RespHeader headerResp = populateResponseHeader(ServiceConstants.SCHEDULEPAYMENT_LIST_SERVICE, mbSession);
			serviceResponse.setHeader(headerResp);
			
			// 20E1 : Data masking for CRN : Start
			String serviceResponseForMasking = objectMapper.writeValueAsString(serviceResponse);
			String serviceResponseAfterMasking = maskValue(serviceResponseForMasking);		
			
			Logger.info("Schedule List JSON Response :" + serviceResponseAfterMasking, this.getClass());
			// 20E1 : Data masking for CRN : End
			return serviceResponse;
					
		}catch (BusinessException e)
		{
			Logger.info("BusinessException Inside processScheduleList() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			BusinessException exp = new BusinessException(e.getKey());
			IMBResp resp1  = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, ServiceConstants.SCHEDULEPAYMENT_LIST_SERVICE, httpServletRequest);
			return resp1;
		}catch (ResourceException e){
			Logger.error("ResourceException Inside processScheduleList() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			ResourceException exp = new ResourceException(e.getKey());
			IMBResp resp1  = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, ServiceConstants.SCHEDULEPAYMENT_LIST_SERVICE, httpServletRequest);
			return resp1;
		} catch (Exception e)
		{
			Logger.error("Exception Inside processScheduleList() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			BusinessException exp = new BusinessException(BusinessException.GENERIC_ERROR);
			IMBResp resp1  = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, ServiceConstants.SCHEDULEPAYMENT_LIST_SERVICE, httpServletRequest);
			return resp1;
		} finally
		{
			performanceLogger.endLog(logName);
			performanceLogger.endAllLogs();
		}	
						
	}
	
	@RequestMapping(value = "listexpired", method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public IMBResp processExpiredScheduleList(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse,
			@RequestBody final EmptyReq req) {

		PerformanceLogger performanceLogger = new PerformanceLogger();
		ObjectMapper objectMapper = new ObjectMapper();
		Collection scheduleList = null;
		Customer customer = null;
		performanceLogger.startAllLogs();
		String logName = MBAppUtils.getLogName(httpServletRequest);
		performanceLogger.startLog(logName);
		fraudLogger = new FraudLogger();
		MobileSession mbSession = null;
		try {
			Logger.info("Schedule List JSON Request :" + objectMapper.writeValueAsString(req), this.getClass());
			ErrorResp errorResp = validate(req, httpServletRequest);

			if (errorResp != null && errorResp.getErrors() != null && errorResp.getErrors().size() > 0) {
				// fraudLogger.logInvalidInput();
				return errorResp;
			}
			validateRequestHeader(req.getHeader(), httpServletRequest);

			mbSession = mbAppHelper.getMobileSession(httpServletRequest);

			customer = mbSession.getCustomer();

			IBankCommonData commonData = mbAppHelper.populateIBankCommonData(mbSession, httpServletRequest);

			Calendar fromDate = Calendar.getInstance();
			Calendar toDate = Calendar.getInstance();

			// Display expired schedule only for Last 3 months.
			fromDate.add(Calendar.MONTH, -3);
			fromDate.set(Calendar.HOUR_OF_DAY, 0);
			fromDate.set(Calendar.MINUTE, 0);
			fromDate.set(Calendar.SECOND, 0);
			fromDate.set(Calendar.MILLISECOND, 0);

			toDate.set(Calendar.HOUR_OF_DAY, 0);
			toDate.set(Calendar.MINUTE, 0);
			toDate.set(Calendar.SECOND, 0);
			toDate.set(Calendar.MILLISECOND, 0);

			scheduleList = scheduledPaymentService.searchExpiredScheduledPayments(fromDate.getTime(), toDate.getTime(), commonData);

			IMBResp serviceResponse = schedulePaymentHelper.populateScheduleListResp(scheduleList, customer, true);

			RespHeader headerResp = populateResponseHeader(ServiceConstants.SCHEDULEPAYMENT_LIST_SERVICE, mbSession);
			serviceResponse.setHeader(headerResp);

			Logger.info("Schedule List JSON Response :" + objectMapper.writeValueAsString(serviceResponse), this.getClass());

			return serviceResponse;

		} catch (BusinessException e) {
			Logger.info("BusinessException Inside processScheduleList() for Customer GCIS: ["
					+ ((mbSession != null && mbSession.getCustomer() != null) ? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			BusinessException exp = new BusinessException(e.getKey());
			IMBResp resp1 = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, ServiceConstants.SCHEDULEPAYMENT_LIST_SERVICE, httpServletRequest);
			return resp1;
		} catch (ResourceException e) {
			Logger.error("ResourceException Inside processScheduleList() for Customer GCIS: ["
					+ ((mbSession != null && mbSession.getCustomer() != null) ? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			ResourceException exp = new ResourceException(e.getKey());
			IMBResp resp1 = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, ServiceConstants.SCHEDULEPAYMENT_LIST_SERVICE, httpServletRequest);
			return resp1;
		} catch (Exception e) {
			Logger.error("Exception Inside processScheduleList() for Customer GCIS: ["
					+ ((mbSession != null && mbSession.getCustomer() != null) ? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			BusinessException exp = new BusinessException(BusinessException.GENERIC_ERROR);
			IMBResp resp1 = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, ServiceConstants.SCHEDULEPAYMENT_LIST_SERVICE, httpServletRequest);
			return resp1;
		} finally {
			performanceLogger.endLog(logName);
			performanceLogger.endAllLogs();
		}

	}
	
	@RequestMapping(value = "modify", method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public IMBResp processScheduleModify(HttpServletRequest httpServletRequest,HttpServletResponse httpServletResponse,
			@RequestBody final SchedulePaymentModifyReq req){ 
		
		PerformanceLogger performanceLogger = new PerformanceLogger();
		ObjectMapper objectMapper = new ObjectMapper();							
		String status = null;								
		performanceLogger.startAllLogs();
		String logName = MBAppUtils.getLogName(httpServletRequest);
		performanceLogger.startLog(logName);		
		fraudLogger = new FraudLogger();		
		MobileSession mbSession = null;
		try{
			mbSession = mbAppHelper.getMobileSession(httpServletRequest);
			Logger.info("Schedule Modify JSON Request :" + objectMapper.writeValueAsString(req), this.getClass());
			validateRequestHeader(req.getHeader(), httpServletRequest);
			ErrorResp errorResp = validate(req, httpServletRequest);
					
			if (errorResp != null && errorResp.getErrors() != null && errorResp.getErrors().size() > 0)
			{				
				//fraudLogger.logInvalidInput();
				return errorResp;
			}			
												
			status = req.getStatus();						
											
			IBankCommonData commonData=mbAppHelper.populateIBankCommonData(mbSession,httpServletRequest);
			validateRequestParams(req.getScheduleId().toString(), commonData);
			scheduledPaymentService.updateScheduledPaymentStatus(req.getScheduleId().toString(), status, commonData);
									
			IMBResp serviceResponse = schedulePaymentHelper.populateScheduleModifyResp(status);
			
			RespHeader headerResp = populateResponseHeader(ServiceConstants.SCHEDULEPAYMENT_MODIFY_SERVICE, mbSession);
			serviceResponse.setHeader(headerResp);
			
			Logger.info(" Schedule Modify :" + objectMapper.writeValueAsString(serviceResponse), this.getClass());
			
			return serviceResponse;
					
		}catch (BusinessException e)
		{
			Logger.info("BusinessException Inside processScheduleModify() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			BusinessException exp = new BusinessException(e.getKey());
			IMBResp resp1  = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, ServiceConstants.SCHEDULEPAYMENT_MODIFY_SERVICE, httpServletRequest);
			return resp1;
		}catch (ResourceException e){
			Logger.error("ResourceException Inside processScheduleModify() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			ResourceException exp = new ResourceException(e.getKey());
			IMBResp resp1  = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, ServiceConstants.SCHEDULEPAYMENT_MODIFY_SERVICE,httpServletRequest);
			return resp1;
		} catch (Exception e)
		{
			Logger.error("Exception Inside processScheduleModify() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			BusinessException exp = new BusinessException(BusinessException.GENERIC_ERROR);
			IMBResp resp1  = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, ServiceConstants.SCHEDULEPAYMENT_MODIFY_SERVICE, httpServletRequest);
			return resp1;
		} finally
		{
			performanceLogger.endLog(logName);
			performanceLogger.endAllLogs();
		}	
						
	}
	
	@RequestMapping(value = "delete", method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public IMBResp processScheduleDelete(HttpServletRequest httpServletRequest,HttpServletResponse httpServletResponse,
			@RequestBody final SchedulePaymentReq req){ 
		
		PerformanceLogger performanceLogger = new PerformanceLogger();
		ObjectMapper objectMapper = new ObjectMapper();										
		Collection scheduleList = null;
		Customer customer = null;		
		performanceLogger.startAllLogs();
		String logName = MBAppUtils.getLogName(httpServletRequest);
		performanceLogger.startLog(logName);		
		fraudLogger = new FraudLogger();		
		MobileSession mbSession = null;
		try{
			mbSession = mbAppHelper.getMobileSession(httpServletRequest);
			Logger.info("Schedule Delete JSON Request :" + objectMapper.writeValueAsString(req), this.getClass());
			validateRequestHeader(req.getHeader(), httpServletRequest);
			ErrorResp errorResp = validate(req, httpServletRequest);
					
			if (errorResp != null && errorResp.getErrors() != null && errorResp.getErrors().size() > 0)
			{				
				//fraudLogger.logInvalidInput();
				return errorResp;
			}			
									
			customer = mbSession.getCustomer();
			
			IBankCommonData commonData = mbAppHelper.populateIBankCommonData(mbSession,httpServletRequest);
			validateRequestParams(req.getScheduleId().toString(), commonData);
			scheduledPaymentService.deleteScheduledPayment(req.getScheduleId().toString(), commonData);
			
			scheduleList = scheduledPaymentService.getAllScheduledPayments(commonData);
			
			IMBResp serviceResponse = schedulePaymentHelper.populateScheduleListResp(scheduleList, customer, false);
			
			RespHeader headerResp = populateResponseHeader(ServiceConstants.SCHEDULEPAYMENT_DELETE_SERVICE, mbSession);
			serviceResponse.setHeader(headerResp);
			
			Logger.info(" Schedule Delete :" + objectMapper.writeValueAsString(serviceResponse), this.getClass());
			
			return serviceResponse;
					
		}catch (BusinessException e)
		{
			Logger.info("BusinessException Inside processScheduleDelete() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			BusinessException exp = new BusinessException(e.getKey());
			IMBResp resp1  = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, ServiceConstants.SCHEDULEPAYMENT_DELETE_SERVICE, httpServletRequest);
			return resp1;
		}catch (ResourceException e){
			Logger.error("ResourceException Inside processScheduleDelete() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			ResourceException exp = new ResourceException(e.getKey());
			IMBResp resp1  = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, ServiceConstants.SCHEDULEPAYMENT_DELETE_SERVICE, httpServletRequest);
			return resp1;
		} catch (Exception e)
		{
			Logger.error("Exception Inside processScheduleDelete() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			BusinessException exp = new BusinessException(BusinessException.GENERIC_ERROR);
			IMBResp resp1  = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, ServiceConstants.SCHEDULEPAYMENT_DELETE_SERVICE, httpServletRequest);
			return resp1;
		} finally
		{
			performanceLogger.endLog(logName);
			performanceLogger.endAllLogs();
		}	
						
	}
	
	@RequestMapping(value = "detail", method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public IMBResp processScheduleDetail(HttpServletRequest httpServletRequest,HttpServletResponse httpServletResponse,
			@RequestBody final SchedulePaymentReq req){ 
		
		PerformanceLogger performanceLogger = new PerformanceLogger();
		ObjectMapper objectMapper = new ObjectMapper();										
		Payment payment = null;
		Customer customer = null;		
		performanceLogger.startAllLogs();
		String logName = MBAppUtils.getLogName(httpServletRequest);
		performanceLogger.startLog(logName);		
		fraudLogger = new FraudLogger();		
		MobileSession mbSession = null;
		try{
			mbSession = mbAppHelper.getMobileSession(httpServletRequest);
			Logger.info("Schedule Detail JSON Request :" + objectMapper.writeValueAsString(req), this.getClass());
			validateRequestHeader(req.getHeader(), httpServletRequest);
			ErrorResp errorResp = validate(req, httpServletRequest);
					
			if (errorResp != null && errorResp.getErrors() != null && errorResp.getErrors().size() > 0)
			{				
				//fraudLogger.logInvalidInput();
				return errorResp;
			}			
									
			customer = mbSession.getCustomer();
			
			IBankCommonData commonData = mbAppHelper.populateIBankCommonData(mbSession,httpServletRequest);
			validateRequestParams(req.getScheduleId().toString(), commonData);
			payment = scheduledPaymentService.getScheduledPayment(req.getScheduleId().toString(), commonData);
									
			IMBResp serviceResponse = schedulePaymentHelper.populateScheduleDetailResp(payment, customer);
			
			RespHeader headerResp = populateResponseHeader(ServiceConstants.SCHEDULEPAYMENT_DETAIL_SERVICE, mbSession);
			serviceResponse.setHeader(headerResp);
			
			Logger.info(" Schedule Detail :" + objectMapper.writeValueAsString(serviceResponse), this.getClass());
			
			return serviceResponse;
					
		}catch (BusinessException e)
		{
			Logger.info("BusinessException Inside processScheduleDetail() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			IMBResp resp1 = null;
			BusinessException exp = new BusinessException(e.getKey());
			if(e.getKey() == BusinessException.ACCT_NOT_AVAILABLE_TO_DEPOSIT || e.getKey() == BusinessException.ACCOUNT_TO_ACCT_NOT_ALLOW_DEPOSIT)
				resp1 = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, ServiceConstants.SCHEDULEPAYMENT_DETAIL_SERVICE, ErrorResp.STATUS_INFO, httpServletRequest); 
			else
				resp1  = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, ServiceConstants.SCHEDULEPAYMENT_DETAIL_SERVICE, httpServletRequest);
			return resp1;
		}catch (ResourceException e){
			Logger.error("ResourceException Inside processScheduleDetail() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			ResourceException exp = new ResourceException(e.getKey());
			IMBResp resp1  = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, ServiceConstants.SCHEDULEPAYMENT_DETAIL_SERVICE, httpServletRequest);
			return resp1;
		} catch (Exception e)
		{
			Logger.error("Exception Inside processScheduleDetail() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			BusinessException exp = new BusinessException(BusinessException.GENERIC_ERROR);
			IMBResp resp1  = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, ServiceConstants.SCHEDULEPAYMENT_DETAIL_SERVICE, httpServletRequest);
			return resp1;
		} finally
		{
			performanceLogger.endLog(logName);
			performanceLogger.endAllLogs();
		}	
						
	}
	
	
	/**
	 * This endpoint will return the next payments from an account for next 7 days
	 * @param httpServletRequest
	 * @param httpServletResponse
	 * @param req
	 * @return
	 */
	@PostMapping(value = "nextPayments", headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public IMBResp processScheduleListForAccount(HttpServletRequest httpServletRequest,HttpServletResponse httpServletResponse,
			 @RequestBody final IndexReq request){ 
		
		PerformanceLogger performanceLogger = new PerformanceLogger();
		ObjectMapper objectMapper = new ObjectMapper();										
		Collection scheduleList = null;
		Customer customer = null;		
		performanceLogger.startAllLogs();
		String logName = MBAppUtils.getLogName(httpServletRequest);
		performanceLogger.startLog(logName);		
		fraudLogger = new FraudLogger();		
		MobileSession mbSession = null;
		try{
			mbSession = mbAppHelper.getMobileSession(httpServletRequest);
			Logger.info("Schedule List JSON Request :" + objectMapper.writeValueAsString(request), this.getClass());
			validateRequestHeader(request.getHeader(), httpServletRequest);
			ErrorResp errorResp = validate(request, httpServletRequest);
					
			if (errorResp != null && errorResp.getErrors() != null && errorResp.getErrors().size() > 0)
			{				
				//fraudLogger.logInvalidInput();
				return errorResp;
			}			
																		
			customer = mbSession.getCustomer();
									
			IBankCommonData commonData=mbAppHelper.populateIBankCommonData(mbSession,httpServletRequest);
			Account fromAcct;
			fromAcct = customer.getAccounts().get(Integer.parseInt(request.getIndex()));
			
			scheduleList = scheduledPaymentService.getNextPaymentsForAccountIndex(commonData, fromAcct.getAccountId().getAccountNumber());
									
			IMBResp serviceResponse = schedulePaymentHelper.populateScheduleListResp(scheduleList, customer, false);
			
			RespHeader headerResp = populateResponseHeader(ServiceConstants.SCHEDULEPAYMENT_LIST_SERVICE_FOR_ACCOUNT, mbSession);
			serviceResponse.setHeader(headerResp);
			
			Logger.info("Schedule List for Account JSON Response :" + objectMapper.writeValueAsString(serviceResponse), this.getClass());
			
			return serviceResponse;
					
		}catch (BusinessException e)
		{
			Logger.info("BusinessException Inside processScheduleListForAccount() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			BusinessException exp = new BusinessException(e.getKey());
			IMBResp resp1  = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, ServiceConstants.SCHEDULEPAYMENT_LIST_SERVICE_FOR_ACCOUNT, httpServletRequest);
			return resp1;
		}catch (ResourceException e){
			Logger.error("ResourceException Inside processScheduleListForAccount() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			ResourceException exp = new ResourceException(e.getKey());
			IMBResp resp1  = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, ServiceConstants.SCHEDULEPAYMENT_LIST_SERVICE_FOR_ACCOUNT, httpServletRequest);
			return resp1;
		} catch (Exception e)
		{
			Logger.error("Exception Inside processScheduleListForAccount() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			BusinessException exp = new BusinessException(BusinessException.GENERIC_ERROR);
			IMBResp resp1  = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, ServiceConstants.SCHEDULEPAYMENT_LIST_SERVICE_FOR_ACCOUNT, httpServletRequest);
			return resp1;
		} finally
		{
			performanceLogger.endLog(logName);
			performanceLogger.endAllLogs();
		}	
						
	}
	/**
	 * Response for invalid body request 
	 * 
	 * @return
	 */
	@ExceptionHandler({org.springframework.http.converter.HttpMessageNotReadableException.class})
	@ResponseStatus(org.springframework.http.HttpStatus.OK)
	@ResponseBody
	public IMBResp resolveException() {		
		return MBAppUtils.createInvalidMessageBodyResponse(ServiceConstants.SCHEDULEPAYMENT_MODIFY_SERVICE);
	}
	
	public ErrorResp validate(IMBReq serviceRequest, HttpServletRequest request) {
		return new MBAppValidator().validate(serviceRequest, request);
	}
	
	public void validateRequestHeader(ReqHeader header, HttpServletRequest request) throws ResourceException
	{	
		mbAppValidator.validateRequestHeader(header,  request);	
	}
	
	public RespHeader populateResponseHeader(String serviceName, MobileSession mobSession )
	{
		return mbAppHelper.populateResponseHeader(serviceName, mobSession);
	}

    public void validateRequestParams(String scheduleId, IBankCommonData commonData) throws ResourceException, BusinessException{    

        Payment payment = scheduledPaymentService.getScheduledPayment(scheduleId, commonData);
        
        boolean isInProgress = false;
        boolean isBTSchedule = false;
        
        Account fromAccount = MBAppHelper.getAccountbyAccountId(payment.getFromAccount(),commonData.getCustomer().getAccounts());
        
        if (Account.BT.equals(fromAccount.getAccountId().getApplicationId())){
              isBTSchedule = true;
        }
        
        String today = MBAppConstants.DATE_FORMAT_YYYYMMDD.format(DateMethods.getUtilDate());
        String nextPayDate = MBAppConstants.DATE_FORMAT_YYYYMMDD.format(payment.getScheduleDetails().getNextPaymentDate());
       /* 
        if (today.equals(nextPayDate) && (!ScheduleDetails.STATUS_SUSPENDED.equalsIgnoreCase(payment.getScheduleDetails().getStatusCode()))){
              isInProgress = true;
        }*/
        
        if(isInProgress 
                    || payment.getScheduleDetails().getStatusCode().equals("P")
                          || payment.getScheduleDetails().getStatusCode().equals("I")
                                || (payment.getScheduleDetails().getStatusCode().equals("S") && isBTSchedule)){
              throw new ResourceException (ResourceException.SYSTEM_ERROR, "Status of schedule id is not valid");
        }
  }

    /*
     * Method to mask crn value in the schedule response
     * 
     */
	private String maskValue(String serviceResponseForMasking) {
		try {
			String[] srvResp = serviceResponseForMasking.split(",");

			for (int i = 0; i < srvResp.length; i++) {

				if ((!StringUtils.isEmpty(srvResp[i])) && srvResp[i].contains("\"crn\"")) {
					int ind = srvResp[i].indexOf("\"crn\"");
					int lastIndex = srvResp[i].lastIndexOf("\"");
					String tempMask = srvResp[i].substring(ind + 7, lastIndex);

					if ((!StringUtils.isEmpty(tempMask)) && tempMask.length() > 10) {
						srvResp[i] = "\"crn\":" + "\"" + StringUtil.maskCrnValue(tempMask, "X") + "\"";
					}
				}
			}
			String serviceResponseAfterMasking = StringUtils.join(srvResp, ",");
			serviceResponseAfterMasking = serviceResponseAfterMasking + "}]}";
			return serviceResponseAfterMasking;
		} catch (Exception e) {
			Logger.info("Error while masking CRN value ", this.getClass());
			return serviceResponseForMasking;
		}

	}

}
