package au.com.stgeorge.mbank.model.common;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_NULL)
public class FastFundingResp {
	private String productName;
	  private String bSBNumber;
	  private String accountNumber;
	  private String salBSBNumber;
	  private String salAccountNumber;
	  private String funding;
	  private String switching;
	  private String salCredit;
	  private String tileStatus;
	  private Integer accountIndex;
	  
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public String getbSBNumber() {
		return bSBNumber;
	}
	public void setbSBNumber(String bSBNumber) {
		this.bSBNumber = bSBNumber;
	}
	public String getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}
	public String getSalBSBNumber() {
		return salBSBNumber;
	}
	public void setSalBSBNumber(String salBSBNumber) {
		this.salBSBNumber = salBSBNumber;
	}
	public String getSalAccountNumber() {
		return salAccountNumber;
	}
	public void setSalAccountNumber(String salAccountNumber) {
		this.salAccountNumber = salAccountNumber;
	}
	public String getFunding() {
		return funding;
	}
	public void setFunding(String funding) {
		this.funding = funding;
	}
	public String getSwitching() {
		return switching;
	}
	public void setSwitching(String switching) {
		this.switching = switching;
	}
	public String getSalCredit() {
		return salCredit;
	}
	public void setSalCredit(String salCredit) {
		this.salCredit = salCredit;
	}
	public String getTileStatus() {
		return tileStatus;
	}
	public void setTileStatus(String tileStatus) {
		this.tileStatus = tileStatus;
	}
	public Integer getAccountIndex() {
		return accountIndex;
	}
	public void setAccountIndex(Integer accountIndex) {
		this.accountIndex = accountIndex;
	}
	
	  
}
