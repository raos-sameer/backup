package au.com.stgeorge.mbank.model.request;

import java.io.Serializable;

import javax.validation.constraints.NotNull;

import au.com.stgeorge.ibank.businessobject.BusinessException;
import au.com.stgeorge.mbank.model.common.IMBReq;
import au.com.stgeorge.mbank.model.common.ReqHeader;

public class AbusiveTrxnReportRequest implements IMBReq, Serializable {

	private static final long serialVersionUID = 4481730103139956387L;
	
	@NotNull(message = "" + BusinessException.WSVC_INVALID_INPUT_PARAM)
	private Integer accountIndex;

	private ReqHeader header;

	public Integer getAccountIndex() {
		return accountIndex;
	}

	@Override
	public ReqHeader getHeader() {
		return header;
	}

	public void setAccountIndex(Integer accountIndex) {
		this.accountIndex = accountIndex;
	}

	@Override
	public void setHeader(ReqHeader header) {
		this.header = header;
	}

	@Override
	public String toString() {
		return "AbusiveTrxnReportRequest [header=" + header + ", accountIndex=" + accountIndex + "]";
	}
}