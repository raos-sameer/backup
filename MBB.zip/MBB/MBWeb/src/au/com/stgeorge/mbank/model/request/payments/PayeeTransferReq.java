package au.com.stgeorge.mbank.model.request.payments;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

import org.apache.commons.lang.builder.ReflectionToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;
import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.Length;

import au.com.stgeorge.ibank.businessobject.BusinessException;

/**
 * Payee transfer request
 * 
 * @author C38854
 * 
 */

public class PayeeTransferReq extends TransferReq {

	private static final long serialVersionUID = -5925462050152885496L;
	private static final String VALID_CHAR_SET_PAYER_NAME = "^[0-9A-Za-z'\\-,.() &/]*$";
	
	@NotNull(message = "" + BusinessException.ACCOUNT_NO_TO_ACCOUNT)
	private Integer toPayeeIndex;

	@Length(max = 50, message = "{errors.payeeEmail.maxlength}")
	@Email(message = "{errors.email.invalid}")
	private String payeeEmail;

//	@Pattern(regexp = VALID_CHAR_SET_PAYER_NAME, message = "{errors.payerName.blockchar}")
	@Length(max = 140, message = "{errors.payerName.maxlength}")
	private String payerName;
	
	@Pattern(regexp = BLOCK_CHARS_PATTERN, message = "{errors.endToEndID.blockchar}")
	@Length(max = 35, message = "{errors.endToEndID.maxlength}")
	private String endToEndID;
	
	private String devicePrint;	
	private String fromAccountNumber;	
	private String fromAccountNumberMasked;	
	private String toAccountNumber;	
	
	public String getDevicePrint() {
		return devicePrint;
	}

	public void setDevicePrint(String devicePrint) {
		this.devicePrint = devicePrint;
	}

	public String getPayerName() {
		return payerName;
	}

	// not used - not needed (check if payee email address is present)
	private Boolean sendPayeeEmail;

	public Integer getToPayeeIndex() {
		return toPayeeIndex;
	}

	public Boolean getSendPayeeEmail() {
		return sendPayeeEmail;
	}

	// not used - not needed (check if payee email address is present)
	public String getPayeeEmail() {
		return payeeEmail;
	}

	@Override
	public String toString() {
		return ReflectionToStringBuilder.toString(this, ToStringStyle.MULTI_LINE_STYLE);
	}

	public String getEndToEndID() {
		return endToEndID;
	}

	public void setEndToEndID(String endToEndID) {
		this.endToEndID = endToEndID;
	}

	public String getFromAccountNumber() {
		return fromAccountNumber;
	}

	public void setFromAccountNumber(String fromAccountNumber) {
		this.fromAccountNumber = fromAccountNumber;
	}

	public String getFromAccountNumberMasked() {
		return fromAccountNumberMasked;
	}

	public void setFromAccountNumberMasked(String fromAccountNumberMasked) {
		this.fromAccountNumberMasked = fromAccountNumberMasked;
	}

	public String getToAccountNumber() {
		return toAccountNumber;
	}

	public void setToAccountNumber(String toAccountNumber) {
		this.toAccountNumber = toAccountNumber;
	}
	

}
