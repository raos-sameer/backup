package au.com.stgeorge.mbank.controller.payments;

import java.text.MessageFormat;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;

import com.fasterxml.jackson.databind.ObjectMapper;

import au.com.stgeorge.digitalsec.logger.DigitalSecLogger;
import au.com.stgeorge.digitalsec.logger.DigitalSecLogggerVO;
import au.com.stgeorge.framework.common.logging.Logger;
import au.com.stgeorge.framework.common.util.StringMethods;
import au.com.stgeorge.ibank.businessobject.BusinessException;
import au.com.stgeorge.ibank.businessobject.ResourceException;
import au.com.stgeorge.ibank.common.cache.IBankParams;
import au.com.stgeorge.ibank.common.cache.IBankRefershParams;
import au.com.stgeorge.ibank.safi.businessobject.Safi2Service;
import au.com.stgeorge.ibank.safi.util.SafiConstants;
import au.com.stgeorge.ibank.safi.util.SafiUtil;
import au.com.stgeorge.ibank.safi.valueobject.SafiPayIdVO;
import au.com.stgeorge.ibank.service.businessobject.ManagePayIdService;
import au.com.stgeorge.ibank.service.valueobject.SafiRespVO;
import au.com.stgeorge.ibank.util.NPPUtil;
import au.com.stgeorge.ibank.util.StringUtil;
import au.com.stgeorge.ibank.valueobject.Account;
import au.com.stgeorge.ibank.valueobject.Customer;
import au.com.stgeorge.ibank.valueobject.ManagePayIdDetails;
import au.com.stgeorge.ibank.valueobject.NonFinTransactionDetails;
import au.com.stgeorge.ibank.valueobject.PayIdAvailabilityDetails;
import au.com.stgeorge.ibank.valueobject.PayIdDetails;
import au.com.stgeorge.ibank.valueobject.PayIdStatusDetails;
import au.com.stgeorge.ibank.valueobject.RegisterPayIdDetails;
import au.com.stgeorge.ibank.valueobject.database.OriginsVO;
import au.com.stgeorge.ibank.valueobject.transfer.IBankCommonData;
import au.com.stgeorge.mbank.controller.IMBController;
import au.com.stgeorge.mbank.controller.SafiWebHelper;
import au.com.stgeorge.mbank.controller.SecureCodeHelper;
import au.com.stgeorge.mbank.controller.customer.LogonHelper;
import au.com.stgeorge.mbank.model.common.IMBReq;
import au.com.stgeorge.mbank.model.common.IMBResp;
import au.com.stgeorge.mbank.model.common.ReqHeader;
import au.com.stgeorge.mbank.model.common.RespHeader;
import au.com.stgeorge.mbank.model.request.EmptyReq;
import au.com.stgeorge.mbank.model.request.SecureCodeReq;
import au.com.stgeorge.mbank.model.request.payments.ManagePayIdReq;
import au.com.stgeorge.mbank.model.request.payments.PayIdRegStatusReq;
import au.com.stgeorge.mbank.model.request.payments.PayIdReq;
import au.com.stgeorge.mbank.model.response.ErrorResp;
import au.com.stgeorge.mbank.model.response.payments.PayIdAvailabilityResp;
import au.com.stgeorge.mbank.session.MobileSession;
import au.com.stgeorge.mbank.session.MobileSessionImpl;
import au.com.stgeorge.mbank.util.MBAppHelper;
import au.com.stgeorge.mbank.util.MBAppUtils;
import au.com.stgeorge.mbank.util.MBAppValidator;
import au.com.stgeorge.mbank.util.ServiceConstants;
import au.com.stgeorge.perflogger.PerformanceLogger;
/**
 * @author c72660
 *
 */
@Controller
@RequestMapping("/managePayId")
public class ManagePayIdController implements IMBController {

	@Autowired
	private ManagePayIdService managePayIdService;

	@Autowired
	private ManagePayIdHelper managePayIdHelper;

	@Autowired
	private MBAppHelper mbAppHelper;
	
	@Autowired
	private MBAppValidator mbAppValidator;

	@Autowired
	private PerformanceLogger perfLogger;
	
	@Autowired
	private SecureCodeHelper secureCodeHelper;
	
	@Autowired
	private LogonHelper logonHelper;
	
	@Autowired
	private Safi2Service safi2Service;
	
	@Autowired
	private DigitalSecLogger digitalSecLogger;
	
	@Autowired
	private IBankRefershParams ibankRefreshParams;
	
	@RequestMapping(value = "getPayIdDetails", method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public IMBResp getPayIdDetails(HttpServletRequest httpServletRequest,HttpServletResponse httpServletResponse,@RequestBody final EmptyReq req) { 

		ObjectMapper objectMapper = new ObjectMapper();	
		perfLogger.startAllLogs();
		String logName = MBAppUtils.getLogName(httpServletRequest);
		perfLogger.startLog(logName);					
		MobileSession mobileSession = new MobileSessionImpl();
		ManagePayIdDetails payIdDtls = null;
		try{
			
			Logger.debug("Manage Payid getPayIdDetails List JSON Request :" + objectMapper.writeValueAsString(req), this.getClass());
			mobileSession.getSessionContext(httpServletRequest);
			ErrorResp errorResp = validate(req, httpServletRequest);
					
			IMBResp serviceResponse = null;
			
			if (errorResp != null && errorResp.getErrors() != null && errorResp.getErrors().size() > 0)	{				
				return errorResp;				
			}else{								
				Customer customer = mobileSession.getCustomer();				
				IBankCommonData commonData=mbAppHelper.populateIBankCommonData(mobileSession,httpServletRequest);
				commonData.setCustomer(customer);

				commonData.setPayIdCorrelationId(IBankParams.generatePayIdCorrelationId(commonData.getSessionId()));
				mobileSession.setPayIdHeaderCorrId(commonData.getPayIdCorrelationId());
				
				payIdDtls = managePayIdService.checkEligibility(commonData,true);
				if(null!=payIdDtls) {
					if(payIdDtls.isUpdateFlow()) {
							if(!StringMethods.isValidString(payIdDtls.getAliasAccountVersionNumber()) || !StringMethods.isValidString(payIdDtls.getArrangementId())) {
								throw new BusinessException(BusinessException.PAYID_SETTINGS_NOT_AVAILABLE);
							}		
					}
					if(ibankRefreshParams.isNppABNPayIdRegSwitchOn() && !payIdDtls.isUpdateFlow() && null != payIdDtls.getPayIdAliasesDetails() && payIdDtls.getPayIdAliasesDetails().size() == 1) { 
						if(payIdDtls.getPayIdAliasesDetails().containsKey(NPPUtil.AUBN)) {
							//20E2 - Checking if selected ABN PayID is verified, else throw Business Exception.
							managePayIdService.isABNPayIdVerified(payIdDtls, NPPUtil.AUBN, commonData,true);
							
							payIdDtls = managePayIdService.getAdditionalPayIdDetailsFromWDP(payIdDtls, commonData);
							payIdDtls.setSelectedPayIdType(NPPUtil.AUBN);
						}else{
							payIdDtls.setSelectedPayIdType(NPPUtil.TELI);
							// 21E2 - Checking Customer mobile no.
							managePayIdService.checkCustomerMobileAvailable(customer);
						}
					}
					mobileSession.setPayIdDetails(payIdDtls);	
				}
				if(null != payIdDtls && !payIdDtls.isUpdateFlow()) {
                	if(!IBankParams.isSwitchOn(commonData.getOrigin(), IBankParams.SAFI_PAYID_REG_SWITCH)) {
                		throw new BusinessException(BusinessException.PAYID_SETTINGS_NOT_AVAILABLE);
                	}
                }
                
                RespHeader headerResp = populateResponseHeader(req.getHeader().getServiceName(), mobileSession);
                if(ibankRefreshParams.isNppABNPayIdRegSwitchOn() && payIdDtls.isUpdateFlow()) {
                	serviceResponse = managePayIdHelper.populateListingPagePayIdResp(commonData, payIdDtls, mbAppHelper);
                } else {
                	serviceResponse = managePayIdHelper.populateGetPayIdResp(commonData, payIdDtls, mbAppHelper, null);
                }
				serviceResponse.setHeader(headerResp);		
                
				Logger.debug("Manage Payid getPayIdDetails List JSON Response :" + objectMapper.writeValueAsString(serviceResponse), this.getClass());
				return serviceResponse;
			}				
		}catch (BusinessException e){
			Logger.warn("BusinessException in ManagePayIdController - [key: " + e.getKey() + "] : GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());
			
			String payId = null;
			if(null != payIdDtls) {
				if(NPPUtil.AUBN.equals(payIdDtls.getSelectedPayIdType())) {
					if(e.getKey() == BusinessException.PAYID_REGISTRATION_NUMBER_INVALID_FORMAT_MB) {
						payId = payIdDtls.getPayIdAliasesDetails().get(NPPUtil.AUBN).getPaymentAliasId();
					}else {
						payId = StringUtil.formatABN(payIdDtls.getPayIdAliasesDetails().get(NPPUtil.AUBN).getPaymentAliasId());
					}
				} else {
					payId = StringUtil.maskPayID(payIdDtls.getPayIdMobileNumber());
				}
			}
			if(e.getKey() == BusinessException.PAYID_MOBILE_NUMBER_MISMATCH) {
				OriginsVO myOriginVO  = IBankParams.getOrigin(mobileSession.getOrigin());
				OriginsVO baseOrigin  = IBankParams.getOrigin(myOriginVO.getBankName());
				String[] values = {baseOrigin.getPhone()};	
				return  MBAppUtils.createErrorResp(mobileSession.getOrigin(), e, values, ServiceConstants.MANAGE_PAYID, httpServletRequest);
			}
			else if(e.getKey() == BusinessException.PAYID_SETTINGS_NOT_AVAILABLE) {
				OriginsVO myOriginVO  = IBankParams.getOrigin(mobileSession.getOrigin());
				OriginsVO baseOrigin  = IBankParams.getOrigin(myOriginVO.getBankName());
				String[] values = {baseOrigin.getPhone()};	
				e = new BusinessException(BusinessException.PAYID_SETTINGS_NOT_AVAILABLE_MB);
				return  MBAppUtils.createErrorResp(mobileSession.getOrigin(), e, values, ServiceConstants.MANAGE_PAYID, httpServletRequest);
			}
			
			else if(e.getKey() == BusinessException.PAYID_ABN_NOT_ACTIVE_IN_ABR_MB) {
				OriginsVO myOriginVO  = IBankParams.getOrigin(mobileSession.getOrigin());
				OriginsVO baseOrigin  = IBankParams.getOrigin(myOriginVO.getBankName());
				String[] values = {payId,baseOrigin.getPhone()};
				return  MBAppUtils.createErrorResp(mobileSession.getOrigin(), e, values, ServiceConstants.MANAGE_PAYID, httpServletRequest);
			}
			else if(e.getKey() == BusinessException.PAYID_ABN_NOT_FOUND_IN_ABR_MB) {
				OriginsVO myOriginVO  = IBankParams.getOrigin(mobileSession.getOrigin());
				OriginsVO baseOrigin  = IBankParams.getOrigin(myOriginVO.getBankName());
				String[] values = {payId,baseOrigin.getPhone()};
				return  MBAppUtils.createErrorResp(mobileSession.getOrigin(), e, values, ServiceConstants.MANAGE_PAYID, httpServletRequest);
			}
			else if(e.getKey() == BusinessException.PAYID_CUSTOMER_NAME_MISMATCH_MB) {
				OriginsVO myOriginVO  = IBankParams.getOrigin(mobileSession.getOrigin());
				OriginsVO baseOrigin  = IBankParams.getOrigin(myOriginVO.getBankName());
				String[] values = {payIdDtls.getPayIdShortName(),payId,baseOrigin.getPhone()};
				return  MBAppUtils.createErrorResp(mobileSession.getOrigin(), e, values, ServiceConstants.MANAGE_PAYID, httpServletRequest);
			}
			else if(e.getKey() == BusinessException.PAYID_CUSTOMER_NOT_VERIFIED_MB) {
				OriginsVO myOriginVO  = IBankParams.getOrigin(mobileSession.getOrigin());
				OriginsVO baseOrigin  = IBankParams.getOrigin(myOriginVO.getBankName());
				String[] values = {baseOrigin.getPhone()};
				return  MBAppUtils.createErrorResp(mobileSession.getOrigin(), e, values, ServiceConstants.MANAGE_PAYID, httpServletRequest);
			}
			else if(e.getKey() == BusinessException.PAYID_REGISTRATION_NUMBER_INVALID_FORMAT_MB) {
				OriginsVO myOriginVO  = IBankParams.getOrigin(mobileSession.getOrigin());
				OriginsVO baseOrigin  = IBankParams.getOrigin(myOriginVO.getBankName());
				String[] values = {payId,baseOrigin.getPhone()};
				return  MBAppUtils.createErrorResp(mobileSession.getOrigin(), e, values, ServiceConstants.MANAGE_PAYID, httpServletRequest);
			}
			else if(e.getKey() == BusinessException.PAYID_CUSTOMER_IS_NOT_A_SOLE_TRADER_MB) {
				OriginsVO myOriginVO  = IBankParams.getOrigin(mobileSession.getOrigin());
				OriginsVO baseOrigin  = IBankParams.getOrigin(myOriginVO.getBankName());
				String[] values = {baseOrigin.getPhone()};
				return  MBAppUtils.createErrorResp(mobileSession.getOrigin(), e, values, ServiceConstants.MANAGE_PAYID, httpServletRequest);
			}
			else if(e.getKey() == BusinessException.PAYID_IDV_NOT_DONE_MB) {
				OriginsVO myOriginVO  = IBankParams.getOrigin(mobileSession.getOrigin());
				OriginsVO baseOrigin  = IBankParams.getOrigin(myOriginVO.getBankName());
				String[] values = {baseOrigin.getPhone()};
				return  MBAppUtils.createErrorResp(mobileSession.getOrigin(), e, values, ServiceConstants.MANAGE_PAYID, httpServletRequest);
			}
			else if(e.getKey() == BusinessException.NO_ELIGIBLE_ACCOUNT_TO_ABN) {
				OriginsVO myOriginVO  = IBankParams.getOrigin(mobileSession.getOrigin());
				OriginsVO baseOrigin  = IBankParams.getOrigin(myOriginVO.getBankName());
				String[] values = {baseOrigin.getPhone()};
				e = new BusinessException(BusinessException.NO_ELIGIBLE_ACCOUNT_TO_ABN_MB);
				return  MBAppUtils.createErrorResp(mobileSession.getOrigin(), e, values, ServiceConstants.MANAGE_PAYID, httpServletRequest);
			}
			else if(e.getKey() == BusinessException.PAYID_NO_ELIGIBLE_ACCOUNT) {
				e = new BusinessException(BusinessException.PAYID_NO_ELIGIBLE_ACCOUNT_MB);
				return  MBAppUtils.createErrorResp(mobileSession.getOrigin(), e, ServiceConstants.MANAGE_PAYID, httpServletRequest);
			}
			else {
				return MBAppUtils.createErrorResp(mobileSession.getOrigin(), e, ServiceConstants.MANAGE_PAYID, httpServletRequest);
			}
		}catch (ResourceException e){
			Logger.warn("ResourceException in ManagePayIdController - [key: " + e.getKey() + "] : GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.SYSTEM_UNAVILABLE, ServiceConstants.MANAGE_PAYID, httpServletRequest);					
		} catch (Exception e){
			Logger.error("Exception in ManagePayIdController GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.GENERIC_ERROR, ServiceConstants.MANAGE_PAYID, httpServletRequest);
		} finally{
			perfLogger.endLog(logName);
			perfLogger.endAllLogs();
		}	
		
	}
	
	@RequestMapping(value = "managePayIdTypeSelect", method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public IMBResp managePayIdTypeSelect(HttpServletRequest httpServletRequest,HttpServletResponse httpServletResponse,
			@RequestBody final ManagePayIdReq req) { 

		ObjectMapper objectMapper = new ObjectMapper();	
		perfLogger.startAllLogs();
		String logName = MBAppUtils.getLogName(httpServletRequest);
		perfLogger.startLog(logName);
		MobileSession mobileSession = new MobileSessionImpl();
		ManagePayIdDetails payIdDtls = null;
		try{
			
			Logger.debug("Manage Payid managePayIdTypeSelect List JSON Request :" + objectMapper.writeValueAsString(req), this.getClass());
			mobileSession.getSessionContext(httpServletRequest);
			ErrorResp errorResp = validate(req, httpServletRequest);

			IMBResp serviceResponse = null;

			if (errorResp != null && errorResp.getErrors() != null && errorResp.getErrors().size() > 0)	{				
				return errorResp;				
			}else{								
				Customer customer = mobileSession.getCustomer();				
				IBankCommonData commonData=mbAppHelper.populateIBankCommonData(mobileSession,httpServletRequest);
				commonData.setCustomer(customer);

				if(mobileSession.getPayIdHeaderCorrId()!=null){
					commonData.setPayIdCorrelationId(mobileSession.getPayIdHeaderCorrId());
				}
				//validation
				if(!NPPUtil.TELI.equals(req.getPayIdType())  &&
						!NPPUtil.AUBN.equals(req.getPayIdType())) {
					throw new BusinessException(BusinessException.PAYID_TYPE_SELECTION_INCORRECT);
				}
				payIdDtls = mobileSession.getPayIdDetails();
				
				if(null != payIdDtls && !payIdDtls.isUpdateFlow()) {
                	if(!IBankParams.isSwitchOn(commonData.getOrigin(), IBankParams.SAFI_PAYID_REG_SWITCH)) {
                		throw new BusinessException(BusinessException.PAYID_SETTINGS_NOT_AVAILABLE);
                	}
                }
				if(NPPUtil.AUBN.equals(req.getPayIdType())){
					
					// 21E2 - Code to check if selected ABN PayID type is verified else throw Business Exception.
					managePayIdService.isABNPayIdVerified(payIdDtls, NPPUtil.AUBN, commonData, true);
					
					payIdDtls = managePayIdService.getAdditionalPayIdDetailsFromWDP(payIdDtls, commonData);
				}
				// 21E2 - Checking customer mobile
				if(NPPUtil.TELI.equals(req.getPayIdType())) {
					managePayIdService.checkCustomerMobileAvailable(customer);
				}
				//Updating session with the payId type selected by user
				payIdDtls.setSelectedPayIdType(req.getPayIdType());
				//Making this update flow as false bcs this same end point is called when user clicks on Add a new Payid button on Overview screen.  
				//Here user is trying to add another payId hence marking update flow as false. 
				//If not done this will cause problem in data sent to SAFI.
				payIdDtls.setUpdateFlow(false);
				mobileSession.setPayIdDetails(payIdDtls);	
				
                RespHeader headerResp = populateResponseHeader(req.getHeader().getServiceName(), mobileSession);
                
				serviceResponse = managePayIdHelper.populateGetPayIdResp(commonData, payIdDtls, mbAppHelper, req.getPayIdType()); 
				serviceResponse.setHeader(headerResp);		
                
				Logger.debug("Manage Payid managePayIdTypeSelect List JSON Response :" + objectMapper.writeValueAsString(serviceResponse), this.getClass());
				return serviceResponse;
			}				
		}catch (BusinessException e){
			Logger.warn("BusinessException in ManagePayIdController - [key: " + e.getKey() + "] : GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());
			
			String payIdFromSession = null;
			if(NPPUtil.AUBN.equals(req.getPayIdType())) {
				if(e.getKey() == BusinessException.PAYID_REGISTRATION_NUMBER_INVALID_FORMAT_MB) {
					payIdFromSession = payIdDtls.getPayIdAliasesDetails().get(NPPUtil.AUBN).getPaymentAliasId();
				}else {
					payIdFromSession = StringUtil.formatABN(payIdDtls.getPayIdAliasesDetails().get(NPPUtil.AUBN).getPaymentAliasId());
				}
			}else {
				payIdFromSession = StringUtil.maskPayID(payIdDtls.getPayIdMobileNumber());
			}
			if(e.getKey() == BusinessException.PAYID_MOBILE_NUMBER_MISMATCH) {
				OriginsVO myOriginVO  = IBankParams.getOrigin(mobileSession.getOrigin());
				OriginsVO baseOrigin  = IBankParams.getOrigin(myOriginVO.getBankName());
				String[] values = {baseOrigin.getPhone()};	
				return  MBAppUtils.createErrorResp(mobileSession.getOrigin(), e, values, ServiceConstants.MANAGE_PAYID, httpServletRequest);
			}
			else if(e.getKey() == BusinessException.PAYID_ABN_NOT_ACTIVE_IN_ABR_MB) {
				OriginsVO myOriginVO  = IBankParams.getOrigin(mobileSession.getOrigin());
				OriginsVO baseOrigin  = IBankParams.getOrigin(myOriginVO.getBankName());
				String[] values = {payIdFromSession,baseOrigin.getPhone()};
				return  MBAppUtils.createErrorResp(mobileSession.getOrigin(), e, values, ServiceConstants.MANAGE_PAYID, httpServletRequest);
			}
			else if(e.getKey() == BusinessException.PAYID_ABN_NOT_FOUND_IN_ABR_MB) {
				OriginsVO myOriginVO  = IBankParams.getOrigin(mobileSession.getOrigin());
				OriginsVO baseOrigin  = IBankParams.getOrigin(myOriginVO.getBankName());
				String[] values = {payIdFromSession,baseOrigin.getPhone()};
				return  MBAppUtils.createErrorResp(mobileSession.getOrigin(), e, values, ServiceConstants.MANAGE_PAYID, httpServletRequest);
			}
			else if(e.getKey() == BusinessException.PAYID_CUSTOMER_NAME_MISMATCH_MB) {
				OriginsVO myOriginVO  = IBankParams.getOrigin(mobileSession.getOrigin());
				OriginsVO baseOrigin  = IBankParams.getOrigin(myOriginVO.getBankName());
				String[] values = {payIdDtls.getPayIdShortName(),payIdFromSession,baseOrigin.getPhone()};
				return  MBAppUtils.createErrorResp(mobileSession.getOrigin(), e, values, ServiceConstants.MANAGE_PAYID, httpServletRequest);
			}
			else if(e.getKey() == BusinessException.PAYID_CUSTOMER_NOT_VERIFIED_MB) {
				OriginsVO myOriginVO  = IBankParams.getOrigin(mobileSession.getOrigin());
				OriginsVO baseOrigin  = IBankParams.getOrigin(myOriginVO.getBankName());
				String[] values = {baseOrigin.getPhone()};
				return  MBAppUtils.createErrorResp(mobileSession.getOrigin(), e, values, ServiceConstants.MANAGE_PAYID, httpServletRequest);
			}
			else if(e.getKey() == BusinessException.PAYID_REGISTRATION_NUMBER_INVALID_FORMAT_MB) {
				OriginsVO myOriginVO  = IBankParams.getOrigin(mobileSession.getOrigin());
				OriginsVO baseOrigin  = IBankParams.getOrigin(myOriginVO.getBankName());
				String[] values = {payIdFromSession,baseOrigin.getPhone()};
				return  MBAppUtils.createErrorResp(mobileSession.getOrigin(), e, values, ServiceConstants.MANAGE_PAYID, httpServletRequest);
			}
			else if(e.getKey() == BusinessException.PAYID_CUSTOMER_IS_NOT_A_SOLE_TRADER_MB) {
				OriginsVO myOriginVO  = IBankParams.getOrigin(mobileSession.getOrigin());
				OriginsVO baseOrigin  = IBankParams.getOrigin(myOriginVO.getBankName());
				String[] values = {baseOrigin.getPhone()};
				return  MBAppUtils.createErrorResp(mobileSession.getOrigin(), e, values, ServiceConstants.MANAGE_PAYID, httpServletRequest);
			}
			else if(e.getKey() == BusinessException.PAYID_SETTINGS_NOT_AVAILABLE) {
				OriginsVO myOriginVO  = IBankParams.getOrigin(mobileSession.getOrigin());
				OriginsVO baseOrigin  = IBankParams.getOrigin(myOriginVO.getBankName());
				String[] values = {baseOrigin.getPhone()};	
				e = new BusinessException(BusinessException.PAYID_SETTINGS_NOT_AVAILABLE_MB);
				return  MBAppUtils.createErrorResp(mobileSession.getOrigin(), e, values, ServiceConstants.MANAGE_PAYID, httpServletRequest);
			}
			else if(e.getKey() == BusinessException.NO_ELIGIBLE_ACCOUNT_TO_ABN) {
				OriginsVO myOriginVO  = IBankParams.getOrigin(mobileSession.getOrigin());
				OriginsVO baseOrigin  = IBankParams.getOrigin(myOriginVO.getBankName());
				String[] values = {baseOrigin.getPhone()};	
				e = new BusinessException(BusinessException.NO_ELIGIBLE_ACCOUNT_TO_ABN_MB);
				return  MBAppUtils.createErrorResp(mobileSession.getOrigin(), e, values, ServiceConstants.MANAGE_PAYID, httpServletRequest);
			}
			else {
				return MBAppUtils.createErrorResp(mobileSession.getOrigin(), e, ServiceConstants.MANAGE_PAYID, httpServletRequest);
			}
		}catch (ResourceException e){
			Logger.warn("ResourceException in ManagePayIdController - [key: " + e.getKey() + "] : GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.SYSTEM_UNAVILABLE, ServiceConstants.MANAGE_PAYID, httpServletRequest);					
		} catch (Exception e){
			Logger.error("Exception in ManagePayIdController GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.GENERIC_ERROR, ServiceConstants.MANAGE_PAYID, httpServletRequest);
		} finally{
			perfLogger.endLog(logName);
			perfLogger.endAllLogs();
		}	
		
	}

	
	@RequestMapping(value = "changeLinkedAcct", method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public IMBResp changeLinkedAcct(HttpServletRequest httpServletRequest,HttpServletResponse httpServletResponse,
			@RequestBody final ManagePayIdReq req) { 

		ObjectMapper objectMapper = new ObjectMapper();	
		perfLogger.startAllLogs();
		String logName = MBAppUtils.getLogName(httpServletRequest);
		perfLogger.startLog(logName);
		MobileSession mobileSession = new MobileSessionImpl();
		try{
			
			Logger.debug("changeLinkedAcct List JSON Request :" + objectMapper.writeValueAsString(req), this.getClass());
			mobileSession.getSessionContext(httpServletRequest);
			ErrorResp errorResp = validate(req, httpServletRequest);

			IMBResp serviceResponse = null;

			if (errorResp != null && errorResp.getErrors() != null && errorResp.getErrors().size() > 0)	{				
				return errorResp;				
			}else{								
				Customer customer = mobileSession.getCustomer();				
				IBankCommonData commonData=mbAppHelper.populateIBankCommonData(mobileSession,httpServletRequest);
				commonData.setCustomer(customer);

				commonData.setPayIdCorrelationId(IBankParams.generatePayIdCorrelationId(commonData.getSessionId()));
				mobileSession.setPayIdHeaderCorrId(commonData.getPayIdCorrelationId());
				
				//validation
				if(!NPPUtil.TELI.equals(req.getPayIdType())  &&
						!NPPUtil.AUBN.equals(req.getPayIdType())) {
					throw new BusinessException(BusinessException.PAYID_TYPE_SELECTION_INCORRECT);
				}
				ManagePayIdDetails payIdDtls = mobileSession.getPayIdDetails();
				if(null != payIdDtls && !payIdDtls.isUpdateFlow()) {
                	if(!IBankParams.isSwitchOn(commonData.getOrigin(), IBankParams.SAFI_PAYID_REG_SWITCH)) {
                		throw new BusinessException(BusinessException.PAYID_SETTINGS_NOT_AVAILABLE);
                	}
                }
				if(NPPUtil.AUBN.equals(req.getPayIdType())){
					payIdDtls = managePayIdService.getAdditionalPayIdDetailsFromWDP(payIdDtls, commonData);
				}
				//Updating session with the payId type selected by user
				payIdDtls.setSelectedPayIdType(req.getPayIdType());
				mobileSession.setPayIdDetails(payIdDtls);	
				
                RespHeader headerResp = populateResponseHeader(req.getHeader().getServiceName(), mobileSession);
                
				serviceResponse = managePayIdHelper.populateChangeLinkedAcctResp(commonData, payIdDtls, mbAppHelper, req.getPayIdType()); 
				serviceResponse.setHeader(headerResp);		
                
				Logger.debug("changeLinkedAcct List JSON Response :" + objectMapper.writeValueAsString(serviceResponse), this.getClass());
				return serviceResponse;
			}				
		}catch (BusinessException e){
			Logger.warn("BusinessException in changeLinkedAcct in ManagePayIdController - [key: " + e.getKey() + "] : GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());				
			if(e.getKey() == BusinessException.PAYID_MOBILE_NUMBER_MISMATCH) {
				OriginsVO myOriginVO  = IBankParams.getOrigin(mobileSession.getOrigin());
				OriginsVO baseOrigin  = IBankParams.getOrigin(myOriginVO.getBankName());
				String[] values = {baseOrigin.getPhone()};	
				return  MBAppUtils.createErrorResp(mobileSession.getOrigin(), e, values, ServiceConstants.MANAGE_PAYID, httpServletRequest);
			} else if(e.getKey() == BusinessException.PAYID_SETTINGS_NOT_AVAILABLE) {
				OriginsVO myOriginVO  = IBankParams.getOrigin(mobileSession.getOrigin());
				OriginsVO baseOrigin  = IBankParams.getOrigin(myOriginVO.getBankName());
				String[] values = {baseOrigin.getPhone()};	
				e = new BusinessException(BusinessException.PAYID_SETTINGS_NOT_AVAILABLE_MB);
				return  MBAppUtils.createErrorResp(mobileSession.getOrigin(), e, values, ServiceConstants.MANAGE_PAYID, httpServletRequest);
			}
			else if(e.getKey() == BusinessException.NO_ELIGIBLE_ACCOUNT_TO_ABN) {
				OriginsVO myOriginVO  = IBankParams.getOrigin(mobileSession.getOrigin());
				OriginsVO baseOrigin  = IBankParams.getOrigin(myOriginVO.getBankName());
				String[] values = {baseOrigin.getPhone()};	
				e = new BusinessException(BusinessException.NO_ELIGIBLE_ACCOUNT_TO_ABN_MB);
				return  MBAppUtils.createErrorResp(mobileSession.getOrigin(), e, values, ServiceConstants.MANAGE_PAYID, httpServletRequest);
			}
			else {
				return MBAppUtils.createErrorResp(mobileSession.getOrigin(), e, ServiceConstants.MANAGE_PAYID, httpServletRequest);
			}
		}catch (ResourceException e){
			Logger.warn("ResourceException in changeLinkedAcct in ManagePayIdController - [key: " + e.getKey() + "] : GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.SYSTEM_UNAVILABLE, ServiceConstants.MANAGE_PAYID, httpServletRequest);					
		} catch (Exception e){
			Logger.error("Exception in changeLinkedAcct in ManagePayIdController GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.GENERIC_ERROR, ServiceConstants.MANAGE_PAYID, httpServletRequest);
		} finally{
			perfLogger.endLog(logName);
			perfLogger.endAllLogs();
		}	
		
	}
	
	@PostMapping(path = "createPayId", headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public IMBResp createPayId(HttpServletRequest httpServletRequest,HttpServletResponse httpServletResponse,@RequestBody final PayIdReq req) { 
		ObjectMapper objectMapper = new ObjectMapper();	
		perfLogger.startAllLogs();
		String logName = MBAppUtils.getLogName(httpServletRequest);
		perfLogger.startLog(logName);					
		MobileSession mobileSession = new MobileSessionImpl();
		DigitalSecLogggerVO digitalSecurityLogVo = new DigitalSecLogggerVO();
		PayIdDetails payIdDetails=new PayIdDetails();
		try{
			Logger.debug("createPayId List JSON Request :" + objectMapper.writeValueAsString(req), this.getClass());
			mobileSession.getSessionContext(httpServletRequest);
			ErrorResp errorResp = validate(req, httpServletRequest);
					
			if (errorResp != null && errorResp.getErrors() != null && errorResp.getErrors().size() > 0)	{				
				return errorResp;				
			}else{								
				Customer customer = mobileSession.getCustomer();				
				IBankCommonData commonData=mbAppHelper.populateIBankCommonData(mobileSession,httpServletRequest);
				commonData.setCustomer(customer);
				Account selectedAccount = commonData.getCustomer().getAccounts().get(Integer.parseInt(req.getAccountIndex()));	
				
				payIdDetails = managePayIdService.populatePayIdDetails(commonData, selectedAccount, mobileSession.getPayIdDetails());
				digitalSecurityLogVo = managePayIdService.initializeDigitalSecLogger(commonData, DigitalSecLogger.PAYID_REGISTRATION, 
						mbAppHelper.getCommonLogData(commonData), payIdDetails);

				RegisterPayIdDetails registerPayIdDetails = new RegisterPayIdDetails();
				
				if(selectedAccount!=null ){
					if(mobileSession.getPayIdHeaderCorrId()!=null){
						commonData.setPayIdCorrelationId(mobileSession.getPayIdHeaderCorrId());
					}
					registerPayIdDetails = managePayIdService.registerPayID(commonData, selectedAccount, payIdDetails);
					
					mobileSession.setCreatedOrUpdatedPayIdDetails(registerPayIdDetails);
					digitalSecurityLogVo.setStatus(DigitalSecLogger.SUCCESS);
					digitalSecurityLogVo.setValues(managePayIdService.getPayIdDigitalSecurityLogValues(payIdDetails));
					digitalSecLogger.log(digitalSecurityLogVo);
				}
				
				RespHeader headerResp = populateResponseHeader(req.getHeader().getServiceName(), mobileSession);
				IMBResp serviceResponse = managePayIdHelper.populatePayIdCreationResp(registerPayIdDetails, commonData,mbAppHelper,Integer.parseInt(req.getAccountIndex()), payIdDetails); 
				serviceResponse.setHeader(headerResp);
				Logger.debug("createPayId JSON Response :" + objectMapper.writeValueAsString(serviceResponse), this.getClass());
				return serviceResponse;
			}				
		}catch (BusinessException e){
			Logger.warn("BusinessException in ManagePayIdController - [key: " + e.getKey() + "] : GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());				
			digitalSecurityLogVo.setStatus(DigitalSecLogger.FAILURE);
			digitalSecurityLogVo.setValues(managePayIdService.getPayIdDigitalSecurityLogValues(payIdDetails));
			digitalSecLogger.log(digitalSecurityLogVo);
			if(e.getKey() == BusinessException.PAYID_SETTINGS_NOT_AVAILABLE) {
				OriginsVO myOriginVO  = IBankParams.getOrigin(mobileSession.getOrigin());
				OriginsVO baseOrigin  = IBankParams.getOrigin(myOriginVO.getBankName());
				String[] values = {baseOrigin.getPhone()};	
				e = new BusinessException(BusinessException.PAYID_SETTINGS_NOT_AVAILABLE_MB);
				return  MBAppUtils.createErrorResp(mobileSession.getOrigin(), e, values, ServiceConstants.MANAGE_PAYID, httpServletRequest);
			}
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), e, ServiceConstants.MANAGE_PAYID, httpServletRequest);
		}catch (ResourceException e){
			Logger.error("ResourceException in ManagePayIdController - [key: " + e.getKey() + "] : GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.SYSTEM_UNAVILABLE, ServiceConstants.MANAGE_PAYID, httpServletRequest);					
		} catch (Exception e){
			Logger.error("Exception in ManagePayIdController GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.GENERIC_ERROR, ServiceConstants.MANAGE_PAYID, httpServletRequest);
		} finally{
			perfLogger.endLog(logName);
			perfLogger.endAllLogs();
		}	
	}
	
	@RequestMapping(value = "updatePayIdDetails", method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public IMBResp updatePayIdDetails(HttpServletRequest httpServletRequest,HttpServletResponse httpServletResponse,@RequestBody final PayIdReq req) { 
				
		ObjectMapper objectMapper = new ObjectMapper();	
		perfLogger.startAllLogs();
		String logName = MBAppUtils.getLogName(httpServletRequest);
		perfLogger.startLog(logName);					
		MobileSession mobileSession = new MobileSessionImpl();
		DigitalSecLogggerVO digitalSecurityLogVo = new DigitalSecLogggerVO();
		PayIdDetails payIdDetails=new PayIdDetails();
		try{
			Logger.debug("Manage Payid updatePayIdDetails List JSON Request :" + objectMapper.writeValueAsString(req), this.getClass());
			mobileSession.getSessionContext(httpServletRequest);
			ErrorResp errorResp = validate(req, httpServletRequest);
					
			if (errorResp != null && errorResp.getErrors() != null && errorResp.getErrors().size() > 0)	{				
				return errorResp;				
			}else{								
				Customer customer = mobileSession.getCustomer();				
				IBankCommonData commonData=mbAppHelper.populateIBankCommonData(mobileSession,httpServletRequest);
				commonData.setCustomer(customer);
				Account selectedAccount = commonData.getCustomer().getAccounts().get(Integer.parseInt(req.getAccountIndex()));	
				
				payIdDetails = managePayIdService.populatePayIdDetails(commonData, selectedAccount, mobileSession.getPayIdDetails());
				digitalSecurityLogVo = managePayIdService.initializeDigitalSecLogger(commonData, DigitalSecLogger.PAYID_UPDATE, 
						mbAppHelper.getCommonLogData(commonData), payIdDetails);
				RegisterPayIdDetails updatePayIdDetails = new RegisterPayIdDetails();
				
				if(selectedAccount!=null){
					if(mobileSession.getPayIdHeaderCorrId()!=null){
						commonData.setPayIdCorrelationId(mobileSession.getPayIdHeaderCorrId());
					}
					
					ManagePayIdDetails details = mobileSession.getPayIdDetails();
					if(null != details) {
						updatePayIdDetails = managePayIdService.updatePayID(commonData, selectedAccount,details);
						
						mobileSession.setCreatedOrUpdatedPayIdDetails(updatePayIdDetails);
						digitalSecurityLogVo.setStatus(DigitalSecLogger.SUCCESS);
						digitalSecurityLogVo.setValues(managePayIdService.getPayIdDigitalSecurityLogValues(payIdDetails));
						digitalSecLogger.log(digitalSecurityLogVo);
					}
					else {
						Logger.error("Unable to get Session details for SVC546" , this.getClass());
						throw new BusinessException(BusinessException.PAYID_SETTINGS_NOT_AVAILABLE);
					}
				}
				
				RespHeader headerResp = populateResponseHeader(req.getHeader().getServiceName(), mobileSession);
				IMBResp serviceResponse = managePayIdHelper.populatePayIdCreationResp(updatePayIdDetails, commonData,mbAppHelper,Integer.parseInt(req.getAccountIndex()), payIdDetails); 
				serviceResponse.setHeader(headerResp);
				Logger.debug("Manage Payid updatePayIdDetails List JSON Response :" + objectMapper.writeValueAsString(serviceResponse), this.getClass());
				return serviceResponse;
			}				
		}catch (BusinessException e){
			Logger.info("BusinessException in ManagePayIdController - [key: " + e.getKey() + "] : GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());				
			digitalSecurityLogVo.setStatus(DigitalSecLogger.FAILURE);
			digitalSecurityLogVo.setValues(managePayIdService.getPayIdDigitalSecurityLogValues(payIdDetails));
			digitalSecLogger.log(digitalSecurityLogVo);
			if(e.getKey() == BusinessException.PAYID_SETTINGS_NOT_AVAILABLE) {
				OriginsVO myOriginVO  = IBankParams.getOrigin(mobileSession.getOrigin());
				OriginsVO baseOrigin  = IBankParams.getOrigin(myOriginVO.getBankName());
				String[] values = {baseOrigin.getPhone()};	
				e = new BusinessException(BusinessException.PAYID_SETTINGS_NOT_AVAILABLE_MB);
				return  MBAppUtils.createErrorResp(mobileSession.getOrigin(), e, values, ServiceConstants.MANAGE_PAYID, httpServletRequest);
			}
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), e, ServiceConstants.MANAGE_PAYID, httpServletRequest);
		}catch (ResourceException e){
			Logger.error("ResourceException in ManagePayIdController - [key: " + e.getKey() + "] : GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.SYSTEM_UNAVILABLE, ServiceConstants.MANAGE_PAYID, httpServletRequest);					
		} catch (Exception e){
			Logger.error("Exception in ManagePayIdController GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.GENERIC_ERROR, ServiceConstants.MANAGE_PAYID, httpServletRequest);
		} finally{
			perfLogger.endLog(logName);
			perfLogger.endAllLogs();
		}	
	}
	
	@RequestMapping(value = "checkPayIdAvailability", method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public IMBResp checkPayIdAvailability(HttpServletRequest httpServletRequest,HttpServletResponse httpServletResponse,@RequestBody final PayIdReq req) { 
				
		Logger.info("checkPayIdAvailability starts",this.getClass());
		ObjectMapper objectMapper = new ObjectMapper();	
		perfLogger.startAllLogs();
		String logName = MBAppUtils.getLogName(httpServletRequest);
		perfLogger.startLog(logName);					
		MobileSession mobileSession = new MobileSessionImpl();
		String origin = null;
		String payIdMobileNumber =null;
		PayIdAvailabilityResp serviceResponse=null;
		PayIdAvailabilityDetails payIdAvailabilityDtls=null;
		DigitalSecLogggerVO digitalSecurityLogVo = new DigitalSecLogggerVO();
		PayIdDetails payIdDetails=new PayIdDetails();
		try{
			Logger.info("Manage Payid checkPayIdAvailability List JSON Request :" + objectMapper.writeValueAsString(req), this.getClass());
			mobileSession.getSessionContext(httpServletRequest);
			ErrorResp errorResp = validate(req, httpServletRequest);
					
			if (errorResp != null && errorResp.getErrors() != null && errorResp.getErrors().size() > 0)	{				
				return errorResp;				
			}else{								
				Customer customer = mobileSession.getCustomer();				
				IBankCommonData commonData=mbAppHelper.populateIBankCommonData(mobileSession,httpServletRequest);
				payIdMobileNumber = commonData.getCustomer().getContactDetail().getMobileNumber().getAreaCode() + 
						   commonData.getCustomer().getContactDetail().getMobileNumber().getPhoneNumber();
				commonData.setCustomer(customer);
				origin = commonData.getOrigin();
				RespHeader headerResp = populateResponseHeader(req.getHeader().getServiceName(), mobileSession);
				
				if(mobileSession.getPayIdHeaderCorrId()!=null){
					commonData.setPayIdCorrelationId(mobileSession.getPayIdHeaderCorrId());
				}
				 
				 Account selectedAccount = commonData.getCustomer().getAccounts().get(Integer.parseInt(req.getAccountIndex()));	
				 payIdDetails = managePayIdService.populatePayIdDetails(commonData, selectedAccount,mobileSession.getPayIdDetails());
				 digitalSecurityLogVo = managePayIdService.initializeDigitalSecLogger(commonData, DigitalSecLogger.PAYID_AVAILABILITY, 
							mbAppHelper.getCommonLogData(commonData), payIdDetails);
				 
				 ManagePayIdDetails details = mobileSession.getPayIdDetails();
				 
				 if(IBankParams.isPayIdAvailabilityServiceSwitchOn(commonData.getOrigin())) {
					 payIdAvailabilityDtls = managePayIdService.checkWDPPayIdAvailability(commonData, details);
				 }else {
					 payIdAvailabilityDtls = managePayIdService.checkPayIdAvailability(commonData);
				 }
				
				 if(payIdAvailabilityDtls.isPayIdAvailabilityStatus())
					 payIdDetails.setPayIdAvailability(DigitalSecLogger.ALIAS_YES);
				 else
					 payIdDetails.setPayIdAvailability(DigitalSecLogger.ALIAS_NO);
				 
				 
				 digitalSecurityLogVo.setStatus(DigitalSecLogger.SUCCESS);
				 digitalSecurityLogVo.setValues(managePayIdService.getPayIdDigitalSecurityLogValues(payIdDetails));
				 digitalSecLogger.log(digitalSecurityLogVo);
				 
				   if(payIdAvailabilityDtls.isPayIdAvailabilityStatus()) {
					   if(ibankRefreshParams.isNppABNPayIdRegSwitchOn()) {
						   if(null != selectedAccount && !NPPUtil.AUBN.equals(details.getSelectedPayIdType())) {
							   managePayIdService.checkAccountOwnerRelationship(selectedAccount);
						   } else {
							   Logger.info("Skipping Account ownership check for payId type - "+details.getSelectedPayIdType(), this.getClass());
						   }
					   } else {
						   if(null != selectedAccount)
							   managePayIdService.checkAccountOwnerRelationship(selectedAccount);
					   }
					    serviceResponse = managePayIdHelper.populatePayIdAvailabilityResp(payIdAvailabilityDtls); 
						serviceResponse.setHeader(headerResp);
						
						if(IBankParams.isSwitchOn(commonData.getOrigin(), IBankParams.SAFI_PAYID_REG_SWITCH)) {
	                		return callSafiAnalyse(httpServletRequest, httpServletResponse, mobileSession, commonData, req, serviceResponse);
	                	}
						Logger.debug("Manage Payid checkPayIdAvailability List JSON Response :" + objectMapper.writeValueAsString(serviceResponse), this.getClass());
						Logger.debug("checkPayIdAvailability ends",this.getClass());		       	
		            }
				   else{
					   Logger.warn("PayId already registered for GCIS : " + commonData.getUser().getGCISNumber(), this.getClass());
					    if(payIdAvailabilityDtls.getServicerBIC()!=null && payIdAvailabilityDtls.getInstitutionType().equals(IBankParams.FINANCIAL_INSTITUTION_EXTERNAL_TYPE)) {
		            	throw new BusinessException(BusinessException.PAYID_ALREADY_REGISTERED_EXTERNAL_OFI);
					    }
					    else if(payIdAvailabilityDtls.getCustomerBrandSilo()!=null && payIdAvailabilityDtls.getCustomerBrandSilo().equals(IBankParams.PAYID_WESTPAC_BRANDSILO) && 
					    		 !payIdAvailabilityDtls.getMasterSystemProductCode().equals(IBankParams.MASTER_SYSTEM_PRODUCT_CODE)) {
		              	throw new BusinessException(BusinessException.PAYID_ALREADY_REGISTERED_EXTERNAL_OFI);
					   	}
					    else if(payIdAvailabilityDtls.getCustomerBrandSilo()!=null && payIdAvailabilityDtls.getCustomerBrandSilo().equals(IBankParams.PAYID_WESTPAC_BRANDSILO) && 
					    		 payIdAvailabilityDtls.getMasterSystemProductCode().equals(IBankParams.MASTER_SYSTEM_PRODUCT_CODE)) {
		              	throw new BusinessException(BusinessException.PAYID_ALREADY_REGISTERED_WESTPAC_P2M);
					   	}
					    else if(payIdAvailabilityDtls.getCustomerBrandSilo()!=null && payIdAvailabilityDtls.getCustomerBrandSilo().equals(IBankParams.PAYID_SBG_BRANDSILO)) {
		            	throw new BusinessException(BusinessException.PAYID_ALREADY_REGISTERED_SBG);
					    } else {
					    	throw new BusinessException(BusinessException.PAYID_SETTINGS_NOT_AVAILABLE);
					    }
				   }
			return serviceResponse;
			}				
		}catch (BusinessException e){
			Logger.info("BusinessException in ManagePayIdController - [key: " + e.getKey() + "] : GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());
			String originHelpDeskPhone = null;
			String bankName = null; 
			String payId = null;
			if(ibankRefreshParams.isNppABNPayIdRegSwitchOn() && NPPUtil.AUBN.equals(mobileSession.getPayIdDetails().getSelectedPayIdType())) {
				payId = StringUtil.formatABN(mobileSession.getPayIdDetails().getPayIdAliasesDetails().get(NPPUtil.AUBN).getPaymentAliasId());
			} else {
				payId = managePayIdHelper.formatPayIdMobileNumber(payIdMobileNumber) != null ? managePayIdHelper.formatPayIdMobileNumber(payIdMobileNumber) : "000 000 000";
				payId = StringUtil.maskPayID(payId);
			}
			
			OriginsVO originVO = IBankParams.getOrigin(IBankParams.getBaseOriginCode(origin));
			 if(null!=originVO){
 				originHelpDeskPhone=originVO.getPhone();
 				bankName = originVO.getName();
 			} 
			if(BusinessException.PAYID_ALREADY_REGISTERED_EXTERNAL_OFI == e.getKey()){
				String institutionName=null;
				if(payIdAvailabilityDtls.getCustomerBrandSilo()!=null && payIdAvailabilityDtls.getCustomerBrandSilo().equals(IBankParams.PAYID_WESTPAC_BRANDSILO)){
					institutionName=payIdAvailabilityDtls.getCustomerBrandSilo();
				  }
				else{
					institutionName=payIdAvailabilityDtls.getInstitutionName();
				}
				Object[] values = {payId, institutionName, originHelpDeskPhone};	
				return MBAppUtils.createErrorResp(mobileSession.getOrigin(), e.getKey(), MessageFormat.format(MBAppUtils.getMessage(mobileSession.getOrigin(), e.getKey()), values),
						ServiceConstants.MANAGE_PAYID, httpServletRequest);
			}
			else if(BusinessException.PAYID_ALREADY_REGISTERED_WESTPAC_P2M == e.getKey()){
				 Object[] values = {payId, payIdAvailabilityDtls.getCustomerBrandSilo(), originHelpDeskPhone};			
				return MBAppUtils.createErrorResp(mobileSession.getOrigin(), e.getKey(), MessageFormat.format(MBAppUtils.getMessage(mobileSession.getOrigin(), e.getKey()), values),
						ServiceConstants.MANAGE_PAYID, httpServletRequest);
			}
			else if(BusinessException.PAYID_ALREADY_REGISTERED_SBG == e.getKey()){
			    
				Object[] values = {payId, bankName, originHelpDeskPhone};			
				return MBAppUtils.createErrorResp(mobileSession.getOrigin(), e.getKey(), MessageFormat.format(MBAppUtils.getMessage(mobileSession.getOrigin(), e.getKey()), values),
						ServiceConstants.MANAGE_PAYID, httpServletRequest);
			}// all other business exceptions
			else if(e.getKey() == BusinessException.PAYID_SETTINGS_NOT_AVAILABLE) {
				OriginsVO myOriginVO  = IBankParams.getOrigin(mobileSession.getOrigin());
				OriginsVO baseOrigin  = IBankParams.getOrigin(myOriginVO.getBankName());
				String[] values = {baseOrigin.getPhone()};	
				e = new BusinessException(BusinessException.PAYID_SETTINGS_NOT_AVAILABLE_MB);
				return  MBAppUtils.createErrorResp(mobileSession.getOrigin(), e, values, ServiceConstants.MANAGE_PAYID, httpServletRequest);
			}
			else{
				digitalSecurityLogVo.setStatus(DigitalSecLogger.FAILURE);
				digitalSecurityLogVo.setValues(managePayIdService.getPayIdDigitalSecurityLogValues(payIdDetails));
				digitalSecLogger.log(digitalSecurityLogVo);
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), e, ServiceConstants.MANAGE_PAYID, httpServletRequest);
			}
		}catch (ResourceException e){
			Logger.error("ResourceException in ManagePayIdController - [key: " + e.getKey() + "] : GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.SYSTEM_UNAVILABLE, ServiceConstants.MANAGE_PAYID, httpServletRequest);					
		} catch (Exception e){
			Logger.error("Exception in ManagePayIdController GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.GENERIC_ERROR, ServiceConstants.MANAGE_PAYID, httpServletRequest);
		}
		finally{
			perfLogger.endLog(logName);
			perfLogger.endAllLogs();
		}	
	}
	
	
	//this endpoint calls safi analyse to check if secure code is required
	@RequestMapping(value = "isSecureCodeRequired", method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public IMBResp isSecureCodeRequired(HttpServletRequest httpServletRequest,HttpServletResponse httpServletResponse,@RequestBody final PayIdReq req) { 
		ObjectMapper objectMapper = new ObjectMapper();	
		perfLogger.startAllLogs();
		String logName = MBAppUtils.getLogName(httpServletRequest);
		perfLogger.startLog(logName);					
		MobileSession mobileSession = new MobileSessionImpl();
		PayIdAvailabilityResp serviceResponse=new PayIdAvailabilityResp();
		try{
			Logger.info("Manage Payid isSecureCodeRequired List JSON Request :" + objectMapper.writeValueAsString(req), this.getClass());
			mobileSession.getSessionContext(httpServletRequest);
			ErrorResp errorResp = validate(req, httpServletRequest);
					
			if (errorResp != null && errorResp.getErrors() != null && errorResp.getErrors().size() > 0)	{				
				return errorResp;				
			}else{								
				Customer customer = mobileSession.getCustomer();				
				IBankCommonData commonData=mbAppHelper.populateIBankCommonData(mobileSession,httpServletRequest);
				commonData.setCustomer(customer);
				RespHeader headerResp = populateResponseHeader(req.getHeader().getServiceName(), mobileSession);
				serviceResponse.setHeader(headerResp);
				Account selectedAccount = commonData.getCustomer().getAccounts().get(Integer.parseInt(req.getAccountIndex()));
				if(ibankRefreshParams.isNppABNPayIdRegSwitchOn()) {
				   if(null != selectedAccount && !NPPUtil.AUBN.equals(mobileSession.getPayIdDetails().getSelectedPayIdType())) {
					   managePayIdService.checkAccountOwnerRelationship(selectedAccount);
				   } else {
					   Logger.info("Skipping Account ownership check ", this.getClass());
				   }
				} else {
				   if(null != selectedAccount)
					   managePayIdService.checkAccountOwnerRelationship(selectedAccount);
				}
				
				if(IBankParams.isSwitchOn(commonData.getOrigin(), IBankParams.SAFI_PAYID_REG_SWITCH)) {
	                	return callSafiAnalyse(httpServletRequest, httpServletResponse, mobileSession, commonData, req, serviceResponse);
				}
			Logger.debug("Manage Payid isSecureCodeRequired  JSON Response :" + objectMapper.writeValueAsString(serviceResponse), this.getClass());
					
			return serviceResponse;
			}				
		}catch (BusinessException e){
			Logger.warn("BusinessException in ManagePayIdController - [key: " + e.getKey() + "] : GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());
			if(e.getKey() == BusinessException.PAYID_SETTINGS_NOT_AVAILABLE) {
				OriginsVO myOriginVO  = IBankParams.getOrigin(mobileSession.getOrigin());
				OriginsVO baseOrigin  = IBankParams.getOrigin(myOriginVO.getBankName());
				String[] values = {baseOrigin.getPhone()};	
				e = new BusinessException(BusinessException.PAYID_SETTINGS_NOT_AVAILABLE_MB);
				return  MBAppUtils.createErrorResp(mobileSession.getOrigin(), e, values, ServiceConstants.MANAGE_PAYID, httpServletRequest);
			}
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), e, ServiceConstants.MANAGE_PAYID, httpServletRequest);
		}catch (ResourceException e){
			Logger.warn("ResourceException in ManagePayIdController - [key: " + e.getKey() + "] : GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.SYSTEM_UNAVILABLE, ServiceConstants.MANAGE_PAYID, httpServletRequest);					
		} catch (Exception e){
			Logger.error("Exception in ManagePayIdController GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.GENERIC_ERROR, ServiceConstants.MANAGE_PAYID, httpServletRequest);
		} finally{
			perfLogger.endLog(logName);
			perfLogger.endAllLogs();
		}	
		
	}
	
	private String[] getContactNumber(MobileSession mobileSession) {
		OriginsVO myOriginVO = IBankParams.getOrigin(mobileSession.getOrigin());
		OriginsVO baseOrigin = IBankParams.getOrigin(myOriginVO.getBankName());
		String[] values = { baseOrigin.getBpayPhone() };
		return values;
	}

	
	public IMBResp callSafiAnalyse(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, MobileSession mobileSession,
			IBankCommonData commonData, PayIdReq payIdReq, PayIdAvailabilityResp payIdAvailabilityResponse) throws ResourceException, BusinessException {
   		
   		SafiPayIdVO safiPayIdVO = new SafiPayIdVO();
		
		try{
		Account selectedAccount = commonData.getCustomer().getAccounts().get(Integer.parseInt(payIdReq.getAccountIndex()));	
		PayIdDetails payIdDetails = managePayIdService.populatePayIdDetails(commonData, selectedAccount, mobileSession.getPayIdDetails());
		
		safiPayIdVO = populateSafiVOForPayId(httpServletRequest, mobileSession, commonData, payIdReq, payIdDetails);
		mobileSession.setSafiRequestVO(safiPayIdVO);
		
		managePayIdService.safiAnalyzeForPayId( commonData, safiPayIdVO);
		
		if(SafiConstants.SAFI_ACTION_ALLOW.equalsIgnoreCase(safiPayIdVO.getSafiRespVO().getSafiAction()) || 
				SafiConstants.SAFI_ACTION_REVIEW.equalsIgnoreCase(safiPayIdVO.getSafiRespVO().getSafiAction())){
			payIdAvailabilityResponse.setSecureCodeReqd(false);
		}
		
		} catch(BusinessException be){
			 if(be.getKey() == BusinessException.SAFI_PAYMENT_DENY_ERROR) {
				return MBAppUtils.createErrorResp(mobileSession.getOrigin(), be, getContactNumber(mobileSession), ServiceConstants.MANAGE_PAYID, httpServletRequest);
				
			} else if (be.getKey() == BusinessException.IBANK_SECURE_REQUIRED) {
				payIdAvailabilityResponse.setSecureCodeReqd(true);
				
			} else if(be.getKey() == BusinessException.SAFI_PAYMENT_NO_PHONE_EXIST
					|| be.getKey() == BusinessException.SAFI_PAYMENT_2FA_EXEMPT
					|| be.getKey() == BusinessException.SAFI_PAYMENT_2FA_GLOBAL_BYPASS) {
				
				String[] values = getContactNumber(mobileSession);
				return MBAppUtils.createErrorResp(mobileSession.getOrigin(), be,values, ServiceConstants.MANAGE_PAYID, httpServletRequest);
				
			}else{
				throw be;
			}
		}finally{
			handleSafiResponseinCookies(httpServletRequest ,httpServletResponse, safiPayIdVO.getSafiRespVO());
		}
   		return payIdAvailabilityResponse;
   	}
	
	
	
	private SafiPayIdVO populateSafiVOForPayId(HttpServletRequest httpRequest, MobileSession mobileSession,
			IBankCommonData commonData, PayIdReq request, PayIdDetails payIdDetails) throws BusinessException {
		String validDecodedPrint;
		String devicePrint;
		Logger.debug("SAFI : populateSafiVOForPayId Device Print" +request.getDevicePrint(), this.getClass()) ;
		validDecodedPrint = SafiUtil.validateDevicePrint(request.getDevicePrint());
		devicePrint = validDecodedPrint != null ? request.getDevicePrint():null;
		
		SafiPayIdVO safiPayIdVO = null;
		
		if(null == devicePrint && null != mobileSession.getSafiLogonInfo() && null != mobileSession.getSafiLogonInfo().getDevicePrint()) {
			devicePrint = mobileSession.getSafiLogonInfo().getDevicePrint();
			Logger.debug("SAFI : populateSafiVOForPayId Device Print from request was null so getting from mobileSession.getSafiLogonInfo():" +devicePrint, this.getClass()) ;
		}
			
		boolean isMobileApp = ((logonHelper.loadCordova(httpRequest)) == -1) ? false:true;
		Logger.debug("SAFI : populateSafiVOForPayId: validDecodedPrint: " +validDecodedPrint + " devicePrint: "+devicePrint+" isMobileApp: "+isMobileApp, this.getClass()) ;
			
		safiPayIdVO = SafiWebHelper.populateSafiPayIdVO(httpRequest, devicePrint, mobileSession, isMobileApp, commonData, payIdDetails, ibankRefreshParams.isNppABNPayIdRegSwitchOn());
		
		return safiPayIdVO;
	}
	
	
	@PostMapping( value = "reqSecureCode" , headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public IMBResp reqSecureCode(HttpServletRequest httpRequest, @RequestBody final SecureCodeReq request) {
		Logger.debug("ManagePayIdController - reqSecureCode(). Request: " + request, this.getClass());

		MobileSession mobileSession = null;
		IBankCommonData commonData = null;
		try {
			mobileSession = mbAppHelper.getMobileSession(httpRequest);
			commonData = new MBAppHelper().populateIBankCommonData(mobileSession, httpRequest);
			validateRequestHeader(request.getHeader(), httpRequest);
			ErrorResp errorResponse = validate(request, httpRequest);
			
			if (errorResponse.hasErrors()){
				return errorResponse;
			}
			
			if (ServiceConstants.PAYIDREG_TRAN_CODE != request.getTranType() &&
					ServiceConstants.PAYIDREGUPD_TRAN_CODE != request.getTranType()) {
				return MBAppUtils.createInvalid2FATransactionTypeResponse(ServiceConstants.PAYIDREG_SECURE_CODE);
			}
			
			PayIdDetails payIdDetails = managePayIdService.populatePayIdDetails(commonData, null, mobileSession.getPayIdDetails());
			if(NPPUtil.PAYID_TYPE_ABNACN.equals(payIdDetails.getPayIdType())) {
				payIdDetails.setPayIdNumber(StringUtil.formatABN(payIdDetails.getPayIdNumber()));
			}
			return secureCodeHelper.reqSecureCode(commonData, mobileSession,null, payIdDetails, request,ServiceConstants.PAYIDREG_SECURE_CODE, httpRequest);
		} catch (ResourceException e) {
			Logger.error("ResourceException in ManagePayIdController - reqSecureCode() - [key: "+ e.getKey()+ "], GCIS: ["+ ((mobileSession != null && mobileSession.getCustomer() != null) ? mobileSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			mobileSession.removeSecureCodeDetails();
			return MBAppUtils.createErrorResp(IBankParams.getBaseOriginCode(mobileSession.getOrigin()),BusinessException.SYSTEM_UNAVILABLE,ServiceConstants.PAYIDREG_SECURE_CODE, httpRequest);
		} catch (Exception e) {
			Logger.error("Exception ManagePayIdController - reqSecureCode(): GCIS: [" + ((mobileSession != null && mobileSession.getCustomer() != null) ? mobileSession.getCustomer().getGcis() : "") + "]", e, this.getClass());
			mobileSession.removeSecureCodeDetails();
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(),BusinessException.GENERIC_ERROR,ServiceConstants.PAYIDREG_SECURE_CODE, httpRequest);
		}
	}


	@PostMapping(path = "verifySecCodePayId", headers = "content-type=application/json", produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public IMBResp verifySecCodePayId(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse,
			@RequestBody final SecureCodeReq req) {
		PerformanceLogger performanceLogger = new PerformanceLogger();
		performanceLogger.startAllLogs();
		String logName = MBAppUtils.getLogName(httpServletRequest);
		performanceLogger.startLog(logName);
		ObjectMapper mapper = new ObjectMapper();
		MobileSession mbSession = null;

		try {
			mbSession = mbAppHelper.getMobileSession(httpServletRequest);
			validateRequestHeader(req.getHeader(), httpServletRequest);
			ErrorResp errorResp = validate(req, httpServletRequest);
			if (errorResp != null && errorResp.getErrors() != null && errorResp.getErrors().size() > 0) {
				return errorResp;
			}

			IBankCommonData ibankCommonData = mbAppHelper.populateIBankCommonData(mbSession, httpServletRequest);
			ErrorResp errorResponse = secureCodeHelper.verifySecureCode(ibankCommonData, mbSession,
					new NonFinTransactionDetails() {
					}, req, ServiceConstants.PAYIDREG_VERIFY_SECURE_CODE, httpServletRequest);

			if (errorResponse.hasErrors()) {
				if(errorResponse.getStatus() ==  ErrorResp.STATUS_2FA_SUSPENDED ){
					callSafiNotify(httpServletRequest, httpServletResponse, false);
				}
				return errorResponse;
			} else {
				mbSession.setSecureCodeVerifiedTranName(ServiceConstants.PAYIDREG_VERIFY_SECURE_CODE);

				Logger.info("Authenticated 2FA", this.getClass());
				callSafiNotify(httpServletRequest, httpServletResponse, true);

				IMBResp serviceResponse = managePayIdHelper.populateManagePayIdResp();
				Logger.info("verifySecCodePayId JSON Response :" + mapper.writeValueAsString(serviceResponse),
						this.getClass());
				RespHeader headerResp = populateResponseHeader(ServiceConstants.PAYIDREG_VERIFY_SECURE_CODE, mbSession);
				serviceResponse.setHeader(headerResp);

				return serviceResponse;
			}
		} catch (BusinessException e) {
			Logger.error("Exception Inside verifySecCodePayId() for Customer GCIS: ["
					+ ((mbSession != null && mbSession.getCustomer() != null) ? mbSession.getCustomer().getGcis() : "")
					+ "] :", e, this.getClass());
			IMBResp resp1 = MBAppUtils.createErrorResp(IBankParams.getBaseOriginCode(mbSession.getOrigin()), e,
					ServiceConstants.PAYIDREG_VERIFY_SECURE_CODE, httpServletRequest);
			return resp1;
		} catch (Exception e) {
			Logger.error("Exception Inside verifySecCodePayId() for Customer GCIS: ["
					+ ((mbSession != null && mbSession.getCustomer() != null) ? mbSession.getCustomer().getGcis() : "")
					+ "] :", e, this.getClass());
			BusinessException exp = new BusinessException(BusinessException.SMPL_SYS_ERROR);
			IMBResp resp1 = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp,
					ServiceConstants.PAYIDREG_VERIFY_SECURE_CODE, httpServletRequest);
			return resp1;
		} finally {
			performanceLogger.endLog(logName);
			performanceLogger.endAllLogs();
		}
	}

	@PostMapping(path = "getPayIdRegStatus", headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public IMBResp getPayIdRegStatus(HttpServletRequest httpServletRequest,HttpServletResponse httpServletResponse,@RequestBody final PayIdRegStatusReq req) { 
				
		Logger.info("getPayIdRegStatus starts",this.getClass());
		ObjectMapper objectMapper = new ObjectMapper();	
		perfLogger.startAllLogs();
		String logName = MBAppUtils.getLogName(httpServletRequest);
		perfLogger.startLog(logName);		
		MobileSession mobileSession = new MobileSessionImpl();
		try{
			Logger.info("Manage PayId getPayIdRegStatus List JSON Request :" + objectMapper.writeValueAsString(req), this.getClass());
			mobileSession.getSessionContext(httpServletRequest);
			ErrorResp errorResp = validate(req, httpServletRequest);
					
			IMBResp serviceResponse = null;
			String accountNumber=null;
			if (errorResp != null && errorResp.getErrors() != null && errorResp.getErrors().size() > 0)	{				
				return errorResp;				
			}else{								
				Customer customer = mobileSession.getCustomer();				
				IBankCommonData commonData=mbAppHelper.populateIBankCommonData(mobileSession,httpServletRequest);
				commonData.setCustomer(customer);
				Account selectedAccount = commonData.getCustomer().getAccounts().get(req.getAccountIndex());
				accountNumber=selectedAccount.getAccountId().getAccountNumber();
				RegisterPayIdDetails createdOrUpdatePayIdDetails = mobileSession.getCreatedOrUpdatedPayIdDetails();
				PayIdDetails payIdDetils = managePayIdService.populatePayIdDetails(commonData, null, mobileSession.getPayIdDetails());
				createdOrUpdatePayIdDetails.setPayIdType(payIdDetils.getPayIdType() == NPPUtil.PAYID_TYPE_CONSMOB ? "Mobile": "ABN");
				createdOrUpdatePayIdDetails.setPayIdValue(payIdDetils.getPayIdNumber() == null ? payIdDetils.getPayIdMobileNumber() : payIdDetils.getPayIdNumber());
				
    			PayIdStatusDetails payIdStatusDtls = managePayIdService.fetchUpdatedRegStatus(commonData, req.getPayIdRegIdentifier(),mobileSession.getPayIdDetails().isUpdateFlow(),accountNumber, createdOrUpdatePayIdDetails);
				RespHeader headerResp = populateResponseHeader(req.getHeader().getServiceName(), mobileSession);
				serviceResponse = managePayIdHelper.populatePayIdRegStatusResp(commonData, payIdStatusDtls, mbAppHelper); 
				serviceResponse.setHeader(headerResp);		
				mobileSession.removePayIdHeaderCorrId();
				
				Logger.info("Manage PayId getPayIdRegStatus List JSON Response :" + objectMapper.writeValueAsString(serviceResponse), this.getClass());
				Logger.info("getPayIdRegStatus ends",this.getClass());
				return serviceResponse;
			}				
		}catch (BusinessException e){
			Logger.info("BusinessException in ManagePayIdController - [key: " + e.getKey() + "] : GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());				
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), e, ServiceConstants.MANAGE_PAYID, httpServletRequest);
		}catch (ResourceException e){
			Logger.error("ResourceException in ManagePayIdController - [key: " + e.getKey() + "] : GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.SYSTEM_UNAVILABLE, ServiceConstants.MANAGE_PAYID, httpServletRequest);					
		} catch (Exception e){
			Logger.error("Exception in ManagePayIdController GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.GENERIC_ERROR, ServiceConstants.MANAGE_PAYID, httpServletRequest);
		} finally{
			mobileSession.removePayIdDetails();
			mobileSession.removeCreatedOrUpdatedPayIdDetails();
			perfLogger.endLog(logName);
			perfLogger.endAllLogs();
		}	
		
	}
	
	/**
	 * Response for invalid body request 
	 * 
	 * @return
	 */
	@ExceptionHandler({org.springframework.http.converter.HttpMessageNotReadableException.class})
	@ResponseStatus(org.springframework.http.HttpStatus.OK)
	@ResponseBody
	public IMBResp resolveException() {		
		return MBAppUtils.createInvalidMessageBodyResponse(ServiceConstants.MANAGE_PAYID);
	}
	
	public ErrorResp validate(IMBReq serviceRequest, HttpServletRequest request) {
		return  mbAppValidator.validate(serviceRequest, request);
	}
	
	public void validateRequestHeader(ReqHeader header, HttpServletRequest request) throws ResourceException
	{	
		mbAppValidator.validateRequestHeader(header,  request);	
	}
	
	public RespHeader populateResponseHeader(String ServiceName)
	{		
		return mbAppHelper.populateResponseHeader(ServiceName);
	}				
	
	public RespHeader populateResponseHeader(String serviceName, MobileSession mobSession )
	{
		return mbAppHelper.populateResponseHeader(serviceName, mobSession);
	}
	
	private void callSafiNotify(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, boolean status2FA) {
		MobileSession mobileSession = new MobileSessionImpl();
		
		try{
		mobileSession.getSessionContext(httpServletRequest);
		IBankCommonData commonData=mbAppHelper.populateIBankCommonData(mobileSession,httpServletRequest);
		
		if(mobileSession.getSafiRequestVO() != null && mobileSession.getSafiRequestVO() instanceof SafiPayIdVO) {
			SafiPayIdVO safiPayIdVO = SafiWebHelper.populateSafiVOForPayIdNotify(httpServletRequest, mobileSession, commonData,  status2FA);
			
			SafiRespVO safiRespVO = safi2Service.notifySafiForPayId(commonData, safiPayIdVO);
			
			handleSafiResponseinCookies(httpServletRequest, httpServletResponse, safiRespVO);
		}
		}catch(BusinessException be){
			Logger.warn("Exception in callSafiNotify", be , getClass());
		}finally{
			mobileSession.removeSafiRequestVO();
		}
	}
	
	private void handleSafiResponseinCookies(HttpServletRequest httpServletRequest,HttpServletResponse httpServletResponse, SafiRespVO safiRespVO){
		if(safiRespVO != null){
			Cookie pmdata2 = SafiWebHelper.readCookies(httpServletRequest);
			Cookie newCookie = SafiWebHelper.createOrUpdatePmdata2Cookie(httpServletRequest,pmdata2,safiRespVO.getDeviceToken());
			httpServletResponse.addCookie(newCookie);
		}
	}
	
}
