package au.com.stgeorge.mbank.model.request.customer;

import java.io.Serializable;
import java.util.ArrayList;

import javax.validation.Valid;

import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.Length;

import au.com.stgeorge.ibank.businessobject.BusinessException;
import au.com.stgeorge.mbank.model.common.AddressReq;
import au.com.stgeorge.mbank.model.common.IMBReq;
import au.com.stgeorge.mbank.model.common.ReqHeader;

public class ContactDetailsReq implements IMBReq, Serializable{
	
	private static final long serialVersionUID = -256469501889499119L;

	@Length(max = 50, message = ""+BusinessException.WSVC_INVALID_INPUT_PARAM)
	@Email(message = ""+BusinessException.SMPL_INV_INP_PARAMS)
	private String email;

    private ReqHeader header;

    @Valid
 	private ArrayList <AddressReq>  addresses;
 	
 	private boolean emailConsent = false;
 	
 	private boolean sourceEuSplashPage;

 	private boolean sourceSecurityWellBeingCheck;
 	private String changeType;
 	
    
	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	private String qasHomeAddress;
    private String qasHomeSearchId;
    private String addressTypeHome;
    private String addressTypeMailing;
    private String qasMailingAddress;
    private String qasMailingSearchId;
	
	public String getChangeType() {
		return changeType;
	}
	public void setChangeType(String changeType) {
		this.changeType = changeType;
	}
	public boolean isSourceSecurityWellBeingCheck() {
		return sourceSecurityWellBeingCheck;
	}
	public void setSourceSecurityWellBeingCheck(boolean sourceSecurityWellBeingCheck) {
		this.sourceSecurityWellBeingCheck = sourceSecurityWellBeingCheck;
	}
	public boolean isSourceEuSplashPage() {
		return sourceEuSplashPage;
	}
	public void setSourceEuSplashPage(boolean sourceEuSplashPage) {
		this.sourceEuSplashPage = sourceEuSplashPage;
	}
	public ArrayList<AddressReq> getAddresses()
	{
		return addresses;
	}
	public void setAddresses(ArrayList<AddressReq> addresses)
	{
		this.addresses = addresses;
	}
		public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	
	public ReqHeader getHeader()
	{
		return header;
	}
	public void setHeader(ReqHeader header)
	{
		this.header = header;
	}
	
	public static long getSerialVersionUID() {
		return serialVersionUID;
	}
	
	private boolean sameAddress;

	public boolean isSameAddress()
	{
		return sameAddress;
	}
	public void setSameAddress(boolean sameAddress)
	{
		this.sameAddress = sameAddress;
	}
	
	/**
	 * @return
	 */
	public boolean isEmailConsent() {
		return emailConsent;
	}
	
	/**
	 * @param emailConsent
	 */
	public void setEmailConsent(boolean emailConsent) {
		this.emailConsent = emailConsent;
	}
	
	public String getQasHomeAddress() {
		return qasHomeAddress;
	}
	public void setQasHomeAddress(String qasHomeAddress) {
		this.qasHomeAddress = qasHomeAddress;
	}
	public String getQasHomeSearchId() {
		return qasHomeSearchId;
	}
	public void setQasHomeSearchId(String qasHomeSearchId) {
		this.qasHomeSearchId = qasHomeSearchId;
	}
	public String getAddressTypeHome() {
		return addressTypeHome;
	}
	public void setAddressTypeHome(String addressTypeHome) {
		this.addressTypeHome = addressTypeHome;
	}
	public String getAddressTypeMailing() {
		return addressTypeMailing;
	}
	public void setAddressTypeMailing(String addressTypeMailing) {
		this.addressTypeMailing = addressTypeMailing;
	}
	public String getQasMailingAddress() {
		return qasMailingAddress;
	}
	public void setQasMailingAddress(String qasMailingAddress) {
		this.qasMailingAddress = qasMailingAddress;
	}
	public String getQasMailingSearchId() {
		return qasMailingSearchId;
	}
	public void setQasMailingSearchId(String qasMailingSearchId) {
		this.qasMailingSearchId = qasMailingSearchId;
	}
	
}
