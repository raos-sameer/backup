package au.com.stgeorge.mbank.controller.payments;

import java.text.DateFormat;
import java.text.MessageFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.builder.ReflectionToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;

import au.com.stgeorge.framework.common.logging.Logger;
import au.com.stgeorge.ibank.businessobject.BusinessException;
import au.com.stgeorge.ibank.businessobject.DuplicateException;
import au.com.stgeorge.ibank.businessobject.PortfolioListsFilter;
import au.com.stgeorge.ibank.businessobject.ResourceException;
import au.com.stgeorge.ibank.common.cache.IBankParams;
import au.com.stgeorge.ibank.common.log.IBankLog;
import au.com.stgeorge.ibank.valueobject.Account;
import au.com.stgeorge.ibank.valueobject.AccountId;
import au.com.stgeorge.ibank.valueobject.Customer;
import au.com.stgeorge.ibank.valueobject.LabelValueVO;
import au.com.stgeorge.ibank.valueobject.P2PPayment;
import au.com.stgeorge.ibank.valueobject.PayToMobileAlias;
import au.com.stgeorge.ibank.valueobject.PaymentDuplicateVO;
import au.com.stgeorge.ibank.valueobject.Statistic;
import au.com.stgeorge.ibank.valueobject.database.CodesVO;
import au.com.stgeorge.ibank.valueobject.database.OriginsVO;
import au.com.stgeorge.ibank.valueobject.transfer.IBankCommonData;
import au.com.stgeorge.ibank.valueobject.transfer.PortfolioLists;
import au.com.stgeorge.mbank.controller.IMBController;
import au.com.stgeorge.mbank.controller.SecureCodeHelper;
import au.com.stgeorge.mbank.model.common.ErrorInfo;
import au.com.stgeorge.mbank.model.common.IMBReq;
import au.com.stgeorge.mbank.model.common.IMBResp;
import au.com.stgeorge.mbank.model.common.ReqHeader;
import au.com.stgeorge.mbank.model.common.RespHeader;
import au.com.stgeorge.mbank.model.request.EmptyReq;
import au.com.stgeorge.mbank.model.request.SecureCodeReq;
import au.com.stgeorge.mbank.model.request.payments.PayToMobileCancelReq;
import au.com.stgeorge.mbank.model.request.payments.PayToMobileReq;
import au.com.stgeorge.mbank.model.response.ErrorResp;
import au.com.stgeorge.mbank.model.response.payments.PayToMobileActivationResp;
import au.com.stgeorge.mbank.model.response.payments.TransferResp;
import au.com.stgeorge.mbank.session.MobileSession;
import au.com.stgeorge.mbank.session.MobileSessionImpl;
import au.com.stgeorge.mbank.util.FraudLogger;
import au.com.stgeorge.mbank.util.MBAppHelper;
import au.com.stgeorge.mbank.util.MBAppUtils;
import au.com.stgeorge.mbank.util.MBAppValidator;
import au.com.stgeorge.mbank.util.ServiceConstants;
import au.com.stgeorge.mobilebank.businessobject.MobileBankService;
import au.com.stgeorge.mobilebank.businessobject.PayMobService;
import au.com.stgeorge.perflogger.PerformanceLogger;

import com.fasterxml.jackson.databind.ObjectMapper;

@Controller
@RequestMapping("/mobile")
public class PayToMobileController implements IMBController {

	@Autowired
	private PayMobService payToMobileService;

	@Autowired
	private PayToMobileHelper helper;

	@Autowired
	private MBAppHelper mbAppHelper;
	
	@Autowired
	private MobileBankService mobileBankService;
	
	@Autowired
	private MBAppValidator mbAppValidator;

	@Autowired
	private SecureCodeHelper secureCodeHelper;
	
	private FraudLogger fraudLogger;
	
	DateFormat df = new SimpleDateFormat("yyyy-MM-dd HH.mm.ss");
	
	private String UNREGISTERERD_CUSTOMERS = "2";
	
	private String ALL_CUSTOMERS = "1";
	/**
	 * Account to account service operation
	 * 
	 * @param httpRequest
	 * @param request
	 * @return
	 */
	@RequestMapping(method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE, value = "transfer")
	@ResponseBody
	public IMBResp transfer(HttpServletRequest httpRequest, @RequestBody final PayToMobileReq request) {
		Logger.debug("PayToMobileController - transfer(). Request: " + request, this.getClass());
		String logName = startPerformanceLog(httpRequest);
		MobileSession mobileSession = new MobileSessionImpl();

		try {
			mobileSession.getSessionContext(httpRequest);
			Customer customer = mobileSession.getCustomer();
			IBankCommonData commonData = new MBAppHelper().populateIBankCommonData(mobileSession, httpRequest);

			validateRequestHeader(request.getHeader(), httpRequest);
			ErrorResp errorResponse = validate(request, httpRequest);
			if (errorResponse.hasErrors())
				return errorResponse;

			helper.validateTransferReq(request);
			return performTransfer(mobileSession, helper.populatePayment(customer, commonData, request), commonData,
					ServiceConstants.ACCOUNT_TRANSFER_SERVICE, httpRequest);

		} catch (BusinessException e) {
			Logger.info("BusinessException in PayToMobileController - transfer() - [key: " + e.getKey() + "], GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), e, ServiceConstants.ACCOUNT_TRANSFER_SERVICE, httpRequest);
		} catch (Exception e) {
			Logger.error("Exception PayToMobileController - transfer(): ", e, this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.GENERIC_ERROR, ServiceConstants.ACCOUNT_TRANSFER_SERVICE, httpRequest);
		} finally {
			endPerformanceLog(logName);
		}
	}

	private IMBResp performTransfer(MobileSession mobileSession , P2PPayment payment, IBankCommonData commonData, String caller, HttpServletRequest httpRequest) throws BusinessException {
		String origin = mobileSession.getOrigin();
		fraudLogger = new FraudLogger(); 
		Customer customer = commonData.getCustomer();
		
		try {
			
			String requestId = "";
			TransferResp response = null;
			PayToMobileAlias payToMobileAlias = null;
			try
			{
			  payToMobileAlias = payToMobileService.getAliasAccountDetails(commonData, payment.getRecipientMobNum());
			}
			catch ( BusinessException e )
			{
				Logger.error("getAliasAccountDetails Failed ...Proceeding with collection.. " + commonData.getCustomer().getGcis() + "  Mob : "+ payment.getRecipientMobNum() , this.getClass());
				payToMobileAlias = null;
			}
			
			AccountId accountId = null;
			
			if(payToMobileAlias != null){
				accountId = payToMobileAlias.getAccountId();
			}

			ArrayList<LabelValueVO> list = new ArrayList<LabelValueVO>();
			
			if(accountId == null){
				Logger.debug("performTransfer(). collection payment ", this.getClass());
				payment.setStraightThrough(false);
				requestId = pay(payment, commonData);
				
				//Adding fraud log for P2M Collection payment
				list = logCollectionPayment(commonData.getSessionId(), customer.getGcis(), payment.getFromAcct().getAccountId().getBsb(), 
						payment.getFromAcct().getAccountId().getAccountNumber(), payment.getAmount().toString(), payment.getOrigin(), commonData.getIpAddress(), 
						"P"+requestId, ServiceConstants.P2M_COLLECTION_PAYMENT, commonData.getUser().getUserId());
						
			} else {
				Logger.debug("performTransfer(). payStraightThruough : bsb accountNum=" + accountId.getBsb() + " " +accountId.getAccountNumber(), this.getClass());
				payment.setStraightThrough(true);
				
				String accountNumber = accountId.getAccountNumber();
				String bsb = accountId.getBsb();
				if(accountNumber.startsWith(bsb)){
					accountNumber = accountNumber.replaceFirst(bsb, "");
				}

				payment.setRecipientAcctNum(accountNumber);
				payment.setRecipientBSBNum(bsb);
				requestId = payStraightThrough(payment, commonData);
				
				//Adding fraud log for P2M straight through payment
				list = logStrightThruPayment(customer.getGcis(), payment.getFromAcct().getAccountId().getBsb(), payment.getFromAcct().getAccountId().getAccountNumber(), 
						payment.getRecipientBSBNum(), payment.getRecipientAcctNum(), payment.getAmount().toString(), payment.getOrigin(),  commonData.getIpAddress(), requestId,
						commonData.getSessionId(), payment.getRecipientMobNum(), ServiceConstants.P2M_STRAIGHT_PAYMENT, commonData.getUser().getUserId());
			}

			response = helper.populateTransferResponse(populateResponseHeader(caller,mobileSession ), payment, requestId);

			Logger.debug("PayToMobileController - performTransfer(). Response: " + response, this.getClass());
			
			fraudLogger.log(list, httpRequest.getHeader("User-Agent"));
			
			return response;
		} catch (DuplicateException e) {
			Logger.info("DuplicateException in PayeeController - transfer() - [key: " + e.getKey() + "], GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());
			if (e.getKey() == BusinessException.DUPLICATE_PAYMENT) {
				return helper.populateTransferResponse(populateResponseHeader(caller, mobileSession), (List<PaymentDuplicateVO>) ((DuplicateException) e)
						.getDuplicatePaymentList(), mobileSession.getCustomer().getAccounts());
			}
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), e, caller, httpRequest);
		} catch (BusinessException e) {
			Logger.info("BusinessException in PayToMobileController - transfer() - [key: " + e.getKey() + "], GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());
			if (e.getKey() == BusinessException.INVALID_CHAR_SET) {
				throw new BusinessException(BusinessException.INVALID_CHAR_SET, "Invalid Character");
			} else if (e.getKey() == BusinessException.DESCRIPTION_INVALID || e.getKey() == BusinessException.PAYER_NAME_INVALID) {
				return MBAppUtils.createErrorResp(origin, e.getKey(), MessageFormat.format(MBAppUtils.getMessage(origin, e.getKey()), e.getValues()),
						caller, httpRequest);
			} else {
				return MBAppUtils.createErrorResp(origin, e, e.getValues(), caller, httpRequest);
			}
		}
	}

	private String pay(P2PPayment payment, IBankCommonData commonData) throws BusinessException {
		Logger.debug("Payment object - " + ReflectionToStringBuilder.toString(payment, ToStringStyle.MULTI_LINE_STYLE), this.getClass());
		P2PPayment respPay = payToMobileService.addPayment(payment, commonData);
		String requestId = "";

		if (respPay != null && respPay.getId() != null) {
			requestId = respPay.getId().toString();
		}
		Logger.debug("Receipt - " + requestId, this.getClass());
		return requestId;
	}

	private String payStraightThrough(P2PPayment payment, IBankCommonData commonData) throws BusinessException {
		Logger.debug("Payment object - " + ReflectionToStringBuilder.toString(payment, ToStringStyle.MULTI_LINE_STYLE), this.getClass());
		P2PPayment respPay = payToMobileService.payStraightThrough(payment, commonData);
		String receiptNumber = "";

		if (respPay != null && respPay.getId() != null) {
			receiptNumber = respPay.getReceiptNumber();
		}
		Logger.debug("Receipt - " + receiptNumber, this.getClass());
		return receiptNumber;
	}
	
	@RequestMapping(value = "list", method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public IMBResp processPaymentList(HttpServletRequest httpServletRequest,HttpServletResponse httpServletResponse,
			@RequestBody final EmptyReq req){ 
		
		PerformanceLogger performanceLogger = new PerformanceLogger();
		ObjectMapper objectMapper = new ObjectMapper();							
		List<P2PPayment> payToMobReqs = null;			
		performanceLogger.startAllLogs();
		String logName = MBAppUtils.getLogName(httpServletRequest);
		performanceLogger.startLog(logName);		
		MobileSession mbSession = null;			
		try{
			mbSession = mbAppHelper.getMobileSession(httpServletRequest);
			Logger.info("P2M RequestList JSON Request :" + objectMapper.writeValueAsString(req), this.getClass());
			validateRequestHeader(req.getHeader(), httpServletRequest);								
			ErrorResp errorResp = validate(req, httpServletRequest);
					
			if (errorResp != null && errorResp.getErrors() != null && errorResp.getErrors().size() > 0)
				return errorResp;
		
			Customer customer = mbSession.getCustomer();
			
			IBankCommonData commonData=mbAppHelper.populateIBankCommonData(mbSession,httpServletRequest);
			payToMobReqs = mobileBankService.getPayToMobReqs(commonData);
													
			IMBResp serviceResponse = helper.populatePaymentListResp(payToMobReqs, customer);
			
			RespHeader headerResp = populateResponseHeader(ServiceConstants.PAY_TO_MOBILE_LIST_SERVICE, mbSession);
			serviceResponse.setHeader(headerResp);
			
			Logger.info(" P2M RequestList :" + objectMapper.writeValueAsString(serviceResponse), this.getClass());
			
			return serviceResponse;
					
		}catch (BusinessException e){
			Logger.info("BusinessException Inside processPaymentList() for Customer ", e, this.getClass());
			BusinessException exp = new BusinessException(e.getKey());
			IMBResp resp1  = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, ServiceConstants.PAY_TO_MOBILE_LIST_SERVICE, httpServletRequest);
			return resp1;
		}catch (ResourceException e){
			Logger.error("ResourceException Inside processPaymentList() for Customer ", e, this.getClass());
			ResourceException exp = new ResourceException(e.getKey());
			IMBResp resp1  = MBAppUtils.createErrorResp(mbSession.getOrigin(), BusinessException.SYSTEM_UNAVILABLE, ServiceConstants.PAY_TO_MOBILE_LIST_SERVICE, httpServletRequest);
			return resp1;
		} catch (Exception e)
		{
			Logger.error("Exception Inside processPaymentList() for Customer ", e, this.getClass());
			BusinessException exp = new BusinessException(BusinessException.GENERIC_ERROR);
			IMBResp resp1  = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, ServiceConstants.PAY_TO_MOBILE_LIST_SERVICE, httpServletRequest);
			return resp1;
		} finally
		{
			performanceLogger.endLog(logName);
			performanceLogger.endAllLogs();
		}	
						
	}
	
	@RequestMapping(value = "cancel", method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public IMBResp processPaymentCancel(HttpServletRequest httpServletRequest,HttpServletResponse httpServletResponse,
			@RequestBody final PayToMobileCancelReq req){ 
		
		PerformanceLogger performanceLogger = new PerformanceLogger();
		ObjectMapper objectMapper = new ObjectMapper();													
		performanceLogger.startAllLogs();
		String logName = MBAppUtils.getLogName(httpServletRequest);
		performanceLogger.startLog(logName);		
		MobileSession mbSession = null;			
		try{
			mbSession = mbAppHelper.getMobileSession(httpServletRequest);
			Logger.info("P2M RequestCancel JSON Request :" + objectMapper.writeValueAsString(req), this.getClass());
			validateRequestHeader(req.getHeader(), httpServletRequest);								
			ErrorResp errorResp = validate(req, httpServletRequest);
					
			if (errorResp != null && errorResp.getErrors() != null && errorResp.getErrors().size() > 0)
				return errorResp;
		
			IBankCommonData commonData=mbAppHelper.populateIBankCommonData(mbSession,httpServletRequest);
			String reqId = req.getRequestId().toString();			
			
			payToMobileService.cancelPayToMobReq(reqId, commonData);
													
			IMBResp serviceResponse = helper.populatePaymentCancelResp();
			
			RespHeader headerResp = populateResponseHeader(ServiceConstants.PAY_TO_MOBILE_CANCEL_SERVICE, mbSession);
			serviceResponse.setHeader(headerResp);
			
			Logger.info(" P2M RequestCancel :" + objectMapper.writeValueAsString(serviceResponse), this.getClass());
			
			return serviceResponse;
					
		}catch (BusinessException e)
		{
			Logger.info("BusinessException Inside processPaymentCancel() for Customer ", e, this.getClass());
			BusinessException exp = new BusinessException(e.getKey());
			IMBResp resp1  = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, ServiceConstants.PAY_TO_MOBILE_CANCEL_SERVICE, httpServletRequest);
			return resp1;
		}catch (ResourceException e){
			Logger.error("ResourceException Inside processPaymentCancel() for Customer ", e, this.getClass());
			ResourceException exp = new ResourceException(e.getKey());
			IMBResp resp1  = MBAppUtils.createErrorResp(mbSession.getOrigin(), BusinessException.SYSTEM_UNAVILABLE, ServiceConstants.PAY_TO_MOBILE_CANCEL_SERVICE, httpServletRequest);
			return resp1;
		} catch (Exception e)
		{
			Logger.error("Exception Inside processPaymentCancel() for Customer ", e, this.getClass());
			BusinessException exp = new BusinessException(BusinessException.GENERIC_ERROR);
			IMBResp resp1  = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, ServiceConstants.PAY_TO_MOBILE_CANCEL_SERVICE, httpServletRequest);
			return resp1;
		} finally
		{
			performanceLogger.endLog(logName);
			performanceLogger.endAllLogs();
		}	
						
	}
	
	public ErrorResp validate(IMBReq serviceRequest, HttpServletRequest request) {
		Logger.info("Service request object - " + ReflectionToStringBuilder.toString(serviceRequest), this.getClass());
		return mbAppValidator.validate(serviceRequest, request);
	}

	public RespHeader populateResponseHeader(String serviceName, MobileSession mobSession) {
		return mbAppHelper.populateResponseHeader(serviceName, mobSession);
	}
	
	public void validateRequestHeader(ReqHeader headerReq, HttpServletRequest request) throws BusinessException {
		Logger.debug("Request header validation: " + ReflectionToStringBuilder.toString(headerReq, ToStringStyle.MULTI_LINE_STYLE), this.getClass());
		new MBAppValidator().validateRequestHeader(headerReq, request);
	}

	/**
	 * Response for invalid body request
	 * 
	 * @return
	 */
	@ExceptionHandler( { org.springframework.http.converter.HttpMessageNotReadableException.class })
	@ResponseStatus(org.springframework.http.HttpStatus.OK)
	@ResponseBody
	public IMBResp resolveException() {
		return MBAppUtils.createInvalidMessageBodyResponse(ServiceConstants.PAY_TO_MOBILE_SERVICE);
	}
	
	
	@Autowired
	private PerformanceLogger perfLogger;
	
	private String startPerformanceLog(HttpServletRequest httpRequest){
		perfLogger.startAllLogs();
		String logName = MBAppUtils.getLogName(httpRequest);
		perfLogger.startLog(logName);
		return logName;
	}
	
	private void endPerformanceLog(String logName){
		perfLogger.endLog(logName);
		perfLogger.endAllLogs();
	}


	/**
	 * Check if customer is eligible for alias registration if yes, check if he
	 * is already registered or not
	 * 
	 * @param httpRequest
	 * @param request
	 * @return
	 */
	@RequestMapping(method = RequestMethod.POST, headers = "content-type=application/json", produces = MediaType.APPLICATION_JSON_VALUE, value = "checkActivation")
	@ResponseBody
	public IMBResp checkActivation(HttpServletRequest httpRequest, @RequestBody final PayToMobileReq request) {
		Logger.debug("PayToMobileController - checkActivation(). Request: " + request, this.getClass());
		String logName = startPerformanceLog(httpRequest);
		MobileSession mobileSession = new MobileSessionImpl();
		PayToMobileActivationResp resp = new PayToMobileActivationResp();
		ObjectMapper mapper = new ObjectMapper();
		
		try {
			mobileSession.getSessionContext(httpRequest);
			IBankCommonData commonData = new MBAppHelper().populateIBankCommonData(mobileSession, httpRequest);

			validateRequestHeader(request.getHeader(), httpRequest);// ??
			boolean isAliasRegistered = false;
			if (payToMobileService.getAliasDetail(commonData) != null) {
				isAliasRegistered = true;
				Logger.debug("PayToMobileController - checkActivation() - isAliasRegistered:  "+ isAliasRegistered, this.getClass());
			}
			
			// validate the pay to mobile switch value against alias
			// registration and set the flag to show intercept page accordingly.
			if (isP2MDecomInterceptMessageRequired(commonData.getOrigin(), isAliasRegistered)) {
				resp.setShowP2MIntercept(true);
				resp.setShowP2MNewInterceptContent(populateInterceptSwitchVal(commonData.getOrigin()));
				Logger.debug("PayToMobileController - checkActivation(). Response: " + mapper.writeValueAsString(resp), this.getClass());
				return resp;
			}
			// set pay to mobile banner switch based on switch value.
			if (isP2MBannerRequired(commonData.getOrigin(), isAliasRegistered)){
				resp.setShowP2MBanner(true);
			}else{
				resp.setShowP2MBanner(false);
			}
			
			int retValue = payToMobileService.checkActivationEntitlement(commonData, false);

			if (retValue == -1 || retValue == BusinessException.P2M_NO_ELIGIBLE_TRANSFER_TO_ACCOUNT
					|| retValue == BusinessException.P2M_NO_SECURE_CODE_REGISTERED || "ServiceMenu".equals(request.getEntryPoint())) {

				resp.setIsAliasRegistered(isAliasRegistered);

				Logger.info("PayToMobileController - checkActivation(). Response: " + resp.getIsAliasRegistered(), this.getClass());

				if (!resp.getIsAliasRegistered()) {
					if (!payToMobileService.isAliasAvailable(commonData)) {
						resp.setError(populateErrorInfo(commonData, BusinessException.P2M_MOBILE_ALREADY_REGISTERED));
					}
				}

				if (resp.getIsAliasRegistered() && retValue != -1) {
					retValue = payToMobileService.checkActivationEntitlement(commonData, true);
				}
			}

			if (retValue != -1) {

				ErrorInfo errorInfo = populateErrorInfo(commonData, retValue);

				resp.setError(errorInfo);
			}

			Logger.debug("PayToMobileController - checkActivation(). Response: " + mapper.writeValueAsString(resp), this.getClass());

			return resp;

		} catch (BusinessException e) {
			Logger.info(
					"BusinessException in PayToMobileController - checkActivation() - [key: " + e.getKey() + "], GCIS: ["
							+ ((mobileSession != null && mobileSession.getCustomer() != null) ? mobileSession.getCustomer().getGcis() : "")
							+ "] :", e, this.getClass());
			ErrorInfo errorInfo = MBAppUtils
					.createErrorResp(mobileSession.getOrigin(), e, ServiceConstants.ACCOUNT_TRANSFER_SERVICE, httpRequest).getErrors()
					.get(0);
			resp.setError(errorInfo);
			return resp;
		} catch (Exception e) {
			Logger.error("Exception PayToMobileController - checkActivation(): ", e, this.getClass());
			ErrorInfo errorInfo = MBAppUtils
					.createErrorResp(mobileSession.getOrigin(), BusinessException.GENERIC_ERROR, ServiceConstants.ACCOUNT_TRANSFER_SERVICE,
							httpRequest).getErrors().get(0);
			resp.setError(errorInfo);
			return resp;
		} finally {
			endPerformanceLog(logName);
		}
	}
	
	/**
	 * @param origin
	 * @return
	 */
	private boolean isP2MDecomInterceptMessageRequired(String origin, boolean isAliasRegistered) {
		Logger.debug("PayToMobileController - isP2MDecomInterceptMessageRequired() - isAliasRegistered "+ isAliasRegistered, this.getClass());
		Logger.debug("PayToMobileController - isP2MDecomInterceptMessageRequired() - origin "+ origin, this.getClass());
		
		
		String switchValue = ""; 
		try {
			CodesVO codesVO = IBankParams
					.getCodesData(origin, IBankParams.CONFIGURATION_PROPERTIES, IBankParams.P2M_DECOM_INTERCEPT_SWITCH);
			switchValue = codesVO.getMessage().trim();
		} catch (Exception e) {
			IBankLog.logEOTFail("unable to get pay to mobile decom intercept switch from IBankParams", IBankParams.class);
		}
		Logger.debug("PayToMobileController - P2M_DECOM_INTERCEPT_SWITCH value - "+switchValue, this.getClass());
		
		if ((switchValue.equals(UNREGISTERERD_CUSTOMERS) && !isAliasRegistered) || switchValue.equals(ALL_CUSTOMERS)){
			Logger.debug("PayToMobileController - InterceptMessage Required.", this.getClass());
			return true;
		}
		Logger.debug("PayToMobileController - InterceptMessage NOT Required.", this.getClass());
		return false;
	}
	
	private boolean populateInterceptSwitchVal(String origin){
		Logger.debug("PayToMobileController - populateInterceptSwitchVal() - origin "+ origin, this.getClass());
		String switchValue = ""; 
		try {
			CodesVO codesVO = IBankParams
					.getCodesData(origin, IBankParams.CONFIGURATION_PROPERTIES, IBankParams.P2M_DECOM_INTERCEPT_SWITCH);
			switchValue = codesVO.getMessage().trim();
		} catch (Exception e) {
			IBankLog.logEOTFail("unable to get pay to mobile decom intercept switch from IBankParams", IBankParams.class);
		}
		Logger.debug("PayToMobileController - P2M_DECOM_INTERCEPT_SWITCH value - "+switchValue, this.getClass());
		
		if (switchValue.equals(ALL_CUSTOMERS)){
			Logger.debug("PayToMobileController - New Intercept Message Required for ALL Customers.", this.getClass());
			return true;
		}
		Logger.debug("PayToMobileController - New Intercept Message NOT Required.", this.getClass());
		return false;
	}
	
	/**
	 * @param origin
	 * @return
	 */
	private boolean isP2MBannerRequired(String origin, boolean isAliasRegistered) {
		Logger.debug("PayToMobileController - isP2MBannerRequired - isAliasRegistered - "+isAliasRegistered, this.getClass());
		Logger.debug("PayToMobileController - isP2MBannerRequired - origin - "+origin, this.getClass());
		String switchValue = ""; 
		try {
			CodesVO codesVO = IBankParams
					.getCodesData(origin, IBankParams.CONFIGURATION_PROPERTIES, IBankParams.P2M_BANNER_SWITCH);
			switchValue = codesVO.getMessage().trim();
		} catch (Exception e) {
			IBankLog.logEOTFail("unable to get pay to mobile decom intercept switch from IBankParams", IBankParams.class);
		}
		
		Logger.debug("PayToMobileController - isP2MBannerRequired - P2M_BANNER_SWITCH value - "+switchValue, this.getClass());
		
		
		if (isAliasRegistered && switchValue.equals("ON") ){
			Logger.debug("PayToMobileController - P2M Banner Required - Return TRUE ", this.getClass());
			return true;
		}
		Logger.debug("PayToMobileController - P2M Banner Not Required - Return FALSE ", this.getClass());
		return false;
	}

	private ErrorInfo populateErrorInfo(IBankCommonData commonData, int retValue) {
		String baseOrigin = IBankParams.getBaseOriginCode(commonData.getOrigin());
		OriginsVO allOriginVO  = IBankParams.getOrigin(baseOrigin);			
		String[] values = {allOriginVO.getPhone()};
		String message = MBAppUtils.getMessage(commonData.getOrigin(), retValue, values);
		
		ErrorInfo errorInfo = new ErrorInfo();
		errorInfo.setCode(String.valueOf(retValue));
		errorInfo.setMessage(message);
		return errorInfo;
	}
	
	/**
	 * Registration of alias - customer mobile number (alias) is registered with the selected account
	 *  
	 * @param httpRequest
	 * @param request
	 * @return
	 */
	@RequestMapping(method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE, value = "activatePayToMobile")
	@ResponseBody
	public IMBResp activatePayToMobile(HttpServletRequest httpRequest, @RequestBody final PayToMobileReq request) {
		
		Logger.debug("PayToMobileController - activatePayToMobile(). Request: " + request, this.getClass());
		
		String logName = startPerformanceLog(httpRequest);
		
		MobileSession mbSession = null;

		fraudLogger = new FraudLogger(); 
		
		try {
			
			validateRequestHeader(request.getHeader(), httpRequest);
			
			MBAppHelper appHelper = new MBAppHelper();			
			mbSession = appHelper.getMobileSession(httpRequest);
			
			int accountIndex = request.getAccountIndex();

			Customer customer = mbSession.getCustomer();				
			Account selectedAccount = appHelper.getAccountFromCustomer(customer, accountIndex);
			
			if(selectedAccount == null || selectedAccount.getAccountId() == null){
				throw new BusinessException(BusinessException.NO_INFORMATION);
			}
			
			IBankCommonData commonData = appHelper.populateIBankCommonData(mbSession, httpRequest);
				
			boolean respValue = payToMobileService.createAlias(commonData, selectedAccount.getAccountId());
			
			if(respValue){
				payToMobileService.makeStatisticsLog(commonData, "", Statistic.PAY_TO_MOBILE_ACTIVATION);
			}
			PayToMobileActivationResp resp = new PayToMobileActivationResp();
			
			resp.setSuccess(respValue);
			
			Logger.info("PayToMobileController - activatePayToMobile(). Response: " + resp.getSuccess(), this.getClass());
			Logger.debug("PayToMobileController - activatePayToMobile(). Response: " + resp, this.getClass());
			
			//Adding fraud log for P2M alias activation
			String phoneNum = customer.getContactDetail().getMobileNumber().getAreaCode()+customer.getContactDetail().getMobileNumber().getPhoneNumber();
			ArrayList<LabelValueVO> list = logActivateUpdate(customer.getGcis(), selectedAccount.getAccountId().getBsb(),  selectedAccount.getAccountId().getAccountNumber(), 
					phoneNum, commonData.getIpAddress(), commonData.getOrigin(), commonData.getSessionId(), ServiceConstants.P2M_ACTIVATION, commonData.getUser().getUserId());
			fraudLogger.log(list, httpRequest.getHeader("User-Agent"));
			
			return resp;

		} catch (BusinessException e) {
			Logger.info("BusinessException in PayToMobileController - activatePayToMobile() - [key: " + e.getKey() + "], GCIS: ["+ ((mbSession != null && mbSession.getCustomer() != null) ? mbSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());
			return MBAppUtils.createErrorResp(mbSession.getOrigin(), e, ServiceConstants.PAY_TO_MOBILE_SERVICE, httpRequest);
		} catch (Exception e) {
			Logger.error("Exception PayToMobileController - activatePayToMobile(): ", e, this.getClass());
			return MBAppUtils.createErrorResp(mbSession.getOrigin(), BusinessException.GENERIC_ERROR, ServiceConstants.PAY_TO_MOBILE_SERVICE, httpRequest);
		} finally {
			endPerformanceLog(logName);
		}
	}
	
	/**
	 * Request security code service operation 
	 * 
	 * @param request
	 * @return
	 */
	@RequestMapping(method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE, value = "reqsecurecode")
	@ResponseBody
	public IMBResp reqSecureCode(HttpServletRequest httpRequest, @RequestBody final SecureCodeReq request) {
		Logger.debug("PayToMobileController - reqSecureCode(). Request: " + request, this.getClass());
		String logName = startPerformanceLog(httpRequest);
		MobileSession mobileSession = new MobileSessionImpl();

		try {
			mobileSession.getSessionContext(httpRequest);
			IBankCommonData commonData = new MBAppHelper().populateIBankCommonData(mobileSession, httpRequest);

			validateRequestHeader(request.getHeader(), httpRequest);
			ErrorResp errorResponse = validate(request, httpRequest);// validate json
			if (errorResponse.hasErrors())
				return errorResponse;

			if (ServiceConstants.PAY_TO_MOBILE_2FA_TRAN_CODE != request.getTranType()) {
				return MBAppUtils.createInvalid2FATransactionTypeResponse(ServiceConstants.PAY_TO_MOBILE_SECURE_CODE_SERVICE);
			}

			return secureCodeHelper.reqSecureCode(commonData, mobileSession, mobileSession.getTransaction(), null, request,
					ServiceConstants.PAY_TO_MOBILE_SECURE_CODE_SERVICE, httpRequest);
		} catch (ResourceException e) {
			Logger.error("ResourceException in PayToMobileController - reqSecureCode() - [key: " + e.getKey() + "] : GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());
			mobileSession.removeSecureCodeDetails();
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.SYSTEM_UNAVILABLE, ServiceConstants.PAY_TO_MOBILE_SECURE_CODE_SERVICE, httpRequest);
		} catch (Exception e) {
			Logger.error("Exception PayToMobileController - reqSecureCode(): GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			mobileSession.removeSecureCodeDetails();
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.GENERIC_ERROR, ServiceConstants.PAY_TO_MOBILE_SECURE_CODE_SERVICE, httpRequest);
		} finally {
			endPerformanceLog(logName);
		}
		
	}
	
	/**
	 * Secure transfer service operation
	 * 
	 * @param request
	 * @return
	 */
	@RequestMapping(method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE, value = "authenticateSecure")
	@ResponseBody
	public IMBResp transferSecure(HttpServletRequest httpRequest, @RequestBody final SecureCodeReq request) {
		Logger.debug("PayToMobileController - transferSecure(). Request: " + request, this.getClass());
		String logName = startPerformanceLog(httpRequest);
		MobileSession mobileSession = new MobileSessionImpl();
		ArrayList<Integer> accountList = new ArrayList<Integer>();

		try {
			mobileSession.getSessionContext(httpRequest);
			IBankCommonData commonData = new MBAppHelper().populateIBankCommonData(mobileSession, httpRequest);

			PayToMobileActivationResp resp = new PayToMobileActivationResp();
			
			validateRequestHeader(request.getHeader(), httpRequest);
			ErrorResp errorResponse = validate(request, httpRequest);// validate json
			if (errorResponse.hasErrors())
				return errorResponse;

			if (ServiceConstants.PAY_TO_MOBILE_2FA_TRAN_CODE != request.getTranType())
				return MBAppUtils.createInvalid2FATransactionTypeResponse(ServiceConstants.PAY_TO_MOBILE_SECURE_CODE_SERVICE);

			errorResponse = secureCodeHelper.verifySecureCode(commonData, mobileSession, mobileSession.getTransaction(), request,
					ServiceConstants.PAY_TO_MOBILE_SECURE_CODE_SERVICE, httpRequest);
			if (errorResponse.hasErrors())
				return errorResponse;

			PortfolioLists portfolioLists = PortfolioListsFilter.getPortfolioList(commonData, PortfolioLists.LIST_ALL_P2M_ACTIVATION_ACCOUNTS);
			if(portfolioLists != null){ 
				for(Account account : portfolioLists.getAccounts()){
					accountList.add(account.getIndex());
				}
			}

			RespHeader headerResp = populateResponseHeader(ServiceConstants.UPDCONTACTDTL_RESPONSE, mobileSession);
			resp.setHeader(headerResp);
			resp.setAccountIndexes(accountList);
			
			return resp;
		} catch (ResourceException e) {
			Logger.info("Exception - [key: " + e.getKey() + "] : GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());
			mobileSession.removeTransaction();
			mobileSession.removeSecureCodeDetails();
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.SYSTEM_UNAVILABLE, ServiceConstants.TT_TRANSFER_SECURE_SERVICE, httpRequest);
		} catch (Exception e) {
			Logger.error("Exception PayToMobileController - reqSecureCode(): GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			mobileSession.removeTransaction();
			mobileSession.removeSecureCodeDetails();
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.GENERIC_ERROR, ServiceConstants.TT_TRANSFER_SECURE_SERVICE, httpRequest);
		} finally {
			endPerformanceLog(logName);
		}
	}
	
	
	/**
	 * Check if customer is eligible for alias  registration if yes, check if he is already registered or not 
	 * 
	 * @param httpRequest
	 * @param request
	 * @return
	 */
	@RequestMapping(method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE, value = "getAliasDetail")
	@ResponseBody
	public IMBResp getAliasDetail(HttpServletRequest httpRequest, @RequestBody final PayToMobileReq request) {
		Logger.debug("PayToMobileController - getAliasDetail(). Request: " + request, this.getClass());
		String logName = startPerformanceLog(httpRequest);
		MobileSession mobileSession = new MobileSessionImpl();
		PayToMobileActivationResp resp = new PayToMobileActivationResp();

		try {
			mobileSession.getSessionContext(httpRequest);
			IBankCommonData commonData = new MBAppHelper().populateIBankCommonData(mobileSession, httpRequest);

			validateRequestHeader(request.getHeader(), httpRequest);//??

			MobileSession mobSession = mbAppHelper.getMobileSession(httpRequest);
			PayToMobileAlias payToMobileAlias = mobSession.getPayToMobileAlias(); 
				
			if(payToMobileAlias == null){
				payToMobileAlias = payToMobileService.getAliasDetail(commonData);
				if(payToMobileAlias != null){
					Customer customer = commonData.getCustomer();
					String mobileNumber = customer.getContactDetail().getMobileNumber().getAreaCode()+customer.getContactDetail().getMobileNumber().getPhoneNumber();
					PayToMobileAlias payToMobAlias = payToMobileService.getAliasAccountDetails(commonData, mobileNumber);
					if(payToMobAlias != null ){
						payToMobileAlias.setAccountId(payToMobAlias.getAccountId());
					}
				} else {
					//TODO change error code in 16E3 sprint 4
					throw new BusinessException(BusinessException.GENERIC_ERROR, "Customer not registered for P2M alias");
				}
			}

			ArrayList<Integer> accountList = new ArrayList<Integer>();
			PortfolioLists portfolioLists = PortfolioListsFilter.getPortfolioList(commonData, PortfolioLists.LIST_ALL_P2M_ACTIVATION_ACCOUNTS );
			resp.setSelectedIndex(-1);
			if(portfolioLists == null){ 				
				resp.setAccountIndexes(accountList);
			} else {
				AccountId aliasAccountId = payToMobileAlias.getAccountId();
				for(Account account : portfolioLists.getAccounts()){
					accountList.add(account.getIndex());
					AccountId accountId = account.getAccountId();
					
					if(accountId.getBsb().equals(aliasAccountId.getBsb()) && accountId.getAccountNumber().equals(aliasAccountId.getAccountNumber())) {
						resp.setSelectedIndex(account.getIndex());
					}
				}
				resp.setAccountIndexes(accountList);
			}
			
			mobSession.setPayToMobileAlias(payToMobileAlias);

			
			Logger.debug("PayToMobileController - getAliasDetail(). Response: " + resp, this.getClass());
			
			return resp;

		} catch (BusinessException e) {
			Logger.info("BusinessException in PayToMobileController - getAliasDetail() - [key: " + e.getKey() + "], GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());
			ErrorInfo errorInfo = MBAppUtils.createErrorResp(mobileSession.getOrigin(), e, ServiceConstants.ACCOUNT_TRANSFER_SERVICE, httpRequest).getErrors().get(0);
			resp.setError(errorInfo);
			return resp;
		} catch (Exception e) {
			Logger.error("Exception PayToMobileController - getAliasDetail(): ", e, this.getClass());
			ErrorInfo errorInfo =  MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.GENERIC_ERROR, ServiceConstants.ACCOUNT_TRANSFER_SERVICE, httpRequest).getErrors().get(0);
			resp.setError(errorInfo);
			return resp;
		} finally {
			endPerformanceLog(logName);
		}
	}
	
	/**
	 * Registration of alias - customer mobile number (alias) is registered with the selected account
	 *  
	 * @param httpRequest
	 * @param request
	 * @param appHelper 
	 * @return
	 */
	@RequestMapping(method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE, value = "updatePayToMobileAccount")
	@ResponseBody
	public IMBResp updatePayToMobileAccount(HttpServletRequest httpRequest, @RequestBody final PayToMobileReq request) {
		
		Logger.debug("PayToMobileController - updatePayToMobileAccount(). Request: " + request, this.getClass());
		
		String logName = startPerformanceLog(httpRequest);
		
		MobileSession mbSession = null;

		fraudLogger = new FraudLogger();
		
		try {
			
			validateRequestHeader(request.getHeader(), httpRequest);
			
			mbSession = mbAppHelper.getMobileSession(httpRequest);
			
			int accountIndex = request.getAccountIndex();

			Customer customer = mbSession.getCustomer();	
			PayToMobileAlias payToMobileAlias = mbSession.getPayToMobileAlias();
			
			Account selectedAccount = mbAppHelper.getAccountFromCustomer(customer, accountIndex);
			
			if(selectedAccount == null || selectedAccount.getAccountId() == null){
				throw new BusinessException(BusinessException.NO_INFORMATION);
			}
			
			IBankCommonData commonData = mbAppHelper.populateIBankCommonData(mbSession, httpRequest);
				
			boolean respValue = payToMobileService.updateRegisteredAlias(commonData, selectedAccount.getAccountId(), payToMobileAlias);
			
			if(respValue){
				payToMobileAlias.setAccountId(selectedAccount.getAccountId());
				mbSession.setPayToMobileAlias(payToMobileAlias);
			}

			PayToMobileActivationResp resp = new PayToMobileActivationResp();
			
			resp.setSuccess(respValue);
			
			Logger.info("PayToMobileController - updatePayToMobileAccount(). Response: " + resp.getSuccess(), this.getClass());
			Logger.debug("PayToMobileController - updatePayToMobileAccount(). Response: " + resp, this.getClass());
			
			//Adding fraud log for P2M alias update
			String phoneNum = customer.getContactDetail().getMobileNumber().getAreaCode()+customer.getContactDetail().getMobileNumber().getPhoneNumber();
			ArrayList<LabelValueVO> list = logActivateUpdate(customer.getGcis(), selectedAccount.getAccountId().getBsb(),  selectedAccount.getAccountId().getAccountNumber(), 
					phoneNum, commonData.getIpAddress(), commonData.getOrigin(), commonData.getSessionId(), ServiceConstants.P2M_UPDATE, commonData.getUser().getUserId());
			fraudLogger.log(list, httpRequest.getHeader("User-Agent"));
			return resp;

		} catch (BusinessException e) {
			Logger.info("BusinessException in PayToMobileController - updatePayToMobileAccount() - [key: " + e.getKey() + "], GCIS: ["+ ((mbSession != null && mbSession.getCustomer() != null) ? mbSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());
			return MBAppUtils.createErrorResp(mbSession.getOrigin(), e, ServiceConstants.PAY_TO_MOBILE_SERVICE, httpRequest);
		} catch (Exception e) {
			Logger.error("Exception PayToMobileController - updatePayToMobileAccount(): ", e, this.getClass());
			return MBAppUtils.createErrorResp(mbSession.getOrigin(), BusinessException.GENERIC_ERROR, ServiceConstants.PAY_TO_MOBILE_SERVICE, httpRequest);
		} finally {
			endPerformanceLog(logName);
		}
	}
	
	public ArrayList<LabelValueVO> logStrightThruPayment(String customerID, String payerBSB, String payerAccountNum, String payeeBSB, String payeeAccountNum, String amount, 
			String origin, String ipAddress, String receiptNum, String sessionId, String payeeMobNum, String tranName, String canNum)
	{
		ArrayList<LabelValueVO> list = new ArrayList<LabelValueVO>();
		list.add(new LabelValueVO("SessionId", sessionId));
		list.add(new LabelValueVO("CAN", canNum));
		list.add(new LabelValueVO("GCISNumber", customerID));
		list.add(new LabelValueVO("PayerBSB", payerBSB));
		list.add(new LabelValueVO("PayerAccountNumber", payerAccountNum));
		list.add(new LabelValueVO("PayeeMobileNum", payeeMobNum));
		list.add(new LabelValueVO("PayeeBSB", payeeBSB));
		list.add(new LabelValueVO("PayeeAccountNumber", payeeAccountNum));
		list.add(new LabelValueVO("PaymentValue", amount));
		list.add(new LabelValueVO("Date", df.format(Calendar.getInstance().getTime())));
		list.add(new LabelValueVO("Origin", origin));
		list.add(new LabelValueVO("IPAddress", ipAddress));
		list.add(new LabelValueVO("ReceiptNumber", receiptNum));
		list.add(new LabelValueVO("TranName", tranName));
		return list;
	}
	
	public ArrayList<LabelValueVO> logActivateUpdate(String gcisNum, String bsb, String accountNum, String phoneNum, String ipAddress, String origin, String sessionId,
			String tranName, String canNum)
	{
		ArrayList<LabelValueVO> list = new ArrayList<LabelValueVO>();
		list.add(new LabelValueVO("SessionId", sessionId));
		list.add(new LabelValueVO("CAN", canNum));
		list.add(new LabelValueVO("GCISNumber", gcisNum));
		list.add(new LabelValueVO("BSB", bsb));
		list.add(new LabelValueVO("AccountNumber", accountNum));
		list.add(new LabelValueVO("PhoneNumber", phoneNum));
		list.add(new LabelValueVO("Date", df.format(Calendar.getInstance().getTime())));
		list.add(new LabelValueVO("Origin", origin));
		list.add(new LabelValueVO("IPAddress", ipAddress));
		list.add(new LabelValueVO("TranName", tranName));
		return list;
	}
	
	public ArrayList<LabelValueVO> logCollectionPayment(String sessionId, String customerID, String payerBSB, String payerAccountNum, String amount, String origin, 
			String ipAddress, String requestID, String tranName, String canNum)
	{
		ArrayList<LabelValueVO> list = new ArrayList<LabelValueVO>();
		list.add(new LabelValueVO("SessionId", sessionId));
		list.add(new LabelValueVO("CAN", canNum));
		list.add(new LabelValueVO("GCISNumber", customerID));
		list.add(new LabelValueVO("PayerBSB", payerBSB));
		list.add(new LabelValueVO("PayerAccountNumber", payerAccountNum));
		list.add(new LabelValueVO("PaymentValue", amount));
		list.add(new LabelValueVO("Date", df.format(Calendar.getInstance().getTime())));
		list.add(new LabelValueVO("Origin", origin));
		list.add(new LabelValueVO("IPAddress", ipAddress));
		list.add(new LabelValueVO("RequestID", requestID));
		list.add(new LabelValueVO("TranName", tranName));
		return list;
	}
	
}
