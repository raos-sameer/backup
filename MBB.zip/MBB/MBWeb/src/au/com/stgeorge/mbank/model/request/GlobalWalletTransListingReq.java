package au.com.stgeorge.mbank.model.request;

import javax.validation.constraints.NotNull;

import au.com.stgeorge.ibank.businessobject.BusinessException;
import au.com.stgeorge.mbank.model.common.IMBReq;
import au.com.stgeorge.mbank.model.common.ReqHeader;

public class GlobalWalletTransListingReq implements IMBReq {
	
	private static final long serialVersionUID = -2075600760077230340L;

	@NotNull(message = "" + BusinessException.WSVC_INVALID_INPUT_PARAM)
	private Integer accountIndex;
	private String transactionPeriod;
	private Integer postedTransactionStartIndex;
	private ReqHeader header;
	
	@Override
	public ReqHeader getHeader() {
		return this.header;
	}

	@Override
	public void setHeader(ReqHeader header) {
		this.header = header;
	}
	
	public Integer getAccountIndex() {
		return accountIndex;
	}

	public void setAccountIndex(Integer accountIndex) {
		this.accountIndex = accountIndex;
	}

	public String getTransactionPeriod() {
		return transactionPeriod;
	}

	public void setTransactionPeriod(String transactionPeriod) {
		this.transactionPeriod = transactionPeriod;
	}	
	public Integer getPostedTransactionStartIndex() {
		return postedTransactionStartIndex;
	}

	public void setPostedTransactionStartIndex(Integer postedTransactionStartIndex) {
		this.postedTransactionStartIndex = postedTransactionStartIndex;
	}	
}
