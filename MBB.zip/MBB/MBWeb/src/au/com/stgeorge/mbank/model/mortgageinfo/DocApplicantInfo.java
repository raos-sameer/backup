package au.com.stgeorge.mbank.model.mortgageinfo;

import java.io.Serializable;
import java.util.List;

import javax.validation.Valid;
import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.Length;
import org.hibernate.validator.constraints.Range;

import au.com.stgeorge.ibank.businessobject.BusinessException;


import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_NULL)
public class DocApplicantInfo implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = -3511955740636187428L;
		
	private int applicantIndex;		
	
	private List<DocTypeDetailInfo> docTypeDetails;	
	
	private List<DocDetailInfo> otherDocuments;	
		

	public int getApplicantIndex() {
		return applicantIndex;
	}
	public void setApplicantIndex(int applicantIndex) {
		this.applicantIndex = applicantIndex;
	}

	
	public List<DocTypeDetailInfo> getDocTypeDetails() {
		return docTypeDetails;
	}
	public void setDocTypeDetails(List<DocTypeDetailInfo> docTypeDetails) {
		this.docTypeDetails = docTypeDetails;
	}


	public List<DocDetailInfo> getOtherDocuments() {
		return otherDocuments;
	}


	public void setOtherDocuments(List<DocDetailInfo> otherDocuments) {
		this.otherDocuments = otherDocuments;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
}
