package au.com.stgeorge.mbank.controller.statements;


import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.swing.plaf.basic.BasicInternalFrameTitlePane.MoveAction;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;

import au.com.stgeorge.framework.common.logging.Logger;
import au.com.stgeorge.framework.common.util.StringMethods;
import au.com.stgeorge.ibank.businessobject.BusinessException;
import au.com.stgeorge.ibank.businessobject.ResourceException;
import au.com.stgeorge.ibank.common.cache.IBankParams;
import au.com.stgeorge.ibank.messagecentre.valueobject.MessageSearch;
import au.com.stgeorge.ibank.valueobject.Account;
import au.com.stgeorge.ibank.valueobject.Customer;
import au.com.stgeorge.ibank.valueobject.Statistic;
import au.com.stgeorge.ibank.valueobject.transfer.IBankCommonData;
import au.com.stgeorge.mbank.controller.IMBController;
import au.com.stgeorge.mbank.controller.customer.LogonHelper;
import au.com.stgeorge.mbank.controller.onboarding.OnboardingHelper;
import au.com.stgeorge.mbank.model.common.IMBReq;
import au.com.stgeorge.mbank.model.common.IMBResp;
import au.com.stgeorge.mbank.model.common.ReqHeader;
import au.com.stgeorge.mbank.model.common.RespHeader;
import au.com.stgeorge.mbank.model.request.ManageEStmtDetailReq;
import au.com.stgeorge.mbank.model.request.customer.SavingsOnboardingReq;
import au.com.stgeorge.mbank.model.request.services.OnboardAccountsReq;
import au.com.stgeorge.mbank.model.request.statements.ManageEStmtReq;
import au.com.stgeorge.mbank.model.response.ErrorResp;
import au.com.stgeorge.mbank.model.response.SuccessResp;
import au.com.stgeorge.mbank.model.response.statements.ManageEStmtAcctReceiptListResp;
import au.com.stgeorge.mbank.session.MobileSession;
import au.com.stgeorge.mbank.util.FraudLogger;
import au.com.stgeorge.mbank.util.MBAppHelper;
import au.com.stgeorge.mbank.util.MBAppUtils;
import au.com.stgeorge.mbank.util.MBAppValidator;
import au.com.stgeorge.mbank.util.ServiceConstants;
import au.com.stgeorge.mobilebank.businessobject.EStatementsService;
import au.com.stgeorge.perflogger.PerformanceLogger;

import com.fasterxml.jackson.databind.ObjectMapper;

@Controller
@RequestMapping("/manageEStmt")

public class ManageEStmtController implements IMBController {
private FraudLogger fraudLogger;
	
	@Autowired
	private EStatementsService mobileEStatementService;

	@Autowired
	private ManageEStmtHelper manageStmtHelper;

	@Autowired
	private MBAppHelper mbAppHelper;
			
	@Autowired
	private PerformanceLogger perfLogger;
	
	@Autowired
	private MBAppValidator mbAppValidator;

	
	@RequestMapping(value ="acctlist", method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public IMBResp processAcctList(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse,
			@RequestBody final OnboardAccountsReq req)
	{								
		ObjectMapper objectMapper = new ObjectMapper();									
		perfLogger.startAllLogs();
		String logName = MBAppUtils.getLogName(httpServletRequest);
		perfLogger.startLog(logName);
		MobileSession mbSession = null;
		IMBResp serviceResponse = null;
		String serviceName = null;
		try{	
			
			mbSession = mbAppHelper.getMobileSession(httpServletRequest);
			Logger.info("Manage EStmt account list JSON Request :" + objectMapper.writeValueAsString(req), this.getClass());
			validateRequestHeader(req.getHeader(), httpServletRequest);
			ErrorResp errorResp = validate(req, httpServletRequest);
			if (errorResp != null && errorResp.getErrors() != null && errorResp.getErrors().size() > 0)
			{				
				return errorResp;
			}
																		
			Customer customer=mbSession.getCustomer();			
			IBankCommonData commonData=mbAppHelper.populateIBankCommonData(mbSession,httpServletRequest);								
			serviceResponse = manageStmtHelper.populateManageStmtAcctListResp(commonData,customer);
			
			RespHeader headerResp = populateResponseHeader(serviceName, mbSession);
			serviceResponse.setHeader(headerResp);
			
			Logger.info("Manage EStmt account list JSON Response :" + objectMapper.writeValueAsString(serviceResponse), this.getClass());
			
			statisticsLogOnboarding(req.getApplication(), Statistic.ONBOARDING_ESTMT_ACCOUNTS, commonData);
			if (req.isSourceSecurityWellBeingCheck() && mbSession.getSWBInfoMsg() == null ) {
				mbSession.setSWBInfoMsg(Boolean.TRUE);
			}
			else {
				mbSession.removeSWBInfoMsg();
			}
			return serviceResponse;		
		}catch (BusinessException e)
		{
			Logger.info("BusinessException Inside processAcctList() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			BusinessException exp = new BusinessException(e.getKey());
			IMBResp resp1  = null;
			if(e.getKey() == BusinessException.STOP_STMT_ACCT_ELIGIBLE_COUNT)
				resp1 = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, ServiceConstants.MANAGE_STMT_SERVICE, ErrorResp.STATUS_INFO, httpServletRequest);
			else
				resp1  = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, ServiceConstants.MANAGE_STMT_SERVICE, httpServletRequest);
			return resp1;
						
		} catch (ResourceException e) {
			Logger.error("ResourceException Inside processAcctList() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			ResourceException exp = new ResourceException(e.getKey());
			IMBResp resp1  = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, serviceName, httpServletRequest);
			return resp1;
		}catch (Exception e)
		{
			Logger.error("Exception Inside processAcctList() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			BusinessException exp = new BusinessException(BusinessException.GENERIC_ERROR);
			IMBResp resp1  = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, serviceName, httpServletRequest);
			return resp1;
		} finally
		{
			perfLogger.endLog(logName);
			perfLogger.endAllLogs();
		}				
	}
	
	@RequestMapping(value ="switchPreference", method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public IMBResp processSwitchPreferenceEStmt(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse,
			@RequestBody final ManageEStmtReq req)
	{								
		ObjectMapper objectMapper = new ObjectMapper();									
		perfLogger.startAllLogs();
		String logName = MBAppUtils.getLogName(httpServletRequest);
		perfLogger.startLog(logName);
		MobileSession mbSession = null;
		List<Account> processedAcctList = null;
		String serviceName = null;
		boolean errExists = false;
		fraudLogger = new FraudLogger(); 
		IBankCommonData commonData = null;
		String switchedAccounts_p=null;
		int switchedAccountsPSize = 0;
		String switchedAccounts_e=null;
		int switchedAccountsESize = 0;
		String E_STATUS = "E";
		String S_STATUS = "S";
		String SWITCH_STATEMENTS_FAIL = "estmt unavailable";
		String SWITCH_STATEMENTS_SUCCESS = "success"; 
		String CHANGE_ESTATEMENT_PREFERENCE = "ChangeEStatementPreference";
		String ACTION_SWITCHE="Paper Stmt Suppress";
		String ACTION_SWITCHP="Paper Stmt Unsupress";
		String ACTION_FAIL="Paper Stmt Suppress / Paper Stmt Unsupress"; 
		try{	
			
			mbSession = mbAppHelper.getMobileSession(httpServletRequest);
			Logger.info("processSwitchPreferenceEStmt JSON Request :" + objectMapper.writeValueAsString(req), this.getClass());
			validateRequestHeader(req.getHeader(), httpServletRequest);
			ErrorResp errorResp = validate(req, httpServletRequest);
			if (errorResp != null && errorResp.getErrors() != null && errorResp.getErrors().size() > 0)
			{				
				return errorResp;
			}
			
			Customer customer=mbSession.getCustomer();			
			commonData=mbAppHelper.populateIBankCommonData(mbSession,httpServletRequest);
			
			String application = req.getApplication();
			//19E4 - Estmt splash page MB (when user has clicked done but toggled to not switch any accounts to estmt)
			if(!StringMethods.isEmptyString(application) &&
					application.equalsIgnoreCase(ManageEStmtHelper.ESTMT_SPLASH) &&
					req.getAccountList().size() == 0){
				Logger.info("Estmt Request with account list 0", this.getClass());
			    MessageSearch messageSearch = mbSession.getSplashInfoMsg();
			    if(null!=messageSearch){
			    	mobileEStatementService.deleteMessage(messageSearch, commonData);
			    }
			    if(req.isEstmtSplashPageSkipped()){
			    	mobileEStatementService.addStatisticsLog(commonData, null, Statistic.ESTMT_SPLASH_SWITCHED, ManageEStmtHelper.ESTMT_SPLASH_SKIPPED_DONE_DESC);
			    }else{
			    	mobileEStatementService.addStatisticsLog(commonData, null, Statistic.ESTMT_SPLASH_SWITCHED, ManageEStmtHelper.ESTMT_SPLASH_DONE_DESC);
			    }
				IMBResp serviceResponse = new ManageEStmtAcctReceiptListResp();
				RespHeader headerResp = populateResponseHeader(serviceName, mbSession);
				serviceResponse.setHeader(headerResp);
				
				return serviceResponse;	
			}
			
			if(req.getAccountList().size() == 0)
				throw new BusinessException(BusinessException.WSVC_INVALID_INPUT_PARAM);
									
			ArrayList<Account> selectedAcctList = null;
			Account acct = null;
			if(req.getAccountList() != null && req.getAccountList().size() > 0){
				selectedAcctList = new ArrayList<Account>();
				for(ManageEStmtDetailReq manageEStmtDetailReq : req.getAccountList()){

					acct = new Account();
					acct.setIndex(manageEStmtDetailReq.getAccountIndex());
					acct.setEstmtAcctStatus(manageEStmtDetailReq.getEstmtAcctStatus());
					selectedAcctList.add(acct);	

				}
			}
			if(selectedAcctList.size() == 0)
				throw new BusinessException(BusinessException.NO_INFORMATION);
			
			//17E2 Service Interaction and Cross Sell -- Updating the GDW description if originated from Transaction Cross Sell
			//String application = req.getApplication();
			
			//19E4 - Estmt splash page MB (when user has selected any accounts to switch preference
			if(!StringMethods.isEmptyString(application) && application.equalsIgnoreCase(ManageEStmtHelper.ESTMT_SPLASH)){
				Logger.info("Estmt Request for Splash page done (non 0 account list) ", this.getClass());
				MessageSearch messageSearch = mbSession.getSplashInfoMsg();
			    if(null!=messageSearch){
			    	mobileEStatementService.deleteMessage(messageSearch, commonData);
			    }
			    List<Account> selectedAccounts = new ArrayList<>();
			    for(Account selAccount : selectedAcctList)
			    {
				 Account selAcct = mbAppHelper.getAccountFromCustomer(customer, selAccount.getIndex());
				 if(null != selAcct)
				     selectedAccounts.add(selAcct);
			    }
			    if(req.isEstmtSplashPageSkipped()){
			    	mobileEStatementService.addStatisticsLog(commonData, selectedAccounts, Statistic.ESTMT_SPLASH_SWITCHED, ManageEStmtHelper.ESTMT_SPLASH_SKIPPED_DONE_DESC);
			    }else{
			    	mobileEStatementService.addStatisticsLog(commonData, selectedAccounts, Statistic.ESTMT_SPLASH_SWITCHED, ManageEStmtHelper.ESTMT_SPLASH_DONE_DESC);
			    }
			}
			if(req.getFromCrossSell()){
				application = IBankParams.TNX_CROSSSELL;
			}

			if (mbSession.getSWBInfoMsg() != null && Boolean.TRUE.equals(mbSession.getSWBInfoMsg()) ) {
				application = application + ServiceConstants.SOURCE_SECURITY_WELLBEING;
				mbSession.removeSWBInfoMsg();
			}
			processedAcctList = (List<Account>) mobileEStatementService.switchStmtPreference(commonData, selectedAcctList, customer, application);
			
			IMBResp serviceResponse = manageStmtHelper.populateResp(commonData,processedAcctList);
									
			RespHeader headerResp = populateResponseHeader(serviceName, mbSession);
			serviceResponse.setHeader(headerResp);
			
			Logger.info("processSwitchPreferenceEStmt JSON Response :" + objectMapper.writeValueAsString(serviceResponse), this.getClass());
			
			return serviceResponse;		
		}catch (BusinessException e)
		{	
			errExists = true;
			Logger.info("BusinessException Inside processSwitchPreferenceEStmt() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			BusinessException exp = new BusinessException(e.getKey());
			IMBResp resp1  = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, serviceName, httpServletRequest);
			return resp1;
		} catch (ResourceException e) {
			errExists = true;
			Logger.error("ResourceException Inside processSwitchPreferenceEStmt() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			ResourceException exp = new ResourceException(ResourceException.SYSTEM_ERROR);
			IMBResp resp1  = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, serviceName, httpServletRequest);
			return resp1;
		}catch (Exception e)
		{	errExists = true;
			Logger.error("Exception Inside processSwitchPreferenceEStmt() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			BusinessException exp = new BusinessException(BusinessException.GENERIC_ERROR);
			IMBResp resp1  = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, serviceName, httpServletRequest);
			return resp1;
		} finally
		{
			switchedAccounts_p = manageStmtHelper.getFraudLogEntryStr(processedAcctList, E_STATUS);//E
			switchedAccounts_e = manageStmtHelper.getFraudLogEntryStr(processedAcctList, S_STATUS);//S
			switchedAccountsPSize = manageStmtHelper.findSwitchedPrefListSize(processedAcctList, E_STATUS);//Switched to P
			switchedAccountsESize = manageStmtHelper.findSwitchedPrefListSize(processedAcctList, S_STATUS);//Switched to E

			if(errExists){
				fraudLogger.logSwitchStatementPreferences(mbSession.getSessionID(),commonData.getUser().getUserId(),commonData.getUser().getGCISNumber() ,mbSession.getOrigin(), commonData.getIpAddress(), CHANGE_ESTATEMENT_PREFERENCE,ACTION_FAIL,null, commonData.getUserAgent(), SWITCH_STATEMENTS_FAIL);
			}else{

				if(switchedAccountsESize > 0)
				{
					fraudLogger.logSwitchStatementPreferences(mbSession.getSessionID(), commonData.getUser().getUserId(), commonData.getUser().getGCISNumber(), commonData.getOrigin(), commonData.getIpAddress(),CHANGE_ESTATEMENT_PREFERENCE,ACTION_SWITCHE,switchedAccounts_e,commonData.getUserAgent(),SWITCH_STATEMENTS_SUCCESS); 
				}

				if(switchedAccountsPSize > 0)
				{
					fraudLogger.logSwitchStatementPreferences(mbSession.getSessionID(), commonData.getUser().getUserId(), commonData.getUser().getGCISNumber(), mbSession.getOrigin(), commonData.getIpAddress(),CHANGE_ESTATEMENT_PREFERENCE,ACTION_SWITCHP,switchedAccounts_p,commonData.getUserAgent(), SWITCH_STATEMENTS_SUCCESS); 
				}	
			}
			
			perfLogger.endLog(logName);
			perfLogger.endAllLogs();
		}				
	}
	
	@RequestMapping(value="skipSplash", method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public IMBResp skipEstatementSplash(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, @RequestBody final ManageEStmtReq req) {
		Logger.info("Inside skipEstatementSplash :" , this.getClass());
		String logName = startPerformanceLog(httpServletRequest);
		MobileSession mbSession = null;
		IBankCommonData commonData = null;
		ObjectMapper mapper = new ObjectMapper();
		String gcisNumber = null;
		try {
			mbSession = mbAppHelper.getMobileSession(httpServletRequest);
			commonData = new MBAppHelper().populateIBankCommonData(mbSession, httpServletRequest);
			gcisNumber = commonData.getCustomer().getGcis();
	
			validateRequestHeader(req.getHeader(), httpServletRequest);
			Logger.info("skipEstatementSplash JSON Request :" + mapper.writeValueAsString(req), this.getClass());
			MessageSearch messageSearch = mbSession.getSplashInfoMsg();
			if (null != messageSearch) {				
			    mobileEStatementService.updateSkipCounter(messageSearch, commonData);
			    mobileEStatementService.addStatisticsLog(commonData, null, Statistic.ESTMT_SPLASH_PRESENTED, ManageEStmtHelper.ESTMT_SPLASH_SKIPPED_DESC);
			}
		}
		catch (Exception e) {	
			Logger.error("skipEstatementSplash failed with Exception for customer " + gcisNumber  + e.getMessage(), this.getClass() );
		} finally {
		    endPerformanceLog(logName);
		}
		
		SuccessResp successResp = new SuccessResp();																			
		RespHeader headerResp = populateResponseHeader(req.getHeader().getServiceName(), mbSession);
		successResp.setHeader(headerResp);
		successResp.setIsSuccess(true);
		mbSession.setLoggedonState(LogonHelper.LOGGEDON_STATE_COMPLETE);
		return successResp;
	}
	private String startPerformanceLog(HttpServletRequest httpRequest) {
		perfLogger.startAllLogs();
		String logName = MBAppUtils.getLogName(httpRequest);
		perfLogger.startLog(logName);
		return logName;
	}
	private void endPerformanceLog(String logName) {
		perfLogger.endLog(logName);
		perfLogger.endAllLogs();
	}
	
	private void statisticsLogOnboarding(String application,String action,IBankCommonData commonData) {
		if(!StringMethods.isEmptyString(application) && ManageEStmtHelper.APPLICATION_ONBOARDING.equalsIgnoreCase(application)) {
			OnboardingHelper.addStatisticsLog(commonData,action,ManageEStmtHelper.GDW_DESC_ONBOARDING);	
		}
	}
	public ErrorResp validate(IMBReq serviceRequest, HttpServletRequest request) {
		return mbAppValidator.validate(serviceRequest, request);
	}

	public RespHeader populateResponseHeader(String serviceName) {
		return new MBAppHelper().populateResponseHeader(serviceName);
	}

	public void validateRequestHeader(ReqHeader headerReq, HttpServletRequest request) throws BusinessException {		
		 mbAppValidator.validateRequestHeader(headerReq, request);
	}

	public RespHeader populateResponseHeader(String serviceName, MobileSession mobSession )
	{
		return mbAppHelper.populateResponseHeader(serviceName, mobSession);
	}

	/**
	 * Response for invalid body request
	 * 
	 * @return
	 */
	@ExceptionHandler( { org.springframework.http.converter.HttpMessageNotReadableException.class })
	@ResponseStatus(org.springframework.http.HttpStatus.OK)
	@ResponseBody
	public IMBResp resolveException() {
		return MBAppUtils.createInvalidMessageBodyResponse(ServiceConstants.MANAGE_STMT_SERVICE);
		
	}
	
}
