package au.com.stgeorge.mbank.controller.statements;

import java.io.File;
import java.io.FileInputStream;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;
import java.util.UUID;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import au.com.stgeorge.framework.common.logging.Logger;
import au.com.stgeorge.framework.common.model.User;
import au.com.stgeorge.ibank.businessobject.BusinessException;
import au.com.stgeorge.ibank.businessobject.CardDisputeService;
import au.com.stgeorge.ibank.businessobject.ResourceException;
import au.com.stgeorge.ibank.common.cache.IBankParams;
import au.com.stgeorge.ibank.messagecentre.valueobject.TokenDetails;
import au.com.stgeorge.ibank.valueobject.transfer.IBankCommonData;
import au.com.stgeorge.ibank.valueobject.wdp.DocumentTokenData;
import au.com.stgeorge.mbank.session.GenericSessionFactory;
import au.com.stgeorge.mbank.session.IGenericSession;
import au.com.stgeorge.mbank.session.MobileSession;
import au.com.stgeorge.mbank.util.MBAppConstants;
import au.com.stgeorge.mbank.util.MBAppHelper;
import au.com.stgeorge.mbank.util.MBAppUtils;
import au.com.stgeorge.perflogger.PerformanceLogger;

@Controller
public class NGINXDocumentController {

  @Autowired
  private MBAppHelper mbAppHelper;

  @Autowired
  private PerformanceLogger perfLogger;

  @Autowired
  private CardDisputeService cardDisputeService;

  ResponseEntity<byte[]> responseEntity = null;

  @RequestMapping(value = "/fetchDocument", method = RequestMethod.GET)
  public ResponseEntity<byte[]> documentTokenGenerator(HttpServletRequest request,
      HttpServletResponse response) throws Exception {

    TokenDetails tokenDetails = new TokenDetails();
    Integer errorCode = null;
    boolean sessionValidated = false;
    boolean userValidated = false;
    perfLogger.startAllLogs();
    String logName = MBAppUtils.getLogName(request);
    perfLogger.startLog(logName);
    MobileSession mbSession = null;
    HttpHeaders httpheaders=null;

    try {
      String pdfToken = request.getParameter("token");
      tokenDetails = cardDisputeService.getTokenDetailsFromDB(pdfToken);
      if (tokenDetails != null) {
        String sessionIdForToken = tokenDetails.getSessionId();
        IGenericSession gSession = GenericSessionFactory.getInstance(sessionIdForToken);
        Cookie cookie = getCookie(request);
        User tempUser = gSession.getUser();
        String docRepoId = tokenDetails.getStmtId(); // This is the Doc:repoId
        String[] output = docRepoId.split(":");
        Logger.info("Document ID for NGINX : " + output[0], this.getClass());
        Logger.info("Repository ID for NGINX : " + output[1], this.getClass());
        if (tempUser != null
            && tempUser.getGCISNumber().equalsIgnoreCase(tokenDetails.getGcisNumber()))
          userValidated = true;
        if (cookie != null) {
          if (sessionIdForToken.equals(cookie.getValue()))
            if (userValidated)
              sessionValidated = true;
        } else if (userValidated)
          sessionValidated = true;
        if (sessionValidated) {
          User user =
              new User(tokenDetails.getGcisNumber(), IBankParams.BLANK_STRING,
                  IBankParams.BLANK_STRING, null, false, true, false);
          IBankCommonData commonData = new IBankCommonData();
          commonData.setUser(user);
          commonData.setOrigin(mbAppHelper.getOrigin(request));
          commonData.setIpAddress(MBAppHelper.resolveIPAddress(request,
              mbAppHelper.getOrigin(request)));
          commonData.setSessionId(sessionIdForToken);
          commonData.setGdwOrigin(tokenDetails.getOriginBank());

          /*
           * String pdfDoc = ""; byte[] stmtBytes = null;
           * 
           * ClassLoader classLoader = getClass().getClassLoader();
           * 
           * File file = new
           * File(classLoader.getResource("/WEB-INF/MultiPgVoucherTIFF.tiff").getFile());
           * 
           * FileInputStream fis = new FileInputStream(new
           * File(classLoader.getResource("/WEB-INF/MultiPgVoucherTIFF.tiff").getFile()));
           * FileChannel channel = fis.getChannel(); ByteBuffer buffer =
           * ByteBuffer.allocate((int)channel.size()); channel.read(buffer);
           * 
           * byte[] imageInByte = buffer.array();
           */

          UUID appCorrelationID = UUID.randomUUID();
          String documentId = output[0].trim();
          String repositoryId = output[1].trim();
          DocumentTokenData documentTokenData =
              cardDisputeService.documentTokenGenerator(documentId, repositoryId, appCorrelationID,
                  commonData);
          Logger.info("Document Token : " + documentTokenData.getDocumentTransferToken(),
              this.getClass());
          Logger.info("Document ProxyURL : " + documentTokenData.getDocumentTransferProxyURL(),
              this.getClass());
          responseEntity =
              cardDisputeService.getNGINXDocument(documentTokenData.getDocumentTransferProxyURL(),
                  documentTokenData.getDocumentTransferToken());
          Logger.info("Response Entity Body : " + responseEntity.getBody(), this.getClass());
          Logger.info("Response Entity Content type : "
              + responseEntity.getHeaders().getContentType(), this.getClass());
          Logger.info("Response Entity Status : " + responseEntity.getStatusCodeValue(),
              this.getClass());
          byte[] docByte= responseEntity.getBody();
         /* httpheaders=new HttpHeaders();
          httpheaders.setContentType(responseEntity.getHeaders().getContentType());
          httpheaders.add("content-disposition", "attachment;filename=" + appCorrelationID+"Statement.pdf");
         */
        //  httpheaders.setContentDispositionFormData("inline",  documentTokenData.getDocumentTransferToken()+"Statement.pdf");
    
          Logger.info("ResponseCodeINTERNAL_SERVER_ERROR: " + HttpStatus.INTERNAL_SERVER_ERROR.value(),
              this.getClass());
         
          if (responseEntity.getStatusCodeValue() == HttpStatus.INTERNAL_SERVER_ERROR.value()) {
            try {
              byte[] imageInByte = new byte[8192];

              ClassLoader classLoader = getClass().getClassLoader();
              FileInputStream fis =
                  new FileInputStream(new File(classLoader.getResource(
                      "/WEB-INF/pdf/" + mbAppHelper.getOrigin(request) + "/NoStatement.pdf")
                      .getFile()));
              FileChannel channel = fis.getChannel();
              ByteBuffer buffer = ByteBuffer.allocate((int) channel.size());
              channel.read(buffer);

              imageInByte = buffer.array();

            /*  httpheaders=new HttpHeaders();
              httpheaders.setContentType( MediaType.APPLICATION_PDF);
              httpheaders.setContentDispositionFormData("attachment", "NoStatement.pdf");*/
              response.setContentType("application/pdf");
              response.setHeader("content-disposition", "attachment;filename=Statement.pdf");
              java.io.OutputStream os = response.getOutputStream();
              os.write(docByte, 0, docByte.length);
              os.flush();
              os.close();
              responseEntity = new ResponseEntity<byte[]>(HttpStatus.OK);
              return responseEntity;
            } catch (Exception e) {
              errorCode = HttpStatus.INTERNAL_SERVER_ERROR.value();
              Logger.error("viewPdf stmt error ", this.getClass());
            }

          }
          response.setContentType("application/pdf");
          response.setHeader("content-disposition", "attachment;filename=Statement.pdf");
          java.io.OutputStream os = response.getOutputStream();
          os.write(docByte, 0, docByte.length);
          os.flush();
          os.close();
          responseEntity = new ResponseEntity<byte[]>(HttpStatus.OK);
          return responseEntity;

        } else {
          Logger.info("Requested PDF token is expired...", this.getClass());
          throw new BusinessException(BusinessException.SESSION_EXPIRED);
        }
      } else {
        Logger.info("pdfStatement service is unavailable...", this.getClass());
        throw new BusinessException(BusinessException.WDP_TOKEN_SERVICE_UNAVILABLE);
      }

    } catch (BusinessException be) {
      if (be.getKey() == BusinessException.PDF_STATEMENT_NOT_FOUND) {

        try {
          byte[] imageInByte = new byte[8192];

          ClassLoader classLoader = getClass().getClassLoader();
          FileInputStream fis =
              new FileInputStream(new File(classLoader.getResource(
                  "/WEB-INF/pdf/" + mbAppHelper.getOrigin(request) + "/NoStatement.pdf").getFile()));
          FileChannel channel = fis.getChannel();
          ByteBuffer buffer = ByteBuffer.allocate((int) channel.size());
          channel.read(buffer);

          imageInByte = buffer.array();

          /*httpheaders=new HttpHeaders();
          httpheaders.setContentType(MediaType.APPLICATION_PDF);
          httpheaders.setContentDispositionFormData("attachment", "NoStatement.pdf");*/
          response.setContentType("application/pdf");
          response.setHeader("content-disposition", "attachment;filename=Statement.pdf");
          java.io.OutputStream os = response.getOutputStream();
          os.write(imageInByte, 0, imageInByte.length);
          os.flush();
          os.close();
          responseEntity = new ResponseEntity<byte[]>(HttpStatus.OK);
          return responseEntity;
        } catch (Exception e) {
          e.printStackTrace();
          errorCode = be.getKey();
          Logger.error("viewPdf stmt error ", this.getClass());
        }

      } else {
        Logger.info("Error code...."+errorCode, this.getClass());
        errorCode = be.getKey();
      }
    } catch (ResourceException re) {
      re.printStackTrace();
      errorCode = re.getKey();
      Logger.info("Error code...."+errorCode, this.getClass());
    } catch (Exception ex) {
      ex.printStackTrace();
      errorCode = BusinessException.GENERIC_ERROR;
      Logger.info("Error code...."+errorCode, this.getClass());
    } finally {
      perfLogger.endLog(logName);
      perfLogger.endAllLogs();
    }

    if (errorCode != null) {
      
      Logger.info("Error code...."+errorCode, this.getClass());
      request.setAttribute("errorCode", errorCode);
      request.setAttribute(MBAppHelper.HTTP_ORIGIN_ATTRIBUTE, mbAppHelper.getOrigin(request));
      request.getRequestDispatcher("/jsp/error/serviceError.jsp").forward(request, response);
    }

    return null;

  }



  private Cookie getCookie(HttpServletRequest request) throws ResourceException {
    try {
      Cookie[] cookies = request.getCookies();
      Cookie cookie = null;
      if (cookies != null) {
        for (int i = 0; i < cookies.length; i++) {
          if (cookies[i].getName().equals(MBAppConstants.SMPL_SESS_CONSTANT)) {
            cookie = cookies[i];
            Logger.info(
                "Cookie " + cookie.getName() + " found in the request. Value : "
                    + cookie.getValue(), this.getClass());
            break;
          }
        }
      }
      return cookie;
    } catch (Exception e) {
      e.printStackTrace();
      return null;
    }
  }

}
