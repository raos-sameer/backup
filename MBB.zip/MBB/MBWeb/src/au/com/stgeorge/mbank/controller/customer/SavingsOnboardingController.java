package au.com.stgeorge.mbank.controller.customer;

import static au.com.stgeorge.ibank.businessobject.acctsvc.AccountService.DDA_ACCT_OPEN_SERVICE;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import au.com.stgeorge.debitcard.service.impl.DebitCardServiceImpl;
import au.com.stgeorge.digitalsec.logger.DigitalSecLogger;
import au.com.stgeorge.framework.common.exception.ResourceException;
import au.com.stgeorge.framework.common.logging.Logger;
import au.com.stgeorge.framework.common.util.StringMethods;
import au.com.stgeorge.ibank.businessobject.BusinessException;
import au.com.stgeorge.ibank.businessobject.GCCService;
import au.com.stgeorge.ibank.businessobject.acctopenservice.AccountOpeningService;
import au.com.stgeorge.ibank.messagecentre.util.MessageCentreConstants;
import au.com.stgeorge.ibank.messagecentre.valueobject.MessageSearch;
import au.com.stgeorge.ibank.servicestation.businessobject.ServiceStation;
import au.com.stgeorge.ibank.util.DateUtils;
import au.com.stgeorge.ibank.util.ServiceHelper;
import au.com.stgeorge.ibank.util.StringUtil;
import au.com.stgeorge.ibank.valueobject.Account;
import au.com.stgeorge.ibank.valueobject.AccountId;
import au.com.stgeorge.ibank.valueobject.Statistic;
import au.com.stgeorge.ibank.valueobject.database.AcctOpeningVO;
import au.com.stgeorge.ibank.valueobject.transfer.IBankCommonData;
import au.com.stgeorge.mbank.controller.IMBController;
import au.com.stgeorge.mbank.controller.newaccount.OpenDDAHelper;
import au.com.stgeorge.mbank.controller.payments.AccountTransferHelper;
import au.com.stgeorge.mbank.controller.services.TFNHelper;
import au.com.stgeorge.mbank.model.common.IMBReq;
import au.com.stgeorge.mbank.model.common.IMBResp;
import au.com.stgeorge.mbank.model.common.OpenAcctDetail;
import au.com.stgeorge.mbank.model.common.ReqHeader;
import au.com.stgeorge.mbank.model.common.RespHeader;
import au.com.stgeorge.mbank.model.request.customer.ConfirmSavingsOnboardingReq;
import au.com.stgeorge.mbank.model.request.customer.DDAHeartBeatReq;
import au.com.stgeorge.mbank.model.request.customer.SavingsOnboardingReq;
import au.com.stgeorge.mbank.model.request.newaccount.OpenDDAAcctReq;
import au.com.stgeorge.mbank.model.request.payments.AcctTransferReq;
import au.com.stgeorge.mbank.model.response.ErrorResp;
import au.com.stgeorge.mbank.model.response.SuccessResp;
import au.com.stgeorge.mbank.model.response.customer.ConfirmSavingsOnboardingResp;
import au.com.stgeorge.mbank.model.response.customer.ListFromAcctSavingsOnboardingResp;
import au.com.stgeorge.mbank.model.response.newaccount.OpenDDAAcctResp;
import au.com.stgeorge.mbank.model.response.payments.TransferResp;
import au.com.stgeorge.mbank.session.MobileSession;
import au.com.stgeorge.mbank.util.MBAppConstants;
import au.com.stgeorge.mbank.util.MBAppHelper;
import au.com.stgeorge.mbank.util.MBAppUtils;
import au.com.stgeorge.mbank.util.MBAppValidator;
import au.com.stgeorge.mbank.util.ServiceConstants;
import au.com.stgeorge.mobilebank.businessobject.OpenDDAService;
import au.com.stgeorge.mobilebank.businessobject.SavingsOnboardingService;
import au.com.stgeorge.mobilebank.businessobject.SavingsOnboardingService.SavingsOnboardindDescEnum;
import au.com.stgeorge.mobilebank.businessobject.TransactService;
import au.com.stgeorge.perflogger.PerformanceLogger;

import com.fasterxml.jackson.databind.ObjectMapper;



@Controller
@RequestMapping("/savingsonboarding")
public class SavingsOnboardingController implements IMBController {

	@Autowired
	private MBAppValidator mbAppValidator;
	
	@Autowired
    private PerformanceLogger perfLogger;
	
	@Autowired
	private MBAppHelper mbAppHelper;
		
	@Autowired
    private SavingsOnboardingService savingsOnboardingService;
	
	@Autowired
	private OpenDDAHelper openDDAHelper;
	
	@Autowired
	private AccountTransferHelper accountTransferHelper;
		
	@Autowired
	private LogonHelper logonHelper;
	
	@Autowired
	private OpenDDAService openDDAService;
	
	@Autowired
    private DigitalSecLogger digitalSecLogger;
    
	@Autowired
	private ServiceStation serviceStationService;
	
	@Autowired
	private TransactService transactService;

	@Autowired
	private GCCService gccService;
	
	@Autowired
	private DebitCardServiceImpl debitCardService;
	
	//19E3 code
	@Autowired
	private TFNHelper tfnHelper;	
	
	private static final String BSA = "BSA";
	private static final String INCENTIVE_SAVER = "INCENTIVE_SAVER";
		
	@RequestMapping(value="skipSavingsOnboarding", method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public IMBResp skipSavingsOnboarding(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, @RequestBody final SavingsOnboardingReq req) {
		Logger.info("Inside skipSavingsOnboarding :" , this.getClass());
		String logName = startPerformanceLog(httpServletRequest);
		MobileSession mbSession = null;
		IBankCommonData commonData = null;
		ObjectMapper mapper = new ObjectMapper();
		String gcisNumber = null;
		try {
			mbSession = mbAppHelper.getMobileSession(httpServletRequest);
			commonData = new MBAppHelper().populateIBankCommonData(mbSession, httpServletRequest);
			gcisNumber = commonData.getCustomer().getGcis();
	
			validateRequestHeader(req.getHeader(), httpServletRequest);
			Logger.info("skipSavingsOnboarding JSON Request :" + mapper.writeValueAsString(req), this.getClass());
			MessageSearch messageSearch = mbSession.getSplashInfoMsg();
			if (null != messageSearch) {
				boolean isExisting = MessageCentreConstants.SPLASH_ACTION_SAVINGS_ONBOARDING_EXISTING.equals(messageSearch.getMessageAction());
				savingsOnboardingService.updateSkipCounter(messageSearch, commonData, isExisting);
			}
		}
		catch (Exception e) {	
			Logger.error("skipSavingsOnboarding failed with Exception for customer " + gcisNumber  + e.getMessage(), this.getClass() );
		} finally {
		    endPerformanceLog(logName);
		}
		
		SuccessResp successResp = new SuccessResp();																			
		RespHeader headerResp = populateResponseHeader(req.getHeader().getServiceName(), mbSession);
		successResp.setHeader(headerResp);
		successResp.setIsSuccess(true);
		mbSession.setLoggedonState(LogonHelper.LOGGEDON_STATE_COMPLETE);
		return successResp;
	}

	@RequestMapping(value="confirmSavings", method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public IMBResp confirmSavingsOnboarding(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, @RequestBody final ConfirmSavingsOnboardingReq request) {
		Logger.info("Inside confirmSavingsOnboarding :" , this.getClass());
		String logName = startPerformanceLog(httpServletRequest);
		MobileSession mbSession = null;
		ObjectMapper mapper = new ObjectMapper();
		
		ConfirmSavingsOnboardingResp response = new ConfirmSavingsOnboardingResp();	
		
		try {
			Logger.info("confirmSavingsOnboarding JSON Request :" + mapper.writeValueAsString(request), this.getClass());
	    	mbSession = mbAppHelper.getMobileSession(httpServletRequest);			
	    	
	    	ErrorResp errorResp = validateRequest(httpServletRequest, request);
	    	if (errorResp != null) {
	    		return errorResp;
	    	}
	      
	    	IBankCommonData ibankCommonData = mbAppHelper.populateIBankCommonData(mbSession, httpServletRequest);
	    	openDDAHelper.validateAddress(mbSession.getCustomer());
	      
	    	//setting the end date to 2 years from the start date
			if (request.getScheduleDetail() != null && request.getScheduleDetail().getFirstPayDate() != null) {
				request.getScheduleDetail().setLastPayDate(calculateEndDate());
			}
						
	    	//validate request data
	    	validateSavingsOnboardingReq(request, mbSession);
	    	
	    	if (request.getExistingFlow() != null && request.getExistingFlow()) {
		    	return scheduleTransfer(mbSession, ibankCommonData, httpServletRequest, request, response);
	    	} else {
		    	AccountOpeningService accountOpeningService = (AccountOpeningService) ServiceHelper.getBean(DDA_ACCT_OPEN_SERVICE);
		    	OpenDDAAcctReq openAcctRequest = createNewOpenDDAAcctReq(request, mbSession, accountOpeningService);	  
		    	
				 //19E3 Changes
				//if switch is On and !tfnheld - then get values from req and do validation
				Boolean statUpdTfn=false;
				Boolean showTfn = mbSession.getShowTfn();
				Logger.debug("SavingsOnboardingController - confirmSavingsOnboarding - showTfnValue"+showTfn,this.getClass());
		    	
				if(showTfn!=null){	
						
					Logger.debug("SavingsOnboardingController - confirmSavingsOnboarding - showTfn : "+showTfn, this.getClass());
					
					//fetch the statUpdTfn value from session irrespective of showTfn flag				
					Logger.debug("SavingsOnboardingController - confirmSavingsOnboarding - mbSession.getStatUpdTfn : "+mbSession.getStatUpdTfn(), this.getClass());
					
					if (null != mbSession.getStatUpdTfn()){
						statUpdTfn = mbSession.getStatUpdTfn();
					}

				}
				
		    	return openNewAccountAndScheduleTransfer(mbSession, ibankCommonData, httpServletRequest, request, openAcctRequest, accountOpeningService, response, true, statUpdTfn);
	    	}
		} catch (BusinessException e) {
			Logger.error("Exception Inside confirmSavingsOnboarding() for Customer GCIS [" + ((mbSession != null && mbSession.getCustomer() != null) ? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			IMBResp errorResponse = null;
			if (e.getKey() == BusinessException.MAX_ACCT_OPENING_REQ) {
				errorResponse = MBAppUtils.createErrorResp(mbSession.getOrigin(), e, e.getValues(), MBAppConstants.SAVINGS_ONBOARDING_RESP_NAME, httpServletRequest);
			} else if (e.getKey() == BusinessException.GCC_ESB_TECH_ERROR) {
				IBankCommonData commonData = mbAppHelper.populateIBankCommonData(mbSession, httpServletRequest);
				String[] phoneNumbers = accountTransferHelper.getGCCPhoneNumber(commonData.getOrigin());
				return MBAppUtils.createErrorResp(mbSession.getOrigin(), e, phoneNumbers, ServiceConstants.ACCOUNT_TRANSFER_SERVICE, httpServletRequest);
			} else {
				errorResponse = MBAppUtils.createErrorResp(mbSession.getOrigin(), e, MBAppConstants.SAVINGS_ONBOARDING_RESP_NAME, httpServletRequest);
			}
		
			return errorResponse;
		} catch (Exception e) {
			Logger.error("Exception Inside confirmSavingsOnboarding() for Customer GCIS: [" + ((mbSession != null && mbSession.getCustomer() != null) ? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			BusinessException exp = new BusinessException(BusinessException.GENERIC_ERROR);
			return MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, MBAppConstants.SAVINGS_ONBOARDING_RESP_NAME, httpServletRequest);
		} finally {
			if (request.getSource() != null && SavingsOnboardindDescEnum.SPLASH_OPEN_ACCOUNT.toString().equals(request.getSource())) {
				mbSession.setLoggedonState(LogonHelper.LOGGEDON_STATE_COMPLETE);
			}
			
			endPerformanceLog(logName);
		}		
	}
	
	@RequestMapping(value="listFromAcct", method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public IMBResp listFromAccounts(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, @RequestBody final DDAHeartBeatReq request) {
		Logger.info("Inside listFromAccounts :" , this.getClass());
		String logName = startPerformanceLog(httpServletRequest);
		MobileSession mbSession = null;
		ObjectMapper mapper = new ObjectMapper();
		
		ListFromAcctSavingsOnboardingResp response = new ListFromAcctSavingsOnboardingResp();	
		List<Integer> fromAccountIndexesList = new ArrayList<>();
		boolean isDDAAvailable = true;
		
		try {
			ErrorResp errorResp = validateRequest(httpServletRequest, request);
	    	if (errorResp != null) {
	    		return errorResp;
	    	}
	    	
			Logger.info("listFromAccounts JSON Request :" + mapper.writeValueAsString(request), this.getClass());
	    	mbSession = mbAppHelper.getMobileSession(httpServletRequest);			
	    	
	    	isDDAAvailable = savingsOnboardingService.isDDAAvailable();
	    	
	    	if (isDDAAvailable) {
	    		IBankCommonData ibankCommonData = mbAppHelper.populateIBankCommonData(mbSession, httpServletRequest);
		    	List<Account> fromAccounts = savingsOnboardingService.getSavingsOnboardingFromAcounts(mbSession.getCustomer(), ibankCommonData.getOrigin());
		    	for (Account account : fromAccounts) {
		    		fromAccountIndexesList.add(account.getIndex());
				}
		    	
		    	response.setSavingsHabitFromAccts(fromAccountIndexesList);
	    	}
	    	
	    	RespHeader headerResp = populateResponseHeader(request.getHeader().getServiceName(), mbSession);
	    	response.setHeader(headerResp);
	    	response.setDdaAvailable(isDDAAvailable);
			return response;
		} catch (Exception e) {
			Logger.error("Exception Inside listFromAccounts() for Customer GCIS: [" + ((mbSession != null && mbSession.getCustomer() != null) ? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			BusinessException exp = new BusinessException(BusinessException.GENERIC_ERROR);
			return MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, MBAppConstants.SAVINGS_ONBOARDING_RESP_NAME, httpServletRequest);
		} finally {
			endPerformanceLog(logName);
		}
	}
		
	@Override
	public void validateRequestHeader(ReqHeader headerReq, HttpServletRequest request) throws BusinessException {
		mbAppValidator.validateRequestHeader(headerReq,  request);		
	}

	@Override
	public ErrorResp validate(IMBReq serviceRequest, HttpServletRequest httpRequest) throws BusinessException {
		return mbAppValidator.validate(serviceRequest, httpRequest);
	}

	@Override
	public RespHeader populateResponseHeader(String serviceName, MobileSession mobileSession) {
		return mbAppHelper.populateResponseHeader(serviceName,mobileSession);
	}
	
	private IMBResp scheduleTransfer(MobileSession mbSession, IBankCommonData ibankCommonData, HttpServletRequest httpServletRequest, ConfirmSavingsOnboardingReq request, ConfirmSavingsOnboardingResp response) throws BusinessException {
		Logger.info("Inside scheduleTransfer :" , this.getClass());
		
		Account fromAccount = getFromAccount(mbSession, request);
		Account toAccount = getToAccount(mbSession, request);
		
		IMBResp transferResponse = performScheduleTransfer(mbSession, ibankCommonData, httpServletRequest, request, Statistic.SAVINGS_ONBOARDING_SCHEDULE_TRANSFER, fromAccount, toAccount, response, SavingsOnboardindDescEnum.SPLASH_SCHEDULE_TRANSFER.getValue());
		// SBGEXP-5326 MRA 2019-01-18: Prudential Limit error handling -> The transfer method throws an ErrorResponse. So, return as it is.
		if(transferResponse != null && transferResponse instanceof ErrorResp){
			ErrorResp errorResponse = (ErrorResp) transferResponse;
			int errorKey = Integer.parseInt(errorResponse.getErrors().get(0).getCode());
			if (errorKey == BusinessException.SCHEDULED_PAYMENT_EXCEED_PRUDENTIAL_LIMITS) {
				BusinessException ex = new BusinessException(BusinessException.SHO_SCHEDULED_PAYMENT_EXCEED_PRUDENTIAL_LIMITS_EXISTING_ACCT);
				throw ex;
			}
			return transferResponse;
		}
		
		RespHeader headerResp = populateResponseHeader(request.getHeader().getServiceName(), mbSession);
		response.setHeader(headerResp);
    	return response;
	}
	
	private IMBResp openNewAccountAndScheduleTransfer(MobileSession mbSession, IBankCommonData ibankCommonData, HttpServletRequest httpServletRequest, ConfirmSavingsOnboardingReq request, OpenDDAAcctReq openAcctRequest, AccountOpeningService accountOpeningService, ConfirmSavingsOnboardingResp response, boolean handleInvalidBranchError, Boolean statUpdTfn) throws BusinessException {
		Logger.info("Inside openNewAccountAndScheduleTransfer :" , this.getClass());
		try {
			//19E2Hotfix1: SHO
			//get the from acct before creating the new account because the session is updated and the order of accounts change
			//and this may cause a problem with the index of the FROM acct.
			Account fromAccount = getFromAccount(mbSession, request);
			
			IMBResp createNewDDAccountResponse = openNewDDAAccount(mbSession, ibankCommonData, accountOpeningService, request, openAcctRequest, statUpdTfn);
			
			if (createNewDDAccountResponse != null && createNewDDAccountResponse instanceof OpenDDAAcctResp) {
				OpenDDAAcctResp openAccountResponse = (OpenDDAAcctResp) createNewDDAccountResponse;
	    		
				//if it is a duplicate response
				if (openAccountResponse.getDupList() != null && !openAccountResponse.getDupList().isEmpty()) {
					return openAccountResponse;
				}	
				
				if (openAccountResponse.getNewAccountDetail() != null) {	    		
					//setting list of accounts and new account details in the response object
					response.setAccounts(openAccountResponse.getAccounts());
					response.setNewAccountDetail(openAccountResponse.getNewAccountDetail());
					response.setStmtSuppressed(openAccountResponse.getStmtSuppressed());
					    		
					Account toAccount = createToAccount(openAccountResponse.getNewAccountDetail());
					
					SavingsOnboardindDescEnum sourceEnum = SavingsOnboardindDescEnum.SPLASH_OPEN_ACCOUNT;
					if (request.getSource() != null) {
						sourceEnum = SavingsOnboardindDescEnum.valueOf(request.getSource());
					}
					
					IMBResp transferResponse = performScheduleTransfer(mbSession, ibankCommonData, httpServletRequest, request, Statistic.SAVINGS_ONBOARDING_OPEN_ACCOUNT, fromAccount, toAccount, response, sourceEnum.getValue());
					// SBGEXP-5326 MRA 2019-01-18: Prudential Limit error handling -> The transfer method throws an ErrorResponse. So, return as it is.
					if(transferResponse != null && transferResponse instanceof ErrorResp){
						ErrorResp errorResponse = (ErrorResp) transferResponse;
						int errorKey = Integer.parseInt(errorResponse.getErrors().get(0).getCode());
						if (errorKey == BusinessException.SCHEDULED_PAYMENT_EXCEED_PRUDENTIAL_LIMITS) {
							BusinessException ex = new BusinessException(BusinessException.SHO_SCHEDULED_PAYMENT_EXCEED_PRUDENTIAL_LIMITS);
							Logger.error("Schedule Transfer to New Account Failed for Customer GCIS: [" + ((mbSession != null && mbSession.getCustomer() != null) ? mbSession.getCustomer().getGcis() : "") + "] :", ex, this.getClass());
							throw ex;
						}
					}
				} else {
	    			BusinessException ex = new BusinessException(BusinessException.GENERIC_ERROR);
					Logger.error("Account Opening Failed for Customer GCIS: [" + ((mbSession != null && mbSession.getCustomer() != null) ? mbSession.getCustomer().getGcis() : "") + "] :", ex, this.getClass());
					throw ex;
	    		}
	    		
	    		RespHeader headerResp = populateResponseHeader(request.getHeader().getServiceName(), mbSession);
				response.setHeader(headerResp);
		    	return response;
	    	} else {
	    		//any other type of response
	    		return createNewDDAccountResponse;
	    	}
		} catch (BusinessException ex) {
			//if the selected branch is invalid, then try opening the account again with the default branch for the logged in brand
			if (ex.getKey() == BusinessException.ACCOUNT_INVALID_BSB) {
				if (handleInvalidBranchError) {
    				if (isCustomerLoggedInBSA(mbSession)) {
	    				throw ex;
    				} else {
    					//use default branch mapping if user logged on STG or BOM, and try again
    					openAcctRequest.setBranchId(null);
    					return openNewAccountAndScheduleTransfer(mbSession, ibankCommonData, httpServletRequest, request, openAcctRequest, accountOpeningService, response, false, statUpdTfn);
    				}	    			
				} else {
					throw ex;
				}
			} else {
				throw ex;
			}
		}
	}
	
	// SBGEXP-5326 MRA 2019-01-18: Prudential Limit error handling - Added Return type
	private IMBResp performScheduleTransfer(MobileSession mbSession, IBankCommonData ibankCommonData, HttpServletRequest httpServletRequest, ConfirmSavingsOnboardingReq request, String action, Account fromAccount, Account toAccount, ConfirmSavingsOnboardingResp response, String statisticDescription) throws BusinessException {
		Logger.info("Inside performScheduleTransfer :" , this.getClass());
    	IMBResp transferResponse = null;
    	
    	try {
    		//setup schedule transfer
        	AcctTransferReq acctTransferReq = createAcctTransferReq(request);
    		transferResponse = accountTransferHelper.performTransfer(mbSession, fromAccount, toAccount, ibankCommonData, acctTransferReq, httpServletRequest, mbAppHelper, gccService, transactService, serviceStationService, digitalSecLogger, true, ServiceConstants.SAVINGS_HABIT);
    	} catch (BusinessException ex) {
    		//error while setting up transfer
			//if there is any error while creating the schedule, delete the message,
			//so that the splash page will not be displayed anymore to customer
			deleteCustomerMessage(mbSession, ibankCommonData);
			// SBGEXP-5505 MRA 2019-01-30
			Logger.error("Schedule Transfer to Account Failed for Customer GCIS due to exception: [" + ((mbSession != null && mbSession.getCustomer() != null) ? mbSession.getCustomer().getGcis() : "") + "] :", ex, this.getClass());
			ex = new BusinessException(getSchPymntExceptionKey(request));
			throw ex;
		}
    	
		if (transferResponse != null && transferResponse instanceof TransferResp) {
			TransferResp transferResp = (TransferResp) transferResponse;
			
			if (transferResp.getReceipt() != null) {
				response.setReceiptNumber(transferResp.getReceipt().getReceiptNumDisp());
				//only log statistics in case of success
				makeStatisticsLog(statisticDescription, request.getScheduleDetail().getFreq(), ibankCommonData, action, fromAccount, toAccount, request.getAmt());	
				deleteCustomerMessage(mbSession, ibankCommonData);					
			} else {
				// SBGEXP-5505 MRA 2019-01-30
				deleteCustomerMessage(mbSession, ibankCommonData);
				BusinessException ex = new BusinessException(getSchPymntExceptionKey(request));
				Logger.error("Schedule Transfer to Account Failed for Customer GCIS due to missing receipt: [" + ((mbSession != null && mbSession.getCustomer() != null) ? mbSession.getCustomer().getGcis() : "") + "] :", ex, this.getClass());
				throw ex;
	    	}
		} else {
			//if there is any error while setting up the schedule, delete the message,
			//so that the splash page will not be displayed anymore to customer
			deleteCustomerMessage(mbSession, ibankCommonData);
			BusinessException ex = new BusinessException(getSchPymntExceptionKey(request));
			Logger.error("Schedule Transfer to Account Failed for Customer GCIS due to exception: [" + ((mbSession != null && mbSession.getCustomer() != null) ? mbSession.getCustomer().getGcis() : "") + "] :", ex, this.getClass());
			throw ex;
		}
		return transferResponse;
	}
	
	// SBGEXP-5505 MRA 2019-01-30 SHO Mobile: Schedule Failed message for existing is incorrect
	private int getSchPymntExceptionKey(ConfirmSavingsOnboardingReq request){
		if (request.getExistingFlow() != null && request.getExistingFlow()) {
			return BusinessException.SHO_SCHEDULED_PAYMENT_FAILED_EXISTING_ACCT;
		}
		return BusinessException.SHO_SCHEDULED_PAYMENT_FAILED;
	}
	
	private IMBResp openNewDDAAccount(MobileSession mbSession, IBankCommonData ibankCommonData, AccountOpeningService accountOpeningService, ConfirmSavingsOnboardingReq request, OpenDDAAcctReq openAcctRequest, Boolean statUpdTfn) throws BusinessException {
		Logger.info("Inside openNewDDAAccount :" , this.getClass());
		OpenDDAAcctResp openAccountResponse;
    			
    	//open the account
		try {
			//Fixing security flaw
	    	//verify if there max number of accounts was reached, if the MAX_ACCT_OPENING_REQ exception is raised, there is not need to chek
			//the overrideDuplicate flag
			ArrayList<AcctOpeningVO> duplicateAcctOpeningList = null ; //openDDAHelper.getNewAcctDuplicateList(request.getProduct(), ibankCommonData, accountOpeningService);
			
			if (request.getOverrideDuplicate()) {
	    		openAccountResponse = (OpenDDAAcctResp) openDDAHelper.openNewDDAAccount(openAcctRequest, mbSession, ibankCommonData, accountOpeningService, logonHelper, openDDAService, debitCardService, statUpdTfn);
	    	} else {
	    		if (duplicateAcctOpeningList != null && duplicateAcctOpeningList.size() > 0) {
	    			//if it is a duplicate, prompt the user with the choice to continue
	    			IMBResp duplicateResponse = openDDAHelper.populateDDADuplicateList(duplicateAcctOpeningList);
	    			RespHeader headerResp = populateResponseHeader(request.getHeader().getServiceName(), mbSession);
	    			duplicateResponse.setHeader(headerResp);
	    	    	return duplicateResponse;
	    		} else {
	    			openAccountResponse = (OpenDDAAcctResp) openDDAHelper.openNewDDAAccount(openAcctRequest, mbSession, ibankCommonData, accountOpeningService, logonHelper, openDDAService, debitCardService, statUpdTfn);
	    		}
	    	}
		} catch (BusinessException ex) {
			if (ex.getKey() == BusinessException.MAX_ACCT_OPENING_REQ) {
				//if customer has already reached the maximum number of accounts in last 5 days,
				//delete the customer message so that splash page is not displayed again.
				deleteCustomerMessage(mbSession, ibankCommonData);
			}

			throw ex;
		}
		
		return openAccountResponse;
	}

	private void makeStatisticsLog(String statisticDescription, String frequency, IBankCommonData ibankCommonData, String action, Account fromAccount, Account toAccount, String amount) {
		StringBuffer description = new StringBuffer(statisticDescription);	
		description.append(";").append(frequency);		
		savingsOnboardingService.makeStatisticsLog(ibankCommonData, description.toString(), action, fromAccount, toAccount, amount);
	}
	
	private void deleteCustomerMessage(MobileSession mbSession, IBankCommonData ibankCommonData) throws BusinessException {
		//logically deleting the splash page message from the CustomerMessage table
		Logger.info("Inside deleteCustomerMessage :" , this.getClass());
		
		MessageSearch messageSearch = mbSession.getSplashInfoMsg();
		if (null != messageSearch) {
			savingsOnboardingService.deleteMessage(messageSearch, ibankCommonData);				
		}
	}
	
	private Account getFromAccount(MobileSession mbSession,	ConfirmSavingsOnboardingReq request) throws BusinessException {
		Account fromAccount = mbSession.getCustomer().getAccounts().get(request.getFromAccountIndex());	   
    	
    	if (fromAccount == null) {
			BusinessException ex = new BusinessException(BusinessException.GENERIC_ERROR);
			Logger.error("Schedule Transfer Failed for Customer GCIS: [" + ((mbSession != null && mbSession.getCustomer() != null) ? mbSession.getCustomer().getGcis() : "") + "] : could not find FROM account: ", ex, this.getClass());
			throw ex;
		}
		return fromAccount;
	}
	
	private Account getToAccount(MobileSession mbSession, ConfirmSavingsOnboardingReq request) throws BusinessException {
		Account toAccount = mbSession.getCustomer().getAccounts().get(request.getToAccountIndex());	    	
    	
		if (toAccount == null) {
			BusinessException ex = new BusinessException(BusinessException.GENERIC_ERROR);
			Logger.error("Schedule Transfer Failed for Customer GCIS: [" + ((mbSession != null && mbSession.getCustomer() != null) ? mbSession.getCustomer().getGcis() : "") + "] : could not find to account: ", ex, this.getClass());
			throw ex;
		}
		return toAccount;
	}
	
	private Account createToAccount(OpenAcctDetail newAccountDetail) {
		Account account = new Account();
		AccountId accountId = new AccountId();
		accountId.setApplicationId(Account.DDA);
		
		/* When account is not in session, newAccountDetail.getProduct() is empty and thus the code below does not work
		if (newAccountDetail != null) {
			if (newAccountDetail.getProduct() != null && newAccountDetail.getProduct().getSubProdcode() != null) {
				accountId.setSubProductCode(newAccountDetail.getProduct().getSubProdcode());
				ProductVO prodObj = IBankParams.getEHUBData(accountId.getApplicationId(), accountId.getSubProductCode());
				accountId.setEhubProductCode(prodObj.getEhubProductCode());				
			}
			
			accountId.setBranchKey(newAccountDetail.getBranchKey());
			accountId.setAccountKey(newAccountDetail.getAccountNum());
		}
		*/
		
		//hard coding the product code due to account session sync issue 		
		accountId.setEhubProductCode(Account.SAVING_ACCOUNT);
		accountId.setSubProductCode(Account.INCENTIVE_SAVER);
		accountId.setBranchKey(newAccountDetail.getBranchKey());
		accountId.setAccountKey(newAccountDetail.getAccountNum());
		accountId.setNewAccount(true);
		
		String myAcctno = StringUtil.getAccountNumber(accountId.getBranchKey(), accountId.getAccountKey(), accountId.getApplicationId());
		accountId.setAccountNumber(myAcctno);
		    
		account.setAccountId(accountId);
		account.setAvailableBalance(new BigDecimal(0));
		return account;
	}
	
	private OpenDDAAcctReq createNewOpenDDAAcctReq(ConfirmSavingsOnboardingReq request, MobileSession mbSession, AccountOpeningService accountOpeningService) throws ResourceException, BusinessException {
		OpenDDAAcctReq openAcctRequest = new OpenDDAAcctReq();
		openAcctRequest.setHeader(request.getHeader());
		openAcctRequest.setOverrideDuplicate(request.getOverrideDuplicate());
		openAcctRequest.setComingFromSavingsHabit(true);
		
		//if the user has not yet selected the branch, set the branch using the selected from account
		if (request.getBranchId() == null) {				
			Account fromAccount = mbSession.getCustomer().getAccounts().get(request.getFromAccountIndex());
			
			if (isBSAAccount(fromAccount)) {
				openAcctRequest.setBranchId(fromAccount.getAccountId().getBsb().substring(3, fromAccount.getAccountId().getBsb().length()));
			} else {
				if (isCustomerLoggedInBSA(mbSession)) {
					throw new BusinessException(BusinessException.ACCOUNT_INVALID_BSB);
				}
			}
		} else {
			openAcctRequest.setBranchId(request.getBranchId());
		}
		
		openAcctRequest.setProduct(request.getProduct());
		
		return openAcctRequest;
	}
	
	private boolean isCustomerLoggedInBSA(MobileSession mbSession) {
		String origin = mbSession.getOrigin();		
		
		if (origin != null && origin.contains(BSA)) {
			return true;
		}
		
		return false;
	}
	
	private boolean isBSAAccount(Account account) {
		if (account != null && account.getAccountId() != null &&	
			account.getAccountId().getBsb() != null && account.getBrand().equals(BSA)) {
			return true;
		}
		
		return false;
	}
	
	private AcctTransferReq createAcctTransferReq(ConfirmSavingsOnboardingReq request) throws BusinessException {
		AcctTransferReq acctTransferReq = new AcctTransferReq();
		acctTransferReq.setHeader(request.getHeader());
		acctTransferReq.setOrigination(ServiceConstants.SAVINGS_HABIT);
		acctTransferReq.setAmt(request.getAmt());		
		acctTransferReq.setScheduleDetail(request.getScheduleDetail());
		acctTransferReq.setSendEmail(request.getSendEmail());
		
		return acctTransferReq;
	}

	private String calculateEndDate() {
		//end date is 2 years from today
		Calendar endDateCalendar = Calendar.getInstance();
		endDateCalendar.add(Calendar.YEAR, 2);
		return DateUtils.getFormatDateStringYYYY_MM_DD(endDateCalendar.getTime());
	}

	private void validateSavingsOnboardingReq(ConfirmSavingsOnboardingReq request, MobileSession mbSession) throws BusinessException {
		if (request.getFromAccountIndex() == null) {
		   throw new BusinessException(BusinessException.ACCOUNT_NO_FROM_ACCOUNT);
		}
		
		if (mbSession.getCustomer().getAccounts() == null || mbSession.getCustomer().getAccounts().size() <= request.getFromAccountIndex()) {
			throw new BusinessException(BusinessException.INVALID_ACCOUNT);
		}	
		
		if (request.getExistingFlow() != null && request.getExistingFlow()) {
			if (request.getToAccountIndex() == null) {
			   throw new BusinessException(BusinessException.ACCOUNT_NO_TO_ACCOUNT);
			}
			
			if (mbSession.getCustomer().getAccounts().size() <= request.getToAccountIndex()) {
				throw new BusinessException(BusinessException.INVALID_ACCOUNT);
			}
		} else {
			if (!INCENTIVE_SAVER.equals(request.getProduct().getSubProdcode())) {
			   throw new BusinessException(BusinessException.ACCOUNT_DETAILS_NOT_VALID);
			}
		}
		
		if (request.getProduct() == null || request.getProduct().getSubProdcode() == null) {
		   throw new BusinessException(BusinessException.PRODUCT_REQUIRED);
		}
		
		validateSavingsOnboardingAmount(request);
	    
		if (request.getScheduleDetail() != null) {
			accountTransferHelper.validateTransferSchedule(request.getScheduleDetail());
		}
	}
	
	private void validateSavingsOnboardingAmount(ConfirmSavingsOnboardingReq request) throws BusinessException {
		if (StringMethods.isEmptyString(request.getAmt())) {
			throw new BusinessException(BusinessException.AMOUNT_IS_NULL);
		}
		
		if (!StringMethods.isNumber(request.getAmt())) {
		   throw new BusinessException(BusinessException.AMOUNT_INVALID);
		}
		
	    if (new BigDecimal(request.getAmt()).compareTo(new BigDecimal(0)) < 0) {
		    throw new BusinessException(BusinessException.ACCOUNT_NEGATIVE_AMOUNT);
	    }
	    
	    if (new BigDecimal(request.getAmt()).compareTo(new BigDecimal(0)) == 0) {
		    throw new BusinessException(BusinessException.ACCOUNT_AMT_CANNOT_ZERO);
	    }
	    
	    try {
	    	StringUtil.getMonetaryAmount(request.getAmt());
	    } catch (NumberFormatException nfe) {
	    	throw new BusinessException(BusinessException.AMOUNT_INVALID, nfe);
	    }
	}

	private ErrorResp validateRequest(HttpServletRequest httpServletRequest, IMBReq req) throws BusinessException {
		validateRequestHeader(req.getHeader(), httpServletRequest);

		ErrorResp errorResp = validate(req, httpServletRequest);
		if (errorResp != null && errorResp.getErrors() != null && errorResp.getErrors().size() > 0) {
			return errorResp;
		}

		return null;
	}
	
	private String startPerformanceLog(HttpServletRequest httpRequest) {
		perfLogger.startAllLogs();
		String logName = MBAppUtils.getLogName(httpRequest);
		perfLogger.startLog(logName);
		return logName;
    }

    private void endPerformanceLog(String logName) {
		perfLogger.endLog(logName);
		perfLogger.endAllLogs();
    }
}
