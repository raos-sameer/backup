package au.com.stgeorge.mbank.model.common;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
@JsonInclude(Include.NON_NULL)
public class GhostTileResp implements Serializable
{
	public boolean isIncompleteAppl() {
		return incompleteAppl;
	}
	public void setIncompleteAppl(boolean incompleteAppl) {
		this.incompleteAppl = incompleteAppl;
	}
	/**
	 * 
	 */
	private static final long serialVersionUID = 2741909902369994504L;
	private String tileType;	
	private String tileStatusDesc;
	private String expiryDate;
	private String productType;
	private String tileStatusDetails;
	private boolean incompleteAppl;	

	
	public String getTileType() {
		return tileType;
	}
	public void setTileType(String tileType) {
		this.tileType = tileType;
	}
	public String getTileStatusDesc() {
		return tileStatusDesc;
	}
	public void setTileStatusDesc(String tileStatusDesc) {
		this.tileStatusDesc = tileStatusDesc;
	}
		
	public String getExpiryDate() {
		return expiryDate;
	}
	public void setExpiryDate(String expiryDate) {
		this.expiryDate = expiryDate;
	}
	public String getProductType() {
		return productType;
	}
	public void setProductType(String productType) {
		this.productType = productType;
	}
	public String getTileStatusDetails() {
		return tileStatusDetails;
	}
	public void setTileStatusDetails(String tileStatusDetails) {
		this.tileStatusDetails = tileStatusDetails;
	}
	
}
