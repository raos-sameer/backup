package au.com.stgeorge.mbank.controller.newaccount;


import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.fasterxml.jackson.databind.ObjectMapper;

import au.com.stgeorge.framework.common.logging.Logger;
import au.com.stgeorge.framework.common.util.StringMethods;
import au.com.stgeorge.ibank.businessobject.BusinessException;
import au.com.stgeorge.ibank.businessobject.OnlinePINService;
import au.com.stgeorge.ibank.businessobject.ResourceException;
import au.com.stgeorge.ibank.businessobject.globalWallet.CardHolderDetailsService;
import au.com.stgeorge.ibank.businessobject.globalWallet.GlobalWalletPaymentService;
import au.com.stgeorge.ibank.businessobject.globalWallet.GlobalWalletService;
import au.com.stgeorge.ibank.businessobject.globalWallet.GlobalWalletServiceHelper;
import au.com.stgeorge.ibank.businessobject.model.globalwallet.cardholderdetails.GetCardHolderAccountDetailsResp;
import au.com.stgeorge.ibank.common.cache.IBankParams;
import au.com.stgeorge.ibank.valueobject.Customer;
import au.com.stgeorge.ibank.valueobject.GCCAccount;
import au.com.stgeorge.ibank.valueobject.OnlinePINVO;
import au.com.stgeorge.ibank.valueobject.Statistic;
import au.com.stgeorge.ibank.valueobject.database.CodesVO;
import au.com.stgeorge.ibank.valueobject.database.GlobalWallet;
import au.com.stgeorge.ibank.valueobject.globalWallet.GlobalWalletDetails;
import au.com.stgeorge.ibank.valueobject.globalWallet.GlobalWalletPurse;
import au.com.stgeorge.ibank.valueobject.globalWallet.GlobalWalletPursePayment;
import au.com.stgeorge.ibank.valueobject.globalWallet.GlobalWalletReceipt;
import au.com.stgeorge.ibank.valueobject.globalWallet.GlobalWalletTransaction;
import au.com.stgeorge.ibank.valueobject.globalWallet.GlobalWalletTransactionDetails;
import au.com.stgeorge.ibank.valueobject.transfer.IBankCommonData;
import au.com.stgeorge.mbank.controller.IMBController;
import au.com.stgeorge.mbank.controller.services.OnlinePINHelper;
import au.com.stgeorge.mbank.model.common.IMBReq;
import au.com.stgeorge.mbank.model.common.IMBResp;
import au.com.stgeorge.mbank.model.common.ReqHeader;
import au.com.stgeorge.mbank.model.common.RespHeader;
import au.com.stgeorge.mbank.model.request.EmptyReq;
import au.com.stgeorge.mbank.model.request.GlobalWalletTransDetailsReq;
import au.com.stgeorge.mbank.model.request.GlobalWalletTransListingReq;
import au.com.stgeorge.mbank.model.request.newaccount.GlobalWalletAccountReq;
import au.com.stgeorge.mbank.model.request.newaccount.GlobalWalletPurseTransferReq;
import au.com.stgeorge.mbank.model.response.CurrenciesDebitedResp;
import au.com.stgeorge.mbank.model.response.ErrorResp;
import au.com.stgeorge.mbank.model.response.GlobalWalletPurseDetailsResp;
import au.com.stgeorge.mbank.model.response.GlobalWalletTransDetailsResp;
import au.com.stgeorge.mbank.model.response.GlobalWalletTransListingResp;
import au.com.stgeorge.mbank.model.response.accountinfo.GlobalWalletAccountInfoResp;
import au.com.stgeorge.mbank.model.response.accountinfo.GlobalWalletCardsForSetPinResp;
import au.com.stgeorge.mbank.model.response.accountinfo.GlobalWalletPurseResp;
import au.com.stgeorge.mbank.model.response.accountinfo.GlobalWalletPurseTransferResp;
import au.com.stgeorge.mbank.session.MobileSession;
import au.com.stgeorge.mbank.util.MBAppHelper;
import au.com.stgeorge.mbank.util.MBAppUtils;
import au.com.stgeorge.mbank.util.MBAppValidator;
import au.com.stgeorge.mbank.util.ServiceConstants;
import au.com.stgeorge.perflogger.PerformanceLogger;
import au.com.stgeorge.framework.common.util.DateMethods;


@Controller
@RequestMapping("/globalWallet")
public class GlobalWalletAccountController implements IMBController
{
	
	@Autowired
	private MBAppHelper mbAppHelper;
	
	@Autowired
	private MBAppValidator mbAppValidator;
		
	
	@Autowired
	private PerformanceLogger perfLogger;
	
	@Autowired
	private CardHolderDetailsService cardHolderDetailsService;
	
	@Autowired
	private GlobalWalletService globalWalletService;
	
	@Autowired
	private GlobalWalletAccountControllerHelper gwAccountControllerHelper;
	
	@Autowired
	private GlobalWalletPaymentService globalWalletPaymentService;
	
    @Autowired
	private GlobalWalletServiceHelper gwServiceHelper;
	
	@Autowired
	private OnlinePINHelper helper;
    
	@Autowired
	private OnlinePINService onlinePinService;
	
	public ErrorResp validate(IMBReq serviceRequest, HttpServletRequest request) {
		return mbAppValidator.validate(serviceRequest, request);
	}
	
	public void validateRequestHeader(ReqHeader header, HttpServletRequest request) throws ResourceException
	{	
		mbAppValidator.validateRequestHeader(header,  request);	
	}
	
	public RespHeader populateResponseHeader(String serviceName, MobileSession mobSession )
	{
		return mbAppHelper.populateResponseHeader(serviceName, mobSession);
	}
	
	@RequestMapping(value= "purseTransfer" , method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public IMBResp globalWalletPurseTransfer(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, @RequestBody final GlobalWalletPurseTransferReq req)
	{		
	
		ObjectMapper objectMapper = new ObjectMapper();				
		IMBResp serviceResponse = new GlobalWalletPurseTransferResp();
		perfLogger.startAllLogs();
		String logName = MBAppUtils.getLogName(httpServletRequest);
		perfLogger.startLog(logName);
		MobileSession mbSession = null;
		try{	
			Logger.info("globalWalletPurseTransfer JSON Request :" + objectMapper.writeValueAsString(req), this.getClass());
			mbSession = mbAppHelper.getMobileSession(httpServletRequest);			
			validateRequestHeader(req.getHeader(), httpServletRequest);
			ErrorResp errorResp = validate(req, httpServletRequest);
			if (errorResp != null && errorResp.getErrors() != null && errorResp.getErrors().size() > 0)
			{				
				return errorResp;
			}

			//Populate GlobalWalletPursePayment VO
			GlobalWalletPursePayment globalWalletPursePaymentVO = gwAccountControllerHelper.populateGlobalWalletPursePaymentVO(mbSession, req);
			
			//Call GlobalWalletPaymentService for purseTransfer
			IBankCommonData commonData=mbAppHelper.populateIBankCommonData(mbSession,httpServletRequest);
			Customer customer=mbSession.getCustomer();			
			GCCAccount globalWalletAccount = (GCCAccount) mbAppHelper.getAccountFromCustomer(customer, req.getAccountIndex());
			Logger.debug("globalWalletPurseTransfer globalWalletPursePaymentVO for globalWalletPaymentService.purseTransfer - JSON Request :" + objectMapper.writeValueAsString(globalWalletPursePaymentVO), this.getClass());
			GlobalWalletReceipt globalWalletReceipt = (GlobalWalletReceipt)globalWalletPaymentService.purseTransfer(commonData, globalWalletAccount, globalWalletPursePaymentVO);

			//Populate response
			serviceResponse = gwAccountControllerHelper.populateGlobalWalletPurseTransferResp(req.getAccountIndex(), globalWalletReceipt, mbSession);
			
			
			RespHeader headerResp = populateResponseHeader(ServiceConstants.GLOBAL_WALLET_PURSE_TRANSFER_SERVICE, mbSession);
			serviceResponse.setHeader(headerResp);
			Logger.info("globalWalletPurseTransfer JSON Response :" + objectMapper.writeValueAsString(serviceResponse), this.getClass());
			
			return serviceResponse;
			
		}catch (BusinessException e) {	
			Logger.error("BusinessException Inside globalWalletPurseTransfer() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "]", e, this.getClass());		
			BusinessException exp = new BusinessException(e.getKey());
			IMBResp resp1  = MBAppUtils.createErrorResp(mbSession.getOrigin() ,exp, ServiceConstants.GLOBAL_WALLET_PURSE_TRANSFER_SERVICE, httpServletRequest);
			return resp1;
			
		}catch (ResourceException e) {
			Logger.error("ResourceException Inside globalWalletPurseTransfer() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "]", e, this.getClass());			
			ResourceException exp = new ResourceException(BusinessException.GLOBAL_WALLET_PURSE_TRANSFER_SVC_UNAVAILABLE);
			IMBResp resp1  = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, ServiceConstants.GLOBAL_WALLET_PURSE_TRANSFER_SERVICE, httpServletRequest);
			return resp1;
			
		}catch (Exception e) {			
			Logger.error("Exception Inside globalWalletPurseTransfer() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "]", e, this.getClass());
			BusinessException exp = new BusinessException(BusinessException.GLOBAL_WALLET_PURSE_TRANSFER_SVC_UNAVAILABLE);
			IMBResp resp1  = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, ServiceConstants.GLOBAL_WALLET_PURSE_TRANSFER_SERVICE, httpServletRequest);
			return resp1;
		} finally {
			perfLogger.endLog(logName);
			perfLogger.endAllLogs();
		}	
	}

	
	/**
	 * This method will retrieve limit details on click of Details tab on GCC account.  
	 * 
	 * @param httpServletRequest
	 * @param httpServletResponse
	 * @param req
	 * @return IMBResp
	 */
	@RequestMapping(value= "limits" , method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public IMBResp getGlobalWalletAcctLimits(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, @RequestBody final GlobalWalletAccountReq req)
	{		
	
		ObjectMapper objectMapper = new ObjectMapper();				
		IMBResp serviceResponse = new GlobalWalletAccountInfoResp();
		perfLogger.startAllLogs();
		String logName = MBAppUtils.getLogName(httpServletRequest);
		perfLogger.startLog(logName);
		MobileSession mbSession = null;
		try{	
			Logger.info("getGlobalWalletAcctLimits JSON Request :" + objectMapper.writeValueAsString(req), this.getClass());
			mbSession = mbAppHelper.getMobileSession(httpServletRequest);			
			validateRequestHeader(req.getHeader(), httpServletRequest);
			ErrorResp errorResp = validate(req, httpServletRequest);
			if (errorResp != null && errorResp.getErrors() != null && errorResp.getErrors().size() > 0)
			{				
				return errorResp;
			}
																			
			int myAcctIndex = req.getAccountIndex();
			Customer customer=mbSession.getCustomer();			
			
			GCCAccount globalWalletAccount = (GCCAccount) mbAppHelper.getAccountFromCustomer(customer, myAcctIndex);
			String cardNumber = globalWalletAccount.getCardNumber();
			IBankCommonData commonData=null;
			
			if(globalWalletAccount!=null &&  null != cardNumber){
				commonData=mbAppHelper.populateIBankCommonData(mbSession,httpServletRequest);
				GlobalWalletDetails globalWalletDtls = globalWalletService.getGlobalWalletLimitDetails(cardNumber, commonData, UUID.randomUUID());
				//Populate the Global Wallet account limit details in response
				serviceResponse = gwAccountControllerHelper.populateGlobalWalletAcctLimitsResp(mbSession,globalWalletAccount,globalWalletDtls);
				
				//set response header
				RespHeader headerResp = populateResponseHeader(ServiceConstants.GLOBAL_WALLET_CARD_LIMIT_SERVICE, mbSession);
				serviceResponse.setHeader(headerResp);
			}else{
				Logger.error("getGlobalWalletAcctLimits cardNumber : is null for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "]", this.getClass());		
				BusinessException exp = new BusinessException(BusinessException.GLOBAL_WALLET_CARD_LIMITAPI_ERROR);
				IMBResp resp1  = MBAppUtils.createErrorResp(mbSession.getOrigin() ,exp, ServiceConstants.GLOBAL_WALLET_CARD_LIMIT_SERVICE, httpServletRequest);
				return resp1;
			}
			
			return serviceResponse;
			
		}catch (BusinessException e) {	
			Logger.error("BusinessException Inside getGlobalWalletAcctLimits() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "]", e, this.getClass());		
			BusinessException exp = new BusinessException(BusinessException.GLOBAL_WALLET_CARD_LIMITAPI_ERROR);
			IMBResp resp1  = MBAppUtils.createErrorResp(mbSession.getOrigin() ,exp, ServiceConstants.GLOBAL_WALLET_CARD_LIMIT_SERVICE, httpServletRequest);
			return resp1;
			
		}catch (ResourceException e) {
			Logger.error("ResourceException Inside getGlobalWalletAcctLimits() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "]", e, this.getClass());			
			ResourceException exp = new ResourceException(BusinessException.GLOBAL_WALLET_CARD_LIMITAPI_ERROR);
			IMBResp resp1  = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, ServiceConstants.GLOBAL_WALLET_CARD_LIMIT_SERVICE, httpServletRequest);
			return resp1;
			
		}catch (Exception e) {			
			Logger.error("Exception Inside getGlobalWalletAcctLimits() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "]", e, this.getClass());
			BusinessException exp = new BusinessException(BusinessException.GLOBAL_WALLET_CARD_LIMITAPI_ERROR);
			IMBResp resp1  = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, ServiceConstants.GLOBAL_WALLET_CARD_LIMIT_SERVICE, httpServletRequest);
			return resp1;
		} finally {
			perfLogger.endLog(logName);
			perfLogger.endAllLogs();
		}	
	}
	

	/**
	 * SBGEXP-6978<br>
	 * This method will return the card numbers for setting PIN immediately after 
	 * origination of branch picked up GCC cards.<br>
	 * <br>
	 * <b>Steps : </b>
	 * <li> DB Id column ([requestId]) to be picked from MB session, set after origination.</li>
	 * <li> Using this ID, fetch the Card holder Id from DB.</li> 
	 * <li> Using the card holder Id, call the Car dHolder Details API to retrieve the card numbers.</li>
	 * <li> Pass the card numbers to UI.</li>
	 * <br><br>
	 * 
	 * <b>Note</b><br>
	 * As its origination, card holder details will return only two cards, which can be passed to UI as is.<br>
	 * No need to call card status API to validate the status of the cards.
	 * <br><br>
	 * @param httpServletRequest
	 * @param httpServletResponse
	 * @param req
	 * @return IMBResp
	 */
	@RequestMapping(value= "getCardsForSetPin" , method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public IMBResp getCardsForSetPin(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, @RequestBody final EmptyReq emptyReq)
	{		
		Logger.info("Global Wallet : getCardsForSetPin - START. ", this.getClass());
		
		MobileSession mbSession = null;
		IMBResp serviceResponse = new GlobalWalletAccountInfoResp();		
		String logName = MBAppUtils.getLogName(httpServletRequest);
		
		perfLogger.startAllLogs();
		perfLogger.startLog(logName);
				
		try{	
					
			mbSession = mbAppHelper.getMobileSession(httpServletRequest);			
			
			validateRequestHeader( emptyReq.getHeader(), httpServletRequest );
			
			Long requestId = mbSession.getInitiatedGlobalWalletId();
			
			if(null == requestId){
				Logger.error("Global Wallet : InitiatedGlobalWalletId is not set in mbSession. ", this.getClass());
				throw new BusinessException(BusinessException.GLOBAL_WALLET_API_ERROR);
			}
			
			//SBGEXP-8078 - fetch GlobalWallet account details for CardHolder ID and brand
			GlobalWallet globalWallet  = globalWalletService.getGlobalWalletWithRequestId(requestId);
						
			if(null != globalWallet && null != globalWallet.getCardholderId()){
				//Call the Card Holder Details API
				IBankCommonData commonData = mbAppHelper.populateIBankCommonData(mbSession,httpServletRequest);
				GetCardHolderAccountDetailsResp cardHolderAccountDetailsResp = cardHolderDetailsService.getCardHolderAccountDetails(commonData, UUID.randomUUID(), globalWallet.getCardholderId(), globalWallet.getOrigin());

				
				
				//Populate the response
				serviceResponse = gwAccountControllerHelper.populateCardsForSetPinResp(cardHolderAccountDetailsResp,mbSession);

				OnlinePINVO onlinePINVO = null;
				//20E4 -- Skip 2FA for WWW set pin, if coming from WDP UI after card activation/branch back
		        if(IBankParams.isSwitchOn(IBankParams.getBaseOriginCode(mbSession.getOrigin()), IBankParams.GLOBAL_WALLET_SETPIN_2FA_BYPASS_SWITCH)) {//Switch
				
		        	if(!StringMethods.isEmptyString(mbSession.getActionType()) && mbSession.getActionType().equalsIgnoreCase(IBankParams.GLOBAL_WALLET_PIN_BRANCH_PACK)) {
		        		
		        	
					// Check for the GlobalWallet Card
					//Boolean globalWalletCardActivation = false;
					
					//19E4 - Check the switch for GlobalWallet and call the GlobalWallet card encryption details service if the BINs are matching
					if(globalWalletService.isGlobalWalletSwitchOn(commonData.getCustomer().getGcis())){
						//check the BIN numbers 
						onlinePINVO = helper.populateOnlinePINVOForWWW(mbSession);
						String brand = gwServiceHelper.isGlobalWalletCard(onlinePINVO.getCardNum());
						if(null != brand){
							//call the backend service to return the modulus, exponent
							onlinePINVO =onlinePinService.getEncryptionDetailsForGlobalWallet();	
							onlinePINVO.setGwCardBrand(brand);
							//resp =helper.populateEncryptionDetailsForWWW(populateResponseHeader(ServiceConstants.ONLINE_PIN_SERVICE, mbSession ), onlinePINVO);
							
							if(onlinePINVO != null && serviceResponse instanceof GlobalWalletCardsForSetPinResp) {
								GlobalWalletCardsForSetPinResp resp = (GlobalWalletCardsForSetPinResp)serviceResponse;
								
								resp.setHideSecureCode(true);//UI to by pass 2FA screen and show set pin page
								resp.setRandomNum(onlinePINVO.getRandomNum());
								resp.setModulus(onlinePINVO.getModulus());
								resp.setExponent(onlinePINVO.getExponent());
								resp.setHashAlgo(onlinePINVO.getHashAlgo());
								resp.setGlobalWalletCardSetPIN(true);
								serviceResponse = resp;
							}

							
							//set the secure code verified tran name 
							mbSession.setSecureCodeVerifiedTranName(ServiceConstants.ONLINE_PIN_SERVICE);
							//globalWalletCardActivation = true;
							//serviceResponse.setGlobalWalletCardSetPIN(true);
						}
					}
		        	}
		        }


				
				RespHeader headerResp = populateResponseHeader(ServiceConstants.GLOBAL_WALLET_CARD_PIN_SERVICE, mbSession);
				serviceResponse.setHeader(headerResp);
			}else{
				Logger.error("Global Wallet : getCardsForSetPin cardHolderId : is null for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "]", this.getClass());		
				throw new BusinessException(BusinessException.GLOBAL_WALLET_API_ERROR);
			}
			
			return serviceResponse;
			
		}catch (BusinessException e) {	
			Logger.error("Global Wallet : BusinessException Inside getCardsForSetPin() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "]", e, this.getClass());		
			BusinessException exp = new BusinessException(BusinessException.GLOBAL_WALLET_API_ERROR);
			IMBResp resp1  = MBAppUtils.createErrorResp(mbSession.getOrigin() ,exp, ServiceConstants.GLOBAL_WALLET_CARD_PIN_SERVICE, httpServletRequest);
			return resp1;
			
		}catch (ResourceException e) {
			Logger.error("Global Wallet : ResourceException Inside getCardsForSetPin() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "]", e, this.getClass());			
			ResourceException exp = new ResourceException(BusinessException.GLOBAL_WALLET_API_ERROR);
			IMBResp resp1  = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, ServiceConstants.GLOBAL_WALLET_CARD_PIN_SERVICE, httpServletRequest);
			return resp1;
			
		}catch (Exception e) {			
			Logger.error("Global Wallet : Exception Inside getCardsForSetPin() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "]", e, this.getClass());
			BusinessException exp = new BusinessException(BusinessException.GLOBAL_WALLET_API_ERROR);
			IMBResp resp1  = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, ServiceConstants.GLOBAL_WALLET_CARD_PIN_SERVICE, httpServletRequest);
			return resp1;
		} finally {
			perfLogger.endLog(logName);
			perfLogger.endAllLogs();
			
			// Remove the global wallet id from session
			mbSession.removeInitiatedGlobalWalletId();

			//20E4 -- Skip 2FA for WWW set pin, if coming from WDP UI after card activation/branch back
			mbSession.removeActionType();
			
			Logger.debug("Global Wallet : getCardsForSetPin - END. ", this.getClass());
		}	
	}
	
	/**
	 * This method will retrieve the transactions for specified period on click of Transactions tab on GCC account.  
	 * 
	 * @param httpServletRequest
	 * @param httpServletResponse
	 * @param req
	 * @return IMBResp
	 */
	@RequestMapping(value= "globalWalletTransListing" , method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public IMBResp getGlobalWalletCardTransactionListing(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, @RequestBody final GlobalWalletTransListingReq req)
	{		
		ObjectMapper objectMapper = new ObjectMapper();				
		IMBResp serviceResponse = new GlobalWalletTransListingResp();
		perfLogger.startAllLogs();
		String logName = MBAppUtils.getLogName(httpServletRequest);
		perfLogger.startLog(logName);
		MobileSession mbSession = null;
		try{	
			Logger.info("getGlobalWalletCardTransactionListing JSON Request :" + objectMapper.writeValueAsString(req), this.getClass());
			mbSession = mbAppHelper.getMobileSession(httpServletRequest);			
			validateRequestHeader(req.getHeader(), httpServletRequest);
			ErrorResp errorResp = validate(req, httpServletRequest);
			if (errorResp != null && errorResp.getErrors() != null && errorResp.getErrors().size() > 0)
			{				
				return errorResp;
			}
																			
			int myAcctIndex = req.getAccountIndex();
			Customer customer=mbSession.getCustomer();			
			
			GCCAccount globalWalletAccount = (GCCAccount) mbAppHelper.getAccountFromCustomer(customer, myAcctIndex);
			String cardNumber = globalWalletAccount.getCardNumber();
			IBankCommonData commonData=null;
			
			if(globalWalletAccount!=null &&  null != cardNumber){
				commonData=mbAppHelper.populateIBankCommonData(mbSession,httpServletRequest);
				
				  String currentYear=DateMethods.getCurrentYear()+"";
	  			  String currentMonth=DateMethods.formatDate("MM",new java.util.Date());
	              String year = req.getTransactionPeriod().substring(0, 4);
	  			  String month = req.getTransactionPeriod().substring(4);
	  			  boolean getPendingTrans=false;
	  			  if(currentYear.equals(year) && currentMonth.equals(month) && mbSession.getFetchGlobalWalletPendingTransactions()){
	  				getPendingTrans=true;
	  			  }
				
				GlobalWalletDetails globalWalletDtls = globalWalletService.getGlobalWalletTransactionListing(cardNumber, getPendingTrans, req.getTransactionPeriod(), req.getPostedTransactionStartIndex(),commonData, UUID.randomUUID());
				
				//Put Convert Currency debit transactions in session
				mbSession.setConvertCurrencyTransList(globalWalletDtls.getConvertCurrencyDebitTransactions());
				
				//Populate the Global Wallet account transaction listing in response
				serviceResponse = gwAccountControllerHelper.populateGlobalWalletTransactionListingResp(mbSession, globalWalletAccount, globalWalletDtls);
				
				//Set No Transactions Found message
				String baseOrigin = IBankParams.getBaseOriginCode(commonData.getOrigin());
				String gccCustomerCare = IBankParams.getGCCMasterCardCustomerCare(baseOrigin);
				String gccCustomerCareOverseas = IBankParams.getGCCMasterCardCustomerCareOverseas(baseOrigin);
				String[] msgParams = { globalWalletDtls.getTransHistoryDefaultMonth(), gccCustomerCare, gccCustomerCareOverseas };
				String noTransactionsFoundMessage = IBankParams.getErrorMessage(baseOrigin,String.valueOf(BusinessException.GLOBAL_WALLET_TRANS_HISTORY_NOT_FOUND));
				if (msgParams != null && !StringUtils.isEmpty(noTransactionsFoundMessage)) {
					noTransactionsFoundMessage = MessageFormat.format(noTransactionsFoundMessage, (Object[])msgParams);
					((GlobalWalletTransListingResp)serviceResponse).setNoTransactionsFoundMessage(noTransactionsFoundMessage);
				}
				Logger.debug("getGlobalWalletCardTransactionListing JSON Response :" + objectMapper.writeValueAsString(serviceResponse),this.getClass());
				//set response header
				RespHeader headerResp = populateResponseHeader(ServiceConstants.GLOBAL_WALLET_TRANSACTION_LISTING_SERVICE, mbSession);
				serviceResponse.setHeader(headerResp);
			}else{
				Logger.error("getGlobalWalletCardTransactionListing cardNumber : is null for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "]", this.getClass());		
				BusinessException exp = new BusinessException(BusinessException.GLOBAL_WALLET_CARD_TRANSACTION_LISTING_API_ERROR);
				IMBResp resp1  = MBAppUtils.createErrorResp(mbSession.getOrigin() ,exp, ServiceConstants.GLOBAL_WALLET_TRANSACTION_LISTING_SERVICE, httpServletRequest);
				return resp1;
			}
			
			return serviceResponse;
			
		}catch (BusinessException e) {	
			Logger.error("BusinessException Inside getGlobalWalletCardTransactionListing() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "]", e, this.getClass());		
			BusinessException exp = new BusinessException(BusinessException.GLOBAL_WALLET_CARD_TRANSACTION_LISTING_API_ERROR);
			IMBResp resp1  = MBAppUtils.createErrorResp(mbSession.getOrigin() ,exp, ServiceConstants.GLOBAL_WALLET_TRANSACTION_LISTING_SERVICE, httpServletRequest);
			return resp1;
			
		}catch (ResourceException e) {
			Logger.error("ResourceException Inside getGlobalWalletCardTransactionListing() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "]", e, this.getClass());			
			ResourceException exp = new ResourceException(BusinessException.GLOBAL_WALLET_CARD_TRANSACTION_LISTING_API_ERROR);
			IMBResp resp1  = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, ServiceConstants.GLOBAL_WALLET_TRANSACTION_LISTING_SERVICE, httpServletRequest);
			return resp1;
			
		}catch (Exception e) {			
			Logger.error("Exception Inside getGlobalWalletCardTransactionListing() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "]", e, this.getClass());
			BusinessException exp = new BusinessException(BusinessException.GLOBAL_WALLET_CARD_TRANSACTION_LISTING_API_ERROR);
			IMBResp resp1  = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, ServiceConstants.GLOBAL_WALLET_TRANSACTION_LISTING_SERVICE, httpServletRequest);
			return resp1;
		} finally {
			perfLogger.endLog(logName);
			perfLogger.endAllLogs();
		}	
	}
	
	/**
	 * This method will retrieve the transactions details for a specified transaction.  
	 * 
	 * @param httpServletRequest
	 * @param httpServletResponse
	 * @param req
	 * @return IMBResp
	 */
	@RequestMapping(value= "globalWalletTranDetail" , method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public IMBResp getGlobalWalletCardTransactionDetails(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, @RequestBody final GlobalWalletTransDetailsReq req)
	{		
		ObjectMapper objectMapper = new ObjectMapper();				
		IMBResp serviceResponse = new GlobalWalletTransListingResp();
		perfLogger.startAllLogs();
		String logName = MBAppUtils.getLogName(httpServletRequest);
		perfLogger.startLog(logName);
		MobileSession mbSession = null;
		CurrenciesDebitedResp nonNetworkTxn = null;
		try{	
			Logger.info("getGlobalWalletCardTransactionDetails JSON Request :" + objectMapper.writeValueAsString(req), this.getClass());
			mbSession = mbAppHelper.getMobileSession(httpServletRequest);			
			validateRequestHeader(req.getHeader(), httpServletRequest);
			ErrorResp errorResp = validate(req, httpServletRequest);
			if (errorResp != null && errorResp.getErrors() != null && errorResp.getErrors().size() > 0)
			{				
				return errorResp;
			}
																			
			int myAcctIndex = req.getAccountIndex();
			Customer customer=mbSession.getCustomer();			
			
			GCCAccount globalWalletAccount = (GCCAccount) mbAppHelper.getAccountFromCustomer(customer, myAcctIndex);
			String cardNumber = globalWalletAccount.getCardNumber();
			IBankCommonData commonData=null;
			List<GlobalWalletTransactionDetails> globalWalletTransactionDetailsList = null;
			String convertCurrencyDescription = null;
			boolean isWalletTransfer = false;
			if(req.getIsWalletTransfer()!=null) {
				isWalletTransfer = req.getIsWalletTransfer();
			}
			
			if(globalWalletAccount!=null &&  null != cardNumber){
				commonData=mbAppHelper.populateIBankCommonData(mbSession,httpServletRequest);

				//Call TransactionDetails Service parallelly for both credit and debit for convert currencies
				GlobalWalletTransactionDetails tranDetails = new GlobalWalletTransactionDetails();
				tranDetails.setTransactionSequenceNumber(req.getTransactionSequenceNumber());
				tranDetails.setEffectiveDate(req.getEffectiveDateTime());
				tranDetails.setCycleDateTime(req.getCycleDateTime());

				/*if(req.getTransCode().equals(GlobalWalletServiceHelper.TXN_CODE_CREDIT_ADJUSTMENT)) {*/
				if(isWalletTransfer) {	
					GlobalWalletTransactionDetails debitTranDetails = new GlobalWalletTransactionDetails();
					for (GlobalWalletTransaction globalWalletTransaction : mbSession.getConvertCurrencyTransList()) {
						if(globalWalletTransaction.getReferenceNumber().substring(8).equalsIgnoreCase(req.getRefNum().substring(8))) {
							debitTranDetails.setTransactionSequenceNumber(globalWalletTransaction.getTransactionSequenceNumber());
							debitTranDetails.setEffectiveDate(globalWalletTransaction.getEffectiveDate());
							debitTranDetails.setCycleDateTime(globalWalletTransaction.getCycleDateTime());
							convertCurrencyDescription=globalWalletTransaction.getDescription().substring(28);
						}
					}
					
					globalWalletTransactionDetailsList = 
							globalWalletService.getTransactionDetailsForConvertCurrencies(commonData,UUID.randomUUID(),cardNumber, tranDetails, debitTranDetails,req.getCurrencyCode());
					
				}
				else {
					globalWalletTransactionDetailsList = 
							globalWalletService.getGlobalWalletTransactionDetails(commonData,UUID.randomUUID() ,cardNumber, tranDetails, req.getCurrencyCode());
					
					//20E4 - Non Network Transaction
					nonNetworkTxn = gwAccountControllerHelper.getNonNetworkTxn(globalWalletTransactionDetailsList, commonData, req.getTransCode());
				}		
			
				
				//Populate the Global Wallet account transaction details in response
				 serviceResponse = gwAccountControllerHelper.populateGlobalWalletTransactionDetailsResp(globalWalletTransactionDetailsList,req.getCurrencyCode(),req.getTransCode(),convertCurrencyDescription, isWalletTransfer);
				
				((GlobalWalletTransDetailsResp)serviceResponse).setDisputeTranCodes(globalWalletService.getDisputeTranCodes(commonData.getOrigin()));
				
				((GlobalWalletTransDetailsResp)serviceResponse).setNonNetworkTxn(nonNetworkTxn);
				
				//set response header GLOBAL_WALLET_PURSE_DETAILS_SERVICE
				RespHeader headerResp = populateResponseHeader(ServiceConstants.GLOBAL_WALLET_TRANSACTION_DETAILS_SERVICE, mbSession);
				serviceResponse.setHeader(headerResp);
				
				//SBGEXP-8137 - GDW entry
				globalWalletService.processGDWForGlobalWallet(commonData, globalWalletAccount, Statistic.GLOBAL_WALLET_TXN_DETAIL_INQUIRY);
				
			}else{
				Logger.error("getGlobalWalletCardTransactionDetails cardNumber : is null for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "]", this.getClass());		
				BusinessException exp = new BusinessException(BusinessException.GLOBAL_WALLET_CARD_TRANSACTION_LISTING_API_ERROR);
				IMBResp resp1  = MBAppUtils.createErrorResp(mbSession.getOrigin() ,exp, ServiceConstants.GLOBAL_WALLET_TRANSACTION_DETAILS_SERVICE, httpServletRequest);
				return resp1;
			}
			
			return serviceResponse;
			
		}catch (BusinessException e) {	
			Logger.error("BusinessException Inside getGlobalWalletCardTransactionDetails() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "]", e, this.getClass());		
			BusinessException exp = new BusinessException(BusinessException.GLOBAL_WALLET_CARD_TRANSACTION_LISTING_API_ERROR);
			IMBResp resp1  = MBAppUtils.createErrorResp(mbSession.getOrigin() ,exp, ServiceConstants.GLOBAL_WALLET_TRANSACTION_DETAILS_SERVICE, httpServletRequest);
			return resp1;
			
		}catch (ResourceException e) {
			Logger.error("ResourceException Inside getGlobalWalletCardTransactionDetails() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "]", e, this.getClass());			
			ResourceException exp = new ResourceException(BusinessException.GLOBAL_WALLET_CARD_TRANSACTION_LISTING_API_ERROR);
			IMBResp resp1  = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, ServiceConstants.GLOBAL_WALLET_TRANSACTION_DETAILS_SERVICE, httpServletRequest);
			return resp1;
			
		}catch (Exception e) {			
			Logger.error("Exception Inside getGlobalWalletCardTransactionDetails() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "]", e, this.getClass());
			BusinessException exp = new BusinessException(BusinessException.GLOBAL_WALLET_CARD_TRANSACTION_LISTING_API_ERROR);
			IMBResp resp1  = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, ServiceConstants.GLOBAL_WALLET_TRANSACTION_DETAILS_SERVICE, httpServletRequest);
			return resp1;
		} finally {
			perfLogger.endLog(logName);
			perfLogger.endAllLogs();
		}	
	}
	
	/**
	 * This method will retrieve the toCurrenciesList based on the from Currency selected 
	 * 
	 * @param httpServletRequest
	 * @param httpServletResponse
	 * @param req
	 * @return IMBResp
	 */
	@RequestMapping(value= "purseDetails" , method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public IMBResp getPurseDetails(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, @RequestBody final GlobalWalletTransDetailsReq req)
	{		
		IMBResp serviceResponse = null;
		perfLogger.startAllLogs();
		String logName = MBAppUtils.getLogName(httpServletRequest);
		perfLogger.startLog(logName);
		MobileSession mbSession = null;
		try{	
			Logger.info("getPurseDetails JSON Request :" , this.getClass());
			mbSession = mbAppHelper.getMobileSession(httpServletRequest);
			IBankCommonData iBankCommonData = mbAppHelper.populateIBankCommonData(mbSession, httpServletRequest);
			
			String selFromCurrencyCode = req.getCurrencyCode();//Get from request
			GlobalWalletDetails globalWalletDetails = mbSession.getGlobalWalletDetails();
			List<GlobalWalletPurse> globalWalletPurses = globalWalletDetails.getPurses();//Get from session
			
			String customerFxBand = mbSession.getCustomerFxBand();
			if(StringMethods.isEmptyString(customerFxBand)) {
				customerFxBand = globalWalletPaymentService.getCustomerBand(iBankCommonData);
				mbSession.setCustomerFxBand(customerFxBand);
			}
			
			Map<String, GlobalWalletPurse> toCurrPurseMap = globalWalletService.getToCurrenciesList(selFromCurrencyCode, globalWalletPurses, customerFxBand);			
            
            GlobalWalletPurseDetailsResp response = new GlobalWalletPurseDetailsResp();
            
            //Populate pursesResponse
            List<GlobalWalletPurseResp> pursesResp = new ArrayList<>();
            
			//GccExchangeRateQuotes
			//FromCode|ToCode - quoteId

            HashMap<String, GlobalWalletPurse> mapGccExchangeRateQuotes = new HashMap<String, GlobalWalletPurse>();
            
            for(GlobalWalletPurse purse  : toCurrPurseMap.values()) {
            	GlobalWalletPurseResp purseResp = new GlobalWalletPurseResp();
            	purseResp.setCurrencyCode(purse.getCurrencyCode());
            	purseResp.setDescription(purse.getCurrencyDescription());
            	purseResp.setAvailBalance(purse.getAvailableBal());
            	purseResp.setExchangeRate(String.valueOf(purse.getExchangeRate()));
            	purseResp.setExchangeInfo(purse.getExchangeInfo());
            	pursesResp.add(purseResp);
            	
            	mapGccExchangeRateQuotes.put(selFromCurrencyCode+"|"+purse.getCurrencyCode(), purse);
            }

        	//Set GccExchangeRateQuotes (quoteIds) to session
            mbSession.setGccExchangeRateQuotes(mapGccExchangeRateQuotes);
            
            response.setPurses(pursesResp);
            
            CodesVO currencyOrderVO = IBankParams.getCodesData(IBankParams.DEFAULT_ORIGIN, IBankParams.GLOBAL_WALLET, IBankParams.GLOBAL_WALLET_CURRENCY_CONVERSION_FEE);
            response.setConversionFee(currencyOrderVO.getMessage());
            
            Collection<CodesVO> gwCurrList = IBankParams.getCodesDataList(IBankParams.TT_NONDEC_CURRENCY);
            String[] nonDecimalCurrencies = new String[gwCurrList.size()];
            int index = 0;
            for(CodesVO nonDecimalCodeVO : gwCurrList ) {
           	 
           	 nonDecimalCurrencies[index] = nonDecimalCodeVO.getCode();
           	 index++;
            }
            response.setNonDecimalCurrencies(nonDecimalCurrencies);        
            serviceResponse = response;
            
            //set response header 
			RespHeader headerResp = populateResponseHeader(ServiceConstants.GLOBAL_WALLET_PURSE_DETAILS_SERVICE, mbSession);
			
			serviceResponse.setHeader(headerResp);
			return serviceResponse;
			
		}catch (BusinessException be) {	
			Logger.error("BusinessException Inside getPurseDetails() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "]", be, this.getClass());			
			IMBResp resp1  = MBAppUtils.createErrorResp(mbSession.getOrigin() , BusinessException.SYSTEM_UNAVILABLE, ServiceConstants.GLOBAL_WALLET_PURSE_DETAILS_SERVICE, httpServletRequest);
			return resp1;
			
		}catch (Exception e) {			
			Logger.error("Exception Inside getPurseDetails() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "]", e, this.getClass());
			IMBResp resp1  = MBAppUtils.createErrorResp(mbSession.getOrigin(), BusinessException.SYSTEM_UNAVILABLE, ServiceConstants.GLOBAL_WALLET_PURSE_DETAILS_SERVICE, httpServletRequest);
			return resp1;
		} finally {
			perfLogger.endLog(logName);
			perfLogger.endAllLogs();
		}	
	}
	
	/**
	 * This method will return the purse payment status 
	 * 
	 * @param httpServletRequest
	 * @param httpServletResponse
	 * @param req
	 * @return IMBResp
	 */
	@RequestMapping(value= "purseTransferStatus" , method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public IMBResp getPurseReceiptStatus (HttpServletRequest httpServletRequest, @RequestBody final EmptyReq request)
	{		
		IMBResp serviceResponse = new GlobalWalletPurseTransferResp();
		perfLogger.startAllLogs();
		String logName = MBAppUtils.getLogName(httpServletRequest);
		perfLogger.startLog(logName);
		MobileSession mbSession = null;
		try{	
			Logger.info("getPurseReceiptStatus JSON Request :" , this.getClass());
			mbSession = mbAppHelper.getMobileSession(httpServletRequest);
			IBankCommonData iBankCommonData = mbAppHelper.populateIBankCommonData(mbSession, httpServletRequest);
			
			String pursePaymentsLogId = mbSession.getPursePaymentsLogId();
			Logger.info("getPurseReceiptStatus(). : pursePaymentsLogId in session :"+pursePaymentsLogId , this.getClass());
			if(pursePaymentsLogId == null){
				Logger.error("getPurseReceiptStatus(). : pursePaymentsLogId is null in session ." , this.getClass());
				throw new BusinessException(BusinessException.SYSTEM_UNAVILABLE, "purseTransferStatus(). : pursePaymentsLogId is null in session .");
			}
			
			GlobalWalletReceipt globalWalletReceipt = (GlobalWalletReceipt)globalWalletPaymentService.getPursePaymentReceipt(Long.parseLong(pursePaymentsLogId));
            
			//Populate response
			serviceResponse = gwAccountControllerHelper.populateGlobalWalletPurseTransferResp(Integer.valueOf(mbSession.getSelectedAccountIndex()), globalWalletReceipt, mbSession);
			
            //set response header 
			RespHeader headerResp = populateResponseHeader(ServiceConstants.GLOBAL_WALLET_PURSE_TRANSFER_STATUS, mbSession);
			
			serviceResponse.setHeader(headerResp);
			return serviceResponse;
			
		}catch (BusinessException be) {	
			Logger.error("BusinessException Inside getPurseReceiptStatus() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "]", be, this.getClass());			
			IMBResp resp1  = MBAppUtils.createErrorResp(mbSession.getOrigin() , BusinessException.SYSTEM_UNAVILABLE, ServiceConstants.GLOBAL_WALLET_PURSE_TRANSFER_STATUS, httpServletRequest);
			return resp1;
			
		}catch (Exception e) {			
			Logger.error("Exception Inside getPurseReceiptStatus() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "]", e, this.getClass());
			IMBResp resp1  = MBAppUtils.createErrorResp(mbSession.getOrigin(), BusinessException.SYSTEM_UNAVILABLE, ServiceConstants.GLOBAL_WALLET_PURSE_TRANSFER_STATUS, httpServletRequest);
			return resp1;
		} finally {
			perfLogger.endLog(logName);
			perfLogger.endAllLogs();
		}	
	}
			
}

