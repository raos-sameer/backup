package au.com.stgeorge.mbank.model.accountinfo;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
/**
 * @author C50216
 *
 */

@JsonInclude(Include.NON_NULL)
public class OfferDetailResp {

	private String offerAmt;
	private String minIncreaseAmt;
	
	public String getOfferAmt() {
		return offerAmt;
	}
	public void setOfferAmt(String offerAmt) {
		this.offerAmt = offerAmt;
	}
	public String getMinIncreaseAmt() {
		return minIncreaseAmt;
	}
	public void setMinIncreaseAmt(String minIncreaseAmt) {
		this.minIncreaseAmt = minIncreaseAmt;
	}
			
}
