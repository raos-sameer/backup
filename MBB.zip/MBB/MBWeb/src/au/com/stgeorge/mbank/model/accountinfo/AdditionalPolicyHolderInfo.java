package au.com.stgeorge.mbank.model.accountinfo;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_NULL)
public class AdditionalPolicyHolderInfo{

	private String holderName;
	private List<AdditionalPolicyInfo> increasedLimits;
	public String getHolderName() {
		return holderName;
	}
	public void setHolderName(String holderName) {
		this.holderName = holderName;
	}
	public List<AdditionalPolicyInfo> getIncreasedLimits() {
		return increasedLimits;
	}
	public void setIncreasedLimits(List<AdditionalPolicyInfo> increasedLimits) {
		this.increasedLimits = increasedLimits;
	}
}
