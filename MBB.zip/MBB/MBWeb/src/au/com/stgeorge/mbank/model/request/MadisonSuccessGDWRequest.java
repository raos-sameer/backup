package au.com.stgeorge.mbank.model.request;

import au.com.stgeorge.mbank.model.common.IMBReq;
import au.com.stgeorge.mbank.model.common.ReqHeader;

public class MadisonSuccessGDWRequest implements IMBReq {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -857135397877777359L;
	private ReqHeader header;
	private String cardIndex;
	@Override
	public ReqHeader getHeader() {
		return header;
	}

	@Override
	public void setHeader(ReqHeader header) {
		this.header=header;
	}

	public String getCardIndex() {
		return cardIndex;
	}

	public void setCardIndex(String cardIndex) {
		this.cardIndex = cardIndex;
	}

	
}
