package au.com.stgeorge.mbank.model.request.payments;

import javax.validation.Valid;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
//import javax.validation.constraints.Pattern;
import org.apache.commons.lang.builder.ReflectionToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;
import org.hibernate.validator.constraints.Length;
import org.hibernate.validator.constraints.NotEmpty;

import au.com.stgeorge.ibank.businessobject.BusinessException;
import au.com.stgeorge.mbank.model.common.IMBReq;
import au.com.stgeorge.mbank.model.common.ReqHeader;

public class NPPValidationsReq implements IMBReq {

	private static final long serialVersionUID = 7259582730803367267L;
	//private static final String VALID_CHAR_SET_PAYER_NAME = "^[0-9A-Za-z'\\-,.() &/]*$";
	
	private ReqHeader header;
	
	@NotEmpty(message = "{errors.amt.required}")
	@Length(max = 14, message = "{errors.amt.maxlength}")
	//@Pattern(regexp = AMT_PATTERN, message = "{errors.amt.blockchar}")
	private String amt;
	
	@NotNull(message = "" + BusinessException.ACCOUNT_NO_FROM_ACCOUNT)
	@Min(value = 0, message="" + BusinessException.GENERIC_ERROR)
	private Integer fromAccountIndex;
	
	@NotNull(message = "" + BusinessException.ACCOUNT_NO_TO_ACCOUNT)
	private Integer toPayeeIndex;
	
	//@Pattern(regexp = BLOCK_CHARS_PATTERN, message = "{errors.desc.blockchar}")
	@Length(max = 280, message = "{errors.desc.maxlength}")
	private String desc;
	
//	@Pattern(regexp = VALID_CHAR_SET_PAYER_NAME, message = "{errors.payerName.blockchar}")
	@Length(max = 140, message = "{errors.payerName.maxlength}")
	private String payerName;
	
	@Valid
	private TransferScheduleReq scheduleDetail;
	
	private String reference;
	
	public String getReference() {
		return reference;
	}

	public void setReference(String reference) {
		this.reference = reference;
	}

	public String getAmt() {
		return amt;
	}

	public void setAmt(String amt) {
		this.amt = amt;
	}
	
	public Integer getFromAccountIndex() {
		return fromAccountIndex;
	}

	public void setFromAccountIndex(Integer fromAccountIndex) {
		this.fromAccountIndex = fromAccountIndex;
	}

	public Integer getToPayeeIndex() {
		return toPayeeIndex;
	}

	public void setToPayeeIndex(Integer toPayeeIndex) {
		this.toPayeeIndex = toPayeeIndex;
	}

	public String getDesc() {
		return desc;
	}

	public void setDesc(String desc) {
		this.desc = desc;
	}

	public String getPayerName() {
		return payerName;
	}

	public void setPayerName(String payerName) {
		this.payerName = payerName;
	}	
	
	public TransferScheduleReq getScheduleDetail() {
		return scheduleDetail;
	}

	public void setScheduleDetail(TransferScheduleReq scheduleDetail) {
		this.scheduleDetail = scheduleDetail;
	}

	public ReqHeader getHeader() {		
		return header;
	}
	
	public void setHeader(ReqHeader header) {
		this.header = header;
	}
	
	@Override
	public String toString() {
		return ReflectionToStringBuilder.toString(this, ToStringStyle.MULTI_LINE_STYLE);
	}
}
