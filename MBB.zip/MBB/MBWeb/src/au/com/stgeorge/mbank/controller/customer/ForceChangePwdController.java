package au.com.stgeorge.mbank.controller.customer;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import au.com.stgeorge.framework.common.logging.Logger;
import au.com.stgeorge.framework.common.model.User;
import au.com.stgeorge.ibank.businessobject.BusinessException;
import au.com.stgeorge.ibank.businessobject.ForceChangePwdService;
import au.com.stgeorge.ibank.businessobject.IBankSecureService;
import au.com.stgeorge.ibank.businessobject.ResourceException;
import au.com.stgeorge.ibank.common.cache.IBankParams;
import au.com.stgeorge.ibank.valueobject.Customer;
import au.com.stgeorge.ibank.valueobject.ForceChangePwd;
import au.com.stgeorge.ibank.valueobject.pwdreset.PwdResetCustomerDetails;
import au.com.stgeorge.ibank.valueobject.transfer.IBankCommonData;
import au.com.stgeorge.mbank.controller.IMBController;
import au.com.stgeorge.mbank.controller.SecureCodeHelper;
import au.com.stgeorge.mbank.model.common.IMBReq;
import au.com.stgeorge.mbank.model.common.IMBResp;
import au.com.stgeorge.mbank.model.common.ReqHeader;
import au.com.stgeorge.mbank.model.common.RespHeader;
import au.com.stgeorge.mbank.model.request.EmptyReq;
import au.com.stgeorge.mbank.model.request.SecureCodeReq;
import au.com.stgeorge.mbank.model.request.pwdreset.PwdSecNumResetReq;
import au.com.stgeorge.mbank.model.response.ErrorResp;
import au.com.stgeorge.mbank.model.response.customer.ActivationResp;
import au.com.stgeorge.mbank.session.MobileSession;
import au.com.stgeorge.mbank.session.MobileSessionImpl;
import au.com.stgeorge.mbank.util.MBAppHelper;
import au.com.stgeorge.mbank.util.MBAppUtils;
import au.com.stgeorge.mbank.util.MBAppValidator;
import au.com.stgeorge.mbank.util.ServiceConstants;
import au.com.stgeorge.perflogger.PerformanceLogger;

import com.fasterxml.jackson.databind.ObjectMapper;

@Controller
@RequestMapping("/forcechangepwd")
public class ForceChangePwdController implements IMBController
{
	
	
	@Autowired
	private LogonHelper logonHelper;
	
	@Autowired
	private ForceChangePwdService forceChangePwdService;
	
	
	@Autowired
	private SecureCodeHelper secureCodeHelper;	
	
	@Autowired
	private PerformanceLogger perfLogger;
	
	@Autowired
	private MBAppHelper mbAppHelper;	
	
	@Autowired
	private MBAppValidator mbAppValidator;	
	
	private static final String PASSWORD_REGEX="[a-zA-Z]+[0-9]+[a-zA-Z0-9]*|[0-9]+[a-zA-Z]+[a-zA-Z0-9]*";
	private static final String SECURITYNO_REGEX="^[0-9]*$";	
	private static final String INVALID_OTP="INVALD";
	
	@RequestMapping(value="skip", method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public IMBResp skipForceChagePwd(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, @RequestBody final EmptyReq req)
	{
		ObjectMapper mapper = new ObjectMapper();
		
		perfLogger.startAllLogs();
		String logName = MBAppUtils.getLogName(httpServletRequest);
		perfLogger.startLog(logName);
		MBAppHelper mbAppHelper = new MBAppHelper();
		
		User user = null;
		MobileSession mobileSession = null;	
		try
		{
			mobileSession = mbAppHelper.getMobileSession(httpServletRequest);
			user = mobileSession.getUser();
			
			Customer customer = mobileSession.getCustomer();
			
			
			String loggedonState =mobileSession.getLoggedonState();
			if(LogonHelper.LOGGEDON_STATE_FORCE_PWDCHANGE.equalsIgnoreCase(loggedonState) || LogonHelper.LOGGEDON_STATE_FORCE_PWDCHANGE_2FA_EXEMPT.equalsIgnoreCase(loggedonState)){
			
				IBankCommonData commonData = populateIBankCommonData(httpServletRequest, user, mobileSession);	
				//get the skip count from session
				ForceChangePwd forceChangePwdVO =mobileSession.getForceChangePwd();
				int newSkipCount =forceChangePwdVO.getSkipCount().intValue() + 1;
				forceChangePwdService.skipForceChange(commonData, newSkipCount);
				
				//remove from session
				mobileSession.setForceChangePwd(null);
				mobileSession.setLoggedonState(LogonHelper.LOGGEDON_STATE_COMPLETE);
				IMBResp serviceResponse = populateSecureResponse();					
				RespHeader headerResp = populateResponseHeader(ServiceConstants.FORCE_CHANGE_PWD_RESPONSE, mobileSession  );
				serviceResponse.setHeader(headerResp);
				Logger.info("ForceChangePwd SKIP JSON Response :" + mapper.writeValueAsString(serviceResponse), this.getClass());			
				return serviceResponse;	
			}
			else {
				throw new BusinessException(BusinessException.SYSTEM_UNAVILABLE);
			}
			
		
			
		} catch (BusinessException e)
		{
			Logger.error("Exception Inside popularFeatures | ForceChangePwd SKIP " + e.getKey(), e, this.getClass());
			IMBResp resp = MBAppUtils.createErrorResp(mobileSession.getOrigin(), e, ServiceConstants.FORCE_CHANGE_PWD_RESPONSE, httpServletRequest);
			return resp;
		} catch (Exception e)
		{
			Logger.error("Exception Inside popularFeatures | ForceChangePwd SKIP ", e, this.getClass());
			BusinessException exp = new BusinessException(BusinessException.SYSTEM_UNAVILABLE);
			IMBResp resp = MBAppUtils.createErrorResp(mobileSession.getOrigin(), exp, ServiceConstants.POPULAR_FEATURES_RESPONSE, httpServletRequest);
			return resp;
		} finally
		{
			perfLogger.endLog(logName);
			perfLogger.endAllLogs();
		}
	}
	
	
	
	  @RequestMapping(value="create", method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE)
		@ResponseBody
		public IMBResp reqSecureCode(HttpServletRequest httpRequest, @RequestBody final SecureCodeReq request) {
			Logger.debug("ForceChangePwdController - reqSecureCode(). Request: " + request, this.getClass());
			
			perfLogger.startAllLogs();
			String logName = MBAppUtils.getLogName(httpRequest);
			perfLogger.startLog(logName);			
			MobileSession mobileSession = new MobileSessionImpl();
			IMBResp resp = null;

			try {
				mobileSession.getSessionContext(httpRequest);
				IBankCommonData commonData = new MBAppHelper().populateIBankCommonData(mobileSession, httpRequest);
				
				validateRequestHeader(request.getHeader(), httpRequest);
				ErrorResp errorResponse = validate(request, httpRequest);// validate json
				if (errorResponse!=null && errorResponse.hasErrors())
					return errorResponse;
				
				if (ServiceConstants.PWD_RESET_TRAN_CODE != request.getTranType()){
					return MBAppUtils.createInvalid2FATransactionTypeResponse(ServiceConstants.FORCE_CHANGE_PWD_RESPONSE);
				}
				
				//remove from session
				mobileSession.setForceChangePwd(null);				
				
				PwdResetCustomerDetails pwdResetDetails =new PwdResetCustomerDetails();	
				return secureCodeHelper.reqSecureCode(commonData, mobileSession, null, pwdResetDetails, request, ServiceConstants.REQ_2FA_PWDRESET, httpRequest);
				
			} catch (ResourceException e) {
				Logger.error("ResourceException in ForceChangePwdController - reqChangePINSecureCode() - [key: " + e.getKey() + "], GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());
				mobileSession.removeSecureCodeDetails();
				return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.SYSTEM_UNAVILABLE, ServiceConstants.FORCE_CHANGE_PWD_RESPONSE, httpRequest);
			} catch (Exception e) {			
				Logger.error("Exception ForceChangePwdController - reqChangePINSecureCode(): GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "]", e, this.getClass());
				mobileSession.removeSecureCodeDetails();
				return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.GENERIC_ERROR, ServiceConstants.FORCE_CHANGE_PWD_RESPONSE, httpRequest);
			} finally {
				perfLogger.endLog(logName);
				perfLogger.endAllLogs();
			}
		}	
	
	
	  @RequestMapping(value="verify", method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE)
		@ResponseBody
		public IMBResp verifyPwdResetSecureCode(HttpServletRequest httpRequest, @RequestBody final SecureCodeReq request) {
			Logger.debug("ForceChangePwdController - verifyPwdResetSecureCode(). Request: " + request, this.getClass());
			perfLogger.startAllLogs();
			String logName = MBAppUtils.getLogName(httpRequest);
			perfLogger.startLog(logName);
			MobileSession mobileSession = new MobileSessionImpl();

			try {
				mobileSession.getSessionContext(httpRequest);
				IBankCommonData commonData = new MBAppHelper().populateIBankCommonData(mobileSession, httpRequest);
				
				validateRequestHeader(request.getHeader(), httpRequest);
				ErrorResp errorResponse = validate(request, httpRequest);// validate json
				if (errorResponse!=null && errorResponse.hasErrors())
					return errorResponse;

				if (ServiceConstants.PWD_RESET_TRAN_CODE != request.getTranType()) 
					return MBAppUtils.createInvalid2FATransactionTypeResponse(ServiceConstants.VERIFY_2FA_PWDRESET);		
				
				if(!isValidOTPPwd(request.getOtpPwd())){
					//we still need to increment the bad OTP counter, hence cannot throw an exception
					request.setOtpPwd(INVALID_OTP);
				}
				
				PwdResetCustomerDetails pwdResetDetails =new PwdResetCustomerDetails();	
				errorResponse = secureCodeHelper.verifySecureCode(commonData, mobileSession, pwdResetDetails, request, ServiceConstants.VERIFY_2FA_PWDRESET, httpRequest);
				if (errorResponse.hasErrors())
					return errorResponse;
				else{
					
					//set a value in session if 2fa verification is successful. This will be used to validate in reset pwd and sec num
					mobileSession.setSecureCodeVerifiedTranName(ServiceConstants.REQ_2FA_PWDRESET);
					//set the logged on state to 2FA done
					mobileSession.setLoggedonState(LogonHelper.LOGGEDON_STATE_FORCE_PWDCHANGE_2FA);
					IMBResp serviceResponse = populateSecureResponse();					
					RespHeader headerResp = populateResponseHeader(ServiceConstants.FORCE_CHANGE_PWD_RESPONSE, mobileSession  );
					serviceResponse.setHeader(headerResp);
					return serviceResponse;					
					
				}
				
			} catch (ResourceException e) {
				Logger.error("Exception ForceChangePwdController - verifyPwdResetSecureCode(): GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "]", e, this.getClass());
				mobileSession.removeTransaction();
				mobileSession.removeSecureCodeDetails();
				return MBAppUtils.createErrorResp("ALL", BusinessException.SYSTEM_UNAVILABLE, ServiceConstants.FORCE_CHANGE_PWD_RESPONSE, httpRequest);
			} catch (Exception e) {
				Logger.error("Exception ForceChangePwdController - verifyPwdResetSecureCode(): GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "]", e, this.getClass());
				mobileSession.removeTransaction();
				mobileSession.removeSecureCodeDetails();
				return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.GENERIC_ERROR, ServiceConstants.FORCE_CHANGE_PWD_RESPONSE, httpRequest);
			} finally {
				perfLogger.endLog(logName);
				perfLogger.endAllLogs();
			}

		}	
		
		@RequestMapping(value="change", method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE)
		@ResponseBody
		public IMBResp resetPwdAndSecNum(HttpServletRequest httpRequest, @RequestBody final PwdSecNumResetReq request) {
			Logger.debug("ForceChangePwdController - resetPwdAndSecNum(). Request: " + request, this.getClass());
			perfLogger.startAllLogs();
			String logName = MBAppUtils.getLogName(httpRequest);
			perfLogger.startLog(logName);
			MobileSession mobileSession = new MobileSessionImpl();
		
			try {
				mobileSession.getSessionContext(httpRequest);
				//check if 2fa is verified
				if((mobileSession.getSecureCodeVerifiedTranName() !=null && ServiceConstants.REQ_2FA_PWDRESET.equalsIgnoreCase(mobileSession.getSecureCodeVerifiedTranName()))
						|| (IBankParams.isGlobalByPass()) || (IBankSecureService.isCustomerExempt(mobileSession.getCustomer().getIBankSecureDetails()))){
					IBankCommonData commonData = new MBAppHelper().populateIBankCommonData(mobileSession, httpRequest);
					
					validateRequestHeader(request.getHeader(), httpRequest);
					ErrorResp errorResponse = validate(request, httpRequest);// validate json
					if (errorResponse !=null && errorResponse.hasErrors())
						return errorResponse;				
				
					//validate the password and sec num
					if(isPasswordValid(request.getConfirmPassword()) && isPasswordValid(request.getPassword())){
						if(isSecurityNoValid(request.getConfirmSecNum()) && isSecurityNoValid(request.getSecNum())){
							PwdResetCustomerDetails pwdResetDetails=populatePwdResetCustomerDetails(commonData);
							populatePwdResetDetails(pwdResetDetails, request);
							pwdResetDetails.setReferURL(httpRequest.getHeader("referer"));
							forceChangePwdService.changePwdAndSecNum(pwdResetDetails,commonData);
							mobileSession.setLoggedonState(LogonHelper.LOGGEDON_STATE_COMPLETE);
							IMBResp serviceResponse = populateSecureResponse();					
							RespHeader headerResp = populateResponseHeader(ServiceConstants.FORCE_CHANGE_PWD_RESPONSE, mobileSession  );
							serviceResponse.setHeader(headerResp);
							return serviceResponse;	
						}
						else{
							throw new BusinessException(BusinessException.INVALID_CURRENT_PWD_SEC_NUM);
						}
					}
					else{
						throw new BusinessException(BusinessException.INVALID_CURRENT_PWD_SEC_NUM);
					}
					
		
	
				}
				else{
					//2fa was not verified. throw an error
					Logger.error("BusinessException ForceChangePwdController- 2FA not verified- resetPwdAndSecNum(): GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "]", this.getClass());
					throw new ResourceException(ResourceException.SYSTEM_ERROR);
				}
				
			}
			catch (BusinessException e) {
				Logger.error("BusinessException ForceChangePwdController - resetPwdAndSecNum(): GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "]", e, this.getClass());
				mobileSession.removeTransaction();
				mobileSession.removeSecureCodeDetails();
				return MBAppUtils.createErrorResp(mobileSession.getOrigin(), e, ServiceConstants.FORCE_CHANGE_PWD_RESPONSE, httpRequest);
			} 		
			catch (ResourceException e) {
				Logger.error("ResourceException ForceChangePwdController - resetPwdAndSecNum(): GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "]", e, this.getClass());
				mobileSession.removeTransaction();
				mobileSession.removeSecureCodeDetails();
				return MBAppUtils.createErrorResp("ALL", BusinessException.SYSTEM_UNAVILABLE, ServiceConstants.FORCE_CHANGE_PWD_RESPONSE, httpRequest);
			} catch (Exception e) {
				Logger.error("Exception ForceChangePwdController - resetPwdAndSecNum(): GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "]", e, this.getClass());
				mobileSession.removeTransaction();
				mobileSession.removeSecureCodeDetails();
				return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.GENERIC_ERROR, ServiceConstants.FORCE_CHANGE_PWD_RESPONSE, httpRequest);
			} finally {
				perfLogger.endLog(logName);
				perfLogger.endAllLogs();
			}

		}			
	
	private IMBResp populateSecureResponse()
	{
		ActivationResp activationResponse = new ActivationResp();
		activationResponse.setSuccess(true);
		return activationResponse;
	}
	
	private PwdResetCustomerDetails populatePwdResetCustomerDetails(IBankCommonData commondata) {
		//populate the PwdResetCustomerDetails from session
		PwdResetCustomerDetails pwdCustDetails = new PwdResetCustomerDetails();
		if(commondata!=null && commondata.getUser()!=null && commondata.getCustomer()!=null){
			pwdCustDetails.setCan(commondata.getUser().getUserId());
			pwdCustDetails.setGcisNumber(commondata.getUser().getGCISNumber());			
			pwdCustDetails.setIpAddress(commondata.getIpAddress());			
		}
		
		return pwdCustDetails;
	}	
	
	public PwdResetCustomerDetails populatePwdResetDetails(PwdResetCustomerDetails pwdCustDetails,PwdSecNumResetReq request){
		pwdCustDetails.setPassword(request.getPassword());
		pwdCustDetails.setConfirmPassword(request.getConfirmPassword());
		pwdCustDetails.setSecurityNo(request.getSecNum());
		pwdCustDetails.setConfirmSecurityNo(request.getConfirmSecNum());
		return pwdCustDetails;
	}	

	private IBankCommonData populateIBankCommonData(HttpServletRequest httpServletRequest,	User user, MobileSession mobileSession) {
		IBankCommonData commonData = new IBankCommonData();
		commonData.setUser(user);
		commonData.setOrigin(mobileSession.getOrigin());
		commonData.setGdwOrigin(mobileSession.getGDWOrigin());
		commonData.setIpAddress(MBAppHelper.resolveIPAddress(httpServletRequest, mobileSession.getOrigin()));
		commonData.setSessionId(mobileSession.getSessionID());
		commonData.setCustomer(mobileSession.getCustomer());
		String userAgent = httpServletRequest.getHeader("User-Agent");		
		commonData.setUserAgent(userAgent);
		return commonData;
	}	

	@Override
	public ErrorResp validate(IMBReq serviceRequest,HttpServletRequest httpRequest) throws BusinessException {
		return mbAppValidator.validate(serviceRequest, httpRequest);
	}
	
	public RespHeader populateResponseHeader(String serviceName, MobileSession mobSession )
	{
		return mbAppHelper.populateResponseHeader(serviceName, mobSession);
	}

	@Override
	public void validateRequestHeader(ReqHeader headerReq,HttpServletRequest request) throws BusinessException {
		mbAppValidator.validateRequestHeader(headerReq,  request);
	}
	
	
  	private boolean isPasswordValid(String password){
  		boolean retValue=false;						
  	    Pattern mask = Pattern.compile(PASSWORD_REGEX);	
  	    Matcher matcher = mask.matcher(password);
  	    if (matcher.matches()){
  	    	retValue=true;
  	    }		
  		return retValue;
  	}
  	
  	private boolean isSecurityNoValid(String securityNo){
  		boolean retValue=false;
  	    Pattern mask = Pattern.compile(SECURITYNO_REGEX);	
  	    Matcher matcher = mask.matcher(securityNo);
  	    if (matcher.matches()){
  	    	retValue=true;
  	    }		
  		return retValue;
  	}	
  	
  	private boolean isValidOTPPwd(String otpPwd){
  		boolean retValue=false;
  	    Pattern mask = Pattern.compile(SECURITYNO_REGEX);	
  	    Matcher matcher = mask.matcher(otpPwd);
  	    if (matcher.matches()){
  	    	retValue=true;
  	    }		
  		return retValue;
  	}
}
