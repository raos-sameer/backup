package au.com.stgeorge.mbank.controller.services;

import java.math.BigDecimal;

import au.com.stgeorge.ibank.common.cache.IBankParams;
import au.com.stgeorge.ibank.valueobject.Account;
import au.com.stgeorge.ibank.valueobject.CreditCardAccount;
import au.com.stgeorge.ibank.valueobject.database.OriginsVO;
import au.com.stgeorge.ibank.valueobject.database.ProductVO;
import au.com.stgeorge.mbank.model.common.IMBResp;
import au.com.stgeorge.mbank.model.response.services.IncreaseCreditLimitInfoResp;

public class IncreaseCreditLimitHelper {

	protected IMBResp populateInfoResp(CreditCardAccount acct,String newLimit){
		
		IncreaseCreditLimitInfoResp resp = new IncreaseCreditLimitInfoResp();
		
		ProductVO prodVO = IBankParams.getLogoData(Account.CRA, acct.getCreditCardAdditionalInfo().getOrganisation(), acct.getCreditCardAdditionalInfo().getLogo(), acct.getAccountId().getAccountNumber());
		String brand = prodVO.getBrand();
		OriginsVO originVO = IBankParams.getOrigin(brand);
				
		resp.setBankName(originVO.getName());
		resp.setPhoneNum(originVO.getPhone());
		resp.setOriginURL(originVO.getUrl());
		
		BigDecimal minPayPercnt = new BigDecimal((IBankParams.getCodesData(IBankParams.DEFAULT_ORIGIN, IBankParams.CREDIT_CARD_CONFIG, IBankParams.CC_MIN_MONTHLYPAYMENT)).getMessage());
		
		//resp.setCurrentMinPayment((new BigDecimal(req.getCurrentLimit()).multiply(minPayPercnt)).toString());
		//resp.setNewMinPayment((new BigDecimal(req.getNewLimit()).multiply(minPayPercnt)).toString());
						
		resp.setCurrentMinPayment((acct.getCreditLimit().multiply(minPayPercnt)).toString());
		resp.setNewMinPayment((new BigDecimal(newLimit).multiply(minPayPercnt)).toString());
						
		return resp;		
	}	
}
