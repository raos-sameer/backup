package au.com.stgeorge.mbank.model.request.canretrieval;

import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import org.apache.commons.lang.builder.ReflectionToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;
import org.hibernate.validator.constraints.NotEmpty;

import au.com.stgeorge.ibank.businessobject.BusinessException;
import au.com.stgeorge.mbank.model.common.IMBReq;
import au.com.stgeorge.mbank.model.common.ReqHeader;

public class CanRetrievalReq implements IMBReq {
	
	private static final long serialVersionUID = -2290300454035750499L;

	private ReqHeader header;

	@NotEmpty(message = "{errors.cardNum.required}")
	@Size(min = 12, max = 16, message = ""+BusinessException.INVALID_CARD_ACCESS_NUMBER)
	@Pattern(regexp="([0-9-]+)", message = ""+BusinessException.INVALID_CARD_ACCESS_NUMBER)
	private String cardNum;

	@NotEmpty(message = "{errors.issueNum.required}")
	@Size(max = 1, message = ""+BusinessException.INVALID_ISSUE_NUMBER)
	@Pattern(regexp="([0-9-]+)", message = ""+BusinessException.INVALID_ISSUE_NUMBER)
	private String issueNum;

	@NotEmpty(message = "{errors.dateOfBirth.required}")
	@Pattern(regexp="\\d{4}-(0?[1-9]|1[012])-(0?[1-9]|[12][0-9]|3[01])", message = ""+BusinessException.INVALID_DATE_OF_BIRTH)
	private String dateOfBirth;



	public String getCardNum() {
		return cardNum;
	}

	public void setCardNum(String cardNum) {
		this.cardNum = cardNum;
	}

	public String getIssueNum() {
		return issueNum;
	}

	public void setIssueNum(String issueNum) {
		this.issueNum = issueNum;
	}

	public String getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public ReqHeader getHeader() {
		return header;
	}

	public void setHeader(ReqHeader header) {
		this.header = header;
	}

	@Override
	public String toString() {
		return ReflectionToStringBuilder.toString(this, ToStringStyle.MULTI_LINE_STYLE);
	}

}
