package au.com.stgeorge.mbank.controller.customer;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import au.com.stgeorge.digitalsec.logger.DigitalSecLogger;
import au.com.stgeorge.framework.common.logging.Logger;
import au.com.stgeorge.framework.common.util.StringMethods;
import au.com.stgeorge.ibank.businessobject.BusinessException;
import au.com.stgeorge.ibank.common.cache.IBankParams;
import au.com.stgeorge.ibank.safi.util.SafiUtil;
import au.com.stgeorge.ibank.safi.valueobject.SafiUpdatePhoneVO;
import au.com.stgeorge.ibank.service.valueobject.SafiRespVO;
import au.com.stgeorge.ibank.servicestation.businessobject.valueobject.ServiceStationVO;
import au.com.stgeorge.ibank.servicestation.util.ServicetationConstants;
import au.com.stgeorge.ibank.valueobject.Address;
import au.com.stgeorge.ibank.valueobject.ContactDetail;
import au.com.stgeorge.ibank.valueobject.Customer;
import au.com.stgeorge.ibank.valueobject.CustomerTypes;
import au.com.stgeorge.ibank.valueobject.PhoneNumber;
import au.com.stgeorge.ibank.valueobject.database.CodesVO;
import au.com.stgeorge.ibank.valueobject.database.CountryListVO;
import au.com.stgeorge.ibank.valueobject.database.OriginsVO;
import au.com.stgeorge.ibank.valueobject.transfer.IBankCommonData;
import au.com.stgeorge.mbank.controller.SafiWebHelper;
import au.com.stgeorge.mbank.model.common.AccountKeyInfoResp;
import au.com.stgeorge.mbank.model.common.AddressReq;
import au.com.stgeorge.mbank.model.common.AddressResp;
import au.com.stgeorge.mbank.model.common.IMBResp;
import au.com.stgeorge.mbank.model.common.PhoneInfoResp;
import au.com.stgeorge.mbank.model.common.PhoneReq;
import au.com.stgeorge.mbank.model.request.customer.ContactDetailsReq;
import au.com.stgeorge.mbank.model.request.customer.PhoneDetailReq;
import au.com.stgeorge.mbank.model.response.customer.ContactDetailsResp;
import au.com.stgeorge.mbank.model.response.servicestation.ServiceStationResp;
import au.com.stgeorge.mbank.session.MobileSession;
import au.com.stgeorge.mbank.util.MBAppUtils;

/**
 * Contact detail Helper
 * 
 * @author C57303
 */
public class ContactDetailHelper
{
	private LogonHelper logonHelper;
		
	public LogonHelper getLogonHelper() {
		return logonHelper;
	}

	public void setLogonHelper(LogonHelper logonHelper) {
		this.logonHelper = logonHelper;
	}


	public ContactDetail getContactDetail(ContactDetailsReq req, Customer customer) throws BusinessException
	{
		ContactDetail oldContactDetail = customer.getContactDetail();
		ContactDetail contactDetail = new ContactDetail();

		if ( customer.isGHSCustomer() )
		{

			ArrayList<AddressReq> addresList = req.getAddresses();
			Iterator<AddressReq> it = addresList.iterator();
	
			while (it.hasNext())
			{
				AddressReq tempAdd = it.next();
				Address resAddress=null;
				if ("RES".equalsIgnoreCase(tempAdd.getAddrType()))
				{
					resAddress = getAddress(tempAdd);
					if ( oldContactDetail.getResidentialAddress()!= null && oldContactDetail.getResidentialAddress().toString().equalsIgnoreCase( resAddress.toString() ))
					{
						contactDetail.setResidentialAddress(oldContactDetail.getResidentialAddress());
					}
					else
					{
						contactDetail.setResidentialAddress(resAddress);
					}
				}
				if("MAIL".equalsIgnoreCase(tempAdd.getAddrType()))
				{
					Address mailAddress = getAddress(tempAdd);
					if ( oldContactDetail.getMailingAddress() != null && oldContactDetail.getMailingAddress().toString().equalsIgnoreCase(mailAddress.toString()) )
					{
						contactDetail.setMailingAddress(oldContactDetail.getMailingAddress());
					}
					else
					{
						contactDetail.setMailingAddress(mailAddress);
					}
				}
/*				if(req.isSameAddress())
				{
					contactDetail.setMailingAddress(resAddress);
				}  */
			}
		}
		contactDetail.setEmail(req.getEmail()==null?"":req.getEmail());
		contactDetail.setPrimaryProfile(customer.getContactDetail().getPrimaryProfile());
		contactDetail.setCustomerType(customer.getContactDetail().getCustomerType());
		contactDetail.setCustTypeInd(customer.getContactDetail().getCustTypeInd());
		contactDetail.setCustomerNumber(customer.getContactDetail().getCustomerNumber());
		contactDetail.setMobileNumber(customer.getContactDetail().getMobileNumber());
		contactDetail.setHomeNumber(customer.getContactDetail().getHomeNumber());
		contactDetail.setWorkNumber(customer.getContactDetail().getWorkNumber());
		contactDetail.setFaxNumber(customer.getContactDetail().getFaxNumber());
		contactDetail.setEmailConsent(req.isEmailConsent());
		return contactDetail;
	}

	
	public ContactDetail getPhoneDetails(PhoneDetailReq req, Customer customer) throws BusinessException
	{
		ContactDetail oldContactDetail = customer.getContactDetail();
		ContactDetail contactDetail = new ContactDetail();
		
		if ( customer.isCustomerOfTypeGHS() )
		{

			ArrayList<PhoneReq> phoneList = req.getPhones();
			Iterator<PhoneReq> it = phoneList.iterator();
	
			while (it.hasNext())
			{
				PhoneReq tempPhone = it.next();
				if (tempPhone.getIsPhnNoChange()) {
					if ("MOBILE".equalsIgnoreCase(tempPhone.getPhoneType()))
					{
						PhoneNumber mobNumber = new PhoneNumber();
						String areaCode = tempPhone.getPhoneNum().substring(0, 4);
						String phoneNo = tempPhone.getPhoneNum().substring(4, 10);
						mobNumber.setAreaCode(areaCode);
						mobNumber.setPhoneNumber(phoneNo);
						contactDetail.setMobileNumber(mobNumber);
						contactDetail.setMobilePhone(tempPhone.getPhoneNum());
					}
					else if ("HOME".equalsIgnoreCase(tempPhone.getPhoneType()))
					{
						PhoneNumber homeNumber = new PhoneNumber();
						String areaCode = tempPhone.getPhoneNum().substring(0, 2);
						String phoneNo = tempPhone.getPhoneNum().substring(2, 10);
						homeNumber.setAreaCode(areaCode);
						homeNumber.setPhoneNumber(phoneNo);
						contactDetail.setHomeNumber(homeNumber);
						contactDetail.setHomePhone(tempPhone.getPhoneNum());
					}
					else if ("WORK".equalsIgnoreCase(tempPhone.getPhoneType()))
					{
						PhoneNumber workNumber = new PhoneNumber();
						String areaCode = tempPhone.getPhoneNum().substring(0, 2);
						String phoneNo = tempPhone.getPhoneNum().substring(2, 10);
						workNumber.setAreaCode(areaCode);
						workNumber.setPhoneNumber(phoneNo);
						contactDetail.setWorkNumber(workNumber);
						contactDetail.setWorkPhone(tempPhone.getPhoneNum());
					}
				}
				else {
					if ("MOBILE".equalsIgnoreCase(tempPhone.getPhoneType()))
					{
						contactDetail.setMobileNumber(oldContactDetail.getMobileNumber());
						contactDetail.setMobilePhone(oldContactDetail.getMobilePhone());
					}
					else if ("HOME".equalsIgnoreCase(tempPhone.getPhoneType()))
					{
						contactDetail.setHomeNumber(oldContactDetail.getHomeNumber());
						contactDetail.setHomePhone(oldContactDetail.getHomePhone());
					}
					else if ("WORK".equalsIgnoreCase(tempPhone.getPhoneType()))
					{
						contactDetail.setWorkNumber(oldContactDetail.getWorkNumber());
						contactDetail.setWorkPhone(oldContactDetail.getWorkPhone());
					}
				}
			}
		}
		contactDetail.setEmail(oldContactDetail.getEmail());
		contactDetail.setPrimaryProfile(oldContactDetail.getPrimaryProfile());
		contactDetail.setCustomerType(oldContactDetail.getCustomerType());
		contactDetail.setCustTypeInd(oldContactDetail.getCustTypeInd());
		contactDetail.setCustomerNumber(oldContactDetail.getCustomerNumber());
		contactDetail.setFaxNumber(oldContactDetail.getFaxNumber());
		contactDetail.setEmailConsent(oldContactDetail.isEmailConsent());
		contactDetail.setResidentialAddress(oldContactDetail.getResidentialAddress());
		contactDetail.setMailingAddress(oldContactDetail.getMailingAddress());
		return contactDetail;
	}
	
	public Address getAddress(AddressReq addressReq) throws BusinessException
	{
		Address address = new Address();
		address.setLine1(StringMethods.isEmptyString(addressReq.getLine1())?"":addressReq.getLine1());
		address.setLine2(StringMethods.isEmptyString(addressReq.getLine2())?"":addressReq.getLine2());
		address.setLine3(StringMethods.isEmptyString(addressReq.getLine3())?"":addressReq.getLine3());		
		address.setSuburb(StringMethods.isEmptyString(addressReq.getSuburb())?"":addressReq.getSuburb());
		address.setState(StringMethods.isEmptyString(addressReq.getState())?"":addressReq.getState());
		address.setPostZipcode(StringMethods.isEmptyString(addressReq.getPostCode())?"":addressReq.getPostCode());
		address.setCountryName(StringMethods.isEmptyString(addressReq.getCountryName())?"":addressReq.getCountryName());
		address.setCountry(StringMethods.isEmptyString(addressReq.getCountryName())?"":getCountryCode(addressReq.getCountryName()));
		return address;
	}

	public IMBResp populateResponse(ContactDetail contactDetail, boolean isEditable, String origin) throws BusinessException
	{
		ContactDetailsResp contactDetailsResp = new ContactDetailsResp();
		contactDetailsResp.setEditable(isEditable);
		// contactDetailsResp.setContactInfoResp(populateContact(contactDetail,isEditable,
		// contactDetailsResp));
		if (contactDetail.getResidentialAddress() != null)
		{
			if (contactDetail.getMailingAddress() != null)
			{
				if (StringMethods.isValidString(contactDetail.getMailingAddress().getCountry()))
					contactDetail.getMailingAddress().setCountry(contactDetail.getMailingAddress().getCountry().trim());
				if (contactDetail.getResidentialAddress().toString().equalsIgnoreCase(contactDetail.getMailingAddress().toString()))
					contactDetailsResp.setSameAddress(true);
			} else
			{
				contactDetail.setMailingAddress(contactDetail.getResidentialAddress());
				contactDetailsResp.setSameAddress(true);
			}
		}
		
		contactDetailsResp = populateContact(contactDetail, contactDetailsResp, origin);

		if (isEditable)
		{
			contactDetailsResp.setStates(getStateList());
			contactDetailsResp.setCountries((ArrayList) getCountryNameList());
		}
		if ( CustomerTypes.TYPE_GHS.equalsIgnoreCase(contactDetail.getCustomerType()))
			contactDetailsResp.setEditAddress(true);
		else
			contactDetailsResp.setEditAddress(false);		
		
		//if(IBankParams.isChangeStmtAddrSwitchOn()){
			contactDetailsResp.setShowDisclaimer(true);
		//}
		//else
		//{
		//	contactDetailsResp.setShowDisclaimer(false);
		//}
		
		return contactDetailsResp;
	}
	
	public boolean isCustomerOver14(Customer customer){
	    Calendar today = Calendar.getInstance();
	    today.add(Calendar.YEAR, -14);
	    Calendar birth = Calendar.getInstance();
	    boolean resp = false;
	    if (customer.getBirthDate() != null){
	    	birth.setTime(customer.getBirthDate());
	
	    	if (birth.getTime().getTime() > today.getTime().getTime()){
	    		resp = false;
	    	}else{
	    		resp = true;
	    	}
	    }	
	    return resp;
	}	
	
	public ContactDetailsResp populateContact(ContactDetail contactDetail, ContactDetailsResp resp, String origin)
	{
		return populateContact(contactDetail,resp,origin,null,null,null);
	}

	public ContactDetailsResp populateContact(ContactDetail contactDetail, ContactDetailsResp resp, String origin, ServiceStationVO serviceStationVO, ArrayList<AccountKeyInfoResp> accDisplayList,ArrayList<AccountKeyInfoResp> accNotDisplayList)
	{
		// ContactInfoResp mbContact = new ContactInfoResp();
		ArrayList<AddressResp> addresses = new ArrayList<AddressResp>();
		
		if (contactDetail.getResidentialAddress() != null)
			addresses.add(populateAddress(contactDetail.getResidentialAddress(), "RES"));

		if (contactDetail.getMailingAddress() != null && ! resp.isSameAddress())
		{
			addresses.add(populateAddress(contactDetail.getMailingAddress(), "MAIL"));
		}

		ArrayList<au.com.stgeorge.mbank.model.common.PhoneInfoResp> phones = new ArrayList<au.com.stgeorge.mbank.model.common.PhoneInfoResp>();

		PhoneInfoResp phoneInfo = null;
		boolean isPhoneExists = false;
		if (contactDetail.getMobileNumber() != null)
		{
			phoneInfo = new PhoneInfoResp();
			phoneInfo.setPhoneType("MOBILE");
			if ( StringMethods.isEmptyString(contactDetail.getMobileNumber().getPhoneNumber() ) )
			{
				phoneInfo.setPhoneNum("");
			}
			else
			{
				phoneInfo.setPhoneNum(maskPhoneNumber(contactDetail.getMobileNumber().getAreaCode() + contactDetail.getMobileNumber().getPhoneNumber()));
				isPhoneExists = true;
			}
			phones.add(phoneInfo);
		}
		if (contactDetail.getHomeNumber() != null)
		{
			phoneInfo = new PhoneInfoResp();
			phoneInfo.setPhoneType("HOME");
			if ( StringMethods.isEmptyString(contactDetail.getHomeNumber().getPhoneNumber()) )
			{
				phoneInfo.setPhoneNum("" );
			}
			else
			{
				phoneInfo.setPhoneNum("(" + contactDetail.getHomeNumber().getAreaCode() + ") "
						+ maskPhoneNumber(contactDetail.getHomeNumber().getPhoneNumber()));
				isPhoneExists = true;
			}
			phones.add(phoneInfo);
		}
		if (contactDetail.getWorkNumber() != null)
		{
			phoneInfo = new PhoneInfoResp();
			phoneInfo.setPhoneType("WORK");
			if ( StringMethods.isEmptyString(contactDetail.getWorkNumber().getPhoneNumber()) )
			{
				phoneInfo.setPhoneNum("");
			}
			else
			{
				phoneInfo.setPhoneNum("(" + contactDetail.getWorkNumber().getAreaCode() + ") "
						+ maskPhoneNumber(contactDetail.getWorkNumber().getPhoneNumber()));
				isPhoneExists = true;
			}
			
			phones.add(phoneInfo);
		}
		
		
		if ( ! isPhoneExists )
		{
			String msg = MBAppUtils.getMessage(origin, BusinessException.IBANK_SECURE_NO_PHONE_EXIST);
			resp.setPageInfoMsg( "code:"+BusinessException.IBANK_SECURE_NO_PHONE_EXIST + "|message:" +  msg);
		}
			
		if (phones.size() > 0)
			resp.setPhones(phones);
		if (addresses.size() > 0)
			resp.setAddresses(addresses);
		if ( CustomerTypes.TYPE_GHS.equalsIgnoreCase(contactDetail.getCustomerType()))
			resp.setEditAddress(true);
		else
			resp.setEditAddress(false);		
		resp.setEmail(contactDetail.getEmail());
		
		if(null!=serviceStationVO)
		{			
			populateServiceStationResponse(resp,serviceStationVO);
		}
		if(null!=accDisplayList){
			resp.setEligibleAccounts(accDisplayList);
		}
		if(null!=accNotDisplayList){
			resp.setNotEligibleAccounts(accNotDisplayList);
		}
		
		return resp;
	}

	private AddressResp populateAddress(Address address, String type)
	{
		AddressResp mbAddress = new AddressResp();
		if (address != null)
		{
			mbAddress.setAddrType(type);
			mbAddress.setCountryName(address.getCountryName());
			mbAddress.setLine1(address.getLine1());
			mbAddress.setLine2(address.getLine2());
			mbAddress.setLine3(address.getLine3());

			mbAddress.setPostCode(address.getPostZipcode());
			mbAddress.setState(address.getState());
			mbAddress.setSuburb(address.getSuburb());
		}
		return mbAddress;

	}

	public ArrayList<String> getStateList()
	{
		ArrayList<String> stateList = (ArrayList<String>) IBankParams.getStates();
		return stateList;
	}

	public ArrayList<String> getCountryNameList() throws BusinessException
	{
		ArrayList<String> countryNameList = new ArrayList<String>();
		Collection<String> tempCountryList = getCountryList();
		if (tempCountryList != null && tempCountryList.size() > 0)
		{
			Iterator<String> iterator = tempCountryList.iterator();
			while (iterator.hasNext())
			{
				String country = (String) iterator.next();
				String temp[] = country.split(",");
//				countryNameList.add(country.trim());
				if ( temp.length == 3 )
					countryNameList.add(temp[1] + ","+ temp[2] );
				else
					countryNameList.add(temp[1] );
			}
		}
		return countryNameList;
	}

	public Collection<String> getCountryList()  throws BusinessException
	{
		ArrayList<String> countryNameList = null;
	
		try
		{
			Collection<CountryListVO> tempCountryList = IBankParams.getCountryList();
			if (tempCountryList != null && tempCountryList.size() > 0)
			{
				countryNameList = new ArrayList<String>();
				Iterator<CountryListVO> iterator = tempCountryList.iterator();
				while (iterator.hasNext())
				{
					CountryListVO country = (CountryListVO) iterator.next();
					if ( StringMethods.isEmptyString(country.getCountryCode()) )
					{
						country.setCountryCode(" ");
					}
					String tempCountry = country.getCountryCode() + ","+ country.getCountryName();
					countryNameList.add(tempCountry);
				}
			}
		}
		catch (BusinessException e )
		{
       Logger.debug("Unable to load AML Country List.. Using the list from Codes ", this.getClass());			
       if ( countryNameList != null )
       {
      	 countryNameList.clear();
       }

		}
		if (countryNameList == null || countryNameList.size() < 10 )
		{
			countryNameList = new ArrayList<String>();
			Collection<CodesVO>  tempCountryList = IBankParams.getCodesDataList(IBankParams.DEFAULT_ORIGIN, IBankParams.CATEGORY_COUNTRY);
			for(CodesVO codesVO : tempCountryList) {
//				countryNameList.add(codesVO.getMessage());
				if ( StringMethods.isEmptyString(codesVO.getCode()) )
				{
					codesVO.setCode(" ");
				}
				String tempCountry = codesVO.getCode() + ","+ codesVO.getMessage();
				countryNameList.add(tempCountry);
		  }
		}
		return countryNameList;
	}

	public String getCountryCode(String paramCountryName)throws BusinessException
	{
		if (StringMethods.isEmptyString(paramCountryName) || paramCountryName.equalsIgnoreCase("Australia"))
			return " ";
		String countryName = paramCountryName.trim();
		Collection<String> tempCountryList = getCountryList();
		String countryCode = null;
		if (tempCountryList != null && tempCountryList.size() > 0)
		{
			Iterator<String> iterator = tempCountryList.iterator();
			while (iterator.hasNext())
			{
				String country = (String) iterator.next();
				String temp[] = country.split(",");
				if ( temp.length == 3 )
					country = (temp[1] + ","+ temp[2] );
				else
					country = temp[1];

				
				if (  countryName.equalsIgnoreCase( country ))
				{
					countryCode = temp[0];
					break;
				}

			}
		}
		if (StringMethods.isEmptyString(countryCode))
			Logger.error("Country code not found for country " + paramCountryName, this.getClass());
		return countryCode;
	}

	public ContactDetail populateNewContactDetails(ContactDetail newContactDetail, Customer tempCustomer)
	{
		Customer customer = tempCustomer;
		ContactDetail sessContactDetail = customer.getContactDetail();
		sessContactDetail.setEmail(newContactDetail.getEmail());
		sessContactDetail.setResidentialAddress(newContactDetail.getResidentialAddress());
		sessContactDetail.setMailingAddress(newContactDetail.getMailingAddress());
		return sessContactDetail;
	}

	public IMBResp populateNewContactResponse(ContactDetail contactDetail, boolean isModified)
	{
		ContactDetailsResp contactDetailsResp = new ContactDetailsResp();
		contactDetailsResp.setModified(isModified);

		ArrayList<au.com.stgeorge.mbank.model.common.AddressResp> addresses = new ArrayList<au.com.stgeorge.mbank.model.common.AddressResp>();
		
		if (contactDetail.getResidentialAddress() != null)
			addresses.add(populateAddress(contactDetail.getResidentialAddress(), "RES"));

		if (contactDetail.getMailingAddress() != null)
			addresses.add(populateAddress(contactDetail.getMailingAddress(), "MAIL"));

		contactDetailsResp.setAddresses(addresses);
		if (contactDetail.getEmail() != null)
			contactDetailsResp.setEmail(contactDetail.getEmail());

		return contactDetailsResp;
	}

	public ArrayList<Boolean> isModified(ContactDetail oldContactDetails, ContactDetail newContactDetail , boolean isSameAddress) throws BusinessException
	{
		ArrayList<Boolean> modifiedAttributesList=new ArrayList<Boolean>();
		boolean isModified = false;
		boolean isModifiedAddressOnly=false;
		boolean isModifiedEmailOnly=false;
		Address oldMailingAddress =oldContactDetails.getMailingAddress();
		Address oldResAddress =oldContactDetails.getResidentialAddress();
		String oldEmail = oldContactDetails.getEmail();

		if ( oldMailingAddress == null )
			oldMailingAddress = new Address();
		
		if ( (CustomerTypes.TYPE_GHS.equalsIgnoreCase(oldContactDetails.getCustomerType()))  && isSameAddress )
		{
			if ( oldContactDetails.getMailingAddress() == null )
				newContactDetail.setMailingAddress( newContactDetail.getResidentialAddress() );
			else
			{
				
				Logger.debug( " Old "+ oldContactDetails.getMailingAddress().toString() + " New " + newContactDetail.getResidentialAddress().toString(), this.getClass());
				
				if ( ! oldContactDetails.getMailingAddress().toString().equalsIgnoreCase( newContactDetail.getResidentialAddress().toString()) )
					newContactDetail.setMailingAddress( newContactDetail.getResidentialAddress() );
			}
		}

		if ( (CustomerTypes.TYPE_GHS.equalsIgnoreCase(oldContactDetails.getCustomerType())) && oldResAddress != null && newContactDetail.getResidentialAddress() != null && ! oldResAddress.toString().equals(newContactDetail.getResidentialAddress().toString()))
		{
			isModified = true;
			isModifiedAddressOnly=true;
		}
		else if ( (CustomerTypes.TYPE_GHS.equalsIgnoreCase(oldContactDetails.getCustomerType())) && oldMailingAddress != null &&  newContactDetail.getMailingAddress() != null && ! oldMailingAddress.toString().equals(newContactDetail.getMailingAddress().toString()))
		{
			isModified = true;
			isModifiedAddressOnly=true;
			newContactDetail.setMailingAddrModified(true);

		}
		else if ( oldEmail != null && ! newContactDetail.getEmail().equals(oldEmail) )
		{
			isModified = true;
			isModifiedEmailOnly=true;
		}
		else if ( oldEmail == null && newContactDetail.getEmail().length() > 0 )
		{
			isModified = true;
			isModifiedEmailOnly=true;
		}
		
		modifiedAttributesList.add(0,isModified);
		modifiedAttributesList.add(1,isModifiedAddressOnly);
		modifiedAttributesList.add(2,isModifiedEmailOnly);
		
		return modifiedAttributesList;
	}
	
	public boolean isModifiedEmailOnly(ContactDetail oldContactDetails, ContactDetail newContactDetail , boolean isSameAddress) throws BusinessException
	{
		boolean isModifiedEmailOnly = false;
		Address oldMailingAddress =oldContactDetails.getMailingAddress();
		Address oldResAddress =oldContactDetails.getResidentialAddress();
		String oldEmail = oldContactDetails.getEmail();

		if(!isSameAddress){
			if(CustomerTypes.TYPE_GHS.equalsIgnoreCase(oldContactDetails.getCustomerType()) 
					&& oldResAddress != null 
					&& newContactDetail.getResidentialAddress() != null 
					&& oldResAddress.toString().equals(newContactDetail.getResidentialAddress().toString())
					&& oldMailingAddress != null 
					&& newContactDetail.getMailingAddress() != null 
					&& oldMailingAddress.toString().equals(newContactDetail.getMailingAddress().toString())
					&& oldEmail != null && ! newContactDetail.getEmail().equals(oldEmail) )
			{
				isModifiedEmailOnly = true;
			}
		}
		else{
			
			if(CustomerTypes.TYPE_GHS.equalsIgnoreCase(oldContactDetails.getCustomerType()) 
					&& oldResAddress != null 
					&& newContactDetail.getResidentialAddress() != null 
					&& oldResAddress.toString().equals(newContactDetail.getResidentialAddress().toString())
					&& newContactDetail.getMailingAddress() != null 
					&& oldMailingAddress.toString().equals(newContactDetail.getMailingAddress().toString())
					&& oldEmail != null && ! newContactDetail.getEmail().equals(oldEmail) )
			{
				isModifiedEmailOnly = true;
			}
		}

		return isModifiedEmailOnly;
	}

	public boolean isValidPostCode(Address address, Customer customer)
	{

		String value = address.getPostZipcode();
		String country = address.getCountry();

		String state = address.getState();

		if (!CustomerTypes.TYPE_GHS.equalsIgnoreCase(customer.getContactDetail().getCustomerType()))
		{
			return true;
		}
		if (!StringMethods.isEmptyString(country))
		{
			return true;
		}

		int postCode = 0;
		try
		{
			postCode = Integer.parseInt(value);
		} catch (NumberFormatException ex)
		{
			return false;
		}

		if (StringMethods.isEmptyString(country))
		{
			if (state.equals("NSW"))
			{
				if (((postCode < 1000) | (postCode > 1999)) & ((postCode < 2000) | (postCode > 2599)) & ((postCode < 2619) | (postCode > 2899))
						& ((postCode < 2921) | (postCode > 2999)))
				{
					return false;
				} else
					return true;
			} else if (state.equals("ACT"))
			{
				if (((postCode < 200) | (postCode > 299)) & ((postCode < 2600) | (postCode > 2618)) & ((postCode < 2900) | (postCode > 2920)))
				{
					return false;
				} else
					return true;

			} else if (state.equals("VIC"))
			{
				if (((postCode < 3000) | (postCode > 3999)) & ((postCode < 8000) | (postCode > 8999)))
				{
					return false;
				} else
					return true;
			} else if (state.equals("QLD"))
			{
				if (((postCode < 4000) | (postCode > 4999)) & ((postCode < 9000) | (postCode > 9799)))
				{
					return false;
				} else
					return true;
			} else if (state.equals("SA"))
			{
				if ((postCode < 5000) | (postCode > 5999))
				{
					return false;
				} else
					return true;
			} else if (state.equals("WA"))
			{
				if ((postCode < 6000) | (postCode > 6999))
				{
					return false;
				} else
					return true;
			} else if (state.equals("TAS"))
			{
				if ((postCode < 7000) | (postCode > 7999))
				{
					return false;
				} else
					return true;

			} else if (state.equals("NT"))
			{
				if ((postCode < 800) | (postCode > 999))
				{
					return false;
				} else
					return true;
			}
		}
		return true;
	}

	private static String maskPhoneNumber(String phoneNumber)
	{
		String phoneNo = "";
		if (!StringMethods.isEmptyString(phoneNumber))
		{
			int len = phoneNumber.length();
			if (len > 4)
			{
				for (int i = 0; i < len - 4; i++)
				{
					phoneNo = phoneNo + "#";
				}

				phoneNo = phoneNo + phoneNumber.substring(len - 4);

			}
		}
		return phoneNo;
	}
	
	public long getInsertionPointCode(String insertionPointString){
		List<CodesVO> CodesVOList = (List<CodesVO>) IBankParams.getCodesDataList(IBankParams.DEFAULT_ORIGIN, ServicetationConstants.CD_CATEGORY_SERVICETATION_INSERTION_PT);
		long insertionPointValue = 0;
		for(CodesVO codesVO : CodesVOList){
			if(codesVO.getMessage().trim().equalsIgnoreCase(insertionPointString)){
				if(StringMethods.isValidString(codesVO.getCode())){
					insertionPointValue = Long.parseLong(codesVO.getCode());
					break;
				}
			}
		}
		if(insertionPointValue == 0){
			Logger.warn("NO match found in RELEASECODES table for the insertion point "+insertionPointString, this.getClass());
		}
		return insertionPointValue;
	}
	
	protected ContactDetailsResp populateServiceStationResponse(ContactDetailsResp resp,ServiceStationVO serviceStationVO) 
	{
		ServiceStationResp ssResponse = null;
		if(null!=serviceStationVO)
		{
			ServiceStationResp serviceResponse = new ServiceStationResp();
			if(null!=serviceStationVO.getContent())
			{
				serviceResponse.setContent(serviceStationVO.getContent());
			}			
			if(null!=serviceStationVO.getServiceStationMsg())
			{
				serviceResponse.setInsertionPointValue(new Long(serviceStationVO.getServiceStationMsg().getInsertionPointValue()).toString());	
			}
			if(null!=serviceStationVO.getSubject())
			{
				serviceResponse.setSubject(serviceStationVO.getSubject());
			}
			if(null!=serviceStationVO.getServiceStationMsg().getFunctionLink())
			{
				serviceResponse.setFunctionLink(serviceStationVO.getServiceStationMsg().getFunctionLink());
			}
			if(null!=serviceStationVO.getServiceStationMsg().getMessageAction())
			{
				serviceResponse.setMessageAction(serviceStationVO.getServiceStationMsg().getMessageAction());
			}
			if(null!=serviceStationVO.getServiceStationMsg())
			{
			    serviceResponse.setMsgID(new Long(serviceStationVO.getServiceStationMsg().getMsgID()).toString());
			}
			
			resp.setServiceStation(serviceResponse);			
		}		
	  else
		{
			resp.setServiceStation(ssResponse);	
		}		
		return resp;
	}
	
	
	public boolean isPhoneNumberModified(ContactDetail oldContactDetails, ContactDetail newContactDetail) throws BusinessException
	{
		
		boolean isModified = false;
		
		if(!oldContactDetails.getMobileNumber().equals(newContactDetail.getMobileNumber())
				|| !oldContactDetails.getHomeNumber().equals(newContactDetail.getHomeNumber())
				|| !oldContactDetails.getWorkNumber().equals(newContactDetail.getWorkNumber())) 
		{
			isModified = true;			
		}
		
		return isModified;
	}
	

	/**
	 * Method to populate SAFI VO for update phone
	 *  
	 * @param httpRequest
	 * @param mobileSession
	 * @param commonData
	 * @param request
	 * @return SafiUpdatePhoneVO
	 * @throws BusinessException
	 */
	public SafiUpdatePhoneVO populateSafiVO(HttpServletRequest httpRequest, MobileSession mobileSession, IBankCommonData commonData, PhoneDetailReq request) throws BusinessException {
		String validDecodedPrint;
		String devicePrint;
		Logger.debug("SAFI : populateSafiVO Device Print" +request.getDevicePrint(), this.getClass()) ;
		validDecodedPrint = SafiUtil.validateDevicePrint(request.getDevicePrint());
		devicePrint = validDecodedPrint != null ? request.getDevicePrint():null;
		
		SafiUpdatePhoneVO safiVO = new SafiUpdatePhoneVO();
		
		if(null == devicePrint && null != mobileSession.getSafiLogonInfo() && null != mobileSession.getSafiLogonInfo().getDevicePrint()) {
			devicePrint = mobileSession.getSafiLogonInfo().getDevicePrint();
			Logger.debug("SAFI : populateSafiVO :  Device Print from request was null so getting from mobileSession.getSafiLogonInfo():" +devicePrint, this.getClass()) ;
		}
			
		boolean isMobileApp = ((logonHelper.loadCordova(httpRequest)) == -1) ? false:true;
		Logger.debug("SAFI : populateSafiVO: validDecodedPrint: " +validDecodedPrint + " devicePrint: "+devicePrint+" isMobileApp: "+isMobileApp, this.getClass()) ;
			
		safiVO = SafiWebHelper.populateSafiVOForPhoneUpdate(httpRequest, devicePrint, commonData, isMobileApp, safiVO, mobileSession);
		
		return safiVO;
	}	
	
	/**
	 * Returns help desk contact numbers
	 * @param mobileSession
	 * @return
	 */
	public String[] getContactNumber(MobileSession mobileSession) {
		OriginsVO myOriginVO = IBankParams.getOrigin(mobileSession.getOrigin());
		OriginsVO baseOrigin = IBankParams.getOrigin(myOriginVO.getBankName());
		String[] values = { baseOrigin.getPhone() };
		return values;
	}
	
	public void handleSafiResponseinCookies(HttpServletRequest httpServletRequest,HttpServletResponse httpServletResponse, SafiRespVO safiRespVO){
		if(safiRespVO != null){
			Cookie pmdata2 = SafiWebHelper.readCookies(httpServletRequest);
			Cookie newCookie = SafiWebHelper.createOrUpdatePmdata2Cookie(httpServletRequest,pmdata2,safiRespVO.getDeviceToken());
			httpServletResponse.addCookie(newCookie);
		}
	}
	
	public String populateChangedPhoneNumbers(ContactDetail contactDetailsNew, ContactDetail contactDetailsOld, String devicePrintForLogger) {
		StringBuffer logBuffer = new StringBuffer();
		
			if(isPhoneNumberChanged(contactDetailsNew.getMobileNumber(), contactDetailsOld.getMobileNumber())){
				logBuffer.append(DigitalSecLogger.OLD_MOBILE_NUMBER)
				.append(DigitalSecLogger.DELIMITER_COLON)
				.append(contactDetailsOld.getMobileNumber().getAreaCode()+contactDetailsOld.getMobileNumber().getPhoneNumber())
				.append(DigitalSecLogger.DELIMITER_COMMA)
				.append(DigitalSecLogger.NEW_MOBILE_NUMBER)
				.append(DigitalSecLogger.DELIMITER_COLON)
				.append(contactDetailsNew.getMobileNumber().getAreaCode()+contactDetailsNew.getMobileNumber().getPhoneNumber())
				.append(DigitalSecLogger.DELIMITER_COMMA);
			}
			
			if(isPhoneNumberChanged(contactDetailsNew.getHomeNumber(), contactDetailsOld.getHomeNumber())){
				logBuffer.append(DigitalSecLogger.OLD_HOME_NUMBER)
				.append(DigitalSecLogger.DELIMITER_COLON)
				.append(contactDetailsOld.getHomeNumber().getAreaCode()+contactDetailsOld.getHomeNumber().getPhoneNumber())
				.append(DigitalSecLogger.DELIMITER_COMMA)
				.append(DigitalSecLogger.NEW_HOME_NUMBER)
				.append(DigitalSecLogger.DELIMITER_COLON)
				.append(contactDetailsNew.getHomeNumber().getAreaCode()+contactDetailsNew.getHomeNumber().getPhoneNumber())
				.append(DigitalSecLogger.DELIMITER_COMMA);
			}
			
			if(isPhoneNumberChanged(contactDetailsNew.getWorkNumber(), contactDetailsOld.getWorkNumber())){
				logBuffer.append(DigitalSecLogger.OLD_WORK_NUMBER)
				.append(DigitalSecLogger.DELIMITER_COLON)
				.append(contactDetailsOld.getWorkNumber().getAreaCode()+contactDetailsOld.getWorkNumber().getPhoneNumber())
				.append(DigitalSecLogger.DELIMITER_COMMA)
				.append(DigitalSecLogger.NEW_WORK_NUMBER)
				.append(DigitalSecLogger.DELIMITER_COLON)
				.append(contactDetailsNew.getWorkNumber().getAreaCode()+contactDetailsNew.getWorkNumber().getPhoneNumber())
				.append(DigitalSecLogger.DELIMITER_COMMA);
			}
			
			if(!StringMethods.isEmptyString(devicePrintForLogger)) {
				logBuffer.append(DigitalSecLogger.SDK_DEVICE_PRINT)
				.append(DigitalSecLogger.DELIMITER_COLON)
				.append(devicePrintForLogger);
			}
			
			if(logBuffer.lastIndexOf(",")==logBuffer.length()-1) {
				logBuffer.replace(logBuffer.lastIndexOf(","),logBuffer.length(),"");
			}
		
		return logBuffer.toString();
	}
	
	private boolean isPhoneNumberChanged(PhoneNumber newPhone, PhoneNumber oldPhone) {
		if(!newPhone.getAreaCode().trim().equals(oldPhone.getAreaCode().trim()) || !newPhone.getPhoneNumber().trim().equals(oldPhone.getPhoneNumber().trim())) {
			return true;
		}
		return false;
	}
	
	public ContactDetail getPhoneDetailsNew(PhoneDetailReq req, Customer customer) throws BusinessException
	{
		ContactDetail oldContactDetail = customer.getContactDetail();
		ContactDetail contactDetail = new ContactDetail();
		
		if ( customer.isCustomerOfTypeGHS() )
		{

			ArrayList<PhoneReq> phoneList = req.getPhones();
			Iterator<PhoneReq> it = phoneList.iterator();
	
			while (it.hasNext())
			{
				PhoneReq tempPhone = it.next();
				if (tempPhone.getIsPhnNoChange()) {
					if ("MOBILE".equalsIgnoreCase(tempPhone.getPhoneType()))
					{
						PhoneNumber mobNumber = new PhoneNumber();
						String areaCode = "";
						String phoneNo = "";
						//if(tempPhone.getPhoneNum()!=null && tempPhone.getPhoneNum()!="") {
							areaCode = tempPhone.getPhoneNum().substring(0, 4);
							phoneNo = tempPhone.getPhoneNum().substring(4, 10);
						//}
						mobNumber.setAreaCode(areaCode);
						mobNumber.setPhoneNumber(phoneNo);					
						contactDetail.setMobileNumber(mobNumber);
						contactDetail.setMobilePhone(tempPhone.getPhoneNum());
					}
					else if ("HOME".equalsIgnoreCase(tempPhone.getPhoneType()))
					{
						PhoneNumber homeNumber = new PhoneNumber();
						String areaCode = ""; 
						String phoneNo = "";
						if(tempPhone.getPhoneNum()!=null && tempPhone.getPhoneNum()!="") {
						 areaCode = tempPhone.getPhoneNum().substring(0, 2);
						 phoneNo = tempPhone.getPhoneNum().substring(2, 10);
						}
						homeNumber.setAreaCode(areaCode);
						homeNumber.setPhoneNumber(phoneNo);
						
						contactDetail.setHomeNumber(homeNumber);
						contactDetail.setHomePhone(tempPhone.getPhoneNum());
					}
					else if ("WORK".equalsIgnoreCase(tempPhone.getPhoneType()))
					{
						PhoneNumber workNumber = new PhoneNumber();
						String areaCode = "";
						String phoneNo = "";
						if(tempPhone.getPhoneNum()!=null && tempPhone.getPhoneNum()!="") {
							areaCode = tempPhone.getPhoneNum().substring(0, 2);
							phoneNo = tempPhone.getPhoneNum().substring(2, 10);
						}
						workNumber.setAreaCode(areaCode);
						workNumber.setPhoneNumber(phoneNo);
						contactDetail.setWorkNumber(workNumber);
						contactDetail.setWorkPhone(tempPhone.getPhoneNum());
					}
				}
				else {
					if ("MOBILE".equalsIgnoreCase(tempPhone.getPhoneType()))
					{
						contactDetail.setMobileNumber(oldContactDetail.getMobileNumber());
						contactDetail.setMobilePhone(oldContactDetail.getMobilePhone());
					}
					else if ("HOME".equalsIgnoreCase(tempPhone.getPhoneType()))
					{
						contactDetail.setHomeNumber(oldContactDetail.getHomeNumber());
						contactDetail.setHomePhone(oldContactDetail.getHomePhone());
					}
					else if ("WORK".equalsIgnoreCase(tempPhone.getPhoneType()))
					{
						contactDetail.setWorkNumber(oldContactDetail.getWorkNumber());
						contactDetail.setWorkPhone(oldContactDetail.getWorkPhone());
					}
				}
			}
		}
		contactDetail.setEmail(oldContactDetail.getEmail());
		contactDetail.setPrimaryProfile(oldContactDetail.getPrimaryProfile());
		contactDetail.setCustomerType(oldContactDetail.getCustomerType());
		contactDetail.setCustTypeInd(oldContactDetail.getCustTypeInd());
		contactDetail.setCustomerNumber(oldContactDetail.getCustomerNumber());
		contactDetail.setFaxNumber(oldContactDetail.getFaxNumber());
		contactDetail.setEmailConsent(oldContactDetail.isEmailConsent());
		contactDetail.setResidentialAddress(oldContactDetail.getResidentialAddress());
		contactDetail.setMailingAddress(oldContactDetail.getMailingAddress());
		return contactDetail;
	}
	public ContactDetail getContactDetailNew(ContactDetailsReq req, Customer customer) throws BusinessException
	{
		ContactDetail oldContactDetail = customer.getContactDetail();
		ContactDetail contactDetail = new ContactDetail();

		if ( customer.isGHSCustomer() )
		{

			if(req.getChangeType()!=null && ("A").equalsIgnoreCase(req.getChangeType())) {

			ArrayList<AddressReq> addresList = req.getAddresses();
			Iterator<AddressReq> it = addresList.iterator();
	
			while (it.hasNext())
			{
				AddressReq tempAdd = it.next();
				Address resAddress=null;
				if ("RES".equalsIgnoreCase(tempAdd.getAddrType()))
				{
					resAddress = getAddress(tempAdd);
					if ( oldContactDetail.getResidentialAddress()!= null && oldContactDetail.getResidentialAddress().toString().equalsIgnoreCase( resAddress.toString() ))
					{
						contactDetail.setResidentialAddress(oldContactDetail.getResidentialAddress());
					}
					else
					{
						contactDetail.setResidentialAddress(resAddress);
					}
				}
				if("MAIL".equalsIgnoreCase(tempAdd.getAddrType()))
				{
					Address mailAddress = getAddress(tempAdd);
					if ( oldContactDetail.getMailingAddress() != null && oldContactDetail.getMailingAddress().toString().equalsIgnoreCase(mailAddress.toString()) )
					{
						contactDetail.setMailingAddress(oldContactDetail.getMailingAddress());
					}
					else
					{
						contactDetail.setMailingAddress(mailAddress);
					}
				}
/*				if(req.isSameAddress())
				{
					contactDetail.setMailingAddress(resAddress);
				}  */
			}
		  }else {
			   contactDetail.setMailingAddress(oldContactDetail.getMailingAddress());
			   contactDetail.setResidentialAddress(oldContactDetail.getResidentialAddress());
		   }
		}
		if(req.getChangeType()!=null && ("E").equalsIgnoreCase(req.getChangeType())) {
			contactDetail.setEmail(req.getEmail());
		}else {
			contactDetail.setEmail(oldContactDetail.getEmail());
		}
		//contactDetail.setEmail(req.getEmail()==null?"":req.getEmail());
		contactDetail.setPrimaryProfile(customer.getContactDetail().getPrimaryProfile());
		contactDetail.setCustomerType(customer.getContactDetail().getCustomerType());
		contactDetail.setCustTypeInd(customer.getContactDetail().getCustTypeInd());
		contactDetail.setCustomerNumber(customer.getContactDetail().getCustomerNumber());
		contactDetail.setMobileNumber(customer.getContactDetail().getMobileNumber());
		contactDetail.setHomeNumber(customer.getContactDetail().getHomeNumber());
		contactDetail.setWorkNumber(customer.getContactDetail().getWorkNumber());
		contactDetail.setFaxNumber(customer.getContactDetail().getFaxNumber());
		contactDetail.setEmailConsent(req.isEmailConsent());
		return contactDetail;
	}
	
	public ArrayList<Boolean> isModifiedNew(ContactDetail oldContactDetails, ContactDetail newContactDetail , boolean isSameAddress) throws BusinessException
	{
		ArrayList<Boolean> modifiedAttributesList=new ArrayList<Boolean>();
		boolean isModified = false;
		boolean isModifiedAddressOnly=false;
		boolean isModifiedEmailOnly=false;
		Address oldMailingAddress =oldContactDetails.getMailingAddress();
		Address oldResAddress =oldContactDetails.getResidentialAddress();
		String oldEmail = oldContactDetails.getEmail();

		if ( oldMailingAddress == null )
			oldMailingAddress = new Address();
		
		if ( (CustomerTypes.TYPE_GHS.equalsIgnoreCase(oldContactDetails.getCustomerType()))  && isSameAddress )
		{
			if ( oldContactDetails.getMailingAddress() == null )
				newContactDetail.setMailingAddress( newContactDetail.getResidentialAddress() );
			else
			{
				
				Logger.debug( " Old "+ oldContactDetails.getMailingAddress().toString() + " New " + newContactDetail.getResidentialAddress().toString(), this.getClass());
				
				if ( ! oldContactDetails.getMailingAddress().toString().equalsIgnoreCase( newContactDetail.getResidentialAddress().toString()) )
					newContactDetail.setMailingAddress( newContactDetail.getResidentialAddress() );
			}
		}

		if ( (CustomerTypes.TYPE_GHS.equalsIgnoreCase(oldContactDetails.getCustomerType())) && oldResAddress != null && newContactDetail.getResidentialAddress() != null && ! oldResAddress.toString().equalsIgnoreCase(newContactDetail.getResidentialAddress().toString()))
		{
			isModified = true;
			isModifiedAddressOnly=true;
		}
		else if ( (CustomerTypes.TYPE_GHS.equalsIgnoreCase(oldContactDetails.getCustomerType())) && oldMailingAddress != null &&  newContactDetail.getMailingAddress() != null && ! oldMailingAddress.toString().equalsIgnoreCase(newContactDetail.getMailingAddress().toString()))
		{
			isModified = true;
			isModifiedAddressOnly=true;
			newContactDetail.setMailingAddrModified(true);

		}
		else if ( oldEmail != null && ! newContactDetail.getEmail().equals(oldEmail) )
		{
			isModified = true;
			isModifiedEmailOnly=true;
		}
		else if ( oldEmail == null && newContactDetail.getEmail().length() > 0 )
		{
			isModified = true;
			isModifiedEmailOnly=true;
		}
		
		modifiedAttributesList.add(0,isModified);
		modifiedAttributesList.add(1,isModifiedAddressOnly);
		modifiedAttributesList.add(2,isModifiedEmailOnly);
		
		return modifiedAttributesList;
	}
	
}
