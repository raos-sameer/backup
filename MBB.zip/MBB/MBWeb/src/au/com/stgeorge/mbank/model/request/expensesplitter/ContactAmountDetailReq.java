package au.com.stgeorge.mbank.model.request.expensesplitter;


import java.util.List;

import javax.validation.constraints.Pattern;

import au.com.stgeorge.ibank.businessobject.BusinessException;
import au.com.stgeorge.mbank.model.common.IMBReq;
import au.com.stgeorge.mbank.model.common.ReqHeader;


public class ContactAmountDetailReq implements IMBReq {


	public String getContactID() {
		return contactID;
	}

	public void setContactID(String contactID) {
		this.contactID = contactID;
	}



	/**
	 * 
	 */
	private static final long serialVersionUID = -6798167197288990625L;
	/**
	 * 
	 */
	protected static final String AMT_PATTERN = "^[0-9]*\\.{0,1}(\\d{1,2}){0,1}$";
	protected static final String BLOCK_CHARS_PATTERN = "^[0-9A-Za-z',. &/\\-]*$";
	protected static final String MASK_NUMBERS = "^[0-9]+$";

	private ReqHeader header;
	
	@Pattern(regexp = MASK_NUMBERS, message = "" + BusinessException.WSVC_INVALID_INPUT_PARAM)
	private String contactID;

	public ReqHeader getHeader() {
		return header;
	}

	public void setHeader(ReqHeader header) {
		this.header = header;
	}

	
	public List<ExpenseGroupReq> getExpenseGrpList() {
		return expenseGrpList;
	}

	public void setExpenseGrpList(List<ExpenseGroupReq> expenseGrpList) {
		this.expenseGrpList = expenseGrpList;
	}



	private List<ExpenseGroupReq> expenseGrpList;
	
	

	
		
	
}
