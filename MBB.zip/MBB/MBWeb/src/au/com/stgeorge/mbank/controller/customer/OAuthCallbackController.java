package au.com.stgeorge.mbank.controller.customer;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.AbstractController;

import au.com.stgeorge.framework.common.logging.Logger;
import au.com.stgeorge.ibank.businessobject.BusinessException;
import au.com.stgeorge.ibank.businessobject.ResourceException;
import au.com.stgeorge.ibank.businessobject.mgrp.MgrpSAMLService;
import au.com.stgeorge.ibank.valueobject.SAMLStore;
import au.com.stgeorge.ibank.valueobject.transfer.IBankCommonData;
import au.com.stgeorge.mbank.controller.MainController;
import au.com.stgeorge.mbank.session.MobileSession;
import au.com.stgeorge.mbank.util.MBAppHelper;
import au.com.stgeorge.mbank.util.MBAppUtils;
import au.com.stgeorge.perflogger.PerformanceLogger;
import au.com.stgeorge.security.util.StringMethods;



@Controller
public class OAuthCallbackController extends AbstractController
{
	private static final String OAUTH_EXTERNAL = "oauthcallback";
	
	@Autowired
	private PerformanceLogger perfLogger;

	@Autowired
	private MBAppHelper mbAppHelper;
	
	@Autowired
	private LogonHelper logonHelper;

	@Override
	protected ModelAndView handleRequestInternal(HttpServletRequest request, HttpServletResponse response) throws Exception
	{
		Logger.debug("OAuthCallbackController - handleRequestInternal(). Request: " + request, this.getClass());	
		perfLogger.startAllLogs();
		String logName = MBAppUtils.getLogName(request);
		perfLogger.startLog(logName);
		
		
		ModelAndView model = null;
		
		
		MobileSession mbSession = null;
		
		try
		{
			
			mbSession = mbAppHelper.getMobileSession(request);
			model = new ModelAndView(OAUTH_EXTERNAL);
			request.setAttribute(MainController.WEB_CONTEXT, logonHelper.getMBWebResourceContext());
			
			return model;
			

		} catch (BusinessException be) {
			Logger.error("BusinessException : " , be , this.getClass());
		} catch (ResourceException re) {
			Logger.error("ResourceException : " , re , this.getClass());
		} catch (Exception ex) {
			Logger.error("Exception : " , ex , this.getClass());		
		} finally {
			perfLogger.endLog(logName);
			perfLogger.endAllLogs();
			
			if(null != mbSession)
				mbSession.invalidateSession();
		}	
		return model;
	}

	
}