package au.com.stgeorge.mbank.model.common;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_NULL)
public class BusinessAccountReceiptResp {
	private String accountNumDisp;
	private String accountName;
	private String errorMessage;
	
	public String getAccountNumDisp() {
		return accountNumDisp;
	}
	public void setAccountNumDisp(String accountNumDisp) {
		this.accountNumDisp = accountNumDisp;
	}
	public String getAccountName() {
		return accountName;
	}
	public void setAccountName(String accountName) {
		this.accountName = accountName;
	}
	public String getErrorMessage() {
		return errorMessage;
	}
	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}
}
