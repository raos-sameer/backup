package au.com.stgeorge.mbank.model.request;

import javax.validation.constraints.NotNull;
import au.com.stgeorge.ibank.businessobject.BusinessException;
import au.com.stgeorge.mbank.model.common.IMBReq;
import au.com.stgeorge.mbank.model.common.ReqHeader;

public class GlobalWalletTransDetailsReq implements IMBReq {

	
	private static final long serialVersionUID = -2075600760077230340L;	
	
	@NotNull(message = "" + BusinessException.WSVC_INVALID_INPUT_PARAM)
	private Integer accountIndex;
	private String refNum;	
	private String transCode;
	private ReqHeader header;
	private String currencyCode;
	private String cycleDateTime;
	private String effectiveDateTime;
	private String transactionSequenceNumber;
	private Boolean isWalletTransfer;
	
	@Override
	public ReqHeader getHeader() {
		return this.header;
	}

	public String getCycleDateTime() {
		return cycleDateTime;
	}

	public void setCycleDateTime(String cycleDateTime) {
		this.cycleDateTime = cycleDateTime;
	}

	public String getEffectiveDateTime() {
		return effectiveDateTime;
	}

	public void setEffectiveDateTime(String effectiveDateTime) {
		this.effectiveDateTime = effectiveDateTime;
	}

	public String getTransactionSequenceNumber() {
		return transactionSequenceNumber;
	}

	public void setTransactionSequenceNumber(String transactionSequenceNumber) {
		this.transactionSequenceNumber = transactionSequenceNumber;
	}

	@Override
	public void setHeader(ReqHeader header) {
		this.header = header;
	}

	public Integer getAccountIndex() {
		return accountIndex;
	}

	public void setAccountIndex(Integer accountIndex) {
		this.accountIndex = accountIndex;
	}

	public String getRefNum() {
		return refNum;
	}

	public void setRefNum(String refNum) {
		this.refNum = refNum;
	}

	public String getTransCode() {
		return transCode;
	}

	public void setTransCode(String transCode) {
		this.transCode = transCode;
	}

	public String getCurrencyCode() {
		return currencyCode;
	}

	public void setCurrencyCode(String currencyCode) {
		this.currencyCode = currencyCode;
	}

	public Boolean getIsWalletTransfer() {
		return isWalletTransfer;
	}

	public void setIsWalletTransfer(Boolean isWalletTransfer) {
		this.isWalletTransfer = isWalletTransfer;
	}

		
	
}
