package au.com.stgeorge.mbank.controller.services;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang.builder.ReflectionToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import au.com.stgeorge.framework.common.logging.Logger;
import au.com.stgeorge.ibank.businessobject.BusinessException;
import au.com.stgeorge.ibank.businessobject.CustomerService;
import au.com.stgeorge.ibank.businessobject.ResourceException;
import au.com.stgeorge.ibank.businessobject.SmartPlansService;
import au.com.stgeorge.ibank.businessobject.impl.CardServiceImpl;
import au.com.stgeorge.ibank.common.cache.IBankParams;
import au.com.stgeorge.ibank.common.cache.IBankRefershParams;
import au.com.stgeorge.ibank.common.log.IBankLog;
import au.com.stgeorge.ibank.valueobject.Account;
import au.com.stgeorge.ibank.valueobject.CreditCardAccount;
import au.com.stgeorge.ibank.valueobject.Customer;
import au.com.stgeorge.ibank.valueobject.Statistic;
import au.com.stgeorge.ibank.valueobject.database.CodesVO;
import au.com.stgeorge.ibank.valueobject.transfer.IBankCommonData;
import au.com.stgeorge.mbank.controller.IMBController;
import au.com.stgeorge.mbank.model.common.IMBReq;
import au.com.stgeorge.mbank.model.common.IMBResp;
import au.com.stgeorge.mbank.model.common.ReqHeader;
import au.com.stgeorge.mbank.model.common.RespHeader;
import au.com.stgeorge.mbank.model.request.EmptyReq;
import au.com.stgeorge.mbank.model.request.services.PlanAndPayLogStatsReq;
import au.com.stgeorge.mbank.model.request.services.SetupPlanPayReq;
import au.com.stgeorge.mbank.model.response.ErrorResp;
import au.com.stgeorge.mbank.model.response.SuccessResp;
import au.com.stgeorge.mbank.model.response.services.PlanAndPayEligibleCardResp;
import au.com.stgeorge.mbank.model.response.services.PlanAndPayInstalmentResp;
import au.com.stgeorge.mbank.model.response.services.SetupPlanAndPayResp;
import au.com.stgeorge.mbank.session.MobileSession;
import au.com.stgeorge.mbank.session.MobileSessionImpl;
import au.com.stgeorge.mbank.util.MBAppHelper;
import au.com.stgeorge.mbank.util.MBAppUtils;
import au.com.stgeorge.mbank.util.MBAppValidator;
import au.com.stgeorge.mbank.util.ServiceConstants;
import au.com.stgeorge.perflogger.PerformanceLogger;


@Controller
@RequestMapping("/smartplan")
public class SmartPlanController implements IMBController {

	private static final String SMART_PLANS_MAX_ACTIVE_PLAN_COUNT = "SmartPlansMaxActivePlanCount";
	private static final String SOURCE_SERVICES = "Services";
	//New plan sources
	private static final String SOURCE_ACCOUNTSERVICES = "AccountServices";
	private static final String SOURCE_ACCOUNTDETAILSBALANCEPLAN = "AccountDetailsBalancePlan";
	private static final String SOURCE_ACCOUNTDETAILSPURCHASEPLAN = "AccountDetailsPurchasePlan";
	private static final String SOURCE_TRANSACTIONDETAILS = "TransactionDetails";
	//Existing plan sources
	private static final String SOURCE_DASHBOARD = "Dashboard";
	private static final String SOURCE_ACCOUNTDETAILSPLANOVERVIEW = "AccountDetailsPlanOverview";
	private static final String SOURCE_TRANSACTIONLISTPLANOVERVIEW = "TransactionListPlanOverview";
	private static final String SOURCE_TRANSACTIONDETAILSPLANOVERVIEW = "TransactionDetailsPlanOverview";
	
	@Autowired
	private MBAppValidator mbAppValidator;

	@Autowired
	private MBAppHelper mbAppHelper;

	@Autowired 
	private SmartPlansService smartPlansService;
	
	@Autowired
	IBankRefershParams ibankRefreshParams;

	/**
	 * Get Credit Cards for Smart Plan	 * 
	 * @param httpRequest
	 * @param request
	 * @return
	 */

	@RequestMapping(method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE, value = "getPlanAndPayInstalmentList")
	@ResponseBody
	public IMBResp getPlanAndPayInstalmentList(HttpServletRequest httpRequest, @RequestBody final EmptyReq request) {
		Logger.debug("PlanAndPayInstalmentController - getPlanAndPayInstalmentList(). Request: " + request, this.getClass());
		String logName = startPerformanceLog(httpRequest);
		MobileSession mobileSession = new MobileSessionImpl();

		List<Account> cards = new ArrayList<Account>(); 
		
		try {
			mobileSession.getSessionContext(httpRequest);
			validateRequestHeader(request.getHeader(), httpRequest);
			ErrorResp errorResponse = validate(request, httpRequest);
			if (errorResponse.hasErrors())
				return errorResponse;
			IBankCommonData commonData = new MBAppHelper().populateIBankCommonData(mobileSession, httpRequest);

			cards = getEligibleCreditCardsForSmartPlan(commonData);
			
			if(cards.size() > 0) {
				return populatePlanAndPayCardListResponse(commonData, populateResponseHeader(ServiceConstants.PLAN_AND_PAY_SERVICE, mobileSession ), (List<Account>) cards, false);
			}else {
				throw new BusinessException(BusinessException.SMARTPLAN_NO_ELIGIBLE_ACCOUNTS);
			}			
			
		} catch (BusinessException e) {
			Logger.info("BusinessException in PlanAndPayInstalmentController - getPlanAndPayInstalmentList():  - [key: " + e.getKey() + "] : GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), e, ServiceConstants.PLAN_AND_PAY_SERVICE, httpRequest);
		} catch (ResourceException e) {
			Logger.error("ResourceException in PlanAndPayInstalmentController - getPlanAndPayInstalmentList():  - [key: " + e.getKey() + "] : GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.SYSTEM_UNAVILABLE, ServiceConstants.PLAN_AND_PAY_SERVICE, httpRequest);
		}catch (Exception e) {
			Logger.error("Exception PlanAndPayInstalmentController - getPlanAndPayInstalmentList(): GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(),ResourceException.MOBILE_NON_FINANCIAL_FATAL_ERR, ServiceConstants.PLAN_AND_PAY_SERVICE, httpRequest);
		} finally {
			endPerformanceLog(logName);
		}
	}

	@Autowired
	private PerformanceLogger perfLogger;

	private String startPerformanceLog(HttpServletRequest httpRequest){
		perfLogger.startAllLogs();
		String logName = MBAppUtils.getLogName(httpRequest);
		perfLogger.startLog(logName);
		return logName;
	}

	private void endPerformanceLog(String logName){
		perfLogger.endLog(logName);
		perfLogger.endAllLogs();
	}

	public ErrorResp validate(IMBReq serviceRequest, HttpServletRequest request) {
		Logger.info("Service request object - " + ReflectionToStringBuilder.toString(serviceRequest), this.getClass());
		return mbAppValidator.validate(serviceRequest, request);
	}

	public void validateRequestHeader(ReqHeader headerReq, HttpServletRequest request) throws BusinessException {
		Logger.debug("Request header validation: " + ReflectionToStringBuilder.toString(headerReq, ToStringStyle.MULTI_LINE_STYLE), this.getClass());
		mbAppValidator.validateRequestHeader(headerReq, request);
	}

	public RespHeader populateResponseHeader(String serviceName, MobileSession mobSession) {
		return mbAppHelper.populateResponseHeader(serviceName, mobSession);
	}

	public  List<Account> getEligibleCreditCardsForSmartPlan(IBankCommonData commonData) throws BusinessException,ResourceException{

		List<Account> validCardList = new ArrayList<Account>();
		List<String> craAccountNumber = new ArrayList<String>();
		try{

			//Get the credit cards from customer
			Customer customer = commonData.getCustomer();
			if (customer == null)
			{
				customer = CustomerService.getCustomer(commonData);
			}
			List<Account> accountList = customer.getAccounts();


			for(Account account:commonData.getCustomer().getAccounts()) {
				if (Account.CRA.equalsIgnoreCase(account.getAccountId().getApplicationId())) {
					craAccountNumber.add(account.getAccountId().getAccountNumber());
				}
			}
	
			if (accountList != null){ 

				for (int i = 0; i < accountList.size(); i++) {
					try{
						Account account = (Account) accountList.get(i);	
						if(Account.CRA.equalsIgnoreCase(account.getAccountId().getApplicationId())){
							//Explicitly passing active and pending plan count as 0 since we do not want to hide cards that have crossed smart plan max threshold 
							//i.e. cards having more than 8  smart plans should still be shown
							boolean isAccountEligibleForSmartPlan = smartPlansService.isCustomerAccountEligible(commonData.getCustomer(), account, 0, 0);
							if(isAccountEligibleForSmartPlan) {
								boolean isAccountBalanceEligible= smartPlansService.isAccountEligibleForBalanceSmartPlans(account);
								if(isAccountBalanceEligible) {
									validCardList.add(account);
								}
							}

						}
					}
					catch (Exception e) {
						IBankLog.logWRN("Unable to get valid credit card", e,
								CardServiceImpl.class);
					}
				}//end of outer for 			
			}

		}
		finally
		{
			perfLogger.endLog("getEligibleCreditCardsForSmartPlan");
		}

		IBankLog.logTRC(
				"valid cr cards:"+validCardList.size(),CardServiceImpl.class);
		return validCardList;
	}//End of getEligibleCreditCardsForSmartPlan


	protected IMBResp populatePlanAndPayCardListResponse(IBankCommonData commonData, RespHeader header, List<Account> cards, boolean isMaxPlanThresholdReached) throws BusinessException {
		PlanAndPayEligibleCardResp response = new PlanAndPayEligibleCardResp(header);
		List<PlanAndPayInstalmentResp> cardsResp = new ArrayList<PlanAndPayInstalmentResp>();
		String cardArtUrl = null;
		
		if (!isMaxPlanThresholdReached) {
			for (Account card : cards) {
				PlanAndPayInstalmentResp cardResp = new PlanAndPayInstalmentResp();
				cardResp.setIndex(String.valueOf(card.getIndex()));
	
				if (card instanceof CreditCardAccount) {			
					cardResp.setAccountNumDisp(new MBAppHelper().getFormattedAcctNumber(card.getAccountId().getAccountNumber(), card.getAccountId().getApplicationId(), card.getAccountId().getBsb()));
					String cardLogo =card.getCreditCardAdditionalInfo().getLogo();				
					
					cardArtUrl = IBankParams.getCardArtImageURL(commonData.getOrigin(), cardLogo);	    		
					if(cardArtUrl == null){
						cardArtUrl = IBankParams.getCardArtImageURL(commonData.getOrigin(),  "999");	    		
					}
					cardResp.setCardImageUrl(cardArtUrl);
				
					cardResp.setProductName(card.getAlias());
				}
				cardsResp.add(cardResp);
			}
	
			response.setPlanAndPaycards(cardsResp);
		}
		response.setIsMaxPlanThresholdReached(isMaxPlanThresholdReached);
		if(isMaxPlanThresholdReached) {
			response.setMaxPlanAllowedCount(Integer.valueOf(ibankRefreshParams.getRefreshCodesData(IBankParams.DEFAULT_ORIGIN, SMART_PLANS_MAX_ACTIVE_PLAN_COUNT)));
		}
		Logger.info("Response: " + response, this.getClass());
		return response;
	}

	@RequestMapping(method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE, value = "setupPlanAndPay")
	@ResponseBody
	public IMBResp setupPlanAndPay(HttpServletRequest httpRequest, @RequestBody final SetupPlanPayReq request) {
		Logger.debug("PlanAndPayInstalmentController - setupPlanAndPay(). Request: " + request, this.getClass());
		String logName = startPerformanceLog(httpRequest);
		MobileSession mobileSession = new MobileSessionImpl();
		String accountNumberFrom = null;
		
		try {
			mobileSession.getSessionContext(httpRequest);
			validateRequestHeader(request.getHeader(), httpRequest);
			ErrorResp errorResponse = validate(request, httpRequest);
			if (errorResponse.hasErrors())
				return errorResponse;
			IBankCommonData commonData = new MBAppHelper().populateIBankCommonData(mobileSession, httpRequest);

			Account selAccount = commonData.getCustomer().getAccounts().get(request.getFromAccountIndex());
			if (selAccount == null || !Account.CRA.equals(selAccount.getAccountId().getApplicationId())) {
				throw new BusinessException(BusinessException.SYSTEM_UNAVILABLE);
			}
			
			int currentPlanCount = smartPlansService.getTotalInstalmentPlanCount(selAccount.getAccountId().getAccountNumber());
			if(smartPlansService.isPlanThresholdReached(currentPlanCount, 0)) {
				return processSetupPlanAndPayResponse(populateResponseHeader(ServiceConstants.PLAN_AND_PAY_SETUP, mobileSession), true);
			}else{
				Logger.debug("Account eligible for redirecting to WDP", this.getClass());
				//GDW
				accountNumberFrom = (selAccount == null)? null:selAccount.getAccountId().getAccountNumber();
				if (SOURCE_ACCOUNTSERVICES.equalsIgnoreCase(request.getSource())){
					smartPlansService.logStatistic(commonData, Statistic.PLANANDPAY_NEWPLAN, SOURCE_ACCOUNTSERVICES, accountNumberFrom);
				} else if (SOURCE_SERVICES.equalsIgnoreCase(request.getSource())){
					smartPlansService.logStatistic(commonData, Statistic.PLANANDPAY_NEWPLAN, SOURCE_SERVICES, accountNumberFrom);
				}
			}
			
			return processSetupPlanAndPayResponse(populateResponseHeader(ServiceConstants.PLAN_AND_PAY_SETUP, mobileSession), false);
						
			
		} catch (BusinessException e) {
			Logger.info("BusinessException in PlanAndPayInstalmentController - setupPlanAndPay():  - [key: " + e.getKey() + "] : GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), e, ServiceConstants.PLAN_AND_PAY_SETUP, httpRequest);
		} catch (ResourceException e) {
			Logger.error("ResourceException in PlanAndPayInstalmentController - setupPlanAndPay():  - [key: " + e.getKey() + "] : GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.SYSTEM_UNAVILABLE, ServiceConstants.PLAN_AND_PAY_SETUP, httpRequest);
		}catch (Exception e) {
			Logger.error("Exception PlanAndPayInstalmentController - setupPlanAndPay(): GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(),ResourceException.MOBILE_NON_FINANCIAL_FATAL_ERR, ServiceConstants.PLAN_AND_PAY_SETUP, httpRequest);
		} finally {
			endPerformanceLog(logName);
		}
	}
	
	protected IMBResp processSetupPlanAndPayResponse(RespHeader headerResp, boolean isMaxPlanThresholdReached){			
		SetupPlanAndPayResp resp = new SetupPlanAndPayResp(headerResp);
		resp.setHeader(headerResp);
		resp.setIsMaxPlanThresholdReached(isMaxPlanThresholdReached);
		if(isMaxPlanThresholdReached) {
			resp.setMaxPlanAllowedCount(Integer.valueOf(ibankRefreshParams.getRefreshCodesData(IBankParams.DEFAULT_ORIGIN, SMART_PLANS_MAX_ACTIVE_PLAN_COUNT)));
		}
		return resp;
	}
	
	@RequestMapping(method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE, value = "logNewPlanStats")
	@ResponseBody
	public IMBResp logNewPlanStats(HttpServletRequest httpRequest, @RequestBody final PlanAndPayLogStatsReq request){
		Logger.debug("SmartPlanController - logNewPlanStats(). Request: " + request, this.getClass());
		String logName = startPerformanceLog(httpRequest);
		MobileSession mobileSession = new MobileSessionImpl();
		String accountNumberFrom = null;
		
		try {

			mobileSession.getSessionContext(httpRequest);
			validateRequestHeader(request.getHeader(), httpRequest);
			ErrorResp errorResponse = validate(request, httpRequest);
			if (errorResponse.hasErrors())
				return errorResponse;
			IBankCommonData commonData = new MBAppHelper().populateIBankCommonData(mobileSession, httpRequest);
		
			Account selAccount = commonData.getCustomer().getAccounts().get(request.getFromAccountIndex());
			if (selAccount == null || !Account.CRA.equals(selAccount.getAccountId().getApplicationId())) {
				throw new BusinessException(BusinessException.SYSTEM_UNAVILABLE);
			}
			
			//GDW
			accountNumberFrom = (selAccount == null)? null:selAccount.getAccountId().getAccountNumber();
			if (SOURCE_ACCOUNTDETAILSBALANCEPLAN.equalsIgnoreCase(request.getSource())){
				smartPlansService.logStatistic(commonData, Statistic.PLANANDPAY_NEWPLAN, SOURCE_ACCOUNTDETAILSBALANCEPLAN, accountNumberFrom);
			} else if (SOURCE_ACCOUNTDETAILSPURCHASEPLAN.equalsIgnoreCase(request.getSource())){
				smartPlansService.logStatistic(commonData, Statistic.PLANANDPAY_NEWPLAN, SOURCE_ACCOUNTDETAILSPURCHASEPLAN, accountNumberFrom);
			} else if (SOURCE_TRANSACTIONDETAILS.equalsIgnoreCase(request.getSource())){
				smartPlansService.logStatistic(commonData, Statistic.PLANANDPAY_NEWPLAN, SOURCE_TRANSACTIONDETAILS, accountNumberFrom);
			}
			
			SuccessResp resp = new SuccessResp();
			resp.setHeader(populateResponseHeader(ServiceConstants.PLAN_AND_PAY_LOG_NEW_PLAN_STATS, mobileSession));
			resp.setIsSuccess(true);
			return resp;
			
		} catch (BusinessException e) {
			Logger.info("BusinessException in SmartPlanController - logNewPlanStats():  - [key: " + e.getKey() + "] : GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), e, ServiceConstants.PLAN_AND_PAY_LOG_NEW_PLAN_STATS, httpRequest);
		} catch (ResourceException e) {
			Logger.error("ResourceException in SmartPlanController - logNewPlanStats():  - [key: " + e.getKey() + "] : GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.SYSTEM_UNAVILABLE, ServiceConstants.PLAN_AND_PAY_LOG_NEW_PLAN_STATS, httpRequest);
		}catch (Exception e) {
			Logger.error("Exception SmartPlanController - logNewPlanStats(): GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(),ResourceException.MOBILE_NON_FINANCIAL_FATAL_ERR, ServiceConstants.PLAN_AND_PAY_LOG_NEW_PLAN_STATS, httpRequest);
		} finally {
			endPerformanceLog(logName);
		}
	}
	
	@RequestMapping(method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE, value = "logExistingPlanStats")
	@ResponseBody
	public IMBResp logExistingPlanStats(HttpServletRequest httpRequest, @RequestBody final PlanAndPayLogStatsReq request){
		Logger.debug("SmartPlanController - logExistingPlanStats(). Request: " + request, this.getClass());
		String logName = startPerformanceLog(httpRequest);
		MobileSession mobileSession = new MobileSessionImpl();
		String accountNumberFrom = null;
		
		try {

			mobileSession.getSessionContext(httpRequest);
			validateRequestHeader(request.getHeader(), httpRequest);
			ErrorResp errorResponse = validate(request, httpRequest);
			if (errorResponse.hasErrors())
				return errorResponse;
			IBankCommonData commonData = new MBAppHelper().populateIBankCommonData(mobileSession, httpRequest);
		
			Account selAccount = commonData.getCustomer().getAccounts().get(request.getFromAccountIndex());
			if (selAccount == null || !Account.CRA.equals(selAccount.getAccountId().getApplicationId())) {
				throw new BusinessException(BusinessException.SYSTEM_UNAVILABLE);
			}
			
			//GDW
			accountNumberFrom = (selAccount == null)? null:selAccount.getAccountId().getAccountNumber();
			if (SOURCE_DASHBOARD.equalsIgnoreCase(request.getSource())){
				smartPlansService.logStatistic(commonData, Statistic.PLANANDPAY_ACTIVE, SOURCE_DASHBOARD, accountNumberFrom);
			} else if (SOURCE_ACCOUNTDETAILSPLANOVERVIEW.equalsIgnoreCase(request.getSource())){
				smartPlansService.logStatistic(commonData, Statistic.PLANANDPAY_ACTIVE, SOURCE_ACCOUNTDETAILSPLANOVERVIEW, accountNumberFrom);
			} else if (SOURCE_TRANSACTIONLISTPLANOVERVIEW.equalsIgnoreCase(request.getSource())){
				smartPlansService.logStatistic(commonData, Statistic.PLANANDPAY_ACTIVE, SOURCE_TRANSACTIONLISTPLANOVERVIEW, accountNumberFrom);
			} else if (SOURCE_TRANSACTIONDETAILSPLANOVERVIEW.equalsIgnoreCase(request.getSource())){
				smartPlansService.logStatistic(commonData, Statistic.PLANANDPAY_ACTIVE, SOURCE_TRANSACTIONDETAILSPLANOVERVIEW, accountNumberFrom);
			}
			
			SuccessResp resp = new SuccessResp();
			resp.setHeader(populateResponseHeader(ServiceConstants.PLAN_AND_PAY_LOG_EXISTING_PLAN_STATS, mobileSession));
			resp.setIsSuccess(true);
			return resp;
			
		} catch (BusinessException e) {
			Logger.info("BusinessException in SmartPlanController - logExistingPlanStats():  - [key: " + e.getKey() + "] : GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), e, ServiceConstants.PLAN_AND_PAY_LOG_EXISTING_PLAN_STATS, httpRequest);
		} catch (ResourceException e) {
			Logger.error("ResourceException in SmartPlanController - logExistingPlanStats():  - [key: " + e.getKey() + "] : GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.SYSTEM_UNAVILABLE, ServiceConstants.PLAN_AND_PAY_LOG_EXISTING_PLAN_STATS, httpRequest);
		}catch (Exception e) {
			Logger.error("Exception SmartPlanController - logExistingPlanStats(): GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(),ResourceException.MOBILE_NON_FINANCIAL_FATAL_ERR, ServiceConstants.PLAN_AND_PAY_LOG_EXISTING_PLAN_STATS, httpRequest);
		} finally {
			endPerformanceLog(logName);
		}
	}
}