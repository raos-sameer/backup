package au.com.stgeorge.mbank.model.request.accountinfo;

import javax.validation.constraints.NotNull;
import au.com.stgeorge.ibank.businessobject.BusinessException;
import au.com.stgeorge.mbank.model.common.IMBReq;
import au.com.stgeorge.mbank.model.common.ReqHeader;

public class ShareBsbAccNumReq implements IMBReq{

	private static final long serialVersionUID = 4438080951948859767L;

	private ReqHeader header;
	
	@NotNull(message = "" + BusinessException.WSVC_INVALID_INPUT_PARAM)
	private Integer accountIndex;
	
	
	@NotNull(message = "" + BusinessException.WSVC_INVALID_INPUT_PARAM)
	private String shareType;
	
	public String getShareType() {
		return shareType;
	}
	public void setShareType(String shareType) {
		this.shareType = shareType;
	}
	
	public Integer getAccountIndex() {
		return accountIndex;
	}	
	public void setAccountIndex(Integer accountIndex) {
		this.accountIndex = accountIndex;
	}
		
	public ReqHeader getHeader()
	{
		return header;
	}
	public void setHeader(ReqHeader header)
	{
		this.header = header;
	}
				

}
