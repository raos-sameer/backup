package au.com.stgeorge.mbank.model.request.expensesplitter;


import org.hibernate.validator.constraints.NotEmpty;

import au.com.stgeorge.ibank.businessobject.BusinessException;
import au.com.stgeorge.mbank.model.common.IMBReq;
import au.com.stgeorge.mbank.model.common.ReqHeader;
import javax.validation.constraints.Pattern;

public class ContactDetailReq implements IMBReq {


	/**
	 * 
	 */
	private static final long serialVersionUID = -1648485516113973564L;
	/**
	 * 
	 */
	protected static final String AMT_PATTERN = "^[0-9]*\\.{0,1}(\\d{1,2}){0,1}$";
	protected static final String BLOCK_CHARS_PATTERN = "^[0-9A-Za-z',. &/\\-]*$";
	protected static final String MASK_NUMBERS = "^[0-9]+$";
	
	private ReqHeader header;

	public ReqHeader getHeader() {
		return header;
	}

	public void setHeader(ReqHeader header) {
		this.header = header;
	}

	public String getContactID() {
		return contactID;
	}

	public void setContactID(String contactID) {
		this.contactID = contactID;
	}

	@Pattern(regexp = MASK_NUMBERS, message = "" + BusinessException.WSVC_INVALID_INPUT_PARAM)
	@NotEmpty(message = "{error.customer.credential.invalid}")
	private String contactID;
		
	
}
