package au.com.stgeorge.mbank.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.AbstractController;

import au.com.stgeorge.framework.common.logging.Logger;
import au.com.stgeorge.framework.common.model.User;
import au.com.stgeorge.ibank.businessobject.BusinessException;
import au.com.stgeorge.ibank.businessobject.SystemInformation;
import au.com.stgeorge.ibank.businessobject.mortgage.MortgageLenderService;
import au.com.stgeorge.ibank.businessobject.mortgage.MortgageService;
import au.com.stgeorge.ibank.common.cache.IBankParams;
import au.com.stgeorge.ibank.util.ServiceHelper;
import au.com.stgeorge.ibank.util.StringUtil;
import au.com.stgeorge.ibank.valueobject.database.OriginsVO;
import au.com.stgeorge.ibank.valueobject.mortgage.Applicant;
import au.com.stgeorge.ibank.valueobject.mortgage.Application;
import au.com.stgeorge.ibank.valueobject.mortgage.MortgageSessionInfo;
import au.com.stgeorge.mbank.controller.customer.LogonHelper;
import au.com.stgeorge.mbank.controller.mortgage.MortgageHelper;
import au.com.stgeorge.mbank.session.IGenericSession;
import au.com.stgeorge.mbank.session.MobileSessionImpl;
import au.com.stgeorge.mbank.util.GDPRWebHelper;
import au.com.stgeorge.mbank.util.MBAppConstants;
import au.com.stgeorge.mbank.util.MBAppHelper;
import au.com.stgeorge.mbank.util.MBAppUtils;
import au.com.stgeorge.perflogger.PerformanceLogger;
import au.com.stgeorge.security.util.StringMethods;

public class MortgageMainController extends AbstractController {

	public static final String PAGE_NAME = "Mortgage";
	//private static final String ERROR_VIEW = "404";
	private static final String ERROR_VIEW = "/error/serviceError";
	private static volatile int numberOfRequests = 0;

	public static final String NUM_KEYBOARD_TYPE = "NumKeyBoardType";
	public static final String NUM_KEYBOARD_PATTERN_TYPE = "NumKeyBoardTypePattern";
	public static final String SYS_VERSION = "SysVersion";
	public static final String ORIGIN_NAME = "OriginName";
	public static final String HELP_DESK_NO = "HelpDeskNo";
	public static final String DATA_ROLE = "DataRole";
	public static final String ACTION_TYPE = "actiontype";
	public static final String DATA_SERVICES_AVAILABILITY = "ServicesAvailability";
	public static final String ERROR = "Error";
	public static final String BLANK = "";
	public static final String WEB_CONTEXT = "WebContext";
	public static final String REQ_LOAD_CORDOVA = "LoadCordova";
	public static final String ORIGIN_PHONE = "originPhone";
	public static final String ORIGIN_HELPDESK_PHONE = "originHelpDeskPhone";
	public static final String STR_SECRET_KEYMAP = "secretKey";
	public static final String STR_PASSWORD_KEYMAP = "passwordMap";
	public static final String STR_SECNUM_KEYMAP = "securityNumMap";
	public static final String STR_ENCRYPTION_SWITCH = "isEncryptionOn";
	public static final String STR_NAME_ID = "nameId";
	
	public static final String DEFAULT_DATA_ROLE = "NORMAL";
	public static final String DEFAULT_SIGNEDIN_DATA_ROLE = "EXISTING";
	public static final String EXISTING_RETRIEVE_DATA_ROLE = "EXISTINGRETRIEVE";
	
	public static final String ACTION_TYPE_EXISTING_RETRIEVE = "retrieve";
	
	public static final String ACTION_TYPE_EXISTING_CUSTOMER_RETRIEVE = "retrieveExisting";
	public static final String EXISTING_CUSTOMER_RETRIEVE_DATA_ROLE = "EXISTINGCUSTOMERRETRIEVE";
	
	private static final String REQ_PARAM_TOKEN = "id_token";
	
	public static final String DATA_LENDERID = "DataLenderId";
	public static final String LENDERID = "lenderid";
	
	public static final String APP_REFERENCE_NUMBER = "appRefNum";
	public static final String DATA_REFERENCE_NUMBER = "DataRefNumber";
	
	
	@Autowired
	private MortgageService mortgageService;

	@Override
	protected ModelAndView handleRequestInternal(HttpServletRequest request,
			HttpServletResponse response) throws Exception {

		PerformanceLogger performanceLogger = new PerformanceLogger(true);
		performanceLogger.startAllLogs();
		String logName = MBAppUtils.getLogName(request);
		performanceLogger.startLog(logName);
		ModelAndView model = null;
		String origin = null;
		String numKeyType = null;
		String numKeyTypePattern = null;
		IGenericSession genericSession =  null;
		String nativeApplenderId =  null;
		String appRefNum = null;
		try {

			numberOfRequests++;
			origin = LogonHelper.resolveOrigin(request);

			if (StringMethods.isEmptyString(origin)) {
				origin = "MBOM";
				request.setAttribute(LogonHelper.ORIGIN, origin);
				Logger.info(
						"Unable to resolve the origin for Mortgage Request Details. URL : "
								+ request.getRequestURL() + " IP :"
								+ request.getRemoteAddr()
								+ " Number Of Requests : " + numberOfRequests +
								" True IP >> " + request.getHeader(IBankParams.trueClientIP()),
						this.getClass());
				model = new ModelAndView(ERROR_VIEW);
			} else {
				//MortgageNTBSwitch - If switch not available, allow flow
				Boolean homeLoanSwitch = IBankParams.getSwitch(origin, IBankParams.MORTGAGE_NTB_SWITCH);
				if(homeLoanSwitch != null && !homeLoanSwitch){
					Logger.info("Mortgage NTB Switch is off : ", this.getClass());
					throw new BusinessException(BusinessException.SYSTEM_UNAVILABLE);
				}
				request.setAttribute(LogonHelper.ORIGIN, origin);
				numKeyType = logonHelper.getNumKeyBoardType(request);
				numKeyTypePattern = logonHelper.getNumKeyBoardPattern(request);
				request.setAttribute(NUM_KEYBOARD_TYPE, numKeyType);
				request.setAttribute(NUM_KEYBOARD_PATTERN_TYPE,numKeyTypePattern);
				request.setAttribute(WEB_CONTEXT, "mortgage");

				String actionType = request.getParameter(ACTION_TYPE);
				Logger.info("The value for data role is  " + actionType,this.getClass());

				
				//Changes for CSH NTB 
				
				appRefNum = request.getParameter(APP_REFERENCE_NUMBER);
				Logger.info("The value for application reference number is  " + appRefNum,this.getClass());
				
				boolean hasSignedIn = false;
				String token = request.getParameter(REQ_PARAM_TOKEN);
				if(!StringMethods.isEmptyString(token))
				{
					Logger.info("DM -- Cookie Values  " + actionType,this.getClass());
					try
					{
	      		MBAppHelper.diplayCookie(request ); 
	       		Cookie sessCookie = logonHelper.getCookie(request , MBAppConstants.SMPL_SESS_CONSTANT);
	      		if ( sessCookie != null )
	      		{
	            Logger.info("Deleting cookie - ( Mortgage) Session Id : " + sessCookie.getValue(), this.getClass());        
	            
	      			sessCookie.setValue("00");
	      			sessCookie.setMaxAge(0);
	      			response.addCookie(sessCookie);
	      		}
	      		MBAppHelper.expireCookie(MBAppConstants.SMPL_SESS_CONSTANT,  response);
					}
					catch (Exception e)
					{
						Logger.error("Error display cookie",e,this.getClass());
					}
      		
					String[] jwtData= mortgageService.verifyJWTParams(token);
					String customerId = jwtData[0]; 
					//String customerId = mortgageService.verifyJWTParams(token);
					genericSession = mortgageHelper.createSession( request, response);
					MortgageSessionInfo sessionInfo = new MortgageSessionInfo();
					Application application=new Application();
					List<Applicant> applicants=new ArrayList<Applicant>(1);
					Applicant applicant=new Applicant();					
					applicant.setGcisNum(customerId);
					applicants.add(applicant);
					application.setApplicants(applicants);
					sessionInfo.setApplication(application);
					sessionInfo.setLoggedOnGCISNumber(customerId); // For DocUpload GCIS
					sessionInfo.setOrigin((String)genericSession.getAttribute(MobileSessionImpl.ORIGIN_OBLECT));
					genericSession.setAttribute(MobileSessionImpl.MORTGAGE_APPLICATION, sessionInfo);
					
					if ( jwtData[1] != null && jwtData[1].length() > 3 ){
						Logger.info("LenderId in jwtToken : " + jwtData[1], this.getClass());  
						//genericSession.setAttribute(MobileSessionImpl.MORTGAGE_LENDER_ID, jwtData[1]);
						
						MortgageLenderService mortgageLenderService = (MortgageLenderService) ServiceHelper.getBean("mortgageLenderService");
						if (  mortgageLenderService.isMortgageLenderInitiatedSwtichON(origin) )
						{
							genericSession.setAttribute(MobileSessionImpl.MORTGAGE_LENDER_ID, jwtData[1]);
							request.setAttribute( DATA_LENDERID , jwtData[1] );
						}
					}
					 
					User user = new User();
					user.setAttribute(User.GCISNUMBER, customerId);
					genericSession.setUser(user);
					hasSignedIn = true;
				}
				
				if(StringMethods.isEmptyString(actionType))
				{
					if(hasSignedIn)
					{
						request.setAttribute( DATA_ROLE , DEFAULT_SIGNEDIN_DATA_ROLE );
					}
					else
					{
						request.setAttribute( DATA_ROLE , DEFAULT_DATA_ROLE );
					}
				}
				else if(hasSignedIn)
				{
					if(ACTION_TYPE_EXISTING_CUSTOMER_RETRIEVE.equals(actionType))
					{
						request.setAttribute( DATA_ROLE , EXISTING_CUSTOMER_RETRIEVE_DATA_ROLE );
					}
					else{
						request.setAttribute( DATA_ROLE ,actionType );
					}
					
				}else if(ACTION_TYPE_EXISTING_RETRIEVE.equals(actionType))
				{
					request.setAttribute( DATA_ROLE , EXISTING_RETRIEVE_DATA_ROLE );
				}
				
				if(ACTION_TYPE_EXISTING_RETRIEVE.equals(actionType))
				{					
					if(null!=appRefNum && isValidReferenceNumber(appRefNum)) {
						request.setAttribute( DATA_REFERENCE_NUMBER , appRefNum );
					}else {
						request.setAttribute( DATA_REFERENCE_NUMBER , BLANK );
					}
				}

				if (this.systemInformation == null) {
					Logger.info("************ Loading systemInformation for Mortgage*************** "
									+ request.getRequestURL(), this.getClass());
					this.systemInformation = getSystemInformationDtls();
				}
				// request.setAttribute(WEB_CONTEXT, PAGE_NAME.toLowerCase());
				int loadCordova = logonHelper.loadCordova(request);
				request.setAttribute(REQ_LOAD_CORDOVA,
						String.valueOf(loadCordova));

				request.setAttribute(SYS_VERSION,
						this.systemInformation.getMB3PackageVersion());
				OriginsVO originVO = IBankParams.getOrigin(origin);
				request.setAttribute(ORIGIN_NAME, originVO.getName());
				request.setAttribute(ORIGIN_HELPDESK_PHONE, originVO.getPhone());

				OriginsVO baseOrigin = IBankParams.getOrigin(originVO
						.getBankName());
				request.setAttribute(ORIGIN_PHONE, baseOrigin.getPhone());

				String lenderId = request.getParameter(LENDERID);

				//SBGEXP-5664: DM Simplified logon for lender
				if(	genericSession != null && genericSession.getAttribute(MobileSessionImpl.MORTGAGE_LENDER_ID) != null){
					lenderId = (String)genericSession.getAttribute(MobileSessionImpl.MORTGAGE_LENDER_ID);
					Logger.info("LenderId in session from native app : " + lenderId, this.getClass());
				}
				
				Logger.info("The value for data lenderId is  " + lenderId,this.getClass());
				
				if(!StringMethods.isEmptyString(lenderId) && StringUtil.isValidAlphaNumeric(lenderId) )
				{
					MortgageLenderService mortgageLenderService = (MortgageLenderService) ServiceHelper.getBean("mortgageLenderService");
					if (  mortgageLenderService.isMortgageLenderInitiatedSwtichON(origin) )
					{
						request.setAttribute( DATA_LENDERID , lenderId );
					}
					else{
						//sending "", to avoid UI to receive "null".
						request.setAttribute( DATA_LENDERID , IBankParams.BLANK_STRING );
					}
				}
				else{
					//sending "", to avoid UI to receive "null".
					request.setAttribute( DATA_LENDERID , IBankParams.BLANK_STRING );
				}
				
				//SBGEXP-5664: DM Simplified logon for lender
				//Added at the bottom. Since, above code is over ridding the DATA_LENDERID value, if request param is empty. But in native app, it won't be part of url, but as part of JWT
				/*if(!StringMethods.isEmptyString(nativeApplenderId) && StringUtil.isValidAlphaNumeric(nativeApplenderId) ){
					request.setAttribute( DATA_LENDERID , nativeApplenderId );
				}*/
				
				gdprWebHelper.gdpr(origin, request, response);
				Logger.debug(
						"Loading Mortgage page... "
								+ request.getRequestURL() + " IP :"
								+ request.getRemoteAddr() +
								" True IP >> " + request.getHeader(IBankParams.trueClientIP()), this.getClass());
				model = new ModelAndView(PAGE_NAME);
			}
			return model;
		}
		catch (BusinessException e) {
			//origin = "MSTG";
			request.setAttribute("errorCode", e.getKey());
			request.setAttribute(MBAppHelper.HTTP_ORIGIN_ATTRIBUTE, LogonHelper.resolveOrigin(request));
			model = new ModelAndView(ERROR_VIEW);
			Logger.error("Error in Main Controller ", e, this.getClass());
			return model;
		}

		catch (Exception e) {
			origin = "MSTG";
			request.setAttribute(LogonHelper.ORIGIN, origin);
			model = new ModelAndView(ERROR_VIEW);
			Logger.error("Error in Main Controller ", e, this.getClass());
			return model;
		} finally {
			if ( genericSession != null )
				genericSession.updateSession();	
			numberOfRequests--;
			performanceLogger.endLog(logName);
			performanceLogger.endAllLogs();
		}

	}
	
	private boolean isValidReferenceNumber(String referenceNumbe) {
		boolean validRefNumber=false;		
		String REGEX = "[a-zA-Z0-9]*";
		Pattern pattern = Pattern.compile(REGEX);
		Matcher matcher = pattern.matcher(referenceNumbe);
		if (matcher.matches()){
			validRefNumber=true;
		}
		return validRefNumber;
	}

	private SystemInformation getSystemInformationDtls() {
		SystemInformation systemInformation = (SystemInformation) ServiceHelper
				.getBean("systemInformation");
		return systemInformation;

	}

	@Autowired
	private LogonHelper logonHelper;

	@Autowired
	private GDPRWebHelper gdprWebHelper;

	@Autowired
	private MortgageHelper mortgageHelper;
	
	@Autowired
	private SystemInformation systemInformation;

}
