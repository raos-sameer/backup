package au.com.stgeorge.mbank.model.common;

import java.io.Serializable;

public class FavTranReq implements IMBReq, Serializable
{
	
	private ReqHeader header;

	public ReqHeader getHeader()
	{
		return header;
	}

	public void setHeader(ReqHeader header)
	{
		this.header = header;
	}



	private int index;

	public int getTranIndex()
	{
		return index;
	}

	public void setTranIndex(int index)
	{
		this.index = index;
	}



	private String aliasName;



	public String getAliasName()
	{
		return aliasName;
	}

	public void setAliasName(String aliasName)
	{
		this.aliasName = aliasName;
	}


	private String tranAmount;

	public String getTranAmount()
	{
		return tranAmount;
	}

	public void setTranAmount(String tranAmount)
	{
		this.tranAmount = tranAmount;
	}
	
	private boolean favouriteFlag;

	public boolean isFavouriteFlag()
	{
		return favouriteFlag;
	}

	public void setFavouriteFlag(boolean favouriteFlag)
	{
		this.favouriteFlag = favouriteFlag;
	}
	
	
	private Integer fromAccountIndex;
	private Integer toItemIndex;
	private int tranType;
	private int paymentLogId;
	private boolean sendEmail;
	private String payeeEmail;

	public int getIndex()
	{
		return index;
	}

	public void setIndex(int index)
	{
		this.index = index;
	}

	public Integer getFromAccountIndex()
	{
		return fromAccountIndex;
	}

	public void setFromAccountIndex(Integer fromAccountIndex)
	{
		this.fromAccountIndex = fromAccountIndex;
	}

	public Integer getToItemIndex()
	{
		return toItemIndex;
	}

	public void setToItemIndex(Integer toItemIndex)
	{
		this.toItemIndex = toItemIndex;
	}

	public int getTranType()
	{
		return tranType;
	}

	public void setTranType(int tranType)
	{
		this.tranType = tranType;
	}

	public int getPaymentLogId()
	{
		return paymentLogId;
	}

	public void setPaymentLogId(int paymentLogId)
	{
		this.paymentLogId = paymentLogId;
	}

	public boolean isSendEmail()
	{
		return sendEmail;
	}

	public void setSendEmail(boolean sendEmail)
	{
		this.sendEmail = sendEmail;
	}

	public String getPayeeEmail()
	{
		return payeeEmail;
	}

	public void setPayeeEmail(String payeeEmail)
	{
		this.payeeEmail = payeeEmail;
	}
	
	
	
	
	
}
