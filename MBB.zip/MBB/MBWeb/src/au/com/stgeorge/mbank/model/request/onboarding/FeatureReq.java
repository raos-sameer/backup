package au.com.stgeorge.mbank.model.request.onboarding;

import java.io.Serializable;

import javax.validation.constraints.NotNull;

import org.apache.commons.lang.builder.ReflectionToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;

import au.com.stgeorge.ibank.businessobject.BusinessException;
import au.com.stgeorge.mbank.model.common.IMBReq;
import au.com.stgeorge.mbank.model.common.ReqHeader;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_NULL)
public class FeatureReq implements IMBReq,Serializable{
	
	private static final long serialVersionUID = 2022242446298729854L;

	// @Valid TODO
	private ReqHeader header;

	@NotNull(message = "" + BusinessException.WSVC_INVALID_INPUT_PARAM)
	private Long featureID;

	public Long getFeatureID() {
		return featureID;
	}

	public ReqHeader getHeader() {
		return header;
	}

	public void setHeader(ReqHeader header) {
		this.header = header;
	}

	@Override
	public String toString() {
		return ReflectionToStringBuilder.toString(this, ToStringStyle.MULTI_LINE_STYLE);
	}
}
