package au.com.stgeorge.mbank.model.request.payments;

import javax.validation.constraints.Pattern;

import org.apache.commons.lang.builder.ReflectionToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;
import org.hibernate.validator.constraints.NotEmpty;

import au.com.stgeorge.ibank.businessobject.BusinessException;
import au.com.stgeorge.mbank.model.common.IMBReq;
import au.com.stgeorge.mbank.model.common.ReqHeader;

/**
 * CC Details request
 * 
 * @author C38854
 * 
 */
public class BillerDetailsReq implements IMBReq {

	private static final long serialVersionUID = 2022242446298729854L;

	// @Valid TODO
	private ReqHeader header;

	@NotEmpty(message = "" + BusinessException.WSVC_INVALID_INPUT_PARAM)
	@Pattern(regexp = "^[0-9]+$", message = "" + BusinessException.WSVC_INVALID_INPUT_PARAM)
	private String code;

	public String getCode() {
		return code;
	}

	public ReqHeader getHeader() {
		return header;
	}

	public void setHeader(ReqHeader header) {
		this.header = header;
	}

	@Override
	public String toString() {
		return ReflectionToStringBuilder.toString(this, ToStringStyle.MULTI_LINE_STYLE);
	}

}
