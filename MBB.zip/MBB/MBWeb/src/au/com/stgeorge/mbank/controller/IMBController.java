package au.com.stgeorge.mbank.controller;

import javax.servlet.http.HttpServletRequest;

import au.com.stgeorge.ibank.businessobject.BusinessException;
import au.com.stgeorge.mbank.model.common.ReqHeader;
import au.com.stgeorge.mbank.model.common.RespHeader;
import au.com.stgeorge.mbank.model.common.IMBReq;
import au.com.stgeorge.mbank.model.response.ErrorResp;
import au.com.stgeorge.mbank.session.MobileSession;

public interface IMBController
{
		public void validateRequestHeader(ReqHeader headerReq, HttpServletRequest request) throws BusinessException;
		public ErrorResp validate(IMBReq serviceRequest, HttpServletRequest httpRequest) throws BusinessException;
		public RespHeader populateResponseHeader(String serviceName, MobileSession mobileSession);
}
