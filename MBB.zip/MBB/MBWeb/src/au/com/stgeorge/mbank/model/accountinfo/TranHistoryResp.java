package au.com.stgeorge.mbank.model.accountinfo;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_NULL)
public class TranHistoryResp {

	private Boolean hasMoreTran=false;
	
	private Boolean noMoreRecordsStored=false;
	
	public Boolean getNoMoreRecordsStored() {
		return noMoreRecordsStored;
	}
	public void setNoMoreRecordsStored(Boolean noMoreRecordsStored) {
		this.noMoreRecordsStored = noMoreRecordsStored;
	}
	private Boolean maxTransactionsReached = false;
	public Boolean getMaxTransactionsReached() {
		return maxTransactionsReached;
	}
	public void setMaxTransactionsReached(Boolean maxTransactionsReached) {
		this.maxTransactionsReached = maxTransactionsReached;
	}
	private List<TranDetailResp> tranList;
	private String toDate;
	
	public Boolean isHasMoreTran() {
		return hasMoreTran;
	}
	public void setHasMoreTran(Boolean hasMoreTran) {
		this.hasMoreTran = hasMoreTran;
	}
	public List<TranDetailResp> getTranList() {
		return tranList;
	}
	public void setTranList(List<TranDetailResp> tranList) {
		this.tranList = tranList;
	}
	public String getToDate() {
		return toDate;
	}
	public void setToDate(String toDate) {
		this.toDate = toDate;
	}
	
  private BigDecimal openingBalance;
  private BigDecimal closingBalance;

  private Date closingDate;
  private Date openDate;

	public BigDecimal getOpeningBalance()
	{
		return openingBalance;
	}
	public void setOpeningBalance(BigDecimal openingBalance)
	{
		this.openingBalance = openingBalance;
	}
	public BigDecimal getClosingBalance()
	{
		return closingBalance;
	}
	public void setClosingBalance(BigDecimal closingBalance)
	{
		this.closingBalance = closingBalance;
	}
	public Date getClosingDate()
	{
		return closingDate;
	}
	public void setClosingDate(Date closingDate)
	{
		this.closingDate = closingDate;
	}
	public Date getOpenDate()
	{
		return openDate;
	}
	public void setOpenDate(Date openDate)
	{
		this.openDate = openDate;
	}

	
}
