package au.com.stgeorge.mbank.controller.customer;

import au.com.stgeorge.digitalsec.logger.DigitalSecLogger;
import au.com.stgeorge.digitalsec.logger.DigitalSecLogggerVO;
import au.com.stgeorge.framework.common.logging.Logger;
import au.com.stgeorge.framework.common.util.StringMethods;
import au.com.stgeorge.ibank.businessobject.*;
import au.com.stgeorge.ibank.businessobject.assembler.CustomerVOAssembler;
import au.com.stgeorge.ibank.common.cache.IBankParams;
import au.com.stgeorge.ibank.model.idp.IdpConfig;
import au.com.stgeorge.ibank.safi.businessobject.Safi2Service;
import au.com.stgeorge.ibank.safi.util.SafiConstants;
import au.com.stgeorge.ibank.safi.valueobject.SafiFileshareVO;
import au.com.stgeorge.ibank.service.valueobject.SafiRespVO;
import au.com.stgeorge.ibank.util.ServiceHelper;
import au.com.stgeorge.ibank.valueobject.ContactDetail;
import au.com.stgeorge.ibank.valueobject.Customer;
import au.com.stgeorge.ibank.valueobject.IDPSSODetails;
import au.com.stgeorge.ibank.valueobject.SAMLStore;
import au.com.stgeorge.ibank.valueobject.database.CodesVO;
import au.com.stgeorge.ibank.valueobject.database.OriginsVO;
import au.com.stgeorge.ibank.valueobject.transfer.IBankCommonData;
import au.com.stgeorge.mbank.controller.IMBController;
import au.com.stgeorge.mbank.controller.SafiWebHelper;
import au.com.stgeorge.mbank.controller.SecureCodeHelper;
import au.com.stgeorge.mbank.controller.services.OIDCHelper;
import au.com.stgeorge.mbank.model.common.*;
import au.com.stgeorge.mbank.model.request.SecureCodeReq;
import au.com.stgeorge.mbank.model.request.customer.FileshareReq;
import au.com.stgeorge.mbank.model.response.ErrorResp;
import au.com.stgeorge.mbank.model.response.customer.FileshareResp;
import au.com.stgeorge.mbank.session.MobileSession;
import au.com.stgeorge.mbank.util.*;
import au.com.stgeorge.mobilebank.businessobject.MobileBankService;
import au.com.stgeorge.perflogger.PerformanceLogger;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.Date;

@Controller
@RequestMapping("/fileshare")
public class FileshareController  implements IMBController {


	private static final String SRV_TOKEN_TYPE = "OIDCToken";

	@Autowired
	private MemoryThrottlingService memoryThrottlingService;
    
    @Autowired
    private FileshareControllerHelper fileshareHelper;
    
	@Autowired
	private SecureCodeHelper secureCodeHelper;
	
	@Autowired
	private MBAppHelper mbAppHelper;
	
	@Autowired
	private MBAppValidator mbAppValidator;
	
	@Autowired
    private DigitalSecLogger digitalSecurityLogger;
	
	@Autowired
	private MobileBankService mobileBankService;
	
	@Autowired
	private Safi2Service safi2Service; 
	
	@Autowired
	private LogonHelper logonHelper;
	
	@Autowired
	private FileshareService fileshareService;
	
	@Autowired
	private FileShareDigiSecLoggerService fileShareDigiSecLoggerService;

	@Autowired
	private OIDCService oidcService;
	
	
	@PostMapping(path="fileshare2FA", headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public IMBResp fileshare2FA(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, @RequestBody final FileshareReq req)
	{
		PerformanceLogger performanceLogger = new PerformanceLogger();
		performanceLogger.startAllLogs();
		
		
		
		String logName = MBAppUtils.getLogName(httpServletRequest);
		performanceLogger.startLog(logName);
		
		String origin = null;
		MobileSession mbSession = null;
				
		DigitalSecLogggerVO digitalSecurityLogVO =new DigitalSecLogggerVO();
		digitalSecurityLogVO.setTranName(DigitalSecLogger.FILESHARE);
		
		FileshareResp fileshareResp = new FileshareResp();
		ObjectMapper mapper = new ObjectMapper();
		try
		{
			mbSession = mbAppHelper.getMobileSession(httpServletRequest);
            validateRequestHeader( req.getHeader(), httpServletRequest );
			origin = mbSession.getOrigin();

			ErrorResp errorResp = validate(req, httpServletRequest);
			if (errorResp != null && errorResp.getErrors() != null && errorResp.getErrors().size() > 0)
			{
				return errorResp;
			}
			Customer customer=mbSession.getCustomer();
						
			IBankCommonData ibankCommonData=mbAppHelper.populateIBankCommonData(mbSession,httpServletRequest);
			
			fileshareHelper.setStatisticGDWLog(ibankCommonData);
			
			RespHeader headerResp = populateResponseHeader(req.getHeader().getServiceName(), mbSession );
			fileshareResp.setHeader(headerResp);
			
			if(mbSession.getSafiRequestVO()!=null) {
				mbSession.removeSafiRequestVO();
			}
			
			boolean isSafiFileshareSwitchOn = IBankParams.isSwitchOn(IBankParams.DEFAULT_ORIGIN, IBankParams.SAFI_FILESHARE_SWITCH);
			Logger.debug("SAFI : fileshare switch Value: "+isSafiFileshareSwitchOn, this.getClass());
			boolean isSafiServiceAvailable = false;
			
			if(isSafiFileshareSwitchOn){
				isSafiServiceAvailable = HeartBeat.isApplicationAvailable(HeartBeat.SAFI2_SERVICE_APPLICATION);
				Logger.info("SAFI : fileshare2FA :: SAFI2_SERVICE_APPLICATION STATUS: "+isSafiServiceAvailable, this.getClass());
			}
			boolean isMobileApp = ((logonHelper.loadCordova(httpServletRequest)) == -1) ? false:true;
			if(isSafiServiceAvailable){
				
				boolean	isThrottleAllowed = memoryThrottlingService.processThrottling(IBankParams.THROTTLE_CAT_FILE_SHARE, customer.getGcis(), mbSession.getSessionID());
										
				if(isThrottleAllowed){
					FileshareResp response = (FileshareResp) callSafiAnalyse(httpServletRequest, httpServletResponse, mbSession, ibankCommonData, req, fileshareResp,mapper,isMobileApp);
					
					if(!response.isSecureCodeReqd()) {
						
						Logger.info("SAFI : fileshare2FA :: isMobileApp: "+isMobileApp, this.getClass());
						String saml =  fileshareService.createFileshareSAML(ibankCommonData);
						if(isMobileApp){
							
							Date today = new Date();
							SAMLStore samlStore = new SAMLStore();
							String pdfToken = mbAppHelper.getPdfDocToken();
							samlStore.setToken(pdfToken);
							samlStore.setCreatedBy(mbSession.getUser().getUserId());
							samlStore.setCreatedOn(today);
							//samlStore.setExpiryTime(today);
							samlStore.setGcisNumber(mbSession.getCustomer().getGcis());
							samlStore.setSamlData(saml);
							samlStore.setFeature("FileShare");
							
							fileshareService.addSamlResponseToStore(samlStore);	
							
							response.setToken(pdfToken);	
							Logger.info("SAFI : fileshare2FA :: pdfToken: "+pdfToken, this.getClass());
						}						
						else {
							response.setSamlResponse(fileshareService.deflateSAMLObject(saml));
						    String URL=getRelayStateURL(ibankCommonData);
							response.setRelayState(URL);
							response.setSamlPOSTBindingURL(fileshareService.getRecipientURL(ibankCommonData));
						}					
					}
					return response;
				}
			} else {			
				int errorID=0;boolean errorFlag=false;String status;
				if (getRegisteredPhoneNumberCount(ibankCommonData.getCustomer().getContactDetail()) == 0) {
					errorID=(BusinessException.SAFI_FILESHARE_NO_PHONE_EXIST);
					status=DigitalSecLogger.FAILURE;
					errorFlag=true;
				} else if (IBankSecureService.isCustomerExempt(ibankCommonData.getCustomer().getIBankSecureDetails())) {
					errorID=(BusinessException.SAFI_FILESHARE_2FA_EXEMPT);
					status=DigitalSecLogger.FAILURE;
					errorFlag=true;
				} else if (IBankParams.isGlobalByPass()) {
					errorID=(BusinessException.SAFI_FILESHARE_2FA_GLOBAL_BYPASS);
					status=DigitalSecLogger.FAILURE;;
					errorFlag=true;
				}else {
					status="Pending2FA";
				}
			
				DigitalSecLogggerVO digitalSecLogggerVO=fileShareDigiSecLoggerService.initializeDigitalLogger(ibankCommonData, DigitalSecLogger.ACCESSDOCUMENTSHARE_SAFIOFFHOST, status);
				fileShareDigiSecLoggerService.logDigiSecForSafiAnalyseSAFISwitchOFF(digitalSecLogggerVO, ibankCommonData);
				
				if(errorFlag) {
					throw new BusinessException(errorID);
				}
				fileshareResp.setSecureCodeReqd(true);
				
				return fileshareResp;
			}
			
			return null;
			
		} catch (BusinessException e)
		{
		//	digitalSecurityLogVO.setStatus(DigitalSecLogger.FAILURE);
		//	digitalSecurityLogger.log(digitalSecurityLogVO);
			
			IMBResp resp1 = null;
			Logger.error("Exception Inside fileshare2FA for Customer "+ e.getKey(), e, this.getClass());
			
			if(e.getKey()==BusinessException.SAFI_FILESHARE_2FA_DENY ||
					e.getKey()==BusinessException.SAFI_FILESHARE_2FA_EXEMPT ||
					e.getKey()==BusinessException.SAFI_FILESHARE_NO_PHONE_EXIST ||
					e.getKey()==BusinessException.SAFI_FILESHARE_2FA_GLOBAL_BYPASS){
				
				Logger.debug("BusinessException in fileshare2FA - DENY/Exempt/No Phone ERROR", this.getClass());
			
				OriginsVO myOriginVO = IBankParams.getOrigin(mbSession.getOrigin());
				OriginsVO baseOrigin = IBankParams.getOrigin(myOriginVO.getBankName());
				String[] values = null;
				
				if(e.getKey()==BusinessException.SAFI_FILESHARE_2FA_DENY)
					values = new String[] {baseOrigin.getBpayPhone()};
				else if(e.getKey() == BusinessException.SAFI_FILESHARE_2FA_GLOBAL_BYPASS)
					values = new String[] {baseOrigin.getName()};
				else
					values = new String[] {baseOrigin.getPhone()};
				
				IMBResp resp = MBAppUtils.createErrorResp(IBankParams.getBaseOriginCode(mbSession.getOrigin()), e,values, ServiceConstants.FILESHARE, httpServletRequest);
				return resp;
			}
			
			
			if (e.getValues() != null) {
				resp1 = MBAppUtils.createErrorResp(origin , e, e.getValues(), MBAppConstants.FILESHARE, httpServletRequest);
			} else if ( e.getKey() == 9898) { //  HOST ERROR TRANSACTION ROLLBACK 
				BusinessException exp = new BusinessException(BusinessException.GENERIC_ERROR);
				resp1 = MBAppUtils.createErrorResp(origin, exp, MBAppConstants.FILESHARE, httpServletRequest);
			} else{
				resp1 = MBAppUtils.createErrorResp(origin, e, MBAppConstants.FILESHARE, httpServletRequest);
			}
			return resp1;
			
		} catch (Exception e)
		{
	//		digitalSecurityLogVO.setStatus(DigitalSecLogger.FAILURE);
	//		digitalSecurityLogger.log(digitalSecurityLogVO);
			
			Logger.error("Exception Inside fileshare2FA() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			BusinessException exp = new BusinessException(BusinessException.GENERIC_ERROR);
			IMBResp resp1 = MBAppUtils.createErrorResp(origin, exp, MBAppConstants.FILESHARE, httpServletRequest);
			return resp1;
		} finally
		{
			performanceLogger.endLog(logName);
			performanceLogger.endAllLogs();
		}
	}



	@PostMapping(path="check2FA", headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public IMBResp check2FA(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, @RequestBody final FileshareReq req)
	{
		PerformanceLogger performanceLogger = new PerformanceLogger();
		performanceLogger.startAllLogs();



		String logName = MBAppUtils.getLogName(httpServletRequest);
		performanceLogger.startLog(logName);

		String origin = null;
		MobileSession mbSession = null;

		DigitalSecLogggerVO digitalSecurityLogVO =new DigitalSecLogggerVO();
		digitalSecurityLogVO.setTranName(DigitalSecLogger.FILESHARE);

		FileshareResp fileshareResp = new FileshareResp();
		ObjectMapper mapper = new ObjectMapper();
		try
		{
			mbSession = mbAppHelper.getMobileSession(httpServletRequest);
			validateRequestHeader( req.getHeader(), httpServletRequest );
			origin = mbSession.getOrigin();

			ErrorResp errorResp = validate(req, httpServletRequest);
			if (errorResp != null && errorResp.getErrors() != null && errorResp.getErrors().size() > 0)
			{
				return errorResp;
			}
			Customer customer=mbSession.getCustomer();

			IBankCommonData ibankCommonData=mbAppHelper.populateIBankCommonData(mbSession,httpServletRequest);

			fileshareHelper.setStatisticGDWLog(ibankCommonData);

			RespHeader headerResp = populateResponseHeader(req.getHeader().getServiceName(), mbSession );
			fileshareResp.setHeader(headerResp);

			if(mbSession.getSafiRequestVO()!=null) {
				mbSession.removeSafiRequestVO();
			}

			boolean isSafiFileshareSwitchOn = IBankParams.isSwitchOn(IBankParams.DEFAULT_ORIGIN, IBankParams.SAFI_FILESHARE_SWITCH);
			Logger.debug("SAFI : fileshare switch Value: "+isSafiFileshareSwitchOn, this.getClass());
			boolean isSafiServiceAvailable = false;

			if(isSafiFileshareSwitchOn){
				isSafiServiceAvailable = HeartBeat.isApplicationAvailable(HeartBeat.SAFI2_SERVICE_APPLICATION);
				Logger.info("SAFI : check2FA :: SAFI2_SERVICE_APPLICATION STATUS: "+isSafiServiceAvailable, this.getClass());
			}
		//	boolean isMobileApp = ((logonHelper.loadCordova(httpServletRequest)) == -1) ? false:true;
			if(isSafiServiceAvailable){

				boolean	isThrottleAllowed = memoryThrottlingService.processThrottling(IBankParams.THROTTLE_CAT_FILE_SHARE, customer.getGcis(), mbSession.getSessionID());
				boolean isMobileApp = ((logonHelper.loadCordova(httpServletRequest)) == -1) ? false:true;
				if(isThrottleAllowed){
					FileshareResp response = (FileshareResp) callSafiAnalyse(httpServletRequest, httpServletResponse, mbSession, ibankCommonData, req, fileshareResp,mapper,isMobileApp);

					String baseOrigin = IBankParams.getBaseOriginCode(ibankCommonData.getOrigin());
					if(!response.isSecureCodeReqd()) {


						String cookieName = "IBVrfyTk";
						String cookieValue = "";
						//Create cookie to know which application(IB or MB) has launched Vendor

						IDPSSODetails idpSSODetails = new IDPSSODetails();
						idpSSODetails.setCreationTime(new Date());
						idpSSODetails.setCustomerType("P");
						idpSSODetails.setGcisNumber(ibankCommonData.getUser().getGCISNumber());
						idpSSODetails.setSessionId(mbSession.getSessionID());
						idpSSODetails.setTokenType(SRV_TOKEN_TYPE);
						idpSSODetails.setFirstName(ibankCommonData.getCustomer().getFirstName());
						idpSSODetails.setLastName(ibankCommonData.getCustomer().getLastName());
						idpSSODetails.setCan(ibankCommonData.getUser().getUserId());
						idpSSODetails.setAcctBrand(baseOrigin);
						//	Logger.info("About to get Token : "+app, this.getClass());

						cookieValue = oidcService.getServiceTokenId(idpSSODetails, ibankCommonData, SRV_TOKEN_TYPE, true);

						Logger.info("Got Token for vendor launch: " + cookieValue, this.getClass());

						mbSession.setidpSSODetails(idpSSODetails);

						Logger.info("Update Session Got Token : " + cookieValue + "Sess Id " + idpSSODetails.getSessionId(), this.getClass());

						OIDCHelper.addCompassAppTypeCookie(baseOrigin, httpServletRequest, httpServletResponse, cookieName, "MB:" + cookieValue);
					}

						String clientId=null,scope=null,partnerSpId=null;

					CodesVO codeItem=IBankParams.getCodesData(baseOrigin , IBankParams.FEATURES,IBankParams.FILESHARE_CLIENT_ID);
						if ( codeItem != null && ! StringMethods.isEmptyString(codeItem.getMessage()))
						{
							clientId=codeItem.getMessage();
							Logger.debug("FileshareController - clientId " + clientId, this.getClass());
						}


					codeItem=IBankParams.getCodesData(baseOrigin , IBankParams.FILESHARE_CATEGORY,IBankParams.FILESHARE_SCOPE);
					if ( codeItem != null && ! StringMethods.isEmptyString(codeItem.getMessage()))
					{
						scope=codeItem.getMessage();
						Logger.debug("FileshareController - scope " + clientId, this.getClass());
					}

					codeItem=IBankParams.getCodesData(baseOrigin , IBankParams.FEATURES,IBankParams.FILESHARE_PARTNER_SP_ID);
					if ( codeItem != null && ! StringMethods.isEmptyString(codeItem.getMessage()))
					{
						partnerSpId=codeItem.getMessage();
						Logger.debug("FileshareController - scope " + clientId, this.getClass());
					}

					IdpConfig idpConfig = oidcService.getCommonIdpConfigs(baseOrigin,clientId, scope, true);
					idpConfig.setScope(scope);
					idpConfig.setClientId(clientId);
					idpConfig.setPartnerSpId(partnerSpId);
					response.setIdpConfig(idpConfig);

					return response;
				}
			} else {
				int errorID=0;boolean errorFlag=false;String status;
				if (getRegisteredPhoneNumberCount(ibankCommonData.getCustomer().getContactDetail()) == 0) {
					errorID=(BusinessException.SAFI_FILESHARE_NO_PHONE_EXIST);
					status=DigitalSecLogger.FAILURE;
					errorFlag=true;
				} else if (IBankSecureService.isCustomerExempt(ibankCommonData.getCustomer().getIBankSecureDetails())) {
					errorID=(BusinessException.SAFI_FILESHARE_2FA_EXEMPT);
					status=DigitalSecLogger.FAILURE;
					errorFlag=true;
				} else if (IBankParams.isGlobalByPass()) {
					errorID=(BusinessException.SAFI_FILESHARE_2FA_GLOBAL_BYPASS);
					status=DigitalSecLogger.FAILURE;;
					errorFlag=true;
				}else {
					status="Pending2FA";
				}

				DigitalSecLogggerVO digitalSecLogggerVO=fileShareDigiSecLoggerService.initializeDigitalLogger(ibankCommonData, DigitalSecLogger.ACCESSDOCUMENTSHARE_SAFIOFFHOST, status);
				fileShareDigiSecLoggerService.logDigiSecForSafiAnalyseSAFISwitchOFF(digitalSecLogggerVO, ibankCommonData);

				if(errorFlag) {
					throw new BusinessException(errorID);
				}
				fileshareResp.setSecureCodeReqd(true);

				return fileshareResp;
			}

			return null;

		} catch (BusinessException e)
		{
			//	digitalSecurityLogVO.setStatus(DigitalSecLogger.FAILURE);
			//	digitalSecurityLogger.log(digitalSecurityLogVO);

			IMBResp resp1 = null;
			Logger.error("Exception Inside fileshare2FA for Customer "+ e.getKey(), e, this.getClass());

			if(e.getKey()==BusinessException.SAFI_FILESHARE_2FA_DENY ||
					e.getKey()==BusinessException.SAFI_FILESHARE_2FA_EXEMPT ||
					e.getKey()==BusinessException.SAFI_FILESHARE_NO_PHONE_EXIST ||
					e.getKey()==BusinessException.SAFI_FILESHARE_2FA_GLOBAL_BYPASS){

				Logger.debug("BusinessException in fileshare2FA - DENY/Exempt/No Phone ERROR", this.getClass());

				OriginsVO myOriginVO = IBankParams.getOrigin(mbSession.getOrigin());
				OriginsVO baseOrigin = IBankParams.getOrigin(myOriginVO.getBankName());
				String[] values = null;

				if(e.getKey()==BusinessException.SAFI_FILESHARE_2FA_DENY)
					values = new String[] {baseOrigin.getBpayPhone()};
				else if(e.getKey() == BusinessException.SAFI_FILESHARE_2FA_GLOBAL_BYPASS)
					values = new String[] {baseOrigin.getName()};
				else
					values = new String[] {baseOrigin.getPhone()};

				IMBResp resp = MBAppUtils.createErrorResp(IBankParams.getBaseOriginCode(mbSession.getOrigin()), e,values, ServiceConstants.FILESHARE, httpServletRequest);
				return resp;
			}


			if (e.getValues() != null) {
				resp1 = MBAppUtils.createErrorResp(origin , e, e.getValues(), MBAppConstants.FILESHARE, httpServletRequest);
			} else if ( e.getKey() == 9898) { //  HOST ERROR TRANSACTION ROLLBACK
				BusinessException exp = new BusinessException(BusinessException.GENERIC_ERROR);
				resp1 = MBAppUtils.createErrorResp(origin, exp, MBAppConstants.FILESHARE, httpServletRequest);
			} else{
				resp1 = MBAppUtils.createErrorResp(origin, e, MBAppConstants.FILESHARE, httpServletRequest);
			}
			return resp1;

		} catch (Exception e)
		{
			//		digitalSecurityLogVO.setStatus(DigitalSecLogger.FAILURE);
			//		digitalSecurityLogger.log(digitalSecurityLogVO);

			Logger.error("Exception Inside fileshare2FA() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			BusinessException exp = new BusinessException(BusinessException.GENERIC_ERROR);
			IMBResp resp1 = MBAppUtils.createErrorResp(origin, exp, MBAppConstants.FILESHARE, httpServletRequest);
			return resp1;
		} finally
		{
			performanceLogger.endLog(logName);
			performanceLogger.endAllLogs();
		}
	}

	@RequestMapping(value="reqsecurecode", method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public IMBResp reqSecureCode(HttpServletRequest httpRequest, HttpServletResponse httpServletResponse,
			@RequestBody final SecureCodeReq request)
	{
		Logger.debug("In reqSecCode for Customer " +  "  " + httpRequest.getContentType() + " "
				+ httpRequest.getRemoteAddr() + "  " + httpServletResponse.getCharacterEncoding() + httpServletResponse.getLocale() +
				" True IP >> " + httpRequest.getHeader(IBankParams.trueClientIP()), this.getClass());

		PerformanceLogger performanceLogger = new PerformanceLogger();
		
		performanceLogger.startAllLogs();
		String logName = MBAppUtils.getLogName(httpRequest);
		performanceLogger.startLog(logName);
		MobileSession mbSession = null;
		try {
			mbSession = mbAppHelper.getMobileSession(httpRequest);
			validateRequestHeader( request.getHeader(), httpRequest );
			
			ErrorResp errorResponse = validate(request, httpRequest);
			if (errorResponse.hasErrors())
				return errorResponse;
			
			
			//check SafiFileshareVO exists in session.
			SafiFileshareVO safiVO = null;
			String safiAction = null;
			
			//check if this me
			if(null != mbSession.getSafiRequestVO() && mbSession.getSafiRequestVO() instanceof SafiFileshareVO) {
				
				Logger.debug("SAFI VO available in session. ", this.getClass());
				
				safiVO = (SafiFileshareVO) mbSession.getSafiRequestVO();
				
				if(null != safiVO.getSafiRespVO())
					safiAction = safiVO.getSafiRespVO().getSafiAction();
			} 
			
			IBankCommonData commonData=mbAppHelper.populateIBankCommonData(mbSession,httpRequest);
			
			IMBResp response = secureCodeHelper.reqSecureCode(commonData, mbSession, mbSession.getTransaction(), request, IBankSecureService.FILESHARE, httpRequest);
			
			//In case of error log the errors
			if(response instanceof ErrorResp){			
				errorResponse = (ErrorResp) response;
				if (errorResponse.hasErrors()){
					DigitalSecLogggerVO digitalSecLoggerVO =new DigitalSecLogggerVO();
					digitalSecLoggerVO.setUserAgent(commonData.getUserAgent()); 
					digitalSecLoggerVO.setTranName(DigitalSecLogger.FILESHARE);
					digitalSecLoggerVO.setStatus(DigitalSecLogger.FAILURE_2FA);
					digitalSecurityLogger.log(digitalSecLoggerVO);
					
					//SAFI notify call in case 2FA_SUSPENDED and SAFI_ACTION is a CHALLENGE
					if(errorResponse.getStatus() ==  ErrorResp.STATUS_2FA_SUSPENDED  && !(StringMethods.isEmptyString(safiAction)) && safiAction.equalsIgnoreCase(SafiConstants.SAFI_ACTION_CHALLENGE)){
						Logger.debug("SAFI : reqSecureCode(): Notify Call:START : SafiAction :Challenge: STATUS_2FA_SUSPENDED",this.getClass());
						callSafiNotify(httpRequest, httpServletResponse, false, commonData,mbSession);
						Logger.debug("SAFI : reqSecureCode(): Notify Call:END : SafiAction :Challenge: STATUS_2FA_SUSPENDED",this.getClass());
					}
					
					return errorResponse;
				}
			}
			
			
			return response;
		}
		catch (BusinessException e)
		{
			Logger.error("Exception Inside reqsecurecode() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			IMBResp resp1 = MBAppUtils.createErrorResp(mbSession.getOrigin(), e, MBAppConstants.FILESHARE, httpRequest);
			return resp1;
		} catch (Exception e)
		{
			Logger.error("Exception Inside reqsecurecode() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			BusinessException exp = new BusinessException(BusinessException.SMPL_SYS_ERROR);
			IMBResp resp1 = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, MBAppConstants.FILESHARE, httpRequest);
			return resp1;
		} finally
		{
			performanceLogger.endLog(logName);
			performanceLogger.endAllLogs();
		}
	}

	@RequestMapping(value="verifyseccode", method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public IMBResp verifySecCode(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, @RequestBody final SecureCodeReq req)
	{
		Logger.debug("In verifySecCode ( ContactDetailsController )  for Customer " +  "  " + httpServletRequest.getContentType() + " "
				+ httpServletRequest.getRemoteAddr() + "  " + httpServletResponse.getCharacterEncoding() + httpServletResponse.getLocale() +
				" True IP >> " + httpServletRequest.getHeader(IBankParams.trueClientIP()), this.getClass());

		PerformanceLogger performanceLogger = new PerformanceLogger();
		
		performanceLogger.startAllLogs();
		String logName = MBAppUtils.getLogName(httpServletRequest);
		performanceLogger.startLog(logName);
		ObjectMapper mapper = new ObjectMapper();
		MobileSession mbSession = null;
	
		
		try
		{
			mbSession = mbAppHelper.getMobileSession(httpServletRequest);

			validateRequestHeader( req.getHeader(), httpServletRequest );

			ErrorResp errorResp = validate(req, httpServletRequest);
			if (errorResp != null && errorResp.getErrors() != null && errorResp.getErrors().size() > 0)
			{
				return errorResp;
			}
			
			boolean isMobileApp = ((logonHelper.loadCordova(httpServletRequest)) == -1) ? false:true;
			String sdkDevicePrint= null;
			
			
			
			//check SafiFileshareVO exists in session.
			SafiFileshareVO safiVO = null;
			String safiAction = null;
			boolean safiFlow=false;
			boolean callPRM = true;
			
			if(null != mbSession.getSafiRequestVO() && mbSession.getSafiRequestVO() instanceof SafiFileshareVO) {
				
				Logger.debug("SAFI VO available in session. ", this.getClass());
				
				safiVO = (SafiFileshareVO) mbSession.getSafiRequestVO();
				safiFlow=true;
				if(null != safiVO.getSafiRespVO() && null != safiVO.getSafiRespVO().getSafiAction()) {
					callPRM = false;
					safiAction = safiVO.getSafiRespVO().getSafiAction();
					if(!(StringMethods.isEmptyString(safiAction)) && SafiConstants.SAFI_ACTION_CHALLENGE.equals(safiAction))
						sdkDevicePrint= 	populateSDKDevicePrint( mapper,  mbSession,  isMobileApp) ;
				
				}
			}
			
			IBankCommonData ibankCommonData=mbAppHelper.populateIBankCommonData(mbSession,httpServletRequest);
			DigitalSecLogggerVO digitalSecurityLogVO =null;
			ErrorResp errorResponse = secureCodeHelper.verifySecureCode(ibankCommonData, mbSession, mbSession.getTransaction(), req, IBankSecureService.FILESHARE, httpServletRequest);
			String tranName;
		
			if (errorResponse.hasErrors()){
				String status=DigitalSecLogger.FAILURE_2FA;
				if(safiFlow) {
					tranName= DigitalSecLogger.ACCESSDOCUMENTSHARE_SAFIANALYSE;
					digitalSecurityLogVO = fileShareDigiSecLoggerService.initializeDigitalLogger(ibankCommonData,tranName, status);
					fileShareDigiSecLoggerService.logDigiSecForSafi2FA(digitalSecurityLogVO, ibankCommonData,sdkDevicePrint,0, false, false,false);
				
				}
				else {
					tranName=DigitalSecLogger.ACCESSDOCUMENTSHARE_SAFIOFFHOST;
					digitalSecurityLogVO = fileShareDigiSecLoggerService.initializeDigitalLogger(ibankCommonData,tranName, status);
					fileShareDigiSecLoggerService.logDigiSecForSafi2FA(digitalSecurityLogVO, ibankCommonData,sdkDevicePrint,0, false, false,false);
					
				}
				
					
				//SAFI notify call in case 2FA_SUSPENDED and SAFI_ACTION is a CHALLENGE
				if(errorResponse.getStatus() ==  ErrorResp.STATUS_2FA_SUSPENDED  && !(StringMethods.isEmptyString(safiAction)) && safiAction.equalsIgnoreCase(SafiConstants.SAFI_ACTION_CHALLENGE)){
					Logger.debug("SAFI : verifySecCode(): Notify Call:START : SafiAction :Challenge: STATUS_2FA_SUSPENDED",this.getClass());
					callSafiNotify(httpServletRequest, httpServletResponse, false, ibankCommonData,mbSession);
					Logger.debug("SAFI : verifySecCode(): Notify Call:END : SafiAction :Challenge: STATUS_2FA_SUSPENDED",this.getClass());
				}
					return errorResponse;
			}else {
				
				if(safiFlow) {
					tranName= DigitalSecLogger.ACCESSDOCUMENTSHARE_SAFIANALYSE;
					digitalSecurityLogVO = fileShareDigiSecLoggerService.initializeDigitalLogger(ibankCommonData, tranName, DigitalSecLogger.SUCCESS);
					if(!(StringMethods.isEmptyString(safiAction)) && SafiConstants.SAFI_ACTION_CHALLENGE.equals(safiAction))
						callSafiNotify(httpServletRequest, httpServletResponse, true, ibankCommonData,mbSession);
					fileShareDigiSecLoggerService.logDigiSecForSafi2FA(digitalSecurityLogVO, ibankCommonData,sdkDevicePrint,0, true, false,false);
				}
				else {
					tranName=DigitalSecLogger.ACCESSDOCUMENTSHARE_SAFIOFFHOST;
					digitalSecurityLogVO = fileShareDigiSecLoggerService.initializeDigitalLogger(ibankCommonData, tranName, DigitalSecLogger.SUCCESS);
					fileShareDigiSecLoggerService.logDigiSecForSafi2FA(digitalSecurityLogVO, ibankCommonData,sdkDevicePrint,0, true, false,false);
				}
				
				if(callPRM) {
					//PRM call for SAFI off host scenario					
					PRMUpdateService prmServiceBean = (PRMUpdateService) ServiceHelper.getBean("prmServiceBean");
					prmServiceBean.sendPrmFileshare(ibankCommonData, fileshareService.populateDeviceRiskDetails(null, ibankCommonData));
				}
				
				
				
				
			}
			
			mbSession.setSecureCodeVerifiedTranName(ServiceConstants.FILESHARE);
			
			FileshareResp serviceResponse = new FileshareResp();
			serviceResponse.setSuccess(true);
			String baseOrigin=IBankParams.getBaseOriginCode(ibankCommonData.getOrigin());
			if(!IBankParams.isSwitchOn(baseOrigin,IBankParams.FILESHARE_PING_IDP_SWITCH)) {
				String saml = fileshareService.createFileshareSAML(ibankCommonData);
				if (isMobileApp) {
					Date today = new Date();
					SAMLStore samlStore = new SAMLStore();
					String pdfToken = mbAppHelper.getPdfDocToken();
					samlStore.setToken(pdfToken);
					samlStore.setCreatedBy(mbSession.getUser().getUserId());
					samlStore.setCreatedOn(today);
					//samlStore.setExpiryTime(today);
					samlStore.setGcisNumber(mbSession.getCustomer().getGcis());
					samlStore.setSamlData(saml);
					samlStore.setFeature("FileShare");

					fileshareService.addSamlResponseToStore(samlStore);
					serviceResponse.setToken(pdfToken);
					Logger.info("SAFI : verifySecCode :: pdfToken: " + pdfToken, this.getClass());
				} else {
					serviceResponse.setSamlResponse(fileshareService.deflateSAMLObject(saml));
					serviceResponse.setSamlPOSTBindingURL(fileshareService.getRecipientURL(ibankCommonData));
					String URL = getRelayStateURL(ibankCommonData);
					serviceResponse.setRelayState(URL);
					Logger.info("verifySecCode JSON Response :" + mapper.writeValueAsString(serviceResponse), this.getClass());
				}
			}
			else{

				String cookieName = "IBVrfyTk";
				String cookieValue = "";
				//Create cookie to know which application(IB or MB) has launched Vendor

				IDPSSODetails idpSSODetails = new IDPSSODetails();
				idpSSODetails.setCreationTime(new Date());
				idpSSODetails.setCustomerType("P");
				idpSSODetails.setGcisNumber(ibankCommonData.getUser().getGCISNumber());
				idpSSODetails.setSessionId(mbSession.getSessionID());
				idpSSODetails.setTokenType(SRV_TOKEN_TYPE);
				idpSSODetails.setFirstName(ibankCommonData.getCustomer().getFirstName());
				idpSSODetails.setLastName(ibankCommonData.getCustomer().getLastName());
				idpSSODetails.setCan(ibankCommonData.getUser().getUserId());
				idpSSODetails.setAcctBrand(baseOrigin);
				//	Logger.info("About to get Token : "+app, this.getClass());

				cookieValue = oidcService.getServiceTokenId(idpSSODetails, ibankCommonData, SRV_TOKEN_TYPE, true);

				Logger.info("Got Token for vendor launch: " + cookieValue, this.getClass());

				mbSession.setidpSSODetails(idpSSODetails);

				Logger.info("Update Session Got Token : " + cookieValue + "Sess Id " + idpSSODetails.getSessionId(), this.getClass());

				OIDCHelper.addCompassAppTypeCookie(baseOrigin, httpServletRequest, httpServletResponse, cookieName, "MB:" + cookieValue);
			}
			RespHeader headerResp = populateResponseHeader(ServiceConstants.FILESHARE, mbSession);
			serviceResponse.setHeader(headerResp);
			return serviceResponse;
		} catch (BusinessException e)
		{
			Logger.error("Exception Inside verifySecCode() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			
			IMBResp resp1 = MBAppUtils.createErrorResp( mbSession.getOrigin(), e, MBAppConstants.FILESHARE, httpServletRequest);
			return resp1;
		} catch (Exception e)
		{
			Logger.error("Exception Inside verifySecCode() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			
			BusinessException exp = new BusinessException(BusinessException.SMPL_SYS_ERROR);
			IMBResp resp1 = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, MBAppConstants.FILESHARE, httpServletRequest);
			return resp1;
		} finally
		{
			performanceLogger.endLog(logName);
			performanceLogger.endAllLogs();
		}
	}	

	public ErrorResp validate(IMBReq serviceRequest, HttpServletRequest httpServletRequest)
	{
		return mbAppValidator.validate(serviceRequest, httpServletRequest);
	}
	public void validateRequestHeader(ReqHeader header, HttpServletRequest request) throws ResourceException
	{
		mbAppValidator.validateRequestHeader(header,  request);
	}
	public RespHeader populateResponseHeader(String serviceName)
	{
		return mbAppHelper.populateResponseHeader(serviceName);
	}

	public RespHeader populateResponseHeader(String serviceName, MobileSession mobSession )
	{
		return mbAppHelper.populateResponseHeader(serviceName, mobSession);
	}	
	

	private IMBResp callSafiAnalyse(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, MobileSession mobileSession, IBankCommonData commonData,
			FileshareReq request, FileshareResp response,ObjectMapper mapper,boolean isMobileApp) throws ResourceException, BusinessException {
   		
		SafiFileshareVO safiVO = new SafiFileshareVO();
		
		try {
			safiVO = fileshareHelper.populateSafiVO(httpServletRequest, mobileSession, commonData, request);
			String sdkDevicePrint = populateSDKDevicePrint(mapper, mobileSession, isMobileApp);
			mobileBankService.safiAnalyzeForFileshare(commonData, safiVO,sdkDevicePrint);
			
			
			if(null != safiVO && null != safiVO.getSafiRespVO() && null != safiVO.getSafiRespVO().getSafiAction()) {
				if(SafiConstants.SAFI_ACTION_ALLOW.equalsIgnoreCase(safiVO.getSafiRespVO().getSafiAction()) || SafiConstants.SAFI_ACTION_REVIEW.equalsIgnoreCase(safiVO.getSafiRespVO().getSafiAction()))
					response.setSecureCodeReqd(false);
			}
			response.setSecureCodeReqd(false);
		} catch(BusinessException be){
		
			//Only in case of Challenge - set setSecureCodeReqd to TRUE
			//Otherwise throw exception
			if (be.getKey() == BusinessException.IBANK_SECURE_REQUIRED) {
				response.setSecureCodeReqd(true);
			} else{
				throw be;
			}
			
		}finally{			
			mobileSession.setSafiRequestVO(safiVO);
			fileshareHelper.handleSafiResponseinCookies(httpServletRequest ,httpServletResponse, safiVO.getSafiRespVO());
		}
		
	   		return response;
   	}
	
	private void callSafiNotify(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, boolean status2FA, IBankCommonData ibankCommonData, MobileSession mobileSession) {
		
		try{
					
			if(mobileSession.getSafiRequestVO() != null && mobileSession.getSafiRequestVO() instanceof SafiFileshareVO) {
				SafiFileshareVO safiVO = SafiWebHelper.populateSafiVOForFileshareNotify(httpServletRequest, mobileSession, ibankCommonData,  status2FA);
				
				SafiRespVO safiRespVO = safi2Service.notifySafiForFileshare(ibankCommonData, safiVO);
				
				fileshareHelper.handleSafiResponseinCookies(httpServletRequest, httpServletResponse, safiRespVO);
			}
		}catch(BusinessException be){
			Logger.warn("Exception in callSafiNotify: ", be , getClass());
		}finally{
			mobileSession.removeSafiRequestVO();
		}
	}	
	
	private String getRelayStateURL(IBankCommonData commonData) {
		CodesVO relayStateCode = IBankParams.getCodesData(IBankParams.getBaseOriginCode(commonData.getOrigin()), IBankParams.SAML_ENTITY_ID,IBankParams.FILESHARE_RELAY_STATE );
      	String relayStateURL = relayStateCode.getMessage();
      
      	CodesVO entityIDCode = IBankParams.getCodesData(IBankParams.getBaseOriginCode(commonData.getOrigin()), IBankParams.SAML_ENTITY_ID,IBankParams.FILESHARE_ENTITY_ID );
      	String entityID = entityIDCode.getMessage();
      
      	StringBuilder urlBuilder = new StringBuilder();
  		urlBuilder.append(relayStateURL);
  		urlBuilder.append("?entityid=");
  		urlBuilder.append(entityID);
  		return urlBuilder.toString();
  		
	}
   	
	private int getRegisteredPhoneNumberCount(ContactDetail contactDetail){
		int registeredPhoneNumberCount = 0;
		
		if (!CustomerVOAssembler.BUSINESS_CUSTOMER.equalsIgnoreCase(contactDetail.getCustTypeInd())){
			if (contactDetail.getHomeNumber() != null && !StringMethods.isEmptyString(contactDetail.getHomeNumber().getPhoneNumber())){
				registeredPhoneNumberCount++;
			}
		}
		if (contactDetail.getWorkNumber() != null && !StringMethods.isEmptyString(contactDetail.getWorkNumber().getPhoneNumber())){
			registeredPhoneNumberCount++;
		}
		if (contactDetail.getMobileNumber() != null && !StringMethods.isEmptyString(contactDetail.getMobileNumber().getPhoneNumber())){
			registeredPhoneNumberCount++;
		}
		return registeredPhoneNumberCount;
	}	
	
	private String populateSDKDevicePrint(ObjectMapper mapper, MobileSession mbSession, boolean isMobileApp) {
		String devicePrintForLogger = null;
		
		if (isMobileApp) {
				String sdkDevicePrint = mbSession.getSafiLogonInfo() != null ? mbSession.getSafiLogonInfo().getDevicePrint()
						: null;
				try {
					JsonNode jsonNode = mapper.readValue(sdkDevicePrint, JsonNode.class);
					devicePrintForLogger = jsonNode != null ? jsonNode.toString() : "";
					Logger.debug("FileshareController populateSDKDevicePrint():::: " + devicePrintForLogger, this.getClass());
				} catch (Exception e) {
					Logger.error("FileshareController populateSDKDevicePrint() Exception", e, this.getClass());
				}
				
			}
		return devicePrintForLogger;

	}



}
