package au.com.stgeorge.mbank.model.mortgageinfo;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_NULL)
public class DocUploadInfo implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 2793083565358534192L;

	private String fileName;	
	
	private String status;
	
	private Long applicantInd; // -- to validate with enum
	  
	private Long categoryId; // -- to 
	  
	private Long docAppMapId;
	
	private String description;
	
	private String size;

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Long getApplicantInd() {
		return applicantInd;
	}

	public void setApplicantInd(Long applicantInd) {
		this.applicantInd = applicantInd;
	}

	public Long getCategoryId() {
		return categoryId;
	}

	public void setCategoryId(Long categoryId) {
		this.categoryId = categoryId;
	}

	public Long getDocAppMapId() {
		return docAppMapId;
	}

	public void setDocAppMapId(Long docAppMapId) {
		this.docAppMapId = docAppMapId;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getSize() {
		return size;
	}

	public void setSize(String size) {
		this.size = size;
	}
	
}
