package au.com.stgeorge.mbank.controller.newaccount.cpp;
import java.math.BigDecimal;
import java.math.MathContext;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.commons.lang3.Range;

import au.com.stgeorge.framework.common.logging.Logger;
import au.com.stgeorge.framework.common.util.DateMethods;
import au.com.stgeorge.framework.common.util.StringMethods;
import au.com.stgeorge.ibank.businessobject.AccountFilter;
import au.com.stgeorge.ibank.businessobject.BusinessException;
import au.com.stgeorge.ibank.businessobject.CalculatorService;
import au.com.stgeorge.ibank.businessobject.ResourceException;
import au.com.stgeorge.ibank.businessobject.model.cpp.prcngoffer.EnumConstants.InterestFrequency;
import au.com.stgeorge.ibank.common.cache.IBankParams;
import au.com.stgeorge.ibank.cpp.util.InterestPaidEnum;
import au.com.stgeorge.ibank.cpp.valueobjects.TermDepositDetails;
import au.com.stgeorge.ibank.cpp.valueobjects.TermDepositProducts;
import au.com.stgeorge.ibank.util.ServiceHelper;
import au.com.stgeorge.ibank.util.StringUtil;
import au.com.stgeorge.ibank.util.TermDepositConstants;
import au.com.stgeorge.ibank.valueobject.Account;
import au.com.stgeorge.ibank.valueobject.AccountId;
import au.com.stgeorge.ibank.valueobject.Customer;
import au.com.stgeorge.ibank.valueobject.ExternalLinkVO;
import au.com.stgeorge.ibank.valueobject.TermDepositAccount;
import au.com.stgeorge.ibank.valueobject.TermDepositProduct;
import au.com.stgeorge.ibank.valueobject.ThirdParty;
import au.com.stgeorge.ibank.valueobject.database.AcctOpeningVO;
import au.com.stgeorge.ibank.valueobject.database.BranchVO;
import au.com.stgeorge.ibank.valueobject.database.CodesVO;
import au.com.stgeorge.ibank.valueobject.database.OriginsVO;
import au.com.stgeorge.ibank.valueobject.database.RegionVO;
import au.com.stgeorge.ibank.valueobject.transfer.IBankCommonData;
import au.com.stgeorge.ibank.valueobject.transfer.NewTermDepositAccount;
import au.com.stgeorge.ibank.valueobject.transfer.TermDepositRenewal;
import au.com.stgeorge.mbank.model.common.AddressResp;
import au.com.stgeorge.mbank.model.common.IMBResp;
import au.com.stgeorge.mbank.model.common.KeyValueResp;
import au.com.stgeorge.mbank.model.common.NewAcctDupResp;
import au.com.stgeorge.mbank.model.common.ReceiptResp;
import au.com.stgeorge.mbank.model.request.newaccount.cpp.TDOpenAcctReq;
import au.com.stgeorge.mbank.model.request.newaccount.cpp.TDRenewAcctReq;
import au.com.stgeorge.mbank.model.response.newaccount.TermDepositResp;
import au.com.stgeorge.mbank.model.response.newaccount.cpp.TDInterestFrequencyResp;
import au.com.stgeorge.mbank.model.response.newaccount.cpp.TDMaturityDateResp;
import au.com.stgeorge.mbank.model.response.newaccount.cpp.TDOpenAcctResp;
import au.com.stgeorge.mbank.model.response.newaccount.cpp.TDRenewAcctResp;
import au.com.stgeorge.mbank.model.response.newaccount.cpp.TDResp;
import au.com.stgeorge.mbank.model.response.services.TFNCheckResp;
import au.com.stgeorge.mbank.session.MobileSession;
import au.com.stgeorge.mbank.util.MBAppConstants;
import au.com.stgeorge.mbank.util.MBAppUtils;
import au.com.stgeorge.mobilebank.businessobject.TermDepositService;


public class TDHelper
{
	
	private static final String EXTERNAL_NOMINATED_ALIAS = "Nominated Account";  

	protected Account getSelectedAccount(Collection<Account> accountList ,String accountIndex ){
		Logger.debug("CPP : TDHelper - getSelectedAccount", this.getClass());
		Account selectedAccount = null;
		int index = 0;
		try{
			index = Integer.parseInt(accountIndex);
		}catch(Exception e){
			Logger.warn("CPP TDHelper - getSelectedAccount - Something went wrong..", this.getClass());
		}
			
		if(null!= accountList){
			for(Account a : accountList){
				if(a.getIndex() == index){
					selectedAccount = a;
					break;
				}				
			}
		}
				
		return selectedAccount;
	}
	
	public IMBResp populateTDResponse(TFNCheckResp tfnCheckResp, Collection<Account> fundFromAcctList, Customer customer,Collection<Account> depositToAccounts,Collection<Account>  paidToInterestAccounts,Collection<RegionVO> regions,List<BranchVO> branches,BranchVO branch) {
		TDResp tdaResp = new TDResp();
		List<Account> customerAllAccountsList = customer.getAccounts();
				
		//Populate the fund from accounts
		if(fundFromAcctList!=null) {
			tdaResp.setAccountIndexes(populateFundFromAccounts(fundFromAcctList,customerAllAccountsList));
		}
		
		//Populate the deposit to accounts
		if(depositToAccounts!=null) {
			tdaResp.setDepositAccntIndexes(populateDepositToAccounts(depositToAccounts,customerAllAccountsList));
		}
		
		//Populate the interest paid to accounts
		if(paidToInterestAccounts!=null) {
			tdaResp.setInterestToAccntIndexes(populatePaidToInterestAccounts(paidToInterestAccounts,customer));
		}
		
		//Populate the interest paid options
		//tdaResp.setInterestPaidOptionsList(populateInterestPaidList());
		
		//Populate the regions
		if ( regions!= null )
		{
			ArrayList<KeyValueResp> regionList = new ArrayList<KeyValueResp>();
			for (Iterator<RegionVO> iterator = regions.iterator(); iterator.hasNext();) {
				RegionVO eachRegion = iterator.next();
				KeyValueResp nameIDResp = new KeyValueResp();
				nameIDResp.setId(  eachRegion.getRegionId() );
				nameIDResp.setName(  eachRegion.getRegionName() );
				regionList.add(nameIDResp);
			}
			tdaResp.setRegions(regionList);
		}
		
		//Populate the branches
		if ( branches!= null ) {
			ArrayList<KeyValueResp> branchList = new ArrayList<KeyValueResp>();
			for (Iterator<BranchVO> iterator = branches.iterator(); iterator.hasNext();) {
				BranchVO branchVO = iterator.next();
				KeyValueResp nameIDResp = new KeyValueResp();
				nameIDResp.setId(  branchVO.getBranchId() );
				nameIDResp.setName(  branchVO.getBranchName() );
				branchList.add(nameIDResp);
			}	
			tdaResp.setBranches(branchList);
		}
		
		//Populate the branch address
		if(branch!=null) {
			AddressResp addressResp = new AddressResp();
			addressResp.setAddrType("Branch");
			addressResp.setLine1(branch.getAddress1());
			addressResp.setLine2(branch.getAddress2());
			addressResp.setLine3(branch.getAddress3());
			addressResp.setSuburb(" ");
			addressResp.setState(" ");
			addressResp.setPostCode(" ");
			tdaResp.setAddress(addressResp);
		}
		
		if(tfnCheckResp!=null){
			tdaResp.setTfnCheck(tfnCheckResp);
		}
		
        return tdaResp;
	}	
	
	private ArrayList<Integer> populateFundFromAccounts(Collection<Account> fundFromAcctList, List<Account> customerAllAccountsList) {
		ArrayList<Integer> accountIndexesList = new ArrayList<Integer>();
		
		if(fundFromAcctList != null){
			ArrayList<Account> custAcctList = (ArrayList<Account>)customerAllAccountsList;
			int id;			
			for (Iterator<Account> iterator = fundFromAcctList.iterator(); iterator.hasNext();) {
				Account eachAccount = iterator.next();
				id = getAccountIndex(custAcctList, eachAccount.getAccountId());
				accountIndexesList.add(id);
			}			
		}
		return accountIndexesList;
	}
	
	public int getAccountIndex(ArrayList<Account> acctList, AccountId pAccountId) {
		int i = 0;
		boolean found = false;
		if (acctList != null && !acctList.isEmpty()) {			
			int size = acctList.size();
			for (; i < size; i++) {
				Account account = (Account) acctList.get(i);
				if (pAccountId.equals(account.getAccountId())) {
					found = true;
					break;
				}
			}
		}
		if (found)
			return i;
		else
			return -1;
	}	

	private ArrayList<Integer> populateDepositToAccounts(Collection<Account> depositToAccounts,List<Account> customerAllAccountsList){		
			
		ArrayList<Integer> depositInfoIndexesList = new ArrayList<Integer>();
		if(depositToAccounts != null){
			ArrayList<Account> custAcctList = (ArrayList<Account>) customerAllAccountsList;

			int id;			
			for (Iterator<Account> iterator = depositToAccounts.iterator(); iterator.hasNext();) {
				Account eachAccount = iterator.next();
				id = getAccountIndex(custAcctList, eachAccount.getAccountId());
				depositInfoIndexesList.add(id);
			}			
		}
		
		return depositInfoIndexesList;
	}

	private ArrayList<String> populatePaidToInterestAccounts(Collection<Account>  paidToInterestAccounts, Customer customer) {
		ArrayList<Account> accts = createAcctListfromSession(customer, paidToInterestAccounts);
		ArrayList<String> interestToAccntIndexesList = new ArrayList<String>();

		if(accts != null){
			for (Iterator<Account> iterator = accts.iterator(); iterator.hasNext();) {
				Account eachAccount = iterator.next();
				interestToAccntIndexesList.add(String.valueOf(eachAccount.getIndex()));
			}
		}
		if (customer.getThirdParties() != null )
		{
			ArrayList<ThirdParty> thirdPartyList = (ArrayList<ThirdParty>) customer.getThirdParties();

			int thirdPartyListLen = thirdPartyList.size();
			for (int i = 0; i < thirdPartyListLen; i++) {
				interestToAccntIndexesList.add("T|"+i);
				}
		}
		return interestToAccntIndexesList;
	}
	
	
	/**
	 * This method will return a response object for Joint button action. 
	 * 
	 * @param httpRequest
	 * @param mbSession
	 * @param commonData
	 * @param externalLinkVO
	 * @return TDResp
	 */
    public TDResp populateTDOAFStatusResp(IBankCommonData commonData, ExternalLinkVO externalLinkVO){
        
    	TDResp tdResp = new TDResp();

    	tdResp.setToken(externalLinkVO.getUnSignedData());
    	tdResp.setTargetURL(externalLinkVO.getUrl());

		return tdResp;
    }
    
    /**
	 * This method will populate the Response object with getRates
	 * 
	 * @param httpRequest
	 * @param mbSession
	 * @param ratesResp
	 * @return TDResp
	 */
    
    public TDResp populategetRatesResp(List<TermDepositDetails>ratesResp, BusinessException exception, IBankCommonData commonData){
    	TDResp tdResp = new TDResp();
    	
    	if(ratesResp!=null && ratesResp.size() >0){    		
    		tdResp.setTermDepositBstRateDetails(ratesResp);    		
    		if(exception != null){
    			
    			String originHelpDeskPhone = null;    			
  
    			OriginsVO originVO = IBankParams.getOrigin(IBankParams.getBaseOriginCode(commonData.getOrigin()));	
    			    			
    			if(null!=originVO){
    				originHelpDeskPhone=originVO.getPhone();
    			} 			
			
    			Object[] values = {originHelpDeskPhone};
    			
				String cardedRateMessage = MBAppUtils.getMessage(IBankParams.DEFAULT_ORIGIN, exception.getKey(), values);
				
				tdResp.setCardedRateMessage(cardedRateMessage);
    		}
    	}
    	
    	return tdResp;
    	
    }
  
    /**
     * This method will construct the TDResp, for TD Renewal Option - Renew with no change
     * 
     * @param httpRequest
     * @param mbSession
     * @param ratesResp
     * @param tdGetRatesObj
     * @return TDResp
     */
    public TDResp populateRenewAsISRatesResp(TermDepositAccount tdaAccount, IBankCommonData commonData){
    	TDResp tdResp = new TDResp();
    	
    	TermDepositDetails termDepositDetails = new TermDepositDetails();
    	BigDecimal interestRate = tdaAccount.getInterestRate();
    	int termInMonths = tdaAccount.getTermInMonth();
    	String interestFrequency = tdaAccount.getFrequency();
    	CalculatorService calcService = ServiceHelper.getBean("calcService");
    	BigDecimal interestEarned = calcService.getEarnedInterest(tdaAccount.getBalance(), interestRate, termInMonths);
    	
    	//Limit the rate to two decimal places
    	interestRate = interestRate.divide(new BigDecimal(1), 2, RoundingMode.DOWN);
    	
		Logger.debug("interestRate: " + interestRate + ", " + " termInMonths: "
				+ termInMonths + ", " + "interestFrequency: "
				+ interestFrequency + ", " + "interestEarned: "
				+ interestEarned, this.getClass());
    	
    	termDepositDetails.setFinalIntRate(interestRate.toString());
    	termDepositDetails.setTerm(termInMonths);
    	termDepositDetails.setInterestFrequency(getTDTerm(commonData, interestFrequency));
    	termDepositDetails.setTotalInterestEarned(interestEarned);
    	    	
    	tdResp.setTermDepositBstRateDetails(Arrays.asList(termDepositDetails));
    		
    	return tdResp;    	
    }
    
    /**
     * This method will return the Interest paid options from ReleaseCodes table based on the acronyms passed -<br><br>
     * Example - 
     * <li>IM - Monthly</li>
     * <li>0 - At maturity</li>
     * <li>IQ - Quarterly</li>
     * <br><br>
     *       
     * @param frequency
     * @return String
     */
    public String getTDTerm(IBankCommonData commonData, String frequency){
    	    	
    	CodesVO codes = IBankParams.getCodesData(commonData.getOrigin(), IBankParams.CPP_TERM_DEPOSIT_FREQUENCY, frequency);
    	
    	if(null != codes)
    		return codes.getMessage();
    	
    	return null;    	
    }
    
    public BranchVO getBranch(List<BranchVO> branchList, String branchId) throws BusinessException, ResourceException {
	    Iterator<BranchVO> it = branchList.iterator();
	    BranchVO branch = null;
	    while (it.hasNext()) {
	      branch = it.next();
	      if (branch.getBranchId().equalsIgnoreCase(branchId))
	        break;
	    }
	    if (branch == null)
	      throw new BusinessException(BusinessException.GENERIC_ERROR);
	    return branch;
	}
    
    public ArrayList<Account> createAcctListfromSession(Customer customer, Collection<Account> accounts){
		ArrayList<Account> resultList = new ArrayList<Account>();
		
		if(accounts != null){
			ArrayList<Account> acctList = (ArrayList<Account>)accounts;
			Account acct = new Account();
			Account custAcct = new Account();
			ArrayList<Account> custAcctList = (ArrayList<Account>)customer.getAccounts();
			String acctKey ="";
			for (int i = 0; i < acctList.size(); i++){
				acct = (Account) acctList.get(i);
				acctKey = acct.getAccountId().getAccountKey();
				for(int j=0; j < custAcctList.size(); j++){
					custAcct = (Account) custAcctList.get(j);
					if(custAcct.getAccountId().getAccountKey().equalsIgnoreCase(acctKey)){
						resultList.add(custAcct);
						break;
					}
				}
			}
		}
		return resultList;
	}
    
    /**
     * This method will return the maturity date for the TD account based on the term.
     * 
     * <br>
     * @param term
     * @return Date - TD maturity date
     */
    public Date getMaturityDate (String term , Date maturityDate) {
    	
    	Date newMaturityDate = null;
    	Date currentDay = null;
    	
    	if(null != term && !term.isEmpty()){   		
  		
    		//Current date 
    		if(null!= maturityDate){
    			//for Renewal
    			currentDay = maturityDate;
    		}else{
    			//for origination
    			currentDay = DateMethods.getUtilDate();
    		}
    		   		
    		//Add number of months to current date and get the maturity date
    		newMaturityDate = DateMethods.relativeMonth(currentDay, Integer.valueOf(term));
    		
    		//Fetch the last date of the current month
    		Date lastDate = getLastDateOfMonth(currentDay);
    		
    		//If current date and the last date of the month match,
    		//fetch the last date of the month which maturity date belongs to.
    		//Example  
    		//current date - 29 Feb 2020, term - 1 month, maturity date - 31 Mar 2020 (NOT 29 March)
    		//current date - 28 Feb 2019, term - 1 month, maturity date - 31 Mar 2019 (NOT 28 March)
    		//current date - 29 Feb 2020, term - 2 months, maturity date - 30 Apr 2020 (NOT 29 April)
    		//current date - 28 Feb 2019, term - 2 month, maturity date - 31 Apr 2019 (NOT 28 April)    		
    		if(lastDate.equals(currentDay)){
    			newMaturityDate = getLastDateOfMonth(newMaturityDate);
    		}
    	}
    	
    	return newMaturityDate;
    }

    /**
     * This method returns the last day of the month.
     * 
     * @param date
     * @return Date - last date of the month.
     */
    public Date getLastDateOfMonth (Date date) {
    	
		Calendar cal = Calendar.getInstance();
	    cal.setTime(date);
	    cal.set(Calendar.DAY_OF_MONTH, cal.getActualMaximum(Calendar.DAY_OF_MONTH));
	    
	    return cal.getTime();
    }
    
    /**
     * This method will return the response for Confirmation page.
     * <br>
     * 
     * @param httpRequest
     * @param mbSession
     * @param commonData
     * @param maturityDate
     * @return TDMaturityDateResp
     */
    public TDMaturityDateResp populateConfirmationResponse(Date maturityDate, TermDepositAccount selectedAccount, List<Account> customerAllAccountsList){
        
    	TDMaturityDateResp tdResp = new TDMaturityDateResp();

    	tdResp.setMaturityDate(maturityDate);    
    	
    	if(null!=selectedAccount) {
	    	switch(selectedAccount.getInterestInstruction().getInterestInstruction()) {
	    		case "TA" : 
	    			tdResp.setPayInterestToOption("Add to principal"); 
	    			break;
	    			
	    		case "TT" : 
	    			tdResp.setPayInterestToOption("Paid to account");
	    			
	    			//find the account name and number from customerAllAccountsList    			
	    			for(Account account : customerAllAccountsList){	    				
	    				if(StringMethods.removeLeadingZero(selectedAccount.getInterestInstruction().getInterestAccount()).equals(StringMethods.removeLeadingZero(account.getAccountId().getAccountKey()))){
	    					tdResp.setAccountNum(account.getAccountId().getFormattedAccountNumber());
	    					tdResp.setAccountName(account.getAlias());    
	    					break;
	    				}    				
	    			}    				
	    			break;    		
	    	}	
    	}
		return tdResp;
    }
    
    public boolean isChangeInAmount(BigDecimal oldTDAmount, BigDecimal newTDAmount) {
    	if(oldTDAmount!=null) 
    	{
	    	Logger.debug("Inside : isChangeInAmount() oldTDAmount: " + oldTDAmount + ", " + " newTDAmount: "+newTDAmount, this.getClass());
			if(oldTDAmount.compareTo(newTDAmount) != 0){
				Logger.debug("isChangeInAmount() : returns true" , this.getClass());
				return true;
			}
			else {
				Logger.debug("isChangeInAmount() : returns false" , this.getClass());
				return false;
			}
    	}
    	return false;
	}
    
    public IMBResp populateTDInterestFreqResp(String term, List<CodesVO> termFrequencyList) {
    	TDInterestFrequencyResp tdIntFreqResp = new TDInterestFrequencyResp();
    	Map<String,String[]> termFrequencyMap = new HashMap<String,String[]>();
    	
    	for(CodesVO codesVO: termFrequencyList){
    		if(null!= codesVO && null!= codesVO.getCode() && null!= codesVO.getMessage()){
    			termFrequencyMap.put(codesVO.getCode(), codesVO.getMessage().split("-") );
    		}    		
		}
    	
    	ArrayList<String>intFrequencies = new ArrayList<String>();
		
		Iterator<Entry<String, String[]>> itr = termFrequencyMap.entrySet().iterator();
		while(itr.hasNext()){
			Map.Entry<String, String[]> entry = (Entry<String, String[]>) itr.next();
			Range<Integer> range = Range.between(Integer.parseInt(entry.getValue()[0]),Integer.parseInt(entry.getValue()[1]));
			if(range.contains(Integer.parseInt(term))){
				intFrequencies.add(entry.getKey());
			}				
		}
		Logger.debug("CPP : populateTDInterestFreqResp - size of list :"+intFrequencies.size(), this.getClass());
		//Populate the interest paid options
    	tdIntFreqResp.setInterestPaidOptionsList(intFrequencies);
				
		return tdIntFreqResp;
	}
    
    public NewTermDepositAccount populateNewTermDepositAccount(MobileSession mobileSession, TDOpenAcctReq tdOpenAcctReq, IBankCommonData ibankCommonData,TermDepositProducts termDepositProduct,Boolean statUpdTfn) throws ResourceException, BusinessException{

		NewTermDepositAccount newTdaObj = new NewTermDepositAccount();
		Customer customer=mobileSession.getCustomer();
		
		IBankCommonData commonData=ibankCommonData;	
		
		//19E3 - remove M from Origin in case of its IB-MB redirection
		if(null != mobileSession && null != mobileSession.getState()){
			if(mobileSession.getState().equals(MBAppConstants.STATE_MOBILE)){
				Logger.info("CPP Mobile state received  : populateNewTermDepositAccount", this.getClass());
				newTdaObj.setMBLite(true);			
			}
		}	
		
		newTdaObj.setOrigin(commonData.getOrigin());
		newTdaObj.setCommonData(commonData);
		newTdaObj.setCustomer(customer);
	
		newTdaObj.setAmount(mobileSession.getTermDepositAmount());
		if(null!= termDepositProduct && termDepositProduct.getSubProductCode()!=null) {
			newTdaObj.setSelectedProduct(termDepositProduct.getSubProductCode().trim());
		}
		Logger.debug("TDHelper : subProd code for origination - "+newTdaObj.getSelectedProduct(), this.getClass());
		newTdaObj.setTermInMonths(tdOpenAcctReq.getTdTerm());
		//newTdaObj.setState(req.getTdaState());
		
		//TODO: null checks
		TermDepositProduct product = new TermDepositProduct();
		product.setInterestRate(new BigDecimal(termDepositProduct.getRates().getFinalDiscretionary()));		
		product.setFrequency(getInterestFrequency(InterestFrequency.valueOf(termDepositProduct.getInterestFrequency())));
		
		//Added for warranty
		product.setTerm(tdOpenAcctReq.getTdTerm());
		product.setTreasuryQuotationCode(termDepositProduct.getTreasuryQuotationCode());
		
		newTdaObj.setSelectedProductInstance(product);
		if(termDepositProduct.isCardedRate()) {
			newTdaObj.setRateType(TermDepositConstants.RATE_TYPE_CARDED);
		}
		else {
			newTdaObj.setRateType(TermDepositConstants.RATE_TYPE_CPP);
		}
		
		if(tdOpenAcctReq.getIntrPayInst().equalsIgnoreCase("Add to principal")) {
			newTdaObj.setInterestInstruction("TA");
		}
		else if(tdOpenAcctReq.getIntrPayInst().equalsIgnoreCase("Pay to account")) {
			newTdaObj.setInterestInstruction("TT");
		}		

		if(tdOpenAcctReq.getFundsFromAcctIndex().equalsIgnoreCase(TermDepositConstants.FUND_EXTERNALLY)) {
			newTdaObj.setSourceFundsFromExternally(TermDepositConstants.FUND_EXTERNALLY);
		}
		else {
			//Get account object from the index for source funds from account
			if( tdOpenAcctReq.getFundsFromAcctIndex() != null && Integer.parseInt(tdOpenAcctReq.getFundsFromAcctIndex()) >= 0){
				TermDepositService termDepositService = (TermDepositService)  ServiceHelper.getBean("termDepositService");
				Collection<Account> accountList = termDepositService.getFundingAccounts(ibankCommonData);						
				Account sourceAcct = getSelectedAccount(accountList,tdOpenAcctReq.getFundsFromAcctIndex());
				newTdaObj.setSourceFundsFrom(sourceAcct);
			}	
		}
		
		//Get interest paid to account
		String selInterestToIndex = tdOpenAcctReq.getIntrPayToAcctIndex();
		if(!StringMethods.isEmptyString(selInterestToIndex)){
			selInterestToIndex = selInterestToIndex.replace('|',',');
			String[] tempStr = selInterestToIndex.split(",");
			if(tempStr.length < 2){
				String acctIndex = tempStr[0].trim();
				List<Account> customerAllAccountsList = mobileSession.getCustomer().getAccounts();
				Collection<Account> paidToInterestAccountsList = AccountFilter.getTermDepositPaidToInterestAccounts(customerAllAccountsList);
				Account intrToAcct = getSelectedAccount(paidToInterestAccountsList,acctIndex);
				if(intrToAcct != null){
					newTdaObj.setSelectedToAccount(intrToAcct.getAccountId());
					newTdaObj.setPaidToAccount(intrToAcct);//for sessionreceipt
				}
			}
			else if(MBAppConstants.KEY_IDENTIFIER_THIRD_PARTY.equalsIgnoreCase(tempStr[0].trim())){
				String acctIndex = tempStr[1].trim();
				ThirdParty intrToTP = getThirdPartyFromCustomer(customer, Integer.parseInt(acctIndex));
				newTdaObj.setSelectedToThirdParty(intrToTP);
				newTdaObj.setPaidToAccount(intrToTP);//for sessionreceipt
				
			}
		}
		
		if(tdOpenAcctReq.getBranchId() != null){
			newTdaObj.setSelectedBranch(tdOpenAcctReq.getBranchId());
		}
		
		//19e3 code
		if(!IBankParams.isSwitchOn(ibankCommonData.getOrigin(), IBankParams.TFN_SWITCH))
			newTdaObj.setHasTFN(null);
		else{
		   if(statUpdTfn)
			 newTdaObj.setHasTFN("Y");
		   else
			 newTdaObj.setHasTFN("N");
		}
		
		if(tdOpenAcctReq.getLeadIdTda() != null)
			newTdaObj.setLeadId(tdOpenAcctReq.getLeadIdTda());
		
		return newTdaObj;
	}
	
	private ThirdParty getThirdPartyFromCustomer(Customer customer, int index) {
		ThirdParty thirdParty = null;
		if (customer.getThirdParties() != null
				&& customer.getThirdParties().size() > 0) {
			ArrayList thirdPartyList = (ArrayList) customer.getThirdParties();
			int thirdPartyListLen = customer.getThirdParties().size();
			for (int i = 0; i < thirdPartyListLen; i++) {
				if (index == i) {
					thirdParty = (ThirdParty) thirdPartyList.get(i);
					break;
				}
			}
		}
		return thirdParty;
	}
	
	public IMBResp populateopenTDAAccountResp(NewTermDepositAccount newTDAAccount,String origin,Boolean tfnExcemption, Boolean tfnHeld)
	{
		TDOpenAcctResp openTDAResp = new TDOpenAcctResp();
		ReceiptResp receiptResp = new ReceiptResp();
		
		if(newTDAAccount!=null){
			openTDAResp.setAppReferenceId(newTDAAccount.getAppReferenceId());
			if(newTDAAccount.getReceipt() != null){
				receiptResp.setReceiptNumDisp(formatReceiptNumber(newTDAAccount.getReceipt().getReceiptNumber()));
				receiptResp.setNewAccountNum(newTDAAccount.getNewAcctNumber());
				receiptResp.setDateTime(newTDAAccount.getReceipt().getTimestamp());
				
				openTDAResp.setNewTdaBal(newTDAAccount.getAmount().toString());
				if(newTDAAccount.getNewAcctNumber() != null){
					receiptResp.setNewAccountNum(getFormattedAcctNumber(newTDAAccount.getNewAcctNumber(), "CDA", newTDAAccount.getNewBSBNumber()));
				}
				else{
					receiptResp.setNewAccountNum("To be opened");
					receiptResp.setStatus("ERROR_OPEN");
				}
			}
			else{
				if(newTDAAccount.getNewAcctNumber() != null){
					receiptResp.setNewAccountNum(getFormattedAcctNumber(newTDAAccount.getNewAcctNumber(), "CDA", newTDAAccount.getNewBSBNumber()));
				}
			}
			
			if((newTDAAccount.getSourceFundsFrom()!= null) && (newTDAAccount.getNewAcctNumber() == null) && (newTDAAccount.getReceipt() == null)){
				receiptResp.setNewAccountNum("To be opened");
				receiptResp.setStatus("ERROR_TRANSFER");
			}
			
			if((newTDAAccount.getSourceFundsFrom()== null) && (newTDAAccount.getNewAcctNumber() == null)){
				receiptResp.setNewAccountNum("To be opened");
				receiptResp.setStatus("ERROR_OPEN");
			}
			
			if((newTDAAccount.getSourceFundsFrom()== null) && (newTDAAccount.getNewAcctNumber() != null)){
				receiptResp.setNewAccountNum(getFormattedAcctNumber(newTDAAccount.getNewAcctNumber(), "CDA", newTDAAccount.getNewBSBNumber()));
			}

			receiptResp.setDateTime(DateMethods.getTimestamp());
			openTDAResp.setReceipt(receiptResp);
			
			CodesVO codesVO = IBankParams.getCodesData(origin, "TermDeposit", "EmailBillerCode");
						
			String tdBillerCode = codesVO.getMessage();
			openTDAResp.setTdBillerCode(tdBillerCode);		
		}

		//populate TFN
		openTDAResp.setTfnExemption(tfnExcemption);
		openTDAResp.setTfnHeld(tfnHeld);
		
		return openTDAResp;
	}
	
	public IMBResp populateRenewTDAAccountResp(TermDepositRenewal termDepositRenewal,String origin, Boolean tfnExcemption, Boolean tfnHeld)
	{
		TDRenewAcctResp renewTDAResp = new TDRenewAcctResp();
		ReceiptResp receiptResp = new ReceiptResp();		
		
		if(termDepositRenewal!=null){
			if(termDepositRenewal.getReceiptNumber() != null){				
				receiptResp.setReceiptNumDisp(formatReceiptNumber(termDepositRenewal.getReceiptNumber()));											
			}	
			renewTDAResp.setNewTdaBal(String.valueOf(termDepositRenewal.getAccount().getBalanceDisplay()));		
			receiptResp.setNewAccountNum(termDepositRenewal.getAccount().getAccountId().getFormattedAccountNumber());
		}
		receiptResp.setDateTime(DateMethods.getTimestamp());		
		renewTDAResp.setReceipt(receiptResp);
			
		CodesVO codesVO = IBankParams.getCodesData(origin, "TermDeposit", "EmailBillerCode");
		String tdBillerCode = codesVO.getMessage();
		renewTDAResp.setTdBillerCode(tdBillerCode);
		renewTDAResp.setAppReferenceId(termDepositRenewal.getAppReferenceId());
		
		//populate TFN
		renewTDAResp.setTfnExemption(tfnExcemption);
		renewTDAResp.setTfnHeld(tfnHeld);
		
		return renewTDAResp;
	}
	
	public static String formatReceiptNumber(String receiptNumber) {
		StringBuffer theBody = new StringBuffer();
		if (receiptNumber.length() < 1)
			return "";

		String first = "";

		if (!StringMethods.isNumber(receiptNumber.trim().substring(0, 1))) {
			first = receiptNumber.trim().substring(0, 1) + " ";
			receiptNumber = receiptNumber.trim().substring(1,
					receiptNumber.length());
		}

		int len = receiptNumber.length();
		int iter = len / 4;

		if (len <= 4) {
			theBody.append(receiptNumber);
		} else {
			int maxLen = 0;
			for (int i = 0; i <= iter; i++) {
				if (i * 4 + 4 > len)
					maxLen = len;
				else
					maxLen = i * 4 + 4;

				theBody.append(receiptNumber.trim().substring(i * 4, maxLen));
				theBody.append(" ");
			}
		}
		return first + theBody;
	}
	
	public String getFormattedAcctNumber(String sAccount, String accountType,
			String bsb) {
		StringBuffer formattedAcctNum = new StringBuffer();
		int counter = 0;
		String temp = "";
		if (StringMethods.isValidString(sAccount)) {
			sAccount = sAccount.replaceAll(" ", "");
			sAccount = sAccount.trim();
			int len = sAccount.length();
			if (Account.NOM.equalsIgnoreCase(accountType)) {
				if (bsb != null && bsb.length() > 0) {
					boolean internalNomAcct = isInternalNominatedAcct(bsb);
					if (!internalNomAcct) {
						return sAccount;
					}
				}
			}
			if ((len > 9) && (!(Account.CDA.equalsIgnoreCase(accountType)))) {
				String acctNumStr = sAccount.substring(0, 4);
				if (acctNumStr.startsWith("0")) {
					sAccount = sAccount.replaceAll("^[0]*", "");
					if (sAccount.length() < 9) {
						sAccount = StringUtil
								.padLeadingString(sAccount, 9, '0');
					}
				}
			}
			len = sAccount.trim().length();
			if (Account.MGL.equalsIgnoreCase(accountType)) {
				formattedAcctNum.append(sAccount);
			} else if (Account.DDA.equalsIgnoreCase(accountType)
					|| Account.CDA.equalsIgnoreCase(accountType)
					|| Account.CHS.equalsIgnoreCase(accountType)) {
				if (len > 9) {
					formattedAcctNum = formatBSA(len, sAccount, accountType);
				} else {
					formattedAcctNum = format(3, len, sAccount);
				}
			} else if (Account.CRA.equalsIgnoreCase(accountType)) {
				formattedAcctNum = format(4, len, sAccount);
			}
			else if (Account.LIS.equalsIgnoreCase(accountType)
					|| (sAccount.length() > 0 && !(Character.isDigit(sAccount
							.charAt(0))))) {
				if (sAccount.length() > 3) {
					formattedAcctNum.append(sAccount.trim().substring(0, 4));
					formattedAcctNum.append(" ");
					for (int i = 4; i < len;) {
						counter = i + 3;
						if (counter > len) {
							counter = len;
						}
						temp = sAccount.trim().substring(i, counter);
						formattedAcctNum.append(temp);
						formattedAcctNum.append(" ");
						i = i + 3;
					}
				} else {
					formattedAcctNum.append(sAccount);
				}
			} else if (len == 16) {
				formattedAcctNum = format(4, len, sAccount);
			} else if (len > 0 && len <= 9) {
				formattedAcctNum = format(3, len, sAccount);
			}
			else if (len > 9 && len < 16) {
				formattedAcctNum = formatBSA(len, sAccount, accountType);
			} else {
				formattedAcctNum.append(sAccount);
			}
		}
		return formattedAcctNum.toString();
	}
	
	public static boolean isInternalNominatedAcct(String bsb) {
		boolean internalNomAcct = false;
		if (StringMethods.isValidString(bsb)) {
			String bsbPrefix = bsb.substring(0, 2);
			if (TermDepositConstants.STG_BSB_PREFIX.equals(bsbPrefix)
					|| TermDepositConstants.BSA_BSB_PREFIX.equals(bsbPrefix)
					|| TermDepositConstants.CHS_BSB_PREFIX.equals(bsbPrefix)
					|| TermDepositConstants.BOM_BSB_PREFIX.equals(bsbPrefix)) {
				internalNomAcct = true;
			}
		}
		return internalNomAcct;
	}
	
	private StringBuffer format(int offSet, int len, String sAccount) {
		StringBuffer theBody = new StringBuffer();
		String temp = "";
		int counter = 0;
		for (int i = 0; i < len;) {
			counter = i + offSet;
			if (counter > len) {
				counter = len;
			}
			temp = sAccount.trim().substring(i, counter);
			theBody.append(temp);
			if (counter != len) 
				theBody.append(" ");
			i = i + offSet;
		}
		return theBody;
	}
	
	private StringBuffer formatBSA(int len, String sAccount, String accountType) {
		StringBuffer theBody = new StringBuffer();
		int counter = 0;
		String temp = "";
		sAccount = sAccount.trim();
		if (len < 13) {
			for (int j = 0; j < 13 - len; j++) {
				sAccount = "0" + sAccount;
			}
		} else if (len > 13 && len < 16) {
			for (int j = 0; j < 16 - len; j++) {
				sAccount = "0" + sAccount;
			}
		}
		len = sAccount.trim().length();
		if (Account.CDA.equalsIgnoreCase(accountType)) {
			if (!sAccount.trim().startsWith("000")) {
				theBody.append(sAccount.trim().substring(0, 3));
				theBody.append(" ");
				theBody.append(sAccount.trim().substring(3, 7));

			} else {
				theBody.append(sAccount.trim().substring(3, 7));

			}
		} else {
			theBody.append(sAccount.trim().substring(4, 7));
		}
		theBody.append(" ");
		for (int i = 7; i < len;) {
			counter = i + 3;
			if (counter > len) {
				counter = len;
			}
			temp = sAccount.trim().substring(i, counter);
			theBody.append(temp);
			if (counter != len) 
				theBody.append(" ");
			i = i + 3;
		}
		return theBody;
	}
	
	/**
     * This method will return the Interest frequency - text corresponding to enum InterestFrequency
     *  
     * @param frequency
     * @return String
     */
    public static String getInterestFrequency(InterestFrequency frequency) {
    	
    	String text = null;
    	
    	switch(frequency) {    	
    		case  Annually : text = InterestPaidEnum.ANNUALLY.getText(); break;
    		case  At_Maturity : text = InterestPaidEnum.AT_MATURITY.getText(); break;
    		case  Half_Yearly : text = InterestPaidEnum.EVERY_SIX_MONTHS.getText(); break;
    		case  Monthly : text = InterestPaidEnum.MONTHLY.getText(); break;    		
    	}
    	
    	return text;
    }
    
    
    public TermDepositRenewal populateTDRenewal(TDRenewAcctReq req,IBankCommonData commonData, MobileSession mbSession,TermDepositProducts selectedTermDepositProduct) throws ResourceException, BusinessException{
		TermDepositRenewal renewalObj = new TermDepositRenewal();
		Customer customer=mbSession.getCustomer();

		//19E3 - remove M from Origin in case of its IB-MB redirection
		if(null != mbSession && null != mbSession.getState()){
			if(mbSession.getState().equals(MBAppConstants.STATE_MOBILE)){
				renewalObj.setMBLite(true);
			}
		}
		
		renewalObj.setCommonData(commonData);
		renewalObj.setCustomer(customer);
		
		TermDepositService termDepositService = (TermDepositService)  ServiceHelper.getBean("termDepositService");
	
		if(null!= mbSession){			
			TermDepositAccount tdaAccount = (TermDepositAccount)termDepositService.getTDAAccount(mbSession.getSelectedAccount().getAccountId(),commonData);
			renewalObj.setAccount(tdaAccount);			
			renewalObj.setTransferAmount(mbSession.getTermDepositTransferAmount());			
		}
		
		renewalObj.setAddWidthdrawlIndicator(req.getRenewalOption().intValue());
				
		renewalObj.setTermLength(req.getTdTerm());
		//Populate the maturity date
		//Date maturityDate = getMaturityDate(new Integer(req.getTdTerm()).toString());
		//renewalObj.setMaturityDate(maturityDate);
		
		TermDepositProduct product = new TermDepositProduct();
		product.setInterestRate(new BigDecimal(selectedTermDepositProduct.getRates().getFinalDiscretionary()));		
		product.setFrequency(getInterestFrequency(InterestFrequency.valueOf(selectedTermDepositProduct.getInterestFrequency())));
		product.setTreasuryQuotationCode(selectedTermDepositProduct.getTreasuryQuotationCode());
		product.setSubProductCode(selectedTermDepositProduct.getSubProductCode());
		product.setCardedRate(selectedTermDepositProduct.isCardedRate());
		renewalObj.setSelectedProduct(product);
		if(selectedTermDepositProduct.isCardedRate()) {
			renewalObj.setRateType(TermDepositConstants.RATE_TYPE_CARDED);
		}
		else {
			renewalObj.setRateType(TermDepositConstants.RATE_TYPE_CPP);
		}
		
		if(req.getIntrPayInst().equalsIgnoreCase("Add to principal")) {
			renewalObj.setInterestPaymentOption("TA");
		}
		else if(req.getIntrPayInst().equalsIgnoreCase("Pay to account")) {
			renewalObj.setInterestPaymentOption("TT");
		}
		
		
		if(null!=req.getSelSourceAcctIndex() && req.getSelSourceAcctIndex().equalsIgnoreCase(TermDepositConstants.FUND_EXTERNALLY)) {
			renewalObj.setSourceFundsFromExternally(TermDepositConstants.FUND_EXTERNALLY);
		}
		
		Collection<Account> addWithdrawAccntList = null; 
		List<Account> customerAllAccountsList = mbSession.getCustomer().getAccounts();	
		
		if(renewalObj.getAddWidthdrawlIndicator() == TermDepositConstants.ADD_INDICATOR){
			if(renewalObj.getSourceFundsFromExternally()!=null && renewalObj.getSourceFundsFromExternally().equalsIgnoreCase(TermDepositConstants.FUND_EXTERNALLY)) {
				renewalObj.setFundFrom(TermDepositConstants.FUND_EXTERNAL);
			}
			else {
				renewalObj.setFundFrom(TermDepositConstants.FUND_INTERNAL);
				//add
				//Get account object from the index for source funds from account
				addWithdrawAccntList= termDepositService.getFundingAccounts(commonData);
				Account addAccnout = getSelectedAccount(addWithdrawAccntList, req.getSelSourceAcctIndex());
				renewalObj.setSourceFromAccount(addAccnout);
			}
		}
		else if(renewalObj.getAddWidthdrawlIndicator() == TermDepositConstants.WITHDRAWL_INDICATOR){
			renewalObj.setFundFrom(TermDepositConstants.FUNDS_FROM_WITHDRAW);
			//withdraw
			//Get account object from the index for source funds from account
								
			addWithdrawAccntList = AccountFilter.getTermDepDepositToAccounts(customerAllAccountsList);
			Account withdrawAccnout = getSelectedAccount(addWithdrawAccntList, req.getSelSourceAcctIndex());
			renewalObj.setSourceFromAccount(withdrawAccnout);
			
		}else if(renewalObj.getAddWidthdrawlIndicator() == 1){
			renewalObj.setFundFrom(TermDepositConstants.FUNDS_FROM_USE_EXISTING);
		}		
		
		//Get interest paid to account
		String selInterestToIndex = req.getIntrPayToAcctIndex();
		if(!StringMethods.isEmptyString(selInterestToIndex)){
			selInterestToIndex = selInterestToIndex.replace('|',',');
			String[] tempStr = selInterestToIndex.split(",");
			if(tempStr.length < 2){
				String acctIndex = tempStr[0].trim();
				Collection<Account> paidToInterestAccountsList = AccountFilter.getTermDepositPaidToInterestAccounts(customerAllAccountsList);
				Account intrToAcct = getSelectedAccount(paidToInterestAccountsList,acctIndex);
				if(intrToAcct != null){
					renewalObj.setSelectedToAccount(intrToAcct.getAccountId());
					renewalObj.setPaidToAccount(intrToAcct); //setting entore account for session receipt
				}
			}
			else if(MBAppConstants.KEY_IDENTIFIER_THIRD_PARTY.equalsIgnoreCase(tempStr[0].trim())){
				String acctIndex = tempStr[1].trim();
				ThirdParty intrToTP = getThirdPartyFromCustomer(customer, Integer.parseInt(acctIndex));
				renewalObj.setSelectedToAccount(intrToTP);
				renewalObj.setPaidToAccount(intrToTP); //setting entore account for session receipt
			}
		}
		
		renewalObj.setIntFrequency(mbSession.getTermDepositIntFrequency());
		
		if(req.getLeadIdTda() != null)
			renewalObj.setLeadId(req.getLeadIdTda());
		
		return renewalObj;
	}
    
    protected boolean isPrimary(String relationship){
    	List<String> eligibleOwnerList = new ArrayList<String>();
		String ownerList = "";
		boolean isPrimary = false;
		CodesVO codesVo = IBankParams.getCodesData(IBankParams.DEFAULT_ORIGIN, IBankParams.PRIMARY_OWNER_CONFIG_PROPERTY, IBankParams.ELIGIBLE_PRIMARY_OWNER_LIST);
		if(null != codesVo && null!= codesVo.getMessage()){
			ownerList =  codesVo.getMessage();
		}
		
		if(null!= ownerList && (ownerList.equalsIgnoreCase("") || ownerList.length() > 0)){
			eligibleOwnerList.addAll(Arrays.asList(ownerList.split(",")));
		}
		
		if(null!= relationship && eligibleOwnerList.contains(relationship)){		
			isPrimary = true;
			Logger.debug("isPrimary owner :"+isPrimary, this.getClass());
		}
		
		return isPrimary;
	}
    
    
    public void updateMaturityDate(List<TermDepositDetails> sortRatesResp, Date currentrollOverDate ) {
    	
    	for(TermDepositDetails tdDetail : sortRatesResp) {    		
    		Date mDate = getMaturityDate(String.valueOf(tdDetail.getTerm()), currentrollOverDate);    		
    		tdDetail.setMaturityDate(MBAppConstants.DATE_FORMAT_YYYYMMDD.format(mDate));
    	}
    }
    
    

	public IMBResp populateDuplicateAcctsList(MobileSession mobileSession,ArrayList<AcctOpeningVO> duplicateAcctOpeningList, String securityUniqueID){
		//TermDepositResp termDepositResp = new TermDepositResp();
		
		TDOpenAcctResp openTDAResp = new TDOpenAcctResp();
		ReceiptResp receiptResp = new ReceiptResp();
		//JSONObject json = new JSONObject();
		//json.put(MobileConstants.HTTP_REQUEST_PARAM_SECURITY_UNIQUE_ID, securityUniqueID);
		//JSONArray jsonArray = new JSONArray();
		ArrayList<NewAcctDupResp> acctOpeningList = new ArrayList<NewAcctDupResp>();
		
		if(duplicateAcctOpeningList!=null && duplicateAcctOpeningList.size() > 0){
			//AcctOpeningVO eachVO = new AcctOpeningVO();
			int len=duplicateAcctOpeningList.size();		
			
			for (int i = 0; i < duplicateAcctOpeningList.size(); i++){
				NewAcctDupResp newTDAAcctDupResp = new NewAcctDupResp();
				AcctOpeningVO eachVO = (AcctOpeningVO) duplicateAcctOpeningList.get(i);
				
				newTDAAcctDupResp.setId((len-i));
				newTDAAcctDupResp.setAmt(eachVO.getAmount().toString());
				newTDAAcctDupResp.setTerm(eachVO.getTermLength());
				if(eachVO.getAccountNumberFrom() != null){
					newTDAAcctDupResp.setFromAcct(getFormattedAcctNumber(eachVO.getAccountNumberFrom(), eachVO.getApplIDFrom(), eachVO.getBsbNumberFrom()));
				}
				newTDAAcctDupResp.setDateTime(eachVO.getRequestDate());
				newTDAAcctDupResp.setStatus(eachVO.getStatus());
				acctOpeningList.add(newTDAAcctDupResp);
			}
		}
		openTDAResp.setDupList(acctOpeningList);
		return openTDAResp;
	}
}

