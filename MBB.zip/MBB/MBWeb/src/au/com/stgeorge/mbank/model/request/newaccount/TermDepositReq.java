package au.com.stgeorge.mbank.model.request.newaccount;

import java.io.Serializable;

import au.com.stgeorge.mbank.model.common.IMBReq;
import au.com.stgeorge.mbank.model.common.ProductReq;
import au.com.stgeorge.mbank.model.common.ReqHeader;

public class TermDepositReq implements IMBReq, Serializable{
	
	private static final long serialVersionUID = -256469501889499119L;


    private ReqHeader header;
    
	public String getTdaAmount() {
		return tdaAmount;
	}
	public void setTdaAmount(String tdaAmount) {
		this.tdaAmount = tdaAmount;
	}
	public String getTdaState() {
		return tdaState;
	}
	public void setTdaState(String tdaState) {
		this.tdaState = tdaState;
	}
	public int getTdaTerm() {
		return tdaTerm;
	}
	public void setTdaTerm(int tdaTerm) {
		this.tdaTerm = tdaTerm;
		
	}
	public Integer getSourceAcctIndex() {
		return selSourceAcctIndex;
	}
	public void setSourceAcctIndex(Integer selSourceAcctIndex) {
		this.selSourceAcctIndex = selSourceAcctIndex;
	}
	public String getIntrPayToAcctIndex() {
		return intrPayToAcctIndex;
	}
	public void setIntrPayToAcctIndex(String intrPayToAcctIndex) {
		this.intrPayToAcctIndex = intrPayToAcctIndex;
	}
	public String getInterestPayInst() {
		return interestPayInst;
	}
	public void setInterestPayInst(String interestPayInst) {
		this.interestPayInst = interestPayInst;
	}
	
	
	

	public String getRegionId() {
		return regionId;
	}
	public void setRegionId(String regionId) {
		this.regionId = regionId;
	}
	public String getBranchId() {
		return branchId;
	}
	public void setBranchId(String branchId) {
		this.branchId = branchId;
	}
	public boolean getIsRenew() {
		return isRenew;
	}
	public void setIsRenew(boolean isRenew) {
		this.isRenew = isRenew;
	}
	public boolean isLooseRetIndFlag() {
		return looseRetIndFlag;
	}
	public void setLooseRetIndFlag(boolean looseRetIndFlag) {
		this.looseRetIndFlag = looseRetIndFlag;
	}

	private String tdaAmount;
	private String tdaState;
	private Integer tdaTerm;
	private Integer selSourceAcctIndex;
	private String intrPayToAcctIndex;
	private String interestPayInst;
//	private String selProduct;
	private Integer renewTDAIndex;

	private String renewalOption;
	private String regionId;
	private String branchId;
	private boolean isRenew;
	private boolean looseRetIndFlag;
	private boolean checkDuplicate;
	private boolean depositNow;
	
	private String leadIdTda;
		
	public String getLeadIdTda() {
		return leadIdTda;
	}
	public void setLeadIdTda(String leadIdTda) {
		this.leadIdTda = leadIdTda;
	}
	public String getRenewalOption()
	{
		return renewalOption;
	}
	public void setRenewalOption(String renewalOption)
	{
		this.renewalOption = renewalOption;
	}

	
	public Integer getRenewTDAIndex()
	{
		return renewTDAIndex;
	}
	public void setRenewTDAIndex(Integer renewTDAIndex)
	{
		this.renewTDAIndex = renewTDAIndex;
	}
	
	public boolean isDepositNow()
	{
		return depositNow;
	}
	public void setDepositNow(boolean depositNow)
	{
		this.depositNow = depositNow;
	}
	public boolean isCheckDuplicate()
	{
		return checkDuplicate;
	}
	public void setCheckDuplicate(boolean checkDuplicate)
	{
		this.checkDuplicate = checkDuplicate;
	}

	private ProductReq product;
	public ProductReq getProduct() {
		return product;
	}
	public void setProduct(ProductReq product) {
		this.product = product;
	}

 
	public ReqHeader getHeader()
	{
		return header;
	}
	public void setHeader(ReqHeader header)
	{
		this.header = header;
	}
	
	public static long getSerialVersionUID() {
		return serialVersionUID;
	}
 
}
