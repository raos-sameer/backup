package au.com.stgeorge.mbank.model.accountinfo;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_NULL)
public class TranCategory {

	private String total;
	private String percentage;
	private List<TranCategoryInfo> categoryList;

	public String getTotal() {
		return total;
	}
	public void setTotal(String total) {
		this.total = total;
	}
	public String getPercentage() {
		return percentage;
	}
	public void setPercentage(String percentage) {
		this.percentage = percentage;
	}
	public List<TranCategoryInfo> getCategoryList() {
		return categoryList;
	}
	public void setCategoryList(List<TranCategoryInfo> categoryList) {
		this.categoryList = categoryList;
	}
	
	
	
	
}
