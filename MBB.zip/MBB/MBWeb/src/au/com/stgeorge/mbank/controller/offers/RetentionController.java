package au.com.stgeorge.mbank.controller.offers;

import java.math.BigDecimal;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;

import au.com.stgeorge.framework.common.logging.Logger;
import au.com.stgeorge.framework.common.util.StringMethods;
import au.com.stgeorge.ibank.businessobject.BusinessException;
import au.com.stgeorge.ibank.businessobject.ResourceException;
import au.com.stgeorge.ibank.common.cache.IBankParams;
import au.com.stgeorge.ibank.service.businessobject.RetentionService;
import au.com.stgeorge.ibank.service.valueobject.OfferDetails;
import au.com.stgeorge.ibank.valueobject.Account;
import au.com.stgeorge.ibank.valueobject.Customer;
import au.com.stgeorge.ibank.valueobject.Statistic;
import au.com.stgeorge.ibank.valueobject.transfer.IBankCommonData;
import au.com.stgeorge.mbank.controller.IMBController;
import au.com.stgeorge.mbank.model.common.IMBReq;
import au.com.stgeorge.mbank.model.common.IMBResp;
import au.com.stgeorge.mbank.model.common.ReqHeader;
import au.com.stgeorge.mbank.model.common.RespHeader;
import au.com.stgeorge.mbank.model.request.EmptyReq;
import au.com.stgeorge.mbank.model.request.offers.RetentionOfferAcceptReq;
import au.com.stgeorge.mbank.model.request.offers.RetentionOfferReq;
import au.com.stgeorge.mbank.model.request.offers.RetentionReq;
import au.com.stgeorge.mbank.model.request.offers.RetentionSurveyReq;
import au.com.stgeorge.mbank.model.response.ErrorResp;
import au.com.stgeorge.mbank.model.response.SuccessResp;
import au.com.stgeorge.mbank.model.response.offers.RetentionResp;
import au.com.stgeorge.mbank.session.MobileSession;
import au.com.stgeorge.mbank.session.MobileSessionImpl;
import au.com.stgeorge.mbank.util.MBAppHelper;
import au.com.stgeorge.mbank.util.MBAppUtils;
import au.com.stgeorge.mbank.util.MBAppValidator;
import au.com.stgeorge.mbank.util.ServiceConstants;
import au.com.stgeorge.perflogger.PerformanceLogger;

@Controller
@RequestMapping("/retention")
public class RetentionController  implements IMBController{
	
	@Autowired
	private RetentionService retentionService;
	
	@Autowired
	private RetentionHelper retentionHelper;
	
	@Autowired
	private MBAppHelper mbAppHelper;
	
	@Autowired
	private MBAppValidator mbAppValidator;
	
	@Autowired
	private PerformanceLogger perfLogger;
	
	private static final String CASH_BACK_OFFER = "C";
	private static final String FEE_WAIVER_OFFER = "F";
	private static final String SAVING_SAVINGS_OFFER = "S";
	private static final String ACCEPT_OFFER = "A";
	private static final String DECLINE_OFFER = "D";
	
	
	@RequestMapping(value = "savingsEligibility", method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public IMBResp processSavingsEligibility(HttpServletRequest httpServletRequest,HttpServletResponse httpServletResponse,@RequestBody final RetentionReq req) { 
				
		Logger.info("processSavingsEligibility starts",this.getClass());

		perfLogger.startAllLogs();
		String logName = MBAppUtils.getLogName(httpServletRequest);
		perfLogger.startLog(logName);					
		MobileSession mobileSession = new MobileSessionImpl();
		OfferDetails savingSavingsOfferDetails = new OfferDetails(); 
		try{			
			mobileSession.getSessionContext(httpServletRequest);
			mobileSession.removeOfferDetails();
			ErrorResp errorResp = validate(req, httpServletRequest);
					
			if (errorResp != null && errorResp.getErrors() != null && errorResp.getErrors().size() > 0)	{				
				return errorResp;				
			}else{								
				Customer customer = mobileSession.getCustomer();				
				IBankCommonData commonData=mbAppHelper.populateIBankCommonData(mobileSession,httpServletRequest);
				
				Account fromAcct = customer.getAccounts().get(req.getFromAccountIndex());
				Account toAcct = customer.getAccounts().get(req.getToAccountIndex());
				
				savingSavingsOfferDetails = retentionService.checkSavingSavingsEligibility(fromAcct, toAcct,new BigDecimal(req.getAmt()),commonData);
				
				mobileSession.setOfferDetails(savingSavingsOfferDetails);
				
				RetentionResp retentionResp = retentionHelper.populateRetentionEligibilityResp(savingSavingsOfferDetails); 
				retentionResp.setHeader(mbAppHelper.populateResponseHeader("savingsEligibility", mobileSession));
				
				Logger.info("processSavingsEligibility ends",this.getClass());
				return retentionResp;
			}				
		}catch (BusinessException e){
			Logger.info("BusinessException in RetentionController - [key: " + e.getKey() + "] : GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());				
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), e, ServiceConstants.ACCOUNT_TRANSFER_SERVICE, httpServletRequest);
		}catch (ResourceException e){
			Logger.error("ResourceException in RetentionController - [key: " + e.getKey() + "] : GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.SYSTEM_UNAVILABLE, ServiceConstants.ACCOUNT_TRANSFER_SERVICE, httpServletRequest);					
		} catch (Exception e){
			Logger.error("Exception in RetentionController GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.GENERIC_ERROR, ServiceConstants.ACCOUNT_TRANSFER_SERVICE, httpServletRequest);
		} finally{
			perfLogger.endLog(logName);
			perfLogger.endAllLogs();
		}		
	}
	
	@RequestMapping(value = "acceptSavings", method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public IMBResp processAcceptSavings(HttpServletRequest httpServletRequest,HttpServletResponse httpServletResponse,@RequestBody final RetentionOfferAcceptReq req) { 
				
		Logger.info("processAcceptSavings starts",this.getClass());

		perfLogger.startAllLogs();
		String logName = MBAppUtils.getLogName(httpServletRequest);
		perfLogger.startLog(logName);					
		MobileSession mobileSession = new MobileSessionImpl();
		OfferDetails savingSavingsOfferDetails = null;
		 
		try{			
			mobileSession.getSessionContext(httpServletRequest);
			ErrorResp errorResp = validate(req, httpServletRequest);
			
			if (errorResp != null && errorResp.getErrors() != null && errorResp.getErrors().size() > 0)	{				
				return errorResp;				
			}else{												
				IBankCommonData commonData=mbAppHelper.populateIBankCommonData(mobileSession,httpServletRequest);
				Customer customer = mobileSession.getCustomer();
				
				if(mobileSession.getOfferDetails() != null){
					Account account = customer.getAccounts().get(req.getAccountIndex());
					savingSavingsOfferDetails = mobileSession.getOfferDetails();
					retentionService.processSavingSavingsOfferAccept(account,commonData, savingSavingsOfferDetails, null, SAVING_SAVINGS_OFFER);
				}
				
				RetentionResp retentionResp = retentionHelper.populateRetentionAcceptResp(savingSavingsOfferDetails); 
				retentionResp.setHeader(mbAppHelper.populateResponseHeader("acceptSavings", mobileSession));
				
				Logger.info("processAcceptSavings ends",this.getClass());
				return retentionResp;
			}				
		} catch (Exception e){
			Logger.error("Exception in RetentionController GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.RETENTION_SAVINGS_ACCEPT_FAILED, ServiceConstants.RETENTION_SAVING_ACCEPTANCE_SERVICE, httpServletRequest);
		} finally{
			perfLogger.endLog(logName);
			perfLogger.endAllLogs();
		}		
	}

	
	@RequestMapping(value = "acceptOffer", method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public IMBResp processAcceptOffer(HttpServletRequest httpServletRequest,HttpServletResponse httpServletResponse,@RequestBody final RetentionOfferReq req) { 
				
		Logger.info("processAcceptOffer starts",this.getClass());

		perfLogger.startAllLogs();
		String logName = MBAppUtils.getLogName(httpServletRequest);
		perfLogger.startLog(logName);					
		MobileSession mobileSession = new MobileSessionImpl();
		OfferDetails offerDetails = null;
		String sessionLeadID = null;
		 
		try{			
			mobileSession.getSessionContext(httpServletRequest);
			ErrorResp errorResp = validate(req, httpServletRequest);
			
			if (errorResp != null && errorResp.getErrors() != null && errorResp.getErrors().size() > 0)	{				
				return errorResp;				
			}else{												
				IBankCommonData commonData=mbAppHelper.populateIBankCommonData(mobileSession,httpServletRequest);
				if(mobileSession.getOfferDetails() != null){
					
					offerDetails = mobileSession.getOfferDetails();
					
					if(IBankParams.isSwitchOn(IBankParams.getBaseOriginCode(commonData.getOrigin()),IBankParams.AEM_NBA_CAMPAIGN_SWITCH)){
						sessionLeadID = mobileSession.getRetentionCampaignLead();
						Logger.debug("Lead id in session : "+ sessionLeadID ,this.getClass());
						Logger.debug("Lead id in request : "+ req.getLeadId().trim(), this.getClass());
						if(StringMethods.isEmptyString(sessionLeadID) || !req.getLeadId().trim().equalsIgnoreCase(sessionLeadID)){
							throw new BusinessException(BusinessException.SYSTEM_UNAVILABLE);
						}
					}
					
					offerDetails=retentionService.getRetentionOfferDetails(offerDetails, commonData, req.getLeadId(),req.getOfferType());
					
					if(req.getOfferType().equals(CASH_BACK_OFFER)){
					  retentionService.processSavingSavingsOfferAccept(offerDetails.getAccount(), commonData, offerDetails, req.getLeadId(), CASH_BACK_OFFER);
					 }
					if(req.getOfferType().equals(FEE_WAIVER_OFFER)){
					  retentionService.processFeeWaiverOfferAccept(offerDetails.getAccount(), commonData, offerDetails, req.getLeadId());
					 }
					
					retentionService.sendOfferDetailsMsg(commonData, offerDetails);
				}
				
				RetentionResp retentionResp = retentionHelper.populateAcceptOfferResp(offerDetails); 
				retentionResp.setHeader(mbAppHelper.populateResponseHeader("acceptOffer", mobileSession));
				
				mobileSession.removeOfferDetails();
				mobileSession.removeRetentionCampaignLead();
				Logger.info("processAcceptOffer ends",this.getClass());
				return retentionResp;
			}				
		} catch (Exception e){
			Logger.error("Exception in RetentionController GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.RETENTION_SAVINGS_ACCEPT_FAILED, ServiceConstants.RETENTION_SAVING_ACCEPTANCE_SERVICE, httpServletRequest);
		} finally{
			perfLogger.endLog(logName);
			perfLogger.endAllLogs();
		}		
	}
	
	@RequestMapping(value = "declineSavings", method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public IMBResp processDeclineSavings(HttpServletRequest httpServletRequest,HttpServletResponse httpServletResponse,@RequestBody final EmptyReq req) { 
				
		Logger.info("processDeclineSavings starts",this.getClass());

		perfLogger.startAllLogs();
		String logName = MBAppUtils.getLogName(httpServletRequest);
		perfLogger.startLog(logName);					
		MobileSession mobileSession = new MobileSessionImpl();
		 
		try{			
			mobileSession.getSessionContext(httpServletRequest);
			ErrorResp errorResp = validate(req, httpServletRequest);
			
			if (errorResp != null && errorResp.getErrors() != null && errorResp.getErrors().size() > 0)	{				
				return errorResp;				
			}else{												
				IBankCommonData commonData=mbAppHelper.populateIBankCommonData(mobileSession,httpServletRequest);
				
				if(mobileSession.getOfferDetails() != null){
					OfferDetails savingSavingsOfferDetails = mobileSession.getOfferDetails();
					retentionService.processSavingSavingsOfferDecline(commonData, savingSavingsOfferDetails);
				}
				
				SuccessResp successResp = new SuccessResp();
				successResp.setHeader(mbAppHelper.populateResponseHeader("declineSavings", mobileSession));
				successResp.setIsSuccess(true);
				
				Logger.info("processDeclineSavings ends",this.getClass());
				return successResp;
			}				
		}catch (BusinessException e){
			Logger.info("BusinessException in RetentionController - [key: " + e.getKey() + "] : GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());				
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), e, ServiceConstants.ACCOUNT_TRANSFER_SERVICE, httpServletRequest);
		}catch (ResourceException e){
			Logger.error("ResourceException in RetentionController - [key: " + e.getKey() + "] : GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.SYSTEM_UNAVILABLE, ServiceConstants.ACCOUNT_TRANSFER_SERVICE, httpServletRequest);					
		} catch (Exception e){
			Logger.error("Exception in RetentionController GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.GENERIC_ERROR, ServiceConstants.ACCOUNT_TRANSFER_SERVICE, httpServletRequest);
		} finally{
			perfLogger.endLog(logName);
			perfLogger.endAllLogs();
		}		
	}
	
	@RequestMapping(value = "saveSurveyReason", method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public IMBResp saveSurveyReasonStatistics(HttpServletRequest httpServletRequest,HttpServletResponse httpServletResponse,@RequestBody final RetentionSurveyReq req) { 
				
		Logger.info("saveSurveyReasonStatistics starts",this.getClass());

		perfLogger.startAllLogs();
		String logName = MBAppUtils.getLogName(httpServletRequest);
		perfLogger.startLog(logName);					
		MobileSession mobileSession = new MobileSessionImpl();
		 
		try{			
			mobileSession.getSessionContext(httpServletRequest);
			ErrorResp errorResp = validate(req, httpServletRequest);
			
			if (errorResp != null && errorResp.getErrors() != null && errorResp.getErrors().size() > 0)	{				
				return errorResp;				
			}else{												
				IBankCommonData commonData=mbAppHelper.populateIBankCommonData(mobileSession,httpServletRequest);
				
				String retAction = null;
				
				if(ACCEPT_OFFER.equals(req.getSurveyAction())){
					retAction = Statistic.RETENTION_SURVEY_ACCEPT;
				}else if(DECLINE_OFFER.equals(req.getSurveyAction())){
					retAction = Statistic.RETENTION_SURVEY_DECLINE;
				}
				
				retentionService.createSurveyStat(retAction, req.getSurveyReason(), commonData);
				
				SuccessResp successResp = new SuccessResp();
				successResp.setHeader(mbAppHelper.populateResponseHeader("saveSurveyReason", mobileSession));
				successResp.setIsSuccess(true);
				
				Logger.info("saveSurveyReasonStatistics ends",this.getClass());
				return successResp;
			}				
		}catch (BusinessException e){
			Logger.info("BusinessException in RetentionController | Method saveSurveyReasonStatistics - [key: " + e.getKey() + "] : GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());				
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), e, ServiceConstants.RETENTION_SERVICE, httpServletRequest);
		}catch (ResourceException e){
			Logger.error("ResourceException in RetentionController | Method saveSurveyReasonStatistics - [key: " + e.getKey() + "] : GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.SYSTEM_UNAVILABLE, ServiceConstants.RETENTION_SERVICE, httpServletRequest);					
		} catch (Exception e){
			Logger.error("Exception in RetentionController | Method saveSurveyReasonStatistics GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.GENERIC_ERROR, ServiceConstants.RETENTION_SERVICE, httpServletRequest);
		} finally{
			perfLogger.endLog(logName);
			perfLogger.endAllLogs();
		}		
	}
	
	
	/**
	 * Response for invalid body request 
	 * 
	 * @return
	 */
	@ExceptionHandler({org.springframework.http.converter.HttpMessageNotReadableException.class})
	@ResponseStatus(org.springframework.http.HttpStatus.OK)
	@ResponseBody
	public IMBResp resolveException() {		
		return MBAppUtils.createInvalidMessageBodyResponse(ServiceConstants.RETENTION_SERVICE);
	}
	
	public ErrorResp validate(IMBReq serviceRequest, HttpServletRequest request) {
		return  mbAppValidator.validate(serviceRequest, request);
	}
	
	public void validateRequestHeader(ReqHeader header, HttpServletRequest request) throws ResourceException
	{	
		mbAppValidator.validateRequestHeader(header,  request);	
	}
	
	public RespHeader populateResponseHeader(String ServiceName)
	{		
		return mbAppHelper.populateResponseHeader(ServiceName);
	}				
	
	
	public RespHeader populateResponseHeader(String serviceName, MobileSession mobSession )
	{
		return mbAppHelper.populateResponseHeader(serviceName, mobSession);
	}
	
}
