package au.com.stgeorge.mbank.controller.newaccount;

import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

import au.com.stgeorge.framework.common.logging.Logger;
import au.com.stgeorge.framework.common.model.User;
import au.com.stgeorge.framework.common.util.DateMethods;
import au.com.stgeorge.framework.common.util.StringMethods;
import au.com.stgeorge.ibank.businessobject.AccountFilter;
import au.com.stgeorge.ibank.businessobject.BusinessException;
import au.com.stgeorge.ibank.businessobject.ResourceException;
import au.com.stgeorge.ibank.businessobject.StatisticsService;
import au.com.stgeorge.ibank.common.cache.IBankParams;
import au.com.stgeorge.ibank.common.log.IBankLog;
import au.com.stgeorge.ibank.util.ServiceHelper;
import au.com.stgeorge.ibank.util.StringUtil;
import au.com.stgeorge.ibank.valueobject.Account;
import au.com.stgeorge.ibank.valueobject.AccountId;
import au.com.stgeorge.ibank.valueobject.Address;
import au.com.stgeorge.ibank.valueobject.Customer;
import au.com.stgeorge.ibank.valueobject.Statistic;
import au.com.stgeorge.ibank.valueobject.TDAForecastVO;
import au.com.stgeorge.ibank.valueobject.TermDepositAccount;
import au.com.stgeorge.ibank.valueobject.TermDepositProduct;
import au.com.stgeorge.ibank.valueobject.ThirdParty;
import au.com.stgeorge.ibank.valueobject.database.AcctOpeningVO;
import au.com.stgeorge.ibank.valueobject.database.CodesVO;
import au.com.stgeorge.ibank.valueobject.database.RegionVO;
import au.com.stgeorge.ibank.valueobject.transfer.IBankCommonData;
import au.com.stgeorge.ibank.valueobject.transfer.NewTermDepositAccount;
import au.com.stgeorge.ibank.valueobject.transfer.TermDepositProductList;
import au.com.stgeorge.ibank.valueobject.transfer.TermDepositRenewal;
import au.com.stgeorge.mbank.model.common.AddressResp;
import au.com.stgeorge.mbank.model.common.IMBResp;
import au.com.stgeorge.mbank.model.common.KeyValueResp;
import au.com.stgeorge.mbank.model.common.NewAcctDupResp;
import au.com.stgeorge.mbank.model.common.PaymentInstructionsResp;
import au.com.stgeorge.mbank.model.common.ReceiptResp;
import au.com.stgeorge.mbank.model.common.TDAProductResp;
import au.com.stgeorge.mbank.model.request.newaccount.TermDepositReq;
import au.com.stgeorge.mbank.model.response.newaccount.TermDepositResp;
import au.com.stgeorge.mbank.session.MobileSession;
import au.com.stgeorge.mbank.util.MBAppConstants;
import au.com.stgeorge.mobilebank.businessobject.OpenDDAService;





/**
 * @author 
 * 
 */
public class TermDepositHelper
{

	private static final String STG_BSB_PREFIX = "11";
	private static final String BSA_BSB_PREFIX = "10";
	private static final String CHS_BSB_PREFIX = "33";
	private static final String BOM_BSB_PREFIX = "19";
	public static final String BILLER_CODE = "BillerCode";
	
	public static final String FLEXI_TDA_SUB_PROD="80";

	public void addStatticLog(TermDepositRenewal renewalObject){
		Statistic s = new Statistic();
		s.setAction(Statistic.TERM_DEPOSIT_REINVEST);
		s.setGcisNumber(renewalObject.getCustomer().getGcis());
		s.setOriginBank(renewalObject.getCommonData().getGdwOrigin());
		s.setGDWOriginBank(renewalObject.getCommonData().getGdwOrigin());

		if (renewalObject.getSourceFromAccount() != null) {
			s
			    .setAccountNumberFrom(StringMethods.safeString(renewalObject
			        .getSourceFromAccount().getAccountId().getBranchKey(), "")
			        + renewalObject.getSourceFromAccount().getAccountId()
			            .getAccountKey());
			s.setAccountTypeFrom(renewalObject.getSourceFromAccount().getAccountId()
			    .getEhubProductCode());
			s.setProdCodeFrom(renewalObject.getSourceFromAccount().getAccountId()
			    .getSubProductCode());

			if (renewalObject.getAddWidthdrawlIndicator() == TermDepositRenewal.ADD_INDICATOR) {
				s.setAmount(renewalObject.getAccount().getBalance().add(
				    renewalObject.getTransferAmount()));
			} else if (renewalObject.getAddWidthdrawlIndicator() == TermDepositRenewal.WITHDRAWL_INDICATOR) {
				s.setAmount(renewalObject.getAccount().getBalance().subtract(
				    renewalObject.getTransferAmount()));
			} else {
				s.setAmount(renewalObject.getAccount().getBalance());
			}
		}
		s.setIpAddress(renewalObject.getCommonData().getIpAddress());
		s.setSessionId(renewalObject.getCommonData().getSessionId());
		
		try {
			StatisticsService.logStatistic(s);
		} catch (Throwable t) {
			// do nothing as this is not a part of the transaction
			IBankLog.logERR(
			    "Failed to create a statistic entry for renew term deposit", t,
			    this.getClass());
		}
	}

	public IMBResp populateDuplicateAcctsList(MobileSession mobileSession,ArrayList<AcctOpeningVO> duplicateAcctOpeningList, String securityUniqueID){
		TermDepositResp termDepositResp = new TermDepositResp();
		//JSONObject json = new JSONObject();
		//json.put(MobileConstants.HTTP_REQUEST_PARAM_SECURITY_UNIQUE_ID, securityUniqueID);
		//JSONArray jsonArray = new JSONArray();
		ArrayList<NewAcctDupResp> acctOpeningList = new ArrayList<NewAcctDupResp>();
		
		if(duplicateAcctOpeningList!=null && duplicateAcctOpeningList.size() > 0){
			//AcctOpeningVO eachVO = new AcctOpeningVO();
			int len=duplicateAcctOpeningList.size();		
			
			for (int i = 0; i < duplicateAcctOpeningList.size(); i++){
				NewAcctDupResp newTDAAcctDupResp = new NewAcctDupResp();
				AcctOpeningVO eachVO = (AcctOpeningVO) duplicateAcctOpeningList.get(i);
				
				newTDAAcctDupResp.setId((len-i));
				newTDAAcctDupResp.setAmt(eachVO.getAmount().toString());
				newTDAAcctDupResp.setTerm(eachVO.getTermLength());
				if(eachVO.getAccountNumberFrom() != null){
					newTDAAcctDupResp.setFromAcct(getFormattedAcctNumber(eachVO.getAccountNumberFrom(), eachVO.getApplIDFrom(), eachVO.getBsbNumberFrom()));
				}
				newTDAAcctDupResp.setDateTime(eachVO.getRequestDate());
				newTDAAcctDupResp.setStatus(eachVO.getStatus());
				acctOpeningList.add(newTDAAcctDupResp);
			}
		}
		termDepositResp.setDupList(acctOpeningList);
		return termDepositResp;
	}

	public NewTermDepositAccount populateNewTermDepositAccount(MobileSession mobileSession, TermDepositReq req, IBankCommonData ibankCommonData) throws ResourceException, BusinessException{

		NewTermDepositAccount newTdaObj = new NewTermDepositAccount();
		Customer customer=mobileSession.getCustomer();
		User user=mobileSession.getUser();
		
		IBankCommonData commonData=ibankCommonData;
		
		newTdaObj.setOrigin(commonData.getOrigin());
		newTdaObj.setCommonData(commonData);
		newTdaObj.setCustomer(customer);
	
		newTdaObj.setAmount(new BigDecimal(req.getTdaAmount()));
		newTdaObj.setSelectedProduct(req.getProduct().getSubProdcode());
		newTdaObj.setTermInMonths(req.getTdaTerm());
		newTdaObj.setState(req.getTdaState());
		
		ArrayList<TermDepositProduct> tdaProdList = (ArrayList<TermDepositProduct>)mobileSession.getTermDepositProductList();
		TermDepositProduct tdaProd = new TermDepositProduct();
		
		/** HashMap of available interest instructions for account */
		HashMap availableInterestInstructions = new HashMap();
		
		for(int i=0; i < tdaProdList.size() ; i++){
			tdaProd = (TermDepositProduct)tdaProdList.get(i);
			if(tdaProd.getSubProductCode().equalsIgnoreCase(req.getProduct().getSubProdcode())){
				newTdaObj.setSelectedProductInstance(tdaProd);
				break;
			}
		}
		
		Iterator instructions =
			tdaProd.getAvailableInterestInstructions().iterator();
		while (instructions.hasNext())
		{
			String instruction = (String) instructions.next();
			availableInterestInstructions.put(instruction,instruction);
		}
		newTdaObj.setAllowedInterestInstructions(availableInterestInstructions);
		newTdaObj.setInterestInstruction(req.getInterestPayInst());

		//Get account object from the index for source funds from account
		if( req.getSourceAcctIndex() != null && req.getSourceAcctIndex() >= 0  ){
			Account sourceAcct = getAccountFromCustomer(customer, req.getSourceAcctIndex().intValue());
			newTdaObj.setSourceFundsFrom(sourceAcct);
		}
		//Get interest paid to account
		String selInterestToIndex = req.getIntrPayToAcctIndex();
		if(!StringMethods.isEmptyString(selInterestToIndex)){
			selInterestToIndex = selInterestToIndex.replace('|',',');
			String[] tempStr = selInterestToIndex.split(",");
			if(tempStr.length < 2){
				String acctIndex = tempStr[0].trim();
				Account intrToAcct = getAccountFromCustomer(customer, Integer.parseInt(acctIndex));
				if(intrToAcct != null){
					newTdaObj.setSelectedToAccount(intrToAcct.getAccountId());
				}
			}
			else if(MBAppConstants.KEY_IDENTIFIER_THIRD_PARTY.equalsIgnoreCase(tempStr[0].trim())){
				String acctIndex = tempStr[1].trim();
				ThirdParty intrToTP = getThirdPartyFromCustomer(customer, Integer.parseInt(acctIndex));
				newTdaObj.setSelectedToThirdParty(intrToTP);
			}
		}
		
		//To do set branch and region for unfunded BSA
		
		Collection<RegionVO> regions = getRegions(); 
		
		if(req.getBranchId() != null){
			newTdaObj.setSelectedBranch(req.getBranchId());
		}
		
		if(req.getLeadIdTda() != null)
			newTdaObj.setLeadId(req.getLeadIdTda());
		
		return newTdaObj;
	}
	
	public ThirdParty getThirdPartyFromCustomer(Customer customer, int index) {
		ThirdParty thirdParty = null;
		if (customer.getThirdParties() != null
				&& customer.getThirdParties().size() > 0) {
			ArrayList thirdPartyList = (ArrayList) customer.getThirdParties();
			int thirdPartyListLen = customer.getThirdParties().size();
			for (int i = 0; i < thirdPartyListLen; i++) {
				if (index == i) {
					thirdParty = (ThirdParty) thirdPartyList.get(i);
					break;
				}
			}
		}
		return thirdParty;
	}
	public IMBResp populateProductResponse(MobileSession mbSession,  Collection<Account> fundingAccounts, List<Account> custAccounts, String origin, TDAForecastVO forecastVO, boolean isLooseRetIndFlag, boolean isRenew, Collection<RegionVO> regions, TermDepositAccount tdaAccount){
		TermDepositResp tdaResp = new TermDepositResp();
		String tdaBillerCode = null;
    boolean exclIntApplied = false;
    
    Collection tdaProdList = mbSession.getTermDepositProductList();
		if(isLooseRetIndFlag) {
			tdaResp.setLooseRetIntFlag(true); // Y
		} else {
			tdaResp.setLooseRetIntFlag(false); // N
		}
/*		if(forecastVO != null) {
			if("C".equalsIgnoreCase(forecastVO.getNewInterestRateType() ) || StringMethods.isEmptyString(forecastVO.getNewInterestRateType()) ) {
				//Logger.debug("Inside getProductsRates & NewInterestRateType==C : Flag set to Y " +isLooseRetIndFlag , this.getClass());
				tdaResp.setLooseRetIntFlag(true);
				tdaResp.setRetIntProdCode(forecastVO.getSubProductcode());
				tdaResp.setNewIntRate(forecastVO.getNewInterestRate().toString());
			} else {
				//Logger.debug("Inside getProductsRates & NewInterestRateType!=C : Flag set to N " +isLooseRetIndFlag , this.getClass());
				tdaResp.setLooseRetIntFlag(false);
				tdaResp.setRetIntProdCode(forecastVO.getSubProductcode());
				tdaResp.setNewIntRate(forecastVO.getNewInterestRate().toString());
	//			tdaResp.setExclIntRateApp("Y");
				exclIntApplied = true;
			}
		}  */	//			exclIntApplied = true;


		if(forecastVO != null && tdaAccount != null ) {
			if("C".equalsIgnoreCase(forecastVO.getNewInterestRateType() ) || StringMethods.isEmptyString(forecastVO.getNewInterestRateType()) ) {
				Logger.debug("Inside getProductsRates & NewInterestRateType==C : Flag set to Y " +isLooseRetIndFlag , this.getClass());
				if ( forecastVO.getNewInterestRate().compareTo(forecastVO.getCurrentInterestRate()) < 0)
				{
					tdaResp.setLooseRetIntFlag(true);
					tdaResp.setRetIntProdCode(forecastVO.getSubProductcode());
					tdaResp.setNewIntRate(forecastVO.getNewInterestRate().toString());
				}
				else
				{
					tdaResp.setLooseRetIntFlag(false);
					tdaResp.setRetIntProdCode(forecastVO.getSubProductcode());
					tdaResp.setNewIntRate(forecastVO.getNewInterestRate().toString());
//					exclIntApplied = true;
				}
			} else {
					Logger.debug("Inside getProductsRates & NewInterestRateType!=C : Flag set to N " +isLooseRetIndFlag + " tdaAccount.getInterestRate() "+tdaAccount.getInterestRate() + " forecastVO.getNewInterestRate()"+ forecastVO.getNewInterestRate() , this.getClass());
					tdaResp.setLooseRetIntFlag(false);
//				json.put("looseRetIntFlag", "N");
//				json.put("retIntProdCode", forecastVO.getSubProductcode());
//				json.put("newIntRate", forecastVO.getNewInterestRate());
					tdaResp.setRetIntProdCode(forecastVO.getSubProductcode());
					tdaResp.setNewIntRate(forecastVO.getNewInterestRate().toString());
					exclIntApplied = true;
			}
		}
		
		
		if (tdaProdList!= null){
			//ArrayList<TermDepositProduct> productList = (ArrayList<TermDepositProduct>)tdaProdList.getProductList();
			//TermDepositProduct tdaProduct;
			ArrayList<TDAProductResp> rateDetail = new ArrayList<TDAProductResp>();
			Collection<TermDepositProduct> productList = tdaProdList;
			Iterator<TermDepositProduct> iterator = productList.iterator();
			while(iterator.hasNext())
			{
			//for (int i = 0; i < tdaProdList.getProductList().size(); i++){
				//JSONObject eachRow=new JSONObject();
				TermDepositProduct tdaProduct = (TermDepositProduct)iterator.next();
				if(IBankParams.isFlexiTermDepositRemovalSwitchON()){
					if(!FLEXI_TDA_SUB_PROD.equalsIgnoreCase(tdaProduct.getSubProductCode())||isRenew){
						TDAProductResp tdaProductResp = new TDAProductResp();
						
						tdaProductResp.setFrequencyCode(tdaProduct.getFrequencyCode());
						tdaProductResp.setFrequency(tdaProduct.getFrequency());
						tdaProductResp.setInterestRate(tdaProduct.getInterestRate());
						tdaProductResp.setRangeFrom(tdaProduct.getRangeFrom());
						tdaProductResp.setRangeTo(tdaProduct.getRangeTo());
						tdaProductResp.setSubProdCode(tdaProduct.getSubProductCode());	
						if ( exclIntApplied && forecastVO != null && tdaProduct.getSubProductCode().equalsIgnoreCase(forecastVO.getSubProductcode()))
						{
							Logger.debug("exclIntApplied for  " + tdaProduct.getSubProductCode() + " forecastVO.getSubProductcode() "+tdaAccount.getInterestRate() + " forecastVO.getNewInterestRate()"+ forecastVO.getNewInterestRate() , this.getClass());
							tdaProductResp.setExclIntRate(exclIntApplied);
							tdaProductResp.setInterestRate(forecastVO.getNewInterestRate());
						}
						ArrayList<PaymentInstructionsResp> paymentInstructions = getPaymentInstructions(tdaProduct);;
						tdaProductResp.setPaymentInstructions(paymentInstructions);
						rateDetail.add(tdaProductResp);
					}
			}
				else{
					TDAProductResp tdaProductResp = new TDAProductResp();
					tdaProductResp.setFrequencyCode(tdaProduct.getFrequencyCode());
					tdaProductResp.setFrequency(tdaProduct.getFrequency());
					tdaProductResp.setInterestRate(tdaProduct.getInterestRate());
					tdaProductResp.setRangeFrom(tdaProduct.getRangeFrom());
					tdaProductResp.setRangeTo(tdaProduct.getRangeTo());
					tdaProductResp.setSubProdCode(tdaProduct.getSubProductCode());	
					if ( exclIntApplied && forecastVO != null && tdaProduct.getSubProductCode().equalsIgnoreCase(forecastVO.getSubProductcode()))
					{
						Logger.debug("exclIntApplied for  " + tdaProduct.getSubProductCode() + " forecastVO.getSubProductcode() "+tdaAccount.getInterestRate() + " forecastVO.getNewInterestRate()"+ forecastVO.getNewInterestRate() , this.getClass());
						tdaProductResp.setExclIntRate(exclIntApplied);
						tdaProductResp.setInterestRate(forecastVO.getNewInterestRate());
					}
					ArrayList<PaymentInstructionsResp> paymentInstructions = getPaymentInstructions(tdaProduct);;
					tdaProductResp.setPaymentInstructions(paymentInstructions);
					rateDetail.add(tdaProductResp);
				}
				
				
			}
			tdaResp.setRateDetail(rateDetail);
		}

		
		if(fundingAccounts != null){
			ArrayList<Account> custAcctList = (ArrayList<Account>)custAccounts;

			int id;
			ArrayList<Integer> idList = new ArrayList<Integer>();
			for (Iterator<Account> iterator = fundingAccounts.iterator(); iterator.hasNext();) {
				Account eachAccount = iterator.next();
				id = getAccountIndex(custAcctList, eachAccount.getAccountId());
				idList.add(id);
			}
			tdaResp.setAccountIndexes(idList);
		}
		
		Collection<Account> acctList = AccountFilter.getTermDepositPaidToInterestAccounts(mbSession.getCustomer().getAccounts());
		ArrayList<Account> accts = createAcctListfromSession(mbSession.getCustomer(), acctList);

		ArrayList<String> idList = new ArrayList<String>();

		if(accts != null){
			//ArrayList<Account> custAcctList = (ArrayList<Account>)custAccounts;
			int id;
			for (Iterator<Account> iterator = accts.iterator(); iterator.hasNext();) {
				Account eachAccount = iterator.next();
//				id = getAccountIndex(accts, eachAccount.getAccountId());
				idList.add(String.valueOf(eachAccount.getIndex()));
			}
		}
		if ( mbSession.getCustomer().getThirdParties() != null )
		{
			ArrayList thirdPartyList = (ArrayList) mbSession.getCustomer().getThirdParties();

			int thirdPartyListLen = thirdPartyList.size();
			for (int i = 0; i < thirdPartyListLen; i++) {
				ThirdParty thirdParty = (ThirdParty) thirdPartyList.get(i);
				idList.add("T|"+i);
				}
		}
		
		if ( idList.size() > 0 )
		{
			tdaResp.setIntrToAcctIndexes(idList);
		}

		if ( tdaAccount != null )
		{
			tdaBillerCode = getBillerCodeForTDA(tdaAccount, "TermDeposit");
		}
		
		if (StringMethods.isEmptyString(tdaBillerCode) )
		{
			CodesVO codesVO = IBankParams.getCodesData(origin, "TermDeposit", "EmailBillerCode");
			tdaBillerCode = codesVO.getMessage();
		}
		
		tdaResp.setTermDepBillerCode(tdaBillerCode);
		
		if ( regions!= null )
		{
			ArrayList<KeyValueResp> regionList = new ArrayList<KeyValueResp>();
			for (Iterator<RegionVO> iterator = regions.iterator(); iterator.hasNext();) {
				RegionVO eachRegion = iterator.next();
				KeyValueResp nameIDResp = new KeyValueResp();
				nameIDResp.setId(  eachRegion.getRegionId() );
				nameIDResp.setName(  eachRegion.getRegionName() );
				regionList.add(nameIDResp);
			}
			tdaResp.setRegions(regionList);
		}

		return tdaResp;
	}
	
	public static String getBillerCodeForTDA(Account acct,String code){
		String billerCode ="";
		CodesVO codesVo = new CodesVO();
		//String branchKey="";
		if(acct!=null && !StringMethods.isEmptyString(acct.getBrand())){
			codesVo = IBankParams.getCodesData("M"+acct.getBrand(), code,BILLER_CODE);
		}
//		else{
//			if(acct!=null){
//				branchKey = acct.getAccountId().getBranchKey();
//				if (OpenTermDepositAction.TDA_BRANCHKEY.equals(branchKey)) {
//					codesVo = IBankParams.getCodesData(IBankForm.STG,code,OpenTermDepositAction.BILLER_CODE);
//				}
//				else{
//					codesVo = IBankParams.getCodesData(IBankForm.BSA, code,OpenTermDepositAction.BILLER_CODE);	
//				}
//			}else{
//				IBankLog.logWRN("Account is NULL in getBillerCodeForTDA.Cannot get BillerCode.", IBankActionHelper.class);
//			}
//		}
		if(codesVo.getMessage()!=null)
			billerCode = codesVo.getMessage();
		return billerCode;
	}
	

	public ArrayList<Account> createAcctListfromSession(Customer customer, Collection<Account> accounts){
		ArrayList<Account> resultList = new ArrayList<Account>();
		
		if(accounts != null){
			ArrayList<Account> acctList = (ArrayList<Account>)accounts;
			Account acct = new Account();
			Account custAcct = new Account();
			ArrayList<Account> custAcctList = (ArrayList<Account>)customer.getAccounts();
			String acctKey ="";
			for (int i = 0; i < acctList.size(); i++){
				acct = (Account) acctList.get(i);
				acctKey = acct.getAccountId().getAccountKey();
				for(int j=0; j < custAcctList.size(); j++){
					custAcct = (Account) custAcctList.get(j);
					if(custAcct.getAccountId().getAccountKey().equalsIgnoreCase(acctKey)){
						resultList.add(custAcct);
						break;
					}
				}
			}
		}
		return resultList;
	}

	private ArrayList<PaymentInstructionsResp> getPaymentInstructions(TermDepositProduct tdaProduct)
	{
		Iterator instructions = tdaProduct.getAvailableInterestInstructions().iterator();
		ArrayList<PaymentInstructionsResp> paymentInstructionsList = new ArrayList<PaymentInstructionsResp>();
		while (instructions.hasNext())
		{
			PaymentInstructionsResp paymentInstructionsResp = new PaymentInstructionsResp();
			String code = (String) instructions.next();
			paymentInstructionsResp.setCode(code);
			if(MBAppConstants.PAY_TO_ACCOUNT.equalsIgnoreCase(code)){
				paymentInstructionsResp.setDesc(MBAppConstants.PAY_TO_ACCOUNT_TEXT);
			}
			if(MBAppConstants.MAIL_CHEQUE.equalsIgnoreCase(code)){
				paymentInstructionsResp.setDesc(MBAppConstants.MAIL_CHEQUE_TEXT);
			}
			if(MBAppConstants.ADD_TO_PRINCIPAL.equalsIgnoreCase(code)){
				paymentInstructionsResp.setDesc(MBAppConstants.ADD_TO_PRINCIPAL_TEXT);
			}
			paymentInstructionsList.add(paymentInstructionsResp);
		}
		return paymentInstructionsList;
	}

	public IMBResp populateopenTDAAccountResp(NewTermDepositAccount newTDAAccount)
	{
		TermDepositResp openTDAResp = new TermDepositResp();
		ReceiptResp receiptResp = new ReceiptResp();

		if(newTDAAccount!=null){
			if(newTDAAccount.getReceipt() != null){
//				openTDAResp.setReceiptNumDisp(formatReceiptNumber(newTDAAccount.getReceipt().getReceiptNumber()));
				receiptResp.setReceiptNumDisp(formatReceiptNumber(newTDAAccount.getReceipt().getReceiptNumber()));
				receiptResp.setNewAccountNum(newTDAAccount.getNewAcctNumber());
				receiptResp.setDateTime(newTDAAccount.getReceipt().getTimestamp());
				
				openTDAResp.setNewTdaBal(newTDAAccount.getAmount().toString());
				if(newTDAAccount.getNewAcctNumber() != null){
					openTDAResp.setTransType(MBAppConstants.OPEN_ACCT_FUNDED_SUCCESS);
					openTDAResp.setTdaAcctNum(getFormattedAcctNumber(newTDAAccount.getNewAcctNumber(), "CDA", newTDAAccount.getNewBSBNumber()));
					receiptResp.setNewAccountNum(getFormattedAcctNumber(newTDAAccount.getNewAcctNumber(), "CDA", newTDAAccount.getNewBSBNumber()));
				}
				else{
					openTDAResp.setTransType(MBAppConstants.OPEN_ACCT_UNSUCCESS_FUNDING_SUCCESS);
					openTDAResp.setTdaAcctNum("To be opened");
					receiptResp.setNewAccountNum("To be opened");
					receiptResp.setStatus("ERROR_OPEN");
				}
			}
			else{
				if(newTDAAccount.getNewAcctNumber() != null){
					openTDAResp.setTransType(MBAppConstants.OPEN_ACCT_SUCCESS_FUNDING_UNSUCCESS);
					openTDAResp.setTdaAcctNum(getFormattedAcctNumber(newTDAAccount.getNewAcctNumber(), "CDA", newTDAAccount.getNewBSBNumber()));
					receiptResp.setNewAccountNum(getFormattedAcctNumber(newTDAAccount.getNewAcctNumber(), "CDA", newTDAAccount.getNewBSBNumber()));
				}
			}
			
			if((newTDAAccount.getSourceFundsFrom()!= null) && (newTDAAccount.getNewAcctNumber() == null) && (newTDAAccount.getReceipt() == null)){
				openTDAResp.setTransType(MBAppConstants.OPEN_ACCT_FUNDED_UNSUCCESS);
				openTDAResp.setTdaAcctNum("To be opened");
				receiptResp.setNewAccountNum("To be opened");
				receiptResp.setStatus("ERROR_TRANSFER");
			}
			
			if((newTDAAccount.getSourceFundsFrom()== null) && (newTDAAccount.getNewAcctNumber() == null)){
				openTDAResp.setTransType(MBAppConstants.OPEN_ACCT_NOT_FUNDED_UNSUCCESS);
				openTDAResp.setTdaAcctNum("To be opened");
				receiptResp.setNewAccountNum("To be opened");
				receiptResp.setStatus("ERROR_OPEN");
			}
			
			if((newTDAAccount.getSourceFundsFrom()== null) && (newTDAAccount.getNewAcctNumber() != null)){
				openTDAResp.setTransType(MBAppConstants.OPEN_ACCT_NOT_FUNDED_SUCCESS);
				openTDAResp.setTdaAcctNum(getFormattedAcctNumber(newTDAAccount.getNewAcctNumber(), "CDA", newTDAAccount.getNewBSBNumber()));
				receiptResp.setNewAccountNum(getFormattedAcctNumber(newTDAAccount.getNewAcctNumber(), "CDA", newTDAAccount.getNewBSBNumber()));
			}

			receiptResp.setDateTime(DateMethods.getTimestamp());
			openTDAResp.setReceipt(receiptResp);
			
			openTDAResp.setTransDate(DateMethods.getTimestamp());
			
		}
		
		//openTDAResp.setNewTdaBal(newTDAAccount.getAmount().toString());
		//openTDAResp.setNewTdaReceiptNum(newTDAAccount.getReceipt().getReceiptNumber());
		//openTDAResp.setTdaAcctNum(newTDAAccount.getNewAcctNumber());
		//openTDAResp.setTransDate(newTDAAccount.getReceipt().getTimestamp().toString());
		//openTDAResp.setTransType(newTDAAccount.getReceipt().)
		return openTDAResp;
	}

	public String getFormattedAmount(BigDecimal input) {
		String formatedAmount = "";
		try {
			if (input != null) {
				DecimalFormat df = new DecimalFormat(
						MBAppConstants.AMOUNT_FORMAT);
				formatedAmount = df.format(input);
			}
		} catch (NumberFormatException ne) {
			IBankLog.logERR("Could not format the Amount : " + input, ne, this
					.getClass());
		}
		return formatedAmount;

	}
	
	public static boolean isInternalNominatedAcct(String bsb) {
		boolean internalNomAcct = false;
		if (StringMethods.isValidString(bsb)) {
			String bsbPrefix = bsb.substring(0, 2);
			if (STG_BSB_PREFIX.equals(bsbPrefix)
					|| BSA_BSB_PREFIX.equals(bsbPrefix)
					|| CHS_BSB_PREFIX.equals(bsbPrefix)
					|| BOM_BSB_PREFIX.equals(bsbPrefix)) {
				internalNomAcct = true;
			}
		}
		return internalNomAcct;
	}

	public String getFormattedAcctNumber(String sAccount, String accountType,
			String bsb) {
		StringBuffer formattedAcctNum = new StringBuffer();
		int counter = 0;
		String temp = "";
		if (StringMethods.isValidString(sAccount)) {
			sAccount = sAccount.replaceAll(" ", "");
			sAccount = sAccount.trim();
			int len = sAccount.length();
			if (Account.NOM.equalsIgnoreCase(accountType)) {
				if (bsb != null && bsb.length() > 0) {
					boolean internalNomAcct = isInternalNominatedAcct(bsb);
					if (!internalNomAcct) {
						return sAccount;
					}
				}
			}
			if ((len > 9) && (!(Account.CDA.equalsIgnoreCase(accountType)))) {
				String acctNumStr = sAccount.substring(0, 4);
				if (acctNumStr.startsWith("0")) {
					sAccount = sAccount.replaceAll("^[0]*", "");
					if (sAccount.length() < 9) {
						sAccount = StringUtil
								.padLeadingString(sAccount, 9, '0');
					}
				}
			}
			len = sAccount.trim().length();
			if (Account.MGL.equalsIgnoreCase(accountType)) {
				formattedAcctNum.append(sAccount);
			} else if (Account.DDA.equalsIgnoreCase(accountType)
					|| Account.CDA.equalsIgnoreCase(accountType)
					|| Account.CHS.equalsIgnoreCase(accountType)) {
				if (len > 9) {
					formattedAcctNum = formatBSA(len, sAccount, accountType);
				} else {
					formattedAcctNum = format(3, len, sAccount);
				}
			} else if (Account.CRA.equalsIgnoreCase(accountType)) {
				formattedAcctNum = format(4, len, sAccount);
			}
			else if (Account.LIS.equalsIgnoreCase(accountType)
					|| (sAccount.length() > 0 && !(Character.isDigit(sAccount
							.charAt(0))))) {
				if (sAccount.length() > 3) {
					formattedAcctNum.append(sAccount.trim().substring(0, 4));
					formattedAcctNum.append(" ");
					for (int i = 4; i < len;) {
						counter = i + 3;
						if (counter > len) {
							counter = len;
						}
						temp = sAccount.trim().substring(i, counter);
						formattedAcctNum.append(temp);
						formattedAcctNum.append(" ");
						i = i + 3;
					}
				} else {
					formattedAcctNum.append(sAccount);
				}
			} else if (len == 16) {
				formattedAcctNum = format(4, len, sAccount);
			} else if (len > 0 && len <= 9) {
				formattedAcctNum = format(3, len, sAccount);
			}
			else if (len > 9 && len < 16) {
				formattedAcctNum = formatBSA(len, sAccount, accountType);
			} else {
				formattedAcctNum.append(sAccount);
			}
		}
		return formattedAcctNum.toString();
	}

	private StringBuffer format(int offSet, int len, String sAccount) {
		StringBuffer theBody = new StringBuffer();
		String temp = "";
		int counter = 0;
		for (int i = 0; i < len;) {
			counter = i + offSet;
			if (counter > len) {
				counter = len;
			}
			temp = sAccount.trim().substring(i, counter);
			theBody.append(temp);
			if (counter != len) 
				theBody.append(" ");
			i = i + offSet;
		}
		return theBody;
	}
	private StringBuffer formatBSA(int len, String sAccount, String accountType) {
		StringBuffer theBody = new StringBuffer();
		int counter = 0;
		String temp = "";
		sAccount = sAccount.trim();
		if (len < 13) {
			for (int j = 0; j < 13 - len; j++) {
				sAccount = "0" + sAccount;
			}
		} else if (len > 13 && len < 16) {
			for (int j = 0; j < 16 - len; j++) {
				sAccount = "0" + sAccount;
			}
		}
		len = sAccount.trim().length();
		if (Account.CDA.equalsIgnoreCase(accountType)) {
			if (!sAccount.trim().startsWith("000")) {
				theBody.append(sAccount.trim().substring(0, 3));
				theBody.append(" ");
				theBody.append(sAccount.trim().substring(3, 7));

			} else {
				theBody.append(sAccount.trim().substring(3, 7));

			}
		} else {
			theBody.append(sAccount.trim().substring(4, 7));
		}
		theBody.append(" ");
		for (int i = 7; i < len;) {
			counter = i + 3;
			if (counter > len) {
				counter = len;
			}
			temp = sAccount.trim().substring(i, counter);
			theBody.append(temp);
			if (counter != len) 
				theBody.append(" ");
			i = i + 3;
		}
		return theBody;
	}
	
	public static String formatReceiptNumber(String receiptNumber) {
		StringBuffer theBody = new StringBuffer();
		if (receiptNumber.length() < 1)
			return "";

		String first = "";

		if (!StringMethods.isNumber(receiptNumber.trim().substring(0, 1))) {
			first = receiptNumber.trim().substring(0, 1) + " ";
			receiptNumber = receiptNumber.trim().substring(1,
					receiptNumber.length());
		}

		int len = receiptNumber.length();
		int iter = len / 4;

		if (len <= 4) {
			theBody.append(receiptNumber);
		} else {
			int maxLen = 0;
			for (int i = 0; i <= iter; i++) {
				if (i * 4 + 4 > len)
					maxLen = len;
				else
					maxLen = i * 4 + 4;

				theBody.append(receiptNumber.trim().substring(i * 4, maxLen));
				theBody.append(" ");
			}
		}
		return first + theBody;
	}

	
	
/*	public IMBResp populateBranchResp(BranchVO branch)
	{
		OpenDDAResp openDDAResp = new OpenDDAResp();
		openDDAResp.setBranch(branch);
		return openDDAResp;
	}  */

	public int getAccountIndex(ArrayList<Account> acctList, AccountId pAccountId) {
		int i = 0;
		boolean found = false;
		if (acctList != null && !acctList.isEmpty()) {
			//ArrayList list = acctList;
			int size = acctList.size();
			for (; i < size; i++) {
				Account account = (Account) acctList.get(i);
				if (pAccountId.equals(account.getAccountId())) {
					found = true;
					break;
				}
			}
		}
		if (found)
			return i;
		else
			return -1;
	}

	private AddressResp populateAddress(Address address, String type)
	{
		AddressResp mbAddress = new AddressResp();
		if (address != null)
		{
			mbAddress.setAddrType(type);
			mbAddress.setCountryName(address.getCountryName());
			mbAddress.setLine1(address.getLine1());
			mbAddress.setLine2(address.getLine2());
			mbAddress.setLine3(address.getLine3());

			mbAddress.setPostCode(address.getPostZipcode());
			mbAddress.setState(address.getState());
			mbAddress.setSuburb(address.getSuburb());
		}
		return mbAddress;
	}

	public boolean isCustomerOver18(Customer customer){
	    Calendar today = Calendar.getInstance();
	    today.add(Calendar.YEAR, -18);
	    Calendar birth = Calendar.getInstance();
	    boolean resp = false;
	    if (customer.getBirthDate() != null){
	    	birth.setTime(customer.getBirthDate());
	
	    	if (birth.getTime().getTime() > today.getTime().getTime()){
	    		resp = false;
	    	}else{
	    		resp = true;
	    	}
	    }	
	    return resp;
	}



	public void validateFundingAccount(Customer customer,String fundingAcctId ) throws BusinessException{
		if (!("-1").equalsIgnoreCase(fundingAcctId)){
			Account acct = getAccountFromCustomer(customer, Integer.parseInt(fundingAcctId));
			if (acct == null){
				throw new BusinessException(BusinessException.SOURCE_ACCOUNT_NOT_SELECTED);
			}
		}
	}	

	public Account getAccountFromCustomer(Customer customer, int index) {
		Account account = null;
		if (customer.getAccounts() != null && customer.getAccounts().size() > 0) {
			ArrayList acctList = (ArrayList) customer.getAccounts();
			int acctListLen = customer.getAccounts().size();
			for (int i = 0; i < acctListLen; i++) {
				if (index == i) {
					account = (Account) acctList.get(i);
					break;
				}
			}
		}
		return account;
	}

	public void validateAddress(Customer customer)throws BusinessException{
		// Check If no residential address given
		if(customer.getContactDetail().getResidentialAddress()==null||customer.getContactDetail().getResidentialAddress().equals("")){
			// Please provide the residential address to proceed further.
			throw new BusinessException(BusinessException.RESIDENTIALADDR_REQUIRED);
		}		
	}

	public void validateCardDeliveryAddress(Customer customer, boolean isCustomerOver18)throws BusinessException{
		//Customer is minor, choose to pickup card, and Residential address is not in Australia
		if (!isCustomerOver18){
			if (!MBAppConstants.AUSTRALIA.equalsIgnoreCase(customer.getContactDetail().getResidentialAddress().getCountryName()) ){
				throw new BusinessException(BusinessException.OVERSEASADDRESS_ERROR);
			}
		}	
	}

//	public void validateMinAmount() throws BusinessException{
//		
//		String category = minAmountCodes.get(String.valueOf(getProdID()));
//		
//		CodesVO myCodesVO = IBankParams.getCodesData(IBankParams.DEFAULT_ORIGIN, category, IBankParams.CD_NEW_ACC_MIN_AMT);
//		
//		BigDecimal minimumAmount = new BigDecimal(myCodesVO.getMessage());
//		
//		
//	}
	
	private int resolveOrigin (String origin){
		int resp = 0;
		if (origin.equalsIgnoreCase(MBAppConstants.STG_ORIGIN)){
			resp = 0;
		}else if (origin.equalsIgnoreCase(MBAppConstants.BSA_ORIGIN)){
			resp = 1;
		}else if (origin.equalsIgnoreCase(MBAppConstants.BOM_ORIGIN)){
			resp = 2;
		}
		
		return resp;
	}


	public int getHisaWorkId(String hisaWorkAcct){
		String prod = hisaWorkAcct;
		int i = prod.lastIndexOf("|");
		
		prod = prod.substring(i+1);
		
		return Integer.parseInt(prod);
	}
	
	public static final String SPRING_OPEN_DDA_SERVICE_BEAN  ="openDDAService";


	private Collection<RegionVO> getRegions() throws BusinessException, ResourceException{
		OpenDDAService service = (OpenDDAService)  ServiceHelper.getBean(SPRING_OPEN_DDA_SERVICE_BEAN);
		return service.getRegion();
	}	

	
	public TermDepositResp getRenewAccountDetail(MobileSession mobileSession, TermDepositAccount tdaAccount, Collection<Account> fundingAccounts ){
		
		TermDepositResp termDepositResp = new TermDepositResp();
		
		if ( tdaAccount != null )
		{
			if ( "Y".equalsIgnoreCase(tdaAccount.getTermCode() ) || "M".equalsIgnoreCase(tdaAccount.getTermCode()) && tdaAccount.getTermInMonth() != 0  )
			{
				termDepositResp.setTermDuration(tdaAccount.getTermInMonth());
			}
			String termNotes = getTermNotes(mobileSession.getOrigin(), tdaAccount);
			
			if ( ! StringMethods.isEmptyString( termNotes ))
				termDepositResp.setTermNotes(termNotes);
			
			
		}
		
		
		termDepositResp.setRenewSubProdCode(tdaAccount.getAccountId().getSubProductCode());
		
		
		if(fundingAccounts != null){
			ArrayList<Account> custAcctList = (ArrayList<Account>)mobileSession.getCustomer().getAccounts();

			int id;
			ArrayList<Integer> idList = new ArrayList<Integer>();
			for (Iterator<Account> iterator = fundingAccounts.iterator(); iterator.hasNext();) {
				Account eachAccount = iterator.next();
				id = getAccountIndex(custAcctList, eachAccount.getAccountId());
				idList.add(id);
			}
			termDepositResp.setDepositInfoIndexes(idList);
		}

		if ( mobileSession.getCustomer().getContactDetail() != null && mobileSession.getCustomer().getContactDetail().getResidentialAddress() != null )
		{
			if ( ! StringMethods.isEmptyString(mobileSession.getCustomer().getContactDetail().getResidentialAddress().getState()))
			{
				String selState = mobileSession.getCustomer().getContactDetail().getResidentialAddress().getState(); 
				termDepositResp.setSelectedState(selState);
			}
			
		}

		
		return termDepositResp;
	}

	private  String getTermNotes(String origin, TermDepositAccount tdaAccount) 
	{
		String message = " ";
		if ( "Y".equalsIgnoreCase(tdaAccount.getRetentionRateInd()) && "M".equalsIgnoreCase(tdaAccount.getTermCode() ))
		{
			String[] values = {String.valueOf(tdaAccount.getTermInMonth())};
			message =getMessageScript(origin, BusinessException.RENEW_TERM_DEPOSIT_TERM_NOTES_1,values);
		}
		else if ( "Y".equalsIgnoreCase(tdaAccount.getRetentionRateInd()) && ! "M".equalsIgnoreCase(tdaAccount.getTermCode() ))
		{
			String[] values = {String.valueOf(tdaAccount.getTermInMonth())};
			message =getMessageScript(origin, BusinessException.RENEW_TERM_DEPOSIT_TERM_NOTES_2, values);
		}
		else if ( "M".equalsIgnoreCase(tdaAccount.getTermCode() ) || "Y".equalsIgnoreCase(tdaAccount.getTermCode() )  )
		{
			String[] values = {String.valueOf(tdaAccount.getTermInMonth())};
			message =getMessageScript(origin, BusinessException.RENEW_TERM_DEPOSIT_TERM_NOTES_3,values);
		}
		return message;
	}
	
	
	public static final String LAST_TRANSACTION_ERROR = "10000000";
	
	public  String getMessageScript(String origin, int msgCode,Object[] values)
	{
		String msgString = IBankParams.getErrorMessage(origin, String.valueOf(msgCode));
		if ( StringMethods.isEmptyString(msgString) )
		{
			 msgString = IBankParams.getErrorMessage(origin, LAST_TRANSACTION_ERROR);
		}
		else if(values!=null && values.length > 0){
			msgString=MessageFormat.format(msgString, values);
		}		
		return msgString;
	}	

	
	 public TermDepositResp popultaeRenewReceipt(TermDepositRenewal renewalObj)
	 {
			TermDepositResp openTDAResp = new TermDepositResp();
			openTDAResp.setMaturityDate( renewalObj.getAccount().getMaturityDate() );
			openTDAResp.setNewTdaBal( String.valueOf( renewalObj.getAccount().getBalanceDisplay()) );

			ReceiptResp receiptResp = new ReceiptResp();
			
			if(renewalObj.getReceiptNumber() != null){
				receiptResp.setReceiptNumDisp(formatReceiptNumber(renewalObj.getReceiptNumber()));			
			}
			
			receiptResp.setDateTime( new Date() );
			openTDAResp.setReceipt(receiptResp);
		 return openTDAResp;
	 }
	 
}

