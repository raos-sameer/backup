package au.com.stgeorge.mbank.controller.customer;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;

import au.com.stgeorge.framework.common.model.User;
import au.com.stgeorge.framework.common.util.StringMethods;
import au.com.stgeorge.ibank.businessobject.BusinessException;
import au.com.stgeorge.ibank.businessobject.IBankSecureService;
import au.com.stgeorge.ibank.valueobject.Address;
import au.com.stgeorge.ibank.valueobject.ContactDetail;
import au.com.stgeorge.ibank.valueobject.Customer;
import au.com.stgeorge.mbank.model.common.AppParams;
import au.com.stgeorge.mbank.model.common.ContactInfoResp;
import au.com.stgeorge.mbank.model.common.CustomerResp;
import au.com.stgeorge.mbank.model.common.IMBResp;
import au.com.stgeorge.mbank.model.common.PhoneInfoResp;
import au.com.stgeorge.mbank.model.common.SecureCodeInfoResp;
import au.com.stgeorge.mbank.model.response.customer.ActivationResp;
import au.com.stgeorge.mbank.util.MBAppUtils;

public class ActivationHelper
{

	public static final String ORIGIN = "origin";
	public static final String BROWSER_NAME = "browserName";
	public static final String SESSION_COOKIE_NAME = "MBAppCookie";

	public static final String SPRING_ORIGIN_RESOLVER_BEAN = "originResolver";

	public IMBResp populateResponse(Customer customer, User user, String origin, String caller, HttpServletRequest request) throws BusinessException
	{
		ActivationResp activationResponse = new ActivationResp();
		CustomerResp mbCustomer = new CustomerResp();
		mbCustomer.setContactInfo(populateContact(customer.getContactDetail()));
		
		if (mbCustomer.getContactInfo().getPhones() == null || mbCustomer.getContactInfo().getPhones().size() == 0) {
			return MBAppUtils.createErrorResp(origin, BusinessException.IBANK_SECURE_NO_PHONE_EXIST, caller, request);
		}
		
		mbCustomer.setSecureCodeInfo(populateSecureCodeInfo(customer));
		activationResponse.setCustomer(mbCustomer);
		
		AppParams appParams = logonHelper.populateAppParams(request, customer);
		activationResponse.setAppParams(appParams);

		return activationResponse;
	}

	private ContactInfoResp populateContact(ContactDetail contactDetail) throws BusinessException
	{
		ContactInfoResp mbContact = new ContactInfoResp();

		ArrayList<au.com.stgeorge.mbank.model.common.AddressResp> addresses = new ArrayList<au.com.stgeorge.mbank.model.common.AddressResp>();
		if (contactDetail.getMailingAddress() != null)
			addresses.add(populateAddress(contactDetail.getMailingAddress(), "MAIL"));

		if (contactDetail.getResidentialAddress() != null)
			addresses.add(populateAddress(contactDetail.getResidentialAddress(), "RES"));

		if (addresses.size() > 0)
		{
			mbContact.setAddresses(addresses);
		}

		
		
		ArrayList<au.com.stgeorge.mbank.model.common.PhoneInfoResp> phones = new ArrayList<au.com.stgeorge.mbank.model.common.PhoneInfoResp>();
		
		PhoneInfoResp phoneInfo = null;
		if ( contactDetail.getMobileNumber() != null && ! StringMethods.isEmptyString(contactDetail.getMobileNumber().getPhoneNumber()) )
		{
			phoneInfo = new PhoneInfoResp();
			phoneInfo.setPhoneType( "MOBILE" );
			phoneInfo.setPhoneNum(LogonHelper.maskPhoneNumber(contactDetail.getMobileNumber().getDisplayPhoneNumber() ));
			phones.add(phoneInfo);
		}

		if ( contactDetail.getHomeNumber() != null && ! StringMethods.isEmptyString(contactDetail.getHomeNumber().getPhoneNumber())  )
		{
			phoneInfo = new PhoneInfoResp();
			phoneInfo.setPhoneType( "HOME" );
			phoneInfo.setPhoneNum( LogonHelper.maskPhoneNumber(contactDetail.getHomeNumber().getDisplayPhoneNumber() ));
			phones.add(phoneInfo);
		}

		if ( contactDetail.getWorkNumber() != null && ! StringMethods.isEmptyString(contactDetail.getWorkNumber().getPhoneNumber()) )
		{
			phoneInfo = new PhoneInfoResp();
			phoneInfo.setPhoneType( "WORK" );
			phoneInfo.setPhoneNum( LogonHelper.maskPhoneNumber(( contactDetail.getWorkNumber().getDisplayPhoneNumber() )));
			phones.add(phoneInfo);
		}
		
		if ( phones.size() > 0 )
		{
			mbContact.setPhones(phones);
//			return mbContact;
		}
		else
		{
			throw new BusinessException( BusinessException.IBANK_SECURE_NO_PHONE_EXIST); 
		}
		
		
		mbContact.setEmailAddress(contactDetail.getEmail() );
		return mbContact;
	}

	private au.com.stgeorge.mbank.model.common.AddressResp populateAddress(Address address, String type)
	{
		au.com.stgeorge.mbank.model.common.AddressResp mbAddress = new au.com.stgeorge.mbank.model.common.AddressResp();
		if (address != null)
		{
			mbAddress.setAddrType(type);
			mbAddress.setCountryName(address.getCountryName());
			mbAddress.setLine1(address.getLine1());
			mbAddress.setLine2(address.getLine3());
			mbAddress.setLine3(address.getLine3());

			mbAddress.setPostCode(address.getPostZipcode());
			mbAddress.setState(address.getState());
			mbAddress.setSuburb(address.getSuburb());
		}
		return mbAddress;

	}

	public IMBResp populateSecureResponse()
	{
		ActivationResp activationResponse = new ActivationResp();
		activationResponse.setSuccess(true);
		return activationResponse;
	}
	
	private SecureCodeInfoResp populateSecureCodeInfo(Customer customer )
	{
		SecureCodeInfoResp secureCodeInfo = null;
		if(customer.getIBankSecureDetails() != null){
			secureCodeInfo = new SecureCodeInfoResp();
			String delPref = customer.getIBankSecureDetails().getDeliveryPref();
			secureCodeInfo.setDeliveryPref(delPref);
			String phonePref = customer.getIBankSecureDetails().getPhonePref();
			secureCodeInfo.setPhonePref(phonePref);
			secureCodeInfo.setExempt(isCustomerSecCodeExempted(customer));
		}
		return secureCodeInfo;
	}
	
	
	private String isCustomerSecCodeExempted(Customer customer)  
	{
		try
		{
			if (  IBankSecureService.isGlobalByPass() ||  IBankSecureService.isCustomerExempt(customer.getIBankSecureDetails()) )
			{
				return "Y"; 
			}
			else
			{
				return "N";
			}
		}
		catch (Exception e)
		{
			return "N";
		}
	}
	
	
	private LogonHelper logonHelper;

	public LogonHelper getLogonHelper()
	{
		return logonHelper;
	}

	public void setLogonHelper(LogonHelper logonHelper)
	{
		this.logonHelper = logonHelper;
	}

}



