package au.com.stgeorge.mbank.controller.newaccount;


import java.util.List;
import javax.xml.bind.annotation.XmlElement; 
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAccessType;

@XmlRootElement(name = "NewAcctStructure")
@XmlAccessorType(XmlAccessType.FIELD)
public class NewAcctStructure {
	
	@XmlElement(name="Category")
    private List<Category> categories;

	public List<Category> getCategories() {
		return categories;
	}

	public void setCategories(List<Category> acctCategories) {
		this.categories = acctCategories;
	}
}
