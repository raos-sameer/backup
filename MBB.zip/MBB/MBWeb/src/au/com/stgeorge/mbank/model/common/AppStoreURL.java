package au.com.stgeorge.mbank.model.common;

public class AppStoreURL {
	
	private String androidUrl;
	private String iosUrl;
	
	public String getAndroidUrl() {
		return androidUrl;
	}
	public void setAndroidUrl(String androidUrl) {
		this.androidUrl = androidUrl;
	}
	public String getIosUrl() {
		return iosUrl;
	}
	public void setIosUrl(String iosUrl) {
		this.iosUrl = iosUrl;
	}
}
