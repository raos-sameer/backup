package au.com.stgeorge.mbank.controller.fixedhomeloan;


import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang.builder.ReflectionToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.ibm.icu.text.DecimalFormat;

import au.com.stgeorge.framework.common.logging.Logger;
import au.com.stgeorge.framework.common.util.StringMethods;
import au.com.stgeorge.ibank.businessobject.BusinessException;
import au.com.stgeorge.ibank.businessobject.FixedHomeLoanService;
import au.com.stgeorge.ibank.businessobject.ResourceException;
import au.com.stgeorge.ibank.businessobject.StatisticsService;
import au.com.stgeorge.ibank.common.cache.IBankParams;
import au.com.stgeorge.ibank.valueobject.Customer;
import au.com.stgeorge.ibank.valueobject.FixedHomeLoanInfo;
import au.com.stgeorge.ibank.valueobject.FixedHomeLoanRateDetails;
import au.com.stgeorge.ibank.valueobject.FixedHomeLoanSelected;
import au.com.stgeorge.ibank.valueobject.Statistic;
import au.com.stgeorge.ibank.valueobject.transfer.IBankCommonData;
import au.com.stgeorge.mbank.controller.IMBController;
import au.com.stgeorge.mbank.model.common.IMBReq;
import au.com.stgeorge.mbank.model.common.IMBResp;
import au.com.stgeorge.mbank.model.common.ReqHeader;
import au.com.stgeorge.mbank.model.common.RespHeader;
import au.com.stgeorge.mbank.model.request.fixedhomeloan.FixedHomeLoanFormReq;
import au.com.stgeorge.mbank.model.request.fixedhomeloan.FixedHomeLoanSaveDetailsReq;
import au.com.stgeorge.mbank.model.response.ErrorResp;
import au.com.stgeorge.mbank.model.response.fixedhomeloan.FixedHomeLoanFormPageResp;
import au.com.stgeorge.mbank.model.response.fixedhomeloan.FixedHomeLoanRateDetailsResp;
import au.com.stgeorge.mbank.model.response.fixedhomeloan.FixedHomeLoanSaveDetailsResp;
import au.com.stgeorge.mbank.session.MobileSession;
import au.com.stgeorge.mbank.util.MBAppHelper;
import au.com.stgeorge.mbank.util.MBAppUtils;
import au.com.stgeorge.mbank.util.MBAppValidator;
import au.com.stgeorge.mbank.util.ServiceConstants;
import au.com.stgeorge.perflogger.PerformanceLogger;


@Controller
@RequestMapping("/fixedhomeloan")
public class FixedHomeLoanController  implements IMBController {

	@Autowired
	private MBAppHelper mbAppHelper;

	@Autowired
	private MBAppValidator mbAppValidator;
	
	@Autowired
	private PerformanceLogger perfLogger;
	
	@Autowired
	private FixedHomeLoanService fixedHomeLoanService;
	
	private String startPerformanceLog(HttpServletRequest httpRequest){
		perfLogger.startAllLogs();
		String logName = MBAppUtils.getLogName(httpRequest);
		perfLogger.startLog(logName);
		return logName;
	}
	
	private void endPerformanceLog(String logName){
		perfLogger.endLog(logName);
		perfLogger.endAllLogs();
	}
	
	public ErrorResp validate(IMBReq serviceRequest, HttpServletRequest request) {
		if(Logger.isDebugEnabled(this.getClass())){
			Logger.debug("Service request object - " + ReflectionToStringBuilder.toString(serviceRequest), this.getClass());
		}
		return mbAppValidator.validate(serviceRequest, request);
	}

	public void validateRequestHeader(ReqHeader headerReq, HttpServletRequest request) throws BusinessException {
		if(Logger.isDebugEnabled(this.getClass())){
			Logger.debug("Request header validation: " + ReflectionToStringBuilder.toString(headerReq, ToStringStyle.MULTI_LINE_STYLE), this.getClass());
		}
		mbAppValidator.validateRequestHeader(headerReq, request);
	}
	
	public RespHeader populateResponseHeader(String serviceName, MobileSession mobSession) {
		return mbAppHelper.populateResponseHeader(serviceName, mobSession);
	}
	
	@RequestMapping(method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE, value = "homeLoanForm")
	@ResponseBody
	public IMBResp getHomeLoanFormPageDetails(HttpServletRequest httpRequest, @RequestBody final FixedHomeLoanFormReq request) {
		Logger.debug("FixedHomeLoanController - getHomeLoanFormPageDetails. Request: " + request, this.getClass());
		String logName = startPerformanceLog(httpRequest);
		MobileSession mbSession = null;
		FixedHomeLoanFormPageResp resp = null;
		
		try {
			mbSession = mbAppHelper.getMobileSession(httpRequest);
			validateRequestHeader(request.getHeader(), httpRequest);
			ErrorResp errorResponse = validate(request, httpRequest);
			if (errorResponse.hasErrors())
			{
				return errorResponse;
			}
			
			IBankCommonData commonData = mbAppHelper.populateIBankCommonData(mbSession, httpRequest);
			
			boolean homeLoanDigiSwitch = IBankParams.isHomeLoanDigiSwitchON();
			Logger.debug("homeLoanDigiSwitch is : "+homeLoanDigiSwitch, this.getClass());
			if(!homeLoanDigiSwitch){
				throw new BusinessException(BusinessException.SYSTEM_UNAVILABLE);
			}
			// Call service when complete. For now call populateDummy for testing.
			Logger.debug("Home loan accountIndex is : "+request.getAccountIndex(), this.getClass());
			FixedHomeLoanInfo loanDetails = fixedHomeLoanService.fetchFixedHomeLoanScreenOfferDetails(commonData, request.getAccountIndex());
			mbSession.setFixedHomeLoanInfo(loanDetails);// storing the data in session to be used in further pages.
			loanDetails.setSource(request.getBannerClickedFrom());
			
			
			recordGDWONBannerClick(commonData,loanDetails);
			if(loanDetails != null){
				resp = populateFormPageResponse(populateResponseHeader(ServiceConstants.FIXED_HOME_LOAN_FORM_SERVICE, mbSession ), loanDetails);
			}else{
				throw new BusinessException(88000011);
			}
			
			return resp;
		} catch (BusinessException e) {
			Logger.info("BusinessException in FixedHomeLoanController - getHomeLoanFormPageDetails() - [key: " + e.getKey() + "] : GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());
			return MBAppUtils.createErrorResp(mbSession.getOrigin(), e, ServiceConstants.FIXED_HOME_LOAN_FORM_SERVICE, httpRequest);
		} catch (ResourceException e) {
			Logger.error("ResourceException in FixedHomeLoanController - getHomeLoanFormPageDetails() - [key: " + e.getKey() + "] : GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());
			return MBAppUtils.createErrorResp(mbSession.getOrigin(), BusinessException.SYSTEM_UNAVILABLE, ServiceConstants.FIXED_HOME_LOAN_FORM_SERVICE, httpRequest);
		} catch (Exception e) {
			Logger.error("Exception FixedHomeLoanController - getHomeLoanFormPageDetails(): GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			return MBAppUtils.createErrorResp(mbSession.getOrigin(), ResourceException.MOBILE_NON_FINANCIAL_FATAL_ERR, ServiceConstants.FIXED_HOME_LOAN_FORM_SERVICE, httpRequest);
		} finally {
			endPerformanceLog(logName);
		}
	}
	
	private FixedHomeLoanFormPageResp populateFormPageResponse(RespHeader header, FixedHomeLoanInfo loanDetails) {
		FixedHomeLoanFormPageResp response = new FixedHomeLoanFormPageResp(header);
		FixedHomeLoanRateDetailsResp rateResp = null;
		ArrayList<FixedHomeLoanRateDetailsResp> refixHomeLoanRates = new ArrayList<FixedHomeLoanRateDetailsResp>();
		
		response.setMaturityDate(loanDetails.getMaturityDate());
		response.setAccountName(loanDetails.getAccountName());
		response.setFormattedAccountNumber(loanDetails.getFormattedAccountNumber());
		response.setLoanCategory(loanDetails.getLoanCategory());
		response.setRepaymentType(loanDetails.getRepaymentType());
		response.setNewRepaymentType(loanDetails.getNewRepaymentType());// If "P" then only show <Your repayment type will also change to Principal & Interest.>
		response.setStartDate(loanDetails.getStartDate());
		response.setPackageStatus(loanDetails.getPackageStatus());
		response.setNewRepaymentTypeText(loanDetails.getNewRepaymentTypeString());
		
		for(FixedHomeLoanRateDetails rateDetails : loanDetails.getFixedHomeLoanRateDetails()){
			rateResp = new FixedHomeLoanRateDetailsResp();
			rateResp.setStandardRate(rateDetails.getStandardRate()); //(only populated for Fixed rate)
			rateResp.setComparisonRate(rateDetails.getComparisonRate());//(only populated for Fixed rate)
			rateResp.setDiscountRate(rateDetails.getDiscountRate());// Used in "Includes Advantage Package discount of 0.15% p.a." if PackageStatus = Y
			rateResp.setLoanTerm(rateDetails.getIndex()); 
			rateResp.setVariableRateField(rateDetails.isVariableRateField());// Tells that the rate is variable or Fixed
			rateResp.setVariableInterestRate(rateDetails.getVariableInterestRate()); // Variable XX.XX rate (only populated for variable rate)
			rateResp.setVariableDiscountRate(rateDetails.getVariableDiscountRate());// Variable YY.YY rate (only populated for variable rate)
			rateResp.setHavingSpecialOfferDiscount(rateDetails.isHavingSpecialOfferDiscount());// To show Special Offer i.e. "Special Offer: Includes Advantage Package discount of 0.15% p.a."
			refixHomeLoanRates.add(rateResp);
		}
		
		response.setRefixHomeLoanRates(refixHomeLoanRates);
		return response;
	}
	
	@RequestMapping(method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE, value = "saveHomeLoanDetails")
	@ResponseBody
	public IMBResp saveHomeLoanFormPageDetails(HttpServletRequest httpRequest, @RequestBody final FixedHomeLoanSaveDetailsReq request) {
		Logger.debug("FixedHomeLoanController - saveHomeLoanFormPageDetails. Request: " + request, this.getClass());
		String logName = startPerformanceLog(httpRequest);
		MobileSession mbSession = null;
		FixedHomeLoanSaveDetailsResp resp = null;
		FixedHomeLoanInfo loanDetails=null;
		FixedHomeLoanSelected termSelected=null;

		try {
			mbSession = mbAppHelper.getMobileSession(httpRequest);
			validateRequestHeader(request.getHeader(), httpRequest);
			ErrorResp errorResponse = validate(request, httpRequest);
			if (errorResponse.hasErrors())
			{
				return errorResponse;
			}
			
			IBankCommonData commonData = mbAppHelper.populateIBankCommonData(mbSession, httpRequest);
			
			boolean homeLoanDigiSwitch = IBankParams.isHomeLoanDigiSwitchON();
			Logger.debug("homeLoanDigiSwitch is : "+homeLoanDigiSwitch, this.getClass());
			if(!homeLoanDigiSwitch){
				throw new BusinessException(BusinessException.SYSTEM_UNAVILABLE);
			}
			loanDetails=mbSession.getFixedHomeLoanInfo();
			loanDetails.setSelectedTerm(String.valueOf(request.getSelectedLoanTerm()));
			
			//Save data
			termSelected = populateFixedHomeLoanSelected(commonData.getCustomer(), loanDetails); 
			fixedHomeLoanService.updateFixedHomeLoanDetails(termSelected);
			
			//Sending email(only for fixed interest selected we send mails)
			if(!termSelected.isVariableRateField()){
				fixedHomeLoanService.emailHomeLoanDetails(commonData, termSelected);
			}
			
			//GDW logging (future sprint)
			
			loanDetails.setSource(request.getBannerClickedFrom());
			
			
			recordGDWONSubmit(commonData,loanDetails,termSelected);
			//Response
			resp = populateSaveHomeLoanDetailsResponse(populateResponseHeader(ServiceConstants.FIXED_HOME_LOAN_SAVE_DETAILS_SERVICE, mbSession ), loanDetails);
			
			return resp;
		} catch (BusinessException e) {
			Logger.info("BusinessException in FixedHomeLoanController - saveHomeLoanFormPageDetails() - [key: " + e.getKey() + "] : GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());
			return MBAppUtils.createErrorResp(mbSession.getOrigin(), e, ServiceConstants.FIXED_HOME_LOAN_SAVE_DETAILS_SERVICE, httpRequest);
		} catch (ResourceException e) {
			Logger.error("ResourceException in FixedHomeLoanController - saveHomeLoanFormPageDetails() - [key: " + e.getKey() + "] : GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());
			return MBAppUtils.createErrorResp(mbSession.getOrigin(), BusinessException.SYSTEM_UNAVILABLE, ServiceConstants.FIXED_HOME_LOAN_SAVE_DETAILS_SERVICE, httpRequest);
		} catch (Exception e) {
			Logger.error("Exception FixedHomeLoanController - saveHomeLoanFormPageDetails(): GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			return MBAppUtils.createErrorResp(mbSession.getOrigin(), ResourceException.MOBILE_NON_FINANCIAL_FATAL_ERR, ServiceConstants.FIXED_HOME_LOAN_SAVE_DETAILS_SERVICE, httpRequest);
		} finally {
			endPerformanceLog(logName);
		}
	}
	
	private FixedHomeLoanSelected populateFixedHomeLoanSelected(Customer cust, FixedHomeLoanInfo loanDetails) throws BusinessException {
		FixedHomeLoanSelected selectedTerm = new FixedHomeLoanSelected();
		FixedHomeLoanRateDetails selectedRateDetails = null;
		
		long selTerm = Long.parseLong(loanDetails.getSelectedTerm());
		for(FixedHomeLoanRateDetails rateDetails : loanDetails.getFixedHomeLoanRateDetails()){
			if(rateDetails.getIndex() == selTerm){
				selectedRateDetails = rateDetails;
				break;
			}
		}
		if(selectedRateDetails == null){
			Logger.info("Unable to select any rate from the session in populateFixedHomeLoanSelected()",this.getClass());
			throw new BusinessException(88000011);
		}
		selectedTerm.setHomeLoanOfferID(loanDetails.getHomeLoanOfferID());
		selectedTerm.setRateCodeSelected(selectedRateDetails.getRateCode());
		selectedTerm.setNewFixedRateTerm(selTerm);
		selectedTerm.setNewNetFixedRate(new BigDecimal(selectedRateDetails.getStandardRate()));
		if(selectedRateDetails.getDiscountRate() != null && !StringMethods.isEmptyString(selectedRateDetails.getDiscountRate())){
			try{
				selectedTerm.setNewTotalDiscount(new BigDecimal(selectedRateDetails.getDiscountRate()));
			}catch(Exception err){
				Logger.debug("Invalid non numeric Discount Rate "+selectedRateDetails.getDiscountRate(),this.getClass());
				selectedTerm.setNewTotalDiscount(null);
			}
		}
		selectedTerm.setGcis(cust.getGcis());
		selectedTerm.setAccountNumber(loanDetails.getAccountNumber());
		selectedTerm.setCustomerName(cust.getFullName());
		selectedTerm.setFirstAccepter("Y");
		selectedTerm.setLoanCategory(loanDetails.getLoanCategory());
		selectedTerm.setRepaymentType(loanDetails.getRepaymentType());
		selectedTerm.setNewRepaymentTypeText(loanDetails.getNewRepaymentTypeString());
		selectedTerm.setRequestedDate(new Date());
		selectedTerm.setMaturityDate(loanDetails.getMaturityDate());
		selectedTerm.setPackageStatus(loanDetails.getPackageStatus());
		selectedTerm.setBrand(loanDetails.getBrand());
		selectedTerm.setOfferOrigin(loanDetails.getOfferOrigin());
		selectedTerm.setVariableRateField(selectedRateDetails.isVariableRateField());
		
		
		
		if(selectedRateDetails.isVariableRateField()){
			selectedTerm.setVariableRate(selectedRateDetails.getVariableInterestRate());
			selectedTerm.setVariableDiscountRate(selectedRateDetails.getVariableDiscountRate());
		}
		selectedTerm.setHavingSpecialOfferDiscount(selectedRateDetails.isHavingSpecialOfferDiscount());
		
		return selectedTerm;
	}
	
	private FixedHomeLoanSaveDetailsResp populateSaveHomeLoanDetailsResponse(RespHeader header, FixedHomeLoanInfo loanDetails) {
		FixedHomeLoanSaveDetailsResp response = new FixedHomeLoanSaveDetailsResp(header);
		response.setPhoneNumber(IBankParams.getHomeLoanDigiPhoneNumber(loanDetails.getOfferOrigin()));
		response.setSuccess(true);
		return response;
	}
	
	private void recordGDWONSubmit(IBankCommonData commonData,	FixedHomeLoanInfo info, FixedHomeLoanSelected fixedSelectedTerm){

		try {
			Statistic statistic = new Statistic();

			statistic.setGcisNumber(commonData.getCustomer().getGcis());
			statistic.setOriginBank(commonData.getOrigin());
			statistic.setGDWOriginBank(commonData.getGdwOrigin());
			statistic.setAccountNumberFrom(fixedSelectedTerm.getAccountNumber());

			if (info.getSource() != null && "ACDT".equalsIgnoreCase(info.getSource())){
				statistic.setAction(Statistic.ACCOUNT_DETAILS_SUBMIT);
			}else{
				statistic.setAction(Statistic.DASHBOARD_SUBMIT);
			}
			statistic.setDescription(getDecription(fixedSelectedTerm,info));
			statistic.setSessionId(commonData.getSessionId());
			statistic.setIpAddress(commonData.getIpAddress());
			StatisticsService.logStatistic(statistic);

		} catch (Throwable t) {
			// Don't care if we successfully recorded in GDW or not
		}


	}

	private void recordGDWONBannerClick(IBankCommonData commonData, FixedHomeLoanInfo info) {

		try {
			Statistic statistic = new Statistic();

			statistic.setGcisNumber(commonData.getCustomer().getGcis());
			statistic.setOriginBank(commonData.getOrigin());
			statistic.setGDWOriginBank(commonData.getGdwOrigin());
			statistic.setAccountNumberFrom(info.getAccountNumber());

			if (info.getSource() != null && "ACDT".equalsIgnoreCase(info.getSource())){
				statistic.setAction(Statistic.ACCOUNT_DETAILS);
			}else{
				statistic.setAction(Statistic.DASHBOARD_BANNER);
			}
			statistic.setSessionId(commonData.getSessionId());
			statistic.setIpAddress(commonData.getIpAddress());
			StatisticsService.logStatistic(statistic);

		} catch (Throwable t) {
			// Don't care if we successfully recorded in GDW or not
		}
	}


	private String getDecription(FixedHomeLoanSelected fixedHomeLoanSelectedTermModel,FixedHomeLoanInfo loanDetails){

		//FixedHomeLoanRateDetails detail= fixedHomeLoanSelectedTermModel.getFixedHomeLoanRateDetail();

		StringBuilder description= new StringBuilder();

		if(fixedHomeLoanSelectedTermModel.isVariableRateField()){
			description .append( "Type:Variable," );
		}else{
			description.append( "Type:Fixed,") ;	
		}
		
		DecimalFormat format = new DecimalFormat("0.00");
		if(!fixedHomeLoanSelectedTermModel.isVariableRateField()){
			
			if(fixedHomeLoanSelectedTermModel.getNewFixedRateTerm().equals(1)){
				description.append("Term:" +  fixedHomeLoanSelectedTermModel.getNewFixedRateTerm()+ " year" + ",");
			}else{description.append("Term:" +  fixedHomeLoanSelectedTermModel.getNewFixedRateTerm()+ " years" +",");}
			
		}
		//description.append( "rate:" + format.format(fixedHomeLoanSelectedTermModel.getNewNetFixedRate())+",");
		description.append( "rate:" + (fixedHomeLoanSelectedTermModel.isVariableRateField() ? fixedHomeLoanSelectedTermModel.getVariableRate():format.format(fixedHomeLoanSelectedTermModel.getNewNetFixedRate()))+",");
		
		
		if(fixedHomeLoanSelectedTermModel.isHavingSpecialOfferDiscount()){
			description.append("Special,");
			description.append("discount:" + (fixedHomeLoanSelectedTermModel.isVariableRateField() ? fixedHomeLoanSelectedTermModel.getVariableDiscountRate() : fixedHomeLoanSelectedTermModel.getNewTotalDiscount()) +",");
		
		}
		else{
			if("Y".equals(fixedHomeLoanSelectedTermModel.getPackageStatus())){
				description.append("Advantage,");
				description.append("discount:" + (fixedHomeLoanSelectedTermModel.isVariableRateField() ? fixedHomeLoanSelectedTermModel.getVariableDiscountRate() : fixedHomeLoanSelectedTermModel.getNewTotalDiscount()) +",");
			}else{
				description.append("Standard,");
				description.append("discount: 0,");
			}
		}
		
		if("Principal & Interest".equalsIgnoreCase(loanDetails.getNewRepaymentTypeString())){
			description.append("Repayment type :P");
		}
		else if("Interest Only".equalsIgnoreCase(loanDetails.getNewRepaymentTypeString())){
			description.append("Repayment type :I");
		}
	
		return description.toString();
	}

	

	
	
}
