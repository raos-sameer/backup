package au.com.stgeorge.mbank.model.request.customer;

import java.io.Serializable;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

import au.com.stgeorge.ibank.businessobject.BusinessException;
import au.com.stgeorge.mbank.model.common.IMBReq;
import au.com.stgeorge.mbank.model.common.ProductReq;
import au.com.stgeorge.mbank.model.common.ReqHeader;
import au.com.stgeorge.mbank.model.request.payments.TransferScheduleReq;

public class ConfirmSavingsOnboardingReq implements IMBReq, Serializable {	
	private static final long serialVersionUID = 109161834038068283L;
	
	protected static final String BLOCK_CHARS_PATTERN = "^[0-9A-Za-z',. &/\\-]*$";
	protected static final String AMT_PATTERN = "^[0-9]*\\.{0,1}(\\d{1,2}){0,1}$";
	
	private ReqHeader header;    
	private ProductReq product;
	private TransferScheduleReq scheduleDetail;
	private Boolean overrideDuplicate;
	private String source;
	private Boolean sendEmail;
	private Boolean existingFlow;
			
	@Pattern(regexp = BLOCK_CHARS_PATTERN, message = "{errors.branchId.blockchar}")
	private String branchId;
	
	@NotNull(message = "" + BusinessException.ACCOUNT_NO_FROM_ACCOUNT)
	private Integer fromAccountIndex;
	
	private Integer toAccountIndex;
	
	private String amt; 
	
	public ReqHeader getHeader() {
		return header;
	}

	public void setHeader(ReqHeader header) {
		this.header = header;
	}

	public ProductReq getProduct() {
		return product;
	}

	public void setProduct(ProductReq product) {
		this.product = product;
	}

	public Boolean getOverrideDuplicate() {
		return overrideDuplicate;
	}

	public void setOverrideDuplicate(Boolean overrideDuplicate) {
		this.overrideDuplicate = overrideDuplicate;
	}

	public String getBranchId() {
		return branchId;
	}

	public void setBranchId(String branchId) {
		this.branchId = branchId;
	}

	public Integer getFromAccountIndex() {
		return fromAccountIndex;
	}

	public void setFromAccountIndex(Integer fromAccountIndex) {
		this.fromAccountIndex = fromAccountIndex;
	}

	public Integer getToAccountIndex() {
		return toAccountIndex;
	}

	public void setToAccountIndex(Integer toAccountIndex) {
		this.toAccountIndex = toAccountIndex;
	}

	public String getAmt() {
		return amt;
	}

	public void setAmt(String amt) {
		this.amt = amt;
	}

	public TransferScheduleReq getScheduleDetail() {
		return scheduleDetail;
	}

	public void setScheduleDetail(TransferScheduleReq scheduleDetail) {
		this.scheduleDetail = scheduleDetail;
	}

	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}

	public Boolean getSendEmail() {
		return sendEmail;
	}

	public void setSendEmail(Boolean sendEmail) {
		this.sendEmail = sendEmail;
	}

	public Boolean getExistingFlow() {
		return existingFlow;
	}

	public void setExistingFlow(Boolean existingFlow) {
		this.existingFlow = existingFlow;
	}	
}
