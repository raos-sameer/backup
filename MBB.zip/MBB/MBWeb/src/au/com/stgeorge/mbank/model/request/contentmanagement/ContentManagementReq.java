package au.com.stgeorge.mbank.model.request.contentmanagement;

import au.com.stgeorge.mbank.model.common.IMBReq;
import au.com.stgeorge.mbank.model.common.ReqHeader;

public class ContentManagementReq implements IMBReq{

	/**
	 * 
	 */
	private static final long serialVersionUID = 5100057632968791540L;
	private ReqHeader header;
	private String productName;
	
	public ReqHeader getHeader() {
		return header;
	}

	public void setHeader(ReqHeader header) {
		this.header = header;
		
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}
	
	

}
