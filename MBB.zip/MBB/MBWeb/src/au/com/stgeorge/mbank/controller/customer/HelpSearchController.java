package au.com.stgeorge.mbank.controller.customer;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.builder.ReflectionToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.w3c.dom.Document;
import org.xml.sax.SAXException;

import com.fasterxml.jackson.databind.ObjectMapper;

import au.com.stgeorge.framework.common.logging.Logger;
import au.com.stgeorge.framework.common.util.StringMethods;
import au.com.stgeorge.ibank.businessobject.AccountFilter;
import au.com.stgeorge.ibank.businessobject.BusinessException;
import au.com.stgeorge.ibank.businessobject.GCCService;
import au.com.stgeorge.ibank.businessobject.ResourceException;
import au.com.stgeorge.ibank.businessobject.assembler.CustomerVOAssembler;
import au.com.stgeorge.ibank.businessobject.globalWallet.GlobalWalletService;
import au.com.stgeorge.ibank.common.cache.IBankParams;
import au.com.stgeorge.ibank.common.cache.IBankRefershParams;
import au.com.stgeorge.ibank.util.ServiceHelper;
import au.com.stgeorge.ibank.util.StringUtil;
import au.com.stgeorge.ibank.valueobject.Account;
import au.com.stgeorge.ibank.valueobject.AccountId;
import au.com.stgeorge.ibank.valueobject.Customer;
import au.com.stgeorge.ibank.valueobject.CustomerTypes;
import au.com.stgeorge.ibank.valueobject.Statistic;
import au.com.stgeorge.ibank.valueobject.database.CodesVO;
import au.com.stgeorge.ibank.valueobject.transfer.IBankCommonData;
import au.com.stgeorge.mbank.controller.IMBController;
import au.com.stgeorge.mbank.model.common.IMBReq;
import au.com.stgeorge.mbank.model.common.IMBResp;
import au.com.stgeorge.mbank.model.common.ReqHeader;
import au.com.stgeorge.mbank.model.common.RespHeader;
import au.com.stgeorge.mbank.model.request.EmptyReq;
import au.com.stgeorge.mbank.model.request.customer.HelpSearchStatReq;
import au.com.stgeorge.mbank.model.response.ErrorResp;
import au.com.stgeorge.mbank.model.response.SuccessResp;
import au.com.stgeorge.mbank.model.response.customer.HelpActionResp;
import au.com.stgeorge.mbank.model.response.customer.HelpSearchKeyMapResp;
import au.com.stgeorge.mbank.model.response.customer.HelpSearchResp;
import au.com.stgeorge.mbank.session.MobileSession;
import au.com.stgeorge.mbank.session.MobileSessionImpl;
import au.com.stgeorge.mbank.util.HelpPageVO;
import au.com.stgeorge.mbank.util.HelpPagesVO;
import au.com.stgeorge.mbank.util.MBAppHelper;
import au.com.stgeorge.mbank.util.MBAppUtils;
import au.com.stgeorge.mbank.util.MBAppValidator;
import au.com.stgeorge.mbank.util.ServiceConstants;
import au.com.stgeorge.perflogger.PerformanceLogger;

@Controller
@RequestMapping("/help")
public class HelpSearchController implements IMBController {

	private static final String FAILED_SEARCH = "Failed Search";
	private static final String SUGGESTED_SEARCH = "Suggested Search";
	private static final String DELIMITER = "|";
	public static final String APP_VER_COOKIE = "AppVersion";
	public static final String TABLET_ORGIN_PREFIX = "T";
	public static final String MOGO_APP_VERSION_COOKIE = "MOGO";
	public static final String MADISON_PILOT = "MadisonPilot";
	public static final String MADISON_IN_APP_PROV_PILOT = "MadisonInAppProvPilot";
	
	//19E3 - Add the Switch ProductContentSwitch Start - Remove below code for the ProductContentSwitch cleanup
	public static final String PRODUCT_LIST = "PRODUCT_LIST";
	
	static final Set<String> helpSearchProducts = new HashSet<String>(
		       Arrays.asList("Open_account"));
	//19E3 - Add the Switch ProductContentSwitch End
	
	//21E1 - Add the Switch UpdateContactDetails Start - Remove below code for the UpdateContactSwitch cleanup
	public static final String UPDATE_CONTACT_DETAILS_VALIDATION = "CONTACT_DETAILS_VALIDATION";
	
	static final Set<String> helpSearchUpdateContactValidation = new HashSet<String>(
		       Arrays.asList("Update_my_contact_details"));
	//19E3 - Add the Switch ProductContentSwitch End

	@Autowired
	private MBAppHelper mbAppHelper;
	
	@Autowired
	private MBAppValidator mbAppValidator;
	
	@Autowired
	private IBankRefershParams ibankRefreshParams;
	
  private List<HelpPageVO> helpPageList;
	
	private static List<HelpPageVO> staticHelpPageList;
	private static HelpPagesVO staticHelpPages;
	
	public List<HelpPageVO> getHelpPageList()
	{
		return helpPageList;
	}
	
	public void setHelpPageList(List<HelpPageVO> helpPageList)
	{
		this.helpPageList = helpPageList;
	}
	
	private Unmarshaller unmarshaller;	
	
	@Autowired
	private GlobalWalletService globalWalletService;
	
	/**
	 * Account to account service operation
	 * 
	 * @param httpRequest
	 * @param request
	 * @return
	 */
	@RequestMapping(method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE, value = "search")
	@ResponseBody
	public IMBResp helpSearch(HttpServletRequest httpRequest, @RequestBody final EmptyReq request) {
		Logger.debug("HelpSearchController - helpSearch(). Request: " + request, this.getClass());
		String logName = startPerformanceLog(httpRequest);
		MobileSession mobileSession = new MobileSessionImpl();

		try {
			mobileSession.getSessionContext(httpRequest);
			Customer customer = mobileSession.getCustomer();
			IBankCommonData commonData = new MBAppHelper().populateIBankCommonData(mobileSession, httpRequest);

			validateRequestHeader(request.getHeader(), httpRequest);
			ErrorResp errorResponse = validate(request, httpRequest);
			if (errorResponse.hasErrors())
				return errorResponse;
	  		Cookie cookie = getCookie(httpRequest, APP_VER_COOKIE);
			IMBResp serviceResponse = getJSONResponse(cookie, commonData, customer, mobileSession);
			
			RespHeader headerResp = populateResponseHeader(ServiceConstants.HELP_SEARCH_RESPONSE, mobileSession);
			serviceResponse.setHeader(headerResp);
			
			ObjectMapper mapper = new ObjectMapper();

			Logger.info("Simplified HelpSearch JSON Response :" + mapper.writeValueAsString(serviceResponse), this.getClass());

			return serviceResponse;


		} catch (BusinessException e) {
			Logger.info("BusinessException in HelpSearchController - helpSearch() - [key: " + e.getKey() + "], GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), e, ServiceConstants.ACCOUNT_TRANSFER_SERVICE, httpRequest);
		} catch (Exception e) {
			Logger.error("Exception in HelpSearchController - helpSearch(): ", e, this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.GENERIC_ERROR, ServiceConstants.ACCOUNT_TRANSFER_SERVICE, httpRequest);
		} finally {
			endPerformanceLog(logName);
		}
	}

	
	/**
	 * HelpSearch Gdw entry for success and failed search scenarios
	 * 
	 * @param httpRequest
	 * @param request
	 * @return
	 */
	@RequestMapping(method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE, value = "stat")
	@ResponseBody
	public IMBResp helpSearchStat(HttpServletRequest httpRequest, @RequestBody final HelpSearchStatReq request) {
		Logger.debug("HelpSearchController - helpSearchStat(). Request: " + request, this.getClass());
		String logName = startPerformanceLog(httpRequest);
		MobileSession mobileSession = new MobileSessionImpl();

		try {
			mobileSession.getSessionContext(httpRequest);
			IBankCommonData commonData = new MBAppHelper().populateIBankCommonData(mobileSession, httpRequest);

			validateRequestHeader(request.getHeader(), httpRequest);
			ErrorResp errorResponse = validateAsync(request, httpRequest);
			if (errorResponse.hasErrors()) {
				return errorResponse;
			}
			
			String desc = getStatisticsLogDesc(httpRequest, request);
			String action = request.getId() == 0 ? Statistic.HELP_SEARCH_FAIL : Statistic.HELP_SEARCH;

			Customer customer = commonData.getCustomer();
			
			  if (!StringMethods.isEmptyString(request.getStatisticsType()))
			  {
			    String statisticsType = request.getStatisticsType();
			    if (StringUtil.isValidAlphaNumeric(statisticsType))
			    {
			      if (statisticsType.equalsIgnoreCase(GlobalWalletService.GLOBAL_WALLET_DISPUTE_TXN_STAT_TYPE))
			      {
			        action = Statistic.GLOBAL_WALLET_DISPUTE_TXN_BUTTON_CLICK;
			        desc = GlobalWalletService.GLOBAL_WALLET_DISPUTE_TXN_BUTTON_CLICK_GDW_DESC;
			      }
			    }
			    else
			    {
			      Logger.error("statisticsType is not a ValidAlphaNumeric or null in helpSearchStat : statisticsType - " + statisticsType, getClass());
			      throw new BusinessException(BusinessException.SYSTEM_UNAVILABLE);
			    }
			    String indexStr = request.getAcctIndex();
			    AccountId accountId = null;
			    if (!StringMethods.isEmptyString(indexStr))
			    {
			      int index = Integer.parseInt(indexStr);
			      if ((customer.getAccounts() != null) && (customer.getAccounts().size() > 0) && (customer.getAccounts().get(index) != null) && (((Account)customer.getAccounts().get(index)).getAccountId() != null)) {
			        accountId = ((Account)customer.getAccounts().get(index)).getAccountId();
			      }
			    }
			    globalWalletService.createStatistics(commonData, accountId, action, desc);
			  }
			  else
			  {
			
			mbAppHelper.makeStatisticsLog(commonData, desc, action);
		      }
			RespHeader headerResp = mbAppHelper.populateAsyncResponseHeader(ServiceConstants.HELP_SEARCH_STAT_RESPONSE, mobileSession);
			SuccessResp successResp = new SuccessResp();
			successResp.setHeader(headerResp);
			successResp.setIsSuccess(true);
			
			ObjectMapper mapper = new ObjectMapper();

			Logger.info("helpSearchGdw JSON Response :" + mapper.writeValueAsString(successResp), this.getClass());

			return successResp;

		} catch (BusinessException e) {
			Logger.info("BusinessException in HelpSearchController - helpSearchStat() - [key: " + e.getKey() + "], GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());
			return MBAppUtils.createErrorRespAsync(mobileSession.getOrigin(), e, ServiceConstants.ACCOUNT_TRANSFER_SERVICE, httpRequest);
		} catch (Exception e) {
			Logger.error("Exception HelpSearchController - helpSearchStat(): ", e, this.getClass());
			return MBAppUtils.createErrorRespAsync(mobileSession.getOrigin(), new BusinessException(BusinessException.GENERIC_ERROR), ServiceConstants.ACCOUNT_TRANSFER_SERVICE, httpRequest);
		} finally {
			endPerformanceLog(logName);
		}
	}

	private String getStatisticsLogDesc(HttpServletRequest httpRequest,
			final HelpSearchStatReq request) {
		StringBuffer descBuffer = new StringBuffer();
		
		if(request.getId() == 0){
			descBuffer.append(FAILED_SEARCH);
		} else {
			descBuffer.append(request.getHelpName());
		}
		descBuffer.append(DELIMITER);
		
		if(! StringUtils.isEmpty(request.getSearchText())) {
			descBuffer.append(request.getSearchText());
		} else {
			descBuffer.append(SUGGESTED_SEARCH);
		}
		descBuffer.append(DELIMITER);

		if(! StringUtils.isEmpty(httpRequest.getHeader("User-Agent"))) {
			descBuffer.append(httpRequest.getHeader("User-Agent"));
		}
		
		String desc =  descBuffer.toString();
		
		if(desc.length() > 255){
			desc = desc.substring(0, 255);
		}
		
		return desc;
	}

	public ErrorResp validate(IMBReq serviceRequest, HttpServletRequest request) {
		Logger.info("Service request object - " + ReflectionToStringBuilder.toString(serviceRequest), this.getClass());
		return mbAppValidator.validate(serviceRequest, request);
	}

	public RespHeader populateResponseHeader(String serviceName, MobileSession mobSession) {
		return mbAppHelper.populateResponseHeader(serviceName, mobSession);
	}
	
	public void validateRequestHeader(ReqHeader headerReq, HttpServletRequest request) throws BusinessException {
		Logger.debug("Request header validation: " + ReflectionToStringBuilder.toString(headerReq, ToStringStyle.MULTI_LINE_STYLE), this.getClass());
		new MBAppValidator().validateRequestHeader(headerReq, request);
	}

	
	
	@Autowired
	private PerformanceLogger perfLogger;
	
	private String startPerformanceLog(HttpServletRequest httpRequest){
		perfLogger.startAllLogs();
		String logName = MBAppUtils.getLogName(httpRequest);
		perfLogger.startLog(logName);
		return logName;
	}
	
	private void endPerformanceLog(String logName){
		perfLogger.endLog(logName);
		perfLogger.endAllLogs();
	}

	public HelpSearchResp getJSONResponse(Cookie cookie, IBankCommonData commonData, Customer customer,MobileSession mobileSession)
	{
		try
		{
			JAXBContext jc;
			try {
				jc = JAXBContext.newInstance(HelpPagesVO.class);
				unmarshaller = jc.createUnmarshaller();
			}
			catch (JAXBException e) {
				Logger.error("JAXBException in getJSONResponse HelpSearchController ", e, this.getClass());
			}
			
			readHelpConfigFile();
			
			String custType = "GHS";
      if (customer.getCustomerTypes().contains("GHS")){
      	custType = "GHS";
      }
      else if(customer.getCustomerTypes().contains("CHS")){
      	custType = "CHS";
      }
      else if (customer.getCustomerTypes().contains("CHSGHS")){
      	custType = "CHSGHS";
      }
			filterForBrand(cookie,commonData, custType, customer.getCustTypeInd(), customer,mobileSession);
			
			HelpSearchResp helpSearchResp = new HelpSearchResp();
			ArrayList<HelpActionResp> actionList = new  ArrayList<HelpActionResp> ();
			HashMap<String,ArrayList<Long>> haskKeyMap = new HashMap<String,ArrayList<Long>>();
			
			HashMap<Long,Long> popularList = new HashMap<Long,Long>(); 
			
			boolean productContentSwitch = IBankParams.isSwitchOn(IBankParams.getBaseOriginCode(commonData.getOrigin()), IBankParams.PRODUCT_CONTENT_SWITCH);
			boolean updateContactSwitch = IBankParams.isSwitchOn(IBankParams.getBaseOriginCode(commonData.getOrigin()), IBankParams.UPD_CONTACT_DETAILS_SWITCH);

			for ( HelpPageVO helpPageVO : getHelpPageList() )
			{
				HelpActionResp helpActionResp = new HelpActionResp();
				if(helpSearchProducts.contains(helpPageVO.getAction())){
					// check the switch value for ProductContentFetch
					if(productContentSwitch){
						helpActionResp.setAction(PRODUCT_LIST);
					}else{
						helpActionResp.setAction(helpPageVO.getAction());
					}	
				}
				else if(helpSearchUpdateContactValidation.contains(helpPageVO.getAction())){
					// check the switch value for Update Contact Details
					if(updateContactSwitch){
						helpActionResp.setAction(UPDATE_CONTACT_DETAILS_VALIDATION);
					}else{
						helpActionResp.setAction(helpPageVO.getAction());
					}	
				}
				else{
					helpActionResp.setAction(helpPageVO.getAction());
				}
				
				helpActionResp.setId(helpPageVO.getId());
				helpActionResp.setName(helpPageVO.getHelpName());
				actionList.add(helpActionResp);

				if ( helpPageVO.getPopularPriority() != null &&  helpPageVO.getPopularPriority() > 0 )
				{
					popularList.put(helpPageVO.getPopularPriority(), helpPageVO.getId());
				}
				
				String[] keys = helpPageVO.getKeywords().split(",");
				for ( String key : keys )
				{
					if ( haskKeyMap.containsKey(key) )
					{
						ArrayList<Long> tempArr = haskKeyMap.get(key) ;
						tempArr.add(helpPageVO.getId());
						haskKeyMap.put(key, tempArr);

					}
					else
					{
						ArrayList<Long> tempArr = new ArrayList<Long> () ;
						tempArr.add(helpPageVO.getId());
						haskKeyMap.put(key, tempArr);
					}
				}
				
			}
			
			helpSearchResp.setActionList(actionList);
			
			ArrayList<HelpSearchKeyMapResp> keyMap = new ArrayList<HelpSearchKeyMapResp>();
			Iterator<String> iterator = haskKeyMap.keySet().iterator();
			
			while ( iterator.hasNext() )
			{
				String key = iterator.next();
				HelpSearchKeyMapResp helpSearchKeyMapResp = new HelpSearchKeyMapResp();
				helpSearchKeyMapResp.setKey(key);
				helpSearchKeyMapResp.setSearchIds(haskKeyMap.get(key));
				keyMap.add(helpSearchKeyMapResp);
			}
			
			int i = 1;
			ArrayList<Long> tempPopularList = new ArrayList<Long>();
			while ( i <= actionList.size() )
			{
				if ( popularList.get(new Long(i)) != null )
					tempPopularList.add(popularList.get(new Long(i)));
				if (( i == 5))  // Max 5 Popular List
				{
					break;
				}
				i++;
				
			}
			
			helpSearchResp.setPopularList(tempPopularList);
			helpSearchResp.setKeyMap(keyMap);

			ObjectMapper mapper = new ObjectMapper();
			Logger.info("Simplified HelpSearch JSON Response :" + mapper.writeValueAsString(helpSearchResp), this.getClass());

			return helpSearchResp;
		}
		catch (Exception e)
		{
			Logger.error("getJSONResponse Failed. ", e, this.getClass());
	//		return Action.ERROR;
		}
		return null;
	}

	
	
	private void readHelpConfigFile() throws IOException
	{
		if (staticHelpPageList == null)
		{
				loadConfigurationBeans();
			  for (int i = 0; i < staticHelpPageList.size(); i++) 
			  { 
				  HelpPageVO	  configurationBean = (HelpPageVO) staticHelpPageList.get(i);
				 // configurationBean.setId(new Long(i + 1));
				  if ( configurationBean.getExternalURL() == null || "N".equalsIgnoreCase(configurationBean.getExternalURL()))
				  {
				  	 staticHelpPageList.get(i).setExternalURL(null);
				  }
				  Logger.info("Help page Name :"+ configurationBean.getHelpName() + " Action : " + configurationBean.getAction() +" Keywords : " + configurationBean.getKeywords() +" External  URL: " + configurationBean.getExternalURL() , this.getClass());
			  }
		}
		
//		setHelpPageList(staticHelpPageList);
	}

	private static final String F_NAME = "HelpPagesConfig.xml";
	
	public void loadConfigurationBeans() throws IOException
	{
		FileInputStream is = null;
		try
		{
			ClassLoader classLoader = getClass().getClassLoader();
			InputStream manageInputStream = null;
			manageInputStream = classLoader.getResourceAsStream(F_NAME);						
			
			try {	
				DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();	
				//set below to avoid security defects
				dbf.setFeature("http://xml.org/sax/features/external-general-entities", false);
				dbf.setFeature("http://xml.org/sax/features/external-parameter-entities", false);
				dbf.setXIncludeAware(false);
			    dbf.setExpandEntityReferences(false);
			    dbf.setFeature("http://javax.xml.XMLConstants/feature/secure-processing", true);
			    
				DocumentBuilder db = dbf.newDocumentBuilder();
				Document document;
				try {
					document = db.parse(manageInputStream);
					staticHelpPages = (HelpPagesVO) unmarshaller.unmarshal(document);
				} catch (SAXException e) {
					Logger.error("SAXException in loadConfigurationBeans HelpSearchController ", e, this.getClass());
					throw new IOException("SAXException in loadConfigurationBeans HelpSearchController");
				}								
				staticHelpPageList = staticHelpPages.getHelpPageVO();				
			} catch (JAXBException e) {
				Logger.error("JAXBException in loadConfigurationBeans HelpSearchController ", e, this.getClass());
				throw new IOException("JAXBException in loadConfigurationBeans HelpSearchController");
			} catch (ParserConfigurationException e) {
				Logger.error("ParserConfigurationException in loadConfigurationBeans HelpSearchController ", e, this.getClass());
				throw new IOException("ParserConfigurationException in loadConfigurationBeans HelpSearchController");
			}						
		}
		finally
		{
			if (is != null)
			{
				is.close();
			}
		}
	}

	
	private void filterForBrand(Cookie cookie, IBankCommonData commonData, String objCustomerType, String custTypesInd, Customer customer,MobileSession mobileSession)
	{
		String origin = commonData.getOrigin();
		String gdwOrigin = commonData.getGdwOrigin();
		List<HelpPageVO> helpPageList = new ArrayList<HelpPageVO>();
		
		String customerType = null;
		if(objCustomerType != null){
			customerType=(String)objCustomerType;
		}
	  String tempOrigin = padComma(origin);
	  String tempcustomerType = padComma(customerType);
	  String tempCustTypesIndExcluded = padComma(custTypesInd);
	  
	  if(null!=commonData) {
		  String uAgent=commonData.getUserAgent();
		  Logger.debug("User agent MD>>"+ uAgent, this.getClass());
	  }
	  
	  if(null!=cookie) {
		  String cookieVal=cookie.getValue();
		  Logger.debug("CookiesVal MD>>"+ cookieVal, this.getClass());
	  }else {
		  Logger.debug("CookiesVal is null MD>>", this.getClass());
	  }
	  
	  if(null!=commonData && null!=cookie) {
		  boolean isMadEligible=isMadisonSearchEligible(commonData.getUserAgent(), cookie);
		  Logger.debug("isMadEligible MD>>"+ isMadEligible, this.getClass());
	  }
	 
	  
    int id = 1;
	  
		for (int i = 0; i < staticHelpPageList.size(); i++) 
	  { 
		  HelpPageVO	  configurationBean = (HelpPageVO) staticHelpPageList.get(i);
		  String exclBrands = padComma(configurationBean.getBrandsExculded());
		  String exclCustType = padComma(configurationBean.getCustTypesExcluded() );
		  String exclCustTypesIndExcluded = padComma(configurationBean.getCustTypesIndExcluded() );
		  
		Logger.debug("tempcustomerType "+ tempcustomerType + "  "+ configurationBean.getCustTypesExcluded() +  " exclCustType "+ exclCustType  + " "+  ( exclCustType.indexOf(tempcustomerType) >= 0 ) , this.getClass());

		  if ( configurationBean.getBrandsExculded() != null && exclBrands.indexOf(tempOrigin) >= 0 	)
		  {
		  	 continue;
		  }
		  else if ( configurationBean.getCustTypesExcluded() != null && exclCustType.indexOf(tempcustomerType) >= 0 	)
		  {
		  	 continue;
		  }
		  else if ( configurationBean.getCustTypesIndExcluded() != null && exclCustTypesIndExcluded.indexOf(tempCustTypesIndExcluded) >= 0 	)
		  {
		  	 continue;
		  }

		   // 16E3 Remove Alerts and T&C links 
		  	if ((configurationBean.getHelpName().equalsIgnoreCase("Deactivate alerts access") || configurationBean.getHelpName().equalsIgnoreCase("Register for SMS & Email Alerts"))){
		  		continue;
		  	}
		  	else if (configurationBean.getHelpName().equalsIgnoreCase("Pay to Mobile transfer") && !IBankParams.isPayToMobileSwitchOn(origin)){
		  		continue;
		  	}
		  	else if((configurationBean.getHelpName().equalsIgnoreCase("Pay to Mobile activation") || configurationBean.getHelpName().equalsIgnoreCase("Pay to Mobile receiving account change"))
		  			&& (!IBankParams.isPayToMobileSwitchOn(origin) || !ibankRefreshParams.getPayIdRegistrationSwitchParams(origin, customer.getGcis()).isShowPayToMobileAccount())){
		  		continue;
		  	}
		  	
		  	//check for Online PIN switch
		  	if(("Change card PIN").equalsIgnoreCase(configurationBean.getHelpName()) && !IBankParams.isOnlinePinSecuritySwitchON(origin)){
		  		continue;
		  	}
		  	if(("Expense Splitter").equalsIgnoreCase(configurationBean.getHelpName())){
			  	Logger.debug("Cookie: " + cookie + "gdwOrigin: "+gdwOrigin, this.getClass());		  		
		  		 if(!IBankParams.isExpenseSplitterSwitchON(origin))
		  			 continue;
		  		 else if( cookie == null || 
		  				( (cookie!=null && !(StringMethods.isEmptyString(cookie.getValue()))) && (gdwOrigin != null && gdwOrigin.startsWith(TABLET_ORGIN_PREFIX)) )
		  		   )
		  			continue;
		  	}
		  	
		  	if(("Cardless Cash").equalsIgnoreCase(configurationBean.getHelpName()) && !checkGetCashEligibility(customer,mobileSession)){
		  		continue;
		  	} 
		  	
		  	if ((configurationBean.getHelpName().equalsIgnoreCase("Decrease credit card limit")) && !IBankParams.isCreditLimitDecreaseSwitchON()){
		  		continue;
		  	}
		  //19E4 Tech Debt Start:Switch Removal
		  	/*if ((configurationBean.getHelpName().equalsIgnoreCase("Close account")) && !IBankParams.isCCClosureSwitchON()){
		  		continue;
		  	}*/
		  	
		  	if ((configurationBean.getHelpName().equalsIgnoreCase("Import payees and billers")) && !IBankParams.isBrandSwitchOn(origin, IBankParams.MEDB_FEATURE_SWITCH) && !checkActiveAccountEligibility(customer.getAccounts(), cookie)){
		  		continue;
		  	}
		  	
		  	if ((configurationBean.getHelpName().equalsIgnoreCase("PayID")) && !ibankRefreshParams.getPayIdRegistrationSwitchParams(origin, customer.getGcis()).isShowPayIdRegistrationMenu()){
		  		continue;
		  	}
	
		  	if ((configurationBean.getHelpName().equalsIgnoreCase("Home loan opening")) && !IBankParams.isSwitchOn(origin, IBankParams.HOME_LOAN_SWITCH)){
		  		continue;
		  	}
		  	
		  	if ((configurationBean.getHelpName().equalsIgnoreCase("Lock and Unlock card")) && !IBankParams.isSwitchOn(origin, IBankParams.LOCK_UNLOCK_SWITCH)){
		  		continue;
		  	}
		  	if ((configurationBean.getHelpName().equalsIgnoreCase("View Direct Debits")) && !IBankParams.isSwitchOn(IBankParams.RECURRING_DIRECT_DEBITS_SWITCH)){
		  		continue;
		  	}
			if ((configurationBean.getHelpName().equalsIgnoreCase("Make a donation")) && !IBankParams.isSwitchOn(IBankParams.DONATIONS_SWITCH)){
		  		continue;
		  	}
			if ((configurationBean.getHelpName().equalsIgnoreCase("Add to Apple Wallet")) && !(IBankParams.getBrandSwitchVal(origin, IBankParams.MADISON_IN_APP_PROVISIONING_SWITCH).equalsIgnoreCase("1")) && !(IBankParams.getBrandSwitchVal(origin, IBankParams.MADISON_IN_APP_PROVISIONING_SWITCH).equalsIgnoreCase("2"))){
		  		continue;
		  	}
		    if ((configurationBean.getHelpName().equalsIgnoreCase("Add to Apple Wallet")) && IBankParams.getBrandSwitchVal(origin, IBankParams.MADISON_IN_APP_PROVISIONING_SWITCH).equalsIgnoreCase("1") && !isMadisonSearchEligible(commonData.getUserAgent(), cookie)){
		  		continue;
		  	}
			if ((configurationBean.getHelpName().equalsIgnoreCase("Add to Apple Wallet")) && IBankParams.getBrandSwitchVal(origin, IBankParams.MADISON_IN_APP_PROVISIONING_SWITCH).equalsIgnoreCase("2") && !ibankRefreshParams.isPilotCustomer(customer.getGcis(), MADISON_IN_APP_PROV_PILOT)){
		  		continue;
		  	}
			if ((configurationBean.getHelpName().equalsIgnoreCase("Add to Apple Wallet")) && IBankParams.getBrandSwitchVal(origin, IBankParams.MADISON_IN_APP_PROVISIONING_SWITCH).equalsIgnoreCase("2") && !isMadisonSearchEligible(commonData.getUserAgent(), cookie)){
		  		continue;
		  	}
			if ((configurationBean.getHelpName().equalsIgnoreCase("Wallets and Wearables"))){
				if((IBankParams.getBrandSwitchVal(origin, IBankParams.MADISON_IN_APP_PROVISIONING_SWITCH).equalsIgnoreCase("1")) || (IBankParams.getBrandSwitchVal(origin, IBankParams.MADISON_IN_APP_PROVISIONING_SWITCH).equalsIgnoreCase("2"))) {
					continue;
				}
				else if(IBankParams.getBrandSwitchVal(origin, IBankParams.MADISON_IN_APP_PROVISIONING_SWITCH).equalsIgnoreCase("0")) {
					if ((configurationBean.getHelpName().equalsIgnoreCase("Wallets and Wearables")) && !(IBankParams.getBrandSwitchVal(origin, IBankParams.MADISON_SWITCH).equalsIgnoreCase("1")) && !(IBankParams.getBrandSwitchVal(origin, IBankParams.MADISON_SWITCH).equalsIgnoreCase("2"))){
				  		continue;
				  	}
				    if ((configurationBean.getHelpName().equalsIgnoreCase("Wallets and Wearables")) && IBankParams.getBrandSwitchVal(origin, IBankParams.MADISON_SWITCH).equalsIgnoreCase("1") && !isMadisonSearchEligible(commonData.getUserAgent(), cookie)){
				  		continue;
				  	}
					if ((configurationBean.getHelpName().equalsIgnoreCase("Wallets and Wearables")) && IBankParams.getBrandSwitchVal(origin, IBankParams.MADISON_SWITCH).equalsIgnoreCase("2") && !ibankRefreshParams.isPilotCustomer(customer.getGcis(), MADISON_PILOT)){
				  		continue;
				  	}
					if ((configurationBean.getHelpName().equalsIgnoreCase("Wallets and Wearables")) && IBankParams.getBrandSwitchVal(origin, IBankParams.MADISON_SWITCH).equalsIgnoreCase("2") && !isMadisonSearchEligible(commonData.getUserAgent(), cookie)){
				  		continue;
				  	}
			  }
			}
		  	if(("Tax Residency Information").equalsIgnoreCase(configurationBean.getHelpName()) && !IBankParams.isSwitchOn(IBankParams.CRS_BUSINESS_SWITCH)
		  			&& CustomerVOAssembler.BUSINESS_CUSTOMER.equalsIgnoreCase(customer.getCustTypeInd())){
		  		continue;
		  	}
		  
		  	//Check for GCC Switch
		  	if(configurationBean.getHelpName().equalsIgnoreCase("Global Currency Card")){
		  		if(  IBankParams.isGlobalWalletSwitchOn(customer.getGcis()) )
		  		{
	  				continue;
		  		}
		  		GCCService gccService = (GCCService) ServiceHelper.getBean("gccService");
	  			if(!gccService.isGCCSwitchON(IBankParams.getBaseOriginCode(origin))) {
	  				continue;
	  			}
		  	}

		  	if(configurationBean.getHelpName().equalsIgnoreCase("Worldwide Wallet")){
		  		if( ! IBankParams.isGlobalWalletSwitchOn(customer.getGcis()) )
		  		{
	  				continue;
	  			}
		  	}

		  	if (configurationBean.getHelpName().equalsIgnoreCase("Dispute a credit card transaction") && IBankParams.isCardDisputeSwitchON(origin)) {
		  		continue;
		  	}
		  	if (configurationBean.getHelpName().equalsIgnoreCase("Dispute a card transaction") && !IBankParams.isCardDisputeSwitchON(origin)) {
		  		continue;
		  	}
		  	//check for Security Wellbeing switch
			if (configurationBean.getHelpName().equalsIgnoreCase("Security wellbeing check") && !IBankParams.isSwitchOn(IBankParams.ONLINE_SECURITY_CHECK_SWITCH)) {
		  		continue;
		  	}
		  	
		  //Check for UOD Switch
		  	if(configurationBean.getHelpName().equalsIgnoreCase("Manage overdraw preferences")){
	  			if(!ibankRefreshParams.isUnarrangedOverdraftSwitchOn()) {
	  				continue;
	  			}
		  	}
		  	if(configurationBean.getHelpName().equalsIgnoreCase("My Offers & Benefits")){
	  			if(! ibankRefreshParams.isAscendaSwitchON()) {
	  				continue;
	  			}
		  	}

		  	//check for Marketing preferences help search
			if (configurationBean.getHelpName().equalsIgnoreCase("Manage marketing preferences")) {
				if(! IBankParams.isSwitchOn(IBankParams.MANAGE_PREFERENCES_SWITCH)) {
					continue;
				}
		  	}
			
			if(configurationBean.getHelpName().equalsIgnoreCase("Card autopay")){
	  			if(!ibankRefreshParams.isAutoPaySwitchOn()) {
	  				continue;
	  			}
		  	}
			
			if(configurationBean.getHelpName().equalsIgnoreCase("Plan&Pay instalment plan")){
	  			if(!ibankRefreshParams.isSmartPlanSwitchON(origin, customer.getGcis())) {
	  				continue;
	  			}
		  	}
			
			if(configurationBean.getHelpName().equalsIgnoreCase("Gambling block")){
				if(!IBankParams.isGamblingSwitchOn()) {
	  				continue;
	  			}
		  	}
			
		  configurationBean.setId(new Long(id) );
		  id++;
		  helpPageList.add(configurationBean);
//		  Logger.info("Help page Name :"+ configurationBean.getHelpName() + " Action : " + configurationBean.getAction() +" Keywords : " + configurationBean.getKeywords() +" External  URL: " + configurationBean.getExternalURL() , this.getClass());
	  }
		setHelpPageList(helpPageList);
	}
	
	private static final String COMMA = ",";
	
	private String padComma(String text)
	{
		return COMMA + text + COMMA; 
	}
	
	private boolean checkGetCashEligibility(Customer customer,MobileSession mobileSession){
		boolean result =false;		
		
		if(customer.getCustomerTypes().contains(CustomerTypes.TYPE_GHS)){
			if(CustomerVOAssembler.PERSONAL_CUSTOMER.equalsIgnoreCase(customer.getCustTypeInd())){				
				result= true;
			}
			else{
				result= false;
			}
		}else if(customer.getCustomerTypes().contains(CustomerTypes.TYPE_CHS)){
			result= false;
		}else if(customer.getCustomerTypes().contains(CustomerTypes.TYPE_CHS_GHS)){
			if(CustomerTypes.TYPE_GHS.equalsIgnoreCase(customer.getPrimaryProfile()) || CustomerVOAssembler.PERSONAL_CUSTOMER.equalsIgnoreCase(customer.getCustTypeInd())){
				result= true;
			}
			else{
				result= false;
			}		
		}
		if(result){
			CodesVO codeItem=IBankParams.getCodesData(IBankParams.BRAND_ORIGIN, IBankParams.CONFIGURATION_PROPERTIES,IBankParams.GET_CASH_SWITCH);
			//0,1,9 9 FOR BROWSER
			
			// GetCashSwitch = 9, ignore flag sent by native app. 
			if (codeItem != null && "9".equals(codeItem.getMessage())){			
				return result;
			}
			
			if (!("1".equals(mobileSession.getGetCashAllowFlag()))){
				result =false;
			}
		}
		
		return result;			
	}
	
	private boolean checkSecurityWellbeingEligibility(Customer customer,MobileSession mobileSession){
		boolean result =false;		
		
		if(customer.getCustomerTypes().contains(CustomerTypes.TYPE_GHS)){
			if(IBankParams.isSwitchOn(IBankParams.ONLINE_SECURITY_CHECK_SWITCH)){				
				result= true;
			}
			else{
				result= false;
			}
		}else if(customer.getCustomerTypes().contains(CustomerTypes.TYPE_CHS)){
			result= false;
		}else if(customer.getCustomerTypes().contains(CustomerTypes.TYPE_CHS_GHS)){
			if(CustomerTypes.TYPE_GHS.equalsIgnoreCase(customer.getPrimaryProfile()) && (IBankParams.isSwitchOn(IBankParams.ONLINE_SECURITY_CHECK_SWITCH))){
				result= true;
			}
			else{
				result= false;
			}		
		}
		return result;
	  }
	
	private boolean checkActiveAccountEligibility(List<Account> accountList, Cookie cookie){
		boolean isMogoAvailable = isMogoSDKInstalled(cookie);
		boolean isEligible = isActiveAccountPresent(accountList);
		if(isMogoAvailable && isEligible){
			return true;
		}
		return false;
	}
	
	public boolean isMogoSDKInstalled(Cookie cookie)
	{
		if (cookie != null && ! StringMethods.isEmptyString(cookie.getValue())){
			String tempStr = cookie.getValue();
	  		Logger.debug("App version Cookie value .. " +tempStr , this.getClass());
		  	  if ( tempStr.toUpperCase().indexOf(MOGO_APP_VERSION_COOKIE) >= 0){
		  	  	return true;
		  	  }
		  	  else{
		  	  	return false;
		  	  }
	  	}
	  	return true;
	}
	
	private boolean isActiveAccountPresent(List<Account> accountList){
		List<Account> custAccounts = AccountFilter.filterGetActiveOnYourAccount(accountList);
		if(custAccounts!=null && custAccounts.size() > 0){
			Logger.info("Returning true from isActiveAccountPresent", this.getClass());
			return true;
		}
		Logger.info("Returning false from isActiveAccountPresent", this.getClass());
		return false;
	}
	
	private Cookie getCookie(HttpServletRequest request, String cookieName) throws ResourceException
	{

		Cookie[] cookies = request.getCookies();
		Cookie cookie = null;
		if (cookies != null)
		{
			for (int i = 0; i < cookies.length; i++)
			{
				if (cookies[i].getName().equals(cookieName))
				{
						cookie = cookies[i]; 
						Logger.info("Cookie " + cookieName + " found in the request. Value : " + cookie.getValue() , this.getClass());
					  break;
				}
			}
		}
		return cookie;
	}
	
	private boolean isMadisonSearchEligible(String userAgent, Cookie cookie) throws ResourceException
	{
		if( (cookie!=null && !(StringMethods.isEmptyString(cookie.getValue())))){
			if(null!=userAgent) {
				if(StringUtils.containsIgnoreCase(userAgent, "ios") || StringUtils.containsIgnoreCase(userAgent, "iphone")){
					return true;
				}else {
					return false;
				}
			}else {
				return false;
			}
		}
		else {
			return false;
	   }
	}
	

	/**
	 * SBGEXP-8092 - Fix issue of name id getting generated for async error response
	 *  
	 * @param serviceRequest
	 * @param httpRequest
	 * @return ErrorResp
	 * @throws BusinessException
	 */	
	public ErrorResp validateAsync(IMBReq serviceRequest, HttpServletRequest httpRequest) throws BusinessException {
		return  mbAppValidator.validateAsync(serviceRequest, httpRequest);
	}	
	
}
