package au.com.stgeorge.mbank.model.request.mortgage;

import java.io.Serializable;

import au.com.stgeorge.mbank.model.common.IMBReq;
import au.com.stgeorge.mbank.model.common.ReqHeader;

public class UpdatePIDReq implements IMBReq, Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = -4202918060199510055L;
	private ReqHeader header;
	private String clasAssetId;
	private String qasAddressID;
	

	public String getClasAssetId() {
		return clasAssetId;
	}

	public void setClasAssetId(String clasAssetId) {
		this.clasAssetId = clasAssetId;
	}

	public String getQasAddressID() {
		return qasAddressID;
	}

	public void setQasAddressID(String qasAddressID) {
		this.qasAddressID = qasAddressID;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public ReqHeader getHeader() {
		return header;
	}

	public void setHeader(ReqHeader header) {
		this.header = header;
	}
}
