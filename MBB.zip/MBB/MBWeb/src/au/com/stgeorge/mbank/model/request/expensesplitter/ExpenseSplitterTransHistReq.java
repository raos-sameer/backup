package au.com.stgeorge.mbank.model.request.expensesplitter;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.NotEmpty;

import au.com.stgeorge.ibank.businessobject.BusinessException;
import au.com.stgeorge.mbank.model.common.IMBReq;
import au.com.stgeorge.mbank.model.common.ReqHeader;

public class ExpenseSplitterTransHistReq implements IMBReq {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private ReqHeader header;
		
	@NotNull(message = "" + BusinessException.WSVC_INVALID_INPUT_PARAM)
	private Integer accountIndex;
	
	private static final String HISTORY_PERIOD_PATTERN = "((?i)(30|60|all))";
	@NotEmpty (message = ""+BusinessException.WSVC_INVALID_INPUT_PARAM)	
	@Pattern(regexp = HISTORY_PERIOD_PATTERN ,message = ""+BusinessException.WSVC_INVALID_INPUT_PARAM)	 
	private String historyPeriod;
	
	public Integer getAccountIndex() {
		return accountIndex;
	}	
	public void setAccountIndex(Integer accountIndex) {
		this.accountIndex = accountIndex;
	}
	
	public ReqHeader getHeader()
	{
		return header;
	}
	public void setHeader(ReqHeader header)
	{
		this.header = header;
	}
				
	public String getHistoryPeriod() {
		return historyPeriod;
	}
	public void setHistoryPeriod(String historyPeriod) {
		this.historyPeriod = historyPeriod;
	}
}
