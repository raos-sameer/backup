package au.com.stgeorge.mbank.controller.services;

import java.math.BigDecimal;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;

import au.com.stgeorge.framework.common.logging.Logger;
import au.com.stgeorge.framework.common.util.DateMethods;
import au.com.stgeorge.framework.common.util.StringMethods;
import au.com.stgeorge.ibank.businessobject.BusinessException;
import au.com.stgeorge.ibank.businessobject.HeartBeat;
import au.com.stgeorge.ibank.businessobject.PortfolioListsFilter;
import au.com.stgeorge.ibank.businessobject.ResourceException;
import au.com.stgeorge.ibank.valueobject.Account;
import au.com.stgeorge.ibank.valueobject.Customer;
import au.com.stgeorge.ibank.valueobject.database.CCBalanceTransferVO;
import au.com.stgeorge.ibank.valueobject.transfer.IBankCommonData;
import au.com.stgeorge.ibank.valueobject.transfer.PortfolioLists;
import au.com.stgeorge.mbank.controller.IMBController;
import au.com.stgeorge.mbank.model.common.IMBReq;
import au.com.stgeorge.mbank.model.common.IMBResp;
import au.com.stgeorge.mbank.model.common.ReqHeader;
import au.com.stgeorge.mbank.model.common.RespHeader;
import au.com.stgeorge.mbank.model.request.EmptyReq;
import au.com.stgeorge.mbank.model.request.services.CCBalanceTransferReq;
import au.com.stgeorge.mbank.model.response.ErrorResp;
import au.com.stgeorge.mbank.session.MobileSession;
import au.com.stgeorge.mbank.util.FraudLogger;
import au.com.stgeorge.mbank.util.MBAppHelper;
import au.com.stgeorge.mbank.util.MBAppUtils;
import au.com.stgeorge.mbank.util.MBAppValidator;
import au.com.stgeorge.mbank.util.ServiceConstants;
import au.com.stgeorge.mobilebank.businessobject.MobileBankService;
import au.com.stgeorge.perflogger.PerformanceLogger;

import com.fasterxml.jackson.databind.ObjectMapper;

@Controller
@RequestMapping("/cards")
public class CCBalanceTransferController implements IMBController{
	
	private FraudLogger fraudLogger;
	
	@Autowired
	private MBAppHelper mbAppHelper;
	
	@Autowired
	private CCBalanceTransferHelper ccBalanceTransferHelper;
	
	@Autowired
	private MBAppValidator mbAppValidator;
				
	@Autowired
	private PerformanceLogger perfLogger;
	
	@Autowired
	private MobileBankService mobileBankService;
	
	@RequestMapping(value= "baltranlist" , method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public IMBResp processAcctList(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, 
			@RequestBody final EmptyReq req){
		
		ObjectMapper objectMapper = new ObjectMapper();							
		perfLogger.startAllLogs();
		String logName = MBAppUtils.getLogName(httpServletRequest);
		perfLogger.startLog(logName);
		
		fraudLogger = new FraudLogger();
		MobileSession mbSession = null;
		PortfolioLists portfolioList = null;
		try{	
			
			mbSession = mbAppHelper.getMobileSession(httpServletRequest);															
			Logger.info("CC Bal transfer card List JSON Request :" + objectMapper.writeValueAsString(req), this.getClass());
			validateRequestHeader(req.getHeader(), httpServletRequest);
			ErrorResp errorResp = validate(req, httpServletRequest);
			if (errorResp != null && errorResp.getErrors() != null && errorResp.getErrors().size() > 0)
			{				
				//fraudLogger.logInvalidInput();
				return errorResp;
			}
												
			Customer customer=mbSession.getCustomer();			
			IBankCommonData commonData=mbAppHelper.populateIBankCommonData(mbSession,httpServletRequest);
			
			if(!HeartBeat.isApplicationAvailable(HeartBeat.VISION_PLUS))
					throw new BusinessException(BusinessException.SYSTEM_UNAVILABLE);
			
			portfolioList = PortfolioListsFilter.getPortfolioList(commonData, PortfolioLists.LIST_TYPE_CC_CREDITCARD_ACCOUNT_TRANSFER_FROM);
			
			IMBResp serviceResponse = ccBalanceTransferHelper.populateAcctListResp(portfolioList);			 					
			RespHeader headerResp = populateResponseHeader(ServiceConstants.CC_BALANCE_TRANSFER_CARDLIST_SERVICE, mbSession);
			serviceResponse.setHeader(headerResp);			
			
			Logger.info("CC Bal transfer card List JSON Response :" + objectMapper.writeValueAsString(serviceResponse), this.getClass());
			
			return serviceResponse;		
		}catch (BusinessException e)
		{			
			Logger.info("BusinessException Inside processAcctList() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());			
			BusinessException exp = new BusinessException(e.getKey());
			IMBResp resp1  = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, ServiceConstants.CC_BALANCE_TRANSFER_CARDLIST_SERVICE, httpServletRequest);
			return resp1;
		}catch (ResourceException e) {
			Logger.error("ResourceException Inside processAcctList() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			ResourceException exp = new ResourceException(e.getKey());
			IMBResp resp1  = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, ServiceConstants.CC_BALANCE_TRANSFER_CARDLIST_SERVICE, httpServletRequest);
			return resp1;
		}catch (Exception e)
		{
			Logger.error("Exception Inside processAcctList() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			BusinessException exp = new BusinessException(BusinessException.GENERIC_ERROR);
			IMBResp resp1  = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, ServiceConstants.CC_BALANCE_TRANSFER_CARDLIST_SERVICE, httpServletRequest);
			return resp1;
		} finally
		{
			perfLogger.endLog(logName);
			perfLogger.endAllLogs();
		}
		
	}
	
	@RequestMapping(value= "baltran" , method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public IMBResp processBalanceTransferConfirm(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, 
			@RequestBody final CCBalanceTransferReq req){
		
		ObjectMapper objectMapper = new ObjectMapper();							
		perfLogger.startAllLogs();
		String logName = MBAppUtils.getLogName(httpServletRequest);
		perfLogger.startLog(logName);
		
		fraudLogger = new FraudLogger();
		MobileSession mbSession = null;
		PortfolioLists portfolioList = null;
		try{	
			
			mbSession = mbAppHelper.getMobileSession(httpServletRequest);															
			Logger.info("CC Bal transfer confirm JSON Request :" + objectMapper.writeValueAsString(req), this.getClass());
			validateRequestHeader(req.getHeader(), httpServletRequest);
			ErrorResp errorResp = validate(req, httpServletRequest);
			if (errorResp != null && errorResp.getErrors() != null && errorResp.getErrors().size() > 0)
			{				
				//fraudLogger.logInvalidInput();
				return errorResp;
			}
												
			Customer customer=mbSession.getCustomer();			
			IBankCommonData commonData=mbAppHelper.populateIBankCommonData(mbSession,httpServletRequest);
			
			if(!HeartBeat.isApplicationAvailable(HeartBeat.VISION_PLUS))
					throw new BusinessException(BusinessException.SYSTEM_UNAVILABLE);
			
			Account selectedAcct = mbAppHelper.getAccountFromCustomer(customer, req.getAccountIndex());
			ccBalanceTransferHelper.validateInputData(req.getAmount(), commonData, selectedAcct);
			
			CCBalanceTransferVO ccBalanceTransferVO = getCCBalanceTransferVO(commonData, customer, mbSession.getOrigin(), req, selectedAcct); 
			ccBalanceTransferVO = mobileBankService.addCCBalanceTransfer(commonData, ccBalanceTransferVO);
									
			IMBResp serviceResponse = ccBalanceTransferHelper.populateResp(ccBalanceTransferVO);			 					
			RespHeader headerResp = populateResponseHeader(ServiceConstants.CC_BALANCE_TRANSFER_SERVICE, mbSession);
			serviceResponse.setHeader(headerResp);			
			
			Logger.info("CC Bal transfer confirm JSON Response :" + objectMapper.writeValueAsString(serviceResponse), this.getClass());
			
			return serviceResponse;		
		}catch (BusinessException e)
		{			
			Logger.info("BusinessException Inside processBalanceTransferConfirm() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());			
			BusinessException exp = new BusinessException(e.getKey());
			IMBResp resp1  = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, ServiceConstants.CC_BALANCE_TRANSFER_SERVICE, httpServletRequest);
			return resp1;
		}catch (ResourceException e) {
			Logger.error("ResourceException Inside processBalanceTransferConfirm() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			ResourceException exp = new ResourceException(e.getKey());
			IMBResp resp1  = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, ServiceConstants.CC_BALANCE_TRANSFER_SERVICE, httpServletRequest);
			return resp1;
		}catch (Exception e)
		{
			Logger.error("Exception Inside processBalanceTransferConfirm() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			BusinessException exp = new BusinessException(BusinessException.GENERIC_ERROR);
			IMBResp resp1  = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, ServiceConstants.CC_BALANCE_TRANSFER_SERVICE, httpServletRequest);
			return resp1;
		} finally
		{
			perfLogger.endLog(logName);
			perfLogger.endAllLogs();
		}
		
	}
	
	public CCBalanceTransferVO getCCBalanceTransferVO(IBankCommonData commonData, Customer customer, String origin, CCBalanceTransferReq req,Account fromAccount) {

		StringBuffer fromCardName = new StringBuffer();
		
		if (!StringMethods.isEmptyString(customer.getTitle())) {
			fromCardName.append(customer.getTitle());
		}
		if (!StringMethods.isEmptyString(customer.getFirstName())) {
			fromCardName.append(" " + customer.getFirstName());
		}
		if (!StringMethods.isEmptyString(customer.getLastName())) {
			fromCardName.append(" " + customer.getLastName());
		}

		CCBalanceTransferVO ccBalanceTransferVO = new CCBalanceTransferVO();
		if (fromCardName.toString() != null) {
			ccBalanceTransferVO.setFromCardName(fromCardName.toString());
		}

		ccBalanceTransferVO.setFromAccountName(fromAccount.getAccountId().getProductName());
		ccBalanceTransferVO.setFromCardNumber(fromAccount.getAccountId().getAccountNumber());
		ccBalanceTransferVO.setToCardName(req.getCardName());
		ccBalanceTransferVO.setToCardNumber(req.getCardNum());
		ccBalanceTransferVO.setToCardInstitution(req.getInstitutionName());
		ccBalanceTransferVO.setAmount(new BigDecimal(req.getAmount()));
		ccBalanceTransferVO.setGcisNumber(commonData.getUser().getGCISNumber());
		ccBalanceTransferVO.setStatus(0);
		ccBalanceTransferVO.setOriginBank(origin);
		ccBalanceTransferVO.setCreatedBy(commonData.getUser().getUserId());
		ccBalanceTransferVO.setCreatedOn(DateMethods.getTimestamp());

		ccBalanceTransferVO.setModifiedBy(commonData.getUser().getUserId());
		ccBalanceTransferVO.setModifiedOn(DateMethods.getTimestamp());
		ccBalanceTransferVO.setCustFirstName(customer.getFirstName());
		ccBalanceTransferVO.setBrand(fromAccount.getBrand());

		if (req.getSendEmail()) {
			ccBalanceTransferVO.setCustEmailAddress(customer.getContactDetail().getEmail());
		}

		return ccBalanceTransferVO;
	}
	
	/**
	 * Response for invalid body request 
	 * 
	 * @return
	 */
	@ExceptionHandler({org.springframework.http.converter.HttpMessageNotReadableException.class})
	@ResponseStatus(org.springframework.http.HttpStatus.OK)
	@ResponseBody
	public IMBResp resolveException() {		
		return MBAppUtils.createInvalidMessageBodyResponse(ServiceConstants.CC_BALANCE_TRANSFER_SERVICE);
	}
	
	public ErrorResp validate(IMBReq serviceRequest, HttpServletRequest request) {
		return new MBAppValidator().validate(serviceRequest, request);
	}
	
	public void validateRequestHeader(ReqHeader header, HttpServletRequest request) throws ResourceException
	{	
		mbAppValidator.validateRequestHeader(header,  request);	
	}
	
	public RespHeader populateResponseHeader(String ServiceName, MobileSession mobSession )
	{		
		return mbAppHelper.populateResponseHeader(ServiceName, mobSession);
	}
	
}
