package au.com.stgeorge.mbank.controller.customer;


import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang.builder.ReflectionToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import au.com.stgeorge.framework.common.logging.Logger;
import au.com.stgeorge.ibank.businessobject.BusinessException;
import au.com.stgeorge.ibank.businessobject.ResourceException;
import au.com.stgeorge.ibank.common.cache.IBankParams;
import au.com.stgeorge.ibank.safi.valueobject.SafiDeviceInfo;
import au.com.stgeorge.ibank.valueobject.transfer.IBankCommonData;
import au.com.stgeorge.mbank.controller.IMBController;
import au.com.stgeorge.mbank.controller.SafiWebHelper;
import au.com.stgeorge.mbank.model.common.IMBReq;
import au.com.stgeorge.mbank.model.common.IMBResp;
import au.com.stgeorge.mbank.model.common.ReqHeader;
import au.com.stgeorge.mbank.model.common.RespHeader;
import au.com.stgeorge.mbank.model.request.EmptyReq;
import au.com.stgeorge.mbank.model.response.ErrorResp;
import au.com.stgeorge.mbank.model.response.customer.OnlineSecurityCheckResp;
import au.com.stgeorge.mbank.session.MobileSession;
import au.com.stgeorge.mbank.session.MobileSessionImpl;
import au.com.stgeorge.mbank.util.MBAppHelper;
import au.com.stgeorge.mbank.util.MBAppUtils;
import au.com.stgeorge.mbank.util.MBAppValidator;
import au.com.stgeorge.mbank.util.ServiceConstants;
import au.com.stgeorge.perflogger.PerformanceLogger;

@Controller
@RequestMapping("/onlinesecuritycheck")
public class OnlineSecurityCheckController implements IMBController
{
	@Autowired
	private MBAppHelper mbAppHelper;

	@Autowired
	private MBAppValidator mbAppValidator;
	
	@Autowired
	private PerformanceLogger perfLogger;
	
	@Autowired
	private OnlineSecurityCheckHelper onlineSecurityCheckHelper;

	@Autowired
	private LogonHelper logonHelper;
	
	@RequestMapping(value = "view", method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public IMBResp viewSecurityCheckDetails(HttpServletRequest httpRequest, @RequestBody final EmptyReq request) {
		Logger.debug("OnlineSecurityCheckController - viewSecurityCheckDetails. Request: " + request, this.getClass());
		String logName = startPerformanceLog(httpRequest);
		MobileSession mobileSession = new MobileSessionImpl();
		OnlineSecurityCheckResp resp = null;
		SafiDeviceInfo devicePermsInfo = null;
		
		try {
			mobileSession.getSessionContext(httpRequest);
			validateRequestHeader(request.getHeader(), httpRequest);
			ErrorResp errorResponse = validate(request, httpRequest);
			if (errorResponse.hasErrors())
			{
				return errorResponse;
			}
			if(!IBankParams.isSwitchOn(IBankParams.ONLINE_SECURITY_CHECK_SWITCH)) {
				throw new BusinessException(BusinessException.SYSTEM_UNAVILABLE, "IBankParams.ONLINE_SECURITY_CHECK_SWITCH is OFF.");
			}
			
			IBankCommonData commonData = mbAppHelper.populateIBankCommonData(mobileSession, httpRequest);
			
			int appType = logonHelper.getAppOsType(httpRequest);
			boolean isMobileApp = (appType == -1) ? false:true;
			if(isMobileApp) {
				devicePermsInfo = new SafiDeviceInfo();
				SafiWebHelper.readCookieForAppPermissionInfoVersion(httpRequest, devicePermsInfo);
				if(devicePermsInfo != null && devicePermsInfo.getAppVersion() != null) {
					Logger.debug("devicePermsInfo for viewSecurityCheckDetails - App version "+devicePermsInfo.getAppVersion()
					+ ": Location perms "+devicePermsInfo.getLocationPerms() + ": Telephone perms "+devicePermsInfo.getPhonePerms(), this.getClass());
				}
			}
			
			resp = populateOSCViewResponse(populateResponseHeader(ServiceConstants.ONLINE_SECURITY_CHECK_VIEW_SERVICE, mobileSession ), commonData, devicePermsInfo, isMobileApp, appType);
			onlineSecurityCheckHelper.addStatisticsLog(commonData, onlineSecurityCheckHelper.getGDWDescription(resp, isMobileApp, appType));
			
			return resp;
		} catch (BusinessException e) {
			Logger.info("BusinessException in OnlineSecurityCheckController - viewSecurityCheckDetails() - [key: " + e.getKey() + "] : GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), e, ServiceConstants.ONLINE_SECURITY_CHECK_VIEW_SERVICE, httpRequest);
		} catch (ResourceException e) {
			Logger.error("ResourceException in OnlineSecurityCheckController - viewSecurityCheckDetails() - [key: " + e.getKey() + "] : GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.SYSTEM_UNAVILABLE, ServiceConstants.ONLINE_SECURITY_CHECK_VIEW_SERVICE, httpRequest);
		} catch (Exception e) {
			Logger.error("Exception OnlineSecurityCheckController - viewSecurityCheckDetails(): GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), ResourceException.MOBILE_NON_FINANCIAL_FATAL_ERR, ServiceConstants.ONLINE_SECURITY_CHECK_VIEW_SERVICE, httpRequest);
		} finally {
			endPerformanceLog(logName);
		}
	}
	
	private OnlineSecurityCheckResp populateOSCViewResponse(RespHeader header, IBankCommonData commonData, SafiDeviceInfo devicePermsInfo, boolean isMobileApp, int appType){
		OnlineSecurityCheckResp response = new OnlineSecurityCheckResp(header);
		
		response.setEmailIdMissing(onlineSecurityCheckHelper.isEmailMissing(commonData));
		response.setUpperLimitPayeeCount(onlineSecurityCheckHelper.getUpperLimitPayeeCount(commonData));
		response.setEstmtEligibleCount(onlineSecurityCheckHelper.getEstmtEligibleCount(commonData));
		if(isMobileApp) {
			response.setLatestAppVersionStatus(onlineSecurityCheckHelper.latestAppVersionInstalled(devicePermsInfo,commonData.getOrigin(), appType));
			response.setPhoneServiceStatus((devicePermsInfo.getPhonePerms() != null) ? String.valueOf(devicePermsInfo.getPhonePerms()) : "error");
			response.setLocationServiceStatus( (devicePermsInfo.getLocationPerms() != null) ? String.valueOf(devicePermsInfo.getLocationPerms()) : "error");
		}else{
			response.setLatestAppVersionStatus("false");
			response.setPhoneServiceStatus("false");
			response.setLocationServiceStatus("false");
		}
		Logger.debug("Response for viewSecurityCheckDetails - "+response, this.getClass());
		return response;
	}
	
	private String startPerformanceLog(HttpServletRequest httpRequest){
		perfLogger.startAllLogs();
		String logName = MBAppUtils.getLogName(httpRequest);
		perfLogger.startLog(logName);
		return logName;
	}
	
	private void endPerformanceLog(String logName){
		perfLogger.endLog(logName);
		perfLogger.endAllLogs();
	}
	
	public ErrorResp validate(IMBReq serviceRequest, HttpServletRequest request) {
		if(Logger.isDebugEnabled(this.getClass())){
			Logger.debug("Service request object - " + ReflectionToStringBuilder.toString(serviceRequest), this.getClass());
		}
		return mbAppValidator.validate(serviceRequest, request);
	}

	public void validateRequestHeader(ReqHeader headerReq, HttpServletRequest request) throws BusinessException {
		if(Logger.isDebugEnabled(this.getClass())){
			Logger.debug("Request header validation: " + ReflectionToStringBuilder.toString(headerReq, ToStringStyle.MULTI_LINE_STYLE), this.getClass());
		}
		mbAppValidator.validateRequestHeader(headerReq, request);
	}
	
	public RespHeader populateResponseHeader(String serviceName, MobileSession mobSession) {
		return mbAppHelper.populateResponseHeader(serviceName, mobSession);
	}
	
}
