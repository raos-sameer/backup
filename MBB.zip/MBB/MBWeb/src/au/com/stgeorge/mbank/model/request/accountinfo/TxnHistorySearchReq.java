package au.com.stgeorge.mbank.model.request.accountinfo;

import javax.validation.constraints.NotNull;
import au.com.stgeorge.ibank.businessobject.BusinessException;
import au.com.stgeorge.mbank.model.common.IMBReq;
import au.com.stgeorge.mbank.model.common.ReqHeader;

public class TxnHistorySearchReq implements IMBReq{
		
	private static final long serialVersionUID = 2472783637674353799L;

	private ReqHeader header;
	
	//TODO	
	@NotNull(message = "" + BusinessException.WSVC_INVALID_INPUT_PARAM)
	private Integer accountIndex;
	
	private String searchStr;
	
	public String getSearchStr() {
		return searchStr;
	}
	public void setSearchStr(String searchStr) {
		this.searchStr = searchStr;
	}
	public Integer getAccountIndex() {
		return accountIndex;
	}	
	public void setAccountIndex(Integer accountIndex) {
		this.accountIndex = accountIndex;
	}
	
	public ReqHeader getHeader()
	{
		return header;
	}
	public void setHeader(ReqHeader header)
	{
		this.header = header;
	}
	
	public static long getSerialVersionUID() {
		return serialVersionUID;
	}
	
	
}
