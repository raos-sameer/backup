package au.com.stgeorge.mbank.controller.offers;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

import org.springframework.stereotype.Service;

import au.com.stgeorge.framework.common.logging.Logger;
import au.com.stgeorge.framework.common.util.StringMethods;
import au.com.stgeorge.ibank.businessobject.BusinessException;
import au.com.stgeorge.ibank.businessobject.ResourceException;
import au.com.stgeorge.ibank.common.cache.IBankParams;
import au.com.stgeorge.ibank.util.ServiceHelper;
import au.com.stgeorge.ibank.valueobject.Account;
import au.com.stgeorge.ibank.valueobject.AccountId;
import au.com.stgeorge.ibank.valueobject.Customer;
import au.com.stgeorge.ibank.valueobject.Invitation;
import au.com.stgeorge.ibank.valueobject.Invitation.ApplicationLinkEnum;
import au.com.stgeorge.ibank.valueobject.OffersSearchVO;
import au.com.stgeorge.ibank.valueobject.database.CodesVO;
import au.com.stgeorge.ibank.valueobject.transfer.IBankCommonData;
import au.com.stgeorge.mbank.model.response.offers.AemOfferDetailsResp;
import au.com.stgeorge.mbank.model.response.offers.ExternalLinkResp;
import au.com.stgeorge.mbank.model.response.offers.OfferTeaserResp;
import au.com.stgeorge.mbank.model.response.offers.SalesOfferTeaserResp;
import au.com.stgeorge.mbank.model.response.offers.TeaserResp;
import au.com.stgeorge.mbank.util.MBAppHelper;
import au.com.stgeorge.mobilebank.businessobject.MobileBankService;

@Service
public class SalesOfferHelper {
	
	private static final String RETENTION = "RET";
	public static final String SPRING_MOBILE_SERVICE_BEAN  ="mobileBankService";	
	public List<SalesOfferTeaserResp> populateSalesOfferResp(IBankCommonData ibankCommonData){
		
		List<SalesOfferTeaserResp> teaserRespList = new ArrayList<SalesOfferTeaserResp>();
		MobileBankService mobileBankService = (MobileBankService) ServiceHelper.getBean(SPRING_MOBILE_SERVICE_BEAN);
		try{					
			
			List<Invitation> invitationList = mobileBankService.getSalesOfferList(ibankCommonData);
									
			if(invitationList != null && invitationList.size() > 0){
				
				//teaserRespList = new ArrayList<SalesOfferTeaserResp>();
				for(Invitation invitation : invitationList){
					SalesOfferTeaserResp offerResp = new SalesOfferTeaserResp();
					offerResp.setSubject(invitation.getTeaserSubject());
					offerResp.setText(invitation.getTeaserTxtLine());
					offerResp.setLeadId(invitation.getLeadId());
					List<String> featureList = new ArrayList<String>();
					featureList .add(invitation.getInvTxt1());
					featureList .add(invitation.getInvTxt2());
					if(invitation.getInvTxt3() != null)
						featureList .add(invitation.getInvTxt3());
					
					
					offerResp.setFeatures(featureList);
					offerResp.setActionText(invitation.getInvButtonTxt());
					offerResp.setImageUrl(invitation.getInvImageUrl());
					offerResp.setApplicationType(invitation.getInternalUrl());
					offerResp.setIsExternalLink(invitation.getIsExternalLink());
					offerResp.setAccountIndex(invitation.getAccountIndex());	
					
					teaserRespList.add(offerResp);					
				}
																
			}			
			
		}catch(BusinessException e){
			Logger.error("BusinessException while getting OfferList "  ,  this.getClass());
		}catch(ResourceException e){
			Logger.error("ResourceException while getting OfferList "  ,  this.getClass());
		}catch(Exception e){
			Logger.error("Exception while getting OfferList "  ,  this.getClass());
		}
		
		
		return teaserRespList;
		
	}
	
	public SalesOfferTeaserResp populateTeaserResp(Customer mbCustomer) {
		
  		SalesOfferTeaserResp teaserResp = new SalesOfferTeaserResp();
				
		Invitation invitation = mbCustomer.getInvitation();
		if(invitation != null) {
			
			if(invitation.getLeadId() != null){
								
				teaserResp.setLeadId(invitation.getLeadId());
				teaserResp.setText(invitation.getTeaserTxtLine());
				teaserResp.setSubject(invitation.getTeaserSubject());
				teaserResp.setLinkText(invitation.getTeaserLinkTxt());
				teaserResp.setImageId(invitation.getImageId());
				
				if(invitation.getInsertionPoints() != null){
					for(String insertionPoint : invitation.getInsertionPoints()){
						if(insertionPoint.equalsIgnoreCase("My Accounts"))
							teaserResp.setIsDashboard(true);
						else if(insertionPoint.equalsIgnoreCase("Account To Account Transfer Receipt"))
							teaserResp.setIsAccountTfrReceipt(true);
						else if(insertionPoint.equalsIgnoreCase("Overseas Payment Receipt"))
							teaserResp.setIsOverseasTfrReceipt(true);
						else if(insertionPoint.equalsIgnoreCase("BPAY Transfer Receipt"))
							teaserResp.setIsBpayTfrReceipt(true);
						else if(insertionPoint.equalsIgnoreCase("Pay Anyone Receipt"))
							teaserResp.setIsPayeeTfrReceipt(true);
					}
				}
				
				teaserResp.setApplicationType(invitation.getInternalUrl());
				teaserResp.setIsExternalLink(invitation.getIsExternalLink());
				teaserResp.setAccountIndex(invitation.getAccountIndex());
			}
						
		}
		return teaserResp;
	}
	
	public OfferTeaserResp populateNextTeaserResp(Customer mbCustomer) {
		
		OfferTeaserResp offerTeaserResp = new OfferTeaserResp();
		
		TeaserResp teaserResp = new TeaserResp();
				
		teaserResp.setSalesOfferTeaserResp(populateTeaserResp(mbCustomer));
		teaserResp.setInvitationInfoResp(MBAppHelper.populateInvitation(mbCustomer));
		teaserResp.setUnreadOfferCount(mbCustomer.getInvitation().getOfferCount());
		
		offerTeaserResp.setTeaserResp(teaserResp);
								
		return offerTeaserResp;
	}
	
	public DeepLinkTeaserResp populateOfferDeepLink(Customer mbCustomer) {
		
		
		DeepLinkTeaserResp teaserResp = new DeepLinkTeaserResp();
				
		teaserResp.setApplicationType(mbCustomer.getInvitation().getInternalUrl());
		teaserResp.setIsExternalLink(mbCustomer.getInvitation().getIsExternalLink());
		if ( mbCustomer.getInvitation() != null &&  mbCustomer.getInvitation().getInternalUrl().equalsIgnoreCase( "BTSuperSearchURL" ) )
		{
			teaserResp.setIsExternalLink(false);
		}
		teaserResp.setSubject(mbCustomer.getInvitation().getTeaserSubject());
		teaserResp.setAccountIndex(mbCustomer.getInvitation().getAccountIndex());
		
		return teaserResp;
	}
	
public ExternalLinkResp populateExternalLinkURLResp(String url) {
		
	ExternalLinkResp extLinkResp = new ExternalLinkResp();
		
	extLinkResp.setUrl(url);
								
		return extLinkResp;
	}

	public AemOfferDetailsResp populateAemOfferDetailsResp(OffersSearchVO offersSearchVO, IBankCommonData commonData) throws BusinessException {
	
		AemOfferDetailsResp aemOfferDetailsResp = new AemOfferDetailsResp();
		
		aemOfferDetailsResp.setLeadID(offersSearchVO.getLeadId());
		//aemOfferDetailsResp.setEndDate(offersSearchVO.getExpiryDate().toString());
		
		aemOfferDetailsResp.setFirstName(commonData.getCustomer().getFirstName());
		
		if(!StringMethods.isEmptyString(offersSearchVO.getmKT1())){
			
			aemOfferDetailsResp.setField1(offersSearchVO.getmKT1());
			
			if(offersSearchVO.getmKT1().equalsIgnoreCase(RETENTION)){
				Account account = getAccountFromCustomer(commonData, truncateGDWAccountKey(offersSearchVO.getgDWAcctKey()));
			
				if(null != account && null != account.getAccountId()){
					aemOfferDetailsResp.setAccountNumber(account.getAccountId().getAccountNumber());
					aemOfferDetailsResp.setBsbNumber(account.getAccountId().getBsb());
					aemOfferDetailsResp.setProductName(account.getAccountId().getProductName());
				}else{
					throw new BusinessException(BusinessException.OFFER_DETAILS_NOT_FOUND);
				}
				
				if(!StringMethods.isEmptyString(offersSearchVO.getmKT10()) && !StringMethods.isEmptyString(offersSearchVO.getmKT11())){
					try{
						aemOfferDetailsResp.setFeeWaiverAmount(String.valueOf(Integer.parseInt(offersSearchVO.getmKT10()) * Integer.parseInt(offersSearchVO.getmKT11())));
					}catch(Exception e){
						Logger.warn("Exception while trying to get Fee Waiver amount in aemoffer/details ", e, this.getClass());
						aemOfferDetailsResp.setFeeWaiverAmount(null);
					}
				}
				
			}else{
				Integer accountIndex = getAccountIndexByAccountKey(commonData.getCustomer().getAccounts(), getAccountNumForRenewTD(offersSearchVO));
				if(accountIndex!=-1) {
					aemOfferDetailsResp.setAccountIndex(Integer.toString(accountIndex));
				}
			}
		}
		if(!StringMethods.isEmptyString(offersSearchVO.getmKT2())){
			aemOfferDetailsResp.setField2(offersSearchVO.getmKT2());
		}
		if(!StringMethods.isEmptyString(offersSearchVO.getmKT3())){
			aemOfferDetailsResp.setField3(offersSearchVO.getmKT3());
		}
		if(!StringMethods.isEmptyString(offersSearchVO.getmKT4())){
			aemOfferDetailsResp.setField4(offersSearchVO.getmKT4());
		}
		if(!StringMethods.isEmptyString(offersSearchVO.getmKT5())){
			aemOfferDetailsResp.setField5(offersSearchVO.getmKT5());
		}
		if(!StringMethods.isEmptyString(offersSearchVO.getmKT6())){
			aemOfferDetailsResp.setField6(offersSearchVO.getmKT6());
		}
		if(!StringMethods.isEmptyString(offersSearchVO.getmKT7())){
			aemOfferDetailsResp.setField7(offersSearchVO.getmKT7());
		}
		if(!StringMethods.isEmptyString(offersSearchVO.getmKT8())){
			aemOfferDetailsResp.setField8(offersSearchVO.getmKT8());
		}
		if(!StringMethods.isEmptyString(offersSearchVO.getmKT9())){
			aemOfferDetailsResp.setField9(offersSearchVO.getmKT9());
		}
		if(!StringMethods.isEmptyString(offersSearchVO.getmKT10())){
			aemOfferDetailsResp.setField10(offersSearchVO.getmKT10());
		}
		if(!StringMethods.isEmptyString(offersSearchVO.getmKT11())){
			aemOfferDetailsResp.setField11(offersSearchVO.getmKT11());
		}
		if(!StringMethods.isEmptyString(offersSearchVO.getmKT12())){
			aemOfferDetailsResp.setField12(offersSearchVO.getmKT12());
		}
		if(!StringMethods.isEmptyString(offersSearchVO.getmKT13())){
			aemOfferDetailsResp.setField13(offersSearchVO.getmKT13());
		}
		if(!StringMethods.isEmptyString(offersSearchVO.getmKT14())){
			aemOfferDetailsResp.setField14(offersSearchVO.getmKT14());
		}
		if(!StringMethods.isEmptyString(offersSearchVO.getmKT15())){
			aemOfferDetailsResp.setField15(offersSearchVO.getmKT15());
		}
		if(!StringMethods.isEmptyString(offersSearchVO.getmKT16())){
			aemOfferDetailsResp.setField16(offersSearchVO.getmKT16());
		}
		if(!StringMethods.isEmptyString(offersSearchVO.getmKT17())){
			aemOfferDetailsResp.setField17(offersSearchVO.getmKT17());
		}
		if(!StringMethods.isEmptyString(offersSearchVO.getmKT18())){
			aemOfferDetailsResp.setField18(offersSearchVO.getmKT18());
		}
		if(!StringMethods.isEmptyString(offersSearchVO.getmKT19())){
			aemOfferDetailsResp.setField19(offersSearchVO.getmKT19());
		}
		if(!StringMethods.isEmptyString(offersSearchVO.getmKT20())){
			aemOfferDetailsResp.setField20(offersSearchVO.getmKT20());
		}
		
		if(!IBankParams.isSwitchOn(IBankParams.AEM_ADMIN_TEMPLATE_SWITCH)) {
			CodesVO appLinkCode = IBankParams.getCodesData(IBankParams.DEFAULT_ORIGIN,IBankParams.OFFERS_APP_NAME, offersSearchVO.getmBApplicationLink());		
			if(appLinkCode!=null) {
				aemOfferDetailsResp.setApplicationType(appLinkCode.getMessage());
			}
		}

		return aemOfferDetailsResp;
	}
	
	public String truncateGDWAccountKey(String accountNumber) {
		if(!StringMethods.isEmptyString(accountNumber)){
			return accountNumber.substring(9);
		}else{
			return null;
		}
	}
	
	public Account getAccountFromCustomer(IBankCommonData commonData, String accountKey) {
			accountKey = StringMethods.removeLeadingZero(accountKey);
			Account account = null;
			
			if (commonData.getCustomer() != null && commonData.getCustomer().getAccounts() != null) {
				
				Collection accountList = commonData.getCustomer().getAccounts();
				Iterator iterator = accountList.iterator();
				Object temp;
				AccountId accountId;
				String acctKey;
				while (iterator.hasNext()) {
					temp = iterator.next();
					if (temp instanceof Account) {
						account = (Account) temp;
						accountId = account.getAccountId();
						acctKey = account.getAccountId().getAccountKey().trim();
						acctKey = StringMethods.removeLeadingZero(acctKey);
						
						if ((accountId != null) && (acctKey.equals(accountKey.trim()))) {
								return account;
						}
					}
				}
			}
			return null;
		}
	
	private String getAccountNumForRenewTD(OffersSearchVO offerSearch){

		String acctNum = null;
		String delimiter = "|"; 

		Logger.debug("MKT1 account number : " +offerSearch.getmKT1(), this.getClass());
		acctNum = Account.CDA + delimiter + offerSearch.getmKT1();

		return acctNum;
	}
	
	@SuppressWarnings("rawtypes")
	public int getAccountIndexByAccountKey(Collection acctList, String accountKey) {

		AccountId accountId = new AccountId();
		accountId.setAggregatedKey(accountKey);

		int i = 0;
		boolean found = false;
		if (acctList != null && !acctList.isEmpty()) {
			ArrayList list = (ArrayList) acctList;
			int size = list.size();
			for (; i < size; i++) {
				Account account = (Account) list.get(i);				
				if (accountId.equals(account.getAccountId())) {
					found = true;
					break;
				}
			}
		}
		if (found)
			return i;
		else
			return -1;
	}
}
