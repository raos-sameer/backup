package au.com.stgeorge.mbank.controller.statements;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import au.com.stgeorge.ibank.businessobject.AccountFilter;
import au.com.stgeorge.ibank.businessobject.BusinessException;
import au.com.stgeorge.ibank.common.cache.IBankParams;
import au.com.stgeorge.ibank.valueobject.Account;
import au.com.stgeorge.ibank.valueobject.CreditCardAccount;
import au.com.stgeorge.ibank.valueobject.Account.EstmtConsentStatus;
import au.com.stgeorge.ibank.valueobject.Customer;
import au.com.stgeorge.ibank.valueobject.transfer.IBankCommonData;
import au.com.stgeorge.mbank.model.response.statements.ManageEStmtAcctListResp;
import au.com.stgeorge.mbank.model.response.statements.ManageEStmtAcctReceiptListResp;
import au.com.stgeorge.mbank.model.statements.ManageEStmtAcctDetailResp;
import au.com.stgeorge.mbank.util.MBAppHelper;
import au.com.stgeorge.mobilebank.businessobject.EStatementsService;

@Service
public class ManageEStmtHelper {

	@Autowired
	private EStatementsService mobileEStatementService;
	
	@Autowired
	private MBAppHelper mbAppHelper;
		
	public static final int  SOL_ACCT_TNC_TYPE = 1;
	public static final int  JOINT_ACCT_TNC_TYPE = 2;
	public static final String  ESTMT_ACCT_STATUS_S = "S";
	public static final String  ESTMT_ACCT_STATUS_E = "E";
	public static final String APPLICATION_ONBOARDING = "ONBOARDING";
	public static final String GDW_DESC_ONBOARDING = "onboarding";
	public static final String ESTMT_SPLASH = "ESTMTSPLASH";
	public static final String ESTMT_SPLASH_SKIPPED_DESC = "1st time skip: Mobile Estatements Splash Presented1";
	public static final String ESTMT_SPLASH_SKIPPED_DONE_DESC = "2nd time Done: Mobile Estatements Splash Switched2";
	public static final String ESTMT_SPLASH_DONE_DESC = "1st time Done: Mobile Estatements Splash Switched1";
	/**
	 * This method will get the list of eligible sol and joint  accounts for Manage eStatement.
	 * It will set the Type for Terms and conditions to be displayed on UI.
	 * Terms and Conditions text is different for SOL and JOINT+SOL accounts.
	 * @param commonData
	 * @param customer
	 * @return
	 * @throws BusinessException
	 */
protected ManageEStmtAcctListResp populateManageStmtAcctListResp(IBankCommonData commonData,Customer customer) throws BusinessException{
		
		ManageEStmtAcctListResp resp = null;
		ManageEStmtAcctDetailResp accountInfoResp = null;
		List<ManageEStmtAcctDetailResp> respAccountInfoList = null;
		List<Account> solAccList = null;
		List<Account> jointAccList = null;
		List<String>solAcctRelcodes = null;
		List<String>jointAcctRelcodes = null;

			List<Account> accountList = mobileEStatementService.getEligibleAccountsList(commonData, customer);
			
			if(accountList != null && accountList.size() > 0){
				resp = new ManageEStmtAcctListResp();
				respAccountInfoList = new ArrayList<ManageEStmtAcctDetailResp>();
				solAccList = new ArrayList<Account>();
				jointAccList = new ArrayList<Account>();
				solAcctRelcodes = IBankParams.getSolAcctCustAcctRelCodes(commonData.getOrigin());
				jointAcctRelcodes = IBankParams.getJointAcctCustAcctRelCodes(commonData.getOrigin());
				//boolean isMadisonLCMSwitchOn = AccountFilter.isMadisonLCMSwitchOn(customer.getGcis());
				for (Account account : accountList) {
					//if(isMadisonLCMSwitchOn) {
						if(Account.CRA.equalsIgnoreCase(account.getAccountId().getApplicationId())) {
						CreditCardAccount cacc = (CreditCardAccount) account;
							if("S".equalsIgnoreCase(cacc.getBlockCode()) || ("J".equalsIgnoreCase(cacc.getBlockCode()) &&  "Q".equalsIgnoreCase(cacc.getAccountId().getAcctStatus())) ){
				  			   continue;
				  		   	}
						}
					//}					
					accountInfoResp = new  ManageEStmtAcctDetailResp();
					String relCode = account.getAccountId().getRelationshipCode();
					accountInfoResp.setAccountIndex(account.getIndex());
					accountInfoResp.setEstmtAcctStatus(account.getEstmtAcctStatus());
					
					if(account.getEstmtConsentInd() != null){
						accountInfoResp.setEstmtConsentInd(account.getEstmtConsentInd());
					}else{
						accountInfoResp.setEstmtConsentInd("");
					}
										
					if(relCode != null && !("".equalsIgnoreCase(relCode))){
						if(solAcctRelcodes.contains(relCode)){
							solAccList.add(account);
						}else if(jointAcctRelcodes.contains(relCode)){
							jointAccList.add(account);
						}
					}				
					respAccountInfoList.add(accountInfoResp);
				}
			}
			
			resp.setAccountList(respAccountInfoList);
			
			if(solAccList != null && jointAccList != null && (!solAccList.isEmpty()) && jointAccList.isEmpty() ){
				resp.setTncType(SOL_ACCT_TNC_TYPE);
			}else {
				resp.setTncType(JOINT_ACCT_TNC_TYPE);
			}

		return resp;		
}

protected ManageEStmtAcctReceiptListResp populateResp(IBankCommonData commonData,List<Account> accounts) throws BusinessException {

	ManageEStmtAcctReceiptListResp resp = null;
	List<Integer> eStmtAcctList = null;
	List<Integer> partiallyConsentAcctList = null;
	List<Integer> eligibleForEStmtAcctList = null;
	
	if(accounts != null && accounts.size() > 0){

		resp = new ManageEStmtAcctReceiptListResp();
		eStmtAcctList = new ArrayList<Integer>();
		partiallyConsentAcctList = new ArrayList<Integer>();
		eligibleForEStmtAcctList = new ArrayList<Integer>();

		for(Account account : accounts){

			if(account.getEstmtAcctStatus() != null){
				
				if(ESTMT_ACCT_STATUS_E.equalsIgnoreCase(account.getEstmtAcctStatus()) && (EstmtConsentStatus.OTHERS.getStatus().equalsIgnoreCase(account.getEstmtConsentInd())
						|| EstmtConsentStatus.PARTIAL.getStatus().equalsIgnoreCase(account.getEstmtConsentInd()))){
					partiallyConsentAcctList.add(account.getIndex());
				}else if(ESTMT_ACCT_STATUS_E.equalsIgnoreCase(account.getEstmtAcctStatus()) && EstmtConsentStatus.NONE.getStatus().equalsIgnoreCase(account.getEstmtConsentInd())){
					eligibleForEStmtAcctList.add(account.getIndex());
				}else if(ESTMT_ACCT_STATUS_S.equalsIgnoreCase(account.getEstmtAcctStatus())){
					eStmtAcctList.add(account.getIndex());
				}
			}

		}

		resp.seteStmtList(eStmtAcctList);
		resp.setPaperStmtList(eligibleForEStmtAcctList);
		resp.setPartialConsentList(partiallyConsentAcctList);
	}

	return resp;
}
/**
 * This method will return String for fraudlog entry for joint accounts.
 * @param accountList
 * @return
 */
public String  getFraudLogEntryStr(List<Account> accountList,String eStmtStatus){
	
	String fraudLogEntry = null;
	StringBuffer fraudLogStr = null;
	char separator = '|';
	
	if(accountList != null && accountList.size() > 0){

		fraudLogStr = new StringBuffer();
		for(Account acc : accountList){
			if(eStmtStatus.equalsIgnoreCase(acc.getEstmtAcctStatus()))
			{	
				fraudLogStr.append(acc.getAccountId().getAccountNumber());
				fraudLogStr.append(separator);
			}
		}

		if((fraudLogStr.length() > 0) && fraudLogStr.charAt(fraudLogStr.length()-1) == separator)
		{
			fraudLogEntry = fraudLogStr.substring(0, fraudLogStr.length()-1);
		}
	}
	return fraudLogEntry;

}

/**
 * This method will return size of account list depending on eStmtStatus (E/P)passed
 * @param accountList
 * @param eStmtStatus
 * @return
 */
public int findSwitchedPrefListSize(List<Account> accountList,String eStmtStatus){
	
	int size  = 0;
	
	if(accountList != null && accountList.size() > 0){
		for(Account acc : accountList){
			if(eStmtStatus.equalsIgnoreCase(acc.getEstmtAcctStatus()))
			{	
				++size;
			}
		}

	}
	return size;
			
}
	
}
