package au.com.stgeorge.mbank.model.common;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
@JsonInclude(Include.NON_NULL)

public class ProductReq {
	
	private String type;
    private String  subProdcode;

	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getSubProdcode() {
		return subProdcode;
	}
	public void setSubProdcode(String subProdcode) {
		this.subProdcode = subProdcode;
	}

}
