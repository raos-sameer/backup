package au.com.stgeorge.mbank.model.accountinfo;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_NULL)
public class TranCategoryInfo {

	private String name;
	private String amount;
	private String imageId;
	private String percentage;
	private List<TranCategoryDetailInfo> subCategories;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAmount() {
		return amount;
	}
	public void setAmount(String amount) {
		this.amount = amount;
	}
	public String getImageId() {
		return imageId;
	}
	public void setImageId(String imageId) {
		this.imageId = imageId;
	}
	public String getPercentage() {
		return percentage;
	}
	public void setPercentage(String percentage) {
		this.percentage = percentage;
	}
	public List<TranCategoryDetailInfo> getSubCategories() {
		return subCategories;
	}
	public void setSubCategories(List<TranCategoryDetailInfo> subCategories) {
		this.subCategories = subCategories;
	} 
	
	
	
	
}
