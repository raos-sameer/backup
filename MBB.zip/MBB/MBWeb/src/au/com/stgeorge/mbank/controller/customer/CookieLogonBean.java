package au.com.stgeorge.mbank.controller.customer;


public class CookieLogonBean
{

	private String accessNumber;
	private boolean ignoreSec;	
	private String issueNumber;
	
	public String getAccessNumber() {
		return accessNumber;
	}
	public void setAccessNumber(String accessNumber) {
		this.accessNumber = accessNumber;
	}
	public String getIssueNumber() {
		return issueNumber;
	}
	public void setIssueNumber(String issueNumber) {
		this.issueNumber = issueNumber;
	}
	public boolean isIgnoreSec() {
		return ignoreSec;
	}
	public void setIgnoreSec(boolean ignoreSec) {
		this.ignoreSec = ignoreSec;
	}


	
}
