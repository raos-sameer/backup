package au.com.stgeorge.mbank.model.request.payments;

import javax.validation.constraints.Pattern;

import org.apache.commons.lang.builder.ReflectionToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;
import org.hibernate.validator.constraints.NotEmpty;

import au.com.stgeorge.ibank.businessobject.BusinessException;
import au.com.stgeorge.mbank.model.common.IMBReq;
import au.com.stgeorge.mbank.model.common.ReqHeader;

/**
 * 
 * 
 * 
 */
public class PayIdReq implements IMBReq {

	private static final long serialVersionUID = -4723751125232692028L;
	private ReqHeader header;
	
	@NotEmpty(message = "" + BusinessException.WSVC_INVALID_INPUT_PARAM)
	@Pattern(regexp = "^[0-9]+$", message = "" + BusinessException.WSVC_INVALID_INPUT_PARAM)
	private String accountIndex;
	
	private String devicePrint;
	
	public String getAccountIndex() {
		return accountIndex;
	}

	public void setAccountIndex(String accountIndex) {
		this.accountIndex = accountIndex;
	}

	public ReqHeader getHeader() {
		return header;
	}

	public void setHeader(ReqHeader header) {
		this.header = header;
	}
	
	@Override
	public String toString() {
		return ReflectionToStringBuilder.toString(this, ToStringStyle.MULTI_LINE_STYLE);
	}

	public String getDevicePrint() {
		return devicePrint;
	}

	public void setDevicePrint(String devicePrint) {
		this.devicePrint = devicePrint;
	}

}
