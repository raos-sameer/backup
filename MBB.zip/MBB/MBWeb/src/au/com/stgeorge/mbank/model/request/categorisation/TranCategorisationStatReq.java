package au.com.stgeorge.mbank.model.request.categorisation;


import javax.validation.constraints.NotNull;

import au.com.stgeorge.ibank.businessobject.BusinessException;
import au.com.stgeorge.mbank.model.common.IMBReq;
import au.com.stgeorge.mbank.model.common.ReqHeader;

public class TranCategorisationStatReq implements IMBReq{

	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1881886950222390021L;


	private ReqHeader header;
	
	@NotNull(message = "" + BusinessException.WSVC_INVALID_INPUT_PARAM)
	private Integer accountIndex;
	
	private String categoryName;
	
    private Boolean isDebit=false;
	
	public Integer getAccountIndex() {
		return accountIndex;
	}	
	public void setAccountIndex(Integer accountIndex) {
		this.accountIndex = accountIndex;
	}	
	public ReqHeader getHeader()
	{
		return header;
	}
	public void setHeader(ReqHeader header)
	{
		this.header = header;
	}
	
	
	public String getCategoryName() {
		return categoryName;
	}
	public void setCategoryName(String categoryName) {
		this.categoryName = categoryName;
	}
	public static long getSerialVersionUID() {
		return serialVersionUID;
	}
	
	public Boolean isDebit() {
		return isDebit;
	}
	public void setDebit(Boolean isDebit) {
		this.isDebit = isDebit;
	}

}
