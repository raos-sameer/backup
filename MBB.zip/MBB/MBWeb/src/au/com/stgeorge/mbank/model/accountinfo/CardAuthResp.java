/**
 * 
 */
package au.com.stgeorge.mbank.model.accountinfo;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

/**
 * @author C50216
 *
 */
@JsonInclude(Include.NON_NULL)
public class CardAuthResp {

	private String totAmt;
	private List<TranDetailResp> authList;
	private String lwcDesc;
		
	public String getTotAmt() {
		return totAmt;
	}
	public void setTotAmt(String totAmt) {
		this.totAmt = totAmt;
	}
	public List<TranDetailResp> getAuthList() {
		return authList;
	}
	public void setAuthList(List<TranDetailResp> authList) {
		this.authList = authList;
	}
	public String getLwcDesc() {
		return lwcDesc;
	}
	public void setLwcDesc(String lwcDesc) {
		this.lwcDesc = lwcDesc;
	}
		
}
