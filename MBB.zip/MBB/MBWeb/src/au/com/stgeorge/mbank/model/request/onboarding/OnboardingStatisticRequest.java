package au.com.stgeorge.mbank.model.request.onboarding;

import java.io.Serializable;

import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.Length;

import au.com.stgeorge.mbank.model.common.IMBReq;
import au.com.stgeorge.mbank.model.common.ReqHeader;

public class OnboardingStatisticRequest implements IMBReq, Serializable {

	private static final long serialVersionUID = 5194501329694799012L;
	
	protected static final String BLOCK_CHARS_PATTERN = "^[0-9A-Za-z',. &/\\-<>:;_]*$";
	
	@Pattern(regexp = BLOCK_CHARS_PATTERN, message = "{errors.desc.blockchar}")
	@Length(max = 50, message = "{errors.desc.maxlength}")
	private String action_type;
	
	public String getAction_type() {
		return action_type;
	}

	public void setAction_type(String action_type) {
		this.action_type = action_type;
	}

	@Pattern(regexp = BLOCK_CHARS_PATTERN, message = "{errors.desc.blockchar}")
	@Length(max = 255, message = "{errors.desc.maxlength}")
	private String desc; 
	

	

	public String getDesc() {
		return desc;
	}

	public void setDesc(String desc) {
		this.desc = desc;
	}

	@Override
	public ReqHeader getHeader() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void setHeader(ReqHeader header) {
		// TODO Auto-generated method stub
		
	}

}
