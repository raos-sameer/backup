package au.com.stgeorge.mbank.model.request.payments;

import javax.validation.constraints.Pattern;

import org.apache.commons.lang.builder.ReflectionToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;
import org.hibernate.validator.constraints.NotEmpty;

import au.com.stgeorge.ibank.businessobject.BusinessException;
import au.com.stgeorge.mbank.model.common.IMBReq;
import au.com.stgeorge.mbank.model.common.ReqHeader;

/**
 * Get default currency for country request 
 * 
 * @author C38854
 *
 */
public class TTCountryCurrencyReq implements IMBReq {

	private static final long serialVersionUID = 2022242446298729854L;

	// @Valid TODO
	private ReqHeader header;

	@NotEmpty(message = "" + BusinessException.GENERIC_ERROR)
	@Pattern(regexp = "^[0-9A-Za-z',. &/\\-\\(\\)]*$", message = "{errors.country.blockchar}")
	private String country;
	
	private String countryCode;

	public String getCountry() {
		return country;
	}
	
	public String getCountryCode() {
		return countryCode;
	}

	public ReqHeader getHeader() {
		return header;
	}

	public void setHeader(ReqHeader header) {
		this.header = header;
	}

	@Override
	public String toString() {
		return ReflectionToStringBuilder.toString(this, ToStringStyle.MULTI_LINE_STYLE);
	}
}