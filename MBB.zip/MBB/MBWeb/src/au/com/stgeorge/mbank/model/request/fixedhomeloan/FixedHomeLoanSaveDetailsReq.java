package au.com.stgeorge.mbank.model.request.fixedhomeloan;

import javax.validation.constraints.NotNull;

import au.com.stgeorge.ibank.businessobject.BusinessException;
import au.com.stgeorge.mbank.model.common.IMBReq;
import au.com.stgeorge.mbank.model.common.ReqHeader;

public class FixedHomeLoanSaveDetailsReq implements IMBReq{

	private static final long serialVersionUID = -1219853237797299425L;
	
	private ReqHeader header;
	@NotNull(message = "" + BusinessException.WSVC_INVALID_INPUT_PARAM)
	private Integer selectedLoanTerm;
	private String bannerClickedFrom;
	
	public Integer getSelectedLoanTerm() {
		return selectedLoanTerm;
	}

	public void setSelectedLoanTerm(Integer selectedLoanTerm) {
		this.selectedLoanTerm = selectedLoanTerm;
	}
	
	public String getBannerClickedFrom() {
		return bannerClickedFrom;
	}

	public void setBannerClickedFrom(String bannerClickedFrom) {
		this.bannerClickedFrom = bannerClickedFrom;
	}


	public ReqHeader getHeader(){
		return header;
	}
	
	public void setHeader(ReqHeader header){
		this.header = header;
	}
}
