package au.com.stgeorge.mbank.controller.loanApplication;

import org.springframework.stereotype.Service;

import au.com.stgeorge.mbank.model.loanApplication.EContractResp;

/**
 * @author c70714
 *
 */
@Service
public class EContractApplicationHelper {
	
	public EContractResp populateEcontractResp(){
		EContractResp eContractResp = new EContractResp();
		eContractResp.setIsSuccess(true);
		return eContractResp;
	}
	
	public EContractResp populatePerformStatisticResp(){
		EContractResp eContractResp = new EContractResp();
		eContractResp.setIsSuccess(true);
		return eContractResp;
	}
	public EContractResp populate2FARequiredResponse(boolean authRequired){
		EContractResp eContractResp = new EContractResp();
		eContractResp.setAuth2FArequired(authRequired);
		return eContractResp;
	}
	
}
