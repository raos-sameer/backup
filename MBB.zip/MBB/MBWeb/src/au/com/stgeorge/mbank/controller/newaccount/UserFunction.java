package au.com.stgeorge.mbank.controller.newaccount;



public class UserFunction
{
	private String functionCode;
	private Boolean allowed;
	
	
	public UserFunction()
	{
		super();
	}

	public UserFunction(String functionCode, Boolean allowed)
	{
		this.functionCode = functionCode;
		this.allowed = allowed;
	}

	public String getFunctionCode()
	{
		return functionCode;
	}

	public void setFunctionCode(String functionCode)
	{
		this.functionCode = functionCode;
	}

	public Boolean isAllowed()
	{
		return allowed;
	}

	public void setAllowed(Boolean allowed)
	{
		this.allowed = allowed;
	}

	
	@Override
	public int hashCode()
	{
		final int prime = 31;
		int result = 1;
		result = prime * result + ((allowed == null) ? 0 : allowed.hashCode());
		result = prime * result + ((functionCode == null) ? 0 : functionCode.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj)
	{
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		UserFunction other = (UserFunction) obj;
		if (allowed == null)
		{
			if (other.allowed != null)
				return false;
		} else if (!allowed.equals(other.allowed))
			return false;
		if (functionCode == null)
		{
			if (other.functionCode != null)
				return false;
		} else if (!functionCode.equals(other.functionCode))
			return false;
		return true;
	}

	@Override
	public String toString()
	{
		StringBuffer buffer = new StringBuffer();
		if (functionCode!=null) buffer.append(functionCode);
		return buffer.toString();
	}
	
	
	
	


	
}
