/**
 * 
 */
package au.com.stgeorge.mbank.model.accountinfo;

import java.util.List;

import au.com.stgeorge.mbank.model.common.KeyValueResp;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
/**
 * @author C50216
 *
 */

@JsonInclude(Include.NON_NULL)
public class GCCAccountDetailResp{

 private List<KeyValueResp> cards ;

List<KeyValueResp>  balances;
  
  private String status;
  
  private boolean allowFunding;
  
private String googleUrl;
private String itunesUrl;


public String getGoogleUrl() {
	return googleUrl;
}

public void setGoogleUrl(String googleUrl) {
	this.googleUrl = googleUrl;
}

public String getItunesUrl() {
	return itunesUrl;
}

public void setItunesUrl(String itunesUrl) {
	this.itunesUrl = itunesUrl;
}


public boolean isAllowFunding() {
	return allowFunding;
}

public void setAllowFunding(boolean allowFunding) {
	this.allowFunding = allowFunding;
}

public String getStatus() {
	return status;
}

public void setStatus(String status) {
	this.status = status;
}

public List<KeyValueResp> getCards() {
	return cards;
}

public void setCards(List<KeyValueResp> cards) {
	this.cards = cards;
}

public List<KeyValueResp> getBalances() {
	return balances;
}

public void setBalances(List<KeyValueResp> balances) {
	this.balances = balances;
}


	
}
