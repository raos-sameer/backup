package au.com.stgeorge.mbank.model.request.customer;

import java.io.Serializable;

import au.com.stgeorge.mbank.model.common.IMBReq;
import au.com.stgeorge.mbank.model.common.ReqHeader;

public class EmailBounceBackReq implements IMBReq, Serializable {

	private static final long serialVersionUID = 6036683551101343515L;

	private String actionType;
	private String emailAddress;
	private ReqHeader header;

	public String getActionType() {
		return actionType;
	}

	public String getEmailAddress() {
		return emailAddress;
	}

	@Override
	public ReqHeader getHeader() {
		return header;
	}

	public void setActionType(String actionType) {
		this.actionType = actionType;
	}

	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}

	@Override
	public void setHeader(ReqHeader header) {
		this.header = header;
	}
}