/**
 * 
 */
package au.com.stgeorge.mbank.model.accountinfo;

import java.util.Date;

import au.com.stgeorge.mbank.util.JsonDateSerializer;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;

/**
 * @author C50216
 *
 */
@JsonInclude(Include.NON_NULL)
public class RewardDetailResp {

	private Date rewardAsAtDate;
	private int pointBalance;
	
	@JsonSerialize(using = JsonDateSerializer.class)
	@JsonInclude(Include.NON_NULL)
	public Date getRewardAsAtDate() {
		return rewardAsAtDate;
	}
	public void setRewardAsAtDate(Date rewardAsAtDate) {
		this.rewardAsAtDate = rewardAsAtDate;
	}
	public int getPointBalance() {
		return pointBalance;
	}
	public void setPointBalance(int pointBalance) {
		this.pointBalance = pointBalance;
	} 
			
}
