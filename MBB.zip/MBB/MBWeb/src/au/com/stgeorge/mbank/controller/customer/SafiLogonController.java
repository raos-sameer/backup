package au.com.stgeorge.mbank.controller.customer;


import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import au.com.stgeorge.digitalsec.logger.DigitalSecLogger;
import au.com.stgeorge.digitalsec.logger.DigitalSecLogggerVO;
import au.com.stgeorge.framework.common.logging.Logger;
import au.com.stgeorge.framework.common.model.User;
import au.com.stgeorge.framework.common.util.StringMethods;
import au.com.stgeorge.ibank.businessobject.BusinessException;
import au.com.stgeorge.ibank.businessobject.ForceChangePwdService;
import au.com.stgeorge.ibank.businessobject.ResourceException;
import au.com.stgeorge.ibank.businessobject.impl.ForceChangePwdServiceImpl;
import au.com.stgeorge.ibank.common.cache.IBankParams;
import au.com.stgeorge.ibank.evcrs.businessobject.CRSService;
import au.com.stgeorge.ibank.evcrs.businessobject.valueobject.CRSInfo;
import au.com.stgeorge.ibank.loanApplication.LoanApplicationDetail;
import au.com.stgeorge.ibank.loanApplication.util.LoanAppConstants;
import au.com.stgeorge.ibank.loanApplication.util.LoanAppUtil;
import au.com.stgeorge.ibank.messagecentre.util.MessageCentreConstants;
import au.com.stgeorge.ibank.messagecentre.valueobject.CustomerMessage;
import au.com.stgeorge.ibank.messagecentre.valueobject.MessageSearch;
import au.com.stgeorge.ibank.safi.businessobject.Safi2Service;
import au.com.stgeorge.ibank.safi.util.SafiConstants;
import au.com.stgeorge.ibank.safi.valueobject.SafiForensicInfo;
import au.com.stgeorge.ibank.service.valueobject.SafiRespVO;
import au.com.stgeorge.ibank.service.valueobject.SafiVO;
import au.com.stgeorge.ibank.servicestation.businessobject.ServiceStation;
import au.com.stgeorge.ibank.servicestation.businessobject.ServiceStationImpl;
import au.com.stgeorge.ibank.servicestation.businessobject.valueobject.ServiceStationVO;
import au.com.stgeorge.ibank.servicestation.util.ServicetationConstants;
import au.com.stgeorge.ibank.util.CommonBusinessUtil;
import au.com.stgeorge.ibank.valueobject.AutoApplyRetentionInfo;
import au.com.stgeorge.ibank.valueobject.Customer;
import au.com.stgeorge.ibank.valueobject.ForceChangePwd;
import au.com.stgeorge.ibank.valueobject.MsgCentreInfo;
import au.com.stgeorge.ibank.valueobject.NonFinTransactionDetails;
import au.com.stgeorge.ibank.valueobject.database.OriginsVO;
import au.com.stgeorge.ibank.valueobject.transfer.IBankCommonData;
import au.com.stgeorge.mbank.controller.IMBController;
import au.com.stgeorge.mbank.controller.SafiWebHelper;
import au.com.stgeorge.mbank.controller.SecureCodeHelper;
import au.com.stgeorge.mbank.model.common.IMBReq;
import au.com.stgeorge.mbank.model.common.IMBResp;
import au.com.stgeorge.mbank.model.common.ReqHeader;
import au.com.stgeorge.mbank.model.common.RespHeader;
import au.com.stgeorge.mbank.model.common.SplashPageResp;
import au.com.stgeorge.mbank.model.request.SecureCodeReq;
import au.com.stgeorge.mbank.model.response.ErrorResp;
import au.com.stgeorge.mbank.model.response.customer.LogonResp;
import au.com.stgeorge.mbank.session.MobileSession;
import au.com.stgeorge.mbank.session.MobileSessionImpl;
import au.com.stgeorge.mbank.util.MBAppHelper;
import au.com.stgeorge.mbank.util.MBAppUtils;
import au.com.stgeorge.mbank.util.MBAppValidator;
import au.com.stgeorge.mbank.util.ServiceConstants;
import au.com.stgeorge.mobilebank.businessobject.MobileBankService;
import au.com.stgeorge.mobilebank.businessobject.MobileMsgCntrService;
import au.com.stgeorge.perflogger.PerformanceLogger;

import com.fasterxml.jackson.databind.ObjectMapper;

@Controller
@RequestMapping("/safi")
public class SafiLogonController implements IMBController{

	@Autowired
	private MBAppValidator mbAppValidator;

	@Autowired
	private MBAppHelper mbAppHelper;
	
	@Autowired
    private PerformanceLogger perfLogger;
	
	@Autowired
	private SecureCodeHelper secureCodeHelper;
	
	@Autowired
    private CRSService crsService;
	
	@Autowired
	private LogonHelper logonHelper;
	
	private static final String CRS_SPLASH_TYPE = "CRS";
	
	@Autowired
	MobileBankService mobileBankService;
	
	@Autowired
	private MobileMsgCntrService msgCntrService;
	
	@Autowired
	private ServiceStation serviceStationService;
	
	@Autowired
	ForceChangePwdService forcePwdService;
	
	@Autowired
    private Safi2Service safi2Service;
	
	@Autowired
    private DigitalSecLogger digitalSecurityLogger;
	
	public static final String SMS_RESET_STATUS = "SMSRESET";
	
	@RequestMapping(method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE, value = "reqsecurecode")
	@ResponseBody
	public IMBResp reqSecureCode(HttpServletRequest httpRequest, @RequestBody final SecureCodeReq request) {
		Logger.debug("SAFI : SafiLogonController - reqSecureCode(). Request: " + request, this.getClass());
		String logName = startPerformanceLog(httpRequest);
		MobileSession mobileSession = null;
		IBankCommonData commonData = null;
		try {
			mobileSession = mbAppHelper.getMobileSession(httpRequest);	
			mobileSession.getSessionContext(httpRequest);
			commonData = new MBAppHelper().populateIBankCommonData(mobileSession, httpRequest);
			
			if(isLoggedOnStateError(mobileSession.getLoggedonState()))
			{	
				throw new BusinessException(BusinessException.SYSTEM_UNAVILABLE);
			}
			
			validateRequestHeader(request.getHeader(), httpRequest);
			ErrorResp errorResponse = validate(request, httpRequest);// validate json
			if (errorResponse.hasErrors())
				return errorResponse;
			
			if (ServiceConstants.SAFI_LOGON_TRAN_CODE != request.getTranType()){
				return MBAppUtils.createInvalid2FATransactionTypeResponse(ServiceConstants.SAFI_LOGON);
			}
			
			return secureCodeHelper.reqSecureCode(commonData, mobileSession, null, new NonFinTransactionDetails() {}, request, ServiceConstants.SAFI_LOGON, httpRequest);
			
		} catch (ResourceException e) {
			Logger.error("ResourceException in SafiLogonController - reqSecureCode() - [key: " + e.getKey() + "], GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());
			mobileSession.removeSecureCodeDetails();
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.SYSTEM_UNAVILABLE, ServiceConstants.SAFI_LOGON, httpRequest);
		}
		catch (Exception e) {
			Logger.error("Exception SafiLogonController - reqSecureCode(): GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "]", e, this.getClass());
			mobileSession.removeSecureCodeDetails();
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.GENERIC_ERROR, ServiceConstants.SAFI_LOGON, httpRequest);
		} finally {
			endPerformanceLog(logName);
		}

	}	
	
	@RequestMapping(method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE, value = "verifysecurecode")
	@ResponseBody
	public IMBResp verifySecureCode(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse,@RequestBody final SecureCodeReq request) {
		
		String logName = startPerformanceLog(httpServletRequest);
		MobileSession mobileSession = new MobileSessionImpl();
		ObjectMapper mapper = new ObjectMapper();
		int unreadMsgCount = -1;
		DigitalSecLogggerVO digitalSecLoggerVO = new DigitalSecLogggerVO();
		
		try {
			Logger.debug("SAFI : SafiController - verifySecureCode(). Request: " + mapper.writeValueAsString(request), this.getClass());

			mobileSession.getSessionContext(httpServletRequest);
			IBankCommonData commonData = new MBAppHelper().populateIBankCommonData(mobileSession, httpServletRequest);
			User user=mobileSession.getUser();
			String devicePrint = mobileSession.getSafiLogonInfo()!= null ?mobileSession.getSafiLogonInfo().getDevicePrint():null;
			validateRequestHeader(request.getHeader(), httpServletRequest);
			ErrorResp errorResponse = validate(request, httpServletRequest);// validate json
			if (errorResponse.hasErrors())
				return errorResponse;
			
			if (ServiceConstants.SAFI_LOGON_TRAN_CODE != request.getTranType()){
				return MBAppUtils.createInvalid2FATransactionTypeResponse(ServiceConstants.SAFI_LOGON);
			}
			errorResponse = secureCodeHelper.verifySecureCode(commonData, mobileSession, new NonFinTransactionDetails() {},
					request, ServiceConstants.SAFI_LOGON, httpServletRequest);
			
			//18E4 - Safi Forensic logging
			SafiForensicInfo safiForensicInfo = new SafiForensicInfo();
			boolean isMobileApp = ((logonHelper.loadCordova(httpServletRequest)) == -1) ? false:true;
			safiForensicInfo.setSafiRiskScore(mobileSession.getSafiLogonInfo()!= null ? mobileSession.getSafiLogonInfo().getSafiRiskScore() :"");
			safiForensicInfo.setSafiRuleName(mobileSession.getSafiLogonInfo()!= null ? mobileSession.getSafiLogonInfo().getSafiRuleName() :"");
			if(isMobileApp)
				safiForensicInfo.setSafiSdkDevicePrint(devicePrint != null ? devicePrint : "");
			
			digitalSecLoggerVO.setTranName(DigitalSecLogger.SAFI_APP_LOGON);
			digitalSecLoggerVO.setValues(logonHelper.toDigitalSecuritySafiLog(safiForensicInfo));
			digitalSecLoggerVO.setCommonLogData(logonHelper.getCommonLogData(null,commonData,null));
			digitalSecLoggerVO.setUserAgent(commonData.getUserAgent());
			
			
			if (errorResponse.hasErrors()) {
				if(errorResponse.getStatus() ==  ErrorResp.STATUS_2FA_SUSPENDED){
					notifyCallAndUpdateCookie(httpServletRequest, httpServletResponse, devicePrint,commonData, mobileSession,false);
				}
				
				//18E4 : Safi forensic logging for challenge failures
				digitalSecLoggerVO.setStatus(DigitalSecLogger.SAFI_CHALLENGE_STATUS);
				digitalSecurityLogger.log(digitalSecLoggerVO);
				
				return errorResponse;
			} else{

				mobileSession.setSafiLast2FASuccessTime(new Date());
				
				notifyCallAndUpdateCookie(httpServletRequest, httpServletResponse, devicePrint, commonData,mobileSession,true);
								
				mobileSession.removeSafiLogonInfo();
				
				Customer customer=mobileSession.getCustomer();
				if ( customer == null || StringMethods.isEmptyString( customer.getGcis() ) )
				{
					customer = mobileBankService.getCustomer(commonData);
					mobileSession.setCustomer(customer);
					commonData.setCustomer(customer);
				}
				
				mobileSession.setLoggedonState(LogonHelper.LOGGEDON_STATE_COMPLETE);
				
				//18E4 : Safi forensic logging for challenge Success
				digitalSecLoggerVO.setStatus(DigitalSecLogger.SUCCESS);
				digitalSecurityLogger.log(digitalSecLoggerVO);
				
				//check priority 
				
//				Splash page update MsgCount							
				Logger.debug("SAFI : Processing splashPageInfo", this.getClass());
				boolean isECorrespondenceSupported = CommonBusinessUtil.isECorrespondenceSupported(httpServletRequest);
				
				MsgCentreInfo msgCentreInfo= processMsgCentre(mobileSession.getOrigin(),customer.getGcis(),isECorrespondenceSupported);
				//List<Object> splashPageInfo= processMsgCentre(mbSession.getOrigin(),customer.getGcis(),isECorrespondenceSupported);
				List<MessageSearch> splashPageInfo = msgCentreInfo.getSplashPageInfo();
				     				
				if(splashPageInfo != null && !splashPageInfo.isEmpty()){
					MessageSearch messageSearch = (MessageSearch)splashPageInfo.get(0);
					mobileSession.setSplashInfoMsg(messageSearch);
					//unreadMsgCount = (Integer)splashPageInfo.get(0);
					unreadMsgCount = msgCentreInfo.getUnreadMessageCount();
					Logger.debug("SAFI : splashPageInfo - unreadMsgCount: "+unreadMsgCount, this.getClass());
				}
				
				List<AutoApplyRetentionInfo>  digiRetInfoList= 			msgCentreInfo.getApplyRetentionInfo();
				AutoApplyRetentionInfo autoApplyRetentionInfo =null;
				
				
				if(digiRetInfoList!= null && digiRetInfoList.size()>0 ){
					try{
					 autoApplyRetentionInfo = digiRetInfoList.get(0);
				
					 Logger.debug("SAFI : Auto Apply retention info message seen: "+autoApplyRetentionInfo.getAccountNumber(), this.getClass());
					 
					 mobileSession.setAutoApplyRetentionInfo( autoApplyRetentionInfo); 
					}
					catch(Exception e){
						Logger.info("SAFI : LogonController:smplGetCustomer() autoApplyRetentionInfo is null", this.getClass());
					}
				}
				
				// call service to get ServiceAdminVo
			    long insertionPt = logonHelper.getInsertionPointCode(ServicetationConstants.DASHBOARD);
				ServiceStationVO servicestationVO=populateServiceMessage(insertionPt,ServiceStationImpl.CHANNEL_MOBILE, commonData);
				if(null!=servicestationVO)
				{
					mobileSession.setServiceStationDashboardMessage(servicestationVO.getServiceStationMsg());
				}

				IMBResp serviceResponse = logonHelper.populateResponse(customer,user,unreadMsgCount, httpServletRequest , httpServletResponse, false,servicestationVO,autoApplyRetentionInfo);				

				//Populate the ghost tile Response
				if(customer.getPreference() != null){
					
					//20E2-CSH -SBGEXP-8227 - added condition to check CSH/Efinance/Homeloan combination					
					int cshIndicator = LoanAppUtil.getCSHTileIndicator(customer.getPreference().getCcPLLoanInd());
					
					if(customer.getPreference().getCcPLLoanInd() == LoanAppConstants.PRF_CCLOANIND_EFINANCE || customer.getPreference().getCcPLLoanInd() == LoanAppConstants.PRF_CCLOANIND_EFINANCE_HOMELOAN_BOTH
							|| cshIndicator == LoanAppConstants.PRF_CCLOANIND_EFINANCE
							|| cshIndicator == LoanAppConstants.PRF_CCLOANIND_EFINANCE_HOMELOAN_BOTH){						
						LoanApplicationDetail loanAppDetail = logonHelper.populateLoanApplicationDetail(commonData,serviceResponse);
						mobileSession.setLoanApplicationDetail(loanAppDetail);

					}
					
					//20E2-CSH -SBGEXP-8227 - populate the details for CSH tile
					if(cshIndicator == LoanAppConstants.PRF_CCLOANIND_CSH ||
							cshIndicator == LoanAppConstants.PRF_CCLOANIND_EFINANCE ||	
							cshIndicator == LoanAppConstants.PRF_CCLOANIND_HOMELOAN ||
							cshIndicator == LoanAppConstants.PRF_CCLOANIND_EFINANCE_HOMELOAN_BOTH) {
						Logger.debug("CSH : Populate CSH Tile. ", getClass());
						logonHelper.populateCSHApplicationDetail(commonData,serviceResponse);						 
					}
					
					//20E2-CSH -SBGEXP-8227 - added condition to check CSH/Efinance/Homeloan combination
					if(customer.getPreference().getCcPLLoanInd() == LoanAppConstants.PRF_CCLOANIND_HOMELOAN || customer.getPreference().getCcPLLoanInd() == LoanAppConstants.PRF_CCLOANIND_EFINANCE_HOMELOAN_BOTH
							|| cshIndicator == LoanAppConstants.PRF_CCLOANIND_HOMELOAN
							|| cshIndicator == LoanAppConstants.PRF_CCLOANIND_EFINANCE_HOMELOAN_BOTH){
						logonHelper.populateHomeLoanGhostTile(commonData, serviceResponse);
					}

				}

				//			Populate the SplashPage Response
				Logger.debug("SAFI : Before populate splashPageInfo", this.getClass());
				List<Object> populateSplashPageResult=null;
				if(splashPageInfo != null && splashPageInfo.size() > 0 && splashPageInfo.get(0) != null){
					//populateSplashPage(splashPageInfo, mbSession.getOrigin(), customer, ibankCommonData, serviceResponse);
					populateSplashPageResult=populateSplashPage(splashPageInfo, mobileSession.getOrigin(), customer, commonData, serviceResponse);
					if(null!= populateSplashPageResult){
						boolean crsSplash = (boolean) populateSplashPageResult.get(0);
						Logger.debug("SAFI : After actResetPwdSecNum populateSplashPage : crsSlpash :"+crsSplash , this.getClass());
						if(crsSplash){
							if(populateSplashPageResult.size() > 1){
								mobileSession.setCrsRegistrationNumber((String)populateSplashPageResult.get(1));
								Logger.debug("SAFI : In actResetPwdSecNum CredentialController :: CRS Flag "+(String)populateSplashPageResult.get(1), this.getClass());
							}

							if(isCrsHardPrompt3(splashPageInfo)){
								Logger.debug("SAFI : This actResetPwdSecNum is hard prompt three ..Setting logged on state..", this.getClass());
								mobileSession.setLoggedonState(LogonHelper.LOGGEDON_STATE_CRS_HARD_PROMPT);
							}
						}
					}
				}			
			
				ForceChangePwd forceVO = forcePwdService.getStatus(commonData);
				mobileSession.setForceChangePwd(forceVO);
				String forceStatus = forcePwdService.getStatusFromVO(commonData, forceVO);

				Boolean smsRest = (Boolean) user.getAttribute(SMS_RESET_STATUS);
				String autoInitSts=(String)user.getAttribute(IBankParams.REG_STATUS);
				
				if(!user.isStatusMustChangePassword() &&  !(smsRest != null && smsRest.booleanValue()) && !(!StringMethods.isEmptyString(autoInitSts) && autoInitSts.equalsIgnoreCase(IBankParams.AUTO_INIT_ADMIN))){
					Logger.info("SAFI : SafiLogonController.verifySecureCode(): forceChangePwd gcis: " + customer.getGcis() + " status = " + forceStatus, SafiLogonController.class);
					((LogonResp) serviceResponse).setForceChangePwdStatus(forceStatus);
					((LogonResp) serviceResponse).setRemSkipCount(forcePwdService.getRemSkipCount(forceVO, forceStatus,  mobileSession.getOrigin()));
					((LogonResp) serviceResponse).setSafiChallengeSuccess(true);
					mobileSession.setSecureCodeVerifiedTranName(ServiceConstants.REQ_2FA_PWDRESET);
					setLoggedStatus(mobileSession, forceStatus, customer);
				}
											
				Logger.info("SAFI : SAFIController  VerifySecureCode JSON Response :" + mapper.writeValueAsString(serviceResponse), this.getClass());
				RespHeader headerResp = populateResponseHeader(request.getHeader().getServiceName(), mobileSession);
				serviceResponse.setHeader(headerResp);
				return serviceResponse;

			}
			
		} catch (ResourceException e) {
			Logger.error("SAFI : Exception SafiLogonController - verifySecureCode(): GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "]", e, this.getClass());
			mobileSession.removeSecureCodeDetails();
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.SYSTEM_UNAVILABLE, ServiceConstants.SAFI_LOGON, httpServletRequest);
		} 
		catch (Exception e) {
			Logger.error("SAFI : Exception SafiLogonController - verifySecureCode(): GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "]", e, this.getClass());
			mobileSession.removeSecureCodeDetails();
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.GENERIC_ERROR, ServiceConstants.SAFI_LOGON, httpServletRequest);
		} finally {
			endPerformanceLog(logName);
		}

	}	
	
	
//	Populate the SplashPage Response
	public List populateSplashPage(/*List<Object> splashPageInfo*/List<MessageSearch> splashPageInfo  , String origin, Customer customer, IBankCommonData ibankCommonData, IMBResp serviceResponse) throws au.com.stgeorge.framework.common.exception.ResourceException, BusinessException{
		Logger.debug("SAFI : Inside populateSplashPage, GCIS: "+customer.getGcis(), this.getClass());
		SplashPageResp splashPageResp = null;
		MessageSearch messageSearch = splashPageInfo.get(0);
		CRSInfo crsInfo = null;
		boolean showSplash=false;
		List populateSplashPageResult = null;
		boolean showHardPrompt3=false;
		
		//switch check for CRS Hard prompt
		if(!IBankParams.isSwitchOn(IBankParams.CRS_PRODUCT_READY_SWITCH) ){
			Logger.debug("SAFI : CRS Hard Prompt Switch is OFF :: Kindly do not populate splash resp", this.getClass());
					
		}else{
			if(MessageSearch.messageActionCRSList.contains(messageSearch.getMessageAction())){
				populateSplashPageResult = new ArrayList();
				//				Call 258
				try{				
					Logger.debug("SAFI : populateSplashPage CRS Update  ",  this.getClass());
					crsInfo = crsService.getCrsInfo(ibankCommonData);		
					CustomerMessage customerMessage = new CustomerMessage();
					customerMessage.setId(messageSearch.getCustMsgID());
					customerMessage.setMsgID(messageSearch.getMsgID());
					customerMessage.setModifiedBy(ibankCommonData.getCustomer().getGcis());
					customerMessage.setAppField1(messageSearch.getAppField1());
					customerMessage.setGcisNumber(ibankCommonData.getCustomer().getGcis());
					customerMessage.setExpiryDate(messageSearch.getCustMessageExpiry());
					Logger.debug("SAFI : 258 response & crsInfo  : "+crsInfo, this.getClass());
					if(crsInfo != null && !"X".equalsIgnoreCase(crsInfo.getRegistrationNumber())){
						Logger.debug("Inside populateSplashPage : ",this.getClass());
						crsService.updateMsgDeleteStatus(messageSearch,ibankCommonData);
					}
					else{
						if(MessageCentreConstants.SPLASH_ACTION_CRS_HARD_PROMPT_3.equalsIgnoreCase(messageSearch.getMessageAction())){
							Logger.debug("SAFI : Hard prompt 3",this.getClass());
							showHardPrompt3 = true;
							if(messageSearch.getXrefId() == null){
								Logger.debug("SAFI : Inside XrefID NULL::>>", this.getClass());
								crsService.updateCRSPromptDetails(ibankCommonData, customerMessage, messageSearch.getMessageAction());
								showSplash=true;
								((LogonResp) serviceResponse).setCustomer(null);
								((LogonResp) serviceResponse).setFirstName(customer.getFirstName());
							}
						}
						else{
							Logger.debug("SAFI : HP2 or Hp1", this.getClass());
							splashPageResp = new SplashPageResp();
							String hardPromptType = getHardPrompt(messageSearch.getMessageAction());
							splashPageResp.setSplashType(CRS_SPLASH_TYPE); // TODO Remove Hardcode
							splashPageResp.setPromptType(hardPromptType);
							/*if(MessageCentreConstants.SPLASH_ACTION_CRS_HARD_PROMPT_1.equalsIgnoreCase(messageSearch.getMessageAction())){
								Logger.debug("Inside HP1",  this.getClass());
								if(messageSearch.getCustMessageExpiry() != null){
									splashPageResp.setExpiryDate(logonHelper.convertExpiryDateForCRSPrompt(messageSearch.getCustMessageExpiry()));
								}else{
									splashPageResp.setExpiryDate(logonHelper.getExpiryDateForCRSPrompt(messageSearch.getAppField1()!=null?Integer.valueOf(messageSearch.getAppField1()).intValue():0));
						    	}							}else{

								Logger.debug("Inside HP2 or HP3",  this.getClass());
								splashPageResp.setExpiryDate(logonHelper.convertExpiryDateForCRSPrompt(messageSearch.getCustMessageExpiry()));
							}*/
							Date expiryDate = customerMessage.getExpiryDate();
							Logger.debug("SAFI : ExpiryDate in customer message is "+expiryDate,getClass());
							Logger.debug("SAFI : XrefID::>>"+messageSearch.getXrefId(), this.getClass());
							if(messageSearch.getXrefId() == null){
								Logger.debug("Inside XrefID NULL::>>", this.getClass());
								splashPageResp.setShowCRSAsTile(false);
								expiryDate = crsService.updateCRSPromptDetails(ibankCommonData, customerMessage, messageSearch.getMessageAction());
								showSplash=true;
							}
							else{
								Logger.debug("SAFI : Inside XrefID NOT NULL::>>", this.getClass());
								splashPageResp.setShowCRSAsTile(true);
							}
							Logger.debug("SAFI : Inside HP2 or HP3",  this.getClass());
							splashPageResp.setExpiryDate(logonHelper.convertExpiryDateForCRSPrompt(expiryDate));
						}
															
					}
				} catch(BusinessException e){
					Logger.warn("SAFI : Business Exception:" + e.getKey() + " Mesage : "+ e.getMessage(), e, this.getClass());
					//saveError(getServletRequest(), e.getKey());		
					splashPageResp = null;		
				}						
				if(serviceResponse != null && serviceResponse instanceof LogonResp){				
					if(null!=customer){
						Logger.debug("SAFI : Setting customer type ::"+customer.getCustTypeInd(), this.getClass());
						((LogonResp) serviceResponse).setCustTypeInd(customer.getCustTypeInd());
					}
					if(((LogonResp) serviceResponse).getCustomer() != null && null!= splashPageResp){
						Logger.debug("SAFI : Setting the SplashPageResp in LogonResp", this.getClass());
						((LogonResp) serviceResponse).getCustomer().setSplashPage(splashPageResp);
						
					}else if(null == splashPageResp && showHardPrompt3){
						Logger.debug("SAFI : Setting showHardPrompt as true b'cuz its HP3", this.getClass());
						((LogonResp) serviceResponse).setShowHardPrompt(showHardPrompt3);
					}
				}
				populateSplashPageResult.add(showSplash);
			}
			
			
			if(null!= crsInfo){
				populateSplashPageResult.add(crsInfo.getRegistrationNumber());
				Logger.debug("SAFI : In populateSplashPage :: flag value ::"+crsInfo.getRegistrationNumber(), this.getClass());
			}	
			
		}
		return populateSplashPageResult;
		
	}	

	private String getHardPrompt(String msgActionType ){		
		String hardPromptType =  "";
		switch(msgActionType){
		case "C1":
			hardPromptType = "H1";		   
			return hardPromptType;
		case "C2":
			hardPromptType = "H2";	
			return hardPromptType;
		case "C3":
			hardPromptType = "H3";	
			return hardPromptType;
		default:
			return hardPromptType;
		}
	}
	
	public boolean isCrsHardPrompt3(/*List<Object>*/ List<MessageSearch> splashPageInfo){
		Logger.debug("SAFI : Inside isCrsHardPrompt3", this.getClass());
		boolean isCrsHardPrompt3=false;
		if(splashPageInfo.size() > 0){
			
			MessageSearch messageSearch = /*(MessageSearch)*/splashPageInfo.get(0);			
			if(MessageCentreConstants.SPLASH_ACTION_CRS_HARD_PROMPT_3.equalsIgnoreCase(messageSearch.getMessageAction())){
				isCrsHardPrompt3 = true;
			}			
		}
		
		return isCrsHardPrompt3;
	}
	
	private /*List<Object>*/ MsgCentreInfo processMsgCentre(String origin, String gcisNum,boolean isECorrespondenceSupported) throws BusinessException, ResourceException{
		OriginsVO originVO= IBankParams.getOrigin(origin);
		msgCntrService.addBrandCustMsg(originVO.getBankName(),gcisNum);
		return msgCntrService.getCustomerMessageInfo(gcisNum,isECorrespondenceSupported,origin);				
	}
	
	private ServiceStationVO populateServiceMessage(long insertionPoint,String channel, IBankCommonData commonData)
	{
		ServiceStationVO serviceStationAdminVo=null;
		try
		{
		 serviceStationAdminVo= serviceStationService.getServiceMessage(insertionPoint, ServiceStationImpl.CHANNEL_MOBILE, commonData);			
		}
		 catch(BusinessException ex){
			Logger.error("SAFI : An error occurred while getting service station message for mobile accoutn details", ex, this.getClass());
		}
		return serviceStationAdminVo;
	}
	
	private boolean isLoggedOnStateError(String loggedOnState){

		if(!LogonHelper.LOGGEDON_STATE_SAFI_CHALLENGE.equalsIgnoreCase(loggedOnState)){
			return true;
		}else{
			return false;
		}
	}

	private void notifyCallAndUpdateCookie(HttpServletRequest httpServletRequest,HttpServletResponse httpServletResponse ,String devicePrint,IBankCommonData commonData,MobileSession mobileSession,Boolean status2FA) throws BusinessException{
		//SAFI Notify Call
		boolean isMobileApp = ((logonHelper.loadCordova(httpServletRequest)) == -1) ? false:true;
		Logger.debug("SAFI : notifyCallAndUpdateCookie(): isMobileApp: "+isMobileApp, this.getClass());
		SafiVO safiVO = SafiWebHelper.populateSafiVOForNotify(httpServletRequest,commonData,mobileSession,status2FA,isMobileApp,SafiConstants.DEFAULT_TIME_LAST2FA_SUCCESS);
		SafiRespVO safiRespVO = safi2Service.notifySafiForLogon(commonData, safiVO);
		//create or update cookie and save
		if(safiRespVO != null){
			Cookie pmdata2 = SafiWebHelper.readCookies(httpServletRequest);
			Cookie newCookie = SafiWebHelper.createOrUpdatePmdata2Cookie(httpServletRequest,pmdata2,safiRespVO.getDeviceToken());
			Logger.debug("SAFI : Setting PMDATA2 cookie in VerifySecureCode resp : value :"+ newCookie.getValue(), this.getClass());
			httpServletResponse.addCookie(newCookie);
		}
		
	}
	
	
	@Override
	public void validateRequestHeader(ReqHeader headerReq,
			HttpServletRequest request) throws BusinessException {
		mbAppValidator.validateRequestHeader(headerReq,  request);
		
	}

	@Override
	public ErrorResp validate(IMBReq serviceRequest,
			HttpServletRequest httpRequest) throws BusinessException {
		return mbAppValidator.validate(serviceRequest, httpRequest);
	}

	@Override
	public RespHeader populateResponseHeader(String serviceName,
			MobileSession mobileSession) {
		return mbAppHelper.populateResponseHeader(serviceName,mobileSession);
	}

	private String startPerformanceLog(HttpServletRequest httpRequest) {
		perfLogger.startAllLogs();
		String logName = MBAppUtils.getLogName(httpRequest);
		perfLogger.startLog(logName);
		return logName;
	}

	private void endPerformanceLog(String logName) {
		perfLogger.endLog(logName);
		perfLogger.endAllLogs();
	}
	
	
	private void setLoggedStatus (MobileSession session, String status, Customer customer){

		if (ForceChangePwdServiceImpl.FORCE_PWD_SHOW_SKIP.equalsIgnoreCase(status) || ForceChangePwdServiceImpl.FORCE_PWD_TARGETED.equalsIgnoreCase(status)){
			session.setLoggedonState(LogonHelper.LOGGEDON_STATE_FORCE_PWDCHANGE_2FA_EXEMPT);
		}
	}	
	
	
}
