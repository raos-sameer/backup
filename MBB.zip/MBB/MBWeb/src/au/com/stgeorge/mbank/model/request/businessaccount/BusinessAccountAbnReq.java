package au.com.stgeorge.mbank.model.request.businessaccount;

import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.Length;
import org.hibernate.validator.constraints.NotEmpty;

import au.com.stgeorge.ibank.businessobject.BusinessException;
import au.com.stgeorge.mbank.model.common.IMBReq;
import au.com.stgeorge.mbank.model.common.ReqHeader;

public class BusinessAccountAbnReq implements IMBReq{

	@NotEmpty(message = "" + BusinessException.BUSINESS_ACCOUNT_NOT_VALID_ABN)
	@Length(min = 11, max = 11, message = "" + BusinessException.BUSINESS_ACCOUNT_NOT_VALID_ABN)
	@Pattern(regexp = "[\\d]{11}", message = "" + BusinessException.BUSINESS_ACCOUNT_NOT_VALID_ABN)
	private String abnNumber; 
	
	private ReqHeader header;
	
	public ReqHeader getHeader()
	{
		return header;
	}
	public void setHeader(ReqHeader header)
	{
		this.header = header;
	}
	public String getAbnNumber() {
		return abnNumber;
	}
	public void setAbnNumber(String abnNumber) {
		this.abnNumber = abnNumber;
	}
	
}
