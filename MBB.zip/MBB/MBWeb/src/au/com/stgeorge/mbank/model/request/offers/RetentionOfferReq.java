package au.com.stgeorge.mbank.model.request.offers;

import javax.validation.constraints.NotNull;

import org.apache.commons.lang.builder.ReflectionToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;

import au.com.stgeorge.ibank.businessobject.BusinessException;
import au.com.stgeorge.mbank.model.common.IMBReq;
import au.com.stgeorge.mbank.model.common.ReqHeader;

/**
 * Transfer request
 * 
 * @author C38854
 * 
 */
public class RetentionOfferReq implements IMBReq {

	/**
	 * 
	 */
	private static final long serialVersionUID = -4723751125232692028L;
	
	// @Valid TODO
	private ReqHeader header;

	@NotNull(message = "" + BusinessException.WSVC_INVALID_INPUT_PARAM)
	private String leadId;
	
	@NotNull(message = "Invalid offer type")
	private String offerType;
		
	public ReqHeader getHeader() {
		return header;
	}

	public void setHeader(ReqHeader header) {
		this.header = header;
	}
	
	@Override
	public String toString() {
		return ReflectionToStringBuilder.toString(this, ToStringStyle.MULTI_LINE_STYLE);
	}

	public String getOfferType() {
		return offerType;
	}

	public void setOfferType(String offerType) {
		this.offerType = offerType;
	}

	public String getLeadId() {
		return leadId;
	}

	public void setLeadId(String leadId) {
		this.leadId = leadId;
	}
}
