package au.com.stgeorge.mbank.controller.statements;

import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.AbstractController;

import au.com.stgeorge.framework.common.logging.Logger;
import au.com.stgeorge.ibank.businessobject.BusinessException;
import au.com.stgeorge.ibank.businessobject.ProofOfStmtService;
import au.com.stgeorge.ibank.businessobject.ResourceException;
import au.com.stgeorge.ibank.util.PDFStatmentUtil;
import au.com.stgeorge.ibank.valueobject.Account;
import au.com.stgeorge.ibank.valueobject.PDFStore;
import au.com.stgeorge.ibank.valueobject.Statistic;
import au.com.stgeorge.ibank.valueobject.TransactionHistory;
import au.com.stgeorge.ibank.valueobject.transfer.IBankCommonData;
import au.com.stgeorge.mbank.session.MobileSession;
import au.com.stgeorge.mbank.util.MBAppHelper;
import au.com.stgeorge.mbank.util.MBAppUtils;
import au.com.stgeorge.perflogger.PerformanceLogger;
import au.com.stgeorge.security.util.StringMethods;

/**
 * @author C50216
 * 
 */

@Controller
public class ViewProofOfStmtController extends AbstractController
{

	private static final String PROOF_ACCOUNT_BALANCE = "acctBalance";
	private static final String TRANSACTION_LISTING = "transactionListing";

	@Autowired
	private MBAppHelper mbAppHelper;

	@Autowired
	private PerformanceLogger perfLogger;

	@Autowired
	private ProofOfStmtService proofOfStmtService;

	@Override
	protected ModelAndView handleRequestInternal(HttpServletRequest request, HttpServletResponse response) throws Exception
	{
		Logger.debug("ViewProofOfStmtController - handleRequestInternal(). Request: " + request, this.getClass());

		Integer errorCode = null;
		perfLogger.startAllLogs();
		String logName = MBAppUtils.getLogName(request);
		perfLogger.startLog(logName);

		String actionType = request.getParameter("actionType");
		
		String token = request.getParameter("token");

		try
		{
			if ((PROOF_ACCOUNT_BALANCE.equalsIgnoreCase(actionType) || TRANSACTION_LISTING.equalsIgnoreCase(actionType)) && !StringMethods.isEmptyString(token) )
			{
				
				PDFStore pdfStore = proofOfStmtService.getPDFDocTokenDetails(token);
				
				if(pdfStore == null){
					throw new BusinessException(BusinessException.PDF_STATEMENT_NOT_FOUND);
				}
				byte[] pdfData = pdfStore.getPdfData();
				String pdfFileName = pdfStore.getPdfFilename();
				
				proofOfStmtService.deletePDFDocTokenDetails(token);
				
				response.setContentType("application/pdf");
				response.setHeader("Content-Disposition", "attachment;filename=" + pdfFileName + ".pdf");
				response.setContentLength(pdfData.length);
				response.getOutputStream().write(pdfData, 0, pdfData.length);

				response.getOutputStream().flush();
				response.getOutputStream().close();
				response.flushBuffer();

				return null;
			}
			else if (PROOF_ACCOUNT_BALANCE.equalsIgnoreCase(actionType))
			{
				processProofAccountBalance(request, response);
				return null;
			}			
			else if (TRANSACTION_LISTING.equalsIgnoreCase(actionType))
			{
				processTransactionListing(request, response);
				return null;
			}

		} catch (BusinessException be)
		{
			if (be.getKey() == BusinessException.PDF_STATEMENT_NOT_FOUND)
			{

				try
				{
					response.setContentType("application/pdf");
					response.setHeader("Content-Disposition", "attachment;filename=NoStatement.pdf");
					OutputStream os = response.getOutputStream();
					byte[] buf = new byte[8192];
					InputStream is = getServletContext().getResourceAsStream("/WEB-INF/pdf/" + mbAppHelper.getOrigin(request) + "/NoStatement.pdf");
					int c = 0;
					while ((c = is.read(buf, 0, buf.length)) > 0)
					{
						os.write(buf, 0, c);
						os.flush();
					}
					os.close();
					is.close();

				} catch (Exception e)
				{
					errorCode = be.getKey();
					Logger.error("viewPdf stmt error ", this.getClass());
				}

			} else
			{
				errorCode = be.getKey();
			}
		} catch (ResourceException re)
		{
			errorCode = re.getKey();
		} catch (Exception ex)
		{
//			ex.printStackTrace();
			Logger.error("Error : " , ex , this.getClass());
			errorCode = BusinessException.GENERIC_ERROR;
		} finally
		{
			perfLogger.endLog(logName);
			perfLogger.endAllLogs();
		}

		if (errorCode != null)
		{
			request.setAttribute("errorCode", errorCode);
			request.setAttribute(MBAppHelper.HTTP_ORIGIN_ATTRIBUTE, mbAppHelper.getOrigin(request));
			request.getRequestDispatcher("/jsp/error/serviceError.jsp").forward(request, response);
		}

		return null;
	}

	protected ModelAndView processProofAccountBalance(HttpServletRequest request, HttpServletResponse response) throws BusinessException, ResourceException,
			Exception
	{

		String actionType = request.getParameter("actionType");

		String accts = request.getParameter("accts");

		if (!PROOF_ACCOUNT_BALANCE.equalsIgnoreCase(actionType) || StringMethods.isEmptyString(accts))
		{
			return null;
		}

		MobileSession mbSession = mbAppHelper.getMobileSession(request);
		Logger.info("processProofAccountBalance(). Accounts : " + accts, this.getClass());

		String[] acctSelList = accts.split(",");

		IBankCommonData commonData = mbAppHelper.populateIBankCommonData(mbSession, request);

		ArrayList<Account> selectedAcctList = new ArrayList<Account>();

		for (String index : acctSelList)
		{

			if (!StringMethods.isNumber(index))
			{
				Logger.error("Invalid Index Data : " + index, this.getClass());
				throw new BusinessException(BusinessException.SYSTEM_UNAVILABLE, "Invalid Index Data : " + index);
			}
			Account acct = mbAppHelper.getAccountFromCustomer(commonData.getCustomer(), Integer.parseInt(index));
			if (acct != null)
				selectedAcctList.add(acct);
		}

		Date todayDate = new Date();
		String reportDate = PDFStatmentUtil.getReportDate(todayDate);

		String pdfFileName = PDFStatmentUtil.getAccountBalanceFileName(todayDate);

		byte[] pdfData = proofOfStmtService.generateAccountBalancePdf(commonData.getCustomer(), selectedAcctList, reportDate, commonData.getOrigin());

		response.setContentType("application/pdf");
		response.setHeader("Content-Disposition", "attachment;filename=" + pdfFileName + ".pdf");
		response.setContentLength(pdfData.length);
		response.getOutputStream().write(pdfData, 0, pdfData.length);

		response.getOutputStream().flush();
		response.getOutputStream().close();
		response.flushBuffer();
		
		//GDW Statistics log
		proofOfStmtService.makeStatisticsLog(commonData, selectedAcctList, Statistic.PROOF_OF_BALANCE, null); 
		
		return null;
	}
	
	protected ModelAndView processTransactionListing(HttpServletRequest request, HttpServletResponse response) throws BusinessException, ResourceException,
	Exception
	{
	
		String actionType = request.getParameter("actionType");
		
		String accountIndex = request.getParameter("accountIndex");
		
		String transPeriod = request.getParameter("transPeriod");
		
		if (!TRANSACTION_LISTING.equalsIgnoreCase(actionType) || StringMethods.isEmptyString(accountIndex))
		{
			return null;
		}
		
		if (!StringMethods.isNumber(accountIndex))
		{
			Logger.error("Invalid Index Data : " + accountIndex, this.getClass());
			throw new BusinessException(BusinessException.SYSTEM_UNAVILABLE, "Invalid Index Data : " + accountIndex);
		}
		
		if (!StringMethods.isNumber(transPeriod))
		{
			Logger.error("Transaction Period : " + transPeriod, this.getClass());
			throw new BusinessException(BusinessException.SYSTEM_UNAVILABLE, "Transaction Period : " + transPeriod);
		}
		
		MobileSession mbSession = mbAppHelper.getMobileSession(request);
		Logger.info("processTransactionListing(). Account : " + accountIndex, this.getClass());
		
		IBankCommonData commonData = mbAppHelper.populateIBankCommonData(mbSession, request);
		
		
		Account selectedAcct = mbAppHelper.getAccountFromCustomer(commonData.getCustomer(), Integer.parseInt(accountIndex));
		
		Date todayDate = new Date();
		
		TransactionHistory transactionHistory = proofOfStmtService.fetchTransactionHistory(selectedAcct, commonData, Integer.parseInt(transPeriod));
		
		String pdfFileName = PDFStatmentUtil.getTransactionListingFileName(selectedAcct, todayDate);
		
		byte[] pdfData = proofOfStmtService.generateTransactionListingPdf(commonData.getCustomer(), selectedAcct, transactionHistory, todayDate, Integer.parseInt(transPeriod), commonData.getOrigin());
		
		response.setContentType("application/pdf");
		response.setHeader("Content-Disposition", "attachment;filename=" + pdfFileName + ".pdf");
		response.setContentLength(pdfData.length);
		response.getOutputStream().write(pdfData, 0, pdfData.length);
		
		response.getOutputStream().flush();
		response.getOutputStream().close();
		response.flushBuffer();
		
		List<Account> selectedAccountList = new ArrayList<Account>();
		selectedAccountList.add(selectedAcct);
		//GDW Statistics log
		proofOfStmtService.makeStatisticsLog(commonData, selectedAccountList, Statistic.PROOF_OF_TRANSACTION, transPeriod);
		
		return null;
	}
}
