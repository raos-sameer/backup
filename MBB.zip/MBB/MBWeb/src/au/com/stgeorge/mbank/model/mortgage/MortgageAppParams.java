package au.com.stgeorge.mbank.model.mortgage;

import java.util.Date;
import java.util.List;

import au.com.stgeorge.ibank.valueobject.LabelValueVO;
import au.com.stgeorge.ibank.valueobject.mortgage.PropertyInsightDetails;
import au.com.stgeorge.mbank.util.JsonDateTimeSerializer;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;

public class MortgageAppParams {
	
	//DMCodes
	private String helpDeskPhone;
	private String callCentreNumber;
	private String standardCCCNumber;
	private String qasUrl;
	private String canRetrievalURL;
	private String resetPwdURL;
	private String updateContactUrl;
	private String origin;
	private String originName;
	private String keyboardAmountType;   
	private String keyboardNumType;
	private Date systemDate;
	private Integer maxEntries;
	private String dtmUrl;
	private String lpSiteId;
	private String lpAppKey;
	private Boolean existingCustomerSwitch;
	
	//18E4 
	private Boolean refinNewAppSwitch;
	private Boolean refinRetrievalSwitch;
	private Boolean dtmLoanAttributesSwitch;
	
	//19E1
	private Boolean mortgageDocUploadSwitch;
	private List<String> creditCheckSwitchOff;
	
	private String deviceType;
	
	//19E2
	private Boolean appDynamicsDMSwitch;
	private Boolean appDynamicsMBSwitch;
	
	//DMReferenceData
	private List<LabelValueVO> title;
	private List<LabelValueVO> maritalStatus;
	private List<LabelValueVO> maritalStatusJoint;
	private List<LabelValueVO> frequency;
	private List<LabelValueVO> expenseFrequency;
	private List<LabelValueVO> repaymentFrequency;
	private List<LabelValueVO> employmentType;
	private List<LabelValueVO> bankBrand;
	private List<LabelValueVO> bankBrandRefinance;
	private List<LabelValueVO> customerSituation;
	//private List<LabelValueVO> incomeType;
	private List<LabelValueVO> incomeTypePension;
	private List<LabelValueVO> incomeTypeOther;
	private List<LabelValueVO> liabilityType;
	private List<LabelValueVO> liabilityTypeOther;
	private List<LabelValueVO> expenseType;
	private List<LabelValueVO> assetType;
	private List<LabelValueVO> incomeCategory;
	private List<LabelValueVO> assetCategory;
	private List<LabelValueVO> expenseCategory;
	private List<LabelValueVO> liabilityCategory;
	private List<LabelValueVO> repaymentType;
	//private List<LabelValueVO> loanPurpose;
	//private List<LabelValueVO> loanType;
	
	private List<LabelValueVO> propertyType;
	
	// 18E4- refinance property types
	
	private List<LabelValueVO> propertyTypeRefinance;
	private Integer refiLVRIntOnly;
	private Integer refiLVRPAndI;
	private String minBorrowAmt;
	private Integer clientTimeout;
	
	private List<String> spinnerText;
	//private List<LabelValueVO> employmentIndustry;
	private List<LabelValueVO> employmentRole;
	
	private boolean showConfitti;
	
	private PropertyInsightDetails propertyInsightDetails;

	//19E4
	private boolean dmApraSwitch;
	
	//20E2
	private boolean dmNewLoanTermSwitch;
	
	//20E4
	private boolean lpMessagingSwitch;
	
	private boolean lpNativeOldApp;
	

	
	public boolean isDmApraSwitch() {
		return dmApraSwitch;
	}

	public void setDmApraSwitch(boolean dmApraSwitch) {
		this.dmApraSwitch = dmApraSwitch;
	}

	public String getHelpDeskPhone() {
		return helpDeskPhone;
	}

	public String getCallCentreNumber() {
		return callCentreNumber;
	}

	public void setCallCentreNumber(String callCentreNumber) {
		this.callCentreNumber = callCentreNumber;
	}

	public String getStandardCCCNumber() {
		return standardCCCNumber;
	}

	public void setStandardCCCNumber(String standardCCCNumber) {
		this.standardCCCNumber = standardCCCNumber;
	}

	public Integer getMaxEntries() {
		return maxEntries;
	}

	public void setMaxEntries(Integer maxEntries) {
		this.maxEntries = maxEntries;
	}
	public List<LabelValueVO> getLiabilityTypeOther() {
		return liabilityTypeOther;
	}

	public void setLiabilityTypeOther(List<LabelValueVO> liabilityTypeOther) {
		this.liabilityTypeOther = liabilityTypeOther;
	}

	public List<LabelValueVO> getTitle() {
		return title;
	}

	public void setTitle(List<LabelValueVO> title) {
		this.title = title;
	}

	public List<LabelValueVO> getMaritalStatus() {
		return maritalStatus;
	}

	public void setMaritalStatus(List<LabelValueVO> maritalStatus) {
		this.maritalStatus = maritalStatus;
	}

	public List<LabelValueVO> getMaritalStatusJoint() {
		return maritalStatusJoint;
	}

	public void setMaritalStatusJoint(List<LabelValueVO> maritalStatusJoint) {
		this.maritalStatusJoint = maritalStatusJoint;
	}

	public List<LabelValueVO> getFrequency() {
		return frequency;
	}

	public void setFrequency(List<LabelValueVO> frequency) {
		this.frequency = frequency;
	}

	public List<LabelValueVO> getExpenseFrequency() {
		return expenseFrequency;
	}

	public void setExpenseFrequency(List<LabelValueVO> expenseFrequency) {
		this.expenseFrequency = expenseFrequency;
	}

	public List<LabelValueVO> getRepaymentFrequency() {
		return repaymentFrequency;
	}

	public void setRepaymentFrequency(List<LabelValueVO> repaymentFrequency) {
		this.repaymentFrequency = repaymentFrequency;
	}

	public List<LabelValueVO> getEmploymentType() {
		return employmentType;
	}

	public void setEmploymentType(List<LabelValueVO> employmentType) {
		this.employmentType = employmentType;
	}

	public List<LabelValueVO> getBankBrand() {
		return bankBrand;
	}
	
	public List<LabelValueVO> getBankBrandRefinance() {
		return bankBrandRefinance;
	}

	public void setBankBrand(List<LabelValueVO> bankBrand) {
		this.bankBrand = bankBrand;
	}
	
	public void setBankBrandRefinance(List<LabelValueVO> bankBrandRefinance) {
		this.bankBrandRefinance = bankBrandRefinance;
	}

	public List<LabelValueVO> getCustomerSituation() {
		return customerSituation;
	}

	public void setCustomerSituation(List<LabelValueVO> customerSituation) {
		this.customerSituation = customerSituation;
	}

	public List<LabelValueVO> getLiabilityType() {
		return liabilityType;
	}

	public void setLiabilityType(List<LabelValueVO> liabilityType) {
		this.liabilityType = liabilityType;
	}

	public List<LabelValueVO> getExpenseType() {
		return expenseType;
	}

	public void setExpenseType(List<LabelValueVO> expenseType) {
		this.expenseType = expenseType;
	}

	public List<LabelValueVO> getAssetType() {
		return assetType;
	}

	public void setAssetType(List<LabelValueVO> assetType) {
		this.assetType = assetType;
	}

	public List<LabelValueVO> getIncomeCategory() {
		return incomeCategory;
	}

	public void setIncomeCategory(List<LabelValueVO> incomeCategory) {
		this.incomeCategory = incomeCategory;
	}

	public List<LabelValueVO> getAssetCategory() {
		return assetCategory;
	}

	public void setAssetCategory(List<LabelValueVO> assetCategory) {
		this.assetCategory = assetCategory;
	}

	public List<LabelValueVO> getExpenseCategory() {
		return expenseCategory;
	}

	public void setExpenseCategory(List<LabelValueVO> expenseCategory) {
		this.expenseCategory = expenseCategory;
	}

	public List<LabelValueVO> getLiabilityCategory() {
		return liabilityCategory;
	}

	public void setLiabilityCategory(List<LabelValueVO> liabilityCategory) {
		this.liabilityCategory = liabilityCategory;
	}

	public void setHelpDeskPhone(String helpDeskPhone) {
		this.helpDeskPhone = helpDeskPhone;
	}

	public String getOrigin() {
		return origin;
	}

	public void setOrigin(String origin) {
		this.origin = origin;
	}

	public String getOriginName() {
		return originName;
	}

	public void setOriginName(String originName) {
		this.originName = originName;
	}

	public String getQasUrl() {
		return qasUrl;
	}

	public void setQasUrl(String qasUrl) {
		this.qasUrl = qasUrl;
	}

	public String getCanRetrievalURL() {
		return canRetrievalURL;
	}

	public void setCanRetrievalURL(String canRetrievalURL) {
		this.canRetrievalURL = canRetrievalURL;
	}

	public String getResetPwdURL() {
		return resetPwdURL;
	}

	public void setResetPwdURL(String resetPwdURL) {
		this.resetPwdURL = resetPwdURL;
	}

	public String getUpdateContactUrl() {
		return updateContactUrl;
	}

	public void setUpdateContactUrl(String updateContactUrl) {
		this.updateContactUrl = updateContactUrl;
	}

	public String getKeyboardAmountType() {
		return keyboardAmountType;
	}

	public void setKeyboardAmountType(String keyboardAmountType) {
		this.keyboardAmountType = keyboardAmountType;
	}

	public String getKeyboardNumType() {
		return keyboardNumType;
	}

	public void setKeyboardNumType(String keyboardNumType) {
		this.keyboardNumType = keyboardNumType;
	}

	@JsonSerialize(using = JsonDateTimeSerializer.class)
	public Date getSystemDate() {
		return systemDate;
	}

	public void setSystemDate(Date systemDate) {
		this.systemDate = systemDate;
	}

	public List<LabelValueVO> getIncomeTypePension() {
		return incomeTypePension;
	}

	public void setIncomeTypePension(List<LabelValueVO> incomeTypePension) {
		this.incomeTypePension = incomeTypePension;
	}

	public List<LabelValueVO> getIncomeTypeOther() {
		return incomeTypeOther;
	}

	public void setIncomeTypeOther(List<LabelValueVO> incomeTypeOther) {
		this.incomeTypeOther = incomeTypeOther;
	}

	public List<LabelValueVO> getRepaymentType() {
		return repaymentType;
	}

	public void setRepaymentType(List<LabelValueVO> repaymentType) {
		this.repaymentType = repaymentType;
	}

	public String getDtmUrl() {
		return dtmUrl;
	}

	public void setDtmUrl(String dtmUrl) {
		this.dtmUrl = dtmUrl;
	}

	public String getLpSiteId() {
		return lpSiteId;
	}

	public void setLpSiteId(String lpSiteId) {
		this.lpSiteId = lpSiteId;
	}

	public String getLpAppKey() {
		return lpAppKey;
	}

	public void setLpAppKey(String lpAppKey) {
		this.lpAppKey = lpAppKey;
	}

	public Boolean getExistingCustomerSwitch() {
		return existingCustomerSwitch;
	}

	public void setExistingCustomerSwitch(Boolean existingCustomerSwitch) {
		this.existingCustomerSwitch = existingCustomerSwitch;
	}

	public Boolean getRefinNewAppSwitch() {
		return refinNewAppSwitch;
	}

	public void setRefinNewAppSwitch(Boolean refinNewAppSwitch) {
		this.refinNewAppSwitch = refinNewAppSwitch;
	}

	public List<LabelValueVO> getPropertyType() {
		return propertyType;
	}

	public void setPropertyType(List<LabelValueVO> propertyType) {
		this.propertyType = propertyType;
	}

	public List<LabelValueVO> getPropertyTypeRefinance() {
		return propertyTypeRefinance;
	}

	public void setPropertyTypeRefinance(List<LabelValueVO> propertyTypeRefinance) {
		this.propertyTypeRefinance = propertyTypeRefinance;
	}
	public String getDeviceType() {
		return deviceType;
	}

	public void setDeviceType(String deviceType) {
		this.deviceType = deviceType;
	}
	
	public Boolean getRefinRetrievalSwitch() {
		return refinRetrievalSwitch;
	}

	public void setRefinRetrievalSwitch(Boolean refinRetrievalSwitch) {
		this.refinRetrievalSwitch = refinRetrievalSwitch;
	}

	public Integer getRefiLVRIntOnly() {
		return refiLVRIntOnly;
	}

	public Boolean getDTMLoanAttributesSwitch() {
		return dtmLoanAttributesSwitch;
	}

	public void setDTMLoanAttributesSwitch(Boolean dtmLoanAttributesSwitch) {
		this.dtmLoanAttributesSwitch = dtmLoanAttributesSwitch;
	}

	public void setRefiLVRIntOnly(Integer refiLVRIntOnly) {
		this.refiLVRIntOnly = refiLVRIntOnly;
	}

	public Integer getRefiLVRPAndI() {
		return refiLVRPAndI;
	}

	public void setRefiLVRPAndI(Integer refiLVRPAndI) {
		this.refiLVRPAndI = refiLVRPAndI;
	}

	public String getMinBorrowAmt() {
		return minBorrowAmt;
	}

	public void setMinBorrowAmt(String minBorrowAmt) {
		this.minBorrowAmt = minBorrowAmt;
	}

	public Integer getClientTimeout() {
		return clientTimeout;
	}

	public void setClientTimeout(Integer clientTimeout) {
		this.clientTimeout = clientTimeout;
	}

	public List<String> getSpinnerText() {
		return spinnerText;
	}

	public void setSpinnerText(List<String> spinnerText) {
		this.spinnerText = spinnerText;
	}
	
	public PropertyInsightDetails getPropertyInsightDetails() {
		return propertyInsightDetails;
	}

	public void setPropertyInsightDetails(
			PropertyInsightDetails propertyInsightDetails) {
		this.propertyInsightDetails = propertyInsightDetails;
	}

	public List<LabelValueVO> getEmploymentRole() {
		return employmentRole;
	}

	public void setEmploymentRole(List<LabelValueVO> employmentRole) {
		this.employmentRole = employmentRole;
	}

	public Boolean getMortgageDocUploadSwitch() {
		return mortgageDocUploadSwitch;
	}

	public void setMortgageDocUploadSwitch(Boolean mortgageDocUploadSwitch) {
		this.mortgageDocUploadSwitch = mortgageDocUploadSwitch;
	}

	public List<String> getCreditCheckSwitchOff() {
		return creditCheckSwitchOff;
	}

	public void setCreditCheckSwitchOff(List<String> creditCheckSwitchOff) {
		this.creditCheckSwitchOff = creditCheckSwitchOff;
	}

	public boolean isShowConfitti()
	{
		return showConfitti;
	}

	public void setShowConfitti(boolean showConfitti)
	{
		this.showConfitti = showConfitti;
	}

	public Boolean getAppDynamicsDMSwitch() {
	    return appDynamicsDMSwitch;
	}

	public void setAppDynamicsDMSwitch(Boolean appDynamicsDMSwitch) {
	    this.appDynamicsDMSwitch = appDynamicsDMSwitch;
	}

	public Boolean getAppDynamicsMBSwitch() {
	    return appDynamicsMBSwitch;
	}

	public void setAppDynamicsMBSwitch(Boolean appDynamicsMBSwitch) {
	    this.appDynamicsMBSwitch = appDynamicsMBSwitch;
	}

	public boolean isDmNewLoanTermSwitch() {
		return dmNewLoanTermSwitch;
	}

	public void setDmNewLoanTermSwitch(boolean dmNewLoanTermSwitch) {
		this.dmNewLoanTermSwitch = dmNewLoanTermSwitch;
	}

	public boolean isLpMessagingSwitch() {
		return lpMessagingSwitch;
	}

	public void setLpMessagingSwitch(boolean lpMessagingSwitch) {
		this.lpMessagingSwitch = lpMessagingSwitch;
	}

	public boolean isLpNativeOldApp() {
		return lpNativeOldApp;
	}

	public void setLpNativeOldApp(boolean lpNativeOldApp) {
		this.lpNativeOldApp = lpNativeOldApp;
	}

	
}
