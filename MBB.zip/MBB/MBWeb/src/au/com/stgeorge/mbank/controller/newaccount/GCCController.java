package au.com.stgeorge.mbank.controller.newaccount;


import java.util.ArrayList;
import java.util.HashMap;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import au.com.stgeorge.framework.common.logging.Logger;
import au.com.stgeorge.framework.common.util.StringMethods;
import au.com.stgeorge.ibank.businessobject.BusinessException;
import au.com.stgeorge.ibank.businessobject.GCCService;
import au.com.stgeorge.ibank.businessobject.OfferService;
import au.com.stgeorge.ibank.businessobject.ResourceException;
import au.com.stgeorge.ibank.common.cache.IBankParams;
import au.com.stgeorge.ibank.util.ServiceHelper;
import au.com.stgeorge.ibank.valueobject.Account;
import au.com.stgeorge.ibank.valueobject.Address;
import au.com.stgeorge.ibank.valueobject.Customer;
import au.com.stgeorge.ibank.valueobject.GCCDetail;
import au.com.stgeorge.ibank.valueobject.TDAForecastVO;
import au.com.stgeorge.ibank.valueobject.database.CodesVO;
import au.com.stgeorge.ibank.valueobject.database.OriginsVO;
import au.com.stgeorge.ibank.valueobject.transfer.IBankCommonData;
import au.com.stgeorge.mbank.controller.IMBController;
import au.com.stgeorge.mbank.controller.accountinfo.AccountInfoHelper;
import au.com.stgeorge.mbank.controller.customer.LogonHelper;
import au.com.stgeorge.mbank.model.common.AddressReq;
import au.com.stgeorge.mbank.model.common.IMBReq;
import au.com.stgeorge.mbank.model.common.IMBResp;
import au.com.stgeorge.mbank.model.common.ReceiptResp;
import au.com.stgeorge.mbank.model.common.ReqHeader;
import au.com.stgeorge.mbank.model.common.RespHeader;
import au.com.stgeorge.mbank.model.request.newaccount.GCCDetailsReq;
import au.com.stgeorge.mbank.model.response.ErrorResp;
import au.com.stgeorge.mbank.model.response.newaccount.GCCDetailsResp;
import au.com.stgeorge.mbank.session.MobileSession;
import au.com.stgeorge.mbank.util.FraudLogger;
import au.com.stgeorge.mbank.util.MBAppConstants;
import au.com.stgeorge.mbank.util.MBAppHelper;
import au.com.stgeorge.mbank.util.MBAppUtils;
import au.com.stgeorge.mbank.util.MBAppValidator;
import au.com.stgeorge.mobilebank.businessobject.MobileBankService;
import au.com.stgeorge.mobilebank.businessobject.TermDepositService;
import au.com.stgeorge.mobilebank.businessobject.impl.TermDepositServiceImpl;
import au.com.stgeorge.perflogger.PerformanceLogger;

import com.fasterxml.jackson.databind.ObjectMapper;


@Controller
@RequestMapping("/gcc")
public class GCCController implements IMBController
{

	private static HashMap<String, MsgSubCategory> gccErrorMsgList = null; 

	private FraudLogger fraudLogger;
	
	@Autowired
	private MBAppHelper mbAppHelper;
	
	
	@Autowired
	private MobileBankService mobileBankService;
	
	@Autowired
	private LogonHelper logonHelper;
	
	@Autowired
	private OfferService offerService;
	
	
	private TermDepositHelper tdaHelper = new TermDepositHelper();
	private TermDepositService termDepositService = new TermDepositServiceImpl();

	
	@RequestMapping(value="eligible", method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public IMBResp checkEligibility(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse,
			@RequestBody final GCCDetailsReq req)
	{
		Logger.debug("In checkEligibility ( GCCController )  for Customer " +  "  " + httpServletRequest.getContentType() + " "
				+ httpServletRequest.getRemoteAddr() + "  " + httpServletResponse.getCharacterEncoding() + httpServletResponse.getLocale() + " Req From " + req.getRequestFrom() +
				" True IP >> " + httpServletRequest.getHeader(IBankParams.trueClientIP()), this.getClass());

		PerformanceLogger performanceLogger = new PerformanceLogger();
		fraudLogger = new FraudLogger();
		performanceLogger.startAllLogs();
		String logName = MBAppUtils.getLogName(httpServletRequest);
		performanceLogger.startLog(logName);
		ObjectMapper mapper = new ObjectMapper();
		TDAForecastVO forecastVO = null;

		MobileSession mbSession =  null;
		try
		{
			Logger.info("getFundingAccount JSON Request :" + mapper.writeValueAsString(req), this.getClass());
			mbSession = mbAppHelper.getMobileSession(httpServletRequest);		

			validateRequestHeader( req.getHeader(), httpServletRequest );
			ErrorResp errorResp = validate(req, httpServletRequest);
			if (errorResp != null && errorResp.getErrors() != null && errorResp.getErrors().size() > 0)
			{
				return errorResp;
			}
			IBankCommonData ibankCommonData = mbAppHelper.populateIBankCommonData(mbSession, httpServletRequest);
			
			String gcis = ibankCommonData.getUser().getGCISNumber();
			GCCDetailsResp gccDetailsResp = new GCCDetailsResp();
			
			GCCService gccService = (GCCService) ServiceHelper.getBean("gccService");
			String eligEroor = gccService.verifyEligibility(ibankCommonData);
			Logger.debug("Error Code : " + eligEroor, this.getClass());
			if ( ! StringMethods.isEmptyString(eligEroor) ) {
				MsgSubCategory msgSubCategory = getMsgSubCategory(eligEroor);
				ArrayList<String> eligiblityMsg = new ArrayList<String>();
				gccDetailsResp.setIsEligible(new Boolean(false));
				eligiblityMsg.add(formatMessage(msgSubCategory.getMessage1(),ibankCommonData.getOrigin()) );
				eligiblityMsg.add(formatMessage(msgSubCategory.getMessage2() ,ibankCommonData.getOrigin()));
				eligiblityMsg.add(formatMessage(msgSubCategory.getMessage3(),ibankCommonData.getOrigin()));
				gccDetailsResp.setEligiblityMsg(eligiblityMsg);
			}
			else
			{
				gccDetailsResp.setIsEligible(new Boolean(true));
				String desc = getStatDesc(req);
				gccService.makeStatisticsLog(ibankCommonData, desc, "GCCPRD");
			}
						
			IMBResp serviceResponse = gccDetailsResp;
			Logger.info("GCC - checkEligibility JSON Response :" + mapper.writeValueAsString(serviceResponse), this.getClass());
			RespHeader headerResp = populateResponseHeader(req.getHeader().getServiceName(), mbSession);
			serviceResponse.setHeader(headerResp);
			return serviceResponse;
		} catch (BusinessException e)
		{
			Logger.error("Exception Inside getFundingAccount() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			IMBResp resp1 = MBAppUtils.createErrorResp(mbSession.getOrigin(), e, MBAppConstants.SMPL_OPENDDAACCOUNT_RESP_NAME, httpServletRequest);
			return resp1;
		}
		catch (Exception e)
		{
			Logger.error("Exception Inside getFundingAccount() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			BusinessException exp = new BusinessException(BusinessException.SYSTEM_UNAVILABLE);
			IMBResp resp1 = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, MBAppConstants.SMPL_OPENDDAACCOUNT_RESP_NAME, httpServletRequest);
			return resp1;
		} finally
		{
			performanceLogger.endLog(logName);
			performanceLogger.endAllLogs();
		}
	}

	private MsgSubCategory getMsgSubCategory(String errorCode) {

		if (gccErrorMsgList == null || gccErrorMsgList.size() < 1) {
			gccErrorMsgList = new HashMap<String, MsgSubCategory>();

			SimpleMessageLocator actionMessageLocator = (SimpleMessageLocator) ServiceHelper
			    .getBean("simpleMessageLocator");
			SimpleMessageStructure newActionMessage = actionMessageLocator.getMessageStructure();

			// List<MsgCategory> msgCatgs = newActionMessage.getMsgCategories();

			for (MsgCategory category : newActionMessage.getMsgCategories()) {
				if ("GCC".equalsIgnoreCase(category.getName())) {
					Logger.info("GCC Msg  category.getName() : " + category.getName(), this.getClass());
					for (MsgSubCategory subCategory : category.getMsgSubCategories()) {
						gccErrorMsgList.put(subCategory.getMessageId(), subCategory);
						
						Logger.info("GCC Msg  Deatisl ...  : " + subCategory.getMessageId() + "  " + subCategory.getMessage1()
						    + "  " + subCategory.getMessage1(), this.getClass());
					}
				}
			}
		}
		
		return gccErrorMsgList.get(errorCode);

	}
	
	@RequestMapping(value="apply", method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public IMBResp applyGCC(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse,
			@RequestBody final GCCDetailsReq req)
	{
		Logger.debug("In Apply() ( GCCController )  for Customer " +  "  " + httpServletRequest.getContentType() + " "
				+ httpServletRequest.getRemoteAddr() + "  " + httpServletResponse.getCharacterEncoding() + httpServletResponse.getLocale() +
				" True IP >> " + httpServletRequest.getHeader(IBankParams.trueClientIP()), this.getClass());

		PerformanceLogger performanceLogger = new PerformanceLogger();
		fraudLogger = new FraudLogger();
		performanceLogger.startAllLogs();
		String logName = MBAppUtils.getLogName(httpServletRequest);
		performanceLogger.startLog(logName);
		ObjectMapper mapper = new ObjectMapper();
		IBankCommonData ibankCommonData =  null;
		MobileSession mbSession =  null;
		try
		{
			Logger.info("getFundingAccount JSON Request :" + mapper.writeValueAsString(req), this.getClass());
			mbSession = mbAppHelper.getMobileSession(httpServletRequest);		

			validateRequestHeader( req.getHeader(), httpServletRequest );
			ErrorResp errorResp = validate(req, httpServletRequest);
			if (errorResp != null && errorResp.getErrors() != null && errorResp.getErrors().size() > 0)
			{
				return errorResp;
			}
			ibankCommonData = mbAppHelper.populateIBankCommonData(mbSession, httpServletRequest);
			String gcis = ibankCommonData.getUser().getGCISNumber();
			GCCDetailsResp gccDetailsResp = new GCCDetailsResp();
			
			
			GCCService gccService = (GCCService) ServiceHelper.getBean("gccService");
			
			GCCDetail gccDetail = new GCCDetail();

			gccDetail.setEmailAdd(req.getEmail());
			
			Customer customer = ibankCommonData.getCustomer();
			
			if ("NEW".equalsIgnoreCase(req.getSelPhoneType())) {
				gccDetail.setPhone(req.getPhone());
			} else if ("MOBILE".equalsIgnoreCase(req.getSelPhoneType())) {
				gccDetail.setPhone(customer.getContactDetail().getMobileNumber()
				    .getAreaCode()
				    + customer.getContactDetail().getMobileNumber().getPhoneNumber());
			} else if ("HOME".equalsIgnoreCase(req.getSelPhoneType())) {
				gccDetail.setPhone(customer.getContactDetail().getHomeNumber()
				    .getAreaCode()
				    + customer.getContactDetail().getHomeNumber().getPhoneNumber());
			} else if ("WORK".equalsIgnoreCase(req.getSelPhoneType())) {
				gccDetail.setPhone(customer.getContactDetail().getWorkNumber()
				    .getAreaCode()
				    + customer.getContactDetail().getWorkNumber().getPhoneNumber());
			}
			
			AddressReq addressReq = req.getAddress();

			 boolean isValidateAddress = true;

			if ("NEW".equalsIgnoreCase(addressReq.getAddrType())) {
				Address address = new Address();
				address.setLine1(addressReq.getLine1());
				address.setLine2(addressReq.getLine2());
				address.setPostZipcode(addressReq.getPostCode());
				address.setState(addressReq.getState());
				address.setSuburb(addressReq.getSuburb());
				gccDetail.setDeliveryAddress(address);
			}  else if  ("RES".equalsIgnoreCase(addressReq.getAddrType())) {
				gccDetail.setDeliveryAddress( customer.getContactDetail().getResidentialAddress());
				 isValidateAddress = false;
			} else if  ("MAIL".equalsIgnoreCase(addressReq.getAddrType())) {
				gccDetail.setDeliveryAddress( customer.getContactDetail().getMailingAddress());
				 isValidateAddress = false;
			} 
			
			
			GCCDetail newGccDetail =  gccService.applyGCC(ibankCommonData, gccDetail, isValidateAddress );

			ReceiptResp receiptResp = new ReceiptResp();
			receiptResp.setReceiptNumDisp( newGccDetail.getAccountNumber() );
			gccDetailsResp.setReceipt(receiptResp);
			gccDetailsResp.setIsSuccess(new Boolean( true));
			gccDetailsResp.setIsAddressValidated(new Boolean(true));
			
			//added in 20E1 - set appReferenceID - AEM tagging 
			final String appReferenceId = IBankParams.getCodesMessage(IBankParams.DEFAULT_ORIGIN, IBankParams.CONFIGURATION_PROPERTIES, IBankParams.APPREFERENCE_ID);        	
			gccDetailsResp.setAppReferenceId(newGccDetail.getRequestId() + new Long(appReferenceId));
			
			IMBResp serviceResponse = gccDetailsResp;
			ibankCommonData.setCustomer(null);
			customer = mobileBankService.getCustomer(ibankCommonData, "");
			ibankCommonData.setCustomer( customer );
			mbSession.setCustomer(customer);
			ArrayList<au.com.stgeorge.mbank.model.common.AccountResp> accountList = logonHelper.populateAccountList(mbSession.getCustomer(),mbSession.getAutoApplyRetentionInfo());
			gccDetailsResp.setAccounts(accountList);
			Account newGCCAccount = MBAppHelper.getAccountByAccountNumber(customer.getAccounts(), newGccDetail.getRevRefId().trim());
			if ( newGCCAccount != null )
			{				
				gccDetailsResp.setNewGCCAcountIndex(newGCCAccount.getIndex());
				
				if(req.getLeadId() != null)
					offerService.acceptLead(ibankCommonData, req.getLeadId());
			}
			else
			{
				gccDetailsResp.setNewGCCAcountIndex(-1);
			}
			gccDetailsResp.setAllowFunding(AccountInfoHelper.isGCCFundingSwitchON(ibankCommonData.getOrigin()));
			Logger.info("GCC - checkEligibility JSON Response :" + mapper.writeValueAsString(serviceResponse), this.getClass());
			RespHeader headerResp = populateResponseHeader(req.getHeader().getServiceName(), mbSession);
			serviceResponse.setHeader(headerResp);
			gccDetailsResp.setIsAddressValidated(true);
			gccDetailsResp.setIsEligible(new Boolean(true));
			return serviceResponse;
		} catch (BusinessException e)
		{
			Logger.error("Exception Inside getFundingAccount() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			Logger.error("e.getKey() ..: ["+ e.getKey(), e, this.getClass());
			
			if (e.getKey() == BusinessException.GCC_NEW_APPL_DPID_ADDRESS_VALIDATION_FAILED )
			{
				GCCDetailsResp gccDetailsResp = new GCCDetailsResp();
				gccDetailsResp.setIsAddressValidated(new Boolean(false));
				RespHeader headerResp = populateResponseHeader(req.getHeader().getServiceName(), mbSession);
				IMBResp serviceResponse = gccDetailsResp;
				serviceResponse.setHeader(headerResp);
				return serviceResponse;
			}
			else if  (e.getKey() == 2040 )
			{
			    String eligEroor = "GCCE010";
				MsgSubCategory msgSubCategory = getMsgSubCategory(eligEroor);
				GCCDetailsResp gccDetailsResp = new GCCDetailsResp();
				ArrayList<String> eligiblityMsg = new ArrayList<String>();
				gccDetailsResp.setIsEligible(new Boolean(false));
				eligiblityMsg.add(formatMessage(msgSubCategory.getMessage1(),ibankCommonData.getOrigin()) );
				eligiblityMsg.add(formatMessage(msgSubCategory.getMessage2() ,ibankCommonData.getOrigin()));
				eligiblityMsg.add(formatMessage(msgSubCategory.getMessage3(),ibankCommonData.getOrigin()));
				gccDetailsResp.setEligiblityMsg(eligiblityMsg);
				gccDetailsResp.setIsAddressValidated(true);
				RespHeader headerResp = populateResponseHeader(req.getHeader().getServiceName(), mbSession);
				IMBResp serviceResponse = gccDetailsResp;
				serviceResponse.setHeader(headerResp);
				return serviceResponse;
			}
		
			IMBResp resp1 = MBAppUtils.createErrorResp(mbSession.getOrigin(), e, MBAppConstants.SMPL_OPENDDAACCOUNT_RESP_NAME, httpServletRequest);
			return resp1;
		}
		catch (Exception e)
		{
			Logger.error("Exception Inside getFundingAccount() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			BusinessException exp = new BusinessException(BusinessException.SYSTEM_UNAVILABLE);
			IMBResp resp1 = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, MBAppConstants.SMPL_OPENDDAACCOUNT_RESP_NAME, httpServletRequest);
			return resp1;
		} finally
		{
			performanceLogger.endLog(logName);
			performanceLogger.endAllLogs();
		}
	}


	private String formatMessage(String msg, String origin )
	{
		OriginsVO myOriginVO  = IBankParams.getOrigin(origin);
		OriginsVO baseOrigin  = IBankParams.getOrigin(myOriginVO.getBankName());
		
		
		
//  	appParams.setOriginPhone(baseOrigin.getPhone());
//		appParams.setOriginURL(myOriginVO.getUrl());
		
		CodesVO codesVO = IBankParams.getCodesData(baseOrigin.getBankName(), "GCCDetails", "HelpDeskContact");
		CodesVO codesVOURL = IBankParams.getCodesData(baseOrigin.getBankName(), "GCCDetails", "TermsURL");

		Logger.info("GCC - Subcategory.getName() baseOrigin "
		    + baseOrigin.getName() + " " + baseOrigin.getBankName() + "  " + myOriginVO.getName(), this.getClass());

		
		String str2 = msg.replaceAll("\\$brandURL", codesVOURL.getMessage() );

		Logger.info("GCC - Subcategory.getName() baseOrigin ( 2)  "
		    + baseOrigin.getName() + " " + codesVOURL.getMessage() + "  " + myOriginVO.getName(), this.getClass());

		if ( "STG".equalsIgnoreCase (baseOrigin.getBankName() ) )
			 str2 = str2.replaceAll("\\$brand", baseOrigin.getName().replaceAll("Bank", ""));
		else
			str2 = str2.replaceAll("\\$brand", baseOrigin.getName());
		
		str2 = str2.replaceAll("\\$contact", codesVO.getMessage());

		
		str2 = str2.replaceAll("\\$cccContact", baseOrigin.getBpayPhone());
	
		
		return str2;

	
	}

	
	private String getStatDesc(GCCDetailsReq req)
	{
		if ( StringMethods.isEmptyString(req.getRequestFrom() ))
			return "";
		if ( req.getRequestFrom().equalsIgnoreCase("overseasTravel") )
			return "Overseas Travel";
		else if ( req.getRequestFrom().equalsIgnoreCase("popular") )
			return "Compass Product Page";
		else
			return "";
	}
	

	public RespHeader populateResponseHeader(String serviceName, MobileSession mobSession )
	{
		return mbAppHelper.populateResponseHeader(serviceName, mobSession);
	}

	
	
	private static final String REGEX_PATTERN = "^[0-9A-Za-z',. &/\\-]*$";

	public ErrorResp validate(IMBReq serviceRequest, HttpServletRequest request)
	{
		
		if ( serviceRequest != null )
		{
			boolean isValidData = true;
			MBAppUtils mbAppUtils = new MBAppUtils();
			GCCDetailsReq req = (GCCDetailsReq) serviceRequest;
			if ( req.getAddress() != null )
			{
				if ( ! StringMethods.isEmptyString( req.getAddress().getAddrType() ) && isValidData )
				{
					isValidData = mbAppUtils.validateDataUsingRegEx(req.getAddress().getAddrType(), REGEX_PATTERN);
				}
				if ( ! StringMethods.isEmptyString( req.getAddress().getCountryName() )  && isValidData )
				{
					isValidData = mbAppUtils.validateDataUsingRegEx(req.getAddress().getCountryName(), REGEX_PATTERN);
				}
				if ( ! StringMethods.isEmptyString( req.getAddress().getLine1() )  && isValidData )
				{
					isValidData = mbAppUtils.validateDataUsingRegEx(req.getAddress().getLine1(), REGEX_PATTERN);
				}
				if ( ! StringMethods.isEmptyString( req.getAddress().getLine2() )  && isValidData )
				{
					isValidData = mbAppUtils.validateDataUsingRegEx(req.getAddress().getLine2(), REGEX_PATTERN);
				}
				if ( ! StringMethods.isEmptyString( req.getAddress().getLine3() )  && isValidData )
				{
					isValidData = mbAppUtils.validateDataUsingRegEx(req.getAddress().getLine3(), REGEX_PATTERN);
				}
				if ( ! StringMethods.isEmptyString( req.getAddress().getPostCode() )  && isValidData )
				{
					isValidData = mbAppUtils.validateDataUsingRegEx(req.getAddress().getPostCode(), REGEX_PATTERN);
				}
				if ( ! StringMethods.isEmptyString( req.getAddress().getState() )  && isValidData )
				{
					isValidData = mbAppUtils.validateDataUsingRegEx(req.getAddress().getState(), REGEX_PATTERN);
				}
				if ( ! StringMethods.isEmptyString( req.getAddress().getSuburb() )  && isValidData )
				{
					isValidData = mbAppUtils.validateDataUsingRegEx(req.getAddress().getSuburb(), REGEX_PATTERN);
				}
			}
			if ( ! StringMethods.isEmptyString( req.getEmail() )  && isValidData )
			{
				isValidData = mbAppUtils.validateDataUsingRegEx(req.getEmail(), "^\\w+([\\.-]?\\w+)*@\\w+([\\.-]?\\w+)*(\\.\\w{2,3})+$");
			}
			if ( "NEW".equalsIgnoreCase(req.getSelPhoneType()) &&  ! StringMethods.isEmptyString( req.getPhone() )  && isValidData )
			{
				isValidData = mbAppUtils.validateDataUsingRegEx(req.getPhone(), REGEX_PATTERN);
			}
			if ( ! StringMethods.isEmptyString( req.getRequestFrom() )  && isValidData )
			{
				isValidData = mbAppUtils.validateDataUsingRegEx(req.getRequestFrom(), REGEX_PATTERN);
			}
			if ( ! StringMethods.isEmptyString( req.getSelPhoneType() )  && isValidData )
			{
				isValidData = mbAppUtils.validateDataUsingRegEx(req.getSelPhoneType(), REGEX_PATTERN);
			}
			
		  if ( ! isValidData )
		  {
			  Logger.error(" Validation failed....  "  , this.getClass());
			  throw new ResourceException( ResourceException.SYSTEM_ERROR);
		  }
		
		}
		
		return null;
		
	}

	public void validateRequestHeader(ReqHeader header, HttpServletRequest request) throws ResourceException
	{
		mbAppValidator.validateRequestHeader(header, request);
	}


	@Autowired
	private MBAppValidator mbAppValidator;

		
}

