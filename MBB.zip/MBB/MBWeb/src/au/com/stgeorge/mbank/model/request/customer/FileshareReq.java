package au.com.stgeorge.mbank.model.request.customer;

import au.com.stgeorge.mbank.model.common.IMBReq;
import au.com.stgeorge.mbank.model.common.ReqHeader;

public class FileshareReq implements IMBReq {

	private static final long serialVersionUID = 8762681772283948019L;
	
	private ReqHeader header;
	private String devicePrint;
	
	@Override
	public ReqHeader getHeader() {
		return header;
	}

	@Override
	public void setHeader(ReqHeader header) {
		this.header = header;
	}

	public String getDevicePrint() {
		return devicePrint;
	}

	public void setDevicePrint(String devicePrint) {
		this.devicePrint = devicePrint;
	}	
}
