package au.com.stgeorge.mbank.model.mortgage;

import java.util.List;

import au.com.stgeorge.ibank.valueobject.LabelValueVO;

public class RefData {
	private List<LabelValueVO> title;
	private List<LabelValueVO> maritalStatus;
	private List<LabelValueVO> maritalStatusJoint;
	private List<LabelValueVO> frequency;
	private List<LabelValueVO> expenseFrequency;
	private List<LabelValueVO> repaymentFrequency;
	private List<LabelValueVO> employmentType;
	private List<LabelValueVO> bankBrand;
	private List<LabelValueVO> customerSituation;
	private List<LabelValueVO> incomeType;
	private List<LabelValueVO> liabilityType;
	private List<LabelValueVO> expenseType;
	private List<LabelValueVO> assetType;
	//private List<LabelValueVO> loanPurpose;
	//private List<LabelValueVO> loanType;
	//private List<LabelValueVO> incomeCategory;
	//private List<LabelValueVO> assetCategory;
	//private List<LabelValueVO> expenseCategory;
	//private List<LabelValueVO> liabilityCategory;
	//private List<LabelValueVO> repaymentType;
	
	
	public List<LabelValueVO> getMaritalStatusJoint() {
		return maritalStatusJoint;
	}

	public void setMaritalStatusJoint(List<LabelValueVO> maritalStatusJoint) {
		this.maritalStatusJoint = maritalStatusJoint;
	}

	public List<LabelValueVO> getTitle() {
		return title;
	}

	public void setTitle(List<LabelValueVO> title) {
		this.title = title;
	}

	public List<LabelValueVO> getMaritalStatus() {
		return maritalStatus;
	}

	public void setMaritalStatus(List<LabelValueVO> maritalStatus) {
		this.maritalStatus = maritalStatus;
	}

	public List<LabelValueVO> getFrequency() {
		return frequency;
	}

	public void setFrequency(List<LabelValueVO> frequency) {
		this.frequency = frequency;
	}

	public List<LabelValueVO> getExpenseFrequency() {
		return expenseFrequency;
	}

	public void setExpenseFrequency(List<LabelValueVO> expenseFrequency) {
		this.expenseFrequency = expenseFrequency;
	}

	public List<LabelValueVO> getRepaymentFrequency() {
		return repaymentFrequency;
	}

	public void setRepaymentFrequency(List<LabelValueVO> repaymentFrequency) {
		this.repaymentFrequency = repaymentFrequency;
	}
	
	public List<LabelValueVO> getEmploymentType() {
		return employmentType;
	}

	public void setEmploymentType(List<LabelValueVO> employmentType) {
		this.employmentType = employmentType;
	}

	public List<LabelValueVO> getBankBrand() {
		return bankBrand;
	}

	public void setBankBrand(List<LabelValueVO> bankBrand) {
		this.bankBrand = bankBrand;
	}


	public List<LabelValueVO> getCustomerSituation() {
		return customerSituation;
	}

	public void setCustomerSituation(List<LabelValueVO> customerSituation) {
		this.customerSituation = customerSituation;
	}

	public List<LabelValueVO> getIncomeType() {
		return incomeType;
	}

	public void setIncomeType(List<LabelValueVO> incomeType) {
		this.incomeType = incomeType;
	}

	public List<LabelValueVO> getLiabilityType() {
		return liabilityType;
	}

	public void setLiabilityType(List<LabelValueVO> liabilityType) {
		this.liabilityType = liabilityType;
	}

	public List<LabelValueVO> getExpenseType() {
		return expenseType;
	}

	public void setExpenseType(List<LabelValueVO> expenseType) {
		this.expenseType = expenseType;
	}

	public List<LabelValueVO> getAssetType() {
		return assetType;
	}

	public void setAssetType(List<LabelValueVO> assetType) {
		this.assetType = assetType;
	}
}
