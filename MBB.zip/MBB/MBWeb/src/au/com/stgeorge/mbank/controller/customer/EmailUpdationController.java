package au.com.stgeorge.mbank.controller.customer;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import au.com.stgeorge.framework.common.logging.Logger;
import au.com.stgeorge.ibank.businessobject.BusinessException;
import au.com.stgeorge.ibank.businessobject.emailupdation.EmailUpdationService;
import au.com.stgeorge.ibank.common.cache.IBankParams;
import au.com.stgeorge.ibank.messagecentre.valueobject.MessageSearch;
import au.com.stgeorge.ibank.valueobject.transfer.IBankCommonData;
import au.com.stgeorge.mbank.controller.IMBController;
import au.com.stgeorge.mbank.model.common.IMBReq;
import au.com.stgeorge.mbank.model.common.IMBResp;
import au.com.stgeorge.mbank.model.common.ReqHeader;
import au.com.stgeorge.mbank.model.common.RespHeader;
import au.com.stgeorge.mbank.model.request.customer.EmailUpdationReq;
import au.com.stgeorge.mbank.model.response.ErrorResp;
import au.com.stgeorge.mbank.model.response.SuccessResp;
import au.com.stgeorge.mbank.session.MobileSession;
import au.com.stgeorge.mbank.util.MBAppHelper;
import au.com.stgeorge.mbank.util.MBAppUtils;
import au.com.stgeorge.mbank.util.MBAppValidator;
import au.com.stgeorge.perflogger.PerformanceLogger;

import com.fasterxml.jackson.databind.ObjectMapper;

@Controller
@RequestMapping("/emailUpdation")
public class EmailUpdationController implements IMBController{

	@Autowired
	private MBAppValidator mbAppValidator;
	
	@Autowired
	private MBAppHelper mbAppHelper;
	
	@Autowired
    private PerformanceLogger perfLogger;
	
	@Autowired
    private EmailUpdationService emailUpdationService;
	
	
	@RequestMapping(value="skipSplash", method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public IMBResp skipSplashForEmailUpdation(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, @RequestBody final EmailUpdationReq req) {
		Logger.info("Inside skipSplashForEmailUpdation :" , this.getClass());
		String logName = startPerformanceLog(httpServletRequest);
		MobileSession mbSession = null;
		IBankCommonData commonData = null;
		ObjectMapper mapper = new ObjectMapper();
		String gcisNumber = null;
		try {
			mbSession = mbAppHelper.getMobileSession(httpServletRequest);
			commonData = new MBAppHelper().populateIBankCommonData(mbSession, httpServletRequest);
			gcisNumber = commonData.getCustomer().getGcis();
	
			validateRequestHeader(req.getHeader(), httpServletRequest);
			Logger.info("skipSplashForEmailUpdation JSON Request :" + mapper.writeValueAsString(req), this.getClass());
			MessageSearch messageSearch = mbSession.getSplashInfoMsg();
			emailUpdationService.updateSkipCounter(messageSearch, commonData, false);
			mbSession.removeSplashInfoMsg(); 
		}
		catch (Exception e) {	
			Logger.error("skipSplashForEmailUpdation failed with Exception for customer " + gcisNumber  + e.getMessage(), this.getClass() );
		} finally {
		    endPerformanceLog(logName);
		}
		
		SuccessResp successResp = new SuccessResp();																			
		RespHeader headerResp = populateResponseHeader(req.getHeader().getServiceName(), mbSession);
		successResp.setHeader(headerResp);
		successResp.setIsSuccess(true);
		mbSession.setLoggedonState(LogonHelper.LOGGEDON_STATE_COMPLETE);
		return successResp;
	}
	
	private String startPerformanceLog(HttpServletRequest httpRequest) {
		perfLogger.startAllLogs();
		String logName = MBAppUtils.getLogName(httpRequest);
		perfLogger.startLog(logName);
		return logName;
    }

    private void endPerformanceLog(String logName) {
		perfLogger.endLog(logName);
		perfLogger.endAllLogs();
    }
	
	
	@Override
	public void validateRequestHeader(ReqHeader headerReq,
			HttpServletRequest request) throws BusinessException {
		mbAppValidator.validateRequestHeader(headerReq,  request);		
	}

	@Override
	public ErrorResp validate(IMBReq serviceRequest,
			HttpServletRequest httpRequest) throws BusinessException {
		return mbAppValidator.validate(serviceRequest, httpRequest);		
	}

	@Override
	public RespHeader populateResponseHeader(String serviceName,
			MobileSession mobileSession) {
		return mbAppHelper.populateResponseHeader(serviceName,mobileSession);
	}

}
