package au.com.stgeorge.mbank.model.request.mortgage;

import java.io.Serializable;

import javax.validation.Valid;

import au.com.stgeorge.mbank.model.common.IMBReq;
import au.com.stgeorge.mbank.model.common.ReqHeader;
import au.com.stgeorge.mbank.model.mortgageinfo.ApplicationInfo;

public class ApplicationReq implements IMBReq, Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = -2334701650351329205L;
	private ReqHeader header;
	@Valid
	private ApplicationInfo app;

	public ApplicationInfo getApp() {
		return app;
	}

	public void setApp(ApplicationInfo app) {
		this.app = app;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public ReqHeader getHeader() {
		return header;
	}

	public void setHeader(ReqHeader header) {
		this.header = header;
	}
}
