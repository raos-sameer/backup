/* DMExpense.java : define class */
package au.com.stgeorge.mbank.model.mortgageinfo; 
import java.io.Serializable;

import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.Range;

import au.com.stgeorge.ibank.businessobject.BusinessException;


import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_NULL)
public class ExpenseInfo implements Serializable
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 4021754307698069511L;

	@Range(max=100, message = ""+BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE)
	@Pattern(regexp="([0-9]+[.]?[0-9]?[0-9]?)",message = ""+BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE)
	private String owner1Percent;

	@Range(max=100, message = ""+BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE)
	@Pattern(regexp="([0-9]+[.]?[0-9]?[0-9]?)",message = ""+BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE)
	private String owner2Percent;

	@Range(max=100, message = ""+BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE)
	@Pattern(regexp="([0-9]+[.]?[0-9]?[0-9]?)",message = ""+BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE)
	private String otherPercent;
	
	private String Category;
	private String expenseType;

	@Range(max=9999999, message = ""+BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE)
	@Pattern(regexp="([0-9]+[.]?[0-9]?[0-9]?)",message = ""+BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE)
	private String amount;
	private String expenseFrequency;

	private Boolean sigEventsExpectedInd;
	
	private int index;
	
	public int getIndex() {
		return index;
	}
	public void setIndex(int index) {
		this.index = index;
	}
	public String getOwner1Percent() {
		return owner1Percent;
	}
	public void setOwner1Percent(String owner1Percent) {
		this.owner1Percent = owner1Percent;
	}
	public String getOwner2Percent() {
		return owner2Percent;
	}
	public void setOwner2Percent(String owner2Percent) {
		this.owner2Percent = owner2Percent;
	}
	public String getOtherPercent() {
		return otherPercent;
	}
	public void setOtherPercent(String otherPercent) {
		this.otherPercent = otherPercent;
	}
	public String getAmount() {
		return amount;
	}
	public void setAmount(String amount) {
		this.amount = amount;
	}
	public String getCategory() {
		return Category;
	}
	public void setCategory(String category) {
		Category = category;
	}
	public String getExpenseType() {
		return expenseType;
	}
	public void setExpenseType(String expenseType) {
		this.expenseType = expenseType;
	}
	public String getExpenseFrequency() {
		return expenseFrequency;
	}
	public void setExpenseFrequency(String expenseFrequency) {
		this.expenseFrequency = expenseFrequency;
	}
	public Boolean getSigEventsExpectedInd() {
		return sigEventsExpectedInd;
	}
	public void setSigEventsExpectedInd(Boolean sigEventsExpectedInd) {
		this.sigEventsExpectedInd = sigEventsExpectedInd;
	}
}