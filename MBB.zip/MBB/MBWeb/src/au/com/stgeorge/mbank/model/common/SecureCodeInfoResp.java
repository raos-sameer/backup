package au.com.stgeorge.mbank.model.common;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_NULL)
public class SecureCodeInfoResp
{

  String deliveryPref;
	String phonePref;
  String exempt;
  
  public String getDeliveryPref()
	{
		return deliveryPref;
	}
	public void setDeliveryPref(String deliveryPref)
	{
		this.deliveryPref = deliveryPref;
	}
	public String getPhonePref()
	{
		return phonePref;
	}
	public void setPhonePref(String phonePref)
	{
		this.phonePref = phonePref;
	}
	public String getExempt()
	{
		return exempt;
	}
	public void setExempt(String exempt)
	{
		this.exempt = exempt;
	}

}
