package au.com.stgeorge.mbank.model.request.expensesplitter;


import java.util.List;

import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.Length;
import org.hibernate.validator.constraints.NotEmpty;

import au.com.stgeorge.ibank.businessobject.BusinessException;
import au.com.stgeorge.mbank.model.common.IMBReq;
import au.com.stgeorge.mbank.model.common.ReqHeader;


public class ExpenseSplitterReq implements IMBReq {


	/**
	 * 
	 */
	private static final long serialVersionUID = -7681575102312038403L;
	protected static final String AMT_PATTERN = "^[0-9]*\\.{0,1}(\\d{1,2}){0,1}$";
	protected static final String BLOCK_CHARS_PATTERN = "^[0-9A-Za-z',. &/\\-]*$";
	protected static final String MASK_NUMBERS = "^[0-9]+$";

	private ReqHeader header;
	
	@Pattern(regexp = MASK_NUMBERS, message = "" + BusinessException.WSVC_INVALID_INPUT_PARAM)
	private String expGrpID;

	public ReqHeader getHeader() {
		return header;
	}

	public void setHeader(ReqHeader header) {
		this.header = header;
	}
	
	@NotEmpty(message = "{errors.expenseGrpName.required}")
	@Pattern(regexp = BLOCK_CHARS_PATTERN, message = "{errors.desc.blockchar}")
	@Length(max = 13, message = "{errors.expenseGrpName.maxlength}")
	private String expenseGrpName;
	
	@NotEmpty(message = "{errors.can.required}")
	@Pattern(regexp = BLOCK_CHARS_PATTERN, message = "{errors.desc.blockchar}")
	@Length(max = 24, message = "{errors.desc.maxlength}")
	private String splitOption;
	
	private boolean settled;


	private List<ExpenseReq> expenseList;
	
	private List<ContactReq> contactList;
	
	public String getExpenseGrpName() {
		return expenseGrpName;
	}

	public void setExpenseGrpName(String expenseGrpName) {
		this.expenseGrpName = expenseGrpName;
	}

	public List<ExpenseReq> getExpenseList() {
		return expenseList;
	}

	public void setExpenseList(List<ExpenseReq> expenseList) {
		this.expenseList = expenseList;
	}

	public List<ContactReq> getContactList() {
		return contactList;
	}

	public void setContactList(List<ContactReq> contactList) {
		this.contactList = contactList;
	}

	public String getSplitOption() {
		return splitOption;
	}

	public void setSplitOption(String splitOption) {
		this.splitOption = splitOption;
	}

	public String getExpGrpID() {
		return expGrpID;
	}

	public void setExpGrpID(String expGrpID) {
		this.expGrpID = expGrpID;
	}

	public boolean isSettled() {
		return settled;
	}

	public void setSettled(boolean settled) {
		this.settled = settled;
	}



	
		
	
}
