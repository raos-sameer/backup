package au.com.stgeorge.mbank.controller.newaccount;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import au.com.stgeorge.framework.common.logging.Logger;
import au.com.stgeorge.framework.common.model.User;
import au.com.stgeorge.framework.common.util.StringMethods;
import au.com.stgeorge.ibank.businessobject.AccountFilter;
import au.com.stgeorge.ibank.businessobject.BusinessException;
import au.com.stgeorge.ibank.businessobject.ResourceException;
import au.com.stgeorge.ibank.businessobject.acctsvc.AccountService;
import au.com.stgeorge.ibank.businessobject.acctsvc.DDAAccountOpeningService;
import au.com.stgeorge.ibank.businessobject.acctsvc.TDAAccountService;
import au.com.stgeorge.ibank.common.cache.IBankParams;
import au.com.stgeorge.ibank.common.log.IBankLog;
import au.com.stgeorge.ibank.util.ServiceHelper;
import au.com.stgeorge.ibank.valueobject.Account;
import au.com.stgeorge.ibank.valueobject.Customer;
import au.com.stgeorge.ibank.valueobject.TDAForecastVO;
import au.com.stgeorge.ibank.valueobject.TermDepositAccount;
import au.com.stgeorge.ibank.valueobject.TermDepositProduct;
import au.com.stgeorge.ibank.valueobject.TermDepositProductVO;
import au.com.stgeorge.ibank.valueobject.ThirdParty;
import au.com.stgeorge.ibank.valueobject.database.AcctOpeningVO;
import au.com.stgeorge.ibank.valueobject.database.BranchVO;
import au.com.stgeorge.ibank.valueobject.database.CodesVO;
import au.com.stgeorge.ibank.valueobject.database.OriginsVO;
import au.com.stgeorge.ibank.valueobject.database.RegionVO;
import au.com.stgeorge.ibank.valueobject.transfer.IBankCommonData;
import au.com.stgeorge.ibank.valueobject.transfer.NewTermDepositAccount;
import au.com.stgeorge.ibank.valueobject.transfer.TermDepositProductList;
import au.com.stgeorge.ibank.valueobject.transfer.TermDepositRenewal;
import au.com.stgeorge.mbank.controller.IMBController;
import au.com.stgeorge.mbank.controller.customer.LogonHelper;
import au.com.stgeorge.mbank.model.common.IMBReq;
import au.com.stgeorge.mbank.model.common.IMBResp;
import au.com.stgeorge.mbank.model.common.ReqHeader;
import au.com.stgeorge.mbank.model.common.RespHeader;
import au.com.stgeorge.mbank.model.request.newaccount.OpenDDAReq;
import au.com.stgeorge.mbank.model.request.newaccount.TermDepositReq;
import au.com.stgeorge.mbank.model.response.ErrorResp;
import au.com.stgeorge.mbank.session.MobileSession;
import au.com.stgeorge.mbank.util.FraudLogger;
import au.com.stgeorge.mbank.util.MBAppConstants;
import au.com.stgeorge.mbank.util.MBAppHelper;
import au.com.stgeorge.mbank.util.MBAppUtils;
import au.com.stgeorge.mbank.util.MBAppValidator;
import au.com.stgeorge.mobilebank.businessobject.MobileBankService;
import au.com.stgeorge.mobilebank.businessobject.OpenDDAService;
import au.com.stgeorge.mobilebank.businessobject.TermDepositService;
import au.com.stgeorge.mobilebank.businessobject.impl.TermDepositServiceImpl;
import au.com.stgeorge.perflogger.PerformanceLogger;

import com.fasterxml.jackson.databind.ObjectMapper;


@Controller
@RequestMapping("/termdep")
public class TermDepositController implements IMBController
{

	private static final String OPEN_TDA_ACCOUNT = "openTDAAccount";

	private FraudLogger fraudLogger;
	
	@Autowired
	private MBAppHelper mbAppHelper;
	
	@Autowired
	private OpenDDAHelper openDDAHelper;
	
	@Autowired
	private DDAAccountOpeningService ddaAcctOpenSvc;
	
	@Autowired
	private OpenDDAService openDDAService;
	
	@Autowired
	private MobileBankService mobileBankService;
	
	@Autowired
	private LogonHelper logonHelper;
	
	
	@Autowired
	private TDAAccountService tdaAcctSvc;
	
	
	private TermDepositHelper tdaHelper = new TermDepositHelper();
	private TermDepositService termDepositService = new TermDepositServiceImpl();

	
	@RequestMapping(value="products", method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public IMBResp getFundingAccount(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse,
			@RequestBody final TermDepositReq req)
	{
		Logger.debug("In getFundingAccount ( OpenDDAController )  for Customer " +  "  " + httpServletRequest.getContentType() + " "
				+ httpServletRequest.getRemoteAddr() + "  " + httpServletResponse.getCharacterEncoding() + httpServletResponse.getLocale() +
				" True IP >> " + httpServletRequest.getHeader(IBankParams.trueClientIP()), this.getClass());

		PerformanceLogger performanceLogger = new PerformanceLogger();
		fraudLogger = new FraudLogger();
		performanceLogger.startAllLogs();
		String logName = MBAppUtils.getLogName(httpServletRequest);
		performanceLogger.startLog(logName);
		ObjectMapper mapper = new ObjectMapper();
		TDAForecastVO forecastVO = null;

		MobileSession mbSession =  null;
		try
		{
			Logger.info("getFundingAccount JSON Request :" + mapper.writeValueAsString(req), this.getClass());
			mbSession = mbAppHelper.getMobileSession(httpServletRequest);		

      validateRequestHeader( req.getHeader(), httpServletRequest );
			ErrorResp errorResp = validate(req, httpServletRequest);
			if (errorResp != null && errorResp.getErrors() != null && errorResp.getErrors().size() > 0)
			{
				return errorResp;
			}
			IBankCommonData ibankCommonData = mbAppHelper.populateIBankCommonData(mbSession, httpServletRequest);
			OriginsVO originVO = IBankParams.getOrigin(ibankCommonData.getOrigin());
			
			TermDepositAccount tdaAccount = null;
			if(req.getIsRenew()) {
				if(req.getRenewTDAIndex() != null){
					Customer customer = mbSession.getCustomer();
					Account acct = mbAppHelper.getAccountFromCustomer(customer, req.getRenewTDAIndex() );
					tdaAccount = (TermDepositAccount)termDepositService.getTDAAccount(acct.getAccountId(), ibankCommonData);;
					TermDepositProductVO tdaProdList = getRenewProductList(ibankCommonData, tdaAccount, req );
					mbSession.setTermDepositProductList(tdaProdList.getProductList());
					
					Logger.debug("Inside getTDARates: retRateInd: " + tdaAccount.getRetentionRateInd(), this.getClass());
//					tdaAccount.setRetentionRateInd("Y");
//					if(tdaAccount.getAvailableBalance().compareTo(new BigDecimal(termDepBean.getTdaAmount())) == -1)
/*					if(new BigDecimal(req.getTdaAmount()).compareTo(tdaAccount.getAvailableBalance()) == -1)
					{
						req.setLooseRetIndFlag(true);
						Logger.debug("Inside getTDARates: Amount less: ", this.getClass());
					}
					else {  */
						BigDecimal var = new BigDecimal(req.getTdaAmount());
						Logger.debug("Application Id:" + tdaAccount.getAccountId().getApplicationId() + ":" +
								"Application Id:" + tdaAccount.getAccountId().getApplicationId() + ":" +
								"getAccountNumber Id:" + tdaAccount.getAccountId().getAccountNumber() + ":" +
								"getSubProductCode Id:" + tdaAccount.getAccountId().getSubProductCode() + ":" +
								"getTdaAmount var Id:" + var + ":" +
								"getTdaTerm Id:" + req.getTdaTerm() + ":" +
								"tdaProdList.getCampaignCode() Id:" + tdaProdList.getCampaignCode() + ":" +
								"getAccountKey Id:" + tdaAccount.getAccountId().getAccountKey() + ":" +
								"getBranchKey Id:" + tdaAccount.getAccountId().getBranchKey() + ":", 
								getClass());
						
						if("Y".equalsIgnoreCase(tdaAccount.getRetentionRateInd()) ) //&& isChangeInAmountAndTerm(tdaAccount, new BigDecimal(req.getTdaAmount()), req.getTdaTerm())) {
						{
							boolean isForCastInqReq = makeForCastInquiry(tdaProdList.getProductList(), tdaAccount );
							
							if(new BigDecimal(req.getTdaAmount()).compareTo(tdaAccount.getOrgPrincipalAmt()) == -1 || ! isForCastInqReq )
							{
								req.setLooseRetIndFlag(true);
								Logger.debug("Inside getTDARates: Amount less: ", this.getClass());
							}
							else
							{
								forecastVO = tdaAcctSvc.getTDAForecastDetails(tdaAccount, 
										new BigDecimal(req.getTdaAmount()).setScale(2), req.getTdaTerm(), tdaProdList.getCampaignCode());
								
								Logger.debug("Forecastvo values ... :" + forecastVO.getAccountNum()+", "+forecastVO.getApplID() +", "+ forecastVO.getCampaignRate() +", "+
										forecastVO.getCurrentInterestRate()+", "+ forecastVO.getNewInterestRate()+", "+ forecastVO.getNewInterestRateType()+", "+
										forecastVO.getSubProductcode(), this.getClass());
							}
						}
					}
			}
			else
			{
				TermDepositProductList tdaProdList = getProductList(ibankCommonData,  req);
				mbSession.setTermDepositProductList(tdaProdList.getProductList());
			}
			
			Collection<Account> fundingAcctList = termDepositService.getFundingAccounts(ibankCommonData);

			Collection<RegionVO> regions = null;
			if ( MBAppConstants.ORIGIN_MBSA.equals(ibankCommonData.getOrigin()))
			{
				regions = openDDAService.getRegion();
			}
			IMBResp serviceResponse = tdaHelper.populateProductResponse(mbSession, fundingAcctList,mbSession.getCustomer().getAccounts(), ibankCommonData.getOrigin(), forecastVO, req.isLooseRetIndFlag(), req.getIsRenew(), regions, tdaAccount);
			Logger.info("getFundingAccount JSON Response :" + mapper.writeValueAsString(serviceResponse), this.getClass());
			RespHeader headerResp = populateResponseHeader(req.getHeader().getServiceName(), mbSession);
			serviceResponse.setHeader(headerResp);
			return serviceResponse;
		} catch (BusinessException e)
		{
			Logger.error("Exception Inside getFundingAccount() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			IMBResp resp1 = MBAppUtils.createErrorResp(mbSession.getOrigin(), e, MBAppConstants.SMPL_OPENDDAACCOUNT_RESP_NAME, httpServletRequest);
			return resp1;
		}
		catch (Exception e)
		{
			Logger.error("Exception Inside getFundingAccount() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			BusinessException exp = new BusinessException(BusinessException.SYSTEM_UNAVILABLE);
			IMBResp resp1 = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, MBAppConstants.SMPL_OPENDDAACCOUNT_RESP_NAME, httpServletRequest);
			return resp1;
		} finally
		{
			performanceLogger.endLog(logName);
			performanceLogger.endAllLogs();
		}
	}
	@RequestMapping(value="branches", method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public IMBResp getBranches(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse,
			@RequestBody final OpenDDAReq req)
	{
		Logger.debug("In getBranches ( OpenDDAController )  for OpenDDA " +  "  " + httpServletRequest.getContentType() + " "
				+ httpServletRequest.getRemoteAddr() + "  " + httpServletResponse.getCharacterEncoding() + httpServletResponse.getLocale() +
				" True IP >> " + httpServletRequest.getHeader(IBankParams.trueClientIP()), this.getClass());

		PerformanceLogger performanceLogger = new PerformanceLogger();
		fraudLogger = new FraudLogger();
		performanceLogger.startAllLogs();
		String logName = MBAppUtils.getLogName(httpServletRequest);
		performanceLogger.startLog(logName);
		ObjectMapper mapper = new ObjectMapper();
		MobileSession mbSession = null;
		try
		{
			Logger.info("getBranches JSON Request :" + mapper.writeValueAsString(req), this.getClass());
			mbSession = mbAppHelper.getMobileSession(httpServletRequest);		

      validateRequestHeader( req.getHeader(), httpServletRequest );
			ErrorResp errorResp = validate(req, httpServletRequest);
			if (errorResp != null && errorResp.getErrors() != null && errorResp.getErrors().size() > 0)
			{
				return errorResp;
			}
			List<BranchVO> branches = openDDAService.getBranch(req.getRegionId());
			IMBResp serviceResponse = openDDAHelper.populateBranchDtlResp(branches);
			Logger.info("getBranches JSON Response :" + mapper.writeValueAsString(serviceResponse), this.getClass());
			RespHeader headerResp = populateResponseHeader(req.getHeader().getServiceName(), mbSession);
			serviceResponse.setHeader(headerResp);
			return serviceResponse;
		} catch (BusinessException e)
		{
			Logger.error("Exception Inside getBranches() for OpenDDA GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			BusinessException exp = new BusinessException(e.getKey());
			IMBResp resp1 = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, MBAppConstants.SMPL_OPENDDAACCOUNT_RESP_NAME, httpServletRequest);
			return resp1;
		} catch (Exception e)
		{
			Logger.error("Exception Inside getBranches() for OpenDDA GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			BusinessException exp = new BusinessException(BusinessException.SYSTEM_UNAVILABLE);
			IMBResp resp1 = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, MBAppConstants.SMPL_OPENDDAACCOUNT_RESP_NAME, httpServletRequest);
			return resp1;
		} finally
		{
			performanceLogger.endLog(logName);
			performanceLogger.endAllLogs();
		}
	}

	@RequestMapping(value="branchaddress", method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public IMBResp getBranch(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse,
			@RequestBody final OpenDDAReq req)
	{
		Logger.debug("In getBranch ( OpenDDAController )  for Customer " +  "  " + httpServletRequest.getContentType() + " "
				+ httpServletRequest.getRemoteAddr() + "  " + httpServletResponse.getCharacterEncoding() + httpServletResponse.getLocale() +
				" True IP >> " + httpServletRequest.getHeader(IBankParams.trueClientIP()), this.getClass());

		PerformanceLogger performanceLogger = new PerformanceLogger();
		fraudLogger = new FraudLogger();
		performanceLogger.startAllLogs();
		String logName = MBAppUtils.getLogName(httpServletRequest);
		performanceLogger.startLog(logName);
		ObjectMapper mapper = new ObjectMapper();
		MobileSession mbSession = null;
		try
		{
			Logger.info("getBranch JSON Request :" + mapper.writeValueAsString(req), this.getClass());
			mbSession = mbAppHelper.getMobileSession(httpServletRequest);		

      validateRequestHeader( req.getHeader(), httpServletRequest );
			ErrorResp errorResp = validate(req, httpServletRequest);
			if (errorResp != null && errorResp.getErrors() != null && errorResp.getErrors().size() > 0)
			{
				return errorResp;
			}
			List<BranchVO> branches = openDDAService.getBranch(req.getRegionId());
			BranchVO branch = getBranch(branches, req.getBranchId());			
			IMBResp serviceResponse = openDDAHelper.populateBranchResp(branch);
			Logger.info("getFundingAccount JSON Response :" + mapper.writeValueAsString(serviceResponse), this.getClass());
			RespHeader headerResp = populateResponseHeader(req.getHeader().getServiceName(), mbSession);
			serviceResponse.setHeader(headerResp);
			return serviceResponse;
		} catch (BusinessException e)
		{
			Logger.error("Exception Inside getFundingAccount() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			BusinessException exp = new BusinessException(e.getKey());
			IMBResp resp1 = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, MBAppConstants.SMPL_OPENDDAACCOUNT_RESP_NAME, httpServletRequest);
			return resp1;
		} catch (Exception e)
		{
			Logger.error("Exception Inside getFundingAccount() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			BusinessException exp = new BusinessException(BusinessException.SYSTEM_UNAVILABLE);
			IMBResp resp1 = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, MBAppConstants.SMPL_OPENDDAACCOUNT_RESP_NAME, httpServletRequest);
			return resp1;
		} finally
		{
			performanceLogger.endLog(logName);
			performanceLogger.endAllLogs();
		}
	}
	
	@RequestMapping(value="openTDA", method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public IMBResp openDDAAccount(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse,
			@RequestBody final TermDepositReq req)
	{
		Logger.debug("In openDDAAccount ( OpenDDAController )  for Customer " +  "  " + httpServletRequest.getContentType() + " "
				+ httpServletRequest.getRemoteAddr() + "  " + httpServletResponse.getCharacterEncoding() + httpServletResponse.getLocale() +
				" True IP >> " + httpServletRequest.getHeader(IBankParams.trueClientIP()), this.getClass());
		PerformanceLogger performanceLogger = new PerformanceLogger();
		fraudLogger = new FraudLogger();
		performanceLogger.startAllLogs();
		String logName = MBAppUtils.getLogName(httpServletRequest);
		performanceLogger.startLog(logName);
		ObjectMapper mapper = new ObjectMapper();
		MobileSession mbSession = null;
		try
		{
			Logger.info("openDDAAccount JSON Request :" + mapper.writeValueAsString(req), this.getClass());
			mbSession = mbAppHelper.getMobileSession(httpServletRequest);		
      validateRequestHeader( req.getHeader(), httpServletRequest );

			ErrorResp errorResp = validate(req, httpServletRequest);
			if (errorResp != null && errorResp.getErrors() != null && errorResp.getErrors().size() > 0)
			{
				return errorResp;
			}
			IBankCommonData ibankCommonData = mbAppHelper.populateIBankCommonData(mbSession, httpServletRequest);
			IMBResp serviceResponse;
			if(req.isCheckDuplicate()){
				ArrayList duplicateAcctOpeningList = checkDuplicateAcctOpeningReq(ibankCommonData, req.getProduct().getSubProdcode());
				if(duplicateAcctOpeningList!=null && duplicateAcctOpeningList.size() > 0){
					serviceResponse = tdaHelper.populateDuplicateAcctsList(mbSession, duplicateAcctOpeningList, mbSession.getSecurityUniqueID());
				}
				else{
					NewTermDepositAccount account = tdaHelper.populateNewTermDepositAccount(mbSession, req, ibankCommonData);
					NewTermDepositAccount newDDAAccount = (NewTermDepositAccount) termDepositService.openAccount(account);
					//ArrayList<au.com.stgeorge.mbank.model.common.AccountResp> accountList = logonHelper.populateAccountList(mbSession.getCustomer().getAccounts());
					serviceResponse = tdaHelper.populateopenTDAAccountResp(newDDAAccount);
				}
			}
			else{
				NewTermDepositAccount account = tdaHelper.populateNewTermDepositAccount(mbSession, req, ibankCommonData);
				NewTermDepositAccount newDDAAccount = (NewTermDepositAccount) termDepositService.openAccount(account);
				//ArrayList<au.com.stgeorge.mbank.model.common.AccountResp> accountList = logonHelper.populateAccountList(mbSession.getCustomer().getAccounts());
				serviceResponse = tdaHelper.populateopenTDAAccountResp(newDDAAccount);
			}
			if (req.getIsRenew())
			{
				TermDepositRenewal renewalObj =  buildRenewTermDepositAccount(req,ibankCommonData,mbSession);
				
				renewalObj = termDepositService.renewAccount(renewalObj);
				
				//Do statistic log entry
				tdaHelper.addStatticLog(renewalObj);
				//This host call is required to get the new balance and new maturity date after successful renew
				TermDepositAccount tdaAccount = (TermDepositAccount)termDepositService.getTDAAccount(renewalObj.getAccount().getAccountId(),ibankCommonData);
				renewalObj.setAccount(tdaAccount);
			}
			//NewTermDepositAccount account = tdaHelper.populateNewTermDepositAccount(mbSession, req, ibankCommonData);
			//NewTermDepositAccount newDDAAccount = (NewTermDepositAccount) termDepositService.openAccount(account);
			//ArrayList<au.com.stgeorge.mbank.model.common.AccountResp> accountList = logonHelper.populateAccountList(mbSession.getCustomer().getAccounts());
			//serviceResponse = tdaHelper.populateopenTDAAccountResp(newDDAAccount);
			//}
			Logger.info("openDDAAccount JSON Response :" + mapper.writeValueAsString(serviceResponse), this.getClass());
			RespHeader headerResp = populateResponseHeader(req.getHeader().getServiceName(), mbSession);
			serviceResponse.setHeader(headerResp);
			return serviceResponse;
		} catch (BusinessException e)
		{
			Logger.error("Exception Inside openDDAAccount() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			IMBResp resp1 = MBAppUtils.createErrorResp(mbSession.getOrigin(), e, MBAppConstants.SMPL_OPENDDAACCOUNT_RESP_NAME, httpServletRequest);
			return resp1;
		}
		catch (Exception e)
		{
			Logger.error("Exception Inside openDDAAccount() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			BusinessException exp = new BusinessException(BusinessException.SYSTEM_UNAVILABLE);
			IMBResp resp1 = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, MBAppConstants.SMPL_OPENDDAACCOUNT_RESP_NAME, httpServletRequest);
			return resp1;
		} finally
		{
			performanceLogger.endLog(logName);
			performanceLogger.endAllLogs();
		}
	}

	
	@RequestMapping(value="renewTDA", method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public IMBResp renewDDAAccount(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse,
			@RequestBody final TermDepositReq req)
	{
		Logger.debug("In renewDDAAccount ( TDAController )  for Customer " +  "  " + httpServletRequest.getContentType() + " "
				+ httpServletRequest.getRemoteAddr() + "  " + httpServletResponse.getCharacterEncoding() + httpServletResponse.getLocale() +
				" True IP >> " + httpServletRequest.getHeader(IBankParams.trueClientIP()), this.getClass());
		PerformanceLogger performanceLogger = new PerformanceLogger();
		fraudLogger = new FraudLogger();
		performanceLogger.startAllLogs();
		String logName = MBAppUtils.getLogName(httpServletRequest);
		performanceLogger.startLog(logName);
		ObjectMapper mapper = new ObjectMapper();
		MobileSession mbSession = null;
		try
		{
			Logger.info("TDAController JSON Request :" + mapper.writeValueAsString(req), this.getClass());
			mbSession = mbAppHelper.getMobileSession(httpServletRequest);		

      validateRequestHeader( req.getHeader(), httpServletRequest );
			
			ErrorResp errorResp = validate(req, httpServletRequest);
			if (errorResp != null && errorResp.getErrors() != null && errorResp.getErrors().size() > 0)
			{
				return errorResp;
			}
			IBankCommonData ibankCommonData = mbAppHelper.populateIBankCommonData(mbSession, httpServletRequest);
			IMBResp serviceResponse = null ;
			TermDepositRenewal renewalObj = null;
			if (req.getIsRenew())
			{
				renewalObj =  buildRenewTermDepositAccount(req,ibankCommonData,mbSession);
				
				renewalObj = termDepositService.renewAccount(renewalObj);
				
				//Do statistic log entry
			//	tdaHelper.addStatticLog(renewalObj);
				
				//This host call is required to get the new balance and new maturity date after successful renew
				TermDepositAccount tdaAccount = (TermDepositAccount)termDepositService.getTDAAccount(renewalObj.getAccount().getAccountId(),ibankCommonData);
				renewalObj.setAccount(tdaAccount);
			}
			//NewTermDepositAccount account = tdaHelper.populateNewTermDepositAccount(mbSession, req, ibankCommonData);
			//NewTermDepositAccount newDDAAccount = (NewTermDepositAccount) termDepositService.openAccount(account);
			//ArrayList<au.com.stgeorge.mbank.model.common.AccountResp> accountList = logonHelper.populateAccountList(mbSession.getCustomer().getAccounts());
			//serviceResponse = tdaHelper.populateopenTDAAccountResp(newDDAAccount);
			//}
			
			serviceResponse = tdaHelper.popultaeRenewReceipt(renewalObj);

			Logger.info("openDDAAccount JSON Response :" + mapper.writeValueAsString(serviceResponse), this.getClass());
			RespHeader headerResp = populateResponseHeader(req.getHeader().getServiceName(), mbSession);
			serviceResponse.setHeader(headerResp);
			return serviceResponse;
		} catch (BusinessException e)
		{
			Logger.error("Exception Inside openDDAAccount() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			
            if(BusinessException.INVALID_MIN_AMT_TDA == e.getKey()){
                CodesVO myCodesVO = IBankParams.getCodesData(IBankParams.DEFAULT_ORIGIN, IBankParams.CATEGORY_TERM_DEP, IBankParams.CD_NEW_ACC_MIN_AMT);
                String[] params = {"Term Deposit Account", myCodesVO.getMessage()};
                return MBAppUtils.createErrorResp(mbSession.getOrigin(), BusinessException.INVALID_MIN_AMT_TDA, MBAppUtils.getMessage(mbSession.getOrigin(), BusinessException.INVALID_MIN_AMT_TDA, params), MBAppConstants.SMPL_OPENDDAACCOUNT_RESP_NAME, httpServletRequest);
            }
			
			IMBResp resp1 = MBAppUtils.createErrorResp(mbSession.getOrigin() , e, MBAppConstants.SMPL_OPENDDAACCOUNT_RESP_NAME, httpServletRequest);
			return resp1;
		}
		catch (Exception e)
		{
			Logger.error("Exception Inside openDDAAccount() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			BusinessException exp = new BusinessException(BusinessException.SYSTEM_UNAVILABLE);
			IMBResp resp1 = MBAppUtils.createErrorResp(mbSession.getOrigin(),exp, MBAppConstants.SMPL_OPENDDAACCOUNT_RESP_NAME, httpServletRequest);
			return resp1;
		} finally
		{
			performanceLogger.endLog(logName);
			performanceLogger.endAllLogs();
		}
	}

	
	
	
	
	
	
	
	
	
	
	
	
	
	private TermDepositRenewal buildRenewTermDepositAccount(TermDepositReq req,IBankCommonData commonData, MobileSession mbSession) throws ResourceException, BusinessException{
		TermDepositRenewal renewalObj = new TermDepositRenewal();
		Customer customer=mbSession.getCustomer();
		User user=mbSession.getUser();
		
		//IBankCommonData commonData=populateIBankCommonData(customer,user);

		renewalObj.setCommonData(commonData);
		renewalObj.setCustomer(customer);
	
		if(req.getRenewTDAIndex() != null ){
			Account acct = mbAppHelper.getAccountFromCustomer(mbSession.getCustomer(), req.getRenewTDAIndex());
			TermDepositAccount tdaAccount = (TermDepositAccount)termDepositService.getTDAAccount(acct.getAccountId(),commonData);
			renewalObj.setAccount(tdaAccount);
		}
		
//		renewalObj.setAddWidthdrawlIndicator(req.getRenewalOption());
		renewalObj.setAddWidthdrawlIndicator( Integer.parseInt(  req.getRenewalOption()) );
		
		if(!StringMethods.isEmptyString(req.getTdaAmount())){
			renewalObj.setTransferAmount(new BigDecimal(req.getTdaAmount()));
		}
		renewalObj.setTermLength(req.getTdaTerm());
		
		ArrayList<TermDepositProduct> tdaProdList = (ArrayList<TermDepositProduct>)mbSession.getTermDepositProductList();
		TermDepositProduct tdaProd = new TermDepositProduct();
		
		/** HashMap of available interest instructions for account */
		HashMap availableInterestInstructions = new HashMap();
		
		for(int i=0; i < tdaProdList.size() ; i++){
			tdaProd = (TermDepositProduct)tdaProdList.get(i);
			if(tdaProd.getSubProductCode().equalsIgnoreCase(req.getProduct().getSubProdcode())){
				renewalObj.setSelectedProduct(tdaProd);
				break;
			}
		}
		
		renewalObj.setInterestPaymentOption(req.getInterestPayInst());
		//Get interest paid to account
		String selInterestToIndex = req.getIntrPayToAcctIndex();
		if(!StringMethods.isEmptyString(selInterestToIndex)){
			selInterestToIndex = selInterestToIndex.replace('|',',');
			String[] tempStr = selInterestToIndex.split(",");
			if(tempStr.length < 2){
				String acctIndex = tempStr[0].trim();
				Account intrToAcct = mbAppHelper.getAccountFromCustomer(customer, Integer.parseInt(acctIndex));
				if(intrToAcct != null){
					renewalObj.setSelectedToAccount(intrToAcct.getAccountId());
				}
			}
			else if(MBAppConstants.KEY_IDENTIFIER_THIRD_PARTY.equalsIgnoreCase(tempStr[0].trim())){
				String acctIndex = tempStr[1].trim();
				ThirdParty intrToTP = mbAppHelper.getThirdPartyFromCustomer(customer, Integer.parseInt(acctIndex));
				renewalObj.setSelectedToAccount(intrToTP);
			}
		}
		
		//Get account object from the index for source funds from account
		if(!StringMethods.isEmptyString(req.getSourceAcctIndex().toString())){
			Account sourceAcct = mbAppHelper.getAccountFromCustomer(customer, req.getSourceAcctIndex());
			renewalObj.setSourceFromAccount(sourceAcct);
		}

		if(req.getLeadIdTda() != null)
			renewalObj.setLeadId(req.getLeadIdTda());
		
		return renewalObj;
	}
	
	
	
	public BranchVO getBranch(List<BranchVO> branchList, String branchId) throws BusinessException, ResourceException{
		Iterator<BranchVO> it = branchList.iterator();
		BranchVO branch = null;
		while (it.hasNext()) {
			branch = it.next();
			if (branch.getBranchId().equalsIgnoreCase(branchId))
				break;
		}
		if (branch == null) 
			throw new BusinessException(BusinessException.GENERIC_ERROR);
		return branch;
	}	
	

	public ArrayList checkDuplicateAcctOpeningReq(IBankCommonData commonData, String selProduct) throws BusinessException{
		 boolean isDuplicate=false;
		 ArrayList duplicateAcctOpeningList=null;
		 
		 //Customer customer=mobileSession.getCustomer();
		 //User user=mobileSession.getUser();
			
		 //IBankCommonData commonData=populateIBankCommonData(customer,user);
			
		  try{
				AcctOpeningVO newAcct=new AcctOpeningVO();
				newAcct.setGcisNumber(commonData.getUser().getGCISNumber());
				newAcct.setSubProdCode(""+selProduct);			
				duplicateAcctOpeningList=(ArrayList)termDepositService.getDuplicateReqList(newAcct);
			}
			catch(BusinessException e){
				if(e.getKey()==BusinessException.MAX_TD_ACCT_OPENING_REQ){
					IBankLog.logWRN("Max TDA Acct Opening Req reached ", this.getClass());
					e = new BusinessException(BusinessException.MAX_ACCT_OPENING_REQ);
					throw e;
				}
			}
			catch(ResourceException re){
				IBankLog.logWRN("Resourceexception in checkTDDuplicateAcctOpeningReq() ", this.getClass());
			}	  
			return duplicateAcctOpeningList;
	}


	public ErrorResp validate(IMBReq serviceRequest, HttpServletRequest request) {
		return  mbAppValidator.validate(serviceRequest, request);
	}
	
	public void validateRequestHeader(ReqHeader header, HttpServletRequest request) throws ResourceException
	{
		mbAppValidator.validateRequestHeader(header,  request);
	}

	public boolean isChangeInAmountAndTerm(TermDepositAccount tdaAccount, BigDecimal newTermDepBal, int newTermInMon) {
		Logger.debug("Inside : isChangeInAmountAndTerm() " + newTermDepBal + ", " + newTermInMon + ", " + tdaAccount.getBalance() + ", " + tdaAccount.getTermInMonth(), this.getClass());
		if( (tdaAccount.getBalance().compareTo(newTermDepBal) != 0) || (tdaAccount.getTermInMonth() != newTermInMon) ){
			Logger.debug("Returns true: isChangeInAmountAndTerm() " , this.getClass());
			return true;
		}
		else {
			Logger.debug("Returns false: isChangeInAmountAndTerm() " , this.getClass());
			return false;
		}
	}


	
	///  termdep/renew - JS
	
	@RequestMapping(value="renewalDetails", method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public IMBResp getRenewAccountDetail(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse,
			@RequestBody final TermDepositReq req)
	{
		Logger.debug("In getAccountDetail ( TermDepositContrioller )  for Customer " +  "  " + httpServletRequest.getContentType() + " "
				+ httpServletRequest.getRemoteAddr() + "  " + httpServletResponse.getCharacterEncoding() + httpServletResponse.getLocale()
				+ " True IP >> " + httpServletRequest.getHeader(IBankParams.trueClientIP()), this.getClass());
		PerformanceLogger performanceLogger = new PerformanceLogger();
		fraudLogger = new FraudLogger();
		performanceLogger.startAllLogs();
		String logName = MBAppUtils.getLogName(httpServletRequest);
		performanceLogger.startLog(logName);
		ObjectMapper mapper = new ObjectMapper();
		MobileSession mbSession = null;
		try
		{
//			Logger.info("getAccountDetail JSON Request :" + mapper.writeValueAsString(req), this.getClass());
			mbSession = mbAppHelper.getMobileSession(httpServletRequest);		

      validateRequestHeader( req.getHeader(), httpServletRequest );
			
			ErrorResp errorResp = validate(req, httpServletRequest);
			if (errorResp != null && errorResp.getErrors() != null && errorResp.getErrors().size() > 0)
			{
				return errorResp;
			}
			IBankCommonData ibankCommonData = mbAppHelper.populateIBankCommonData(mbSession, httpServletRequest);
			
			Account acct = mbAppHelper.getAccountFromCustomer(mbSession.getCustomer(), req.getRenewTDAIndex());
			TermDepositAccount tdaAccount = (TermDepositAccount)termDepositService.getTDAAccount(acct.getAccountId(), ibankCommonData);
//			Collection<Account> fundingAcctList = termDepositService.getFundingAccounts(ibankCommonData);
			Collection<Account> fundingAcctList = AccountFilter.getTermDepDepositToAccounts(mbSession.getCustomer().getAccounts());
			IMBResp serviceResponse = tdaHelper.getRenewAccountDetail(mbSession, tdaAccount, fundingAcctList);
			Logger.info("getAccountDetail JSON Response :" + mapper.writeValueAsString(serviceResponse), this.getClass());
			RespHeader headerResp = populateResponseHeader(req.getHeader().getServiceName(), mbSession);
			serviceResponse.setHeader(headerResp);
			return serviceResponse;
		} catch (BusinessException e)
		{
			Logger.error("Exception Inside getAccountDetail() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			BusinessException exp = new BusinessException(e.getKey());
			IMBResp resp1 = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, MBAppConstants.SMPL_OPENDDAACCOUNT_RESP_NAME, httpServletRequest);
			return resp1;
		}
		catch (Exception e)
		{
			Logger.error("Exception Inside getAccountDetail() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			BusinessException exp = new BusinessException(BusinessException.SYSTEM_UNAVILABLE);
			IMBResp resp1 = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, MBAppConstants.SMPL_OPENDDAACCOUNT_RESP_NAME, httpServletRequest);
			return resp1;
		} finally
		{
			performanceLogger.endLog(logName);
			performanceLogger.endAllLogs();
		}
	}

	private boolean makeForCastInquiry(Collection<TermDepositProduct> productList, TermDepositAccount tdaAccount )
	{
		ArrayList<TermDepositProduct> termDepositProductList = new ArrayList<TermDepositProduct>();
		Iterator<TermDepositProduct> iterator = productList.iterator();
		boolean makeForecast = false;
		while (iterator.hasNext())
		{
			TermDepositProduct termDepositProduct = iterator.next();
			Logger.debug(" termDepositProduct.getSubProductCode() " +  termDepositProduct.getSubProductCode() + " tda Sub "+ tdaAccount.getAccountId().getSubProductCode() , this.getClass());
			if (termDepositProduct.getSubProductCode().equalsIgnoreCase( tdaAccount.getAccountId().getSubProductCode()) )
			{
				makeForecast=  true;
				break;
			}
		}
		return makeForecast;
	}
	
	private TermDepositProductVO getRenewProductList(IBankCommonData commonData, TermDepositAccount tdaAccount, TermDepositReq req )throws BusinessException, ResourceException
	{
		TermDepositProductVO product = new TermDepositProductVO();

		product.setUser(commonData.getUser());
		product.setCustomer(commonData.getCustomer());
		
		OriginsVO originVo = IBankParams.getOrigin(commonData.getOrigin());
		product.setInstitutionTypeIndicator(originVo.getInstTypeInd());
		product.setOrigin(commonData.getOrigin());

		// set the campaign code here
/*		renewTDA.setSpOfferInd(accountSessionInfo.isSpOfferInd());
		if (renewTDA.isSpOfferInd()) {
			product.setCampaignCode(accountSessionInfo.getElead().getCampaignId());
			// get terms and conditions text
			getSpecialOfferText(accountSessionInfo, renewTDA);
		}  */
		
		product.setLedgerBranch(tdaAccount.getDomicileBranch());
		product.setMaturityDate(tdaAccount.getMaturityDate());
		product.setOpenDate(tdaAccount.getOpenDate());
		product.setTermInMonths(new Integer(req.getTdaTerm()).intValue());
		product.setRollOverDate(tdaAccount.getTermDepositAdditionalInfo().getRollOverDate());
		product.setAmount(new BigDecimal(req.getTdaAmount()));
		product.setFlexi("Flexi Term Deposit Account".equalsIgnoreCase(tdaAccount.getName()));
		// get product list
		AccountService acctSvc = (AccountService) ServiceHelper.getBean("acctSvc");
		product = acctSvc.getProductListRenew(product);
		return product;
	}

	
	private TermDepositProductList getProductList(IBankCommonData commonData,  TermDepositReq req ) throws BusinessException, ResourceException
	{
		TermDepositProductList transfer = new TermDepositProductList();

		transfer.setUser(commonData.getUser());
		transfer.setCustomer(commonData.getCustomer());

		OriginsVO originVo = IBankParams.getOrigin(commonData.getOrigin());
		transfer.setInstitutionTypeIndicator(originVo.getInstTypeInd());
		transfer.setOrigin(commonData.getOrigin());


		Calendar c = Calendar.getInstance();
		c.add(Calendar.MONTH, (new Integer(req.getTdaTerm()).intValue()));
		transfer.setAmount(new BigDecimal(req.getTdaAmount()) );
		transfer
		    .setTermInMonths(new Integer(req.getTdaTerm()).intValue());
		transfer.setState( req.getTdaState());

		// get product list
		transfer = termDepositService.getProductList(transfer);
		return transfer;

	}

	

	public RespHeader populateResponseHeader(String serviceName, MobileSession mobSession )
	{
		return mbAppHelper.populateResponseHeader(serviceName, mobSession);
	}

	

	@Autowired
	private MBAppValidator mbAppValidator;

		
}
