package au.com.stgeorge.mbank.model.accountinfo;

import java.util.Date;
import java.util.List;

import au.com.stgeorge.mbank.util.JsonDateSerializer;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;

/**
 * @author C50216
 *
 */
@JsonInclude(Include.NON_NULL)
public class InterestRateDetailResp {

	private Boolean isAdditionalDetail;
	private String baseRateType;
	private String baseRate;
	private Date baseExpiryDate;
	private String bonusRateType;
	private String bonusRate;
	private Date bonusExpiryDate;
	private String externalLink;
	private String totalRate;
	private String tierType;
	private List<InterestRateTierDetailResp> tierDetail;
	private String errorDesc;
	
	public Boolean getIsAdditionalDetail() {
		return isAdditionalDetail;
	}
	public void setIsAdditionalDetail(Boolean isAdditionalDetail) {
		this.isAdditionalDetail = isAdditionalDetail;
	}
	public String getBaseRateType() {
		return baseRateType;
	}
	public void setBaseRateType(String baseRateType) {
		this.baseRateType = baseRateType;
	}
	public String getBaseRate() {
		return baseRate;
	}
	public void setBaseRate(String baseRate) {
		this.baseRate = baseRate;
	}
	@JsonSerialize(using = JsonDateSerializer.class)
	@JsonInclude(Include.NON_NULL)
	public Date getBaseExpiryDate() {
		return baseExpiryDate;
	}
	public void setBaseExpiryDate(Date baseExpiryDate) {
		this.baseExpiryDate = baseExpiryDate;
	}
	public String getBonusRateType() {
		return bonusRateType;
	}
	public void setBonusRateType(String bonusRateType) {
		this.bonusRateType = bonusRateType;
	}
	public String getBonusRate() {
		return bonusRate;
	}
	public void setBonusRate(String bonusRate) {
		this.bonusRate = bonusRate;
	}
	@JsonSerialize(using = JsonDateSerializer.class)
	@JsonInclude(Include.NON_NULL)
	public Date getBonusExpiryDate() {
		return bonusExpiryDate;
	}
	public void setBonusExpiryDate(Date bonusExpiryDate) {
		this.bonusExpiryDate = bonusExpiryDate;
	}
	public String getExternalLink() {
		return externalLink;
	}
	public void setExternalLink(String externalLink) {
		this.externalLink = externalLink;
	}
	public String getTotalRate() {
		return totalRate;
	}
	public void setTotalRate(String totalRate) {
		this.totalRate = totalRate;
	}
	public String getTierType() {
		return tierType;
	}
	public void setTierType(String tierType) {
		this.tierType = tierType;
	}
	public List<InterestRateTierDetailResp> getTierDetail() {
		return tierDetail;
	}
	public void setTierDetail(List<InterestRateTierDetailResp> tierDetail) {
		this.tierDetail = tierDetail;
	}
	public String getErrorDesc() {
		return errorDesc;
	}
	public void setErrorDesc(String errorDesc) {
		this.errorDesc = errorDesc;
	}
			
}
