package au.com.stgeorge.mbank.controller.customer;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang.builder.ReflectionToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import au.com.stgeorge.framework.common.logging.Logger;
import au.com.stgeorge.ibank.businessobject.BusinessException;
import au.com.stgeorge.ibank.businessobject.ResourceException;
import au.com.stgeorge.ibank.valueobject.transfer.IBankCommonData;
import au.com.stgeorge.mbank.controller.IMBController;
import au.com.stgeorge.mbank.model.common.IMBReq;
import au.com.stgeorge.mbank.model.common.IMBResp;
import au.com.stgeorge.mbank.model.common.ReqHeader;
import au.com.stgeorge.mbank.model.common.RespHeader;
import au.com.stgeorge.mbank.model.request.customer.MarketingPreferencesUpdationReq;
import au.com.stgeorge.mbank.model.response.ErrorResp;
import au.com.stgeorge.mbank.model.response.SuccessResp;
import au.com.stgeorge.mbank.session.MobileSession;
import au.com.stgeorge.mbank.session.MobileSessionImpl;
import au.com.stgeorge.mbank.util.MBAppHelper;
import au.com.stgeorge.mbank.util.MBAppUtils;
import au.com.stgeorge.mbank.util.MBAppValidator;
import au.com.stgeorge.mbank.util.ServiceConstants;
import au.com.stgeorge.perflogger.PerformanceLogger;
import au.com.stgeorge.ibank.valueobject.Customer;
import au.com.stgeorge.ibank.valueobject.CustomerTypes;
import au.com.stgeorge.ibank.valueobject.Preference;
import au.com.stgeorge.ibank.businessobject.PreferencesService;

@Controller
@RequestMapping("/preferences")
public class PreferencesController implements IMBController {
	
	@Autowired
	private PerformanceLogger perfLogger;
	
	@Autowired
	private MBAppValidator mbAppValidator;
	
	@Autowired
	private MBAppHelper mbAppHelper;
	
	
	@RequestMapping(method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE, value = "updateMarketingPreferences")
	@ResponseBody
	public IMBResp updateMarketingPreferences(HttpServletRequest httpRequest, @RequestBody final MarketingPreferencesUpdationReq request){
		Logger.debug("PreferencesController - updateMarketingPreferences(). Request: " + request, this.getClass());
		String logName = startPerformanceLog(httpRequest);
		MobileSession mobileSession = new MobileSessionImpl();
		
		try {
			mobileSession.getSessionContext(httpRequest);
			validateRequestHeader(request.getHeader(), httpRequest);
			ErrorResp errorResponse = validate(request, httpRequest);
			if (errorResponse.hasErrors())
				return errorResponse;
			IBankCommonData commonData = new MBAppHelper().populateIBankCommonData(mobileSession, httpRequest);
			
			Customer myCustObj = commonData.getCustomer();
			Preference myPrefObj = myCustObj.getPreference();
			if (myCustObj != null && myPrefObj != null) {
				myPrefObj.setPhoneMarketingmodified(false);
				myPrefObj.setGeneralMarketingmodified(false);
				myPrefObj.setEMarketingmodified(false);
				if(myCustObj.isGHSCustomer() || (myCustObj.isCHSGHSCustomer() && CustomerTypes.TYPE_GHS.equals(myCustObj.getPrimaryProfile()))){
					String contactForGeneralMarketing = request.getContactForGeneralMarketing()?"Y":"N";
					String contactForTelephoneMarketing = request.getContactForTelephoneMarketing()?"Y":"N";
					String contactForElectronicMarketing = request.getContactForElectronicMarketing()?"Y":"N";
					if((myCustObj.getPreference().getContactForTelephoneMarketing() != null) && (!(myCustObj.getPreference().getContactForTelephoneMarketing()).equalsIgnoreCase(contactForTelephoneMarketing))){
						myPrefObj.setPhoneMarketingmodified(true);
						myPrefObj.setContactForTelephoneMarketing(contactForTelephoneMarketing);
						Logger.debug("Change received for Telephone marketing prefs - TelephoneMarketing:"+contactForTelephoneMarketing, this.getClass());
					}
					if((myCustObj.getPreference().getContactForGeneralMarketing() != null) && (!(myCustObj.getPreference().getContactForGeneralMarketing()).equalsIgnoreCase(contactForGeneralMarketing))){
						myPrefObj.setGeneralMarketingmodified(true);
						myPrefObj.setContactForGeneralMarketing(contactForGeneralMarketing); 
						Logger.debug("Change received for General marketing prefs - GeneralMarketing:"+contactForGeneralMarketing, this.getClass());
					}
					if((myCustObj.getPreference().getContactForElectronicMarketing() != null) && (!(myCustObj.getPreference().getContactForElectronicMarketing()).equalsIgnoreCase(contactForElectronicMarketing))){
						myPrefObj.setEMarketingmodified(true);
						myPrefObj.setContactForElectronicMarketing(contactForElectronicMarketing); 
						Logger.debug("Change received for Electronic marketing prefs - ElectronicMarketing:"+contactForElectronicMarketing, this.getClass());
					}	
				}
				myPrefObj.setDisplayELeadsSplashPage(request.getReceiveOfferViaInternetMobileBanking());
				Logger.debug("Change received for Receive Offer Via InternetMobileBanking prefs - :"+request.getReceiveOfferViaInternetMobileBanking(), this.getClass());
				PreferencesService.updateMarketingPreferences(commonData, myPrefObj);
				myCustObj.setPreference(myPrefObj);
		        commonData.setCustomer(myCustObj); 
		        mobileSession.setCustomer(myCustObj);
		        
		        return processUpdateMarketingPrefsResponse(populateResponseHeader(ServiceConstants.UPDATE_MARKETING_PREFERENCES_SERVICE, mobileSession), true);
			}else {
				Logger.info("Customer or Preference object null. Cannot update marketing prefs", this.getClass());
				throw new BusinessException(BusinessException.GENERIC_ERROR, "Cannot update customer preferences");
			}

		} catch (BusinessException e) {
			Logger.info("BusinessException in PreferencesController - updateMarketingPreferences():  - [key: " + e.getKey() + "] : GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), e, ServiceConstants.UPDATE_MARKETING_PREFERENCES_SERVICE, httpRequest);
		} catch (ResourceException e) {
			Logger.error("ResourceException in PreferencesController - updateMarketingPreferences():  - [key: " + e.getKey() + "] : GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.SYSTEM_UNAVILABLE, ServiceConstants.UPDATE_MARKETING_PREFERENCES_SERVICE, httpRequest);
		}catch (Exception e) {
			Logger.error("Exception PreferencesController - updateMarketingPreferences(): GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(),ResourceException.MOBILE_NON_FINANCIAL_FATAL_ERR, ServiceConstants.UPDATE_MARKETING_PREFERENCES_SERVICE, httpRequest);
		} finally {
			endPerformanceLog(logName);
		}
	}

	protected IMBResp processUpdateMarketingPrefsResponse(RespHeader headerResp, boolean isSuccess){			
		SuccessResp resp = new SuccessResp();
		resp.setHeader(headerResp);
		resp.setIsSuccess(isSuccess);
		return resp;
	}
	
	private String startPerformanceLog(HttpServletRequest httpRequest){
		perfLogger.startAllLogs();
		String logName = MBAppUtils.getLogName(httpRequest);
		perfLogger.startLog(logName);
		return logName;
	}

	private void endPerformanceLog(String logName){
		perfLogger.endLog(logName);
		perfLogger.endAllLogs();
	}
	
	public ErrorResp validate(IMBReq serviceRequest, HttpServletRequest request) {
		Logger.info("Service request object - " + ReflectionToStringBuilder.toString(serviceRequest), this.getClass());
		return mbAppValidator.validate(serviceRequest, request);
	}

	public void validateRequestHeader(ReqHeader headerReq, HttpServletRequest request) throws BusinessException {
		Logger.debug("Request header validation: " + ReflectionToStringBuilder.toString(headerReq, ToStringStyle.MULTI_LINE_STYLE), this.getClass());
		mbAppValidator.validateRequestHeader(headerReq, request);
	}

	public RespHeader populateResponseHeader(String serviceName, MobileSession mobSession) {
		return mbAppHelper.populateResponseHeader(serviceName, mobSession);
	}

	
}
