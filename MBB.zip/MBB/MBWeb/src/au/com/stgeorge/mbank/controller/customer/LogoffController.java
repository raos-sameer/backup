package au.com.stgeorge.mbank.controller.customer;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import au.com.stgeorge.framework.common.logging.Logger;
import au.com.stgeorge.framework.common.model.User;
import au.com.stgeorge.ibank.businessobject.BusinessException;
import au.com.stgeorge.ibank.businessobject.ResourceException;
import au.com.stgeorge.ibank.common.cache.IBankParams;
import au.com.stgeorge.ibank.valueobject.Customer;
import au.com.stgeorge.ibank.valueobject.transfer.IBankCommonData;
import au.com.stgeorge.mbank.controller.IMBController;
import au.com.stgeorge.mbank.model.common.IMBReq;
import au.com.stgeorge.mbank.model.common.IMBResp;
import au.com.stgeorge.mbank.model.common.ReqHeader;
import au.com.stgeorge.mbank.model.common.RespHeader;
import au.com.stgeorge.mbank.model.response.ErrorResp;
import au.com.stgeorge.mbank.model.response.customer.LogonOffResp;
import au.com.stgeorge.mbank.session.MobileSession;
import au.com.stgeorge.mbank.util.FraudLogger;
import au.com.stgeorge.mbank.util.MBAppHelper;
import au.com.stgeorge.mbank.util.MBAppUtils;
import au.com.stgeorge.mbank.util.MBAppValidator;
import au.com.stgeorge.mbank.util.ServiceConstants;
import au.com.stgeorge.mobilebank.businessobject.MobileMsgCntrService;
import au.com.stgeorge.perflogger.PerformanceLogger;


@Controller
@RequestMapping(method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE)
public class LogoffController implements IMBController
{

	private static final String LOGON_SRV_NAME = "logon";
	private FraudLogger fraudLogger;

	@Autowired
	private MobileMsgCntrService msgCntrService;
	
	@Autowired
	private MBAppHelper mbAppHelper;

	@Autowired
	private LogonHelper logonHelper;


	@RequestMapping("/logoff")
	@ResponseBody
	public IMBResp processLogoff(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse)
	{
			PerformanceLogger performanceLogger = new PerformanceLogger();
			String logName = MBAppUtils.getLogName(httpServletRequest);
			LogonOffResp serviceResponse = new LogonOffResp();

		try
		{
			fraudLogger = new FraudLogger();
			performanceLogger.startAllLogs();
			performanceLogger.startLog(logName);
			MobileSession mobileSession = mbAppHelper.getMobileSession(httpServletRequest);
			if ( mobileSession != null && mobileSession.getUser() != null  )
			{
				Logger.debug("In processLogoff for Customer GCIS " + mobileSession.getUser().getGCISNumber()+ " " +  httpServletRequest.getContentType() + " "
						+ httpServletRequest.getRemoteAddr() + "  " + httpServletResponse.getCharacterEncoding() + httpServletResponse.getLocale() +
						" True IP >> " + httpServletRequest.getHeader(IBankParams.trueClientIP()), this.getClass());
	
				IBankCommonData iBankCommonData = mbAppHelper.populateIBankCommonData(mobileSession, httpServletRequest);
				String origin= mobileSession.getOrigin();

				if (  logonHelper.isDemo() )
				{
					// Defect : 2063. Setting origin for DEMO.Otherwise once the customer logoff, it is always going to STG logon page. 
					 mobileSession.setCustomer(new Customer());
					 mobileSession.setUser( new User() );
					 Logger.debug(" Demo Logoff Origin : " + origin, this.getClass());
				}
				else
				{
					mbAppHelper.addAuthCookie(IBankParams.getBaseOriginCode(origin), httpServletRequest, httpServletResponse, true);
					mobileSession.invalidateSession();
				}
				
			}

			RespHeader headerResp = populateResponseHeader(ServiceConstants.LOGON_RESPONSE);
			serviceResponse.setHeader(headerResp);
			serviceResponse.setSuccess(true);
			return serviceResponse;

		} catch (BusinessException e)
		{
			Logger.error("Exception Inside processLogon() for Customer ", e, this.getClass());
			RespHeader headerResp = populateResponseHeader(ServiceConstants.LOGON_RESPONSE);
			serviceResponse.setHeader(headerResp);
			serviceResponse.setSuccess(true);
			return serviceResponse;
		} catch (Exception e)
		{
			Logger.error("Exception Inside processLogon() for Customer ", e, this.getClass());
			RespHeader headerResp = populateResponseHeader(ServiceConstants.LOGON_RESPONSE);
			serviceResponse.setHeader(headerResp);
			serviceResponse.setSuccess(true);
			return serviceResponse;
		} finally
		{
			performanceLogger.endLog(logName);
			performanceLogger.endAllLogs();
		}
		
	}
		public ErrorResp validate(IMBReq serviceRequest, HttpServletRequest request) {
			return new MBAppValidator().validate(serviceRequest, request);
		}
		
		public void validateRequestHeader(ReqHeader header, HttpServletRequest request) throws ResourceException
		{
			// Nothing to do in case of logon as Session is not created. Session is
			// created after only successful logon
			MBAppValidator mbAppValidator = new MBAppValidator();
			mbAppValidator.validateRequestHeader(header,  request);

		}

		public RespHeader populateResponseHeader(String serviceName, MobileSession mobSession )
		{
			return mbAppHelper.populateResponseHeader(serviceName, mobSession);
		}

		
		public RespHeader populateResponseHeader(String serviceName)
		{
			MBAppHelper mbAppHelper = new MBAppHelper();
			return mbAppHelper.populateResponseHeader(serviceName);
			
		}
		

		
	}
	

