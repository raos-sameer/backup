/**
 * 
 */
package au.com.stgeorge.mbank.controller.services;

import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;

import au.com.stgeorge.framework.common.logging.Logger;
import au.com.stgeorge.ibank.businessobject.AccountFilter;
import au.com.stgeorge.ibank.businessobject.BusinessException;
import au.com.stgeorge.ibank.businessobject.CardService;
import au.com.stgeorge.ibank.businessobject.FastFundingService;
import au.com.stgeorge.ibank.businessobject.ResourceException;
import au.com.stgeorge.ibank.util.ServiceHelper;
import au.com.stgeorge.ibank.valueobject.Account;
import au.com.stgeorge.ibank.valueobject.FastFund;
import au.com.stgeorge.ibank.valueobject.transfer.IBankCommonData;
import au.com.stgeorge.mbank.controller.IMBController;
import au.com.stgeorge.mbank.model.common.IMBReq;
import au.com.stgeorge.mbank.model.common.IMBResp;
import au.com.stgeorge.mbank.model.common.ReqHeader;
import au.com.stgeorge.mbank.model.common.RespHeader;
import au.com.stgeorge.mbank.model.request.EmptyReq;
import au.com.stgeorge.mbank.model.request.services.FastFundReq;
import au.com.stgeorge.mbank.model.response.ErrorResp;
import au.com.stgeorge.mbank.model.response.payments.TransferReceiptResp;
import au.com.stgeorge.mbank.model.response.services.FastFundResp;
import au.com.stgeorge.mbank.session.MobileSession;
import au.com.stgeorge.mbank.util.MBAppHelper;
import au.com.stgeorge.mbank.util.MBAppUtils;
import au.com.stgeorge.mbank.util.MBAppValidator;
import au.com.stgeorge.mbank.util.ServiceConstants;
import au.com.stgeorge.perflogger.PerformanceLogger;

import com.fasterxml.jackson.databind.ObjectMapper;


/**
 * @author c50216
 *
 */
@Controller
@RequestMapping("/fastfund")
public class FastFundingController implements IMBController{

	private static final String DECIMAL_FORMAT = "#.00";
	
	@Autowired
	private CardService cardService;
	
	@Autowired
	private MBAppHelper mbAppHelper;
	
	@Autowired
	private MBAppValidator mbAppValidator;
	
	@Autowired
	private PerformanceLogger perfLogger;
	
	@Autowired
	private AtmLimitHelper atmLimitHelper;			
	
	@RequestMapping(value= "details" , method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public IMBResp getDetails(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse,
			@RequestBody final EmptyReq req)
	{				
				
		ObjectMapper objectMapper = new ObjectMapper();							
		perfLogger.startAllLogs();
		String logName = MBAppUtils.getLogName(httpServletRequest);
		perfLogger.startLog(logName);		
		MobileSession mbSession = null;		
		try{	
			
			mbSession = mbAppHelper.getMobileSession(httpServletRequest);												
			Logger.info("Fast Funding init Request :" + objectMapper.writeValueAsString(req), this.getClass());
			
			validateRequestHeader(req.getHeader(), httpServletRequest);
			ErrorResp errorResp = validate(req, httpServletRequest);
			if (errorResp != null && errorResp.getErrors() != null && errorResp.getErrors().size() > 0)
			{									
				return errorResp;
			}								
			
			IBankCommonData commonData=mbAppHelper.populateIBankCommonData(mbSession, httpServletRequest);
			
//			PortfolioLists toAcctLists = PortfolioListsFilter.getPortfolioList(commonData, PortfolioLists.LIST_ALL_FAST_FUND_ACCOUNTS);
			
			List<Account> ffAccountList  = AccountFilter.filterFastFundingAcounts(commonData.getCustomer().getAccounts());
				
			IMBResp serviceResponse = populateAccountList(ffAccountList);						
			RespHeader headerResp = populateResponseHeader(ServiceConstants.FAST_FUNDING, mbSession);
			serviceResponse.setHeader(headerResp);			
			Logger.info("Fast Funding - getDetails() JSON Response :" + objectMapper.writeValueAsString(serviceResponse), this.getClass());
			
			return serviceResponse;		
			
		}catch (BusinessException e)
		{
			BusinessException exp = null;
			Logger.info("BusinessException Inside  Funding - getDetails() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "]", e, this.getClass());		
			
			exp = new BusinessException(e.getKey());
			IMBResp resp1  = MBAppUtils.createErrorResp(mbSession.getOrigin() ,exp, ServiceConstants.ATM_LIMIT_GET_CARDS, httpServletRequest);
			return resp1;
		}catch (ResourceException e) {
			Logger.error("ResourceException Inside  Funding - getDetails() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "]", e, this.getClass());			
			ResourceException exp = new ResourceException(e.getKey());
			IMBResp resp1  = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, ServiceConstants.ATM_LIMIT_GET_CARDS, httpServletRequest);
			return resp1;
		}catch (Exception e)
		{			
			Logger.error("Exception Inside  Funding - getDetails() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "]", e, this.getClass());
			BusinessException exp = new BusinessException(BusinessException.GENERIC_ERROR);
			IMBResp resp1  = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, ServiceConstants.ATM_LIMIT_GET_CARDS, httpServletRequest);
			return resp1;
		} finally
		{
			perfLogger.endLog(logName);
			perfLogger.endAllLogs();
		}				
	}
	
	@RequestMapping(value= "transfer" , method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public IMBResp processUpdate(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse,
			@RequestBody final FastFundReq req)
	{				
				
		ObjectMapper objectMapper = new ObjectMapper();							
		perfLogger.startAllLogs();
		String logName = MBAppUtils.getLogName(httpServletRequest);
		perfLogger.startLog(logName);		
		MobileSession mbSession = null;		
		try{	
			
			mbSession = mbAppHelper.getMobileSession(httpServletRequest);												
			Logger.info("FastFundingController.processUpdate Request :" + objectMapper.writeValueAsString(req), this.getClass());
			
			validateRequestHeader(req.getHeader(), httpServletRequest);
			ErrorResp errorResp = validate(req, httpServletRequest);
			if (errorResp != null && errorResp.getErrors() != null && errorResp.getErrors().size() > 0)
			{									
				return errorResp;
			}								
			
			IBankCommonData commonData=mbAppHelper.populateIBankCommonData(mbSession, httpServletRequest);
			FastFundingService fastFundingService = (FastFundingService)ServiceHelper.getBean("fastFundingService");
			
			  FastFund fastFund = new FastFund();
			  fastFund.setCardName(req.getCardName());
			  fastFund.setCardNumber(req.getCardNumber());
			  fastFund.setCvv(req.getCvv());
			  fastFund.setSendEmail(req.getSendEmail());
			  fastFund.setEmailAddress(req.getEmailAddress());
			  fastFund.setAmount(new BigDecimal(req.getAmt()));
			  fastFund.setReceiptDate(new Date());
			  Account acct = mbAppHelper.getAccountFromCustomer(commonData.getCustomer(), req.getAccountIndex());
			  fastFund.setToAccount(acct);
			  Calendar calendar = Calendar.getInstance();
			  calendar.set(Calendar.MONTH, req.getValidMonth() );
			  calendar.set(Calendar.YEAR, req.getValidYear());
			  fastFund.setValidUpTo(calendar.getTime());

			fastFundingService.processFastFuningTransfer(commonData, fastFund);

			
			/*
			 * TODO Review changes for fastfunding code cleanup
			if(commonData.getCustomer().getFastFundingTile() != null){
				// FastFundingService fastFundingService = (FastFundingService)ServiceHelper.getBean("fastFundingService");
				long reqId = commonData.getCustomer().getFastFundingTile().getRequestID();
				fastFundingService.updateFsatFundingStatus(commonData, reqId);
			}
			*/	
			IMBResp serviceResponse = populateFastFundResponse(req);
			RespHeader headerResp = populateResponseHeader(ServiceConstants.FAST_FUNDING, mbSession );
			serviceResponse.setHeader(headerResp);						
			
			Logger.info("FastFundingController.processUpdate Request :" + objectMapper.writeValueAsString(serviceResponse), this.getClass());
					
			return serviceResponse;					
		}catch (BusinessException e)
		{
			BusinessException exp = null;
			Logger.info("BusinessException Inside atmlimit.processUpdate() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "]", e, this.getClass());		
			
			exp = new BusinessException(e.getKey());
			IMBResp resp1  = MBAppUtils.createErrorResp(mbSession.getOrigin() ,exp, ServiceConstants.ATM_LIMIT_UPDATE, httpServletRequest);
			return resp1;
		}catch (ResourceException e) {
			Logger.error("ResourceException Inside atmlimit.processUpdate() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "]", e, this.getClass());			
			ResourceException exp = new ResourceException(e.getKey());
			IMBResp resp1  = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, ServiceConstants.ATM_LIMIT_UPDATE, httpServletRequest);
			return resp1;
		}catch (Exception e)
		{			
			Logger.error("Exception Inside atmlimit.processUpdate() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "]", e, this.getClass());
			BusinessException exp = new BusinessException(BusinessException.GENERIC_ERROR);
			IMBResp resp1  = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, ServiceConstants.ATM_LIMIT_UPDATE, httpServletRequest);
			return resp1;
		} finally
		{
			perfLogger.endLog(logName);
			perfLogger.endAllLogs();
		}				
	}
	
	/**
	 * Response for invalid body request 
	 * 
	 * @return
	 */
	@ExceptionHandler({org.springframework.http.converter.HttpMessageNotReadableException.class})
	@ResponseStatus(org.springframework.http.HttpStatus.OK)
	@ResponseBody
	public IMBResp resolveException() {		
		return MBAppUtils.createInvalidMessageBodyResponse(ServiceConstants.ATM_LIMIT_UPDATE);
	}
	
	public ErrorResp validate(IMBReq serviceRequest, HttpServletRequest request) {
		return mbAppValidator.validate(serviceRequest, request);
	}
	
	public void validateRequestHeader(ReqHeader header, HttpServletRequest request) throws ResourceException
	{	
		mbAppValidator.validateRequestHeader(header,  request);	
	}
	
	public RespHeader populateResponseHeader(String serviceName, MobileSession mobSession )
	{
		return mbAppHelper.populateResponseHeader(serviceName, mobSession);
	}
	
	
	
	private IMBResp  populateAccountList(List<Account>  list)
	{
		FastFundResp fastFundResp =  new FastFundResp();
		//List<Account> list = toAcctLists.getAccounts();
		List<Integer> indexes = new ArrayList<Integer>(); 
		for ( Account account : list )
		{
			indexes.add( account.getIndex());
		}
		fastFundResp.setAccountIndexes(indexes);
		return fastFundResp;
	}

	
	private IMBResp  populateFastFundResponse(FastFundReq req)
	{
		FastFundResp fastFundResp =  new FastFundResp();
		//List<Account> list = toAcctLists.getAccounts();
		List<Integer> indexes = new ArrayList<Integer>(); 
		
		fastFundResp.setAccountIndexes(indexes);
		
		TransferReceiptResp receipt = new TransferReceiptResp();
		
		DecimalFormat decFormat = new DecimalFormat(DECIMAL_FORMAT);
		String formattedAmount = decFormat.format(Double.parseDouble(req.getAmt()));

		receipt.setAmt(formattedAmount);
		receipt.setReceiptNumDisp((new Date()).getTime() + "");
		receipt.setTranDateTime(new Date());
		
		fastFundResp.setReceipt(receipt);
		fastFundResp.setStatus(FastFundResp.STATUS_SUCCESS);
		fastFundResp.setAccountIndex(req.getAccountIndex());
		
		return fastFundResp;
	}
	
	public static void main(String a[]){
		DecimalFormat decFormat = new DecimalFormat("#.00");
		System.out.println(decFormat.format(Double.parseDouble(".11")));
	}
	
}
