package au.com.stgeorge.mbank.model.request.customer.ev;



import au.com.stgeorge.mbank.util.JsonDateSerializer;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;

public class EVInfo {
	
	private boolean driversLicence;
	private boolean medicareCard;
	private boolean passport;
	private boolean ausBirthCertificate;
	private boolean nswPhotoCard;
	private String dlStateOfIssue;
	private String dlicenceNum;
	private String medicareNum;
	private String medicarePosNum;
	private String medicareMiddleInitial;
	private String medicareValidToMon;
	private String medicareValidToYear;
	private String passportCountryOfIssue;
	private String passportNum;
	private String birthCertRegNum;
	private String birthCertStateOfIssue;
	private String birthCertRegDateDay;
	private String birthCertRegDateMon;
	private String birthCertRegDateYear;
	private String birthCertDateOfPrint;
	private String birthCertificateNumber;
	private String photoCardNum;
	private String photoCardPCNum;
	
	@JsonSerialize(using = JsonDateSerializer.class)
	private String birthCertRegDate;
	
	public boolean isDriversLicence() {
		return driversLicence;
	}
	public void setDriversLicence(boolean driversLicence) {
		this.driversLicence = driversLicence;
	}
	public boolean isMedicareCard() {
		return medicareCard;
	}
	public void setMedicareCard(boolean medicareCard) {
		this.medicareCard = medicareCard;
	}
	public boolean isPassport() {
		return passport;
	}
	public void setPassport(boolean passport) {
		this.passport = passport;
	}
	public boolean isAusBirthCertificate() {
		return ausBirthCertificate;
	}
	public void setAusBirthCertificate(boolean ausBirthCertificate) {
		this.ausBirthCertificate = ausBirthCertificate;
	}
	public boolean isNswPhotoCard() {
		return nswPhotoCard;
	}
	public void setNswPhotoCard(boolean nswPhotoCard) {
		this.nswPhotoCard = nswPhotoCard;
	}
	public String getDlStateOfIssue() {
		return dlStateOfIssue;
	}
	public void setDlStateOfIssue(String dlStateOfIssue) {
		this.dlStateOfIssue = dlStateOfIssue;
	}
	public String getDlicenceNum() {
		return dlicenceNum;
	}
	public void setDlicenceNum(String dlicenceNum) {
		this.dlicenceNum = dlicenceNum;
	}
	public String getMedicareNum() {
		return medicareNum;
	}
	public void setMedicareNum(String medicareNum) {
		this.medicareNum = medicareNum;
	}
	public String getMedicarePosNum() {
		return medicarePosNum;
	}
	public void setMedicarePosNum(String medicarePosNum) {
		this.medicarePosNum = medicarePosNum;
	}
	public String getMedicareMiddleInitial() {
		return medicareMiddleInitial;
	}
	public void setMedicareMiddleInitial(String medicareMiddleInitial) {
		this.medicareMiddleInitial = medicareMiddleInitial;
	}
	public String getMedicareValidToMon() {
		return medicareValidToMon;
	}
	public void setMedicareValidToMon(String medicareValidToMon) {
		this.medicareValidToMon = medicareValidToMon;
	}
	public String getMedicareValidToYear() {
		return medicareValidToYear;
	}
	public void setMedicareValidToYear(String medicareValidToYear) {
		this.medicareValidToYear = medicareValidToYear;
	}
	public String getPassportNum() {
		return passportNum;
	}
	public void setPassportNum(String passportNum) {
		this.passportNum = passportNum;
	}
	public String getBirthCertRegNum() {
		return birthCertRegNum;
	}
	public void setBirthCertRegNum(String birthCertRegNum) {
		this.birthCertRegNum = birthCertRegNum;
	}
	public String getBirthCertStateOfIssue() {
		return birthCertStateOfIssue;
	}
	public void setBirthCertStateOfIssue(String birthCertStateOfIssue) {
		this.birthCertStateOfIssue = birthCertStateOfIssue;
	}
	public String getBirthCertRegDateDay() {
		return birthCertRegDateDay;
	}
	public void setBirthCertRegDateDay(String birthCertRegDateDay) {
		this.birthCertRegDateDay = birthCertRegDateDay;
	}
	public String getBirthCertRegDateMon() {
		return birthCertRegDateMon;
	}
	public void setBirthCertRegDateMon(String birthCertRegDateMon) {
		this.birthCertRegDateMon = birthCertRegDateMon;
	}
	public String getBirthCertRegDateYear() {
		return birthCertRegDateYear;
	}
	public void setBirthCertRegDateYear(String birthCertRegDateYear) {
		this.birthCertRegDateYear = birthCertRegDateYear;
	}
	public String getPhotoCardNum() {
		return photoCardNum;
	}
	public void setPhotoCardNum(String photoCardNum) {
		this.photoCardNum = photoCardNum;
	}
	public String getPhotoCardPCNum() {
		return photoCardPCNum;
	}
	public void setPhotoCardPCNum(String photoCardPCNum) {
		this.photoCardPCNum = photoCardPCNum;
	}
	public String getBirthCertRegDate() {
		return birthCertRegDate;
	}
	public void setBirthCertRegDate(String birthCertRegDate) {
		this.birthCertRegDate = birthCertRegDate;
	}
	public String getPassportCountryOfIssue() {
		return passportCountryOfIssue;
	}
	public void setPassportCountryOfIssue(String passportCountryOfIssue) {
		this.passportCountryOfIssue = passportCountryOfIssue;
	}
	public String getBirthCertDateOfPrint() {
		return birthCertDateOfPrint;
	}
	public void setBirthCertDateOfPrint(String birthCertDateOfPrint) {
		this.birthCertDateOfPrint = birthCertDateOfPrint;
	}
	public String getBirthCertificateNumber() {
		return birthCertificateNumber;
	}
	public void setBirthCertificateNumber(String birthCertificateNumber) {
		this.birthCertificateNumber = birthCertificateNumber;
	}	
}
