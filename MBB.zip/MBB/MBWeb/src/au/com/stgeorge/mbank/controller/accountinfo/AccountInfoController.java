/**
 * 
 */
package au.com.stgeorge.mbank.controller.accountinfo;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

import javax.naming.InitialContext;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;

import au.com.stgeorge.digitalsec.logger.DigitalSecLogger;
import au.com.stgeorge.digitalsec.logger.DigitalSecLogggerVO;
import au.com.stgeorge.framework.common.logging.Logger;
import au.com.stgeorge.framework.common.model.User;
import au.com.stgeorge.framework.common.util.DateMethods;
import au.com.stgeorge.framework.common.util.JNDIMethods;
import au.com.stgeorge.framework.common.util.StringMethods;
import au.com.stgeorge.ibank.AbusiveTransactionVO;
import au.com.stgeorge.ibank.businessobject.AbusiveTransactionsService;
import au.com.stgeorge.ibank.businessobject.AccountFilter;
import au.com.stgeorge.ibank.businessobject.BusinessException;
import au.com.stgeorge.ibank.businessobject.CardDisputeService;
import au.com.stgeorge.ibank.businessobject.FixedHomeLoanService;
import au.com.stgeorge.ibank.businessobject.HomeLoanService;
import au.com.stgeorge.ibank.businessobject.MerchantTransactionInfo;
import au.com.stgeorge.ibank.businessobject.MerchantTransactionInfoService;
import au.com.stgeorge.ibank.businessobject.NPPService;
import au.com.stgeorge.ibank.businessobject.NPPTransactionService;
import au.com.stgeorge.ibank.businessobject.ResourceException;
import au.com.stgeorge.ibank.businessobject.SmartPlansService;
import au.com.stgeorge.ibank.businessobject.StatisticsService;
import au.com.stgeorge.ibank.businessobject.TranCategorisationService;
import au.com.stgeorge.ibank.businessobject.categorisation.CategorisationService;
import au.com.stgeorge.ibank.businessobject.globalWallet.GlobalWalletService;
import au.com.stgeorge.ibank.businessobject.wdp.WDPServiceHelper;
import au.com.stgeorge.ibank.common.cache.IBankParams;
import au.com.stgeorge.ibank.common.cache.IBankRefershParams;
import au.com.stgeorge.ibank.cpp.businessobject.CustomerPricingService;
import au.com.stgeorge.ibank.cpp.valueobjects.PreCalculatedOffer;
import au.com.stgeorge.ibank.evcrs.businessobject.valueobject.NPPTransactionDetail;
import au.com.stgeorge.ibank.servicestation.businessobject.ServiceStation;
import au.com.stgeorge.ibank.servicestation.businessobject.ServiceStationImpl;
import au.com.stgeorge.ibank.servicestation.businessobject.valueobject.ServiceStationVO;
import au.com.stgeorge.ibank.servicestation.util.ServicetationConstants;
import au.com.stgeorge.ibank.util.NPPUtil;
import au.com.stgeorge.ibank.util.ServiceHelper;
import au.com.stgeorge.ibank.valueobject.Account;
import au.com.stgeorge.ibank.valueobject.AccountFlags;
import au.com.stgeorge.ibank.valueobject.AccountingTransactionHistory;
import au.com.stgeorge.ibank.valueobject.Customer;
import au.com.stgeorge.ibank.valueobject.DdaAccount;
import au.com.stgeorge.ibank.valueobject.GCCAccount;
import au.com.stgeorge.ibank.valueobject.LabelValueVO;
import au.com.stgeorge.ibank.valueobject.LoanAccount;
import au.com.stgeorge.ibank.valueobject.SmartPlanActiveInstalment;
import au.com.stgeorge.tranhistory.valueobject.SmartPlanDetails;
import au.com.stgeorge.ibank.valueobject.Statistic;
import au.com.stgeorge.ibank.valueobject.TranHistoryByMonth;
import au.com.stgeorge.ibank.valueobject.TransactionHistory;
import au.com.stgeorge.ibank.valueobject.TransactionHistoryCrossLink;
import au.com.stgeorge.ibank.valueobject.TransactionInfo;
import au.com.stgeorge.ibank.valueobject.database.CodesVO;
import au.com.stgeorge.ibank.valueobject.database.FixedHomeLoanOffer;
import au.com.stgeorge.ibank.valueobject.database.GlobalWallet;
import au.com.stgeorge.ibank.valueobject.database.ProductVO;
import au.com.stgeorge.ibank.valueobject.globalWallet.GlobalWalletDetails;
import au.com.stgeorge.ibank.valueobject.transfer.IBankCommonData;
import au.com.stgeorge.ibank.valueobject.CreditCardAccount;
import au.com.stgeorge.mbank.controller.IMBController;
import au.com.stgeorge.mbank.controller.customer.LogonHelper;
import au.com.stgeorge.mbank.model.accountinfo.AccountDetailResp;
import au.com.stgeorge.mbank.model.common.IMBReq;
import au.com.stgeorge.mbank.model.common.IMBResp;
import au.com.stgeorge.mbank.model.common.ReqHeader;
import au.com.stgeorge.mbank.model.common.RespHeader;
import au.com.stgeorge.mbank.model.request.EmptyReq;
import au.com.stgeorge.mbank.model.request.IndexReq;
import au.com.stgeorge.mbank.model.request.TransactionDetailsReq;
import au.com.stgeorge.mbank.model.request.accountinfo.AccountInfoReq;
import au.com.stgeorge.mbank.model.request.accountinfo.ShareBsbAccNumReq;
import au.com.stgeorge.mbank.model.request.accountinfo.TxnHistorySearchReq;
import au.com.stgeorge.mbank.model.response.ErrorResp;
import au.com.stgeorge.mbank.model.response.SuccessResp;
import au.com.stgeorge.mbank.model.response.accountinfo.AccountInfoResp;
import au.com.stgeorge.mbank.model.response.accountinfo.GlobalWalletAccountInfoResp;
import au.com.stgeorge.mbank.model.response.lwc.MerchantDetailsResp;
import au.com.stgeorge.mbank.model.response.servicestation.ServiceStationResp;
import au.com.stgeorge.mbank.session.MobileSession;
import au.com.stgeorge.mbank.session.MobileSessionImpl;
import au.com.stgeorge.mbank.util.FraudLogger;
import au.com.stgeorge.mbank.util.MBAppHelper;
import au.com.stgeorge.mbank.util.MBAppUtils;
import au.com.stgeorge.mbank.util.MBAppValidator;
import au.com.stgeorge.mbank.util.ServiceConstants;
import au.com.stgeorge.mobilebank.businessobject.ExternalLinkService;
import au.com.stgeorge.mobilebank.businessobject.MobileBankService;
import au.com.stgeorge.mobilebank.businessobject.impl.MobileBankServiceImpl;
import au.com.stgeorge.perflogger.PerformanceLogger;
import au.com.stgeorge.tranhistory.service.ExtendTransactionHistoryService;
import au.com.stgeorge.ibank.valueobject.CreditCardAccount;

import com.fasterxml.jackson.databind.ObjectMapper;


/**
 * @author C50216
 *
 */

@Controller
@RequestMapping("/account")
public class AccountInfoController implements IMBController{
	
	/*private static final String ZERO = "0";*/

	private static final String TXDET = "TXDET";
	private static final String MADISON_PILOT = "MadisonPilot";
	public static final String APP_VER_COOKIE = "AppVersion";
	private FraudLogger fraudLogger;
	
	@Autowired
	private AbusiveTransactionsService abusiveTransactionsService;
	
	@Autowired
	private AccountInfoHelper accountInfoHelper;
	
	@Autowired
	private MBAppHelper mbAppHelper;
	
	@Autowired
	private MBAppValidator mbAppValidator;
		
	@Autowired
	private MobileBankService mobileBankService;
	
	@Autowired
	private ExtendTransactionHistoryService extendTranHistService;
	
	@Autowired
	private PerformanceLogger perfLogger;
	
	@Autowired
	HomeLoanService hliAccountsService;
	
	@Autowired
	ExternalLinkService externalLinkService;
	
	@Autowired
	private ServiceStation serviceStationService;
	
	@Autowired
	private TranCategorisationService tranCategorisationService;
	
	@Autowired
	private CategorisationService categorisationService;
	
	@Autowired
	private DigitalSecLogger digitalSecLogger;
	
	@Autowired
	private NPPService nppService;
	
	@Autowired
	private CardDisputeService cardDisputeService;
	
	@Autowired
	private CustomerPricingService customerPricingService;
	
	/*@Autowired
	private TransactionCategorisationHelper tranCategorisationHelper;*/
	
	@Autowired
	private NPPTransactionService nppTransactionService;
	
	@Autowired
	private IBankRefershParams ibankRefreshParams;
	
	@Autowired
	private GlobalWalletService globalWalletService;
	
	@Autowired
	private LogonHelper logonHelper;
	
	@Autowired
	private FixedHomeLoanService fixedHomeLoanService;
	
	@Autowired
	MerchantTransactionInfoService merchantTransactionInfoService;
	
	@Autowired
	private SmartPlansService smartPlansService;
	
	
	@RequestMapping(value= "info" , method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public IMBResp processAcctInfo(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse,
			@RequestBody final AccountInfoReq req)
	{				
				
		ObjectMapper objectMapper = new ObjectMapper();				
		StringBuffer[] cardAuthtotAmt = { new StringBuffer() };
		Collection cardAuths = null;
		Account acctDetail = null;
		TransactionHistory trxnHist = null;
		boolean isRespCameFromExtendHist = false;
		boolean isAccountEligibleForSmartPlans = false;
		boolean isAccountEligibleForBalanceSmartPlans = false;
		boolean isAccountEligibleForPurchaseSmartPlans = false;
		boolean showSmartPlanAccountServiceMenu = false;
		IMBResp serviceResponse = new AccountInfoResp();
		
		perfLogger.startAllLogs();
		String logName = MBAppUtils.getLogName(httpServletRequest);
		perfLogger.startLog(logName);
		
		fraudLogger = new FraudLogger();
		MobileSession mbSession = null;
		try{	

			mbSession = mbAppHelper.getMobileSession(httpServletRequest);		
			Logger.info("Account Info JSON Request :" + objectMapper.writeValueAsString(req), this.getClass());
			validateRequestHeader(req.getHeader(), httpServletRequest);
			ErrorResp errorResp = validate(req, httpServletRequest);
			Cookie cookie = getCookie(httpServletRequest, APP_VER_COOKIE);
			if (errorResp != null && errorResp.getErrors() != null && errorResp.getErrors().size() > 0)
			{				
				//fraudLogger.logInvalidInput();
				return errorResp;
			}
			
			if(null!=mbSession.getServiceStationAccountDetailMessage())
			{
				mbSession.removeServiceStationAccountDetailsMessage();
			}
																			
			int myAcctIndex = req.getAccountIndex();
			Customer customer=mbSession.getCustomer();			
						
			Account selectedAcct=mbAppHelper.getAccountFromCustomer(customer, myAcctIndex);
			
			IBankCommonData commonData=null;SimpleDateFormat homeLoanDateFormat = new SimpleDateFormat("dd MMM yyyy");
			
			boolean isCustomerPrimaryCardHolder = false;
			
			if(selectedAcct!=null){
				
				commonData=mbAppHelper.populateIBankCommonData(mbSession,httpServletRequest);
						
				acctDetail = mobileBankService.getAccountDetails(selectedAcct.getAccountId(), commonData);				
				
				if (acctDetail instanceof LoanAccount || acctDetail instanceof DdaAccount) {
					setLoanIncreaseFlag(commonData, acctDetail);
				}
				TransactionHistory sessionTranHist = mbSession.getTransactionHistory();
				if(Account.CREDIT_CARD.equalsIgnoreCase(acctDetail.getAccountId().getEhubProductCode())     || 
					Account.SAVING_ACCOUNT.equalsIgnoreCase(acctDetail.getAccountId().getEhubProductCode()) ||
					Account.CHEQUE_ACCOUNT.equalsIgnoreCase(acctDetail.getAccountId().getEhubProductCode())
				  )
					cardAuths = mobileBankService.getCardAuthorisations(selectedAcct.getAccountId(), cardAuthtotAmt);
				if ( ! Account.GCC.equalsIgnoreCase(selectedAcct.getAccountId().getApplicationId()) && ! Account.AHI.equalsIgnoreCase(selectedAcct.getAccountId().getApplicationId()) && ! Account.AMI.equalsIgnoreCase(selectedAcct.getAccountId().getApplicationId())
						 && ! Account.ATI.equalsIgnoreCase(selectedAcct.getAccountId().getApplicationId())){				
					
					isCustomerPrimaryCardHolder = smartPlansService.isCustomerPrimaryCardHolder(acctDetail);
					if(IBankParams.isExtendTranHistSwitchOn(commonData.getOrigin(),selectedAcct.getAccountId().getApplicationId(),customer.getGcis())){
						// merged transactions from extend tran hist
						Logger.debug("Calling Extend Transaction History Service | getMergedTransactionHistory" ,this.getClass());
						isRespCameFromExtendHist = true;
						trxnHist = extendTranHistService.getMergedTransactionHistory(selectedAcct.getAccountId(),commonData,req.getHistoryPeriod(),null,Integer.parseInt(IBankParams.getExtendTranHistMaxTransaction(commonData.getOrigin())), isCustomerPrimaryCardHolder);
						//19E1 CI - Removing increase transaction history CI item
						//accountInfoHelper.updateExtendTranHistInSession(mbSession, trxnHist, true);
						sessionTranHist = accountInfoHelper.updateExtendTranHistInSession(mbSession,sessionTranHist , trxnHist, req.getHistoryPeriod());
					}else{
						Logger.debug("Calling Mobile Bank Service | getTransactionHistory" ,this.getClass());
						trxnHist = mobileBankService.getTransactionHistory(selectedAcct.getAccountId(), commonData,req.getHistoryPeriod(),null);
						
					}
				}
					//MQ 30 days call
					
				//	mbSession.setTranHistoryByMonthList(null);
					String tranHistCleaup = mbSession.getTransHistFlag();
					if ( "Y".equalsIgnoreCase( tranHistCleaup ))
			  		{
			   			mbSession.setTransHistFlag("N");
			   			mbSession.removeTranHistoryByMonthStatus();
			  		}  	 
					//19E1 CI - Removing increase transaction history CI item
					//updateTranHistoryDetailsInSession(selectedAcct,  trxnHist, req.getHistoryPeriod(),  mbSession , commonData, true, isRespCameFromExtendHist, null );
					updateTranHistoryDetailsInSession(selectedAcct,  trxnHist, "30",  mbSession , commonData, isMaxTranHistoryReached(sessionTranHist, commonData));
			}else
				throw new BusinessException(BusinessException.NO_INFORMATION);
			ServiceStationResp resp = null;
			try{
				if ( ! Account.GCC.equalsIgnoreCase(selectedAcct.getAccountId().getApplicationId()) && ! Account.AHI.equalsIgnoreCase(selectedAcct.getAccountId().getApplicationId()) && ! Account.AMI.equalsIgnoreCase(selectedAcct.getAccountId().getApplicationId()))
				{		
					long insertionPt = accountInfoHelper.getInsertionPointCode(ServicetationConstants.ACCOUNT_DETAILS);
					ServiceStationVO serviceStationVo = serviceStationService.getServiceMessage(insertionPt, ServiceStationImpl.CHANNEL_MOBILE, commonData);					
					if(null!=serviceStationVo)
					{
						mbSession.setServiceStationAccountDetailMessage(serviceStationVo.getServiceStationMsg());
					}					
					resp = accountInfoHelper.populateServiceStationResp(serviceStationVo);
				}
			}catch(BusinessException bex){
				Logger.error("An error occurred while getting service station message for mobile accoutn details", bex, this.getClass());
			}
			
			boolean isEligibleForCategorisation = false;
			boolean isCategorisationAvailableForTranHistory = false;
			if(Account.CRA.equalsIgnoreCase(acctDetail.getAccountId().getApplicationId()) || Account.DDA.equalsIgnoreCase(acctDetail.getAccountId().getApplicationId())){
				if ( acctDetail.getAllowFlags() != null )
				{
					isEligibleForCategorisation = acctDetail.getAllowFlags().contains(AccountFlags.ALLOW_TNX_CATEGORISATION); // categorisationService.isEligibleForCategorisation(acctDetail, commonData);
				}
				isCategorisationAvailableForTranHistory = categorisationService.isCategorisationAvailableForTranHistory(acctDetail, commonData);
			}
			
			//19E1 : CPP changes
			if(IBankParams.isSwitchOn(IBankParams.CPP_SWITCH)){				
				UUID appCorrelationId = WDPServiceHelper.generateAppCorrelationId();
				PreCalculatedOffer preCalculatedOffer = customerPricingService.getEligibleOffer(commonData, acctDetail, appCorrelationId);

				if(preCalculatedOffer != null){
					acctDetail.setPreCalOfferDetails(preCalculatedOffer);
				}							
				
				//19E1-CPP- SBGEXP-4699
				mobileBankService.processGDWEntryForAccountInquiry(commonData, acctDetail);
			}
						
			//19E1 CPP - add selected account to session.
			//Set the selected account in session for offer details page.
			mbSession.setSelectedAccount(acctDetail);
			
			//20e4 - Warranty - set CRA account brand in session for MGRP
			
			//Remove mgrpBrand from session if exists.
			mbSession.removeMgrpBrand();
			
			if(IBankParams.isSwitchOn(IBankParams.MGRP_SWITCH)) {
			
				if( null != acctDetail && Account.CRA.equalsIgnoreCase(acctDetail.getAccountId().getApplicationId())) {
					ProductVO prodVO = IBankParams.getLogoData(Account.CRA, 
							acctDetail.getCreditCardAdditionalInfo().getOrganisation(), 
							acctDetail.getCreditCardAdditionalInfo().getLogo(), 
							acctDetail.getAccountId().getAccountNumber());
	                    String brand = prodVO.getBrand();
	                    
	                    Logger.debug("CRA account Brand : "+brand, this.getClass());
	                    
	                    if(null != brand)
	                    	mbSession.setMgrpBrand(brand);
	                    else
	                    	mbSession.setMgrpBrand(IBankParams.STG_ORIGIN); //set default brand as STG
				}
			}
			
			//20E4 Smart Plan Eligibility checks and smart plan details
			List<SmartPlanActiveInstalment> activeInstalmentPlanResps = null;
			
			int smartPlanPendingRequestCount = 0;
			if(isCustomerPrimaryCardHolder && ibankRefreshParams.isSmartPlanSwitchON(IBankParams.DEFAULT_ORIGIN, commonData.getCustomer().getGcis()) && Account.CRA.equals( selectedAcct.getAccountId().getApplicationId())) {
				CreditCardAccount craAccount = null;
				craAccount = (CreditCardAccount) acctDetail;
				activeInstalmentPlanResps = smartPlansService.getActiveInstalmentPlan(acctDetail.getAccountId().getAccountNumber(),craAccount);
				mbSession.setSmartPlanActiveInstalmentList(activeInstalmentPlanResps);
								
				smartPlanPendingRequestCount = smartPlansService.getPendingRequestInstalmentPlanCount(acctDetail.getAccountId().getAccountNumber());
				isAccountEligibleForSmartPlans = smartPlansService.isCustomerAccountEligible(commonData.getCustomer(), acctDetail, 0, 0);
				if(isAccountEligibleForSmartPlans) {
					showSmartPlanAccountServiceMenu = true;
					if(smartPlansService.isPlanThresholdReached(activeInstalmentPlanResps.size(),smartPlanPendingRequestCount)) {
						isAccountEligibleForSmartPlans = false;
					}
				}
				mbSession.setIsAccountEligibleForSmartPlan(isAccountEligibleForSmartPlans);//Moving in session so that it can be used in /history endpoint
				isAccountEligibleForBalanceSmartPlans = smartPlansService.isAccountEligibleForBalanceSmartPlans(acctDetail);
				isAccountEligibleForPurchaseSmartPlans = smartPlansService.isAccountEligibleForPurchaseSmartPlans(acctDetail);
				mbSession.setIsAccountEligibleForPurchaseSmartPlan(isAccountEligibleForPurchaseSmartPlans);
			}
			
			//19E1 Release Fix
			//minimise invokation to mbSession.getTransactionHistory(); because every time triggers SELECT SESSION
			TransactionHistory tranHistorySession = mbSession.getTransactionHistory();
			if(isRespCameFromExtendHist){
				//19E1 CI - Removing increase transaction history CI item
				serviceResponse = accountInfoHelper.populateResp(mbSession,tranHistorySession, acctDetail, cardAuths, cardAuthtotAmt, trxnHist, resp, isEligibleForCategorisation, isCategorisationAvailableForTranHistory,isRespCameFromExtendHist,commonData);
			}else{
				//19E1 CI - Removing increase transaction history CI item
				serviceResponse = accountInfoHelper.populateResp(mbSession, tranHistorySession, acctDetail, cardAuths, cardAuthtotAmt, trxnHist, resp, isEligibleForCategorisation, isCategorisationAvailableForTranHistory,commonData);
			}
			
			if(isCustomerPrimaryCardHolder && ibankRefreshParams.isSmartPlanSwitchON(IBankParams.DEFAULT_ORIGIN, commonData.getCustomer().getGcis()) && Account.CRA.equals( selectedAcct.getAccountId().getApplicationId())) {
				Iterator iterator = activeInstalmentPlanResps.iterator();
				BigDecimal totalCurrBal = new BigDecimal(0);
				SmartPlanActiveInstalment smartPlanDetails = null;
				while (iterator.hasNext()) {
					smartPlanDetails = (SmartPlanActiveInstalment) iterator.next();
					totalCurrBal = totalCurrBal.add(smartPlanDetails.getCurrBalance());
				}
				((AccountInfoResp) serviceResponse).setTotalSmartPlanCurrBalance(totalCurrBal);
				((AccountInfoResp) serviceResponse).setTotalActiveInstalmentPlanCount(activeInstalmentPlanResps.size());
				((AccountInfoResp) serviceResponse).setTotalPendingInstalmentPlanCount(smartPlanPendingRequestCount);
				((AccountInfoResp) serviceResponse).setActiveInstalmentPlanList(activeInstalmentPlanResps);
				
				if(isAccountEligibleForSmartPlans && isAccountEligibleForBalanceSmartPlans) {
					Logger.info("Account eligible for Balance installment plans", this.getClass());
					(((AccountInfoResp) serviceResponse).getAccountDetail()).setShowBalanceSmartPlan(true);
				}
				if(showSmartPlanAccountServiceMenu && isAccountEligibleForBalanceSmartPlans) {
					Logger.debug("Account eligible for showing plan and pay link in account details services menu", this.getClass());
					(((AccountInfoResp) serviceResponse).getAccountDetail()).setShowSmartPlanAccountServiceMenu(true);
				}
			}
			
			if(null != acctDetail.getPreCalOfferDetails()) {
				Logger.debug("CPP : acctDetail.getPreCalOfferDetails() is not NULL - show blue ribbon.", this.getClass());
				(((AccountInfoResp) serviceResponse).getAccountDetail()).setShowOffer(true);
				
				//First time check for CPP offer
				if(null == acctDetail.getPreCalOfferDetails().getFirstTimeCheck() && customerPricingService.isFirstTimeOfferDisplay(commonData, acctDetail)){
					Logger.debug("CPP : firstTimeCheck is TRUE. Display splash page.", this.getClass());
					acctDetail.getPreCalOfferDetails().setFirstTimeCheck(Boolean.TRUE);
		        	(((AccountInfoResp) serviceResponse).getAccountDetail()).setFirstTimeCheck(Boolean.TRUE);
				}	
			}
			
			
			if(IBankParams.isHomeLoanDigiSwitchON() && Account.LIS.equals( selectedAcct.getAccountId().getApplicationId())){
				AccountDetailResp accountDetailResp =(((AccountInfoResp) serviceResponse).getAccountDetail());
				if(selectedAcct!=null){
					try{
						FixedHomeLoanOffer offer = fixedHomeLoanService.getHomeLoanEligiblilityDetailsByAccount(customer, selectedAcct.getAccountId().getAccountNumber());
						if(offer!=null){
							accountDetailResp.setHomeLoanDigiMaturityDate( homeLoanDateFormat.format(offer.getFixedRateMaturityDate()));
							accountDetailResp.setHomeLoanDigiOfferFlag(offer.getOfferStatus());
						}
					}
					catch(Exception e){
						accountDetailResp.setHomeLoanDigiMaturityDate("");
						accountDetailResp.setHomeLoanDigiOfferFlag("");
						Logger.error("Exception found in homeloan service",e, this.getClass());
					}
				}
			}
			
			// Display Madison Service Link in Account Details
			
			String MADISON_SWITCH = IBankParams.getBrandSwitchVal(commonData.getOrigin().trim(), IBankParams.MADISON_SWITCH) ;
			
			if(MADISON_SWITCH.equalsIgnoreCase("1")) {
				
				boolean isMadisonEligible=logonHelper.isMadisonEligible(commonData.getUserAgent(), cookie);
				
				if(isMadisonEligible && (selectedAcct.isApplicationIdCra())){
					(((AccountInfoResp) serviceResponse).getAccountDetail()).setAllowMadison(true);
				}
				else if(isMadisonEligible && (selectedAcct.isApplicationIdDda())){
					(((AccountInfoResp) serviceResponse).getAccountDetail()).setAllowMadison(true);
				}
				else {
					(((AccountInfoResp) serviceResponse).getAccountDetail()).setAllowMadison(false);
				}
			}else if(MADISON_SWITCH.equalsIgnoreCase("2")) {
				
				boolean isPilot=ibankRefreshParams.isPilotCustomer(customer.getGcis(),MADISON_PILOT);
				
				if(isPilot) {
					boolean isMadisonEligible=logonHelper.isMadisonEligible(commonData.getUserAgent(), cookie);
					
					if(isMadisonEligible && (selectedAcct.isApplicationIdCra())){
						(((AccountInfoResp) serviceResponse).getAccountDetail()).setAllowMadison(true);
					}
					else if(isMadisonEligible && (selectedAcct.isApplicationIdDda())){
						(((AccountInfoResp) serviceResponse).getAccountDetail()).setAllowMadison(true);
					}
					else {
						(((AccountInfoResp) serviceResponse).getAccountDetail()).setAllowMadison(false);
					}
				}
			}
			
			if(AccountFilter.isMadisonLCMSwitchOn(customer.getGcis()) && selectedAcct.isApplicationIdCra()) {
				CreditCardAccount crAccount=(CreditCardAccount)selectedAcct;
				if("J".equals(crAccount.getBlockCode()) && !(("Q").equalsIgnoreCase(crAccount.getAccountId().getAcctStatus()) && ("J").equalsIgnoreCase(crAccount.getBlockCode()))) {
					(((AccountInfoResp) serviceResponse).getAccountDetail()).setAllowTnxCategorisation(true);
				}
				
				if("S".equals(crAccount.getBlockCode())) {
					(((AccountInfoResp) serviceResponse).getAccountDetail()).setBalance(null);
					(((AccountInfoResp) serviceResponse).getAccountDetail()).setAvailBalance(null);
				}
			}
			
			
			
			RespHeader headerResp = populateResponseHeader(ServiceConstants.ACCOUNT_INFO_SERVICE, mbSession);
			serviceResponse.setHeader(headerResp);
			
			AccountInfoResp logResp = (AccountInfoResp) serviceResponse;
			if(selectedAcct.getAccountId() != null && selectedAcct.getAccountId().getAccountNumber()!=null){
				StringBuilder acctInfoLog = new StringBuilder();
				acctInfoLog.append("Account Info response generated, AcctNumber: " + selectedAcct.getAccountId().getAccountNumber());
				if(logResp.getTranHistory()!=null && logResp.getTranHistory().getTranList()!=null){
					acctInfoLog.append(", Number of transactions: "+ logResp.getTranHistory().getTranList().size());
				}
				Logger.info(acctInfoLog.toString(), this.getClass());
			}
			
			if(Logger.isDebugEnabled(this.getClass())){
				Logger.debug("Account History info Response :" + objectMapper.writeValueAsString(serviceResponse), this.getClass());
			}
			
			return serviceResponse;		
		}catch (BusinessException e)
		{
			if (BusinessException.POLICY_DETAILS_UNAVAILABLE == e.getKey()){
				Logger.info("BusinessException Inside processAcctInfo() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "]", e, this.getClass());
				IMBResp resp1  = MBAppUtils.createErrorResp(mbSession.getOrigin() ,e, ServiceConstants.ACCOUNT_INFO_SERVICE, httpServletRequest);
				return resp1;
			}else{	
				BusinessException exp = null;
				Logger.info("BusinessException Inside processAcctInfo() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "]", e, this.getClass());		
				exp = new BusinessException(BusinessException.ACCOUNT_INFO_UNAVAILABLE);
				IMBResp resp1  = MBAppUtils.createErrorResp(mbSession.getOrigin() ,exp, ServiceConstants.ACCOUNT_INFO_SERVICE, httpServletRequest);
				return resp1;
			}
		}catch (ResourceException e) {
			Logger.error("ResourceException Inside processAcctInfo() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "]", e, this.getClass());			
			ResourceException exp = new ResourceException(BusinessException.ACCOUNT_INFO_UNAVAILABLE);
			IMBResp resp1  = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, ServiceConstants.ACCOUNT_INFO_SERVICE, httpServletRequest);
			return resp1;
		}catch (Exception e)
		{			
			Logger.error("Exception Inside processAcctInfo() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "]", e, this.getClass());
			BusinessException exp = new BusinessException(BusinessException.ACCOUNT_INFO_UNAVAILABLE);
			IMBResp resp1  = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, ServiceConstants.ACCOUNT_INFO_SERVICE, httpServletRequest);
			return resp1;
		} finally
		{
			perfLogger.endLog(logName);
			perfLogger.endAllLogs();
		}				
	}
	
	@RequestMapping(value ="history", method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public IMBResp processAcctHistory(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse,
			@RequestBody final AccountInfoReq req)
	{								
		ObjectMapper objectMapper = new ObjectMapper();					
		TransactionHistory trxnHist = null;				
		perfLogger.startAllLogs();
		String logName = MBAppUtils.getLogName(httpServletRequest);
		perfLogger.startLog(logName);
		MobileSession mbSession = null;
		Calendar toCalendarUI = null;
		boolean isRespCameFromExtendHist = false;
		try{

			mbSession = mbAppHelper.getMobileSession(httpServletRequest);
			Logger.info("Account History JSON Request :" + objectMapper.writeValueAsString(req), this.getClass());
			validateRequestHeader(req.getHeader(), httpServletRequest);
			ErrorResp errorResp = validate(req, httpServletRequest);
			if (errorResp != null && errorResp.getErrors() != null && errorResp.getErrors().size() > 0)
			{				
				return errorResp;
			}			
			
			int myAcctIndex = req.getAccountIndex();
			Customer customer=mbSession.getCustomer();			
						
			Account selectedAcct=mbAppHelper.getAccountFromCustomer(customer, myAcctIndex);
			
			IBankCommonData commonData=null;
			TransactionHistory sessionTranHist = mbSession.getTransactionHistory();
			if(selectedAcct!=null){
				
				commonData=mbAppHelper.populateIBankCommonData(mbSession,httpServletRequest);
				
				/* Advanced search extend tran history changes start*/
				if(accountInfoHelper.isAdvancedSearch(req)){
					Logger.debug("Calling Extend Transaction History Service | getAdvancedTransactionHistory" ,this.getClass());
					accountInfoHelper.validateAdvancedSearch(req);
					trxnHist = extendTranHistService.getAdvancedTransactionHistory(selectedAcct.getAccountId(),commonData, req.getAdvanceSearch().getDescription(),req.getAdvanceSearch().getFromDate(),req.getAdvanceSearch().getToDate(),req.getAdvanceSearch().getFromAmount(),req.getAdvanceSearch().getToAmount());
					accountInfoHelper.createGDWEntryForAdvancedSearch(req.getAdvanceSearch(), commonData, selectedAcct.getAccountId());
				}else{
					if(IBankParams.isExtendTranHistSwitchOn(commonData.getOrigin(),selectedAcct.getAccountId().getApplicationId(),customer.getGcis())){
						// merged transactions from extend tran hist
						Logger.debug("Calling Extend Transaction History Service | getMergedTransactionHistory" ,this.getClass());
						isRespCameFromExtendHist = true;
						int numberOfTranReqd = accountInfoHelper.calculateNumberOfTranReqd(mbSession, Integer.parseInt(IBankParams.getExtendTranHistMaxTransaction(commonData.getOrigin())));
						if(numberOfTranReqd==0){
							Logger.debug("As number of tran reqd is 0, no need to call the service" ,this.getClass());
							trxnHist = new AccountingTransactionHistory();
							trxnHist.setTransactions(new ArrayList<TransactionInfo>());
						}else{
							Logger.debug("Calling the new Service for mergedTransactions " ,this.getClass());
							//19E1 CI - Removing increase transaction history CI item
							/*
							toCalendarUI = formatUIDate(req.getToDate());
							if (toCalendarUI != null){
								Logger.debug("To Date from UI :"+toCalendarUI.getTime().toString(),this.getClass());
							}*/
							trxnHist = extendTranHistService.getMergedTransactionHistory(selectedAcct.getAccountId(),commonData,req.getHistoryPeriod(),null,numberOfTranReqd, smartPlansService.isCustomerPrimaryCardHolder(selectedAcct));
						}
						if(null != trxnHist && null!=trxnHist.getTransactions())
							Logger.debug("Transaction History List size: " + trxnHist.getTransactions().size(),this.getClass());
						//trxnHist = extendTranHistService.getMergedTransactionHistory(selectedAcct.getAccountId(),commonData,req.getHistoryPeriod(),null);
						//19E1 CI - Removing increase transaction history CI item
						//accountInfoHelper.updateExtendTranHistInSession(mbSession, trxnHist, false);
						sessionTranHist = accountInfoHelper.updateExtendTranHistInSession(mbSession,sessionTranHist, trxnHist, req.getHistoryPeriod());
					}else{
						toCalendarUI = formatUIDate(req.getToDate());
						Logger.debug("Calling Mobile Bank Service | getTransactionHistory" ,this.getClass());
						trxnHist = mobileBankService.getTransactionHistory(selectedAcct.getAccountId(), commonData,req.getHistoryPeriod(),toCalendarUI);	
					}
				}
				/* Advanced search extend tran history changes end*/
			}else
				throw new BusinessException(BusinessException.NO_INFORMATION);
			
			/*Need not cache for Advanced Search response, as it has impact on other inquiries*/
			
			if(!accountInfoHelper.isAdvancedSearch(req)){
				if (req.getCcDispute() != null && req.getCcDispute()) {
					//TransactionHistory sessionTranHist = mbSession.getTransactionHistory();
					if (sessionTranHist == null) {
						sessionTranHist = new AccountingTransactionHistory();
						sessionTranHist.setTransactions(new ArrayList<TransactionInfo>());
					} else if (sessionTranHist.getTransactions() == null)
						sessionTranHist.setTransactions(new ArrayList<TransactionInfo>());
					if (trxnHist == null) {
						trxnHist = new AccountingTransactionHistory();
						trxnHist.setTransactions(new ArrayList<TransactionInfo>());
					} else if (trxnHist.getTransactions() == null)
						trxnHist.setTransactions(new ArrayList<TransactionInfo>());
					String cardType="";
					if(Account.CRA.equals(selectedAcct.getAccountId().getApplicationId())){
						cardType="credit";
						
					}
					else if (Account.DDA.equals(selectedAcct.getAccountId().getApplicationId())){
						cardType="debit";
					}
					//19E4 - Defect fix. Commenting the below as we are already updating the results in session above using accountInfoHelper.updateExtendTranHistInSession.
					//This was causing dup entries in session and incorrect transaction is getting disputed via MB.
					/*
					if (!"30".equals(req.getHistoryPeriod())){
						sessionTranHist.getTransactions().addAll(sessionTranHist.getTransactions().size(), trxnHist.getTransactions());
						mbSession.setTransactionHistory(sessionTranHist);
						
					}else{
						mbSession.setTransactionHistory(trxnHist);
					}*/
					/*DateFormat df = new SimpleDateFormat("dd/MM/yyyy");
					String fromDate = df.format(DateMethods.relativeDate( DateMethods.getUtilDate(),-150));
					String toDate = df.format(DateMethods.relativeDate( DateMethods.getUtilDate(),-1));
					TransactionHistory hist = mbSession.getTransactionHistory();
					List<TransactionInfo> tranList =cardDisputeService.getFilteredCardDisputeTransactions(hist, cardType, fromDate, toDate);
					hist.setTransactions(tranList);
					mbSession.setTransactionHistory(hist);*/
					
				}
				else
				{
					//19E1 CI - Removing increase transaction history CI item
					//updateTranHistoryDetailsInSession(selectedAcct,  trxnHist, req.getHistoryPeriod(),  mbSession , commonData , false, isRespCameFromExtendHist, formatUIDate(req.getToDate()));
					updateTranHistoryDetailsInSession(selectedAcct,  trxnHist, req.getHistoryPeriod(),  mbSession , commonData,isMaxTranHistoryReached( sessionTranHist, commonData));
				}
			}
			
			boolean isCategorisationAvailableForTranHistory = false;
			if(Account.CRA.equalsIgnoreCase(selectedAcct.getAccountId().getApplicationId()) || Account.DDA.equalsIgnoreCase(selectedAcct.getAccountId().getApplicationId())){
				isCategorisationAvailableForTranHistory = categorisationService.isCategorisationAvailableForTranHistory(selectedAcct, commonData);
			}
			
			boolean isGoogleSearchAllowed = false;
			
			if(selectedAcct.isApplicationIdCra() || selectedAcct.isApplicationIdDda()){
				isGoogleSearchAllowed = true;
			}
			
			AccountInfoResp serviceResponse = new AccountInfoResp();
			
			// 20E4 Smart plan Customer account eligibility check
			boolean isAccountEligibleForSmartPlans = mbSession.getIsAccountEligibleForSmartPlan() != null ? mbSession.getIsAccountEligibleForSmartPlan() : false;
			boolean isAccEligibleForPurchaseSmartPlans = mbSession.getIsAccountEligibleForPurchaseSmartPlan() != null ? mbSession.getIsAccountEligibleForPurchaseSmartPlan() : false;
			
			if(isRespCameFromExtendHist){
				 //19E1 Release Fix
				 //minimise invokation to mbSession.getTransactionHistory(); because every time triggers SELECT SESSION
				 TransactionHistory tranHistorySession = mbSession.getTransactionHistory();
				 accountInfoHelper.populateAcctHistoryResp(tranHistorySession, serviceResponse, trxnHist,toCalendarUI,isCategorisationAvailableForTranHistory,isGoogleSearchAllowed,isRespCameFromExtendHist,commonData, selectedAcct.getAccountId().getApplicationId(), isAccountEligibleForSmartPlans, isAccEligibleForPurchaseSmartPlans);
			}else{
				 accountInfoHelper.populateAcctHistoryResp(serviceResponse, trxnHist,toCalendarUI,isCategorisationAvailableForTranHistory,isGoogleSearchAllowed,commonData, selectedAcct.getAccountId().getApplicationId(), isAccountEligibleForSmartPlans, isAccEligibleForPurchaseSmartPlans);
			}
			
			
									
			RespHeader headerResp = populateResponseHeader(ServiceConstants.ACCOUNT_HISTORY_SERVICE, mbSession);
			serviceResponse.setHeader(headerResp);
			
			if(selectedAcct.getAccountId() != null && selectedAcct.getAccountId().getAccountNumber()!=null){
				StringBuilder acctInfoLog = new StringBuilder();
				acctInfoLog.append("Account History response generated, AcctNumber: " + selectedAcct.getAccountId().getAccountNumber());
				if(serviceResponse.getTranHistory()!=null && serviceResponse.getTranHistory().getTranList()!=null){
					acctInfoLog.append(", Number of transactions: "+ serviceResponse.getTranHistory().getTranList().size());
				}
				Logger.info(acctInfoLog.toString(), this.getClass());
			}
			if(Logger.isDebugEnabled(this.getClass())){
				if(null != trxnHist && null!=trxnHist.getTransactions()){
				Logger.debug("Transaction History List size: " + trxnHist.getTransactions().size(),this.getClass());
				}
			    Logger.debug("Account History Response :" + objectMapper.writeValueAsString(serviceResponse), this.getClass());
			}	
			return serviceResponse;		
		}catch (BusinessException e)
		{
			Logger.info("BusinessException Inside processAcctHistory() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "]", e, this.getClass());
			BusinessException exp = new BusinessException(e.getKey());
			IMBResp resp1  = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, ServiceConstants.ACCOUNT_HISTORY_SERVICE, httpServletRequest);
			return resp1;
		} catch (ResourceException e) {
			Logger.error("ResourceException Inside processAcctHistory() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "]", e, this.getClass());
			ResourceException exp = new ResourceException(e.getKey());
			IMBResp resp1  = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, ServiceConstants.ACCOUNT_HISTORY_SERVICE, httpServletRequest);
			return resp1;
		}catch (Exception e)
		{
			Logger.error("Exception Inside processAcctHistory() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "]", e, this.getClass());
			BusinessException exp = new BusinessException(BusinessException.GENERIC_ERROR);
			IMBResp resp1  = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, ServiceConstants.ACCOUNT_HISTORY_SERVICE, httpServletRequest);
			return resp1;
		} finally
		{
			perfLogger.endLog(logName);
			perfLogger.endAllLogs();
		}				
	}
	
	/**
	 * @param dateStr
	 * @return
	 */
	private Calendar formatUIDate(String dateStr){
		
		Calendar calendarUIAdvSearch = null; 
		
		if(!StringMethods.isEmptyString(dateStr)){
			long dateMilliSeconds = Long.parseLong(dateStr);
			calendarUIAdvSearch = Calendar.getInstance();
			calendarUIAdvSearch.setTimeInMillis(dateMilliSeconds);
		}
		
		return calendarUIAdvSearch; 
	}
	
	
	
	/**
	 * checkHLIEligibility service operation
	 * 
	 * @param httpRequest
	 * @param request
	 * @return
	 */
	@RequestMapping(method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE, value = "checkHLI")
	@ResponseBody
	public IMBResp checkHLIEligibility(HttpServletRequest httpRequest, @RequestBody final IndexReq request) {
		Logger.debug("AccountInfoController - checkHLIEligibility(). Request: " + request, this.getClass());

		perfLogger.startAllLogs();
		String logName = MBAppUtils.getLogName(httpRequest);
		perfLogger.startLog(logName);

		MobileSession mobileSession = new MobileSessionImpl();
		try {
			mobileSession.getSessionContext(httpRequest);
			IBankCommonData commonData = new MBAppHelper().populateIBankCommonData(mobileSession, httpRequest);

			validateRequestHeader(request.getHeader(), httpRequest);
			mobileSession.getSessionContext(httpRequest);
			commonData.setCustomer(mobileSession.getCustomer());
			ErrorResp errorResponse = validate(request, httpRequest);// validate json
			if (errorResponse.hasErrors())
				return errorResponse;

			String destination = "";
			String link = "";
			boolean isExisting = false;

			Account account = mobileSession.getCustomer().getAccounts().get(Integer.parseInt(request.getIndex()));

			Account acctDetail = mobileBankService.getAccountDetails(account.getAccountId(), commonData);
			if (acctDetail instanceof LoanAccount || acctDetail instanceof DdaAccount) {
				
				setLoanIncreaseFlag(commonData, acctDetail);

				if (acctDetail instanceof LoanAccount && "X".equals(((LoanAccount) acctDetail).getDispLoanIncreaseLink())
						|| (acctDetail instanceof DdaAccount && "X".equals(((DdaAccount) acctDetail).getDispLoanIncreaseLink()))) {
					try {
						Statistic s = new Statistic();
						s.setAction(Statistic.DIRECT_EXTERNAL_LINK);
						s.setGcisNumber(commonData.getUser().getGCISNumber());
						s.setOriginBank(commonData.getOrigin());
						s.setIpAddress(commonData.getIpAddress());
						s.setGDWOriginBank(commonData.getGdwOrigin());
						s.setSessionId(commonData.getSessionId());
						s.setDescription("Account|Loans|Home Loan Increase");
						StatisticsService.logStatistic(s);
					} catch (Exception e) {
						Logger.error(" Mobile Banking - Failed Statistic log for getHomeLoanIncreaseLink", this.getClass());
					}
					destination = "OAF";
					link = hliAccountsService.getOAFUrl(mobileSession.getOrigin());
					link+="&appAction=exitNoPrompt";
				} else {

					String hliEligFlag = hliAccountsService.checkHLIEligibility(commonData, account);

					if ("4".equalsIgnoreCase(hliEligFlag)) {
						// CLAS Web-already submitted
						throw new BusinessException(BusinessException.HOMELOAN_NOT_INCREASABLE);
					} else if ("3".equalsIgnoreCase(hliEligFlag)) {
						throw new BusinessException(BusinessException.HOMELOAN_NOT_INCREASABLE);
					} else if ("-".equalsIgnoreCase(hliEligFlag)) {
						throw new BusinessException(BusinessException.GENERIC_ERROR);
					} else if ("2".equalsIgnoreCase(hliEligFlag)) {
						destination = "OAF";
						try {
							Statistic s = new Statistic();
							s.setAction(Statistic.DIRECT_EXTERNAL_LINK);
							s.setGcisNumber(commonData.getUser().getGCISNumber());
							s.setOriginBank(commonData.getOrigin());
							s.setIpAddress(commonData.getIpAddress());
							s.setGDWOriginBank(commonData.getGdwOrigin());
							s.setSessionId(commonData.getSessionId());
							s.setDescription("Account|Loans|Home Loan Increase");
							StatisticsService.logStatistic(s);
						} catch (Exception e) {
							Logger.error(" Mobile Banking - Failed Statistic log for getHomeLoanIncreaseLink", this.getClass());
						}
						link = hliAccountsService.getOAFUrl(mobileSession.getOrigin());
						link+="&appAction=exitNoPrompt";
					} else if ("1".equalsIgnoreCase(hliEligFlag) || "5".equalsIgnoreCase(hliEligFlag)) {
						destination = "CLAS";
						if ("5".equalsIgnoreCase(hliEligFlag)) isExisting = true;
						link = externalLinkService.getHomeLoanIncreaseURL(commonData, account);
					} else {
						Logger.error("Unknown response from .checkHLIEligibility()", this.getClass());
						throw new BusinessException(BusinessException.GENERIC_ERROR);
					}
				}
			}
			return accountInfoHelper.populateHLIResponse(populateResponseHeader(ServiceConstants.HLI_SERVICE, mobileSession), destination, link, isExisting);
		} catch (BusinessException e) {
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), e, ServiceConstants.HLI_SERVICE, httpRequest);
		} catch (ResourceException e) {
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.SYSTEM_UNAVILABLE, ServiceConstants.HLI_SERVICE,
					httpRequest);
		} catch (Exception e) {
			Logger.error("Exception AccountInfoController - checkHLIEligibility(): GCIS: ["
					+ ((mobileSession != null && mobileSession.getCustomer() != null) ? mobileSession.getCustomer().getGcis() : "") + "] :", e, this
					.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), ResourceException.MOBILE_NON_FINANCIAL_FATAL_ERR,
					ServiceConstants.HLI_SERVICE, httpRequest);
		} finally {
			perfLogger.endLog(logName);
			perfLogger.endAllLogs();
		}

	}

	/**
	 * closeSessionForMakeAClaim service operation
	 * 
	 * @param httpRequest
	 * @param request
	 * @return
	 */
	@RequestMapping(method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE, value = "closeSession")
	@ResponseBody
	public IMBResp closeSessionForMakeAClaim(HttpServletRequest httpRequest, @RequestBody final EmptyReq request) {
		Logger.debug("AccountInfoController - closeSessionForMakeAClaim(). Request: " + request, this.getClass());
		
		ObjectMapper objectMapper = new ObjectMapper();	
		perfLogger.startAllLogs();
		String logName = MBAppUtils.getLogName(httpRequest);
		perfLogger.startLog(logName);

		MobileSession mobileSession = new MobileSessionImpl();
		try {
			mobileSession.getSessionContext(httpRequest);
			IBankCommonData commonData = new MBAppHelper().populateIBankCommonData(mobileSession, httpRequest);

			validateRequestHeader(request.getHeader(), httpRequest);
			mobileSession.getSessionContext(httpRequest);
			commonData.setCustomer(mobileSession.getCustomer());
			ErrorResp errorResp = validate(request, httpRequest);// validate json
			if (errorResp != null && errorResp.getErrors() != null && errorResp.getErrors().size() > 0)
				return errorResp;
			
			if(mobileSession.getPolicyAppId() != null && mobileSession.getPolicySubProdCode() != null){
				try{
				ExternalLinkService extService = ServiceHelper.getBean("externalLinkService");
				extService.createLogStatistics(commonData, true, IBankParams.INSURANCE+"|"+mobileSession.getPolicyAppId()+"|"+mobileSession.getPolicySubProdCode()+"|"+IBankParams.CLAIM_INSURANCE);
				}
				catch(Exception e){
					Logger.error(" Unable to create statistics entry in closeSessionForMakeAClaim(). ", this.getClass());
				}
				}
			else{
				Logger.error(" Unable to get the ApplId and SubProdCode for Policy in closeSessionForMakeAClaim().", this.getClass());
				//throw new BusinessException(BusinessException.GENERIC_ERROR);
			}
			
			SuccessResp successResp = new SuccessResp();																			
			RespHeader headerResp = populateResponseHeader(request.getHeader().getServiceName(), mobileSession);
			successResp.setHeader(headerResp);
			successResp.setIsSuccess(true);
			
			Logger.info("closeSessionForMakeAClaim Info JSON Response :" + objectMapper.writeValueAsString(successResp), this.getClass());

			return successResp;

		} catch (BusinessException e) {
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), e, ServiceConstants.CLOSE_SESSION_FOR_MAKEACLAIM, httpRequest);
		} catch (ResourceException e) {
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.SYSTEM_UNAVILABLE, ServiceConstants.CLOSE_SESSION_FOR_MAKEACLAIM,
					httpRequest);
		} catch (Exception e) {
			Logger.error("Exception AccountInfoController - closeSessionForMakeAClaim(): GCIS: ["
					+ ((mobileSession != null && mobileSession.getCustomer() != null) ? mobileSession.getCustomer().getGcis() : "") + "] :", e, this
					.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), ResourceException.MOBILE_NON_FINANCIAL_FATAL_ERR,
					ServiceConstants.CLOSE_SESSION_FOR_MAKEACLAIM, httpRequest);
		} finally {
			if ( mobileSession != null )
				mobileSession.invalidateSession();
			perfLogger.endLog(logName);
			perfLogger.endAllLogs();
		}

	}


	//17E2 Service Interaction and Cross Sell Feature: This method will return the cross sell service function details for each transaction.
	
	/**
	 * @param httpServletRequest
	 * @param httpServletResponse
	 * @param req
	 * @return
	 */
	@RequestMapping(value= "tnxCrossSellDtls" , method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public IMBResp getTransCrossSellDetails(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse,
			@RequestBody final TransactionDetailsReq req)
	{				
				
		ObjectMapper objectMapper = new ObjectMapper();				
		perfLogger.startAllLogs();
		String logName = MBAppUtils.getLogName(httpServletRequest);
		perfLogger.startLog(logName);
		
		fraudLogger = new FraudLogger();
		MobileSession mbSession = null;
		try{	
			
			mbSession = mbAppHelper.getMobileSession(httpServletRequest);		
			Logger.info("Account tnxCrossSellDtls JSON Request :" + objectMapper.writeValueAsString(req), this.getClass());
			validateRequestHeader(req.getHeader(), httpServletRequest);
			ErrorResp errorResp = validate(req, httpServletRequest);
			if (errorResp != null && errorResp.getErrors() != null && errorResp.getErrors().size() > 0)
			{				
				//fraudLogger.logInvalidInput();
				return errorResp;
			}			
																			
			int myAcctIndex = req.getAccountIndex();
			Customer customer=mbSession.getCustomer();			
						
			Account selectedAcct=mbAppHelper.getAccountFromCustomer(customer, myAcctIndex);
			
			IBankCommonData commonData=null;
			TransactionHistoryCrossLink crossSellDtls = null;
			
			if(selectedAcct!=null){
				
				commonData=mbAppHelper.populateIBankCommonData(mbSession,httpServletRequest);
					
				crossSellDtls = tranCategorisationService.getTransactionHistCrossLinks(commonData, selectedAcct, !req.isDebit(), req.isCardLinked(),true);
				
			}else{
				Logger.info("Exception in getTransCrossSellDetails : selectedAcct object is null. " + objectMapper.writeValueAsString(req), this.getClass());
				throw new BusinessException(BusinessException.NO_INFORMATION, "selectedAcct object is null. ");
				}
			
			if(crossSellDtls == null){
				Logger.info("Exception in getTransCrossSellDetails : crossSellDtls object is null. " + objectMapper.writeValueAsString(req), this.getClass());
				throw new BusinessException(BusinessException.NO_INFORMATION, "crossSellDtls object is null.");
				}
			ServiceStationResp resp = null;
			try{
					long insertionPt = accountInfoHelper.getInsertionPointCode(ServicetationConstants.TRAN_HISTORY_DTLS);
					ServiceStationVO serviceStationVo = serviceStationService.getServiceMessage(insertionPt, ServiceStationImpl.CHANNEL_MOBILE, commonData);					
					if(null!=serviceStationVo)
					{
						resp = accountInfoHelper.populateServiceStationResp(serviceStationVo);
						//mbSession.setServiceStationAccountDetailMessage(serviceStationVo.getServiceStationMsg());
					}					
			}catch(BusinessException bex){
				Logger.error("An error occurred while getting service station message for mobile accoutn details", bex, this.getClass());
			}

			IMBResp serviceResponse = accountInfoHelper.getTranCrossSellResp(crossSellDtls, resp);
		
			RespHeader headerResp = populateResponseHeader(ServiceConstants.TRANS_CROSSELL_SERVICE, mbSession);
			serviceResponse.setHeader(headerResp);
			
			Logger.info("tnxCrossSellDtls JSON Response :" + objectMapper.writeValueAsString(serviceResponse), this.getClass());
			
			return serviceResponse;		
		}catch (BusinessException e)
		{
				Logger.info("BusinessException Inside getTransCrossSellDetails() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "]", e, this.getClass());
				IMBResp resp1  = MBAppUtils.createErrorResp(mbSession.getOrigin() ,e, ServiceConstants.TRANS_CROSSELL_SERVICE, httpServletRequest);
				return resp1;
		}catch (ResourceException e) {
			Logger.error("ResourceException Inside getTransCrossSellDetails() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "]", e, this.getClass());			
			//IMBResp resp1  = MBAppUtils.createErrorResp(mbSession.getOrigin(), BusinessException.SYSTEM_UNAVILABLE, ServiceConstants.TRANS_CROSSELL_SERVICE, httpServletRequest);
			IMBResp resp1  = MBAppUtils.createErrorResp(mbSession.getOrigin(), e, ServiceConstants.TRANS_CROSSELL_SERVICE, httpServletRequest);
			return resp1;
		}catch (Exception e)
		{			
			Logger.error("Exception Inside getTransCrossSellDetails() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "]", e, this.getClass());
			IMBResp resp1  = MBAppUtils.createErrorResp(mbSession.getOrigin(), BusinessException.SYSTEM_UNAVILABLE, ServiceConstants.TRANS_CROSSELL_SERVICE, httpServletRequest);
			return resp1;
		} finally
		{
			perfLogger.endLog(logName);
			perfLogger.endAllLogs();
		}				
	}
	
	/**
	 * @param httpServletRequest
	 * @param httpServletResponse
	 * @param req
	 * @return
	 */
	@RequestMapping(value= "transactionDetails" , method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public IMBResp getTransactionDetails(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse,
			@RequestBody final TransactionDetailsReq req)
	{				
		final String methodName = "AccountInfoController.getTransactionDetails():";
		
		ObjectMapper objectMapper = new ObjectMapper();				
		perfLogger.startAllLogs();
		String logName = MBAppUtils.getLogName(httpServletRequest);
		perfLogger.startLog(logName);
		
		fraudLogger = new FraudLogger();
		MobileSession mbSession = null;
		boolean showAbusiveLinkIntraDay = false;
		try{	
			
			mbSession = mbAppHelper.getMobileSession(httpServletRequest);		
			Logger.info("Account transactionDetails JSON Request :" + objectMapper.writeValueAsString(req), this.getClass());
			validateRequestHeader(req.getHeader(), httpServletRequest);
			ErrorResp errorResp = validate(req, httpServletRequest);
			if (errorResp != null && errorResp.getErrors() != null && errorResp.getErrors().size() > 0){				
				return errorResp;
			}			
																			
			int myAcctIndex = req.getAccountIndex();
			Customer customer=mbSession.getCustomer();	
			Account selectedAcct=mbAppHelper.getAccountFromCustomer(customer, myAcctIndex);
			IBankCommonData commonData=mbAppHelper.populateIBankCommonData(mbSession,httpServletRequest);
			
			// 21E2
			String trxnRefNumber_ = null;

			String gcisNo_ = customer.getGcis();
			Logger.info(methodName + "gcisNo: " + gcisNo_, this.getClass());

			String accountNo_ = null;
			String bsb_ = null;
			try {
				accountNo_ = selectedAcct.getAccountId().getAccountNumber();
				bsb_ = selectedAcct.getAccountId().getBsb();
				Logger.info(methodName + "accountNo: " + accountNo_ + "  Bsb: "+bsb_, this.getClass());
			} catch (Exception tExc) {
				Logger.error(methodName + "Exception caught while getting account number", tExc, this.getClass());
			}
			// 21E2
			
			NPPTransactionDetail nppTransactionDetails = null;
			MerchantTransactionInfo lwcDetailsResp = null;
			
			boolean isNPPInwardSwitchOn = ibankRefreshParams.isNPPInwardSwitchON(commonData.getOrigin(), commonData.getUser().getGCISNumber());
			boolean isNPPOutwardSwitchOn = ibankRefreshParams.isNPPOutwardSwitchON(commonData.getOrigin(), commonData.getUser().getGCISNumber());
			
			if(isNPPInwardSwitchOn) {
				if(null != req && StringMethods.isEmptyString(req.getpRPaymentId())) {
					if(!StringMethods.isEmptyString(req.getTransDate()) && !StringMethods.isEmptyString(req.getTransDesc())) {
						String transDate = req.getTransDate();
						String transDesc =  req.getTransDesc();
						showAbusiveLinkIntraDay = accountInfoHelper.isReportIntraDayTrans(transDesc, transDate);
					}					
				}
			}
			if(IBankParams.isLWCSwitchON()) {
				long timeOut = IBankParams.lwcAPIParrallelCallTimeout();
				final IBankCommonData ibankCommonData = commonData;
				InitialContext initialContext = JNDIMethods.createInitialContext();
				ExecutorService executorService = (ExecutorService) initialContext.lookup("wm/ExecutorService");	
				Callable<MerchantTransactionInfo> getLWCDetails = getLWCDetails(req, ibankCommonData);
		        Callable<NPPTransactionDetail> getNPPTransactionDetail = getNPPTransactionDetail(req, ibankCommonData);
		        Future<MerchantTransactionInfo> lwcDetailsFuture = executorService.submit(getLWCDetails);
		        Future<NPPTransactionDetail> nppTranDetailsFuture = executorService.submit(getNPPTransactionDetail);
		        
		        try {
		        	lwcDetailsResp = lwcDetailsFuture.get(timeOut,TimeUnit.SECONDS);
				} catch (InterruptedException | ExecutionException | TimeoutException e) {
					Logger.error("Exception while retrieving LWC Resp ", e, this.getClass());
					throw new BusinessException(BusinessException.GENERIC_ERROR);
				}
		        
		        try {
		        	nppTransactionDetails = nppTranDetailsFuture.get(timeOut,TimeUnit.SECONDS);
		        	if (nppTransactionDetails!=null && nppTransactionDetails.isErrorResponse()) {
						errorResp = MBAppUtils.createErrorResp(mbSession.getOrigin(), BusinessException.NPP_INWARD_PAY_ERROR, ServiceConstants.TRANS_DETAILS, httpServletRequest);
					}
		        } catch (InterruptedException | ExecutionException | TimeoutException e) {
					Logger.error("Exception while retrieving NPP Tran Details Resp ", e, this.getClass());
					throw new BusinessException(BusinessException.GENERIC_ERROR);
				}
			}else {

				if(null != req && !StringMethods.isEmptyString(req.getpRPaymentId()) && !StringMethods.isEmptyString(req.getNppTranType())) {
					Logger.debug("TransactionDetailsReq: PRPaymentId : " + req.getpRPaymentId()+", nppTranType : " + req.getNppTranType()+", isDebit : " + req.isDebit(), this.getClass());					
					boolean isDebit = true;
					boolean isErrorResponse = false;
					if (null == req.isDebit() || req.isDebit() == false) {
						isDebit = false;
					}
										
					try {
						if (isNPPInwardSwitchOn
								&& (NPPUtil.isOriginalInwardTransaction(req.getNppTranType(), isDebit) || NPPUtil.isReturnOfInwardTransaction(
										req.getNppTranType(), isDebit))) {
							nppTransactionDetails = nppTransactionService.getInwardNPPTransactionDetail(req.getpRPaymentId(),
									req.getNppTranType(), isDebit, commonData);
							isErrorResponse = validateNPPTransactionDetails(req, nppTransactionDetails, isDebit, isErrorResponse);
							nppTransactionDetails.setEffectiveDate(req.getTransDate());
							if(NPPUtil.isOriginalInwardTransaction(req.getNppTranType(), isDebit)) {
							nppTransactionDetails.setShowReportAbusiveLink(accountInfoHelper.isReportInappropriateEligible(nppTransactionDetails));
							}
						
						} else if (((NPPUtil.isOriginalOutwardTransaction(req.getNppTranType(), isDebit))
								|| (NPPUtil.isReturnOfOutwardTransaction(req.getNppTranType(), isDebit)) || (NPPUtil
									.isReversalOfOutwardTransaction(req.getNppTranType(), isDebit))) && isNPPOutwardSwitchOn) {
							nppTransactionDetails = nppTransactionService.getOutwardNPPTransactionDetail(req.getpRPaymentId(),
									req.getNppTranType(), isDebit, commonData);
							isErrorResponse = validateNPPTransactionDetails(req, nppTransactionDetails, isDebit, isErrorResponse);
						}
					} catch (Exception ex) {
						Logger.error("Error while making NPP details WDP call for Customer GCIS: ["+ ((mbSession != null && mbSession.getCustomer() != null) ? mbSession.getCustomer().getGcis() : "") + "]", ex,this.getClass());
						isErrorResponse = true;
					} finally {
						if (isErrorResponse) {
							errorResp = MBAppUtils.createErrorResp(mbSession.getOrigin(), BusinessException.NPP_INWARD_PAY_ERROR,ServiceConstants.TRANS_DETAILS, httpServletRequest);
						}
					}
				}
			}
			
			ServiceStationResp serviceStationResp = null;
			if (selectedAcct != null) {
				try {
					long insertionPt = accountInfoHelper.getInsertionPointCode(ServicetationConstants.TRAN_HISTORY_DTLS);
					ServiceStationVO serviceStationVo = serviceStationService.getServiceMessage(insertionPt, ServiceStationImpl.CHANNEL_MOBILE, commonData);
					if (null!=serviceStationVo)
					{
						serviceStationResp = accountInfoHelper.populateServiceStationResp(serviceStationVo);
						// mbSession.setServiceStationAccountDetailMessage(serviceStationVo.getServiceStationMsg());
					}
				} catch (BusinessException bex) {
					Logger.error("An error occurred while getting service station message for mobile accoutn details",bex, this.getClass());
				}
			}

			trxnRefNumber_ = abusiveTransactionsService.getTransactionRefNumber(nppTransactionDetails.getUnformattedBic(), 
					nppTransactionDetails.getCreditStatusTransId());
			Logger.info(methodName + "trxnRefNumber: " + trxnRefNumber_, this.getClass());
			
			IMBResp serviceResponse = accountInfoHelper.populateTransactionDetailsResp(nppTransactionDetails,
					serviceStationResp, lwcDetailsResp, errorResp, showAbusiveLinkIntraDay, gcisNo_, accountNo_,
					trxnRefNumber_);
			mbSession.removeAbusiveTransactionDetails();
			if(null != nppTransactionDetails) {
				if(nppTransactionDetails.isShowReportAbusiveLink()) {
					AbusiveTransactionVO abusiveTransVO = accountInfoHelper.populateAbusiveTransVO(nppTransactionDetails,accountNo_,bsb_,req.getpRPaymentId());
					abusiveTransVO.setAbusiveReferenceNumber(trxnRefNumber_);
					mbSession.setAbusiveTransactionDetails(abusiveTransVO);
				}
			}
			/*((TransactionNppDetailsResp)serviceResponse).setTotalCategoryAmount(totalAmountSpentOnCategory);*/
			accountInfoHelper.logStatistic(selectedAcct, commonData, TXDET, lwcDetailsResp);
			RespHeader headerResp = populateResponseHeader(ServiceConstants.TRANS_DETAILS, mbSession);
			serviceResponse.setHeader(headerResp);
			
			Logger.info("Npp Inward payment details JSON Response :" + objectMapper.writeValueAsString(serviceResponse), this.getClass());
			
			return serviceResponse;		
		}catch (ResourceException e) {
			Logger.error("ResourceException Inside getTransactionDetails() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "]", e, this.getClass());			
			IMBResp resp1  = MBAppUtils.createErrorResp(mbSession.getOrigin(), e, ServiceConstants.TRANS_DETAILS, httpServletRequest);
			return resp1;
		}catch (Exception e)
		{			
			Logger.error("Exception Inside getTransactionDetails() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "]", e, this.getClass());
			IMBResp resp1  = MBAppUtils.createErrorResp(mbSession.getOrigin(), BusinessException.SYSTEM_UNAVILABLE, ServiceConstants.TRANS_DETAILS, httpServletRequest);
			return resp1;
		} finally
		{
			perfLogger.endLog(logName);
			perfLogger.endAllLogs();
		}				
	}

	private Callable<NPPTransactionDetail> getNPPTransactionDetail(final TransactionDetailsReq req, final IBankCommonData ibankCommonData) {
		Callable<NPPTransactionDetail> getNPPTransactionDetail = new Callable<NPPTransactionDetail>() {
			public NPPTransactionDetail call() throws Exception {
				NPPTransactionDetail nppTranDetails = null;
				boolean isNPPInwardSwitchOn = ibankRefreshParams.isNPPInwardSwitchON(ibankCommonData.getOrigin(), ibankCommonData.getUser().getGCISNumber());
				boolean isNPPOutwardSwitchOn = ibankRefreshParams.isNPPOutwardSwitchON(ibankCommonData.getOrigin(), ibankCommonData.getUser().getGCISNumber());
				if (null != req && !StringMethods.isEmptyString(req.getpRPaymentId()) && !StringMethods.isEmptyString(req.getNppTranType())) {
					Logger.debug("Callable TransactionDetailsReq: PRPaymentId : " + req.getpRPaymentId()+", nppTranType : " + req.getNppTranType()+", isDebit : " + req.isDebit(), this.getClass());
					boolean isErrorResponse = false;
					boolean isDebit = true;
					if (null == req.isDebit() || req.isDebit() == false) {
						isDebit = false;
					}
					try {
						if (isNPPInwardSwitchOn && (NPPUtil.isOriginalInwardTransaction(req.getNppTranType(), isDebit) || NPPUtil.isReturnOfInwardTransaction(req.getNppTranType(), isDebit))) {
							nppTranDetails = nppTransactionService.getInwardNPPTransactionDetail(req.getpRPaymentId(), req.getNppTranType(), isDebit, ibankCommonData);
							isErrorResponse = validateNPPTransactionDetails(req, nppTranDetails, isDebit,isErrorResponse);
							nppTranDetails.setEffectiveDate(req.getTransDate());
							if(NPPUtil.isOriginalInwardTransaction(req.getNppTranType(), isDebit)) {
							nppTranDetails.setShowReportAbusiveLink(accountInfoHelper.isReportInappropriateEligible(nppTranDetails));
							}
						
						} else if (((NPPUtil.isOriginalOutwardTransaction(req.getNppTranType(), isDebit)) || (NPPUtil.isReturnOfOutwardTransaction(req.getNppTranType(), isDebit))
								|| (NPPUtil.isReversalOfOutwardTransaction(req.getNppTranType(), isDebit)))
								&& isNPPOutwardSwitchOn) {
							nppTranDetails = nppTransactionService.getOutwardNPPTransactionDetail(
									req.getpRPaymentId(), req.getNppTranType(), isDebit, ibankCommonData);
							isErrorResponse = validateNPPTransactionDetails(req, nppTranDetails, isDebit,
									isErrorResponse);
						}
					} catch (Exception ex) {
						Logger.error("Callable Error while making NPP details WDP call for Customer GCIS: ["+ibankCommonData.getCustomer().getGcis()+"]", ex, this.getClass());
						isErrorResponse = true;
					} finally {
						nppTranDetails.setErrorResponse(isErrorResponse);
					}

				}
				return nppTranDetails;
			}
		};
		return getNPPTransactionDetail;
	}

	private Callable<MerchantTransactionInfo> getLWCDetails(final TransactionDetailsReq req, final IBankCommonData ibankCommonData) {
		Callable<MerchantTransactionInfo> getLWCDetails = new Callable<MerchantTransactionInfo>() {
			public MerchantTransactionInfo call() throws Exception {
				if(!StringMethods.isEmptyString(req.getLwcDesc())) {
					Logger.info("LWC - Parallel call START", this.getClass());
					MerchantTransactionInfo resp = merchantTransactionInfoService.retrieveLWCDetails(ibankCommonData, req.getLwcDesc());	        		
					Logger.info("LWC - Parallel call END", this.getClass());	        		
			        return resp;
				}
				return null;
			}
		};
		return getLWCDetails;
	}

	private boolean validateNPPTransactionDetails(
			final TransactionDetailsReq req,
			NPPTransactionDetail nppTransactionDetails, boolean isDebit,
			boolean isErrorResponse) {
		if (!accountInfoHelper.isValidNPPTransactionDetails(nppTransactionDetails,req.getNppTranType(),isDebit)) {
			isErrorResponse = true;
		}
		return isErrorResponse;
	}

	/*private boolean isOptTransactionDetailswitchOFF(
			String optimizationCategorySwitch) {
		return IBankParams.OFF.equals(optimizationCategorySwitch)|| ZERO.equals(optimizationCategorySwitch);
	}
	
	private BigDecimal getSumOfAmountSpentOnCateory(TransactionDetailsReq req, MobileSession mbSession, IBankCommonData commonData, String optimizationSwitch) {
		Map<Integer,Date> monthsList = null;
		BigDecimal totalCatAmount;
		try {
			int myAcctIndex = req.getAccountIndex();
			Customer customer = mbSession.getCustomer();
			Date fromDate = null;
			Account selectedAcct = mbAppHelper.getAccountFromCustomer(customer,
					myAcctIndex);

			TranCategorisationDetailVO tranCategorisationDetail = null;
			if(null == req.getTranCategoryId() || isOptTransactionDetailswitchOFF(optimizationSwitch)) {
				return null;
			} 
			int optSwitchValue = getOptimizationTransactionDetailValue(optimizationSwitch);
			int reqMonths =  optSwitchValue - 1;
			if (selectedAcct != null) {
				monthsList = categorisationService.getCategorisationMonths(commonData, selectedAcct);
				TransactionHistory trxnHist = null;
				if (monthsList != null && monthsList.size() > 0) {
					DateFormat DATE_FORMATTER = new SimpleDateFormat("yyyyMM");
					boolean inRange = isTransactionWithinReqRange(req, reqMonths);
					if(!inRange)
						return null;
					if (req.getTranDate() != null) {
						fromDate = monthsList.get(Integer.parseInt(DATE_FORMATTER.format(req.getTranDate()).toString()));
					}
					if (fromDate != null) {
						// Only for CRA and DDA AppId
						if (Account.CRA.equalsIgnoreCase(selectedAcct.getAccountId().getApplicationId())
								|| Account.DDA.equalsIgnoreCase(selectedAcct.getAccountId().getApplicationId())) {
							trxnHist = getTransactionHistory(mbSession,
									commonData, fromDate, selectedAcct);

						} else {
							Logger.info("Transaction Categoriation is available only for CRA and DDA accounts. Selected account is : "+ selectedAcct.getAccountId().getApplicationId() , this.getClass());
						}

						if (trxnHist != null && trxnHist.getTransactions() != null && trxnHist.getTransactions().size() > 0) {
							tranCategorisationDetail = categorisationService.getCategoryDetail(trxnHist.getTransactions(), selectedAcct
											.getAccountId().getApplicationId());
							totalCatAmount = calculateTotalCategoryAmount(tranCategorisationDetail,req.getTranCategoryId(), req.isDebit());
							return totalCatAmount;
						} else {
							trxnHist = null;// If there are no transactions
											// also, empty object is coming. So,
											// making trxnHist = null, to avoid
											// populating history response.
						}
					} else {
						Logger.warn("Invalid Month.", this.getClass());
								
					}
				}
			}
		}catch (Exception ex) {
			Logger.warn("Exception in getSumOfAmountSpentOnCateory " + ex, this.getClass());	
		}
		return null;
	}

	private int getOptimizationTransactionDetailValue(String optimizationSwitch) {
		int optSwitchValue = Integer.parseInt(optimizationSwitch);
		if(optSwitchValue > 12) {
			optSwitchValue  = 12;
		}
		return optSwitchValue;
	}

	private TransactionHistory getTransactionHistory(MobileSession mbSession,
			IBankCommonData commonData, Date fromDate, Account selectedAcct)
			throws BusinessException {
		TransactionHistory trxnHist;
		TranHistoryByMonth tranHistoryByMonth = tranCategorisationHelper.getTranHistForMonthFromSession(fromDate, mbSession);

		if (tranHistoryByMonth == null) {
			trxnHist = categorisationService.getTranHistoryForCategorisation(selectedAcct.getAccountId(),commonData, fromDate);
			tranCategorisationHelper.updateTransactionHistoryInSession(null,fromDate, trxnHist, mbSession);
		}

		else {
			if ("F".equalsIgnoreCase(tranHistoryByMonth.getStatus())) {
				Logger.debug("Using Session data ...", this.getClass());
				trxnHist = tranHistoryByMonth.getTransactionHistory();
			} else {
				trxnHist = categorisationService.getTranHistoryForCategorisation(selectedAcct.getAccountId(),commonData, fromDate);
				tranCategorisationHelper.updateTransactionHistoryInSession(tranHistoryByMonth, fromDate,trxnHist, mbSession);
			}
		}
		return trxnHist;
	}

	private boolean isTransactionWithinReqRange(TransactionDetailsReq req, int reqMonths) {
		Calendar startDate = Calendar.getInstance();
		startDate = resetDateTime(startDate);
		startDate.add(Calendar.MONTH, -reqMonths);
		
		if (req.getTranDate() != null) {
			Calendar selectedDate = Calendar.getInstance();
			selectedDate.setTime(req.getTranDate());
			selectedDate = resetDateTime(selectedDate);
			if(startDate.after(selectedDate)) {
				return false;
			}
		}
		return true;
	}

	public Calendar resetDateTime(Calendar calendar){
		calendar.set(Calendar.DATE, 1);
		calendar.set(Calendar.HOUR_OF_DAY, 0);
		calendar.set(Calendar.MINUTE, 0);
		calendar.set(Calendar.SECOND, 0);
		calendar.set(Calendar.MILLISECOND, 0);
		return calendar;
	}
	
	private BigDecimal calculateTotalCategoryAmount(TranCategorisationDetailVO tranCategorisationDetail, String categoryId, Boolean isDebit) {
		TranCategoryList categoryList = null;
		
		if(tranCategorisationDetail.getDebit() != null && isDebit){
			
			if(categoryList == null){
				categoryList = new TranCategoryList();
			}
			TranCategorisationInfoVO infoVO = tranCategorisationDetail.getDebit();
			
			if(infoVO.getTranCategories() != null && infoVO.getTranCategories().size() > 0 ){
				Iterator it = infoVO.getTranCategories().iterator();
				while(it.hasNext()){
					TranCategoryVO eachTransactionInfo=(TranCategoryVO)it.next();
					if(eachTransactionInfo.getId().equals(categoryId)) {
						return eachTransactionInfo.getAmount();
					}
				}
			}	
		}
		
		if(tranCategorisationDetail.getCredit() != null && !isDebit){
			
			if(categoryList == null){
				categoryList = new TranCategoryList();
			}
			TranCategorisationInfoVO infoVO = tranCategorisationDetail.getCredit();
			
			if(infoVO.getTranCategories() != null && infoVO.getTranCategories().size() > 0 ){
				Iterator it = infoVO.getTranCategories().iterator();
				while(it.hasNext()){
					TranCategoryVO eachTransactionInfo=(TranCategoryVO)it.next();
					if(eachTransactionInfo.getId().equals(categoryId)) {
						return eachTransactionInfo.getAmount();
					}
					
				}
			}	
		}
		return null;
	}*/

	/**
	 * To make GDW For GoogleSearch in Transaction Cross sell page
	 * 
	 * @param httpRequest
	 * @param request
	 * @return
	 */
	@RequestMapping(method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE, value = "tnxSearchGDW")
	@ResponseBody
	public IMBResp makeGDWForGoogleSearch(HttpServletRequest httpRequest, @RequestBody final EmptyReq request) {
		Logger.debug("AccountInfoController - makeGDWForGoogleSearch(). Request: " + request, this.getClass());
		
		ObjectMapper objectMapper = new ObjectMapper();	
		perfLogger.startAllLogs();
		String logName = MBAppUtils.getLogName(httpRequest);
		perfLogger.startLog(logName);

		MobileSession mobileSession = new MobileSessionImpl();
		try {
			mobileSession.getSessionContext(httpRequest);
			IBankCommonData commonData = new MBAppHelper().populateIBankCommonData(mobileSession, httpRequest);

			validateRequestHeader(request.getHeader(), httpRequest);
			mobileSession.getSessionContext(httpRequest);
			commonData.setCustomer(mobileSession.getCustomer());
			ErrorResp errorResp = validate(request, httpRequest);// validate json
			if (errorResp != null && errorResp.getErrors() != null && errorResp.getErrors().size() > 0)
				return errorResp;
			
				try{
					tranCategorisationService.processGDWEntryForGoogleSearch(commonData);
				}
				catch(Exception e){
					Logger.error(" Unable to create statistics entry in makeGDWForGoogleSearch(). ", this.getClass());
				}
			
			SuccessResp successResp = new SuccessResp();																			
			RespHeader headerResp = populateResponseHeader(request.getHeader().getServiceName(), mobileSession);
			successResp.setHeader(headerResp);
			successResp.setIsSuccess(true);
			
			Logger.info("makeGDWForGoogleSearch Info JSON Response :" + objectMapper.writeValueAsString(successResp), this.getClass());

			return successResp;

		} catch (BusinessException e) {
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), e, ServiceConstants.TRANS_CROSSELL_GOOGLE_GDW, httpRequest);
		} catch (ResourceException e) {
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.SYSTEM_UNAVILABLE, ServiceConstants.TRANS_CROSSELL_GOOGLE_GDW,
					httpRequest);
		} catch (Exception e) {
			Logger.error("Exception AccountInfoController - makeGDWForGoogleSearch(): GCIS: ["
					+ ((mobileSession != null && mobileSession.getCustomer() != null) ? mobileSession.getCustomer().getGcis() : "") + "] :", e, this
					.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), ResourceException.MOBILE_NON_FINANCIAL_FATAL_ERR,
					ServiceConstants.TRANS_CROSSELL_GOOGLE_GDW, httpRequest);
		} finally {
			perfLogger.endLog(logName);
			perfLogger.endAllLogs();
		}

	}
	
	private void setLoanIncreaseFlag(IBankCommonData commonData, Account acctDetail) throws BusinessException {
		//REMOVED UNNECESSARY CALL TO BACKEND ***********************
		//AccountDetails acctountDetails = accountService.getAccountDetails(new AccountId[] { acctDetail.getAccountId() }, commonData)[0];
		new HomeLoanService().processHLIMobile(acctDetail, commonData);
		if (acctDetail instanceof LoanAccount) {
			((LoanAccount) acctDetail).setDispLoanIncreaseLink(((LoanAccount) acctDetail).getDispLoanIncreaseLink());
		} else if (acctDetail instanceof DdaAccount) {
			((DdaAccount) acctDetail).setDispLoanIncreaseLink(((DdaAccount) acctDetail).getDispLoanIncreaseLink());
		}
	}
	//19E1 CI - Removing increase transaction history CI item
	//private void updateTranHistoryDetailsInSession(Account account , TransactionHistory trxnHist, String histPeriod, MobileSession mbSession, IBankCommonData commonData, boolean isFirstRequest, boolean isRespCameFromExtendHist, Calendar toDate)
	private void updateTranHistoryDetailsInSession(Account account , TransactionHistory trxnHist, String histPeriod, MobileSession mbSession, IBankCommonData commonData, boolean isMaxTranReached)
	{

		try
		{
			perfLogger.startLog("TranInSession");
			
//			if ( Account.CRA.equalsIgnoreCase(account.getAccountId().getApplicationId() ) && CatStatusEnum.ON.getCatSwtichValue() == categorisationService.getTnxCategorisationSwitchFlag(mbSession.getOrigin(), mbSession.getCustomer().getGcis(), true) && account.getAllowFlags().contains(AccountFlags.ALLOW_TNX_CATEGORISATION) )
			if ( categorisationService.isEligibleForCategorisation(account,commonData) )
			{
	
				mbSession.setTransHistFlag("Y");
				//19E1 CI - Removing increase transaction history CI item
				//Date[] dates = formTrnHistDateList(histPeriod, toDate, isFirstRequest, isRespCameFromExtendHist); 
				Date[] dates = formTrnHistDateList(histPeriod);
	
				Logger.debug("Dates for time period. From : " + dates[0] + "  To "+ dates[1], this.getClass());
				HashMap<String,LabelValueVO> tranHistMonthSessionList = null;
				Collection<TranHistoryByMonth> tranHistByMonth = null;
				
				tranHistMonthSessionList = mbSession.getTranHistoryMonthListStatus();
				
				
				//19E1 CI - Removing increase transaction history CI item
				if ( "30".equalsIgnoreCase(histPeriod ) )
				{
					if ( tranHistMonthSessionList != null )
					{
						tranHistMonthSessionList.clear();
						tranHistByMonth.clear();
					}
				}
	
				Integer tranCatedays = IBankParams.CATEGORISATION_DEFAULT_DAYS;
				
				try{
					tranCatedays = IBankParams.getCategorisationDaysFromCodes(commonData.getOrigin(), account.getAccountId().getApplicationId(),commonData.getCustomer().getGcis());
				} catch (Exception e) {
					Logger.error("unable to get TranCategoryDefViewDays from IBankParams" , e , this.getClass());
					tranCatedays = 180;
				}
				
				HashMap<String, LabelValueVO> tranHistMonthListStatus = getListOfMonths(  dates[0], dates[1] , tranCatedays);
				//boolean isMaxReached = isMaxTranHistoryReached(trxnHist,commonData);
				
				
				if(isMaxTranReached) {
					tranHistMonthListStatus = removeMonthsFromMonthList(trxnHist,	tranHistMonthListStatus);
					
				}
				if(tranHistMonthListStatus != null && tranHistMonthListStatus.size() > 0) {
					if(tranHistMonthSessionList != null && tranHistMonthSessionList.size() > 0){
						tranHistMonthSessionList.putAll(tranHistMonthListStatus);
						mbSession.setTranHistoryMonthListStatus(tranHistMonthSessionList);
					}else {
						mbSession.setTranHistoryMonthListStatus(tranHistMonthListStatus);
					}
				}
				
				//TODO Remove just for testing 
				Map<String, LabelValueVO> monthStatusList = mbSession.getTranHistoryMonthListStatus();
				Logger.info("Transaction monthList from session ", this.getClass());
				if(null != monthStatusList)
					for(String monthKey : monthStatusList.keySet()) {
						Logger.debug("Months "  + monthKey + " "+  monthStatusList.get(monthKey).getLabel() + "  "+ monthStatusList.get(monthKey).getValue() , this.getClass());
					}
			}
		}
		catch ( Exception e)
		{
			Logger.error("Exception in updateTranHistoryDetailsInSession() " , e , this.getClass());
		}
		finally
		{
			perfLogger.endLog("TranInSession");
		}

	}

	private HashMap<String, LabelValueVO> removeMonthsFromMonthList(TransactionHistory trxnHist,
			HashMap<String, LabelValueVO> tranHistMonthSessionList) {
		if(trxnHist != null && null !=trxnHist.getTransactions()) {
			try {
				HashMap<String, LabelValueVO> tempMap  = (HashMap<String, LabelValueVO>)tranHistMonthSessionList.clone();
				String pattern = "dd/MM/yyyy";
				TransactionInfo transactionInfo = trxnHist.getTransactions().get(trxnHist.getTransactions().size()-1);	
				String tranDate = transactionInfo.getFormattedDate();
				Date lastTranDate = new SimpleDateFormat(pattern).parse(tranDate);
				String lastMMYYYY = new SimpleDateFormat(DATE_MMYYYY).format(lastTranDate);;
				LabelValueVO monthStatusVO = tranHistMonthSessionList.get(lastMMYYYY);
				monthStatusVO.setValue("P");
				
				tranHistMonthSessionList.put(lastMMYYYY, monthStatusVO);
				Iterator<String> iterator = tranHistMonthSessionList.keySet().iterator();
				while ( iterator.hasNext() )
				{
					
		 			String mmYYYY = iterator.next();
		 			
		 			String monthStringDate = "01".concat(mmYYYY);
					
					Date monthDate=new SimpleDateFormat("ddMMyyyy").parse(monthStringDate);
					
					if(monthDate.before(lastTranDate)) {
						tempMap.remove(mmYYYY);
					}
					
				}
				tranHistMonthSessionList = (HashMap<String, LabelValueVO>)tempMap.clone();
			}catch(Exception ex) {
				Logger.debug("Error while date formatting in tranHistMonthSessionList" +  ex.getMessage(), this.getClass());
			}
			return tranHistMonthSessionList;
		}
		return tranHistMonthSessionList;
	}	
	
	private boolean isMaxTranHistoryReached(TransactionHistory trxnHist,IBankCommonData commonData) {
		if(trxnHist != null && null !=trxnHist.getTransactions())
			if(Integer.parseInt(IBankParams.getExtendTranHistMaxTransaction(commonData.getOrigin())) <= trxnHist.getTransactions().size())
				return true;
		return false;
	}

	//19E1 CI - Removing increase transaction history CI item
	//private Date[] formTrnHistDateList(String period, Calendar toDateUI, boolean isFirstRequest, boolean isRespCameFromExtendHist)  {
	private Date[] formTrnHistDateList(String period)  {
		// we will be getting the last 30 days txn
		Calendar fromCalendar = Calendar.getInstance();
		fromCalendar.setTime(new Date());

		
		Calendar toCalendar = Calendar.getInstance();
		toCalendar.setTime(new Date());
		
		Date toDate = null;
		Date fromDate =null;

		if(period.equalsIgnoreCase(MobileBankServiceImpl.TXN_PERIOD_30)){
			
			fromCalendar.add(Calendar.DAY_OF_MONTH, -30);
			fromDate = fromCalendar.getTime();
			toDate   = toCalendar.getTime();
			
		}else if(period.equalsIgnoreCase(MobileBankServiceImpl.TXN_PERIOD_60)){
			
			fromCalendar.add(Calendar.DAY_OF_MONTH, -90);
			fromDate = fromCalendar.getTime();
			toCalendar.add(Calendar.DAY_OF_MONTH, -31);
			toDate = toCalendar.getTime();
			
		}
		//19E1 CI - Removing increase transaction history CI item
		/*
		else if(period.equalsIgnoreCase(MobileBankServiceImpl.TXN_PERIOD_90)){ 
			if (isRespCameFromExtendHist){
				if (isFirstRequest){
					toDate = toCalendar.getTime();
					fromCalendar.add(Calendar.DAY_OF_MONTH, -90);
					fromDate = fromCalendar.getTime();
				}else{
					if(toDateUI == null) {
						toDate   = toCalendar.getTime();
						fromCalendar.add(Calendar.DAY_OF_MONTH, -90);
						fromDate = fromCalendar.getTime();
					} else {
						Date toDateTemp = toDateUI.getTime();
						toDate = DateUtils.addDays(toDateTemp,-1);
						fromDate = DateUtils.addDays(toDateTemp,-90);
					}	
				}
			}
		}*/
		else if(period.equalsIgnoreCase(MobileBankServiceImpl.ALL_TXN)){
			
			fromCalendar.set(Calendar.YEAR, 1950) ;
			fromCalendar.set(Calendar.MONTH, 01) ;

			fromCalendar.set(Calendar.DAY_OF_MONTH, 01) ;
			
			fromDate =  fromCalendar.getTime();
			//19E1 CI - Removing increase transaction history CI item
			/*
			if (isRespCameFromExtendHist && toDateUI != null){
				Date toDateTemp = toDateUI.getTime();
				toDate = DateUtils.addDays(toDateTemp,-1);
			}else{
				toCalendar.add(Calendar.DAY_OF_MONTH, -91);
				toDate = toCalendar.getTime();
			}
			*/
			toCalendar.add(Calendar.DAY_OF_MONTH, -91);
			toDate = toCalendar.getTime();
		}else if(period.equalsIgnoreCase(MobileBankServiceImpl.TXN_PERIOD_14)){
			fromCalendar.add(Calendar.DAY_OF_MONTH, -14);
			fromDate = fromCalendar.getTime();
			toDate   = toCalendar.getTime();
		}
		Date[] dtList = new Date[2];
		dtList[0] =  fromDate;
		dtList[1] =  toDate;
		return dtList;
		
	}  

    private static final String DATE_MMYYYY = "MMyyyy";
    private static final String DATE_DDMMYYYY = "ddMMyyyy";
    private static final String DATE_01 = "01";

    private  HashMap<String, LabelValueVO> getListOfMonths( Date fromDate, Date toDate , Integer tranCatedays)
    {
		Date fromDateStart = fromDate ;
		HashMap<String, LabelValueVO> hashMonths = new HashMap<String, LabelValueVO> ();  
		boolean isFirst = true;
		
	//-120days
		Calendar categoryCalendar = Calendar.getInstance();
		categoryCalendar.add(Calendar.DAY_OF_MONTH, -tranCatedays);
		
		
		Logger.debug(" Months : fromDateStart " +fromDateStart +  " toDate " + toDate +  " categoryCalendar " + categoryCalendar.getTime() , this.getClass());
		
		if ( fromDateStart.getTime() < categoryCalendar.getTime().getTime() )
		{
			fromDateStart = categoryCalendar.getTime();
			Logger.debug("After. Months : fromDateStart " +fromDateStart +  " toDate " + toDate +  " categoryCalendar " + categoryCalendar.getTime() , this.getClass());
		}

		while ( fromDateStart.getTime() < toDate.getTime()  )
		{
			Calendar tempCalendar = Calendar.getInstance();
			tempCalendar.setTime(fromDateStart);
			String tempDate = null;
			String status = null;
			String label = new SimpleDateFormat(DATE_MMYYYY).format(fromDateStart);
			if ( isFirst )
			{
				tempDate =  new SimpleDateFormat(DATE_DDMMYYYY).format(fromDateStart);
				String tempFullDate =DATE_01+ new SimpleDateFormat(DATE_MMYYYY).format(fromDateStart);
				if ( tempDate.equalsIgnoreCase(tempFullDate))
				{
					status = "F";
				}
				else
				{
					status = "P";
				}
				isFirst = false;
			}
			else
			{
				 tempDate =DATE_01+ new SimpleDateFormat(DATE_MMYYYY).format(fromDateStart);
				  status = "F";
			}
			LabelValueVO subLabelValueVO = new LabelValueVO(tempDate, status);
 			Logger.debug("Months " +label + "  "+  subLabelValueVO.getLabel() + "  "+ status , this.getClass());
    				
			hashMonths.put(label ,  subLabelValueVO );
			
			tempCalendar.add( Calendar.MONTH, 1);
			tempCalendar.set(Calendar.DAY_OF_MONTH, 01);
			fromDateStart = tempCalendar.getTime();
		}
		
		return hashMonths;
    }

	private Collection<TranHistoryByMonth> setTranHistForMonthInSession(String parammmYYYY,MobileSession mbSession,  TransactionHistory trxnHist, LabelValueVO labelValueVO , Collection<TranHistoryByMonth> tranHistByMonth )
	{
		
	//	Collection<TranHistoryByMonth> tranHistByMonth = mbSession.getTranHistoryByMonthList();
		
		Logger.debug("setTranHistForMonthInSession. Month Key : " + parammmYYYY + " From date : " + labelValueVO.getLabel() + "  Status :" + labelValueVO.getValue() , this.getClass());
		
		if ( tranHistByMonth == null )
		{
			tranHistByMonth = new ArrayList<TranHistoryByMonth> ();
	//		mbSession.setTranHistoryByMonthList(tranHistByMonth);
		}  
		
		boolean isFound = false;
		if ( tranHistByMonth != null & tranHistByMonth.size() > 0 )
		{
			Iterator iterator =tranHistByMonth.iterator();
			
			while (iterator.hasNext() )
			{
				TranHistoryByMonth tranHistoryByMonth = (TranHistoryByMonth) iterator.next();
				if ( parammmYYYY.equalsIgnoreCase(tranHistoryByMonth.getMonthYYYY() ) && "F".equalsIgnoreCase(tranHistoryByMonth.getStatus())   )
				{
					isFound = true;
					//return tranHistoryByMonth;
					Logger.debug("Already In Session. Month Key : " + parammmYYYY + " From date : " + labelValueVO.getLabel() + "  Status :" + labelValueVO.getValue() , this.getClass());

					break;
				}
				else if ( parammmYYYY.equalsIgnoreCase(tranHistoryByMonth.getMonthYYYY() ) && "P".equalsIgnoreCase(tranHistoryByMonth.getStatus())   )
				{
//					history.getTransactions().addAll(history.getTransactions().size(), trxnHist.getTransactions());
					tranHistoryByMonth = filterTransactionHistoryForMonth(parammmYYYY, trxnHist , tranHistoryByMonth );
					Date tempDate = DateMethods.getUtilDateTime(labelValueVO.getLabel(), DATE_DDMMYYYY);
					tranHistoryByMonth.setFromDate(tempDate);
					tranHistoryByMonth.setStatus(labelValueVO.getValue());
					isFound = true;
					Logger.debug("Partially In Session. Month Key : " + parammmYYYY + " From date : " + labelValueVO.getLabel() + "  Status :" + labelValueVO.getValue() , this.getClass());
					break;
					//return tranHistoryByMonth;
				}
			}
		}

		if ( ! isFound )
		{
			Logger.debug("Adding New entry in Session. Month Key : " + parammmYYYY + " From date : " + labelValueVO.getLabel() + "  Status :" + labelValueVO.getValue() , this.getClass());
			TranHistoryByMonth tranHistoryByMonth = new TranHistoryByMonth();
			tranHistoryByMonth.setMonthYYYY(parammmYYYY);
			Date tempDate = DateMethods.getUtilDateTime(labelValueVO.getLabel(), DATE_DDMMYYYY);
			tranHistoryByMonth.setFromDate(tempDate);
			tranHistoryByMonth.setStatus(labelValueVO.getValue());
			 TransactionHistory transactionHistory = new AccountingTransactionHistory();
			tranHistoryByMonth.setTransactionHistory(transactionHistory);
			tranHistoryByMonth = filterTransactionHistoryForMonth(parammmYYYY, trxnHist , tranHistoryByMonth );
			tranHistByMonth.add(tranHistoryByMonth);
		//	mbSession.setTranHistoryByMonthList(tranHistByMonth);
		}
		
		return tranHistByMonth;
		
	}
	
	
	private TranHistoryByMonth filterTransactionHistoryForMonth(String parammmYYYY, TransactionHistory trxnHist , TranHistoryByMonth tranHistoryByMonth )
	{
		
		if(trxnHist != null && trxnHist.getTransactions() != null && trxnHist.getTransactions().size() > 0){
			
			List<TransactionInfo> transaction = trxnHist.getTransactions();
			
			if (transaction != null && transaction.size() > 0  )
			{
				Iterator iterator = transaction.iterator();
				while ( iterator.hasNext())
				{
					TransactionInfo transactionInfo = ( TransactionInfo ) iterator.next();
					String tranDate = new SimpleDateFormat(DATE_MMYYYY).format(transactionInfo.getDate());
					if ( parammmYYYY.equalsIgnoreCase(tranDate))
					{
						if ( tranHistoryByMonth.getTransactionHistory().getTransactions() == null )
						{
							List<TransactionInfo> tempTransaction  = new ArrayList();  
							tranHistoryByMonth.getTransactionHistory().setTransactions(tempTransaction);
						}
						tranHistoryByMonth.getTransactionHistory().getTransactions().add(transactionInfo);
					}
				}
			}
			
			List<TransactionInfo> crTransaction = trxnHist.getCreditTransactions();
			
			if (crTransaction != null && crTransaction.size() > 0  )
			{
				Iterator iterator = crTransaction.iterator();
				while ( iterator.hasNext())
				{
					TransactionInfo transactionInfo = ( TransactionInfo ) iterator.next();
					String tranDate = new SimpleDateFormat(DATE_MMYYYY).format(transactionInfo.getDate());
					if ( parammmYYYY.equalsIgnoreCase(tranDate))
					{
						if ( tranHistoryByMonth.getTransactionHistory().getCreditTransactions() == null )
						{
							List<TransactionInfo> tempTransaction  = new ArrayList();  
							tranHistoryByMonth.getTransactionHistory().setCreditTransactions(tempTransaction);
						}
						tranHistoryByMonth.getTransactionHistory().getCreditTransactions().add(transactionInfo);
					}
				}
			}
	
			List<TransactionInfo> drTransaction = trxnHist.getDebitTransactions();
			
			if (drTransaction != null && drTransaction.size() > 0  )
			{
				Iterator iterator = drTransaction.iterator();
				while ( iterator.hasNext())
				{
					TransactionInfo transactionInfo = ( TransactionInfo ) iterator.next();
					String tranDate = new SimpleDateFormat(DATE_MMYYYY).format(transactionInfo.getDate());
					if ( parammmYYYY.equalsIgnoreCase(tranDate))
					{
						if ( tranHistoryByMonth.getTransactionHistory().getDebitTransactions() == null )
						{
							List<TransactionInfo> tempTransaction  = new ArrayList();  
							tranHistoryByMonth.getTransactionHistory().setDebitTransactions(tempTransaction);
						}
						Logger.debug("Adding Transaction History . " + transactionInfo.getDescription1() + " Amount " +transactionInfo.getAmount() + " Merchant. " +  transactionInfo.getMerchantCategoryCode() +  " Catg. " +  transactionInfo.getCategoryCode()  + "  Sub Catg. :" + transactionInfo.getTranSubCategory() , this.getClass());
						tranHistoryByMonth.getTransactionHistory().getDebitTransactions().add(transactionInfo);
					}
				}
			}
			
		}
		return tranHistoryByMonth;
	
	}
	

	@RequestMapping(method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE, value = "uitxnsearchgdw")
	@ResponseBody
	public IMBResp makeGDWForUiTxnHistorySearch(HttpServletRequest httpRequest, @RequestBody final TxnHistorySearchReq request) {
		Logger.debug("AccountInfoController - makeGDWForUiTxnHistorySearch(). Request: " + request, this.getClass());
		
		ObjectMapper objectMapper = new ObjectMapper();	
		perfLogger.startAllLogs();
		String logName = MBAppUtils.getLogName(httpRequest);
		perfLogger.startLog(logName);

		MobileSession mobileSession = new MobileSessionImpl();
		try {
			mobileSession.getSessionContext(httpRequest);
			IBankCommonData commonData = new MBAppHelper().populateIBankCommonData(mobileSession, httpRequest);

			validateRequestHeader(request.getHeader(), httpRequest);
			mobileSession.getSessionContext(httpRequest);
			commonData.setCustomer(mobileSession.getCustomer());
			ErrorResp errorResp = validateAsync(request, httpRequest);// validate json
			
			if (errorResp != null && errorResp.getErrors() != null && errorResp.getErrors().size() > 0)
				return errorResp;
			
			
				try{
					int myAcctIndex = request.getAccountIndex();
					Customer customer=mobileSession.getCustomer();			
					Account selectedAcct=mbAppHelper.getAccountFromCustomer(customer, myAcctIndex);
					mobileBankService.processGDWEntryForUiTxnHistorySearch(commonData, selectedAcct.getAccountId(), request.getSearchStr());
					
				}
				catch(Exception e){
					Logger.error(" Unable to create statistics entry in makeGDWForGoogleSearch(). ", this.getClass());
				}
			
			SuccessResp successResp = new SuccessResp();																			
			//RespHeader headerResp = populateResponseHeader(request.getHeader().getServiceName(), mobileSession);
			RespHeader headerResp  = populateAsyncResponseHeader(request.getHeader().getServiceName(), mobileSession);
			successResp.setHeader(headerResp);
			successResp.setIsSuccess(true);
			
			Logger.info("makeGDWForUiTxnHistorySearch Info JSON Response :" + objectMapper.writeValueAsString(successResp), this.getClass());

			return successResp;

		} catch (BusinessException e) {
			return MBAppUtils.createErrorRespAsync(mobileSession.getOrigin(), e, ServiceConstants.UI_TRANS_HISTORY_SEARCH_GDW, httpRequest);
		} catch (ResourceException e) {
			return MBAppUtils.createErrorRespAsync(mobileSession.getOrigin(), new ResourceException(BusinessException.SYSTEM_UNAVILABLE), ServiceConstants.UI_TRANS_HISTORY_SEARCH_GDW,
					httpRequest);
		} catch (Exception e) {
			Logger.error("Exception AccountInfoController - makeGDWForUiTxnHistorySearch(): GCIS: ["
					+ ((mobileSession != null && mobileSession.getCustomer() != null) ? mobileSession.getCustomer().getGcis() : "") + "] :", e, this
					.getClass());
			return MBAppUtils.createErrorRespAsync(mobileSession.getOrigin(), new BusinessException(ResourceException.MOBILE_NON_FINANCIAL_FATAL_ERR),
					ServiceConstants.UI_TRANS_HISTORY_SEARCH_GDW, httpRequest);
		} finally {
			perfLogger.endLog(logName);
			perfLogger.endAllLogs();
		}

	}
	
	@RequestMapping(method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE, value = "sharebsbgdwdigiseclog")
	@ResponseBody
	public IMBResp makeGDWDigitalSecLogShareBsbAccNum(HttpServletRequest httpRequest, @RequestBody final ShareBsbAccNumReq request) {
		Logger.debug("AccountInfoController - makeGDWDigitalSecLogShareBsbAccNum(). Request: " + request, this.getClass());
		
		ObjectMapper objectMapper = new ObjectMapper();	
		perfLogger.startAllLogs();
		String logName = MBAppUtils.getLogName(httpRequest);
		perfLogger.startLog(logName);
		MobileSession mobileSession = new MobileSessionImpl();
		
		try {
			mobileSession.getSessionContext(httpRequest);
			IBankCommonData commonData = new MBAppHelper().populateIBankCommonData(mobileSession, httpRequest);
			validateRequestHeader(request.getHeader(), httpRequest);
			mobileSession.getSessionContext(httpRequest);
			commonData.setCustomer(mobileSession.getCustomer());
			ErrorResp errorResp = validate(request, httpRequest);// validate json
			
			if (errorResp != null && errorResp.getErrors() != null && errorResp.getErrors().size() > 0)
				return errorResp;

			
			
				try{
					int myAcctIndex = request.getAccountIndex();
					Customer customer=mobileSession.getCustomer();			
					Account selectedAcct=mbAppHelper.getAccountFromCustomer(customer, myAcctIndex);
					String accountNumber = selectedAcct.getAccountId().getAccountNumber();
					//Digital Security Logging 
					DigitalSecLogggerVO digitalSecLoggerVO = new DigitalSecLogggerVO();
					digitalSecLoggerVO.setTranName(DigitalSecLogger.SHARE_BSB_ACCT_NUM);
					digitalSecLoggerVO.setStatus(DigitalSecLogger.SUCCESS);
					digitalSecLoggerVO.setCommonLogData(mbAppHelper.getCommonLogData(commonData));
					digitalSecLoggerVO.setUserAgent(commonData.getUserAgent());
					StringBuffer sb = new StringBuffer();
					sb.append(DigitalSecLogger.BSB).append(DigitalSecLogger.DELIMITER_COLON).append(selectedAcct.getAccountId().getBsb()).append(DigitalSecLogger.DELIMITER_COMMA)
			        .append(DigitalSecLogger.ACCOUNT_NUMBER).append(DigitalSecLogger.DELIMITER_COLON).append(accountNumber);
					digitalSecLoggerVO.setValues(sb.toString());
					digitalSecLogger.log(digitalSecLoggerVO);
					//GDW Entry 
					mobileBankService.processGDWEntryForShareBsbAcctNum(commonData, selectedAcct.getAccountId(), request.getShareType());
					
				}
				catch(Exception e){
					Logger.error(" Unable to create statistics entry in makeGDWDigitalSecLogShareBsbAccNum(). ", this.getClass());
				}
			
			SuccessResp successResp = new SuccessResp();																			
			RespHeader headerResp  = populateAsyncResponseHeader(request.getHeader().getServiceName(), mobileSession);
			successResp.setHeader(headerResp);
			successResp.setIsSuccess(true);
			
			Logger.info("makeGDWDigitalSecLogShareBsbAccNum Info JSON Response :" + objectMapper.writeValueAsString(successResp), this.getClass());

			return successResp;

		} catch (BusinessException e) {
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), e, ServiceConstants.SHARE_BSB_ACCOUNT_NUMBER, httpRequest);
		} catch (ResourceException e) {
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.SYSTEM_UNAVILABLE, ServiceConstants.SHARE_BSB_ACCOUNT_NUMBER,
					httpRequest);
		} catch (Exception e) {
			Logger.error("Exception AccountInfoController - makeGDWDigitalSecLogShareBsbAccNum(): GCIS: ["
					+ ((mobileSession != null && mobileSession.getCustomer() != null) ? mobileSession.getCustomer().getGcis() : "") + "] :", e, this
					.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), ResourceException.MOBILE_NON_FINANCIAL_FATAL_ERR,
					ServiceConstants.SHARE_BSB_ACCOUNT_NUMBER, httpRequest);
		} finally {
			perfLogger.endLog(logName);
			perfLogger.endAllLogs();
		}

	}

	/**
	 * This method will retrieve account details on click of GCC account.  
	 * 
	 * @param httpServletRequest
	 * @param httpServletResponse
	 * @param req
	 * @return IMBResp
	 */
	@RequestMapping(value= "globalWalletInfo" , method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public IMBResp getGlobalWalletAcctInfo(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, @RequestBody final AccountInfoReq req)
	{		
	
		ObjectMapper objectMapper = new ObjectMapper();				

		IMBResp serviceResponse = new GlobalWalletAccountInfoResp();
		
		perfLogger.startAllLogs();
		String logName = MBAppUtils.getLogName(httpServletRequest);
		perfLogger.startLog(logName);
		
		fraudLogger = new FraudLogger();
		MobileSession mbSession = null;
		
		try{	

			Logger.info("getGCCAcctInfo JSON Request :" + objectMapper.writeValueAsString(req), this.getClass());
			
			mbSession = mbAppHelper.getMobileSession(httpServletRequest);			
		
			validateRequestHeader(req.getHeader(), httpServletRequest);
			ErrorResp errorResp = validate(req, httpServletRequest);
			
			if (errorResp != null && errorResp.getErrors() != null && errorResp.getErrors().size() > 0)
			{				
				return errorResp;
			}
			
			if(null!=mbSession.getServiceStationAccountDetailMessage())
			{
				mbSession.removeServiceStationAccountDetailsMessage();
			}
																			
			int myAcctIndex = req.getAccountIndex();
			Customer customer=mbSession.getCustomer();			
						
			GCCAccount globalWalletAccount = (GCCAccount) mbAppHelper.getAccountFromCustomer(customer, myAcctIndex);
		
			IBankCommonData commonData=null;
			
			if(globalWalletAccount!=null){
				commonData=mbAppHelper.populateIBankCommonData(mbSession,httpServletRequest);
				GlobalWallet globalWallet = globalWalletService.getGlobalWalletWithAccountNumber(globalWalletAccount.getAccountId().getAccountKey(),globalWalletAccount.getAccountId().getBsb().trim());
				
				if(null != globalWallet && null != globalWallet.getCardholderId()){
					Logger.debug("globalWallet Details  CardHolder Id :" + globalWallet.getCardholderId() + " AccountNumber: " + globalWallet.getAccountNumber(), this.getClass());					
					GlobalWalletDetails globalWalletDtls = globalWalletService.getGlobalWalletDetails(globalWallet, commonData, UUID.randomUUID());
					
					mbSession.setGlobalWalletDetails(globalWalletDtls);
					
					mbSession.setFetchGlobalWalletPendingTransactions(globalWalletDtls.getFetchGlobalWalletPendingTransactions());
					//Populate the Global Wallet account details in response
					serviceResponse = accountInfoHelper.populateGlobalWalletAcctDetailsResp(mbSession,globalWalletAccount,globalWalletDtls);
				}	
				
				//SBGEXP-8137 - GDW entry
				globalWalletService.processGDWForGlobalWallet(commonData, globalWalletAccount, Statistic.ACCOUNT_INQUIRY);	
			}
			
			RespHeader responseHeader = populateResponseHeader(ServiceConstants.GLOBAL_WALLET_ACCOUNT_INFO_SERVICE, mbSession);
			serviceResponse.setHeader(responseHeader);
			
			Logger.info("getGCCAcctInfo JSON Response :" + objectMapper.writeValueAsString(serviceResponse), this.getClass());
			
			return serviceResponse;
			
		}catch (BusinessException e) {	
			Logger.error("BusinessException Inside getGlobalWalletAcctInfo() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "]", e, this.getClass());
			if(e.getKey() == BusinessException.GLOBAL_WALLET_ACCOUNT_CLOSED) {
				try{
					accountInfoHelper.refreshAccountList(req.getAccountIndex(), mbSession);
					serviceResponse =  populateGlobalWalletAcctClosedResp(mbSession, MBAppUtils.getMessage(IBankParams.getBaseOriginCode(mbSession.getOrigin()), e.getKey()));
					RespHeader responseHeader = populateResponseHeader(ServiceConstants.GLOBAL_WALLET_ACCOUNT_INFO_SERVICE, mbSession);
					serviceResponse.setHeader(responseHeader);
					
					return serviceResponse;
				}catch(Exception expAccount) {			
					Logger.error("Exception Inside getGlobalWalletAcctInfo() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "]", expAccount, this.getClass());
					BusinessException exp = new BusinessException(BusinessException.GLOBAL_WALLET_API_ERROR);
					IMBResp resp1  = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, ServiceConstants.GLOBAL_WALLET_ACCOUNT_INFO_SERVICE, httpServletRequest);
					return resp1;
				}
			}
			if(e.getKey() != BusinessException.GLOBAL_WALLET_ACCOUNT_CLOSED && e.getKey() != BusinessException.GLOBAL_WALLET_API_ERROR)
				e = new BusinessException(BusinessException.GLOBAL_WALLET_API_ERROR);
			
			IMBResp resp1  = MBAppUtils.createErrorResp(mbSession.getOrigin() ,e, ServiceConstants.GLOBAL_WALLET_ACCOUNT_INFO_SERVICE, httpServletRequest);
			return resp1;
			
		}catch (ResourceException e) {
			Logger.error("ResourceException Inside getGlobalWalletAcctInfo() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "]", e, this.getClass());			
			ResourceException exp = new ResourceException(BusinessException.GLOBAL_WALLET_API_ERROR);
			IMBResp resp1  = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, ServiceConstants.GLOBAL_WALLET_ACCOUNT_INFO_SERVICE, httpServletRequest);
			return resp1;
			
		}catch (Exception e) {			
			Logger.error("Exception Inside getGlobalWalletAcctInfo() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "]", e, this.getClass());
			BusinessException exp = new BusinessException(BusinessException.GLOBAL_WALLET_API_ERROR);
			IMBResp resp1  = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, ServiceConstants.GLOBAL_WALLET_ACCOUNT_INFO_SERVICE, httpServletRequest);
			return resp1;
		} finally {
			perfLogger.endLog(logName);
			perfLogger.endAllLogs();
		}	
	}
    
	/**
	 * Response for invalid body request 
	 * 
	 * @return
	 */
	@ExceptionHandler({org.springframework.http.converter.HttpMessageNotReadableException.class})
	@ResponseStatus(org.springframework.http.HttpStatus.OK)
	@ResponseBody
	public IMBResp resolveException() {		
		return MBAppUtils.createInvalidMessageBodyResponse(ServiceConstants.ACCOUNT_INFO_SERVICE);
	}
	
	public ErrorResp validate(IMBReq serviceRequest, HttpServletRequest request) {
		return mbAppValidator.validate(serviceRequest, request);
	}
	
	public void validateRequestHeader(ReqHeader header, HttpServletRequest request) throws ResourceException
	{	
		mbAppValidator.validateRequestHeader(header,  request);	
	}
	
	public RespHeader populateResponseHeader(String ServiceName)
	{		
		return mbAppHelper.populateResponseHeader(ServiceName);
	}			
	
	public RespHeader populateResponseHeader(String serviceName, MobileSession mobSession )
	{
		return mbAppHelper.populateResponseHeader(serviceName, mobSession);
	}

	public RespHeader populateAsyncResponseHeader(String serviceName, MobileSession mobSession )
	{
		return mbAppHelper.populateAsyncResponseHeader(serviceName, mobSession);
	}
	
	/**
	 * This method will set the response when the account is closed
	 * 
	 * @param mbSession
	 * @return GCCAccountInfoResp
	 */
	public GlobalWalletAccountInfoResp populateGlobalWalletAcctClosedResp(MobileSession mbSession, String errorMessage) {
		
		GlobalWalletAccountInfoResp response = new GlobalWalletAccountInfoResp();
		response.setAccountClosed(errorMessage);
		ArrayList<au.com.stgeorge.mbank.model.common.AccountResp> accountList = logonHelper.populateAccountList(mbSession.getCustomer(),mbSession.getAutoApplyRetentionInfo());
		response.setAccounts(accountList);		
		
		return response;
	}
	
	private Cookie getCookie(HttpServletRequest request, String cookieName) throws ResourceException
	{

		Cookie[] cookies = request.getCookies();
		Cookie cookie = null;
		if (cookies != null)
		{
			for (int i = 0; i < cookies.length; i++)
			{
				if (cookies[i].getName().equals(cookieName))
				{
						cookie = cookies[i]; 
						Logger.info("Cookie " + cookieName + " found in the request. Value : " + cookie.getValue() , this.getClass());
					  break;
				}
			}
		}
		return cookie;
	}

	/**
	 * SBGEXP-8092 - Fix issue of name id getting generated for async error response
	 *  
	 * @param serviceRequest
	 * @param httpRequest
	 * @return ErrorResp
	 * @throws BusinessException
	 */	
	public ErrorResp validateAsync(IMBReq serviceRequest, HttpServletRequest httpRequest) throws BusinessException {
		return  mbAppValidator.validateAsync(serviceRequest, httpRequest);
	}	
	
}
