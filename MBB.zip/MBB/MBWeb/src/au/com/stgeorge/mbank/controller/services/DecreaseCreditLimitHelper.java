/**
 * 
 */
package au.com.stgeorge.mbank.controller.services;

import java.util.ArrayList;
import java.util.List;

import au.com.stgeorge.framework.common.logging.Logger;
import au.com.stgeorge.ibank.businessobject.BusinessException;
import au.com.stgeorge.ibank.valueobject.Account;
import au.com.stgeorge.ibank.valueobject.CCDecreaseLimit;
import au.com.stgeorge.ibank.valueobject.CreditCardAccount;
import au.com.stgeorge.mbank.model.response.services.DecreaseCreditLimitCardListResp;
import au.com.stgeorge.mbank.model.response.services.DecreaseCreditLimitCardResp;
import au.com.stgeorge.mbank.util.MBAppHelper;

/**
 * @author c50216
 *
 */
public class DecreaseCreditLimitHelper {

	protected DecreaseCreditLimitCardListResp populateCardsResp(List<CCDecreaseLimit> cardList){
		
		DecreaseCreditLimitCardListResp resp = new DecreaseCreditLimitCardListResp();		
		List<DecreaseCreditLimitCardResp> cardListResp = new ArrayList<DecreaseCreditLimitCardResp>(); 
		
		for(CCDecreaseLimit ccDecreaseLimitVO : cardList){
			
			DecreaseCreditLimitCardResp cardResp = new DecreaseCreditLimitCardResp();
			cardResp.setIndex(ccDecreaseLimitVO.getIndex());
			cardResp.setCurrentLimit(ccDecreaseLimitVO.getCurrentLimit());
			cardResp.setMinLimit(ccDecreaseLimitVO.getMinLimit());
			Account acct = ccDecreaseLimitVO.getAccount();			
			cardResp.setAccountNumDisp(new MBAppHelper().getFormattedAcctNumber(acct.getAccountId().getAccountNumber(), acct.getAccountId()
					.getApplicationId(), acct.getAccountId().getBsb()));			
			cardResp.setAccountName(acct.getAlias());							
		
			cardListResp.add(cardResp);				
		}		
		
		resp.setCardList(cardListResp);
		
		return resp;
	}
	
	protected CreditCardAccount getDecreaseCreditAccountFromIndex(int index, List<CCDecreaseLimit> cardList) throws BusinessException{
				
		CCDecreaseLimit ccDecreaseLimitVO = null;
		CreditCardAccount selectedCCaccount = null;	
		for(CCDecreaseLimit obj: cardList){
			if(index == obj.getIndex()){
				ccDecreaseLimitVO = obj;
				if(ccDecreaseLimitVO != null){
				selectedCCaccount = (CreditCardAccount)ccDecreaseLimitVO.getAccount();
				}
				break;
			}
		}
				
		if(ccDecreaseLimitVO == null || selectedCCaccount == null){
			Logger.info("Error: Could not find CCDecreaseLimit from the session List", this.getClass());
			throw new BusinessException(BusinessException.GENERIC_ERROR);
		}
		
		return selectedCCaccount;		
	}
	
	protected List<CCDecreaseLimit> populateUpdatedCardList(List<CCDecreaseLimit> cardList, int reqIndex, String newLimit){
		
		//Since using reference is not recommended to update the mewLimit in session. This method is created to populate updated list. 
		List<CCDecreaseLimit> list = new ArrayList<CCDecreaseLimit>();
		
		for(CCDecreaseLimit ccDecreaseLimitVO : cardList){
			
			CCDecreaseLimit newVo = new CCDecreaseLimit();
			
			newVo.setAccount(ccDecreaseLimitVO.getAccount());
			newVo.setIndex(ccDecreaseLimitVO.getIndex());
			
			if(reqIndex == ccDecreaseLimitVO.getIndex()){
				newVo.setCurrentLimit(newLimit);
			}
			else{
				newVo.setCurrentLimit(ccDecreaseLimitVO.getCurrentLimit());
			}
			
			list.add(newVo);			
		}		
		return list;
	}
	
}
