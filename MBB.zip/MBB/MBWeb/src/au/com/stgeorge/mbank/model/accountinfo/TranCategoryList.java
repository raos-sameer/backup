package au.com.stgeorge.mbank.model.accountinfo;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_NULL)
public class TranCategoryList {

	private TranCategory credit;
	private TranCategory debit;
	public TranCategory getCredit() {
		return credit;
	}
	public void setCredit(TranCategory credit) {
		this.credit = credit;
	}
	public TranCategory getDebit() {
		return debit;
	}
	public void setDebit(TranCategory debit) {
		this.debit = debit;
	}

	
}
