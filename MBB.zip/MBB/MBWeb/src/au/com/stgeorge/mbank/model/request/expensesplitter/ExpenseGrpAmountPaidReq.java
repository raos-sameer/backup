package au.com.stgeorge.mbank.model.request.expensesplitter;


import java.util.List;

import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.NotEmpty;

import au.com.stgeorge.ibank.businessobject.BusinessException;
import au.com.stgeorge.mbank.model.common.IMBReq;
import au.com.stgeorge.mbank.model.common.ReqHeader;
import org.hibernate.validator.constraints.Length;



public class ExpenseGrpAmountPaidReq implements IMBReq {


	/**
	 * 
	 */
	private static final long serialVersionUID = -1363915820028562508L;
	/**
	 * 
	 */
	protected static final String AMT_PATTERN = "^[0-9]*\\.{0,1}(\\d{1,2}){0,1}$";
	protected static final String BLOCK_CHARS_PATTERN = "^[0-9A-Za-z',. &/\\-]*$";
	protected static final String MASK_NUMBERS = "^[0-9]+$";

	private ReqHeader header;
	
	@NotEmpty(message = "{error.customer.credential.invalid}")
	@Pattern(regexp = MASK_NUMBERS, message = "" + BusinessException.WSVC_INVALID_INPUT_PARAM)
	private String expGrpID;
	
	@Length(max = 14, message = "{errors.amt.maxlength}")
	@Pattern(regexp = AMT_PATTERN, message = "{errors.amt.blockchar}")
	private String totalAmt;
	
	private List<ExpenseReq> expenseList;

	public ReqHeader getHeader() {
		return header;
	}

	public void setHeader(ReqHeader header) {
		this.header = header;
	}

	private List<ContactReq> contactList;
	
	
	public List<ContactReq> getContactList() {
		return contactList;
	}

	public void setContactList(List<ContactReq> contactList) {
		this.contactList = contactList;
	}

	
	public String getExpGrpID() {
		return expGrpID;
	}

	public void setExpGrpID(String expGrpID) {
		this.expGrpID = expGrpID;
	}

	public String getTotalAmt() {
		return totalAmt;
	}

	public void setTotalAmt(String totalAmt) {
		this.totalAmt = totalAmt;
	}

	public List<ExpenseReq> getExpenseList() {
		return expenseList;
	}

	public void setExpenseList(List<ExpenseReq> expenseList) {
		this.expenseList = expenseList;
	}

	


	
		
	
}
