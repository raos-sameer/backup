package au.com.stgeorge.mbank.model.accountinfo;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

/**
 * 
 * @author C38854
 * 
 */
@JsonInclude(Include.NON_NULL)
public class HomeLoanIncreaseResp {

	private String appDestination;
	private String linkURL;
	private Boolean isExisting;

	public Boolean getIsExisting() {
		return isExisting;
	}

	public void setIsExisting(Boolean isExisting) {
		this.isExisting = isExisting;
	}

	public String getAppDestination() {
		return appDestination;
	}

	public void setAppDestination(String appDestination) {
		this.appDestination = appDestination;
	}

	public String getLinkURL() {
		return linkURL;
	}

	public void setLinkURL(String linkURL) {
		this.linkURL = linkURL;
	}
}
