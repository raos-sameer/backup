package au.com.stgeorge.mbank.controller;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.AbstractController;

import au.com.stgeorge.framework.common.logging.Logger;
import au.com.stgeorge.ibank.businessobject.SystemInformation;
import au.com.stgeorge.ibank.common.cache.IBankParams;
import au.com.stgeorge.ibank.util.ServiceHelper;
import au.com.stgeorge.ibank.valueobject.database.CodesVO;
import au.com.stgeorge.ibank.valueobject.database.OriginsVO;
import au.com.stgeorge.mbank.controller.customer.LogonHelper;
import au.com.stgeorge.mbank.util.GDPRWebHelper;
import au.com.stgeorge.mbank.util.MBAppUtils;
import au.com.stgeorge.perflogger.PerformanceLogger;
import au.com.stgeorge.security.util.StringMethods;

public class PwdResetMainController extends AbstractController{
	
	public static final String PAGE_NAME = "PwdReset";
	private static final String ERROR_VIEW = "404";
	private static volatile int numberOfRequests = 0;
	
	public static final String NUM_KEYBOARD_TYPE = "NumKeyBoardType";
	public static final String NUM_KEYBOARD_PATTERN_TYPE = "NumKeyBoardTypePattern";	
	public static final String SYS_VERSION = "SysVersion";
	public static final String ORIGIN_NAME = "OriginName";
	public static final String HELP_DESK_NO = "HelpDeskNo";
	public static final  String DATA_ROLE = "DataRole";
	public static final  String ACTION_TYPE = "actionType";
	public static final  String CAN = "CANRetrieval";
	public static final String PWD = "PwdReset";
	public static final String DATA_SERVICES_AVAILABILITY = "ServicesAvailability";
	public static final String TAGGING_SWITCH = "TaggingSwitch";
	public static final String WEB_CONTEXT = "WebContext";
	@Override
	protected ModelAndView handleRequestInternal(HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		
		PerformanceLogger performanceLogger = new PerformanceLogger();
		performanceLogger.startAllLogs();
		String logName = MBAppUtils.getLogName(request);
		performanceLogger.startLog(logName);
		
		ModelAndView model = null;
		String origin = null;
		String numKeyType = null;
		String numKeyTypePattern = null;
		String dataRole =null;
		
		try{
			numberOfRequests ++;
			
			origin = logonHelper.resolveOrigin(request);
			Logger.debug("Checking for native", getClass());
			logonHelper.loadCordova(request);
			
			if ( StringMethods.isEmptyString(origin) )
			{
				origin = "MSTG";
				request.setAttribute(LogonHelper.ORIGIN, origin);
				Logger.info("Unable to resolve the origin for pwd reset Request Details. URL : "+ request.getRequestURL() + " IP :" + request.getRemoteAddr() + " Number Of Requests : "+ numberOfRequests +
						" True IP >> " + request.getHeader(IBankParams.trueClientIP()), this.getClass());
				model = new ModelAndView(ERROR_VIEW);
			}
			else{
				String taggingSwitch = "ON";
				CodesVO codesVO = IBankParams.getCodesData(origin,	IBankParams.CONFIGURATION_PROPERTIES, TAGGING_SWITCH);
				if ( (codesVO == null) || (codesVO != null  && "OFF".equalsIgnoreCase(codesVO.getMessage()))){
					taggingSwitch = "OFF";
				}
				request.setAttribute(TAGGING_SWITCH, taggingSwitch);
				
				CodesVO codesVo = IBankParams.getCodesData( IBankParams.DEFAULT_ORIGIN,IBankParams.CONFIGURATION_PROPERTIES, IBankParams.CAN_PWD_SECURITY_SWITCH);
				if(codesVo != null && codesVo.getMessage() != null && codesVo.getMessage().equalsIgnoreCase(IBankParams.ON)){
					request.setAttribute(DATA_SERVICES_AVAILABILITY, IBankParams.ON);
				}else{
					request.setAttribute(DATA_SERVICES_AVAILABILITY, IBankParams.OFF);
				}
				request.setAttribute(LogonHelper.ORIGIN, origin);
				numKeyType =  logonHelper.getNumKeyBoardType(request);
				numKeyTypePattern =  logonHelper.getNumKeyBoardPattern(request);
				request.setAttribute(NUM_KEYBOARD_TYPE, numKeyType);
				request.setAttribute(NUM_KEYBOARD_PATTERN_TYPE, numKeyTypePattern);
				
				dataRole=request.getParameter(ACTION_TYPE);
				Logger.info("The value for data role is  "+dataRole, this.getClass());
				if(dataRole != null){
					if(dataRole.contains(PWD)){					
						request.setAttribute(DATA_ROLE, PWD);
					}else{
						request.setAttribute(DATA_ROLE, CAN);
					}
				}
				else{
					request.setAttribute(DATA_ROLE,CAN);
				}
				request.setAttribute(PwdResetMainController.WEB_CONTEXT, logonHelper.getMBWebResourceContext());
				if ( this.systemInformation == null )
				{
					Logger.info("************ Loading systemInformation for Pwd reset*************** "+ request.getRequestURL()   , this.getClass());
					this.systemInformation = getSystemInformationDtls();
				}
				request.setAttribute(SYS_VERSION, this.systemInformation.getMB3PackageVersion());
				OriginsVO originVO = IBankParams.getOrigin(origin);
				request.setAttribute(ORIGIN_NAME, originVO.getName());	
				request.setAttribute(HELP_DESK_NO, originVO.getPhone());
				gdprWebHelper.gdpr(origin, request, response);
				Logger.debug("Loading Pwd reset page ... " + request.getRequestURL() + " IP :" + request.getRemoteAddr() +
						" True IP >> " + request.getHeader(IBankParams.trueClientIP()), this.getClass());
				model = new ModelAndView(PAGE_NAME);
			}
			return model;
		}
		
		catch ( Exception e)
		{
			origin = "MSTG";
			request.setAttribute(LogonHelper.ORIGIN, origin);
			model = new ModelAndView(ERROR_VIEW);
			Logger.error("Error in Main Controller " , e, this.getClass());
			return model;
		}
		finally
		{
			numberOfRequests--;
			performanceLogger.endLog(logName);
			performanceLogger.endAllLogs();
		}		


	}
	
	private SystemInformation getSystemInformationDtls()
	{
		SystemInformation systemInformation = (SystemInformation) ServiceHelper.getBean("systemInformation");
		return systemInformation;

	}	
	
	@Autowired
	private LogonHelper logonHelper;

	@Autowired
	private GDPRWebHelper gdprWebHelper;	

	@Autowired
	private SystemInformation systemInformation;	
	
	
}
