package au.com.stgeorge.mbank.model.request.mortgage;

import java.io.Serializable;

import au.com.stgeorge.mbank.model.common.IMBReq;
import au.com.stgeorge.mbank.model.common.ReqHeader;

public class SubmitReq implements IMBReq, Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = -2334701650351329202L;
	private ReqHeader header;
	private String segmentName;


	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	public ReqHeader getHeader() {
		return header;
	}

	public void setHeader(ReqHeader header) {
		this.header = header;
	}
	
	public String getSegmentName()
	{
		return segmentName;
	}

	public void setSegmentName(String segmentName)
	{
		this.segmentName = segmentName;
	}

}
