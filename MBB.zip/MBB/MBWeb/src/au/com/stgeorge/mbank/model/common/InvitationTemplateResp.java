package au.com.stgeorge.mbank.model.common;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_NULL)
public class InvitationTemplateResp implements Serializable {

	private static final long serialVersionUID = -7023725564882460464L;

	private String prodName;
	private String invitationText;
	private String invitationTerms;
	private String landingPageText;
	private String landingPageTerms;
	
	public String getProdName() {
		return prodName;
	}
	public void setProdName(String prodName) {
		this.prodName = prodName;
	}
	public String getInvitationText() {
		return invitationText;
	}
	public void setInvitationText(String invitationText) {
		this.invitationText = invitationText;
	}
	public String getInvitationTerms() {
		return invitationTerms;
	}
	public void setInvitationTerms(String invitationTerms) {
		this.invitationTerms = invitationTerms;
	}
	public String getLandingPageText() {
		return landingPageText;
	}
	public void setLandingPageText(String landingPageText) {
		this.landingPageText = landingPageText;
	}
	public String getLandingPageTerms() {
		return landingPageTerms;
	}
	public void setLandingPageTerms(String landingPageTerms) {
		this.landingPageTerms = landingPageTerms;
	}
	
	
}
