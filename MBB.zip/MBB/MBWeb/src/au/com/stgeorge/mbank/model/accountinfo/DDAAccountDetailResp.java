/**
 * 
 */
package au.com.stgeorge.mbank.model.accountinfo;

import au.com.stgeorge.mbank.model.common.AccountKeyInfoResp;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
/**
 * @author C50216
 *
 */

@JsonInclude(Include.NON_NULL)
public class DDAAccountDetailResp{

	//final list	
	private String standardInterestRate;
	private String bonusRate;
	private InterestRateDetailResp interestRateDetail;
	private OverdraftDetailResp overdraft;
	private InterestAmtDetailResp interestCharged;  
	private InterestAmtDetailResp interestEarned;
	private AccountKeyInfoResp linkedAccount;
	private String savingsTargetAmt;
	private HomeLoanIncreaseResp homeLoanIncreaseResp;
	private boolean isGetCashEligible;
		
	public boolean isGetCashEligible() {
		return isGetCashEligible;
	}
	public void setGetCashEligible(boolean isGetCashEligible) {
		this.isGetCashEligible = isGetCashEligible;
	}
	public HomeLoanIncreaseResp getHomeLoanIncrease() {
		return homeLoanIncreaseResp;
	}
	public void setHomeLoanIncreaseResp(HomeLoanIncreaseResp homeLoanIncreaseResp) {
		this.homeLoanIncreaseResp = homeLoanIncreaseResp;
	}
			
	public String getStandardInterestRate() {
		return standardInterestRate;
	}
	public void setStandardInterestRate(String standardInterestRate) {
		this.standardInterestRate = standardInterestRate;
	}
	public String getBonusRate() {
		return bonusRate;
	}
	public void setBonusRate(String bonusRate) {
		this.bonusRate = bonusRate;
	}
	
	public InterestRateDetailResp getInterestRateDetail() {
		return interestRateDetail;
	}
	public void setInterestRateDetail(InterestRateDetailResp interestRateDetail) {
		this.interestRateDetail = interestRateDetail;
	}
	public OverdraftDetailResp getOverdraft() {
		return overdraft;
	}
	public void setOverdraft(OverdraftDetailResp overdraft) {
		this.overdraft = overdraft;
	}
	public InterestAmtDetailResp getInterestCharged() {
		return interestCharged;
	}
	public void setInterestCharged(InterestAmtDetailResp interestCharged) {
		this.interestCharged = interestCharged;
	}
	public InterestAmtDetailResp getInterestEarned() {
		return interestEarned;
	}
	public void setInterestEarned(InterestAmtDetailResp interestEarned) {
		this.interestEarned = interestEarned;
	}
	public AccountKeyInfoResp getLinkedAccount() {
		return linkedAccount;
	}
	public void setLinkedAccount(AccountKeyInfoResp linkedAccount) {
		this.linkedAccount = linkedAccount;
	}
	public String getSavingsTargetAmt() {
		return savingsTargetAmt;
	}
	public void setSavingsTargetAmt(String savingsTargetAmt) {
		this.savingsTargetAmt = savingsTargetAmt;
	}	
				
}
