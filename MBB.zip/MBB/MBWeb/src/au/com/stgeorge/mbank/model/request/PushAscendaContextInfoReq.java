package au.com.stgeorge.mbank.model.request;

import au.com.stgeorge.mbank.model.common.IMBReq;
import au.com.stgeorge.mbank.model.common.ReqHeader;

public class PushAscendaContextInfoReq implements IMBReq{

	private static final long serialVersionUID = -4263462927851878958L;
	private ReqHeader header;
	
	private String idToken;
	private String ppId;
	private String launchPoint;
	
	public String getLaunchPoint() {
		return launchPoint;
	}

	public void setLaunchPoint(String launchPoint) {
		this.launchPoint = launchPoint;
	}

	@Override
	public ReqHeader getHeader() {
		return header;
	}

	@Override
	public void setHeader(ReqHeader header) {
		this.header = header;		
	}

	public String getIdToken() {
		return idToken;
	}

	public void setIdToken(String idToken) {
		this.idToken = idToken;
	}

	public String getPpId() {
		return ppId;
	}

	public void setPpId(String ppId) {
		this.ppId = ppId;
	}
	
}
