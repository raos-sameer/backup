package au.com.stgeorge.mbank.controller.payments;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.builder.ReflectionToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;

import au.com.stgeorge.digitalsec.logger.DigitalSecLogger;
import au.com.stgeorge.digitalsec.logger.DigitalSecLogggerVO;
import au.com.stgeorge.framework.common.logging.Logger;
import au.com.stgeorge.framework.common.util.StringMethods;
import au.com.stgeorge.ibank.businessobject.BusinessException;
import au.com.stgeorge.ibank.businessobject.DuplicateException;
import au.com.stgeorge.ibank.businessobject.HeartBeat;
import au.com.stgeorge.ibank.businessobject.IBankSecureService;
import au.com.stgeorge.ibank.businessobject.MemoryThrottlingService;
import au.com.stgeorge.ibank.businessobject.ResourceException;
import au.com.stgeorge.ibank.businessobject.TTService;
import au.com.stgeorge.ibank.businessobject.assembler.CustomerVOAssembler;
import au.com.stgeorge.ibank.common.cache.IBankParams;
import au.com.stgeorge.ibank.common.cache.IBankRefershParams;
import au.com.stgeorge.ibank.safi.util.SafiConstants;
import au.com.stgeorge.ibank.safi.util.SafiUtil;
import au.com.stgeorge.ibank.safi.valueobject.SafiPayTranVO;
import au.com.stgeorge.ibank.service.valueobject.SafiRespVO;
import au.com.stgeorge.ibank.util.CommonBusinessUtil;
import au.com.stgeorge.ibank.util.StringUtil;
import au.com.stgeorge.ibank.valueobject.Account;
import au.com.stgeorge.ibank.valueobject.ContactDetail;
import au.com.stgeorge.ibank.valueobject.Currency;
import au.com.stgeorge.ibank.valueobject.Customer;
import au.com.stgeorge.ibank.valueobject.OverseasTTBeneficiary;
import au.com.stgeorge.ibank.valueobject.PhoneNumber;
import au.com.stgeorge.ibank.valueobject.Receipt;
import au.com.stgeorge.ibank.valueobject.TTDuplicateVO;
import au.com.stgeorge.ibank.valueobject.TTPurposeCode;
import au.com.stgeorge.ibank.valueobject.TelegraphicTransfer;
import au.com.stgeorge.ibank.valueobject.collection.LabelValueMap;
import au.com.stgeorge.ibank.valueobject.database.CodesVO;
import au.com.stgeorge.ibank.valueobject.database.OriginsVO;
import au.com.stgeorge.ibank.valueobject.transfer.IBankCommonData;
import au.com.stgeorge.mbank.controller.IMBController;
import au.com.stgeorge.mbank.controller.SafiWebHelper;
import au.com.stgeorge.mbank.controller.SecureCodeHelper;
import au.com.stgeorge.mbank.controller.customer.LogonHelper;
import au.com.stgeorge.mbank.model.common.IMBReq;
import au.com.stgeorge.mbank.model.common.IMBResp;
import au.com.stgeorge.mbank.model.common.ReqHeader;
import au.com.stgeorge.mbank.model.common.RespHeader;
import au.com.stgeorge.mbank.model.request.EmptyReq;
import au.com.stgeorge.mbank.model.request.SecureCodeReq;
import au.com.stgeorge.mbank.model.request.payments.TTCountryCurrencyReq;
import au.com.stgeorge.mbank.model.request.payments.TTGetFeeDetailReq;
import au.com.stgeorge.mbank.model.request.payments.TTTransferReq;
import au.com.stgeorge.mbank.model.response.ErrorResp;
import au.com.stgeorge.mbank.model.response.SuccessResp;
import au.com.stgeorge.mbank.model.response.payments.TransferResp;
import au.com.stgeorge.mbank.session.MobileSession;
import au.com.stgeorge.mbank.session.MobileSessionImpl;
import au.com.stgeorge.mbank.util.MBAppHelper;
import au.com.stgeorge.mbank.util.MBAppUtils;
import au.com.stgeorge.mbank.util.MBAppValidator;
import au.com.stgeorge.mbank.util.ServiceConstants;
import au.com.stgeorge.mobilebank.businessobject.OverseasTransService;
import au.com.stgeorge.mobilebank.businessobject.TransactService;
import au.com.stgeorge.perflogger.PerformanceLogger;

/**
 * Overseas Telegraphic Transfer Rest Service
 * 
 * @author C38854
 * 
 */
@Controller
@RequestMapping("/tt")
public class TTController implements IMBController {

	@Autowired
	private TTService ttService;

	@Autowired
	private TransactService transactService;

	@Autowired
	private OverseasTransService overseasTransService;

	@Autowired
	private SecureCodeHelper secureCodeHelper;

	@Autowired
	private TTHelper ttHelper;
	
	@Autowired
	private MBAppValidator mbAppValidator;
	
	@Autowired
	private MBAppHelper mbAppHelper;
	
    @Autowired
    private DigitalSecLogger digitalSecLogger;

    @Autowired
	private LogonHelper logonHelper;
    
	@Autowired
	private MemoryThrottlingService memoryThrottlingService;
    
	@Autowired
	IBankRefershParams ibankRefreshParams;
	
	/**
	 * TT transfer service operation
	 * 
	 * @param httpRequest
	 * @param request
	 * @return
	 */
	@RequestMapping(method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE, value = "transfer")
	@ResponseBody
	public IMBResp transfer(HttpServletRequest httpRequest,HttpServletResponse httpServletResponse, @RequestBody final TTTransferReq request) {
		Logger.debug("TTController - transfer(). Request: " + request, this.getClass());
		String logName = startPerformanceLog(httpRequest);
		MobileSession mobileSession = new MobileSessionImpl();
		String validDecodedPrint = null;
		String devicePrint = null;
		TelegraphicTransfer tt = null;
		IBankCommonData commonData = null;
		try {
			mobileSession.getSessionContext(httpRequest);
			Customer customer = mobileSession.getCustomer();
			commonData = new MBAppHelper().populateIBankCommonData(mobileSession, httpRequest);

			validateRequestHeader(request.getHeader(), httpRequest);
			ErrorResp errorResponse = validate(request, httpRequest);
			if (errorResponse.hasErrors())
				return errorResponse;

			Account fromAccount = customer.getAccounts().get(request.getFromAccountIndex());

			OverseasTTBeneficiary beneficiary = ttHelper.getBeneficiaryById(request.getToBeneficiaryId(), customer.getGcis());
			ttHelper.validateTTTransferReq(mobileSession.getOrigin(), beneficiary.getBankCountry(), request.getCurrency());
			
			tt = ttHelper.populatePayment(beneficiary, fromAccount, customer, commonData, request);
			
			// SBGEXP-3394 - SAFI switch, Throttle and Heartbeat check
			String baseOrigin = IBankParams.getBaseOriginCode(tt.getCommonData().getOrigin());
			boolean isSafiTTSwitchOn = IBankParams.isSwitchOn(baseOrigin, IBankParams.SAFI_TELEGRAPHIC_TRANSFER_SWITCH);
			Logger.info("SAFI : TTController.transfer:: Safi Logon Switch Value: "+isSafiTTSwitchOn, this.getClass());
			boolean isSafiServiceAvailable = false;
			
			if(isSafiTTSwitchOn){
				isSafiServiceAvailable = HeartBeat.isApplicationAvailable(HeartBeat.SAFI2_SERVICE_APPLICATION);
				Logger.info("SAFI : TTController.transfer:: SAFI2_SERVICE_APPLICATION STATUS: "+isSafiServiceAvailable, this.getClass());
			}
			
			if(isSafiServiceAvailable){
				
				boolean	isThrottleAllowed = memoryThrottlingService.processThrottling(IBankParams.THROTTLE_CAT_PAYMENT, customer.getGcis(), mobileSession.getSessionID());
										
				if(isThrottleAllowed){
					//18E4: Safi 
					Logger.debug("SAFI : TTController.transfer(): Device Print Received in TT Transfer Request: " +request.getDevicePrint(), this.getClass()) ;
					validDecodedPrint = SafiUtil.validateDevicePrint(request.getDevicePrint());
					devicePrint = validDecodedPrint != null ? request.getDevicePrint():null;
					boolean isMobileApp = ((logonHelper.loadCordova(httpRequest)) == -1) ? false:true;
					tt.setTtRestrictHighRiskCountriesSwitchOn(ibankRefreshParams.isTTRestrictHighRiskCountriesSwitchOn());
					SafiPayTranVO safiPayTranVO = SafiWebHelper.populateSafiPayTranVOForTT(httpRequest, tt, commonData,devicePrint,mobileSession,isMobileApp);
					tt.setSafiPayTranVO(safiPayTranVO);
					//18E4: Safi 
				}		
			}
			// SBGEXP-3394 - SAFI switch, Throttle and Heartbeat check
			
			mobileSession.setTransaction(tt);

			overseasTransService.checkDuplicate(tt);
			
			//SAFI Switch OFF Scenario
			if (check2FA(mobileSession.getCustomer(), tt)) {
				// dummy transaction
				tt.setVerify(true);
				transactService.performTransfer(tt);
				
				//Start: SAFI Switch ON Scenario
				SafiRespVO safiRespVO = tt.getSafiRespVO();
				
				if(safiRespVO != null){
					return performSafiCheck(mobileSession, tt, httpRequest, httpServletResponse, fromAccount);
				}
				//End: SAFI Switch ON Scenario
				return ttHelper.populateSecureRequiredResponse(populateResponseHeader(ServiceConstants.TT_TRANSFER_SERVICE, mobileSession), customer, mobileSession.getOrigin(), ServiceConstants.TT_TRANSFER_SERVICE, httpRequest);

			}else{
				//Start: SAFI Switch ON Scenario
				tt.setVerify(true);
				transactService.performTransfer(tt);
				SafiRespVO safiRespVO = tt.getSafiRespVO();
				
				if(safiRespVO != null){
					return performSafiCheck(mobileSession, tt, httpRequest, httpServletResponse, fromAccount);
				}
				//End: SAFI Switch ON Scenario
				
				//Start: Safi Switch OFF /Safi Timeout Scenario
				return performTransfer(mobileSession, fromAccount, tt, ServiceConstants.TT_TRANSFER_SERVICE, httpRequest,httpServletResponse, false);
				//End: Safi Switch OFF /Safi Timeout Scenario
				
			}
			
		} catch (DuplicateException e) {
			Logger.info("DuplicateException in TTController - transfer() - [key: " + e.getKey() + "] : GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());
			if (e.getKey() == BusinessException.DUPLICATE_PAYMENT) {
				return ttHelper.populateTransferResponse1(populateResponseHeader(ServiceConstants.TT_TRANSFER_SERVICE, mobileSession),
						(List<TTDuplicateVO>) ((DuplicateException) e).getDuplicatePaymentList(), mobileSession.getCustomer().getAccounts());
			}
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), e, ServiceConstants.TT_TRANSFER_SERVICE, httpRequest);

		} catch (BusinessException e) {
			Logger.info("BusinessException in TTController - transfer() - [key: " + e.getKey() + "] : GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());
			if (e.getKey() == BusinessException.DUMMY_TT_2FA_LIMIT_EXCEEDED ||
					e.getKey() == BusinessException.DUMMY_OVER_TT_DAILY_PRUD_LIMIT)
				return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.EXCEED_DAILY_LIMIT, ServiceConstants.TT_TRANSFER_SERVICE, httpRequest);
			
			if(e.getKey()==BusinessException.SAFI_PAYMENT_DENY_ERROR && ibankRefreshParams.isTTRestrictHighRiskCountriesSwitchOn()) {
				addSAFIDenyForensicLogs(mobileSession, commonData, tt);
			}
			if(e.getKey()==BusinessException.SAFI_PAYMENT_DENY_ERROR
					|| e.getKey()==BusinessException.SAFI_PAYMENT_NO_PHONE_EXIST
					|| e.getKey()==BusinessException.SAFI_PAYMENT_2FA_EXEMPT
					|| e.getKey()==BusinessException.SAFI_PAYMENT_2FA_GLOBAL_BYPASS){
				
				if(tt != null){
					createOrUpdatePMData2Cookie(httpRequest, tt.getSafiRespVO(), httpServletResponse);
				}
				OriginsVO myOriginVO = IBankParams.getOrigin(mobileSession.getOrigin());
				OriginsVO baseOrigin = IBankParams.getOrigin(myOriginVO.getBankName());
				String[] values = { baseOrigin.getBpayPhone() };
				IMBResp resp1 = MBAppUtils.createErrorResp(mobileSession.getOrigin(), e,values, ServiceConstants.TT_TRANSFER_SERVICE, httpRequest);
				return resp1;
			}
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), e, ServiceConstants.TT_TRANSFER_SERVICE, httpRequest);
		} catch (ResourceException e) {
			Logger.error("ResourceException in TTController - transfer() - [key: " + e.getKey() + "] : GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());
			mobileSession.removeTransaction();
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.SYSTEM_UNAVILABLE, ServiceConstants.TT_TRANSFER_SERVICE, httpRequest);
		} catch (Throwable e) {
			Logger.error("Exception TTController - transfer(): GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			mobileSession.removeTransaction();
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.GENERIC_ERROR, ServiceConstants.TT_TRANSFER_SERVICE, httpRequest);
		} finally {
			endPerformanceLog(logName);
		}
	}

	//18E4: Safi
	private IMBResp performSafiCheck(MobileSession mobileSession, TelegraphicTransfer tt,HttpServletRequest httpRequest,HttpServletResponse httpServletResponse,Account fromAccount)throws BusinessException{
		
			SafiRespVO safiRespVO = tt != null ? tt.getSafiRespVO():null;
			String safiAction =  safiRespVO != null ? safiRespVO.getSafiAction(): null;
			Logger.debug("SAFI : TTController.performSafiCheck(): safiRespVO not NULL. Updating PMData2 Cookie.",this.getClass());
			createOrUpdatePMData2Cookie(httpRequest,safiRespVO, httpServletResponse);

			if(!StringMethods.isEmptyString(safiAction) && safiAction.equalsIgnoreCase(SafiConstants.SAFI_ACTION_CHALLENGE)){
				Logger.debug("SAFI : TTController.performSafiCheck(): SafiAction: "+safiAction+" 2FA Required.",this.getClass());
				
				if(IBankParams.isGlobalByPass()) {
					throw new BusinessException(BusinessException.SAFI_PAYMENT_2FA_GLOBAL_BYPASS);
				} else if (IBankSecureService.isCustomerExempt(tt.getCommonData().getCustomer().getIBankSecureDetails())) {
					throw new BusinessException(BusinessException.SAFI_PAYMENT_2FA_EXEMPT);
				} else if(getRegisteredPhoneNumberCount(tt.getCommonData().getCustomer().getContactDetail()) == 0) {
					throw new BusinessException(BusinessException.SAFI_PAYMENT_NO_PHONE_EXIST);
				} 
				
				return  ttHelper.populateSecureRequiredResponse(populateResponseHeader(ServiceConstants.TT_TRANSFER_SERVICE, mobileSession), mobileSession.getCustomer(), mobileSession.getOrigin(), ServiceConstants.TT_TRANSFER_SERVICE, httpRequest);
			}else{
				Logger.debug("SAFI : TTController.performSafiCheck(): SafiAction: "+safiAction+" Processing Transfer.",this.getClass());
				return performTransfer(mobileSession, fromAccount, tt, ServiceConstants.TT_TRANSFER_SERVICE, httpRequest,httpServletResponse, false);
			}
	}
	//18E4: Safi
	/**
	 * Request security code service operation
	 * 
	 * @param request
	 * @return
	 */
	@RequestMapping(method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE, value = "reqsecurecode")
	@ResponseBody
	public IMBResp reqSecureCode(HttpServletRequest httpRequest, @RequestBody final SecureCodeReq request) {
		Logger.debug("TTController - reqSecureCode(). Request: " + request, this.getClass());
		String logName = startPerformanceLog(httpRequest);
		MobileSession mobileSession = new MobileSessionImpl();

		try {
			mobileSession.getSessionContext(httpRequest);
			mobileSession.removeDigitalSecLoggerMap();
			IBankCommonData commonData = new MBAppHelper().populateIBankCommonData(mobileSession, httpRequest);

			validateRequestHeader(request.getHeader(), httpRequest);
			ErrorResp errorResponse = validate(request, httpRequest);// validate json
			if (errorResponse.hasErrors())
				return errorResponse;

			if (ServiceConstants.OVERSEAS_TT_2FA_TRAN_CODE != request.getTranType()) {
				return MBAppUtils.createInvalid2FATransactionTypeResponse(ServiceConstants.TT_SECURE_CODE_SERVICE);
			}

			LabelValueMap digitalSecLoggerMap = new LabelValueMap(2);
			digitalSecLoggerMap.put(DigitalSecLogger.AUTHTYPE, request.getDeliveryMethod());
			PhoneNumber phoneNumber = CommonBusinessUtil.get2FAPhoneNumber(commonData, request.getPhone());
			digitalSecLoggerMap.put(DigitalSecLogger.AUTHPHONE, phoneNumber.getAreaCode()+phoneNumber.getPhoneNumber());
			mobileSession.setDigitalSecLoggerMap(digitalSecLoggerMap);
			
			return secureCodeHelper.reqSecureCode(commonData, mobileSession, mobileSession.getTransaction(), mobileSession.getBiller(), request,
					ServiceConstants.TT_SECURE_CODE_SERVICE, httpRequest);
		} catch (ResourceException e) {
			Logger.error("ResourceException in TTController - reqSecureCode() - [key: " + e.getKey() + "] : GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());
			mobileSession.removeSecureCodeDetails();
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.SYSTEM_UNAVILABLE, ServiceConstants.TT_SECURE_CODE_SERVICE, httpRequest);
		} catch (Exception e) {
			Logger.error("Exception TTController - reqSecureCode(): GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			mobileSession.removeSecureCodeDetails();
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.GENERIC_ERROR, ServiceConstants.TT_SECURE_CODE_SERVICE, httpRequest);
		} finally {
			endPerformanceLog(logName);
		}
	}

	/**
	 * Secure transfer service operation
	 * 
	 * @param request
	 * @return
	 */
	@RequestMapping(method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE, value = "transfersecure")
	@ResponseBody
	public IMBResp transferSecure(HttpServletRequest httpRequest, HttpServletResponse httpResponse,@RequestBody final SecureCodeReq request) {
		Logger.debug("TTController - transferSecure(). Request: " + request, this.getClass());
		String logName = startPerformanceLog(httpRequest);
		MobileSession mobileSession = new MobileSessionImpl();
		String safiAction = null;
		TelegraphicTransfer payment =  null;
		IBankCommonData commonData = null;
		boolean is2FADone = false;
		LabelValueMap digitalSecMap = null;
		String optDeliveryMethod = null;
		String optPhoneUsed = null;
		try {
			mobileSession.getSessionContext(httpRequest);
			commonData = new MBAppHelper().populateIBankCommonData(mobileSession, httpRequest);

			validateRequestHeader(request.getHeader(), httpRequest);
			ErrorResp errorResponse = validate(request, httpRequest);// validate json
			if (errorResponse.hasErrors())
				return errorResponse;

			if (ServiceConstants.OVERSEAS_TT_2FA_TRAN_CODE != request.getTranType())
				return MBAppUtils.createInvalid2FATransactionTypeResponse(ServiceConstants.TT_TRANSFER_SECURE_SERVICE);

			payment = (TelegraphicTransfer) mobileSession.getTransaction();
			safiAction  =  payment != null && payment.getSafiRespVO() != null ? payment.getSafiRespVO().getSafiAction(): null ;
			
			errorResponse = secureCodeHelper.verifySecureCode(commonData, mobileSession, mobileSession.getTransaction(), request,
					ServiceConstants.TT_TRANSFER_SECURE_SERVICE, httpRequest);
			if (errorResponse.hasErrors()){
				DigitalSecLogggerVO digitalSecLoggerVO =new DigitalSecLogggerVO();
		        digitalSecLoggerVO.setTranName(DigitalSecLogger.OSEAS_TRANSFER);
				digitalSecLoggerVO.setStatus(DigitalSecLogger.FAILURE_2FA);
				digitalSecLoggerVO.setCommonLogData(mbAppHelper.getCommonLogData(commonData));
				digitalSecLoggerVO.setUserAgent(commonData.getUserAgent());
				digitalSecMap = mobileSession.getDigitalSecLoggerMap();
				String purposeDescription = null;
				List<TTPurposeCode> purposeCodesList = mobileSession.getPurposeCodesList();
				if(purposeCodesList != null && !purposeCodesList.isEmpty()){
					purposeDescription = getPurposeDescription(purposeCodesList, payment);
				}
				digitalSecLoggerVO.setValues(payment.toDigitalSecurityLogWithPurposeDesc(digitalSecMap.get(DigitalSecLogger.AUTHTYPE), digitalSecMap.get(DigitalSecLogger.AUTHPHONE), purposeDescription));
				if(ibankRefreshParams.isTTRestrictHighRiskCountriesSwitchOn() && StringMethods.isEmptyString(safiAction)) { 
					digitalSecLoggerVO.setStatus(DigitalSecLogger.FAILURE_2FA_SAFI_OFFHOST);
				}
				digitalSecLoggerVO.setValues(ttService.addSafiDetailsToForensicLogs(digitalSecLoggerVO.getValues(), payment, is2FADone));
				digitalSecLogger.log(digitalSecLoggerVO);
				mobileSession.removePurposeCodesList();
				//18E4: Safi Notify TODO: Add SafiSwitch check here
				if(errorResponse.getStatus() ==  ErrorResp.STATUS_2FA_SUSPENDED  && !(StringMethods.isEmptyString(safiAction)) && safiAction.equalsIgnoreCase(SafiConstants.SAFI_ACTION_CHALLENGE)){
					is2FADone = false;
					Logger.info("SAFI : TTController - transferSecure(): Notify Call:START SafiAction :Challenge: STATUS_2FA_SUSPENDED",this.getClass());
					optDeliveryMethod = digitalSecMap.get(DigitalSecLogger.AUTHTYPE);
					optPhoneUsed = digitalSecMap.get(DigitalSecLogger.AUTHPHONE);
					notifyCallAndUpdateCookie(payment, httpRequest, httpResponse,commonData, mobileSession, false, false,optPhoneUsed,optDeliveryMethod);
					Logger.info("SAFI : TTController - transferSecure(): Notify Call: END",this.getClass());
				}
				//18E4: Safi Notify
				
				return errorResponse;
			}
			//18E4: Safi changes
			is2FADone = true;
			
			//commented for SBGEXP-3873
			// Date is set inside verifySecureCode method of SecureCodeHelper
			//mobileSession.setSafiLast2FASuccessTime(new Date());
			
			//18E4: Safi changes
			// do transfer
			payment.setOtp(mobileSession.getSecureCodeDetails().getOtp());

			Account fromAccount = MBAppHelper.getAccountbyAccountId(payment.getFromAccount(), mobileSession.getCustomer().getAccounts());

			optDeliveryMethod = digitalSecMap != null ? digitalSecMap.get(DigitalSecLogger.AUTHTYPE):null;
			optPhoneUsed = digitalSecMap != null ? digitalSecMap.get(DigitalSecLogger.AUTHPHONE):null;
			
			return performTransfer(mobileSession, fromAccount, payment, ServiceConstants.TT_TRANSFER_SECURE_SERVICE, httpRequest,httpResponse, is2FADone);
			
		} catch (ResourceException e) {
			Logger.info("Exception TTController - transferSecure()- [key: " + e.getKey() + "] : GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());
			mobileSession.removeTransaction();
			mobileSession.removeSecureCodeDetails();
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.SYSTEM_UNAVILABLE, ServiceConstants.TT_TRANSFER_SECURE_SERVICE, httpRequest);
		} catch (BusinessException e) {
			Logger.error("BusinessException TTController - transferSecure(): GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			try {
				if(!(StringMethods.isEmptyString(safiAction)) && safiAction.equalsIgnoreCase(SafiConstants.SAFI_ACTION_CHALLENGE)){
					Logger.info("SAFI : BusinessException TTController - transferSecure(): Notify Call:START SafiAction :Challenge:  2FA Status: "+is2FADone+"Payment Failed",this.getClass());
					notifyCallAndUpdateCookie(payment, httpRequest, httpResponse,commonData, mobileSession, is2FADone,false,optPhoneUsed,optDeliveryMethod);
					Logger.info("SAFI : BusinessException TTController - transferSecure(): Notify Call: END",this.getClass());
				}
			} catch (BusinessException e1) {
				mobileSession.removeTransaction();
				mobileSession.removeSecureCodeDetails();
				return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.GENERIC_ERROR, ServiceConstants.TT_TRANSFER_SECURE_SERVICE, httpRequest);
			}
			mobileSession.removeTransaction();
			mobileSession.removeSecureCodeDetails();
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.GENERIC_ERROR, ServiceConstants.TT_TRANSFER_SECURE_SERVICE, httpRequest);
		} 
		catch (Exception e) {
			Logger.error("Exception TTController - transferSecure(): GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			mobileSession.removeTransaction();
			mobileSession.removeSecureCodeDetails();
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.GENERIC_ERROR, ServiceConstants.TT_TRANSFER_SECURE_SERVICE, httpRequest);
		} finally {
			endPerformanceLog(logName);
		}
	}

	/**
	 * TT getFee detail service operation
	 * 
	 * @param httpRequest
	 * @param request
	 * @return
	 */
	@RequestMapping(method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE, value = "feedetail")
	@ResponseBody
	public IMBResp getFeeDetails(HttpServletRequest httpRequest, @RequestBody final TTGetFeeDetailReq request) {
		Logger.debug("TTController - getFeeDetails(). Request: " + request, this.getClass());
		String logName = startPerformanceLog(httpRequest);
		MobileSession mobileSession = new MobileSessionImpl();

		try {
			mobileSession.getSessionContext(httpRequest);

			validateRequestHeader(request.getHeader(), httpRequest);
			ErrorResp errorResponse = validate(request, httpRequest);
			if (errorResponse.hasErrors())
				return errorResponse;

			Account fromAccount = mobileSession.getCustomer().getAccounts().get(request.getFromAccountIndex());
			
			try {
				
				ttHelper.validateGetFeeReq(mobileSession.getOrigin(), request, fromAccount, mobileSession.getCustomer().getGcis(), mobileSession.getCustomer().getCustTypeInd());
				
				//18E4 -Tech Debt - to validate country code and purpose code combination
				if (ttHelper.countryMatchFound(request.getCountryCode()) && StringMethods.isEmptyString(request.getPurposeCode())) {
					throw new BusinessException(BusinessException.TT_PURPOSE_CODE_REQUIRED);
				}
				
				if (ttHelper.countryMatchFound(request.getCountryCode()) && StringMethods.isValidString(request.getPurposeCode())) {					
					Logger.debug("TT : PurposeCode -countrycode validation for :"+request.getCountryCode()+" and "+request.getPurposeCode(), this.getClass());
					//String countryCode = ttHelper.getCountryCodeTTPurposeCode(request.getCountry());  
					List<TTPurposeCode> purposeCodes = ttService.getPurposeCode(request.getCountryCode());
					if(!ttHelper.purposeCodeFound(purposeCodes , request.getCountryCode() , request.getPurposeCode())){
						throw new BusinessException(BusinessException.TT_PURPOSE_CODE_REQUIRED);
					}
				}
			} catch (BusinessException e) {
				if (e.getKey() == BusinessException.TT_BELOW_MIN) {
					CodesVO code = IBankParams.getCodesData(mobileSession.getOrigin(), IBankParams.TT_MINAMT_CAT, IBankParams.TT_MINAMT_CODE);
					return MBAppUtils.createErrorResp(mobileSession.getOrigin(), e.getKey(), MBAppUtils.getMessage(mobileSession.getOrigin(), e
							.getKey(), new String[] { (code == null) ? "" : code.getMessage() }), ServiceConstants.TT_FEE_DETAIL_SERVICE, httpRequest);
				} else if (e.getKey() == BusinessException.TT_MAX_EXCEED) {
					CodesVO code = IBankParams.getCodesData(mobileSession.getOrigin(), IBankParams.TT_MAXAMT_CAT, IBankParams.TT_MAXAMT_CODE);
					return MBAppUtils.createErrorResp(mobileSession.getOrigin(), e.getKey(), MBAppUtils.getMessage(mobileSession.getOrigin(), e
							.getKey(), new String[] { (code == null) ? "" : code.getMessage() }), ServiceConstants.TT_FEE_DETAIL_SERVICE, httpRequest);
				} else if (e.getKey() == BusinessException.EXCEED_AVAILABLE_BALANCE) {
					return MBAppUtils.createErrorResp(mobileSession.getOrigin(), e.getKey(), MBAppUtils.getMessage(mobileSession.getOrigin(), e
							.getKey(), new String[] { fromAccount.getAlias() + "-" + fromAccount.getAccountId().getAccountNumber() }),
							ServiceConstants.TT_FEE_DETAIL_SERVICE, httpRequest);
				}
				else if (e.getKey() == BusinessException.TT_SANCTIONED_COUNTRY) {
					String[] values =new String[] {request.getCurrency(),request.getCountry()};
					return MBAppUtils.createErrorResp(mobileSession.getOrigin(), e.getKey(), MBAppUtils.getMessage(mobileSession.getOrigin(), e
							.getKey(), values),
							ServiceConstants.TT_FEE_DETAIL_SERVICE, httpRequest);
				}
				 else if(e.getKey() == BusinessException.TT_RESTRICTED_COUNTRIES_BELOW_MIN) {
               	  CodesVO code = IBankParams.getCodesData(IBankParams.DEFAULT_ORIGIN, IBankParams.OVERSEAS_TT_CATEGORY, IBankParams.OVERSEAS_TT_MIN_AMOUNT);
                return MBAppUtils.createErrorResp(mobileSession.getOrigin(), e.getKey(), MBAppUtils.getMessage(mobileSession.getOrigin(), e
						.getKey(), new String[] { (code == null) ? "" : StringUtil.formatCurrencyWithoutDecimal(new BigDecimal(new String(code.getMessage()))) }), ServiceConstants.TT_FEE_DETAIL_SERVICE, httpRequest);
                 }
				throw e;
			}
			
			String feeType = MBAppUtils.findFeeType(request.getCurrency());
			BigDecimal feeAsDecimal = MBAppUtils.getUpdatedFee(mobileSession.getOrigin(), fromAccount,feeType);
			String totalAmt = String.valueOf(feeAsDecimal.add(new BigDecimal(request.getAmt())));
			return ttHelper.populateFeeDetailResponse(mobileSession.getOrigin(), mobileSession.getCustomer(), populateResponseHeader(ServiceConstants.TT_FEE_DETAIL_SERVICE, mobileSession), String.valueOf(feeAsDecimal),
					totalAmt);

		} catch (BusinessException e) {
			Logger.error("BusinessException in TTController - getFeeDetails() - [key: " + e.getKey() + "] : GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), e, ServiceConstants.TT_FEE_DETAIL_SERVICE, httpRequest);
		} catch (ResourceException e) {
			Logger.error("ResourceException in TTController - getFeeDetails() - [key: " + e.getKey() + "] : GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.SYSTEM_UNAVILABLE, ServiceConstants.TT_FEE_DETAIL_SERVICE, httpRequest);
		} catch (Exception e) {
			Logger.error("Exception TTController - getFeeDetails(): GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), ResourceException.MOBILE_NON_FINANCIAL_FATAL_ERR, ServiceConstants.TT_FEE_DETAIL_SERVICE, httpRequest);
		} finally {
			endPerformanceLog(logName);
		}
	}

	/**
	 * Get list of TT Beneficiaries
	 * 
	 * @param httpRequest
	 * @param request
	 * @return
	 */
	@RequestMapping(method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE, value = "beneficiaries")
	@ResponseBody
	public IMBResp getBeneficiaries(HttpServletRequest httpRequest, @RequestBody final EmptyReq request) {
		Logger.debug("TTController - getBeneficiaries(). Request: " + request, this.getClass());
		String logName = startPerformanceLog(httpRequest);
		MobileSession mobileSession = new MobileSessionImpl();

		try {
			mobileSession.getSessionContext(httpRequest);

			validateRequestHeader(request.getHeader(), httpRequest);
			ErrorResp errorResponse = validate(request, httpRequest);// validate json
			if (errorResponse.hasErrors())
				return errorResponse;
			// getBeneficiaries
			try {
				List<OverseasTTBeneficiary> beneficiaries = ttService.findBenefListByGCISWithoutDelete(mobileSession.getCustomer().getGcis());
				if (beneficiaries.size() > 0)
					return ttHelper.populateBeneficiariesResponse(populateResponseHeader(ServiceConstants.TT_BENEFICIARIES_SERVICE, mobileSession), beneficiaries);
				else
					throw new BusinessException(BusinessException.TT_NO_BENEFICIARY);
			} catch (BusinessException e) {
				return MBAppUtils.createErrorResp(mobileSession.getOrigin(), e, ServiceConstants.TT_BENEFICIARIES_SERVICE, httpRequest);
			}

		} catch (ResourceException e) {
			Logger.info("Exception - [key: " + e.getKey() + "] : GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.SYSTEM_UNAVILABLE, ServiceConstants.TT_BENEFICIARIES_SERVICE, httpRequest);
		} catch (Exception e) {
			Logger.error("Exception TTController - reqSecureCode(): GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), ResourceException.MOBILE_NON_FINANCIAL_FATAL_ERR, ServiceConstants.TT_BENEFICIARIES_SERVICE, httpRequest);
		} finally {
			endPerformanceLog(logName);
		}

	}

	/**
	 * Get list of currencies for a country
	 * 
	 * @param httpRequest
	 * @param request
	 * @return
	 */
	@RequestMapping(method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE, value = "currency")
	@ResponseBody
	public IMBResp getCurrencies(HttpServletRequest httpRequest, @RequestBody final TTCountryCurrencyReq request) {
		Logger.debug("TTController - getCurrencies(). Request: " + request, this.getClass());
		String logName = startPerformanceLog(httpRequest);
		MobileSession mobileSession = new MobileSessionImpl();

		try {
			mobileSession.getSessionContext(httpRequest);
			validateRequestHeader(request.getHeader(), httpRequest);
			ErrorResp errorResponse = validate(request, httpRequest);// validate json
			if (errorResponse.hasErrors())
				return errorResponse;
			IBankCommonData commonData = new MBAppHelper().populateIBankCommonData(mobileSession, httpRequest);

			try {
				String defaultCurrency = "";
				
				/**18E4 : Tech Debt - country code - Below look up is still with country name 
				 * bcz the code is of three chars and in request code is of 2 chars*/
				
				CodesVO codesVo = IBankParams.getCodesData(IBankParams.DEFAULT_ORIGIN, IBankParams.COUNTRY_CURRENCY, request.getCountry()
						.toUpperCase());
				if (codesVo != null) {
					defaultCurrency = codesVo.getMessage();
//					throw new Exception("Currency not found for the country " + request.getCountry().toUpperCase());
				}
				
				/*18E4 : tech Debt countrycode -*/
				/*List<BICCountry> countryList = (List<BICCountry>) IBankParams.getBICCountryList(); 
				String countryCode = "";				
				for(BICCountry bICCountry : countryList){
					if(bICCountry.getCountryName().equalsIgnoreCase(request.getCountry())){
						countryCode =  bICCountry.getCountryCode();
					}
				}*/
				List<TTPurposeCode> purposeCodes = null;
				purposeCodes = ttService.getPurposeCode(request.getCountryCode());
				mobileSession.setPurposeCodesList(purposeCodes);
				if(purposeCodes == null){
					purposeCodes = new ArrayList<TTPurposeCode>();
					Logger.info("TTController - getCurrencies(): purposeCodes List is empty " ,this.getClass());
				}

				return ttHelper.populateCountryCurrenciesResponse(mobileSession.getOrigin(),
						populateResponseHeader(ServiceConstants.TT_CURRENCIES_SERVICE, mobileSession), defaultCurrency, (List<Currency>) ttService
								.getCurrencyList(commonData.getUser().getGCISNumber()),purposeCodes, mobileSession.getCustomer().getContactDetail()
								.getResidentialAddress());
			} catch (BusinessException e) {
				return MBAppUtils.createErrorResp(mobileSession.getOrigin(), e, ServiceConstants.TT_CURRENCIES_SERVICE, httpRequest);
			}

		} catch (ResourceException e) {
			Logger.info("Exception - [key: " + e.getKey() + "] : GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.SYSTEM_UNAVILABLE, ServiceConstants.TT_CURRENCIES_SERVICE, httpRequest);
		} catch (Exception e) {
			Logger.error("Exception TTController - reqSecureCode(): GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.GENERIC_ERROR, ServiceConstants.TT_CURRENCIES_SERVICE, httpRequest);
		} finally {
			endPerformanceLog(logName);
		}

	}

	private IMBResp performTransfer(MobileSession mobileSession, Account fromAccount, TelegraphicTransfer payment, String caller, HttpServletRequest httpRequest,HttpServletResponse httpResponse, boolean is2FADone)
			throws BusinessException {
        DigitalSecLogggerVO digitalSecLoggerVO =new DigitalSecLogggerVO();
        digitalSecLoggerVO.setTranName(DigitalSecLogger.OSEAS_TRANSFER);
        digitalSecLoggerVO.setStatus(DigitalSecLogger.SUCCESS);
        IBankCommonData commonData = null;
        String optDeliveryMethod = null;
        String optPhoneUsed = null;
        String safiAction = null;
        
		try {
			commonData=mbAppHelper.populateIBankCommonData(mobileSession,httpRequest);
			digitalSecLoggerVO.setCommonLogData(mbAppHelper.getCommonLogData(commonData));
			digitalSecLoggerVO.setUserAgent(commonData.getUserAgent());
			LabelValueMap digitalSecMap = mobileSession.getDigitalSecLoggerMap();
			optDeliveryMethod = digitalSecMap != null ? digitalSecMap.get(DigitalSecLogger.AUTHTYPE):null;
			optPhoneUsed = digitalSecMap != null ? digitalSecMap.get(DigitalSecLogger.AUTHPHONE):null;
			safiAction = payment != null && payment.getSafiRespVO() != null? payment.getSafiRespVO().getSafiAction(): null;
			
			Receipt receipt = pay(payment, mobileSession);
			
			if(!(StringMethods.isEmptyString(safiAction)) && safiAction.equalsIgnoreCase(SafiConstants.SAFI_ACTION_CHALLENGE)){
				Logger.info("SAFI : TTController - performTransfer(): Notify Call:START SafiAction :Challenge:  2FA Status: "+is2FADone+"Payment Successful",this.getClass());
				notifyCallAndUpdateCookie(payment, httpRequest, httpResponse,commonData, mobileSession, is2FADone,true,optPhoneUsed,optDeliveryMethod);
				Logger.info("SAFI : TTController - performTransfer(): Notify Call: END",this.getClass());
			}
			
			TransferResp response = ttHelper.populateTransferResponse(populateResponseHeader(ServiceConstants.TT_TRANSFER_SERVICE, mobileSession), receipt, payment,
					mobileSession.getCustomer());
			// added to get Offer On transfer receipt
			response = ttHelper.populateTeaserResponse(response, commonData,"Overseas Payment Receipt");

			String purposeDescription = null;
			List<TTPurposeCode> purposeCodesList = mobileSession.getPurposeCodesList();
			if(purposeCodesList != null && !purposeCodesList.isEmpty()){
				purposeDescription = getPurposeDescription(purposeCodesList, payment);
			}
			
			if(is2FADone){
				digitalSecLoggerVO.setValues(payment.toDigitalSecurityLogWithPurposeDesc(digitalSecMap.get(DigitalSecLogger.AUTHTYPE), digitalSecMap.get(DigitalSecLogger.AUTHPHONE), purposeDescription));
			} else {
				digitalSecLoggerVO.setValues(payment.toDigitalSecurityLogWithPurposeDesc(CommonBusinessUtil.get2FAExemptType(commonData.getCustomer()), null, purposeDescription));
			}
			if(ibankRefreshParams.isTTRestrictHighRiskCountriesSwitchOn() && StringMethods.isEmptyString(safiAction)) {
				digitalSecLoggerVO.setStatus(DigitalSecLogger.SUCCESS_SAFI_OFFHOST);
			}
			digitalSecLoggerVO.setValues(ttService.addSafiDetailsToForensicLogs(digitalSecLoggerVO.getValues(), payment, is2FADone));
			digitalSecLogger.log(digitalSecLoggerVO);
			mobileSession.removeDigitalSecLoggerMap();
			mobileSession.removeTransaction();
			mobileSession.removePurposeCodesList();
			mobileSession.removeSecureCodeDetails();
			Logger.debug("TTController - performTransfer(). Response: " + response, this.getClass());
			return response;

		} catch (BusinessException e) {
			Logger.error("BusinessException in TTController - performTransfer() - [key: " + e.getKey() + "] : GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());
			digitalSecLoggerVO.setStatus(DigitalSecLogger.FAILURE);
			digitalSecLogger.log(digitalSecLoggerVO);
			
			if(!(StringMethods.isEmptyString(safiAction)) && safiAction.equalsIgnoreCase(SafiConstants.SAFI_ACTION_CHALLENGE)){
				Logger.info("SAFI : BusinessException TTController - performTransfer(): Notify Call:START SafiAction :Challenge:  2FA Status: "+is2FADone+"Payment Failed: ",this.getClass());
				notifyCallAndUpdateCookie(payment, httpRequest, httpResponse,commonData, mobileSession, is2FADone,false,optPhoneUsed,optDeliveryMethod);
				Logger.info("SAFI : BusinessException TTController - performTransfer(): Notify Call: END",this.getClass());
			}
			
			if (e.getKey() == BusinessException.ACCOUNT_AMT_BELOW_MIN_REDRAW) {
				String minAmt = "";
				if (fromAccount != null && fromAccount.getLimits() != null) {
					minAmt = String.valueOf(fromAccount.getLimits().getMinimumRedrawAmount());
				}
				return MBAppUtils.createErrorResp(mobileSession.getOrigin(), e.getKey(), MBAppUtils.getMessage(mobileSession.getOrigin(), e.getKey(),
						new String[] { minAmt }), caller, httpRequest);
			} else if (e.getKey() == BusinessException.INVALID_CHAR_SET) {
				throw new BusinessException(BusinessException.INVALID_CHAR_SET, "Invalid Character");
			} else {
				return MBAppUtils.createErrorResp(mobileSession.getOrigin(), e.getKey(), caller, httpRequest);
			}

		}
	}
	
	private String getPurposeDescription(List<TTPurposeCode> purposeCodesList, TelegraphicTransfer payment) {
		String purposeCodeDescription = null;
		for (TTPurposeCode tempList : purposeCodesList) {
			if (tempList.getPurposeCode().equalsIgnoreCase(payment.getPurposeCode())) {
				purposeCodeDescription = tempList.getPurposeDesc();
			}
		}

		return purposeCodeDescription;
	}

	private Receipt pay(TelegraphicTransfer tt, MobileSession mobileSession) throws BusinessException {
		Logger.debug("Payment object - " + ReflectionToStringBuilder.toString(tt, ToStringStyle.MULTI_LINE_STYLE), this.getClass());
		tt.setVerify(false);
		Receipt receipt = transactService.performTransfer(tt);
		Logger.debug("Receipt - " + ReflectionToStringBuilder.toString(receipt, ToStringStyle.MULTI_LINE_STYLE), this.getClass());
		Customer updatedCustomer = tt.getCommonData().getCustomer();
		mobileSession.setCustomer(updatedCustomer);
		mobileSession.removeTransaction();
		mobileSession.removeSecureCodeDetails();
		return receipt;
	}

	private boolean check2FA(Customer customer, TelegraphicTransfer tt) throws ResourceException, BusinessException {
		CodesVO myCodes = IBankParams.getCodesData(IBankParams.DEFAULT_ORIGIN, IBankParams.CD_CATEGORY_2FA, IBankParams.CD_CODE_2FA_TTTHRESHOLD);
		BigDecimal threshold = new BigDecimal(myCodes.getMessage());
		boolean custExempt = IBankSecureService.isCustomerExempt(customer.getIBankSecureDetails());
		boolean bypass = IBankSecureService.isGlobalByPass();
		return (!bypass && ((tt.getAudAmount().compareTo(threshold) >= 1) && !custExempt));
	}
	
	private void createOrUpdatePMData2Cookie(HttpServletRequest httpServletRequest,SafiRespVO safiRespVO,HttpServletResponse httpServletResponse){
		
		if(safiRespVO != null){
			Cookie pmdata2 = SafiWebHelper.readCookies(httpServletRequest);
			//create or update cookie and save
			Cookie newCookie = SafiWebHelper.createOrUpdatePmdata2Cookie(httpServletRequest,pmdata2,safiRespVO.getDeviceToken());
			Logger.debug("SAFI : TTController.createOrUpdatePMData2Cookie(): Setting new PMDATA2 cookie in resp : ", this.getClass());
			httpServletResponse.addCookie(newCookie);
			Logger.debug("SAFI : TTController.createOrUpdatePMData2Cookie(): PMDATA2 cookie setting resp done: ", this.getClass());
		}
	}

	private void notifyCallAndUpdateCookie(TelegraphicTransfer tt,HttpServletRequest httpServletRequest,HttpServletResponse httpServletResponse ,IBankCommonData commonData,MobileSession mobileSession,boolean status2FA,boolean isPaymentSuccess,String otpPhoneUsed,String otpDeliveryMethod) throws BusinessException{
		Logger.debug("SAFI : TTController.notifyCallAndUpdateCookie():START", this.getClass());
		try{
			if(tt != null){
				//populate the safiPayTranVO for notify call
				SafiWebHelper.populateSafiVOForNotifyTT(httpServletRequest,tt, mobileSession, status2FA,isPaymentSuccess,otpPhoneUsed, otpDeliveryMethod);
				//SAFI Notify Call
				SafiRespVO safiRespVO = ttService.notifyCallForOverseasTransfer(commonData,tt.getSafiPayTranVO());
				//create or update cookie and save
				createOrUpdatePMData2Cookie(httpServletRequest,safiRespVO , httpServletResponse);
			}
		}catch(Exception e){
			Logger.debug("SAFI : TTController.notifyCallAndUpdateCookie(): exception during notify call", this.getClass());
		}
		Logger.debug("SAFI : TTController.notifyCallAndUpdateCookie():END", this.getClass());
	}
	
	
	/**
	 * Response for invalid body request
	 * 
	 * @return
	 */
	@ExceptionHandler( { org.springframework.http.converter.HttpMessageNotReadableException.class })
	@ResponseStatus(org.springframework.http.HttpStatus.OK)
	@ResponseBody
	public IMBResp resolveException() {
		return MBAppUtils.createInvalidMessageBodyResponse(ServiceConstants.TT_BENEFICIARIES_SERVICE);
	}

	public ErrorResp validate(IMBReq serviceRequest, HttpServletRequest request) {
		Logger.info("Service request object - " + ReflectionToStringBuilder.toString(serviceRequest), this.getClass());
		return mbAppValidator.validate(serviceRequest, request);
	}

	public void validateRequestHeader(ReqHeader headerReq, HttpServletRequest request) throws BusinessException {
		Logger.debug("Request header validation: " + ReflectionToStringBuilder.toString(headerReq, ToStringStyle.MULTI_LINE_STYLE), this.getClass());
		mbAppValidator.validateRequestHeader(headerReq, request);
	}
	
	public RespHeader populateResponseHeader(String serviceName, MobileSession mobSession) {
		return mbAppHelper.populateResponseHeader(serviceName, mobSession);
	}

	@Autowired
	private PerformanceLogger perfLogger;
	
	private String startPerformanceLog(HttpServletRequest httpRequest){
		perfLogger.startAllLogs();
		String logName = MBAppUtils.getLogName(httpRequest);
		perfLogger.startLog(logName);
		return logName;
	}
	
	private void endPerformanceLog(String logName){
		perfLogger.endLog(logName);
		perfLogger.endAllLogs();
	}

	private int getRegisteredPhoneNumberCount(ContactDetail contactDetail){
		int registeredPhoneNumberCount = 0;
		
		if (!CustomerVOAssembler.BUSINESS_CUSTOMER.equalsIgnoreCase(contactDetail.getCustTypeInd())){
			if (contactDetail.getHomeNumber() != null && !StringMethods.isEmptyString(contactDetail.getHomeNumber().getPhoneNumber())){
				registeredPhoneNumberCount++;
			}
		}
		if (contactDetail.getWorkNumber() != null && !StringMethods.isEmptyString(contactDetail.getWorkNumber().getPhoneNumber())){
			registeredPhoneNumberCount++;
		}
		if (contactDetail.getMobileNumber() != null && !StringMethods.isEmptyString(contactDetail.getMobileNumber().getPhoneNumber())){
			registeredPhoneNumberCount++;
		}
		return registeredPhoneNumberCount;
	}	
	
	@RequestMapping(method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE, value = "cancelsecurecode")
	@ResponseBody
	public IMBResp cancelSecureCode(HttpServletRequest httpRequest, HttpServletResponse httpResponse,@RequestBody final EmptyReq request) {
		Logger.debug("TTController - cancelSecureCode(). Request: " + request, this.getClass());
		String logName = startPerformanceLog(httpRequest);
		MobileSession mobileSession = new MobileSessionImpl();
		TelegraphicTransfer payment =  null;
		IBankCommonData commonData = null;
		LabelValueMap digitalSecMap = null;
		String safiAction = null;
		
		try {
			mobileSession.getSessionContext(httpRequest);
			commonData = new MBAppHelper().populateIBankCommonData(mobileSession, httpRequest);

			validateRequestHeader(request.getHeader(), httpRequest);
			ErrorResp errorResponse = validate(request, httpRequest);// validate json
			if (errorResponse.hasErrors())
				return errorResponse;

			if(!ibankRefreshParams.isTTRestrictHighRiskCountriesSwitchOn()) {
				return populateSuccessResp(populateResponseHeader(ServiceConstants.TT_SECURE_CODE_CANCEL, mobileSession), false);
			}
			payment = (TelegraphicTransfer) mobileSession.getTransaction();
			safiAction = payment != null && payment.getSafiRespVO() != null? payment.getSafiRespVO().getSafiAction(): null;
			DigitalSecLogggerVO digitalSecLoggerVO =new DigitalSecLogggerVO();
	        digitalSecLoggerVO.setTranName(DigitalSecLogger.OSEAS_TRANSFER);
			digitalSecLoggerVO.setStatus(StringMethods.isEmptyString(safiAction)? DigitalSecLogger.CANCEL_2FA_SAFI_OFFHOST:DigitalSecLogger.CANCEL_2FA);
			digitalSecLoggerVO.setCommonLogData(mbAppHelper.getCommonLogData(commonData));
			digitalSecLoggerVO.setUserAgent(commonData.getUserAgent());
			digitalSecMap = mobileSession.getDigitalSecLoggerMap();
			String purposeDescription = null;
			List<TTPurposeCode> purposeCodesList = mobileSession.getPurposeCodesList();
			if(purposeCodesList != null && !purposeCodesList.isEmpty()){
				purposeDescription = getPurposeDescription(purposeCodesList, payment);
			}
			digitalSecLoggerVO.setValues(payment.toDigitalSecurityLogWithPurposeDesc(digitalSecMap.get(DigitalSecLogger.AUTHTYPE), digitalSecMap.get(DigitalSecLogger.AUTHPHONE), purposeDescription));
			digitalSecLoggerVO.setValues(ttService.addSafiDetailsToForensicLogs(digitalSecLoggerVO.getValues(), payment, true));
			digitalSecLogger.log(digitalSecLoggerVO);
			
			
			return populateSuccessResp(populateResponseHeader(ServiceConstants.TT_SECURE_CODE_CANCEL, mobileSession), true);
			
		} catch (ResourceException e) {
			Logger.info("Exception TTController - cancelSecureCode()- [key: " + e.getKey() + "] : GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.SYSTEM_UNAVILABLE, ServiceConstants.TT_SECURE_CODE_CANCEL, httpRequest);
		} catch (BusinessException e) {
			Logger.error("BusinessException TTController - cancelSecureCode(): GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.GENERIC_ERROR, ServiceConstants.TT_SECURE_CODE_CANCEL, httpRequest);
		} 
		catch (Exception e) {
			Logger.error("Exception TTController - cancelSecureCode(): GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.GENERIC_ERROR, ServiceConstants.TT_SECURE_CODE_CANCEL, httpRequest);
		} finally {
			endPerformanceLog(logName);
		}
	}
	
	private SuccessResp populateSuccessResp(RespHeader header, boolean isSuccess) {
		SuccessResp response = new SuccessResp();
		response.setHeader(header);
		response.setIsSuccess(isSuccess);
		Logger.info("populateSuccessResp response populated: " + response, this.getClass());
		return response;
	}
	
	private void addSAFIDenyForensicLogs(MobileSession mobileSession, IBankCommonData commonData, TelegraphicTransfer payment) {
		try {
			DigitalSecLogggerVO digitalSecLoggerVO =new DigitalSecLogggerVO();
	        digitalSecLoggerVO.setTranName(DigitalSecLogger.OSEAS_TRANSFER);
			digitalSecLoggerVO.setStatus(DigitalSecLogger.FAILURE);
			digitalSecLoggerVO.setCommonLogData(mbAppHelper.getCommonLogData(commonData));
			digitalSecLoggerVO.setUserAgent(commonData.getUserAgent());
			String purposeDescription = null;
			List<TTPurposeCode> purposeCodesList = mobileSession.getPurposeCodesList();
			if(purposeCodesList != null && !purposeCodesList.isEmpty()){
				purposeDescription = getPurposeDescription(purposeCodesList, payment);
			}
			digitalSecLoggerVO.setValues(payment.toDigitalSecurityLogWithPurposeDesc(CommonBusinessUtil.get2FAExemptType(commonData.getCustomer()), null, purposeDescription));
			digitalSecLoggerVO.setValues(ttService.addSafiDetailsToForensicLogs(digitalSecLoggerVO.getValues(), payment, false));
			digitalSecLogger.log(digitalSecLoggerVO);
		}catch(Exception err) {
			Logger.error("Exception in Forensic logs for SAFI DENY", err, this.getClass());
		}
	}
	
}
