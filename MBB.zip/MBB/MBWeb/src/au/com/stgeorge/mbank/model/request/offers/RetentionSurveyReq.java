package au.com.stgeorge.mbank.model.request.offers;

import org.apache.commons.lang.builder.ReflectionToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;

import au.com.stgeorge.mbank.model.common.IMBReq;
import au.com.stgeorge.mbank.model.common.ReqHeader;

public class RetentionSurveyReq implements IMBReq {
	
	private static final long serialVersionUID = -3858259604674792651L;

	private ReqHeader header;
	
	private String surveyReason;
	
	private String surveyAction;
	
	public String getSurveyReason() {
		return surveyReason;
	}

	public void setSurveyReason(String surveyReason) {
		this.surveyReason = surveyReason;
	}

	public ReqHeader getHeader() {
		return header;
	}

	public void setHeader(ReqHeader header) {
		this.header = header;
	}
	
	public String getSurveyAction() {
		return surveyAction;
	}

	public void setSurveyAction(String surveyAction) {
		this.surveyAction = surveyAction;
	}
	
	@Override
	public String toString() {
		return ReflectionToStringBuilder.toString(this, ToStringStyle.MULTI_LINE_STYLE);
	}

}