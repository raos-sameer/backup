/**
 * 
 */
package au.com.stgeorge.mbank.controller.services;

import java.util.ArrayList;
import java.util.List;

import au.com.stgeorge.framework.common.logging.Logger;
import au.com.stgeorge.ibank.businessobject.BusinessException;
import au.com.stgeorge.ibank.common.cache.IBankParams;
import au.com.stgeorge.ibank.util.StringUtil;
import au.com.stgeorge.ibank.valueobject.ATMLimitUpdate;
import au.com.stgeorge.ibank.valueobject.Account;
import au.com.stgeorge.ibank.valueobject.DebitCardAccount;
import au.com.stgeorge.ibank.valueobject.database.CodesVO;
import au.com.stgeorge.mbank.model.response.services.AtmLimitCardListResp;
import au.com.stgeorge.mbank.model.response.services.AtmLimitCardResp;
import au.com.stgeorge.mbank.util.MBAppHelper;

/**
 * @author c50216
 *
 */
public class AtmLimitHelper {

	protected AtmLimitCardListResp populateCardsResp(List<ATMLimitUpdate> cardList){
		
		AtmLimitCardListResp resp = new AtmLimitCardListResp();		
		List<AtmLimitCardResp> cardListResp = new ArrayList<AtmLimitCardResp>(); 
		List<String> amtList = new ArrayList<String>();		
		
		for(ATMLimitUpdate atmLimitVO : cardList){
			
			AtmLimitCardResp cardResp = new AtmLimitCardResp();
			cardResp.setIndex(atmLimitVO.getIndex());
			cardResp.setCurrentLimit(atmLimitVO.getCashLimit());
			Account acct = atmLimitVO.getAccount();
			if(acct instanceof DebitCardAccount){
				DebitCardAccount debitCard = (DebitCardAccount) acct;
				
				if(IBankParams.isSwitchOn(IBankParams.CARD_NUM_MASK_SWITCH)) {
					cardResp.setAccountNumDisp(StringUtil.formatCardNumber(debitCard.getCardNumber()));
					}
				else {
					cardResp.setAccountNumDisp(new MBAppHelper().getFormattedAcctNumber(debitCard.getCardNumber(), debitCard.getAccountId()
							.getApplicationId(), debitCard.getAccountId().getBsb()));
					
				}
				
								
				cardResp.setAccountName(debitCard.getCardName());
				
			}else{
				cardResp.setAccountNumDisp(new MBAppHelper().getFormattedAcctNumber(acct.getAccountId().getAccountNumber(), acct.getAccountId()
						.getApplicationId(), acct.getAccountId().getBsb()));
				
				cardResp.setAccountName(acct.getAlias());							
			}
			
			cardListResp.add(cardResp);				
		}		
		
		CodesVO codeItem=IBankParams.getCodesData(IBankParams.BRAND_ORIGIN, IBankParams.PARAMETER,IBankParams.ATM_LIMIT_ELIGIBLE_AMOUNT_LIST);
		if(codeItem != null){
			String[] amtArr = codeItem.getMessage().split(";");
			for(String amt : amtArr){
				amtList.add(amt);
			}
						
			resp.setAmtList(amtList);
		}
		
		resp.setCardList(cardListResp);
		
		return resp;
	}
	
	protected ATMLimitUpdate getAtmLimitAccountFromIndex(int index, List<ATMLimitUpdate> cardList) throws BusinessException{
		
		ATMLimitUpdate atmLimitVO = null;
				
		for(ATMLimitUpdate obj: cardList){
			if(index == obj.getIndex()){
				atmLimitVO = obj;
				Account acc = atmLimitVO.getAccount();
				if (acc instanceof DebitCardAccount)
				{
					DebitCardAccount debitCard = (DebitCardAccount) acc;
					debitCard.setAlias(debitCard.getCardName());
					debitCard.getAccountId().setAccountNumber(debitCard.getCardNumber());
				}
				break;
			}
		}
				
		if(atmLimitVO == null){
			Logger.info("Error: Could not find ATMLimitUpdate from the session List", this.getClass());
			throw new BusinessException(BusinessException.GENERIC_ERROR);
		}
		
		return atmLimitVO;		
	}
	
	protected List<ATMLimitUpdate> populateUpdatedCardList(List<ATMLimitUpdate> cardList, int reqIndex, String newLimit){
		
		//Since using reference is not recommended to update the mewLimit in session. This method is created to populate updated list. 
		List<ATMLimitUpdate> list = new ArrayList<ATMLimitUpdate>();
		
		for(ATMLimitUpdate atmLimitVO : cardList){
			
			ATMLimitUpdate newVo = new ATMLimitUpdate();
			
			newVo.setAccount(atmLimitVO.getAccount());
			newVo.setIndex(atmLimitVO.getIndex());
			
			if(reqIndex == atmLimitVO.getIndex())
				newVo.setCashLimit(newLimit);
			else
				newVo.setCashLimit(atmLimitVO.getCashLimit());
			
			list.add(newVo);			
		}		
		return list;
	}
	
}
