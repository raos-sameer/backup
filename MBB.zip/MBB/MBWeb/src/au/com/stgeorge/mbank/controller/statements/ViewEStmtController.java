package au.com.stgeorge.mbank.controller.statements;

import java.io.InputStream;
import java.io.OutputStream;
import java.util.List;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.AbstractController;

import au.com.stgeorge.framework.common.logging.Logger;
import au.com.stgeorge.framework.common.model.User;
import au.com.stgeorge.ibank.businessobject.BusinessException;
import au.com.stgeorge.ibank.businessobject.EStatementService;
import au.com.stgeorge.ibank.businessobject.ResourceException;
import au.com.stgeorge.ibank.businessobject.globalWallet.GlobalWalletEstatementService;
import au.com.stgeorge.ibank.common.cache.IBankParams;
import au.com.stgeorge.ibank.messagecentre.valueobject.TokenDetails;
import au.com.stgeorge.ibank.valueobject.Account;
import au.com.stgeorge.ibank.valueobject.AccountId;
import au.com.stgeorge.ibank.valueobject.AcctStatement;
import au.com.stgeorge.ibank.valueobject.StatementOrderTransaction;
import au.com.stgeorge.ibank.valueobject.transfer.IBankCommonData;
import au.com.stgeorge.mbank.session.GenericSessionFactory;
import au.com.stgeorge.mbank.session.IGenericSession;
import au.com.stgeorge.mbank.util.MBAppConstants;
import au.com.stgeorge.mbank.util.MBAppHelper;
import au.com.stgeorge.mbank.util.MBAppUtils;
import au.com.stgeorge.mobilebank.businessobject.EStatementsService;
import au.com.stgeorge.perflogger.PerformanceLogger;

/**
 * @author C50216
 *
 */

@Controller
public class ViewEStmtController extends AbstractController{

	private  static final String statementEndDateFormat = "ddMMMYYYY";
	
	@Autowired
	private EStatementService eStatementService;
	
	@Autowired
	private EStatementsService mobileEStatementService;
	
	@Autowired
	private MBAppHelper mbAppHelper;
	
	@Autowired
	private PerformanceLogger perfLogger;
	
	@Autowired
	private GlobalWalletEstatementService globalWalletEstatementService;
	
	@Override
	protected ModelAndView handleRequestInternal(HttpServletRequest request,
			HttpServletResponse response) throws Exception {
						
		TokenDetails tokenDetails = new TokenDetails();		
		Integer errorCode = null;
		boolean sessionValidated = false;
		boolean userValidated = false;
		perfLogger.startAllLogs();
		String logName = MBAppUtils.getLogName(request);
		perfLogger.startLog(logName);
		boolean isClosedAccount = false;
		
		try {
					
			String pdfToken = request.getParameter("token");
			String isClosedAcct = request.getParameter("isClosedAccount");
			if(isClosedAcct != null && (!("".equalsIgnoreCase(isClosedAcct))))
			isClosedAccount = Boolean.parseBoolean(isClosedAcct);
			
			tokenDetails = eStatementService.getPDFDocTokenDetails(pdfToken);
			if (tokenDetails != null) {
				
				//Token Expiry 30 min logic reverted. token has the same expiry time as session. 
				//CodesVO myVO = IBankParams.getCodesData(IBankParams.DEFAULT_ORIGIN, IBankParams.ESTATEMENT, IBankParams.ESTMT_TOKEN_EXPIRY_INTEVAL);
				
				//Calendar tokenCal = Calendar.getInstance();
				//tokenCal.setTime(tokenDetails.getCreatedOn());				
				//Calendar TodayCal = Calendar.getInstance();
				//tokenCal.add(Calendar.MINUTE, Integer.parseInt(myVO.getMessage()));
				
				//validate token corresponding to the session.
				
				String sessionIdForToken = tokenDetails.getSessionId();							
				IGenericSession gSession = GenericSessionFactory.getInstance(sessionIdForToken);
				Cookie cookie = getCookie(request);
				User tempUser = gSession.getUser();
				
				if(tempUser != null && tempUser.getGCISNumber().equalsIgnoreCase(tokenDetails.getGcisNumber()))					
					userValidated = true;
									
				if(cookie != null){
					if(sessionIdForToken.equals(cookie.getValue()))						
						if(userValidated)
							sessionValidated = true;
				}else if(userValidated)
					sessionValidated = true;
								
				if(sessionValidated){
					
					User user = new User(tokenDetails.getGcisNumber(),
							IBankParams.BLANK_STRING, IBankParams.BLANK_STRING,
							null, false, true, false);
					
					IBankCommonData commonData = new IBankCommonData();
					
					commonData.setUser(user);
					commonData.setOrigin(mbAppHelper.getOrigin(request));
					commonData.setIpAddress(MBAppHelper.resolveIPAddress(request, mbAppHelper.getOrigin(request)));
					commonData.setSessionId(sessionIdForToken);
					commonData.setGdwOrigin(tokenDetails.getOriginBank());
										
					Account account = new Account();
					AccountId accountId = new AccountId();
					String accNum = tokenDetails.getAccountNum();
					accountId.setProductName(tokenDetails.getProdName());
					accountId.setApplicationId(tokenDetails.getApplId());
					accountId.setEhubProductCode(tokenDetails.getAccountType());
					accountId.setSubProductCode(tokenDetails.getSubProdCode());
					
					if (Account.DDA.equals(tokenDetails.getApplId())) {
						if (accNum.length() > 9) {
							accountId.setBranchKey(accNum.substring(0, 3));
							accountId.setAccountKey(accNum.substring(3, accNum
									.length()));
						} else {
							accountId.setAccountKey(accNum);
							accountId.setBranchKey("000");
						}
					} else {
						accountId.setAccountKey(accNum);
					}
					
					accountId.setBsb(tokenDetails.getBsb());
					accountId.setRelationshipCode(null);
					account.setAccountId(accountId);
					
					//This is for MostRecent statement. the moment customer click on MostRecent stmt, pdf stmt will be opened. 
					if(tokenDetails.getStmtId().equalsIgnoreCase("")){
						//Relationship Code was saved from Account Details, it will be required to decide Address Masking
						accountId.setRelationshipCode(tokenDetails.getStmtAddrMaskInd());
						
						StatementOrderTransaction stmtOrderTransaction = new StatementOrderTransaction();
						stmtOrderTransaction.setAmountFromAccount(account.getAccountId());
						
						List<AcctStatement> stmtList = mobileEStatementService.getMobileEStatementIDList(stmtOrderTransaction, commonData,isClosedAccount);
						
						if(stmtList.size() == 1){
							
							AcctStatement stmt = (AcctStatement) stmtList.get(0);
							tokenDetails.setStmtId(stmt.getStatementId());
							tokenDetails.setStmtEndDate(stmt.getDateTo());
							
							tokenDetails.setStmtAddrMaskInd(stmt.getStmtAddrMaskInd());
							
							eStatementService.updatePDFDocTokenDetails(tokenDetails);
							
						}else{
							Logger.info("No PDF statement found !!! ",this.getClass());
							throw new BusinessException(BusinessException.PDF_STATEMENT_NOT_FOUND);							
						}																
					}
					
					AcctStatement acctStatement = new AcctStatement();
					acctStatement.setStatementId(tokenDetails.getStmtId());
					acctStatement.setStmtAddrMaskInd(tokenDetails.getStmtAddrMaskInd());
					acctStatement.setDateTo(tokenDetails.getStmtEndDate());
					
					String pdfDoc = "";
					byte[] stmtBytes = null;
					
					if(Account.GWC.equalsIgnoreCase(account.getAccountId().getApplicationId())) {
						acctStatement.setCardNumber(tokenDetails.getStmtId());
						acctStatement.setDateFrom(tokenDetails.getCreatedOn());
						acctStatement.setDateTo(tokenDetails.getStmtEndDate());
						account.setBrand(tokenDetails.getOriginBank());
						pdfDoc = globalWalletEstatementService.getStatementPdfData(acctStatement, account, commonData, isClosedAccount);
					}else {
						pdfDoc = mobileEStatementService.getMobilePDFDocument(acctStatement,
								account, commonData,isClosedAccount);
					}
					
					if (pdfDoc == null || pdfDoc.length() == 0) {
						throw new BusinessException(
								BusinessException.NO_ACCOUNTS_AVAILABLE);
					}
					
					stmtBytes = new sun.misc.BASE64Decoder().decodeBuffer(pdfDoc);
					//Added by Deepti for EStatements for Closed Accounts
					String pdfFileName = account.getAccountId().getProductName()
					+ "-" + mbAppHelper.getAccountKeyDisp(account.getAccountId().getAccountKey()) + "-"
					+ mbAppHelper.formatDate(tokenDetails.getStmtEndDate(),statementEndDateFormat);
					//Added by Deepti for EStatements for Closed Accounts
					
					pdfFileName = trimInternalSpaces(pdfFileName);
					response.setContentType("application/pdf");
					response.setHeader("Content-Disposition",
							"attachment;filename="+pdfFileName +".pdf");
					java.io.OutputStream os = response.getOutputStream();
					os.write(stmtBytes, 0, stmtBytes.length);
					os.flush();
					os.close(); 
					
					//Remove this token from db
					if(Account.GWC.equalsIgnoreCase(account.getAccountId().getApplicationId())) {
						eStatementService.deletePDFDocTokenDetails(tokenDetails);
					}
					
					Logger.info("PDF generated successfully !!! ",this.getClass());
					
				}else{					
					Logger.info("Requested PDF token is expired...", this.getClass());									
					throw new BusinessException(BusinessException.SESSION_EXPIRED);
				}			    			
			}
			else {		
				Logger.info("pdfStatement service is unavailable...", this.getClass());		
				throw new BusinessException(BusinessException.ESTMT_SERVICE_UNAVILABLE);
			}
		}catch(BusinessException be){
			if(be.getKey() == BusinessException.PDF_STATEMENT_NOT_FOUND){

				try{					
					response.setContentType("application/pdf");
					response.setHeader("Content-Disposition","attachment;filename=NoStatement.pdf");					
					OutputStream os = response.getOutputStream();
			        byte[] buf = new byte[8192];			        
			        InputStream is = getServletContext().getResourceAsStream("/WEB-INF/pdf/"+mbAppHelper.getOrigin(request)+"/NoStatement.pdf");		        			        			        
			        int c = 0;
			        while ((c = is.read(buf, 0, buf.length)) > 0) {			        					        
			            os.write(buf, 0, c);
			            os.flush();
			        }		        
			        os.close();
			        is.close();
														       
				}catch(Exception e){
					errorCode = be.getKey();
					Logger.error("viewPdf stmt error ", this.getClass());
				}
				
			}else{
				errorCode = be.getKey();
			}
		}catch(ResourceException re){
			errorCode = re.getKey();						
		}catch (Exception ex) {
			ex.printStackTrace();						
			errorCode = BusinessException.GENERIC_ERROR;										
		}finally
		{
			perfLogger.endLog(logName);
			perfLogger.endAllLogs();
		}	
		
		if(errorCode != null){
			request.setAttribute("errorCode", errorCode);
			request.setAttribute(MBAppHelper.HTTP_ORIGIN_ATTRIBUTE,mbAppHelper.getOrigin(request));
			request.getRequestDispatcher("/jsp/error/serviceError.jsp").forward(request, response);
		}
				
		return null;
	}
	
	//To avoid the problem with spaces in Mozila
	private String trimInternalSpaces(String pdfName){
		int index = 0;
		while ((index = pdfName.indexOf(" ")) != -1) {
			pdfName = pdfName.substring(0, index)
			+ pdfName.substring(index + 1);
		}
		return pdfName;
	}	
	
	private Cookie getCookie(HttpServletRequest request) throws ResourceException
	{
		try
		{
			Cookie[] cookies = request.getCookies();
			Cookie cookie = null;			
			if (cookies != null)
			{
				for (int i = 0; i < cookies.length; i++)
				{
					if (cookies[i].getName().equals(MBAppConstants.SMPL_SESS_CONSTANT))
					{
							cookie = cookies[i]; 							
							Logger.info("Cookie " + cookie.getName() + " found in the request. Value : " + cookie.getValue() , this.getClass());							
						  break;
					}
				}
			}
			return cookie;
		}
		catch ( Exception e )
		{
			 e.printStackTrace();
			 return null;
		}	
	}
	
}
