package au.com.stgeorge.mbank.model.request.customer;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.NotEmpty;

import au.com.stgeorge.ibank.businessobject.BusinessException;
import au.com.stgeorge.mbank.model.common.IMBReq;
import au.com.stgeorge.mbank.model.common.ReqHeader;

public class HelpSearchStatReq implements IMBReq{

	private static final long serialVersionUID = -8619853234497299426L;
	
	private ReqHeader header;
	
	@NotNull(message = "" + BusinessException.WSVC_INVALID_INPUT_PARAM)
	private Integer id;
	
	private String helpName;
	
	private String searchText;
	
	public ReqHeader getHeader() {
		return header;
	}
	public void setHeader(ReqHeader header) {
		this.header = header;
	}
				
	public Integer getId() {
		return id;
	}
	
	public void setId(Integer id) {
		this.id = id;
	}
	
	public String getSearchText() {
		return searchText;
	}
	
	public void setSearchText(String searchText) {
		this.searchText = searchText;
	}
	
	public String getHelpName() {
		return helpName;
	}
	public void setHelpName(String helpName) {
		this.helpName = helpName;
	}
	public static long getSerialVersionUID() {
		return serialVersionUID;
	}

	
	private String statisticsType;
	private String acctIndex;

	public String getStatisticsType() {
		return statisticsType;
	}
	public void setStatisticsType(String statisticsType) {
		this.statisticsType = statisticsType;
	}
	public String getAcctIndex() {
		return acctIndex;
	}
	public void setAcctIndex(String acctIndex) {
		this.acctIndex = acctIndex;
	}
	  


}
