package au.com.stgeorge.mbank.model.request.customer;

import java.io.Serializable;

import au.com.stgeorge.mbank.model.common.IMBReq;
import au.com.stgeorge.mbank.model.common.ReqHeader;

public class DDAHeartBeatReq implements IMBReq, Serializable {
	private static final long serialVersionUID = 1L;

	private ReqHeader header;

	public ReqHeader getHeader() {
		return header;
	}

	public void setHeader(ReqHeader header) {
		this.header = header;
	}

	public static long getSerialVersionUID() {
		return serialVersionUID;
	}
}
