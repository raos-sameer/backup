package au.com.stgeorge.mbank.controller.newaccount;

import java.io.IOException;
import java.io.PrintWriter;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import au.com.stgeorge.framework.common.logging.Logger;
import au.com.stgeorge.ibank.businessobject.BusinessException;
import au.com.stgeorge.ibank.businessobject.CPCService;
import au.com.stgeorge.ibank.businessobject.ProductContentService;
import au.com.stgeorge.ibank.common.cache.IBankParams;
import au.com.stgeorge.ibank.valueobject.transfer.IBankCommonData;
import au.com.stgeorge.mbank.controller.IMBController;
import au.com.stgeorge.mbank.model.common.IMBReq;
import au.com.stgeorge.mbank.model.common.IMBResp;
import au.com.stgeorge.mbank.model.common.ReqHeader;
import au.com.stgeorge.mbank.model.common.RespHeader;
import au.com.stgeorge.mbank.model.request.newaccount.ProductContentCPCReq;
import au.com.stgeorge.mbank.model.request.newaccount.ProductContentReq;
import au.com.stgeorge.mbank.model.response.ErrorResp;
import au.com.stgeorge.mbank.model.response.newaccount.ProductContentCPCDetailResp;
import au.com.stgeorge.mbank.model.response.newaccount.ProductContentCPCResp;
import au.com.stgeorge.mbank.session.MobileSession;
import au.com.stgeorge.mbank.util.MBAppConstants;
import au.com.stgeorge.mbank.util.MBAppHelper;
import au.com.stgeorge.mbank.util.MBAppUtils;
import au.com.stgeorge.mbank.util.MBAppValidator;
import au.com.stgeorge.perflogger.PerformanceLogger;

import com.fasterxml.jackson.databind.ObjectMapper;

@Controller
@RequestMapping("/product")
public class ProductContentController implements IMBController {

	@Autowired
	private MBAppHelper mbAppHelper;
	
	@Autowired
	private MBAppValidator mbAppValidator;

	@Autowired
    private PerformanceLogger perfLogger;
	
	@Autowired
	private ProductContentService productContentService;
	
	@Autowired
	private CPCService cpcService;
	
	
	@RequestMapping(value = "content", method = RequestMethod.POST, headers = "content-type=application/json", produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public void getContents(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, @RequestBody final ProductContentReq request) {
		String logName = startPerformanceLog(httpServletRequest);
		MobileSession mbSession = null;
		PrintWriter outPrinter = null;
		ObjectMapper objectMapper = new ObjectMapper();	
		String msgContent = "";
		
		try {
		    mbSession = mbAppHelper.getMobileSession(httpServletRequest);
		    httpServletResponse.setContentType("text/html");
	    	outPrinter = httpServletResponse.getWriter();
			
		    ErrorResp errorResp = validate(request, httpServletRequest);
	    	if (errorResp != null && errorResp.getErrors() != null && !errorResp.getErrors().isEmpty()) {
	    		outPrinter.print("{} && " + objectMapper.writeValueAsString(errorResp));
	    	}
	    	
	    	validateProductContentReq(request);
	    	
	    	IBankCommonData commonData = mbAppHelper.populateIBankCommonData(mbSession, httpServletRequest);
			
	    	String origin = IBankParams.getBaseOriginCode(commonData.getOrigin());
	    	msgContent = productContentService.getPageContent(origin, request.getPageURL());
			msgContent = URLEncoder.encode(msgContent, StandardCharsets.UTF_8.name());//ISG : Sanitise msg before sending it to mobile
			
			outPrinter.print(msgContent);
	    } catch (BusinessException e) {
	    	Logger.error("Business Exception inside getContents() " + e.getKey(), e, this.getClass());			
	    	ErrorResp errorResp = MBAppUtils.createErrorResp(mbSession.getOrigin(), e, MBAppConstants.PRODUCT_RESP_NAME, httpServletRequest);
	    	try {
	    		outPrinter.print("{} && " + objectMapper.writeValueAsString(errorResp));
	    	} catch (IOException ex) {
				Logger.error("IO Exception inside getContents()", ex, this.getClass());
			}
	    } catch (Exception e) {
	    	Logger.error("Exception Inside getContents() for Customer GCIS: [" + ((mbSession != null && mbSession.getCustomer() != null) ? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
	    	BusinessException exp = new BusinessException(BusinessException.GENERIC_ERROR);
	    	ErrorResp errorResp = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, MBAppConstants.PRODUCT_RESP_NAME, httpServletRequest);
	    	try {
	    		outPrinter.print("{} && " + objectMapper.writeValueAsString(errorResp));
	    	} catch (IOException ex) {
				Logger.error("IO Exception inside getContents()", ex, this.getClass());
			}
	    } finally {
	    	endPerformanceLog(logName);
	    }
	}
	
	@Override
	public void validateRequestHeader(ReqHeader header, HttpServletRequest httpRequest) throws BusinessException {
		mbAppValidator.validateRequestHeader(header, httpRequest);
	}

	@Override
	public ErrorResp validate(IMBReq serviceRequest, HttpServletRequest httpRequest) throws BusinessException {
		return mbAppValidator.validate(serviceRequest, httpRequest);
	}

	@Override
	public RespHeader populateResponseHeader(String serviceName, MobileSession mobileSession) {
		return mbAppHelper.populateResponseHeader(serviceName, mobileSession);
	}

	private void validateProductContentReq(ProductContentReq request) throws BusinessException {
		if (StringUtils.isEmpty(request.getPageURL())) {
		   throw new BusinessException(BusinessException.GENERIC_ERROR);
		}
	}
	
	private void validateProductContentCPCReq(ProductContentReq request) throws BusinessException {
		if (StringUtils.isEmpty(request.getProductContentCPCReq())) {
		   throw new BusinessException(BusinessException.GENERIC_ERROR);
		}
	}

	private String startPerformanceLog(HttpServletRequest httpRequest) {
		perfLogger.startAllLogs();
		String logName = MBAppUtils.getLogName(httpRequest);
		perfLogger.startLog(logName);
		return logName;
    }

    private void endPerformanceLog(String logName) {
		perfLogger.endLog(logName);
		perfLogger.endAllLogs();
    }
    
    @RequestMapping(value = "cpcCode", method = RequestMethod.POST, headers = "content-type=application/json", produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public IMBResp getCPCCode(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, @RequestBody final ProductContentReq request) {
		String logName = startPerformanceLog(httpServletRequest);
		ObjectMapper objectMapper = new ObjectMapper();
		ProductContentCPCResp resp = new ProductContentCPCResp();
		MobileSession mbSession = null;
		try {
			mbSession = mbAppHelper.getMobileSession(httpServletRequest);	
			Logger.info("ProductContentController getCPCCode JSON Request :" + objectMapper.writeValueAsString(request), this.getClass());
			validateRequestHeader(request.getHeader(), httpServletRequest);
			ErrorResp errorResp = validate(request, httpServletRequest);
			if (errorResp != null && errorResp.getErrors() != null && errorResp.getErrors().size() > 0){				
				return errorResp;
			}
			validateProductContentCPCReq(request);
			IBankCommonData commonData = mbAppHelper.populateIBankCommonData(mbSession, httpServletRequest);
	    	RespHeader headerResp = populateResponseHeader(request.getHeader().getServiceName(), mbSession);
			if(null!= request.getProductContentCPCReq()){
				String baseOriginCode = IBankParams.getBaseOriginCode(commonData.getOrigin());
	    		List<ProductContentCPCDetailResp> cpcDetailsCodes = new ArrayList<>();
	    		for(ProductContentCPCReq cpcRequest : request.getProductContentCPCReq()){
	    			ProductContentCPCDetailResp cpcResponse = new ProductContentCPCDetailResp();
	    			cpcResponse.setAppId(cpcRequest.getAppId());
	    			cpcResponse.setSubProductCode(cpcRequest.getSubProductCode());
	    			cpcResponse.setCpcCode(cpcService.getCanonicalCodeFromBrandApplIdSubProdCode(baseOriginCode,cpcRequest.getAppId(), cpcRequest.getSubProductCode()));
	    			cpcDetailsCodes.add(cpcResponse);
	    		}
	    		resp.setCpcDetails(cpcDetailsCodes);	    		
	    	}else{
	    		Logger.info("ProductContentCPCReq is empty  ", this.getClass());
	    	}	
	    	resp.setHeader(headerResp);
	    } catch (BusinessException e) {
	    	Logger.error("Business Exception inside getCPCCode() " + e.getKey(), e, this.getClass());			
	    	ErrorResp errorResp = MBAppUtils.createErrorResp(mbSession.getOrigin(), e, MBAppConstants.PRODUCT_RESP_NAME, httpServletRequest);
	    	return errorResp;
	    } catch (Exception e) {
	    	Logger.error("Exception Inside getCPCCode() for Customer GCIS: [" + ((mbSession != null && mbSession.getCustomer() != null) ? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
	    	BusinessException exp = new BusinessException(BusinessException.GENERIC_ERROR);
	    	ErrorResp errorResp = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, MBAppConstants.PRODUCT_RESP_NAME, httpServletRequest);
	    	return errorResp;
	    } finally {
	    	endPerformanceLog(logName);
	    }
		return resp;
	}
    
}
