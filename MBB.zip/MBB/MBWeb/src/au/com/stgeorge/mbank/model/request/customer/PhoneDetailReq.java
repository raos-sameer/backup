package au.com.stgeorge.mbank.model.request.customer;

import java.util.ArrayList;

import javax.validation.Valid;

import au.com.stgeorge.mbank.model.common.IMBReq;
import au.com.stgeorge.mbank.model.common.PhoneReq;
import au.com.stgeorge.mbank.model.common.ReqHeader;

public class PhoneDetailReq implements IMBReq {
		private static final long serialVersionUID = 1L;

		@Valid
	 	private ArrayList <PhoneReq>  phones;
		
		private String devicePrint;

	  	public ArrayList<PhoneReq> getPhones() {
			return phones;
		}

		public void setPhones(ArrayList<PhoneReq> phones) {
			this.phones = phones;
		}

		private ReqHeader header;
	  	 
		@Override
		public ReqHeader getHeader() {
			return header;
		}

		@Override
		public void setHeader(ReqHeader header) {
			this.header = header;
		}
		
		public String getDevicePrint() {
			return devicePrint;
		}

		public void setDevicePrint(String devicePrint) {
			this.devicePrint = devicePrint;
		}		
}
