package au.com.stgeorge.mbank.controller;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.AbstractController;

import au.com.stgeorge.framework.common.logging.Logger;
import au.com.stgeorge.framework.common.util.StringMethods;
import au.com.stgeorge.ibank.businessobject.BusinessException;
import au.com.stgeorge.ibank.businessobject.ResourceException;
import au.com.stgeorge.ibank.businessobject.SystemInformation;
import au.com.stgeorge.ibank.businessobject.loanapplication.LoanApplicationService;
import au.com.stgeorge.ibank.common.cache.IBankParams;
import au.com.stgeorge.ibank.dao.DAOConstants;
import au.com.stgeorge.ibank.dao.IPreferenceDAO;
import au.com.stgeorge.ibank.dao.ViperDAOFactory;
import au.com.stgeorge.ibank.loanApplication.LoanApplicationDetail;
import au.com.stgeorge.ibank.util.CommonBusinessUtil;
import au.com.stgeorge.ibank.valueobject.database.CodesVO;
import au.com.stgeorge.ibank.valueobject.database.OriginsVO;
import au.com.stgeorge.ibank.valueobject.database.PreferenceVO;
import au.com.stgeorge.ibank.valueobject.transfer.IBankCommonData;
import au.com.stgeorge.mbank.controller.customer.LogonHelper;
import au.com.stgeorge.mbank.session.MobileSession;
import au.com.stgeorge.mbank.util.MBAppHelper;
import au.com.stgeorge.mbank.util.MBAppUtils;
import au.com.stgeorge.perflogger.PerformanceLogger;

public class ProductMainController extends AbstractController {
	
	private static final String GET_CASH_ENABLED = "1";
	private static final String TIMEOUT = "TIMEOUT";
	private static final String OFF = "OFF";
	private static final String ON = "ON";
	private static final String INITIAL_NAMEID = "initialNameid";
	private static final String PRODUCT_PAGE = "Product";
	private static final String INTER_PAGE = "InterProduct";
	private static final String INDEX_PAGE = "Index";
	private static final String PRELOAD_VALUE = "PreLoadParam";
	private static final String HELP_DESK_NO = "HelpDeskNo";
	private static final String ANDROID_BACK_BTN = "androidback";
	private static final String GET_CASH_INDICATOR = "getcashind";
	private static final String ONLINE_REG_SWITCH = "OnlineRegSwitch";	
	private static final String PWD_RESET_URL = "PwdResetURL";
	private static final String PWD_URL = "PwdURL";
	private static final String CAN_RETRIEVAL_URL = "CANRetrievalURL";
	private static final String PRODUCT_TO_BANK = "ProductToBank";
	private static final String BANK_TO_PRODUCT = "BankToProduct";
	private static final String ORIGIN_NAME = "OriginName";	
	
	private static final String REQ_PRODUCT = "PRODUCT";
	private static final String REQ_DASHBOARDBACK = "DASHBOARDBACK";
	private static final String REQ_ERROR = "ERROR";	
	private static final String REQ_IGNORE_SEC_FLAG =  "SIMPLE-LOGON";
	private static final String REQ_ACTION_TYPE = "ActionType";  // Used By GCC and BT Now...
	private static final String REQ_DIRECTION = "direction";
	private static final String REQ_NAME_ID = "nameId";
	private static final String REQ_PRODUCT_URL = "productUrl";
	private static final String REQ_CONTENT_ID = "contentId";
	private static final String REQ_LEAD_ID = "leadId";
	private static final String REQ_RETENTION_APPLICATION_TYPE = "retentionAppType";
	private static final String REQ_TT_ID = "ttid";
	private static final String REQ_P_ID = "pid";
	private static final String REQ_FORWARDED = "forwarded";
	private static volatile int numberOfRequests = 0;
		
	public static final String NUM_KEYBOARD_TYPE = "NumKeyBoardType";
	public static final String NUM_KEYBOARD_PATTERN_TYPE = "NumKeyBoardTypePattern";	
	public static final String SYS_VERSION = "SysVersion";
	public static final String WEB_CONTEXT = "WebContext";	
	
	public static final String PRODUCT_URL = "ProductURL";
	public static final String CONTENT_ID = "ContentId";
	public static final String TT_ID = "tid";
	public static final String P_ID = "pid";
	public static final String CAMPAIGN_CODE = "campaignCode";
	public static final String LEAD_ID = "LeadId";
	public static final String RETENTION_APPLICATION_TYPE = "RetentionAppType";
	public static final String NAME_ID = "NameId";
	public static final String RESOURCES_URL = "ResourcesURL";
	public static final String TAGGING_SWITCH = "TagingSwitch";
	public static final String PERSONALIZATION_SWITCH = "PersonalizationSwitch";
	public static final String LOCATION_ID = "locationId";
	
	public static final String REQ_ACTION_STR = "action";
	public static final String REQ_LOAD_CORDOVA = "LoadCordova";
	
	public static final String APPLY_GCC ="applyGCC";
	
	//19E4-AEM Retention campaign
	public static final String REQ_ACTION_ID = "ActionId";
	
	public static final String AEM_ADMIN_TEMPLATE_SWITCH = "AemAdminTemplateSwitch";
	public static final String SECURE_CHAT_ACTIVE_FLAG = "SecurechatActiveFlag";
	public static final String LPSITEID = "lpsiteid";
	
	@Autowired
	private LogonHelper logonHelper;	

	@Autowired
	private SystemInformation systemInformation;
	
	@Autowired
    private PerformanceLogger perfLogger;
	
	@Autowired
	private MBAppHelper mbAppHelper;

	@Autowired
	private LoanApplicationService loanApplService;
	
	@Override
	protected ModelAndView handleRequestInternal(HttpServletRequest request, HttpServletResponse response) throws Exception {
		String logName = startPerformanceLog(request);
				
		ModelAndView model = null;
		String origin = null;
		MobileSession mobileSession = null;
		
		Logger.info("Starting Product request" , this.getClass());
		
		try {
			numberOfRequests++;
			
			mobileSession = mbAppHelper.getMobileSession(request);
			origin = LogonHelper.resolveOrigin(request);
			setRequestCommonAttributes(request, origin);
			
			String action = request.getParameter(REQ_ACTION_STR);
			if (action != null && action.equalsIgnoreCase(TIMEOUT)) {				
				model = new ModelAndView(INDEX_PAGE);				
				request.setAttribute(REQ_ACTION_STR, action);
				
				Logger.info("Timeout in Main Product Controller", this.getClass());
				return model;
			} else {
				Logger.info("mobileSession : " + mobileSession ,this.getClass());
				//validate session only if it is not coming from timeout
				if (mobileSession == null || mobileSession.getSecurityUniqueID() == null) {
					Logger.info("mobileSession.getSecurityUniqueID: " + mobileSession.getSecurityUniqueID() ,this.getClass());
					model = new ModelAndView(INDEX_PAGE);				
					request.setAttribute(REQ_ACTION_STR, REQ_ERROR);
					
					Logger.info("Error in Main Product Controller - session or nameId null", this.getClass());
					return model;
				} 
			}
						
			if (StringMethods.isEmptyString(origin)) {
				origin = "MSTG";
				request.setAttribute(LogonHelper.ORIGIN, origin);
				Logger.info(
					"Unable to resolve the origin for Online Registration Request Details. URL : " + request.getRequestURL() + " IP :"
						+ request.getRemoteAddr() + " Number Of Requests : " + numberOfRequests + 
						" True IP >> " + request.getHeader(IBankParams.trueClientIP()), this.getClass());
				model = new ModelAndView(INDEX_PAGE);				
				request.setAttribute(REQ_ACTION_STR, REQ_ERROR);				
		    } else {
		    	model = getModel(request, mobileSession, origin);
				
				if (model == null) {
					model = new ModelAndView(INDEX_PAGE);				
					request.setAttribute(REQ_ACTION_STR, REQ_ERROR);
					
					Logger.info("Error in Main Product Controller - settings incorrect. Check nameId and direction ", this.getClass());
					return model;
				}
				
				Logger.debug("Loading " + model.getViewName() + " page... "
								+ request.getRequestURL() + " IP :"
								+ request.getRemoteAddr() +
								" True IP >> " + request.getHeader(IBankParams.trueClientIP()), this.getClass());
		    }
			
			//Setting switch values for Secure chat
			String lpMessagingSwitch = "OFF";
			CodesVO codesVO = IBankParams.getCodesData(IBankParams.getBaseOriginCode(origin),	IBankParams.CONFIGURATION_PROPERTIES, IBankParams.LP_MESSAGING_SWITCH);
			if ( (codesVO == null) || codesVO != null  && "ON".equalsIgnoreCase(codesVO.getMessage())){
				lpMessagingSwitch = "ON";
			}
			request.setAttribute(MainController.LP_MESSAGING_SWITCH, lpMessagingSwitch);
			
			Cookie appVersionCookie = CommonBusinessUtil.getCookie(request, IBankParams.APP_VER_COOKIE);
			Boolean isLpOldAppVersion = !CommonBusinessUtil.cookieContainsValue(appVersionCookie, MainController.CHAT);
			if(isLpOldAppVersion) {
				request.setAttribute(MainController.LP_NATIVE_OLD_APP_SWITCH, IBankParams.ON);
			}else {
				request.setAttribute(MainController.LP_NATIVE_OLD_APP_SWITCH, IBankParams.OFF);
			}
			request.setAttribute(SECURE_CHAT_ACTIVE_FLAG, IBankParams.OFF);
			if (null != mobileSession.getCustomer() && null != mobileSession.getCustomer().getGcis()) {
				IPreferenceDAO myPrefDAO = (IPreferenceDAO) ViperDAOFactory.getDAO(DAOConstants.PREFERENCEDAO);
				PreferenceVO myPrefVO = myPrefDAO.get(mobileSession.getCustomer().getGcis());
				if (myPrefVO.getSecureChatStatus() == 1) {
					request.setAttribute(SECURE_CHAT_ACTIVE_FLAG, IBankParams.ON);
				}
			}
			
			request.setAttribute(LPSITEID, IBankParams.getLpSiteId(origin));
			
			return model;
		} catch (Exception e) {
			model = new ModelAndView(INDEX_PAGE);				
			request.setAttribute(REQ_ACTION_STR, REQ_ERROR);
			
			Logger.error("Error in Main Product Controller " , e, this.getClass());
			return model;
		} finally {
			numberOfRequests--;
			endPerformanceLog(logName);			
		}
	}

	private void setRequestCommonAttributes(HttpServletRequest request, String origin) {
		request.setAttribute(LogonHelper.ORIGIN, origin);
		request.setAttribute(NUM_KEYBOARD_TYPE, logonHelper.getNumKeyBoardType(request));
		request.setAttribute(NUM_KEYBOARD_PATTERN_TYPE, logonHelper.getNumKeyBoardPattern(request));
		request.setAttribute(WEB_CONTEXT, logonHelper.getMBWebResourceContext());
		request.setAttribute(PRELOAD_VALUE, 2);  // Complete
		request.setAttribute(REQ_IGNORE_SEC_FLAG, IBankParams.NO);
		request.setAttribute(SYS_VERSION, this.systemInformation.getMB3PackageVersion());
		
		int loadCordova = logonHelper.loadCordova(request);
		request.setAttribute(REQ_LOAD_CORDOVA, String.valueOf(loadCordova));
		
		String contentId = (String) request.getParameter(REQ_CONTENT_ID);		
		if (!StringMethods.isEmptyString(contentId)) {
			request.setAttribute(CONTENT_ID, contentId);
		}
		String ttid = (String) request.getParameter(REQ_TT_ID);		
		if (!StringMethods.isEmptyString(ttid)) {
			request.setAttribute(TT_ID, ttid);
		}	
		String pid = (String) request.getParameter(REQ_P_ID);		
		if (!StringMethods.isEmptyString(pid)) {
			request.setAttribute(P_ID, pid);
		}
		String campaignCode = (String) request.getParameter(CAMPAIGN_CODE);		
		if (!StringMethods.isEmptyString(campaignCode)) {
			request.setAttribute(CAMPAIGN_CODE, campaignCode);
		}
		String locationId = (String) request.getParameter(LOCATION_ID);		
		if (!StringMethods.isEmptyString(locationId)) {
			request.setAttribute(LOCATION_ID, locationId);
		}
		String leadId = (String) request.getParameter(REQ_LEAD_ID);		
		if (!StringMethods.isEmptyString(leadId)) {
			request.setAttribute(LEAD_ID, leadId);
		}		
		String retentionAppType = (String) request.getParameter(REQ_RETENTION_APPLICATION_TYPE);		
		if (!StringMethods.isEmptyString(retentionAppType)) {
			request.setAttribute(RETENTION_APPLICATION_TYPE, retentionAppType);
		}	
	}
	
	private String getResourceURL(String baseOrigin) {
		String resourcesURL = "";		
		CodesVO baseUrlCodesVO = IBankParams.getCodesData(baseOrigin, IBankParams.FEATURES, IBankParams.RESOURCES_URL);
		
		if (baseUrlCodesVO != null && baseUrlCodesVO.getMessage() != null) {
			resourcesURL =  baseUrlCodesVO.getMessage().trim();
		}
		
		return resourcesURL;
	}

	private ModelAndView getModel(HttpServletRequest request, MobileSession mobileSession, String origin) {
		String direction = (String) request.getParameter(REQ_DIRECTION);
		String forwarded = (String) request.getParameter(REQ_FORWARDED);
		ModelAndView model = null;
		Logger.debug("ProductMainController Direction: " + direction, this.getClass());
		IBankCommonData commonData = mbAppHelper.populateIBankCommonData(mobileSession,request);
		if (direction != null && direction.equals(BANK_TO_PRODUCT)) {
			if (forwarded != null) {
				model = new ModelAndView(PRODUCT_PAGE);
			} else {
				model = new ModelAndView(INTER_PAGE);
			}
			setRequestAttributesBankToProduct(request, mobileSession, origin);		
			Logger.debug("Loading Product...", this.getClass());			
		} else if (direction != null && direction.equals(PRODUCT_TO_BANK)) {
			
			String actionType = request.getParameter(REQ_ACTION_TYPE);
			
			if(StringMethods.isEmptyString(actionType)) {
				//RemoveCampaignLeadID from the session (For Reject offer flow or normal back to dashboard flow)
				mobileSession.removeRetentionCampaignLead();				
			}
			
			Logger.debug("ActionType & Origin : "+actionType+origin, this.getClass());
			if(APPLY_GCC.equalsIgnoreCase(actionType) ) 
			{
				if ( IBankParams.isGCCMasterCardOriginationSwitchOn(commonData.getOrigin(), commonData.getCustomer().getGcis())) {
					Logger.debug("Redirecting to launch action...", this.getClass());
					model = new ModelAndView("redirect:" + "launch?app=GCCOrigination");
					return model;
				}
				else
				{
					Logger.debug("Redirecting to return Dashboard action. GCIS : " + commonData.getCustomer().getGcis() , this.getClass());
					model = new ModelAndView("redirect:" + "return");
					return model;
				}
			}
			
			if (forwarded != null) {
				model = getModelProductToBank(request, mobileSession);				
			} else {
				model = new ModelAndView(INTER_PAGE);
			}		

			setRequestAttributesProductToBank(request, origin);	
			Logger.debug("Loading MBank...", this.getClass());		
		} else if(direction == null){
			/*20E1 Spike for navigating back to Compass from Ace*/
			String actionType = request.getParameter(REQ_ACTION_TYPE);
			if(!StringMethods.isEmptyString(actionType) && ("aceToCompass".equalsIgnoreCase(actionType))){
				setRequestAttributesProductToBank(request, origin);	
				model = redirectFromAceDeeplink(request, mobileSession, actionType);
			}
		}
		else {
			Logger.debug("Invalid direction or action received: " + direction, this.getClass());
		}
		
		return model;
	}

	private ModelAndView redirectFromAceDeeplink(HttpServletRequest request, MobileSession mobileSession, String actionType) {
		Logger.debug("Inside method redirectFromAceDeeplink with actionType :"+actionType, this.getClass());
		ModelAndView model;
		/*--> Check for the parameter in mbsession --> if it is present then only proceed --> else throw an error and restrict the login*/
		IBankCommonData commonData = mbAppHelper.populateIBankCommonData(mobileSession,request);
		LoanApplicationDetail loanAppDetail = null;
		try {
			loanAppDetail = loanApplService.getLoanApplicationDetails(commonData);
			if(loanApplService.redirectToZoom2FASecurePage(commonData,loanAppDetail)){
				Logger.info("Redirect to secure page 2FA",  this.getClass());
				mobileSession.setLoanApplicationDetail(loanAppDetail);
				actionType = "sPlsecpage";
			}else{
				Logger.info("Redirect to dashboard",  this.getClass());
				actionType = "dashboard";
			}
		}catch (Exception e) {
			Logger.error("Exception",e,this.getClass());		
		}
		request.setAttribute(REQ_ACTION_TYPE, actionType);
		model = new ModelAndView(INDEX_PAGE);
		Logger.debug("End of method redirectFromAceDeeplink", this.getClass());
		return model;
	}

	private void setRequestAttributesProductToBank(HttpServletRequest request, String origin) {		
		request.setAttribute(REQ_ACTION_STR, REQ_DASHBOARDBACK);
		
		//actionType is used for deeplinks
		String actionType = request.getParameter(REQ_ACTION_TYPE);
		if (!StringMethods.isEmptyString(actionType)) {
			request.setAttribute(REQ_ACTION_TYPE, actionType);
		}
		
		//19E4- AEM - Retention
		String actionID = request.getParameter(REQ_ACTION_ID);
		if (!StringMethods.isEmptyString(actionID)) {
			request.setAttribute(REQ_ACTION_ID, actionID);
		}
		//19E4- AEM - Retention
		String leadId = request.getParameter(REQ_LEAD_ID);
		if (!StringMethods.isEmptyString(leadId)) {
			request.setAttribute(REQ_LEAD_ID, leadId);
		}
		
		String campaignCode = (String) request.getParameter(CAMPAIGN_CODE);		
		if (!StringMethods.isEmptyString(campaignCode)) {
			request.setAttribute(CAMPAIGN_CODE, campaignCode);
		}
		
		if (logonHelper.isCardlessTokenSupported(request)) {
			request.setAttribute(GET_CASH_INDICATOR , GET_CASH_ENABLED);
		}
		
		String onlineRegSwitch = ON;
		CodesVO codesVO = IBankParams.getCodesData(origin,	IBankParams.CONFIGURATION_PROPERTIES, IBankParams.ONLINE_REG_SWITCH);
		if (codesVO != null && OFF.equalsIgnoreCase(codesVO.getMessage())) {
			onlineRegSwitch = OFF;
		}
		request.setAttribute(ONLINE_REG_SWITCH, onlineRegSwitch);
		//20E3 UI Switch clean up starts
		/*String androidBackButtonSwitch = OFF;
		if(logonHelper.isAndroidBackBtnSupported(request) && IBankParams.isSwitchOn(IBankParams.ANDROID_BACKBUTTON_SWITCH)){
			androidBackButtonSwitch = ON;
		}
		request.setAttribute(ANDROID_BACK_BTN, androidBackButtonSwitch);*/
		//20E3 UI Switch clean up end
		
		OriginsVO originVO = IBankParams.getOrigin(origin);		
		if (originVO != null) {
			if (originVO.getName() != null) {
				request.setAttribute(ORIGIN_NAME, originVO.getName());
			}
			
			if (originVO.getPhone() != null) {
				request.setAttribute(HELP_DESK_NO, originVO.getPhone());		
			}
			
			if (originVO.getBankName() != null) {		
				String pwdResetUrl = IBankParams.getCodesData(originVO.getBankName(), IBankParams.EXTERNAL_LINKS, PWD_URL).getMessage();	
				request.setAttribute(PWD_RESET_URL, pwdResetUrl);
				
				String canRetrievalUrl = IBankParams.getCodesData( originVO.getBankName(), IBankParams.EXTERNAL_LINKS, CAN_RETRIEVAL_URL).getMessage();
				request.setAttribute(CAN_RETRIEVAL_URL, canRetrievalUrl);
			}
		}
	}

	private ModelAndView getModelProductToBank(HttpServletRequest request, MobileSession mobileSession) {
		String nameId = (String) request.getParameter(REQ_NAME_ID);
		Logger.debug("nameId from Request : "+ nameId  , this.getClass());
		Logger.debug("nameId in ProductMainController mobileSession.getSecurityUniqueID() : "+ mobileSession.getSecurityUniqueID()  , this.getClass());
		//validating the nameId that was sent to Product when it was loaded is the same as the one sent back from Product
		if (nameId == null || !nameId.equalsIgnoreCase(mobileSession.getSecurityUniqueID())) {
			Logger.debug("nameId (" + nameId + ") is different from session secure unique id (" 
					     + mobileSession.getSecurityUniqueID() + ")", this.getClass());
	
			return null;
		}
		
		//cleaning the name id in session once logon will be called again to display dashboard
		mobileSession.setSecurityUniqueID(INITIAL_NAMEID);
		
		return new ModelAndView(INDEX_PAGE);
	}

	private void setRequestAttributesBankToProduct(HttpServletRequest request, MobileSession mobileSession, String origin) {
		request.setAttribute(REQ_ACTION_STR, REQ_PRODUCT);
		request.setAttribute(NAME_ID, mobileSession.getSecurityUniqueID());
		request.setAttribute(WEB_CONTEXT, PRODUCT_PAGE.toLowerCase());
		request.setAttribute(PERSONALIZATION_SWITCH, IBankParams.isAdobeTaggingSwitchSwitchOn(origin));
		request.setAttribute(AEM_ADMIN_TEMPLATE_SWITCH, IBankParams.isSwitchOn(IBankParams.AEM_ADMIN_TEMPLATE_SWITCH));
		
		String productURL = (String) request.getParameter(REQ_PRODUCT_URL);	
		if (productURL != null) {
			request.setAttribute(PRODUCT_URL, productURL);
		} else {
			CodesVO productLandingPage = IBankParams.getCodesData(origin, IBankParams.PRODUCT_CONTENT, IBankParams.LANDING_URL);
			if (productLandingPage != null && productLandingPage.getMessage() != null) {
				request.setAttribute(PRODUCT_URL, productLandingPage.getMessage());
			}
		}	
		
		String baseOrigin = IBankParams.getBaseOriginCode(origin);
		if (baseOrigin != null) {
			request.setAttribute(RESOURCES_URL, getResourceURL(baseOrigin));
		}
	}
	
	private String startPerformanceLog(HttpServletRequest httpRequest) {
		perfLogger.startAllLogs();
		String logName = MBAppUtils.getLogName(httpRequest);
		perfLogger.startLog(logName);
		return logName;
    }

    private void endPerformanceLog(String logName) {
		perfLogger.endLog(logName);
		perfLogger.endAllLogs();
    }
}
