package au.com.stgeorge.mbank.model.common;

import java.io.Serializable;

import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.NotEmpty;

import au.com.stgeorge.ibank.businessobject.BusinessException;
import au.com.stgeorge.mbank.util.ServiceConstants;


public class RespHeader implements Serializable{

	private static final long serialVersionUID = 5297519451570513390L;	
	
	@NotEmpty (message = ""+BusinessException.WSVC_INVALID_INPUT_PARAM)
	@Size(max = 10,message = ServiceConstants.INVALID_INPUT_PARAMS)
	@Pattern(regexp="([0-9\\.]+)",message = ServiceConstants.INVALID_INPUT_PARAMS)	
	protected String clientApiVersion;

	public String getClientApiVersion() {
		return clientApiVersion;
	}

	public void setClientApiVersion(String clientApiVersion) {
		this.clientApiVersion = clientApiVersion;
	}
	
	
	/*
	@NotEmpty (message = ""+BusinessException.WSVC_INVALID_INPUT_PARAM)
	//@Size(max = 10,message = ServiceConstants.INVALID_INPUT_PARAMS)
	@Pattern(regexp="([a-zA-Z0-9]+)",message = ""+BusinessException.WSVC_INVALID_INPUT_PARAM)
	private String nameId;

	public String getNameId()
	{
		return nameId;
	}

	public void setNameId(String nameId)
	{
		this.nameId = nameId;
	}
 */

	@NotEmpty (message = ""+BusinessException.WSVC_INVALID_INPUT_PARAM)
	//@Size(max = 10,message = ServiceConstants.INVALID_INPUT_PARAMS)
	@Pattern(regexp="([a-zA-Z0-9]+)",message = ""+BusinessException.WSVC_INVALID_INPUT_PARAM)
	protected String serviceName;

	public String getServiceName()
	{
		return serviceName;
	}

	public void setServiceName(String serviceName)
	{
		this.serviceName = serviceName;
	}

	@NotEmpty (message = ""+BusinessException.SMPL_INV_INP_PARAMS)
	@Size(max = 100,message = ""+BusinessException.SMPL_INV_INP_PARAMS)
	@Pattern(regexp="([a-zA-Z0-9-]+)",message = ""+BusinessException.SMPL_INV_INP_PARAMS)	
	protected String nameId;

	public String getNameId()
	{
		return nameId;
	}

	public void setNameId(String nameId)
	{
		this.nameId = nameId;
	}

	
	

}
