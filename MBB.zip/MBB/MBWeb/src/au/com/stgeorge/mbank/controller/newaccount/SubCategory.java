package au.com.stgeorge.mbank.controller.newaccount;


import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlElement;

@XmlRootElement(name = "SubCategory")
@XmlAccessorType(XmlAccessType.FIELD)
public class SubCategory
{
	@XmlAttribute
	private String type;
	
	@XmlElement(name="Name")
	private String code;
	
	@XmlElement(name="Display")
	private String name;	
	
	@XmlElement(name="Text")
	private String text;	
	
	@XmlElement(name="Group")
	private String group;	
	
	private String id;	
	
	@XmlElement(name="ClientId")
	private String clientId;
	
	
	public String getClientId()
	{
		return clientId;
	}

	public void setClientId(String clientId)
	{
		this.clientId = clientId;
	}

	public String getText()
	{
		return text;
	}

	public void setText(String text)
	{
		this.text = text;
	}


	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public SubCategory()
	{
	}

	public SubCategory(String type, String code, String name, 
			String text, String group, String id, String clientId)
	{
		super();
		this.type = type;
		this.code = code;
		this.name = name;
		this.text = text;
		this.group = group;
		this.id = id;
		this.clientId = clientId;
	}

	public String getCode()
	{
		return code;
	}

	public void setCode(String code)
	{
		this.code = code;
	}

	public String getType()
	{
		return type;
	}

	public void setType(String type)
	{
		this.type = type;
	}

	public String getGroup() {
		return group;
	}

	public void setGroup(String group) {
		this.group = group;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

}

