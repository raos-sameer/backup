package au.com.stgeorge.mbank.model.accountinfo;

import java.util.Date;

import au.com.stgeorge.mbank.util.JsonDateSerializer;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;


/**
 * @author C50216
 *
 */
@JsonInclude(Include.NON_NULL)
public class CRAAccountDetailResp{

	private Date nextPaymentDate;
	private String payNowAmt;
	private String stmtBalanceAmt;
	private Date lastStmtDate;
	private String lastPaymentAmt;
	private Date lastPaymentDate;	
	private String cashAdvanceRate;
	private Boolean needsActivation=false;
	private Boolean isTransferred=false;
	private int replacementAccountIndex = -1;
	private String creditLimitAmt;
	private String availCredit;	
	private Boolean hasClientConsent=false;
	private RewardDetailResp rewardDetail;
	private OfferDetailResp offerDetail;
	private Boolean allowCreditLimitDec=false;
	
	@JsonSerialize(using = JsonDateSerializer.class)
	@JsonInclude(Include.NON_NULL)
	public Date getNextPaymentDate() {
		return nextPaymentDate;
	}
	public void setNextPaymentDate(Date nextPaymentDate) {
		this.nextPaymentDate = nextPaymentDate;
	}
	public String getPayNowAmt() {
		return payNowAmt;
	}
	public void setPayNowAmt(String payNowAmt) {
		this.payNowAmt = payNowAmt;
	}
	public String getStmtBalanceAmt() {
		return stmtBalanceAmt;
	}
	public void setStmtBalanceAmt(String stmtBalanceAmt) {
		this.stmtBalanceAmt = stmtBalanceAmt;
	}
	
	@JsonSerialize(using = JsonDateSerializer.class)
	@JsonInclude(Include.NON_NULL)
	public Date getLastStmtDate() {
		return lastStmtDate;
	}
	public void setLastStmtDate(Date lastStmtDate) {
		this.lastStmtDate = lastStmtDate;
	}
	public String getLastPaymentAmt() {
		return lastPaymentAmt;
	}
	public void setLastPaymentAmt(String lastPaymentAmt) {
		this.lastPaymentAmt = lastPaymentAmt;
	}
	
	@JsonSerialize(using = JsonDateSerializer.class)
	@JsonInclude(Include.NON_NULL)
	public Date getLastPaymentDate() {
		return lastPaymentDate;
	}
	public void setLastPaymentDate(Date lastPaymentDate) {
		this.lastPaymentDate = lastPaymentDate;
	}
	
	public String getCashAdvanceRate() {
		return cashAdvanceRate;
	}
	public void setCashAdvanceRate(String cashAdvanceRate) {
		this.cashAdvanceRate = cashAdvanceRate;
	}
	public Boolean isNeedsActivation() {
		return needsActivation;
	}
	public void setNeedsActivation(Boolean needsActivation) {
		this.needsActivation = needsActivation;
	}
	public Boolean getIsTransferred() {
		return isTransferred;
	}
	public void setIsTransferred(Boolean isTransferred) {
		this.isTransferred = isTransferred;
	}
	@JsonSerialize(include = JsonSerialize.Inclusion.NON_DEFAULT)
	public int getReplacementAccountIndex() {
		return replacementAccountIndex;
	}
	public void setReplacementAccountIndex(int replacementAccountIndex) {
		this.replacementAccountIndex = replacementAccountIndex;
	}
	public String getCreditLimitAmt() {
		return creditLimitAmt;
	}
	public String getAvailCredit() {
		return availCredit;
	}
	public void setAvailCredit(String availCredit) {
		this.availCredit = availCredit;
	}
	public void setCreditLimitAmt(String creditLimitAmt) {
		this.creditLimitAmt = creditLimitAmt;
	}
	public Boolean isHasClientConsent() {
		return hasClientConsent;
	}
	public void setHasClientConsent(Boolean hasClientConsent) {
		this.hasClientConsent = hasClientConsent;
	}
	public RewardDetailResp getRewardDetail() {
		return rewardDetail;
	}
	public void setRewardDetail(RewardDetailResp rewardDetail) {
		this.rewardDetail = rewardDetail;
	}
	public OfferDetailResp getOfferDetail() {
		return offerDetail;
	}
	public void setOfferDetail(OfferDetailResp offerDetail) {
		this.offerDetail = offerDetail;
	}
	public Boolean getAllowCreditLimitDec() {
		return allowCreditLimitDec;
	}
	public void setAllowCreditLimitDec(Boolean allowCreditLimitDec) {
		this.allowCreditLimitDec = allowCreditLimitDec;
	}
	

}
