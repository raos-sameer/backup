package au.com.stgeorge.mbank.model.common;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_NULL)
public class InvitationInfoReq implements IMBReq {
	/**
	 * 
	 */
	private static final long serialVersionUID = -305194663553364108L;
	/**
	 * 
	 */


	private String productType;
	
	private ReqHeader header;
	
	public String getProductType() {
		return productType;
	}
	public void setProductType(String productType) {
		this.productType = productType;
	}
	
	public ReqHeader getHeader()
	{
		return header;
	}

	public void setHeader(ReqHeader header)
	{
		this.header = header;
	}

	

}
