package au.com.stgeorge.mbank.model.request.payments;

import java.io.Serializable;

import javax.validation.constraints.NotNull;

import au.com.stgeorge.ibank.businessobject.BusinessException;
import au.com.stgeorge.mbank.model.common.IMBReq;
import au.com.stgeorge.mbank.model.common.ReqHeader;

public class SchedulePaymentReq implements IMBReq, Serializable{

	/**
	 * 
	 */
	
	private static final long serialVersionUID = -5058686090511235204L;
	
	private ReqHeader header;
	
	@NotNull(message = "" + BusinessException.WSVC_INVALID_INPUT_PARAM)
	private Integer scheduleId;
	
	public ReqHeader getHeader() {
		return header;
	}

	public void setHeader(ReqHeader header) {
		this.header = header;
	}

	public Integer getScheduleId() {
		return scheduleId;
	}

	public void setScheduleId(Integer scheduleId) {
		this.scheduleId = scheduleId;
	}
		
}
