package au.com.stgeorge.mbank.controller.newaccount;

import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "MsgCategory")
@XmlAccessorType(XmlAccessType.FIELD)
public class MsgCategory
{	
	@XmlAttribute
	private String name;
	
	@XmlElement(name="MsgSubCategory")
	private List<MsgSubCategory> msgSubCategories;
	
	@XmlAttribute
	private String type;
	

	public String getName() {
  	return name;
  }

	public void setName(String name) {
  	this.name = name;
  }

	public List<MsgSubCategory> getMsgSubCategories() {
  	return msgSubCategories;
  }

	public void setMsgSubCategories(List<MsgSubCategory> msgSubCategories) {
  	this.msgSubCategories = msgSubCategories;
  }

	public String getType() {
  	return type;
  }

	public void setType(String type) {
  	this.type = type;
  }

	public MsgCategory()
	{
		super();
	}

	public MsgCategory(String name,List<MsgSubCategory> msgSubCategories)
	{
		
		super();
		this.name = name;
		this.msgSubCategories = msgSubCategories;
	}



	
}


 



