/**
 * 
 */
package au.com.stgeorge.mbank.controller.payments;

import java.math.BigDecimal;
import java.util.Collection;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;

import au.com.stgeorge.framework.common.logging.Logger;
import au.com.stgeorge.ibank.businessobject.BusinessException;
import au.com.stgeorge.ibank.businessobject.NPPPaymentStatusService;
import au.com.stgeorge.ibank.businessobject.PaymentService;
import au.com.stgeorge.ibank.businessobject.ResourceException;
import au.com.stgeorge.ibank.common.cache.IBankParams;
import au.com.stgeorge.ibank.util.StringUtil;
import au.com.stgeorge.ibank.valueobject.Account;
import au.com.stgeorge.ibank.valueobject.BPayPayment;
import au.com.stgeorge.ibank.valueobject.Biller;
import au.com.stgeorge.ibank.valueobject.Customer;
import au.com.stgeorge.ibank.valueobject.PaymentsLog;
import au.com.stgeorge.ibank.valueobject.Receipt;
import au.com.stgeorge.ibank.valueobject.ThirdParty;
import au.com.stgeorge.ibank.valueobject.ThirdPartyPayment;
import au.com.stgeorge.ibank.valueobject.database.PaymentsLogVO;
import au.com.stgeorge.ibank.valueobject.transfer.IBankCommonData;
import au.com.stgeorge.mbank.controller.IMBController;
import au.com.stgeorge.mbank.model.common.IMBReq;
import au.com.stgeorge.mbank.model.common.IMBResp;
import au.com.stgeorge.mbank.model.common.ReqHeader;
import au.com.stgeorge.mbank.model.common.RespHeader;
import au.com.stgeorge.mbank.model.request.payments.PaymentLogStatusReq;
import au.com.stgeorge.mbank.model.response.ErrorResp;
import au.com.stgeorge.mbank.model.response.SuccessResp;
import au.com.stgeorge.mbank.model.response.payments.EmailPaymentReceiptReq;
import au.com.stgeorge.mbank.model.response.payments.HistoryReceiptReq;
import au.com.stgeorge.mbank.model.response.payments.HistoryReceiptResp;
import au.com.stgeorge.mbank.model.response.payments.PayeesAndBillersListResp;
import au.com.stgeorge.mbank.model.response.payments.SchedulePaymentResp;
import au.com.stgeorge.mbank.session.MobileSession;
import au.com.stgeorge.mbank.util.FraudLogger;
import au.com.stgeorge.mbank.util.MBAppHelper;
import au.com.stgeorge.mbank.util.MBAppUtils;
import au.com.stgeorge.mbank.util.MBAppValidator;
import au.com.stgeorge.mbank.util.ServiceConstants;
import au.com.stgeorge.mobilebank.businessobject.PayHistoryService;
import au.com.stgeorge.mobilebank.businessobject.TransactService;
import au.com.stgeorge.perflogger.PerformanceLogger;

import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * @author C50216
 *
 */
@Controller
public class HistoryReceiptController implements IMBController{

private FraudLogger fraudLogger;
	
	@Autowired
	private HistoryReceiptHelper historyReceiptHelper;
	
	@Autowired
	private MBAppHelper mbAppHelper;
	
	@Autowired
	private MBAppValidator mbAppValidator;
		
	@Autowired
	private PayHistoryService payHistoryService;
	
	@Autowired
	private PerformanceLogger perfLogger;
	
	@Autowired
	private TransactService transactService;
	
	@Autowired
	private NPPPaymentStatusService nPPPaymentStatusService;
	
	@Autowired
	private PayeeHelper payeeHelper;
	
	public enum TransTypeEnum {
	//	BPAY("BPAY"),
	//	BPAYV("BPAYV"),
		TP("TP"), 
		TPB("TPB"),
		TPC("TPC"),
		TPMB("TPMB"),
		TPMBI("TPMBI"),
		TPCO("TPCO"),
		TPBO("TPBO"),
		TPCR("TPCR"),
		TPBR("TPBR"),
		TPBI("TPBI"),
		TPCI("TPCI"); 
		private String value;
		private TransTypeEnum(String value) {
			this.value = value;
		}
		public String getValue() {
			return value;
		}
	};
	
	
	@RequestMapping(value = "historyreceipt", method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public IMBResp processHistoryReceipt(HttpServletRequest httpServletRequest,HttpServletResponse httpServletResponse,
			@RequestBody final HistoryReceiptReq req){ 
				
		ObjectMapper objectMapper = new ObjectMapper();					
						
		
		perfLogger.startAllLogs();
		String logName = MBAppUtils.getLogName(httpServletRequest);
		perfLogger.startLog(logName);		
		fraudLogger = new FraudLogger();		
		MobileSession mbSession = null;
		try{
			mbSession = mbAppHelper.getMobileSession(httpServletRequest);
			Logger.info("History Receipt JSON Request :" + objectMapper.writeValueAsString(req), this.getClass());
			validateRequestHeader(req.getHeader(), httpServletRequest);
			ErrorResp errorResp = validate(req, httpServletRequest);
					
			if (errorResp != null && errorResp.getErrors() != null && errorResp.getErrors().size() > 0)
			{				
				//fraudLogger.logInvalidInput();
				return errorResp;
			}			
																		
			Customer customer = mbSession.getCustomer();
									
			IBankCommonData commonData=mbAppHelper.populateIBankCommonData(mbSession,httpServletRequest);
			//17E2 Service Interaction and Cross Sell -- Updating the GDW description if originated from Transaction Cross Sell
			String application = null;
			if(req.getFromCrossSell()){
				application = IBankParams.TNX_CROSSSELL;
			}
			
			Collection<PaymentsLog> paymentsLog = payHistoryService.searchLast30Days(commonData, application);
									
			IMBResp serviceResponse = historyReceiptHelper.populateResp(paymentsLog,customer);
			
			RespHeader headerResp = populateResponseHeader(ServiceConstants.HISTORY_RECEIPT_SERVICE, mbSession);
			serviceResponse.setHeader(headerResp);
			
			try{
				PayeesAndBillersListResp resp = payeeHelper.populateAllTypePayeesList(commonData, customer);
				
				HistoryReceiptResp receiptResp = (HistoryReceiptResp) serviceResponse;
				receiptResp.setThirdPartyPayees(resp.getThirdPartyPayees());
				receiptResp.setBillers(resp.getBillers());
				
			} catch (Exception e) {
				Logger.error("Error while loading PayeesAndBillersListResp ", e, this.getClass());
			}

			// 20E1 : Data masking for CRN : Start
			
			String serviceResponseForMasking = objectMapper.writeValueAsString(serviceResponse);
			String serviceResponseAfterMasking = maskValue(serviceResponseForMasking);
						Logger.info("History Receipt JSON Response :" + serviceResponseAfterMasking,
					this.getClass());
			// 20E1 : Data masking for CRN : End
			return serviceResponse;
					
		}catch (BusinessException e)
		{
			Logger.info("BusinessException Inside processHistoryReceipt() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			BusinessException exp = new BusinessException(e.getKey());
			IMBResp resp1  = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, ServiceConstants.HISTORY_RECEIPT_SERVICE, httpServletRequest);
			return resp1;
		}catch (ResourceException e){
			Logger.error("ResourceException Inside processHistoryReceipt() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			ResourceException exp = new ResourceException(e.getKey());
			IMBResp resp1  = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, ServiceConstants.HISTORY_RECEIPT_SERVICE, httpServletRequest);
			return resp1;
		} catch (Exception e)
		{
			Logger.error("Exception Inside processHistoryReceipt() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			BusinessException exp = new BusinessException(BusinessException.GENERIC_ERROR);
			IMBResp resp1  = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, ServiceConstants.HISTORY_RECEIPT_SERVICE, httpServletRequest);
			return resp1;
		} finally
		{
			perfLogger.endLog(logName);
			perfLogger.endAllLogs();
		}							
	}
	
	
	/**
	 * 
	 * Method to populate response for payments stuck in processing
	 * Added as part of SGBEXP- 5743
	 * 
	 * @param paymentsLog
	 * @param customer
	 * @return
	 */
	@RequestMapping(value = "nppStatus", method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public IMBResp getNppPaymentStatus(HttpServletRequest httpServletRequest,HttpServletResponse httpServletResponse,
			@RequestBody final PaymentLogStatusReq req){ 
				
		ObjectMapper objectMapper = new ObjectMapper();					
		
		perfLogger.startAllLogs();
		String logName = MBAppUtils.getLogName(httpServletRequest);
		perfLogger.startLog(logName);		
		fraudLogger = new FraudLogger();		
		MobileSession mbSession = null;
		try{
			mbSession = mbAppHelper.getMobileSession(httpServletRequest);
			Logger.info("NPP Processing Payment Status JSON Request :" + objectMapper.writeValueAsString(req), this.getClass());
			validateRequestHeader(req.getHeader(), httpServletRequest);
			ErrorResp errorResp = validate(req, httpServletRequest);
					
			if (errorResp != null && errorResp.getErrors() != null && errorResp.getErrors().size() > 0)
			{				
				return errorResp;
			}			
																		
			Customer customer = mbSession.getCustomer();
									
			IBankCommonData commonData=mbAppHelper.populateIBankCommonData(mbSession,httpServletRequest);
			
			PaymentsLogVO paymentsLogVO = nPPPaymentStatusService.validateAndGetProcessingPayment(req.getPaymentsLogID(), commonData);
			PaymentsLog paymentsLog = PaymentService.assemblePaymentsLog(paymentsLogVO);
			IMBResp serviceResponse = historyReceiptHelper.populateProcessingPaymentDetailResp(paymentsLog,customer);
			
			RespHeader headerResp = populateResponseHeader(ServiceConstants.HISTORY_RECEIPT_SERVICE, mbSession);
			serviceResponse.setHeader(headerResp);
			
			Logger.info("NPP Processing Payment Status JSON Response :" + objectMapper.writeValueAsString(serviceResponse), this.getClass());
			
			return serviceResponse;
					
		}catch (BusinessException e)
		{
			Logger.info("BusinessException Inside processHistoryReceipt() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			BusinessException exp = new BusinessException(e.getKey());
			IMBResp resp1  = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, ServiceConstants.HISTORY_RECEIPT_SERVICE, httpServletRequest);
			return resp1;
		}catch (ResourceException e){
			Logger.error("ResourceException Inside processHistoryReceipt() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			ResourceException exp = new ResourceException(e.getKey());
			IMBResp resp1  = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, ServiceConstants.HISTORY_RECEIPT_SERVICE, httpServletRequest);
			return resp1;
		} catch (Exception e)
		{
			Logger.error("Exception Inside processHistoryReceipt() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			BusinessException exp = new BusinessException(BusinessException.GENERIC_ERROR);
			IMBResp resp1  = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, ServiceConstants.HISTORY_RECEIPT_SERVICE, httpServletRequest);
			return resp1;
		} finally
		{
			perfLogger.endLog(logName);
			perfLogger.endAllLogs();
		}							
	}
	
	/**
	 * Response for invalid body request 
	 * 
	 * @return
	 */
	
	
	
	
	@ExceptionHandler({org.springframework.http.converter.HttpMessageNotReadableException.class})
	@ResponseStatus(org.springframework.http.HttpStatus.OK)
	@ResponseBody
	
	
	public IMBResp resolveException() {		
		return MBAppUtils.createInvalidMessageBodyResponse(ServiceConstants.HISTORY_RECEIPT_SERVICE);
	}
	
	public ErrorResp validate(IMBReq serviceRequest, HttpServletRequest request) {
		return new MBAppValidator().validate(serviceRequest, request);
	}
	
	public void validateRequestHeader(ReqHeader header, HttpServletRequest request) throws ResourceException
	{	
		mbAppValidator.validateRequestHeader(header,  request);	
	}
	
	public RespHeader populateResponseHeader(String ServiceName)
	{		
		return mbAppHelper.populateResponseHeader(ServiceName);
	}				
	
	
	public RespHeader populateResponseHeader(String serviceName, MobileSession mobSession )
	{
		return mbAppHelper.populateResponseHeader(serviceName, mobSession);
	}
	
	
	//Sending payment receipts to the entered email
	@RequestMapping(value = "sendemail", method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	
	public IMBResp sendEmailToDestination(HttpServletRequest httpServletRequest,HttpServletResponse httpServletResponse,
			@RequestBody final EmailPaymentReceiptReq request){ 
		
		ObjectMapper objectMapper = new ObjectMapper();					
		perfLogger.startAllLogs();
		String logName = MBAppUtils.getLogName(httpServletRequest);
		perfLogger.startLog(logName);		
		fraudLogger = new FraudLogger();		
		MobileSession mbSession = null;
		SuccessResp success = new SuccessResp();
		try{
			mbSession = mbAppHelper.getMobileSession(httpServletRequest);
			Logger.info("History Receipt sendEmailToDestination JSON Request :" + objectMapper.writeValueAsString(request), this.getClass());
			validateRequestHeader(request.getHeader(), httpServletRequest);
			ErrorResp errorResp = validate(request, httpServletRequest);
					
			if (errorResp != null && errorResp.getErrors() != null && errorResp.getErrors().size() > 0)
			{				
				//fraudLogger.logInvalidInput();
				return errorResp;
			}	
			String emailId = request.getEmailId();
			String tranType  = request.getTranType();
			Integer paymentId = request.getPaymentId();
			Customer customer = mbSession.getCustomer();
			
			IBankCommonData commonData=mbAppHelper.populateIBankCommonData(mbSession,httpServletRequest);
			commonData.getCustomer().getContactDetail().setEmail(emailId);
			commonData.setCustomer(commonData.getCustomer());
			
			PaymentsLog paymentLog = payHistoryService.getPaymentDetails(paymentId, commonData);
			if (null!=paymentLog) {
				// do the logic to send the email
			
			Account fromAccount = MBAppHelper.getAccountByAccountNumber(mbSession.getCustomer().getAccounts(),paymentLog.getAccountNumberFrom());
			
			Receipt receipt = new Receipt();
			
			PaymentsLogVO paymentsLogVO = new PaymentsLogVO();
			//	paymentsLogVO.setAmount(new BigDecimal(paymentLog.getAmount()).setScale(2, BigDecimal.ROUND_UP));
				paymentsLogVO.setAmount(new BigDecimal(paymentLog.getAmount()));
				paymentsLogVO.setDate(paymentLog.getDate());
				paymentsLogVO.setReceiptNumber(paymentLog.getReceiptNumber());
				paymentsLogVO.setAccountNumberTo(paymentLog.getAccountNumberTo());
				paymentsLogVO.setBsbNumberTo(paymentLog.getBsbNumberTo());
				paymentsLogVO.setReferenceNumber(paymentLog.getReferenceNumber());
				receipt.setReceiptNumber(paymentLog.getReceiptNumber());
				receipt.setReferenceNumber(paymentLog.getReferenceNumber());
			
				receipt.setPaymentLog(paymentsLogVO);
				
				if (tranType.equalsIgnoreCase(TransTypeEnum.TPB.getValue()) || tranType.equalsIgnoreCase(TransTypeEnum.TPC.getValue())  ||  tranType.equalsIgnoreCase(TransTypeEnum.TP.getValue()) 
						|| tranType.equalsIgnoreCase(TransTypeEnum.TPMB.getValue()) || tranType.equalsIgnoreCase(TransTypeEnum.TPMBI.getValue())
						|| tranType.equalsIgnoreCase(TransTypeEnum.TPCO.getValue()) || tranType.equalsIgnoreCase(TransTypeEnum.TPBO.getValue())
						|| tranType.equalsIgnoreCase(TransTypeEnum.TPCR.getValue()) || tranType.equalsIgnoreCase(TransTypeEnum.TPBR.getValue()) 
						|| tranType.equalsIgnoreCase(TransTypeEnum.TPBI.getValue()) || tranType.equalsIgnoreCase(TransTypeEnum.TPCI.getValue()) ){
				
				ThirdPartyPayment  payment  = new ThirdPartyPayment();
				payment.setFromAccount(fromAccount.getAccountId());
				payment.setCommonData(commonData);
			
				ThirdParty thirdParty = new ThirdParty();
				thirdParty.setPayerName(paymentLog.getPayerName());
				thirdParty.setName(paymentLog.getToAccountAlias());
				
	//			transactService.sendPayeeEmailReceipt(payment, receipt, fromAccount, thirdParty);
				transactService.sendThirdParyEmailReceipt(payment, receipt, fromAccount, thirdParty);
			}
/*			else if(tranType.equalsIgnoreCase(TransTypeEnum.BPAY.getValue())){
				BPayPayment bPay = new BPayPayment();
				bPay.setFromAccount(fromAccount.getAccountId());
				bPay.setCommonData(commonData);
				
				List<Biller> billers = customer.getBillers();
				Biller biller = new Biller();
				for( Biller billerTest : billers){
					if(billerTest.getCode().equalsIgnoreCase(paymentLog.getBillerCode())){
						biller = billerTest;
						
						break;
					}	
				}
				transactService.sendBPayEmailReceipt(bPay, receipt, fromAccount,biller);
			} */
			success.setIsSuccess(true);
		}else{
			
			BusinessException exp = new BusinessException(BusinessException.GENERIC_ERROR);
			Logger.error("Payment Details not found: " , exp, this.getClass());
			success.setIsSuccess(true);
		}
		return success;
	}
	catch (BusinessException e)
	{
		Logger.info("BusinessException Inside sendEmailToDestination() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
		BusinessException exp = new BusinessException(e.getKey());
		IMBResp resp1  = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, ServiceConstants.HISTORY_RECEIPT_SERVICE, httpServletRequest);
		return resp1;
	}catch (ResourceException e){
		Logger.error("ResourceException Inside sendEmailToDestination() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
		ResourceException exp = new ResourceException(e.getKey());
		IMBResp resp1  = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, ServiceConstants.HISTORY_RECEIPT_SERVICE, httpServletRequest);
		return resp1;
	} catch (Exception e)
	{
		Logger.error("Exception Inside sendEmailToDestination() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
		BusinessException exp = new BusinessException(BusinessException.GENERIC_ERROR);
		IMBResp resp1  = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, ServiceConstants.HISTORY_RECEIPT_SERVICE, httpServletRequest);
		return resp1;
	} finally
	{
		perfLogger.endLog(logName);
		perfLogger.endAllLogs();
	}	
}
	 /*
     * Method to mask crn value in the schedule response
     * 
     */
	private String maskValue(String serviceResponseForMasking) {
		try {
			String[] srvResp = serviceResponseForMasking.split(",");

			for (int i = 0; i < srvResp.length; i++) {

				if ((!StringUtils.isEmpty(srvResp[i])) && srvResp[i].contains("\"crn\"")) {
					int ind = srvResp[i].indexOf("\"crn\"");
					int lastIndex = srvResp[i].lastIndexOf("\"");
					String tempMask = srvResp[i].substring(ind + 7, lastIndex);

					if ((!StringUtils.isEmpty(tempMask)) && tempMask.length() > 10) {
						srvResp[i] = "\"crn\":" + "\"" + StringUtil.maskCrnValue(tempMask, "X") + "\"";
					}
				}
			}
			String serviceResponseAfterMasking = StringUtils.join(srvResp, ",");
			return serviceResponseAfterMasking;
		} catch (Exception e) {
			Logger.info("Error while masking CRN value ", this.getClass());
			return serviceResponseForMasking;
		}

	}
}
