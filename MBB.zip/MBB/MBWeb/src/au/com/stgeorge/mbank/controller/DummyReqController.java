package au.com.stgeorge.mbank.controller;

/* The Controller which is used for NAtive app logon */

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.AbstractController;

import au.com.stgeorge.framework.common.logging.Logger;

public class DummyReqController  extends AbstractController {

	public static final String PAGE_NAME = "DummyPage";

		
		
	@Override
	protected ModelAndView handleRequestInternal(HttpServletRequest request,
			HttpServletResponse response) throws Exception {

		Logger.debug("Loading Dummay Page ... " + request.getRequestURL() + " IP :" + request.getRemoteAddr(), this.getClass());
		ModelAndView model = new ModelAndView(PAGE_NAME);
		return model;
	}
	
	

}