package au.com.stgeorge.mbank.model.request.newaccount;

import java.io.Serializable;

import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.Length;
import org.hibernate.validator.constraints.NotEmpty;

import au.com.stgeorge.ibank.businessobject.BusinessException;
import au.com.stgeorge.mbank.model.common.IMBReq;
import au.com.stgeorge.mbank.model.common.OpenAcctDetail;
import au.com.stgeorge.mbank.model.common.ReqHeader;

public class FundDDAAcctReq implements IMBReq, Serializable{

	/**
	 * 
	 */
	protected static final String BLOCK_CHARS_PATTERN = "^[0-9A-Za-z',. &/\\-]*$";
	protected static final String AMT_PATTERN = "^[0-9]*\\.{0,1}(\\d{1,2}){0,1}$";
	
	private static final long serialVersionUID = -1405657066359951980L;
	private ReqHeader header;
	
	@NotNull(message = "" + BusinessException.ACCOUNT_NO_FROM_ACCOUNT)
	@Min(value = 0, message="" + BusinessException.GENERIC_ERROR)	
	private Integer fundingAccountIndex;
	
	@NotEmpty(message = "{errors.amt.required}")
	@Length(max = 14, message = "{errors.amt.maxlength}")
	@Pattern(regexp = AMT_PATTERN, message = "{errors.amt.blockchar}")
	private String initialAmount;
	
	private OpenAcctDetail newAccountDetail;
	
	
	public ReqHeader getHeader() {
		return header;
	}
	public void setHeader(ReqHeader header) {
		this.header = header;
	}
	public Integer getFundingAccountIndex() {
		return fundingAccountIndex;
	}
	public void setFundingAccountIndex(Integer fundingAccountIndex) {
		this.fundingAccountIndex = fundingAccountIndex;
	}
	public String getInitialAmount() {
		return initialAmount;
	}
	public void setInitialAmount(String initialAmount) {
		this.initialAmount = initialAmount;
	}
	public OpenAcctDetail getNewAccountDetail() {
		return newAccountDetail;
	}
	public void setNewAccountDetail(OpenAcctDetail newAccountDetail) {
		this.newAccountDetail = newAccountDetail;
	}
	
	
	 

}
