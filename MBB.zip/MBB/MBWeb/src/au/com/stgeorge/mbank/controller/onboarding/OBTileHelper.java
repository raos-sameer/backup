package au.com.stgeorge.mbank.controller.onboarding;

import java.util.List;

import au.com.stgeorge.ibank.onboarding.OBFeature;
import au.com.stgeorge.ibank.onboarding.OBFeatureOrigin;
import au.com.stgeorge.ibank.onboarding.OBSegment;
import au.com.stgeorge.mbank.model.common.IMBResp;
import au.com.stgeorge.mbank.model.response.onboarding.OBFeatureListResp;
import au.com.stgeorge.mbank.model.response.onboarding.OBFeatureResp;
import au.com.stgeorge.mbank.model.response.onboarding.OBSegmentListResp;
import au.com.stgeorge.mbank.model.response.onboarding.OBSegmentResp;

public class OBTileHelper {

	
	public IMBResp populateOBSegmentResp(List<OBSegment> obSegments, OBSegmentListResp obSegmentListResp){
		OBSegmentResp obSegmentResp = null;
		
		for(OBSegment segment : obSegments){
			obSegmentResp = new OBSegmentResp();
			obSegmentResp.setSegmentID(segment.getSegmentID());
			obSegmentResp.setSegmentName(segment.getName());
			obSegmentResp.setDescription(segment.getDescription());
			obSegmentResp.setIconClass(segment.getIconClass());
			obSegmentListResp.getObSegments().add(obSegmentResp);
			obSegmentResp=null;
		}
	
		return obSegmentListResp;
	}
	
	public List<OBSegmentResp> populateOBSegmentResp(List<OBSegment> obSegments, List<OBSegmentResp> obSegmentListResp){
		OBSegmentResp obSegmentResp = null;
		
		for(OBSegment segment : obSegments){
			obSegmentResp = new OBSegmentResp();
			obSegmentResp.setSegmentID(segment.getSegmentID());
			obSegmentResp.setSegmentName(segment.getName());
			obSegmentResp.setDescription(segment.getDescription());
			obSegmentResp.setIconClass(segment.getIconClass());
			obSegmentListResp.add(obSegmentResp);
			obSegmentResp=null;
		}
	
		return obSegmentListResp;
	}
	
	public IMBResp populateOBFeatureResp(List<OBFeature> obFeatures, OBFeatureListResp obFeatureListResp, String origin){
		OBFeatureResp obFeatureResp = null;
		OBFeatureOrigin featureOrigin = null;
		
		for(OBFeature feature : obFeatures){
			obFeatureResp = new OBFeatureResp();
			
			obFeatureResp.setFeatureId(feature.getFeatureID());
			obFeatureResp.setHeading(feature.getHeading());
			obFeatureResp.setDescription(feature.getDescription());
			obFeatureResp.setTaskFlag(feature.getTaskFlag());
			obFeatureResp.setStatus(feature.getStatus());
			
			if(feature.getFeatureOriginMap()!=null && feature.getFeatureOriginMap().get(origin)!=null){
			featureOrigin = feature.getFeatureOriginMap().get(origin);
			obFeatureResp.setNativeActionType(featureOrigin.getNativeActionType());
			obFeatureResp.setDeepLink(featureOrigin.getMBDeepLink());
			obFeatureResp.setExternalLink(featureOrigin.getExternalLink());
			}
			
			obFeatureListResp.getObFeatures().add(obFeatureResp);
			obFeatureResp = null;
			featureOrigin = null;
		}
		return obFeatureListResp;
	}
}
