package au.com.stgeorge.mbank.model.request;

import au.com.stgeorge.mbank.model.common.IMBReq;
import au.com.stgeorge.mbank.model.common.ReqHeader;

public class PartnerVendorRequest implements IMBReq{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private ReqHeader header;
	
	private String appName;

	public ReqHeader getHeader() {
		return header;
	}

	public void setHeader(ReqHeader header) {
		this.header = header;
	}

	public String getAppName() {
		return appName;
	}

	public void setAppName(String appName) {
		this.appName = appName;
	}
	
	
}
