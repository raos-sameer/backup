package au.com.stgeorge.mbank.model.request.expensesplitter;



import java.io.Serializable;

import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.Length;
import org.hibernate.validator.constraints.NotEmpty;

import au.com.stgeorge.ibank.businessobject.BusinessException;
import au.com.stgeorge.mbank.util.JsonDateSerializer;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;



public class ExpenseReq implements Serializable{


	/**
	 * 
	 */
	private static final long serialVersionUID = -1720856494822181638L;
	/**
	 * 
	 */
	protected static final String AMT_PATTERN = "^[0-9]*\\.{0,1}(\\d{1,2}){0,1}$";
	protected static final String BLOCK_CHARS_PATTERN = "^[0-9A-Za-z',. &/\\-]*$";
	protected static final String MASK_NUMBERS = "^[0-9]+$";
	
	@NotEmpty(message = "{errors.can.required}")
	@Pattern(regexp = BLOCK_CHARS_PATTERN, message = "{errors.desc.blockchar}")
	@Length(max = 24, message = "{errors.desc.maxlength}")
	private String expenseName;
	
	@Length(max = 14, message = "{errors.amt.maxlength}")
	@Pattern(regexp = AMT_PATTERN, message = "{errors.amt.blockchar}")
	private String expenseAmt;
	
	@JsonSerialize(using = JsonDateSerializer.class)
	@NotEmpty(message = "{errors.can.required}")
	private String expenseDate;
	
	/*@Pattern(regexp = MASK_NUMBERS, message = "" + BusinessException.WSVC_INVALID_INPUT_PARAM)*/
	private long expID;
	
	public String getExpenseName() {
		return expenseName;
	}


	public void setExpenseName(String expenseName) {
		this.expenseName = expenseName;
	}


	public String getExpenseAmt() {
		return expenseAmt;
	}


	public void setExpenseAmt(String expenseAmt) {
		this.expenseAmt = expenseAmt;
	}


	public String getExpenseDate() {
		return expenseDate;
	}


	public void setExpenseDate(String expenseDate) {
		this.expenseDate = expenseDate;
	}


	public long getExpID() {
		return expID;
	}


	public void setExpID(long expID) {
		this.expID = expID;
	}




	
	
}
