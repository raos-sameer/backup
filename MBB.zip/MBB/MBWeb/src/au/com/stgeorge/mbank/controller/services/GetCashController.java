package au.com.stgeorge.mbank.controller.services;

import java.math.BigDecimal;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;

import au.com.stgeorge.digitalsec.logger.DigitalSecLogger;
import au.com.stgeorge.digitalsec.logger.DigitalSecLogggerVO;
import au.com.stgeorge.framework.common.logging.Logger;
import au.com.stgeorge.ibank.businessobject.BusinessException;
import au.com.stgeorge.ibank.businessobject.GetCashService;
import au.com.stgeorge.ibank.businessobject.IBankSecureService;
import au.com.stgeorge.ibank.businessobject.ResourceException;
import au.com.stgeorge.ibank.common.cache.IBankParams;
import au.com.stgeorge.ibank.service.valueobject.CustDevice;
import au.com.stgeorge.ibank.service.valueobject.CustServiceRegistration;
import au.com.stgeorge.ibank.util.CommonBusinessUtil;
import au.com.stgeorge.ibank.valueobject.Account;
import au.com.stgeorge.ibank.valueobject.Customer;
import au.com.stgeorge.ibank.valueobject.DebitCardAccount;
import au.com.stgeorge.ibank.valueobject.GetCashArrangementDetail;
import au.com.stgeorge.ibank.valueobject.PhoneNumber;
import au.com.stgeorge.ibank.valueobject.UserAgentVO;
import au.com.stgeorge.ibank.valueobject.collection.LabelValueMap;
import au.com.stgeorge.ibank.valueobject.database.CodesVO;
import au.com.stgeorge.ibank.valueobject.transfer.IBankCommonData;
import au.com.stgeorge.mbank.controller.IMBController;
import au.com.stgeorge.mbank.controller.SecureCodeHelper;
import au.com.stgeorge.mbank.model.common.IMBReq;
import au.com.stgeorge.mbank.model.common.IMBResp;
import au.com.stgeorge.mbank.model.common.ReqHeader;
import au.com.stgeorge.mbank.model.common.RespHeader;
import au.com.stgeorge.mbank.model.request.EmptyReq;
import au.com.stgeorge.mbank.model.request.SecureCodeReq;
import au.com.stgeorge.mbank.model.request.services.GetCashCodeReq;
import au.com.stgeorge.mbank.model.response.ErrorResp;
import au.com.stgeorge.mbank.session.MobileSession;
import au.com.stgeorge.mbank.useragent.UserAgentParser;
import au.com.stgeorge.mbank.util.MBAppHelper;
import au.com.stgeorge.mbank.util.MBAppUtils;
import au.com.stgeorge.mbank.util.MBAppValidator;
import au.com.stgeorge.mbank.util.ServiceConstants;
import au.com.stgeorge.perflogger.PerformanceLogger;
import au.com.stgeorge.security.util.StringMethods;

import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * @author C50216
 *
 */

@Controller
@RequestMapping("/getcash")
public class GetCashController implements IMBController{

	@Autowired
	private GetCashHelper getCashHelper;
	
	@Autowired 
	private GetCashService getCashService;
			
	@Autowired
	private MBAppHelper mbAppHelper;
	
	@Autowired
	private MBAppValidator mbAppValidator;
	
	@Autowired
	private PerformanceLogger perfLogger;
	
	@Autowired
	private UserAgentParser userAgentParser;
	
	@Autowired
	private SecureCodeHelper secureCodeHelper;
	
    @Autowired
    private DigitalSecLogger digitalSecLogger;
	
	private static int tempVariable = 1;//TODO remove this
	
	@RequestMapping(value= "eligibility" , method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public IMBResp checkEligiblity(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse,
			@RequestBody final EmptyReq req)
	{				
				
		ObjectMapper objectMapper = new ObjectMapper();							
		perfLogger.startAllLogs();
		String logName = MBAppUtils.getLogName(httpServletRequest);
		perfLogger.startLog(logName);		
		MobileSession mbSession = null;
		boolean tokenValidated = false;
		CustServiceRegistration  custReg = null;		
		String messageCode = null;		
		boolean isRegistered = false;		
		GetCashArrangementDetail arrangementVO = null;
		try{	
			
			mbSession = mbAppHelper.getMobileSession(httpServletRequest);
			mbSession.setGetCashArrangementDetail(null);
			Logger.info("GetCash Eligiblity check Info JSON Request :" + objectMapper.writeValueAsString(req), this.getClass());
			
			validateRequestHeader(req.getHeader(), httpServletRequest);
			ErrorResp errorResp = validate(req, httpServletRequest);
			if (errorResp != null && errorResp.getErrors() != null && errorResp.getErrors().size() > 0)
			{									
				return errorResp;
			}
						
			Customer customer=mbSession.getCustomer();		
			CodesVO codeItem=IBankParams.getCodesData(IBankParams.BRAND_ORIGIN, IBankParams.CONFIGURATION_PROPERTIES,IBankParams.GET_CASH_SWITCH);//0,1,9 9 FOR BROWSER
			Logger.debug("GetCash Token is :  :" + mbSession.getGetCashToken() + " : GetCash Flag is : " + mbSession.getGetCashAllowFlag(), this.getClass()); 						
			if(codeItem != null && ( codeItem.getMessage().equals("1") || codeItem.getMessage().equals("9") )){
				
				
				String deviceId = mbSession.getDeviceID();				
				//deviceId will be Null when executed via browser(Development/Test region).
				if(codeItem.getMessage().equals("9") && deviceId == null){ 
					deviceId = ""+tempVariable++;
					mbSession.setDeviceID(deviceId);
				}
								
				String token =  mbSession.getGetCashToken();
				String gcisNumber = mbSession.getUser().getGCISNumber();
				UserAgentVO userAgentVO = mbSession.getUserAgentWS();
				//userAgentVO will be Null when executed via browser(Development/Test region).
				if(userAgentVO == null){					
					String userAgent = httpServletRequest.getHeader("User-Agent");					
					au.com.stgeorge.mbank.useragent.UserAgentVO mbank_userAgentVO = userAgentParser.parseUserAgentString(userAgent);
					userAgentVO = getCashHelper.populateUserAgentVO(mbank_userAgentVO);
					mbSession.setUserAgentWS(userAgentVO);				
				}				
				CustDevice custDevice = getCashHelper.populateCustDevice(deviceId, mbSession.getUser().getGCISNumber(), userAgentVO);
				//check for divice +!gcisNumber				
				custReg = getCashService.getRegistrationDetail(custDevice);							
				if (token  != null)
					tokenValidated = getCashService.validateToken(deviceId, token);
								
				if (custReg!=null && tokenValidated){
					//REGISTERED
					mbSession.setGetCashRegistered(true);
					isRegistered = true;				
					
					//Update CustServiceRegistration - LastUsedDate
					getCashService.updateLastUsedDate(custReg, mbSession.getUser().getGCISNumber());

					messageCode = getCashHelper.validateAccountEligiblity(mbSession, isRegistered);
					
					IBankCommonData commonData=mbAppHelper.populateIBankCommonData(mbSession, httpServletRequest);					
					
					
					
					arrangementVO = getCashService.getActiveCashCode(commonData, getCashHelper.populateRetrieveArrangementRequestVO());//getCashService.getArrangements(commonData, getCashHelper.populateRetrieveArrangementRequestVO());					
					if(arrangementVO != null){
						if(arrangementVO.getFaultMessage() != null){							
							messageCode = arrangementVO.getFaultMessage();//getCashService.SERVICE_UNAVAILABLE_CODE;							
						}
						//mbSession.setGetCashArrangementDetail(arrangementVO);
					}else{
						messageCode = getCashService.checkArrangementLimit(commonData);						
					}										
				}else{				
					
					// 2FAExempt / Bypass
					if ( IBankSecureService.isGlobalByPass() )
						messageCode =  GetCashService.SERVICE_UNAVAILABLE_CODE;
					else if(IBankSecureService.isCustomerExempt(customer.getIBankSecureDetails()))
						messageCode =  GetCashService.SECURE_CODE_EXCEMPT_CODE;
					else{						
						messageCode = getCashHelper.validateAccountEligiblity(mbSession, isRegistered);
						
						if(messageCode == null)
							messageCode = getCashHelper.validateCustomerEligiblity(custReg, deviceId, gcisNumber, tokenValidated, token);																									
					}					
					mbSession.setGetCashRegistered(false);				
				}
			}else{				
				messageCode = GetCashService.SERVICE_UNAVAILABLE_CODE;
			}
																																								
			IMBResp serviceResponse = getCashHelper.populateEligiblityResp(mbSession, isRegistered, messageCode, arrangementVO);
						
			RespHeader headerResp = populateResponseHeader(ServiceConstants.GET_CASH_ELIGIBLITY_SERVICE, mbSession);
			serviceResponse.setHeader(headerResp);			
			Logger.info("GetCash Eligiblity JSON Response :" + objectMapper.writeValueAsString(serviceResponse), this.getClass());
			
			return serviceResponse;		
			
		}catch (BusinessException e)
		{
			BusinessException exp = null;
			Logger.info("BusinessException Inside GetCash checkEligiblity() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "]", e, this.getClass());		
			exp = new BusinessException(e.getKey());
			IMBResp resp1  = MBAppUtils.createErrorResp(mbSession.getOrigin() ,exp, ServiceConstants.GET_CASH_ELIGIBLITY_SERVICE, httpServletRequest);
			return resp1;
		}catch (ResourceException e) {
			Logger.error("ResourceException Inside GetCash checkEligiblity() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "]", e, this.getClass());			
			ResourceException exp = new ResourceException(e.getKey());
			IMBResp resp1  = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, ServiceConstants.GET_CASH_ELIGIBLITY_SERVICE, httpServletRequest);
			return resp1;
		}catch (Exception e)
		{			
			Logger.error("Exception Inside GetCash checkEligiblity() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "]", e, this.getClass());
			BusinessException exp = new BusinessException(BusinessException.GENERIC_ERROR);
			IMBResp resp1  = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, ServiceConstants.GET_CASH_ELIGIBLITY_SERVICE, httpServletRequest);
			return resp1;
		} finally
		{
			perfLogger.endLog(logName);
			perfLogger.endAllLogs();
		}				
	}

	//Request for secure code - 2FA
	@RequestMapping(value="reqsecurecode", method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public IMBResp processReqSecCode(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse,
			@RequestBody final SecureCodeReq request)
	{		
		ObjectMapper objectMapper = new ObjectMapper();				
		perfLogger.startAllLogs();
		String logName = MBAppUtils.getLogName(httpServletRequest);
		perfLogger.startLog(logName);
		MobileSession mbSession = null;
		try {			
			mbSession = mbAppHelper.getMobileSession(httpServletRequest);
			mbSession.removeDigitalSecLoggerMap();
			Logger.info("GetCash reqSecureCode check Info JSON Request :" + objectMapper.writeValueAsString(request), this.getClass());
			validateRequestHeader( request.getHeader(), httpServletRequest );			
			ErrorResp errorResp = validate(request, httpServletRequest);
			if (errorResp != null && errorResp.getErrors() != null && errorResp.getErrors().size() > 0)
			{								
				return errorResp;
			}
						
			IBankCommonData commonData=mbAppHelper.populateIBankCommonData(mbSession,httpServletRequest);	
			
			LabelValueMap digitalSecLoggerMap = new LabelValueMap(2);
			digitalSecLoggerMap.put(DigitalSecLogger.AUTHTYPE, request.getDeliveryMethod());
			PhoneNumber phoneNumber = CommonBusinessUtil.get2FAPhoneNumber(commonData, request.getPhone());
			digitalSecLoggerMap.put(DigitalSecLogger.AUTHPHONE, phoneNumber.getAreaCode()+phoneNumber.getPhoneNumber());
			mbSession.setDigitalSecLoggerMap(digitalSecLoggerMap);
			
			return secureCodeHelper.reqSecureCode(commonData, mbSession, mbSession.getTransaction(), request, ServiceConstants.GET_CASH_SECURE_CODE_SERVICE, httpServletRequest);
		}
		catch (BusinessException e)
		{
			Logger.error("Exception Inside reqGetCashSecCode() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			IMBResp resp1 = MBAppUtils.createErrorResp(mbSession.getOrigin(), e, ServiceConstants.GET_CASH_SECURE_CODE_SERVICE, httpServletRequest);
			return resp1;
		}catch (ResourceException e) {
			Logger.error("ResourceException Inside reqGetCashSecCode() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "]", e, this.getClass());			
			ResourceException exp = new ResourceException(e.getKey());
			IMBResp resp1  = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, ServiceConstants.GET_CASH_ELIGIBLITY_SERVICE, httpServletRequest);
			return resp1;	
		} catch (Exception e)
		{
			Logger.error("Exception Inside reqGetCashCode() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			BusinessException exp = new BusinessException(BusinessException.SMPL_SYS_ERROR);
			IMBResp resp1 = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, ServiceConstants.GET_CASH_SECURE_CODE_SERVICE, httpServletRequest);
			return resp1;
		} finally
		{
			perfLogger.endLog(logName);
			perfLogger.endAllLogs();
		}
	}
	
	// Register customer after 2FA verification
	
	@RequestMapping(value= "register" , method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public IMBResp processRegistration(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse,
			@RequestBody final SecureCodeReq req)
	{				
				
		ObjectMapper objectMapper = new ObjectMapper();							
		perfLogger.startAllLogs();
		String logName = MBAppUtils.getLogName(httpServletRequest);
		perfLogger.startLog(logName);		
		MobileSession mbSession = null;		
		GetCashArrangementDetail arrangementVO = null;
		String messageCode = null;
		
        DigitalSecLogggerVO digitalSecLoggerVO =new DigitalSecLogggerVO();
        digitalSecLoggerVO.setTranName(DigitalSecLogger.GET_CASH_REGISTRATION);
        digitalSecLoggerVO.setStatus(DigitalSecLogger.SUCCESS);
        
		try{	
			
			mbSession = mbAppHelper.getMobileSession(httpServletRequest);												
			Logger.info("GetCash Registration Info JSON Request :" + objectMapper.writeValueAsString(req), this.getClass());
			validateRequestHeader(req.getHeader(), httpServletRequest);
			ErrorResp errorResp = validate(req, httpServletRequest);
			if (errorResp != null && errorResp.getErrors() != null && errorResp.getErrors().size() > 0)
			{							
				return errorResp;
			}
			
			IBankCommonData commonData=mbAppHelper.populateIBankCommonData(mbSession,httpServletRequest);
			digitalSecLoggerVO.setCommonLogData(mbAppHelper.getCommonLogData(commonData));
			digitalSecLoggerVO.setUserAgent(commonData.getUserAgent());
									
			if(mbSession.IsGetCashRegistered() == null  || mbSession.IsGetCashRegistered())
			{				
				throw new BusinessException(BusinessException.GENERIC_ERROR);
			}			

			LabelValueMap digitalSecMap = mbSession.getDigitalSecLoggerMap();
			digitalSecLoggerVO.setValues(toDigitalSecurityLog(digitalSecMap.get(DigitalSecLogger.AUTHTYPE), digitalSecMap.get(DigitalSecLogger.AUTHPHONE)));
			String gcisNum = mbSession.getUser().getGCISNumber();
			ErrorResp errorResponse = secureCodeHelper.verifySecureCode(commonData, mbSession, mbSession.getTransaction(), req, ServiceConstants.GET_CASH_REGISTRATION_SERVICE, httpServletRequest);
			if (errorResponse.hasErrors()){
				digitalSecLoggerVO.setStatus(DigitalSecLogger.FAILURE_2FA);
				digitalSecLogger.log(digitalSecLoggerVO);
				
				return errorResponse;
			}
			
			mbSession.setSecureCodeVerifiedTranName(ServiceConstants.GET_CASH_REGISTRATION_SERVICE);
											
			UserAgentVO userAgentVO = mbSession.getUserAgentWS();
			CustDevice custDevice = getCashHelper.populateCustDevice(mbSession.getDeviceID(), gcisNum, userAgentVO);
			
			List<CustServiceRegistration> list = getCashService.isDeviceRegistered(mbSession.getDeviceID(), gcisNum);			
			if(list != null && list.size() > 0){
				for(CustServiceRegistration custReg : list){
					custReg.setModifiedBy(gcisNum);
					Logger.info("DeRegistering old customer from same Device. Old GCIS : " + custReg.getGcisNumber()+ " : new GCIS : "+gcisNum , this.getClass());
					getCashService.deregisterGetCash(commonData, custReg);
				}
			}
			commonData.setUserAgent(userAgentVO.toString());
			String token = getCashService.register(commonData, custDevice);			
			mbSession.setGetCashRegistered(true);
			mbSession.setGetCashToken(token);						
															
			arrangementVO = getCashService.getActiveCashCode(commonData, getCashHelper.populateRetrieveArrangementRequestVO());			
			if(arrangementVO != null){
				if(arrangementVO.getFaultMessage() != null){					
					messageCode = arrangementVO.getFaultMessage();//getCashService.SERVICE_UNAVAILABLE_CODE;							
				}
				//mbSession.setGetCashArrangementDetail(arrangementVO);
			}else{
				messageCode = getCashService.checkArrangementLimit(commonData);						
			}
			
			IMBResp serviceResponse = getCashHelper.populateRegistrationResp(mbSession, arrangementVO, messageCode);			
			RespHeader headerResp = populateResponseHeader(ServiceConstants.GET_CASH_REGISTRATION_SERVICE, mbSession);
			serviceResponse.setHeader(headerResp);
			
			if(!StringMethods.isEmptyString(messageCode)){
				digitalSecLoggerVO.setStatus(DigitalSecLogger.FAILURE);
			}
			
			digitalSecLogger.log(digitalSecLoggerVO);
			Logger.info("GetCash Registration JSON Response :" + objectMapper.writeValueAsString(serviceResponse), this.getClass());
			
			return serviceResponse;		
		}catch (BusinessException e)
		{
			BusinessException exp = null;
			digitalSecLoggerVO.setStatus(DigitalSecLogger.FAILURE);
			digitalSecLogger.log(digitalSecLoggerVO);
			Logger.info("BusinessException Inside GetCash processRegistration() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "]", e, this.getClass());		
			exp = new BusinessException(e.getKey());
			IMBResp resp1  = MBAppUtils.createErrorResp(mbSession.getOrigin() ,exp, ServiceConstants.GET_CASH_REGISTRATION_SERVICE, httpServletRequest);
			return resp1;
		}catch (ResourceException e) {
			Logger.error("ResourceException Inside GetCash processRegistration() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "]", e, this.getClass());			
			ResourceException exp = new ResourceException(e.getKey());
			IMBResp resp1  = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, ServiceConstants.GET_CASH_REGISTRATION_SERVICE, httpServletRequest);
			return resp1;
		}catch (Exception e)
		{			
			Logger.error("Exception Inside GetCash processRegistration() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "]", e, this.getClass());
			BusinessException exp = new BusinessException(BusinessException.GENERIC_ERROR);
			IMBResp resp1  = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, ServiceConstants.GET_CASH_REGISTRATION_SERVICE, httpServletRequest);
			return resp1;
		} finally
		{
			perfLogger.endLog(logName);
			perfLogger.endAllLogs();
		}				
	}
	
	@RequestMapping(value= "code" , method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public IMBResp processCode(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse,
			@RequestBody final GetCashCodeReq req)
	{				
				
		ObjectMapper objectMapper = new ObjectMapper();							
		perfLogger.startAllLogs();
		String logName = MBAppUtils.getLogName(httpServletRequest);
		perfLogger.startLog(logName);		
		MobileSession mbSession = null;		
		
        DigitalSecLogggerVO digitalSecLoggerVO =new DigitalSecLogggerVO();
        digitalSecLoggerVO.setTranName(DigitalSecLogger.GET_CASH_CODE);
        digitalSecLoggerVO.setStatus(DigitalSecLogger.SUCCESS);
        
		try{	
			
			mbSession = mbAppHelper.getMobileSession(httpServletRequest);												
			Logger.info("GetCash code check Info JSON Request :" + objectMapper.writeValueAsString(req), this.getClass());
			
			validateRequestHeader(req.getHeader(), httpServletRequest);
			ErrorResp errorResp = validate(req, httpServletRequest);
			if (errorResp != null && errorResp.getErrors() != null && errorResp.getErrors().size() > 0)
			{									
				return errorResp;
			}
			
			IBankCommonData commonData=mbAppHelper.populateIBankCommonData(mbSession, httpServletRequest);
			commonData.setUserAgent(mbSession.getUserAgentWS().toString());
			digitalSecLoggerVO.setCommonLogData(mbAppHelper.getCommonLogData(commonData));
			digitalSecLoggerVO.setUserAgent(commonData.getUserAgent());
						
			if(mbSession.IsGetCashRegistered() == null  || !mbSession.IsGetCashRegistered())				
				throw new BusinessException(BusinessException.GENERIC_ERROR);
			
			DebitCardAccount account = getCashHelper.getAccountByAccountIndex(mbSession.getGetCashAccountDetail(), req.getAccountIndex());
			
			if(account == null)
				throw new BusinessException(BusinessException.GENERIC_ERROR);
			
			Account custAcct = mbAppHelper.getAccountFromCustomer(mbSession.getCustomer(), account.getIndex());
			if( !(custAcct.getAvailableBalance().compareTo(new BigDecimal(0)) > 0) || (new BigDecimal(req.getAmt()).compareTo(custAcct.getAvailableBalance()) > 0) )
				throw new BusinessException(BusinessException.INSUFFICIENT_AVAILABLE_BALANCE);
			
			GetCashArrangementDetail getCashArrangementDetail = getCashHelper.populateCreateArrangementRequestVO(account, req.getAmt());
			GetCashArrangementDetail arrangementDetail = getCashService.createCashCode(commonData, getCashHelper.populateCreateArrangementRequestVO(account, req.getAmt()), mbSession.getDeviceID(),account.getAccountId().getApplicationId(),account.getAccountId().getSubProductCode());

			if(arrangementDetail.getAccountNumberUpdated()!=null){
				mbSession.getCustomer().getPreference().setDefaultGetCashAccount(account.getAccountId().getAccountNumber());
			}
			
			if(arrangementDetail.getFaultMessage() == null)
				mbSession.setGetCashArrangementDetail(arrangementDetail);
			
			IMBResp serviceResponse = getCashHelper.populateCreateCodeResp(arrangementDetail);
			
			if(arrangementDetail.getFaultMessage() != null) {
				digitalSecLoggerVO.setStatus(DigitalSecLogger.FAILURE);
			} else {
				digitalSecLoggerVO.setValues(getCashArrangementDetail.toDigitalSecurityLog());
			}
			digitalSecLogger.log(digitalSecLoggerVO);
						
			RespHeader headerResp = populateResponseHeader(ServiceConstants.GET_CASH_CODE_SERVICE, mbSession);
			serviceResponse.setHeader(headerResp);			
			Logger.info("GetCash code JSON Response :" + objectMapper.writeValueAsString(serviceResponse), this.getClass());
			
			return serviceResponse;		
			
		}catch (BusinessException e)
		{
			BusinessException exp = null;
			digitalSecLoggerVO.setStatus(DigitalSecLogger.FAILURE);
			digitalSecLogger.log(digitalSecLoggerVO);
			Logger.info("BusinessException Inside GetCash Processcode() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "]", e, this.getClass());		
			
			exp = new BusinessException(e.getKey());
			IMBResp resp1  = MBAppUtils.createErrorResp(mbSession.getOrigin() ,exp, ServiceConstants.GET_CASH_CODE_SERVICE, httpServletRequest);
			return resp1;
		}catch (ResourceException e) {
			Logger.error("ResourceException Inside GetCash Processcode() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "]", e, this.getClass());			
			ResourceException exp = new ResourceException(e.getKey());
			IMBResp resp1  = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, ServiceConstants.GET_CASH_CODE_SERVICE, httpServletRequest);
			return resp1;
		}catch (Exception e)
		{			
			Logger.error("Exception Inside GetCash Processcode() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "]", e, this.getClass());
			BusinessException exp = new BusinessException(BusinessException.GENERIC_ERROR);
			IMBResp resp1  = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, ServiceConstants.GET_CASH_CODE_SERVICE, httpServletRequest);
			return resp1;
		} finally
		{
			perfLogger.endLog(logName);
			perfLogger.endAllLogs();
		}				
	}

	
	@RequestMapping(value= "cancelcode" , method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public IMBResp cancelCashCode(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse,
			@RequestBody final EmptyReq req)
	{				
				
		ObjectMapper objectMapper = new ObjectMapper();							
		perfLogger.startAllLogs();
		String logName = MBAppUtils.getLogName(httpServletRequest);
		perfLogger.startLog(logName);		
		MobileSession mbSession = null;
		String gcisNumber = "";
		
		
		try{	
			
			mbSession = mbAppHelper.getMobileSession(httpServletRequest);
			gcisNumber = (mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "";
			Logger.info("GetCash cancel code Info JSON Request :" + objectMapper.writeValueAsString(req), this.getClass());
			
			validateRequestHeader(req.getHeader(), httpServletRequest);
			ErrorResp errorResp = validate(req, httpServletRequest);
			if (errorResp != null && errorResp.getErrors() != null && errorResp.getErrors().size() > 0)
			{									
				return errorResp;
			}
						
			if(mbSession.IsGetCashRegistered() == null  || !mbSession.IsGetCashRegistered()){				
				Logger.info("Cancel Cash Code: ERROR - Session not registered. GCIS: " + gcisNumber , this.getClass());
				throw new BusinessException(BusinessException.GENERIC_ERROR);
			}
			
			GetCashArrangementDetail currentArrangement =  mbSession.getGetCashArrangementDetail();
			
			if (currentArrangement == null){
				Logger.info("Cancel Cash Code: ERROR - arrangement not found in session. GCIS: " + gcisNumber, this.getClass());
				throw new BusinessException(BusinessException.GENERIC_ERROR);
			}
			
			
			IBankCommonData commonData=mbAppHelper.populateIBankCommonData(mbSession, httpServletRequest);
			GetCashArrangementDetail arrangementDetail = getCashService.cancelCashCode(commonData, currentArrangement, false);						
			
			if(arrangementDetail.getFaultMessage() == null){
				mbSession.setGetCashArrangementDetail(null);
				Logger.info("Cancel Cash Code SUCCESS : removed ID: " + currentArrangement.getId(), this.getClass());
			}else{
				throw new BusinessException (BusinessException.GENERIC_ERROR);
			}
			
			IMBResp serviceResponse = getCashHelper.populateCancelCodeResp(arrangementDetail);
						
			RespHeader headerResp = populateResponseHeader(ServiceConstants.GET_CASH_CODE_SERVICE, mbSession);
			serviceResponse.setHeader(headerResp);			
			Logger.info("Cancel Cash Code SUCCESS: JSON Response :" + objectMapper.writeValueAsString(serviceResponse), this.getClass());
			
			return serviceResponse;		
			
		}catch (BusinessException e){
			//BusinessException exp = null;
			Logger.info("BusinessException Inside GetCash cancelcode for Customer GCIS: ["+ gcisNumber + "]", e, this.getClass());		
			IMBResp resp1  = MBAppUtils.createErrorResp(mbSession.getOrigin() ,e, ServiceConstants.GET_CASH_CODE_SERVICE, httpServletRequest);
			return resp1;
		}catch (ResourceException e){
			Logger.error("ResourceException Inside GetCash cancelcode for Customer GCIS: [" + gcisNumber + "]", e, this.getClass());			
			ResourceException exp = new ResourceException(e.getKey());
			IMBResp resp1  = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, ServiceConstants.GET_CASH_CODE_SERVICE, httpServletRequest);
			return resp1;
		}catch (Exception e){			
			Logger.error("Exception Inside GetCash cancelcode for Customer GCIS: ["+ gcisNumber + "]", e, this.getClass());
			BusinessException exp = new BusinessException(BusinessException.GENERIC_ERROR);
			IMBResp resp1  = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, ServiceConstants.GET_CASH_CODE_SERVICE, httpServletRequest);
			return resp1;
		} finally
		{
			perfLogger.endLog(logName);
			perfLogger.endAllLogs();
		}				
	}	
	
	
	/**
	 * Response for invalid body request 
	 * 
	 * @return
	 */
	@ExceptionHandler({org.springframework.http.converter.HttpMessageNotReadableException.class})
	@ResponseStatus(org.springframework.http.HttpStatus.OK)
	@ResponseBody
	public IMBResp resolveException() {		
		return MBAppUtils.createInvalidMessageBodyResponse(ServiceConstants.GET_CASH_ELIGIBLITY_SERVICE);
	}
	
	public ErrorResp validate(IMBReq serviceRequest, HttpServletRequest request) {
		return mbAppValidator.validate(serviceRequest, request);
	}
	
	public void validateRequestHeader(ReqHeader header, HttpServletRequest request) throws ResourceException
	{	
		mbAppValidator.validateRequestHeader(header,  request);	
	}
	
	public RespHeader populateResponseHeader(String serviceName, MobileSession mobSession )
	{
		return mbAppHelper.populateResponseHeader(serviceName, mobSession);
	}
	
	private String toDigitalSecurityLog(String authType, String phoneNum2FA){
        StringBuffer sb = new StringBuffer();
        try{
        	sb.append(DigitalSecLogger.AUTHTYPE).append(DigitalSecLogger.DELIMITER_COLON).append(authType);	

	        if(!DigitalSecLogger.EXEMPTED.equals(authType) && !DigitalSecLogger.BYPASS.equals(authType)) {
	        	sb.append(DigitalSecLogger.DELIMITER_COMMA).append(DigitalSecLogger.AUTHPHONE).append(DigitalSecLogger.DELIMITER_COLON)
	            .append(phoneNum2FA);
	        }
        }catch (Exception e) {
		}
        
        return sb.toString();

	}
}
