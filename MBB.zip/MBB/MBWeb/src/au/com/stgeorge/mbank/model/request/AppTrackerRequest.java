package au.com.stgeorge.mbank.model.request;

import java.io.Serializable;

import au.com.stgeorge.mbank.model.common.IMBReq;
import au.com.stgeorge.mbank.model.common.ReqHeader;

public class AppTrackerRequest implements IMBReq, Serializable {

	private static final long serialVersionUID = 5937366676539616615L;

	private ReqHeader header;
	private Boolean isDeepLink;
	
	@Override
	public ReqHeader getHeader() {
		return header;
	}

	@Override
	public void setHeader(ReqHeader header) {
		this.header = header;
	}

	public Boolean getIsDeepLink() {
		return isDeepLink;
	}

	public void setIsDeepLink(Boolean isDeepLink) {
		this.isDeepLink = isDeepLink;
	}

	

}
