package au.com.stgeorge.mbank.controller.services;

import java.math.BigDecimal;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import au.com.stgeorge.ibank.businessobject.BusinessException;
import au.com.stgeorge.ibank.businessobject.ResourceException;
import au.com.stgeorge.ibank.businessobject.acctsvc.AccountService;
import au.com.stgeorge.ibank.common.cache.IBankParams;
import au.com.stgeorge.ibank.common.cache.IBankRefershParams;
import au.com.stgeorge.ibank.util.ServiceHelper;
import au.com.stgeorge.ibank.valueobject.Account;
import au.com.stgeorge.ibank.valueobject.AccountId;
import au.com.stgeorge.ibank.valueobject.database.CCBalanceTransferVO;
import au.com.stgeorge.ibank.valueobject.transfer.IBankCommonData;
import au.com.stgeorge.ibank.valueobject.transfer.PortfolioLists;
import au.com.stgeorge.mbank.model.response.services.CCBalanceTransferAcctListResp;
import au.com.stgeorge.mbank.model.response.services.CCBalanceTransferResp;
import au.com.stgeorge.mbank.util.MBAppHelper;
import au.com.stgeorge.mbank.util.MBAppUtils;

@Service
public class CCBalanceTransferHelper {

	@Autowired
	private MBAppHelper mbAppHelper;
	
	@Autowired
	private AccountService acctSvc;
	
	private static final String MOBILE_RECEIPT_PREFIX = "1";
	
	protected CCBalanceTransferAcctListResp populateAcctListResp(PortfolioLists portfolioList){
		
		CCBalanceTransferAcctListResp resp = new CCBalanceTransferAcctListResp();	
		IBankRefershParams ibankRefreshParams = (IBankRefershParams) ServiceHelper.getBean("ibankRefreshParams");

		if(portfolioList != null){			
					
			List<Integer> acctList = mbAppHelper.getAccountIndexList(portfolioList.getAccounts());
			
			resp.setAccountList(acctList);
			resp.setCcBalTransTerm(ibankRefreshParams.getCCBalTranTerm());
			resp.setCcBalTransRate(ibankRefreshParams.getCCBalTranRate());
		}		
		
		return resp;			
	}	
	
	protected CCBalanceTransferResp populateResp(CCBalanceTransferVO ccBalanceTransferVO){
		
		CCBalanceTransferResp resp = new CCBalanceTransferResp();
				
		String receiptNumber = IBankParams.getReceiptNumberPrefix(MOBILE_RECEIPT_PREFIX) + Integer.toString(ccBalanceTransferVO.getReferenceNumber());
		resp.setReceiptNumDisp(MBAppUtils.formatReceiptNumber(receiptNumber));
		
		resp.setIsSuccess(true);
		resp.setSystemDate(ccBalanceTransferVO.getModifiedOn());
		
		return resp;
	}
	
	protected void validateInputData(String amount, IBankCommonData commonData, Account selectedAcct) throws BusinessException
	{
		BigDecimal transAmount = new BigDecimal(amount);
		BigDecimal availableBal = getAvailableBalance(commonData, selectedAcct);
		BigDecimal allowedAmount = (availableBal.multiply(new BigDecimal(80))).divide(new BigDecimal(100));
		if (transAmount.doubleValue() < 200.00) {
			throw new BusinessException(BusinessException.CC_BAL_AMOUNT_EXCEEDED_MIN);
		}
		else if (transAmount.compareTo(allowedAmount) == 1) {
			throw new BusinessException(BusinessException.CC_BAL_AMOUNT_EXCEEDED_MAX);
		}
	}
	
	private BigDecimal getAvailableBalance(IBankCommonData commonData,Account account) throws BusinessException,
	    ResourceException {
		
		BigDecimal availableBalance;
		if (account == null) {
			throw new BusinessException(BusinessException.REQUEST_ERROR);
		} else {
			
			if (Account.CRA.equals(account.getAccountId().getApplicationId())){
				String replacementAcctNum = account.getCreditCardAdditionalInfo()
				    .getReplacementAcctNum();
				String productTransferStatus = account.getCreditCardAdditionalInfo()
						.getProductTransferStatus();
				if (replacementAcctNum == null
				    || (IBankParams.NO.equals(productTransferStatus) && replacementAcctNum != null)) {
					availableBalance = account.getAvailableBalance();
				} else {
					AccountId acctId = new AccountId();
					acctId.setAccountNumber(replacementAcctNum);
					acctId.setApplicationId(Account.CRA);
					
					availableBalance = getAvailableBalance(commonData, acctSvc.getAccountForUser(commonData, acctId));
				}
			} else {
				availableBalance = account.getAvailableBalance();
			}
		}
		return availableBalance;
	}
			
}
