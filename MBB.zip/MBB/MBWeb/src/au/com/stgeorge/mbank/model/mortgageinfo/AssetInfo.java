package au.com.stgeorge.mbank.model.mortgageinfo;

import java.io.Serializable;

import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.Range;

import au.com.stgeorge.ibank.businessobject.BusinessException;


import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_NULL)
public class AssetInfo implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = -486160447489294868L;
	private int index;
	private String assetType;
	private String category;
	private String bankCode;
	
	//added for Existing customers
	private String relationship;	
	private String accountNumber;
	private String clasAssetId;
	
	@Range(min=-9999999, max=9999999, message = ""+BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE)
	@Pattern(regexp="(-?[0-9]+[.]?[0-9]?[0-9]?)",message = ""+BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE)
	private String assetValue;
	
	private Integer propertyIndex;
	
	@Range(max=100, message = ""+BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE)
	@Pattern(regexp="([0-9]+[.]?[0-9]?[0-9]?)",message = ""+BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE)
	private String owner1Percent;

	@Range(max=100, message = ""+BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE)
	@Pattern(regexp="([0-9]+[.]?[0-9]?[0-9]?)",message = ""+BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE)
	private String owner2Percent;

	@Range(max=100, message = ""+BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE)
	@Pattern(regexp="([0-9]+[.]?[0-9]?[0-9]?)",message = ""+BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE)
	private String otherPercent;
	
	public int getIndex() {
		return index;
	}
	public void setIndex(int index) {
		this.index = index;
	}
	public String getAssetType() {
		return assetType;
	}
	public void setAssetType(String assetType) {
		this.assetType = assetType;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public String getBankCode() {
		return bankCode;
	}
	public void setBankCode(String bankCode) {
		this.bankCode = bankCode;
	}
	public Integer getPropertyIndex() {
		return propertyIndex;
	}
	public void setPropertyIndex(Integer propertyIndex) {
		this.propertyIndex = propertyIndex;
	}
	public String getAssetValue() {
		return assetValue;
	}
	public void setAssetValue(String assetValue) {
		this.assetValue = assetValue;
	}
	public String getOwner1Percent() {
		return owner1Percent;
	}
	public void setOwner1Percent(String owner1Percent) {
		this.owner1Percent = owner1Percent;
	}
	public String getOwner2Percent() {
		return owner2Percent;
	}
	public void setOwner2Percent(String owner2Percent) {
		this.owner2Percent = owner2Percent;
	}
	public String getOtherPercent() {
		return otherPercent;
	}
	public void setOtherPercent(String otherPercent) {
		this.otherPercent = otherPercent;
	}
	public String getRelationship() {
		return relationship;
	}
	public void setRelationship(String relationship) {
		this.relationship = relationship;
	}
	public String getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}
	public String getClasAssetId() {
		return clasAssetId;
	}
	public void setClasAssetId(String clasAssetId) {
		this.clasAssetId = clasAssetId;
	}
	
	
}
