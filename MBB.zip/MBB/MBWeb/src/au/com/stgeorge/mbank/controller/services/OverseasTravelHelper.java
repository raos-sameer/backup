package au.com.stgeorge.mbank.controller.services;

import java.text.SimpleDateFormat;

import org.springframework.stereotype.Service;

import au.com.stgeorge.framework.common.logging.Logger;
import au.com.stgeorge.ibank.util.DateUtils;
import au.com.stgeorge.ibank.valueobject.sessionInfo.OverseasTravelSessionVO;
import au.com.stgeorge.mbank.model.common.IMBResp;
import au.com.stgeorge.mbank.model.common.RespHeader;
import au.com.stgeorge.mbank.model.request.services.OverseasTravelReq;
import au.com.stgeorge.mbank.model.response.StatusResp;
import au.com.stgeorge.mbank.model.response.payments.TransferResp;

/**
 * Overseas travel service helper
 * 
 * @author C38854
 * 
 */
@Service
public class OverseasTravelHelper {
	/**
	 * Populate overseas travel request request
	 * 
	 * @param header
	 * @param status
	 * @return
	 */
	protected OverseasTravelSessionVO populateTravelRequest(RespHeader header, OverseasTravelReq request) {

		OverseasTravelSessionVO travelVO = new OverseasTravelSessionVO();
		travelVO.setAdditionalInfo(request.getAdditionalInfo());
		travelVO.setDestinations(request.getCountries());
		SimpleDateFormat sdf = new SimpleDateFormat(DateUtils.EN_AU_DATE_FORMAT_PATTERN);
		travelVO.setStartDate(sdf.format(request.getStartDate()));
		travelVO.setReturnDate(sdf.format(request.getEndDate()));
		travelVO.setEmailCust(request.getSendEmail() == null ? false : request.getSendEmail());
		return travelVO;
	}

	/**
	 * Populate response
	 * 
	 * @param header
	 * @param status
	 * @return
	 */
	protected IMBResp populateSuccessResponse(RespHeader header) {
		StatusResp response = new StatusResp(header);
		response.setStatus(1);
		Logger.info("Response: " + response, this.getClass());
		return response;
	}

	/**
	 * Populate service response - secure required
	 * 
	 * @param header
	 * @param duplicates
	 * @return
	 */
	protected TransferResp populateSecureRequiredResponse(RespHeader header) {
		TransferResp payeeTransferResponse = new TransferResp(header);
		payeeTransferResponse.setSecureCodeReqd(Boolean.TRUE);
		Logger.debug("Response populated: " + payeeTransferResponse, this.getClass());
		return payeeTransferResponse;
	}
}
