package au.com.stgeorge.mbank.controller.statements;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;

import au.com.stgeorge.framework.common.logging.Logger;
import au.com.stgeorge.ibank.businessobject.BusinessException;
import au.com.stgeorge.ibank.businessobject.ResourceException;
import au.com.stgeorge.ibank.valueobject.Account;
import au.com.stgeorge.ibank.valueobject.Customer;
import au.com.stgeorge.ibank.valueobject.transfer.IBankCommonData;
import au.com.stgeorge.mbank.controller.IMBController;
import au.com.stgeorge.mbank.model.common.IMBReq;
import au.com.stgeorge.mbank.model.common.IMBResp;
import au.com.stgeorge.mbank.model.common.ReqHeader;
import au.com.stgeorge.mbank.model.common.RespHeader;
import au.com.stgeorge.mbank.model.request.EmptyReq;
import au.com.stgeorge.mbank.model.request.statements.OptStmtReq;
import au.com.stgeorge.mbank.model.response.ErrorResp;
import au.com.stgeorge.mbank.session.MobileSession;
import au.com.stgeorge.mbank.util.FraudLogger;
import au.com.stgeorge.mbank.util.MBAppHelper;
import au.com.stgeorge.mbank.util.MBAppUtils;
import au.com.stgeorge.mbank.util.MBAppValidator;
import au.com.stgeorge.mbank.util.ServiceConstants;
import au.com.stgeorge.mobilebank.businessobject.EStatementsService;
import au.com.stgeorge.perflogger.PerformanceLogger;

import com.fasterxml.jackson.databind.ObjectMapper;

@Controller
@RequestMapping("/optstmt")

public class OptStmtController implements IMBController {
private FraudLogger fraudLogger;
	
	@Autowired
	private EStatementsService mobileEStatementService;

	@Autowired
	private OptStmtHelper optStmtHelper;

	@Autowired
	private MBAppHelper mbAppHelper;
			
	@Autowired
	private PerformanceLogger perfLogger;
	
	@Autowired
	private MBAppValidator mbAppValidator;

	
	@RequestMapping(value =ServiceConstants.ESTMT_ACCTLIST_SERVICE, method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public IMBResp processSuppressableAcctList(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse,
			@RequestBody final EmptyReq req)
	{								
		return processAcctList(httpServletRequest, httpServletResponse, req);			
	}
	
	@RequestMapping(value =ServiceConstants.PAPERSTMT_ACCTLIST_SERVICE, method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public IMBResp processUnsuppressableAcctList(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse,
			@RequestBody final EmptyReq req)
	{								
		return processAcctList(httpServletRequest, httpServletResponse, req);	
	}
	
	
	private IMBResp processAcctList(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse,
			@RequestBody final EmptyReq req)
	{								
		ObjectMapper objectMapper = new ObjectMapper();									
		perfLogger.startAllLogs();
		String logName = MBAppUtils.getLogName(httpServletRequest);
		perfLogger.startLog(logName);
		MobileSession mbSession = null;
		IMBResp serviceResponse = null;
		String serviceName = null;
		try{	
			
			mbSession = mbAppHelper.getMobileSession(httpServletRequest);
			Logger.info("Paper Stmt account list JSON Request :" + objectMapper.writeValueAsString(req), this.getClass());
			validateRequestHeader(req.getHeader(), httpServletRequest);
			ErrorResp errorResp = validate(req, httpServletRequest);
			if (errorResp != null && errorResp.getErrors() != null && errorResp.getErrors().size() > 0)
			{				
				return errorResp;
			}
																		
			Customer customer=mbSession.getCustomer();			
			IBankCommonData commonData=mbAppHelper.populateIBankCommonData(mbSession,httpServletRequest);								
			serviceName = req.getHeader().getServiceName();
			if(serviceName != null && serviceName.contains("/")){
				serviceName = serviceName.substring(serviceName.indexOf("/")+1,serviceName.length());
			}
			
			if(serviceName.equalsIgnoreCase(ServiceConstants.ESTMT_ACCTLIST_SERVICE)){
				serviceResponse = optStmtHelper.populateSuppressableAcctListResp(commonData,customer);
			}
			else{
				serviceResponse = optStmtHelper.populateUnsuppressableAcctListResp(commonData,customer);
			}
			
			RespHeader headerResp = populateResponseHeader(serviceName, mbSession);
			serviceResponse.setHeader(headerResp);
			
			Logger.info("Paper Stmt account list JSON Response :" + objectMapper.writeValueAsString(serviceResponse), this.getClass());
			
			return serviceResponse;		
		}catch (BusinessException e)
		{
			Logger.info("BusinessException Inside processAcctList() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			BusinessException exp = new BusinessException(e.getKey());
			IMBResp resp1  = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, serviceName, httpServletRequest);
			return resp1;
		} catch (ResourceException e) {
			Logger.error("ResourceException Inside processAcctList() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			ResourceException exp = new ResourceException(e.getKey());
			IMBResp resp1  = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, serviceName, httpServletRequest);
			return resp1;
		}catch (Exception e)
		{
			Logger.error("Exception Inside processAcctList() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			BusinessException exp = new BusinessException(BusinessException.GENERIC_ERROR);
			IMBResp resp1  = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, serviceName, httpServletRequest);
			return resp1;
		} finally
		{
			perfLogger.endLog(logName);
			perfLogger.endAllLogs();
		}				
	}
	@RequestMapping(value =ServiceConstants.PROCESS_SUPPRESSION, method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public IMBResp processSuppression(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse,
			@RequestBody final OptStmtReq req)
	{								
		return processOptStmt(httpServletRequest, httpServletResponse, req);
	}
	@RequestMapping(value =ServiceConstants.PROCESS_UNSUPPRESSION, method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public IMBResp processUnsuppression(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse,
			@RequestBody final OptStmtReq req)
	{								
		return processOptStmt(httpServletRequest, httpServletResponse, req);		
	}
	
	private IMBResp processOptStmt(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse,
			@RequestBody final OptStmtReq req)
	{								
		ObjectMapper objectMapper = new ObjectMapper();									
		perfLogger.startAllLogs();
		String logName = MBAppUtils.getLogName(httpServletRequest);
		perfLogger.startLog(logName);
		MobileSession mbSession = null;
		List<Account> processedAcctList = null;
		String serviceName = null;
		try{	
			
			mbSession = mbAppHelper.getMobileSession(httpServletRequest);
			Logger.info("processSwitchPaperStmt JSON Request :" + objectMapper.writeValueAsString(req), this.getClass());
			validateRequestHeader(req.getHeader(), httpServletRequest);
			ErrorResp errorResp = validate(req, httpServletRequest);
			if (errorResp != null && errorResp.getErrors() != null && errorResp.getErrors().size() > 0)
			{				
				return errorResp;
			}
						
			if(req.getAccountList().size() == 0)
				throw new BusinessException(BusinessException.WSVC_INVALID_INPUT_PARAM);
									
						
			Customer customer=mbSession.getCustomer();			
			IBankCommonData commonData=mbAppHelper.populateIBankCommonData(mbSession,httpServletRequest);	
						
			ArrayList<Account> selectedAcctList = new ArrayList<Account>();
			
			for(Integer index : req.getAccountList()){
				Account acct = mbAppHelper.getAccountFromCustomer(customer, index);
				if(acct != null)
					selectedAcctList.add(acct);				
			}
			if(selectedAcctList.size() == 0)
				throw new BusinessException(BusinessException.NO_INFORMATION);
			
			serviceName = req.getHeader().getServiceName();
			if(serviceName != null && serviceName.contains("/")){
				serviceName = serviceName.substring(serviceName.indexOf("/")+1,serviceName.length());
			}
			
			if(serviceName.equalsIgnoreCase(ServiceConstants.PROCESS_SUPPRESSION)){
				processedAcctList = mobileEStatementService.updateMobileSuppressStatementList(commonData, selectedAcctList, customer);
			}
			else{
				processedAcctList = mobileEStatementService.updateMobileUnSuppressStatementList(commonData, selectedAcctList, customer);
			}
			
			
			
			IMBResp serviceResponse = optStmtHelper.populateResp(processedAcctList);
									
			RespHeader headerResp = populateResponseHeader(serviceName, mbSession);
			serviceResponse.setHeader(headerResp);
			
			Logger.info("processSwitchPaperStmt JSON Response :" + objectMapper.writeValueAsString(serviceResponse), this.getClass());
			
			return serviceResponse;		
		}catch (BusinessException e)
		{
			Logger.info("BusinessException Inside processSwitchPaperStmt() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			BusinessException exp = new BusinessException(e.getKey());
			IMBResp resp1  = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, serviceName, httpServletRequest);
			return resp1;
		} catch (ResourceException e) {
			Logger.error("ResourceException Inside processSwitchPaperStmt() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			ResourceException exp = new ResourceException(ResourceException.SYSTEM_ERROR);
			IMBResp resp1  = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, serviceName, httpServletRequest);
			return resp1;
		}catch (Exception e)
		{
			Logger.error("Exception Inside processSwitchPaperStmt() for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			BusinessException exp = new BusinessException(BusinessException.GENERIC_ERROR);
			IMBResp resp1  = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, serviceName, httpServletRequest);
			return resp1;
		} finally
		{
			perfLogger.endLog(logName);
			perfLogger.endAllLogs();
		}				
	}
	
	public ErrorResp validate(IMBReq serviceRequest, HttpServletRequest request) {
		return mbAppValidator.validate(serviceRequest, request);
	}

	public RespHeader populateResponseHeader(String serviceName) {
		return new MBAppHelper().populateResponseHeader(serviceName);
	}

	public void validateRequestHeader(ReqHeader headerReq, HttpServletRequest request) throws BusinessException {		
		 mbAppValidator.validateRequestHeader(headerReq, request);
	}

	public RespHeader populateResponseHeader(String serviceName, MobileSession mobSession )
	{
		return mbAppHelper.populateResponseHeader(serviceName, mobSession);
	}

	/**
	 * Response for invalid body request
	 * 
	 * @return
	 */
	@ExceptionHandler( { org.springframework.http.converter.HttpMessageNotReadableException.class })
	@ResponseStatus(org.springframework.http.HttpStatus.OK)
	@ResponseBody
	public IMBResp resolveException() {
		return MBAppUtils.createInvalidMessageBodyResponse(ServiceConstants.OPT_STMT_SERVICE);
		
	}
	
}
