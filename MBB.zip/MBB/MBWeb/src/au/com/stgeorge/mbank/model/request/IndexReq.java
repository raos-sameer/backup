package au.com.stgeorge.mbank.model.request;

import java.io.Serializable;

import javax.validation.constraints.Pattern;

import org.apache.commons.lang.builder.ReflectionToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;
import org.hibernate.validator.constraints.NotEmpty;

import au.com.stgeorge.ibank.businessobject.BusinessException;
import au.com.stgeorge.mbank.model.common.IMBReq;
import au.com.stgeorge.mbank.model.common.ReqHeader;

/**
 * CC Details request
 * 
 * @author C38854
 * 
 */
public class IndexReq implements IMBReq, Serializable {

	private static final long serialVersionUID = 2022242446298729854L;

	// @Valid TODO
	private ReqHeader header;

	@NotEmpty(message = "" + BusinessException.WSVC_INVALID_INPUT_PARAM)
	@Pattern(regexp = "^[0-9]+$", message = "" + BusinessException.WSVC_INVALID_INPUT_PARAM)
	private String index;
	
	private String accountType;
	private boolean sourceSecurityWellBeingCheck;
    
	public boolean isSourceSecurityWellBeingCheck() {
		return sourceSecurityWellBeingCheck;
	}
	public void setSourceSecurityWellBeingCheck(boolean sourceSecurityWellBeingCheck) {
		this.sourceSecurityWellBeingCheck = sourceSecurityWellBeingCheck;
	}
	public String getIndex() {
		return index;
	}

	public ReqHeader getHeader() {
		return header;
	}

	public void setHeader(ReqHeader header) {
		this.header = header;
	}
	
	public String getAccountType() {
		return accountType;
	}

	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}

	@Override
	public String toString() {
		return ReflectionToStringBuilder.toString(this, ToStringStyle.MULTI_LINE_STYLE);
	}

}
