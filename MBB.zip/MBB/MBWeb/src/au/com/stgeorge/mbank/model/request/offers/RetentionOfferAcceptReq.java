package au.com.stgeorge.mbank.model.request.offers;

import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;

import org.apache.commons.lang.builder.ReflectionToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;

import au.com.stgeorge.ibank.businessobject.BusinessException;
import au.com.stgeorge.mbank.model.common.IMBReq;
import au.com.stgeorge.mbank.model.common.ReqHeader;

/**
 * Transfer request
 * 
 * @author C38854
 * 
 */
public class RetentionOfferAcceptReq implements IMBReq {

	/**
	 * 
	 */
	private static final long serialVersionUID = -4723751125232692028L;
	
	// @Valid TODO
	private ReqHeader header;

	@NotNull(message = "Invalid input parameters")
	@Min(value = 0, message="" + BusinessException.GENERIC_ERROR)
	private Integer accountIndex;
	
	public Integer getAccountIndex() {
		return accountIndex;
	}

	public ReqHeader getHeader() {
		return header;
	}

	public void setHeader(ReqHeader header) {
		this.header = header;
	}
	
	@Override
	public String toString() {
		return ReflectionToStringBuilder.toString(this, ToStringStyle.MULTI_LINE_STYLE);
	}
}
