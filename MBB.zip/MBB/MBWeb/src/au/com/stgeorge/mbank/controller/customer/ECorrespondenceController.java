/**
 * 
 */
package au.com.stgeorge.mbank.controller.customer;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import au.com.stgeorge.digitalsec.logger.DigitalSecLogger;
import au.com.stgeorge.framework.common.logging.Logger;
import au.com.stgeorge.ibank.businessobject.BusinessException;
import au.com.stgeorge.ibank.businessobject.ResourceException;
import au.com.stgeorge.ibank.businessobject.ecorrespondence.ECorrespondenceService;
import au.com.stgeorge.ibank.common.cache.IBankParams;
import au.com.stgeorge.ibank.messagecentre.valueobject.MessageSearch;
import au.com.stgeorge.ibank.valueobject.transfer.IBankCommonData;
import au.com.stgeorge.mbank.controller.IMBController;
import au.com.stgeorge.mbank.model.common.IMBReq;
import au.com.stgeorge.mbank.model.common.IMBResp;
import au.com.stgeorge.mbank.model.common.ReqHeader;
import au.com.stgeorge.mbank.model.common.RespHeader;
import au.com.stgeorge.mbank.model.request.customer.ECorrespondenceConsentReq;
import au.com.stgeorge.mbank.model.request.customer.ECorrespondenceReq;
import au.com.stgeorge.mbank.model.response.ErrorResp;
import au.com.stgeorge.mbank.model.response.SuccessResp;
import au.com.stgeorge.mbank.model.response.customer.ECorrespondenceResp;
import au.com.stgeorge.mbank.session.MobileSession;
import au.com.stgeorge.mbank.util.MBAppHelper;
import au.com.stgeorge.mbank.util.MBAppUtils;
import au.com.stgeorge.mbank.util.MBAppValidator;
import au.com.stgeorge.mbank.util.ServiceConstants;
import au.com.stgeorge.perflogger.PerformanceLogger;

import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * @author c70656
 *
 */

@Controller
@RequestMapping("/ecorrespondence")
public class ECorrespondenceController implements IMBController{

	@Autowired
	private MBAppValidator mbAppValidator;
	
	@Autowired
    private PerformanceLogger perfLogger;
	
	@Autowired
	private MBAppHelper mbAppHelper;
	
	private static String TARGET_URL = "eCorrOneClickUrl";
	
	@Autowired
	private DigitalSecLogger digitalSecLogger;
	
	@Autowired
    private ECorrespondenceService eCorrespondenceService;
	
	@RequestMapping(value="getjwt", method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public IMBResp getJwt(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, @RequestBody final ECorrespondenceReq req){

		String logName = startPerformanceLog(httpServletRequest);
		ObjectMapper mapper = new ObjectMapper();
		MobileSession mbSession = null;
		try {
			
			mbSession = mbAppHelper.getMobileSession(httpServletRequest);		
			IBankCommonData commonData = new MBAppHelper().populateIBankCommonData(mbSession, httpServletRequest);
			Logger.info("ECorrespondenceController.getJwt JSON Request :" + mapper.writeValueAsString(req), this.getClass());
			validateRequestHeader( req.getHeader(), httpServletRequest );

			ErrorResp errorResp = validate(req, httpServletRequest);
			if (errorResp != null && errorResp.getErrors() != null && errorResp.getErrors().size() > 0)
			{
				return errorResp;
			}
			  
			Logger.info("ECorrespondenceController.getJwt Document ID is:" + req.getDocumentId(), this.getClass());
			  
			String jwsToken = eCorrespondenceService.getSignedJWSTokenEcorrespondence(commonData.getCustomer().getGcis(),req.getDocumentId());
			
			ECorrespondenceResp eCorrespondenceResp = new ECorrespondenceResp();
			eCorrespondenceResp.setJwtToken(jwsToken);
			String url =IBankParams.getCodesData(IBankParams.getBaseOriginCode(commonData.getOrigin()), IBankParams.EXTERNAL_LINKS, TARGET_URL).getMessage();
			eCorrespondenceResp.setTargetURL(url);
			eCorrespondenceResp.setiPAddress(MBAppHelper.resolveIPAddress(httpServletRequest, commonData.getOrigin()));
			
			if(null != mbSession.getDeviceID()) {
				eCorrespondenceResp.setDeviceId(mbSession.getDeviceID());
			}
			eCorrespondenceResp.setClientApiVersion(IBankParams.SWITCHING_SERVICE_APIVERSION);
		    Logger.info("ECorrespondenceController.getJwt JSON Response :" + mapper.writeValueAsString(eCorrespondenceResp), this.getClass());
			return eCorrespondenceResp;

		} catch (BusinessException e) {
			BusinessException exp = new BusinessException(e.getKey());
			IMBResp resp1 = MBAppUtils.createErrorResp(mbSession.getOrigin() , exp, ServiceConstants.ECORRESPONDENCE, httpServletRequest);
			return resp1;
		} catch (ResourceException e) {
			return MBAppUtils.createErrorResp(mbSession.getOrigin(), BusinessException.SYSTEM_UNAVILABLE, ServiceConstants.ECORRESPONDENCE, httpServletRequest);
		}catch (Exception e) {	
			IMBResp resp1 = MBAppUtils.createErrorResp(mbSession.getOrigin(),BusinessException.GENERIC_ERROR, ServiceConstants.ECORRESPONDENCE, httpServletRequest);
			return resp1;
		} finally {
		    endPerformanceLog(logName);
		}
	    
		
	}
	
	@RequestMapping(value="updateEcorConsent", method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public IMBResp updateEcorrespondenceConsent(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, @RequestBody final ECorrespondenceConsentReq req){
		Logger.info("Inside ECorrespondenceController.updateEcorConsent :" , this.getClass());
		String logName = startPerformanceLog(httpServletRequest);
		MobileSession mbSession = null;
		IBankCommonData commonData = null;
		ObjectMapper mapper = new ObjectMapper();
		String gcisNumber = null;
		try {
			mbSession = mbAppHelper.getMobileSession(httpServletRequest);
			commonData = new MBAppHelper()
					.populateIBankCommonData(mbSession, httpServletRequest);
			gcisNumber = commonData.getCustomer().getGcis();
	
			validateRequestHeader( req.getHeader(), httpServletRequest );
			Logger.info("ECorrespondenceController.updateEcorrespondenceConsent JSON Request :" + mapper.writeValueAsString(req), this.getClass());

			eCorrespondenceService.updateConstentPref(gcisNumber);
			eCorrespondenceService.makeECorConsentStatisticsLog(commonData, ECorrespondenceService.SPLASH_SOURCE, req.iseCorrespondenceConsent());
			// going to delete ECorrespondence Splash Info from DB & remove from session
			MessageSearch messageSearch=mbSession.getSplashInfoMsg();
			if(null != messageSearch) {
				eCorrespondenceService.updateMsgDeleteStatus(messageSearch,commonData);
				mbSession.removeSplashInfoMsg();
			}
		}
		catch (Exception e) {	
			//Consume the exception in case of update Consent failed for better customer experience
			Logger.error("ECorrespondenceController.updateEcorConsent  failed with Exception for customer " + gcisNumber  + e.getMessage(), this.getClass() );
		} finally {
		    endPerformanceLog(logName);
		}
		SuccessResp successResp = new SuccessResp();																			
		RespHeader headerResp = populateResponseHeader(req.getHeader().getServiceName(), mbSession );
		successResp.setHeader(headerResp);
		successResp.setIsSuccess(true);
		mbSession.setLoggedonState(LogonHelper.LOGGEDON_STATE_COMPLETE);
		return successResp;
	}

	
	@Override
	public void validateRequestHeader(ReqHeader headerReq, HttpServletRequest request) throws BusinessException {
		mbAppValidator.validateRequestHeader(headerReq,  request);
		
	}

	@Override
	public ErrorResp validate(IMBReq serviceRequest, HttpServletRequest httpRequest) throws BusinessException {
		return mbAppValidator.validate(serviceRequest, httpRequest);
	}

	@Override
	public RespHeader populateResponseHeader(String serviceName, MobileSession mobileSession) {
		return mbAppHelper.populateResponseHeader(serviceName,mobileSession);
	}
	
	
	private String startPerformanceLog(HttpServletRequest httpRequest) {
		perfLogger.startAllLogs();
		String logName = MBAppUtils.getLogName(httpRequest);
		perfLogger.startLog(logName);
		return logName;
    }

    private void endPerformanceLog(String logName) {
		perfLogger.endLog(logName);
		perfLogger.endAllLogs();
    }
	
	
    
}
