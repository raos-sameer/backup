package au.com.stgeorge.mbank.controller.customer;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.builder.ReflectionToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import au.com.stgeorge.digitalsec.logger.DigitalSecLogger;
import au.com.stgeorge.digitalsec.logger.DigitalSecLogggerVO;
import au.com.stgeorge.framework.common.logging.Logger;
import au.com.stgeorge.framework.common.util.StringMethods;
import au.com.stgeorge.ibank.businessobject.BusinessException;
import au.com.stgeorge.ibank.businessobject.ResourceException;
import au.com.stgeorge.ibank.common.cache.IBankParams;
import au.com.stgeorge.ibank.evcrs.businessobject.CRSService;
import au.com.stgeorge.ibank.evcrs.businessobject.valueobject.EVForeignCountryDetail;
import au.com.stgeorge.ibank.messagecentre.util.MessageCentreConstants;
import au.com.stgeorge.ibank.messagecentre.valueobject.MessageSearch;
import au.com.stgeorge.ibank.valueobject.Customer;
import au.com.stgeorge.ibank.valueobject.transfer.IBankCommonData;
import au.com.stgeorge.mbank.controller.IMBController;
import au.com.stgeorge.mbank.controller.customer.ev.CRSHelper;
import au.com.stgeorge.mbank.model.common.IMBReq;
import au.com.stgeorge.mbank.model.common.IMBResp;
import au.com.stgeorge.mbank.model.common.ReqHeader;
import au.com.stgeorge.mbank.model.common.RespHeader;
import au.com.stgeorge.mbank.model.request.EmptyReq;
import au.com.stgeorge.mbank.model.request.customer.CRSPromptReq;
import au.com.stgeorge.mbank.model.request.customer.ev.CRSInfo;
import au.com.stgeorge.mbank.model.response.ErrorResp;
import au.com.stgeorge.mbank.model.response.SuccessResp;
import au.com.stgeorge.mbank.model.response.customer.CRSPromptResp;
import au.com.stgeorge.mbank.session.MobileSession;
import au.com.stgeorge.mbank.util.MBAppHelper;
import au.com.stgeorge.mbank.util.MBAppUtils;
import au.com.stgeorge.mbank.util.MBAppValidator;
import au.com.stgeorge.mbank.util.ServiceConstants;
import au.com.stgeorge.perflogger.PerformanceLogger;

import com.fasterxml.jackson.databind.ObjectMapper;

@Controller
@RequestMapping("/crsPrompt")

public class CRSHardPromptController implements IMBController{
	
	@Autowired
	private MBAppHelper mbAppHelper;
	
	@Autowired
	private MBAppValidator mbAppValidator;
	
	@Autowired
	private CRSService crsService;
	
	@Autowired
	private CRSHelper crsHelper;
	
	@Autowired
	private DigitalSecLogger digitalSecLogger;
	
	public ErrorResp validate(IMBReq serviceRequest, HttpServletRequest request) {
		Logger.info("Service request object - " + ReflectionToStringBuilder.toString(serviceRequest), this.getClass());
		return mbAppValidator.validate(serviceRequest, request);
	}

	public void validateRequestHeader(ReqHeader headerReq, HttpServletRequest request) throws BusinessException {
		Logger.debug("Request header validation: " + ReflectionToStringBuilder.toString(headerReq, ToStringStyle.MULTI_LINE_STYLE), this.getClass());
		mbAppValidator.validateRequestHeader(headerReq, request);
	}
	
	public RespHeader populateResponseHeader(String serviceName, MobileSession mobSession) {
		return mbAppHelper.populateResponseHeader(serviceName, mobSession);
	}
	
	@RequestMapping(value="getCRSInfo", method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public IMBResp getCRSInfo (HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse,@RequestBody final EmptyReq req)
	{
		Logger.debug("Inside getCRSInfo", this.getClass());
		PerformanceLogger performanceLogger = new PerformanceLogger();
		performanceLogger.startAllLogs();
		String logName = MBAppUtils.getLogName(httpServletRequest);
		performanceLogger.startLog(logName);
		MobileSession mbSession = null;
		ObjectMapper mapper = new ObjectMapper();
		List<EVForeignCountryDetail> evForeignCountryDtls=null;
		try
		{
			mbSession = mbAppHelper.getMobileSession(httpServletRequest);
			

			String loggedonState =mbSession.getLoggedonState();
			Logger.info("CRS HARD PROMPT loggedonState :"+loggedonState , this.getClass());
			if(isLoggedOnStateError(mbSession.getSplashInfoMsg().getMessageAction(), loggedonState))
			{	
				throw new BusinessException(BusinessException.SYSTEM_UNAVILABLE);
			}
				Logger.info("Inside hard prompt: getCRSInfo :", this.getClass());
				validateRequestHeader( req.getHeader(), httpServletRequest );				
				ErrorResp errorResp = validate(req, httpServletRequest);
				if (errorResp != null && errorResp.getErrors() != null && errorResp.getErrors().size() > 0)
				{
					return errorResp;
				}			
				IBankCommonData ibankCommonData=mbAppHelper.populateIBankCommonData(mbSession,httpServletRequest);	
				Customer customer=ibankCommonData.getCustomer();
				
				 evForeignCountryDtls = IBankParams.getForeignTINDetails();
				 CRSInfo crsInfo = crsHelper.populateCRSInfo(evForeignCountryDtls,customer.getCustTypeInd());
				 CRSPromptResp crsPromptResp = new CRSPromptResp();
				 crsPromptResp.setCrsInfo(crsInfo);
				// crsPromptResp.setCountries(crsHelper.getCountryList());
				 Logger.info("getCRSInfo JSON Response :" + mapper.writeValueAsString(crsPromptResp), this.getClass());
				RespHeader headerResp = populateResponseHeader(req.getHeader().getServiceName(), mbSession );
				crsPromptResp.setHeader(headerResp);			
				return crsPromptResp;
				
			
		}
		catch (BusinessException e){
			Logger.info("BusinessException in getCRSInfo - [key: " + e.getKey() + "] : GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());
			return MBAppUtils.createErrorResp(mbSession.getOrigin(), e, ServiceConstants.CRS_PRODUCT_READY, httpServletRequest);
		} 
		catch (ResourceException e){
			Logger.error("ResourceException in getCRSInfo- [key: " + e.getKey() + "] : GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());
			return MBAppUtils.createErrorResp(mbSession.getOrigin(), BusinessException.SYSTEM_UNAVILABLE, ServiceConstants.CRS_PRODUCT_READY, httpServletRequest);
		}
		catch (Exception e){
			Logger.error("Exception in getCRSInfo: GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			return MBAppUtils.createErrorResp(mbSession.getOrigin(), BusinessException.SYSTEM_UNAVILABLE, ServiceConstants.CRS_PRODUCT_READY, httpServletRequest);
		} 
		finally
		{
			performanceLogger.endLog(logName);
			performanceLogger.endAllLogs();
		}
	}
	
	
	@RequestMapping(value="submitCRSDetails", method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public IMBResp submitCRSDetails(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse,@RequestBody final CRSPromptReq req)
	{
		Logger.debug("Inside submitCRSDetails", this.getClass());
		PerformanceLogger performanceLogger = new PerformanceLogger();
		performanceLogger.startAllLogs();
		String logName = MBAppUtils.getLogName(httpServletRequest);
		CRSHelper crsHelper=new CRSHelper();
		performanceLogger.startLog(logName);
		MobileSession mbSession = null;
		au.com.stgeorge.ibank.evcrs.businessobject.valueobject.CRSInfo crsInfoVo=null;
		List<EVForeignCountryDetail> evForeignCountryDtls=new ArrayList<EVForeignCountryDetail>();	
		DigitalSecLogggerVO digitalSecLoggerVO = new DigitalSecLogggerVO();
		digitalSecLoggerVO.setTranName(DigitalSecLogger.CRS_HARDPROMPT);
		digitalSecLoggerVO.setAction(DigitalSecLogger.CRS_MAINTENANCE_ACTION_ADD);
		boolean isForeignTaxResident = false;
		try
		{
			mbSession = mbAppHelper.getMobileSession(httpServletRequest);
			IBankCommonData ibankCommonData = mbAppHelper.populateIBankCommonData(mbSession,httpServletRequest);	
			
			String loggedonState =mbSession.getLoggedonState();
			Logger.info("CRS HARD PROMPT loggedonState :"+loggedonState , this.getClass());
			if(isLoggedOnStateError(mbSession.getSplashInfoMsg().getMessageAction(), loggedonState))
			{	
				throw new BusinessException(BusinessException.SYSTEM_UNAVILABLE);
			}
				Logger.info("Inside hard prompt: submit :", this.getClass());

				validateRequestHeader( req.getHeader(), httpServletRequest );
				evForeignCountryDtls=IBankParams.getForeignTINDetails();
				crsHelper.validateCRSData(req.getCrsInfo(),evForeignCountryDtls);
				ErrorResp errorResp = validate(req, httpServletRequest);
				if (errorResp != null && errorResp.getErrors() != null && errorResp.getErrors().size() > 0)
				{
					return errorResp;
				}
				crsInfoVo=crsHelper.populateCRSInfoVo(req.getCrsInfo(),evForeignCountryDtls);
				String crsRegistrationNumber = mbSession.getCrsRegistrationNumber();
				Logger.debug("In CRSHardPromptController .. confirm( ) : flag value ::"+crsRegistrationNumber, this.getClass());
				crsInfoVo.setRegistrationNumber(crsRegistrationNumber);
				
				isForeignTaxResident = crsInfoVo.isForeignTaxResident();
				digitalSecLoggerVO.setCommonLogData(mbAppHelper.getCommonLogData(ibankCommonData));
			    digitalSecLoggerVO.setUserAgent(ibankCommonData.getUserAgent());
			    digitalSecLoggerVO.setValues(crsInfoVo.toDigitalSecurityLog(null, null,DigitalSecLogger.COUNTRY,DigitalSecLogger.TIN));
			    
				try{				
					// going to update the CRS Status: SVC 338
					//crsService.updateCRSInfo(ibankCommonData,crsInfoVo,null);
					
					if(StringMethods.isValidString(crsRegistrationNumber) && crsRegistrationNumber.equalsIgnoreCase("X")){
						Logger.debug("Calling getCustomerTaxInfo()", this.getClass());
						//Individual individualOldData = crsService.getCustomerTaxInfo(ibankCommonData);
						au.com.stgeorge.ibank.evcrs.businessobject.valueobject.CRSInfo oldCrsInfoVO = crsService.getCrsInfo(ibankCommonData);
						crsService.updateCRSInfo(ibankCommonData,crsInfoVo,null,oldCrsInfoVO);
					}else{
						Logger.debug("In CRSHardPromptController .. confirm( ) : Non X ", this.getClass());
						crsService.updateCRSInfo(ibankCommonData,crsInfoVo,null);
					}
					
				    // going to delete crs Infor from DB & remove from session
					MessageSearch messageSearch=mbSession.getSplashInfoMsg();
					crsService.updateMsgDeleteStatus(messageSearch,ibankCommonData);
					mbSession.removeSplashInfoMsg();
					mbSession.removeCrsRegistrationNumber();
									
					SuccessResp successResp = new SuccessResp();																			
					RespHeader headerResp = populateResponseHeader(req.getHeader().getServiceName(), mbSession );
					successResp.setHeader(headerResp);
					successResp.setIsSuccess(true);
					mbSession.setLoggedonState(LogonHelper.LOGGEDON_STATE_COMPLETE);
					
					if(isForeignTaxResident){
						digitalSecLoggerVO.setStatus(DigitalSecLogger.SUCCESS);
						digitalSecLogger.log(digitalSecLoggerVO);
					}
					
					return successResp;
				}
				catch(BusinessException ex){
					return MBAppUtils.createErrorResp(mbSession.getOrigin(), ex, ServiceConstants.CRS_PRODUCT_READY, httpServletRequest);
				}
						
		}
		catch (BusinessException e){
			Logger.info("BusinessException in submitCRSDetails - [key: " + e.getKey() + "] : GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());
			
			if(isForeignTaxResident){
				digitalSecLoggerVO.setStatus(DigitalSecLogger.FAILURE);
				digitalSecLogger.log(digitalSecLoggerVO);
			}
			return MBAppUtils.createErrorResp(mbSession.getOrigin(), e, ServiceConstants.CRS_PRODUCT_READY, httpServletRequest);
		} 
		catch (ResourceException e){
			Logger.error("ResourceException in submitCRSDetails- [key: " + e.getKey() + "] : GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());
			return MBAppUtils.createErrorResp(mbSession.getOrigin(), BusinessException.SYSTEM_UNAVILABLE, ServiceConstants.CRS_PRODUCT_READY, httpServletRequest);
		}
		catch (Exception e){
			Logger.error("Exception in submitCRSDetails: GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			return MBAppUtils.createErrorResp(mbSession.getOrigin(), ResourceException.MOBILE_NON_FINANCIAL_FATAL_ERR, ServiceConstants.CRS_PRODUCT_READY, httpServletRequest);
		} 
		finally
		{
			performanceLogger.endLog(logName);
			performanceLogger.endAllLogs();
		}
	}
	
	
	private boolean isLoggedOnStateError(String messageAction, String loggedOnState){
		if(MessageCentreConstants.SPLASH_ACTION_CRS_HARD_PROMPT_3.equalsIgnoreCase(messageAction)){
			if(!LogonHelper.LOGGEDON_STATE_CRS_HARD_PROMPT.equalsIgnoreCase(loggedOnState)){
				return true;
			}
		}
		return false;
	}
	
}
