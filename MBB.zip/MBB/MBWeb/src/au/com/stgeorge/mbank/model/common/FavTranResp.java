package au.com.stgeorge.mbank.model.common;

public class FavTranResp
{
	private int index;

	private String aliasName;

	public int getTranIndex()
	{
		return index;
	}

	public void setTranIndex(int index)
	{
		this.index = index;
	}

	public String getAliasName()
	{
		return aliasName;
	}

	public void setAliasName(String aliasName)
	{
		this.aliasName = aliasName;
	}

	public String getAmount()
	{
		return amount;
	}

	public void setAmount(String amount)
	{
		this.amount = amount;
	}

	

	private String amount;

	private boolean favouriteFlag;

	public boolean isFavouriteFlag()
	{
		return favouriteFlag;
	}

	public void setFavouriteFlag(boolean favouriteFlag)
	{
		this.favouriteFlag = favouriteFlag;
	}
	
	
  private int fromAccountIndex;
  private int toItemIndex;
  private String desc;
  private String tranType;
  private String custRefNum;
  private String payerName;
  private boolean sendEmail;
  private String payeeEmail;
  private boolean success;

	public int getIndex()
	{
		return index;
	}

	public void setIndex(int index)
	{
		this.index = index;
	}

	public int getFromAccountIndex()
	{
		return fromAccountIndex;
	}

	public void setFromAccountIndex(int fromAccountIndex)
	{
		this.fromAccountIndex = fromAccountIndex;
	}

	public int getToItemIndex()
	{
		return toItemIndex;
	}

	public void setToItemIndex(int toItemIndex)
	{
		this.toItemIndex = toItemIndex;
	}

	public String getDesc()
	{
		return desc;
	}

	public void setDesc(String desc)
	{
		this.desc = desc;
	}

	public String getTranType()
	{
		return tranType;
	}

	public void setTranType(String tranType)
	{
		this.tranType = tranType;
	}

	public String getCustRefNum()
	{
		return custRefNum;
	}

	public void setCustRefNum(String custRefNum)
	{
		this.custRefNum = custRefNum;
	}

	public String getPayerName()
	{
		return payerName;
	}

	public void setPayerName(String payerName)
	{
		this.payerName = payerName;
	}

	public boolean getSendEmail()
	{
		return sendEmail;
	}

	public void setSendEmail(boolean sendEmail)
	{
		this.sendEmail = sendEmail;
	}

	public String getPayeeEmail()
	{
		return payeeEmail;
	}

	public void setPayeeEmail(String payeeEmail)
	{
		this.payeeEmail = payeeEmail;
	}

	public boolean isSuccess()
	{
		return success;
	}

	public void setSuccess(boolean success)
	{
		this.success = success;
	}
}
