package au.com.stgeorge.mbank.model.request.payments;

import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;

import org.apache.commons.lang.builder.ReflectionToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;

import au.com.stgeorge.ibank.businessobject.BusinessException;

/**
 * Account to account transfer request
 * 
 * @author C38854
 * 
 */
public class AcctTransferReq extends TransferReq {

	private static final long serialVersionUID = -4236931634977698922L;

	@NotNull(message = "" + BusinessException.ACCOUNT_NO_TO_ACCOUNT)
	private Integer toAccountIndex;

	@Min(value = 0, message = "{errors.invalid.payment.option}")
	@Max(value = 3, message = "{errors.invalid.payment.option}")
	private Integer ccPaymentType;
	
	private String fromAccountNumber;
	
	private String fromAccountNumberMasked;
	
	private String toAccountNumber;
	
	private String toAccountNumberMasked;

	public Integer getCcPaymentType() {
		return ccPaymentType;
	}

	public Integer getToAccountIndex() {
		return toAccountIndex;
	}

	@Override
	public String toString() {
		return ReflectionToStringBuilder.toString(this, ToStringStyle.MULTI_LINE_STYLE);
	}

	public String getFromAccountNumber() {
		return fromAccountNumber;
	}

	public void setFromAccountNumber(String fromAccountNumber) {
		this.fromAccountNumber = fromAccountNumber;
	}

	public String getFromAccountNumberMasked() {
		return fromAccountNumberMasked;
	}

	public void setFromAccountNumberMasked(String fromAccountNumberMasked) {
		this.fromAccountNumberMasked = fromAccountNumberMasked;
	}

	public String getToAccountNumber() {
		return toAccountNumber;
	}

	public void setToAccountNumber(String toAccountNumber) {
		this.toAccountNumber = toAccountNumber;
	}

	public String getToAccountNumberMasked() {
		return toAccountNumberMasked;
	}

	public void setToAccountNumberMasked(String toAccountNumberMasked) {
		this.toAccountNumberMasked = toAccountNumberMasked;
	}

}
