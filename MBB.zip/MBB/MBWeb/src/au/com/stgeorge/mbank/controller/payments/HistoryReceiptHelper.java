/**
 * 
 */
package au.com.stgeorge.mbank.controller.payments;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import au.com.stgeorge.framework.common.logging.Logger;
import au.com.stgeorge.framework.common.util.StringMethods;
import au.com.stgeorge.ibank.common.cache.IBankParams;
import au.com.stgeorge.ibank.npp.NPPStatus;
import au.com.stgeorge.ibank.npp.NPPTransactionStatusEnum;
import au.com.stgeorge.ibank.util.NPPUtil;
import au.com.stgeorge.ibank.util.StringUtil;
import au.com.stgeorge.ibank.valueobject.Account;
import au.com.stgeorge.ibank.valueobject.Customer;
import au.com.stgeorge.ibank.valueobject.PaymentsLog;
import au.com.stgeorge.ibank.valueobject.database.CodesVO;
import au.com.stgeorge.mbank.model.common.AccountKeyInfoResp;
import au.com.stgeorge.mbank.model.common.IMBResp;
import au.com.stgeorge.mbank.model.response.HistoryReceiptDetailResp;
import au.com.stgeorge.mbank.model.response.payments.HistoryReceiptResp;
import au.com.stgeorge.mbank.model.response.payments.NPPProcessingPaymentStatusResp;
import au.com.stgeorge.mbank.util.MBAppHelper;
import au.com.stgeorge.mbank.util.MBAppUtils;

/**
 * @author C50216
 *
 */
@Service
public class HistoryReceiptHelper {
			
	@Autowired
	private MBAppHelper mbAppHelper;
	
	private static final String TRAN_TYPE_BPAY = "BPAY";
	private static final String TRAN_TYPE_PAYEE = "TP";	
	private static final String TRAN_TYPE_PAYID = "PAYID";	
	private static final String TRAN_TYPE_ACCOUNT = "ACCT";
	private static final String TRAN_TYPE_TT = "TT";
	private static final String NEW_TERM_DEPOSIT_ACCOUNT_NAME = "Term Deposit";
	private static final String P2M_PAYEE_NUM = "Mobile - see description";
	private static final String AVAILABLE_AFTER_PROCESSING ="Available after processing";
	
	protected IMBResp populateResp(Collection<PaymentsLog> paymentsLog,Customer customer) {
		
		HistoryReceiptResp histReceiptResp = new HistoryReceiptResp();
		
		CodesVO myCodes = IBankParams.getCodesData(IBankParams.BRAND_ORIGIN, IBankParams.MOBILE_BANKING, IBankParams.MAX_PAY_HISTORY_DISPLAY);
		
		Integer maxRecs = Integer.parseInt(myCodes.getMessage());
		
		if (paymentsLog.size() > maxRecs.intValue())
			histReceiptResp.setOverThreshold(true);
		
		histReceiptResp.setHistReceiptList(getHistReceiptListResp(paymentsLog,customer,maxRecs.intValue()));
		
		return histReceiptResp;
		
	}
	/**
	 * 
	 * Method to populate response for payments stuck in processing
	 * Added as part of SGBEXP- 5743
	 * 
	 * @param paymentsLog
	 * @param customer
	 * @return
	 */
	protected IMBResp populateProcessingPaymentDetailResp(
			PaymentsLog paymentsLog, Customer customer) {

		NPPProcessingPaymentStatusResp nppProcessingPaymentStatusResp = new NPPProcessingPaymentStatusResp();
		HistoryReceiptDetailResp historyReceiptDetailResp = new HistoryReceiptDetailResp();
		
		historyReceiptDetailResp.setNppStatus(NPPTransactionStatusEnum.getNppTransactionDisplayStatus(paymentsLog.getStatus()));
		
		if (StringUtils.isNotEmpty(paymentsLog.getReceiptNumber())) {
			historyReceiptDetailResp.setReceiptNumDisp(MBAppUtils
					.formatReceiptNumber(paymentsLog.getReceiptNumber()));
		}
		else{
			if(NPPStatus.isStillProcessing(paymentsLog.getStatus())){
				historyReceiptDetailResp.setReceiptNumDisp(AVAILABLE_AFTER_PROCESSING);
			}
		}


		//	19E3 Warranty : Fix to send reject code and reason to UI
		if(NPPStatus.isFailure(paymentsLog.getStatus())) {
			historyReceiptDetailResp.setRejectCode(paymentsLog.getRejectCode());
			historyReceiptDetailResp.setRejectionReason(NPPUtil.getNPPPaymentRejectionMessage(null, paymentsLog.getRejectCode()));
			Logger.debug("populateProcessingPaymentDetailResp() NPP rejection reason:"+historyReceiptDetailResp.getRejectionReason()+" and code "+historyReceiptDetailResp.getRejectCode(), getClass());
		}
		historyReceiptDetailResp.setEndToEndID(paymentsLog.getEndToEndId());
		historyReceiptDetailResp.setStatus(paymentsLog.getStatusDescription());
		nppProcessingPaymentStatusResp.setReceipt(historyReceiptDetailResp);

		return nppProcessingPaymentStatusResp;

	}

	private List<HistoryReceiptDetailResp> getHistReceiptListResp(Collection<PaymentsLog> paymentHistLog,Customer customer,int maxRecs){
		
		List<HistoryReceiptDetailResp> list = null;		
		HistoryReceiptDetailResp histReceiptDtlResp;
		int recCount = 0;		
		 
		if(paymentHistLog!=null){
			
			list = new ArrayList<HistoryReceiptDetailResp>();
			Iterator<PaymentsLog> it = paymentHistLog.iterator();
			List<Account> accts = customer.getAccounts();
			
			while(it.hasNext() && recCount < maxRecs){
				
				histReceiptDtlResp = new HistoryReceiptDetailResp();
				PaymentsLog payLog = it.next();

				histReceiptDtlResp.setPaymentLogId(payLog.getId());
				//histReceiptDtlResp.setAmt(payLog.getFormatAmount().toString());
				histReceiptDtlResp.setAmt(new Double(payLog.getAmount()).toString());
				histReceiptDtlResp.setTranDateTime(payLog.getHostTimestamp());
				histReceiptDtlResp.setStatus(payLog.getStatusDescription());
								
				populateFromAccount(payLog, histReceiptDtlResp, accts);
				
				if (!StringMethods.isEmptyString(payLog.getErrormsg()))
					histReceiptDtlResp.setErrorDesc(payLog.getErrormsg());
				
				// Start: Changes for SBGEXP-5733 
				if(StringUtils.isNotEmpty(payLog.getReceiptNumber())){
				histReceiptDtlResp.setReceiptNumDisp(MBAppUtils.formatReceiptNumber(payLog.getReceiptNumber()));
				}
				
				if(NPPUtil.isNPPTransaction(payLog.getXrefType())){
					histReceiptDtlResp.setisOsko(true);
					histReceiptDtlResp.setPaymentTypeDesc(NPPUtil.OSKO);
					histReceiptDtlResp.setNppStatus(NPPTransactionStatusEnum.getNppTransactionDisplayStatus(payLog.getStatus()));
					histReceiptDtlResp.setNppPaymentId(payLog.getPaymentId());
					if(NPPStatus.isStillProcessing(payLog.getStatus())){
						histReceiptDtlResp.setReceiptNumDisp(AVAILABLE_AFTER_PROCESSING);
					}
				}
				else{
					
					if (PaymentsLog.TYPE_TRANSFER_TO_3RD_PARTY_SETUP.equals(payLog.getXrefType()) || PaymentsLog.TYPE_TRANSFER_TO_3RD_PARTY_SETUP_ON_US.equals(payLog.getXrefType())){
						histReceiptDtlResp.setPaymentTypeDesc(NPPUtil.ONLINE_PAYEE_TRANSFER);
					}
					else if(PaymentsLog.TYPE_TRANSFER_TO_3RD_PARTY.equals(payLog.getXrefType()) || PaymentsLog.TYPE_TRANSFER_TO_3RD_PARTY_ON_US.equals(payLog.getXrefType())){
						histReceiptDtlResp.setPaymentTypeDesc(NPPUtil.PAYEE_TRANSFER);
					}
					histReceiptDtlResp.setisOsko(false);
					histReceiptDtlResp.setNppPaymentId(null);
				}
				
				
				// End: Changes for SBGEXP-5733 
				if (PaymentsLog.TYPE_TRANSFER_TO_3RD_PARTY.equals(payLog.getXrefType()) 
						|| PaymentsLog.TYPE_TRANSFER_TO_3RD_PARTY_SETUP.equals(payLog.getXrefType())  
						|| PaymentsLog.TYPE_TRANSFER_TO_3RD_PARTY_MOBILE.equals(payLog.getXrefType()) 
						|| PaymentsLog.TYPE_P2P_TRANSFER.equals(payLog.getXrefType()) 
						|| PaymentsLog.TYPE_TRANSFER_NPP_CUSTOMER_SETUP.equals(payLog.getXrefType()) 
						|| PaymentsLog.TYPE_TRANSFER_NPP_BANK_SETUP.equals(payLog.getXrefType()) 
						|| PaymentsLog.TYPE_TRANSFER_NPP_DE_RETRY_CUSTOMER.equals(payLog.getXrefType())
						|| PaymentsLog.TYPE_TRANSFER_NPP_DE_RETRY_BANK.equals(payLog.getXrefType())){
					
					histReceiptDtlResp.setTranType(TRAN_TYPE_PAYEE);
					setPayeeReceiptDetail(payLog,histReceiptDtlResp);
					histReceiptDtlResp.setCanAddToFavourite(checkCanAddToFavourite(customer, payLog));
					
				}else if (PaymentsLog.TYPE_TRANSFER_TO_3RD_PARTY_ON_US.equals(payLog.getXrefType()) 
						|| PaymentsLog.TYPE_TRANSFER_TO_3RD_PARTY_SETUP_ON_US.equals(payLog.getXrefType())){
					
					histReceiptDtlResp.setErrorDesc(null);
					histReceiptDtlResp.setTranType(TRAN_TYPE_PAYEE);
					setPayeeReceiptDetail(payLog,histReceiptDtlResp);
					histReceiptDtlResp.setCanAddToFavourite(checkCanAddToFavourite(customer, payLog));
					
				}
				else if (PaymentsLog.TYPE_TRANSFER_NPP_PAYID_CUSTOMER.equals(payLog.getXrefType())){
					
					histReceiptDtlResp.setErrorDesc(null);
					histReceiptDtlResp.setTranType(TRAN_TYPE_PAYID);
					setPayIdReceiptDetail(payLog,histReceiptDtlResp);
				}
				else if (PaymentsLog.TYPE_BPAY.equals(payLog.getXrefType()) 
						||	PaymentsLog.TYPE_BPAY_VIEW.equals(payLog.getXrefType())){
					
					histReceiptDtlResp.setTranType(TRAN_TYPE_BPAY);
					setBillerReceiptDetail(payLog,histReceiptDtlResp);
					histReceiptDtlResp.setCanAddToFavourite(checkCanAddToFavourite(customer, payLog));
					
				}else if (PaymentsLog.TYPE_TELEGRAPHIC_TRANSFER.equals(payLog.getXrefType())){
					
					histReceiptDtlResp.setTranType(TRAN_TYPE_TT);
					setTTReceiptDetail(payLog,histReceiptDtlResp);
					
				}else if (PaymentsLog.TYPE_BANK_CHEQUE.equals(payLog.getXrefType()) 
						|| PaymentsLog.TYPE_BANK_CHEQUE_CANCEL.equals(payLog.getXrefType())){
										
					setBankChequeReceiptDetail(payLog,histReceiptDtlResp);
					
				}else if (PaymentsLog.TYPE_TRANSFER_TO_BT_MV.equals(payLog.getXrefType())){
					
					histReceiptDtlResp.setTranType(TRAN_TYPE_ACCOUNT);
					setBTReceiptDetail(payLog, histReceiptDtlResp, accts);
					
				}else if (PaymentsLog.TYPE_OPEN_NEW_ACCOUNT_ONLINE.equals(payLog.getXrefType())){
					
					histReceiptDtlResp.setTranType(PaymentsLog.TYPE_OPEN_NEW_ACCOUNT_ONLINE);
					setAcctOpenReceiptDetail(payLog,histReceiptDtlResp);
					
				}else if (PaymentsLog.TYPE_OPEN_TERM_DEPOSIT.equals(payLog.getXrefType())){
					
					histReceiptDtlResp.setTranType(PaymentsLog.TYPE_OPEN_NEW_ACCOUNT_ONLINE);
					setTDOpenReceiptDetail(payLog, histReceiptDtlResp, accts);
					
				}else if (PaymentsLog.TYPE_RENEW_TERM_DEPOSIT.equals(payLog.getXrefType())){
										
					histReceiptDtlResp.setTranType(TRAN_TYPE_ACCOUNT);
					setTDRenewDepositReceiptDetail(payLog, histReceiptDtlResp, accts);					
					
				}else if (PaymentsLog.TYPE_WITHDRAWAL_TERMDEP.equals(payLog.getXrefType())){
					
					histReceiptDtlResp.setTranType(TRAN_TYPE_ACCOUNT);
					setTDRenewWithdrawReceiptDetail(payLog, histReceiptDtlResp, accts);		
					
				}
				else if (PaymentsLog.TYPE_TRANSFER_TO_GCC.equals(payLog.getXrefType()) 
						){
					histReceiptDtlResp.setErrorDesc(null);
					histReceiptDtlResp.setTranType(PaymentsLog.TYPE_TRANSFER_TO_GCC) ;//TYPE_TRANSFER_TO_GCC);
					setGCCReceiptDetail(payLog,histReceiptDtlResp,accts);
					histReceiptDtlResp.setCanAddToFavourite(false);
				}
				else{																	
					histReceiptDtlResp.setTranType(TRAN_TYPE_ACCOUNT);
					setAcctReceiptDetail(payLog, histReceiptDtlResp, accts);
					
					//PaymentsLog.TYPE_TRANSFER_TO_NOMINATED confirmed with BA,allowed for Add to Favourite					
					if(PaymentsLog.TYPE_TD_INIT_DEPOSIT.equals(payLog.getXrefType()) 
							|| PaymentsLog.TYPE_TD_ADNL_DEPOSIT.equals(payLog.getXrefType()))							
						histReceiptDtlResp.setCanAddToFavourite(false);					
					else if (PaymentsLog.TYPE_STG_TO_STG_ACCOUNT_TRANSFER.equals(payLog.getXrefType())
							&& payLog.getXrefId() != 0)//XrefId is used for accountOpening with initial transfer
						histReceiptDtlResp.setCanAddToFavourite(false);
					else{
						histReceiptDtlResp.setCanAddToFavourite(checkCanAddToFavourite(customer, payLog));
					}
				}
				if(NPPUtil.isNPPTransaction(payLog.getXrefType())){
					histReceiptDtlResp.setRejectCode(payLog.getRejectCode());
				}				
				
				if(NPPUtil.isBsbAccOskoTransfer(payLog.getXrefType()) && NPPStatus.isFailure(payLog.getStatus())) {
					histReceiptDtlResp.setRejectionReason(NPPUtil.getNPPPaymentRejectionMessage(null, payLog.getRejectCode()));
				}
					
				if(NPPUtil.isPayId(payLog.getXrefType()) && NPPStatus.isFailure(payLog.getStatus())) {
					histReceiptDtlResp.setRejectionReason(NPPUtil.getPayIdPaymentRejectionMessage(null, payLog.getRejectCode()));
					Logger.debug("Setting rejection reason for PayID payment for code:"+payLog.getRejectCode()+" as:"+histReceiptDtlResp.getRejectionReason(), getClass());
				}
				
				list.add(histReceiptDtlResp);		
				recCount++;
			}											
		}					
		return list;
	}
	
	private boolean checkCanAddToFavourite(Customer customer, PaymentsLog payLog){
		
		Account fromAccount = null;
		fromAccount = mbAppHelper.getAccountByAccountKey(customer.getAccounts(), payLog.getAccountNumberFrom());
		if(fromAccount != null && fromAccount.getAccountId().getGroupCode() != null && Account.INCENTIVE_SAVER.equals(fromAccount.getAccountId().getGroupCode()))
		{
			return false;
		}else{
			return true;							
		}
		
	}

	
	private void setGCCReceiptDetail(PaymentsLog payLog,HistoryReceiptDetailResp histReceiptDtlResp, List<Account> accts){
		
		String toAcctNum = payLog.getDescription();		
		Account toAccount = MBAppHelper.getAccountByAccountNumber(accts, toAcctNum);
		if(null != toAccount){
			histReceiptDtlResp.setToAccountName(toAccount.getAlias());
			histReceiptDtlResp.setToAccountNumDisp( toAccount.getAlias());
		} else {
			histReceiptDtlResp.setToAccountName(" ");
			histReceiptDtlResp.setToAccountNumDisp(" ");
		}
	}	

	
	private void setPayeeReceiptDetail(PaymentsLog payLog,HistoryReceiptDetailResp histReceiptDtlResp){
		
		histReceiptDtlResp.setPayeeName(payLog.getDescription());
		histReceiptDtlResp.setPayeeBsbDisp(payLog.getBsbNumberTo());
		if(PaymentsLog.TYPE_P2P_TRANSFER.equals(payLog.getXrefType()))
		{		
			histReceiptDtlResp.setPayeeNum(P2M_PAYEE_NUM);
			histReceiptDtlResp.setPayeeBsbDisp("");
		}
		else
		{
			histReceiptDtlResp.setPayeeNum(StringUtil.formatCompassAccountNumber(payLog.getAccountNumberTo()));
		}				
		histReceiptDtlResp.setDesc(payLog.getReferenceNumber());	
		histReceiptDtlResp.setEndToEndID(payLog.getEndToEndId());
	}	
	
   private void setPayIdReceiptDetail(PaymentsLog payLog,HistoryReceiptDetailResp histReceiptDtlResp){
		
		histReceiptDtlResp.setPayIdName(payLog.getDescription());
		histReceiptDtlResp.setPayIdValue(NPPUtil.getFormattedPayID(payLog.getPayId(), payLog.getPayIdType(), false));
		histReceiptDtlResp.setDesc(payLog.getReferenceNumber());
		histReceiptDtlResp.setEndToEndID(payLog.getEndToEndId());
	}	
	
	private void setBillerReceiptDetail(PaymentsLog payLog,HistoryReceiptDetailResp histReceiptDtlResp){
		
		histReceiptDtlResp.setBillerAlias(payLog.getDescription());
		histReceiptDtlResp.setBillerCode(payLog.getBillerCode());
		histReceiptDtlResp.setCrn(payLog.getReferenceNumber());
				
	}
	
	private void setTTReceiptDetail(PaymentsLog payLog,HistoryReceiptDetailResp histReceiptDtlResp){
		
		histReceiptDtlResp.setBeneficiaryName(payLog.getDescription());
		histReceiptDtlResp.setBeneficiaryAccountNum(payLog.getAccountNumberTo());
		histReceiptDtlResp.setFormNumber(payLog.getReferenceNumber());
		histReceiptDtlResp.setCurrency(payLog.getCurrency());
		histReceiptDtlResp.setForexAmount(String.valueOf(payLog.getForexAmount()));
		histReceiptDtlResp.setPayerName(payLog.getPayerName());
						
	}
	
	private void setBankChequeReceiptDetail(PaymentsLog payLog,HistoryReceiptDetailResp histReceiptDtlResp){
		
		String desc;
		String tranType;
		if (PaymentsLog.TYPE_BANK_CHEQUE.equals(payLog.getXrefType())){
			tranType = PaymentsLog.TYPE_BANK_CHEQUE;			
			desc = "Order bank cheque";			
		}
		else{
			tranType = PaymentsLog.TYPE_BANK_CHEQUE_CANCEL;
			desc = "Cancel bank cheque";
		}
			
		histReceiptDtlResp.setTranType(tranType);
		histReceiptDtlResp.setDesc(desc);		
		histReceiptDtlResp.setToAccountNumDisp(payLog.getReferenceNumber());
		histReceiptDtlResp.setToAccountName(payLog.getAccountNumberTo());				
								
	}

	private void setBTReceiptDetail(PaymentsLog payLog,HistoryReceiptDetailResp histReceiptDtlResp, List<Account> accts){
				
		populateToAccount(payLog, histReceiptDtlResp, accts);				
		histReceiptDtlResp.setDesc(payLog.getReferenceNumber());
						
	}
	
	private void setAcctOpenReceiptDetail(PaymentsLog payLog,HistoryReceiptDetailResp histReceiptDtlResp){
		
		histReceiptDtlResp.setToAccountName(payLog.getAccountNumberTo());			
		histReceiptDtlResp.setDesc(payLog.getReferenceNumber());
		
	}
	
	
	private void setTDOpenReceiptDetail(PaymentsLog payLog,HistoryReceiptDetailResp histReceiptDtlResp, List<Account> accts){
		
		populateToAccount(payLog, histReceiptDtlResp, accts);				
		histReceiptDtlResp.setDesc(payLog.getReferenceNumber());
				
	}
	
	private void setTDRenewDepositReceiptDetail(PaymentsLog payLog,HistoryReceiptDetailResp histReceiptDtlResp, List<Account> accts){
		
		populateToAccount(payLog, histReceiptDtlResp, accts);						
		histReceiptDtlResp.setDesc(payLog.getDescription());
				
	}
	
	private void setTDRenewWithdrawReceiptDetail(PaymentsLog payLog,HistoryReceiptDetailResp histReceiptDtlResp, List<Account> accts){
		
		populateToAccount(payLog, histReceiptDtlResp, accts);				
		//swipeTDRenewWithdrawAccounts(histReceiptDtlResp);
		histReceiptDtlResp.setDesc(payLog.getDescription());
				
	}	
	
	private void setAcctReceiptDetail(PaymentsLog payLog,HistoryReceiptDetailResp histReceiptDtlResp, List<Account> accts){
		
		populateToAccount(payLog, histReceiptDtlResp, accts);					
		histReceiptDtlResp.setDesc(payLog.getReferenceNumber());
		
	}
	
	private void populateFromAccount(PaymentsLog payLog,HistoryReceiptDetailResp histReceiptDtlResp,List<Account> accts){
		
		Account fromAccount = MBAppHelper.getAccountByAccountNumber(accts, payLog.getAccountNumberFrom());
		
		if(fromAccount != null){						
			histReceiptDtlResp.setFromAccountName(fromAccount.getAlias());
			
			AccountKeyInfoResp acctKeyInfo = new AccountKeyInfoResp();
			if(IBankParams.isSwitchOn(IBankParams.CARD_NUM_MASK_SWITCH)) {
				acctKeyInfo.setAccountNum(fromAccount.getAccountId().getFormattedAccountNumber());
			}
			else {
				acctKeyInfo.setAccountNum(fromAccount.getAccountId().getAccountNumber());
			}
			acctKeyInfo.setAccountType(fromAccount.getAccountId().getApplicationId());
			if(!(Account.CREDIT_CARD.equalsIgnoreCase(fromAccount.getAccountId().getEhubProductCode())
					|| Account.TERM_DEPOSIT.equalsIgnoreCase(fromAccount.getAccountId().getEhubProductCode())))
				acctKeyInfo.setBsb(Integer.parseInt(fromAccount.getAccountId().getBsb()));
			
			histReceiptDtlResp.setFromAccountType(acctKeyInfo.getAccountType());
			histReceiptDtlResp.setFromAccountNum(acctKeyInfo.getAccountNum());
			histReceiptDtlResp.setFromAccountNumDisp(acctKeyInfo.getAccountNumDisp());
			histReceiptDtlResp.setFromBsbDisp(acctKeyInfo.getBsbDisp());
		}else{
			//"fromDetails" histReceiptDtlResp.setFromAccountName(payLog.getFromAccountAlias() + "-" + payLog.getAccountNumberFrom());
			histReceiptDtlResp.setFromAccountNum(payLog.getAccountNumberFrom());
			
			if(IBankParams.isSwitchOn(IBankParams.CARD_NUM_MASK_SWITCH)){	
				if(payLog.getAccountNumberFrom()!=null && payLog.getAccountNumberFrom().length()==16) {
					histReceiptDtlResp.setFromAccountName(StringUtil.formatCardNumber(payLog.getAccountNumberFrom()));
					histReceiptDtlResp.setFromAccountNumDisp(StringUtil.formatCardNumber(payLog.getAccountNumberFrom()));
				}
				else {
					histReceiptDtlResp.setFromAccountName(payLog.getAccountNumberFrom());
					histReceiptDtlResp.setFromAccountNumDisp(StringUtil.formatCompassAccountNumber(payLog.getAccountNumberFrom()));
				}
			}
			else {
				histReceiptDtlResp.setFromAccountName(payLog.getAccountNumberFrom());
				histReceiptDtlResp.setFromAccountNumDisp(StringUtil.formatCompassAccountNumber(payLog.getAccountNumberFrom()));
			}
			
			
		}
		
	}
	
	private void populateToAccount(PaymentsLog payLog,HistoryReceiptDetailResp histReceiptDtlResp,List<Account> accts){		
						
		String toAcctNum = payLog.getAccountNumberTo().replaceAll(" ", "");		
		Account toAccount = MBAppHelper.getAccountByAccountNumber(accts, toAcctNum);
		if(toAccount != null){			
			histReceiptDtlResp.setToAccountName(toAccount.getAlias());
			
			AccountKeyInfoResp acctKeyInfo = new AccountKeyInfoResp();
			acctKeyInfo.setAccountNum(toAccount.getAccountId().getAccountNumber());
			acctKeyInfo.setAccountType(toAccount.getAccountId().getApplicationId());
			
			if(!(Account.CREDIT_CARD.equalsIgnoreCase(toAccount.getAccountId().getEhubProductCode())
					|| Account.TERM_DEPOSIT.equalsIgnoreCase(toAccount.getAccountId().getEhubProductCode())))			
				acctKeyInfo.setBsb(Integer.parseInt(toAccount.getAccountId().getBsb()));
			
			histReceiptDtlResp.setToAccountNumDisp(acctKeyInfo.getAccountNumDisp());
		
			histReceiptDtlResp.setToBsbDisp(acctKeyInfo.getBsbDisp());
		}else{
			
			if(payLog.getBsbNumberTo() != null)
				histReceiptDtlResp.setToBsbDisp(StringUtil.formatBSBNumber(payLog.getBsbNumberTo()));
			
			if(PaymentsLog.TYPE_OPEN_TERM_DEPOSIT.equals(payLog.getXrefType())){
				histReceiptDtlResp.setToAccountName(NEW_TERM_DEPOSIT_ACCOUNT_NAME);				
			}else{
				if(IBankParams.isSwitchOn(IBankParams.CARD_NUM_MASK_SWITCH)){	
					if(payLog.getAccountNumberTo()!=null && payLog.getAccountNumberTo().length()==16) {
						histReceiptDtlResp.setToAccountName(StringUtil.formatCardNumber(payLog.getAccountNumberTo()));
					}
					else {
						histReceiptDtlResp.setToAccountName(StringUtil.formatCompassAccountNumber(payLog.getAccountNumberTo()));
					}
				}
				else {
					histReceiptDtlResp.setToAccountName(StringUtil.formatCompassAccountNumber(payLog.getAccountNumberTo()));
				}
			}
			
			if (PaymentsLog.TYPE_RENEW_TERM_DEPOSIT.equals(payLog.getXrefType()) || PaymentsLog.TYPE_WITHDRAWAL_TERMDEP.equals(payLog.getXrefType()) ){
				histReceiptDtlResp.setToAccountNumDisp(StringUtil.formatCDAAccountNumber(payLog.getAccountNumberTo()));
				histReceiptDtlResp.setToAccountName(StringUtil.formatCDAAccountNumber(payLog.getAccountNumberTo()));
			}
			else{
				
				if(IBankParams.isSwitchOn(IBankParams.CARD_NUM_MASK_SWITCH)){	
					if(payLog.getAccountNumberTo()!=null && payLog.getAccountNumberTo().length()==16) {
						histReceiptDtlResp.setToAccountNumDisp(StringUtil.formatCardNumber(payLog.getAccountNumberTo()));
					}
					else {
						histReceiptDtlResp.setToAccountNumDisp(StringUtil.formatCompassAccountNumber(payLog.getAccountNumberTo()));
					}
				}
				else {
					histReceiptDtlResp.setToAccountNumDisp(StringUtil.formatCompassAccountNumber(payLog.getAccountNumberTo()));
				}
			}
		}		
	}
	
	/*private void swipeTDRenewWithdrawAccounts(HistoryReceiptDetailResp histReceiptDtlResp){
		
		String tempToAcctName = histReceiptDtlResp.getToAccountName();
		String tempToAcctNum = histReceiptDtlResp.getToAccountNumDisp();		
		String tempToBsb = histReceiptDtlResp.getToBsbDisp();
		
		histReceiptDtlResp.setToAccountName(histReceiptDtlResp.getFromAccountName());
		histReceiptDtlResp.setToAccountNumDisp(histReceiptDtlResp.getFromAccountNumDisp());
		histReceiptDtlResp.setToBsbDisp(histReceiptDtlResp.getFromBsbDisp());
		
		histReceiptDtlResp.setFromAccountName(tempToAcctName);
		histReceiptDtlResp.setFromAccountNumDisp(tempToAcctNum);
		histReceiptDtlResp.setFromBsbDisp(tempToBsb);
								
	}*/
	
}
