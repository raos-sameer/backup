package au.com.stgeorge.mbank.model.mortgageinfo;

import java.io.Serializable;
import java.util.List;

import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.Range;

import au.com.stgeorge.ibank.businessobject.BusinessException;


import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_NULL)
public class LiabilityInfo implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 7093613573344929280L;
	private Integer index;
	private String liabilityCategory;
	private String liabilityType;
	private String bankCode;
	private Boolean shareCreditCard;
	private String propertyIndex;
	private Boolean toBePaidOut;
	private String repaymentType;
	private String repaymentFreq;
	private Boolean sharedLiability;

	@Range(max=100, message = ""+BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE)
	@Pattern(regexp="([0-9]+[.]?[0-9]?[0-9]?)",message = ""+BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE)
	private String owner1Percent;

	@Range(max=100, message = ""+BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE)
	@Pattern(regexp="([0-9]+[.]?[0-9]?[0-9]?)",message = ""+BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE)
	private String owner2Percent;

	@Range(max=100, message = ""+BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE)
	@Pattern(regexp="([0-9]+[.]?[0-9]?[0-9]?)",message = ""+BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE)
	private String otherPercent;

	@Range(min=-9999999, max=9999999, message = ""+BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE)
	@Pattern(regexp="(-?[0-9]+[.]?[0-9]?[0-9]?)",message = ""+BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE)
	private String currentBal;
	
	@Pattern(regexp="(-?[0-9]+[.]?[0-9]?[0-9]?)",message = ""+BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE)
	private String remaningLoanAmt;

	@Range(min=-9999999, max=9999999, message = ""+BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE)
	@Pattern(regexp="(-?[0-9]+[.]?[0-9]?[0-9]?)",message = ""+BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE)
	private String limitAmt;

	@Range(max=9999999, message = ""+BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE)
	@Pattern(regexp="([0-9]+[.]?[0-9]?[0-9]?)",message = ""+BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE)
	private String repaymentAmt;
	
	@Pattern(regexp="([0-9]+[.]?[0-9]?[0-9]?)",message = ""+BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE)
	private String remainingTermInMonths;
	
	@Pattern(regexp="([0-9]+[.]?[0-9]?[0-9]?)",message = ""+BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE)	
	private String remainingInterestTermInMonths;

	@Range(min=-9999999,max=9999999, message = ""+BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE)
	@Pattern(regexp="(-?[0-9]+[.]?[0-9]?[0-9]?)",message = ""+BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE)
	private String availableRedrawAmt;
	
	@Pattern(regexp="([0-9]+[.]?[0-9]?[0-9]?)",message = ""+BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE)
	private String intRateForMortgage;
	
	private String accountNumber;
	
	private String relationship;
	
	private List<Integer> propertyIndexes;
	
	public Integer getIndex() {
		return index;
	}
	public void setIndex(Integer index) {
		this.index = index;
	}
	public String getLiabilityCategory() {
		return liabilityCategory;
	}
	public void setLiabilityCategory(String liabilityCategory) {
		this.liabilityCategory = liabilityCategory;
	}
	public String getLiabilityType() {
		return liabilityType;
	}
	public void setLiabilityType(String liabilityType) {
		this.liabilityType = liabilityType;
	}
	public String getBankCode() {
		return bankCode;
	}
	public void setBankCode(String bankCode) {
		this.bankCode = bankCode;
	}
	public String getCurrentBal() {
		return currentBal;
	}
	public void setCurrentBal(String currentBal) {
		this.currentBal = currentBal;
	}
	public String getLimitAmt() {
		return limitAmt;
	}
	public void setLimitAmt(String limitAmt) {
		this.limitAmt = limitAmt;
	}
	public String getRepaymentAmt() {
		return repaymentAmt;
	}
	public void setRepaymentAmt(String repaymentAmt) {
		this.repaymentAmt = repaymentAmt;
	}
	public String getRepaymentType() {
		return repaymentType;
	}
	public void setRepaymentType(String repaymentType) {
		this.repaymentType = repaymentType;
	}
	public String getRepaymentFreq() {
		return repaymentFreq;
	}
	public void setRepaymentFreq(String repaymentFreq) {
		this.repaymentFreq = repaymentFreq;
	}
	public String getIntRateForMortgage() {
		return intRateForMortgage;
	}
	public void setIntRateForMortgage(String intRateForMortgage) {
		this.intRateForMortgage = intRateForMortgage;
	}
	public String getAvailableRedrawAmt() {
		return availableRedrawAmt;
	}
	public void setAvailableRedrawAmt(String availableRedrawAmt) {
		this.availableRedrawAmt = availableRedrawAmt;
	}

	public String getOwner1Percent() {
		return owner1Percent;
	}
	public void setOwner1Percent(String owner1Percent) {
		this.owner1Percent = owner1Percent;
	}
	public String getOwner2Percent() {
		return owner2Percent;
	}
	public void setOwner2Percent(String owner2Percent) {
		this.owner2Percent = owner2Percent;
	}
	public String getOtherPercent() {
		return otherPercent;
	}
	public void setOtherPercent(String otherPercent) {
		this.otherPercent = otherPercent;
	}
	public String getRemaningLoanAmt() {
		return remaningLoanAmt;
	}
	public void setRemaningLoanAmt(String remaningLoanAmt) {
		this.remaningLoanAmt = remaningLoanAmt;
	}
	public String getRemainingTermInMonths() {
		return remainingTermInMonths;
	}
	public void setRemainingTermInMonths(String remainingTermInMonths) {
		this.remainingTermInMonths = remainingTermInMonths;
	}
	public String getPropertyIndex() {
		return propertyIndex;
	}
	public void setPropertyIndex(String propertyIndex) {
		this.propertyIndex = propertyIndex;
	}
	public Boolean getSharedLiability() {
		return sharedLiability;
	}
	public void setSharedLiability(Boolean sharedLiability) {
		this.sharedLiability = sharedLiability;
	}
	public String getRemainingInterestTermInMonths() {
		return remainingInterestTermInMonths;
	}
	public void setRemainingInterestTermInMonths(
			String remainingInterestTermInMonths) {
		this.remainingInterestTermInMonths = remainingInterestTermInMonths;
	}
	public Boolean getShareCreditCard() {
		return shareCreditCard;
	}
	public void setShareCreditCard(Boolean shareCreditCard) {
		this.shareCreditCard = shareCreditCard;
	}
	public Boolean getToBePaidOut() {
		return toBePaidOut;
	}
	public void setToBePaidOut(Boolean toBePaidOut) {
		this.toBePaidOut = toBePaidOut;
	}
	public String getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}
	public String getRelationship() {
		return relationship;
	}
	public void setRelationship(String relationship) {
		this.relationship = relationship;
	}
	public List<Integer> getPropertyIndexes() {
		return propertyIndexes;
	}
	public void setPropertyIndexes(List<Integer> propertyIndexes) {
		this.propertyIndexes = propertyIndexes;
	}
}
