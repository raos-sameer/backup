package au.com.stgeorge.mbank.controller.pwdreset;

import java.io.IOException;
import java.util.Date;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.builder.ReflectionToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import au.com.stgeorge.framework.common.logging.Logger;
import au.com.stgeorge.framework.common.model.User;
import au.com.stgeorge.framework.common.util.StringMethods;
import au.com.stgeorge.ibank.businessobject.BusinessException;
import au.com.stgeorge.ibank.businessobject.HeartBeat;
import au.com.stgeorge.ibank.businessobject.IBankSecureService;
import au.com.stgeorge.ibank.businessobject.MemoryThrottlingService;
import au.com.stgeorge.ibank.businessobject.PreferencesService;
import au.com.stgeorge.ibank.businessobject.ResourceException;
import au.com.stgeorge.ibank.businessobject.pwdreset.PwdResetService;
import au.com.stgeorge.ibank.common.cache.IBankParams;
import au.com.stgeorge.ibank.safi.businessobject.Safi2Service;
import au.com.stgeorge.ibank.safi.util.SafiConstants;
import au.com.stgeorge.ibank.safi.util.SafiUtil;
import au.com.stgeorge.ibank.safi.valueobject.SafiDeviceInfo;
import au.com.stgeorge.ibank.safi.valueobject.SafiPwdResetVO;
import au.com.stgeorge.ibank.service.valueobject.SafiRespVO;
import au.com.stgeorge.ibank.valueobject.ContactDetail;
import au.com.stgeorge.ibank.valueobject.Customer;
import au.com.stgeorge.ibank.valueobject.IBankSecureDetails;
import au.com.stgeorge.ibank.valueobject.PhoneNumber;
import au.com.stgeorge.ibank.valueobject.Preference;
import au.com.stgeorge.ibank.valueobject.database.OriginsVO;
import au.com.stgeorge.ibank.valueobject.pwdreset.PwdResetCustomerDetails;
import au.com.stgeorge.ibank.valueobject.pwdreset.PwdResetDetails;
import au.com.stgeorge.ibank.valueobject.transfer.IBankCommonData;
import au.com.stgeorge.mbank.controller.IMBController;
import au.com.stgeorge.mbank.controller.SafiWebHelper;
import au.com.stgeorge.mbank.controller.SecureCodeHelper;
import au.com.stgeorge.mbank.controller.customer.LogonHelper;
import au.com.stgeorge.mbank.model.common.IMBReq;
import au.com.stgeorge.mbank.model.common.IMBResp;
import au.com.stgeorge.mbank.model.common.ReqHeader;
import au.com.stgeorge.mbank.model.common.RespHeader;
import au.com.stgeorge.mbank.model.request.SecureCodeReq;
import au.com.stgeorge.mbank.model.request.canretrieval.CanRetrievalReq;
import au.com.stgeorge.mbank.model.request.pwdreset.PwdResetReq;
import au.com.stgeorge.mbank.model.request.pwdreset.PwdSecNumResetReq;
import au.com.stgeorge.mbank.model.response.ErrorResp;
import au.com.stgeorge.mbank.model.response.canretrieval.CanRetrievalResp;
import au.com.stgeorge.mbank.model.response.pwdreset.PwdResetResp;
import au.com.stgeorge.mbank.session.IGenericSession;
import au.com.stgeorge.mbank.session.MobileSession;
import au.com.stgeorge.mbank.session.MobileSessionImpl;
import au.com.stgeorge.mbank.util.FraudLogger;
import au.com.stgeorge.mbank.util.MBAppConstants;
import au.com.stgeorge.mbank.util.MBAppHelper;
import au.com.stgeorge.mbank.util.MBAppUtils;
import au.com.stgeorge.mbank.util.MBAppValidator;
import au.com.stgeorge.mbank.util.ServiceConstants;
import au.com.stgeorge.mobilebank.businessobject.MobileBankService;
import au.com.stgeorge.perflogger.PerformanceLogger;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;

@Controller
public class PwdResetController implements IMBController {
	
	@Autowired
	private MBAppValidator mbAppValidator;
	
	@Autowired
	private MBAppHelper mbAppHelper;

	@Autowired
	private PerformanceLogger perfLogger;
	
	@Autowired
	private PwdResetHelper pwdResetHelper;
	
	@Autowired
	private PwdResetService pwdResetService;	
	
	@Autowired
	private SecureCodeHelper secureCodeHelper;	

	@Autowired
	private LogonHelper logonHelper;
	
	@Autowired
	private MobileBankService mobileBankService;
	
	@Autowired
	private Safi2Service safi2Service; 
	
	@Autowired
	private MemoryThrottlingService memoryThrottlingService;  
	
	private FraudLogger fraudLogger;

	@RequestMapping(method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE, value = "/pwdreset/valcandetail")
	@ResponseBody
	public IMBResp valcandetail(HttpServletRequest httpRequest,HttpServletResponse httpServletResponse, @RequestBody final CanRetrievalReq request) {
		Logger.debug("PwdResetController - valcandetail(). Request: " + request, this.getClass());
		String logName = startPerformanceLog(httpRequest);
		MobileSession mobileSession = new MobileSessionImpl();
		CanRetrievalResp resp = null;
		IBankCommonData commonData = null;
		PwdResetCustomerDetails pwdResetCustomerDetails = null;
		String origin = logonHelper.resolveOrigin(httpRequest);;
		fraudLogger = new FraudLogger(); 

		try {
			mobileSession.getSessionContext(httpRequest);
			commonData = new MBAppHelper().populateIBankCommonData(mobileSession, httpRequest);

			validateRequestHeader(request.getHeader(), httpRequest);
			ErrorResp errorResponse = validate(request, httpRequest);
			Date dob = pwdResetHelper.validateDateOfBirth(request.getDateOfBirth());
			if (errorResponse.hasErrors())
				return errorResponse;
			
			pwdResetCustomerDetails = generateCANSecureCodeInfo(dob, request, commonData, origin, httpRequest, httpServletResponse,logName);
			if(pwdResetCustomerDetails != null){
				pwdResetCustomerDetails.setCardNumber(request.getCardNum());
				pwdResetCustomerDetails.setIssueNum(request.getIssueNum());			
				resp = populateResponse(pwdResetCustomerDetails, ServiceConstants.VAL_CAN_DETAIL,mobileSession);	
				createSession(pwdResetCustomerDetails, origin, httpRequest, httpServletResponse,mobileSession, logName);
			}
			fraudLogger.logCANPWD(mobileSession.getSessionID(), pwdResetCustomerDetails.getCan(), pwdResetCustomerDetails.getGcisNumber(), request.getCardNum(), request.getIssueNum(), request.getDateOfBirth(), origin, commonData.getIpAddress(), ServiceConstants.CAN_RETRIEVAL, commonData.getUserAgent(), null);			
			return resp;
		} catch (BusinessException e) {
			Logger.error("BusinessException in PwdResetController - valcandetail() - [key: " + e.getKey() + "], GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());
			fraudLogger.logCANPWD(null, null, null, request.getCardNum(), request.getIssueNum(), request.getDateOfBirth(), origin, commonData != null ? commonData.getIpAddress() : "", ServiceConstants.CAN_RETRIEVAL, commonData != null ? commonData.getUserAgent() : "", e);	
			return MBAppUtils.createErrorResp(origin, e, ServiceConstants.VAL_CAN_DETAIL, httpRequest);
		} catch (ResourceException e) {
			Logger.error("ResourceException in PwdResetController - valcandetail() - [key: " + e.getKey() + "], GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());
			mobileSession.removeTransaction();
			fraudLogger.logCANPWD(null, null, null, request.getCardNum(), request.getIssueNum(), request.getDateOfBirth(), origin, commonData != null ? commonData.getIpAddress() : "", ServiceConstants.CAN_RETRIEVAL, commonData != null ? commonData.getUserAgent() : "", e);	
			return MBAppUtils.createErrorResp("ALL", BusinessException.SYSTEM_UNAVILABLE, ServiceConstants.VAL_CAN_DETAIL, httpRequest);
		} catch (Exception e) {
			Logger.error("Exception PwdResetController - valcandetail(): GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			fraudLogger.logCANPWD(null, null, null, request.getCardNum(), request.getIssueNum(), request.getDateOfBirth(), origin, commonData != null ? commonData.getIpAddress() : "", ServiceConstants.CAN_RETRIEVAL, commonData != null ? commonData.getUserAgent() : "", e);	
			mobileSession.removeTransaction();
			return MBAppUtils.createErrorResp(origin, BusinessException.GENERIC_ERROR, ServiceConstants.VAL_CAN_DETAIL, httpRequest);
		} finally {
			endPerformanceLog(logName);
		}

	}
	
	@RequestMapping(method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE, value = "/pwdreset/reqcansecurecode")
	@ResponseBody
	public IMBResp reqCANSecureCode(HttpServletRequest httpRequest, @RequestBody final SecureCodeReq request) {
		Logger.debug("PwdResetController - reqCANSecureCode(). Request: " + request, this.getClass());
		String logName = startPerformanceLog(httpRequest);
		MobileSession mobileSession = new MobileSessionImpl();

		try {
			mobileSession.getSessionContext(httpRequest);
			IBankCommonData commonData = new MBAppHelper().populateIBankCommonData(mobileSession, httpRequest);
			
			validateRequestHeader(request.getHeader(), httpRequest);
			ErrorResp errorResponse = validate(request, httpRequest);// validate json
			if (errorResponse.hasErrors())
				return errorResponse;
			
			if (ServiceConstants.CAN_RETRIEVAL_TRAN_CODE != request.getTranType()){
				return MBAppUtils.createInvalid2FATransactionTypeResponse(ServiceConstants.REQ_2FA_CAN_RETRIEVAL);
			}
			PwdResetCustomerDetails pwdResetDetails =new PwdResetCustomerDetails();			
			
			return secureCodeHelper.reqSecureCode(commonData, mobileSession, null, pwdResetDetails, request, ServiceConstants.REQ_2FA_CAN_RETRIEVAL, httpRequest);
		} catch (ResourceException e) {
			Logger.error("ResourceException in PwdResetController - reqCANSecureCode() - [key: " + e.getKey() + "], GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());
			mobileSession.removeSecureCodeDetails();
			return MBAppUtils.createErrorResp("ALL", BusinessException.SYSTEM_UNAVILABLE, ServiceConstants.REQ_2FA_CAN_RETRIEVAL, httpRequest);
		} catch (Exception e) {
			Logger.error("Exception PwdResetController - reqCANSecureCode(): GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "]", e, this.getClass());
			mobileSession.removeSecureCodeDetails();
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.GENERIC_ERROR, ServiceConstants.REQ_2FA_CAN_RETRIEVAL, httpRequest);
		} finally {
			endPerformanceLog(logName);
		}

	}	
	
	@RequestMapping(method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE, value = "/pwdreset/retrievecan")
	@ResponseBody
	public IMBResp retrieveCAN(HttpServletRequest httpRequest, @RequestBody final SecureCodeReq request) {
		Logger.debug("PwdResetController - retrieveCAN(). Request: " + request, this.getClass());
		String logName = startPerformanceLog(httpRequest);
		MobileSession mobileSession = new MobileSessionImpl();
		String origin = logonHelper.resolveOrigin(httpRequest);
		try {
			mobileSession.getSessionContext(httpRequest);
			IBankCommonData commonData = new MBAppHelper().populateIBankCommonData(mobileSession, httpRequest);
			
			validateRequestHeader(request.getHeader(), httpRequest);
			ErrorResp errorResponse = validate(request, httpRequest);// validate json
			if (errorResponse.hasErrors())
				return errorResponse;

			if (ServiceConstants.CAN_RETRIEVAL_TRAN_CODE != request.getTranType()) 
				return MBAppUtils.createInvalid2FATransactionTypeResponse(ServiceConstants.VERIFY_2FA_CAN_RETRIEVAL);			
			
			PwdResetCustomerDetails pwdResetDetails =new PwdResetCustomerDetails();	
			errorResponse = secureCodeHelper.verifySecureCode(commonData, mobileSession, pwdResetDetails, request, ServiceConstants.VERIFY_2FA_CAN_RETRIEVAL, httpRequest);
			if (errorResponse.hasErrors())
				return errorResponse;
			else{
				pwdResetDetails=pwdResetHelper.populatePwdResetCustomerDetails(commonData);
				pwdResetDetails.setSessionID(mobileSession.getSessionID());
				String gdwOrigin = pwdResetHelper.getGDWOrigin(request.getHeader(), origin);
				mobileSession.setGDWOrigin(gdwOrigin);
				commonData.setGdwOrigin(gdwOrigin);

				pwdResetService.sendCANviaSMS(pwdResetDetails,commonData);
				CanRetrievalResp resp =populateCANRetrievalResp(ServiceConstants.VERIFY_2FA_CAN_RETRIEVAL,mobileSession);
				//invalidate the session after successful retrieval
				mobileSession.invalidateSession();
				return resp;
			}
			
		} catch (ResourceException e) {
			Logger.error("Exception PwdResetController - retrieveCAN(): GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "]", e, this.getClass());
			mobileSession.removeTransaction();
			mobileSession.removeSecureCodeDetails();
			return MBAppUtils.createErrorResp("ALL", BusinessException.SYSTEM_UNAVILABLE, ServiceConstants.VERIFY_2FA_CAN_RETRIEVAL, httpRequest);
		} catch (Exception e) {
			Logger.error("Exception PwdResetController - retrieveCAN(): GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "]", e, this.getClass());
			mobileSession.removeTransaction();
			mobileSession.removeSecureCodeDetails();
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.GENERIC_ERROR, ServiceConstants.VERIFY_2FA_CAN_RETRIEVAL, httpRequest);
		} finally {
			endPerformanceLog(logName);
		}

	}
	
	
	@RequestMapping(method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE, value = "/pwdreset/valpwddetail")
	@ResponseBody
	public IMBResp valPwdDetail(HttpServletRequest httpRequest,HttpServletResponse httpServletResponse, @RequestBody final PwdResetReq request) {
		Logger.debug("PwdResetController - valPwdDetail(). Request: " + request, this.getClass());
		String logName = startPerformanceLog(httpRequest);
		MobileSession mobileSession = new MobileSessionImpl();
		IMBResp resp = null;
		PwdResetCustomerDetails pwdResetCustomerDetails = null;
		PwdResetResp pwdResetResp = null;
		IBankCommonData commonData = null;
		String origin = logonHelper.resolveOrigin(httpRequest);
		fraudLogger = new FraudLogger(); 
		boolean isSafiServiceAvailable = false;
		IGenericSession genericSession = null ;
		
		try {
			mobileSession.getSessionContext(httpRequest);
			commonData = new MBAppHelper().populateIBankCommonData(mobileSession, httpRequest);

			validateRequestHeader(request.getHeader(), httpRequest);
			ErrorResp errorResponse = validate(request, httpRequest);
			Date dob = pwdResetHelper.validateDateOfBirth(request.getDateOfBirth());
			if (errorResponse.hasErrors())
				return errorResponse;

			pwdResetCustomerDetails = generatePwdResetSecureCodeInfo(dob, request, commonData, origin, httpRequest, httpServletResponse,logName);
			if(pwdResetCustomerDetails != null){
				//set the CAN as this is required to be put in session
				//pwdResetCustomerDetails.setCan(request.getCan());		
				pwdResetResp = populatePwdResetResponse(pwdResetCustomerDetails, ServiceConstants.VAL_PWD_DETAIL,mobileSession);
				genericSession = createSessionForPwdReset(pwdResetCustomerDetails, commonData, origin, httpRequest, httpServletResponse, mobileSession, logName);
			}
			boolean isSafiPwdResetSwitchOn = IBankParams.isSwitchOn(IBankParams.DEFAULT_ORIGIN, IBankParams.SAFI_PASSWORD_RESET_SWITCH);
			Logger.debug("SAFI : pwd reset Switch Value: "+isSafiPwdResetSwitchOn, this.getClass());
			
			if(isSafiPwdResetSwitchOn) {
				isSafiServiceAvailable = HeartBeat.isApplicationAvailable(HeartBeat.SAFI2_SERVICE_APPLICATION);
				Logger.info("SAFI : Pwd Reset:: SAFI2_SERVICE_APPLICATION STATUS: "+isSafiServiceAvailable, this.getClass());
			}
			if(isSafiServiceAvailable){
				boolean	isThrottleAllowed = memoryThrottlingService.processThrottling(IBankParams.THROTTLE_CAT_PASSWORD_RESET, pwdResetCustomerDetails.getGcisNumber(), mobileSession.getSessionID());
				
				if(isThrottleAllowed){
					pwdResetResp = callSafiAnalyseForPasswordReset(httpRequest, httpServletResponse, mobileSession, commonData, request, pwdResetResp, genericSession);
				}else {
					pwdResetResp.setSecureCodeReqd(true);
				}
			}else {
				pwdResetResp.setSecureCodeReqd(true);
			}
			if (!pwdResetResp.isSecureCodeReqd()) {
				genericSession.setAttribute(MobileSessionImpl.LAST_2FA_TRANSACTION, ServiceConstants.REQ_2FA_PWDRESET);
			}else {
				if (pwdResetHelper.isNoContactPhoneNumberAvailable(pwdResetCustomerDetails)) {
					throw new BusinessException(BusinessException.INVALID_DETAILS);
				} else if (IBankSecureService.isCustomerExempt(commonData.getCustomer().getIBankSecureDetails())) {
					throw new BusinessException(BusinessException.INVALID_DETAILS);
				} else if (IBankParams.isGlobalByPass()) {
					throw new BusinessException(BusinessException.INVALID_DETAILS);
				}
			}
			fraudLogger.logCANPWD(mobileSession.getSessionID(), request.getCan(), pwdResetCustomerDetails.getGcisNumber(), null, null, request.getDateOfBirth(), origin, commonData.getIpAddress(), ServiceConstants.PWD_RESET, commonData.getUserAgent(), null);
			return pwdResetResp;
		} catch (BusinessException e) {
			Logger.warn("BusinessException in PwdResetController - valPwdDetail() - [key: " + e.getKey() + "], GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());
			fraudLogger.logCANPWD(null, request.getCan(), null, null, null, request.getDateOfBirth(), origin, commonData != null ? commonData.getIpAddress() : "", ServiceConstants.PWD_RESET, commonData != null ? commonData.getUserAgent() : "", e);
			if(e.getKey()==BusinessException.SAFI_PWDRESET_2FA_DENY){
				Logger.debug("BusinessException in PwdResetController - SAFI DENY", this.getClass());
				OriginsVO myOriginVO = IBankParams.getOrigin(origin);
				OriginsVO baseOrigin = IBankParams.getOrigin(myOriginVO.getBankName());
				String[] values = { baseOrigin.getBpayPhone()};
				resp = MBAppUtils.createErrorResp(IBankParams.getBaseOriginCode(origin), e,values, ServiceConstants.VAL_PWD_DETAIL, httpRequest);
				return resp;
			}
			return MBAppUtils.createErrorResp(origin, e, ServiceConstants.VAL_PWD_DETAIL, httpRequest);
		} catch (ResourceException e) {
			Logger.error("ResourceException in PwdResetController - valPwdDetail() - [key: " + e.getKey() + "], GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());
			fraudLogger.logCANPWD(null, request.getCan(), null, null, null, request.getDateOfBirth(), origin, commonData != null ? commonData.getIpAddress() : "", ServiceConstants.PWD_RESET, commonData != null ? commonData.getUserAgent() : "", e);
			mobileSession.removeTransaction();
			return MBAppUtils.createErrorResp("ALL", BusinessException.SYSTEM_UNAVILABLE, ServiceConstants.VAL_PWD_DETAIL, httpRequest);
		} catch (Exception e) {
			Logger.error("Exception PwdResetController - valPwdDetail(): GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			fraudLogger.logCANPWD(null, request.getCan(), null, null, null, request.getDateOfBirth(), origin, commonData != null ? commonData.getIpAddress() : "", ServiceConstants.PWD_RESET, commonData != null ? commonData.getUserAgent() : "", e);
			mobileSession.removeTransaction();
			return MBAppUtils.createErrorResp(origin, BusinessException.GENERIC_ERROR, ServiceConstants.VAL_PWD_DETAIL, httpRequest);
		} finally {
			if ( genericSession != null )
				genericSession.updateSession();	
			endPerformanceLog(logName);			
		}

	}	
	
	@RequestMapping(method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE, value = "/pwdreset/reqpwdsecurecode")
	@ResponseBody
	public IMBResp reqPwdResetSecureCode(HttpServletRequest httpRequest, HttpServletResponse httpServletResponse, @RequestBody final SecureCodeReq request) {
		Logger.debug("PwdResetController - reqPwdResetSecureCode(). Request: " + request, this.getClass());
		String logName = startPerformanceLog(httpRequest);
		MobileSession mobileSession = new MobileSessionImpl();

		try {
			mobileSession.getSessionContext(httpRequest);
			IBankCommonData commonData = new MBAppHelper().populateIBankCommonData(mobileSession, httpRequest);
			
			validateRequestHeader(request.getHeader(), httpRequest);
			ErrorResp errorResponse = validate(request, httpRequest);// validate json
			if (errorResponse.hasErrors())
				return errorResponse;
			
			if (ServiceConstants.PWD_RESET_TRAN_CODE != request.getTranType()){
				return MBAppUtils.createInvalid2FATransactionTypeResponse(ServiceConstants.REQ_2FA_PWDRESET);
			}
			PwdResetCustomerDetails pwdResetDetails =new PwdResetCustomerDetails();			
			//TODO - this needs to be removed.
			if(mobileSession.getSecureCodeVerifiedTranName() !=null){
				Logger.debug("getSecureCodeVerifiedTranName in session. " + mobileSession.getSecureCodeVerifiedTranName(), this.getClass());
			}
			IMBResp response =  secureCodeHelper.reqSecureCode(commonData, mobileSession, null, pwdResetDetails, request, ServiceConstants.REQ_2FA_PWDRESET, httpRequest);
			if(response instanceof ErrorResp){			
				errorResponse = (ErrorResp) response;
				if (errorResponse.hasErrors()){
					//check SafiPwdResetVO exists in session.
					SafiPwdResetVO safiVO = null;
					String safiAction = null;
					if(null != mobileSession.getSafiRequestVO() && mobileSession.getSafiRequestVO() instanceof SafiPwdResetVO) {
						Logger.debug("SAFI VO available in session. ", this.getClass());
						safiVO = (SafiPwdResetVO) mobileSession.getSafiRequestVO();
						if(null != safiVO.getSafiRespVO())
							safiAction = safiVO.getSafiRespVO().getSafiAction();
					} 
					//SAFI notify call in case 2FA_SUSPENDED and SAFI_ACTION is a CHALLENGE
					if(errorResponse.getStatus() ==  ErrorResp.STATUS_2FA_SUSPENDED  && !(StringMethods.isEmptyString(safiAction)) && safiAction.equalsIgnoreCase(SafiConstants.SAFI_ACTION_CHALLENGE)){
						Logger.debug("SAFI : reqSecureCode(): Notify Call:START : SafiAction :Challenge: STATUS_2FA_SUSPENDED",this.getClass());
						callSafiNotifyForPasswordReset(httpRequest, httpServletResponse, false, commonData);
						Logger.debug("SAFI : reqSecureCode(): Notify Call:END : SafiAction :Challenge: STATUS_2FA_SUSPENDED",this.getClass());
					}
					
					return errorResponse;
				}
			}
			return response;
		} catch (ResourceException e) {
			Logger.error("ResourceException in PwdResetController - reqPwdResetSecureCode() - [key: " + e.getKey() + "], GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "] :", e,this.getClass());
			mobileSession.removeSecureCodeDetails();
			return MBAppUtils.createErrorResp("ALL", BusinessException.SYSTEM_UNAVILABLE, ServiceConstants.REQ_2FA_PWDRESET, httpRequest);
		} catch (Exception e) {
		
			Logger.error("Exception PwdResetController - reqPwdResetSecureCode(): GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "]", e, this.getClass());
			mobileSession.removeSecureCodeDetails();
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.GENERIC_ERROR, ServiceConstants.REQ_2FA_PWDRESET, httpRequest);
		} finally {
			endPerformanceLog(logName);
		}

	}	
	
	
	@RequestMapping(method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE, value = "/pwdreset/verifypwdsecurecode")
	@ResponseBody
	public IMBResp verifyPwdResetSecureCode(HttpServletRequest httpRequest, HttpServletResponse httpServletResponse, @RequestBody final SecureCodeReq request) {
		Logger.debug("PwdResetController - verifyPwdResetSecureCode(). Request: " + request, this.getClass());
		String logName = startPerformanceLog(httpRequest);
		MobileSession mobileSession = new MobileSessionImpl();

		try {
			mobileSession.getSessionContext(httpRequest);
			IBankCommonData commonData = new MBAppHelper().populateIBankCommonData(mobileSession, httpRequest);
			
			validateRequestHeader(request.getHeader(), httpRequest);
			ErrorResp errorResponse = validate(request, httpRequest);// validate json
			if (errorResponse.hasErrors())
				return errorResponse;

			if (ServiceConstants.PWD_RESET_TRAN_CODE != request.getTranType()) 
				return MBAppUtils.createInvalid2FATransactionTypeResponse(ServiceConstants.VERIFY_2FA_PWDRESET);			
			
			PwdResetCustomerDetails pwdResetDetails =new PwdResetCustomerDetails();	
			errorResponse = secureCodeHelper.verifySecureCode(commonData, mobileSession, pwdResetDetails, request, ServiceConstants.VERIFY_2FA_PWDRESET, httpRequest);
			
			//check SafiPwdResetVO exists in session.
			SafiPwdResetVO safiVO = null;
			String safiAction = null;
			if(null != mobileSession.getSafiRequestVO() && mobileSession.getSafiRequestVO() instanceof SafiPwdResetVO) {
				Logger.debug("SAFI VO available in session. ", this.getClass());
				safiVO = (SafiPwdResetVO) mobileSession.getSafiRequestVO();
				if(null != safiVO.getSafiRespVO())
					safiAction = safiVO.getSafiRespVO().getSafiAction();
			}else {
				Logger.debug("SAFI VO NOT available in session. ", this.getClass());
			}
			
			if (errorResponse.hasErrors()) {
				//SAFI notify call in case 2FA_SUSPENDED and SAFI_ACTION is a CHALLENGE
				if(errorResponse.getStatus() ==  ErrorResp.STATUS_2FA_SUSPENDED  && !(StringMethods.isEmptyString(safiAction)) && safiAction.equalsIgnoreCase(SafiConstants.SAFI_ACTION_CHALLENGE)){
					Logger.debug("SAFI : reqSecureCode(): Notify Call:START : SafiAction :Challenge: STATUS_2FA_SUSPENDED",this.getClass());
					callSafiNotifyForPasswordReset(httpRequest, httpServletResponse, false, commonData);
					Logger.debug("SAFI : reqSecureCode(): Notify Call:END : SafiAction :Challenge: STATUS_2FA_SUSPENDED",this.getClass());
				}
				return errorResponse;
			}
			else{
				PwdResetResp resp =populatePwdResetResponse(null,ServiceConstants.VERIFY_2FA_PWDRESET,mobileSession);
				//set a value in session if 2fa verification is successful. This will be used to validate in reset pwd and sec num
				mobileSession.setSecureCodeVerifiedTranName(ServiceConstants.REQ_2FA_PWDRESET);
				//Make a notify call after successful 2FA and phone update
				if(null != safiVO) {
					if(null != safiVO.getSafiRespVO() && null != safiVO.getSafiRespVO().getSafiAction() && safiVO.getSafiRespVO().getSafiAction().equals(SafiConstants.SAFI_ACTION_CHALLENGE))
						callSafiNotifyForPasswordReset(httpRequest, httpServletResponse, true, commonData);
					
					//Remove SAFI VO for Pwd Reset
					mobileSession.removeSafiRequestVO();
				}
				return resp;
			}
			
		} catch (ResourceException e) {
			Logger.error("Exception PwdResetController - verifyPwdResetSecureCode(): GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "]", e, this.getClass());
			mobileSession.removeTransaction();
			mobileSession.removeSecureCodeDetails();
			return MBAppUtils.createErrorResp("ALL", BusinessException.SYSTEM_UNAVILABLE, ServiceConstants.VERIFY_2FA_PWDRESET, httpRequest);
		} catch (Exception e) {
			Logger.error("Exception PwdResetController - verifyPwdResetSecureCode(): GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "]", e, this.getClass());
			mobileSession.removeTransaction();
			mobileSession.removeSecureCodeDetails();
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.GENERIC_ERROR, ServiceConstants.VERIFY_2FA_PWDRESET, httpRequest);
		} finally {
			endPerformanceLog(logName);
		}

	}	
	
	@RequestMapping(method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE, value = "/pwdreset/resetpwdsecnum")
	@ResponseBody
	public IMBResp resetPwdAndSecNum(HttpServletRequest httpRequest, @RequestBody final PwdSecNumResetReq request) {
		Logger.debug("PwdResetController - resetPwdAndSecNum(). Request: " + request, this.getClass());
		String logName = startPerformanceLog(httpRequest);
		MobileSession mobileSession = new MobileSessionImpl();
		String origin = logonHelper.resolveOrigin(httpRequest);

		try {
			mobileSession.getSessionContext(httpRequest);
			//check if 2fa is verified
			if(mobileSession.getSecureCodeVerifiedTranName() !=null && ServiceConstants.REQ_2FA_PWDRESET.equalsIgnoreCase(mobileSession.getSecureCodeVerifiedTranName())){
				IBankCommonData commonData = new MBAppHelper().populateIBankCommonData(mobileSession, httpRequest);
				
				validateRequestHeader(request.getHeader(), httpRequest);
				ErrorResp errorResponse = validate(request, httpRequest);// validate json
				if (errorResponse.hasErrors())
					return errorResponse;
				
				String gdwOrigin = pwdResetHelper.getGDWOrigin(request.getHeader(), origin);
				mobileSession.setGDWOrigin(gdwOrigin);
				commonData.setGdwOrigin(gdwOrigin);		
	
				PwdResetCustomerDetails pwdResetDetails=pwdResetHelper.populatePwdResetCustomerDetails(commonData);
				pwdResetHelper.populatePwdResetDetails(pwdResetDetails, request);
				pwdResetDetails.setReferURL(httpRequest.getHeader("referer"));
				pwdResetService.resetPwdAndSecNum(pwdResetDetails,commonData);
				PwdResetResp resp =populatePwdResetResponse(null,ServiceConstants.PWD_SECNUM_RESET,mobileSession);
				//invalidate the session after successful sec num and pwd reset
				mobileSession.invalidateSession();
				return resp;
			}
			else{
				//2fa was not verified. throw an error
				Logger.error("BusinessException PwdResetController- 2FA not verified- resetPwdAndSecNum(): GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "]", this.getClass());
				throw new ResourceException(ResourceException.SYSTEM_ERROR);
			}
			
		}
		catch (BusinessException e) {
			Logger.error("BusinessException PwdResetController - resetPwdAndSecNum(): GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "]", e, this.getClass());
			mobileSession.removeTransaction();
			mobileSession.removeSecureCodeDetails();
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), e, ServiceConstants.PWD_SECNUM_RESET, httpRequest);
		} 		
		catch (ResourceException e) {
			Logger.error("ResourceException PwdResetController - resetPwdAndSecNum(): GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "]", e, this.getClass());
			mobileSession.removeTransaction();
			mobileSession.removeSecureCodeDetails();
			return MBAppUtils.createErrorResp("ALL", BusinessException.SYSTEM_UNAVILABLE, ServiceConstants.PWD_SECNUM_RESET, httpRequest);
		} catch (Exception e) {
			Logger.error("Exception PwdResetController - resetPwdAndSecNum(): GCIS: ["+ ((mobileSession!=null && mobileSession.getCustomer()!=null)? mobileSession.getCustomer().getGcis() : "") + "]", e, this.getClass());
			mobileSession.removeTransaction();
			mobileSession.removeSecureCodeDetails();
			return MBAppUtils.createErrorResp(mobileSession.getOrigin(), BusinessException.GENERIC_ERROR, ServiceConstants.PWD_SECNUM_RESET, httpRequest);
		} finally {
			endPerformanceLog(logName);
		}

	}	
	
	private PwdResetCustomerDetails generateCANSecureCodeInfo(Date dob, CanRetrievalReq request, IBankCommonData commonData, String origin, HttpServletRequest httpRequest, HttpServletResponse httpServletResponse,String logName) throws BusinessException, ResourceException, IOException{
		Logger.debug("In generateCANSecureCodeInfo ", this.getClass());
		PwdResetCustomerDetails pwdResetCustomerDetails = null;
		PwdResetDetails pwdResetDetails = new PwdResetDetails();
		pwdResetDetails.setCardNumber(request.getCardNum());
		pwdResetDetails.setIssueNumber(request.getIssueNum());
		pwdResetDetails.setBirthDate(dob);
		pwdResetCustomerDetails = pwdResetService.validateCANDetails(pwdResetDetails);
		return pwdResetCustomerDetails;
	}
	
	private PwdResetCustomerDetails generatePwdResetSecureCodeInfo(Date dob, PwdResetReq request, IBankCommonData commonData, String origin, HttpServletRequest httpRequest, HttpServletResponse httpServletResponse,String logName) throws BusinessException, ResourceException, IOException{
		Logger.debug("In generatePwdResetSecureCodeInfo ", this.getClass());
		PwdResetCustomerDetails pwdResetCustomerDetails = null;
		PwdResetDetails pwdResetDetails = new PwdResetDetails();
		pwdResetDetails.setCanNumber(request.getCan());
		pwdResetDetails.setBirthDate(dob);
		pwdResetCustomerDetails = pwdResetService.validatePwdDetails(pwdResetDetails);
		return pwdResetCustomerDetails;
	}	

	private CanRetrievalResp populateResponse(PwdResetCustomerDetails pwdResetCustomerDetails, String serviceName, MobileSession mbsession) throws JsonParseException, JsonMappingException, IOException{
		CanRetrievalResp resp = new CanRetrievalResp();
		RespHeader header = populateResponseHeader(serviceName, mbsession);
		resp.setHeader(header);
		resp.setSecureCodeInfo(pwdResetHelper.populateSecureCodeResponse(pwdResetCustomerDetails));
		return resp;
	}
	
	private PwdResetResp populatePwdResetResponse(PwdResetCustomerDetails pwdResetCustomerDetails, String serviceName, MobileSession mbsession) throws JsonParseException, JsonMappingException, IOException{
		PwdResetResp resp = new PwdResetResp();
		RespHeader header = populateResponseHeader(serviceName, mbsession);
		resp.setHeader(header);
		if(pwdResetCustomerDetails!=null){
			resp.setSecureCodeInfo(pwdResetHelper.populateSecureCodeResponse(pwdResetCustomerDetails));
		}
		return resp;
	}	
	
	private CanRetrievalResp populateCANRetrievalResp(String serviceName, MobileSession mbsession) throws JsonParseException, JsonMappingException, IOException{
		CanRetrievalResp resp = new CanRetrievalResp();
		RespHeader header = populateResponseHeader(serviceName, mbsession);
		resp.setHeader(header);
		return resp;
	}

	public RespHeader populateResponseHeader(String serviceName, MobileSession mobSession )	{
		return mbAppHelper.populateResponseHeader(serviceName, mobSession);
	}

	
	private String startPerformanceLog(HttpServletRequest httpRequest){
		perfLogger.startAllLogs();
		String logName = MBAppUtils.getLogName(httpRequest);
		perfLogger.startLog(logName);
		return logName;
	}
	
	private void endPerformanceLog(String logName){
		perfLogger.endLog(logName);
		perfLogger.endAllLogs();
	}

	
	public void validateRequestHeader(ReqHeader headerReq, HttpServletRequest request) throws BusinessException {
		Logger.debug("Request header validation: " + ReflectionToStringBuilder.toString(headerReq, ToStringStyle.MULTI_LINE_STYLE), this.getClass());
		new MBAppValidator().validateRequestHeader(headerReq, request);
	}

	public ErrorResp validate(IMBReq serviceRequest, HttpServletRequest request) {
		return mbAppValidator.validate(serviceRequest, request);
	}

	public void createSession(PwdResetCustomerDetails pwdResetCustomerDetails, String origin, HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse,MobileSession mbsession, String logName) throws BusinessException{
		IGenericSession genericSession = null ;
		User myUser = new User();
		IBankCommonData commonData = new MBAppHelper().populateIBankCommonData(mbsession, httpServletRequest);
		myUser = new User(pwdResetCustomerDetails.getGcisNumber(), pwdResetCustomerDetails.getCan(),
				IBankParams.BLANK_STRING, null, false, true,
				false);		
		myUser.setUserId(pwdResetCustomerDetails.getCan());
		if(pwdResetCustomerDetails.getCardNumber()!=null){
		//adding card num is user object		
			String card = pwdResetCustomerDetails.getCardNumber() + pwdResetCustomerDetails.getIssueNum();
			myUser.setAttribute(IBankParams.USEROBJ_CARDNUMBER, card);		
		}
		myUser.setAttribute(IBankParams.USEROBJ_IPADDRESS, commonData.getIpAddress());
		commonData.setUser(myUser);
		commonData.setOrigin(origin);
	
		
		Customer cust = new Customer();
		ContactDetail contact =new ContactDetail();
		if(pwdResetCustomerDetails.getSecureCodeDetails() != null){
			if(pwdResetCustomerDetails.getSecureCodeDetails().getHome() != null){
				PhoneNumber home =new PhoneNumber();
				home.setAreaCode(pwdResetCustomerDetails.getSecureCodeDetails().getHome().getAreaCode());
				home.setPhoneNumber(pwdResetCustomerDetails.getSecureCodeDetails().getHome().getPhoneNumber());
				contact.setHomeNumber(home);
			}
			if(pwdResetCustomerDetails.getSecureCodeDetails().getMobile() != null){
				PhoneNumber mobile =new PhoneNumber();
				mobile.setAreaCode(pwdResetCustomerDetails.getSecureCodeDetails().getMobile().getAreaCode());
				mobile.setPhoneNumber(pwdResetCustomerDetails.getSecureCodeDetails().getMobile().getPhoneNumber());
				contact.setMobileNumber(mobile);
			}
			if(pwdResetCustomerDetails.getSecureCodeDetails().getWork() != null){
				PhoneNumber work =new PhoneNumber();
				work.setAreaCode(pwdResetCustomerDetails.getSecureCodeDetails().getWork().getAreaCode());
				work.setPhoneNumber(pwdResetCustomerDetails.getSecureCodeDetails().getWork().getPhoneNumber());
				contact.setWorkNumber(work);
			}
		}
		cust.setContactDetail(contact);
		commonData.setCustomer(cust);
		
		try{
			genericSession = logonHelper.createCompassSession(myUser, origin, "WebSrv", httpServletRequest);			
			genericSession.setAttribute(MobileSessionImpl.CUSTOMER_OBLECT, cust);
			genericSession.setAttribute(MobileSessionImpl.ORIGIN_OBLECT, origin);			
			Logger.info("***User-Agent: " +  "***SessionId: " + genericSession.getId(), this.getClass());
			httpServletResponse.setHeader("Set-Cookie", MBAppConstants.SMPL_SESS_CONSTANT + "=" + genericSession.getId()   + "; HttpOnly ; Secure    " );		
			
		} catch (Exception e){
			Logger.error("Exception Inside createSession() ", e, this.getClass());
			throw new BusinessException(BusinessException.SYSTEM_UNAVILABLE);
		} 
		 finally
			{
				if ( genericSession != null )
					genericSession.updateSession();				
			}	
	}
	
	private PwdResetResp callSafiAnalyseForPasswordReset(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, MobileSession mobileSession, IBankCommonData commonData,
			PwdResetReq request, PwdResetResp response, IGenericSession genericSession) throws ResourceException, BusinessException {
   		
		SafiPwdResetVO safiVO = new SafiPwdResetVO(); 
		SafiDeviceInfo safiDeviceInfo = null;
		Preference myPreference = null;
		try {
			boolean isMobileApp = ((logonHelper.loadCordova(httpServletRequest)) == -1) ? false:true;
			if(isMobileApp) {
				safiDeviceInfo = new SafiDeviceInfo();
				SafiWebHelper.readCookiesForDeviceInfo(httpServletRequest,safiDeviceInfo);
			}
			myPreference = PreferencesService.getPreferenceForMobileBank(commonData.getUser());
			
			safiVO = pwdResetHelper.populateSafiVO(httpServletRequest, mobileSession, commonData, request, isMobileApp, safiDeviceInfo);
			safiVO.setDaysSinceLastLogonCredChange(pwdResetHelper.getDaysSinceLastLogonCredChanged(myPreference.getChangePasswordDate()));
			
			mobileBankService.safiAnalyzeForPwdReset(commonData, safiVO);
			
			if(null != safiVO && null != safiVO.getSafiRespVO() && null != safiVO.getSafiRespVO().getSafiAction()) {
				if(SafiConstants.SAFI_ACTION_ALLOW.equalsIgnoreCase(safiVO.getSafiRespVO().getSafiAction()) || SafiConstants.SAFI_ACTION_REVIEW.equalsIgnoreCase(safiVO.getSafiRespVO().getSafiAction()))
					response.setSecureCodeReqd(false);
			}
			
			} catch(BusinessException be){
				//Only in case of Challenge - set setSecureCodeReqd to TRUE
				//Otherwise throw exception
				if (be.getKey() == BusinessException.IBANK_SECURE_REQUIRED) {
					response.setSecureCodeReqd(true);
				} else{
					throw be;
				}
			}finally{
				genericSession.setAttribute(MobileSessionImpl.SAFI_VO, safiVO);
				pwdResetHelper.handleSafiResponseinCookies(httpServletRequest ,httpServletResponse, safiVO.getSafiRespVO());
			}
		
	   		return response;
   	}	
	
	private void callSafiNotifyForPasswordReset(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, boolean status2FA, IBankCommonData ibankCommonData) {
		MobileSession mobileSession = new MobileSessionImpl();
		
		try{
		mobileSession.getSessionContext(httpServletRequest);
				
		if(mobileSession.getSafiRequestVO() != null && mobileSession.getSafiRequestVO() instanceof SafiPwdResetVO) {
			SafiPwdResetVO safiVO = SafiWebHelper.populateSafiVOForPwdResetNotify(httpServletRequest, mobileSession, ibankCommonData,  status2FA);
			
			SafiRespVO safiRespVO = safi2Service.notifySafiForPwdReset(ibankCommonData, safiVO);
			
			pwdResetHelper.handleSafiResponseinCookies(httpServletRequest, httpServletResponse, safiRespVO);
		}
		}catch(BusinessException be){
			Logger.warn("Exception in callSafiNotifyForPasswordReset: ", be , getClass());
		}finally{
			mobileSession.removeSafiRequestVO();
		}
	}
	
	private IGenericSession createSessionForPwdReset(PwdResetCustomerDetails pwdResetCustomerDetails, IBankCommonData commonData, String origin, HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse,MobileSession mbsession, String logName) throws BusinessException{
		IGenericSession genericSession = null ;
		User myUser = new User();
		//IBankCommonData commonData = new MBAppHelper().populateIBankCommonData(mbsession, httpServletRequest);
		myUser = new User(pwdResetCustomerDetails.getGcisNumber(), pwdResetCustomerDetails.getCan(),
				IBankParams.BLANK_STRING, null, false, true,
				false);		
		myUser.setUserId(pwdResetCustomerDetails.getCan());
		if(pwdResetCustomerDetails.getCardNumber()!=null){
		//adding card num is user object		
			String card = pwdResetCustomerDetails.getCardNumber() + pwdResetCustomerDetails.getIssueNum();
			myUser.setAttribute(IBankParams.USEROBJ_CARDNUMBER, card);		
		}
		myUser.setAttribute(IBankParams.USEROBJ_IPADDRESS, commonData.getIpAddress());
		commonData.setUser(myUser);
		commonData.setOrigin(origin);
	
		
		Customer cust = new Customer();
		ContactDetail contact =new ContactDetail();
		if(pwdResetCustomerDetails.getSecureCodeDetails() != null){
			if(pwdResetCustomerDetails.getSecureCodeDetails().getHome() != null){
				PhoneNumber home =new PhoneNumber();
				home.setAreaCode(pwdResetCustomerDetails.getSecureCodeDetails().getHome().getAreaCode());
				home.setPhoneNumber(pwdResetCustomerDetails.getSecureCodeDetails().getHome().getPhoneNumber());
				contact.setHomeNumber(home);
			}
			if(pwdResetCustomerDetails.getSecureCodeDetails().getMobile() != null){
				PhoneNumber mobile =new PhoneNumber();
				mobile.setAreaCode(pwdResetCustomerDetails.getSecureCodeDetails().getMobile().getAreaCode());
				mobile.setPhoneNumber(pwdResetCustomerDetails.getSecureCodeDetails().getMobile().getPhoneNumber());
				contact.setMobileNumber(mobile);
			}
			if(pwdResetCustomerDetails.getSecureCodeDetails().getWork() != null){
				PhoneNumber work =new PhoneNumber();
				work.setAreaCode(pwdResetCustomerDetails.getSecureCodeDetails().getWork().getAreaCode());
				work.setPhoneNumber(pwdResetCustomerDetails.getSecureCodeDetails().getWork().getPhoneNumber());
				contact.setWorkNumber(work);
			}
		}
		cust.setContactDetail(contact);
		cust.setGcis(pwdResetCustomerDetails.getGcisNumber());
		IBankSecureDetails myDetails = new IBankSecureDetails();
		myDetails.setRegistrationStatus(pwdResetCustomerDetails.getIbankSecureRegStatus());
		myDetails.setExemptionStatus(pwdResetCustomerDetails.getIbankSecureExemptStatus());
		myDetails.setExemptExpiryDate(pwdResetCustomerDetails.getIbankSecureExemptDate());
		cust.setIBankSecureDetails(myDetails);
		commonData.setCustomer(cust);
		
		try{
			genericSession = logonHelper.createCompassSession(myUser, origin, "WebSrv", httpServletRequest);			
			genericSession.setAttribute(MobileSessionImpl.CUSTOMER_OBLECT, cust);
			genericSession.setAttribute(MobileSessionImpl.ORIGIN_OBLECT, origin);			
			Logger.info("***User-Agent: " +  "***SessionId: " + genericSession.getId(), this.getClass());
			httpServletResponse.setHeader("Set-Cookie", MBAppConstants.SMPL_SESS_CONSTANT + "=" + genericSession.getId()   + "; HttpOnly ; Secure    " );		
			
		} catch (Exception e){
			Logger.error("Exception Inside createSession() ", e, this.getClass());
			throw new BusinessException(BusinessException.SYSTEM_UNAVILABLE);
		} 
//		 finally
//			{
//				if ( genericSession != null )
//					genericSession.updateSession();				
//			}	
		
		return genericSession;
	}
	
}
