package au.com.stgeorge.mbank.model.request.payments;

import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import org.apache.commons.lang.builder.ReflectionToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;
import au.com.stgeorge.ibank.businessobject.BusinessException;
import au.com.stgeorge.mbank.model.common.IMBReq;
import au.com.stgeorge.mbank.model.common.ReqHeader;

public class NPPValidateEnrichmentReq implements IMBReq {

	private static final long serialVersionUID = 7259582730803369988L;
	
	private String amt;
	private String desc;
	private String reference;
	
	public String getAmt() {
		return amt;
	}

	public void setAmt(String amt) {
		this.amt = amt;
	}

	public String getDesc() {
		return desc;
	}

	public void setDesc(String desc) {
		this.desc = desc;
	}

	public String getReference() {
		return reference;
	}

	public void setReference(String reference) {
		this.reference = reference;
	}

	private ReqHeader header;
	
	@NotNull(message = "" + BusinessException.ACCOUNT_NO_FROM_ACCOUNT)
	@Min(value = 0, message="" + BusinessException.GENERIC_ERROR)
	private Integer fromAccountIndex;
	
	public Integer getFromAccountIndex() {
		return fromAccountIndex;
	}

	public void setFromAccountIndex(Integer fromAccountIndex) {
		this.fromAccountIndex = fromAccountIndex;
	}

	public ReqHeader getHeader() {		
		return header;
	}
	
	public void setHeader(ReqHeader header) {
		this.header = header;
	}
	
	@Override
	public String toString() {
		return ReflectionToStringBuilder.toString(this, ToStringStyle.MULTI_LINE_STYLE);
	}
}
