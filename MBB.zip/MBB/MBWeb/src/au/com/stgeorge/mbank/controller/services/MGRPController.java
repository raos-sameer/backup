package au.com.stgeorge.mbank.controller.services;

import java.net.URLEncoder;
import java.util.Date;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import au.com.stgeorge.ibank.businessobject.impl.OIDCServiceImpl;
import au.com.stgeorge.ibank.model.idp.IdpConfig;
import au.com.stgeorge.ibank.valueobject.IDPSSODetails;
import au.com.stgeorge.ibank.valueobject.database.CodesVO;
import au.com.stgeorge.mbank.model.common.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import au.com.stgeorge.digitalsec.logger.DigitalSecLogger;
import au.com.stgeorge.digitalsec.logger.DigitalSecLogggerVO;
import au.com.stgeorge.framework.common.logging.Logger;
import au.com.stgeorge.framework.common.util.StringMethods;
import au.com.stgeorge.ibank.businessobject.BusinessException;
import au.com.stgeorge.ibank.businessobject.HeartBeat;
import au.com.stgeorge.ibank.businessobject.IBankSecureService;
import au.com.stgeorge.ibank.businessobject.MemoryThrottlingService;
import au.com.stgeorge.ibank.businessobject.SafiDigiSecLoggerService;
import au.com.stgeorge.ibank.businessobject.MgrpService;
import au.com.stgeorge.ibank.businessobject.PRMUpdateService;
import au.com.stgeorge.ibank.businessobject.ResourceException;
import au.com.stgeorge.ibank.businessobject.mgrp.MgrpSAMLService;
import au.com.stgeorge.ibank.common.cache.IBankParams;
import au.com.stgeorge.ibank.safi.businessobject.Safi2Service;
import au.com.stgeorge.ibank.safi.util.SafiConstants;
import au.com.stgeorge.ibank.safi.valueobject.SafiMgrpVO;
import au.com.stgeorge.ibank.service.valueobject.SafiRespVO;
import au.com.stgeorge.ibank.util.ServiceHelper;
import au.com.stgeorge.ibank.valueobject.Customer;
import au.com.stgeorge.ibank.valueobject.ExternalLinkVO;
import au.com.stgeorge.ibank.valueobject.SAMLStore;
import au.com.stgeorge.ibank.valueobject.database.OriginsVO;
import au.com.stgeorge.ibank.valueobject.transfer.IBankCommonData;
import au.com.stgeorge.mbank.controller.IMBController;
import au.com.stgeorge.mbank.controller.SafiWebHelper;
import au.com.stgeorge.mbank.controller.SecureCodeHelper;
import au.com.stgeorge.mbank.controller.customer.LogonHelper;
import au.com.stgeorge.mbank.model.request.SecureCodeReq;
import au.com.stgeorge.mbank.model.request.services.MgrpReq;
import au.com.stgeorge.mbank.model.response.ErrorResp;
import au.com.stgeorge.mbank.model.response.services.MgrpResp;
import au.com.stgeorge.mbank.session.MobileSession;
import au.com.stgeorge.mbank.session.MobileSessionImpl;
import au.com.stgeorge.mbank.util.MBAppConstants;
import au.com.stgeorge.mbank.util.MBAppHelper;
import au.com.stgeorge.mbank.util.MBAppUtils;
import au.com.stgeorge.mbank.util.MBAppValidator;
import au.com.stgeorge.mbank.util.ServiceConstants;
import au.com.stgeorge.mobilebank.businessobject.ExternalLinkService;
import au.com.stgeorge.mobilebank.businessobject.impl.ExternalLinkServiceImpl;
import au.com.stgeorge.perflogger.PerformanceLogger;
import au.com.stgeorge.ibank.businessobject.OIDCService;
@Controller
@RequestMapping("/mgrp")
public class MGRPController implements IMBController {


	private static final String SRV_TOKEN_TYPE = "OIDCToken";
	@Autowired
	private MBAppValidator mbAppValidator;

	@Autowired
	private MBAppHelper mbAppHelper;

	@Autowired
	private ExternalLinkService externalLinkService;

	@Autowired
	private MemoryThrottlingService memoryThrottlingService;

	@Autowired
	private MgrpHelper mgrpHelper;

	@Autowired
	private SecureCodeHelper secureCodeHelper;

	@Autowired
	private Safi2Service safi2Service;

	@Autowired
	private LogonHelper logonHelper;

	@Autowired
	private MgrpService mgrpService;

	@Autowired
	private SafiDigiSecLoggerService safiDigiSecLoggerService;

	@Autowired
	private MgrpSAMLService mgrpSAMLService;

	@Autowired
	private OIDCService oidcService;

	@PostMapping(path = "mgrp2FA", headers = "content-type=application/json", produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public IMBResp mgrp2FA(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse,
			@RequestBody final MgrpReq req) {
		PerformanceLogger performanceLogger = new PerformanceLogger();
		performanceLogger.startAllLogs();

		String logName = MBAppUtils.getLogName(httpServletRequest);
		performanceLogger.startLog(logName);

		String origin = null;
		MobileSession mbSession = null;

		ObjectMapper mapper = new ObjectMapper();
		MgrpResp mgrpResp = new MgrpResp();

		try {

			if (Boolean.FALSE.equals(IBankParams.getSwitch(IBankParams.DEFAULT_ORIGIN, IBankParams.MGRP_SWITCH))) {
				throw new BusinessException(BusinessException.SYSTEM_UNAVILABLE);
			}
			mbSession = mbAppHelper.getMobileSession(httpServletRequest);
			validateRequestHeader(req.getHeader(), httpServletRequest);
			origin = mbSession.getOrigin();

			ErrorResp errorResp = validate(req, httpServletRequest);
			if (errorResp != null && errorResp.getErrors() != null && errorResp.getErrors().size() > 0) {
				return errorResp;
			}
			Customer customer = mbSession.getCustomer();

			IBankCommonData ibankCommonData = mbAppHelper.populateIBankCommonData(mbSession, httpServletRequest);

			mgrpHelper.setStatisticGDWLog(ibankCommonData);

			RespHeader headerResp = populateResponseHeader(req.getHeader().getServiceName(), mbSession);
			mgrpResp.setHeader(headerResp);

			if (mbSession.getSafiRequestVO() != null) {
				mbSession.removeSafiRequestVO();
			}
			
			boolean isSafiMgrpSwitchOn = IBankParams.isSwitchOn(IBankParams.DEFAULT_ORIGIN,
					IBankParams.SAFI_MGRP_SWITCH);
			Logger.debug("SAFI : mgrp switch Value: " + isSafiMgrpSwitchOn, this.getClass());
			boolean isSafiServiceAvailable = false;

			if (isSafiMgrpSwitchOn) {
				isSafiServiceAvailable = HeartBeat.isApplicationAvailable(HeartBeat.SAFI2_SERVICE_APPLICATION);
				Logger.info("SAFI : mgrp2FA :: SAFI2_SERVICE_APPLICATION STATUS: " + isSafiServiceAvailable,
						this.getClass());
			}

			 boolean isMobileApp = ((logonHelper.loadCordova(httpServletRequest)) == -1)? false:true;
			
			 if (isSafiServiceAvailable) {


			 	boolean isThrottleAllowed = memoryThrottlingService.processThrottling(IBankParams.THROTTLE_CAT_MGRP,customer.getGcis(), mbSession.getSessionID());
				if (isThrottleAllowed) {
					MgrpResp response = (MgrpResp) callSafiAnalyse(httpServletRequest, httpServletResponse, mbSession,
							ibankCommonData, req, mgrpResp, mapper, isMobileApp);
					String baseOrigin = IBankParams.getBaseOriginCode(ibankCommonData.getOrigin());

					String brand =  mbSession.getMgrpBrand();
					Logger.info("MGRP :: brand: " +brand, this.getClass());


					if (!response.isSecureCodeReqd()) {

						Logger.info("SAFI : mgrp :: isMobileApp: " + isMobileApp, this.getClass());

						setIdpCookieSessionDetails( brand,  ibankCommonData,  mbSession, httpServletRequest, httpServletResponse);

						/*String saml = mgrpSAMLService.createSAML(ibankCommonData, brand);

						if (isMobileApp) {
							Date today = new Date();
							SAMLStore samlStore = new SAMLStore();
							String pdfToken = mbAppHelper.getPdfDocToken();
							samlStore.setToken(pdfToken);
							samlStore.setCreatedBy(mbSession.getUser().getUserId());
							samlStore.setCreatedOn(today);
							samlStore.setGcisNumber(mbSession.getCustomer().getGcis());
							samlStore.setSamlData(saml);
							samlStore.setFeature("MGRP");

							mgrpSAMLService.addSamlResponseToStore(samlStore);
							response.setToken(pdfToken);
							response.setMgrpBrand(brand);
							Logger.debug("SAFI : mgrp2FA :: pdfToken: " + pdfToken, this.getClass());
						} else {
							response.setSamlResponse(mgrpSAMLService.encodeBase64(saml));
							response.setSamlPOSTBindingURL(mgrpSAMLService.getRecipientURL(brand));
							Logger.debug("mgrp2FA JSON Response :" + mapper.writeValueAsString(response),
									this.getClass());
						}*/
					}

					String clientId = null, scope = null, partnerSpId = null;
					CodesVO codeItem = IBankParams.getCodesData(IBankParams.getBaseOriginCode(brand), IBankParams.FEATURES, IBankParams.MGRP_CLIENT_ID);
					if (codeItem != null && !StringMethods.isEmptyString(codeItem.getMessage())) {
						clientId = codeItem.getMessage();
						Logger.debug("MGRPController - clientId " + clientId, this.getClass());
					}

					codeItem = IBankParams.getCodesData(IBankParams.getBaseOriginCode(brand), IBankParams.MGRP_CATEGORY, IBankParams.MGRP_SCOPE);
					if (codeItem != null && !StringMethods.isEmptyString(codeItem.getMessage())) {
						scope = codeItem.getMessage();
						Logger.debug("MGRPController - scope " + scope, this.getClass());
					}

					codeItem = IBankParams.getCodesData(IBankParams.getBaseOriginCode(brand), IBankParams.FEATURES, IBankParams.MGRP_PARTNER_SP_ID);
					if (codeItem != null && !StringMethods.isEmptyString(codeItem.getMessage())) {
						partnerSpId = codeItem.getMessage();
						Logger.debug("MGRPController -  " + partnerSpId, this.getClass());
					}

					IdpConfig idpConfig = oidcService.getCommonIdpConfigs(IBankParams.getBaseOriginCode(brand), clientId, scope, true);
					idpConfig.setScope(scope);
					idpConfig.setClientId(clientId);
					idpConfig.setPartnerSpId(partnerSpId);
					response.setIdpConfig(idpConfig);

					return response;
				}
			} else {
				int errorID = 0;
				boolean errorFlag = false;
				String status;
				if (mgrpHelper.getRegisteredPhoneNumberCount(ibankCommonData.getCustomer().getContactDetail()) == 0) {
					errorID = (BusinessException.SAFI_MGRP_NO_PHONE_EXIST);
					status = "Failure_SAFIOFFHOST";
					errorFlag = true;
				} else if (IBankSecureService.isCustomerExempt(ibankCommonData.getCustomer().getIBankSecureDetails())) {
					errorID = (BusinessException.SAFI_MGRP_2FA_EXEMPT);
					status = "Failure_SAFIOFFHOST";
					errorFlag = true;
				} else if (IBankParams.isGlobalByPass()) {
					errorID = (BusinessException.SAFI_MGRP_2FA_GLOBAL_BYPASS);
					status = "Failure_SAFIOFFHOST";
					errorFlag = true;
				} else {
					status = "Pending2FA_SAFIOffhost";
				}
				String errorMessage = mgrpService.getErrorMessage(errorID);
				DigitalSecLogggerVO digitalSecLogggerVO = safiDigiSecLoggerService.initializeDigitalLogger(ibankCommonData, DigitalSecLogger.ACCESSMCREWARDSPORTAL, status);
				safiDigiSecLoggerService.logDigiSecForSafiAnalyseSAFISwitchOFF(digitalSecLogggerVO, ibankCommonData, errorMessage);

				if (errorFlag) {
					throw new BusinessException(errorID);
				}
				mgrpResp.setSecureCodeReqd(true);

				return mgrpResp;
			}

			return null;

		} catch (BusinessException e) {

			IMBResp resp1 = null;
			Logger.error("Exception Inside mgrp2FA for Customer " + e.getKey(), e, this.getClass());

			if (e.getKey() == BusinessException.SAFI_MGRP_2FA_DENY
					|| e.getKey() == BusinessException.SAFI_MGRP_2FA_EXEMPT
					|| e.getKey() == BusinessException.SAFI_MGRP_NO_PHONE_EXIST
					|| e.getKey() == BusinessException.SAFI_MGRP_2FA_GLOBAL_BYPASS) {

				Logger.debug("BusinessException in mgrp2FA - DENY/Exempt/No Phone ERROR", this.getClass());

				OriginsVO myOriginVO = IBankParams.getOrigin(mbSession.getOrigin());
				OriginsVO baseOrigin = IBankParams.getOrigin(myOriginVO.getBankName());
				String[] values = null;

				if (e.getKey() == BusinessException.SAFI_MGRP_2FA_DENY)
					values = new String[]{baseOrigin.getBpayPhone()};
				else if (e.getKey() == BusinessException.SAFI_MGRP_2FA_GLOBAL_BYPASS)
					values = new String[]{baseOrigin.getName()};
				else
					values = new String[]{baseOrigin.getPhone()};

				IMBResp resp = MBAppUtils.createErrorResp(IBankParams.getBaseOriginCode(mbSession.getOrigin()), e,
						values, ServiceConstants.MGRP, httpServletRequest);
				return resp;
			}

			if (e.getValues() != null) {
				resp1 = MBAppUtils.createErrorResp(origin, e, e.getValues(), MBAppConstants.MGRP, httpServletRequest);
			} else if (e.getKey() == 9898) { // HOST ERROR TRANSACTION ROLLBACK
				BusinessException exp = new BusinessException(BusinessException.GENERIC_ERROR);
				resp1 = MBAppUtils.createErrorResp(origin, exp, MBAppConstants.MGRP, httpServletRequest);
			} else {
				resp1 = MBAppUtils.createErrorResp(origin, e, MBAppConstants.MGRP, httpServletRequest);
			}
			return resp1;

		} catch (Exception e) {
			Logger.error("Exception Inside mgrp2FA() for Customer GCIS: ["
					+ ((mbSession != null && mbSession.getCustomer() != null) ? mbSession.getCustomer().getGcis() : "")
					+ "] :", e, this.getClass());
			BusinessException exp = new BusinessException(BusinessException.GENERIC_ERROR);
			IMBResp resp1 = MBAppUtils.createErrorResp(origin, exp, MBAppConstants.MGRP, httpServletRequest);
			return resp1;
		} finally {
			performanceLogger.endLog(logName);
			performanceLogger.endAllLogs();
		}
	}

	@RequestMapping(value = "reqsecurecode", method = RequestMethod.POST, headers = "content-type=application/json", produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public IMBResp reqSecureCode(HttpServletRequest httpRequest, HttpServletResponse httpServletResponse,
			@RequestBody final SecureCodeReq request) {
		Logger.debug("In reqSecCode for Customer " + "  " + httpRequest.getContentType() + " "
				+ httpRequest.getRemoteAddr() + "  " + httpServletResponse.getCharacterEncoding()
				+ httpServletResponse.getLocale() + " True IP >> " + httpRequest.getHeader(IBankParams.trueClientIP()),
				this.getClass());

		PerformanceLogger performanceLogger = new PerformanceLogger();
		// fraudLogger = new FraudLogger();
		performanceLogger.startAllLogs();
		String logName = MBAppUtils.getLogName(httpRequest);
		performanceLogger.startLog(logName);
		MobileSession mbSession = null;
		try {
			if (Boolean.FALSE.equals(IBankParams.getSwitch(IBankParams.DEFAULT_ORIGIN, IBankParams.MGRP_SWITCH))) {
				throw new BusinessException(BusinessException.SYSTEM_UNAVILABLE);
			}

			mbSession = mbAppHelper.getMobileSession(httpRequest);
			validateRequestHeader(request.getHeader(), httpRequest);

			ErrorResp errorResponse = validate(request, httpRequest);
			if (errorResponse.hasErrors())
				return errorResponse;

			// check SafiMgrpVO exists in session.
			SafiMgrpVO safiVO = null;
			String safiAction = null;

			// check if this me
			if (null != mbSession.getSafiRequestVO() && mbSession.getSafiRequestVO() instanceof SafiMgrpVO) {

				Logger.debug("SAFI VO available in session. ", this.getClass());

				safiVO = (SafiMgrpVO) mbSession.getSafiRequestVO();

				if (null != safiVO.getSafiRespVO())
					safiAction = safiVO.getSafiRespVO().getSafiAction();
			}

			IBankCommonData commonData = mbAppHelper.populateIBankCommonData(mbSession, httpRequest);

			IMBResp response = secureCodeHelper.reqSecureCode(commonData, mbSession, mbSession.getTransaction(),
					request, IBankSecureService.MGRP, httpRequest);

			// In case of error log the errors
			if (response instanceof ErrorResp) {
				errorResponse = (ErrorResp) response;
				if (errorResponse.hasErrors()) {

					// SAFI notify call in case 2FA_SUSPENDED and SAFI_ACTION is a CHALLENGE
					if (errorResponse.getStatus() == ErrorResp.STATUS_2FA_SUSPENDED
							&& !(StringMethods.isEmptyString(safiAction))
							&& safiAction.equalsIgnoreCase(SafiConstants.SAFI_ACTION_CHALLENGE)) {
						Logger.debug(
								"SAFI : reqSecureCode(): Notify Call:START : SafiAction :Challenge: STATUS_2FA_SUSPENDED",
								this.getClass());
						callSafiNotify(httpRequest, httpServletResponse, false, commonData, mbSession);
						Logger.debug(
								"SAFI : reqSecureCode(): Notify Call:END : SafiAction :Challenge: STATUS_2FA_SUSPENDED",
								this.getClass());
					}

					return errorResponse;
				}
			}

			return response;
		} catch (BusinessException e) {
			Logger.error("Exception Inside reqsecurecode() for Customer GCIS: ["
					+ ((mbSession != null && mbSession.getCustomer() != null) ? mbSession.getCustomer().getGcis() : "")
					+ "] :", e, this.getClass());
			IMBResp resp1 = MBAppUtils.createErrorResp(mbSession.getOrigin(), e, MBAppConstants.MGRP, httpRequest);
			return resp1;
		} catch (Exception e) {
			Logger.error("Exception Inside reqsecurecode() for Customer GCIS: ["
					+ ((mbSession != null && mbSession.getCustomer() != null) ? mbSession.getCustomer().getGcis() : "")
					+ "] :", e, this.getClass());
			BusinessException exp = new BusinessException(BusinessException.SMPL_SYS_ERROR);
			IMBResp resp1 = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, MBAppConstants.MGRP, httpRequest);
			return resp1;
		} finally {
			performanceLogger.endLog(logName);
			performanceLogger.endAllLogs();
		}
	}

	@RequestMapping(value = "verifyseccode", method = RequestMethod.POST, headers = "content-type=application/json", produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public IMBResp verifySecCode(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse,
			@RequestBody final SecureCodeReq req) {
		Logger.debug("In verifySecCode ( MGRPController )  for Customer " + "  " + httpServletRequest.getContentType()
				+ " " + httpServletRequest.getRemoteAddr() + "  " + httpServletResponse.getCharacterEncoding()
				+ httpServletResponse.getLocale() + " True IP >> "
				+ httpServletRequest.getHeader(IBankParams.trueClientIP()), this.getClass());

		PerformanceLogger performanceLogger = new PerformanceLogger();
		
		performanceLogger.startAllLogs();
		String logName = MBAppUtils.getLogName(httpServletRequest);
		performanceLogger.startLog(logName);
		ObjectMapper mapper = new ObjectMapper();
		MobileSession mbSession = null;
		boolean safiFlow = false, safiNotify = false, callPRM = true;

		SafiMgrpVO safiVO = null;
		String safiAction = null;
		DigitalSecLogggerVO digitalSecurityLogVO = null;
		IBankCommonData ibankCommonData = null;
		// check SafiMgrpVO exists in session.
		String sdkDevicePrint = null;
		try {
			if (Boolean.FALSE.equals(IBankParams.getSwitch(IBankParams.DEFAULT_ORIGIN, IBankParams.MGRP_SWITCH))) {
				throw new BusinessException(BusinessException.SYSTEM_UNAVILABLE);
			}

			validateRequestHeader(req.getHeader(), httpServletRequest);
			mbSession = mbAppHelper.getMobileSession(httpServletRequest);
			ibankCommonData = mbAppHelper.populateIBankCommonData(mbSession, httpServletRequest);

			boolean isMobileApp = ((logonHelper.loadCordova(httpServletRequest)) == -1) ? false : true;
			String tranName = DigitalSecLogger.ACCESSMCREWARDSPORTAL;
			digitalSecurityLogVO = safiDigiSecLoggerService.initializeDigitalLogger(ibankCommonData, tranName, DigitalSecLogger.SUCCESS);

			if (null != mbSession.getSafiRequestVO() && mbSession.getSafiRequestVO() instanceof SafiMgrpVO) {

				Logger.debug("SAFI VO available in session. ", this.getClass());
				safiFlow = true;
				
				safiVO = (SafiMgrpVO) mbSession.getSafiRequestVO();

				if (null != safiVO.getSafiRespVO()) {

					safiAction = safiVO.getSafiRespVO().getSafiAction();
					if (safiAction != null) {
						safiNotify = true;
						callPRM = false;
					}
				}
			}

			ErrorResp errorResp = validate(req, httpServletRequest);
			if (errorResp != null && errorResp.getErrors() != null && errorResp.getErrors().size() > 0) {
				return errorResp;
			}
			if (safiAction != null) {
				sdkDevicePrint = populateSDKDevicePrint(mapper, mbSession, isMobileApp);
			}
			ErrorResp errorResponse = secureCodeHelper.verifySecureCode(ibankCommonData, mbSession,
					mbSession.getTransaction(), req, IBankSecureService.MGRP, httpServletRequest);

			if (errorResponse.hasErrors()) {

				if (safiFlow) {
					safiDigiSecLoggerService.logDigiSecForSafi2FA(digitalSecurityLogVO, ibankCommonData, sdkDevicePrint, null, false, false, false);
				} else {
					safiDigiSecLoggerService.logDigiSecForSafi2FASAFIOFF(digitalSecurityLogVO, ibankCommonData, "", false, false);
				}

				// SAFI notify call in case 2FA_SUSPENDED and SAFI_ACTION is a CHALLENGE
				if (errorResponse.getStatus() == ErrorResp.STATUS_2FA_SUSPENDED
						&& !(StringMethods.isEmptyString(safiAction))
						&& safiAction.equalsIgnoreCase(SafiConstants.SAFI_ACTION_CHALLENGE)) {
					Logger.debug("SAFI : verifySecCode(): Notify Call:START : SafiAction :Challenge: STATUS_2FA_SUSPENDED", this.getClass());
					callSafiNotify(httpServletRequest, httpServletResponse, false, ibankCommonData, mbSession);
					Logger.debug("SAFI : verifySecCode(): Notify Call:END : SafiAction :Challenge: STATUS_2FA_SUSPENDED", this.getClass());
				}

				return errorResponse;
			} else {
				if (safiFlow) {
					if (safiNotify) {
						callSafiNotify(httpServletRequest, httpServletResponse, true, ibankCommonData, mbSession);
					}
					safiDigiSecLoggerService.logDigiSecForSafi2FA(digitalSecurityLogVO, ibankCommonData, sdkDevicePrint,"", true, false,false);
				} else {
					safiDigiSecLoggerService.logDigiSecForSafi2FASAFIOFF(digitalSecurityLogVO, ibankCommonData, "", true, false);
				}

				if(callPRM) {
					//PRM call for SAFI off host scenario					
					PRMUpdateService prmServiceBean = (PRMUpdateService) ServiceHelper.getBean("prmServiceBean");
					prmServiceBean.sendPrmMgrp(ibankCommonData, mgrpService.populateDeviceRiskDetails(null, ibankCommonData));
				}
			}

			mbSession.setSecureCodeVerifiedTranName(ServiceConstants.MGRP);

			MgrpResp serviceResponse = new MgrpResp();
			serviceResponse.setSuccess(true);


			String brand = mbSession.getMgrpBrand();
			Logger.info("MGRP :: verifySecCode :: brand: " + brand, this.getClass());
			setIdpCookieSessionDetails( brand,  ibankCommonData,  mbSession, httpServletRequest, httpServletResponse);
			String clientId = null, scope = null, partnerSpId = null;
			CodesVO codeItem = IBankParams.getCodesData(IBankParams.getBaseOriginCode(brand), IBankParams.FEATURES, IBankParams.MGRP_CLIENT_ID);
			if (codeItem != null && !StringMethods.isEmptyString(codeItem.getMessage())) {
				clientId = codeItem.getMessage();
				Logger.debug("MGRPController - clientId " + clientId, this.getClass());
			}

			codeItem = IBankParams.getCodesData(IBankParams.getBaseOriginCode(brand), IBankParams.MGRP_CATEGORY, IBankParams.MGRP_SCOPE);
			if (codeItem != null && !StringMethods.isEmptyString(codeItem.getMessage())) {
				scope = codeItem.getMessage();
				Logger.debug("MGRPController - scope " + scope, this.getClass());
			}

			codeItem = IBankParams.getCodesData(IBankParams.getBaseOriginCode(brand), IBankParams.FEATURES, IBankParams.MGRP_PARTNER_SP_ID);
			if (codeItem != null && !StringMethods.isEmptyString(codeItem.getMessage())) {
				partnerSpId = codeItem.getMessage();
				Logger.debug("MGRPController -  " + partnerSpId, this.getClass());
			}

			IdpConfig idpConfig = oidcService.getCommonIdpConfigs(IBankParams.getBaseOriginCode(brand), clientId, scope, true);
			idpConfig.setScope(scope);
			idpConfig.setClientId(clientId);
			idpConfig.setPartnerSpId(partnerSpId);

			/*
			String saml = mgrpSAMLService.createSAML(ibankCommonData, brand);

			if (isMobileApp) {
				Date today = new Date();
				SAMLStore samlStore = new SAMLStore();
				String pdfToken = mbAppHelper.getPdfDocToken();
				samlStore.setToken(pdfToken);
				samlStore.setCreatedBy(mbSession.getUser().getUserId());
				samlStore.setCreatedOn(today);
				samlStore.setGcisNumber(mbSession.getCustomer().getGcis());
				samlStore.setSamlData(saml);
				samlStore.setFeature("MGRP");

				mgrpSAMLService.addSamlResponseToStore(samlStore);
				serviceResponse.setToken(pdfToken);
				serviceResponse.setMgrpBrand(brand);
				Logger.debug("SAFI : verifySecCode :: pdfToken: " + pdfToken, this.getClass());
			} else {
				serviceResponse.setSamlResponse(mgrpSAMLService.encodeBase64(saml));
				serviceResponse.setSamlPOSTBindingURL(mgrpSAMLService.getRecipientURL(brand));
				Logger.debug("verifySecCode JSON Response :" + mapper.writeValueAsString(serviceResponse),
						this.getClass());
			}*/
			RespHeader headerResp = populateResponseHeader(ServiceConstants.MGRP, mbSession);
			serviceResponse.setHeader(headerResp);
			return serviceResponse;
		} catch (BusinessException e) {
			Logger.error("Exception Inside verifySecCode() for Customer GCIS: ["
					+ ((mbSession != null && mbSession.getCustomer() != null) ? mbSession.getCustomer().getGcis() : "")
					+ "] :", e, this.getClass());
			if (safiFlow) {
				safiDigiSecLoggerService.logDigiSecForSafi2FA(digitalSecurityLogVO, ibankCommonData, sdkDevicePrint, "", true, false, false);
			} else {
				safiDigiSecLoggerService.logDigiSecForSafi2FASAFIOFF(digitalSecurityLogVO, ibankCommonData, "", true, false);
			}
			IMBResp resp1 = MBAppUtils.createErrorResp(mbSession.getOrigin(), e, MBAppConstants.MGRP,
					httpServletRequest);
			return resp1;
		} catch (Exception e) {
			Logger.error("Exception Inside verifySecCode() for Customer GCIS: ["
					+ ((mbSession != null && mbSession.getCustomer() != null) ? mbSession.getCustomer().getGcis() : "")
					+ "] :", e, this.getClass());
			if (safiFlow) {
				safiDigiSecLoggerService.logDigiSecForSafi2FA(digitalSecurityLogVO, ibankCommonData, sdkDevicePrint, "", false, true, false);
			} else {
				safiDigiSecLoggerService.logDigiSecForSafi2FASAFIOFF(digitalSecurityLogVO, ibankCommonData, "", false, true);
			}

			BusinessException exp = new BusinessException(BusinessException.SMPL_SYS_ERROR);
			IMBResp resp1 = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, MBAppConstants.MGRP,
					httpServletRequest);
			return resp1;
		} finally {
			performanceLogger.endLog(logName);
			performanceLogger.endAllLogs();
		}
	}

	@RequestMapping(value = "getUrl", method = RequestMethod.POST, headers = "content-type=application/json", produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public IMBResp getMGRPURL(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse,
			@RequestBody final MgrpReq request) {

		ObjectMapper objectMapper = new ObjectMapper();
		// perfLogger.startAllLogs();
		// String logName = MBAppUtils.getLogName(httpServletRequest);
		// perfLogger.startLog(logName);

		MobileSession mbSession = null;
		try {
			mbSession = mbAppHelper.getMobileSession(httpServletRequest);
			Logger.info("Apply higher credit limit JSON Request :" + objectMapper.writeValueAsString(request),
					this.getClass());
			validateRequestHeader(request.getHeader(), httpServletRequest);
			ErrorResp errorResp = validate(request, httpServletRequest);
			if (errorResp != null && errorResp.getErrors() != null && errorResp.getErrors().size() > 0) {
				return errorResp;
			}
			IBankCommonData commonData = mbAppHelper.populateIBankCommonData(mbSession, httpServletRequest);

			if (Boolean.FALSE.equals(IBankParams.getSwitch(IBankParams.DEFAULT_ORIGIN, IBankParams.MGRP_SWITCH))) {
				throw new BusinessException(BusinessException.SYSTEM_UNAVILABLE);
			}

			// String accountNumber = (request.getAccountIndex() != null) ?
			// mbSession.getCustomer().getAccounts().get(request.getAccountIndex())
			// .getAccountId().getAccountNumber() : null;
			// String accountNumber = mbSession.getIncreaseCCLimitAccountNumber();

			ExternalLinkVO externalLinkVO = externalLinkService.getExternalURLVO(commonData, true,
					ExternalLinkServiceImpl.PINPOINT_LINK_TYPE, null, null);
			StringBuffer url = new StringBuffer(externalLinkVO.getUrl());

			url.append("&data=" + URLEncoder.encode(externalLinkVO.getUnSignedData(), "UTF-8"));
			url.append("&sign=" + URLEncoder.encode(externalLinkVO.getSignedData(), "UTF-8"));

			Logger.info(" External URL " + url, this.getClass());
			MgrpResp mgrpResp = new MgrpResp();
			mgrpResp.setUrl(url.toString());
			RespHeader headerResp = populateResponseHeader(request.getHeader().getServiceName(), mbSession);
			// mbSession.invalidateSession();
			mgrpResp.setHeader(headerResp);

			return mgrpResp;
		} catch (Exception e) {
			Logger.error("Exception Inside getURL() of increaseCredit Limit for Customer GCIS: ["
					+ ((mbSession != null && mbSession.getCustomer() != null) ? mbSession.getCustomer().getGcis() : "")
					+ "] :", e, this.getClass());
			BusinessException exp = new BusinessException(BusinessException.SYSTEM_UNAVILABLE);
			IMBResp resp1 = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, ServiceConstants.MGRP,
					httpServletRequest);
			return resp1;
		} finally {
			if (mbSession != null)
				mbSession.invalidateSession();

			// perfLogger.endLog(logName);
			// perfLogger.endAllLogs();
		}

	}

	private IMBResp callSafiAnalyse(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse,
			MobileSession mobileSession, IBankCommonData commonData, MgrpReq request, MgrpResp response,
			ObjectMapper mapper, boolean isMobileApp) throws ResourceException, BusinessException {

		SafiMgrpVO safiVO = new SafiMgrpVO();

		try {
			safiVO = mgrpHelper.populateSafiVO(httpServletRequest, mobileSession, commonData, request);
			String sdkDevicePrint = null;
			sdkDevicePrint = populateSDKDevicePrint(mapper, mobileSession, isMobileApp);

			mgrpService.safiAnalyzeForMGRP(commonData, safiVO, sdkDevicePrint);

			if (null != safiVO && null != safiVO.getSafiRespVO() && null != safiVO.getSafiRespVO().getSafiAction()) {
				if (SafiConstants.SAFI_ACTION_ALLOW.equalsIgnoreCase(safiVO.getSafiRespVO().getSafiAction())
						|| SafiConstants.SAFI_ACTION_REVIEW.equalsIgnoreCase(safiVO.getSafiRespVO().getSafiAction()))
					response.setSecureCodeReqd(false);
			}

		} catch (BusinessException be) {

			// Only in case of Challenge - set setSecureCodeReqd to TRUE
			// Otherwise throw exception
			if (be.getKey() == BusinessException.IBANK_SECURE_REQUIRED) {
				response.setSecureCodeReqd(true);
			} else {
				throw be;
			}

		} finally {
			mobileSession.setSafiRequestVO(safiVO);
			mgrpHelper.handleSafiResponseinCookies(httpServletRequest, httpServletResponse, safiVO.getSafiRespVO());
		}

		return response;
	}

	private void callSafiNotify(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, boolean status2FA, IBankCommonData ibankCommonData, MobileSession mobileSession) {
		try {
			
			if (mobileSession.getSafiRequestVO() != null && mobileSession.getSafiRequestVO() instanceof SafiMgrpVO) {
				SafiMgrpVO safiVO = SafiWebHelper.populateSafiVOForMgrpNotify(httpServletRequest, mobileSession,
						ibankCommonData, status2FA);

				SafiRespVO safiRespVO = safi2Service.notifySafiForMgrp(ibankCommonData, safiVO);

				mgrpHelper.handleSafiResponseinCookies(httpServletRequest, httpServletResponse, safiRespVO);
			}
		} catch (BusinessException be) {
			Logger.warn("Exception in callSafiNotify: ", be, getClass());
		} finally {
			mobileSession.removeSafiRequestVO();
		}
	}

	public ErrorResp validate(IMBReq serviceRequest, HttpServletRequest request) {
		return mbAppValidator.validate(serviceRequest, request);
	}

	public void validateRequestHeader(ReqHeader header, HttpServletRequest request) throws ResourceException {
		mbAppValidator.validateRequestHeader(header, request);
	}

	public RespHeader populateResponseHeader(String serviceName, MobileSession mobSession) {
		return mbAppHelper.populateResponseHeader(serviceName, mobSession);
	}

	private String populateSDKDevicePrint(ObjectMapper mapper, MobileSession mbSession, boolean isMobileApp) {
		String devicePrintForLogger = null;
		
		if (isMobileApp) {
				String sdkDevicePrint = mbSession.getSafiLogonInfo() != null ? mbSession.getSafiLogonInfo().getDevicePrint()
						: null;
				try {
					JsonNode jsonNode = mapper.readValue(sdkDevicePrint, JsonNode.class);
					devicePrintForLogger = jsonNode != null ? jsonNode.toString() : "";
					Logger.debug("MGRPController populateSDKDevicePrint():::: " + devicePrintForLogger, this.getClass());
				} catch (Exception e) {
					Logger.error("MGRPController populateSDKDevicePrint() Exception", e, this.getClass());
				}
				
			}
		return devicePrintForLogger;

	}


	public void setIdpCookieSessionDetails(String brand, IBankCommonData ibankCommonData, MobileSession mbSession,HttpServletRequest httpServletRequest,HttpServletResponse httpServletResponse) throws au.com.stgeorge.tranhistory.businessobject.BusinessException {

	String cookieName = "IBVrfyTk";
	String cookieValue = "";
	//Create cookie to know which application(IB or MB) has launched Vendor

	IDPSSODetails idpSSODetails = new IDPSSODetails();
	idpSSODetails.setCreationTime(new 	Date());
	idpSSODetails.setCustomerType("P");
	idpSSODetails.setGcisNumber(ibankCommonData.getUser().	getGCISNumber());
	idpSSODetails.setSessionId(mbSession.getSessionID());
	idpSSODetails.setTokenType(SRV_TOKEN_TYPE);

	String basebrand=IBankParams.getBaseOriginCode(brand);
	if(IBankParams.STG_ORIGIN.equalsIgnoreCase(basebrand)){
		basebrand="SGB";
	}
	idpSSODetails.setAcctBrand(basebrand);


	//	Logger.info("About to get Token : "+app, this.getClass());

	cookieValue =oidcService.getServiceTokenId(idpSSODetails,ibankCommonData,SRV_TOKEN_TYPE,true);

	Logger.info("Got Token for vendor launch: "+cookieValue,this.getClass());

	mbSession.setidpSSODetails(idpSSODetails);

	Logger.info("Update Session Got Token : "+cookieValue +"Sess Id "+idpSSODetails.getSessionId(),this.getClass());

	OIDCHelper.addCompassAppTypeCookie(IBankParams.getBaseOriginCode(ibankCommonData.getOrigin()),httpServletRequest,httpServletResponse,cookieName,"MB:"+cookieValue);
}



}

