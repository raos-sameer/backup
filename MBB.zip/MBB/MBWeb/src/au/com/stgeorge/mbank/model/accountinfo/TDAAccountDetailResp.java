/**
 * 
 */
package au.com.stgeorge.mbank.model.accountinfo;

import java.util.Date;

import au.com.stgeorge.mbank.util.JsonDateSerializer;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;

/**
 * @author C50216
 *
 */
@JsonInclude(Include.NON_NULL)
public class TDAAccountDetailResp{

	private Date maturityDate;
	private String interestAmt;
	private Date nextInterestDate;
	private InterestAmtDetailResp interestEarned;
	private TDAFlexiDetailResp tdaFlexiDetail;
	private String instruction;
	
	public String getInstruction() {
		return instruction;
	}
	public void setInstruction(String instruction) {
		this.instruction = instruction;
	}
	@JsonSerialize(using = JsonDateSerializer.class)
	@JsonInclude(Include.NON_NULL)
	public Date getMaturityDate() {
		return maturityDate;
	}
	public void setMaturityDate(Date maturityDate) {
		this.maturityDate = maturityDate;
	}
	public String getInterestAmt() {
		return interestAmt;
	}
	public void setInterestAmt(String interestAmt) {
		this.interestAmt = interestAmt;
	}
	
	@JsonSerialize(using = JsonDateSerializer.class)
	@JsonInclude(Include.NON_NULL)
	public Date getNextInterestDate() {
		return nextInterestDate;
	}
	public void setNextInterestDate(Date nextInterestDate) {
		this.nextInterestDate = nextInterestDate;
	}
	public InterestAmtDetailResp getInterestEarned() {
		return interestEarned;
	}
	public void setInterestEarned(InterestAmtDetailResp interestEarned) {
		this.interestEarned = interestEarned;
	}
	public TDAFlexiDetailResp getTdaFlexiDetail() {
		return tdaFlexiDetail;
	}
	public void setTdaFlexiDetail(TDAFlexiDetailResp flexiDetail) {
		tdaFlexiDetail = flexiDetail;
	} 
	
	
	
}
