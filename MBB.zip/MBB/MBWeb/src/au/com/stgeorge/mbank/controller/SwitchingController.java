package au.com.stgeorge.mbank.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;


import au.com.stgeorge.framework.common.logging.Logger;
import au.com.stgeorge.ibank.businessobject.BusinessException;
import au.com.stgeorge.ibank.businessobject.FastFundingService;
import au.com.stgeorge.ibank.businessobject.ServiceTokenService;
import au.com.stgeorge.ibank.common.cache.IBankParams;
import au.com.stgeorge.ibank.util.ServiceHelper;
import au.com.stgeorge.ibank.valueobject.transfer.IBankCommonData;
import au.com.stgeorge.mbank.model.common.IMBReq;
import au.com.stgeorge.mbank.model.common.IMBResp;
import au.com.stgeorge.mbank.model.common.ReqHeader;
import au.com.stgeorge.mbank.model.common.RespHeader;
import au.com.stgeorge.mbank.model.request.SwitchingDetailsReq;
import au.com.stgeorge.mbank.model.response.ErrorResp;
import au.com.stgeorge.mbank.model.response.SwitchingDetailsResp;
import au.com.stgeorge.mbank.session.MobileSession;
import au.com.stgeorge.mbank.util.BTValidator;
import au.com.stgeorge.mbank.util.MBAppHelper;
import au.com.stgeorge.mbank.util.MBAppUtils;
import au.com.stgeorge.mbank.util.MBAppValidator;
import au.com.stgeorge.mobilebank.businessobject.ExternalLinkService;
import au.com.stgeorge.perflogger.PerformanceLogger;

/**
 *  SwitchingController for Switching and Salary Credit.
 *
 */
@Controller
@RequestMapping("/onboarding")
public class SwitchingController implements IMBController{
	
	@Autowired
	private MBAppHelper mbAppHelper;
	
	@Autowired
	private FastFundingService fastFundingService;
	
	@Autowired
	private MBAppValidator mbAppValidator;
	
	private static final String SMPL_DEVICE_ID ="DeviceID";
	
	/**
	 * Validator has been bound to validate only 
	 * for viewing Switching controller.
	 * @param binder
	 */
	//commenting for mogo fix
/*	@InitBinder
	protected void initBinder(WebDataBinder binder) {
	    binder.setValidator(new BTValidator());
	}*/
	/**
	 * This is the API exposed to switch payees and billers.
	 * @param httpServletRequest
	 * @param httpServletResponse
	 * @param req
	 * @return
	 * @since 16E2
	 */
	//@RequestBody SwitchingDetailsReq req
	@ResponseBody
	@RequestMapping(value="/switching", method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE)
	public IMBResp switchPayee(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse,@RequestBody SwitchingDetailsReq req)
	{
		
		return generateJWT(httpServletRequest, httpServletResponse, req);
	}
	
	/**
	 * This is the API exposed to Salary Credit.
	 * @param httpServletRequest
	 * @param httpServletResponse
	 * @param req
	 * @return
	 * @since 16E2
	 */
	@ResponseBody
	@RequestMapping(value="/salaryCredit", method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE)
	public IMBResp salaryCredit(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse,@RequestBody SwitchingDetailsReq req)
	{
		
		return generateJWT(httpServletRequest, httpServletResponse, req);
	}
	
	/**
	 * This is the API to generate JWT
	 * @param httpServletRequest
	 * @param httpServletResponse
	 * @param req
	 * @return
	 */
	private IMBResp generateJWT(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse,
			SwitchingDetailsReq req) 
	{
		String signedToken = null;
		RespHeader headerResp = null;
		SwitchingDetailsResp tokenResponse = new SwitchingDetailsResp();
		MobileSession mobSession = null;
		IBankCommonData ibankCommonData = null;
		String serviceName = null;
		PerformanceLogger performanceLogger = new PerformanceLogger();
		performanceLogger.startAllLogs();
		String logName = MBAppUtils.getLogName(httpServletRequest);
		performanceLogger.startLog(logName);
		String functionName = null;
		String linkType = null;

		try {
			mobSession = mbAppHelper.getMobileSession(httpServletRequest);
			
			if(req.getHeader() != null)
			{
				validateRequestHeader( req.getHeader(), httpServletRequest );
				serviceName = req.getHeader().getServiceName();
				headerResp = populateResponseHeader(serviceName, mobSession);
				tokenResponse.setHeader(headerResp);
			}

			ibankCommonData = mbAppHelper.populateIBankCommonData(mobSession, httpServletRequest);

			if(serviceName != null && serviceName.contains("/")){
				functionName = serviceName.substring(serviceName.indexOf("/")+1,serviceName.length());
			}

			signedToken = fastFundingService.getSignedJWTForOneClick(ibankCommonData, functionName);

			//log statistic
			if (functionName.equalsIgnoreCase("switching")){
				linkType = "OneClickSwitching";
			}
			else if(functionName.equalsIgnoreCase("salaryCredit")){
				linkType = "OneClickSalCredit";
			}

			tokenResponse.setFinalToken(signedToken);

			tokenResponse.setIsSuccess(true);
			String url =IBankParams.getCodesData(IBankParams.getBaseOriginCode(ibankCommonData.getOrigin()), IBankParams.EXTERNAL_LINKS, linkType).getMessage();
			tokenResponse.setTargetUrl(url);
			tokenResponse.setServiceName(functionName);
			tokenResponse.setClientApiVersion(IBankParams.SWITCHING_SERVICE_APIVERSION);
			tokenResponse.setDeviceID(mobSession.getDeviceID());
			ServiceTokenService tokenService = (ServiceTokenService) ServiceHelper.getBean("switchTokenService");
			String token = tokenService.generateToken(ibankCommonData.getUser().getGCISNumber());
			tokenResponse.setSwitchToken(token);
			Logger.info(url,  this.getClass());

			if(linkType != null){
			ExternalLinkService extService = ServiceHelper.getBean("externalLinkService");			
			/*
			 * TODO Review changes for fastfunding code cleanup
			 * // if fastFundingTile is available, then append account no. and BSB no. for statistics log description.
			if (ibankCommonData.getCustomer().getFastFundingTile() != null) {
				linkType += "|"+ibankCommonData.getCustomer().getFastFundingTile().getAccountNumber()+"|"+ibankCommonData.getCustomer().getFastFundingTile().getBSBNumber();
				}	*/		
			extService.createLogStatistics(ibankCommonData, true, linkType);
			}
			
		}catch (BusinessException e) {
			Logger.error("BusinessException Inside generateJWSToken() for Customer GCIS: ["+ ((mobSession!=null && mobSession.getCustomer()!=null)? mobSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			return MBAppUtils.createErrorResp(mbAppHelper.getOrigin(httpServletRequest), e, serviceName, httpServletRequest);
		} catch(Exception ex){
			Logger.error("Exception Inside generateJWSToken() for Customer GCIS: ["+ ((mobSession!=null && mobSession.getCustomer()!=null)? mobSession.getCustomer().getGcis() : "") + "] :", ex, this.getClass());
		}
		finally
		{
			performanceLogger.endLog(logName);
			performanceLogger.endAllLogs();
		}
		
		return tokenResponse;
	}
	
	public RespHeader populateResponseHeader(String serviceName,
			MobileSession mobileSession) {
		return mbAppHelper.populateResponseHeader(serviceName, mobileSession);
	}

	public ErrorResp validate(IMBReq serviceRequest,
			HttpServletRequest httpRequest) throws BusinessException {
		return mbAppValidator.validate(serviceRequest, httpRequest);
	}

	public void validateRequestHeader(ReqHeader headerReq,
			HttpServletRequest request) throws BusinessException {
		mbAppValidator.validateRequestHeader(headerReq, request);
		
	}
	
}
