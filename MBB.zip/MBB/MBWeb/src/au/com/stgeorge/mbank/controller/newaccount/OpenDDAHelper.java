package au.com.stgeorge.mbank.controller.newaccount;

import java.math.BigDecimal;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

import au.com.stgeorge.debitcard.service.impl.DebitCardServiceImpl;
import au.com.stgeorge.framework.common.exception.ResourceException;
import au.com.stgeorge.framework.common.logging.Logger;
import au.com.stgeorge.framework.common.util.DateMethods;
import au.com.stgeorge.framework.common.util.StringMethods;
import au.com.stgeorge.ibank.businessobject.BusinessException;
import au.com.stgeorge.ibank.businessobject.ContentManagementService;
import au.com.stgeorge.ibank.businessobject.acctopenservice.AccountOpeningService;
import au.com.stgeorge.ibank.common.cache.IBankParams;
import au.com.stgeorge.ibank.common.log.IBankLog;
import au.com.stgeorge.ibank.dao.InvitationTemplateDao;
import au.com.stgeorge.ibank.evcrs.util.EVConstants;
import au.com.stgeorge.ibank.util.ServiceHelper;
import au.com.stgeorge.ibank.util.StringUtil;
import au.com.stgeorge.ibank.valueobject.AEMContent.AEMCRAProdEnum;
import au.com.stgeorge.ibank.valueobject.Account;
import au.com.stgeorge.ibank.valueobject.AccountId;
import au.com.stgeorge.ibank.valueobject.Address;
import au.com.stgeorge.ibank.valueobject.CRAContent;
import au.com.stgeorge.ibank.valueobject.CRAProductContent;
import au.com.stgeorge.ibank.valueobject.CRAProductListContent;
import au.com.stgeorge.ibank.valueobject.Customer;
import au.com.stgeorge.ibank.valueobject.Invitation;
import au.com.stgeorge.ibank.valueobject.Invitation.InvitationTypeEnum;
import au.com.stgeorge.ibank.valueobject.InvitationTemplateContent.InvitationProductTypeEnum;
import au.com.stgeorge.ibank.valueobject.InvitationTemplateContent.InvitationStatusEnum;
import au.com.stgeorge.ibank.valueobject.database.AcctOpeningVO;
import au.com.stgeorge.ibank.valueobject.database.BranchVO;
import au.com.stgeorge.ibank.valueobject.database.CodesVO;
import au.com.stgeorge.ibank.valueobject.database.InvitationTemplateVO;
import au.com.stgeorge.ibank.valueobject.database.RegionVO;
import au.com.stgeorge.ibank.valueobject.transfer.IBankCommonData;
import au.com.stgeorge.ibank.valueobject.transfer.NewDDAAccount;
import au.com.stgeorge.ibank.valueobject.transfer.NewDDAAccount.NewDDAProductsEnum;
import au.com.stgeorge.mbank.controller.customer.LogonHelper;
import au.com.stgeorge.mbank.controller.offers.SalesOfferHelper;
import au.com.stgeorge.mbank.model.common.AddressResp;
import au.com.stgeorge.mbank.model.common.IMBResp;
import au.com.stgeorge.mbank.model.common.InvitationTemplateResp;
import au.com.stgeorge.mbank.model.common.KeyValueResp;
import au.com.stgeorge.mbank.model.common.NewAcctDupResp;
import au.com.stgeorge.mbank.model.common.OpenAcctDetail;
import au.com.stgeorge.mbank.model.common.OpenAcctReceipt;
import au.com.stgeorge.mbank.model.common.ProductReq;
import au.com.stgeorge.mbank.model.common.ReceiptResp;
import au.com.stgeorge.mbank.model.request.newaccount.FundDDAAcctReq;
import au.com.stgeorge.mbank.model.request.newaccount.OpenDDAAcctReq;
import au.com.stgeorge.mbank.model.request.newaccount.OpenDDAReq;
import au.com.stgeorge.mbank.model.response.newaccount.FundDDAAcctResp;
import au.com.stgeorge.mbank.model.response.newaccount.OpenDDAAcctResp;
import au.com.stgeorge.mbank.model.response.newaccount.OpenDDAResp;
import au.com.stgeorge.mbank.model.response.newaccount.ProductContentResp;
import au.com.stgeorge.mbank.model.response.newaccount.ProductDisclaimerResp;
import au.com.stgeorge.mbank.model.response.newaccount.ProductListContentResp;
import au.com.stgeorge.mbank.model.response.newaccount.ProductListItemResp;
import au.com.stgeorge.mbank.model.response.newaccount.ProductsLandingResp;
import au.com.stgeorge.mbank.model.response.newaccount.TermDepositResp;
import au.com.stgeorge.mbank.model.response.services.TFNCheckResp;
import au.com.stgeorge.mbank.session.MobileSession;
import au.com.stgeorge.mbank.util.MBAppConstants;
import au.com.stgeorge.mobilebank.businessobject.OpenDDAService;



/**
 * @author 
 * 
 */
public class OpenDDAHelper
{

	private static final String STG_BSB_PREFIX = "11";
	private static final String BSA_BSB_PREFIX = "10";
	private static final String CHS_BSB_PREFIX = "33";
	private static final String BOM_BSB_PREFIX = "19";
	public static final String SPRING_MOBILE_SERVICE_BEAN  ="mobileBankService";
	private static final String SALES_OFFER_HELPER_BEAN = "salesOfferHelper";
	
	private InvitationTemplateDao invitationTemplateDao;	

	
	public InvitationTemplateDao getInvitationTemplateDao() {
		return invitationTemplateDao;
	}

	public void setInvitationTemplateDao(InvitationTemplateDao invitationTemplateDao) {
		this.invitationTemplateDao = invitationTemplateDao;
	}

	public IMBResp populateResponse(MobileSession mobileSession, List<Account> fundingAccounts, List<Account> custAccounts, Collection<RegionVO> regions,ProductReq product, boolean hasWorkSAcc){
		OpenDDAResp openDDAResp = new OpenDDAResp();
		Customer cust = mobileSession.getCustomer();
		
		int id = -1;
		ArrayList<Integer> idList = new ArrayList<Integer>();
		for (Iterator<Account> iterator = fundingAccounts.iterator(); iterator.hasNext();) {
			Account eachAccount = iterator.next();
			if(eachAccount.getAccountId().getGroupCode() == null  || !eachAccount.getAccountId().getGroupCode().equals(Account.INCENTIVE_SAVER)){
				id = getAccountIndex(custAccounts, eachAccount.getAccountId());
				idList.add(id);
			}
		}
		openDDAResp.setAccountIndexes(idList);
		ArrayList<AddressResp> addresses = new ArrayList<AddressResp>();
		AddressResp residentialAddress = populateAddress(cust.getContactDetail().getResidentialAddress(),"RES");
		addresses.add(residentialAddress);
		//AddressResp mailingAddress = new AddressResp();
		//AddressResp mailingAddress = populateAddress(cust.getContactDetail().getMailingAddress(),"MAIL");
		if (cust.getContactDetail().getMailingAddress() != null){
			addresses.add(populateAddress(cust.getContactDetail().getMailingAddress(),"MAIL"));
		}else{
			addresses.add(populateAddress(cust.getContactDetail().getResidentialAddress(),"MAIL"));
		}
		//openDDAResp.setAddresses(addresses);
		//openDDAResp.setEmail(cust.getContactDetail().getEmail());
		//boolean isCustomerOver18 = isCustomerOver18(cust);
		if(isCustomerOver18(cust))
		{
			openDDAResp.setMailCardAllowed(true);
			openDDAResp.setCustomerOver18(true);
		}
		
		

		if ( regions!= null && MBAppConstants.ORIGIN_MBSA.equalsIgnoreCase(mobileSession.getOrigin()) )
		{
			ArrayList<KeyValueResp> regionList = new ArrayList<KeyValueResp>();
			for (Iterator<RegionVO> iterator = regions.iterator(); iterator.hasNext();) {
				RegionVO eachRegion = iterator.next();
				KeyValueResp nameIDResp = new KeyValueResp();
				nameIDResp.setId(  eachRegion.getRegionId() );
				nameIDResp.setName(  eachRegion.getRegionName() );
				regionList.add(nameIDResp);
			}
			openDDAResp.setRegions(regionList);
			
		}
		
		openDDAResp.setWorkingAccountPresent(hasWorkSAcc);
		
		
		return openDDAResp;
	}
	
	public IMBResp populateMaxiSaverDetail(boolean hasWorkSAcc,TFNCheckResp tfnCheck){
		OpenDDAResp openDDAResp = new OpenDDAResp();
		openDDAResp.setWorkingAccountPresent(hasWorkSAcc);
		if(tfnCheck!=null)
			openDDAResp.setTfnCheck(tfnCheck);
		return openDDAResp;
	}

	public IMBResp populateDuplicateAcctsListOld(ArrayList<AcctOpeningVO> dupList){
		OpenDDAResp openDDAResp = new OpenDDAResp();
		openDDAResp.setDupList(dupList);
		return openDDAResp;
	}

	
	public IMBResp populateDuplicateAcctsList(ArrayList<AcctOpeningVO> duplicateAcctOpeningList){
		TermDepositResp termDepositResp = new TermDepositResp();
		//JSONObject json = new JSONObject();
		//json.put(MobileConstants.HTTP_REQUEST_PARAM_SECURITY_UNIQUE_ID, securityUniqueID);
		//JSONArray jsonArray = new JSONArray();
		ArrayList<NewAcctDupResp> acctOpeningList = new ArrayList<NewAcctDupResp>();
		
		if(duplicateAcctOpeningList!=null && duplicateAcctOpeningList.size() > 0){
			//AcctOpeningVO eachVO = new AcctOpeningVO();
			int len=duplicateAcctOpeningList.size();		
			
			for (int i = 0; i < duplicateAcctOpeningList.size(); i++){
				NewAcctDupResp newTDAAcctDupResp = new NewAcctDupResp();
				AcctOpeningVO eachVO = (AcctOpeningVO) duplicateAcctOpeningList.get(i);
				
				newTDAAcctDupResp.setId((len-i));
				newTDAAcctDupResp.setAmt(eachVO.getAmount().toString());
				newTDAAcctDupResp.setTerm(eachVO.getTermLength());
				if(eachVO.getAccountNumberFrom() != null){
					newTDAAcctDupResp.setFromAcct(getFormattedAcctNumber(eachVO.getAccountNumberFrom(), eachVO.getApplIDFrom(), eachVO.getBsbNumberFrom()));
				}
				newTDAAcctDupResp.setDateTime(eachVO.getRequestDate());
				newTDAAcctDupResp.setStatus(eachVO.getStatus());
				acctOpeningList.add(newTDAAcctDupResp);
			}
		}
		termDepositResp.setDupList(acctOpeningList);
		return termDepositResp;
	}
	
	public IMBResp populateDDADuplicateList(ArrayList<AcctOpeningVO> duplicateAcctOpeningList){
		OpenDDAAcctResp resp =new OpenDDAAcctResp();
		ArrayList<NewAcctDupResp> acctOpeningList = new ArrayList<NewAcctDupResp>();
		if(duplicateAcctOpeningList!=null && duplicateAcctOpeningList.size() > 0){
			//AcctOpeningVO eachVO = new AcctOpeningVO();
			int len=duplicateAcctOpeningList.size();		
			
			for (int i = 0; i < duplicateAcctOpeningList.size(); i++){
				NewAcctDupResp eachDup = new NewAcctDupResp();
				AcctOpeningVO eachVO = (AcctOpeningVO) duplicateAcctOpeningList.get(i);
				
				eachDup.setId((len-i));
				if(eachVO.getAmount()!=null){
					eachDup.setAmt(eachVO.getAmount().toString());
				}
				if(eachVO.getAccountNumberFrom() != null){
					eachDup.setFromAcct(getFormattedAcctNumber(eachVO.getAccountNumberFrom(), eachVO.getApplIDFrom(), eachVO.getBsbNumberFrom()));
				}
				eachDup.setDateTime(eachVO.getRequestDate());
				eachDup.setStatus(eachVO.getStatus());
				acctOpeningList.add(eachDup);
			}
		}		
		resp.setDupList(acctOpeningList);
		return resp;
	}	
	
	public IMBResp populateBankSARegionsResp(Collection<RegionVO> regions){
		OpenDDAResp openDDAResp = new OpenDDAResp();
		if ( regions!= null)
		{
			ArrayList<KeyValueResp> regionList = new ArrayList<KeyValueResp>();
			for (Iterator<RegionVO> iterator = regions.iterator(); iterator.hasNext();) {
				RegionVO eachRegion = iterator.next();
				KeyValueResp nameIDResp = new KeyValueResp();
				nameIDResp.setId(  eachRegion.getRegionId() );
				nameIDResp.setName(  eachRegion.getRegionName() );
				regionList.add(nameIDResp);
			}
			openDDAResp.setRegions(regionList);
			
		}		
		return openDDAResp;
	}	

	
	public IMBResp populateopenDDAAccountResp(ArrayList<au.com.stgeorge.mbank.model.common.AccountResp> accountList, NewDDAAccount newAccount)
	{
		OpenDDAResp openDDAResp = new OpenDDAResp();
		ReceiptResp receiptResp = new ReceiptResp();
		String[] errorsOpen = new String[]{"1", "2", "100", "101", "103", "106"};
		String[] errorsTransfer = new String[]{"104", "105"};
		if(newAccount.getReceipt()!=null){
			receiptResp.setReceiptNumDisp(formatReceiptNumber(newAccount.getReceipt().getReceiptNumber()));
		}
		else{			
			receiptResp.setReceiptNumDisp("");
		}
		receiptResp.setDateTime(DateMethods.getTimestamp());
		receiptResp.setNewAccountNum(getFormattedAcctNumber(newAccount.getNewAcctNumber(), "DDA", null));
		if  (Arrays.asList(errorsOpen).contains(newAccount.getAcctOpenStatus())){
			receiptResp.setStatus("ERROR_OPEN");
		}else if (Arrays.asList(errorsTransfer).contains(newAccount.getAcctOpenStatus())){
			receiptResp.setStatus("ERROR_TRANSFER");
		}else{
			receiptResp.setStatus("SUCCESS");
		}
		openDDAResp.setAccounts(accountList);
		openDDAResp.setReceipt(receiptResp);
		
		if(newAccount.getNewSNSAcctNumber() != null)
		{
//			openDDAResp.setNewSNSAcctNumber(getFormattedAcctNumber(newAccount.getNewSNSAcctNumber(), "DDA", null));
			receiptResp.setNewSNSAccountNum(getFormattedAcctNumber(newAccount.getNewSNSAcctNumber(), "DDA", null));
		}
		
		if(newAccount.getNewWorkingAcctNumber() != null)
		{
	//		openDDAResp.setNewWorkAcctNumber(getFormattedAcctNumber(newAccount.getNewWorkingAcctNumber(), "DDA", null));
			receiptResp.setNewWorkAccountNum(getFormattedAcctNumber(newAccount.getNewWorkingAcctNumber(), "DDA", null));
		}
	
		if  (Arrays.asList(errorsOpen).contains(newAccount.getWorkingAcctStatus())){
//			openDDAResp.setNewWorkAcctStatus("ERROR_OPEN");
			receiptResp.setNewWorkAccountStatus("ERROR_OPEN");
		}else{
			receiptResp.setNewWorkAccountStatus("SUCCESS");
//			openDDAResp.setNewWorkAcctStatus("SUCCESS");
		}
		return openDDAResp;
	}
	
	public IMBResp populateOpenNewDDAAccountResp(ArrayList<au.com.stgeorge.mbank.model.common.AccountResp> accountList, NewDDAAccount newAccount,List<Account> fundingAccounts,
			List<Account> custAccounts,OpenDDAAcctReq req)
	{
		OpenDDAAcctResp openDDAResp = new OpenDDAAcctResp();	
		openDDAResp.setAppReferenceId(newAccount.getAppReferenceId());
		
		if(newAccount.getErrorReason().contains("accOpeningFailed") || newAccount.getErrorReason().contains("senseAcctOpngFailed")){
			//batch mode / acct parked in admin scenario
			if(getProdID(req.getProduct().getSubProdcode())== IBankParams.MAXI_SAVER_ACCOUNT){
				openDDAResp.setMaxiSaverOpened(false);		
				if(newAccount.getNewWorkingAcctNumber()!=null && !StringMethods.isEmptyString(newAccount.getNewWorkingAcctNumber())){
					OpenAcctDetail additionalProduct = new OpenAcctDetail();
					additionalProduct.setAccountNum(newAccount.getNewWorkingAcctNumber());
					additionalProduct.setBranchKey(newAccount.getWorkAcctBsb());
					additionalProduct.setAccountNumDisp(getFormattedAcctNumber(newAccount.getNewWorkingAcctNumber(), "DDA", null));
					additionalProduct.setAccountType("DDA");
					openDDAResp.setAdditionalAccountDetail(additionalProduct);					
				}
			}			
		}else{			
			if(newAccount.getErrorReason().contains("eStmtFailed")){
				openDDAResp.setStmtSuppressed(false);
			}
			else{
				openDDAResp.setStmtSuppressed(true);
			}
			if(newAccount.getErrorReason().contains("eStmtAddlProdctFailed")){
				openDDAResp.setAddlPrdctStmtSuppressed(false);
			}
			else{
				openDDAResp.setAddlPrdctStmtSuppressed(true);
			}
			
			//funding account indexes
			int id = -1;
			ArrayList<Integer> idList = new ArrayList<Integer>();
			for (Iterator<Account> iterator = fundingAccounts.iterator(); iterator.hasNext();) {
				Account eachAccount = iterator.next();
				if(eachAccount.getAccountId().getGroupCode() == null  || !eachAccount.getAccountId().getGroupCode().equals(Account.INCENTIVE_SAVER)){
					id = getAccountIndex(custAccounts, eachAccount.getAccountId());
					idList.add(id);
				}
			}			
			OpenAcctDetail openAcctDetail =new OpenAcctDetail();
			openAcctDetail.setAccountNum(newAccount.getNewAcctNumber());
			openAcctDetail.setBranchKey(newAccount.getBsbNumber());
			openAcctDetail.setAccountNumDisp(getFormattedAcctNumber(newAccount.getNewAcctNumber(), "DDA", null));			
			openAcctDetail.setAccountType("DDA");			
			openDDAResp.setNewAccountDetail(openAcctDetail);
			openDDAResp.setDepositFromAccountIndexes(idList);
			openDDAResp.setAccounts(accountList);
			
			//populated for maxi saver working account flow
			if(newAccount.getNewWorkingAcctNumber()!=null && !StringMethods.isEmptyString(newAccount.getNewWorkingAcctNumber())){
				OpenAcctDetail additionalProduct = new OpenAcctDetail();
				additionalProduct.setAccountNum(newAccount.getNewWorkingAcctNumber());
				additionalProduct.setBranchKey(newAccount.getWorkAcctBsb());
				additionalProduct.setAccountNumDisp(getFormattedAcctNumber(newAccount.getNewWorkingAcctNumber(), "DDA", null));
				additionalProduct.setAccountType("DDA");
				openDDAResp.setAdditionalAccountDetail(additionalProduct);
			}
			
			//if input request is for maxi saver account
			if(getProdID(req.getProduct().getSubProdcode())== IBankParams.MAXI_SAVER_ACCOUNT){	
				openDDAResp.setMaxiSaverOpened(true);	
				if(newAccount.getErrorReason().contains("HISAFailed")){
					openDDAResp.setMaxiSaverOpened(false);
				}
			}
			
			//populated for sense flow
			if(newAccount.getNewSNSAcctNumber()!=null && !StringMethods.isEmptyString(newAccount.getNewSNSAcctNumber())){
				OpenAcctDetail senseSavingsDetail =new OpenAcctDetail();
				senseSavingsDetail.setAccountNum(newAccount.getNewSNSAcctNumber());
				senseSavingsDetail.setBranchKey(newAccount.getBsbNumberSNS());
				senseSavingsDetail.setAccountNumDisp(getFormattedAcctNumber(newAccount.getNewSNSAcctNumber(), "DDA", null));
				senseSavingsDetail.setAccountType("DDA");
				openDDAResp.setSenseSavingsDetail(senseSavingsDetail);
			}
		}
		openDDAResp.setTranDateTime(DateMethods.getTimestamp());
		return openDDAResp;
	}
	
	public IMBResp populateFundDDAAcctResp(ArrayList<au.com.stgeorge.mbank.model.common.AccountResp> accountList, NewDDAAccount respAccount,List<Account> custAccounts,
			NewDDAAccount reqAccount,Integer fromAcctIndex)
	{
		FundDDAAcctResp fundDDAAcctResp = new FundDDAAcctResp();
		OpenAcctReceipt openReceipt = new OpenAcctReceipt();
		OpenAcctDetail fromAcctDetail = new OpenAcctDetail();
		OpenAcctDetail toAcctDetail = new OpenAcctDetail();
		fromAcctDetail.setAccountIndex(fromAcctIndex);
		
		if(respAccount.getReceipt()!=null){
			openReceipt.setReceiptNumDisp(formatReceiptNumber(respAccount.getReceipt().getReceiptNumber()));
			openReceipt.setDateTime(respAccount.getReceipt().getTimestamp());
			//get updated account - with balance
			if(respAccount.getCommonData()!=null && respAccount.getCommonData().getCustomer()!=null){
				//Account fromAcct =getAccountFromCustomer(respAccount.getCommonData().getCustomer(), fromAcctIndex.intValue());
				//fromAcctDetail.setAvailBalance(fromAcct.getAvailableBalance());
				//fromAcctDetail.setBalance(fromAcct.getBalance());
			}
			toAcctDetail.setAccountNum(reqAccount.getNewAcctNumber());			
		}
		else{
			openReceipt.setReceiptNumDisp("Unavailable");
		}
		openReceipt.setFromAccountDetail(fromAcctDetail);
		openReceipt.setToAccountDetail(toAcctDetail);
		fundDDAAcctResp.setAccounts(accountList);		
		fundDDAAcctResp.setReceipt(openReceipt);
		
	
		return fundDDAAcctResp;
	}		
	
	public static boolean isInternalNominatedAcct(String bsb) {
		boolean internalNomAcct = false;
		if (StringMethods.isValidString(bsb)) {
			String bsbPrefix = bsb.substring(0, 2);
			if (STG_BSB_PREFIX.equals(bsbPrefix)
					|| BSA_BSB_PREFIX.equals(bsbPrefix)
					|| CHS_BSB_PREFIX.equals(bsbPrefix)
					|| BOM_BSB_PREFIX.equals(bsbPrefix)) {
				internalNomAcct = true;
			}
		}
		return internalNomAcct;
	}

	public String getFormattedAcctNumber(String sAccount, String accountType,
			String bsb) {
		StringBuffer formattedAcctNum = new StringBuffer();
		int counter = 0;
		String temp = "";
		if (StringMethods.isValidString(sAccount)) {
			sAccount = sAccount.replaceAll(" ", "");
			sAccount = sAccount.trim();
			int len = sAccount.length();
			if (Account.NOM.equalsIgnoreCase(accountType)) {
				if (bsb != null && bsb.length() > 0) {
					boolean internalNomAcct = isInternalNominatedAcct(bsb);
					if (!internalNomAcct) {
						return sAccount;
					}
				}
			}
			if ((len > 9) && (!(Account.CDA.equalsIgnoreCase(accountType)))) {
				String acctNumStr = sAccount.substring(0, 4);
				if (acctNumStr.startsWith("0")) {
					sAccount = sAccount.replaceAll("^[0]*", "");
					if (sAccount.length() < 9) {
						sAccount = StringUtil
								.padLeadingString(sAccount, 9, '0');
					}
				}
			}
			len = sAccount.trim().length();
			if (Account.MGL.equalsIgnoreCase(accountType)) {
				formattedAcctNum.append(sAccount);
			} else if (Account.DDA.equalsIgnoreCase(accountType)
					|| Account.CDA.equalsIgnoreCase(accountType)
					|| Account.CHS.equalsIgnoreCase(accountType)) {
				if (len > 9) {
					formattedAcctNum = formatBSA(len, sAccount, accountType);
				} else {
					formattedAcctNum = format(3, len, sAccount);
				}
			} else if (Account.CRA.equalsIgnoreCase(accountType)) {
				formattedAcctNum = format(4, len, sAccount);
			}
			else if (Account.LIS.equalsIgnoreCase(accountType)
					|| (sAccount.length() > 0 && !(Character.isDigit(sAccount
							.charAt(0))))) {
				if (sAccount.length() > 3) {
					formattedAcctNum.append(sAccount.trim().substring(0, 4));
					formattedAcctNum.append(" ");
					for (int i = 4; i < len;) {
						counter = i + 3;
						if (counter > len) {
							counter = len;
						}
						temp = sAccount.trim().substring(i, counter);
						formattedAcctNum.append(temp);
						formattedAcctNum.append(" ");
						i = i + 3;
					}
				} else {
					formattedAcctNum.append(sAccount);
				}
			} else if (len == 16) {
				formattedAcctNum = format(4, len, sAccount);
			} else if (len > 0 && len <= 9) {
				formattedAcctNum = format(3, len, sAccount);
			}
			else if (len > 9 && len < 16) {
				formattedAcctNum = formatBSA(len, sAccount, accountType);
			} else {
				formattedAcctNum.append(sAccount);
			}
		}
		return formattedAcctNum.toString();
	}

	private StringBuffer format(int offSet, int len, String sAccount) {
		StringBuffer theBody = new StringBuffer();
		String temp = "";
		int counter = 0;
		for (int i = 0; i < len;) {
			counter = i + offSet;
			if (counter > len) {
				counter = len;
			}
			temp = sAccount.trim().substring(i, counter);
			theBody.append(temp);
			if (counter != len) 
				theBody.append(" ");
			i = i + offSet;
		}
		return theBody;
	}
	private StringBuffer formatBSA(int len, String sAccount, String accountType) {
		StringBuffer theBody = new StringBuffer();
		int counter = 0;
		String temp = "";
		sAccount = sAccount.trim();
		if (len < 13) {
			for (int j = 0; j < 13 - len; j++) {
				sAccount = "0" + sAccount;
			}
		} else if (len > 13 && len < 16) {
			for (int j = 0; j < 16 - len; j++) {
				sAccount = "0" + sAccount;
			}
		}
		len = sAccount.trim().length();
		if (Account.CDA.equalsIgnoreCase(accountType)) {
			if (!sAccount.trim().startsWith("000")) {
				theBody.append(sAccount.trim().substring(0, 3));
				theBody.append(" ");
				theBody.append(sAccount.trim().substring(3, 7));

			} else {
				theBody.append(sAccount.trim().substring(3, 7));

			}
		} else {
			theBody.append(sAccount.trim().substring(4, 7));
		}
		theBody.append(" ");
		for (int i = 7; i < len;) {
			counter = i + 3;
			if (counter > len) {
				counter = len;
			}
			temp = sAccount.trim().substring(i, counter);
			theBody.append(temp);
			if (counter != len) 
				theBody.append(" ");
			i = i + 3;
		}
		return theBody;
	}
	
	public static String formatReceiptNumber(String receiptNumber) {
		StringBuffer theBody = new StringBuffer();
		if (receiptNumber.length() < 1)
			return "";

		String first = "";

		if (!StringMethods.isNumber(receiptNumber.trim().substring(0, 1))) {
			first = receiptNumber.trim().substring(0, 1) + " ";
			receiptNumber = receiptNumber.trim().substring(1,
					receiptNumber.length());
		}

		int len = receiptNumber.length();
		int iter = len / 4;

		if (len <= 4) {
			theBody.append(receiptNumber);
		} else {
			int maxLen = 0;
			for (int i = 0; i <= iter; i++) {
				if (i * 4 + 4 > len)
					maxLen = len;
				else
					maxLen = i * 4 + 4;

				theBody.append(receiptNumber.trim().substring(i * 4, maxLen));
				theBody.append(" ");
			}
		}
		return first + theBody;
	}

	public IMBResp populateBranchDtlResp(List<BranchVO> branches)
	{
		OpenDDAResp openDDAResp = new OpenDDAResp();
		ArrayList<KeyValueResp> branchList = new ArrayList<KeyValueResp>();
		for (Iterator<BranchVO> iterator = branches.iterator(); iterator.hasNext();) {
			BranchVO branchVO = iterator.next();
			KeyValueResp nameIDResp = new KeyValueResp();
			nameIDResp.setId(  branchVO.getBranchId() );
			nameIDResp.setName(  branchVO.getBranchName() );
			branchList.add(nameIDResp);
		}
		openDDAResp.setBranches(branchList);
		return openDDAResp;

	}
	
	public IMBResp populateBranchResp(BranchVO branch)
	{
		OpenDDAResp openDDAResp = new OpenDDAResp();
		AddressResp addressResp = new AddressResp();
		addressResp.setAddrType("Branch");
		addressResp.setLine1(branch.getAddress1());
		addressResp.setLine2(branch.getAddress2());
		addressResp.setLine3(branch.getAddress3());
		addressResp.setSuburb(" ");
		addressResp.setState(" ");
		addressResp.setPostCode(" ");
		openDDAResp.setAddress(addressResp);
		return openDDAResp;
	}

	public int getAccountIndex(Collection acctList, AccountId pAccountId) {
		int i = 0;
		boolean found = false;
		if (acctList != null && !acctList.isEmpty()) {
			ArrayList list = (ArrayList) acctList;
			int size = list.size();
			for (; i < size; i++) {
				Account account = (Account) list.get(i);
				if (pAccountId.equals(account.getAccountId())) {
					found = true;
					break;
				}
			}
		}
		if (found)
			return i;
		else
			return -1;
	}

	private AddressResp populateAddress(Address address, String type)
	{
		AddressResp mbAddress = new AddressResp();
		if (address != null)
		{
			mbAddress.setAddrType(type);
			mbAddress.setCountryName(address.getCountryName());
			mbAddress.setLine1(address.getLine1());
			mbAddress.setLine2(address.getLine2());
			mbAddress.setLine3(address.getLine3());

			mbAddress.setPostCode(address.getPostZipcode());
			mbAddress.setState(address.getState());
			mbAddress.setSuburb(address.getSuburb());
		}
		return mbAddress;
	}

	public boolean isCustomerOver18(Customer customer){
	    Calendar today = Calendar.getInstance();
	    today.add(Calendar.YEAR, -18);
	    Calendar birth = Calendar.getInstance();
	    boolean resp = false;
	    if (customer.getBirthDate() != null){
	    	birth.setTime(customer.getBirthDate());
	
	    	if (birth.getTime().getTime() > today.getTime().getTime()){
	    		resp = false;
	    	}else{
	    		resp = true;
	    	}
	    }	
	    return resp;
	}

	public void validateAmount(OpenDDAReq req) throws BusinessException{
		
		
		if ( req.getFundingAccountIndex() != null ){
			
			boolean amountFlag = StringMethods.isNumber(req.getInitialAmount());
	  		if ((!amountFlag)){
	  		   throw new BusinessException(BusinessException.AMOUNT_INVALID);
	  		}
			
		    if (new BigDecimal(req.getInitialAmount()).compareTo(new BigDecimal(0)) < 0){
			    throw new BusinessException(BusinessException.ACCOUNT_NEGATIVE_AMOUNT);
		    }
		    try {
		      StringUtil.getMonetaryAmount(req.getInitialAmount());
		    }
		    catch (NumberFormatException nfe){
		      throw new BusinessException(BusinessException.AMOUNT_INVALID, nfe);
		    }			
		}
		validateSavingTarget(req.getSavingsTarget(),req.getProduct());
	}
	
	public void validateFundingAmt(String amt) throws BusinessException {
		boolean amountFlag = StringMethods.isNumber(amt);
  		if ((!amountFlag)){
  		   throw new BusinessException(BusinessException.AMOUNT_INVALID);
  		}
		
	    if (new BigDecimal(amt).compareTo(new BigDecimal(0)) < 0){
		    throw new BusinessException(BusinessException.ACCOUNT_NEGATIVE_AMOUNT);
	    }
	    if (new BigDecimal(amt).compareTo(new BigDecimal(0)) == 0){
		    throw new BusinessException(BusinessException.AMOUNT_INVALID);
	    }
	    try {
	      StringUtil.getMonetaryAmount(amt);
	    }
	    catch (NumberFormatException nfe){
	      throw new BusinessException(BusinessException.AMOUNT_INVALID, nfe);
	    }				
	}
	
	public void validateSavingTarget(String savingTargetAmount, ProductReq product) throws BusinessException{
		if (StringMethods.isEmptyString(savingTargetAmount))
			return;
		
		BigDecimal savingAmount = new BigDecimal(0);
		if (IBankParams.SENSE_EVERYDAY_ACCOUNT ==  getProdID(product.getSubProdcode())){
			boolean amountFlag = StringMethods.isNumber(savingTargetAmount);
	  		if ((!amountFlag)){
	  		   throw new BusinessException(BusinessException.AMOUNT_INVALID);
	  		}
			
		    if (new BigDecimal(savingTargetAmount).compareTo(new BigDecimal(0)) < 0){
			    throw new BusinessException(BusinessException.ACCOUNT_NEGATIVE_AMOUNT);
		    }
		    try {
		    	savingAmount = StringUtil.getMonetaryAmount(savingTargetAmount);
		    }
		    catch (NumberFormatException nfe){
		      throw new BusinessException(BusinessException.AMOUNT_INVALID, nfe);
		    }			
	    	CodesVO myCodesVO = null;
	 	    myCodesVO = IBankParams.getCodesData(IBankParams.DEFAULT_ORIGIN,IBankParams.SAVINGS_TARGET, IBankParams.SAVINGS_TARGET_MAXLIMIT);
	 	    double savingsTargetMax;
	 	    try{
	        	savingsTargetMax = new BigDecimal(myCodesVO.getMessage().trim()).doubleValue();
	        }
	        catch(Exception e){
	        	IBankLog.logTRC("Exception getting savingsTargetMax :"+e, this.getClass());
	        	throw new BusinessException(BusinessException.GENERIC_ERROR);
	        }
	       	if(savingAmount.doubleValue() > savingsTargetMax){
	      		   throw new BusinessException(BusinessException.SAVINGS_TAREGET_MAX_LIMIT_EXCEEDED);
	      	}		
		}
	}

	public int getProdID(String product){
		String prod = product;
		int i = prod.lastIndexOf("|");
		
		Logger.debug("**************** Sub Prod cde "+ product, this.getClass());
		
		prod = prod.substring(i+1);

		NewDDAProductsEnum ddaProdEnum = NewDDAProductsEnum.valueOf(prod.trim());
		String subProdCode = ddaProdEnum.getSubProdCode();
		return Integer.parseInt(subProdCode);
	}

	public void validateFundingAccount(Customer customer,Integer fundingAcctId ) throws BusinessException{
		if (fundingAcctId != null ){
			Account acct = getAccountFromCustomer(customer, fundingAcctId.intValue());
			if (acct == null){
				throw new BusinessException(BusinessException.SOURCE_ACCOUNT_NOT_SELECTED);
			}
		}
	}	

	public Account getAccountFromCustomer(Customer customer, int index) {
		Account account = null;
		if (customer.getAccounts() != null && customer.getAccounts().size() > 0) {
			ArrayList acctList = (ArrayList) customer.getAccounts();
			int acctListLen = customer.getAccounts().size();
			for (int i = 0; i < acctListLen; i++) {
				if (index == i) {
					account = (Account) acctList.get(i);
					break;
				}
			}
		}
		return account;
	}

	public void validateAddress(Customer customer)throws BusinessException{
		// Check If no residential address given
		if(customer.getContactDetail().getResidentialAddress()==null||customer.getContactDetail().getResidentialAddress().equals("")){
			// Please provide the residential address to proceed further.
			throw new BusinessException(BusinessException.RESIDENTIALADDR_REQUIRED);
		}		
	}

	public void validateCardDeliveryAddress(Customer customer, boolean isCustomerOver18)throws BusinessException{
		//Customer is minor, choose to pickup card, and Residential address is not in Australia
		if (!isCustomerOver18){
			if (!MBAppConstants.AUSTRALIA.equalsIgnoreCase(customer.getContactDetail().getResidentialAddress().getCountryName()) ){
				throw new BusinessException(BusinessException.OVERSEASADDRESS_ERROR);
			}
		}	
	}

//	public void validateMinAmount() throws BusinessException{
//		
//		String category = minAmountCodes.get(String.valueOf(getProdID()));
//		
//		CodesVO myCodesVO = IBankParams.getCodesData(IBankParams.DEFAULT_ORIGIN, category, IBankParams.CD_NEW_ACC_MIN_AMT);
//		
//		BigDecimal minimumAmount = new BigDecimal(myCodesVO.getMessage());
//		
//		
//	}
	
	private int resolveOrigin (String origin){
		int resp = 0;
		if (origin.equalsIgnoreCase(MBAppConstants.ORIGIN_MSTG)){
			resp = 0;
		}else if (origin.equalsIgnoreCase(MBAppConstants.ORIGIN_MBSA)){
			resp = 1;
		}else if (origin.equalsIgnoreCase(MBAppConstants.ORIGIN_MBOM)){
			resp = 2;
		}
		
		return resp;
	}

	public NewDDAAccount populateNewAccount(MobileSession mobileSession, OpenDDAReq req, IBankCommonData ibankCommonData){
		Account fundAcct;
		NewDDAAccount account = new NewDDAAccount();
		IBankCommonData commonData = ibankCommonData;
		
		int subProdCode = getProdID(req.getProduct().getSubProdcode());
		account.setAccountType(subProdCode);
		
       if( req.getFundingAccountIndex() == null ){
	       	account.setAmount(new BigDecimal("0"));
	       	account.setSourceAccount("-1");
	       	account.setSelectedBranch(req.getBranchId());	
	   }else{
	  	 if ( ! StringMethods.isEmptyString(req.getInitialAmount()) )
  			 {
          account.setAmount(StringUtil.getMonetaryAmount(req.getInitialAmount()));
          fundAcct = getAccountFromCustomer(mobileSession.getCustomer(), req.getFundingAccountIndex().intValue());
          account.setSourceFundsFrom(fundAcct);
  			 }
       }
       account.setCustomer(mobileSession.getCustomer());
       Logger.info("Is Request Card : " + req.isRequestCard() , this.getClass());
       if (req.isRequestCard())
       		account.setIsNewCardRequested(true);
       else
    	   account.setIsNewCardRequested(false);
	       
       account.setUser(mobileSession.getUser());
       account.setCommonData(commonData);
       if (req.getSavingsTarget()!=null && req.getSavingsTarget().length()>0){
    	   account.setSavingsTarget(new BigDecimal(req.getSavingsTarget()));
       }
      	 
       // changes for BOM.store the brand value (0,1,2)
       int brand = resolveOrigin(mobileSession.getOrigin());
      	account.setBrandValue(brand);
       if(getProdID(req.getProduct().getSubProdcode())== IBankParams.MAXI_SAVER_ACCOUNT){
      		account.setHisaWorkingAcct(true);
//      		if(!"-1".equalsIgnoreCase(req.getHisaWorkAcct())){
      		if( req.getAdditionalProduct() != null && ! StringMethods.isEmptyString(req.getAdditionalProduct().getSubProdcode())){      		
      			account.setHisaWorkingAcct(false);
      			account.setWorkingAcctType(getProdID(req.getAdditionalProduct().getSubProdcode()));
      			if (req.isRequestCard()){
      				account.setWorkingAcctNewCardRequested(true);
      			}else{
      				account.setWorkingAcctNewCardRequested(false);
      			}
      		}
      	}
		
   
       
		return account;
	}
	
	public NewDDAAccount populateNewDDAAccount(MobileSession mobileSession, OpenDDAAcctReq req, IBankCommonData ibankCommonData,Boolean statusUpd){		
		NewDDAAccount account = new NewDDAAccount();
		IBankCommonData commonData = ibankCommonData;
		
		int subProdCode = getProdID(req.getProduct().getSubProdcode());
		account.setAccountType(subProdCode);
		account.setAmount(new BigDecimal("0"));
		account.setSourceAccount("-1");
		account.setSelectedBranch(req.getBranchId());		
 
		account.setComingFromSavingsHabit(req.isComingFromSavingsHabit());
		
		account.setCustomer(mobileSession.getCustomer());
		if(isCustomerOver14(mobileSession.getCustomer()) && subProdCode==IBankParams.COMPLETE_FREEDOM_ACCOUNT){
			account.setIsNewCardRequested(true);
		}
		else{
			account.setIsNewCardRequested(false);
		}
		 Logger.info("populateNewDDAAccount:is Request Card : " + account.isNewCardRequested(), this.getClass());
		if(req.getComingFromCrossSell()){
			account.setComingFromCrossSell(true);			
		}
		else{
			account.setComingFromCrossSell(false);
		}
       	account.setUser(mobileSession.getUser());
       	account.setCommonData(commonData);
       	if (req.getSavingTargetAmount()!=null && req.getSavingTargetAmount().length()>0){
       		account.setSavingsTarget(new BigDecimal(req.getSavingTargetAmount()));
       	}
       	
       	// changes for BOM.store the brand value (0,1,2)
       	int brand = resolveOrigin(mobileSession.getOrigin());       	
      	account.setBrandValue(brand);
      	if(getProdID(req.getProduct().getSubProdcode())== IBankParams.MAXI_SAVER_ACCOUNT){
      		account.setHisaWorkingAcct(true);
      		if( req.getAdditionalProduct() != null && ! StringMethods.isEmptyString(req.getAdditionalProduct().getSubProdcode())){      		
      			account.setHisaWorkingAcct(false);
      			account.setWorkingAcctType(getProdID(req.getAdditionalProduct().getSubProdcode()));      			
      			if (isCustomerOver14(mobileSession.getCustomer())){
      				account.setWorkingAcctNewCardRequested(true);
      			}else{
      				account.setWorkingAcctNewCardRequested(false);
      			}
      		}
      	}
      	
      	if(req.getLeadId() != null)
      		account.setLeadId(req.getLeadId());
      	
      	 //19E3 tfn related changes
        if(!IBankParams.isSwitchOn(ibankCommonData.getOrigin(), IBankParams.TFN_SWITCH))
     	   account.setHasTFN(null);
        else{
      	    if(statusUpd)
      		   account.setHasTFN("Y");
      	    else
      		   account.setHasTFN("N");
        }
		return account;
	}	
	
	public NewDDAAccount populateNewDDAAccountForFunding(MobileSession mobileSession, FundDDAAcctReq req, IBankCommonData ibankCommonData){
		Account fundAcct;
		NewDDAAccount account = new NewDDAAccount();
		IBankCommonData commonData = ibankCommonData; 
		account.setCustomer(mobileSession.getCustomer());    
       	account.setUser(mobileSession.getUser());
       	account.setCommonData(commonData);
        account.setAmount(StringUtil.getMonetaryAmount(req.getInitialAmount()));        
        fundAcct = getAccountFromCustomer(mobileSession.getCustomer(), req.getFundingAccountIndex().intValue());
        account.setSourceFundsFrom(fundAcct);           
        //to account detail
        if(req.getNewAccountDetail().getProduct()!=null){
        	int subProdCode = getProdID(req.getNewAccountDetail().getProduct().getSubProdcode());
        	account.setAccountType(subProdCode);
        }
		account.setBsbNumber(req.getNewAccountDetail().getBranchKey());
        account.setNewAcctNumber(req.getNewAccountDetail().getAccountNum());	
        
       	int brand = resolveOrigin(mobileSession.getOrigin());       	
      	account.setBrandValue(brand);
      	account.setMobileClickOrigin(mobileSession.getOrigin());
		return account;
	}		
	
	public boolean isCustomerOver14(Customer customer){
	    Calendar today = Calendar.getInstance();
	    today.add(Calendar.YEAR, -14);
	    Calendar birth = Calendar.getInstance();
	    boolean resp = false;
	    if (customer.getBirthDate() != null){
	    	birth.setTime(customer.getBirthDate());
	
	    	if (birth.getTime().getTime() > today.getTime().getTime()){
	    		resp = false;
	    	}else{
	    		resp = true;
	    	}
	    }	
	    return resp;
	}	

	public int getHisaWorkId(String hisaWorkAcct){
		String prod = hisaWorkAcct;
		int i = prod.lastIndexOf("|");
		
		prod = prod.substring(i+1);
		
		return Integer.parseInt(prod);
	}	
	

	public IMBResp populateLandingStructure(MobileSession mobileSession, IBankCommonData ibankCommonData, List<Category> catList, CRAProductListContent craProductListContent)
	{
		ProductsLandingResp productsLandingResp = new ProductsLandingResp();
		productsLandingResp.setMyInvitations(new ArrayList<InvitationTemplateResp>());
		List invitationTemplates = null;
		String greenBirdTemplStat = null;
		
		for (Category category : catList)
		{
			for (SubCategory subcategory : category.getSubCats())
			{
				if (category.getId().equalsIgnoreCase("insurances"))
				{
					if ( isCometSwitch(mobileSession.getOrigin()) )
					{
						if (productsLandingResp.getInsurances() == null)
						{
							productsLandingResp.setInsurances(new ArrayList<String>());
						}
						productsLandingResp.getInsurances().add(subcategory.getClientId().toUpperCase());
					}
				}
				else if (category.getId().equalsIgnoreCase("creditCards"))
				{
					if (productsLandingResp.getCreditCards() == null)
					{
						productsLandingResp.setCreditCards(new ArrayList<String>());
					}
					String[] str = subcategory.getClientId().split(",");
					if ( str.length == 2 )
					{
						productsLandingResp.getCreditCards().add(str[0].toUpperCase());
						productsLandingResp.getCreditCards().add(str[1].toUpperCase());
					}
					else
					{
						productsLandingResp.getCreditCards().add(subcategory.getClientId().toUpperCase());
					}
					
				}
				else if (category.getId().equalsIgnoreCase("myInvitations"))
				{
					//19E4 Tech Debt Start:Switch Removal
					/*if(isGreenBirdSwitch(mobileSession.getOrigin())){*/
						if(invitationTemplates == null)
						{
							invitationTemplates = invitationTemplateDao.findListByBrand(IBankParams.getBaseOriginCode(ibankCommonData.getOrigin()));//TODO get base origin
							greenBirdTemplStat = getGreenBirdOfferTemplStatusFlag(invitationTemplates);
							Logger.info("greenBirdTemplStat : " + greenBirdTemplStat , this.getClass());
						}
						
						if (productsLandingResp.getMyInvitations() == null)
						{
							productsLandingResp.setMyInvitations(new ArrayList<InvitationTemplateResp>());
						}
						
						String[] str = subcategory.getClientId().split(",");
						if ( str.length == 2 )
						{
							if ( subcategory.getId().toUpperCase().startsWith(greenBirdTemplStat) || "BOTH".equalsIgnoreCase(greenBirdTemplStat) )
							{
								populateInvitationTemplateContent(productsLandingResp, invitationTemplates, subcategory.getId(), str[0]);
								populateInvitationTemplateContent(productsLandingResp, invitationTemplates, subcategory.getId(), str[1]);
							}
						}
						else
						{
							if ( subcategory.getId().toUpperCase().startsWith(greenBirdTemplStat) || "BOTH".equalsIgnoreCase(greenBirdTemplStat) )
							{
								populateInvitationTemplateContent(productsLandingResp, invitationTemplates, subcategory.getId(), str[0]);
							}
						}
						populateInvitationAmt(productsLandingResp, mobileSession);
					/*}
					*/
						//19E4 Tech Debt End:Switch Removal
				}
				else if (category.getId().equalsIgnoreCase("savingsAccount"))
				{
					if (productsLandingResp.getSavingAccounts() == null)
					{
						productsLandingResp.setSavingAccounts(new ArrayList<String>());
					}
					productsLandingResp.getSavingAccounts().add(subcategory.getClientId().toUpperCase());
				}else if (category.getId().equalsIgnoreCase("personalLoan"))
				{
					if (productsLandingResp.getPersonalLoans() == null)
					{
						productsLandingResp.setPersonalLoans(new ArrayList<String>());
					}
					productsLandingResp.getPersonalLoans().add(subcategory.getClientId().toUpperCase());
				} else if (category.getId().equalsIgnoreCase("transAccount"))
				{
					if (productsLandingResp.getTransAccount() == null)
					{
						productsLandingResp.setTransAccount(new ArrayList<String>());
					}
					productsLandingResp.getTransAccount().add(subcategory.getClientId().toUpperCase());

				} 
				else if (category.getId().equalsIgnoreCase("travelCard") )
				{
						
						if (  "GCC_CARD".equalsIgnoreCase(subcategory.getClientId().toUpperCase())  )
						{
							if ( isGCCSwitch(mobileSession.getOrigin()) )
							{
								if (productsLandingResp.getTravelCards() == null)
								{
									productsLandingResp.setTravelCards(new ArrayList<String>());
								}
								productsLandingResp.getTravelCards().add(subcategory.getClientId().toUpperCase());
							}
						}
						else
						{
							if (productsLandingResp.getTravelCards() == null)
							{
								productsLandingResp.setTravelCards(new ArrayList<String>());
							}
							productsLandingResp.getTravelCards().add(subcategory.getClientId().toUpperCase());
						}

				}
				else if (category.getId().equalsIgnoreCase("superAccounts") )
				{
						if ("BT_SUPER_FOR_LIFE".equalsIgnoreCase(subcategory.getClientId().toUpperCase()))
						{
							if ( isBTSwitch(mobileSession.getOrigin()) )
							{
								if (productsLandingResp.getSuperAccounts()== null)
								{
									productsLandingResp.setSuperAccounts(new ArrayList<String>());
								}
								productsLandingResp.getSuperAccounts().add(subcategory.getClientId().toUpperCase());
							}
						}
						else if ("BT_SUPER_SEARCH".equalsIgnoreCase(subcategory.getClientId().toUpperCase()))
						{
							if (productsLandingResp.getSuperAccounts()== null)
							{
								productsLandingResp.setSuperAccounts(new ArrayList<String>());
							}
							productsLandingResp.getSuperAccounts().add(subcategory.getClientId().toUpperCase());
						}
				}
				else if (category.getId().equalsIgnoreCase("homeLoans"))
				{
					//HOME_LOAN
					if(!IBankParams.isSwitchOn(mobileSession.getOrigin(), IBankParams.MORTGAGE_SWITCH)){
						if (productsLandingResp.getHomeLoans() == null)
						{
							productsLandingResp.setHomeLoans(new ArrayList<String>());
						}
						productsLandingResp.getHomeLoans().add(subcategory.getClientId().toUpperCase());
					}
				}
				else if (category.getId().equalsIgnoreCase("homeLoansNew"))
				{
					//HOME_LOAN_NEW
					if(IBankParams.isSwitchOn(mobileSession.getOrigin(), IBankParams.MORTGAGE_SWITCH)){
						if (productsLandingResp.getHomeLoans() == null)
						{
							productsLandingResp.setHomeLoans(new ArrayList<String>());
						}
						
						productsLandingResp.getHomeLoans().add(subcategory.getClientId().toUpperCase());
					}
				}
				else if (category.getId().equalsIgnoreCase("businessAccounts"))
				{
					if(IBankParams.isSwitchOn(mobileSession.getOrigin(), IBankParams.BUSINESS_ACCOUNT_SWITCH))
					{
						if (productsLandingResp.getBusinessAccounts() == null)
						{
							productsLandingResp.setBusinessAccounts(new ArrayList<String>());
						}
						productsLandingResp.getBusinessAccounts().add(subcategory.getClientId().toUpperCase());
					}
				}
				else
				{
					/*Logger.error("Not found ... " + category.getId()  ,  this.getClass());*/
					Logger.info("Not found ... " + category.getId()  ,  this.getClass());
				}

			}
			

			
			productsLandingResp.setStates( IBankParams.getStates());
			if ( mobileSession.getCustomer().getContactDetail() != null && mobileSession.getCustomer().getContactDetail().getResidentialAddress() != null )
			{
				if ( ! StringMethods.isEmptyString(mobileSession.getCustomer().getContactDetail().getResidentialAddress().getState()))
				{
					String selState = mobileSession.getCustomer().getContactDetail().getResidentialAddress().getState(); 
					productsLandingResp.setSelectedState(selState);
				}
				
			}
		}

		
		if ( productsLandingResp.getMyInvitations() != null && productsLandingResp.getMyInvitations().size() > 0 &&  productsLandingResp.getPersonalLoans() != null && productsLandingResp.getPersonalLoans().size() > 0 )
		{
			productsLandingResp.setPersonalLoans( reorderProdList( productsLandingResp.getPersonalLoans() , productsLandingResp.getMyInvitations() ));
		}

		//My Invitation for sales
		SalesOfferHelper salesOfferHelper = (SalesOfferHelper) ServiceHelper.getBean(SALES_OFFER_HELPER_BEAN);
		productsLandingResp.setSalesOffers(salesOfferHelper.populateSalesOfferResp(ibankCommonData));
		productsLandingResp.setCreditCardContent(getCreditCardContent(craProductListContent, IBankParams.getBaseOriginCode(ibankCommonData.getOrigin())));

		return productsLandingResp;
	}


	private static void populateInvitationAmt(ProductsLandingResp productsLandingResp, MobileSession mobileSession){
		
		Invitation invitation = mobileSession.getCustomer().getInvitation();
		
		if(InvitationTypeEnum.CREDIT_CARD.getInvitationType().equalsIgnoreCase(invitation.getProductType()))
			productsLandingResp.setCcInvitationDesc(invitation.getCcDescription());
		else if(InvitationTypeEnum.PERSONAL_LOAN.getInvitationType().equalsIgnoreCase(invitation.getProductType()))
			productsLandingResp.setPlInvitationDesc(invitation.getPlDescription());
		else{
			productsLandingResp.setCcInvitationDesc(invitation.getCcDescription());
			productsLandingResp.setPlInvitationDesc(invitation.getPlDescription());
		}
		
	}
	
    private boolean isGCCSwitch(String origin)
    {
		CodesVO codesVO = IBankParams.getCodesData(origin,	IBankParams.CONFIGURATION_PROPERTIES, "GCCSwitch");
		return ( codesVO == null || "ON".equalsIgnoreCase(codesVO.getMessage() ));
    }
    
    private boolean isBTSwitch(String origin)
    {
		CodesVO codesVO = IBankParams.getCodesData(origin,	IBankParams.CONFIGURATION_PROPERTIES, "BTSwitch");
		return ( codesVO == null || "ON".equalsIgnoreCase(codesVO.getMessage() ));
    }
	//19E4 Tech Debt Start:Switch Removal
  /*  protected boolean isGreenBirdSwitch(String origin)
    {
		CodesVO codesVO = IBankParams.getCodesData(origin,	IBankParams.CONFIGURATION_PROPERTIES, "GreenBirdSwitch");
		return ( codesVO == null || "ON".equalsIgnoreCase(codesVO.getMessage() ));
    }*/
	//19E4 Tech Debt End:Switch Removal
    
    protected boolean isCometSwitch(String origin)
    {
		CodesVO codesVO = IBankParams.getCodesData(origin,	IBankParams.CONFIGURATION_PROPERTIES, "CometSwitch");
		return ( codesVO == null || "ON".equalsIgnoreCase(codesVO.getMessage() ));
    }

    private List<String> reorderProdList( List<String> prodList, List<InvitationTemplateResp> myInvitations )
    {
    	 if ( myInvitations == null || myInvitations.size() < 1)
    		 return prodList;
    	 

    	 if ( prodList == null || prodList.size() < 1)
    		 return prodList;

    	 ArrayList<String> newList = new ArrayList<String>();

    	 for ( InvitationTemplateResp invite : myInvitations )
    	 {
    		 if ( prodList != null && prodList .size() > 0 )
    		 {
	        	 for ( String product : prodList )
	        	 {
		    		 if ( product.equalsIgnoreCase(invite.getProdName())  )
		    		 {
		    			 newList.add(invite.getProdName());
		    			 prodList.remove(product);
		    			 break;
		    		 }
	        	 }
    		 }
    	 }
    	 
		 if ( prodList != null && prodList .size() > 0 )
		 {
        	 for ( String product : prodList )
        	 {
	    		 if ( ! StringMethods.isEmptyString(product)  )
	    		 {
	    			 newList.add(product);
	    		 }
        	 }
		 }

		 return  newList;
    }
    
    
    

	private void populateInvitationTemplateContent(ProductsLandingResp productsLandingResp, List invitationTemplates, String subCategoryId, String clientId) {
    	for(Object obj : invitationTemplates){
    		InvitationTemplateVO invitationTemplateVO = (InvitationTemplateVO)obj;
    		if(subCategoryId.equalsIgnoreCase(invitationTemplateVO.getProductCode())){
    			//TODO encode HTML
    			InvitationTemplateResp invitationTemplateResp = new InvitationTemplateResp(); 
    			invitationTemplateResp.setProdName(clientId);
    			invitationTemplateResp.setInvitationText(formatInvitationText(invitationTemplateVO));
    			invitationTemplateResp.setInvitationTerms(invitationTemplateVO.getInvitationTerms());
    			invitationTemplateResp.setLandingPageText(invitationTemplateVO.getLandingPageContent());
    			invitationTemplateResp.setLandingPageTerms(invitationTemplateVO.getLandingPageTerms());
    			
    			productsLandingResp.getMyInvitations().add(invitationTemplateResp);
    		}
    	}
	}

	private String formatInvitationText(InvitationTemplateVO invitationTemplateVO) {
		StringBuilder invitationTextBuilder = new StringBuilder();
		
		invitationTextBuilder.append("<ul><li>");
		invitationTextBuilder.append(invitationTemplateVO.getText1());
		invitationTextBuilder.append("</li><li>");
		invitationTextBuilder.append(invitationTemplateVO.getText2());
		invitationTextBuilder.append("</li><li>");
		invitationTextBuilder.append(invitationTemplateVO.getText3());
		invitationTextBuilder.append("</li></ul>");

		return invitationTextBuilder.toString();
	}    
	
	public String getGreenBirdOfferTemplStatusFlag(List list){
		try
		{
			boolean isCRAactive = true;
			boolean isUPLactive = true;
			
			for ( Object invite :list )
			{
				InvitationTemplateVO inviteVO = (InvitationTemplateVO) invite;
				if ( inviteVO.getStatus() != InvitationStatusEnum.Active.getValue()  )
				{
					if ( isCRAactive && inviteVO.getProductType().equalsIgnoreCase(InvitationProductTypeEnum.CreditCard.getValue()) )
					{
						isCRAactive = false;
					}
					else if ( isUPLactive && inviteVO.getProductType().equalsIgnoreCase(InvitationProductTypeEnum.UnsecuredPersonalLoan.getValue()) )
					{
						isUPLactive = false;
					}
				}
				
				if ( ! isCRAactive && ! isUPLactive  )
				{
					break;
				}
			}
	
			if (  isCRAactive &&  isUPLactive  )
			{
				return "BOTH";
			}
			else if (  isCRAactive )
			{
				return InvitationProductTypeEnum.CreditCard.getValue();	
			}
			else if (  isUPLactive )
			{
				return  "PLUNS" ;//InvitationProductTypeEnum.UnsecuredPersonalLoan.getValue();
			}
		}
		catch (Exception e)
		{
			Logger.error("getGreenBirdOfferTemplStatusFlag(, clazz) method failed. " , e, this.getClass() );
		}
		return "NONE";
	}
	
	public ProductListContentResp getCreditCardContent(CRAProductListContent craProductListContent, String origin){
		
		ProductListContentResp productListContentResp = null;
		
		if(craProductListContent != null && craProductListContent.getContents() != null && craProductListContent.getContents().size() > 0){
			
			productListContentResp = new ProductListContentResp();
			productListContentResp.setHeaderName("Credit cards");
			ProductContentResp productContentResp = null ;
			List<ProductContentResp> productContentListResp = new ArrayList<ProductContentResp>();
        	for(CRAProductContent craProductContent : craProductListContent.getContents()){
        		
        		String aemProdKey = craProductContent.getProductKey();
        		aemProdKey = aemProdKey.toUpperCase().replace("-", "_");
        		if(AEMCRAProdEnum.lookUp(aemProdKey) != null){
        			
        			productContentResp = new ProductContentResp();
        		productContentResp.setProductName(AEMCRAProdEnum.valueOf(aemProdKey).getValue());
        		productContentResp.setProductTitle(craProductContent.getProduct());
        		
        		if(craProductContent.getLineItems() != null && craProductContent.getLineItems().size() > 0){
        			List<ProductListItemResp> productContentList = new ArrayList<ProductListItemResp>();
        			List<ProductListItemResp> productCtatList = new ArrayList<ProductListItemResp>();
        			ProductListItemResp productListItemResp = null;
        			for(CRAContent craContent : craProductContent.getLineItems()){
        				
        				if(craContent.getContentType().equalsIgnoreCase(ContentManagementService.JSON_CONTENT_TITLE)){
        					//productContentResp.setProductSubTitle(craContent.getContentText());
        				}
        				else{
	        				productListItemResp = new ProductListItemResp();
	        				productListItemResp.setContentType(craContent.getContentType());
	        				
	        				String content = URLEncoder.encode(craContent.getContentText());//ISG : Sanitise msg before sending it to mobile
	        				
	        				
	        				productListItemResp.setContent(content);
	        				productListItemResp.setType(craContent.getPriority());
	        				productListItemResp.setSrText(craContent.getAccessibilityText());
	        				
	        				if(craContent.getContentType().equalsIgnoreCase(ContentManagementService.JOSN_CONTENT_CTA)){
	        					productCtatList.add(productListItemResp);
	        				}
	        				else{
	        					productContentList.add(productListItemResp);
	        				}
        				}
        			}
        			
        			if(productContentList.size() > 0){
                		productContentResp.setProductContent(productContentList);
                	}
        			if(productCtatList.size() > 0){
                		productContentResp.setProductCta(productCtatList);
                	}
        			/*if(productDisclaimertList.size() > 0){
        				productDisclaimerResp.setHeaderName(ContentManagementService.TYSK_HEADING);
        				productDisclaimerResp.setContent(productDisclaimertList);
        				productListContentResp.setDisclaimer(productDisclaimerResp);
                	}*/
        			
        		}
        		
        		productContentListResp.add(productContentResp);
        		}
        		
        	}
        	if(productContentListResp.size() > 0){
        		productListContentResp.setProducts(productContentListResp);
        	}
        	
        	if(craProductListContent.getDisclaimerItems() != null && craProductListContent.getDisclaimerItems().size() > 0){
    			
    			ProductDisclaimerResp productDisclaimerResp = new ProductDisclaimerResp();
    			List<ProductListItemResp> productDisclaimertList = new ArrayList<ProductListItemResp>();
    			ProductListItemResp productListItemResp = null;
    			for(CRAContent craContent : craProductListContent.getDisclaimerItems()){
    				
    				productListItemResp = new ProductListItemResp();
    				productListItemResp.setContentType(craContent.getContentType());
    				
    				String content = URLEncoder.encode(craContent.getContentText());//ISG : Sanitise msg before sending it to mobile
    				
    				
    				productListItemResp.setContent(content);
    				productListItemResp.setType(craContent.getPriority());
    				productListItemResp.setSrText(craContent.getAccessibilityText());
    				
   					productDisclaimertList.add(productListItemResp);
        				
    				}
    			if(productDisclaimertList.size() > 0){
    				//Get the Disclaimer title from Brand Variables
    				HashMap brandMap = IBankParams.getAEMBrandMap();
    				
    				String matchedMacro = origin + ".CFRTE.BV." + ContentManagementService.JSON_CONTENT_DISCLAIMER_TITLE;
    				String tyskHeading = (String) brandMap.get(matchedMacro.toUpperCase());
    				if(!StringMethods.isEmptyString(tyskHeading)){
    					productDisclaimerResp.setHeaderName(tyskHeading);
    				}
    				else{
    					productDisclaimerResp.setHeaderName(ContentManagementService.TYSK_HEADING);
    				}
    				//productDisclaimerResp.setHeaderName(ContentManagementService.TYSK_HEADING);
    				productDisclaimerResp.setContent(productDisclaimertList);
    				productListContentResp.setDisclaimer(productDisclaimerResp);
            	}    			
    		}      	
        }
		
		return productListContentResp;
	}

	public IMBResp populateCRAProductListContent(ProductsLandingResp productsLandingResp, CRAProductListContent craProductListContent) {		
		return null;
	}
	
	public NewDDAAccount createNewDDAAccount(OpenDDAAcctReq req, MobileSession mbSession, IBankCommonData ibankCommonData, AccountOpeningService accountOpeningService,Boolean statusUpd) throws ResourceException, BusinessException {
		NewDDAAccount account = populateNewDDAAccount(mbSession, req, ibankCommonData,statusUpd);
		account.setAccountOpenedMode("MB");
		return (NewDDAAccount) accountOpeningService.createAccount(account);
	}
	
	public IMBResp createOpenNewDDAAccountResp(NewDDAAccount newDDAAccount, OpenDDAAcctReq req, MobileSession mbSession, IBankCommonData ibankCommonData, AccountOpeningService accountOpeningService, LogonHelper logonHelper, OpenDDAService openDDAService) throws BusinessException {
		ArrayList<au.com.stgeorge.mbank.model.common.AccountResp> accountList = null;
		List<Account> fundingAccounts = null;
		
		if (openDDAService != null) {
			if (newDDAAccount.isNewAcctFound() && newDDAAccount.getCommonData() != null	&& newDDAAccount.getCommonData().getCustomer() != null) {
				accountList = logonHelper.populateAccountList(newDDAAccount.getCommonData().getCustomer(), null);
				// update the customer in session
				mbSession.setCustomer(newDDAAccount.getCommonData().getCustomer());
				fundingAccounts = openDDAService.getFundingAccounts(newDDAAccount.getCommonData());
			} else {
				fundingAccounts = openDDAService.getFundingAccounts(ibankCommonData);
			}
		}

		return populateOpenNewDDAAccountResp(accountList, newDDAAccount, fundingAccounts, mbSession.getCustomer().getAccounts(), req);
	}

	public void orderCompleteFreedomDebitCard(NewDDAAccount newDDAAccount, AccountOpeningService accountOpeningService, DebitCardServiceImpl debitCardService, boolean isComingFromSavingsHabit) {
		Logger.debug("Is account Complete Freedom ?" + newDDAAccount.getAccountType(), this.getClass());
		Logger.debug("Is card requested ?" + newDDAAccount.isNewCardRequested(), this.getClass());
		Logger.debug("Error reason for account " + newDDAAccount.getErrorReason(), this.getClass());
		
		/*
		 * if (newDDAAccount.getCommonData().getCustomer().getCustTypeInd().
		 * equalsIgnoreCase("P")) {
		 */
		if (newDDAAccount.getErrorReason() == null || newDDAAccount.getErrorReason().trim().isEmpty()) {
			if (newDDAAccount.getAccountType() == IBankParams.COMPLETE_FREEDOM_ACCOUNT) {
				if (debitCardService != null && newDDAAccount.isNewCardRequested()) {
					debitCardService.orderDebitCardForCustomer(newDDAAccount);
				} else if (accountOpeningService != null) {
					Logger.debug("CARD_ORDER_NOT_ELIGIBLE for Customer...2", this.getClass());
					accountOpeningService.updateDebitCardStatus(newDDAAccount.getDebitCardId(),
						EVConstants.CARD_ORDER_NOT_ELIGIBLE, "Account Opened but customer not eligible for debit card");
				}
			} else if (accountOpeningService != null) {
				Logger.debug("CARD_ORDER_STATUS_NO_ELIGIBLE_ACCTS for Customer...2", this.getClass());
				accountOpeningService.updateDebitCardStatus(newDDAAccount.getDebitCardId(),
					EVConstants.CARD_ORDER_STATUS_NO_ELIGIBLE_ACCTS, "Card not ordered as it is not a Complete Freedom account");
			}
		} else if (accountOpeningService != null) {
			if (isComingFromSavingsHabit) {
				Logger.debug("CARD_ORDER_STATUS_NO_ELIGIBLE_ACCTS for Customer...2", this.getClass());
				accountOpeningService.updateDebitCardStatus(newDDAAccount.getDebitCardId(),
					EVConstants.CARD_ORDER_STATUS_NO_ELIGIBLE_ACCTS, "Card not ordered as it is not a Complete Freedom account");
			} else {
				Logger.debug("CARD_NOT_ORDERED for Customer...2", this.getClass());
				accountOpeningService.updateDebitCardStatus(newDDAAccount.getDebitCardId(),
						EVConstants.CARD_NOT_ORDERED, "Card not ordered as Account Opening is failed");
			}
		}
	}
	
	public IMBResp openNewDDAAccount(OpenDDAAcctReq req, MobileSession mbSession, IBankCommonData ibankCommonData, AccountOpeningService accountOpeningService, LogonHelper logonHelper, OpenDDAService openDDAService, DebitCardServiceImpl debitCardService,Boolean statusUpd) throws BusinessException {
		NewDDAAccount newDDAAccount = createNewDDAAccount(req, mbSession, ibankCommonData, accountOpeningService,statusUpd);
		
		if (req.isComingFromSavingsHabit()) {
			if (newDDAAccount.isInvalidBranchError()) {
				throw new BusinessException(BusinessException.ACCOUNT_INVALID_BSB);
			} else if (newDDAAccount.isBatchModeError()) {
				throw new BusinessException(BusinessException.ACCT_OPEN_GHS_BATCH_MODE);
			}
		}
			
 		IMBResp serviceResponse = createOpenNewDDAAccountResp(newDDAAccount, req, mbSession, ibankCommonData, accountOpeningService, logonHelper, openDDAService);
				
		if (debitCardService != null) {
			orderCompleteFreedomDebitCard(newDDAAccount, accountOpeningService, debitCardService, req.isComingFromSavingsHabit());
		}
		
		return serviceResponse;
	}
	
	public ArrayList<AcctOpeningVO> getNewAcctDuplicateList(ProductReq product, IBankCommonData ibankCommonData, AccountOpeningService accountOpeningService) throws BusinessException {
	    IBankCommonData commonData = ibankCommonData;
	    ArrayList<AcctOpeningVO> duplicateAcctOpeningList = null;
	    AcctOpeningVO newAcct = new AcctOpeningVO();
	    newAcct.setGcisNumber(commonData.getUser().getGCISNumber());
	    newAcct.setSubProdCode(String.valueOf(getProdID(product.getSubProdcode())));
	    
	    try {
	    	duplicateAcctOpeningList = (ArrayList<AcctOpeningVO>) accountOpeningService.getDuplicateReqList(newAcct);
	    } catch (BusinessException e) {
	    	if (e.getKey() == BusinessException.MAX_ACCT_OPENING_REQ) {
	    		IBankLog.logWRN("Max Acct Opening Req reached in getNewAcctDuplicateList", this.getClass());
	    		throw e;
	    	}
	    } catch (ResourceException e) {
	    	IBankLog.logWRN(" ResourceException in getNewAcctDuplicateList in New Acct Opening", this.getClass());
	    }
	    
	    return duplicateAcctOpeningList;
	}
	
	
	//Set TFN flags for CompleteFreedom cross cell functionality 
	public IMBResp populateTFNResponse(IMBResp openDDAResp, boolean showTfn, boolean tfnException) {
		
		OpenDDAAcctResp resp = (OpenDDAAcctResp) openDDAResp;
		
		resp.setTfnException(tfnException);
		resp.setShowTfn(showTfn);
		
		return resp;
	}
}

