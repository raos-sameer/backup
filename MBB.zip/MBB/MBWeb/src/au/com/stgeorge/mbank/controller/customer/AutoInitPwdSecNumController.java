package au.com.stgeorge.mbank.controller.customer;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import au.com.stgeorge.framework.common.logging.Logger;
import au.com.stgeorge.framework.common.model.User;
import au.com.stgeorge.framework.common.util.StringMethods;
import au.com.stgeorge.ibank.businessobject.BusinessException;
import au.com.stgeorge.ibank.businessobject.EStatementService;
import au.com.stgeorge.ibank.businessobject.IBankSecureService;
import au.com.stgeorge.ibank.businessobject.ResourceException;
import au.com.stgeorge.ibank.businessobject.StatisticsService;
import au.com.stgeorge.ibank.businessobject.ecorrespondence.ECorrespondenceService;
import au.com.stgeorge.ibank.common.cache.IBankParams;
import au.com.stgeorge.ibank.dao.DAOConstants;
import au.com.stgeorge.ibank.evcrs.businessobject.CRSService;
import au.com.stgeorge.ibank.evcrs.businessobject.valueobject.CRSInfo;
import au.com.stgeorge.ibank.loanApplication.LoanApplicationDetail;
import au.com.stgeorge.ibank.loanApplication.util.LoanAppConstants;
import au.com.stgeorge.ibank.loanApplication.util.LoanAppUtil;
import au.com.stgeorge.ibank.messagecentre.util.MessageCentreConstants;
import au.com.stgeorge.ibank.messagecentre.valueobject.CustomerMessage;
import au.com.stgeorge.ibank.messagecentre.valueobject.MessageSearch;
import au.com.stgeorge.ibank.safi.util.SafiConstants;
import au.com.stgeorge.ibank.safi.valueobject.SafiLogonInfo;
import au.com.stgeorge.ibank.servicestation.businessobject.ServiceStation;
import au.com.stgeorge.ibank.servicestation.businessobject.ServiceStationImpl;
import au.com.stgeorge.ibank.servicestation.businessobject.valueobject.ServiceStationVO;
import au.com.stgeorge.ibank.servicestation.util.ServicetationConstants;
import au.com.stgeorge.ibank.util.CommonBusinessUtil;
import au.com.stgeorge.ibank.util.ServiceHelper;
import au.com.stgeorge.ibank.valueobject.Account;
import au.com.stgeorge.ibank.valueobject.AutoApplyRetentionInfo;
import au.com.stgeorge.ibank.valueobject.ContactDetail;
import au.com.stgeorge.ibank.valueobject.Customer;
import au.com.stgeorge.ibank.valueobject.MsgCentreInfo;
import au.com.stgeorge.ibank.valueobject.Statistic;
import au.com.stgeorge.ibank.valueobject.database.OriginsVO;
import au.com.stgeorge.ibank.valueobject.transfer.IBankCommonData;
import au.com.stgeorge.mbank.model.common.ErrorInfo;
import au.com.stgeorge.mbank.model.common.IMBReq;
import au.com.stgeorge.mbank.model.common.IMBResp;
import au.com.stgeorge.mbank.model.common.RespHeader;
import au.com.stgeorge.mbank.model.common.SplashPageResp;
import au.com.stgeorge.mbank.model.request.customer.AutoInitPwdSecNumReq;
import au.com.stgeorge.mbank.model.response.ErrorResp;
import au.com.stgeorge.mbank.model.response.customer.LogonResp;
import au.com.stgeorge.mbank.session.MobileSession;
import au.com.stgeorge.mbank.util.MBAppConstants;
import au.com.stgeorge.mbank.util.MBAppHelper;
import au.com.stgeorge.mbank.util.MBAppUtils;
import au.com.stgeorge.mbank.util.MBAppValidator;
import au.com.stgeorge.mobilebank.businessobject.ActivationService;
import au.com.stgeorge.mobilebank.businessobject.MobileBankService;
import au.com.stgeorge.mobilebank.businessobject.MobileMsgCntrService;
import au.com.stgeorge.perflogger.PerformanceLogger;

import com.fasterxml.jackson.databind.ObjectMapper;

@Controller
@RequestMapping(method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE)
public class AutoInitPwdSecNumController {
	
	@Autowired
	private MBAppHelper mbAppHelper;
	
	@Autowired
	private MBAppValidator mbAppValidator;
	
	@Autowired
	private MobileBankService mobileBankService;
	
	@Autowired
	private PerformanceLogger perfLogger;
	
	@Autowired
	private ActivationService activationService;
	
	@Autowired
	private MobileMsgCntrService msgCntrService;
	
	@Autowired
	private LogonHelper logonHelper;
	
	@Autowired
	private ServiceStation serviceStationService;
	
	@Autowired
	private EStatementService eStatementService;
	
	@Autowired
    private CRSService crsService;	
	
	@Autowired
    private ECorrespondenceService eCorrespondenceService;
	
	protected static final String AUTO_INIT_AUDIT_LOG_DESC = "Initial Auto Init Set Security Number and password";
	protected static final String ESTMT_STATUS = "S";
	protected static final String APPLICATION = "Auto Init Setup";
	public static final String PERSONAL_CUSTOMER = "P";
	private static final String CRS_SPLASH_TYPE = "CRS";

	
@RequestMapping(value="autoInitPwdSecNumSetUp", method = RequestMethod.POST, headers = "content-type=application/json", produces= MediaType.APPLICATION_JSON_VALUE)
@ResponseBody
public IMBResp resetInitialPwdSecNum(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse,@RequestBody final AutoInitPwdSecNumReq req)
	{
		Logger.debug("In resetInitialPwdSecNum  for Customer " +  "  " + httpServletRequest.getContentType() + " "
				+ httpServletRequest.getRemoteAddr() + "  " + httpServletResponse.getCharacterEncoding() + httpServletResponse.getLocale() +
				" True IP >> " + httpServletRequest.getHeader(IBankParams.trueClientIP()), this.getClass());
		perfLogger.startAllLogs();
		ObjectMapper mapper = new ObjectMapper();
		String logName = MBAppUtils.getLogName(httpServletRequest);
		perfLogger.startLog(logName);
		MobileSession mbSession = null;
		int unreadMsgCount = -1;
		AutoInitPwdSecNumHelper helper=new AutoInitPwdSecNumHelper();
		List<Account> accountListToSwitch=new ArrayList<Account>();
		boolean emailUpdateFailed=false;
		boolean switchToEstmtFailed=false;
		ServiceStationVO servicestationVO=null;
		List populateSplashPageResult = null;
		
		try
		{
			Logger.info("resetInitialPwdSecNum AutoInit Admin JSON Request :" , this.getClass());
			mbSession = mbAppHelper.getMobileSession(httpServletRequest);
			
			String loggedonState =mbSession.getLoggedonState();
			Logger.info("resetInitialPwdSecNum AutoInit loggedonState :"+loggedonState , this.getClass());
			if(LogonHelper.AUTO_INIT_RESET_PWD_SECNUM.equalsIgnoreCase(loggedonState)){
				Logger.info("resetInitialPwdSecNum inside :" , this.getClass());
				ErrorResp errorResp = validate(req, httpServletRequest);
				if (errorResp != null && errorResp.getErrors() != null && errorResp.getErrors().size() > 0)
				{
					return errorResp;
				}
				helper.validateAutoInitPwdSec(req);
				mbSession.getSessionContext(httpServletRequest);
				User user=mbSession.getUser();
				IBankCommonData ibankCommonData = mbAppHelper.populateIBankCommonData(mbSession, httpServletRequest);
				if(user != null) {
					Logger.info("prepareOnline Scenario" , this.getClass());
					user.setActionType(req.getActionType());
					ibankCommonData.setUser(user);
				}
				activationService.setInitialPwdSecurityNumber(ibankCommonData, "Test Ref", req.getNewPassword(), req.getNewSecNum(),IBankParams.MSG_TYPE_AUTOINIT_SET_SEC_NUM_PWD);
				Logger.info("resetInitialPwdSecNum after activation 1:" , this.getClass());
				
				// update Email Address at the time of Activation
				if( StringMethods.isEmptyString(ibankCommonData.getCustomer().getContactDetail().getEmail()) &&  !StringMethods.isEmptyString(req.getEmailAddress())){
					try{ 
						 Logger.info("Going for email update:" , this.getClass()); 
						 ContactDetail myContactDetails = ibankCommonData.getCustomer().getContactDetail();
					     myContactDetails.setEmail(req.getEmailAddress());
					     /*
					      * 17E4 Fix for CHS only customer email update
					      */
                         myContactDetails.setCustomerNumber(getCustomerNumber(ibankCommonData));
				         activationService.updateEmailAddressAtActivation(myContactDetails, ibankCommonData);				         
				         Logger.info("resetInitialPwdSecNum after update email activation 1:" , this.getClass());
					}
					catch (BusinessException e)
					{
						emailUpdateFailed=true;
						Logger.error("Exception Inside auto init activation while updating email address 1: :", e, this.getClass());
					}
					 catch (Exception e)
					{
						 emailUpdateFailed=true;
						 Logger.error("Exception Inside auto init activation while updating email address 2: :", e, this.getClass()); 
					}
				 }
				
				Customer customer=mbSession.getCustomer();
				if ( customer == null || StringMethods.isEmptyString( customer.getGcis() ) )
				{
					customer = mobileBankService.getCustomer(ibankCommonData);
					mbSession.setCustomer(customer);
					ibankCommonData.setCustomer(customer);
				}
				
				//18E1 Staff Assisted Registration: GDW Entry and Preference Table Update for ECorrespondence
				if(CommonBusinessUtil.isECorrespondenceSupported(httpServletRequest)){
					if(req.geteCorrespondenceConsent() != null){
						eCorrespondenceService.updateConsentPrefAndStatisticsLog(ibankCommonData, ECorrespondenceService.REGISTRATION_SOURCE, req.geteCorrespondenceConsent());
					}
				}
				
				// Getting message Centre messages
//				Splash page update MsgCount				
			//	List<Object> splashPageInfo = null;
				MsgCentreInfo msgCentreInfo=null;List<MessageSearch> splashPageInfo =null;AutoApplyRetentionInfo autoApplyRetentionInfo=null;
				try{
					Logger.debug("Processing splashPageInfo", this.getClass());
					boolean isECorrespondenceSupported = CommonBusinessUtil.isECorrespondenceSupported(httpServletRequest);
					//splashPageInfo= processMsgCentre(mbSession.getOrigin(),customer.getGcis(),isECorrespondenceSupported);
					msgCentreInfo= processMsgCentre(mbSession.getOrigin(),customer.getGcis(),isECorrespondenceSupported);
					splashPageInfo = msgCentreInfo.getSplashPageInfo();
					
					MessageSearch messageSearch = splashPageInfo.get(0);
					
					mbSession.setSplashInfoMsg(messageSearch);
					if(splashPageInfo != null && !splashPageInfo.isEmpty()){
						unreadMsgCount = msgCentreInfo.getUnreadMessageCount()   /* (Integer)splashPageInfo.get(0)*/;
						Logger.debug("splashPageInfo - unreadMsgCount: "+unreadMsgCount, this.getClass());
					}
					List<AutoApplyRetentionInfo> digiRetInfoList=		msgCentreInfo.getApplyRetentionInfo();
					
					/*if(digiRetInfoList!= null && digiRetInfoList.size()>0 && digiRetInfoList.get(0)!=null ){
						 autoApplyRetentionInfo = digiRetInfoList.get(0);
						//customer.setDigiretAccountNumber(autoApplyRetentionInfo.getAccountNumber());
						 mbSession.setAutoApplyRetentionInfo(autoApplyRetentionInfo);
						//genericSession.setAttribute(MobileSessionImpl.AUTO_APPLY_RETENTION_SESSION, autoApplyRetentionInfo);
					}
					 */
					if(digiRetInfoList!= null && digiRetInfoList.size()>0 ){
						try{
						 autoApplyRetentionInfo = digiRetInfoList.get(0);
					
						 Logger.debug("Auto Apply retention info message seen: "+autoApplyRetentionInfo.getAccountNumber(), this.getClass());
						 
						 mbSession.setAutoApplyRetentionInfo(autoApplyRetentionInfo);
						}
						catch(Exception e){
							Logger.info("AutoInitPwdSecNumController:resetInitialPwdSecNum() autoApplyRetentionInfo is null", this.getClass());
						}
					}
				}
				catch (BusinessException e)
				{
					Logger.error("Exception Inside auto init activation msg cntr msg 1: :", e, this.getClass());
				}
				 catch (ResourceException ex)
				{
					 Logger.error("Exception Inside auto init activation msg cntr msg 2: :", ex, this.getClass()); 
				}
				 catch (Exception exp)
				{
					 Logger.error("Exception Inside auto init activation msg cntr msg 3: :", exp, this.getClass()); 
				}

				// call service to get ServiceAdminVo	
				long insertionPt = logonHelper.getInsertionPointCode(ServicetationConstants.DASHBOARD);
				servicestationVO=populateServiceMessage(insertionPt,ServiceStationImpl.CHANNEL_MOBILE, ibankCommonData);
				if(null!=servicestationVO)
				 {
					mbSession.setServiceStationDashboardMessage(servicestationVO.getServiceStationMsg());
				 }
				
				// Calling Account list enquiry to get eligible accounts and then send all of them for switch to estmt
				try{
					if(!emailUpdateFailed && req.getSwitchToEStmt()){
						Logger.info("resetInitialPwdSecNum isUpdateContactSuccessful is true:" , this.getClass());
						List<Account> custAccountList = customer.getAccounts();
						EStatementService eStatementService = (EStatementService) ServiceHelper.getBean("eStatementService");
						Logger.info("resetInitialPwdSecNum Going to call account eligibility list:" , this.getClass());
		                List<Account> eStmtEligibleAccountList = eStatementService.getAccountEligibilityList(ibankCommonData, customer); 
		                Logger.info("resetInitialPwdSecNum Going after calling account eligibility list:" , this.getClass());
		               //populateAccountListToSwitch(custAccountList,eStmtEligibleAccountList,accountListToSwitch);
		                accountListToSwitch=helper.getAcctListWithIndex(custAccountList, eStmtEligibleAccountList);
						 
						if(accountListToSwitch!= null && accountListToSwitch.size() > 0){
							Logger.info("resetInitialPwdSecNum going for switiching to estmt:" , this.getClass());
							eStatementService.switchPreferenceForAccountStatement(ibankCommonData,accountListToSwitch,customer,APPLICATION);
							Logger.info("resetInitialPwdSecNum after switiching to estmt:" , this.getClass());
						}
					}
				}
				catch (BusinessException e)
				{
					switchToEstmtFailed=true;
					Logger.error("Exception Inside auto init activation while switching to estmt 1::", e, this.getClass());
				}
				 catch (Exception e)
				{
					 switchToEstmtFailed=true;
					 Logger.error("Exception Inside auto init activation while switching to estmt 2::", e, this.getClass()); 
				}

				// GDW entry after reseting of sec number and password
				Statistic stat = new Statistic();
				stat.setAction(Statistic.AUTO_INIT_SET_SEC_NUM_PWD);
				stat.setGcisNumber(ibankCommonData.getUser().getGCISNumber());
				stat.setOriginBank(ibankCommonData.getOrigin());
				
				if( StringMethods.isEmptyString(ibankCommonData.getCustomer().getContactDetail().getEmail()) &&  !StringMethods.isEmptyString(req.getEmailAddress())){
				   Logger.info("Email is there going to check if update is correct:" , this.getClass());
				   if(!emailUpdateFailed && !switchToEstmtFailed && req.getSwitchToEStmt())
					{
						String statDesc="";
						populateStatLogAccountDesc(statDesc,accountListToSwitch);				
						stat.setDescription(ibankCommonData.getUser().getUserId()+" switched to estatements for accounts:"+statDesc);
					}
				}
				else
				{
					stat.setDescription(ibankCommonData.getUser().getUserId());
				}				
				stat.setIpAddress(ibankCommonData.getIpAddress());
				stat.setGDWOriginBank(ibankCommonData.getGdwOrigin());
				stat.setSessionId(ibankCommonData.getSessionId());
			    StatisticsService.logStatistic(stat); 
			    
			    // Audit Logging
			    helper.addCustomerAuditLog(ibankCommonData, Statistic.AUTO_INIT_SET_SEC_NUM_PWD_AUDIT_LOG, DAOConstants.AFTER_IMAGE, AUTO_INIT_AUDIT_LOG_DESC); 
				
				mbSession.setLoggedonState(LogonHelper.LOGGEDON_STATE_COMPLETE);			
				
				IMBResp serviceResponse = logonHelper.populateResponse(customer,user,unreadMsgCount, httpServletRequest , httpServletResponse, false,servicestationVO,autoApplyRetentionInfo);

				boolean hasSecureCodeConstraints = hasSecureCodeConstraints(customer);
				SafiLogonInfo safiLogonInfo = mbSession.getSafiLogonInfo();
				String safiAction = safiLogonInfo != null ? safiLogonInfo.getSafiAction():null;
				
				if(!StringMethods.isEmptyString(safiAction) && safiAction.equalsIgnoreCase(SafiConstants.SAFI_ACTION_CHALLENGE) && !hasSecureCodeConstraints){
					Logger.info("SAFI : AutoInitPwdSecNumController:autoInitPwdSecNumSetUp(): Setting LoggedOnState - SafiChallenge: SafiAction: "+safiAction+" GCISNumber : "+customer.getGcis(), this.getClass());
					((LogonResp) serviceResponse).setCustomer(null);
					((LogonResp) serviceResponse).setFirstName(customer.getFirstName());
					((LogonResp) serviceResponse).setShowSafiChallenge(true);
					((LogonResp) serviceResponse).setContactInfo(logonHelper.populateContact(customer.getContactDetail()));
					((LogonResp) serviceResponse).setSecureCodeInfo(logonHelper.populateSecureCodeInfo(customer));
					mbSession.setLoggedonState(LogonHelper.LOGGEDON_STATE_SAFI_CHALLENGE);

				}else{
					//Populate the ghost tile Response
					if(customer.getPreference() != null){
						
						//20E2-CSH -SBGEXP-8227 - added condition to check CSH/Efinance/Homeloan combination
						int cshIndicator = LoanAppUtil.getCSHTileIndicator(customer.getPreference().getCcPLLoanInd());
						
						if(customer.getPreference().getCcPLLoanInd() == LoanAppConstants.PRF_CCLOANIND_EFINANCE || customer.getPreference().getCcPLLoanInd() == LoanAppConstants.PRF_CCLOANIND_EFINANCE_HOMELOAN_BOTH
								|| cshIndicator == LoanAppConstants.PRF_CCLOANIND_EFINANCE
								|| cshIndicator == LoanAppConstants.PRF_CCLOANIND_EFINANCE_HOMELOAN_BOTH){						
							LoanApplicationDetail loanAppDetail = logonHelper.populateLoanApplicationDetail(ibankCommonData,serviceResponse);
							mbSession.setLoanApplicationDetail(loanAppDetail);
						}
						
						//20E2-CSH -SBGEXP-8227 - populate the details for CSH tile
						if(cshIndicator == LoanAppConstants.PRF_CCLOANIND_CSH ||
								cshIndicator == LoanAppConstants.PRF_CCLOANIND_EFINANCE ||	
								cshIndicator == LoanAppConstants.PRF_CCLOANIND_HOMELOAN ||
								cshIndicator == LoanAppConstants.PRF_CCLOANIND_EFINANCE_HOMELOAN_BOTH) {
							Logger.debug("CSH : Populate CSH Tile. ", getClass());
							logonHelper.populateCSHApplicationDetail(ibankCommonData,serviceResponse);						 
						}
						
						//20E2-CSH -SBGEXP-8227 - added condition to check CSH/Efinance/Homeloan combination
						if(customer.getPreference().getCcPLLoanInd() == LoanAppConstants.PRF_CCLOANIND_HOMELOAN || customer.getPreference().getCcPLLoanInd() == LoanAppConstants.PRF_CCLOANIND_EFINANCE_HOMELOAN_BOTH
								|| cshIndicator == LoanAppConstants.PRF_CCLOANIND_HOMELOAN
								|| cshIndicator == LoanAppConstants.PRF_CCLOANIND_EFINANCE_HOMELOAN_BOTH){
							logonHelper.populateHomeLoanGhostTile(ibankCommonData, serviceResponse);
						}
					}


					//				Populate the SplashPage Response
					Logger.debug("Before populate splashPageInfo", this.getClass());

					if(splashPageInfo != null && splashPageInfo.size() > 0 && splashPageInfo.get(0) != null){
						//populateSplashPage(splashPageInfo, mbSession.getOrigin(), customer, ibankCommonData, serviceResponse);					
						populateSplashPageResult=populateSplashPage(splashPageInfo, mbSession.getOrigin(), customer, ibankCommonData, serviceResponse);
						if(null!= populateSplashPageResult){
							boolean crsSplash = (boolean) populateSplashPageResult.get(0);
							Logger.debug("After populateSplashPage : crsSlpash :"+crsSplash , this.getClass());
							if(crsSplash){
								if(populateSplashPageResult.size() > 1){
									mbSession.setCrsRegistrationNumber((String)populateSplashPageResult.get(1));
									Logger.debug("In AutoInitPwdSecNumController :: CRS Flag "+(String)populateSplashPageResult.get(1), this.getClass());
								}

								if(isCrsHardPrompt3(splashPageInfo)){
									Logger.debug("This is hard prompt three ..Setting logged on state..", this.getClass());
									mbSession.setLoggedonState(LogonHelper.LOGGEDON_STATE_CRS_HARD_PROMPT);
								}
							}
						}
					}
				}
				RespHeader headerResp = populateResponseHeader(req.getHeader().getServiceName(), mbSession);
				serviceResponse.setHeader(headerResp);
				Logger.info("Auto Init JSON Response :" + mapper.writeValueAsString(serviceResponse), this.getClass());
				return serviceResponse;				
			}
			else{
				throw new BusinessException(BusinessException.SYSTEM_UNAVILABLE);
			}
		} catch (BusinessException e)
		{
			Logger.error("Exception Inside resetInitialPwdSecNum for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			IMBResp resp1 = MBAppUtils.createErrorResp(mbSession.getOrigin() , e, MBAppConstants.REGISTER_CHANGESECNUMPASSWORD_RESP_NAME, httpServletRequest);
			return resp1;
		} catch (Exception e)
		{
			Logger.error("Exception Inside reset pwd secnum for Customer GCIS: ["+ ((mbSession!=null && mbSession.getCustomer()!=null)? mbSession.getCustomer().getGcis() : "") + "] :", e, this.getClass());
			BusinessException exp = new BusinessException(BusinessException.SMPL_SYS_ERROR);
			IMBResp resp1 = MBAppUtils.createErrorResp(mbSession.getOrigin(), exp, MBAppConstants.REGISTER_CHANGESECNUMPASSWORD_RESP_NAME, httpServletRequest);
			return resp1;
		} finally
		{
			perfLogger.endLog(logName);
			perfLogger.endAllLogs();
		}
	}

	//Populate the SplashPage Response
	public List populateSplashPage(/*List<Object>*/List<MessageSearch>  splashPageInfo, String origin, Customer customer, IBankCommonData ibankCommonData, IMBResp serviceResponse) throws au.com.stgeorge.framework.common.exception.ResourceException, BusinessException{
		Logger.debug("Inside populateSplashPage, GCIS: "+customer.getGcis(), this.getClass());
		SplashPageResp splashPageResp = null;
		MessageSearch messageSearch = (MessageSearch)splashPageInfo.get(0);
		CRSInfo crsInfo = null;
		boolean showSplash=false;
		List populateSplashPageResult = null;
		boolean showHardPrompt3=false;
		
		//switch check for CRS Hard prompt
		if(!IBankParams.isSwitchOn(IBankParams.CRS_PRODUCT_READY_SWITCH) ){
			Logger.debug("CRS Hard Prompt Switch is OFF :: Kindly do not populate splash resp", this.getClass());
					
		}else{
			if(MessageSearch.messageActionCRSList.contains(messageSearch.getMessageAction())){
				populateSplashPageResult = new ArrayList();
				//				Call 258
				try{				
					Logger.debug("populateSplashPage CRS Update  ",  this.getClass());
					//crsInfo = crsService.getCrsInfo(ibankCommonData);		
					CustomerMessage customerMessage = new CustomerMessage();
					customerMessage.setId(messageSearch.getCustMsgID());
					customerMessage.setMsgID(messageSearch.getMsgID());
					customerMessage.setModifiedBy(ibankCommonData.getCustomer().getGcis());
					customerMessage.setAppField1(messageSearch.getAppField1());
					customerMessage.setGcisNumber(ibankCommonData.getCustomer().getGcis());
					customerMessage.setExpiryDate(messageSearch.getCustMessageExpiry());
					Logger.debug("258 response & crsInfo  : "+crsInfo, this.getClass());
					if(crsInfo != null && !"X".equalsIgnoreCase(crsInfo.getRegistrationNumber())){
						Logger.debug("Inside populateSplashPage : ",this.getClass());
						crsService.updateMsgDeleteStatus(messageSearch,ibankCommonData);
					}
					if(MessageCentreConstants.SPLASH_ACTION_CRS_HARD_PROMPT_3.equalsIgnoreCase(messageSearch.getMessageAction())){
						Logger.debug("Hard prompt 3",this.getClass());
						showHardPrompt3 = true;
						if(messageSearch.getXrefId() == null){
							Logger.debug("Inside XrefID NULL::>>", this.getClass());
							crsService.updateCRSPromptDetails(ibankCommonData, customerMessage, messageSearch.getMessageAction());
							showSplash=true;
							((LogonResp) serviceResponse).setCustomer(null);
							((LogonResp) serviceResponse).setFirstName(customer.getFirstName());
						}
					}
					else{

						if(MessageCentreConstants.SPLASH_ACTION_CRS_HARD_PROMPT_3.equalsIgnoreCase(messageSearch.getMessageAction())){
							Logger.debug("Hard prompt 3",this.getClass());
							showHardPrompt3 = true;
							if(messageSearch.getXrefId() == null){
								Logger.debug("Inside XrefID NULL::>>", this.getClass());
								crsService.updateCRSPromptDetails(ibankCommonData, customerMessage, messageSearch.getMessageAction());
								showSplash=true;
								((LogonResp) serviceResponse).setCustomer(null);
								((LogonResp) serviceResponse).setFirstName(customer.getFirstName());
							}
						}
						else{
							Logger.debug("HP2 or Hp1", this.getClass());
							splashPageResp = new SplashPageResp();
							String hardPromptType = getHardPrompt(messageSearch.getMessageAction());
							splashPageResp.setSplashType(CRS_SPLASH_TYPE); // TODO Remove Hardcode
							splashPageResp.setPromptType(hardPromptType);
							/*if(MessageCentreConstants.SPLASH_ACTION_CRS_HARD_PROMPT_1.equalsIgnoreCase(messageSearch.getMessageAction())){
								Logger.debug("Inside HP1",  this.getClass());
								if(messageSearch.getCustMessageExpiry() != null){
									splashPageResp.setExpiryDate(logonHelper.convertExpiryDateForCRSPrompt(messageSearch.getCustMessageExpiry()));
								}else{
									splashPageResp.setExpiryDate(logonHelper.getExpiryDateForCRSPrompt(messageSearch.getAppField1()!=null?Integer.valueOf(messageSearch.getAppField1()).intValue():0));
						    	}					}else{
								Logger.debug("Inside HP2 or HP3",  this.getClass());
								splashPageResp.setExpiryDate(logonHelper.convertExpiryDateForCRSPrompt(messageSearch.getCustMessageExpiry()));
							}*/
							Date expiryDate = customerMessage.getExpiryDate();
							Logger.debug("ExpiryDate in customer message is "+expiryDate,getClass());
							Logger.debug("XrefID::>>"+messageSearch.getXrefId(), this.getClass());
							if(messageSearch.getXrefId() == null){
								Logger.debug("Inside XrefID NULL::>>", this.getClass());
								splashPageResp.setShowCRSAsTile(false);
								expiryDate = crsService.updateCRSPromptDetails(ibankCommonData, customerMessage, messageSearch.getMessageAction());
								showSplash=true;
							}
							else{
								Logger.debug("Inside XrefID NOT NULL::>>", this.getClass());
								splashPageResp.setShowCRSAsTile(true);
							}
							Logger.debug("Inside HP2 or HP3",  this.getClass());
							splashPageResp.setExpiryDate(logonHelper.convertExpiryDateForCRSPrompt(expiryDate));
							
						}
															

					}
				} catch(BusinessException e){
					Logger.warn("Business Exception:" + e.getKey() + " Mesage : "+ e.getMessage(), e, this.getClass());
					//saveError(getServletRequest(), e.getKey());		
					splashPageResp = null;		
				}						
				if(serviceResponse != null && serviceResponse instanceof LogonResp){				
					if(null!=customer){
						Logger.debug("Setting customer type ::"+customer.getCustTypeInd(), this.getClass());
						((LogonResp) serviceResponse).setCustTypeInd(customer.getCustTypeInd());
					}
					if(((LogonResp) serviceResponse).getCustomer() != null && null!= splashPageResp){
						Logger.debug("Setting the SplashPageResp in LogonResp", this.getClass());
						((LogonResp) serviceResponse).getCustomer().setSplashPage(splashPageResp);
						
					}else if(null == splashPageResp && showHardPrompt3){
						Logger.debug("Setting showHardPrompt as true b'cuz its HP3", this.getClass());
						((LogonResp) serviceResponse).setShowHardPrompt(showHardPrompt3);
					}
				}
			}
			populateSplashPageResult.add(showSplash);
			if(null!= crsInfo){
				populateSplashPageResult.add(crsInfo.getRegistrationNumber());
				Logger.debug("In populateSplashPage :: flag value ::"+crsInfo.getRegistrationNumber(), this.getClass());
			}
		}
				
		return populateSplashPageResult;
	}
	
	private String getHardPrompt(String msgActionType ){		
		String hardPromptType =  "";
		switch(msgActionType){
		case "C1":
			hardPromptType = "H1";		   
			return hardPromptType;
		case "C2":
			hardPromptType = "H2";	
			return hardPromptType;
		case "C3":
			hardPromptType = "H3";	
			return hardPromptType;
		default:
			return hardPromptType;
		}
	}

	public ErrorResp validate(IMBReq serviceRequest, HttpServletRequest request) {
		ErrorResp errorResp = mbAppValidator.validate(serviceRequest, request);
		if ( errorResp.getErrors()!= null && errorResp.getErrors().size() > 1 )
		{
			ArrayList<ErrorInfo> errors = new ArrayList<ErrorInfo>();
			errors.add(errorResp.getErrors().get(0));
			errorResp.setErrors(errors);
		}
		return errorResp;
	}
	
	public RespHeader populateResponseHeader(String serviceName, MobileSession mobSession )
	{
		return mbAppHelper.populateAsyncResponseHeader(serviceName, mobSession);
	}
	
//	private int processMsgCentre(String origin, String gcisNum) throws BusinessException, ResourceException{
//		
//		int unreadMsgCount = -1;
//		
//		if (HeartBeat.isApplicationAvailable(HeartBeat.MSGCENTRE_APPLICATION_ID)) {
//			
//			if ( msgCntrService == null ){
//				msgCntrService = (MobileMsgCntrService) ServiceHelper.getBean("msgCntrService");
//			}
//			
//			OriginsVO originVO= IBankParams.getOrigin(origin);
//			msgCntrService.addBrandCustMsg(originVO.getBankName(),gcisNum);
//			unreadMsgCount = msgCntrService.findMobCustMsgUnreadCount(gcisNum);				
//		}
//		
//		return unreadMsgCount;
//	}
	
	//Create new branded messages for customer & return an unread count
	private MsgCentreInfo/*List<Object> */processMsgCentre(String origin, String gcisNum,boolean isECorrespondenceSupported) throws BusinessException, ResourceException{
			OriginsVO originVO= IBankParams.getOrigin(origin);
			msgCntrService.addBrandCustMsg(originVO.getBankName(),gcisNum);
			return msgCntrService.getCustomerMessageInfo(gcisNum,isECorrespondenceSupported, origin);				
		
	}

	
	private ServiceStationVO populateServiceMessage(long insertionPoint,String channel, IBankCommonData commonData)
	{
		ServiceStationVO serviceStationAdminVo=null;
		try
		{
		 serviceStationAdminVo= serviceStationService.getServiceMessage(insertionPoint, ServiceStationImpl.CHANNEL_MOBILE, commonData);			
		}
		 catch(BusinessException ex){
			Logger.error("An error occurred while getting service station message for mobile accoutn details", ex, this.getClass());
		}
		return serviceStationAdminVo;
	}
	
	private void populateStatLogAccountDesc(String accountStatusDesc, List<Account> eligibleAccountList){		
		if(null!= accountStatusDesc ){
			for(Account eligibleAccount : eligibleAccountList){
				if(accountStatusDesc.equalsIgnoreCase("")){
					if(null!=eligibleAccount.getAccountId()){
						accountStatusDesc = accountStatusDesc +eligibleAccount.getAccountId().getAccountNumber();
					}	
				}
				else
					accountStatusDesc = accountStatusDesc + ","+eligibleAccount.getAccountId().getAccountNumber();
				
			}
		}
		
	}
    private String getCustomerNumber(IBankCommonData commondata){
        String customerNumber =commondata.getCustomer().getGcis();
        if(commondata.getCustomer().isGHSCustomer() || "GHS".equalsIgnoreCase(commondata.getCustomer().getPrimaryProfile())){
              customerNumber = commondata.getCustomer().getGHSCISNumber();
        }else if(commondata.getCustomer().isCHSCustomer() || "CHS".equalsIgnoreCase(commondata.getCustomer().getPrimaryProfile())){
              customerNumber = commondata.getCustomer().getCHSCISNumber();
        }
        return customerNumber;
  }
    
    public boolean isCrsHardPrompt3(List<MessageSearch> splashPageInfo){
		Logger.debug("Inside isCrsHardPrompt3", this.getClass());
		boolean isCrsHardPrompt3=false;
		if(splashPageInfo.size() > 0){
			
			MessageSearch messageSearch = (MessageSearch)splashPageInfo.get(0);			
			if(MessageCentreConstants.SPLASH_ACTION_CRS_HARD_PROMPT_3.equalsIgnoreCase(messageSearch.getMessageAction())){
				isCrsHardPrompt3 = true;
			}			
		}
		
		return isCrsHardPrompt3;
	}
    
private boolean hasSecureCodeConstraints(Customer customer) {
		
		boolean resp = false;
		
		try{
			if(IBankParams.isGlobalByPass()){
				resp = true;
			}else if (IBankSecureService.isCustomerExempt(customer.getIBankSecureDetails())){
				resp = true;
			}
		}catch (Exception e){
			resp = false;
			Logger.error("Error Logon hasSecureCodeConstraints: " + customer.getGcis(), this.getClass());			
		}
		
		return resp;
	}
}
