package au.com.stgeorge.mbank.controller;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import org.springframework.beans.factory.annotation.Autowired;
import au.com.stgeorge.framework.common.configuration.Configuration;
import au.com.stgeorge.framework.common.configuration.Configurator;
import au.com.stgeorge.framework.common.exception.DAOException;
import au.com.stgeorge.framework.common.exception.DataAccessException;
import au.com.stgeorge.framework.common.logging.Logger;
import au.com.stgeorge.framework.common.util.StringMethods;
import au.com.stgeorge.framework.database.DAOFactory;
import au.com.stgeorge.framework.database.IDAO;
import au.com.stgeorge.ibank.businessobject.BusinessException;
import au.com.stgeorge.ibank.businessobject.ResourceException;
import au.com.stgeorge.ibank.common.cache.IBankParams;
import au.com.stgeorge.ibank.common.cache.IBankRefershParams;
import au.com.stgeorge.ibank.session.SessionDAO;
import au.com.stgeorge.ibank.session.valueobject.SessionVO;

public class ReturnFromExternalAppHelper {
	
	@Autowired
	private IBankRefershParams ibankRefreshParams;
	
	public static String SESSION_COOKIE_NAME_MB = "MBWebSrv";
	private static final String CONFIGURATION_FILE_NAME = "DBSessionService.properties";
	private static final String DAO_MAPPING_PROPERTY_FILE = "SessionDAOMapping.properties";
	private static final String CONFIGURATION_EXPIRY_TIME = "ExpiryTime";
	private static final String SESSION_DAO = "SessionDAO";
	private static final String LAST_ACCESS_TIME = "LastAccessedTime";
	public final static String DEFAULT_CONFIGURATION = "DBSessionService.properties";
	public static final String REDIRECT_TO_EXTERNAL_APP = "RedirectToExternalApp";
    public static final String EXTEND_MOBILE_SESSION = "ExtendMobileSession";
    public static final String CUSTOMER_SESSION_ATTR = "Customer";	
    private static Configuration configuration;
    private static final String DATA_NOT_FOUND = "Data not found in Database";
	
	/**
	 * This method is used to validate the session, whether it is alive or not
	 * Add extra time to the last accessed time and compare with current time 
	 * @param sessionId
	 * @throws BusinessException
	 */
	public void validateSession(String sessionId) throws BusinessException
	{
		IDAO idao = getIDAO(SESSION_DAO, sessionId);
		SessionVO sessVO = fetchSessionFromDatabase(sessionId, idao);
		HashMap hash = deserializeSessionObj(sessVO);
		if(hash.get(REDIRECT_TO_EXTERNAL_APP)!=null){
			String redirectSessionVal = (String)hash.get(REDIRECT_TO_EXTERNAL_APP);
			if(!StringMethods.isEmptyString(redirectSessionVal) && IBankParams.COMPASS_TO_ACE.equals(redirectSessionVal)){
				validateSessionExpiryTime(sessionId, idao, sessVO, hash);
			}else{
				deleteSession(sessionId, idao, sessVO);
				throw new BusinessException(BusinessException.SYSTEM_UNAVILABLE, " Invalid Session " + sessionId);
			}
		}else{
			deleteSession(sessionId, idao, sessVO);
			throw new BusinessException(BusinessException.SYSTEM_UNAVILABLE, " Invalid Session " + sessionId);
		}
	}
	
	/**
	 * @param sessionId
	 * @param idao
	 * @param sessVO
	 * @param hash
	 * @throws BusinessException
	 */
	private void validateSessionExpiryTime(String sessionId, IDAO idao, SessionVO sessVO, HashMap hash) throws BusinessException {
		Calendar lastAccessedTime = getLastAccessedTime(sessVO);
		Calendar currentTime = getCurrentTime();
		int extraTimeInSeconds = 0;
		if(hash.get(EXTEND_MOBILE_SESSION)!=null){
			String extendMobileSessionVal = (String)hash.get(EXTEND_MOBILE_SESSION);
			if(!StringMethods.isEmptyString(extendMobileSessionVal) && IBankParams.YES.equals(extendMobileSessionVal)){
				extraTimeInSeconds = ibankRefreshParams.getExtraSessionTimeInSeconds();
			}
		}
		lastAccessedTime.add(Calendar.SECOND, getExpiryTime()+extraTimeInSeconds);
		if (lastAccessedTime.getTimeInMillis() < currentTime.getTimeInMillis()){
			// Session Expired. Delete the session from database and throw Exception
			deleteSession(sessionId, idao, sessVO);
			throw new BusinessException(BusinessException.SYSTEM_UNAVILABLE, " Session Expired " + sessionId);
		}
		updateSessionLastAccessedDate(sessionId, new Date());
	}

	/**
	 * Method to get current timestamp
	 * @return
	 */
	private Calendar getCurrentTime() {
		Calendar calendar = Calendar.getInstance();
		Date curentTime  = new Date();
		calendar.setTime(curentTime);
		return calendar;
	}

	/**
	 * Method to get last accessed time from session obj
	 * @param sessVO
	 * @return
	 */
	private Calendar getLastAccessedTime(SessionVO sessVO) {
		Date lastAccess = sessVO.getLastAccessed();
		Calendar calendarExp = Calendar.getInstance();
		calendarExp.setTime(lastAccess);
		return calendarExp;
	}

	/**
	 * Method to deserialize session object
	 * @param sessVO
	 * @return
	 */
	private HashMap deserializeSessionObj(SessionVO sessVO) {
		HashMap hash = (HashMap)sessVO.getItem();
		return hash;
	}

	/**
	 * Method to get the session obj from database
	 * @param sessionId
	 * @param idao
	 * @return
	 */
	private SessionVO fetchSessionFromDatabase(String sessionId, IDAO idao) {
		SessionVO sessVO = new SessionVO();
		sessVO.setKey(sessionId);
		try {
			sessVO = (SessionVO) idao.find(sessVO);
		} catch (DataAccessException e) {
			Logger.error("getSessionAttribute() failed for Session Id:"+ sessionId, e, this.getClass());
			throw new ResourceException(ResourceException.SYSTEM_ERROR, e);
		} catch (DAOException e) {
			Logger.debug("getSessionAttribute() failed for Session Id:"+ sessionId, this.getClass());
			throw new IllegalStateException(DATA_NOT_FOUND);
		}
		return sessVO;
	}

	/**
	 * Method to delete session from database
	 * @param sessionId
	 * @param idao
	 * @param sessVO
	 * @throws BusinessException
	 */
	private void deleteSession(String sessionId, IDAO idao, SessionVO sessVO) throws BusinessException {
		//Session Invalid Throw error
		//Delete Session
		try {
			idao.delete(sessVO);
			throw new BusinessException(BusinessException.SYSTEM_UNAVILABLE, " Session already Expired " + sessionId);
		} catch (Exception e) {
			Logger.info("Session expired " + sessionId,this.getClass());
			throw new BusinessException(BusinessException.SYSTEM_UNAVILABLE, " Session already Expired " + sessionId);
		}
	}

	/**
	 * Method to get DAO object
	 * @param daoName
	 * @param sessionId
	 * @return
	 */
	private IDAO getIDAO(String daoName, String sessionId) {
		IDAO idao = null;
		Logger.debug("DatabaseSessionImp - getIDAO - START", this.getClass());
		try {
			idao = DAOFactory.getDAO(daoName, DAO_MAPPING_PROPERTY_FILE);
			if (idao instanceof SessionDAO) {
				Logger.info("DatabaseSessionImp - getIDAO - setting normal configuration - it is SessionDAO",this.getClass());
				SessionDAO sessionDao = (SessionDAO) idao;
				sessionDao.setConfigurationFileName(DEFAULT_CONFIGURATION);
				return sessionDao;
			}
			return idao;
		} catch (Exception e) {
			Logger.error("getIDAO() Failed for Session Id : " + sessionId, e, this.getClass());
			throw new ResourceException(ResourceException.DB_CONNECTION_ERROR, e);
		}
	}
	
	/**
	 * Method to update last accessed date in database
	 * @param sessionId
	 * @param date
	 */
	public void updateSessionLastAccessedDate(String sessionId, Date date)
	{
		Logger.debug("Inside updateSessionLastAccessedDate(), sessionId:" + sessionId  , this.getClass());
		IDAO idao = getIDAO(SESSION_DAO, sessionId);
		SessionVO sessVO = new SessionVO();
		sessVO.setKey(sessionId);
		try{
	      sessVO = (SessionVO) idao.find(sessVO);
	      
	      HashMap dataHashMap = deserializeSessionObj(sessVO);
	      dataHashMap.put(LAST_ACCESS_TIME, date);
	      
	      sessVO.setItem(objectToByteArray(dataHashMap));
	      sessVO.setLastAccessed(date);
	      idao.update(sessVO);
		}
        catch (Exception e){
        	Logger.info("Error Updating Session, sessionId:" + sessionId  , this.getClass());
        }
	}

	/**
	 * Method to convert object into byteArray
	 * @param object
	 * @return
	 * @throws IOException
	 */
	private byte[] objectToByteArray(Object object) throws IOException {
		ByteArrayOutputStream byteOutputStream = new ByteArrayOutputStream();
		ObjectOutputStream objectOutputStream = new ObjectOutputStream(
				byteOutputStream);
		objectOutputStream.writeObject(object);
		objectOutputStream.flush();
		objectOutputStream.close();
		return byteOutputStream.toByteArray();
	}

	/**
	 * This method is used to read the default expiry time of session from properties file
	 * @return expiryTime
	 */
	private int getExpiryTime()
	  {
	    int configExpTime = 0;
	    try{
	      configuration = getConfiguration();
	      configExpTime = Integer.parseInt(configuration.getConfig(CONFIGURATION_EXPIRY_TIME));
	      return configExpTime;
	    }
	    catch (Exception e){
	      return configExpTime;
	    }
	  }
	
	/**
	 * This method is used to get the configuration 
	 * @return configuration
	 */
	private static Configuration getConfiguration()
	  {
	    if (configuration == null)
	    {
	      configuration = Configurator.getConfiguration(CONFIGURATION_FILE_NAME);
	    }
	    return configuration;
	  }
	
	
}
