package au.com.stgeorge.mbank.controller.payments;

import java.math.BigDecimal;
import java.util.List;

import org.springframework.stereotype.Service;

import au.com.stgeorge.framework.common.logging.Logger;
import au.com.stgeorge.ibank.businessobject.BPayService;
import au.com.stgeorge.ibank.businessobject.BusinessException;
import au.com.stgeorge.ibank.businessobject.CustomerService;
import au.com.stgeorge.ibank.businessobject.PaymentService;
import au.com.stgeorge.ibank.businessobject.ResourceException;
import au.com.stgeorge.ibank.common.cache.IBankParams;
import au.com.stgeorge.ibank.servicestation.util.ServicetationConstants;
import au.com.stgeorge.ibank.valueobject.Account;
import au.com.stgeorge.ibank.valueobject.BPayPayment;
import au.com.stgeorge.ibank.valueobject.Biller;
import au.com.stgeorge.ibank.valueobject.BillerMaster;
import au.com.stgeorge.ibank.valueobject.Customer;
import au.com.stgeorge.ibank.valueobject.database.CodesVO;
import au.com.stgeorge.ibank.valueobject.transfer.IBankCommonData;
import au.com.stgeorge.mbank.model.common.IMBResp;
import au.com.stgeorge.mbank.model.common.RespHeader;
import au.com.stgeorge.mbank.model.request.payments.AddBillerReq;
import au.com.stgeorge.mbank.model.request.payments.BPayTransferReq;
import au.com.stgeorge.mbank.model.response.payments.AddBillerResp;
import au.com.stgeorge.mbank.model.response.payments.BillerDetailResp;
import au.com.stgeorge.mbank.model.response.payments.BillerInfoResp;
import au.com.stgeorge.mbank.model.response.payments.DeleteBillerResp;
import au.com.stgeorge.mbank.util.MBAppHelper;
import au.com.stgeorge.mbank.util.ServiceConstants;
import au.com.stgeorge.mobilebank.businessobject.impl.MobileBankServiceImpl;
import au.com.stgeorge.security.util.StringMethods;

/**
 * BPay Transfer Controller Helper
 * 
 * @author C38854
 * 
 */
@Service
public class BPayHelper extends TransferHelper {

	private static final String VARIABLE_CRN_DESC = "Varies bill to bill";

	/**
	 * Populate Payment bean for transfer
	 * 
	 * @param customer
	 * @param commonData
	 * @param request
	 * @param ip
	 * @param sessionId
	 * @return
	 * @throws BusinessException
	 */
	protected BPayPayment populatePayment(Account fromAccount, Customer customer, IBankCommonData commonData, BPayTransferReq request, Biller biller,
			int variableCRN) throws BusinessException {
		BPayPayment bpayPayment = new BPayPayment();
		String modifiedCRN = request.getCustRefNum().replaceAll(" *", "");
		bpayPayment.setReferenceNumber(modifiedCRN);		
		bpayPayment.setPayerName(request.getPayerName());
		if(bpayPayment.getPayerName() ==null){
			bpayPayment.setPayerName("");
		}
		bpayPayment.setDescription(ServiceConstants.BPAY_PAYMENT_DESCRIPTION);
		bpayPayment.setAmount(new BigDecimal(request.getAmt()));
		bpayPayment.setEbpBill(false);
		bpayPayment.setNewBiller(false);
		bpayPayment.setBatch(false);
		bpayPayment.setCheckForDuplicate(true);
		if (request.getOverrideDup() != null)
			bpayPayment.setCheckForDuplicate(!request.getOverrideDup());
		if (request.getDupCount() != null)
			bpayPayment.setDuplicatePaymentCount(request.getDupCount());
		bpayPayment.setCommonData(commonData);
		Biller paymentBiller = new Biller();
		paymentBiller.setCode(biller.getCode());
		paymentBiller.setLastReferenceNumber(modifiedCRN);
		paymentBiller.setSavedBillerStatus(ServiceConstants.ALREADY_SAVED_BILLER);
		paymentBiller.setPayerName(request.getPayerName());
		paymentBiller.setBillerAlias(biller.getBillerAlias());
		paymentBiller.setVariableCRN(variableCRN);
		paymentBiller.setId(biller.getId());
		bpayPayment.setToBiller(paymentBiller);
		bpayPayment.setFromAccount(fromAccount.getAccountId());
		bpayPayment.setIpAddress(commonData.getIpAddress());
		bpayPayment.setSessionId(commonData.getSessionId());
		bpayPayment.setBrand(commonData.getOrigin());

		if ((request.getScheduleID() !=null && !"".equals(request.getScheduleID())) || request.getScheduleDetail() != null){
			bpayPayment.setSchedule(true);
			bpayPayment.setScheduleDetails(populateScheduleDetails(request.getScheduleID(), commonData, request.getScheduleDetail(), request.getSendEmail(), request.getPayerName()));
		} else {
			bpayPayment.setSchedule(false);
		}
		
		if (request.getFavTranID()!=null) bpayPayment.setFavTranId(request.getFavTranID());
		
		bpayPayment.setOrigination(request.getOrigination());
		
		return bpayPayment;
	}

	/**
	 * Additional validation for add biller request
	 * 
	 * @param billerBean
	 * @throws BusinessException
	 */
	protected void validateBillerReq(AddBillerReq billerReq, List<Biller> customerBillers, IBankCommonData commonData) throws BusinessException {

		// if (!StringMethods.isValidString(billerReq.getBillerAlias())) {
		// throw new BusinessException(BusinessException.BPAY_INVALID_);
		// }

		BillerMaster details = BPayService.getBillerDetails(billerReq.getBillerCode());
		if (details == null) {
			throw new BusinessException(BusinessException.BPAY_INVALID_BIILER_CODE);
		}
		String modifiedCRN = "";
		if (billerReq.getCrn() != null) {
			modifiedCRN = billerReq.getCrn().replaceAll(" *", "");
		}
		// do not add the last ref number for variable CRN
		// irrespective of whether
		// it is entered by user
		// 0 - fixed CRN
		// 1 - variable CRN
		// 8R2 Treat variable and Fixed CNR in the same manner
		// if (details.getVariableCRN() == 0) {
		// remove embedded spaces in CRN
		// fixing defect 55
		if (modifiedCRN.length() > ServiceConstants.MAX_CRN_LENGTH) {
			throw new BusinessException(BusinessException.BPAY_INVALID_CRN);
		}

		Biller biller = new Biller();
		biller.setCode(billerReq.getBillerCode());
		if (IBankParams.isICRNBpaySwitchON() && details.getVariableCRN() == 1) {
//			if (!StringMethods.isEmptyString(modifiedCRN)) {
//				throw new BusinessException(BusinessException.ICRN_CUST_REF_NOT_REQD);
//			}
			if (BPayService.checkBPayBillerExists(commonData, biller) != null) {
				throw new BusinessException(BusinessException.BP_BILLER_EXISTS);
			}
		} else {

			if (StringMethods.isEmptyString(modifiedCRN)) {
				throw new BusinessException(BusinessException.BPAY_NO_REFERENCE_NUMBER);
			}

			biller.setLastReferenceNumber(modifiedCRN);
			PaymentService.verifyBPayCRN(biller, commonData);

		}
		// check if alias already exists for the customer
		if (BPayService.checkBPayBillerAliasExists(customerBillers, billerReq.getBillerAlias())) {
			throw new BusinessException(BusinessException.BP_BILLERALIAS_EXISTS);
		}

	}

	/**
	 * Populate biller
	 * 
	 * @param request
	 * @return
	 */
	protected Biller populateBiller(AddBillerReq request, String payerName) throws BusinessException {
		BillerMaster details = BPayService.getBillerDetails(request.getBillerCode());

		Biller myBiller = new Biller();
		myBiller.setSavedBillerStatus(ServiceConstants.NEWLY_SAVED_BILLER);
		myBiller.setCode(request.getBillerCode());
		myBiller.setLastReferenceNumber(request.getCrn());
		myBiller.setBillerAlias(request.getBillerAlias());
		myBiller.setPayerName(payerName);

		myBiller.setName(details.getDescription());

		String modifiedCRN = "";
		if (request.getCrn()!=null) {
			modifiedCRN = request.getCrn().replaceAll(" *", "");
		}
		myBiller.setLastReferenceNumber(modifiedCRN);
		myBiller.setVariableCRN(details.getVariableCRN());
		// check if CRN is fixed OR variable
		if (IBankParams.isICRNBpaySwitchON()) {
			if (details.getVariableCRN() == 1) {
				myBiller.setLastReferenceNumber(VARIABLE_CRN_DESC);
				myBiller.setLastReferenceNumber("");
			}
		}
		if (StringMethods.isValidString(request.getBillerAlias())) {
			myBiller.setBillerAlias(request.getBillerAlias());
		} else {
			myBiller.setBillerAlias(details.getDescription());
		}
		return myBiller;
	}

	/**
	 * Populate service response - add biller
	 * 
	 * @param header
	 * @param duplicates
	 * @return
	 */
	protected AddBillerResp populateAddBillerResp(RespHeader header, List<Biller> billerList, Biller newBiller) {
		AddBillerResp response = new AddBillerResp(header);
		int i = 0;
		response.setNewBillerIndex("");
		for (Biller biller : billerList) {
			//variable CRN -compare only the biller code
			if(biller.getVariableCRN() ==1 ){
				if (StringMethods.removeLeadingZero(newBiller.getCode().trim()).equals(StringMethods.removeLeadingZero(biller.getCode().trim()))
						&& newBiller.getName().trim().equals(biller.getName().trim())) {
					response.setNewBillerIndex(String.valueOf(i));
					break;
				}
			}
			else{
				if (StringMethods.removeLeadingZero(newBiller.getCode().trim()).equals(StringMethods.removeLeadingZero(biller.getCode().trim()))) {
					if(StringMethods.isValidString(newBiller.getLastReferenceNumber()) && StringMethods.isValidString(biller.getLastReferenceNumber())){
						if(newBiller.getLastReferenceNumber().trim().equalsIgnoreCase(biller.getLastReferenceNumber().trim())){
							response.setNewBillerIndex(String.valueOf(i));
							break;
						}
					}
				}
			}			
		
			i++;
		}
		response.setBillers(MBAppHelper.populateBillerList(billerList));
		Logger.debug("BPayHelper. Response populated: " + response, this.getClass());
		return response;
	}

	/**
	 * Additional validation for BPay Transfer request
	 * 
	 * @param request
	 * @param billerMaster
	 * @throws BusinessException
	 */
	protected void validateBPayTransferReq(BPayTransferReq request, BillerMaster billerMaster) throws BusinessException {
		if (billerMaster == null) {
			throw new BusinessException(BusinessException.BPAY_INVALID_BIILER_CODE);
		}
		if (request.getCustRefNum() == null) throw new BusinessException(BusinessException.BPAY_INVALID_CRN);
		String modifiedCRN = request.getCustRefNum().replaceAll(" *", "");
		if (modifiedCRN.length() > ServiceConstants.MAX_CRN_LENGTH) {
			throw new BusinessException(BusinessException.BPAY_INVALID_CRN);
		}

		if (request.getScheduleDetail() != null)
			validateTransferSchedule(request.getScheduleDetail());
		// update the bean with ref num stripped of spaces
		// request.setCustRefNum(modifiedCRN);
	}

	/**
	 * Populate get biller details response
	 * 
	 * @param header
	 * @param billerDetails
	 * @param biller
	 * @return
	 */
	protected IMBResp populateBillerDetailResponse(RespHeader header, BillerMaster billerDetails) {
		BillerDetailResp response = new BillerDetailResp(header);
		response.setBillerDetail(new BillerInfoResp());
		response.getBillerDetail().setBillerAlias(billerDetails.getDescription());
		response.getBillerDetail().setBillerCode(billerDetails.getBillerCode());
		response.getBillerDetail().setBillerName(billerDetails.getDescription());
		Logger.info("Response: " + response, this.getClass());
		return response;
	}

	/**
	 * Populate delete biller response
	 * 
	 * @param header
	 * @param billers
	 * @return
	 */
	protected IMBResp populateDeleteBillerResp(RespHeader header, List<Biller> billers) {
		DeleteBillerResp response = new DeleteBillerResp(header);
		response.setBillers(MBAppHelper.populateBillerList(billers));
		Logger.debug("BPayHelper. Response populated: " + response, this.getClass());
		return response;
	}
	public long getInsertionPointCode(String insertionPointString){
		List<CodesVO> CodesVOList = (List<CodesVO>) IBankParams.getCodesDataList(IBankParams.DEFAULT_ORIGIN, ServicetationConstants.CD_CATEGORY_SERVICETATION_INSERTION_PT);
		long insertionPointValue = 0;
		for(CodesVO codesVO : CodesVOList){
			if(codesVO.getMessage().trim().equalsIgnoreCase(insertionPointString)){
				if(StringMethods.isValidString(codesVO.getCode())){
					insertionPointValue = Long.parseLong(codesVO.getCode());
					break;
				}
			}
		}
		if(insertionPointValue == 0){
			Logger.warn("NO match found in RELEASECODES table for the insertion point "+insertionPointString, this.getClass());
		}
		return insertionPointValue;
	}

	public void populateBillerList(IBankCommonData commonData, Customer customer) throws ResourceException, BusinessException{
		List<Biller> myBillerList;
		
		if(customer.getBillers() == null || (customer.getBillers() != null && customer.getBillers().size() == 0)) {
			myBillerList = CustomerService.getBillerList(commonData, commonData.getUser().getGCISNumber());
			myBillerList = MobileBankServiceImpl.trimAccountList(myBillerList,MobileBankServiceImpl.MAX_BILLER_CODE);			
			customer.setBillers(myBillerList);
			if (myBillerList!=null && myBillerList.size()>0) {
				Logger.warn("populateBillerList: fallback to populate Billers size: " + myBillerList.size(), this.getClass());	
			}

		}
		
		
	}
}
