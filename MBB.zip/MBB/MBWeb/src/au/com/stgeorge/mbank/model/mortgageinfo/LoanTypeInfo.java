package au.com.stgeorge.mbank.model.mortgageinfo;

import java.io.Serializable;

import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.Range;

import au.com.stgeorge.ibank.businessobject.BusinessException;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_NULL)
public class LoanTypeInfo implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = -1830545851191029181L;

	private String loanType;
	private String productType;
	
	@Range(min=1, max=2, message = ""+BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE)
	private int numOfApplicants;
	
	private Boolean firstHomeBuyerInd;
	
	private String loanPurpose;//To live-in(OwnerOccupier) - O, Investment - I
	
	private String customerSituation;

	@Range(min=50000, max=99999900, message = ""+BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE)
	@Pattern(regexp="([0-9]+[.]?[0-9]?[0-9]?)",message = ""+BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE)
	private String custRequestedLoanAmt;
	
	private String applicationCompletionStage;	//Simulated

	@Range(min=0, max=9, message = ""+BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE)
	private int combinedNumDependants;	//3
	
	private String repaymentType;//Principle
	
	//@Range(min=5, max=35, message = ""+BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE)
	private String loanTerm;	//30
	
	@Range(min=1, max=5, message = ""+BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE)
	private String fixedLoanTerm;	//2
	
	@Range(min=1, max=10, message = ""+BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE)
	private String interestOnlyTerm;	//5
	
	private String repaymentFrequency;	//Monthly
	
	private Boolean calculateForMeInd;	//true
	
	@Range(min=1, max=999999999, message = ""+BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE)
	@Pattern(regexp="([0-9]+[.]?[0-9]?[0-9]?)",message = ""+BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE)
	private String depositAmount; 
	
	private Boolean shareAddressInd;	//true
	
	@Range(min=25000, max=99999900, message = ""+BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE)
	@Pattern(regexp="([0-9]+[.]?[0-9]?[0-9]?)",message = ""+BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE)
	private String loanAmt;
	
	@Range(min=0, max=999999999, message = ""+BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE)
	@Pattern(regexp="([0-9]+[.]?[0-9]?[0-9]?)",message = ""+BusinessException.DIGITAL_MORTGAGE_SVC_UNAVAILABLE)
	private String rentalIncome;
	
	private String rentalIncomeFrequency;
	
	private PropertyInfo purchaseProperty;

	private Boolean newPropertyInd;
	
	
	public String getRentalIncomeFrequency() {
		return rentalIncomeFrequency;
	}
	public void setRentalIncomeFrequency(String rentalIncomeFrequency) {
		this.rentalIncomeFrequency = rentalIncomeFrequency;
	}
	public String getRentalIncome() {
		return rentalIncome;
	}
	public void setRentalIncome(String rentalIncome) {
		this.rentalIncome = rentalIncome;
	}
	public String getLoanType() {
		return loanType;
	}
	public void setLoanType(String loanType) {
		this.loanType = loanType;
	}
	public String getProductType() {
		return productType;
	}
	public void setProductType(String productType) {
		this.productType = productType;
	}
	public int getNumOfApplicants() {
		return numOfApplicants;
	}
	public void setNumOfApplicants(int numbOfApplicants) {
		this.numOfApplicants = numbOfApplicants;
	}
	public String getLoanPurpose() {
		return loanPurpose;
	}
	public void setLoanPurpose(String loanPurpose) {
		this.loanPurpose = loanPurpose;
	}
	public String getCustomerSituation() {
		return customerSituation;
	}
	public void setCustomerSituation(String customerSituation) {
		this.customerSituation = customerSituation;
	}
	public String getCustRequestedLoanAmt() {
		return custRequestedLoanAmt;
	}
	public void setCustRequestedLoanAmt(String custRequestedLoanAmt) {
		this.custRequestedLoanAmt = custRequestedLoanAmt;
	}
	public String getApplicationCompletionStage() {
		return applicationCompletionStage;
	}
	public void setApplicationCompletionStage(String applicationCompletionStage) {
		this.applicationCompletionStage = applicationCompletionStage;
	}
	public int getCombinedNumDependants() {
		return combinedNumDependants;
	}
	public void setCombinedNumDependants(int combinedNumDependants) {
		this.combinedNumDependants = combinedNumDependants;
	}
	public String getRepaymentType() {
		return repaymentType;
	}
	public void setRepaymentType(String repaymentType) {
		this.repaymentType = repaymentType;
	}
	public String getLoanTerm() {
		return loanTerm;
	}
	public void setLoanTerm(String loanTerm) {
		this.loanTerm = loanTerm;
	}
	public String getRepaymentFrequency() {
		return repaymentFrequency;
	}
	public void setRepaymentFrequency(String repaymentFrequency) {
		this.repaymentFrequency = repaymentFrequency;
	}
	public String getDepositAmount() {
		return depositAmount;
	}
	public void setDepositAmount(String depositAmount) {
		this.depositAmount = depositAmount;
	}
	public String getLoanAmt() {
		return loanAmt;
	}
	public void setLoanAmt(String loanAmt) {
		this.loanAmt = loanAmt;
	}
	public PropertyInfo getPurchaseProperty() {
		return purchaseProperty;
	}
	public void setPurchaseProperty(PropertyInfo purchaseProperty) {
		this.purchaseProperty = purchaseProperty;
	}
	public Boolean getFirstHomeBuyerInd() {
		return firstHomeBuyerInd;
	}
	public void setFirstHomeBuyerInd(Boolean firstHomeBuyerInd) {
		this.firstHomeBuyerInd = firstHomeBuyerInd;
	}
	public Boolean getCalculateForMeInd() {
		return calculateForMeInd;
	}
	public void setCalculateForMeInd(Boolean calculateForMeInd) {
		this.calculateForMeInd = calculateForMeInd;
	}
	public Boolean getShareAddressInd() {
		return shareAddressInd;
	}
	public void setShareAddressInd(Boolean shareAddressInd) {
		this.shareAddressInd = shareAddressInd;
	}
	public Boolean getNewPropertyInd() {
		return newPropertyInd;
	}
	public void setNewPropertyInd(Boolean newPropertyInd) {
		this.newPropertyInd = newPropertyInd;
	}
	public String getFixedLoanTerm() {
		return fixedLoanTerm;
	}
	public void setFixedLoanTerm(String fixedLoanTerm) {
		this.fixedLoanTerm = fixedLoanTerm;
	}
	public String getInterestOnlyTerm() {
		return interestOnlyTerm;
	}
	public void setInterestOnlyTerm(String interestOnlyTerm) {
		this.interestOnlyTerm = interestOnlyTerm;
	}
	
	
}
