package au.com.stgeorge.mbank.model.mortgageinfo;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_NULL)
public class LenderInfo implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -5902840553513760427L;
	
	private int index;
	//private String lenedrId;
	private String firstName;
	private String familyName;
	//private String mobile;
	private String phoneNumber;
	private boolean isMobile;
	private String email;
	private String branchName;
	private String addresssLine1;
	private String addresssLine2;
	private String addresssLine3;
	private String postcode;
	private String suburb;
	private String state;
	@JsonInclude(Include.NON_DEFAULT)
	public int getIndex() {
		return index;
	}
	public void setIndex(int index) {
		this.index = index;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getFamilyName() {
		return familyName;
	}
	public void setFamilyName(String familyName) {
		this.familyName = familyName;
	}
	/*
	public String getMobile() {
		return mobile;
	}
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}
	*/
	public String getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getBranchName() {
		return branchName;
	}
	public void setBranchName(String branchName) {
		this.branchName = branchName;
	}
	public String getAddresssLine1() {
		return addresssLine1;
	}
	public void setAddresssLine1(String addresssLine1) {
		this.addresssLine1 = addresssLine1;
	}
	public String getAddresssLine2() {
		return addresssLine2;
	}
	public void setAddresssLine2(String addresssLine2) {
		this.addresssLine2 = addresssLine2;
	}
	public String getAddresssLine3() {
		return addresssLine3;
	}
	public void setAddresssLine3(String addresssLine3) {
		this.addresssLine3 = addresssLine3;
	}
	public String getPostcode() {
		return postcode;
	}
	public void setPostcode(String postcode) {
		this.postcode = postcode;
	}
	public String getSuburb() {
		return suburb;
	}
	public void setSuburb(String suburb) {
		this.suburb = suburb;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public boolean getIsMobile() {
		return isMobile;
	}
	public void setIsMobile(boolean isMobile) {
		this.isMobile = isMobile;
	}
		
}
