package au.com.stgeorge.mbank.controller.loanApplication;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Service;

import au.com.stgeorge.digitalsec.logger.DigitalSecLogger;
import au.com.stgeorge.digitalsec.logger.DigitalSecLogggerVO;
import au.com.stgeorge.framework.common.logging.Logger;
import au.com.stgeorge.framework.common.model.User;
import au.com.stgeorge.framework.common.util.StringMethods;
import au.com.stgeorge.ibank.businessobject.BusinessException;
import au.com.stgeorge.ibank.businessobject.ResourceException;
import au.com.stgeorge.ibank.businessobject.loanapplication.LoanApplicationService;
import au.com.stgeorge.ibank.common.cache.IBankParams;
import au.com.stgeorge.ibank.common.cache.IBankRefershParams;
import au.com.stgeorge.ibank.common.cache.MortgageParams;
import au.com.stgeorge.ibank.loanApplication.LoanApplicationDetail;
import au.com.stgeorge.ibank.loanApplication.util.LoanAppConstants;
import au.com.stgeorge.ibank.loanApplication.util.LoanProdTypeEnum;
import au.com.stgeorge.ibank.mortgage.util.MortgageUtil;
import au.com.stgeorge.ibank.onlinereg.valueobject.OnlineRegReqLogVO;
import au.com.stgeorge.ibank.service.valueobject.SafiVO;
import au.com.stgeorge.ibank.util.ServiceHelper;
import au.com.stgeorge.ibank.util.StringUtil;
import au.com.stgeorge.ibank.valueobject.ExternalLinkVO;
import au.com.stgeorge.ibank.valueobject.LabelValueVO;
import au.com.stgeorge.ibank.valueobject.database.CodesVO;
import au.com.stgeorge.ibank.valueobject.database.OriginsVO;
import au.com.stgeorge.ibank.valueobject.transfer.IBankCommonData;
import au.com.stgeorge.mbank.controller.customer.LogonHelper;
import au.com.stgeorge.mbank.model.common.GhostTileResp;
import au.com.stgeorge.mbank.model.common.IMBResp;
import au.com.stgeorge.mbank.model.loanApplication.LoanStatusResp;
import au.com.stgeorge.mbank.model.request.OnlineRegReq;
import au.com.stgeorge.mbank.model.response.CustomerRegResp;
import au.com.stgeorge.mbank.model.response.newaccount.LoanApplicationStatusResp;
import au.com.stgeorge.mbank.session.IGenericSession;
import au.com.stgeorge.mbank.session.MobileSession;
import au.com.stgeorge.mbank.session.MobileSessionImpl;
import au.com.stgeorge.mbank.util.MBAppConstants;
import au.com.stgeorge.mbank.util.MBAppHelper;
import au.com.stgeorge.mbank.util.MBAppUtils;
import au.com.stgeorge.mobilebank.businessobject.impl.ExternalLinkServiceImpl;
import au.com.stgeorge.perflogger.PerformanceLogger;


@Service
public class LoanApplicationHelper {
	
	
	private MBAppHelper mbAppHelper;
	
 
	private LogonHelper logonHelper;
	
  
    private DigitalSecLogger digitalSecLogger;
    
    private static String ONLINE_REG_SESSION_ID_PREFIX = "SR_";
    private static final String APP_VER_COOKIE = "AppVersion";
	public static final String APPVERSION_COOKIE_DOC_UPLOAD = "_docupload";
	
	
	public String populateNewApplicationCustomer(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, OnlineRegReqLogVO onlineRegReqLogVo) throws BusinessException {
		PerformanceLogger perfLogger = new PerformanceLogger();
		mbAppHelper = new MBAppHelper();
		logonHelper = new LogonHelper();
		digitalSecLogger = new DigitalSecLogger();
		String logName = startPerformanceLog(httpServletRequest,perfLogger);
    	OnlineRegReq req = null;
    	//Customer customer = null;
		String origin = null;
		String status= null;
		IGenericSession genericSession = null;
		MobileSession mobileSession = new MobileSessionImpl();
		DigitalSecLogggerVO digitalSecLoggerVO = new DigitalSecLogggerVO();
		digitalSecLoggerVO.setTranName(DigitalSecLogger.SELFREG_FOR_ONLINE_BANKING);
		boolean isNew = true;
		String customerName = "";
		try {
		    //origin = req.getOrigin();
		    origin =onlineRegReqLogVo.getOrigin();
		    CodesVO codesVo = IBankParams.getCodesData(origin, IBankParams.ONLINE_REG_STATUS, IBankParams.ONLINEREG_SUCCESS_STATUS);
		    if (codesVo != null) {
		    	status = codesVo.getMessage();
		    }
		    digitalSecLoggerVO.setStatus(status);
		    mobileSession.getSessionContext(httpServletRequest);
		    IBankCommonData commonData = new MBAppHelper().populateIBankCommonData(mobileSession, httpServletRequest);
		    String sessionId = null;
		    commonData.setOrigin(origin);
		    digitalSecLoggerVO.setCommonLogData(mbAppHelper.getCommonLogDataForOnlineReg(commonData, sessionId));
		    digitalSecLoggerVO.setUserAgent(commonData.getUserAgent());

		    SafiVO safiVO = populateSafiVO(httpServletRequest, onlineRegReqLogVo);
		    digitalSecLoggerVO.setValues(onlineRegReqLogVo.toDigitalSecurityLog());
		    LoanApplicationService loanApplicationService =  (LoanApplicationService)ServiceHelper.getBean("loanApplService");
		    isNew = loanApplicationService.performChecksAndGetNewApplicationCustomer(commonData, onlineRegReqLogVo, safiVO, digitalSecLoggerVO);
		   // commonData.setCustomer(customer);
		    createSession(commonData, onlineRegReqLogVo, httpServletRequest, httpServletResponse,mobileSession, "");
		    
		    //19E1 - Income Verification changed method signature to send application reference number
		    LoanApplicationDetail loanDetails=loanApplicationService.getLoanApplicationDetails(commonData,onlineRegReqLogVo.getSourceApplRefNum());
		    if(loanDetails != null){
			    loanDetails.setGCISNum(commonData.getCustomer().getGcis());
			    loanDetails.setSourceApplRefNum(loanDetails.getSourceApplRefNum());
			    loanDetails.setSourceAppl(LoanAppConstants.LOAN_APPL_SOURCE);
			    loanDetails.setModifiedBy(commonData.getCustomer().getGcis());
			    loanDetails.setStatus(LoanAppConstants.LOAN_STATUS_PENDING);
			    loanDetails.setOrigin(commonData.getOrigin());
			    loanDetails.setEmailAddress(commonData.getCustomer().getContactDetail().getEmail());
			    loanDetails.setFirstName(commonData.getCustomer().getFirstName());   
			    loanApplicationService.updateCustomerDetails(commonData, loanDetails);
		    }else{
		    	Logger.error("There is no entry in loan application details for this customerr ", this.getClass());
			    BusinessException exp = new BusinessException(BusinessException.SYSTEM_UNAVILABLE);
			    throw exp;
		    }
		    		    
		    if(!isNew){
		    	customerName = commonData.getCustomer().getFirstName();
		    }
			} catch (BusinessException e) {
		    Logger.info("BusinessException in OnlineRegistrationController - validateData() - [key: " + e.getKey() + "]", e, this.getClass());
	
		    if ((e.getKey() == BusinessException.ONLINE_REG_GENERIC_ERROR || e.getKey() == BusinessException.ONLINE_REG_FATAL_ERROR) && !DigitalSecLogger.SUCCESS.equalsIgnoreCase(digitalSecLoggerVO.getStatus())) 
		    {
			  digitalSecLogger.log(digitalSecLoggerVO);
			  
		    }
		    throw e;
			} catch (Exception e) {
			    Logger.error("Exception Inside OnlineRegistrationController - validateData() ", e, this.getClass());
			    BusinessException exp = new BusinessException(BusinessException.SYSTEM_UNAVILABLE);
			    throw exp;
			} finally {
			    if (genericSession != null) {
				genericSession.updateSession();
			    }
			    endPerformanceLog(logName,perfLogger);
			}
		return customerName;
    }
	
	   public SafiVO populateSafiVO(HttpServletRequest request, OnlineRegReqLogVO onlineRegReqLogVO) {
			SafiVO safiVO = new SafiVO();
			safiVO.setHttpAccept(request.getHeader("Accept"));
			safiVO.setHttpAcceptChars(request.getHeader("Accept-Charset"));
			safiVO.setHttpAcceptEncoding(request.getHeader("Accept-Encoding"));
			safiVO.setHttpAcceptLanguage(request.getHeader("Accept-Language"));
			safiVO.setHttpReferrer(request.getHeader("Referer"));
			safiVO.setIpAddress(MBAppHelper.resolveIPAddress(request, onlineRegReqLogVO.getOrigin()));
			safiVO.setUserAgent(request.getHeader("User-Agent"));
			safiVO.setClientTransactionId(onlineRegReqLogVO.getRegReqToken());
			safiVO.setOrigin(onlineRegReqLogVO.getOrigin());

			return safiVO;
	    }
	   
	   private void createSession(IBankCommonData commonData, OnlineRegReqLogVO onlineRegReqVO, HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse,MobileSession mbsession, String logName) throws BusinessException{
			IGenericSession genericSession = null ;
			User myUser = commonData.getUser(); 		
		
			myUser.setAttribute(IBankParams.USEROBJ_IPADDRESS, commonData.getIpAddress());
			commonData.setUser(myUser);
			
			commonData.setOrigin(onlineRegReqVO.getOrigin());
			
			
			
			try{
				genericSession = logonHelper.createCompassSession(myUser, commonData.getOrigin(), "WebSrv", httpServletRequest, ONLINE_REG_SESSION_ID_PREFIX);			
				genericSession.setAttribute(MobileSessionImpl.CUSTOMER_OBLECT, commonData.getCustomer());
				genericSession.setAttribute(MobileSessionImpl.ORIGIN_OBLECT, commonData.getOrigin());	
			//	genericSession.setLoggedonState(LogonHelper.LOGGEDON_STATE_ONLINE_REGISTRATION);
				Logger.info("***User-Agent: " +  "***SessionId: " + genericSession.getId(), this.getClass());
				httpServletResponse.setHeader("Set-Cookie", MBAppConstants.ONLINE_REG_SESS_CONSTANT + "=" + genericSession.getId()   + "; HttpOnly ; Secure    " + "; path=/mb");		
			} catch (Exception e){
				Logger.error("Exception Inside createSession() ", e, this.getClass());
				throw new BusinessException(BusinessException.SYSTEM_UNAVILABLE);
			} finally {
				if ( genericSession != null )
					genericSession.updateSession();				
			}		
		}
		
	   private String startPerformanceLog(HttpServletRequest httpRequest, PerformanceLogger perfLogger) {
			perfLogger.startAllLogs();
			String logName = MBAppUtils.getLogName(httpRequest);
			perfLogger.startLog(logName);
			return logName;
	    }

	    private void endPerformanceLog(String logName,PerformanceLogger perfLogger) {
			perfLogger.endLog(logName);
			perfLogger.endAllLogs();
	    }
	    
		public IMBResp populateCustomerRegResponse(LoanApplicationDetail loanApplicationDetail,IBankCommonData ibankCommonData, String can) throws BusinessException
		{
			CustomerRegResp customerRegResp = null;
			String origin=ibankCommonData.getOrigin();
			OriginsVO myOriginVO = IBankParams.getOrigin(origin);
		    String bankName=myOriginVO.getName();
		    
			if(null!=loanApplicationDetail){
				customerRegResp=new CustomerRegResp();
				customerRegResp.setCan(can);			
				customerRegResp.setFirstName(StringUtil.toCamelCaseString(ibankCommonData.getCustomer().getFirstName()));//TODO If first name is not there then what? if 1,2,3 send 2 otherwise 3				
				customerRegResp.setApplStatus(getSourceApplStatus(origin,loanApplicationDetail.getSourceApplStatus(),loanApplicationDetail.getLvRequired(), loanApplicationDetail.getNextStepInd(),loanApplicationDetail.getProductType()));
				customerRegResp.setEmailAddress(getHelpDeskEmail(origin,loanApplicationDetail));
				customerRegResp.setHelpdesk(getHelpDeskNumber(origin,loanApplicationDetail));
				customerRegResp.setLoanApplNextStepInfo(populateNextStepsInfo(loanApplicationDetail,bankName));
				customerRegResp.setBranchName(bankName);
				customerRegResp.setApplicationNumber(loanApplicationDetail.getSourceApplRefNum());
				
				if(IBankParams.isSwitchOn(IBankParams.IV_SWITCH)) {
					Logger.debug("IV switch ON", this.getClass());
					// Added for Income Verification : SBGEXP-4261
					// Display "Send Doc" button when - 
					// Next step indicator = 1 & status = conditionally approved
					// Next step indicator = 2 & status = conditionally approved
					// Next step indicator = 3 & status = conditionally approved
					// Note : status will be "conditionally approved" in all the above mentioned cases.
								
					if(null!=loanApplicationDetail.getNextStepInd() && (loanApplicationDetail.getNextStepInd() == 1 || loanApplicationDetail.getNextStepInd() == 2 || loanApplicationDetail.getNextStepInd() ==3)
							&&
							loanApplicationDetail.getSourceApplStatus().equals(LoanAppConstants.SOURCE_APPL_CONDITIONAL_APPROVED_STATUS)){
						customerRegResp.setSendDoc(true);
					} else {
						customerRegResp.setSendDoc(false);
					}	
				}else{
					Logger.debug("IV switch OFF", this.getClass());
					if(null!=loanApplicationDetail.getNextStepInd() && loanApplicationDetail.getNextStepInd()==1){
						customerRegResp.setSendDoc(true);
					}
					else{
						customerRegResp.setSendDoc(false);
					}	
				}
				if(loanApplicationDetail.getProductType() != null && !loanApplicationDetail.getProductType().trim().equals(""))
				{
					customerRegResp.setProductType(loanApplicationDetail.getProductType());
					Logger.debug("Product Type : "+ customerRegResp.getProductType() ,this.getClass());
				}
				
							
			}
			
			return customerRegResp;
		}
		
		/* No idea what this method does
		 * Please include some documentation  
		 * */
		
		private int getNextStep(LoanApplicationDetail loanApplDetail)
        {   
			long nextStepInd = loanApplDetail.getNextStepInd();
            int nextStep=2;
            String nextStpInd=String.valueOf(nextStepInd);                    
            switch(nextStpInd){
            case "1":
            case "2":
            case "3":
                    nextStep = 2;
                    break;
            case "10":
              	 if(IBankParams.isSwitchOn(IBankParams.IV_SWITCH) && LoanAppConstants.SOURCE_APPL_REFERRED_STATUS.equalsIgnoreCase(loanApplDetail.getSourceApplStatus())){
              		 nextStep = 2;
              	 }else
              		 nextStep = 3;
              	 break;
            default:
                    nextStep = 3;
                    break;
              }
            return nextStep;
        }

		private String getNextStepHeader(LoanApplicationDetail loanApplicationDetail)
		{			
			String nextStepHeader=null;
			long nextStepInd = loanApplicationDetail.getNextStepInd();
			
			CodesVO codesVO = IBankParams.getCodesData(IBankParams.DEFAULT_ORIGIN, IBankParams.EFINANCE_NEXT_STEP_HEADER, String.valueOf(nextStepInd));
			if (codesVO != null){
				nextStepHeader=codesVO.getMessage();
			}
			if(StringMethods.isEmptyString(nextStepHeader)){
				if(nextStepInd > 3){
					nextStepHeader= "Send income documents";
				}
			}
			
			// Added for IV - 19E1
			if(IBankParams.isSwitchOn(IBankParams.IV_SWITCH)){
				if(null !=loanApplicationDetail.getNextStepInd() && (loanApplicationDetail.getNextStepInd()==1 || nextStepInd > 3)) { 
						if(loanApplicationDetail.getProductType().equals(LoanProdTypeEnum.CRA.getProductCode()) ||
								loanApplicationDetail.getProductType().equals(LoanProdTypeEnum.OVD.getProductCode()) ||
								loanApplicationDetail.getProductType().equals(LoanProdTypeEnum.GSL.getProductCode())){
						codesVO = IBankParams.getCodesData(IBankParams.DEFAULT_ORIGIN, IBankParams.EFINANCE_NEXT_STEP_HEADER, String.valueOf(LoanAppConstants.NEXT_STEP_HEADER_VERIFY_YOUR_INCOME));
					 }else if (loanApplicationDetail.getProductType().equals(LoanProdTypeEnum.PLA.getProductCode())){
						codesVO = IBankParams.getCodesData(IBankParams.DEFAULT_ORIGIN, IBankParams.EFINANCE_NEXT_STEP_HEADER, String.valueOf(LoanAppConstants.NEXT_STEP_HEADER_VERIFY_YOUR_INFORMATION));						
					 }
				}
				else if(null !=loanApplicationDetail.getNextStepInd() && loanApplicationDetail.getNextStepInd()==2) {
					if (loanApplicationDetail.getProductType().equals(LoanProdTypeEnum.PLA.getProductCode())){
						codesVO = IBankParams.getCodesData(IBankParams.DEFAULT_ORIGIN, IBankParams.EFINANCE_NEXT_STEP_HEADER, String.valueOf(LoanAppConstants.NEXT_STEP_HEADER_RECEIVED_VERIFICATION_DOCUMENTS));						
					}
				}				
				
				if (codesVO != null){
					nextStepHeader=codesVO.getMessage();
				}
			}
			// Added for IV - 19E1
			
			return nextStepHeader;
		}	
	
		private String getHelpDeskEmail(String origin,LoanApplicationDetail loanApplicationDetail)
		{
			String emailAddress=null;
			CodesVO codesVO=null;
			
			if(null!=loanApplicationDetail && loanApplicationDetail.getProductType().equalsIgnoreCase(IBankParams.EFINANCE_PRODUCT_TYPE_CC)){
				codesVO = IBankParams.getCodesData(origin, IBankParams.EFINANCE_CATEGORY, IBankParams.EFINANCE_HELP_DESK_EMAIL_CC);				
			}
			else if(null!=loanApplicationDetail && (loanApplicationDetail.getProductType().equalsIgnoreCase(IBankParams.EFINANCE_PRODUCT_TYPE_PL) || loanApplicationDetail.getProductType().equalsIgnoreCase(IBankParams.EFINANCE_PRODUCT_TYPE_OVD) || loanApplicationDetail.getProductType().equalsIgnoreCase(IBankParams.EFINANCE_PRODUCT_TYPE_GSL))){
				Logger.info("***Product type:>>" +loanApplicationDetail.getProductType(), this.getClass());
				codesVO = IBankParams.getCodesData(origin, IBankParams.EFINANCE_CATEGORY, IBankParams.EFINANCE_HELP_DESK_EMAIL_PL);		
			}			
			if (codesVO != null){
				emailAddress=codesVO.getMessage();
			}
			
			Logger.info("***Email Address>>" +emailAddress, this.getClass());
			return emailAddress;
		}
		
		private String getHelpDeskNumber(String origin,LoanApplicationDetail loanApplicationDetail)
		{
			String helpdeskNumber=null;
			CodesVO codesVO=null;
			if(null!=loanApplicationDetail && loanApplicationDetail.getProductType().equalsIgnoreCase(IBankParams.EFINANCE_PRODUCT_TYPE_CC)){
				codesVO = IBankParams.getCodesData(IBankParams.DEFAULT_ORIGIN, IBankParams.EFINANCE_CATEGORY, IBankParams.EFINANCE_HELP_DESK_PHONE_CC);				
			}
			else if(null!=loanApplicationDetail && (loanApplicationDetail.getProductType().equalsIgnoreCase(IBankParams.EFINANCE_PRODUCT_TYPE_PL) || loanApplicationDetail.getProductType().equalsIgnoreCase(IBankParams.EFINANCE_PRODUCT_TYPE_OVD) || loanApplicationDetail.getProductType().equalsIgnoreCase(IBankParams.EFINANCE_PRODUCT_TYPE_GSL))){
				Logger.info("***Product type:>>" +loanApplicationDetail.getProductType(), this.getClass());
				codesVO = IBankParams.getCodesData(IBankParams.DEFAULT_ORIGIN, IBankParams.EFINANCE_CATEGORY, IBankParams.EFINANCE_HELP_DESK_PHONE_PL);	
			}
				
			if (codesVO != null){
				helpdeskNumber=codesVO.getMessage();
			}
			Logger.info("***Help desk number>>" +helpdeskNumber, this.getClass());
			return helpdeskNumber;
		}
		
		// Added for IV - 19E1
		private ArrayList<String> getTextDescArr(LoanApplicationDetail loanApplicationDetail) {
			ArrayList<String> textDescArr=new ArrayList<String>();
			if(null!=loanApplicationDetail) {
				if(null !=loanApplicationDetail.getNextStepInd() && loanApplicationDetail.getNextStepInd()==1) {
					Logger.debug("getTextDescArr :: IV_SWITCH is ON.", this.getClass());
	     		   
	             	CodesVO codesVO = null;
	             	String code = null; 
	             	
	             	if(loanApplicationDetail.getSourceApplStatus().equals(LoanAppConstants.SOURCE_APPL_CONDITIONAL_APPROVED_STATUS)) {
	            	 	if(LoanProdTypeEnum.CRA.getProductCode().equalsIgnoreCase(loanApplicationDetail.getProductType())) {
	            	 		code = LoanAppConstants.NEXT_STEP_MSG_CREDIT_CARD;
	            	 	}
	            	 	else if(LoanProdTypeEnum.PLA.getProductCode().equalsIgnoreCase(loanApplicationDetail.getProductType()) ||
	            	 			LoanProdTypeEnum.OVD.getProductCode().equalsIgnoreCase(loanApplicationDetail.getProductType()) ||
	            	 			LoanProdTypeEnum.GSL.getProductCode().equalsIgnoreCase(loanApplicationDetail.getProductType())
	            	 			) {
	            	 		code = LoanAppConstants.NEXT_STEP_MSG_PERSONAL_LOAN;
	            	 	}                   
	             	} else if(loanApplicationDetail.getSourceApplStatus().equals(LoanAppConstants.SOURCE_APPL_REFERRED_STATUS)) {
	               	 		code = LoanAppConstants.NEXT_STEP_MSG_REFERRED_STATUS;                        
	             	}
	            	 	
	             	Logger.debug("getTextDescArr :: code :: "+code, this.getClass());
	             	
	             	codesVO = IBankParams.getCodesData(IBankParams.DEFAULT_ORIGIN, IBankParams.EFINANCE_NEXT_STEP, code);
	             	
	        	 	if (codesVO != null){
	        	 		textDescArr.add(codesVO.getMessage());
	        	 	}
	             // Added for IV - 19E1
				}
				else if(null !=loanApplicationDetail.getNextStepInd() && loanApplicationDetail.getNextStepInd()==2) {
					   CodesVO codesVO = null;
		      		   String code = null;
		      		   if(loanApplicationDetail.getSourceApplStatus().equals(LoanAppConstants.SOURCE_APPL_CONDITIONAL_APPROVED_STATUS)) {
		      			   if(LoanProdTypeEnum.PLA.getProductCode().equalsIgnoreCase(loanApplicationDetail.getProductType())) {
		             	 		code = LoanAppConstants.NEXT_STEP_MSG_VERIFICATION_DOCUMENTS;
		             	 		codesVO = IBankParams.getCodesData(IBankParams.DEFAULT_ORIGIN, IBankParams.EFINANCE_NEXT_STEP, code);
		             	 		Logger.debug("getTextDescArr :: codesVO.getMessage() :: "+codesVO.getMessage(), this.getClass());
		             	 	}  
		      			   else if(LoanProdTypeEnum.CRA.getProductCode().equalsIgnoreCase(loanApplicationDetail.getProductType())
		      					   || LoanProdTypeEnum.GSL.getProductCode().equalsIgnoreCase(loanApplicationDetail.getProductType())
		      					   || LoanProdTypeEnum.OVD.getProductCode().equalsIgnoreCase(loanApplicationDetail.getProductType())) {
		             	 		code = String.valueOf(loanApplicationDetail.getNextStepInd());
		             	 		codesVO = IBankParams.getCodesData(IBankParams.DEFAULT_ORIGIN, IBankParams.EFINANCE_NEXT_STEP, code);
		             	 		Logger.debug("getTextDescArr :: codesVO.getMessage() :: "+codesVO.getMessage(), this.getClass());
		             	 	}
		      		   }
	             	   if (codesVO != null){
	             	 		textDescArr.add(codesVO.getMessage());
	             	   }
					}
			}
			return textDescArr;
		}
		
		 private ArrayList<String> getTextDescArr(LoanApplicationDetail loanApplicationDetail, String bankName)
         {
             ArrayList<String> textDescArr=null;
             if(null!=loanApplicationDetail)
             {
                   textDescArr=new ArrayList<String>();
                   
                   if(null !=loanApplicationDetail.getNextStepInd() && loanApplicationDetail.getNextStepInd()==1)
                   {
	                         if(null!=loanApplicationDetail.getIVText1()){                           
	                               textDescArr.add(loanApplicationDetail.getIVText1());
	                         }
	                         if(null!=loanApplicationDetail.getIVText2()){                           
	                               textDescArr.add(loanApplicationDetail.getIVText2());
	                         }
	                         if(null!=loanApplicationDetail.getIVText3()){                           
	                               textDescArr.add(loanApplicationDetail.getIVText3());
	                         }
	                         if(null!=loanApplicationDetail.getIVText4()){                           
	                               textDescArr.add(loanApplicationDetail.getIVText4());
	                         }
	                         if(null!=loanApplicationDetail.getIVText5()){                           
	                               textDescArr.add(loanApplicationDetail.getIVText5());
	                       }
                	   
                 }
                   else
                   {
                  	   String cdCode= ""; 
                  	   if(LoanAppConstants.SOURCE_APPL_CONTRACTACCEPT_STATUS.equals(loanApplicationDetail.getSourceApplStatus())){
                  		   cdCode = LoanAppConstants.SOURCE_APPL_CONTRACTACCEPT_STATUS;
                  	   }else{
                  		   cdCode = String.valueOf(loanApplicationDetail.getNextStepInd());
                  	   }
                         CodesVO codesVO = IBankParams.getCodesData(IBankParams.DEFAULT_ORIGIN, IBankParams.EFINANCE_NEXT_STEP, cdCode);
                         String textDesc="";
                         if (codesVO != null){
                            textDesc=codesVO.getMessage();
                         }
                    
                         if(textDesc.contains("{NOMINATED_BRANCH}")){
                               textDesc=textDesc.replace("{NOMINATED_BRANCH}", loanApplicationDetail.getBranchName());
                              // textDescArr.add(textDesc);
                         }
                         if(textDesc.contains("{BANK_NAME}")){
                               textDesc=textDesc.replace("{BANK_NAME}",bankName);
                              // textDescArr.add(textDesc);
                         }
                         if(textDesc.contains("|")){
                             String  [] textDescTempArr=textDesc.split("\\|");
                             textDescArr.add(textDescTempArr[0]);
                             textDescArr.add(textDescTempArr[1]);                        	   
                           }
                         else{
                      	   textDescArr.add(textDesc);
                         }
                   }                   
         }
             return textDescArr;
         }

		
		 private ArrayList<LoanApplicationNextStep> populateNextStepsInfo(LoanApplicationDetail loanApplDetail, String bankName){
             Logger.debug("Starting to populate next step response", getClass());
             ArrayList<LoanApplicationNextStep> loanApplicationDetails = new ArrayList();
             ArrayList<String> stepDetails = new ArrayList();
             IBankRefershParams ibankRefreshParams = (IBankRefershParams) ServiceHelper.getBean("ibankRefreshParams");
             //First step will always be static
             LoanApplicationNextStep loanApplicationNextStep1 = new LoanApplicationNextStep();
             loanApplicationNextStep1.setActiveStep(false);
             loanApplicationNextStep1.setStepCompleted(true);
             loanApplicationNextStep1.setStepName("Register for Online Banking");
             loanApplicationNextStep1.setStepDetails(stepDetails);
             
             LoanApplicationNextStep loanApplicationNextStep2 = new LoanApplicationNextStep();
             loanApplicationNextStep2.setActiveStep(getNextStep(loanApplDetail) == 2 ? true : false);
             loanApplicationNextStep2.setStepCompleted(getNextStep(loanApplDetail) == 3 ? true : false);
             loanApplicationNextStep2.setStepName(getNextStepHeader(loanApplDetail)); 
             if(loanApplicationNextStep2.isActiveStep()){
            	 stepDetails = getTextDescArr(loanApplDetail,bankName);
            	 
            	// Added for IV - 19E1
            	 if((IBankParams.isSwitchOn(IBankParams.IV_SWITCH) && (null !=loanApplDetail.getNextStepInd() && (loanApplDetail.getNextStepInd() == 1 || loanApplDetail.getNextStepInd()==2)))){ 
                	 stepDetails = getTextDescArr(loanApplDetail);  
                 }
                 if(ibankRefreshParams.isLVSwitchOn()){
                	 if(!StringMethods.isEmptyString(loanApplDetail.getLvRequired()) && 
                			 loanApplDetail.getLvRequired().equalsIgnoreCase("Y")){
                		 stepDetails = getTextDescArrLV(loanApplDetail);
                	 }
                 }
             }
             if(ibankRefreshParams.isLVSwitchOn()){
            	 if(!StringMethods.isEmptyString(loanApplDetail.getLvRequired()) && 
            			 loanApplDetail.getLvRequired().equalsIgnoreCase("Y") && 
            			 null!=loanApplDetail.getNextStepInd() && loanApplDetail.getNextStepInd()==12){
            		 loanApplicationNextStep2.setStepCompleted(false);
            	 }
             }
             
             loanApplicationNextStep2.setStepDetails(stepDetails);
             
             LoanApplicationNextStep loanApplicationNextStep3 = new LoanApplicationNextStep();
             loanApplicationNextStep3.setActiveStep(getNextStep(loanApplDetail) == 3 ? true : false);
             loanApplicationNextStep3.setStepCompleted(false);
             if(LoanProdTypeEnum.CRA.getProductCode().equalsIgnoreCase(loanApplDetail.getProductType())){
                         loanApplicationNextStep3.setStepName("Activate your card");
                   }else{
                         loanApplicationNextStep3.setStepName("Accept your contract");
                   }
             stepDetails = new ArrayList();
              if(loanApplicationNextStep3.isActiveStep()){
                stepDetails = getTextDescArr(loanApplDetail,bankName);   
             }
              
             loanApplicationNextStep3.setStepDetails(stepDetails);
             
             loanApplicationDetails.add(loanApplicationNextStep1);
             loanApplicationDetails.add(loanApplicationNextStep2);
             loanApplicationDetails.add(loanApplicationNextStep3);
             
             return loanApplicationDetails;
             
       }
		 private String getSourceApplStatus(String origin,String sourceApplStatusCode, String lvRequired, Long nextStepInd, String productType)	
			{			
				String sourceApplStatus=null;
				if(LoanAppConstants.SOURCE_APPL_CONTRACTACCEPT_STATUS.equals(sourceApplStatusCode)){
					//For Econtract Accept scenario we need t show fully approved status
					sourceApplStatusCode = LoanAppConstants.SOURCE_APPL_FULLAPPROVED_STATUS;
				}
				CodesVO codesVO = IBankParams.getCodesData(IBankParams.DEFAULT_ORIGIN, IBankParams.EFINANCE_APPL_STATUS_DESC, sourceApplStatusCode);
				
				if (codesVO != null){
					sourceApplStatus=codesVO.getMessage();
				}
				
				if(productType.equals(LoanProdTypeEnum.CRA.getProductCode())){
					sourceApplStatus = IBankParams.EFINANCE_APPL_DESC_MB_CRA + sourceApplStatus;
				}else{
					sourceApplStatus = IBankParams.EFINANCE_APPL_DESC_MB_LOAN + sourceApplStatus;
				}
				IBankRefershParams ibankRefreshParams = (IBankRefershParams) ServiceHelper.getBean("ibankRefreshParams");
				if(ibankRefreshParams.isLVSwitchOn()){
					if(!StringMethods.isEmptyString(lvRequired) && lvRequired.equalsIgnoreCase("Y")){// if the application is flagged for LV
						
						String code = String.valueOf(nextStepInd);
						
						if(null!=nextStepInd && 
								(nextStepInd==1 || 
									nextStepInd==10 || 
										nextStepInd==12)){
							code = code+"LV";
							codesVO = IBankParams.getCodesData(IBankParams.DEFAULT_ORIGIN, IBankParams.EFINANCE_NEXT_STEP, code);
							if (codesVO != null){
								sourceApplStatus=codesVO.getMessage();
							}		
						}						
					}
				}
				
				return sourceApplStatus;
			}

         public LoanApplicationStatusResp populateIncompleteStatusResp(HttpServletRequest httpRequest, MobileSession mbSession, IBankCommonData commonData, ExternalLinkVO externalLinkVO){

             
			LoanApplicationStatusResp loanStatusResp = new LoanApplicationStatusResp();

			loanStatusResp.setToken(externalLinkVO.getUnSignedData());
			loanStatusResp.setTargetURL(externalLinkVO.getUrl()+ExternalLinkServiceImpl.ACE_DATA_PARAM+externalLinkVO.getUnSignedData());
			loanStatusResp.setiPAddress(httpRequest.getRemoteAddr());
			if (null != mbSession.getDeviceID()) {
				loanStatusResp.setDeviceId(mbSession.getDeviceID());
			}
			loanStatusResp
					.setClientApiVersion(IBankParams.SWITCHING_SERVICE_APIVERSION);
	
			return loanStatusResp;
         }    
         
     	public String getHelpDeskContactNumber(String origin) {
    		MortgageParams mortgageParams = ServiceHelper.getBean("mortgageParams");
    		String baseOrigin = mortgageParams.getBaseOriginCode(origin);
    		String originHelpDeskPhone = null;
    		if(MortgageUtil.ORIGIN_SGB.equals(baseOrigin)) {
    			baseOrigin = MortgageUtil.ORIGIN_ALL;
    		}
    		List<LabelValueVO> labelValueVOList = getDMCodesData(baseOrigin,MortgageUtil.REF_DATA_CATEGORY_HELP_DESK);
    		if (labelValueVOList != null && !labelValueVOList.isEmpty()) {
    			//baseOrigin = IBankParams.getBaseOriginCode(origin);
    			for (LabelValueVO labelValueVO : labelValueVOList) {
    				if(labelValueVO.getValue().equals(baseOrigin)) {
    					originHelpDeskPhone = labelValueVO.getLabel();
    					break;
    				} 
    			}
    			if(originHelpDeskPhone == null) {
    				originHelpDeskPhone = labelValueVOList.get(0).getLabel();
    			}
    			
    		}
    		return originHelpDeskPhone;
    	}
     	
    	private  List<LabelValueVO> getDMCodesData(String origin, String category) {
    		MortgageParams mortgageParams = ServiceHelper.getBean("mortgageParams");
    		if(origin == null || origin.isEmpty()) {
    			origin = MortgageUtil.ORIGIN_ALL;
    		}
    		List<LabelValueVO> labelValueVOList = mortgageParams.getDMCodesDataLabelValueVOList(origin, category);
    		return labelValueVOList;
    	}
    	

    	// Added for Income Verification : SBGEXP-4263
    	public LoanStatusResp populateLoanApplicationDetail(IBankCommonData ibankCommonData, LoanApplicationService loanService ){
    		try{
    			Logger.debug("Inside populateLoanApplicationDetail",  this.getClass());
    			List<GhostTileResp> ghostTileList=new ArrayList<GhostTileResp>();
    			GhostTileResp ghostTileResp = new GhostTileResp();
    		 	LoanApplicationDetail loanAppDetail = loanService.getLoanApplicationDetails(ibankCommonData);
    		 	DateFormat dateFormat = new SimpleDateFormat("dd MMM yyyy"); 
    		 	LoanStatusResp loanStatusResp = new LoanStatusResp();
    		 	
    			if(loanAppDetail != null){
    		 	if(null!=loanAppDetail.getApplExpDate())
    		 	{
    	 			if(null!=loanAppDetail.getNextStepInd() && (loanAppDetail.getNextStepInd().longValue()==LoanAppConstants.NEXT_STEP_INDICATOR_7 || loanAppDetail.getNextStepInd().longValue()==LoanAppConstants.NEXT_STEP_INDICATOR_8))
    	 			{
    	 				ghostTileResp.setExpiryDate(null);
    	 		    }
    	 			else{
    	 				ghostTileResp.setExpiryDate(dateFormat.format((loanAppDetail.getApplExpDate())));
    	 			}
    		 	}

    		 	ghostTileResp.setTileType(LoanAppConstants.TILE_TYPE_EFINANCE);
    		 
    		 		if(null!= loanAppDetail.getProductType()){
    					Logger.debug("product Type : "+loanAppDetail.getProductType(),this.getClass());
    					ghostTileResp.setProductType(LoanProdTypeEnum.valueOf(loanAppDetail.getProductType()).getProductName());
    				}

    				
    			 	if(null!=loanAppDetail.getSourceApplStatus() && loanAppDetail.getSourceApplStatus().equalsIgnoreCase(LoanAppConstants.SOURCE_APPL_INCOMPLETE_STATUS)){
    			 		ghostTileResp.setTileStatusDesc(LoanAppConstants.INCOMPLETE_STATUS);
    			 		ghostTileResp.setIncompleteAppl(true);
    			 	}else{
    			 		ghostTileResp.setTileStatusDesc(getEFinanceTileStatusDesc(String.valueOf(loanAppDetail.getNextStepInd())));
    			 		ghostTileResp.setIncompleteAppl(false);
    			 		// Added for IV - 19E1
    	                if((IBankParams.isSwitchOn(IBankParams.IV_SWITCH) && null!=loanAppDetail.getNextStepInd() && (loanAppDetail.getNextStepInd() == 1 || loanAppDetail.getNextStepInd()==2))){
    	                	ghostTileResp.setTileStatusDesc(getEFinanceTileStatusDesc(loanAppDetail)); 
    	                }
    			 	}
    			 	ghostTileList.add(ghostTileResp);	 	
    
    		 	}
    			
    			loanStatusResp.setGhostTiles(ghostTileList);
    			
    			return loanStatusResp;
    		}
    		catch(Exception ex){
    			Logger.error("Eception caught while populating loan application details.", ex, this.getClass());
    		    return null;
    		}		
    	}
    	
    	// Added for Income Verification : SBGEXP-4263
    	private String getEFinanceTileStatusDesc(String tileStatusCode)
    	{			
    		String eFinanceTileStatusDesc=null;
    		List<CodesVO> codesVOList = (List<CodesVO>)IBankParams.getCodesDataList(IBankParams.EFINANCE_NEXT_STEP_HEADER);
    		for(CodesVO codeVO : codesVOList){		
    			if(null != codeVO && null != codeVO.getCode()){
    				if(codeVO.getCode().contains(tileStatusCode)){
    					eFinanceTileStatusDesc=codeVO.getMessage();
    				}
    			}
    		}				
    		return eFinanceTileStatusDesc;
    	}
    	
    	// Added for IV - 19E1
    	private  String getEFinanceTileStatusDesc(LoanApplicationDetail loanApplicationDetail) {
    			String eFinanceTileStatusDesc=null;
    			CodesVO codesVO = null;
    			if(null!=loanApplicationDetail.getNextStepInd() && loanApplicationDetail.getNextStepInd()==1) { 
    					if(loanApplicationDetail.getProductType().equals(LoanProdTypeEnum.CRA.getProductCode()) ||
    							loanApplicationDetail.getProductType().equals(LoanProdTypeEnum.OVD.getProductCode()) ||
    							loanApplicationDetail.getProductType().equals(LoanProdTypeEnum.GSL.getProductCode())){
    					codesVO = IBankParams.getCodesData(IBankParams.DEFAULT_ORIGIN, IBankParams.EFINANCE_NEXT_STEP_HEADER, String.valueOf(LoanAppConstants.NEXT_STEP_HEADER_VERIFY_YOUR_INCOME));
    					
    				 } 
    				 else if (loanApplicationDetail.getProductType().equals(LoanProdTypeEnum.PLA.getProductCode())){
    						codesVO = IBankParams.getCodesData(IBankParams.DEFAULT_ORIGIN, IBankParams.EFINANCE_NEXT_STEP_HEADER, String.valueOf(LoanAppConstants.NEXT_STEP_HEADER_VERIFY_YOUR_INFORMATION));						
    				}
    			}
    			else if(null!=loanApplicationDetail.getNextStepInd() && loanApplicationDetail.getNextStepInd()==2) {
    				if (loanApplicationDetail.getProductType().equals(LoanProdTypeEnum.PLA.getProductCode())){
    					codesVO = IBankParams.getCodesData(IBankParams.DEFAULT_ORIGIN, IBankParams.EFINANCE_NEXT_STEP_HEADER, String.valueOf(LoanAppConstants.NEXT_STEP_HEADER_RECEIVED_VERIFICATION_DOCUMENTS));						
    				}
    				else if(loanApplicationDetail.getProductType().equals(LoanProdTypeEnum.CRA.getProductCode()) ||
    						loanApplicationDetail.getProductType().equals(LoanProdTypeEnum.OVD.getProductCode()) ||
    						loanApplicationDetail.getProductType().equals(LoanProdTypeEnum.GSL.getProductCode())){
    				codesVO = IBankParams.getCodesData(IBankParams.DEFAULT_ORIGIN, IBankParams.EFINANCE_NEXT_STEP_HEADER, String.valueOf(loanApplicationDetail.getNextStepInd()));
    				} 
    			}				
    			
    			if (codesVO != null){
    				eFinanceTileStatusDesc=codesVO.getMessage();
    			}
    		return eFinanceTileStatusDesc;	
    	}
    	
        // Added for Income Verification : SBGEXP-4263 
        // Add post param IV=Y to ACE URL
        public LoanApplicationStatusResp populateIncomeVerificationResp(HttpServletRequest httpRequest, MobileSession mbSession, IBankCommonData commonData, ExternalLinkVO externalLinkVO){
            
			LoanApplicationStatusResp loanStatusResp = populateIncompleteStatusResp(httpRequest, mbSession, commonData, externalLinkVO);		
			
			if(null != loanStatusResp && null != loanStatusResp.getTargetURL()) 
				loanStatusResp.setTargetURL(loanStatusResp.getTargetURL() + "&IV=Y");	
			
			Cookie cookie = getCookie(httpRequest, APP_VER_COOKIE);
			if(isDocUploadAllowed(cookie)){
				Logger.debug("Doc Upload is allowed" , this.getClass());
				loanStatusResp.setDocUpload(Boolean.TRUE);
			}
			  
			return loanStatusResp;
        }
        
        protected Cookie getCookie(HttpServletRequest request, String cookieName) throws ResourceException{
    		Cookie[] cookies = request.getCookies();
    		Cookie cookie = null;
    		if (cookies != null){
    			for (Cookie c : cookies){
    				if (c.getName().equalsIgnoreCase(cookieName)){
    					cookie = c; 
    					break;
    				}
    			}
    		}
    		return cookie;
    	}
        
        private boolean isDocUploadAllowed(Cookie cookie){
			Logger.debug("START - isDocUploadAllowed", this.getClass());
			boolean isAllowed = false;
			if(null!= cookie && StringMethods.isValidString(cookie.getValue()) && (cookie.getValue().indexOf(APPVERSION_COOKIE_DOC_UPLOAD) >=0)){
				Logger.debug("doc upload ",this.getClass());
				isAllowed = true;
				/*String[] strAr = cookie.getValue().split("\\(");
				String[] strAr2 = strAr[1].split("/");
				String docUpload = "";
				for(int i =0 ; i < strAr2.length ;i++){	
					if(strAr2[i].endsWith(APPVERSION_COOKIE_DOC_UPLOAD)){
						docUpload = strAr2[i];
						Logger.debug("Doc upload :"+docUpload, this.getClass());
					}
				}				
				String[] strAr3 = docUpload.split("_");
				Double version = Double.valueOf(strAr3[0]);
				if(version >= 1.0){
					Logger.debug("Doc Upload Version :"+version.toString(), this.getClass());
					isAllowed = true ;
				}*/
			}
			Logger.debug("END - isDocUploadAllowed", this.getClass());
			return isAllowed;
		}
        
        protected static ArrayList<String> getTextDescArrLV(LoanApplicationDetail loanApplicationDetail) {
			ArrayList<String> textDescArr=new ArrayList<String>();
			if(null!=loanApplicationDetail) {
				if(null!=loanApplicationDetail.getNextStepInd() && loanApplicationDetail.getNextStepInd()==10) {
	             	CodesVO codesVO = null;
	             	String code = null; 
	             	if(loanApplicationDetail.getSourceApplStatus().equals(LoanAppConstants.SOURCE_APPL_REFERRED_STATUS)) {
               	 		code = LoanAppConstants.NEXT_STEP_MSG_REFERRED_STATUS;                        
	             	}
	             	Logger.debug("getTextDescArrLV :: code :: "+code, LoanApplicationHelper.class);
	             	codesVO = IBankParams.getCodesData(IBankParams.DEFAULT_ORIGIN, IBankParams.EFINANCE_NEXT_STEP, code);
	        	 	if (codesVO != null){
	        	 		textDescArr.add(codesVO.getMessage());
	        	 	}
				}
			}
			return textDescArr;
		}
    	
}

