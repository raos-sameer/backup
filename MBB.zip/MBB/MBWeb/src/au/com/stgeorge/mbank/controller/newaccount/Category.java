package au.com.stgeorge.mbank.controller.newaccount;


import java.util.List;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement; 
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.*;

@XmlRootElement(name = "Category")
@XmlAccessorType(XmlAccessType.FIELD)
public class Category
{
	@XmlAttribute
	private String name;
	
	@XmlElement(name="SubCategory")
	private List<SubCategory> subCats;
	
	@XmlAttribute
	private String type;	
	
	@XmlAttribute
	private String id;	
	
	@XmlAttribute
	private String text;
	

	public Category()
	{
		super();
	}

	public Category(String name,List<SubCategory> subCats, String type, String id, String text)
	{
		
		super();
		this.name = name;
		this.subCats = subCats;
		this.type = type;
		this.id = id;
		this.text = text;
	}



	public String getType()
	{
		return type;
	}

	public void setType(String type)
	{
		this.type = type;
	}



	public String getName()
	{
		return name;
	}

	public void setName(String name)
	{
		this.name = name;
	}

	public String getId() {
  	return id;
  }

	public void setId(String id) {
  	this.id = id;
  }

	public List<SubCategory> getSubCats() {
		return subCats;
	}

	public void setSubCats(List<SubCategory> subCats) {
		this.subCats = subCats;
	}

	public String getText() {
		return text;
	}

	public void setText(String text) {
		this.text = text;
	}

	
}
