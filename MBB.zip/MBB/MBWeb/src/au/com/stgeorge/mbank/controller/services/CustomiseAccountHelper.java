package au.com.stgeorge.mbank.controller.services;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

import au.com.stgeorge.framework.common.exception.BaseException;
import au.com.stgeorge.framework.common.logging.Logger;
import au.com.stgeorge.ibank.businessobject.BusinessException;
import au.com.stgeorge.ibank.businessobject.assembler.CreditCardChargeBackRequestVOAssemblerFactory;
import au.com.stgeorge.ibank.enumerated.CreditCardChargeBackDisputeReason;
import au.com.stgeorge.ibank.enumerated.CreditCardChargeBackRequestState;
import au.com.stgeorge.ibank.enumerated.CreditCardTransactionType;
import au.com.stgeorge.ibank.enumerated.CreditCardType;
import au.com.stgeorge.ibank.enumerated.PreferredContactMethod;
import au.com.stgeorge.ibank.valueobject.Account;
import au.com.stgeorge.ibank.valueobject.AccountAlias;
import au.com.stgeorge.ibank.valueobject.CreditCardChargeBackRequestVO;
import au.com.stgeorge.ibank.valueobject.CreditCardChargeBackTransactionVO;
import au.com.stgeorge.ibank.valueobject.Customer;
import au.com.stgeorge.ibank.valueobject.TransactionInfo;
import au.com.stgeorge.ibank.valueobject.transfer.IBankCommonData;
import au.com.stgeorge.mbank.model.common.IMBResp;
import au.com.stgeorge.mbank.model.common.RespHeader;
import au.com.stgeorge.mbank.model.request.services.CCDisputeReq;
import au.com.stgeorge.mbank.model.request.services.CustomiseAccountDetailsReq;
import au.com.stgeorge.mbank.model.request.services.CustomiseAccountReq;
import au.com.stgeorge.mbank.model.response.StatusResp;
import au.com.stgeorge.mbank.session.MobileSession;
import au.com.stgeorge.security.util.StringMethods;

/**
 * 
 * Customise Account helper
 * 
 * @author C69934
 * 
 */
@Service
public class CustomiseAccountHelper {


	/**
	 * Make CC Dispute details response
	 * 
	 * @param header
	 * @param helpDeskPhoneNumber
	 * @param disputeReasons
	 * @param cardIndexes
	 * @return
	 */
	protected List<AccountAlias> getAccountAliasListNomCheck(IBankCommonData commonData,CustomiseAccountReq customiseAccountReq) {
		List<AccountAlias> accountAliasList = new ArrayList<AccountAlias>();
		List<Account> accountList = commonData.getCustomer().getAccounts();
		boolean isSortOrderChanged = isSortOrderChanged(accountList, customiseAccountReq);
		for(int i=0;i<customiseAccountReq.getAccounts().size();i++)
		{
			CustomiseAccountDetailsReq eachAccountDtl = customiseAccountReq.getAccounts().get(i);
			AccountAlias eachAccountAlias = new AccountAlias();
			Account account = getAccountForIndex(accountList, eachAccountDtl.getAccountIndex());
			if(!"NOM".equals(account.getAccountId().getApplicationId())){
				eachAccountAlias.setAccountNumber(account.getAccountId().getAccountNumber());
				eachAccountAlias.setApplicationId(account.getAccountId().getApplicationId());
				eachAccountAlias.setProductName(account.getAccountId().getProductName());
				eachAccountAlias.setAliasName(eachAccountDtl.getAccountName());
				if(isSortOrderChanged){
					if(eachAccountDtl.getSortOrder() != null){
						eachAccountAlias.setSortOrder(String.valueOf(eachAccountDtl.getSortOrder()));
					}
				} else {
					eachAccountAlias.setSortOrder("");
				}
				accountAliasList.add(eachAccountAlias);
			}
		}
		return accountAliasList;
	}
	
	
	private boolean isSortOrderChanged(List<Account> accountList, CustomiseAccountReq customiseAccountReq){
		ArrayList<CustomiseAccountDetailsReq> customiseAccountList = customiseAccountReq.getAccounts();
		int nomCount = 0;
		for(Account account : accountList){
			if(!"NOM".equals(account.getAccountId().getApplicationId())){
				int origIndex = account.getIndex();
				CustomiseAccountDetailsReq customiseReq = customiseAccountList.get(origIndex - nomCount);
				if(origIndex != customiseReq.getAccountIndex()){
					return true;
				}
			} else {
				nomCount++;			}
		}
		
		return false;
	}
	
	private Account getAccountForIndex(List<Account> accountList, int accountIndex){
		for(Account account : accountList){
			if(account.getIndex() == accountIndex){
				return account;
			}
		}
		return null;
	}

/*	*//**
	 * Populate service request
	 * 
	 * @param request
	 * @param customer
	 * @param selectedAcct
	 * @param mobileSession
	 * @param ip
	 * @return
	 * @throws BaseException
	 *//*
	protected CreditCardChargeBackRequestVO createCreditCardChargeBackRequestVo(CCDisputeReq request, IBankCommonData commonData, Customer customer,
			Account selectedAcct, MobileSession mobileSession, String ip) throws BaseException {
		
		if (mobileSession.getTransactionHistory() == null || mobileSession.getTransactionHistory().getTransactions() == null
				|| mobileSession.getTransactionHistory().getTransactions().size() < request.getDisputeTrans().size()) 
			throw new BusinessException(BusinessException.TRANSACTION_HISTORY_NO_RESULTS);

		
		List<TransactionInfo> txnHistoryList = (List<TransactionInfo>) mobileSession.getTransactionHistory().getTransactions();
		List<CreditCardChargeBackTransactionVO> txnList = new ArrayList<CreditCardChargeBackTransactionVO>();

		for (int i = 0; i < request.getDisputeTrans().size(); i++) {
			TransactionInfo transactionInfo = (TransactionInfo) txnHistoryList.get(request.getDisputeTrans().get(i).getTranIndex() - 1);
			
			CreditCardChargeBackDisputeReason ccChargeBackDisputeReason = null;
			if (request.getDisputeTrans().get(i).getReason().contains("Service") || request.getDisputeTrans().get(i).getReason().contains("Merchandise")) {
				ccChargeBackDisputeReason = CreditCardChargeBackDisputeReason.SERVICE_OR_MERCHANDISE_NOT_RECEIVED;
			} else if (request.getDisputeTrans().get(i).getReason().contains("Others")) {
				ccChargeBackDisputeReason = CreditCardChargeBackDisputeReason.OTHER;
			} else {
				ccChargeBackDisputeReason = CreditCardChargeBackDisputeReason.fromString(request.getDisputeTrans().get(i).getReason());
			}
			CreditCardTransactionType transType = transactionInfo.getAmount().signum() == 1 ? CreditCardTransactionType.CR
					: CreditCardTransactionType.DR;
			String desription = StringMethods.isEmptyString(transactionInfo.getDescription1()) ? transactionInfo.getDescription2() : transactionInfo
					.getDescription1();
			CreditCardChargeBackTransactionVO newCcVo = new CreditCardChargeBackTransactionVO(null, null, transactionInfo.getDate(), desription,
					transactionInfo.getAmount(), transType,// TransactionType
					ccChargeBackDisputeReason,// Disputed Reason
					(request.getDisputeTrans().get(i).getAdditionalInfo()==null)? "" : request.getDisputeTrans().get(i).getAdditionalInfo());// Additonal Info
			txnList.add(newCcVo);
		}
		String customerName = customer.getFirstName() + " " + customer.getLastName();
		if (customerName.length() > 24)
			customerName = customerName.substring(0, 24);

		String emailAddr = null;
		if (customer.getContactDetail() != null)
			emailAddr = customer.getContactDetail().getEmail();

		PreferredContactMethod preferredContactNumber = null;
		if (StringMethods.isEmptyString(request.getPrefContact())) {
			preferredContactNumber = PreferredContactMethod.NONE;
		} else {
			preferredContactNumber = PreferredContactMethod.fromString(request.getPrefContact());
		}

		CreditCardChargeBackRequestVO ccChargeBackRequestVO = CreditCardChargeBackRequestVOAssemblerFactory.getInstance()
				.createCreditCardChargeBackRequestVO(CreditCardChargeBackRequestState.NEW, customer.getGcis(), selectedAcct.getBrand(),
						selectedAcct.getAccountId(), selectedAcct.getAssociatedAlias(), customerName, request.getCardName(),
						CreditCardType.fromString(CreditCardType.fromLogoCodeStringVP(selectedAcct.getAccountId().getGroupCode()).stringValue()),
						preferredContactNumber, emailAddr, (request.getSendEmail() != null) ? request.getSendEmail() : false, customer.getGcis(),
						txnList.toArray(new CreditCardChargeBackTransactionVO[txnList.size()]), mobileSession.getSessionID(), ip);
		ccChargeBackRequestVO.setGdwOrigin(commonData.getGdwOrigin());
		
		return ccChargeBackRequestVO;
	}

	*//**
	 * Validate dispute request
	 * 
	 * @param request
	 * @throws BusinessException
	 *//*
	protected void validateDisputeCCTxnReq(CCDisputeReq request) throws BusinessException {
		if (request.getDisputeTrans().size() > 3) {
			throw new BusinessException(BusinessException.SYSTEM_UNAVILABLE, "Number of dispute transaction is more than 3 ");
		}
	}

	*//**
	 * Populate cc dispute response
	 * 
	 * @param header
	 * @param status
	 * @return
	 *//*
	protected IMBResp populateCCDisputeResponse(RespHeader header, Integer status) {
		StatusResp response = new StatusResp(header);
		response.setStatus(status);
		Logger.info("Response: " + response, this.getClass());
		return response;
	}*/

}
