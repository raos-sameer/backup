package au.com.stgeorge.mbank.model.request.payments;
import au.com.stgeorge.mbank.model.common.IMBReq;
import au.com.stgeorge.mbank.model.common.ReqHeader;

/**
 * Pay to mobile request
 * 
 * @author C38854
 * 
 */
public class TapAndPayReq implements IMBReq {

	/**
	 * 
	 */
	private static final long serialVersionUID = -1152319232660898837L;

	private ReqHeader header;
	public ReqHeader getHeader() {
		return header;
	}

	public void setHeader(ReqHeader header) {
		this.header = header;
	}
	

	

}
