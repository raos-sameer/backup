package au.com.stgeorge.mbank.model.accountinfo;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_NULL)
public class InsuranceAccountDetailResp {

	private String policyNumber;
	private String startDate;
	private String expiryDate;
	private String premiumAmt;
	private String premiumType;
	private List<CoverageInfo> coverageList;
	private String claimUrl;
	private String productUrl;
	private boolean additionalInfo;
	
	public String getClaimUrl() {
		return claimUrl;
	}
	public void setClaimUrl(String claimUrl) {
		this.claimUrl = claimUrl;
	}
	public String getPolicyNumber() {
		return policyNumber;
	}
	public void setPolicyNumber(String policyNumber) {
		this.policyNumber = policyNumber;
	}
	public String getExpiryDate() {
		return expiryDate;
	}
	public void setExpiryDate(String expiryDate) {
		this.expiryDate = expiryDate;
	}
	public String getPremiumAmt() {
		return premiumAmt;
	}
	public void setPremiumAmt(String premiumAmt) {
		this.premiumAmt = premiumAmt;
	}
	public String getPremiumType() {
		return premiumType;
	}
	public void setPremiumType(String premiumType) {
		this.premiumType = premiumType;
	}
	public List<CoverageInfo> getCoverageList() {
		return coverageList;
	}
	public void setCoverageList(List<CoverageInfo> coverageList) {
		this.coverageList = coverageList;
	}
	public String getProductUrl() {
		return productUrl;
	}
	public void setProductUrl(String productUrl) {
		this.productUrl = productUrl;
	}
	public String getStartDate() {
		return startDate;
	}
	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}
	public boolean isAdditionalInfo() {
		return additionalInfo;
	}
	public void setAdditionalInfo(boolean additionalInfo) {
		this.additionalInfo = additionalInfo;
	}
	
	
	
}
